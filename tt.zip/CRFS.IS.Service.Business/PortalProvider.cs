﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using Microsoft.EntityFrameworkCore;

using Google.Protobuf.Collections;

using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.Util;
using CRFS.IS.Service.Security;
using CRFS.IS.Service.Common;

namespace CRFS.IS.Service.Business
{
    public static class PortalProvider
    {
        public static Config GetPDFConfig(GetConfigRequest request)
        {
            var ret = new Config();
            using(var ctx = new ApplicationConfigurationContext())
            {
                ret = ctx.TblClientPdfcompression.Where(x => x.ClientId == request.Id)
                                                 .Select(x => new Config
                                                 {
                                                     Active = x.Active ? 1 : 0,
                                                     ClientId = x.ClientId,
                                                     ClientDL = string.IsNullOrEmpty(x.NotifyClientDl) ? "" : x.NotifyClientDl,
                                                     Comment = string.IsNullOrEmpty(x.Comment) ? "" : x.Comment,
                                                     CrfsDL = string.IsNullOrEmpty(x.NotifyCrfsDl) ? "" : x.NotifyCrfsDl,
                                                     Cron = x.Cron,
                                                     ErrorDir = x.ErrorFolder,
                                                     Limit = x.SizeLimitMb ?? 0,
                                                     SourceDir = x.SourceFolder,
                                                     TargetDir = x.DestinationFolder
                                                 }).SingleOrDefault();
            }
            return ret;
        }
        public static SaveConfigReply SavePDFConfig(Config config, string token)
        {
            var ret = new SaveConfigReply();
            var uname = "";
            using (var pctx = new PortalContext())
            {
                uname = pctx.TblSession.Where(x => x.Token == token).Select(x => x.Uname).SingleOrDefault();
            }
            using (var ctx = new ApplicationConfigurationContext())
            {
                var cid = (from u in ctx.LkpUsers
                           where u.Login == uname
                           select u.UserId).SingleOrDefault();

                var con = ctx.TblClientPdfcompression.Where(x => x.ClientId == config.ClientId).SingleOrDefault();
                if(con == null)
                {
                    ctx.TblClientPdfcompression.Add(new TblClientPdfcompression {
                        Active = config.Active == 1,
                        ClientId = config.ClientId,
                        AddedBy = cid,
                        AddedDate = DateTime.Now,
                        Comment = config.Comment,
                        Cron = config.Cron,
                        DestinationFolder = config.TargetDir,
                        ErrorFolder = config.ErrorDir,
                        SourceFolder = config.SourceDir,
                        NotifyClientDl = config.ClientDL,
                        NotifyCrfsDl = config.CrfsDL,
                        SizeLimitMb = config.Limit,
                        UpdatedBy = cid,
                        UpdatedDate = DateTime.Now
                    });
               
                } else
                {
                    con.Active = config.Active == 1;
                    con.Comment = config.Comment;
                    con.Cron = config.Cron;
                    con.DestinationFolder = config.TargetDir;
                    con.ErrorFolder = config.ErrorDir;
                    con.NotifyClientDl = config.ClientDL;
                    con.NotifyCrfsDl = config.CrfsDL;
                    con.SizeLimitMb = config.Limit;
                    con.SourceFolder = config.SourceDir;
                    con.UpdatedBy = cid;
                    con.UpdatedDate = DateTime.Now;
                }
                ctx.SaveChanges();
            }
            return ret;
        }
        public static GetKeyValueListReply GetKeyValueListByType(string type, string id, string token)
        {
            var temp = new List<GRpc.KeyValuePair>();
            var ret = new GetKeyValueListReply();
            
            var acctx = new ApplicationConfigurationContext();
            var portalctx = new PortalContext();
            var lactx = new LossAnalysisNewContext();
        
            try
            {
                switch (type.ToUpper())
                {
                    case "CLIENT":
                        var lkpuser = SessionProvider.GetUser(token);
                        if (acctx.XrefClientsUsers.Any( x => (lkpuser.AllClientAccess ?? false) || (x.UserId == lkpuser.UserId && !x.MarkedForDelete)))
                        {
                            temp = acctx.LkpClients.Where(x => x.Active && (lkpuser.AllClientAccess ?? false 
                                                                            || x.XrefClientsUsers.Any(y => y.UserId == lkpuser.UserId && !y.MarkedForDelete)))
                                .Select(x => new GRpc.KeyValuePair
                                {
                                    Key = x.ClientId.ToString(),
                                    Value = x.ClientDisplayName
                                }).OrderBy(x => x.Value).ToList();
                        }
                        break;
                    case "CLIENTTIERRATE":
                        var dt = DateTime.Now;
                        temp = lactx.ClientTier.Where(x => dt >= x.EffectiveDate && dt <= x.ExpiryDate).Select(x => new GRpc.KeyValuePair
                        {
                            Key = x.ClientId.ToString(), Value = x.TierRate.ToString()
                        }).ToList();
                        break;
                    case "LACLAIMTYPE":
                        temp = lactx.LkpTypeCat.Include(x => x.LkpType).Where(x => x.LkpType.LkpTypeName == "ClaimType")
                            .Select(x => new GRpc.KeyValuePair
                             {
                                Key = x.LkpTypeCatId.ToString(),
                                Value = x.LkpTypeCatName
                             }).OrderBy(x => x.Value).ToList();
                        break; 
                    case "LACLOSEREASON":
                        temp = lactx.LkpTypeCat.Include(x => x.LkpType).Where(x => x.LkpType.LkpTypeName == "ClosingReasons")
                           .Select(x => new GRpc.KeyValuePair
                           {
                               Key = x.LkpTypeCatId.ToString(),
                               Value = x.LkpTypeCatName
                           }).OrderBy(x => x.Value).ToList();
                        break;
                    case "LAINVESTOR":
                        temp = acctx.TblControlInvestors.Select(x => new GRpc.KeyValuePair
                        {
                            Key = x.InvestorId.ToString(),
                            Value = x.InvestorName
                        }).OrderBy(x => x.Value).ToList();
                        break;
                    case "LALOAN":
                        temp = lactx.Loan.Select(x => new GRpc.KeyValuePair
                        {
                            Key = x.LoanId.ToString(),
                            Value = x.LoanNumber
                        }).OrderByDescending(x => x.Key).ToList();
                        break;
                    case "LAMILESTONE":
                        temp = lactx.LkpMileStoneType.Select(x => new GRpc.KeyValuePair
                        {
                            Key = x.MilestoneId.ToString(),
                            Value = x.MilestoneType
                        }).OrderBy(x => x.Value).ToList();
                        break;
                    case "LAUSER":
                        temp = portalctx.VwUserPermit.Where(x => x.AppName == "Portal.Home" 
                                                               && x.Uiname == "LossAnalysis"
                                                               && x.Uitype == "SubApp"
                                                               && x.Uipermit >= (int)Constant.UIPrivilege.Read)
                            .Select(x => new GRpc.KeyValuePair{
                                            Key = x.Uid.ToString(),
                                            Value = x.UserName
                                        }).OrderBy(x => x.Value).ToList();
                        break;
                    case "OCCUPANCYSTATUS":
                        temp = lactx.LkpVacancyStatus.Select(x => new GRpc.KeyValuePair
                        {
                            Key = x.LkpTypeCatId.ToString(),
                            Value = x.LkpTypeCatName
                        }).ToList();
                        break;
                    case "SESSIONMESSAGE":
                        var ds = Util.SessionMessage.Get(token, "Compress", Convert.ToInt32(id));
                        foreach(var d in ds)
                        {
                            temp.Add(new GRpc.KeyValuePair { Key = d.Key, Value = d.Value });
                        }
                        break;
                  
                    default:
                        break;
                }
                ret.KVList.AddRange(temp);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                acctx.Dispose();
                portalctx.Dispose();
                lactx.Dispose();
            }
            return ret;
        }
        public static GetHistoryReply GetCompressionHist()
        {
            var ret = new GetHistoryReply();
            try
            {
                using (var ctx = new PortalContext())
                {
                    var temp = ctx.VwClientPdfcompressionSummary.OrderByDescending(x => x.BatchId).ToList();
                    foreach (var h in temp)
                    {
                        ret.Hists.Add(new History
                        {
                            BatchId = h.BatchId,
                            ClientName = h.ClientDisplayName,
                            RunBy = h.RunBy,
                            RunDate = h.RunDate.ToString("MM/dd/yyyy HH:mm:ss"),
                            TtlCompressed = h.TtlComp ?? 0,
                            TtlError = h.TtlErr ?? 0,
                            TtlFile = h.TtlFile ?? 0,
                            TtlTime = h.TtlTime ?? 0
                        });
                    }
                }

                return ret;
            } catch(Exception ex)
            {
                return ret;
            }
        }
        public static GetBatchDetailReply GetBatchDetail(int batchid)
        {
            var ret = new GetBatchDetailReply();
            try
            {
                using (var ctx = new PortalContext())
                {
                    var temp = ctx.TblClientPdfcompressionBatchDetail.Where(x => x.BatchId == batchid)
                        .OrderBy(x => x.TimeStart).ToList();
                    var i = 1;
                    foreach (var h in temp)
                    {
                         ret.Details.Add(new BatchDetail
                        {
                            DetailId = i++,
                            FName = Path.GetFileName(h.FileName),
                            Reason = h.Reason,
                            SizeAfter = h.FileSizeAfter ?? 0,
                            SizeBefore = h.FileSizeBefore,
                            Status = h.Status,
                            TimeEnd = h.TimeEnd == null ? "" : h.TimeEnd.Value.ToString("MM/dd/yyyy HH:mm:ss"),
                            TimeStart = h.TimeStart.ToString("MM/dd/yyyy HH:mm:ss")
                        
                        });
                    }
                }

                return ret;
            }
            catch (Exception ex)
            {
                return ret;
            }
        }
    }
}
