﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Google.Protobuf.WellKnownTypes;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.GRpc;

namespace CRFS.IS.Service.Business
{
    public class LossAnalysisProvider
    {
        private IConfiguration _config;
        private ILogger _logger;
        private int _userid;

        public LossAnalysisProvider(IConfiguration config, ILogger logger, int uid)
        {
            _config = config;
            _logger = logger;
            _userid = uid;
        }

        public LoanData GetLoanData(string loannumber)
        {
            var ret = new LoanData();
            
            var acctx = new ApplicationConfigurationContext();
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    var id = lactx.Loan.Where(x => x.LoanNumber == loannumber).Select(x => x.LoanId).SingleOrDefault();

                    var temp = lactx.Loan.Where(x => x.LoanId == id)
                                         .Include(x => x.Investor)
                                         .Include(x => x.PropertyStateNavigation).Select(x => new LoanData
                                         {
                                             LoanId = x.LoanId,
                                             BorrowerFirstName = x.BorrowerFirstName.GetSafeString(),
                                             BorrowerLastName = x.BorrowerLastName.GetSafeString(),
                                            // BuyOutDate = Timestamp.FromDateTime(x.BuyOutDate ?? Convert.ToDateTime(Constant.EmptyDateTime).SetKind(DateTimeKind.Utc),
                                             BuyOutDate = x.BuyOutDate.GetSafeString(),
                                             ClaimTypeId = x.ClaimTypeId.GetSafeValue<int>(),
                                             ClientId = x.ClientId.GetSafeValue<int>(),
                                             CloseDate = x.CloseDate.GetSafeString(),
                                             ClosingReasonId = x.ClosingReason ?? 0,
                                            // DebentureInterestRate = (double)x.DebentureInterestRate,
                                             FHACaseNumber = x.FhacaseNumber,
                                             InvestorId = x.InvestorId ?? 0,
                                             InvestorName = x.Investor.InvestorName.GetSafeString(),
                                             LossAnalysisDueDate = x.LossAnalysisDueDate.GetSafeString(),
                                             LoanNumber = x.LoanNumber,
                                             LossAnalysisReferralDate = x.LossAnalysisReferralDate.GetSafeString(),
                                             NoteRate = (double)(x.NoteRate ?? 0.0m.GetSafeValue<decimal>()),
                                             PropertyCity = x.PropertyCity.GetSafeString(),
                                             PropertyLotSize = x.PropertyLotSize ?? 0,
                                             PropertyStateId = x.PropertyState ?? 0,
                                             PropertyStateName = x.PropertyStateNavigation.StateName.GetSafeString(),
                                             PropertyStreetAddressLine1 = x.PropertyStreetAddressLine1.GetSafeString(),
                                             PropertyStreetAddressLine2 = x.PropertyStreetAddressLine2.GetSafeString(),
                                             PropertyZipCode = x.PropertyZipCode.GetSafeString(),
                                             ServiceTransferDate = x.ServiceTransferDate.GetSafeString()
                                         }).SingleOrDefault();

                    temp.ClaimTypeName = lactx.LkpType.Where(x => x.LkpTypeName == "ClaimType")
                        .Select(x => x.LkpTypeCat.Where(y => y.LkpTypeCatId == temp.ClaimTypeId).Select(y => y.LkpTypeCatName).Single()).Single();
                    temp.ClientName = acctx.LkpClients.Where(x => x.ClientId == temp.ClientId).Select(x => x.ClientDisplayName).SingleOrDefault();
                    temp.ClosingReasonName = temp.ClosingReasonId > 0 ? lactx.LkpType.Where(x => x.LkpTypeName == "ClosingReasons")
                                           .Select(x => x.LkpTypeCat.Where(y => y.LkpTypeCatId == temp.ClosingReasonId).Select(y => y.LkpTypeCatName).Single()).Single()
                                           : "";
                    var lms = lactx.LoanMilestone.Where(x => x.LoanId == temp.LoanId).Include(x => x.Milestone).ToList();
                    var partaassign = lms.Where(x => x.Milestone.MilestoneType == "Part-A Assignment").SingleOrDefault();
                    var partbassign = lms.Where(x => x.Milestone.MilestoneType == "Part-B Assignment").SingleOrDefault();
                    if(partaassign != null)
                    {
                        temp.PartAAnalystId = partaassign.AssignedUser ?? 0;
                        temp.PartAAnalystName = temp.PartAAnalystId > 0 ? acctx.LkpUsers.Where(x => x.UserId == temp.PartAAnalystId).Select(x => x.UserName).SingleOrDefault()
                                : "";
                    }
                    else
                    {
                        temp.PartAAnalystId = 0;
                        temp.PartAAnalystName = "";
                    }
                    if (partbassign != null)
                    {
                        temp.PartBAnalystId = partbassign.AssignedUser ?? 0;
                        temp.PartBAnalystName = temp.PartBAnalystId > 0 ? acctx.LkpUsers.Where(x => x.UserId == temp.PartBAnalystId).Select(x => x.UserName).SingleOrDefault()
                                : "";
                    }
                    else
                    {
                        temp.PartBAnalystId = 0;
                        temp.PartBAnalystName = "";
                    }
                    var pacdate = lms.Where(x => x.Milestone.MilestoneType == "Part-A Complete Date").Select(x => x.MilestoneDate).SingleOrDefault();
                    var pbcdate = lms.Where(x => x.Milestone.MilestoneType == "Part-B Complete Date").Select(x => x.MilestoneDate).SingleOrDefault();
                    temp.PartACompleteDate = pacdate.GetSafeString();
                    temp.PartBCompleteDate = pbcdate.GetSafeString();
                    var maxorder = lms.Max(x => x.Milestone.MilestoneOrder);
                    var stt = lms.Where(x => /*x.MilestoneDate == lms.Max(y => y.MilestoneDate) 
                                                  &&*/ x.Milestone.MilestoneOrder == maxorder).SingleOrDefault();
                 
                    if(stt != null)
                    {   
                        temp.StatusId = stt.MilestoneId;
                        temp.StatusDate = stt.MilestoneDate.GetSafeString();
                        temp.StatusName = lactx.LkpMileStoneType.Where(x => x.MilestoneId == stt.MilestoneId).Select(x => x.MilestoneType).Single();
                    }
  
                    ret = temp;
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                acctx.Dispose();
            }
            return ret;
        }
        public CompPartA GetCompPartA(int loanid)
        {
            var ret = new CompPartA();

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    //var lutypelist = 
                    var temp = lactx.LoanPartAcomp.Include(x => x.LoanLivingUnits)
                        .Include(x => x.Loan)
                        .Include(x => x.Loan.PropertyStateNavigation).Where(x => x.LoanId == loanid).SingleOrDefault();

                    ret.AuthorizedBidAmount = (double)temp.AuthorizedBidAmount.GetSafeValue<decimal?>();
                    ret.BankruptcyLiftDate = temp.BankruptcyLiftDate.GetSafeString();
                    ret.ClaimFiledDate = temp.ClaimFiledDate.GetSafeString();
                    ret.ConveyanceExtensionDate = temp.ConveyanceExtensionDate.GetSafeString();
                    ret.DateDeedOrAssignmentFiled = temp.DateDeedOrAssignmentFiled.GetSafeString();
                    ret.DateOfPossessionAcquisition = temp.DateOfPossessionAcquisition.GetSafeString();
                    ret.DebentureInterestRate = (double)temp.DebentureInterestRate.GetSafeValue<decimal?>();
                    ret.DeedInLieuDate = temp.DeedInLieuDate.GetSafeString();
                    ret.DueDateOfLastPaymentInstallment = temp.DueDateOfLastPaymentInstallment.GetSafeString();
                    ret.EndorsementDate = temp.EndorsementDate.GetSafeString();
                    ret.ForeclosureFirstLegalDate = temp.ForeclosureFirstLegalDate.GetSafeString();
                    ret.InstitutionExtensionDate = temp.InstitutionExtensionDate.GetSafeString();
                    ret.MortgageeCurtailmentDate = temp.MortgageeCurtailmentDate.GetSafeString();
                    ret.NumberOfLivingUnits = (int)temp.NumberOfLivingUnits.GetSafeValue<int?>();
                    ret.LoanId = temp.LoanId;
                    ret.OriginalPrincipalBalance = (double)temp.OriginalPrincipalBalance.GetSafeValue<decimal?>();
                    ret.PartACompId = temp.PartAcompId;
                    ret.UnpaidPrincipalBalance = (double)temp.UnpaidPrincipalBalance.GetSafeValue<decimal?>();
                    ret.BorrowerFirstName = temp.Loan.BorrowerFirstName.GetSafeString();
                    ret.BorrowerLastName = temp.Loan.BorrowerLastName.GetSafeString();
                    ret.PropertyCity = temp.Loan.PropertyCity.GetSafeString();
                    ret.PropertyStateId = (int)temp.Loan.PropertyState.GetSafeValue<int?>();
                    ret.PropertyStateName = temp.Loan.PropertyStateNavigation.StateName.GetSafeString();
                    ret.PropertyStreetAddressLine1 = temp.Loan.PropertyStreetAddressLine1.GetSafeString();
                    ret.PropertyStreetAddressLine2 = temp.Loan.PropertyStreetAddressLine2.GetSafeString();
                    ret.PropertyZipCode = temp.Loan.PropertyZipCode.GetSafeString();
                  
                    foreach(var lu in temp.LoanLivingUnits)
                    {
                        ret.LivingUnits.Add(new LivingUnit
                        {
                            LivingUnitPartATypeId = lactx.LkpLivingUnitPartAtype.Where(x => x.LkpTypeCatName == "Part-A Completed").Select(x => x.LkpTypeCatId).Single(),
                            LoanLivingUnitId = lu.LoanLivUnitId,
                            PartAId = (int)lu.PartAcompId.GetSafeValue<int?>(),
                            UnitNum = lu.UnitNum,
                            UnitOccupancyStatusId = (int)lu.UnitOccupancyStatus.GetSafeValue<int?>(),
                            UnitOccupantName = lu.UnitOccupantName.GetSafeString(),
                            UnitSecuredDate = lu.UnitSecuredDate.GetSafeString(),
                            UnitVacatedDate = lu.UnitVacatedDate.GetSafeString()
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
         
            return ret;
        }
        public string SaveCompPartA(CompPartA data)
        {
            var ret = Constant.Success;
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    var lutype = lactx.LkpLivingUnitPartAtype.Where(x => x.LkpTypeCatName == "Part-A Completed").Single();
                    if(data.PartACompId > 0)
                    {
                        var cpa = lactx.LoanPartAcomp.Where(x => x.PartAcompId == data.PartACompId).Single();
                        cpa.AuthorizedBidAmount = Convert.ToDecimal(data.AuthorizedBidAmount);
                        cpa.BankruptcyLiftDate = Convert.ToDateTime(data.BankruptcyLiftDate);
                        cpa.ClaimFiledDate = Convert.ToDateTime(data.ClaimFiledDate);
                        cpa.ConveyanceExtensionDate = Convert.ToDateTime(data.ConveyanceExtensionDate);
                        cpa.DateDeedOrAssignmentFiled = Convert.ToDateTime(data.DateDeedOrAssignmentFiled);
                        cpa.DateOfPossessionAcquisition = Convert.ToDateTime(data.DateOfPossessionAcquisition);
                        cpa.DebentureInterestRate = Convert.ToDecimal(data.DebentureInterestRate);
                        cpa.DeedInLieuDate = Convert.ToDateTime(data.DeedInLieuDate);
                        cpa.DueDateOfLastPaymentInstallment = Convert.ToDateTime(data.DueDateOfLastPaymentInstallment);
                        cpa.EndorsementDate = Convert.ToDateTime(data.EndorsementDate);
                        cpa.ForeclosureFirstLegalDate = Convert.ToDateTime(data.ForeclosureFirstLegalDate);
                        cpa.InstitutionExtensionDate = Convert.ToDateTime(data.InstitutionExtensionDate);
                        cpa.NumberOfLivingUnits = data.NumberOfLivingUnits;
                        cpa.ModifiedBy = _userid;
                        cpa.ModifiedDate = DateTime.Now;
                        cpa.MortgageeCurtailmentDate = Convert.ToDateTime(data.MortgageeCurtailmentDate);
                        cpa.OriginalPrincipalBalance = Convert.ToDecimal(data.OriginalPrincipalBalance);
                        cpa.UnpaidPrincipalBalance = Convert.ToDecimal(data.UnpaidPrincipalBalance);

                        var lus = lactx.LoanLivingUnits.Where(x => x.PartAcompId == data.PartACompId).ToList();
                        lactx.LoanLivingUnits.RemoveRange(lus);

                        foreach(var d in data.LivingUnits)
                        {
                            lactx.LoanLivingUnits.Add(new LoanLivingUnits
                            {
                                AddedBy = _userid,
                                AddedDate = DateTime.Now,
                                LivingUnitPartAtypeId = lutype.LkpTypeCatId,
                                LoanLivUnitId = 0,
                                ModifiedBy = _userid,
                                ModifiedDate = DateTime.Now,
                                PartAcompId = data.PartACompId,
                                UnitNum = (short)d.UnitNum,
                                UnitOccupancyStatus = d.UnitOccupancyStatusId,
                                UnitOccupantName = d.UnitOccupantName,
                                UnitSecuredDate = Convert.ToDateTime(d.UnitSecuredDate.GetSafeDateString()),
                                UnitVacatedDate = Convert.ToDateTime(d.UnitVacatedDate.GetSafeDateString())
                            }) ;
                        }
                    }
                    else
                    {
                        var temp = new LoanPartAcomp {
                            AddedBy = _userid,
                            AddedDate = DateTime.Now,
                            AuthorizedBidAmount = Convert.ToDecimal(data.AuthorizedBidAmount),
                            BankruptcyLiftDate = Convert.ToDateTime(data.BankruptcyLiftDate.GetSafeDateString()),
                            ClaimFiledDate = Convert.ToDateTime(data.ClaimFiledDate.GetSafeDateString()),
                            ConveyanceExtensionDate = Convert.ToDateTime(data.ConveyanceExtensionDate.GetSafeDateString()),
                            DateDeedOrAssignmentFiled = Convert.ToDateTime(data.DateDeedOrAssignmentFiled.GetSafeDateString()),
                            DateOfPossessionAcquisition = Convert.ToDateTime(data.DateOfPossessionAcquisition.GetSafeDateString()),
                            DebentureInterestRate = Convert.ToDecimal(data.DebentureInterestRate),
                            DeedInLieuDate = Convert.ToDateTime(data.DeedInLieuDate.GetSafeDateString()),
                            DueDateOfLastPaymentInstallment = Convert.ToDateTime(data.DueDateOfLastPaymentInstallment.GetSafeDateString()),
                            EndorsementDate = Convert.ToDateTime(data.EndorsementDate.GetSafeDateString()),
                            ForeclosureFirstLegalDate = Convert.ToDateTime(data.ForeclosureFirstLegalDate.GetSafeDateString()),
                            InstitutionExtensionDate = Convert.ToDateTime(data.InstitutionExtensionDate.GetSafeDateString()),
                            LoanId = data.LoanId,
                            ModifiedBy = _userid,
                            ModifiedDate = DateTime.Now,
                            MortgageeCurtailmentDate = Convert.ToDateTime(data.MortgageeCurtailmentDate.GetSafeString()),
                            NumberOfLivingUnits = data.NumberOfLivingUnits,
                            OriginalPrincipalBalance = Convert.ToDecimal(data.OriginalPrincipalBalance),
                            UnpaidPrincipalBalance = Convert.ToDecimal(data.UnpaidPrincipalBalance),
                            PartAcompId = 0
                        };
                        lactx.LoanPartAcomp.Add(temp);
                        lactx.SaveChanges();

                        foreach (var d in data.LivingUnits)
                        {
                            lactx.LoanLivingUnits.Add(new LoanLivingUnits
                            {
                                AddedBy = _userid,
                                AddedDate = DateTime.Now,
                                LivingUnitPartAtypeId = lutype.LkpTypeCatId,
                                LoanLivUnitId = 0,
                                ModifiedBy = _userid,
                                ModifiedDate = DateTime.Now,
                                PartAcompId = temp.PartAcompId,
                                UnitNum = (short)d.UnitNum,
                                UnitOccupancyStatus = d.UnitOccupancyStatusId,
                                UnitOccupantName = d.UnitOccupantName,
                                UnitSecuredDate = Convert.ToDateTime(d.UnitSecuredDate.GetSafeDateString()),
                                UnitVacatedDate = Convert.ToDateTime(d.UnitVacatedDate.GetSafeDateString())
                            });
                        }
                    }
                    lactx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetCompAOPReply GetCompAOP(int loanid)
        {
            var ret = new GetCompAOPReply();

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    var aopt = lactx.LkpAoptype.ToList();
                    var compparta = lactx.LoanPartAcomp.Where(x => x.LoanId == loanid).Single();

                    var temp = lactx.LoanAop.Where(x => x.LoanId == loanid).ToList();

                    foreach (var t in temp) {
                        ret.CompAOPs.Add( new CompAOP
                        {
                            AOPId = t.Aopid,
                            LoanId = t.LoanId,
                            AOPTypeId = t.Aoptype,
                            AOPTypeName = aopt.Where(y => y.LkpTypeCatId == t.Aoptype).Select(y => y.LkpTypeCatName).Single(),
                            FHASettlementAmount = (double)t.FhasettlementAmount.GetValueOrDefault(),
                            InterestEndDate = t.InterestEndDate.GetSafeString(),
                            InterestStartDate = t.InterestStartDate.GetSafeString(),
                            LessOffsetAmount = (double)t.LessOffsetAmount.GetSafeValue<decimal?>(),
                            ReceivedDate = t.ReceivedDate.GetSafeString(),
                            SettlementDate = t.SettlementDate.GetSafeString(),
                            TotalInterestPaid = (double)t.TotalInterestPaid.GetSafeValue<decimal?>(),
                            DebentureInterestRate = (double)compparta.DebentureInterestRate.GetSafeValue<decimal?>(),
                            DueDateOfLastPaymentInstallment = compparta.DueDateOfLastPaymentInstallment.GetSafeString(),
                            UnpaidPrincipalBalance = (double)compparta.UnpaidPrincipalBalance.GetSafeValue<decimal?>()
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public string SaveCompAOP(CompAOP data)
        {
            var ret = Constant.Success;
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    if(data.AOPId > 0)
                    {
                        var aop = lactx.LoanAop.Where(x => x.Aopid == data.AOPId).Single();
                        aop.ModifiedBy = _userid;
                        aop.ModifiedDate = DateTime.Now;
                        aop.FhasettlementAmount = Convert.ToDecimal(data.FHASettlementAmount);
                        aop.InterestEndDate = Convert.ToDateTime(data.InterestEndDate.GetSafeDateString());
                        //aop.Aoptype = data.AOPTypeId;
                        aop.InterestStartDate = Convert.ToDateTime(data.InterestStartDate.GetSafeDateString());
                        aop.LessOffsetAmount = Convert.ToDecimal(data.LessOffsetAmount);
                        aop.ReceivedDate = Convert.ToDateTime(data.ReceivedDate);
                        aop.SettlementDate = Convert.ToDateTime(data.SettlementDate);
                        aop.TotalInterestPaid = Convert.ToDecimal(data.TotalInterestPaid);
                    } else
                    {
                        lactx.LoanAop.Add(new LoanAop
                        {
                            LoanId = data.LoanId,
                            Aopid = 0,
                            AddedBy = _userid,
                            AddedDate = DateTime.Now,
                            Aoptype = data.AOPTypeId,
                            FhasettlementAmount = Convert.ToDecimal(data.FHASettlementAmount),
                            InterestEndDate = Convert.ToDateTime(data.InterestEndDate),
                            InterestStartDate = Convert.ToDateTime(data.InterestStartDate),
                            LessOffsetAmount = Convert.ToDecimal(data.LessOffsetAmount),
                            ModifiedBy = _userid,
                            ModifiedDate = DateTime.Now,
                            ReceivedDate = Convert.ToDateTime(data.ReceivedDate),
                            SettlementDate = Convert.ToDateTime(data.SettlementDate),
                            TotalInterestPaid = Convert.ToDecimal(data.TotalInterestPaid)
                        });
                    }

                    if(lactx.LoanPartAcomp.Any(x => x.LoanId == data.LoanId))
                    {
                        var pac = lactx.LoanPartAcomp.Where(x => x.LoanId == data.LoanId).Single();
                        pac.DebentureInterestRate = Convert.ToDecimal(data.DebentureInterestRate);
                    }
                    lactx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public CompPartB GetCompPartB(int loanid)
        {
            var ret = new CompPartB();

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    ret = lactx.VwLoanPartBdata.Where(x => x.LoanId == loanid).Select(x => new CompPartB
                    {
                        LoanId = x.LoanId,
                       // PartBId = x.PartBblockId,
                        AOPAdditionAmount = (double)x.AopadditionAmount.GetSafeValue<decimal?>(),
                        AOPDeductionAmount = (double)x.AopdeductionAmount.GetSafeValue<decimal?>(),
                        AOPInterestAmount = (double)x.AopinterestAmount.GetSafeValue<decimal?>(),
                        Note = x.Note.GetSafeString(),
                        PartBBlockId = x.PartBblockId,
                        PartBBlockName = x.PartBblockName,
                        SubAdditionAmount = (double)x.SubAdditionAmount.GetSafeValue<decimal?>(),
                        SubDeductionAmount = (double)x.SubDeductionAmount.GetSafeValue<decimal?>(),
                        SubInterestAmount = (double)x.SubInterestAmount.GetSafeValue<decimal?>()
                    }).SingleOrDefault();
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        private List<LoanPartBdata> FlatDataToPartBData(CompPartB pb, LossAnalysisNewContext ctx)
        {
            var ret = new List<LoanPartBdata>();
            var col = ctx.LkpPartBcolumn.ToList();
            var typ = ctx.LkpPartBtype.ToList();
            if(pb.SubAdditionAmount > 0)
            {
                ret.Add(new LoanPartBdata
                {
                    AddedBy = _userid,
                    AddedDate = DateTime.Now,
                    ModifiedBy = _userid,
                    ModifiedDate = DateTime.Now,
                    Amount = Convert.ToDecimal(pb.SubAdditionAmount),
                    LoanId = pb.LoanId,
                    PartBblockId = pb.PartBBlockId,
                    PartBcolumn = col.Where(x => x.LkpTypeCatName == "Addition").Select(x => x.LkpTypeCatId).Single(),
                    PartBtype = typ.Where(x => x.LkpTypeCatName == "Submitted Claim").Select(x => x.LkpTypeCatId).Single(),
                    PartBid = 0
                });
            }
            if (pb.SubDeductionAmount > 0)
            {
                ret.Add(new LoanPartBdata
                {
                    AddedBy = _userid,
                    AddedDate = DateTime.Now,
                    ModifiedBy = _userid,
                    ModifiedDate = DateTime.Now,
                    Amount = Convert.ToDecimal(pb.SubDeductionAmount),
                    LoanId = pb.LoanId,
                    PartBblockId = pb.PartBBlockId,
                    PartBcolumn = col.Where(x => x.LkpTypeCatName == "Deduction").Select(x => x.LkpTypeCatId).Single(),
                    PartBtype = typ.Where(x => x.LkpTypeCatName == "Submitted Claim").Select(x => x.LkpTypeCatId).Single(),
                    PartBid = 0
                });
            }
            if (pb.SubInterestAmount > 0)
            {
                ret.Add(new LoanPartBdata
                {
                    AddedBy = _userid,
                    AddedDate = DateTime.Now,
                    ModifiedBy = _userid,
                    ModifiedDate = DateTime.Now,
                    Amount = Convert.ToDecimal(pb.SubInterestAmount),
                    LoanId = pb.LoanId,
                    PartBblockId = pb.PartBBlockId,
                    PartBcolumn = col.Where(x => x.LkpTypeCatName == "Interest").Select(x => x.LkpTypeCatId).Single(),
                    PartBtype = typ.Where(x => x.LkpTypeCatName == "Submitted Claim").Select(x => x.LkpTypeCatId).Single(),
                    PartBid = 0
                });
            }
            if (pb.AOPAdditionAmount > 0)
            {
                ret.Add(new LoanPartBdata
                {
                    AddedBy = _userid,
                    AddedDate = DateTime.Now,
                    ModifiedBy = _userid,
                    ModifiedDate = DateTime.Now,
                    Amount = Convert.ToDecimal(pb.AOPAdditionAmount),
                    LoanId = pb.LoanId,
                    PartBblockId = pb.PartBBlockId,
                    PartBcolumn = col.Where(x => x.LkpTypeCatName == "Addition").Select(x => x.LkpTypeCatId).Single(),
                    PartBtype = typ.Where(x => x.LkpTypeCatName == "Advice of Payment").Select(x => x.LkpTypeCatId).Single(),
                    PartBid = 0
                });
            }
            if (pb.AOPDeductionAmount > 0)
            {
                ret.Add(new LoanPartBdata
                {
                    AddedBy = _userid,
                    AddedDate = DateTime.Now,
                    ModifiedBy = _userid,
                    ModifiedDate = DateTime.Now,
                    Amount = Convert.ToDecimal(pb.AOPDeductionAmount),
                    LoanId = pb.LoanId,
                    PartBblockId = pb.PartBBlockId,
                    PartBcolumn = col.Where(x => x.LkpTypeCatName == "Deduction").Select(x => x.LkpTypeCatId).Single(),
                    PartBtype = typ.Where(x => x.LkpTypeCatName == "Advice of Payment").Select(x => x.LkpTypeCatId).Single(),
                    PartBid = 0
                });
            }
            if (pb.AOPInterestAmount > 0)
            {
                ret.Add(new LoanPartBdata
                {
                    AddedBy = _userid,
                    AddedDate = DateTime.Now,
                    ModifiedBy = _userid,
                    ModifiedDate = DateTime.Now,
                    Amount = Convert.ToDecimal(pb.AOPInterestAmount),
                    LoanId = pb.LoanId,
                    PartBblockId = pb.PartBBlockId,
                    PartBcolumn = col.Where(x => x.LkpTypeCatName == "Interest").Select(x => x.LkpTypeCatId).Single(),
                    PartBtype = typ.Where(x => x.LkpTypeCatName == "Advice of Payment").Select(x => x.LkpTypeCatId).Single(),
                    PartBid = 0
                });
            }
            return ret;
        }
        public string SaveCompPartB(SaveCompPartBRequest data)
        {
            var ret = Constant.Success;
            if (data.CompPartBs.Count == 0)
                throw new Exception("No data to save");

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    using (var trans = lactx.Database.BeginTransaction())
                    {
                        try
                        {
                            var cpbs = lactx.LoanPartBdata.Where(x => x.LoanId == data.CompPartBs.First().LoanId).ToList();
                            var cpbns = lactx.LoanPartBdataNote.Where(x => x.LoanId == data.CompPartBs.First().LoanId).ToList();
                            lactx.LoanPartBdata.RemoveRange(cpbs);

                            foreach(var pb in data.CompPartBs)
                            {
                                var temp = FlatDataToPartBData(pb, lactx);
                                lactx.LoanPartBdata.AddRange(temp);

                                lactx.LoanPartBdataNote.Add(new LoanPartBdataNote
                                {
                                    AddedBy = _userid,
                                    AddedDate = DateTime.Now,
                                    ModifiedBy = _userid,
                                    ModifiedDate = DateTime.Now,
                                    LoanId = pb.LoanId,
                                    Note = pb.Note,
                                    PartBblockId = pb.PartBBlockId,
                                    PartBnoteId = 0,
                                    Passed = pb.Passed == 1
                                });
                            }

                            lactx.SaveChanges();
                            trans.Commit();
                        }
                        catch
                        {
                            trans.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public string SaveLoan(LoanData ld)
        {
            var ret = Constant.Success;
            try
            {
                 using(var lactx = new LossAnalysisNewContext())
                 {
                    if (ld.LoanId > 0)
                    {
                        var loan = lactx.Loan.SingleOrDefault(x => x.LoanId == ld.LoanId);
                        loan.ModifiedBy = _userid;
                        loan.ModifiedDate = DateTime.Now;
                        loan.BorrowerFirstName = ld.BorrowerFirstName;
                        loan.BorrowerLastName = ld.BorrowerLastName;
                        loan.BuyOutDate = Convert.ToDateTime(ld.BuyOutDate.GetSafeDateString());
                        loan.ClaimTypeId = ld.ClaimTypeId;
                        loan.ClientId = ld.ClientId;
                        loan.CloseDate = Convert.ToDateTime(ld.CloseDate.GetSafeDateString());
                        loan.ClosingReason = ld.ClosingReasonId;
                       // loan.DebentureInterestRate = Convert.ToDecimal(Math.Round(ld.DebentureInterestRate, 4));
                        loan.FhacaseNumber = ld.FHACaseNumber;
                        loan.InvestorId = ld.InvestorId;
                        loan.LossAnalysisDueDate = Convert.ToDateTime(ld.LossAnalysisDueDate.GetSafeDateString());
                        loan.LossAnalysisReferralDate = Convert.ToDateTime(ld.LossAnalysisReferralDate.GetSafeDateString());
                        loan.NoteRate = Convert.ToDecimal(Math.Round(ld.NoteRate, 4));
                        loan.PropertyCity = ld.PropertyCity;
                        loan.PropertyLotSize = ld.PropertyLotSize;
                        loan.PropertyState = ld.PropertyStateId;
                        loan.PropertyStreetAddressLine1 = ld.PropertyStreetAddressLine1;
                        loan.PropertyStreetAddressLine2 = ld.PropertyStreetAddressLine2;
                        loan.PropertyZipCode = ld.PropertyZipCode;
                        loan.ServiceTransferDate = Convert.ToDateTime(ld.ServiceTransferDate.GetSafeDateString());

                        var lms = lactx.LoanMilestone.Where(x => x.LoanId == ld.LoanId).ToList();
                        if(!lms.Any(x => x.MilestoneId == ld.StatusId))
                        {
                            var ms = new LoanMilestone
                            {
                                LoanMilestoneId = 0,
                                LoanId = ld.LoanId,
                                MilestoneId = ld.StatusId,
                                MilestoneDate = Convert.ToDateTime(ld.StatusDate.GetSafeDateString()),
                                AddedBy = _userid,
                                AddedDate = DateTime.Now,
                                ModifiedBy = _userid,
                                ModifiedDate = DateTime.Now,
                                AssignedUser = 0
                            };
                            lactx.LoanMilestone.Add(ms);
                        } else
                        {
                            var ms = lms.Where(x => x.MilestoneId == ld.StatusId).Single();
                            ms.MilestoneDate = Convert.ToDateTime(ld.StatusDate.GetSafeDateString());
                            ms.ModifiedBy = _userid;
                            ms.ModifiedDate = DateTime.Now;
                        }
                    }
                    else
                    {
                        var loan = new Loan
                        {
                            LoanId = ld.LoanId,
                            AddedBy = _userid,
                            AddedDate = DateTime.Now,
                            BorrowerFirstName = ld.BorrowerFirstName,
                            BorrowerLastName = ld.BorrowerLastName,
                            BuyOutDate = Convert.ToDateTime(ld.BuyOutDate.GetSafeDateString()),
                            ClaimTypeId = ld.ClaimTypeId,
                            ClientId = ld.ClientId,
                            CloseDate = Convert.ToDateTime(ld.CloseDate.GetSafeDateString()),
                            ClosingReason = ld.ClosingReasonId,
                        //    DebentureInterestRate = Convert.ToDecimal(Math.Round(ld.DebentureInterestRate, 4)),
                            FhacaseNumber = ld.FHACaseNumber,
                            InvestorId = ld.InvestorId,
                            LoanNumber = ld.LoanNumber,
                            LossAnalysisDueDate = Convert.ToDateTime(ld.LossAnalysisDueDate.GetSafeDateString()),
                            LossAnalysisReferralDate = Convert.ToDateTime(ld.LossAnalysisReferralDate.GetSafeDateString()),
                            ModifiedBy = _userid,
                            ModifiedDate = DateTime.Now,
                            NoteRate = Convert.ToDecimal(Math.Round(ld.NoteRate, 4)),
                            PropertyCity = ld.PropertyCity,
                            PropertyLotSize = ld.PropertyLotSize,
                            PropertyState = ld.PropertyStateId,
                            PropertyStreetAddressLine1 = ld.PropertyStreetAddressLine1,
                            PropertyStreetAddressLine2 = ld.PropertyStreetAddressLine2,
                            PropertyZipCode = ld.PropertyZipCode,
                            ServiceTransferDate = Convert.ToDateTime(ld.ServiceTransferDate.GetSafeDateString())
                        };
                        lactx.Loan.Add(loan);
                        lactx.SaveChanges();

                        lactx.LoanMilestone.Add(new LoanMilestone
                        {
                            LoanMilestoneId = 0,
                            LoanId = loan.LoanId,
                            MilestoneId = ld.StatusId,
                            MilestoneDate = Convert.ToDateTime(ld.StatusDate.GetSafeDateString()),
                            AddedBy =_userid,
                            AddedDate = DateTime.Now,
                            ModifiedBy =_userid,
                            ModifiedDate = DateTime.Now,
                            AssignedUser = 0
                        });
                    }
                    lactx.SaveChanges();
                 }
            }
            catch(Exception ex)
            {
                throw;
            }
            return ret;
        }
        public string SaveMilestone(Milestone ms)
        {
            var ret = Constant.Success;
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    var lms = lactx.LoanMilestone.Where(x => x.LoanId == ms.LoanId).ToList();

                    if (lms.Any(x => x.MilestoneId == ms.MilestoneId))
                    {
                        var lm = lms.SingleOrDefault(x => x.MilestoneId == ms.MilestoneId);
                        lm.AssignedUser = ms.AssignedUserId;
                        // lm.MilestoneDate = ms.MilestoneDate.ToDateTime();
                        lm.ModifiedBy = _userid;
                        lm.ModifiedDate = DateTime.Now;
                    }
                    else
                    {
                        lactx.LoanMilestone.Add(new LoanMilestone
                        {
                            AddedBy = _userid,
                            AddedDate = DateTime.Now,
                            AssignedUser = ms.AssignedUserId,
                            LoanId = ms.LoanId,
                            LoanMilestoneId = 0,
                            MilestoneDate = Convert.ToDateTime(ms.MilestoneDate.GetSafeDateString()),
                            MilestoneId = ms.MilestoneId,
                            ModifiedBy = _userid,
                            ModifiedDate = DateTime.Now
                        });
                    }
                    lactx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
    }
}
