﻿using System;
using System.Threading.Tasks;
using System.IO;
using Grpc.Core;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;

using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Util;
using CRFS.IS.Service.Security;
using CRFS.IS.Service.Common;

namespace CRFS.IS.Service.Services
{
    public class FileTransferService : FileTransfer.FileTransferBase
    {
        private readonly IConfiguration _config;
        private readonly ILogger<FileTransferService> _logger;
        public FileTransferService(ILogger<FileTransferService> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
        }
        public override async Task<UploadFileReply> UploadFile(Grpc.Core.IAsyncStreamReader<UploadFileRequest> request, ServerCallContext context)
        {
            var ret = new UploadFileReply {
                Message = Constant.Success
            };
            var firstround = true;
            var req = new UploadFileRequest();
            var pos = 0;
            try
            {
                using (var ms = new MemoryStream()) {
                    while (await request.MoveNext())
                    {
                        var sm = request.Current;
                        if (firstround) {
                            req.Appname = sm.Appname;
                            req.Name = sm.Name;
                            req.Type = sm.Type;
                            firstround = false;
                        }
                        ms.Write(sm.Content.ToByteArray(), pos, sm.Content.Length);
                       // pos += sm.Content.Length;
                    }
                    ms.Seek(0, SeekOrigin.Begin);
                    await FileProvider.UploadFile(ms, req.Appname, req.Name, req.Type);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                ret.Message = "Error: " + ex.Message;
            }
            return ret;
        }
    }
}

