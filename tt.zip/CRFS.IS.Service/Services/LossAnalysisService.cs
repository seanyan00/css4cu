﻿using System;
using System.Threading.Tasks;
using System.Linq;
using Grpc.Core;
using Google.Protobuf.WellKnownTypes;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;

using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Util;
using CRFS.IS.Service.Security;
using CRFS.IS.Service.Business;

namespace CRFS.IS.Service.Services
{
    public class LossAnalysisService : LossAnalysis.LossAnalysisBase
    {
        private readonly IConfiguration _config;
        private readonly ILogger<LossAnalysisService> _logger;
        public LossAnalysisService(ILogger<LossAnalysisService> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
        }
        public override Task<LoanData> GetLoan(GetLoanRequest request, ServerCallContext context)
        {
            var ret = new LoanData();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    _logger.LogWarning("GetLoan: Not a valid token or timed out");
                    return Task.FromResult(ret);
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetLoanData(request.LoanNumber));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
            }
            return Task.FromResult(ret);
        }
        public override Task<CompPartA> GetCompPartA(GetCompPartARequest request, ServerCallContext context)
        {
            var ret = new CompPartA();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    _logger.LogWarning("GetCompPartA: Not a valid token or timed out");
                    return Task.FromResult(ret);
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetCompPartA(request.LoanId));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
            }
            return Task.FromResult(ret);
        }
        public override Task<GetCompAOPReply> GetCompAOP(GetCompAOPRequest request, ServerCallContext context)
        {
            var ret = new GetCompAOPReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    _logger.LogWarning("GetCompAOP: Not a valid token or timed out");
                    return Task.FromResult(ret);
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetCompAOP(request.LoanId));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
            }
            return Task.FromResult(ret);
        }
        public override Task<CompPartB> GetCompPartB(GetCompPartBRequest request, ServerCallContext context)
        {
            var ret = new CompPartB();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    _logger.LogWarning("GetCompPartB: Not a valid token or timed out");
                    return Task.FromResult(ret);
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetCompPartB(request.LoanId));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SaveCompPartA(CompPartA request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    ret.Message = "Not a valid token or timed out";
                    _logger.LogWarning("SaveCompPartA: Not a valid token or timed out");
                    return Task.FromResult(ret);
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SaveCompPartA(request);
                return Task.FromResult(ret);
            }
            catch (Exception ex)
            {
                _logger.LogError("SaveCompPartA: " + ex.Message);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SaveCompAOP(CompAOP request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    ret.Message = "Not a valid token or timed out";
                    _logger.LogWarning("SaveCompAOP: Not a valid token or timed out");
                    return Task.FromResult(ret);
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SaveCompAOP(request);
                return Task.FromResult(ret);
            }
            catch (Exception ex)
            {
                _logger.LogError("SaveCompAOP: " + ex.Message);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SaveCompPartB(SaveCompPartBRequest request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    ret.Message = "Not a valid token or timed out";
                    _logger.LogWarning("SaveCompPartB: Not a valid token or timed out");
                    return Task.FromResult(ret);
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SaveCompPartB(request);
                return Task.FromResult(ret);
            }
            catch (Exception ex)
            {
                _logger.LogError("SaveCompPartB: " + ex.Message);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SaveLoan(LoanData request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    ret.Message = "Not a valid token or timed out";
                    _logger.LogWarning("SaveLoan: Not a valid token or timed out");
                    return Task.FromResult(ret);
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SaveLoan(request);
                return Task.FromResult(ret);
            }
            catch (Exception ex)
            {
                _logger.LogError("SaveLoan: " + ex.Message);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SaveMilestone(Milestone request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    ret.Message = "Not a valid token or timed out";
                    _logger.LogWarning("SaveMilestone: Not a valid token or timed out");
                    return Task.FromResult(ret);
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SaveMilestone(request);
                return Task.FromResult(ret);
            }
            catch (Exception ex)
            {
                _logger.LogError("SaveMilestone: " + ex.Message);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
    }
}
