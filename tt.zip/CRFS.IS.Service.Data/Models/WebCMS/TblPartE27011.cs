﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblPartE27011
    {
        public TblPartE27011()
        {
            TblPartE27011MultiBlock = new HashSet<TblPartE27011MultiBlock>();
        }

        public long PartE27011id { get; set; }
        public long FhaclaimId { get; set; }
        public DateTime? DateFormPrepared { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUser { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUser { get; set; }

        public virtual TblFhaclaims Fhaclaim { get; set; }
        public virtual ICollection<TblPartE27011MultiBlock> TblPartE27011MultiBlock { get; set; }
    }
}
