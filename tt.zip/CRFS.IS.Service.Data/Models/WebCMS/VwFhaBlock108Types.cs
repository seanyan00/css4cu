﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaBlock108Types
    {
        public long Block108TypeId { get; set; }
        public string Block108Description { get; set; }
    }
}
