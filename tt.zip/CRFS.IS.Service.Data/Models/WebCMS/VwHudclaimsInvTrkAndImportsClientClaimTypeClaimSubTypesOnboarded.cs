﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwHudclaimsInvTrkAndImportsClientClaimTypeClaimSubTypesOnboarded
    {
        public long FhaclientClaimTypeEdicontrolId { get; set; }
        public string ClientDisplayName { get; set; }
        public long FhaclientId { get; set; }
        public string HudclaimsClaimTypeName { get; set; }
        public long HudclaimsClaimTypeId { get; set; }
        public string InvTrkClaimTypeName { get; set; }
        public int InvTrkClaimTypeId { get; set; }
        public string HudclaimsClaimSubTypeName { get; set; }
        public long? HudclaimsClaimSubTypeId { get; set; }
        public string InvTrkClaimSubTypeName { get; set; }
        public int InvTrkClaimSubTypeId { get; set; }
        public bool EnableHudEdi { get; set; }
    }
}
