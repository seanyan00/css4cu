﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaPropertyConditionCodes
    {
        public long PropertyConditionId { get; set; }
        public string PropertyConditionCode { get; set; }
        public string PropertyConditionDescription { get; set; }
    }
}
