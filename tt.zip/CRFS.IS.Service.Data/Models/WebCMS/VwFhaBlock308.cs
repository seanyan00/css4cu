﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaBlock308
    {
        public long TaxOnDeedId { get; set; }
        public long PartD27011id { get; set; }
        public DateTime DatePaid { get; set; }
        public string TaxType { get; set; }
        public decimal? ToMortgagee { get; set; }
        public decimal? ToHud { get; set; }
        public decimal AmountPaid { get; set; }
        public decimal? DebentureInterest { get; set; }
        public decimal? DebentureInterestCalc { get; set; }
        public long FhaclaimId { get; set; }
        public DateTime? CurtailDateForDi { get; set; }
        public decimal? DebentureInterestRate { get; set; }
        public long ClaimTypeId { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUser { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUser { get; set; }
        public int UseDefaultDateForCalc { get; set; }
    }
}
