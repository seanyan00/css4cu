﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaBlock307Description
    {
        public string Lutext { get; set; }
    }
}
