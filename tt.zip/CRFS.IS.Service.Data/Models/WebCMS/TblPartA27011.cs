﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblPartA27011
    {
        public TblPartA27011()
        {
            TblFhaTaxSchedule = new HashSet<TblFhaTaxSchedule>();
            TblFhalivingUnits = new HashSet<TblFhalivingUnits>();
        }

        public long PartA27011id { get; set; }
        public long FhaclaimId { get; set; }
        public long? DefaultReasonId { get; set; }
        public DateTime? EndorsementDate { get; set; }
        public DateTime? DateFormPrepared { get; set; }
        public DateTime? FirstPaymentDueDateOriginal { get; set; }
        public DateTime? LastCompleteInstallmentPaidDate { get; set; }
        public DateTime? DateOfPossession { get; set; }
        public DateTime? DateOfAcquisitionOfTitle { get; set; }
        public DateTime? Block9Date { get; set; }
        public DateTime? DateDeedFiledForRecord { get; set; }
        public DateTime? DateAssignmentFiledForRecord { get; set; }
        public DateTime? DateOfClosing { get; set; }
        public DateTime? DateOfAppraisal { get; set; }
        public DateTime? Block10Date { get; set; }
        public bool? Block11Instituted { get; set; }
        public bool? Block11DateofDil { get; set; }
        public DateTime? ForeclosureProceedingsDate { get; set; }
        public DateTime? DateOfDeedInLieu { get; set; }
        public decimal? Block15Original { get; set; }
        public decimal? Block15Modified { get; set; }
        public string HoldingMortgageeEin { get; set; }
        public decimal? UnpaidLoanBalance { get; set; }
        public DateTime? FirmCommitmentDate { get; set; }
        public DateTime? ExpDateExtensionToForeclose { get; set; }
        public DateTime? ExpDateExtensionToAssign { get; set; }
        public DateTime? Block19Date { get; set; }
        public DateTime? DateOfNoticeToConvey { get; set; }
        public DateTime? DateOfExtensionToConvey { get; set; }
        public DateTime? Block20Date { get; set; }
        public DateTime? ReleaseOfBankruptcyDate { get; set; }
        public long? OccupancyStatusId { get; set; }
        public DateTime? DateLocalOfficeApprovalConveyanceOccupied { get; set; }
        public long? PropertyConditionId { get; set; }
        public DateTime? DateLocalOfficeApprovalConveyanceDamaged { get; set; }
        public DateTime? DateLocalOfficeCertificationConveyanceDamaged { get; set; }
        public long? DamageTypeId { get; set; }
        public decimal? EstimateOfDamage { get; set; }
        public decimal? InsuranceRecovery { get; set; }
        public bool? IsMortgageeSuccessfulBidder { get; set; }
        public long? DeficiencyJudgementCodeId { get; set; }
        public decimal? AuthorizedBidAmount { get; set; }
        public DateTime? MortgageeReportedCurtailmentDate { get; set; }
        public string PropertyDescription { get; set; }
        public decimal? MonthlyFhainsurance { get; set; }
        public decimal? MonthlyTaxes { get; set; }
        public decimal? MonthlyHazardInsurance { get; set; }
        public decimal? MonthlyInterestAndPrincipal { get; set; }
        public DateTime? BankruptcyDateFiled { get; set; }
        public DateTime? DateDamaged { get; set; }
        public DateTime? HipcancelledDate { get; set; }
        public DateTime? HiprefusedDate { get; set; }
        public int? NumberOfLivingUnits { get; set; }
        public string MortgageeComments { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUser { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUser { get; set; }
        public long? Block9TypeId { get; set; }
        public long? Block10TypeId { get; set; }
        public DateTime? FirstPaymentDueDateModified { get; set; }

        public virtual TblFhaclaims Fhaclaim { get; set; }
        public virtual ICollection<TblFhaTaxSchedule> TblFhaTaxSchedule { get; set; }
        public virtual ICollection<TblFhalivingUnits> TblFhalivingUnits { get; set; }
    }
}
