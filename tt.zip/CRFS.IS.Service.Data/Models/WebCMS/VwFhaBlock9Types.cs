﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaBlock9Types
    {
        public long Block9TypeId { get; set; }
        public string Block9Description { get; set; }
    }
}
