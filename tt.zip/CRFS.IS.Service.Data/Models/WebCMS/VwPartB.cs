﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwPartB
    {
        public long PartB27011id { get; set; }
        public long FhaclaimId { get; set; }
        public string Block100 { get; set; }
        public string Block101 { get; set; }
        public string Block102 { get; set; }
        public string Block103 { get; set; }
        public DateTime? Block104 { get; set; }
        public DateTime? Block105 { get; set; }
        public long? Block105TypeId { get; set; }
        public bool? Block106 { get; set; }
        public string Block107aAmount { get; set; }
        public string Block107bAmount { get; set; }
        public string Block108aAmount { get; set; }
        public long? Block108TypeId { get; set; }
        public string Block109aAmount { get; set; }
        public string Block110b { get; set; }
        public string Block110c { get; set; }
        public string Block111b { get; set; }
        public string Block111c { get; set; }
        public string Block112b { get; set; }
        public string Block112c { get; set; }
        public string Block113b { get; set; }
        public string Block113c { get; set; }
        public string Block114b { get; set; }
        public string Block114c { get; set; }
        public string Block115aAmount { get; set; }
        public string Block116bAmount { get; set; }
        public string Block117b { get; set; }
        public string Block117c { get; set; }
        public string Block118aAmount { get; set; }
        public string Wksheet119L1amount { get; set; }
        public string Wksheet119L2amount { get; set; }
        public string Wksheet119L3amount { get; set; }
        public string Block119aAmount { get; set; }
        public string Block119bAmount { get; set; }
        public string Block120b { get; set; }
        public string Block120c { get; set; }
        public DateTime? Wksheet121FromDate { get; set; }
        public DateTime? Wksheet121ToDate { get; set; }
        public decimal? Wksheet121Rate { get; set; }
        public string Block121Amount { get; set; }
        public string Block122b { get; set; }
        public string Block122c { get; set; }
        public string Block123aAmount { get; set; }
        public string Block123bAmount { get; set; }
        public string Block123cAmount { get; set; }
        public string Block124aAmount { get; set; }
        public string Block124bAmount { get; set; }
        public string Block124cAmount { get; set; }
        public string Block125b { get; set; }
        public string Block125c { get; set; }
        public string Block126cAmount { get; set; }
        public string Block127a { get; set; }
        public string Block128b { get; set; }
        public string Block129b { get; set; }
        public string Block130b { get; set; }
        public string Block130c { get; set; }
        public string Block131b { get; set; }
        public string Block131c { get; set; }
        public string Block132Description { get; set; }
        public string Block132aAmount { get; set; }
        public string Block132bAmount { get; set; }
        public string Block132cAmount { get; set; }
        public string Block133a { get; set; }
        public string Block133b { get; set; }
        public string Block134Amount { get; set; }
        public string Block135Amount { get; set; }
        public string Block136Amount { get; set; }
        public string Block137Amount { get; set; }
    }
}
