﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblProtectionPreservationDisbursements
    {
        public long ProtectionPreservationDisbursementId { get; set; }
        public long PartC27011id { get; set; }
        public DateTime DatePaid { get; set; }
        public DateTime DateWorkCompleted { get; set; }
        public string DescriptionOfServicesPerformed { get; set; }
        public decimal AmountPaid { get; set; }
        public decimal? DebentureInterest { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUser { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUser { get; set; }
        public bool? Hudapproved { get; set; }
        public bool? CostEstimator { get; set; }
        public int? Quantity { get; set; }
        public long? ActualSqFt { get; set; }

        public virtual TblPartC27011 PartC27011 { get; set; }
    }
}
