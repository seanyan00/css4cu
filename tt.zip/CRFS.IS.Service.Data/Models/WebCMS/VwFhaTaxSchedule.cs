﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaTaxSchedule
    {
        public long TaxScheduleId { get; set; }
        public long PartA27011id { get; set; }
        public int TaxYear { get; set; }
        public string TaxType { get; set; }
        public string CollectorPropertyIdentification { get; set; }
        public decimal? AmountPaid { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public DateTime? DatePaid { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUser { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUser { get; set; }
    }
}
