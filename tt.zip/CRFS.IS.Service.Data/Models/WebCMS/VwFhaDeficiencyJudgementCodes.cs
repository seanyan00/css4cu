﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaDeficiencyJudgementCodes
    {
        public long DeficiencyJudgementCodeId { get; set; }
        public string DeficiencyJudgementCode { get; set; }
        public string DeficiencyJudgementDescription { get; set; }
    }
}
