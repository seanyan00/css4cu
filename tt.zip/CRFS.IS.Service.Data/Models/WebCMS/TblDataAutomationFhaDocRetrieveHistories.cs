﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblDataAutomationFhaDocRetrieveHistories
    {
        public long FhaDocRetrieveHistoryId { get; set; }
        public long FhaclaimId { get; set; }
        public long FharetrievedDocumentTypeId { get; set; }
        public DateTime DocumentRetrieveDate { get; set; }
        public long? DocumentSize { get; set; }
        public int? DocumentPageCount { get; set; }
        public string DocuwareCabinet { get; set; }
        public DateTime? DocuwareStorageDate { get; set; }
        public bool? IsDocuwareStorageSuccessful { get; set; }

        public virtual TblFhaclaims Fhaclaim { get; set; }
        public virtual LkpFharetrievedDocumentTypes FharetrievedDocumentType { get; set; }
    }
}
