﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class PendingSubmits
    {
        public long? ClaimEdilogId { get; set; }
        public long? FhaclaimId { get; set; }
        public string FhacaseNumber { get; set; }
        public string ClientName { get; set; }
        public int? ClaimId { get; set; }
        public string LoanNumber { get; set; }
        public string DefaultReason { get; set; }
        public string SubmitType { get; set; }
        public string ClaimTypeName { get; set; }
        public string SubType { get; set; }
        public DateTime? DateTimeStamp { get; set; }
        public bool? SubmitSuccessful { get; set; }
    }
}
