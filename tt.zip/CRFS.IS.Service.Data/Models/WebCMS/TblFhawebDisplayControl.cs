﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblFhawebDisplayControl
    {
        public long WebControlId { get; set; }
        public string ObjectName { get; set; }
        public long? StateClaimType01 { get; set; }
        public long? StateClaimType02 { get; set; }
        public long? StateClaimType03 { get; set; }
        public long? StateClaimType04 { get; set; }
        public long? StateClaimType05 { get; set; }
        public long? StateClaimType06 { get; set; }
        public long? StateClaimType07 { get; set; }
        public long? StateClaimType31 { get; set; }
        public long? StateClaimType32 { get; set; }
        public long? StateClaimType33 { get; set; }
        public string ObjectType { get; set; }
    }
}
