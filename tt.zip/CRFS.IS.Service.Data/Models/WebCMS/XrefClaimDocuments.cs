﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefClaimDocuments
    {
        public long ClaimDocumentXrefId { get; set; }
        public long ClaimTypeId { get; set; }
        public long FharetrievedDocumentTypeId { get; set; }
        public DateTime? EnteredDate { get; set; }
        public string DocuwareCabinet { get; set; }

        public virtual LkpFhalookups ClaimType { get; set; }
        public virtual LkpFharetrievedDocumentTypes FharetrievedDocumentType { get; set; }
    }
}
