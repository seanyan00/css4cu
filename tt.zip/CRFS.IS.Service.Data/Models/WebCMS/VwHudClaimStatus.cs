﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwHudClaimStatus
    {
        public long FhaclaimId { get; set; }
        public string ClaimStatus { get; set; }
    }
}
