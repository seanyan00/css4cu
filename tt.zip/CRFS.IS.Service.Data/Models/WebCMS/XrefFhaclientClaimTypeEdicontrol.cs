﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefFhaclientClaimTypeEdicontrol
    {
        public long FhaclientClaimTypeEdicontrolId { get; set; }
        public long FhaclientId { get; set; }
        public long ClaimTypeId { get; set; }
        public long? FhaclaimSubTypeId { get; set; }
        public bool EnableHudEdi { get; set; }
    }
}
