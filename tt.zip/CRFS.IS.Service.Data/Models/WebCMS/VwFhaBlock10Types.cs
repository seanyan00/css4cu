﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaBlock10Types
    {
        public long Block10TypeId { get; set; }
        public string Block10Description { get; set; }
    }
}
