﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaDefaultReasons
    {
        public long DefaultReasonId { get; set; }
        public string DefaultReasonCode { get; set; }
        public string DefaultReasonDescription { get; set; }
    }
}
