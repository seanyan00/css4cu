﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpAccessLevel
    {
        public int Lvl { get; set; }
        public string Description { get; set; }
    }
}
