﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblClientPdfcompressionBatchDetail
    {
        public int BatchId { get; set; }
        public int ClientId { get; set; }
        public string FileName { get; set; }
        public int FileSizeBefore { get; set; }
        public int? FileSizeAfter { get; set; }
        public DateTime TimeStart { get; set; }
        public DateTime? TimeEnd { get; set; }
        public string Status { get; set; }
        public string Reason { get; set; }

        public virtual TblClientPdfcompressionBatch Batch { get; set; }
    }
}
