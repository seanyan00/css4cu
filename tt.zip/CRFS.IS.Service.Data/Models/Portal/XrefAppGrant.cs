﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefAppGrant
    {
        public int Id { get; set; }
        public int AppId { get; set; }
        public int Gid { get; set; }
        public int Permit { get; set; }

        public virtual LkpGroup G { get; set; }
    }
}
