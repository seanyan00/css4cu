﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LoanExpenseComp
    {
        public LoanExpenseComp()
        {
            LoanExpenseRec = new HashSet<LoanExpenseRec>();
        }

        public int LoanExpenseCompId { get; set; }
        public int LoanId { get; set; }
        public int ExpenseCategory { get; set; }
        public int ExpenseSubCategory { get; set; }
        public int AdvanceFrom { get; set; }
        public DateTime? DisbursedDate { get; set; }
        public decimal? DisbursedAmount { get; set; }
        public decimal? ClaimAmount { get; set; }
        public decimal? DebentureInterestAmount { get; set; }
        public decimal? LossAmount { get; set; }
        public decimal? EstimatedRefundAmount { get; set; }
        public int? ChargeOffReason { get; set; }
        public int? ResponsibleParty { get; set; }
        public string ExpenseDescription { get; set; }
        public string InvoiceNumber { get; set; }
        public string PolicyNumber { get; set; }
        public int? AppraisalType { get; set; }
        public int? SaleType { get; set; }
        public DateTime? WorkCompleteDate { get; set; }
        public DateTime? CoverageStartDate { get; set; }
        public DateTime? CoverageEndDate { get; set; }
        public DateTime? CancellationDate { get; set; }
        public decimal? CostEstimatorAmount { get; set; }
        public decimal? HudapprovedAmount { get; set; }
        public DateTime? HudapprovedDate { get; set; }
        public decimal? Quantity { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual Loan Loan { get; set; }
        public virtual ICollection<LoanExpenseRec> LoanExpenseRec { get; set; }
    }
}
