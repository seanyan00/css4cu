﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgPartAlmextensionsReportOnetime
    {
        public string LoanNumber { get; set; }
        public string FhaCaseNumber { get; set; }
        public string ApprovalToParticipateExpirationDate { get; set; }
        public string ApprovedContractDate { get; set; }
        public string ApprovedVariance { get; set; }
        public string BorrowerVacated { get; set; }
        public string DateLastPaymentPlanAppliedToLoan { get; set; }
        public string DateOfAprovalToParticipate { get; set; }
        public string DecisionDate { get; set; }
        public string DocumentationAvailable { get; set; }
        public string DocumentationSignedDate { get; set; }
        public string FirstMissedPaymentDueDate { get; set; }
        public string FirstPlanPaymentDueDate { get; set; }
        public string ForeclosureFirstActionDate { get; set; }
        public string LastPlanPaymentDueDate { get; set; }
        public string LossMitigationCode { get; set; }
        public string LossMitigationType { get; set; }
        public string NextPlanPaymentDueDate { get; set; }
        public string OptOutDate { get; set; }
        public string PlanCompleted { get; set; }
        public string PlanIncludesSfbExpirationDate { get; set; }
        public string PlanPaymentsSuspendedOrReduced { get; set; }
        public string ReportsToSfdms { get; set; }
        public string SfdmsReportDate { get; set; }
        public string SpecialForeberanceExpirationDate { get; set; }
        public string VarianceExtensionDate { get; set; }
        public string VarianceRequestDate { get; set; }
    }
}
