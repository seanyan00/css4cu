﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class ReferralImportBatches
    {
        public ReferralImportBatches()
        {
            StgReferralImport = new HashSet<StgReferralImport>();
        }

        public int BatchId { get; set; }
        public string SourceFileName { get; set; }
        public DateTime ImportDateTime { get; set; }

        public virtual ICollection<StgReferralImport> StgReferralImport { get; set; }
    }
}
