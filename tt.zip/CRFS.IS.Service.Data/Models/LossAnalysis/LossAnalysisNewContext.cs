﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CRFS.IS.Service.Data
{
    public partial class LossAnalysisNewContext : DbContext
    {
        public LossAnalysisNewContext()
        {
        }

        public LossAnalysisNewContext(DbContextOptions<LossAnalysisNewContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AopimportBatches> AopimportBatches { get; set; }
        public virtual DbSet<ClientReqLoanTracking> ClientReqLoanTracking { get; set; }
        public virtual DbSet<ClientReqTrackView> ClientReqTrackView { get; set; }
        public virtual DbSet<ClientReqTracking> ClientReqTracking { get; set; }
        public virtual DbSet<ClientTier> ClientTier { get; set; }
        public virtual DbSet<ClientVenorPriorServicerLosses> ClientVenorPriorServicerLosses { get; set; }
        public virtual DbSet<ExpSubCatMapping> ExpSubCatMapping { get; set; }
        public virtual DbSet<ExpenseImportBatches> ExpenseImportBatches { get; set; }
        public virtual DbSet<Investor> Investor { get; set; }
        public virtual DbSet<InvestorMapping> InvestorMapping { get; set; }
        public virtual DbSet<LkpAdvanceFromType> LkpAdvanceFromType { get; set; }
        public virtual DbSet<LkpAoptype> LkpAoptype { get; set; }
        public virtual DbSet<LkpAppraisalType> LkpAppraisalType { get; set; }
        public virtual DbSet<LkpAttorneyCost> LkpAttorneyCost { get; set; }
        public virtual DbSet<LkpAttorneyFee> LkpAttorneyFee { get; set; }
        public virtual DbSet<LkpBankruptcyFeeCost> LkpBankruptcyFeeCost { get; set; }
        public virtual DbSet<LkpBankruptcyType> LkpBankruptcyType { get; set; }
        public virtual DbSet<LkpBkruling> LkpBkruling { get; set; }
        public virtual DbSet<LkpBpoappraisal> LkpBpoappraisal { get; set; }
        public virtual DbSet<LkpChargeOffReason> LkpChargeOffReason { get; set; }
        public virtual DbSet<LkpClaimType> LkpClaimType { get; set; }
        public virtual DbSet<LkpClosingReasons> LkpClosingReasons { get; set; }
        public virtual DbSet<LkpDelayType> LkpDelayType { get; set; }
        public virtual DbSet<LkpEvictionFeeCost> LkpEvictionFeeCost { get; set; }
        public virtual DbSet<LkpEvictionType> LkpEvictionType { get; set; }
        public virtual DbSet<LkpExpCategory> LkpExpCategory { get; set; }
        public virtual DbSet<LkpExpSubCategory> LkpExpSubCategory { get; set; }
        public virtual DbSet<LkpExtensionType> LkpExtensionType { get; set; }
        public virtual DbSet<LkpFcrestartReason> LkpFcrestartReason { get; set; }
        public virtual DbSet<LkpForeclosureType> LkpForeclosureType { get; set; }
        public virtual DbSet<LkpHoa> LkpHoa { get; set; }
        public virtual DbSet<LkpImportTemplateType> LkpImportTemplateType { get; set; }
        public virtual DbSet<LkpInsurance> LkpInsurance { get; set; }
        public virtual DbSet<LkpLivingUnitPartAtype> LkpLivingUnitPartAtype { get; set; }
        public virtual DbSet<LkpLossMitType> LkpLossMitType { get; set; }
        public virtual DbSet<LkpMileStoneType> LkpMileStoneType { get; set; }
        public virtual DbSet<LkpPartBblock> LkpPartBblock { get; set; }
        public virtual DbSet<LkpPartBcolumn> LkpPartBcolumn { get; set; }
        public virtual DbSet<LkpPartBtype> LkpPartBtype { get; set; }
        public virtual DbSet<LkpPlanPayments> LkpPlanPayments { get; set; }
        public virtual DbSet<LkpPropertyPres> LkpPropertyPres { get; set; }
        public virtual DbSet<LkpResponsibleParty> LkpResponsibleParty { get; set; }
        public virtual DbSet<LkpSaleType> LkpSaleType { get; set; }
        public virtual DbSet<LkpStates> LkpStates { get; set; }
        public virtual DbSet<LkpSupplementalPart> LkpSupplementalPart { get; set; }
        public virtual DbSet<LkpSupplementalType> LkpSupplementalType { get; set; }
        public virtual DbSet<LkpTimeframeType> LkpTimeframeType { get; set; }
        public virtual DbSet<LkpType> LkpType { get; set; }
        public virtual DbSet<LkpTypeCat> LkpTypeCat { get; set; }
        public virtual DbSet<LkpTypeSubCat> LkpTypeSubCat { get; set; }
        public virtual DbSet<LkpUtilities> LkpUtilities { get; set; }
        public virtual DbSet<LkpVacancyStatus> LkpVacancyStatus { get; set; }
        public virtual DbSet<Loan> Loan { get; set; }
        public virtual DbSet<LoanAop> LoanAop { get; set; }
        public virtual DbSet<LoanBankruptcy> LoanBankruptcy { get; set; }
        public virtual DbSet<LoanDelay> LoanDelay { get; set; }
        public virtual DbSet<LoanEviction> LoanEviction { get; set; }
        public virtual DbSet<LoanExpense> LoanExpense { get; set; }
        public virtual DbSet<LoanExpenseTest> LoanExpenseTest { get; set; }
        public virtual DbSet<LoanExtension> LoanExtension { get; set; }
        public virtual DbSet<LoanForeclosure> LoanForeclosure { get; set; }
        public virtual DbSet<LoanLivingUnits> LoanLivingUnits { get; set; }
        public virtual DbSet<LoanLossMit> LoanLossMit { get; set; }
        public virtual DbSet<LoanMilestone> LoanMilestone { get; set; }
        public virtual DbSet<LoanPartAcomp> LoanPartAcomp { get; set; }
        public virtual DbSet<LoanPartArec> LoanPartArec { get; set; }
        public virtual DbSet<LoanPartBdata> LoanPartBdata { get; set; }
        public virtual DbSet<LoanPartBdataNote> LoanPartBdataNote { get; set; }
        public virtual DbSet<LoanReconciliation> LoanReconciliation { get; set; }
        public virtual DbSet<LoanSuppTracking> LoanSuppTracking { get; set; }
        public virtual DbSet<LoanSupplemental> LoanSupplemental { get; set; }
        public virtual DbSet<LoanTimeframes> LoanTimeframes { get; set; }
        public virtual DbSet<MilestoneAnalysts> MilestoneAnalysts { get; set; }
        public virtual DbSet<MilestoneDates> MilestoneDates { get; set; }
        public virtual DbSet<ReferralImportBatches> ReferralImportBatches { get; set; }
        public virtual DbSet<StgAopimport> StgAopimport { get; set; }
        public virtual DbSet<StgCompletedClaimAopreportOnetime> StgCompletedClaimAopreportOnetime { get; set; }
        public virtual DbSet<StgCompletedClaimPartAreportOnetime> StgCompletedClaimPartAreportOnetime { get; set; }
        public virtual DbSet<StgCompletedClaimPartBreportOnetime> StgCompletedClaimPartBreportOnetime { get; set; }
        public virtual DbSet<StgDueReportOnetime> StgDueReportOnetime { get; set; }
        public virtual DbSet<StgExpenseCatSubCatLookup> StgExpenseCatSubCatLookup { get; set; }
        public virtual DbSet<StgExpenseImport> StgExpenseImport { get; set; }
        public virtual DbSet<StgLoanDataReportOnetime> StgLoanDataReportOnetime { get; set; }
        public virtual DbSet<StgPartAbkextensionsReportOnetime> StgPartAbkextensionsReportOnetime { get; set; }
        public virtual DbSet<StgPartAdataInputReportOnetime> StgPartAdataInputReportOnetime { get; set; }
        public virtual DbSet<StgPartAevictionExtensionsReportOnetime> StgPartAevictionExtensionsReportOnetime { get; set; }
        public virtual DbSet<StgPartAfcextensionsReportOnetime> StgPartAfcextensionsReportOnetime { get; set; }
        public virtual DbSet<StgPartAlmextensionsReportOnetime> StgPartAlmextensionsReportOnetime { get; set; }
        public virtual DbSet<StgPartAotherDelaysReportOnetime> StgPartAotherDelaysReportOnetime { get; set; }
        public virtual DbSet<StgPartAotherExtensionsReportOnetime> StgPartAotherExtensionsReportOnetime { get; set; }
        public virtual DbSet<StgPartAtimeframesReportOnetime> StgPartAtimeframesReportOnetime { get; set; }
        public virtual DbSet<StgPartBreportOnetime> StgPartBreportOnetime { get; set; }
        public virtual DbSet<StgReconciliationReportOnetime> StgReconciliationReportOnetime { get; set; }
        public virtual DbSet<StgReferralImport> StgReferralImport { get; set; }
        public virtual DbSet<SupplementClaimInfo> SupplementClaimInfo { get; set; }
        public virtual DbSet<TimeframeTestandExt> TimeframeTestandExt { get; set; }
        public virtual DbSet<VwLoanPartBdata> VwLoanPartBdata { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=vm-sql1-dev.dev.crfs.crfservices.com\\cms_d;Initial Catalog=LossAnalysisNew;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AopimportBatches>(entity =>
            {
                entity.HasKey(e => e.BatchId)
                    .HasName("PK__AOPImpor__5D55CE3828CE66B5");

                entity.ToTable("AOPImportBatches");

                entity.Property(e => e.BatchId).HasColumnName("BatchID");

                entity.Property(e => e.ImportDateTime).HasColumnType("datetime");

                entity.Property(e => e.SourceFileName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ClientReqLoanTracking>(entity =>
            {
                entity.HasKey(e => e.ReqLoanTrackId)
                    .HasName("PK_ClientReqLoanTracking_ReqLoanTrackID");

                entity.Property(e => e.ReqLoanTrackId).HasColumnName("ReqLoanTrackID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ClientReqTrackId).HasColumnName("ClientReqTrackID");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ReqInfoDate).HasColumnType("datetime");

                entity.Property(e => e.ReqInfoDec).HasColumnType("decimal(10, 4)");

                entity.Property(e => e.ReqInfoString)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.ClientReqTrack)
                    .WithMany(p => p.ClientReqLoanTracking)
                    .HasForeignKey(d => d.ClientReqTrackId)
                    .OnDelete(DeleteBehavior.ClientSetNull);

                entity.HasOne(d => d.Loan)
                    .WithMany(p => p.ClientReqLoanTracking)
                    .HasForeignKey(d => d.LoanId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<ClientReqTrackView>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("ClientReqTrackView");

                entity.Property(e => e.CloseOutStepComplete)
                    .HasColumnName("Close Out Step Complete")
                    .HasColumnType("datetime");

                entity.Property(e => e.DeliveredDate)
                    .HasColumnName("Delivered Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.RcaComplete)
                    .HasColumnName("RCA Complete")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<ClientReqTracking>(entity =>
            {
                entity.HasKey(e => e.ClientReqTrackId)
                    .HasName("PK_ClientReqTracking_ClientReqTrackID");

                entity.Property(e => e.ClientReqTrackId).HasColumnName("ClientReqTrackID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Purpose)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ReqInfo)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ReqInfoDataType)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ClientTier>(entity =>
            {
                entity.HasKey(e => e.TierId)
                    .HasName("PK_ClientTier_TierID");

                entity.Property(e => e.TierId).HasColumnName("TierID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.EffectiveDate).HasColumnType("date");

                entity.Property(e => e.ExpiryDate).HasColumnType("date");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.TierRate).HasColumnType("decimal(8, 4)");
            });

            modelBuilder.Entity<ClientVenorPriorServicerLosses>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("ClientVenorPriorServicerLosses");

                entity.Property(e => e.ClientLossAmount).HasColumnType("decimal(38, 2)");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.PriorServicerLossAmount).HasColumnType("decimal(38, 2)");

                entity.Property(e => e.VendorLossAmount).HasColumnType("decimal(38, 2)");
            });

            modelBuilder.Entity<ExpSubCatMapping>(entity =>
            {
                entity.HasKey(e => e.ExpSubCatMapId)
                    .HasName("PK_ExpSubCatMapping_ExpSubCatMapID");

                entity.Property(e => e.ExpSubCatMapId).HasColumnName("ExpSubCatMapID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ClientExpCatCode)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.ClientExpCatDescription)
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.CrfsexpSubCatId).HasColumnName("CRFSExpSubCatID");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<ExpenseImportBatches>(entity =>
            {
                entity.HasKey(e => e.BatchId)
                    .HasName("PK__ExpenseI__5D55CE384E7E3A1B");

                entity.Property(e => e.BatchId).HasColumnName("BatchID");

                entity.Property(e => e.ImportDateTime).HasColumnType("datetime");

                entity.Property(e => e.SourceFileName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Investor>(entity =>
            {
                entity.Property(e => e.InvestorId).HasColumnName("InvestorID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.InvestorName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<InvestorMapping>(entity =>
            {
                entity.HasKey(e => e.InvestorMapId);

                entity.Property(e => e.InvestorMapId).HasColumnName("InvestorMapID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.InvestorId).HasColumnName("InvestorID");

                entity.Property(e => e.InvestorName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Investor)
                    .WithMany(p => p.InvestorMapping)
                    .HasForeignKey(d => d.InvestorId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<LkpAdvanceFromType>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpAdvanceFromType");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpAoptype>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpAOPType");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpAppraisalType>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpAppraisalType");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpAttorneyCost>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpAttorneyCost");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeSubCatId).HasColumnName("LkpTypeSubCatID");

                entity.Property(e => e.LkpTypeSubCatName)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpAttorneyFee>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpAttorneyFee");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeSubCatId).HasColumnName("LkpTypeSubCatID");

                entity.Property(e => e.LkpTypeSubCatName)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpBankruptcyFeeCost>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpBankruptcyFeeCost");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeSubCatId).HasColumnName("LkpTypeSubCatID");

                entity.Property(e => e.LkpTypeSubCatName)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpBankruptcyType>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpBankruptcyType");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpBkruling>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpBKRuling");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpBpoappraisal>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpBPOAppraisal");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeSubCatId).HasColumnName("LkpTypeSubCatID");

                entity.Property(e => e.LkpTypeSubCatName)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpChargeOffReason>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpChargeOffReason");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpClaimType>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpClaimType");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpClosingReasons>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpClosingReasons");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpDelayType>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpDelayType");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpEvictionFeeCost>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpEvictionFeeCost");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeSubCatId).HasColumnName("LkpTypeSubCatID");

                entity.Property(e => e.LkpTypeSubCatName)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpEvictionType>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpEvictionType");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpExpCategory>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpExpCategory");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpExpSubCategory>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpExpSubCategory");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeSubCatId).HasColumnName("LkpTypeSubCatID");

                entity.Property(e => e.LkpTypeSubCatName)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpExtensionType>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpExtensionType");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpFcrestartReason>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpFCRestartReason");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpForeclosureType>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpForeclosureType");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpHoa>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpHOA");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeSubCatId).HasColumnName("LkpTypeSubCatID");

                entity.Property(e => e.LkpTypeSubCatName)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpImportTemplateType>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpImportTemplateType");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpInsurance>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpInsurance");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeSubCatId).HasColumnName("LkpTypeSubCatID");

                entity.Property(e => e.LkpTypeSubCatName)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpLivingUnitPartAtype>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpLivingUnitPartAType");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpLossMitType>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpLossMitType");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpMileStoneType>(entity =>
            {
                entity.HasKey(e => e.MilestoneId)
                    .HasName("PK_LkpMileStoneType_MilestoneID");

                entity.Property(e => e.MilestoneId).HasColumnName("MilestoneID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.MilestoneType)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<LkpPartBblock>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpPartBBlock");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpPartBcolumn>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpPartBColumn");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpPartBtype>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpPartBType");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpPlanPayments>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpPlanPayments");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpPropertyPres>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpPropertyPres");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeSubCatId).HasColumnName("LkpTypeSubCatID");

                entity.Property(e => e.LkpTypeSubCatName)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpResponsibleParty>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpResponsibleParty");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpSaleType>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpSaleType");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpStates>(entity =>
            {
                entity.HasKey(e => e.StateId)
                    .HasName("PK_LkpStates_StateID");

                entity.Property(e => e.StateId).HasColumnName("StateID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.StateCode)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.StateName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpSupplementalPart>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpSupplementalPart");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpSupplementalType>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpSupplementalType");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpTimeframeType>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpTimeframeType");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpType>(entity =>
            {
                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.DateAdded)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DateModified)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpTypeCat>(entity =>
            {
                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.DateAdded)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DateModified)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.HasOne(d => d.LkpType)
                    .WithMany(p => p.LkpTypeCat)
                    .HasForeignKey(d => d.LkpTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<LkpTypeSubCat>(entity =>
            {
                entity.Property(e => e.LkpTypeSubCatId).HasColumnName("LkpTypeSubCatID");

                entity.Property(e => e.DateAdded)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DateModified)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeSubCatName)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.HasOne(d => d.LkpTypeCat)
                    .WithMany(p => p.LkpTypeSubCat)
                    .HasForeignKey(d => d.LkpTypeCatId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LkpTypeSubCat_LkpTypeSubCat_LkpTypeCatID");
            });

            modelBuilder.Entity<LkpUtilities>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpUtilities");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeSubCatId).HasColumnName("LkpTypeSubCatID");

                entity.Property(e => e.LkpTypeSubCatName)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpVacancyStatus>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("lkpVacancyStatus");

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.LkpTypeCatId).HasColumnName("LkpTypeCatID");

                entity.Property(e => e.LkpTypeCatName)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LkpTypeId).HasColumnName("LkpTypeID");

                entity.Property(e => e.LkpTypeName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Loan>(entity =>
            {
                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.BorrowerFirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BorrowerLastName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BuyOutDate).HasColumnType("date");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.CloseDate).HasColumnType("datetime");

                entity.Property(e => e.FhacaseNumber)
                    .IsRequired()
                    .HasColumnName("FHACaseNumber")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.InvestorId).HasColumnName("InvestorID");

                entity.Property(e => e.LoanNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.LossAnalysisDueDate).HasColumnType("date");

                entity.Property(e => e.LossAnalysisReferralDate).HasColumnType("date");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.NoteRate).HasColumnType("decimal(8, 5)");

                entity.Property(e => e.PropertyCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyStreetAddressLine1)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyStreetAddressLine2)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ServiceTransferDate).HasColumnType("date");

                entity.HasOne(d => d.Investor)
                    .WithMany(p => p.Loan)
                    .HasForeignKey(d => d.InvestorId);

                entity.HasOne(d => d.PropertyStateNavigation)
                    .WithMany(p => p.Loan)
                    .HasForeignKey(d => d.PropertyState)
                    .HasConstraintName("FK_Loan_LkpStates_StateID");
            });

            modelBuilder.Entity<LoanAop>(entity =>
            {
                entity.HasKey(e => e.Aopid)
                    .HasName("PK_LoanAOP_AOPID");

                entity.ToTable("LoanAOP");

                entity.Property(e => e.Aopid).HasColumnName("AOPID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Aoptype).HasColumnName("AOPType");

                entity.Property(e => e.FhasettlementAmount)
                    .HasColumnName("FHASettlementAmount")
                    .HasColumnType("decimal(12, 2)");

                entity.Property(e => e.InterestEndDate).HasColumnType("date");

                entity.Property(e => e.InterestStartDate).HasColumnType("date");

                entity.Property(e => e.LessOffsetAmount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ReceivedDate).HasColumnType("date");

                entity.Property(e => e.SettlementDate).HasColumnType("date");

                entity.Property(e => e.TotalInterestPaid).HasColumnType("decimal(12, 2)");

                entity.HasOne(d => d.Loan)
                    .WithMany(p => p.LoanAop)
                    .HasForeignKey(d => d.LoanId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<LoanBankruptcy>(entity =>
            {
                entity.HasKey(e => e.LoanBkextensionId)
                    .HasName("PK_LoanBankruptcy_LoanBKExtensionID");

                entity.Property(e => e.LoanBkextensionId).HasColumnName("LoanBKExtensionID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.AttorneyProvidedLiftDate).HasColumnType("date");

                entity.Property(e => e.BankruptcyCaseNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.BankruptcyCompletionDate).HasColumnType("date");

                entity.Property(e => e.ClearanceDate).HasColumnType("date");

                entity.Property(e => e.DischargeDate).HasColumnType("date");

                entity.Property(e => e.DismissalDate).HasColumnType("date");

                entity.Property(e => e.FiledDate).HasColumnType("date");

                entity.Property(e => e.FirstActionDate).HasColumnType("date");

                entity.Property(e => e.FirstUnacceptableDelay).HasColumnType("date");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.MotionForReliefDate).HasColumnType("date");

                entity.Property(e => e.OrderGrantingMfr).HasColumnName("OrderGrantingMFR");

                entity.Property(e => e._4001ruleWaived).HasColumnName("4001RuleWaived");

                entity.HasOne(d => d.Loan)
                    .WithMany(p => p.LoanBankruptcy)
                    .HasForeignKey(d => d.LoanId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<LoanDelay>(entity =>
            {
                entity.Property(e => e.LoanDelayId).HasColumnName("LoanDelayID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DelayEndDate).HasColumnType("date");

                entity.Property(e => e.DelayReason)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DelayStartDate).HasColumnType("date");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Loan)
                    .WithMany(p => p.LoanDelay)
                    .HasForeignKey(d => d.LoanId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<LoanEviction>(entity =>
            {
                entity.Property(e => e.LoanEvictionId).HasColumnName("LoanEvictionID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.CloseAndBillDate).HasColumnType("date");

                entity.Property(e => e.EvictionFirstLegalDate).HasColumnType("date");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ReoccupancyDate).HasColumnType("date");

                entity.Property(e => e.UnacceptableDelayStartDate).HasColumnType("date");

                entity.Property(e => e.VacancyDate).HasColumnType("date");

                entity.HasOne(d => d.Loan)
                    .WithMany(p => p.LoanEviction)
                    .HasForeignKey(d => d.LoanId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<LoanExpense>(entity =>
            {
                entity.Property(e => e.LoanExpenseId).HasColumnName("LoanExpenseID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.CancellationDate).HasColumnType("date");

                entity.Property(e => e.ClaimAmount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.CostEstimatorAmount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.CoverageEndDate).HasColumnType("date");

                entity.Property(e => e.CoverageStartDate).HasColumnType("date");

                entity.Property(e => e.DebentureInterestAmount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.DisbursedAmount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.DisbursedDate).HasColumnType("date");

                entity.Property(e => e.EstimatedRefundAmount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.ExpenseDescription)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.HudapprovedAmount)
                    .HasColumnName("HUDApprovedAmount")
                    .HasColumnType("decimal(12, 2)");

                entity.Property(e => e.HudapprovedDate)
                    .HasColumnName("HUDApprovedDate")
                    .HasColumnType("date");

                entity.Property(e => e.InvoiceNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.LossAmount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ParentLoanExpenseId).HasColumnName("ParentLoanExpenseID");

                entity.Property(e => e.PolicyNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Quantity).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.WorkCompleteDate).HasColumnType("date");

                entity.HasOne(d => d.Loan)
                    .WithMany(p => p.LoanExpense)
                    .HasForeignKey(d => d.LoanId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<LoanExpenseTest>(entity =>
            {
                entity.HasKey(e => e.LoanExpenseId)
                    .HasName("PK_LoanExpenseTest_LoanExpenseID");

                entity.Property(e => e.LoanExpenseId).HasColumnName("LoanExpenseID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.CancellationDate).HasColumnType("date");

                entity.Property(e => e.ClaimAmount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.CostEstimatorAmount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.CoverageEndDate).HasColumnType("date");

                entity.Property(e => e.CoverageStartDate).HasColumnType("date");

                entity.Property(e => e.DebentureInterestAmount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.DisbursedAmount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.DisbursedDate).HasColumnType("date");

                entity.Property(e => e.EstimatedRefundAmount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.ExpenseDescription)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.HudapprovedAmount)
                    .HasColumnName("HUDApprovedAmount")
                    .HasColumnType("decimal(12, 2)");

                entity.Property(e => e.HudapprovedDate)
                    .HasColumnName("HUDApprovedDate")
                    .HasColumnType("date");

                entity.Property(e => e.InvoiceNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.LossAmount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ParentLoanExpenseId).HasColumnName("ParentLoanExpenseID");

                entity.Property(e => e.PolicyNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Quantity).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.WorkCompleteDate).HasColumnType("date");

                entity.HasOne(d => d.Loan)
                    .WithMany(p => p.LoanExpenseTest)
                    .HasForeignKey(d => d.LoanId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<LoanExtension>(entity =>
            {
                entity.Property(e => e.LoanExtensionId).HasColumnName("LoanExtensionID");

                entity.Property(e => e.ActiveDutyDischargeDate).HasColumnType("date");

                entity.Property(e => e.ActiveDutyStartDate).HasColumnType("date");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DeclarationDate).HasColumnType("date");

                entity.Property(e => e.FemaextensionDate)
                    .HasColumnName("FEMAExtensionDate")
                    .HasColumnType("date");

                entity.Property(e => e.FirstActionDate).HasColumnType("date");

                entity.Property(e => e.HazardClaimDate).HasColumnType("date");

                entity.Property(e => e.HazardClaimSettlementDate).HasColumnType("date");

                entity.Property(e => e.HudextensionDate)
                    .HasColumnName("HUDExtensionDate")
                    .HasColumnType("date");

                entity.Property(e => e.HudextensionRequestDate)
                    .HasColumnName("HUDExtensionRequestDate")
                    .HasColumnType("date");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.LossDate).HasColumnType("date");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SaleContractApprovalDate).HasColumnType("date");

                entity.Property(e => e.StatuteEndDate).HasColumnType("date");

                entity.Property(e => e.StatuteStartDate).HasColumnType("date");

                entity.HasOne(d => d.Loan)
                    .WithMany(p => p.LoanExtension)
                    .HasForeignKey(d => d.LoanId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<LoanForeclosure>(entity =>
            {
                entity.Property(e => e.LoanForeclosureId).HasColumnName("LoanForeclosureID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Comments)
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.FirstLegalDate).HasColumnType("date");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Sfdmscode68Date)
                    .HasColumnName("SFDMSCode68Date")
                    .HasColumnType("date");

                entity.HasOne(d => d.Loan)
                    .WithMany(p => p.LoanForeclosure)
                    .HasForeignKey(d => d.LoanId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<LoanLivingUnits>(entity =>
            {
                entity.HasKey(e => e.LoanLivUnitId)
                    .HasName("PK_LoanLivingUnits_LoanLivUnitID");

                entity.Property(e => e.LoanLivUnitId).HasColumnName("LoanLivUnitID");

                entity.Property(e => e.AddedDate).HasColumnType("datetime");

                entity.Property(e => e.LivingUnitPartAtypeId).HasColumnName("LivingUnitPartATypeID");

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.PartAcompId).HasColumnName("PartACompID");

                entity.Property(e => e.PartArecId).HasColumnName("PartARecID");

                entity.Property(e => e.UnitOccupantName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UnitSecuredDate).HasColumnType("date");

                entity.Property(e => e.UnitVacatedDate).HasColumnType("date");

                entity.HasOne(d => d.PartAcomp)
                    .WithMany(p => p.LoanLivingUnits)
                    .HasForeignKey(d => d.PartAcompId);

                entity.HasOne(d => d.PartArec)
                    .WithMany(p => p.LoanLivingUnits)
                    .HasForeignKey(d => d.PartArecId);
            });

            modelBuilder.Entity<LoanLossMit>(entity =>
            {
                entity.HasKey(e => e.LoanLmextensionId)
                    .HasName("PK_LoanLossMit_LoanLMExtensionID");

                entity.Property(e => e.LoanLmextensionId).HasColumnName("LoanLMExtensionID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ApprovalToParticipateDate).HasColumnType("date");

                entity.Property(e => e.ApprovalToParticipateExpirationDate).HasColumnType("date");

                entity.Property(e => e.ApprovedContractDate).HasColumnType("date");

                entity.Property(e => e.BorrowerVacatedDate).HasColumnType("date");

                entity.Property(e => e.DecisionDate).HasColumnType("date");

                entity.Property(e => e.DocumentSignDate).HasColumnType("date");

                entity.Property(e => e.FirstActionDate).HasColumnType("date");

                entity.Property(e => e.FirstMissedPaymentDueDate).HasColumnType("date");

                entity.Property(e => e.FirstPlanPaymentDueDate).HasColumnType("date");

                entity.Property(e => e.LastPlanPaymentAppliedDate).HasColumnType("date");

                entity.Property(e => e.LastPlanPaymentDueDate).HasColumnType("date");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.NextPlanPaymentDueDate).HasColumnType("date");

                entity.Property(e => e.OptOutDate).HasColumnType("date");

                entity.Property(e => e.PlanIncludesSfbexpiration).HasColumnName("PlanIncludesSFBExpiration");

                entity.Property(e => e.SfbexpirationDate)
                    .HasColumnName("SFBExpirationDate")
                    .HasColumnType("date");

                entity.Property(e => e.SfdmsreportDate)
                    .HasColumnName("SFDMSReportDate")
                    .HasColumnType("date");

                entity.Property(e => e.Sfdmsreported).HasColumnName("SFDMSReported");

                entity.Property(e => e.VarianceExtensionDate).HasColumnType("date");

                entity.Property(e => e.VarianceRequestDate).HasColumnType("date");

                entity.HasOne(d => d.Loan)
                    .WithMany(p => p.LoanLossMit)
                    .HasForeignKey(d => d.LoanId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<LoanMilestone>(entity =>
            {
                entity.Property(e => e.LoanMilestoneId).HasColumnName("LoanMilestoneID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.MilestoneDate).HasColumnType("datetime");

                entity.Property(e => e.MilestoneId).HasColumnName("MilestoneID");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Loan)
                    .WithMany(p => p.LoanMilestone)
                    .HasForeignKey(d => d.LoanId)
                    .OnDelete(DeleteBehavior.ClientSetNull);

                entity.HasOne(d => d.Milestone)
                    .WithMany(p => p.LoanMilestone)
                    .HasForeignKey(d => d.MilestoneId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanMilestone_LkpMileStoneType_LoanID");
            });

            modelBuilder.Entity<LoanPartAcomp>(entity =>
            {
                entity.HasKey(e => e.PartAcompId)
                    .HasName("PK_LoanPartAComp_PartACompID");

                entity.ToTable("LoanPartAComp");

                entity.Property(e => e.PartAcompId).HasColumnName("PartACompID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.AuthorizedBidAmount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.BankruptcyLiftDate).HasColumnType("date");

                entity.Property(e => e.ClaimFiledDate).HasColumnType("date");

                entity.Property(e => e.ConveyanceExtensionDate).HasColumnType("date");

                entity.Property(e => e.DateDeedOrAssignmentFiled).HasColumnType("date");

                entity.Property(e => e.DateOfPossessionAcquisition).HasColumnType("date");

                entity.Property(e => e.DebentureInterestRate).HasColumnType("decimal(8, 4)");

                entity.Property(e => e.DeedInLieuDate).HasColumnType("date");

                entity.Property(e => e.DueDateOfLastPaymentInstallment).HasColumnType("date");

                entity.Property(e => e.EndorsementDate).HasColumnType("date");

                entity.Property(e => e.ForeclosureFirstLegalDate).HasColumnType("date");

                entity.Property(e => e.InstitutionExtensionDate).HasColumnType("date");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.MortgageeCurtailmentDate).HasColumnType("date");

                entity.Property(e => e.OriginalPrincipalBalance).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.UnpaidPrincipalBalance).HasColumnType("decimal(12, 2)");

                entity.HasOne(d => d.Loan)
                    .WithMany(p => p.LoanPartAcomp)
                    .HasForeignKey(d => d.LoanId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<LoanPartArec>(entity =>
            {
                entity.HasKey(e => e.PartArecId)
                    .HasName("PK_LLoanPartARec_PartARecID");

                entity.ToTable("LoanPartARec");

                entity.Property(e => e.PartArecId).HasColumnName("PartARecID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ApprovalToParticipateDate).HasColumnType("date");

                entity.Property(e => e.AuthorizedBidAmount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.BankruptcyLiftDate).HasColumnType("date");

                entity.Property(e => e.CheckWireDate).HasColumnType("date");

                entity.Property(e => e.ClientSpecifiedBlock9).HasColumnType("date");

                entity.Property(e => e.DateOfInspectionPriorToFtv)
                    .HasColumnName("DateOfInspectionPriorToFTV")
                    .HasColumnType("date");

                entity.Property(e => e.DateOfPossessionAndAcquisition).HasColumnType("date");

                entity.Property(e => e.DebentureInterestRate).HasColumnType("decimal(8, 4)");

                entity.Property(e => e.DeedInLieuDate).HasColumnType("date");

                entity.Property(e => e.DeedInLieuTransferDate).HasColumnType("date");

                entity.Property(e => e.DefaultDate).HasColumnType("date");

                entity.Property(e => e.DueDate).HasColumnType("date");

                entity.Property(e => e.DueDateofLastPaymentInstallment).HasColumnType("date");

                entity.Property(e => e.EndorsementDate).HasColumnType("date");

                entity.Property(e => e.FirstInspectionDate).HasColumnType("date");

                entity.Property(e => e.FirstSfdmscode1Adate)
                    .HasColumnName("FirstSFDMSCode1ADate")
                    .HasColumnType("date");

                entity.Property(e => e.FirstTimeVacancyDate).HasColumnType("date");

                entity.Property(e => e.ForeclosureDeedRecordedDate).HasColumnType("date");

                entity.Property(e => e.ForeclosureSaleDate).HasColumnType("date");

                entity.Property(e => e.HudassignmentDate)
                    .HasColumnName("HUDAssignmentDate")
                    .HasColumnType("date");

                entity.Property(e => e.HuddeedFilingDate)
                    .HasColumnName("HUDDeedFilingDate")
                    .HasColumnType("date");

                entity.Property(e => e.LastLoanModificationDate).HasColumnType("date");

                entity.Property(e => e.LastOnTimePaymentDate).HasColumnType("date");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.MarketableTitleDate).HasColumnType("date");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.OriginalDefaultDate).HasColumnType("date");

                entity.Property(e => e.PartAcompId).HasColumnName("PartACompID");

                entity.Property(e => e.PfssettlementDate)
                    .HasColumnName("PFSSettlementDate")
                    .HasColumnType("date");

                entity.Property(e => e.PropertyReosold).HasColumnName("PropertyREOSold");

                entity.Property(e => e.RecentVacancyDate).HasColumnType("date");

                entity.Property(e => e.RedemptionDate).HasColumnType("date");

                entity.Property(e => e.Rrcdate)
                    .HasColumnName("RRCDate")
                    .HasColumnType("date");

                entity.Property(e => e.SaleBidAmount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.SecondChanceSaleDate).HasColumnType("date");

                entity.Property(e => e.SfdmsreportingMissedCycles).HasColumnName("SFDMSReportingMissedCycles");

                entity.Property(e => e.UnpaidPrincipalBalance).HasColumnType("decimal(12, 2)");

                entity.HasOne(d => d.Loan)
                    .WithMany(p => p.LoanPartArec)
                    .HasForeignKey(d => d.LoanId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<LoanPartBdata>(entity =>
            {
                entity.HasKey(e => e.PartBid)
                    .HasName("PK_LoanPartBData_PartBID");

                entity.ToTable("LoanPartBData");

                entity.Property(e => e.PartBid).HasColumnName("PartBID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Amount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.PartBblockId).HasColumnName("PartBBlockID");

                entity.Property(e => e.PartBcolumn).HasColumnName("PartBColumn");

                entity.Property(e => e.PartBtype).HasColumnName("PartBType");

                entity.HasOne(d => d.Loan)
                    .WithMany(p => p.LoanPartBdata)
                    .HasForeignKey(d => d.LoanId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<LoanPartBdataNote>(entity =>
            {
                entity.HasKey(e => e.PartBnoteId)
                    .HasName("PK__LoanPart__C031ECC027BAFD26");

                entity.ToTable("LoanPartBDataNote");

                entity.Property(e => e.PartBnoteId).HasColumnName("PartBNoteID");

                entity.Property(e => e.AddedDate).HasColumnType("datetime");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.Note)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.PartBblockId).HasColumnName("PartBBlockID");

                entity.HasOne(d => d.Loan)
                    .WithMany(p => p.LoanPartBdataNote)
                    .HasForeignKey(d => d.LoanId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanPartBDataNote_Loan");
            });

            modelBuilder.Entity<LoanReconciliation>(entity =>
            {
                entity.HasKey(e => e.LoanReconId)
                    .HasName("PK_LoanReconciliation_LoanReconID");

                entity.Property(e => e.LoanReconId).HasColumnName("LoanReconID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.CurrentSystemBalance).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.ExpenseCurtDate).HasColumnType("date");

                entity.Property(e => e.ExpenseCurtOverrideDate).HasColumnType("date");

                entity.Property(e => e.FiledExpenseAmount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.FiledInterestAmount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.FiledInterestCurtDate).HasColumnType("date");

                entity.Property(e => e.FiledUpb)
                    .HasColumnName("FiledUPB")
                    .HasColumnType("decimal(12, 2)");

                entity.Property(e => e.InterestCurtAmount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.InterestCurtOverrideDate).HasColumnType("date");

                entity.Property(e => e.LoanComment)
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ReconAppliedFunds).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.ReconAttorneyCostsUl)
                    .HasColumnName("ReconAttorneyCostsUL")
                    .HasColumnType("decimal(12, 2)");

                entity.Property(e => e.ReconAttorneyFeesUl)
                    .HasColumnName("ReconAttorneyFeesUL")
                    .HasColumnType("decimal(12, 2)");

                entity.Property(e => e.ReconBankruptcyFeesUl)
                    .HasColumnName("ReconBankruptcyFeesUL")
                    .HasColumnType("decimal(12, 2)");

                entity.Property(e => e.ReconControllableExpense).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.ReconControllableInterest).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.ReconCorporateBalance).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.ReconCreditAfterClaim).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.ReconEscrowBalance).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.ReconFinalProceeds).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.ReconInterest).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.ReconInterestDifferentialUl)
                    .HasColumnName("ReconInterestDifferentialUL")
                    .HasColumnType("decimal(12, 2)");

                entity.Property(e => e.ReconLiquidationProceeds).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.ReconPaidAfterClaim).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.ReconPartialProceeds).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.ReconRestrictedBalance).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.ReconSuspenseBalance).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.ReconTwoMonthsInterestUl)
                    .HasColumnName("ReconTwoMonthsInterestUL")
                    .HasColumnType("decimal(12, 2)");

                entity.Property(e => e.ReconUpb)
                    .HasColumnName("ReconUPB")
                    .HasColumnType("decimal(12, 2)");

                entity.Property(e => e.SettledExpenseAmount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.SettledInterestAmount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.SettledInterestCurtDate).HasColumnType("date");

                entity.Property(e => e.SettledUpb)
                    .HasColumnName("SettledUPB")
                    .HasColumnType("decimal(12, 2)");

                entity.Property(e => e.UpdateExpenseAmount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.UpdateInterestAmount).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.UpdateInterestCurtDate).HasColumnType("date");

                entity.Property(e => e.UpdateUpb)
                    .HasColumnName("UpdateUPB")
                    .HasColumnType("decimal(12, 2)");

                entity.HasOne(d => d.Loan)
                    .WithMany(p => p.LoanReconciliation)
                    .HasForeignKey(d => d.LoanId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<LoanSuppTracking>(entity =>
            {
                entity.HasKey(e => e.LoanSuppTrackId)
                    .HasName("PK_LoanSuppTracking_LoanSuppTrackID");

                entity.Property(e => e.LoanSuppTrackId).HasColumnName("LoanSuppTrackID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.HudrecvdAmt)
                    .HasColumnName("HUDRecvdAmt")
                    .HasColumnType("decimal(12, 2)");

                entity.Property(e => e.HudrecvdDate)
                    .HasColumnName("HUDRecvdDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SuppTrackingInfo)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Loan)
                    .WithMany(p => p.LoanSuppTracking)
                    .HasForeignKey(d => d.LoanId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<LoanSupplemental>(entity =>
            {
                entity.HasKey(e => e.LoanSuppId)
                    .HasName("PK_LoanSupplemental_LoanSuppID");

                entity.Property(e => e.LoanSuppId).HasColumnName("LoanSuppID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.SuppAmtCalculated).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.SuppAmtOverride).HasColumnType("decimal(12, 2)");

                entity.HasOne(d => d.Loan)
                    .WithMany(p => p.LoanSupplemental)
                    .HasForeignKey(d => d.LoanId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<LoanTimeframes>(entity =>
            {
                entity.HasKey(e => e.LoanTimeframeId)
                    .HasName("PK_LoanTimeframes_LoanTimeframeID");

                entity.Property(e => e.LoanTimeframeId).HasColumnName("LoanTimeframeID");

                entity.Property(e => e.AddedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.ModifiedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.TimeframeActivityDate).HasColumnType("date");

                entity.Property(e => e.TimeframeCalcDeadlineDate).HasColumnType("date");

                entity.Property(e => e.TimeframeOverrideDeadlineDate).HasColumnType("date");

                entity.HasOne(d => d.Loan)
                    .WithMany(p => p.LoanTimeframes)
                    .HasForeignKey(d => d.LoanId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<MilestoneAnalysts>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("MilestoneAnalysts");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.PartAAssignment)
                    .HasColumnName("Part-A Assignment")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PartAQcAssignment)
                    .HasColumnName("Part-A QC Assignment")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PartBAssignment)
                    .HasColumnName("Part-B Assignment")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PartBQcAssignment)
                    .HasColumnName("Part-B QC Assignment")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.SuppRecAnalystAssigned)
                    .HasColumnName("Supp Rec Analyst Assigned")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.SuppRefAnalystAssigned)
                    .HasColumnName("Supp Ref Analyst Assigned")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<MilestoneDates>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("MilestoneDates");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.PartAAssignment)
                    .HasColumnName("Part-A Assignment")
                    .HasColumnType("datetime");

                entity.Property(e => e.PartACompleteDate)
                    .HasColumnName("Part-A Complete Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.PartAQcAssignment)
                    .HasColumnName("Part-A QC Assignment")
                    .HasColumnType("datetime");

                entity.Property(e => e.PartAQcComplete)
                    .HasColumnName("Part-A QC Complete")
                    .HasColumnType("datetime");

                entity.Property(e => e.PartAQcStartDate)
                    .HasColumnName("Part-A QC Start Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.PartAStartDate)
                    .HasColumnName("Part-A Start Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.PartBAssignment)
                    .HasColumnName("Part-B Assignment")
                    .HasColumnType("datetime");

                entity.Property(e => e.PartBCompleteDate)
                    .HasColumnName("Part-B Complete Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.PartBQcAssignment)
                    .HasColumnName("Part-B QC Assignment")
                    .HasColumnType("datetime");

                entity.Property(e => e.PartBQcComplete)
                    .HasColumnName("Part-B QC Complete")
                    .HasColumnType("datetime");

                entity.Property(e => e.PartBQcStartDate)
                    .HasColumnName("Part-B QC Start Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.PartBStartDate)
                    .HasColumnName("Part-B Start Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.ReadyToBill)
                    .HasColumnName("Ready to Bill")
                    .HasColumnType("datetime");

                entity.Property(e => e.ReferralLoad)
                    .HasColumnName("Referral LOAD")
                    .HasColumnType("datetime");

                entity.Property(e => e.ReportDelivered)
                    .HasColumnName("Report Delivered")
                    .HasColumnType("datetime");

                entity.Property(e => e.ReportGenerated)
                    .HasColumnName("Report Generated")
                    .HasColumnType("datetime");

                entity.Property(e => e.SuppRecAnalystAssigned)
                    .HasColumnName("Supp Rec Analyst Assigned")
                    .HasColumnType("datetime");

                entity.Property(e => e.SuppRecClaimReq)
                    .HasColumnName("Supp Rec Claim Req")
                    .HasColumnType("datetime");

                entity.Property(e => e.SuppRecCompleteDate)
                    .HasColumnName("Supp Rec Complete Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.SuppRecStartDate)
                    .HasColumnName("Supp Rec Start Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.SuppRefAnalystAssigned)
                    .HasColumnName("Supp Ref Analyst Assigned")
                    .HasColumnType("datetime");

                entity.Property(e => e.SuppRefClaimReq)
                    .HasColumnName("Supp Ref Claim Req")
                    .HasColumnType("datetime");

                entity.Property(e => e.SuppRefCompleteDate)
                    .HasColumnName("Supp Ref Complete Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.SuppRefStartDate)
                    .HasColumnName("Supp Ref Start Date")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<ReferralImportBatches>(entity =>
            {
                entity.HasKey(e => e.BatchId)
                    .HasName("PK__Referral__5D55CE38B69E35C9");

                entity.Property(e => e.BatchId).HasColumnName("BatchID");

                entity.Property(e => e.ImportDateTime).HasColumnType("datetime");

                entity.Property(e => e.SourceFileName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StgAopimport>(entity =>
            {
                entity.HasKey(e => e.AoprowId)
                    .HasName("PK__stg_AOPI__99C0E1080F4412AF");

                entity.ToTable("stg_AOPImport");

                entity.Property(e => e.AoprowId).HasColumnName("AOPRowID");

                entity.Property(e => e.BatchId).HasColumnName("BatchID");

                entity.Property(e => e.ClaimReceivedDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Client)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DebentureInterestRate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FhacaseNumber)
                    .HasColumnName("FHACaseNumber")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FhasettlementAmount)
                    .HasColumnName("FHASettlementAmount")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InterestEndDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InterestOnUpbamount)
                    .HasColumnName("InterestOnUPBAmount")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InterestStartDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastPaymentInstallmentDueDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LessOffsetAmount)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line107A)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line107B)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line108A)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line109A)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line110B)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line110C)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line111B)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line111C)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line112B)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line112C)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line113B)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line113C)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line114B)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line114C)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line115A)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line116B)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line117B)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line117C)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line118A)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line119A)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line119B)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line120B)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line120C)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line121C)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line122B)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line122C)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line123A)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line123B)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line123C)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line124A)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line124B)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line124C)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line125B)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line125C)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line126C)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line127A)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line128B)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line129B)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line130A)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line130B)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line130C)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line131A)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line131B)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Line131C)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoanNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PaymentAdviceType)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SettlementDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UnpaidPrincipalBalance)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Batch)
                    .WithMany(p => p.StgAopimport)
                    .HasForeignKey(d => d.BatchId)
                    .HasConstraintName("FK__stg_AOPImport__AOPImportBatches__BatchID");
            });

            modelBuilder.Entity<StgCompletedClaimAopreportOnetime>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("stg_CompletedClaimAOPReport_onetime");

                entity.Property(e => e.AopfinalFullClaimReceivedDate)
                    .HasColumnName("AOPFinalFullClaimReceivedDate")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AopfinalFullDebentureInterestRate)
                    .HasColumnName("AOPFinalFullDebentureInterestRate")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AopfinalFullDueDateofLastPaymentInstallment)
                    .HasColumnName("AOPFinalFullDueDateofLastPaymentInstallment")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AopfinalFullFhasettlmentAmount)
                    .HasColumnName("AOPFinalFullFHASettlmentAmount")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AopfinalFullInterestEndDate)
                    .HasColumnName("AOPFinalFullInterestEndDate")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AopfinalFullInterstStartDate)
                    .HasColumnName("AOPFinalFullInterstStartDate")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AopfinalFullLessOffsetAmount)
                    .HasColumnName("AOPFinalFullLessOffsetAmount")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AopfinalFullSettlementDate)
                    .HasColumnName("AOPFinalFullSettlementDate")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AopfinalFullTotalInterestPaid)
                    .HasColumnName("AOPFinalFullTotalInterestPaid")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AopfinalFullUnpaidPrincipalBalance)
                    .HasColumnName("AOPFinalFullUnpaidPrincipalBalance")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AoppartialClaimReceivedDate)
                    .HasColumnName("AOPPartialClaimReceivedDate")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AoppartialDebentureInterestRate)
                    .HasColumnName("AOPPartialDebentureInterestRate")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AoppartialDueDateofLastPaymentInstallment)
                    .HasColumnName("AOPPartialDueDateofLastPaymentInstallment")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AoppartialFhasettlementAmount)
                    .HasColumnName("AOPPartialFHASettlementAmount")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AoppartialInterestEndDate)
                    .HasColumnName("AOPPartialInterestEndDate")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AoppartialInterestStartDate)
                    .HasColumnName("AOPPartialInterestStartDate")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AoppartialLessOffsetAmount)
                    .HasColumnName("AOPPartialLessOffsetAmount")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AoppartialSettlementDate)
                    .HasColumnName("AOPPartialSettlementDate")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AoppartialTotalInterestPaid)
                    .HasColumnName("AOPPartialTotalInterestPaid")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AoppartialUnpaidPrincipalBalance)
                    .HasColumnName("AOPPartialUnpaidPrincipalBalance")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FhacaseNumber)
                    .HasColumnName("FHACaseNumber")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoanNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StgCompletedClaimPartAreportOnetime>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("stg_CompletedClaimPartAReport_onetime");

                entity.Property(e => e.BankruptcyLifyDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Block9)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BorrowerFirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BorrowerLastName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimFiledDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CommissionersAdjustedFairMarketValue)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ConveyanceExtensionDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DateDeedorAssignmentFiled)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DeedInLieuDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DueDateLastPaymentInstallment)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EndorsementDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FhacaseNumber)
                    .HasColumnName("FHACaseNumber")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ForeclosureFirstLegalDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InstitutionExtensionDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoanNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageeCurtailmentDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NumberLivingUnits)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OriginalPrincipalBalance)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyState)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyStreetAddressLine1)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyStreetAddressLine2)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyZipCode)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit1DateSecured)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit1DateVacated)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit1NameofOccupant)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit1OccupancyStatus)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit2DateSecured)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit2DateVacated)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit2NameofOccupant)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit2OccupancyStatus)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit3DateSecured)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit3DateVacated)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit3NameofOccupant)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit3OccupancyStatus)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit4DateSecured)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit4DateVacated)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit4NameofOccupant)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit4OccupancyStatus)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UnpaidPrincipalBalance)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StgCompletedClaimPartBreportOnetime>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("stg_CompletedClaimPartBReport_onetime");

                entity.Property(e => e.AdditionalClosingCostsAdditions)
                    .HasColumnName("Additional Closing Costs - Additions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AdditionalClosingCostsExpenses)
                    .HasColumnName("Additional Closing Costs - Expenses")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AdjustedRecoveryAmountAdditions)
                    .HasColumnName("Adjusted Recovery Amount - Additions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AdjustedRecoveryAmountDeductions)
                    .HasColumnName("Adjusted Recovery Amount - Deductions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AdjustedRecoveryAmountDeductions1)
                    .HasColumnName("Adjusted Recovery Amount - Deductions1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AdjustedRecoveryAmountExpenses)
                    .HasColumnName("Adjusted Recovery Amount - Expenses")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AdjustmentsToLoanBalanceAdditions)
                    .HasColumnName("Adjustments to Loan Balance - Additions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AdjustmentsToLoanBalanceDeductions)
                    .HasColumnName("Adjustments to Loan Balance - Deductions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AdjustmentsToLoanBalanceDeductions1)
                    .HasColumnName("Adjustments to Loan Balance - Deductions1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AdjustmentsToLoanBalanceExpenses)
                    .HasColumnName("Adjustments to Loan Balance - Expenses")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AmountDueFromBuyerAtClosingOrAtAppraisalNoticeDateDeductions)
                    .HasColumnName("Amount due from buyer at closing or at appraisal notice date - Deductions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AmountDueFromBuyerAtClosingOrAtAppraisalNoticeDateDeductions1)
                    .HasColumnName("Amount due from buyer at closing or at appraisal notice date - Deductions1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AmountOwedToBuyerAtClosingOrAtAppraisalNoticeDateAdditions)
                    .HasColumnName("Amount owed to buyer at closing or at appraisal notice date - Additions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AmountOwedToBuyerAtClosingOrAtAppraisalNoticeDateExpenses)
                    .HasColumnName("Amount owed to buyer at closing or at appraisal notice date - Expenses")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AppraisalFeeAdditions)
                    .HasColumnName("Appraisal Fee - Additions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AppraisalFeeDeductions)
                    .HasColumnName("Appraisal Fee - Deductions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AppraisalFeeDeductions1)
                    .HasColumnName("Appraisal Fee - Deductions1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AppraisalFeeExpenses)
                    .HasColumnName("Appraisal Fee - Expenses")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AppraisalFeeInterests)
                    .HasColumnName("Appraisal Fee - Interests")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AppraisalFeeInterests1)
                    .HasColumnName("Appraisal Fee - Interests1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AttorneyTrusteeFeesPaidExpenses)
                    .HasColumnName("Attorney   Trustee Fees Paid - Expenses")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AttorneyTrusteeFeesPaidInterests)
                    .HasColumnName("Attorney   Trustee Fees Paid - Interests")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AttorneyTrusteeFeesPaidInterests1)
                    .HasColumnName("Attorney   Trustee Fees Paid - Interests1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AttorneyTrusteeFesPaidAdditions)
                    .HasColumnName("Attorney   Trustee Fes Paid - Additions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BankruptcyFeeAdditions)
                    .HasColumnName("Bankruptcy Fee - Additions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BankruptcyFeeExpenses)
                    .HasColumnName("Bankruptcy Fee - Expenses")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BankruptcyFeeInterests)
                    .HasColumnName("Bankruptcy Fee - Interests")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BankruptcyFeeInterests1)
                    .HasColumnName("Bankruptcy Fee - Interests1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DeficiencyJudgmentCostsFees)
                    .HasColumnName("Deficiency Judgment Costs   Fees")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DeficiencyJudgmentCostsFeesDeductions)
                    .HasColumnName("Deficiency Judgment Costs   Fees - Deductions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DeficiencyJudgmentCostsFeesDeductions1)
                    .HasColumnName("Deficiency Judgment Costs   Fees - Deductions1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DeficiencyJudgmentCostsFeesExpenses)
                    .HasColumnName("Deficiency Judgment Costs - Fees - Expenses")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DeficiencyJudgmentCostsFeesInterests)
                    .HasColumnName("Deficiency Judgment Costs   Fees - Interests")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DeficiencyJudmentCostsFeesAdditions)
                    .HasColumnName("Deficiency Judment Costs   Fees - Additions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EscrowBalanceDeductions)
                    .HasColumnName("Escrow Balance - Deductions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EscrowBalanceDeductions1)
                    .HasColumnName("Escrow Balance - Deductions1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FhaCaseNumber)
                    .HasColumnName("FHA Case Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ForeclosureAcquisitionConveyanceAndOtherCostsAdditions)
                    .HasColumnName("Foreclosure   Acquisition   Conveyance and Other Costs - Additions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ForeclosureAcquisitionConveyanceAndOtherCostsExpenses)
                    .HasColumnName("Foreclosure   Acquisition   Conveyance and Other Costs - Expenses")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ForeclosureAcquisitionConveyanceAndOtherCostsInterests)
                    .HasColumnName("Foreclosure   Acquisition   Conveyance and Other Costs - Interests")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ForeclosureAcquisitionConveyanceAndOtherCostsInterests1)
                    .HasColumnName("Foreclosure   Acquisition   Conveyance and Other Costs - Interests1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoanNumber)
                    .HasColumnName("Loan Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageInsurancePremiumsAdditions)
                    .HasColumnName("Mortgage Insurance Premiums - Additions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageInsurancePremiumsExpenses)
                    .HasColumnName("Mortgage Insurance Premiums - Expenses")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageInsurancePremiumsInterests)
                    .HasColumnName("Mortgage Insurance Premiums - Interests")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageInsurancePremiumsInterests1)
                    .HasColumnName("Mortgage Insurance Premiums - Interests1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageNoteInterestInterests)
                    .HasColumnName("Mortgage Note Interest - Interests")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageNoteInterestInterests1)
                    .HasColumnName("Mortgage Note Interest - Interests1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OverheadCostsAdditions)
                    .HasColumnName("Overhead Costs - Additions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OverheadCostsExpenses)
                    .HasColumnName("Overhead Costs - Expenses")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OverheadCostsInterests)
                    .HasColumnName("Overhead Costs - Interests")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OverheadCostsInterests1)
                    .HasColumnName("Overhead Costs - Interests1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OverpaidSection235AssistancePaymentsAdditions)
                    .HasColumnName("Overpaid Section 235 Assistance Payments - Additions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OverpaidSection235AssistancePaymentsDeductions)
                    .HasColumnName("Overpaid Section 235 Assistance Payments - Deductions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OverpaidSection235AssistancePaymentsDeductions1)
                    .HasColumnName("Overpaid Section 235 Assistance Payments - Deductions1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OverpaidSection235AssistancePaymentsExpenses)
                    .HasColumnName("Overpaid Section 235 Assistance Payments - Expenses")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OverpaidSection235AssistancePaymentsInterests)
                    .HasColumnName("Overpaid Section 235 Assistance Payments - Interests")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OverpaidSection235AssistancePaymentsInterests1)
                    .HasColumnName("Overpaid Section 235 Assistance Payments - Interests1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RecoveryOrDamageDeductions)
                    .HasColumnName("Recovery or Damage - Deductions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RecoveryOrDamageDeductions1)
                    .HasColumnName("Recovery or Damage - Deductions1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RentalExpenseAdditions)
                    .HasColumnName("Rental Expense - Additions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RentalExpenseExpenses)
                    .HasColumnName("Rental Expense - Expenses")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RentalIncomeDeductions)
                    .HasColumnName("Rental Income - Deductions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RentalIncomeDeductions1)
                    .HasColumnName("Rental Income - Deductions1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SaleBidOrAppraisalValueDeductions)
                    .HasColumnName("Sale Bid or Appraisal Value - Deductions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SaleBidOrAppraisalValueDeductions1)
                    .HasColumnName("Sale Bid or Appraisal Value - Deductions1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SpecialAssessmentsAdditions)
                    .HasColumnName("Special Assessments - Additions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SpecialAssessmentsExpenses)
                    .HasColumnName("Special Assessments - Expenses")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SpecialAssessmentsInterests)
                    .HasColumnName("Special Assessments - Interests")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SpecialAssessmentsInterests1)
                    .HasColumnName("Special Assessments - Interests1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TotalDisbursementsAdditions)
                    .HasColumnName("Total Disbursements - Additions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TotalDisbursementsExpenses)
                    .HasColumnName("Total Disbursements - Expenses")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TotalDisbursementsForProtectionAndPreservationAdditions)
                    .HasColumnName("Total Disbursements for Protection and Preservation - Additions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TotalDisbursementsForProtectionAndPreservationExpenses)
                    .HasColumnName("Total Disbursements for Protection and Preservation - Expenses")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TotalDisbursementsForProtectionAndPreservationInterests)
                    .HasColumnName("Total Disbursements for Protection and Preservation - Interests")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TotalDisbursementsForProtectionAndPreservationInterests1)
                    .HasColumnName("Total Disbursements for Protection and Preservation - Interests1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TotalDisbursementsInterests)
                    .HasColumnName("Total Disbursements - Interests")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TotalDisbursementsInterests1)
                    .HasColumnName("Total Disbursements - Interests1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TotalTaxesOnDeedAdditions)
                    .HasColumnName("Total Taxes on Deed - Additions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TotalTaxesOnDeedExpenses)
                    .HasColumnName("Total Taxes on Deed - Expenses")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TotalTaxesOnDeedInterests)
                    .HasColumnName("Total Taxes on Deed - Interests")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TotalTaxesOnDeedInterests1)
                    .HasColumnName("Total Taxes on Deed - Interests1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UnappliedSection235AssistancePaymentsAdditions)
                    .HasColumnName("Unapplied Section 235 Assistance Payments - Additions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UnappliedSection235AssistancePaymentsDeductions)
                    .HasColumnName("Unapplied Section 235 Assistance Payments - Deductions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UnappliedSection235AssistancePaymentsDeductions1)
                    .HasColumnName("Unapplied Section 235 Assistance Payments - Deductions1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UnappliedSection235AssistancePaymentsExpenses)
                    .HasColumnName("Unapplied Section 235 Assistance Payments - Expenses")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UnappliedSection235AssistancePaymentsInterests)
                    .HasColumnName("Unapplied Section 235 Assistance Payments - Interests")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UnappliedSection235AssistancePaymentsInterests1)
                    .HasColumnName("Unapplied Section 235 Assistance Payments - Interests1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UncollectedInterestInterests)
                    .HasColumnName("Uncollected Interest - Interests")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UncollectedInterestInterests1)
                    .HasColumnName("Uncollected Interest - Interests1")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StgDueReportOnetime>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("stg_DueReport_onetime");

                entity.Property(e => e.BorrowerName)
                    .HasColumnName("Borrower Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CaseNumber)
                    .HasColumnName("Case Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimType)
                    .HasColumnName("Claim Type")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClientName)
                    .HasColumnName("Client Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CloseOutStepComplete)
                    .HasColumnName("Close Out Step Complete")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Delivered)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DueDate)
                    .HasColumnName("Due Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Ecd)
                    .HasColumnName("ECD")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HudRecvdAmount)
                    .HasColumnName("HUD Recvd Amount")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HudRecvdSupplementalDate)
                    .HasColumnName("HUD Recvd Supplemental Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoanNumber)
                    .HasColumnName("Loan Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MissingDoc)
                    .HasColumnName("Missing Doc")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MissingDoc2)
                    .HasColumnName("Missing Doc2")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PartACompleteDate)
                    .HasColumnName("Part A Complete Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PartAProcessor)
                    .HasColumnName("Part A Processor")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PartAStartDate)
                    .HasColumnName("Part A Start Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PartBCompleteDate)
                    .HasColumnName("Part B Complete Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PartBProcessor)
                    .HasColumnName("Part B Processor")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PartBStartDate)
                    .HasColumnName("Part B Start Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RcaComplete)
                    .HasColumnName("RCA Complete")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ReferralDate)
                    .HasColumnName("Referral Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SettlementDate)
                    .HasColumnName("Settlement Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SuppAnalyst)
                    .HasColumnName("Supp Analyst")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SuppAnalyst2)
                    .HasColumnName("Supp Analyst2")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SupplementalDueDate)
                    .HasColumnName("Supplemental Due Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SupplementalRecoveryAmount)
                    .HasColumnName("Supplemental Recovery Amount")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SupplementalRecoveryClaimFiled)
                    .HasColumnName("Supplemental Recovery Claim Filed")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SupplementalRecoveryNeeded)
                    .HasColumnName("Supplemental Recovery Needed")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SupplementalRefundAmount)
                    .HasColumnName("Supplemental Refund Amount")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SupplementalRefundClaimFiled)
                    .HasColumnName("Supplemental Refund Claim Filed")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SupplementalRefundNeeded)
                    .HasColumnName("Supplemental Refund Needed")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SupplementalTracking)
                    .HasColumnName("Supplemental Tracking #")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StgExpenseCatSubCatLookup>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("stg_ExpenseCatSubCatLookup");

                entity.Property(e => e.ExpenseCategory)
                    .HasColumnName("Expense Category")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.ExpenseSubCategory)
                    .HasColumnName("Expense Sub Category")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Table2LkpTypeSubCatId)
                    .HasColumnName("Table2 LkpTypeSubCatID")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StgExpenseImport>(entity =>
            {
                entity.HasKey(e => e.ExpenseRowId)
                    .HasName("PK__stg_ExpenseImport_ExpenseRowID");

                entity.ToTable("stg_ExpenseImport");

                entity.Property(e => e.ExpenseRowId).HasColumnName("ExpenseRowID");

                entity.Property(e => e.AdvanceFrom)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AmountClaimed)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AmountDispersed)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BatchId).HasColumnName("BatchID");

                entity.Property(e => e.ChargeOffReason)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimAmountOverride)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Client)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CoverageEndDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CoverageStartDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DateWorkCompleted)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ExpenseCategory)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FhacaseNumber)
                    .HasColumnName("FHACaseNumber")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ItemDescription)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.LoanNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LotSize)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PaidDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Quantity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ResponsibleParty)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.Batch)
                    .WithMany(p => p.StgExpenseImport)
                    .HasForeignKey(d => d.BatchId)
                    .HasConstraintName("FK__stg_ExpenseImport__ExpenseImportBatches__BatchID");
            });

            modelBuilder.Entity<StgLoanDataReportOnetime>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("stg_LoanDataReport_onetime");

                entity.Property(e => e.BuyOutDate)
                    .HasColumnName("Buy Out Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimType)
                    .HasColumnName("Claim Type")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Client)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClosingDate)
                    .HasColumnName("Closing Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClosingReason)
                    .HasColumnName("Closing Reason")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CompleteDate)
                    .HasColumnName("Complete Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DebentureInterestRate)
                    .HasColumnName("Debenture Interest Rate")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DueDate)
                    .HasColumnName("Due Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EndorsementDate)
                    .HasColumnName("Endorsement Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FhaCaseNumber)
                    .HasColumnName("FHA Case Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FhaCaseNumber1)
                    .HasColumnName("FHA Case Number1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Investor)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoanNumber)
                    .HasColumnName("Loan Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoanNumber1)
                    .HasColumnName("Loan Number1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NoteRate)
                    .HasColumnName("Note Rate")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OriginalDefaultDate)
                    .HasColumnName("Original Default Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PartAAnalyst)
                    .HasColumnName("Part A Analyst")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PartBAnalyst)
                    .HasColumnName("Part B Analyst")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ReferralDate)
                    .HasColumnName("Referral Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ServiceTransferDate)
                    .HasColumnName("Service Transfer Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StgPartAbkextensionsReportOnetime>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("stg_PartABKExtensionsReport_onetime");

                entity.Property(e => e.AttorneyProvidedLiftDate)
                    .HasColumnName("Attorney Provided Lift Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BankruptcyCompletionDate)
                    .HasColumnName("Bankruptcy Completion Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BankruptcyType)
                    .HasColumnName("Bankruptcy Type")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CaseNumber)
                    .HasColumnName("Case Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClearanceDate)
                    .HasColumnName("Clearance Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClosedSameDayAsDischarge)
                    .HasColumnName("Closed Same Day as Discharge")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DaysForAcceptableBankruptcyCompletion)
                    .HasColumnName("Days for Acceptable Bankruptcy Completion")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DischargeDate)
                    .HasColumnName("Discharge Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DismissalDate)
                    .HasColumnName("Dismissal Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FhaCaseNumber)
                    .HasColumnName("FHA Case Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FiledDate)
                    .HasColumnName("Filed Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FirstUnacceptableDelay)
                    .HasColumnName("First Unacceptable Delay")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ForeclosureFirstActionDate)
                    .HasColumnName("Foreclosure First Action Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoanNumber)
                    .HasColumnName("Loan Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MotionForReliefDate)
                    .HasColumnName("Motion for Relief Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OrderGrantingMotionForRelief)
                    .HasColumnName("Order Granting Motion For Relief")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Ruling)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.WereDelaysAcceptable)
                    .HasColumnName("Were Delays Acceptable")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e._4001RuleWaived)
                    .HasColumnName("4001 Rule Waived")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StgPartAdataInputReportOnetime>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("stg_PartADataInputReport_onetime");

                entity.Property(e => e.ApprovalToParticipateDate)
                    .HasColumnName("Approval to Participate Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BankruptcyLiftDateBlock21)
                    .HasColumnName("Bankruptcy Lift Date (Block 21)")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Block108)
                    .HasColumnName("Block 108")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Block9)
                    .HasColumnName("Block 9")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BorrowerFirstName)
                    .HasColumnName("Borrower First Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BorrowerLastName)
                    .HasColumnName("Borrower Last Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BorrowerPaymentsMade)
                    .HasColumnName("Borrower Payments Made")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CheckOrWireDate)
                    .HasColumnName("Check or Wire Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClientSpecifiedBlock9Date)
                    .HasColumnName("Client Specified Block 9 Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CommissionersAdjustedFairMarketValueBlock30)
                    .HasColumnName("Commissioners Adjusted Fair Market Value (Block 30)")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DateOfInspectionPriorToFirstTimeVacancy)
                    .HasColumnName("Date of Inspection Prior to First Time Vacancy")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DeedInLieuDateBlock11b)
                    .HasColumnName("Deed In Lieu Date (Block 11b)")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DeedInLieuTransferDate)
                    .HasColumnName("Deed In Lieu Transfer Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DefaultDate)
                    .HasColumnName("Default Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DueDate)
                    .HasColumnName("Due Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DueDateOfLastPaymentInstallmentBlock8)
                    .HasColumnName("Due Date of Last Payment Installment (Block 8)")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EndorsementDateBlock5)
                    .HasColumnName("Endorsement Date (Block 5)")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FhaCaseNumber)
                    .HasColumnName("FHA Case Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FirstInspectionDate)
                    .HasColumnName("First Inspection Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FirstInspectionStatus)
                    .HasColumnName("First Inspection Status")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FirstSfdmsCode1aDate)
                    .HasColumnName("First SFDMS Code 1A Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FirstTimeVacancyDate)
                    .HasColumnName("First Time Vacancy Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ForeclosureDeedRecordingDate)
                    .HasColumnName("Foreclosure Deed Recording Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ForeclosureSaleDate)
                    .HasColumnName("Foreclosure Sale Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HudAssignmentDate)
                    .HasColumnName("HUD Assignment Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HudDeedFilingDate)
                    .HasColumnName("HUD Deed Filing Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastLoanModificationDate)
                    .HasColumnName("Last Loan Modification Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastOnTimePaymentDate)
                    .HasColumnName("Last On Time Payment Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoanNumber)
                    .HasColumnName("Loan Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MarketableTitleDate)
                    .HasColumnName("Marketable Title Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NumberOfLivingUnits)
                    .HasColumnName("Number of Living Units")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OriginalDefaultDate)
                    .HasColumnName("Original Default Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OwnerSAssociation)
                    .HasColumnName("Owner's Association")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PfsSettlementDate)
                    .HasColumnName("PFS Settlement Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyCity)
                    .HasColumnName("Property City")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyReoSold)
                    .HasColumnName("Property REO Sold")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyState)
                    .HasColumnName("Property State")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyStreetAddressLine1)
                    .HasColumnName("Property Street Address Line 1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyStreetAddressLine2)
                    .HasColumnName("Property Street Address Line 2")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyZipCode)
                    .HasColumnName("Property Zip Code")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RecentVacancyDate)
                    .HasColumnName("Recent Vacancy Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RedemptionDate)
                    .HasColumnName("Redemption Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RrcDate)
                    .HasColumnName("RRC Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SfdmsReportingMissedCycles)
                    .HasColumnName("SFDMS Reporting Missed Cycles")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SufficientPaymentHistory)
                    .HasColumnName("Sufficient Payment History")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit1DateSecured)
                    .HasColumnName("Unit 1 Date Secured")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit1DateVacated)
                    .HasColumnName("Unit 1 Date Vacated")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit1NameOfOccupant)
                    .HasColumnName("Unit 1 Name of Occupant")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit1OccupancyStatus)
                    .HasColumnName("Unit 1 Occupancy Status")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit2DateSecured)
                    .HasColumnName("Unit 2 Date Secured")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit2DateVacated)
                    .HasColumnName("Unit 2 Date Vacated")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit2NameOfOccupant)
                    .HasColumnName("Unit 2 Name of Occupant")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit2OccupancyStatus)
                    .HasColumnName("Unit 2 Occupancy Status")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit3DateSecured)
                    .HasColumnName("Unit 3 Date Secured")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit3DateVacated)
                    .HasColumnName("Unit 3 Date Vacated")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit3NameOfOccupant)
                    .HasColumnName("Unit 3 Name of Occupant")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit3OccupancyStatus)
                    .HasColumnName("Unit 3 Occupancy Status")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit4DateSecured)
                    .HasColumnName("Unit 4 Date Secured")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit4DateVacated)
                    .HasColumnName("Unit 4 Date Vacated")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit4NameOfOccupant)
                    .HasColumnName("Unit 4 Name of Occupant")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Unit4OccupancyStatus)
                    .HasColumnName("Unit 4 Occupancy Status")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UnpaidPrincipalBalanceBlock17)
                    .HasColumnName("Unpaid Principal Balance (Block 17)")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e._2ndChanceSaleDate)
                    .HasColumnName("2nd Chance Sale Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StgPartAevictionExtensionsReportOnetime>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("stg_PartAEvictionExtensionsReport_onetime");

                entity.Property(e => e.CloseAndBillDate)
                    .HasColumnName("Close and Bill Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EvictionFirstLegalDate)
                    .HasColumnName("Eviction First Legal Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FhaCaseNumber)
                    .HasColumnName("FHA Case Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoanNumber)
                    .HasColumnName("Loan Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ReoccupancyDate)
                    .HasColumnName("Reoccupancy Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UnacceptableDelayStartDate)
                    .HasColumnName("Unacceptable Delay Start Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.VacancyDate)
                    .HasColumnName("Vacancy Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.VacancyType)
                    .HasColumnName("Vacancy Type")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StgPartAfcextensionsReportOnetime>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("stg_PartAFCExtensionsReport_onetime");

                entity.Property(e => e.Comments)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.FhaCaseNumber)
                    .HasColumnName("FHA Case Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FirstLegalDate)
                    .HasColumnName("First Legal Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoanNumber)
                    .HasColumnName("Loan Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RestartReason)
                    .HasColumnName("Restart Reason")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RestartValidity)
                    .HasColumnName("Restart Validity")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SfdmsCode68Date)
                    .HasColumnName("SFDMS Code 68 Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Type)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StgPartAlmextensionsReportOnetime>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("stg_PartALMExtensionsReport_onetime");

                entity.Property(e => e.ApprovalToParticipateExpirationDate)
                    .HasColumnName("Approval to Participate Expiration Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ApprovedContractDate)
                    .HasColumnName("Approved Contract Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ApprovedVariance)
                    .HasColumnName("Approved Variance")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BorrowerVacated)
                    .HasColumnName("Borrower Vacated")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DateLastPaymentPlanAppliedToLoan)
                    .HasColumnName("Date Last Payment Plan Applied to Loan")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DateOfAprovalToParticipate)
                    .HasColumnName("Date of Aproval to Participate")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DecisionDate)
                    .HasColumnName("Decision Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DocumentationAvailable)
                    .HasColumnName("Documentation Available")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DocumentationSignedDate)
                    .HasColumnName("Documentation Signed Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FhaCaseNumber)
                    .HasColumnName("FHA Case Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FirstMissedPaymentDueDate)
                    .HasColumnName("First Missed Payment Due Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FirstPlanPaymentDueDate)
                    .HasColumnName("First Plan Payment Due Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ForeclosureFirstActionDate)
                    .HasColumnName("Foreclosure First Action Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastPlanPaymentDueDate)
                    .HasColumnName("Last Plan Payment Due Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoanNumber)
                    .HasColumnName("Loan Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LossMitigationCode)
                    .HasColumnName("Loss Mitigation Code")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LossMitigationType)
                    .HasColumnName("Loss Mitigation Type")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NextPlanPaymentDueDate)
                    .HasColumnName("Next Plan Payment Due Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OptOutDate)
                    .HasColumnName("Opt Out Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PlanCompleted)
                    .HasColumnName("Plan Completed")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PlanIncludesSfbExpirationDate)
                    .HasColumnName("Plan Includes SFB Expiration Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PlanPaymentsSuspendedOrReduced)
                    .HasColumnName("Plan Payments Suspended or Reduced")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ReportsToSfdms)
                    .HasColumnName("Reports to SFDMS")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SfdmsReportDate)
                    .HasColumnName("SFDMS Report Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SpecialForeberanceExpirationDate)
                    .HasColumnName("Special Foreberance Expiration Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.VarianceExtensionDate)
                    .HasColumnName("Variance Extension Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.VarianceRequestDate)
                    .HasColumnName("Variance Request Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StgPartAotherDelaysReportOnetime>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("stg_PartAOtherDelaysReport_onetime");

                entity.Property(e => e.Acceptable)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EndDate)
                    .HasColumnName("End Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FhaCaseNumber)
                    .HasColumnName("FHA Case Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoanNumber)
                    .HasColumnName("Loan Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Reason)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.StartDate)
                    .HasColumnName("Start Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Type)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StgPartAotherExtensionsReportOnetime>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("stg_PartAOtherExtensionsReport_onetime");

                entity.Property(e => e.DateOfHazardClaim)
                    .HasColumnName("Date of Hazard Claim")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DateOfLoss)
                    .HasColumnName("Date of Loss")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DeclarationDate)
                    .HasColumnName("Declaration Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DischargeDate)
                    .HasColumnName("Discharge Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ExtensionType)
                    .HasColumnName("Extension Type")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FhaCaseNumber)
                    .HasColumnName("FHA Case Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FirstActionDate)
                    .HasColumnName("First Action Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HazardClaimSettlementDate)
                    .HasColumnName("Hazard Claim Settlement Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HudExtensionDate)
                    .HasColumnName("HUD Extension Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HudExtensionRequestDate)
                    .HasColumnName("HUD Extension Request Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HudSpecifiedExtensionDate)
                    .HasColumnName("HUD Specified Extension Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoanNumber)
                    .HasColumnName("Loan Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SalesContractApprovalDate)
                    .HasColumnName("Sales Contract Approval Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.StartOfActiveDuty)
                    .HasColumnName("Start of Active Duty")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.StatuteEndDate)
                    .HasColumnName("Statute End Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.StatuteStartDate)
                    .HasColumnName("Statute Start Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StgPartAtimeframesReportOnetime>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("stg_PartATimeframesReport_onetime");

                entity.Property(e => e.ClaimDueActualActivityDate)
                    .HasColumnName("Claim Due Actual Activity Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimDueDeadline)
                    .HasColumnName("Claim Due Deadline")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimDueDeadlineOverride)
                    .HasColumnName("Claim Due Deadline Override")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimDueExtensions)
                    .HasColumnName("Claim Due Extensions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimDueTest)
                    .HasColumnName("Claim Due Test")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ConveyanceActualActivityDate)
                    .HasColumnName("Conveyance Actual Activity Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ConveyanceExtensions)
                    .HasColumnName("Conveyance Extensions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ConveyanceTest)
                    .HasColumnName("Conveyance Test")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ConveyanceTestDeadline)
                    .HasColumnName("Conveyance Test Deadline")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ConveyanceTestDeadlineOverride)
                    .HasColumnName("Conveyance Test Deadline Override")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EvictionActualActivityDate)
                    .HasColumnName("Eviction Actual Activity Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EvictionExtensions)
                    .HasColumnName("Eviction Extensions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EvictionTest)
                    .HasColumnName("Eviction Test")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EvictionTestDeadline)
                    .HasColumnName("Eviction Test Deadline")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EvictionTestDeadlineOverride)
                    .HasColumnName("Eviction Test Deadline Override")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ExpenseCurtailmentDate)
                    .HasColumnName("Expense Curtailment Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ExpenseCurtailmentDateOverride)
                    .HasColumnName("Expense Curtailment Date Override")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FhaCaseNumber)
                    .HasColumnName("FHA Case Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ForeclosureInstitutionActualActivityDate)
                    .HasColumnName("Foreclosure Institution Actual Activity Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ForeclosureInstitutionExtensions)
                    .HasColumnName("Foreclosure Institution Extensions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ForeclosureInstitutionTest)
                    .HasColumnName("Foreclosure Institution Test")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ForeclosureInstitutionTestDeadline)
                    .HasColumnName("Foreclosure Institution Test Deadline")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ForeclosureInstitutionTestDeadlineOverride)
                    .HasColumnName("Foreclosure Institution Test Deadline Override")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HasExpenseCurtailment)
                    .HasColumnName("Has Expense Curtailment")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HasInterestCurtailment)
                    .HasColumnName("Has Interest Curtailment")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoanNumber)
                    .HasColumnName("Loan Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ReasonableDiligenceActualActivityDate)
                    .HasColumnName("Reasonable Diligence Actual Activity Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ReasonableDiligenceExtensions)
                    .HasColumnName("Reasonable Diligence Extensions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ReasonableDiligenceTest)
                    .HasColumnName("Reasonable Diligence Test")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ReasonableDiligenceTestDeadline)
                    .HasColumnName("Reasonable Diligence Test Deadline")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ReasonableDiligenceTestDeadlineOverride)
                    .HasColumnName("Reasonable Diligence Test Deadline Override")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SfdmsActualActivityDate)
                    .HasColumnName("SFDMS Actual Activity Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SfdmsExtensions)
                    .HasColumnName("SFDMS Extensions")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SfdmsTest)
                    .HasColumnName("SFDMS Test")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SfdmsTestDeadline)
                    .HasColumnName("SFDMS Test Deadline")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SfdmsTestDeadlineOverride)
                    .HasColumnName("SFDMS Test Deadline Override")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedCurtailmentDate)
                    .HasColumnName("Updated Curtailment Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedCurtailmentDateOverride)
                    .HasColumnName("Updated Curtailment Date Override")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StgPartBreportOnetime>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("stg_PartBReport_onetime");

                entity.Property(e => e.AdvanceFrom)
                    .HasColumnName("Advance From")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AmountClaimedPaid)
                    .HasColumnName("Amount Claimed & Paid")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AmountDisbursed)
                    .HasColumnName("Amount Disbursed")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AppraisalType)
                    .HasColumnName("Appraisal Type")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BankruptcyId)
                    .HasColumnName("Bankruptcy ID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CancellationDate)
                    .HasColumnName("Cancellation Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ChargeOffReason)
                    .HasColumnName("Charge Off Reason")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CompletedDate)
                    .HasColumnName("Completed Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CostEstimatorAmount)
                    .HasColumnName("Cost Estimator Amount")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CoverageEndDate)
                    .HasColumnName("Coverage End Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CoverageStartDate)
                    .HasColumnName("Coverage Start Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DebentureInterestClaimedPaid)
                    .HasColumnName("Debenture Interest Claimed & Paid")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Description)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.EstHazRefOnClaim)
                    .HasColumnName("Est Haz Ref on Claim")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EstHazRefRecommended)
                    .HasColumnName("Est Haz Ref Recommended")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EvictionAction)
                    .HasColumnName("Eviction Action")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ExpenseCategory)
                    .HasColumnName("Expense Category")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ExpenseSubCategory)
                    .HasColumnName("Expense Sub Category")
                    .HasMaxLength(120)
                    .IsUnicode(false);

                entity.Property(e => e.ExpenseType)
                    .HasColumnName("Expense Type")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FhaCaseNumber)
                    .HasColumnName("FHA Case Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ForeclosureAction)
                    .HasColumnName("Foreclosure Action")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HudApprovedAmount)
                    .HasColumnName("HUD Approved Amount")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HudApprovedDate)
                    .HasColumnName("HUD Approved Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InvoiceNumber)
                    .HasColumnName("Invoice Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoanNumber)
                    .HasColumnName("Loan Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LotSize)
                    .HasColumnName("Lot Size")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PaidDate)
                    .HasColumnName("Paid Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PartBrowId)
                    .HasColumnName("PartBRowID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.PenaltiesFeesInterest)
                    .HasColumnName("Penalties   Fees   Interest")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PolicyNumber)
                    .HasColumnName("Policy Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ProjectedLossAmount)
                    .HasColumnName("Projected Loss Amount")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Quantity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RecommendedClaimAmount)
                    .HasColumnName("Recommended Claim Amount")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RecommendedDebentureInterest)
                    .HasColumnName("Recommended Debenture Interest")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RefundAmount)
                    .HasColumnName("Refund Amount")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ResponsibleParty)
                    .HasColumnName("Responsible Party")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Review)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SaleType)
                    .HasColumnName("Sale Type")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ShortSaleAttempt)
                    .HasColumnName("Short Sale Attempt")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.WorkCompleteDate)
                    .HasColumnName("Work Complete Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StgReconciliationReportOnetime>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("stg_ReconciliationReport_onetime");

                entity.Property(e => e.ARecoveryAmount)
                    .HasColumnName("A Recovery Amount")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ARecoveryAmountOverride)
                    .HasColumnName("A Recovery Amount Override")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ARefundAmount)
                    .HasColumnName("A Refund Amount")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ARefundAmountOverride)
                    .HasColumnName("A Refund Amount Override")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AttorneyCosts)
                    .HasColumnName("Attorney Costs")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AttorneyFees)
                    .HasColumnName("Attorney Fees")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BERecoveryAmount)
                    .HasColumnName("B-E Recovery Amount")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BERecoveryAmountOverride)
                    .HasColumnName("B-E Recovery Amount Override")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BERefundAmount)
                    .HasColumnName("B-E Refund Amount")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BERefundAmountOverride)
                    .HasColumnName("B-E Refund Amount Override")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BalancingDifference)
                    .HasColumnName("Balancing Difference")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BankruptcyFees)
                    .HasColumnName("Bankruptcy Fees")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimFiledExpense)
                    .HasColumnName("Claim Filed Expense")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimFiledInterest)
                    .HasColumnName("Claim Filed Interest")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimFiledInterestDate)
                    .HasColumnName("Claim Filed Interest Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimFiledUnpaidPrincipalBalance)
                    .HasColumnName("Claim Filed Unpaid Principal Balance")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ControllableExpenseLosses)
                    .HasColumnName("Controllable Expense Losses")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ControllableInterestLosses)
                    .HasColumnName("Controllable Interest Losses")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CorporateBalance)
                    .HasColumnName("Corporate Balance")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CorporateDifference)
                    .HasColumnName("Corporate Difference")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CreditsAfterClaim)
                    .HasColumnName("Credits After Claim")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EscrowBalance)
                    .HasColumnName("Escrow Balance")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EscrowDifference)
                    .HasColumnName("Escrow Difference")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FhaCaseNumber)
                    .HasColumnName("FHA Case Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FinalFullProceeds)
                    .HasColumnName("Final   Full Proceeds")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FundsAppliedToEscrowCorporate)
                    .HasColumnName("Funds Applied to Escrow   Corporate")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Hud1)
                    .HasColumnName("HUD-1")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Hud1Difference)
                    .HasColumnName("HUD-1 Difference")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Interest)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InterestCurtailmentAmount)
                    .HasColumnName("Interest Curtailment Amount")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InterestDifferential)
                    .HasColumnName("Interest Differential")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InterestResponsibleParty)
                    .HasColumnName("Interest Responsible Party")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LiquidationProceeds)
                    .HasColumnName("Liquidation Proceeds")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoanNumber)
                    .HasColumnName("Loan Number")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PaidAfterClaim)
                    .HasColumnName("Paid After Claim")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PartialProceeds)
                    .HasColumnName("Partial Proceeds")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RecoveryYesNo)
                    .HasColumnName("Recovery Yes No")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RefundYesNo)
                    .HasColumnName("Refund Yes No")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RestrictedEscrowBalance)
                    .HasColumnName("Restricted Escrow Balance")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RestrictedEscrowDifference)
                    .HasColumnName("Restricted Escrow Difference")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SettledExpense)
                    .HasColumnName("Settled Expense")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SettledInterest)
                    .HasColumnName("Settled Interest")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SettledInterestDate)
                    .HasColumnName("Settled Interest Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SettledUnpaidPrincipalBalance)
                    .HasColumnName("Settled Unpaid Principal Balance")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SuspenseDifference)
                    .HasColumnName("Suspense Difference")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SuspenseEscrowBalance)
                    .HasColumnName("Suspense Escrow Balance")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TotalControllableLosses)
                    .HasColumnName("Total Controllable Losses")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TotalDebt)
                    .HasColumnName("Total Debt")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TotalLosses)
                    .HasColumnName("Total Losses")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TotalProceeds)
                    .HasColumnName("Total Proceeds")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TotalUncrontrollableLosses)
                    .HasColumnName("Total Uncrontrollable Losses")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Upb)
                    .HasColumnName("UPB")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedCurtailmentDate)
                    .HasColumnName("Updated Curtailment Date")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedExpenseAmount)
                    .HasColumnName("Updated Expense Amount")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedInterestAmount)
                    .HasColumnName("Updated Interest Amount")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedUnpaidPrincipalBalance)
                    .HasColumnName("Updated Unpaid Principal Balance")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.WriteOffTotal)
                    .HasColumnName("Write Off Total")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e._2MonthsInterest)
                    .HasColumnName("2 Months Interest")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StgReferralImport>(entity =>
            {
                entity.HasKey(e => e.ReferralRowId)
                    .HasName("PK__stg_Refe__FFBC1BF645EDF27A");

                entity.ToTable("stg_ReferralImport");

                entity.Property(e => e.ReferralRowId).HasColumnName("ReferralRowID");

                entity.Property(e => e.Attorney)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.BankruptcyLiftDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Cafmvamount)
                    .HasColumnName("CAFMVAmount")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CheckWireDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimSettlementDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimType)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Client)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ConveyanceExtensionDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DateDeed)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DateofApprovaltoParticipate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DebentureInterestRate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DilrecordedDate)
                    .HasColumnName("DILRecordedDate")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DueDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EndorsementDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FhacaseNumber)
                    .HasColumnName("FHACaseNumber")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.FirstTimeVacantDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ForeclosureDeedRecordedDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ForeclosureFirstLegalFiledDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ForeclosureSaleDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HudassignmentDate)
                    .HasColumnName("HUDAssignmentDate")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HuddeedFilingDate)
                    .HasColumnName("HUDDeedFilingDate")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InstitutionExtensionDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Investor)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastPaidInstallmentDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoanNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.MarketableTitleDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageeCurtailmentDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorFirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorLastName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NoteRate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NumberOfLivingUnits)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OriginalDefaultDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OriginalPrincipalBalance)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PartAclaimFiledDate)
                    .HasColumnName("PartAClaimFiledDate")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PassThroughRate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PfssettlementDate)
                    .HasColumnName("PFSSettlementDate")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PriorServicer)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyAddress)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyPreservationCompany)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyState)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyZip)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RedemptionDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ReferralBatchId).HasColumnName("ReferralBatchID");

                entity.Property(e => e.RrcexpirationDate)
                    .HasColumnName("RRCExpirationDate")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UnpaidPrincipalBalance)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e._2ndChanceSaleDate)
                    .HasColumnName("2ndChanceSaleDate")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.ReferralBatch)
                    .WithMany(p => p.StgReferralImport)
                    .HasForeignKey(d => d.ReferralBatchId)
                    .HasConstraintName("FK__stg_referralImport_ReferralImportBatches_BatchID");
            });

            modelBuilder.Entity<SupplementClaimInfo>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("SupplementClaimInfo");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.SuppRecOverrideAmount).HasColumnType("decimal(38, 2)");

                entity.Property(e => e.SuppRecoveryAmount).HasColumnType("decimal(38, 2)");

                entity.Property(e => e.SuppRecoveryHudrecAmount)
                    .HasColumnName("SuppRecoveryHUDRecAmount")
                    .HasColumnType("decimal(12, 2)");

                entity.Property(e => e.SuppRecoveryHudrecDate)
                    .HasColumnName("SuppRecoveryHUDRecDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.SuppRecoveryNeeded)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.SuppRecoveryTrackInfo)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SuppRefOverrideAmount).HasColumnType("decimal(38, 2)");

                entity.Property(e => e.SuppRefundAmount).HasColumnType("decimal(38, 2)");

                entity.Property(e => e.SuppRefundHudrecAmount)
                    .HasColumnName("SuppRefundHUDRecAmount")
                    .HasColumnType("decimal(12, 2)");

                entity.Property(e => e.SuppRefundHudrecDate)
                    .HasColumnName("SuppRefundHUDRecDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.SuppRefundNeeded)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.SuppRefundTrackInfo)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TimeframeTestandExt>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("TimeframeTestandExt");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.Sfdmsextension).HasColumnName("SFDMSExtension");

                entity.Property(e => e.Sfdmstest).HasColumnName("SFDMSTest");
            });

            modelBuilder.Entity<VwLoanPartBdata>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vwLoanPartBData");

                entity.Property(e => e.AopadditionAmount)
                    .HasColumnName("AOPAdditionAmount")
                    .HasColumnType("decimal(38, 2)");

                entity.Property(e => e.AopdeductionAmount)
                    .HasColumnName("AOPDeductionAmount")
                    .HasColumnType("decimal(38, 2)");

                entity.Property(e => e.AopinterestAmount)
                    .HasColumnName("AOPInterestAmount")
                    .HasColumnType("decimal(38, 2)");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.Note)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.PartBblockId).HasColumnName("PartBBlockID");

                entity.Property(e => e.PartBblockName)
                    .HasColumnName("PartBBlockName")
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.SubAdditionAmount).HasColumnType("decimal(38, 2)");

                entity.Property(e => e.SubDeductionAmount).HasColumnType("decimal(38, 2)");

                entity.Property(e => e.SubInterestAmount).HasColumnType("decimal(38, 2)");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
