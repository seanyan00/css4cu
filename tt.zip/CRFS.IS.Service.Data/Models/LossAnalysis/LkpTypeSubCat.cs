﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpTypeSubCat
    {
        public int LkpTypeSubCatId { get; set; }
        public int LkpTypeCatId { get; set; }
        public string LkpTypeSubCatName { get; set; }
        public bool Active { get; set; }
        public DateTime DateAdded { get; set; }
        public int AddedBy { get; set; }
        public DateTime DateModified { get; set; }
        public int ModifiedBy { get; set; }

        public virtual LkpTypeCat LkpTypeCat { get; set; }
    }
}
