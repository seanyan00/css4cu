﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgExpenseCatSubCatLookup
    {
        public string ExpenseCategory { get; set; }
        public string ExpenseSubCategory { get; set; }
        public string Table2LkpTypeSubCatId { get; set; }
    }
}
