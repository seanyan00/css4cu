﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LoanExtension
    {
        public int LoanExtensionId { get; set; }
        public int LoanId { get; set; }
        public int ExtensionType { get; set; }
        public DateTime? HudextensionRequestDate { get; set; }
        public DateTime? HudextensionDate { get; set; }
        public DateTime? DeclarationDate { get; set; }
        public DateTime? FemaextensionDate { get; set; }
        public DateTime? FirstActionDate { get; set; }
        public DateTime? StatuteStartDate { get; set; }
        public DateTime? StatuteEndDate { get; set; }
        public DateTime? ActiveDutyStartDate { get; set; }
        public DateTime? ActiveDutyDischargeDate { get; set; }
        public DateTime? HazardClaimDate { get; set; }
        public DateTime? HazardClaimSettlementDate { get; set; }
        public DateTime? LossDate { get; set; }
        public DateTime? SaleContractApprovalDate { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual Loan Loan { get; set; }
    }
}
