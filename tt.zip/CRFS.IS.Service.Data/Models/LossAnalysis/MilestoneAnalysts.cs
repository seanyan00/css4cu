﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class MilestoneAnalysts
    {
        public int LoanId { get; set; }
        public string PartAAssignment { get; set; }
        public string PartAQcAssignment { get; set; }
        public string PartBAssignment { get; set; }
        public string PartBQcAssignment { get; set; }
        public string SuppRefAnalystAssigned { get; set; }
        public string SuppRecAnalystAssigned { get; set; }
    }
}
