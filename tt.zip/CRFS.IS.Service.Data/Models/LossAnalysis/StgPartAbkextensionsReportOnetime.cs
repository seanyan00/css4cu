﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgPartAbkextensionsReportOnetime
    {
        public string LoanNumber { get; set; }
        public string FhaCaseNumber { get; set; }
        public string _4001RuleWaived { get; set; }
        public string AttorneyProvidedLiftDate { get; set; }
        public string BankruptcyCompletionDate { get; set; }
        public string BankruptcyType { get; set; }
        public string CaseNumber { get; set; }
        public string ClearanceDate { get; set; }
        public string ClosedSameDayAsDischarge { get; set; }
        public string DaysForAcceptableBankruptcyCompletion { get; set; }
        public string DischargeDate { get; set; }
        public string DismissalDate { get; set; }
        public string FiledDate { get; set; }
        public string FirstUnacceptableDelay { get; set; }
        public string ForeclosureFirstActionDate { get; set; }
        public string MotionForReliefDate { get; set; }
        public string OrderGrantingMotionForRelief { get; set; }
        public string Ruling { get; set; }
        public string WereDelaysAcceptable { get; set; }
    }
}
