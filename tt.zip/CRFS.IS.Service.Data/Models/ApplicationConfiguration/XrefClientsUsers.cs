﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefClientsUsers
    {
        public int ClientUserId { get; set; }
        public int ClientId { get; set; }
        public int UserId { get; set; }
        public bool MarkedForDelete { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual LkpClients Client { get; set; }
        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual LkpUsers User { get; set; }
    }
}
