﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpApplications
    {
        public int ApplicationId { get; set; }
        public string ApplicationName { get; set; }
        public string ApplicationUrl { get; set; }
        public int? CmsformId { get; set; }
        public DateTime EffectiveFromDate { get; set; }
        public DateTime EffectiveToDate { get; set; }
        public bool? Active { get; set; }
        public DateTime EnteredDate { get; set; }
        public int? EnteredByUserId { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUserId { get; set; }

        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
    }
}
