﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRFS.IS.Service.Util
{
    public static class FileLog
    {

    }
}
