﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Google.Protobuf.WellKnownTypes;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.Common.TransferObjects;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Security;

namespace CRFS.IS.Service.Business
{
    public class DataAutomationProvider
    {
        private IConfiguration _config;
        private ILogger _logger;
        private int _userid;

        public DataAutomationProvider(IConfiguration config, ILogger logger, int uid)
        {
            _config = config;
            _logger = logger;
            _userid = uid;
        }

        public GetFHAConnectionAccountsReply GetFHASystemAccounts()
        {
            var ret = new GetFHAConnectionAccountsReply();

            try
            {
                using (var dactx = new DataAutomationContext())
                {
                    var temp = dactx.LkpAutomationSystems.Select(x => new AutoSystem
                    {
                        Id = x.AutomationSystemId,
                        Active = x.Active ?? true ? 1 : 0,
                        AuthPmtAdvRetrieve = x.AuthPmtAdvRetrieve.GetIntValue(),
                        AuthSS820Alt = x.AuthSs820alt.GetIntValue(),
                        AuthSS824Alt = x.AuthSs824alt.GetIntValue(),
                        CMSClientId = x.CmsClientId ?? 0,
                        CredentialsValid = x.CredentialsValid.GetIntValue(),
                        MainFrameCommand = x.MainFrameCommand.GetSafeString(),
                        OwnerId = x.OwnerId ?? 0,
                        PWDChangeDate = x.PwdchangeDate.GetSafeDateTimeString(),
                        SystemId = x.SystemId,
                        SystemKey = x.SystemKey.GetSafeString(),
                        SystemName = x.SystemName,
                        SystemOtherCode = x.SystemOtherCode.GetSafeString(),
                        SystemPageCheck = x.SystemPageCheck.GetSafeString(),
                        SystemPassword = Constant.PasswordStr,
                        SystemType = x.SystemType,
                        SystemURL = x.SystemUrl.GetSafeString(),
                        UsedFor = x.UsedFor.GetSafeString(),
                        WebCMSClientID = x.WebCmsClientId ?? 0
                    }).ToList();

                    ret.AutoSystems.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public string GetPassword(int id)
        {
            var ret = Constant.PasswordStr;

            try
            {
                using(var dactx = new DataAutomationContext())
                {
                    var temp = dactx.LkpAutomationSystems.Where(x => x.AutomationSystemId == id).Select(x => x.SystemPassword).Single();

                    ret = temp.Decrypt(true);
                }
            }
            catch(Exception ex)
            {
                throw;
            }

            return ret;
        }
        public string SaveAutoSystem(AutoSystem data)
        {
            var ret = Constant.Success;

            try
            {
                using(var dactx = new DataAutomationContext())
                {
                    if(data.Id > 0)
                    {
                        var temp = dactx.LkpAutomationSystems.Where(x => x.AutomationSystemId == data.Id).Single();

                        temp.Active = data.Active == 1 || data.Active == Constant.NULLINT;
                        temp.AuthPmtAdvRetrieve = data.AuthPmtAdvRetrieve.GetBoolValue();
                        temp.AuthSs820alt = data.AuthSS820Alt.GetBoolValue();
                        temp.AuthSs824alt = data.AuthSS824Alt.GetBoolValue();
                        temp.CmsClientId = data.CMSClientId.GetNullIntOrId();
                        temp.CredentialsValid = data.CredentialsValid.GetBoolValue();
                        temp.DateUpdated = DateTime.Now;
                        temp.UpdatedBy = _userid;
                 
                        temp.OwnerId = data.OwnerId;
                        if (data.SystemPassword != Constant.PasswordStr && temp.SystemPassword.Decrypt(true) != data.SystemPassword) {
                            temp.PwdchangeDate = DateTime.Now;
                            temp.SystemPassword = data.SystemPassword.Encrypt(true);
                        }
                       // temp.SystemId = data.SystemId;
                       
                        temp.SystemName = data.SystemName;
                        temp.SystemOtherCode = data.SystemOtherCode; 
                        ///May comment out to not update
                        temp.SystemKey = data.SystemKey;
                        temp.SystemPageCheck = data.SystemPageCheck;
                        temp.SystemType = data.SystemType;
                        temp.SystemUrl = data.SystemURL;       
                        temp.MainFrameCommand = data.MainFrameCommand;
                        ///
                        temp.UsedFor = data.UsedFor;
                        temp.WebCmsClientId = data.WebCMSClientID.GetNullIntOrId();
                    } else
                    {
                        dactx.LkpAutomationSystems.Add(new LkpAutomationSystems
                        {
                            Active = true,
                            EnteredBy = _userid,
                            DateEntered = DateTime.Now,
                            AuthPmtAdvRetrieve = data.AuthPmtAdvRetrieve.GetBoolValue(),
                            AuthSs820alt = data.AuthSS820Alt.GetBoolValue(),
                            AuthSs824alt = data.AuthSS824Alt.GetBoolValue(),
                            CmsClientId = data.CMSClientId.GetNullIntOrId(),
                            CredentialsValid = data.CredentialsValid.GetBoolValue(),
                            DateUpdated = DateTime.Now,
                            UpdatedBy = _userid,
                            MainFrameCommand = data.MainFrameCommand,
                            OwnerId = data.OwnerId,
                            PwdchangeDate = DateTime.Now,
                            SystemPassword = data.SystemPassword.Encrypt(true),
                            SystemId = data.SystemId,
                            SystemKey = data.SystemKey,
                            SystemName = data.SystemName,
                            SystemOtherCode = data.SystemOtherCode,
                            SystemPageCheck = data.SystemPageCheck,
                            SystemType = data.SystemType,
                            SystemUrl = data.SystemURL,
                            UsedFor = data.UsedFor,
                            WebCmsClientId = data.WebCMSClientID.GetNullIntOrId()
                         });
                    }
                    dactx.SaveChanges();
                }
            }
            catch(Exception ex)
            {
                throw;
            }

            return ret;
        }
    }
}
