﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Net;
using System.Net.Cache;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Xml.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Google.Protobuf.WellKnownTypes;
using DocuWare.Platform.ServerClient;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.Common.TransferObjects;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Security;
using CRFS.IS.Service.Util;
using CRFS.IS.Service.Business.Models;

namespace CRFS.IS.Service.Business
{
    public class DocuwareProvider
    {
        private IConfiguration _config;
        private ILogger _logger;
        private int _userid;

        public DocuwareProvider(IConfiguration config, ILogger logger, int uid = 0)
        {
            _config = config;
            _logger = logger;
            _userid = uid;
        }
        //http://vm-dw-u.uat.crfs.crfservices.com/DocuWare/Platform
        //http://docuware.crfs.crfservices.com/docuware/platform
        public async Task<MessageReply> GetDocumentStatusAsync(GetDocumentStatusRequest req)
        {
            var ret = new MessageReply { Message = "Complete" };
            var appsetting = _config.GetSection("AppSettings").Get<AppSettings>();
       
            try
            {
                var postdata = new List<KeyValuePair<string, string>>
                {
                    new KeyValuePair<string, string>("UserName", appsetting.DW_UserName),
                    new KeyValuePair<string, string>("Password", appsetting.DW_Password),
                    new KeyValuePair<string, string>("LicenseType", ""),
                    new KeyValuePair<string, string>("RedirectToMyselfInCaseOfError", "false"),
                    new KeyValuePair<string, string>("RememberMe", "false"),
                    new KeyValuePair<string, string>("HostID", "CURL_CLIENT")
                };
                HttpContent content = new FormUrlEncodedContent(postdata);
            
                var cookiejar = new CookieContainer();
                var handler = new HttpClientHandler
                {
                    CookieContainer = cookiejar,
                    UseCookies = true
                };
                using(var client = new HttpClient(handler))
                {
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(
                        new MediaTypeWithQualityHeaderValue("application/json"));
                    client.BaseAddress = new Uri(appsetting.DW_Platform);

                    var response = await client.PostAsync("Account/Logon", content);
                    response.EnsureSuccessStatusCode();
                    
                    //IEnumerable<Cookie> responseCookies = cookiejar.GetCookies(url).Cast<Cookie>();

                /*    response = await client.GetAsync(url + "/Organizations");

                    response.EnsureSuccessStatusCode();
                    var jstr = await response.Content.ReadAsStringAsync();
                    //var js = JsonSerializer.Deserialize<Dictionary<string, dynamic>>(jstr);

                    response = await client.GetAsync(url + "/FileCabinets?orgid=1");

                    response.EnsureSuccessStatusCode();
                    jstr = await response.Content.ReadAsStringAsync();
                */
                   // response = await client.GetAsync("FileCabinets/C8CB8902-FEF1-471C-987A-16B367F3D169");

                  //  response.EnsureSuccessStatusCode();
                 //   var jstr = await response.Content.ReadAsStringAsync();

                 //   response = await client.GetAsync("FileCabinets/C8CB8902-FEF1-471C-987A-16B367F3D169/Dialogs/CE9F2EF1-6269-442F-887D-8CB240C82872?dialogType=");

                 //   response.EnsureSuccessStatusCode();
                  //  jstr = await response.Content.ReadAsStringAsync();

                    var cond = new DWDialogExpression
                    {
                        Operation = "And",
                        Condition = new List<DWSearchCondition>
                        {
                            new DWSearchCondition{ DBName = "Loan_Number", Value = new List<string>{"1010057374" } },
                            new DWSearchCondition{ DBName = "Claim_Type", Value = new List<string> { "FHA CWCOT" } }
                        }
                    };
                    var jsoncontent = JsonContent.Create<DWDialogExpression>(cond/*, new MediaTypeWithQualityHeaderValue("application/json")*/);

                    response = await client.PostAsync("FileCabinets/C8CB8902-FEF1-471C-987A-16B367F3D169/Query/DialogExpressionLink?dialogId=CE9F2EF1-6269-442F-887D-8CB240C82872",
                        jsoncontent);
                    var querystr = await response.Content.ReadAsStringAsync();
                    response = await client.GetAsync(querystr);
                    var jstr = await response.Content.ReadAsStringAsync();
                    //  response = await client.GetAsync("FileCabinets/C8CB8902-FEF1-471C-987A-16B367F3D169/Dialogs/CE9F2EF1-6269-442F-887D-8CB240C82872?dialogType=");
                    // jstr = await response.Content.ReadAsStringAsync();
                  
                    // response = await client.PostAsync("FileCabinets/C8CB8902-FEF1-471C-987A-16B367F3D169/Dialogs/CE9F2EF1-6269-442F-887D-8CB240C82872?dialogType=");
                    //jstr = await response.Content.ReadAsStringAsync();

                    /*postdata = new List<KeyValuePair<string, string>>
                    {
                        new KeyValuePair<string, string>("LOAN_NUMBER", "1010057374"),
                        new KeyValuePair<string, string>("CLAIM_TYPE", "FHA CWCOT")
                    };
                    var xmlstr = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n<DialogExpression xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\""
                               + "Count=\"100\" Operation=\"And\" CompleteConditionInInvariantCulture=\"false\" xmlns=\"http://dev.docuware.com/schema/public/services/platform\">\r\n"
                               + "<SortOrder>\r\n        <OrderBy Field=\"DWSTOREDATETIME\" Direction=\"Desc\" />\r\n    </SortOrder>\r\n"
                               + "<Condition DBName=\"DWDOCID\">\r\n        <Value>1</Value>\r\n    </Condition>\r\n    <AdditionalCabinets>00000000-0000-0000-0000-000000000000</AdditionalCabinets>\r\n"
                               + "<AdditionalCabinets>00000000-0000-0000-0000-000000000000</AdditionalCabinets>\r\n</DialogExpression>";
                    XDocument postdata1 = new XDocument(   
                                            new XElement("Root",
                                                new XElement("LOAN_NUMBER", "1010057374"),
                                                new XElement("CLAIM_TYPE", "FHA CWCOT")
                                             )
                                        );
                    var content1 = new StringContent(postdata1.ToString(), Encoding.UTF8, "text/xml");
                 */
                    // response = await client.GetAsync("FileCabinets/C8CB8902-FEF1-471C-987A-16B367F3D169/Dialogs/CE9F2EF1-6269-442F-887D-8CB240C82872/Query/Documents?q=");
                   // response = await client.PostAsync("FileCabinets/C8CB8902-FEF1-471C-987A-16B367F3D169/Query/DialogExpression?dialogId=CE9F2EF1-6269-442F-887D-8CB240C82872&count=2100000000", 
                    //                                  content1);
                    //response.EnsureSuccessStatusCode();
                   // jstr = await response.Content.ReadAsStringAsync();
                   /* postdata = new List<KeyValuePair<string, string>>
                    {
                        new KeyValuePair<string, string>("LOAN_NUMBER", "1010057374"),
                        new KeyValuePair<string, string>("CLAIM_TYPE", "FHA CWCOT")
                    };
                    content = new FormUrlEncodedContent(postdata);
                    content.Headers.Add("Content-Type", "application/x-www-form-urlencoded");
                    response = await client.PostAsync("FileCabinets/C8CB8902-FEF1-471C-987A-16B367F3D169/Dialogs/CE9F2EF1-6269-442F-887D-8CB240C82872/CreateUserDefinedSearch", content);

                    response.EnsureSuccessStatusCode();
                    jstr = await response.Content.ReadAsStringAsync();
                    */
                }
            }
            catch(Exception ex)
            {
                throw;
            }

            return ret;
        }
    }
}
