﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.ServiceModel;

namespace CRFS.IS.Service.Business.Jobs
{
    public  class Locator 
    {
        string uri { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="uri"></param>
        public Locator(string uri)
        {
            this.uri = uri;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public DataTable go(DataTable dt)
        {
            var binding = new BasicHttpBinding();
            var endpoint = new EndpointAddress(uri);
            var fac = new ChannelFactory<LocatorInterface>(binding, endpoint);
            
            var cln = fac.CreateChannel();
            var ret = cln.getStorageParameters(dt, "");
            return ret;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="claimid"></param>
        /// <param name="doctype"></param>
        /// <returns></returns>
        public DataTable go(string env, int claimid, string doctype, string Initiator, string OriginationUser)
        {
            DataTable dt = new DataTable("locateparm");
            dt.Columns.Add("claimid", typeof(int));
            dt.Columns.Add("field", typeof(string));
            dt.Columns.Add("value", typeof(string));

            switch (env.ToUpper())
            {
                case "DEV":
                case "UAT":
                    env = "UAT";
                    break;

                case "PROD":
                    env = "PROD";
                    break;
            }

            DataRow dr = dt.NewRow();
            dr["claimid"] = claimid;
            dr["field"] = "Environment";
            dr["value"] = env;
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["claimid"] = claimid;
            dr["field"] = "DocType";
            dr["value"] = doctype;
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["claimid"] = claimid;
            dr["field"] = "Initiator";
            dr["value"] = Initiator;
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["claimid"] = claimid;
            dr["field"] = "OriginationUser";
            dr["value"] = OriginationUser;
            dt.Rows.Add(dr);

            dt = go(dt);

            // fill in the dates
            foreach (DataRow dr2 in dt.Rows)
            {
                 if (dr2["Field"].ToString().ToUpper() == "ORIGINATIONDATE")
                    dr2["value"] = DateTime.Now.ToString("s");
            }
            return dt;
        }
    }
}

