﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.EntityFrameworkCore;

using CRFS.IS.Service.Data;
using CRFS.IS.Service.Common;
using CRFS.IS.Service.Business.Models;

namespace CRFS.IS.Service.Business.Jobs
{
    public static class JobStatusHelper
    {
        public static string GetJobParamValue(this List<KeyValuePair<string, string>> ljp, string key)
        {
            var ret = "";
            if(ljp.Any(x => x.Key == key))
            {
                ret = ljp.Single(x => x.Key == key).Value;
            }
            return ret;
        }
        public static string GetReportParamValue(this List<DBParameter> lrp, string dbname)
        {
            var ret = "";
            if(lrp.Any(x => x.ParamDbName == dbname && x.ForReportName > 0))
            {
                ret = lrp.Single(x => x.ParamDbName == dbname && x.ForReportName > 0).Value;
            }
            return ret;
        }
        public static string GetReportParamValue(this List<VwClientReport> lrp, string dbname)
        {
            var temp = lrp.Take(1).Single();
            return temp.GetType().GetProperty(dbname).GetValue(temp, null).ToString();
        }
        public static int SaveStatus(TblScheduledJobStatus js)
        {
            var ret = 0;

            try
            {
                using (var ctx = new PortalContext())
                {
                    if(js.Id > 0)
                    {
                        var temp = ctx.TblScheduledJobStatus.Where(x => x.Id == js.Id).Single();
                        temp.Status = js.Status;
                        temp.Message = temp.Message + ". " + js.Message;
                        temp.TimeEnd = temp.TimeEnd;
                        ctx.SaveChanges();
                    } else
                    {
                        ctx.TblScheduledJobStatus.Add(js);
                        ctx.SaveChanges();
                        ret = js.Id;
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public static void UpdateStatus(int id, string stt, DateTime? tend, string msg = "")
        {
            try
            {
                using (var ctx = new PortalContext())
                {
                    var temp = ctx.TblScheduledJobStatus.Where(x => x.Id == id).Single();
                    temp.Status = string.IsNullOrEmpty(stt) ? temp.Status : stt;
                    var tmsg = temp.Message + (string.IsNullOrEmpty(msg) ? "" : (". " + msg));
                    temp.Message = tmsg.Substring(0, Math.Min(tmsg.Length, 1999));
                    temp.TimeEnd = tend == (DateTime?)null ? temp.TimeEnd : tend;
                    ctx.SaveChanges();
                 
                }
            }
            catch
            {
                throw;
            }
     
        }
    }
}
