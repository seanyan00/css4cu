﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.Data;

namespace CRFS.IS.Service.Business.Jobs
{
    [ServiceContract(Namespace = "LocatorInterface")]
    public interface LocatorInterface
    {
        [OperationContract]
        DataTable getStorageParameters(DataTable dt, string env);
    }
}
