﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

using Renci.SshNet;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Util;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.Security;
namespace CRFS.IS.Service.Business.Jobs.FTPJobTasks
{
    public class FTPDeleteFolderJobTask : FTPTaskBase
    {
        public FTPDeleteFolderJobTask(int taskid, Models.SchItem item, ILogger logger, AppSettings setting) : base(taskid, item, logger, setting)
        {
            Init();
        }
        new public void Init()
        {
            base.Init();

            if (JobTask.SourceFolder.Contains("%"))
            {
                JobTask.SourceFolder = ReplaceDelimiters(JobTask.SourceFolder);
            }
        }
        public override List<string> ExecuteTask()
        {
            if (!Directory.Exists(JobTask.SourceFolder))
            {
                throw new Exception("FTMS Task " + JobTask.TaskName + " : Folder to be deleted does not exist." +
                     " The task will be aborted.");
            }

            if (!IsDirectoryEmpty(JobTask.SourceFolder))
            {
                throw new Exception("FTMS Task " + JobTask.TaskName + " : Folder to be deleted does not exist." +
                     " The task will be aborted.");
            }
            else
            {
                try
                {
                    Directory.Delete(JobTask.SourceFolder, false);
                }
                catch (Exception ex)
                {
                    Logger.LogError("Exception " + ex.Message + " occured attempting to delete folder " + JobTask.SourceFolder);
                    throw new Exception("Unable to delete folder " + JobTask.SourceFolder + " because an error occurred. The error was: " +
                        ex.Message);
                }
            }
            return new List<string>();
        }
    }
}
