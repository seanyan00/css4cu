﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

using Renci.SshNet;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Util;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.Security;

namespace CRFS.IS.Service.Business.Jobs.FTPJobTasks
{
    public class FTPCompressJobTask : FTPTaskBase
    {
        public FTPCompressJobTask(int taskid, Models.SchItem item, ILogger logger, AppSettings setting) : base(taskid, item, logger, setting)
        {
            Init();
        }
        new public void Init()
        {
            base.Init();

            if (JobTask.SourceFolder.Contains("%"))
            {
                JobTask.SourceFolder = ReplaceDelimiters(JobTask.SourceFolder);
            }
            if (JobTask.DestinationFolder.Contains("%"))
            {
                JobTask.DestinationFolder = ReplaceDelimiters(JobTask.DestinationFolder);
            }
            try
            {
                using (var appctx = new ApplicationConfigurationContext())
                {

                }
            }
            catch (Exception ex)
            {
                throw new Exception("Unable to retrieve FTP properties for the job. Job will be aborted. The error was: " +
                    ex.Message);
            }
        }
        public override List<string> ExecuteTask()
        {
            return new List<string>();
        }
    }
}
