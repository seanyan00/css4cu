﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Util;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.Security;

namespace CRFS.IS.Service.Business.Jobs.FTPJobTasks
{
    public class FTPEmailJobTask : FTPTaskBase
    {
        public List<string> FilesToNotify { get; set; }
        public List<FTPTaskEmailRecipient> EmailRecipients { get; set; }
        public FTPEmailTask EmailTask { get; set; }

        public FTPEmailJobTask(int taskid, Models.SchItem item, ILogger logger, AppSettings setting, 
            List<string> filetonotify, List<FTPTaskEmailRecipient> emailrecipients) : base(taskid, item, logger, setting)
        {
            FilesToNotify = filetonotify;
            EmailRecipients = emailrecipients;
            Init();
        }
        new public void Init()
        {
            base.Init();
            using(var ctx = new ApplicationConfigurationContext())
            {
                EmailTask = ctx.LkpFtmsEmailTasks.Where(x => x.TaskId == JobTask.TaskId)
                    .Select(x => new FTPEmailTask { 
                        TaskId = x.TaskId,
                        EmailFiesAsAttachments = x.EmailFilesAsAttachments ? 1 : 0,
                        SendEachMatchingFileAsSeparateEmail = x.SendEachMatchingFileAsSeparateEmail ? 1 : 0,
                        EmailSubject = x.EmailSubject.GetSafeString(),
                        EmailText = x.EmailText.GetSafeString(),
                        IncludeFileDetailsInEmailBody = x.IncludeFileDetailsInEmailBody ? 1 : 0,
                        SendIfNoFilesProcessed = x.SendIfNoFilesProcessed ? 1 : 0
                    }).SingleOrDefault();
            }
            EmailRecipients = EmailRecipients.Union(Recipients).ToList();
        }
        public override List<string> ExecuteTask()
        {
            if (EmailTask != null && EmailRecipients.Count > 0 && (EmailTask.SendIfNoFilesProcessed == 1 || FilesToNotify.Count > 0))
            {
                var msgto = string.Join(",", EmailRecipients.Where(x => x.MessageType.ToUpper() == "MESSAGE" && x.RecipientType == "TO").Select(x => x.EmailAddress).ToArray());
                var msgcc = string.Join(",", EmailRecipients.Where(x => x.MessageType.ToUpper() == "MESSAGE" && x.RecipientType == "CC").Select(x => x.EmailAddress).ToArray());
                var msgbcc = string.Join(",", EmailRecipients.Where(x => x.MessageType.ToUpper() == "MESSAGE" && x.RecipientType == "BCC").Select(x => x.EmailAddress).ToArray());

                var msg = new StringBuilder(EmailTask.EmailText);
                
                foreach (string f in FilesToNotify)
                {
                    if (EmailTask.IncludeFileDetailsInEmailBody == 1)
                    {
                        string ctime = "";
                      
                        if (File.Exists(f))
                        {
                            ctime = File.GetCreationTime(f).ToString("f");
                        }
                        else
                        {
                            ctime = DateTime.Now.ToString();
                        }
                        msg.Append("<br>File Name: " + Path.GetFileName(f) + ";  Received time: " +  ctime + "<br/>");
                    }
                   
                    if (EmailTask.SendEachMatchingFileAsSeparateEmail == 1)
                    {
                        Email.SendMail(Constant.SendFrom,
                            msgto,
                            EmailTask.EmailSubject,
                            msg.ToString(),
                            new string[] { f },
                            Setting.MailServer,
                            msgcc, null, msgbcc
                            );

                        Logger.LogInformation("Email sent to " + msgto);
                        LogEmailMessage(JobTask.TaskId, msgto, msgcc, msgbcc, msg.ToString(), f);
                    }
                }
                if (!string.IsNullOrEmpty(msg.ToString()))
                {
                    Email.SendMail(Constant.SendFrom,
                            msgto,
                            EmailTask.EmailSubject,
                            msg.ToString(),
                            null,
                            Setting.MailServer,
                            msgcc, null, msgbcc
                            );

                    Logger.LogInformation("Email sent to " + msgto);
                    LogEmailMessage(JobTask.TaskId, msgto, msgcc, msgbcc, msg.ToString(), "");
                }

            }
            if (Warnings.Count > 0)
            {
                SendWarnings();
            }
            return new List<string> { };
        }
        private void LogEmailMessage(int taskid, string to, string cc, string bcc, string body, string files)
        {
            using(var ctx = new DataAutomationContext())
            {
                ctx.LogFtmsEmailLog.Add(new LogFtmsEmailLog
                {
                    Attachments = files,
                    EmailText = body,
                    FtmsemailLogId = 0,
                    RecipBcc = bcc,
                    RecipCc = cc,
                    RecipTo = to,
                    SentDate = DateTime.Now,
                    TaskId = taskid
                });
                ctx.SaveChanges();
            }
           
        }
    }
}
