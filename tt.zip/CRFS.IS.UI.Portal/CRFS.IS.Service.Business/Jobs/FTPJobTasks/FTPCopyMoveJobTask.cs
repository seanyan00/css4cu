﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

using Renci.SshNet;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Util;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.Security;

namespace CRFS.IS.Service.Business.Jobs.FTPJobTasks
{
    public class FTPCopyMoveJobTask : FTPTaskBase
    {
        public string LastFolder { get; set; }
        public FTPCopyMoveJobTask(int taskid, Models.SchItem item, ILogger logger, AppSettings setting, string lastfolder) : base(taskid, item, logger, setting)
        {
            LastFolder = lastfolder;
            Init();
        }
        new public void Init()
        {
            base.Init();

            if (!string.IsNullOrEmpty(LastFolder))
            {
                if (JobTask.SourceFolder.ToUpper().Equals("%CREATEDFOLDER%"))
                {
                    JobTask.SourceFolder = LastFolder;
                }
                if (JobTask.DestinationFolder.ToUpper().Equals("%CREATEDFOLDER%"))
                {
                    JobTask.DestinationFolder = LastFolder;
                }
            }

            if (JobTask.SourceFolder.Contains("%"))
            {
                JobTask.SourceFolder = ReplaceDelimiters(JobTask.SourceFolder);
            }
            if (JobTask.DestinationFolder.Contains("%"))
            {
                JobTask.DestinationFolder = ReplaceDelimiters(JobTask.DestinationFolder);
            }
                       
            if (!Directory.Exists(JobTask.SourceFolder))
            {
                throw new Exception("FTMS Task " + JobTask.TaskName + " : Source folder does not exist or cannot be accessed by FTMS." +

                    " The task will be aborted.");
            }
            if (string.IsNullOrEmpty(JobTask.SourceMask))
            {
                throw new Exception("Source mask is not configured.");
            }
        }
        public override List<string> ExecuteTask()
        {
            ProcessedFiles = new List<string> { };
            if (!Directory.Exists(JobTask.SourceFolder))
            {
                throw new Exception("FTMS Task " + JobTask.TaskName + ": Source folder does not exist or cannot be accessed by FTMS." +
                   " The task will be aborted.");
            }

            List<string> matchingfiles = GetMatchingFiles();
            if (matchingfiles.Count > 0)
            {
                try
                {
                    if (!Directory.Exists(JobTask.DestinationFolder))
                    {
                        Logger.LogInformation("Creating folder " + JobTask.DestinationFolder);
                        Directory.CreateDirectory(JobTask.DestinationFolder);
                    }
                    switch (JobTask.TaskTypeName.ToUpper())
                    {
                        case "COPY":
                            CopyFile(matchingfiles);
                            break;
                        case "MOVE":
                            MoveFile(matchingfiles);
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogError("Cannot copy or move file because error " + ex.Message + " occurred.");
                    throw new Exception("FTMS Task " + JobTask.TaskName + ": Source or destination folder does not exist or cannot be accessed by FTMS." +
                       " The task will be aborted.   The error was: " + ex.Message);
                }
            }
            if (Warnings.Count > 0)
            {
                SendWarnings();
            }
            return ProcessedFiles;
        }
        private void MoveFile(List<string> filesToMove)
        {
            foreach (string fileToMove in filesToMove)
            {
                try
                {
                    string newpathName = JobTask.DestinationFolder + "\\" + Path.GetFileName(fileToMove);
                    if (File.Exists(newpathName))
                    {
                        File.Delete(newpathName);
                    }
                    File.Move(fileToMove, newpathName);
                    LogFileTransfer(newpathName);
               
                    ProcessedFiles.Add(newpathName);
                }
                catch (Exception ex)
                {
                    string s = ex.GetType().Name;
                    throw new Exception("Task " + JobTask.TaskName + " failed moving file " + fileToMove +
                        " to " + JobTask.DestinationFolder + "\\" + Path.GetFileName(fileToMove) +
                        "  because " + ex.Message);
                }
            }
        }
        private void CopyFile(List<string> filesToCopy)
        {
            foreach (string fileToCopy in filesToCopy)
            {
                try
                {
                    string newpathName = JobTask.DestinationFolder + "\\" + Path.GetFileName(fileToCopy);
                    File.Copy(fileToCopy, newpathName, true);  
                    LogFileTransfer(newpathName);
                    ProcessedFiles.Add(fileToCopy);
                }
                catch (Exception ex)
                {
                    string s = ex.GetType().Name;
                    throw new Exception("Task " + JobTask.TaskName + " failed copying file " + fileToCopy +
                        " to " + JobTask.DestinationFolder + "\\" + Path.GetFileName(fileToCopy) +
                        "  because " + ex.Message);
                }

            }
        }
    }
}
