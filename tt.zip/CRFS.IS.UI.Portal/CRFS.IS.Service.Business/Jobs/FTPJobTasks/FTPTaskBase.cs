﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Util;
using CRFS.IS.Service.Data;

namespace CRFS.IS.Service.Business.Jobs.FTPJobTasks
{
    public abstract class FTPTaskBase
    {
        public static readonly string WarningMessage = "{0} Generated the following warnings at {1}<br>"; 
        private int _taskId;
        public FTPJobTask JobTask { get; set; }
        public List<string> ProcessedFiles { get; set; }
        public List<string> Warnings = new List<string> { };
        public List<FTPTaskEmailRecipient> Recipients { get; set; }

        private string[] masks;
       
        public ILogger Logger { get; set; }
        public Models.SchItem Item { get; set; }
        public AppSettings Setting { get; set; }
        
        public FTPTaskBase(int taskid, Models.SchItem item, ILogger logger, AppSettings setting)
        {
            Item = item;
            Logger = logger;
            Setting = setting;
            _taskId = taskid;
            Recipients = new List<FTPTaskEmailRecipient>();
            ProcessedFiles = new List<string>();
            Warnings = new List<string>();
        }
        public void Init()
        {
            using (var appctx = new ApplicationConfigurationContext())
            {
                JobTask = appctx.LkpFtmsJobTasks.Where(x => x.TaskId == _taskId)
                    .Select(x => new FTPJobTask {
                        DestinationFolder = x.DestinationFolder.GetSafeString(),
                        FTPDeleteAfterPut = x.FtpdeleteAfterPut ? 1 : 0,
                        FTPRemoveFolder = x.FtpremoveFolder ?? false ? 1 : 0,
                        SourceFolder = x.SourceFolder.GetSafeString(),
                        JobId = x.JobId,
                        JobTaskPriority = x.JobTaskPriority,
                        RenamePrefix = x.RenamePrefix.GetSafeString(),
                        RenameSuffix = x.RenameSuffix.GetSafeString(),
                        SourceMask = x.SourceMask.GetSafeString(),
                        TaskEnabled = x.TaskEnabled ? 1 : 0,
                        TaskId = x.TaskId,
                        TaskName = x.TaskName,
                        TaskTypeId = x.TaskTypeId,
                        ZipFileName = x.ZipFileName.GetSafeString(),
                        TaskTypeName = x.TaskType.TaskType
                    }).Single();

                Recipients = (from a in appctx.XrefFtmsTaskEmailRecipients
                              join b in appctx.LkpFtmsEmailRecipients
                              on a.RecipientId equals b.RecipientId
                              where (b.Active ?? false) && a.TaskId == _taskId
                              select new FTPTaskEmailRecipient { 
                                  Id = 0,
                                  EmailAddress = b.EmailAddress,
                                  JobId = a.JobId,
                                  MessageType = a.MessageType.GetSafeString(),
                                  RecipientId = a.RecipientId,
                                  RecipientType = a.RecipientType,
                                  TaskId = 0
                              }).ToList();
            }
        }
        public void LogFileTransfers(List<string> tranferredFiles)
        {
            foreach (string f in tranferredFiles)
            {
                LogFileTransfer(f);
            }
        }
        public void SendWarnings()
        {
            if (Warnings.Count > 0)
            {
                var msg = new StringBuilder();
                msg.Append(String.Format(WarningMessage, JobTask.TaskName, DateTime.Now.ToString()));
                 
                foreach (string w in Warnings)
                {
                    msg.Append(w);
                    msg.Append("<br>");
                }
                var sendto = Recipients.Where(x => x.MessageType == "Warning").Select(x => x.EmailAddress).ToList();
                Email.SendMail(string.Join(",", sendto.ToArray()), 
                    string.Format("FTMS Job  {0} Failed execution", JobTask.TaskName), 
                    msg.ToString(), Setting.MailServer);
            }
        }
        public abstract List<string> ExecuteTask();
       
        public List<string> GetMatchingFiles()
        {
            try
            {
                List<string> MatchingFiles = new List<string> { };
                masks = JobTask.SourceMask.Split(';');
                
                foreach (string mask in masks)
                {
                    MatchingFiles = Directory.GetFiles(JobTask.SourceFolder, mask).ToList<string>();
                }
                return MatchingFiles;
            }
            catch (IOException ex)
            {
                throw new Exception("FTMS Task Configuration error for task " + JobTask.TaskName +
                    " : Unable to access the specified source folder. Either the folder " +
                    "does not exist or the FTMS Service account does not have access to it." + ex.Message);
            }
        }

        protected void LogFileTransfer(string filename)
        {
            try
            {
                using (var dactx = new DataAutomationContext())
                {

                    if (filename.Contains("'"))
                    {
                        filename = filename.Replace("'", "''");
                    }
                    filename = Path.GetFileName(filename);
                    dactx.LogFtmsFileTransferLog.Add(new LogFtmsFileTransferLog { 
                        FtmstaskId = JobTask.TaskId,
                        TransferFileName = filename,
                        TransferType = JobTask.TaskTypeName
                    });
                    dactx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Warnings.Add("File transfer file logging failed for file : " + filename + ex.Message +
                    "<br>The details are: " + ex.StackTrace);
            }
            return;
        }

        public string ReplaceDelimiters(string str)
        {
            while (1 == 1)
            {
                int freq = str.Count(f => (f == '%'));
                if ((freq % 2) != 0)
                {
                    throw new Exception("Mismatched delimiters in folder format string in Task " + JobTask.TaskTypeName);
                }

                string toReplace = Regex.Match(str, @"\%([^%]+)\%").Groups[1].Value;
                if (!IsTimeStampModifierValid(toReplace))
                {
                    throw new Exception("Invalid time stamp modifier configured for " + JobTask.TaskName);
                }
                str = str.Replace("%" + toReplace + "%", DateTime.Now.ToString(toReplace));
                if (!str.Contains("%"))
                    break;
            }

            return str;
        }

        public bool IsDirectoryEmpty(string path)
        {
            return !Directory.EnumerateFileSystemEntries(path).Any();
        }

        private bool IsTimeStampModifierValid(string modifier)
        {
            if (!string.IsNullOrEmpty(modifier))
            {
                bool _valid;
                string test;
                try
                {
                    test = DateTime.Now.ToString(modifier);
                    _valid = true;
                }
                catch (FormatException)
                {
                    _valid = false;
                }
                return _valid;
            }
            else
                return true;

        }
    }
}
