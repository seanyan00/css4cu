﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

using Renci.SshNet;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Util;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.Security;

namespace CRFS.IS.Service.Business.Jobs.FTPJobTasks
{
    public class FTPRenameJobTask : FTPTaskBase
    {
        public const string NAMEDELIMITER = " ";
        public FTPRenameJobTask(int taskid, Models.SchItem item, ILogger logger, AppSettings setting) : base(taskid, item, logger, setting)
        {
            Init();
        }
        new public void Init()
        {
            base.Init();
                   
            if (string.IsNullOrEmpty(JobTask.SourceFolder))
            {
                throw new Exception("Invalid source folder configured for Rename task " + JobTask.TaskName);
            }
            if (string.IsNullOrEmpty(JobTask.SourceMask))
            {
                throw new Exception("Invalid source mask configured for Rename task " + JobTask.TaskName);
            }
            if (string.IsNullOrEmpty(JobTask.RenameSuffix) && string.IsNullOrEmpty(JobTask.RenamePrefix))
            {
                throw new Exception("No prefix or suffix is specified for Rename task " + JobTask.TaskName);
            }
        }
        public override List<string> ExecuteTask()
        {
            ProcessedFiles = new List<string> { };
            if (!Directory.Exists(JobTask.SourceFolder))
            {
                throw new Exception("Source folder does not exist or cannot be accessed by FTMS." +
                    " The task will be aborted.");
            }

            List<string> matchingfiles = GetMatchingFiles();
            foreach (string fileName in matchingfiles)
            {
                var newFileName = new StringBuilder();
                 
                string baseName = Path.GetFileNameWithoutExtension(Path.GetFileName(fileName).ToString());
                if (!string.IsNullOrEmpty(JobTask.RenameLeadingSuppresion))
                {
                    baseName = baseName.TrimStart(JobTask.RenameLeadingSuppresion.ToCharArray());
                }
                string extention = Path.GetExtension(Path.GetFileName(fileName).ToString());
                if (!String.IsNullOrEmpty(JobTask.RenamePrefix))
                {
                    if (JobTask.RenamePrefix.Contains("%"))
                    {
                        JobTask.RenamePrefix = ReplaceDelimiters(JobTask.RenamePrefix);
                    }
                }
                if (!String.IsNullOrEmpty(JobTask.RenameSuffix))
                {
                    if (JobTask.RenameSuffix.Contains("%"))
                    {
                        JobTask.RenameSuffix = ReplaceDelimiters(JobTask.RenameSuffix);
                    }
                }

                newFileName.Append(string.IsNullOrEmpty(JobTask.RenamePrefix) ? "" : (baseName.StartsWith(JobTask.RenamePrefix) ? "" : (JobTask.RenamePrefix + NAMEDELIMITER)));
                newFileName.Append(baseName);
                newFileName.Append(string.IsNullOrEmpty(JobTask.RenameSuffix) ? "" : (baseName.EndsWith(JobTask.RenameSuffix) ? "" : (NAMEDELIMITER + JobTask.RenameSuffix)));
                newFileName.Append(extention);

                try
                {
                    File.Move(fileName, JobTask.SourceFolder + "\\" + newFileName);
                    ProcessedFiles.Add(newFileName.ToString());
                }
                catch (Exception ex)
                {
                    throw new Exception("Error occurred in FTMS Task " + JobTask.TaskName + "for file " +
                        newFileName + ". The error was " + ex.Message);
                }
            }
            return ProcessedFiles;
        }
    }
}
