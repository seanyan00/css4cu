﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

using Renci.SshNet;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Util;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.Security;

namespace CRFS.IS.Service.Business.Jobs.FTPJobTasks
{
    public class FTPZipJobTask : FTPTaskBase
    {
        public string LastFolder { get; set; }
        public FTPZipJobTask(int taskid, Models.SchItem item, ILogger logger, AppSettings settings, string lastfolder) : base(taskid, item, logger, settings)
        {
            LastFolder = lastfolder;
            Init();
        }
        new public void Init()
        {
            base.Init();

            try
            {
                if (!string.IsNullOrEmpty(LastFolder))
                {
                    if (JobTask.SourceFolder.ToUpper().Equals("%CREATEDFOLDER%"))
                    {
                        JobTask.SourceFolder = LastFolder;
                    }
                    if (JobTask.DestinationFolder.ToUpper().Equals("%CREATEDFOLDER%"))
                    {
                        JobTask.DestinationFolder = LastFolder;
                    }
                }

                if (JobTask.TaskTypeName == "ZIP" && string.IsNullOrEmpty(JobTask.ZipFileName))
                {
                    throw new Exception("FTMS Task " + JobTask.TaskId.ToString() + " " + JobTask.TaskName +
                        " has a configuration error. Unable to retrieve the task properties.");
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Unable to retrieve properties for task ID " + JobTask.TaskId.ToString() + " " + JobTask.TaskName +
                    ". Job will be aborted. The error was: " +
                    ex.Message);
            }
        }
        public override List<string> ExecuteTask()
        {
            ProcessedFiles = new List<string> { };
           
            List<string> matchingfiles = GetMatchingFiles();

            switch (JobTask.TaskTypeName.ToUpper())
            {
                case "UNZIP":
                    foreach (string file in matchingfiles)
                    {
                        Logger.LogInformation("Unzipping source file " + file);
                        ProcessedFiles = UnZipFiles(file, JobTask.DestinationFolder);
                    }

                    break;
                case "ZIP":
                    if (matchingfiles.Count > 0)
                    {
                        ProcessedFiles = ZipFiles(matchingfiles);
                        Logger.LogInformation("Zipped archive " + JobTask.DestinationFolder + "\\" + JobTask.ZipFileName + " created.");
                    }
                    break;
            }

            return ProcessedFiles;

        }
        private List<string> UnZipFiles(string ZippedFileName, string extractPath)
        {
            try
            {
                ProcessedFiles = new List<string> { };
                using (var archive = ZipFile.OpenRead(ZippedFileName))
                {
                    foreach (ZipArchiveEntry entry in archive.Entries)
                    {
                        ProcessedFiles.Add(entry.FullName);
                        if (File.Exists(extractPath + "\\" + entry.FullName))
                        {
                            Warnings.Add("File " + extractPath + "\\" + entry.FullName + "already exists.");
                        }
                    }
                }
                if (Warnings.Count > 0)
                {
                    SendWarnings();
                    throw new Exception("Could not unzip file because one or more files already exist in the destination folder.");
                }
               
                ZipFile.ExtractToDirectory(ZippedFileName, extractPath);
                return ProcessedFiles;
            }
            catch (System.IO.InvalidDataException ex)
            {
                throw new Exception("Unzip failed extracting file " + ZippedFileName + "  because it is not a valid ZIP file or is corrupt. (" +
                  ex.Message + ")");
            }

            catch (System.IO.IOException ex)
            {
                throw new Exception("Unzip failed extracting file " + ZippedFileName + " for the reason " +
                    ex.Message);
            }

        }
        private List<String> ZipFiles(List<string> files)
        {
            ProcessedFiles = new List<string> { };
            string workDirectory = JobTask.SourceFolder + "\\Zipsrc";
            Directory.CreateDirectory(workDirectory);
          
            foreach (string f in files)
            {
                string fileName = Path.GetFileName(f);
                File.Copy(Path.Combine(JobTask.SourceFolder + "\\", fileName), workDirectory + "\\" + fileName, true);
                ProcessedFiles.Add(f);
            }
            if (JobTask.ZipFileName.Contains("%"))
            {
                JobTask.ZipFileName = ReplaceDelimiters(JobTask.ZipFileName);
            }
            if (File.Exists(JobTask.ZipFileName))
            {
                File.Delete(JobTask.ZipFileName);
            }
            ZipFile.CreateFromDirectory(workDirectory, JobTask.DestinationFolder + "\\" + JobTask.ZipFileName);
        //    LogFileTransfers(ProcessedFiles);
            Directory.Delete(workDirectory, true); 
            return ProcessedFiles;
        }

    }
}
