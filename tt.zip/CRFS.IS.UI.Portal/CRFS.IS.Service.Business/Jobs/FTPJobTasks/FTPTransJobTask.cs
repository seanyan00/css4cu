﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

using Renci.SshNet;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Util;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.Security;

namespace CRFS.IS.Service.Business.Jobs.FTPJobTasks
{
    public class FTPTransJobTask : FTPTaskBase
    {
        public FTPClientSite ClientSite { get; set; }
        public SftpClient SFTPClient { get; set; }
        public FTPTransJobTask(int taskid, Models.SchItem item, ILogger logger, AppSettings setting) : base(taskid, item, logger, setting){
            Init();
        }
        new public void Init()
        {
            base.Init();
          
            if (JobTask.SourceFolder.Contains("%"))
            {
                JobTask.SourceFolder = ReplaceDelimiters(JobTask.SourceFolder);
            }
            if (JobTask.DestinationFolder.Contains("%"))
            {
                JobTask.DestinationFolder = ReplaceDelimiters(JobTask.DestinationFolder);
            }
            try
            {
                using(var appctx = new ApplicationConfigurationContext())
                {
                    ClientSite = appctx.LkpClientFtpsites.ToList().Where(x => x.ClientId == Item.ClientId && x.Active).Select(x => new FTPClientSite
                    {
                        Id = x.FtpsiteId,
                        Active = 1,
                        ClientId = x.ClientId,
                        Password = PasswordSecurity.Decrypt(x.Password, true),
                        Port = x.Port ?? 0,
                        SFTPSiteURL = x.SftpsiteUrl,
                        UserId = x.UserId
                    }).Single();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Unable to retrieve FTP properties for the job. Job will be aborted. The error was: " +
                    ex.Message);
            }
        }
        public override List<string> ExecuteTask()
        {
            try
            {
                using(SFTPClient = new SftpClient(ClientSite.SFTPSiteURL, ClientSite.Port == 0 ? 22 : ClientSite.Port, ClientSite.UserId, ClientSite.Password))
                {
#if !DEBUG
                    SFTPClient.Connect();
#endif

                    switch (JobTask.TaskTypeName.ToUpper())
                    {
                        case "FTPGET":
#if DEBUG
                            ProcessedFiles = Directory.GetFiles(JobTask.SourceFolder).ToList();
#else
                            ProcessedFiles = DownloadMatchingRemoteFiles
#endif
                            if (ProcessedFiles.Count() > 0)
                            {
                                Logger.LogDebug("One or more files were downloaded from the FTP site.");
                            }
                            break;
                        case "FTPPUT":
                            List<string> matchingfiles = GetMatchingFiles();
                            if (matchingfiles.Count > 0)
                            {
#if DEBUG
                                ProcessedFiles = matchingfiles;
#else
                                ProcessedFiles = UploadMatchingRemoteFiles(matchingfiles);
#endif
                                if (ProcessedFiles.Count() > 0)
                                {
                                    Logger.LogDebug("One or more files were uploaded to the FTP site.");
                                }
                            }
                            else
                            {
                                ProcessedFiles = matchingfiles;
                            }
                            break;
                        default:
                            throw new Exception("Invalid task type " + JobTask.TaskTypeName);
                    }
                    SFTPClient.Disconnect();
                    SFTPClient.Dispose();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error occurred uploading or downloading files to FTP Site: " + ex.Message);
            }
            return ProcessedFiles;
        }

        private void ChangeDirectory(string folderName)
        {
            try
            {
                SFTPClient.ChangeDirectory(folderName);
            }
            catch (Exception ex)
            {
                throw new Exception("Unable to change to specified folder. " + ex.Message);
            }
        }
        private bool FitsMask(string fileName, string fileMask)
        {
            Regex mask = new Regex(
                '^' +
                fileMask
                    .Replace(".", "[.]")
                    .Replace("*", ".*")
                    .Replace("?", ".")
                + '$',
                RegexOptions.IgnoreCase);
            return mask.IsMatch(fileName);
        }
        //return true if the file name matches one of the defined masks for this job.
        private bool FitsOneOfSourceMasks(string fileName)
        {
            return JobTask.SourceMask.Split(new string[] { "\r\n", "\n", ",", "|", " ", ";" },
                StringSplitOptions.RemoveEmptyEntries)
                .Any(fileMask => FitsMask(fileName, fileMask));
        }

        private List<string> DownloadMatchingRemoteFiles()
        {
            List<string> remoteFileNames = new List<String>();

            ListDirectory(SFTPClient, JobTask.SourceFolder, ref remoteFileNames);
            List<string> matchingFiles = new List<string> { };
            foreach (string remoteFileName in remoteFileNames)
            {
                if (FitsOneOfSourceMasks(remoteFileName))
                {
                    string localFileName = DownloadFile(remoteFileName);
                    matchingFiles.Add(localFileName);

                }
            }
            try
            {
                ChangeDirectory(JobTask.SourceFolder);
                if (JobTask.FTPRemoveFolder == 1)
                {
                    SFTPClient.DeleteDirectory(JobTask.SourceFolder);
                }
            }
            catch (Exception ex)
            {
                this.Warnings.Add("Unable to remove remote folder " + JobTask.SourceFolder + " on site " + ClientSite.SFTPSiteURL +
                    "because an error occured when attempting to remove it: " + ex.Message);
            }
            return matchingFiles;
        }

        //download the file into this task's Destination Directory.
        private string DownloadFile(string remoteFileName)
        {

            try
            {
                string fileName = remoteFileName.Substring(remoteFileName.LastIndexOf('/') + 1);
                string foldername = remoteFileName.Replace(fileName, "");
              
                ChangeDirectory(foldername);
                string destinationFileName = JobTask.DestinationFolder + "\\" + fileName;
                using (Stream fileStream = File.OpenWrite(destinationFileName))
                {
                    SFTPClient.DownloadFile(fileName, fileStream);
                    DeleteFile(fileName);
                    LogFileTransfer(fileName);
                }
                //return the local file name complete path
                return destinationFileName;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.GetType().Name + " error occurred attempting to down load file " + remoteFileName +
                    " from site " + ClientSite.SFTPSiteURL + ". The error was: " + ex.Message
                    + ex.GetType().Name + "  exception has been caught " + ex.ToString());
            }
        }
        private void DeleteFile(string fileName)
        {
            try
            {
                SFTPClient.DeleteFile(fileName);
            }
            catch (Exception ex)
            {
                throw new Exception("Could not delete remote file " + fileName + " after downloading it from the FTP Server." +
                    "  The error message was :" + ex.Message);
            }
        }

        private void ListDirectory(SftpClient client, String dirName, ref List<String> files)
        {
            if (JobTask.FTPRemoveFolder == 1 && !(client.Exists(dirName)))
            {
                return; 
            }
            foreach (var entry in client.ListDirectory(dirName))
            {
                if (entry.Name.StartsWith(".")) { continue; }
              
                if (entry.IsDirectory)
                {
                    ListDirectory(client, entry.FullName, ref files);
                }
                else
                {
                    files.Add(entry.FullName);
                }
            }
        }
        private List<string> UploadMatchingRemoteFiles(List<string> matchingfiles)
        {
            List<string> ProcessedFiles = new List<string> { };
            foreach (string fileName in matchingfiles)
            {
                UploadFile(fileName);
              
                LogFileTransfer(fileName);
                if (Path.GetExtension(fileName).ToUpper() == "ZIP")
                {
                    var arch = ZipFile.OpenRead(fileName);
                    LogFileTransfers(arch.Entries.Select(x => x.FullName).ToList());
                }
                if (JobTask.FTPDeleteAfterPut == 1)
                {
                   File.Delete(fileName);
                }
                ProcessedFiles.Add(fileName);
            }
            return ProcessedFiles;
        }
        private void UploadFile(string fileName)
        {
            try
            {
                ChangeDirectory(JobTask.DestinationFolder);
                using (Stream fileStream = new FileStream(fileName, FileMode.Open))
                {
                    SFTPClient.BufferSize = 4 * 1024;
                    string remoteName = Path.GetFileName(fileName);
                    SFTPClient.UploadFile(fileStream, remoteName, null);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.GetType().Name + " error occurred attempting to down load file " + fileName +
                    " from site " + ClientSite.SFTPSiteURL + ". The error was: " + ex.Message
                    + ex.GetType().Name + "  exception has been caught " + ex.ToString());
            }

        }
    }
}
