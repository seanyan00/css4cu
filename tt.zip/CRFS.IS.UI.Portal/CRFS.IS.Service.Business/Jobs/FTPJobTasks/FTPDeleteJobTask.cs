﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

using Renci.SshNet;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Util;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.Security;
namespace CRFS.IS.Service.Business.Jobs.FTPJobTasks
{
    public class FTPDeleteJobTask : FTPTaskBase
    {
        public FTPDeleteJobTask(int taskid, Models.SchItem item, ILogger logger, AppSettings setting) : base(taskid, item, logger, setting)
        {
            Init();
        }
        new public void Init()
        {
            base.Init();
        }
        public override List<string> ExecuteTask()
        {
            ProcessedFiles = new List<string> { };
            if (!Directory.Exists(JobTask.SourceFolder))
            {
                throw new Exception("Source folder does not exist or cannot be accessed by FTMS." +
                    " The task will be aborted.");
            }
            List<string> matchingfiles = GetMatchingFiles();
            if (matchingfiles.Count() > 0)
            {
                Logger.LogInformation("One or more files removed in the delete directory.");
            }
            try
            {
                foreach (string fileName in matchingfiles)
                {
                    File.Delete(fileName);
                    ProcessedFiles.Add(fileName);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error occurred in FTMS Task " + JobTask.TaskName + ". The error was " + ex.Message);
            }
            return ProcessedFiles;
        }
    }
}
