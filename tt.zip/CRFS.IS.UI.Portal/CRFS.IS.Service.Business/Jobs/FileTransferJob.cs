﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using System.Reflection;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Linq;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;

using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Util;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.Common;
using CRFS.IS.Service.Business.Models;
using CRFS.IS.Service.Business.Jobs.FTPJobTasks;

namespace CRFS.IS.Service.Business.Jobs
{
    public class FileTransferJob : JobBase
    {
        public FTPJob Ftpjob { get; set; }
        public List<string> LastFilesProcessed { get; set; }
        public string LastFolderCreated { get; set; }
        public List<FTPTaskEmailRecipient> JobRecipients { get; set; }
        public List<FTPJobTask> Tasks { get; set; }
        public int StatusId = 0;

        public FileTransferJob(SchItem schitem, ILogger logger, AppSettings appsetting) : base(schitem, logger, appsetting)
        {
            Init();
        }
        public override void Init()
        {
            using (var appctx = new ApplicationConfigurationContext())
            {
                var tempid = Convert.ToInt32(Item.ClassName);

                Ftpjob = appctx.LkpFtmsJobs.ToList().Where(x => x.JobId == tempid && x.JobEnabled).Select(x => new FTPJob
                {
                    ClientId = x.ClientId,
                    Cron = "",
                    Id = x.JobId,
                    JobEnabled = x.JobEnabled ? 1 : 0,
                    JobName = x.JobName,
                    Params = Item.Params.GetSafeString()
                }).SingleOrDefault();
                if (Ftpjob != null)
                {
                    Tasks = appctx.LkpFtmsJobTasks.Where(x => x.JobId == Ftpjob.Id && x.TaskEnabled)
                        .Select(x => new FTPJobTask
                        {
                            DestinationFolder = x.DestinationFolder.GetSafeString(),
                            FTPDeleteAfterPut = x.FtpdeleteAfterPut ? 1 : 0,
                            FTPRemoveFolder = x.FtpremoveFolder ?? false ? 1 : 0,
                            SourceFolder = x.SourceFolder.GetSafeString(),
                            JobId = x.JobId,
                            JobTaskPriority = x.JobTaskPriority,
                            RenamePrefix = x.RenamePrefix.GetSafeString(),
                            RenameSuffix = x.RenameSuffix.GetSafeString(),
                            SourceMask = x.SourceMask.GetSafeString(),
                            TaskEnabled = x.TaskEnabled ? 1 : 0,
                            TaskId = x.TaskId,
                            TaskName = x.TaskName,
                            TaskTypeId = x.TaskTypeId,
                            ZipFileName = x.ZipFileName.GetSafeString(),
                            TaskTypeName = x.TaskType.TaskType
                        }).OrderBy(x => x.JobTaskPriority).ToList();

                    JobRecipients = (from a in appctx.XrefFtmsTaskEmailRecipients
                                     join b in appctx.LkpFtmsEmailRecipients
                                     on a.RecipientId equals b.RecipientId
                                     where (b.Active ?? false) && a.JobId == Ftpjob.Id && a.TaskId == null
                                     select new FTPTaskEmailRecipient
                                     {
                                         Id = 0,
                                         EmailAddress = b.EmailAddress,
                                         JobId = a.JobId,
                                         MessageType = a.MessageType.GetSafeString(),
                                         RecipientId = a.RecipientId,
                                         RecipientType = a.RecipientType,
                                         TaskId = 0
                                     }).ToList();
                }
            }
        }
        public override string DoJob(RunReportRequest req, int userid = 0, string runby = "Scheduler")
        {
            throw new NotImplementedException();
        }
        public override string DoJob(int userid = 0, string runby = "Scheduler")
        {
            var ret = Constant.Success;
            var status = new TblScheduledJobStatus
            {
                Id = 0,
                JobId = Item.Id,
                RunBy = runby,
                TimeStart = DateTime.Now,
                Message = "",
                Status = "Started"
            };
          
            try {  
                StatusId = JobStatusHelper.SaveStatus(status);
                if(Ftpjob == null)
                {
                    Logger.LogWarning("No active job found for name " + Ftpjob.JobName);
                    return Constant.Failed;
                }
                Logger.LogInformation("Getting tasks for job " + Ftpjob.JobName);
                
                foreach (var task in Tasks)
                {
                    Logger.LogInformation("Processing Task " + task.TaskName.ToString() + "/Priority " + task.JobTaskPriority.ToString());
                    switch (task.TaskTypeName.ToUpper())
                    {
                        case "FTPGET":
                        case "FTPPUT":
                            FTPTransJobTask ftp = new FTPTransJobTask(task.TaskId, Item, Logger, Setting);
                            LastFilesProcessed = ftp.ExecuteTask();
                            break;
                        case "EMAIL":
                            var emt = new FTPEmailJobTask(task.TaskId, Item, Logger, Setting, LastFilesProcessed, JobRecipients);
                            emt.ExecuteTask();
                            break;
                        case "ZIP":
                            var zip = new FTPZipJobTask(task.TaskId, Item, Logger, Setting, LastFolderCreated);

                            LastFilesProcessed = zip.ExecuteTask();
                            break;
                        case "UNZIP":
                            var unzip = new FTPZipJobTask(task.TaskId, Item,  Logger, Setting, LastFolderCreated);
                          
                            unzip.Recipients = JobRecipients;
                            LastFilesProcessed = unzip.ExecuteTask();
                            break;
                        case "COPY":
                            var copyTask = new FTPCopyMoveJobTask(task.TaskId, Item, Logger, Setting, LastFolderCreated);
                            LastFilesProcessed = copyTask.ExecuteTask();
                            break;
                        case "MOVE":
                            var moveTask = new FTPCopyMoveJobTask(task.TaskId, Item, Logger, Setting, LastFolderCreated);
                            LastFilesProcessed = moveTask.ExecuteTask();
                            break;
                        case "RENAME":
                            var rt = new FTPRenameJobTask(task.TaskId, Item, Logger, Setting);
                            LastFilesProcessed = rt.ExecuteTask();
                            break;
                        case "DELETE":
                            var dt = new FTPDeleteJobTask(task.TaskId, Item, Logger, Setting);
                            LastFilesProcessed = dt.ExecuteTask();
                            break;

                        case "DELETEFOLDER":
                            var df = new FTPDeleteFolderJobTask(task.TaskId, Item, Logger, Setting);
                            df.ExecuteTask();
                            break;
                        default:
                            throw new Exception("Invalid task type " + task.TaskTypeName + " encountered for FTMS Job " + Ftpjob.JobName);
                    }
                }
            }
            catch (Exception ex)
            {
                JobStatusHelper.UpdateStatus(StatusId, "Error", (DateTime?)null, ex.Message);
                Logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret = ex.Message;
            }
            return ret;
        }
    }
}