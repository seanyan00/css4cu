﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Logging;

using CRFS.IS.Service.Common;

namespace CRFS.IS.Service.Business.Jobs
{
    public abstract class JobBase
    {
        public ILogger Logger { get; set; }
        public Models.SchItem Item { get; set; }
        public AppSettings Setting { get; set; }
        public JobBase(Models.SchItem item, ILogger logger, AppSettings setting)
        {
            Item = item;
            Logger = logger;
            Setting = setting;
        }
        public abstract string DoJob(int userid = 0, string runby = "Scheduler");
        public abstract void Init();
    }
}
