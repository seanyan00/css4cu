﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using System.Reflection;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Linq;
using System.Text.Json;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;

using CRFS.IS.Service.Util;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.Data.DAOs;
using CRFS.IS.Service.Data.Extensions;
using CRFS.IS.Service.Common;
using CRFS.IS.Service.Business.Models;
using CRFS.IS.Service.GRpc;

namespace CRFS.IS.Service.Business.Jobs
{
    public static class JobCommonHelper
    {
        public static bool IsHoliday(this DateTime d, string org = "CRFS")
        {
            using(var appctx = new ApplicationConfigurationContext())
            {
                var hds = appctx.LkpOrganizationHoliday.Where(x => x.Organization == org).ToList();
                foreach(var t in hds)
                {
                    if (t.HolidayDate.Year == d.Year && t.HolidayDate.Month == d.Month && t.HolidayDate.Day == d.Day)
                        return true;
                }
            }
            return false;
        }
    }
}
