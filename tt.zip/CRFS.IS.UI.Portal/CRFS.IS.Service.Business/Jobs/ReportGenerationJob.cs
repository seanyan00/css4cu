﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using System.Reflection;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Linq;
using System.Text.Json;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;

using NPOI;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using NPOI.HSSF.UserModel;

using iText.Kernel.Pdf;
//using iText.Kernel.Geom;
using iText.Kernel.Font;
using iText.Kernel.Events;
using iText.Kernel.Pdf.Xobject;
using iText.Kernel.Pdf.Canvas;
using iText.Kernel.Pdf.Canvas.Draw;
using iText.Kernel.Colors;
using iText.Layout;
using iText.Layout.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;
using iText.Layout.Renderer;
using iText.Layout.Borders;
using iText.Layout.Font;

using iText.IO;
using iText.IO.Font.Otf;
using iText.IO.Util;
using iText.IO.Source;
using iText.IO.Image;
using iText.Forms;
using iText.Pdfa;

using CRFS.IS.Service.Util;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.Data.DAOs;
using CRFS.IS.Service.Data.Extensions;
using CRFS.IS.Service.Common;
using CRFS.IS.Service.Business.Models;
using CRFS.IS.Service.GRpc;

namespace CRFS.IS.Service.Business.Jobs
{
    public class ReportGenerationJob : JobBase
    {
        private int _userid;
        private string _targetfile = "";

        public string SendTo { get; set; }
        public string Subject { get; set; }
        public string TargetFolder { get; set; }
        public string FileName { get; set; }
        
        public List<KeyValuePair<int, string>> HColumns { get; set; }
        public VwClientReport CurrClnRpt = null;

        public ReportGenerationJob(SchItem schitem, ILogger logger, AppSettings appsetting) : base(schitem, logger, appsetting)
        {
            Init();
        }
        public override void Init()
        {
            HColumns = new List<KeyValuePair<int, string>>();
        }
        public override string DoJob(int userid = 0, string runby = "Scheduler")
        {
            var ret = Constant.Success;

            _userid = userid;

            return ret;
        }
        public override string DoJob(RunReportRequest req, int userid = 0, string runby = "Scheduler")
        {
            var ret = Constant.Success;
            IWorkbook wb = null;
            
            _userid = userid;

            object ctx = null;
            var pctx = new PortalContext();
            var rctx = new RGSContext();

            var ljparam = req.JobParameters.ToKeyValueList(";", "=");

            var ritem = rctx.VwClientReport.Where(x => x.ReportId.ToString() == Item.ClassName && (Item.ClientId == 0 || (x.ClientId == Item.ClientId))).ToList();
            string tempjparam = "";
            if(ritem.Count > 0)
                tempjparam = ritem.Select(x => x.Params).Take(1).Single();
            var jparam = tempjparam.ToKeyValueList("\r\n", "=");

            ljparam.AddRange(jparam.Where(x => !ljparam.Any(y => y.Key == x.Key)).ToList());

            InitJobParams(ljparam, ritem, null);

            var targetfile = Path.Combine(TargetFolder, FileName);

            var status = new TblScheduledJobStatus
            {
                Id = 0,
                JobId = Item.Id,
                RunBy = runby,
                TimeStart = DateTime.Now,
                Message = "",
                Status = "Started",
                FileFullPath = targetfile,
                JobParameters = "" //string.IsNullOrEmpty(req.JobParameters) ? Item.Params : req.JobParameters
            };
            JobStatusHelper.SaveStatus(status);

            try
            {
                var mode = ritem.First().FileName.GetFileExtension().ToUpper();
                if (string.IsNullOrEmpty(ritem.First().ReportTemplate))
                { 
                    wb = new XSSFWorkbook();
                } else
                {
                    wb = new XSSFWorkbook(ritem.First().ReportTemplate);
                }

                foreach (var pgid in ritem.Select(x => x.PageId).Distinct().ToList())
                {
                    CurrClnRpt = ritem.Where(x => x.PageId == pgid).First();

                    var ds = new ReportDataset
                    {
                        Id = CurrClnRpt.DatasetId,
                        SProc = CurrClnRpt.Sproc,
                        SqlStr = CurrClnRpt.SqlStr
                    };
                    
                    var dbparam = new DatasetParameter { DatasetId = ds.Id };
                    dbparam.DBParameters = ritem.Where(x => x.DatasetId == ds.Id).Select(x => new DBParameter
                    {
                        ParameterId = x.ParameterId,
                        ParamDbName = x.ParamDbName,
                        ParamReportName = x.ParamReportName,
                        DataType = x.DataType,
                        ParamDirection = x.ParamDirection,
                        ParamPivotDirection = x.ParamPivotDirection,
                        DefaultValue = x.DefaultValue,
                        IsNullable = x.Nullable,
                        ForReportName = x.ForReportName ?? 0,
                        MaxLen = x.MaxLen ?? 0,
                        Value = "",
                        Idx = x.Idx ?? 0
                    }).Distinct().ToList();

                    UpdateDatasetParameter(dbparam.DBParameters, req.ReportDatasetParameters.Where(x => x.DataSetId == ds.Id).ToList());

                    var lsqlparam = CreateSqlParameter(ds.Id, dbparam.DBParameters, CurrClnRpt);

                    switch (ds.SProc.GetContextName().ToUpper())
                    {
                        case "CLAIMSMANAGEMENT":
                            ctx = new ClaimsManagementContext();
                            break;
                        case "HUDCLAIMS":
                            ctx = new HUDClaimsContext();
                            break;
                        case "RGS":
                            ctx = new RGSContext();
                            break;
                        case "APPLICATIONCONFIGURATION":
                            ctx = new ApplicationConfigurationContext();
                            break;
                        default:
                            throw new Exception("No mapping for DbConext of Stored Procedure " + ds.SProc);
                    }

                    var rd = (SqlDataReader)new RawSqlDAO(userid, (DbContext)ctx, null).RunSproc(ds.SProc, lsqlparam);

                    switch (mode)
                    {
                        case "XLSX":
                            CreateExeclReport(wb, rd, ritem, dbparam.DBParameters);
                            break;
                        case "PDF":
                            CreatePDFReport(targetfile, rd, ritem, dbparam.DBParameters);
                            break;
                        default:
                            CreateTextReport(targetfile, rd, dbparam.DBParameters, string.IsNullOrEmpty(CurrClnRpt.Delimiter) ? "," : CurrClnRpt.Delimiter);
                            break;

                    }
                }
                if (mode == "XLSX")
                {
                    using (FileStream out1 = new FileStream(targetfile, FileMode.Create))
                    {
                        wb.Write(out1);
                    }
                }
                rctx.TblReportGeneration.Add(new TblReportGeneration
                {
                    DatasetsParameters = JsonSerializer.Serialize(req.ReportDatasetParameters),
                    Id = 0,
                    JobStatusId = status.Id
                });
                rctx.SaveChanges();
                JobStatusHelper.UpdateStatus(status.Id, "Complete", DateTime.Now);
            }
            catch(Exception ex)
            {
                JobStatusHelper.UpdateStatus(status.Id, "Error", DateTime.Now, ex.Message);
                throw;
            }
            finally
            {
                if (pctx != null)
                    pctx.Dispose();
                if (rctx != null)
                    rctx.Dispose();
                if (ctx != null)
                    ((DbContext)ctx).Dispose();        
                
            }
            return ret;
        }
        private void InitJobParams(List<KeyValuePair<string, string>> ljp, List<VwClientReport> lclnrpt, List<DBParameter> ldbp)
        {
            /*{Name}{Client}{RunDateTime}{Yesterday}{Parameter})*/
            SendTo = ljp.GetJobParamValue("SendTo");
            Subject = ljp.GetJobParamValue("Subject");
            if (string.IsNullOrEmpty(ljp.GetJobParamValue("Destination")))
                TargetFolder = lclnrpt.GetReportParamValue("Destination");
            else
                TargetFolder = ljp.GetJobParamValue("Destination");

            if (string.IsNullOrEmpty(ljp.GetJobParamValue("FileName")))
                FileName = lclnrpt.GetReportParamValue("FileName");
            else
                FileName = ljp.GetJobParamValue("FileName");

            if (FileName.IndexOf("{Name}") != -1)
                FileName = FileName.Replace("{Name}", lclnrpt.GetReportParamValue("ReportName"));
            if (FileName.IndexOf("{Client}") != -1)
                FileName = FileName.Replace("{Client}", lclnrpt.GetReportParamValue("ClientDisplayName"));
            if (FileName.IndexOf("{RunDateTime}") != -1)
                FileName = FileName.Replace("{RunDateTime}", DateTime.Now.ToString(Constant.DateTimeStringFlat));
            if (FileName.IndexOf("{Yesterday}") != -1)
                FileName = FileName.Replace("{Yesterday}", DateTime.Today.AddDays(-1).ToString(Constant.DateStringFlat));
            if (FileName.IndexOf("{LastWeek}") != -1)
                FileName = FileName.Replace("{LastWeek}", DateTime.Now.AddDays(-(int)DateTime.Now.DayOfWeek - 6).ToString(Constant.DateStringFlat));
            if (FileName.IndexOf("{LastMonth}") != -1)
                FileName = FileName.Replace("{LastMonth}", DateTime.Now.AddMonths(-1).ToString("Y"));
            if (FileName.IndexOf("{LastYear}") != -1)
                FileName = FileName.Replace("{LastYear}", DateTime.Now.AddYears(-1).ToString());
        }
        private void UpdateDatasetParameter(List<DBParameter> ldbp, List<ReportDatasetParameter> lrdsp)
        {
            foreach(var p in ldbp)
            {
                if(lrdsp.Any(x => x.DBName == p.ParamDbName && p.ParamDirection == "Input"))
                {
                    p.Value = lrdsp.Single(x => x.DBName == p.ParamDbName && p.ParamDirection == "Input").Value;
                }
            }
        }
        private List<SqlParameter> CreateSqlParameter(int dsid, List<DBParameter> ldbp, VwClientReport vcr)
        {
            var ret = new List<SqlParameter>();

            foreach(var p in ldbp.Where(x => x.ParamDirection == "Input").ToList())
            {
                var val = !string.IsNullOrEmpty(p.Value) ? p.Value : p.DefaultValue;

                val = GetFromBuiltIn(val, vcr);

                if(string.IsNullOrEmpty(val) && !p.IsNullable)
                {
                    throw new Exception("Dataset: " + dsid.ToString() + ", Sql Parameter " + p.ParamDbName + " is non-nullable");
                }

                Type t = p.DataType.GetSystemType();

                ret.Add(new SqlParameter(p.ParamDbName, EntityAttributeHelper.GetValue(val, t)));
            }
            return ret;
        }
        private void CreateExeclReport(IWorkbook wb, SqlDataReader rd, List<VwClientReport> lclnrpt, List<DBParameter> ldbp) 
        {
            ISheet sheet;
            if (string.IsNullOrEmpty(CurrClnRpt.ReportTemplate)) {
                sheet = wb.CreateSheet(string.IsNullOrEmpty(CurrClnRpt.PageName) ? "sheet" + CurrClnRpt.PageNum.ToString() : CurrClnRpt.PageName);
                GetHeadRowInfo(ldbp);
                IRow row = sheet.CreateRow(1);
                foreach(var c in HColumns)
                {
                    ICell cell = row.CreateCell(c.Key);
                    cell.SetCellValue(c.Value);
                }
            }
            else
            {
                if (string.IsNullOrEmpty(CurrClnRpt.PageName))
                    sheet = wb.GetSheetAt(CurrClnRpt.PageNum);
                else
                    sheet = wb.GetSheet(CurrClnRpt.PageName);

                GetHeadRowInfo(sheet);
            }
            int rownum = 0;
            while (rd.Read())
            {
                IRow row = sheet.CreateRow(++rownum);
                for(int i = 0; i < HColumns.Count; i++)
                {
                    ICell cell = row.CreateCell(i);

                    var dbp = ldbp.SingleOrDefault(x => x.ParamDirection == "Output" && ((string.IsNullOrEmpty(x.ParamReportName) && x.ParamDbName.ToUpper().Trim() == HColumns[i].Value.ToUpper().Trim())
                                                || x.ParamReportName.ToUpper().Trim() == HColumns[i].Value.ToUpper().Trim()));
                    if (dbp != null)
                    {
                        var oval = rd.GetValue(rd.GetOrdinal(dbp.ParamDbName));
                        cell.SetCellValue(oval, dbp.DataType);
                    } else
                    {
                        var str = rd.GetValue(rd.GetOrdinal(HColumns[i].Value)).ToString();
                        cell.SetCellValue(str);
                    }
                }
            }
        }
        private void GetHeadRowInfo(List<DBParameter> ldbp)
        {
            foreach(var dbp in ldbp.Where(x => x.ParamDirection == "Output").OrderBy(x => x.Idx))
            {
                HColumns.Add(new KeyValuePair<int, string>(dbp.Idx, string.IsNullOrEmpty(dbp.ParamReportName) ? dbp.ParamDbName: dbp.ParamReportName));
            }
        }
        private void GetHeadRowInfo(ISheet st)
        {
            IRow row = st.GetRow(0);

            HColumns.AddRange(row.Cells.Select(x => new KeyValuePair<int, string>(x.ColumnIndex, x.StringCellValue)).OrderBy(x => x.Key).ToList());
        }
        private void CreatePDFReport(string fnm, SqlDataReader rd, List<VwClientReport> lclnrpt, List<DBParameter> ldbp) {
            throw new NotImplementedException();
        }
        private void CreateTextReport(string fnm, SqlDataReader rd, List<DBParameter> ldbp, string dlm) 
        {
            GetHeadRowInfo(ldbp);
            var sb = new StringBuilder();
            
            using (var sw = new StreamWriter(fnm, false))
            {
                var first = true;

                foreach (var c in HColumns)
                {
                    sb.Append((!first ? dlm : "") + c.Value);
                    first = false;
                }
                sw.WriteLine(sb.ToString());

                while (rd.Read())
                {
                    first = true;
                    sb.Clear();
                    for (int i = 0; i < HColumns.Count; i++)
                    {
                        var temp = !first ? dlm : "";
                        first = false;

                        var dbp = ldbp.Single(x => x.ParamDirection == "Output" && ((string.IsNullOrEmpty(x.ParamReportName) && x.ParamDbName.ToUpper() == HColumns[i].Value.ToUpper())
                                               || x.ParamReportName.ToUpper() == HColumns[i].Value.ToUpper()));
                        var oval = rd.GetValue(rd.GetOrdinal(dbp.ParamDbName));
                        if (oval == null)
                        {
                            sb.Append(temp);
                        }
                        else
                        {
                            switch (dbp.DataType)
                            {
                                case "Date":
                                    sb.Append(temp + ((DateTime)oval).ToString(Constant.DateString));
                                    break;
                                case "DateTime":
                                    sb.Append(temp + ((DateTime)oval).ToString(Constant.DateTimeString));
                                    break;
                                default:
                                    sb.Append(temp + oval.ToString().AddDoubleQuote(dlm));
                                    break;
                            }
                        }
                    }
                    sw.WriteLine(sb.ToString());
                }
            }
        }
        private string GetFromBuiltIn(string val, VwClientReport vcr)
        {
            var temp = DateTime.Now;

            switch (val)
            {
                case "{ClientId}":
                    return vcr.ClientId.ToString();
                case "{Yesterday-Start}":
                    temp = temp.AddDays(-1);
                    temp = new DateTime(temp.Year, temp.Month, temp.Day, 0, 0, 0, 0);
                    return temp.ToString(Constant.DateTimeString);
                case "{Yesterday-End}":
                    temp = temp.AddDays(-1);
                    temp = new DateTime(temp.Year, temp.Month, temp.Day, 23, 59, 59, 999);
                    return temp.ToString(Constant.DateTimeString);
                case "{BusinessYesterday-Start}":
                    temp = temp.AddDays(-1).GetBusinessDay();
                    temp = new DateTime(temp.Year, temp.Month, temp.Day, 0, 0, 0, 0);
                    return temp.ToString(Constant.DateTimeString);
                case "{BusinessYesterday-End}":
                    temp = temp.AddDays(-1).GetBusinessDay();
                    temp = new DateTime(temp.Year, temp.Month, temp.Day, 23, 59, 59, 999);
                    return temp.ToString(Constant.DateTimeString);
                case "{SystemUser}":
                    return "Admin";
                default:
                    return val;
            }
        }
    }
}
