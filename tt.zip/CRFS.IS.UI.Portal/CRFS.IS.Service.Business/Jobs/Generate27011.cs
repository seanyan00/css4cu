﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.Data;

namespace CRFS.IS.Service.Business.Jobs
{
    public class Generate27011
    {
        string uri { get; set; }
        public Generate27011(string uri)
        {
            this.uri = uri;
        }

        public DataTable go(DataTable dt)
        {
            var binding = new BasicHttpBinding();
            int claimct = dt.DefaultView.ToTable(true, "claimid").Rows.Count;
            binding.SendTimeout = new TimeSpan(120000000L * (claimct + 20));
            var endpoint = new EndpointAddress(uri);
            var fac = new ChannelFactory<Interface_27011>(binding, endpoint);

            var cln = fac.CreateChannel();
            var ret = cln.save27011(dt);
            return ret;
        }
    }
}
