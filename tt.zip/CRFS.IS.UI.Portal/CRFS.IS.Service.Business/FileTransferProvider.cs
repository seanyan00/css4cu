﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using System.Reflection;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.Common;
using CRFS.IS.Service.Business.Jobs;
using CRFS.IS.Service.Business.Models;
using CRFS.IS.Service.Security;

namespace CRFS.IS.Service.Business
{
    public class FileTransferProvider
    {
        private IConfiguration _config;
        private ILogger _logger;
        private int _userid;

        public FileTransferProvider(IConfiguration config, ILogger logger, int uid)
        {
            _config = config;
            _logger = logger;
            _userid = uid;
        }
        public GetEmailRecipientReply GetEmailRecipient()
        {
            var ret = new GetEmailRecipientReply();
            try
            {
                using(var appctx = new ApplicationConfigurationContext())
                {
                    var temp = appctx.LkpFtmsEmailRecipients.ToList().Select(x => new FTPEmailRecipient { 
                       Id = x.RecipientId,
                       Active = (x.Active ?? false) ? 1 : 0,
                       EmailAddress = x.EmailAddress.GetSafeString(),
                       UIAct = ""
                    }).OrderBy(x => x.EmailAddress).ToList();
                    ret.FTPEmailRecipients.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public MessageReply SaveEmailRecipient(FTPEmailRecipient data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var appctx = new ApplicationConfigurationContext())
                {
                    if(data.Id > 0)
                    {
                        var temp = appctx.LkpFtmsEmailRecipients.Single(x => x.RecipientId == data.Id);
                        if(data.UIAct == "Delete")
                        {
                            appctx.LkpFtmsEmailRecipients.Remove(temp);
                        } else
                        {
                            temp.EmailAddress = data.EmailAddress;
                            temp.Active = data.Active == 1;
                            temp.UpdatedBy = _userid;
                            temp.DateUpdated = DateTime.Now;
                        }
                        appctx.SaveChanges();
                    } else
                    {
                        var temp = new LkpFtmsEmailRecipients
                        {
                            EmailAddress = data.EmailAddress,
                            Active = data.Active == 1,
                            DateEntered = DateTime.Now,
                            EnteredBy = _userid,
                            DateUpdated = DateTime.Now,
                            UpdatedBy = _userid,
                            RecipientId = 0
                        };
                        appctx.LkpFtmsEmailRecipients.Add(temp);
                        appctx.SaveChanges();
                        ret.Id = temp.RecipientId;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetEmailTaskReply GetEmailTask(int tid)
        {
            var ret = new GetEmailTaskReply();
            try
            {
                using (var appctx = new ApplicationConfigurationContext())
                {
                    var temp = appctx.LkpFtmsEmailTasks.Where(x => x.TaskId == tid).Select(x => new FTPEmailTask
                    {
                        TaskId = x.TaskId,
                        EmailFiesAsAttachments = x.EmailFilesAsAttachments ? 1 : 0,
                        IncludeFileDetailsInEmailBody = x.IncludeFileDetailsInEmailBody ? 1 :0,
                        SendIfNoFilesProcessed = x.SendIfNoFilesProcessed ? 1 : 0,
                        SendEachMatchingFileAsSeparateEmail = x.SendEachMatchingFileAsSeparateEmail ? 1 : 0,
                        EmailSubject = x.EmailSubject.GetSafeString(),
                        EmailText = x.EmailText.GetSafeString(),
                        UIAct = ""
                    }).ToList();
                    ret.FTPEmailTasks.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }

        public MessageReply SaveEmailTask(FTPEmailTask data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var appctx = new ApplicationConfigurationContext())
                {
                    if (data.UIAct == "Delete")
                    {
                        var temp = appctx.LkpFtmsEmailTasks.Single(x => x.TaskId == data.TaskId);
                        appctx.LkpFtmsEmailTasks.Remove(temp);
                    }
                    else
                    {
                        if (data.UIAct == "Edit")
                        {
                            var temp = appctx.LkpFtmsEmailTasks.Single(x => x.TaskId == data.TaskId);
                            temp.EmailText = data.EmailText;
                            temp.EmailSubject = data.EmailSubject;
                            temp.EmailFilesAsAttachments = data.EmailFiesAsAttachments == 1;
                            temp.IncludeFileDetailsInEmailBody = data.IncludeFileDetailsInEmailBody == 1;
                            temp.SendEachMatchingFileAsSeparateEmail = data.SendEachMatchingFileAsSeparateEmail == 1;
                            temp.SendIfNoFilesProcessed = data.SendIfNoFilesProcessed == 1;
                        }
                        else
                        {
                            var temp = new LkpFtmsEmailTasks
                            {
                                TaskId = data.TaskId,
                                EmailSubject = data.EmailSubject,
                                EmailText = data.EmailText,
                                EmailFilesAsAttachments = data.EmailFiesAsAttachments == 1,
                                IncludeFileDetailsInEmailBody = data.IncludeFileDetailsInEmailBody == 1,
                                SendEachMatchingFileAsSeparateEmail = data.SendEachMatchingFileAsSeparateEmail == 1,
                                SendIfNoFilesProcessed = data.SendIfNoFilesProcessed == 1
                            };
                            appctx.LkpFtmsEmailTasks.Add(temp);
                        }
                    }
                    appctx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetFTPJobReply GetFTPJob()
        {
            var ret = new GetFTPJobReply();
            try
            {
                using (var appctx = new ApplicationConfigurationContext())
                {
                    var temp = appctx.LkpFtmsJobs.Select(x => new FTPJob
                    {
                        Id = x.JobId,
                        ClientId = x.ClientId,
                        EndHour = x.EndHour.GetSafeValue(),
                        StartHour = x.StartHour.GetSafeValue(),
                        JobEnabled = x.JobEnabled ? 1 : 0,
                        JobName = x.JobName,
                        UIAct = ""
                    }).ToList();
                    ret.FTPJobs.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }

        public MessageReply SaveFTPJob(FTPJob data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var appctx = new ApplicationConfigurationContext())
                {
                    if (data.Id > 0)
                    {
                        var temp = appctx.LkpFtmsJobs.Single(x => x.JobId == data.Id);
                        if (data.UIAct == "Delete")
                        {
                            appctx.LkpFtmsJobs.Remove(temp);
                        }
                        else
                        {
                            temp.ClientId = data.ClientId;
                            temp.EndHour = data.EndHour;
                            temp.JobName = data.JobName;
                            temp.JobEnabled = data.JobEnabled == 1;
                            temp.StartHour = data.StartHour;
                        }
                        appctx.SaveChanges();
                    }
                    else
                    {
                        var temp = new LkpFtmsJobs
                        {
                            JobId = 0,
                            JobEnabled = data.JobEnabled == 1,
                            JobName = data.JobName,
                            StartHour = data.StartHour,
                            EndHour = data.EndHour,
                            ClientId = data.ClientId
                        };
                        appctx.LkpFtmsJobs.Add(temp);
                        appctx.SaveChanges();
                        ret.Id = temp.JobId;
                    }
                }

            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetFTPTaskReply GetFTPTask(int jid)
        {
            var ret = new GetFTPTaskReply();
            try
            {
                using (var appctx = new ApplicationConfigurationContext())
                {
                    var temp = appctx.LkpFtmsJobTasks.Where(x => x.JobId == jid).Select(x => new FTPJobTask
                    {
                        TaskId = x.TaskId,
                        JobId = x.JobId,
                        FTPDeleteAfterPut = x.FtpdeleteAfterPut ? 1 : 0,
                        DestinationFolder = x.DestinationFolder.GetSafeString(),
                        FTPRemoveFolder = (x.FtpremoveFolder ?? false) ? 1 : 0,
                        JobTaskPriority = x.JobTaskPriority.GetSafeValue(),
                        RenamePrefix = x.RenamePrefix.GetSafeString(),
                        RenameSuffix = x.RenameSuffix.GetSafeString(),
                        SourceFolder = x.SourceFolder.GetSafeString(),
                        SourceMask = x.SourceMask.GetSafeString(),
                        TaskEnabled = x.TaskEnabled ? 1 : 0,
                        TaskName = x.TaskName,
                        TaskTypeId = x.TaskTypeId.GetSafeValue(),
                        ZipFileName = x.ZipFileName.GetSafeString(),
                        UIAct = ""
                    }).ToList();
                    ret.FTPJobTasks.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }

        public MessageReply SaveFTPTask(FTPJobTask data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var appctx = new ApplicationConfigurationContext())
                {
                    if (data.UIAct == "Delete")
                    {
                        var temp = appctx.LkpFtmsJobTasks.Single(x => x.TaskId == data.TaskId);
                        appctx.LkpFtmsJobTasks.Remove(temp);
                    }
                    else
                    {
                        if (data.UIAct == "Edit")
                        {
                            var temp = appctx.LkpFtmsJobTasks.Single(x => x.TaskId == data.TaskId);
                            temp.RenameSuffix = data.RenameSuffix;
                            temp.JobTaskPriority = data.JobTaskPriority;
                            temp.RenamePrefix = data.RenamePrefix;
                            temp.SourceFolder = data.SourceFolder;
                            temp.SourceMask = data.SourceMask;
                            temp.TaskEnabled = data.TaskEnabled == 1;
                            temp.TaskName = data.TaskName;
                            temp.TaskTypeId = data.TaskTypeId;
                            temp.DestinationFolder = data.DestinationFolder;
                            temp.FtpdeleteAfterPut = data.FTPDeleteAfterPut == 1;
                            temp.FtpremoveFolder = data.FTPRemoveFolder == 1;
                            temp.ZipFileName = data.ZipFileName;
                            temp.JobId = data.JobId;
                        }
                        else
                        {
                            var temp = new LkpFtmsJobTasks
                            {
                                FtpdeleteAfterPut = data.FTPDeleteAfterPut == 1,
                                FtpremoveFolder = data.FTPRemoveFolder == 1,
                                DestinationFolder = data.DestinationFolder,
                                JobId = data.JobId,
                                JobTaskPriority = data.JobTaskPriority,
                                RenamePrefix = data.RenamePrefix,
                                RenameSuffix = data.RenameSuffix,
                                SourceFolder = data.SourceFolder,
                                SourceMask = data.SourceMask,
                                TaskEnabled = data.TaskEnabled == 1,
                                TaskId = data.TaskId,
                                TaskName = data.TaskName,
                                TaskTypeId = data.TaskTypeId,
                                ZipFileName = data.ZipFileName
                            };
                            appctx.LkpFtmsJobTasks.Add(temp);
                        }
                    }
                    appctx.SaveChanges();
                } 
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetFTPTaskTypeReply GetFTPTaskType()
        {
            var ret = new GetFTPTaskTypeReply();
            try
            {
                using (var appctx = new ApplicationConfigurationContext())
                {
                    var temp = appctx.LkpFtmstaskTypes.Select(x => new FTPTaskType
                    {
                        Id = x.TaskTypeId,
                        TaskType = x.TaskType,
                        UIAct = ""
                    }).ToList();
                    ret.FTPTaskTypes.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }

        public MessageReply SaveFTPTaskType(FTPTaskType data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var appctx = new ApplicationConfigurationContext())
                {
                    if (data.Id > 0)
                    {
                        var temp = appctx.LkpFtmstaskTypes.Single(x => x.TaskTypeId == data.Id);
                        if (data.UIAct == "Delete")
                        {
                            appctx.LkpFtmstaskTypes.Remove(temp);
                        }
                        else
                        {
                            temp.TaskType = data.TaskType;
                        }
                        appctx.SaveChanges();
                    }
                    else
                    {
                        var temp = new LkpFtmstaskTypes
                        {
                            TaskTypeId = 0,
                            TaskType = data.TaskType
                        };
                        appctx.LkpFtmstaskTypes.Add(temp);
                        appctx.SaveChanges();
                        ret.Id = temp.TaskTypeId;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetFTPTaskEmailRecipientReply GetFTPTaskEmailRecipient()
        {
            var ret = new GetFTPTaskEmailRecipientReply();
            try
            {
                using (var appctx = new ApplicationConfigurationContext())
                {
                    var temp = appctx.XrefFtmsTaskEmailRecipients.Select(x => new FTPTaskEmailRecipient
                    {
                       Id = x.TaskRecipientId,
                       JobId = x.JobId,
                       TaskId = x.TaskId.GetSafeNullValue(),
                       RecipientId = x.RecipientId,
                       MessageType = x.MessageType.GetSafeString(),
                       RecipientType = x.RecipientType.GetSafeString(),
                       UIAct = ""
                    }).ToList();
                    ret.FTPTaskEmailRecipients.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }

        public MessageReply SaveFTPTaskEmailRecipient(FTPTaskEmailRecipient data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var appctx = new ApplicationConfigurationContext())
                {
                    if (data.UIAct == "Delete")
                    {
                        var temp = appctx.XrefFtmsTaskEmailRecipients.Single(x => x.TaskRecipientId == data.Id);
                        appctx.XrefFtmsTaskEmailRecipients.Remove(temp);
                        appctx.SaveChanges();
                    }
                    else
                    {
                        if (data.UIAct == "Edit")
                        {
                            var temp = appctx.XrefFtmsTaskEmailRecipients.Single(x => x.TaskRecipientId == data.Id);
                            temp.TaskId = data.TaskId.GetNullValue();
                            temp.JobId = data.JobId;
                            temp.RecipientId = data.RecipientId;
                            temp.RecipientType = data.RecipientType;
                            temp.MessageType = data.MessageType;
                            appctx.SaveChanges();
                        }
                        else
                        {
                            var temp = new XrefFtmsTaskEmailRecipients
                            {
                                TaskRecipientId = 0,
                                TaskId = data.TaskId.GetNullValue(),
                                JobId = data.JobId,
                                RecipientType = data.RecipientType,
                                RecipientId = data.RecipientId,
                                MessageType = data.MessageType
                            };
                            appctx.XrefFtmsTaskEmailRecipients.Add(temp);
                            appctx.SaveChanges();
                            ret.Id = temp.TaskRecipientId;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetFTPEmailTaskHistReply GetFTPEmailTaskHist(int tid = 0)
        {
            var ret = new GetFTPEmailTaskHistReply();
            try
            {
                var jobs = new List<LkpFtmsJobs>();
                var tasks = new List<LkpFtmsJobTasks>();
                using(var appctx = new ApplicationConfigurationContext())
                {
                    jobs = appctx.LkpFtmsJobs.ToList();
                    tasks = appctx.LkpFtmsJobTasks.Include(x => x.LkpFtmsEmailTasks).ToList();
                }
                using (var ctx = new DataAutomationContext())
                {
                    var temp = ctx.LogFtmsEmailLog.Where(x => tid == 0 || x.TaskId == tid).ToList().Select(x => new FTPEmailTaskHist
                    {
                        Id = x.FtmsemailLogId,
                        Attachments = x.Attachments.GetSafeString(),
                        EmailText = x.EmailText.GetSafeString(),
                        TaskId = x.TaskId,
                        TaskName = tasks.Single(y => y.TaskId == x.TaskId).TaskName,
                        JobId = tasks.Single(y => y.TaskId == x.TaskId).JobId,
                        JobName = jobs.Single(z => z.JobId == tasks.Single(y => y.TaskId == x.TaskId).JobId).JobName,
                        RecipBcc = x.RecipBcc.GetSafeString(),
                        RecipCc = x.RecipCc.GetSafeString(),
                        RecipTo = x.RecipTo.GetSafeString(),
                        SentDate = x.SentDate.GetSafeDateTimeString()
                    }).OrderByDescending(x => x.Id).ToList();
                    ret.FTPEmailTaskHists.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetFTPTaskHistReply GetFTPTaskHist(int tid = 0)
        {
            var ret = new GetFTPTaskHistReply();
            try
            {
                var jobs = new List<LkpFtmsJobs>();
                var tasks = new List<LkpFtmsJobTasks>();
                using (var appctx = new ApplicationConfigurationContext())
                {
                    jobs = appctx.LkpFtmsJobs.ToList();
                    tasks = appctx.LkpFtmsJobTasks.Include(x => x.LkpFtmsEmailTasks).ToList();
                }
                using (var ctx = new DataAutomationContext())
                {
                    var temp = ctx.LogFtmsFileTransferLog.Where(x => tid == 0 || x.FtmstaskId == tid).ToList().Select(x => new FTPTaskHist
                    {
                        Id = x.FtmstransferId,
                        TaskId = x.FtmstaskId ?? 0,
                        TaskName = tasks.Single(y => y.TaskId == x.FtmstaskId).TaskName,
                        JobId = tasks.Single(y => y.TaskId == x.FtmstaskId).JobId,
                        JobName = jobs.Single(z => z.JobId == tasks.Single(y => y.TaskId == x.FtmstaskId).JobId).JobName,
                        TransferDateTime = x.TransferDateTime.GetSafeDateTimeString(),
                        TransferFileName = x.TransferFileName.GetSafeString(),
                        TransferType = x.TransferType.GetSafeString()
                    }).OrderByDescending(x => x.Id).ToList();
                    ret.FTPTaskHists.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetClientSiteReply GetClientSite()
        {
            var ret = new GetClientSiteReply();
            try
            {
                using (var appctx = new ApplicationConfigurationContext())
                {
                    var temp = appctx.LkpClientFtpsites.Select(x => new FTPClientSite
                    {
                        Id = x.FtpsiteId,
                        Active = x.Active ? 1 : 0,
                        ClientId = x.ClientId,
                        Password = Constant.PasswordStr,
                        Port = x.Port.ToString().GetSafeString(),
                        SFTPSiteURL = x.SftpsiteUrl.GetSafeString(),
                        UserId = x.UserId.GetSafeString(),
                        UIAct = ""
                    }).ToList();
                    ret.FTPClientSites.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }

        public MessageReply SaveClientSite(FTPClientSite data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var appctx = new ApplicationConfigurationContext())
                {
                    if (data.UIAct == "Delete")
                    {
                        var temp = appctx.LkpClientFtpsites.Single(x => x.FtpsiteId == data.Id);
                        appctx.LkpClientFtpsites.Remove(temp);
                        appctx.SaveChanges();
                    }
                    else
                    {
                        if (data.UIAct == "Edit")
                        {
                            var temp = appctx.LkpClientFtpsites.Single(x => x.FtpsiteId == data.Id);
                            temp.ClientId = data.ClientId;
                            temp.Active = data.Active == 1;
                            temp.Password = data.Password == Constant.PasswordStr ? temp.Password : data.Password.Encrypt(true);
                            temp.Port = String.IsNullOrEmpty(data.Port) ? null : (int?)Convert.ToInt32(data.Port);
                            temp.SftpsiteUrl = data.SFTPSiteURL;
                            temp.UserId = data.UserId;

                            appctx.SaveChanges();
                        }
                        else
                        {
                            var temp = new LkpClientFtpsites
                            {
                                FtpsiteId = 0,
                                ClientId = data.ClientId,
                                Active = data.Active == 1,
                                Password = data.Password.Encrypt(true),
                                Port = String.IsNullOrEmpty(data.Port) ? null : (int?)Convert.ToInt32(data.Port),
                                SftpsiteUrl = data.SFTPSiteURL,
                                UserId = data.UserId
                            };
                            appctx.LkpClientFtpsites.Add(temp);
                            appctx.SaveChanges();
                            ret.Id = temp.FtpsiteId;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public MessageReply GetPassword(int id)
        {
            var ret = new MessageReply { Id = 0, Message = ""};
            try
            {
                using (var appctx = new ApplicationConfigurationContext())
                {
                    var temp = appctx.LkpClientFtpsites.Single(x => x.FtpsiteId == id);

                    ret.Message = temp.Password.Decrypt(true);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
    }
  
}
