﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Google.Protobuf.WellKnownTypes;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.Common.TransferObjects;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.GRpc;

namespace CRFS.IS.Service.Business
{
    public class LossAnalysisProvider
    {
        private IConfiguration _config;
        private ILogger _logger;
        private int _userid;

        public LossAnalysisProvider(IConfiguration config, ILogger logger, int uid)
        {
            _config = config;
            _logger = logger;
            _userid = uid;
        }

        public LoanData GetLoanData(string loannumber)
        {
            var ret = new LoanData();

            var acctx = new ApplicationConfigurationContext();
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    var id = lactx.Loan.Where(x => x.LoanNumber == loannumber.Trim()).Select(x => x.LoanId).SingleOrDefault();

                    var temp = lactx.Loan.Where(x => x.LoanId == id)
                                         .Include(x => x.Investor)
                                         .Include(x => x.PropertyStateNavigation).Select(x => new LoanData
                                         {
                                             LoanId = x.LoanId,
                                             BorrowerFirstName = x.BorrowerFirstName.GetSafeString(),
                                             BorrowerLastName = x.BorrowerLastName.GetSafeString(),
                                             // BuyOutDate = Timestamp.FromDateTime(x.BuyOutDate ?? Convert.ToDateTime(Constant.EmptyDateTime).SetKind(DateTimeKind.Utc),
                                             BuyOutDate = x.BuyOutDate.GetSafeString(),
                                             ClaimTypeId = x.ClaimTypeId.GetSafeValue<int>(),
                                             ClientId = x.ClientId.GetSafeValue<int>(),
                                             CloseDate = x.CloseDate.GetSafeString(),
                                             ClosingReasonId = x.ClosingReason ?? 0,
                                             // DebentureInterestRate = (double)x.DebentureInterestRate,
                                             FHACaseNumber = x.FhacaseNumber,
                                             InvestorId = x.InvestorId ?? 0,
                                             InvestorName = x.Investor.InvestorName.GetSafeString(),
                                             LossAnalysisDueDate = x.LossAnalysisDueDate.GetSafeString(),
                                             LoanNumber = x.LoanNumber,
                                             LossAnalysisReferralDate = x.LossAnalysisReferralDate.GetSafeString(),
                                             NoteRate = (double)(x.NoteRate ?? 0.0m.GetSafeValue<decimal>()),
                                             PropertyCity = x.PropertyCity.GetSafeString(),
                                             PropertyLotSize = x.PropertyLotSize ?? 0,
                                             PropertyStateId = x.PropertyState ?? 0,
                                             PropertyStateName = x.PropertyStateNavigation.StateName.GetSafeString(),
                                             PropertyStreetAddressLine1 = x.PropertyStreetAddressLine1.GetSafeString(),
                                             PropertyStreetAddressLine2 = x.PropertyStreetAddressLine2.GetSafeString(),
                                             PropertyZipCode = x.PropertyZipCode.GetSafeString(),
                                             ServiceTransferDate = x.ServiceTransferDate.GetSafeString()
                                         }).SingleOrDefault();

                    temp.ClaimTypeName = lactx.LkpType.Where(x => x.LkpTypeName == "ClaimType")
                        .Select(x => x.LkpTypeCat.Where(y => y.LkpTypeCatId == temp.ClaimTypeId).Select(y => y.LkpTypeCatName).Single()).Single();
                    temp.ClientName = acctx.LkpClients.Where(x => x.ClientId == temp.ClientId).Select(x => x.ClientDisplayName).SingleOrDefault();
                    temp.ClosingReasonName = temp.ClosingReasonId > 0 ? lactx.LkpType.Where(x => x.LkpTypeName == "ClosingReasons")
                                           .Select(x => x.LkpTypeCat.Where(y => y.LkpTypeCatId == temp.ClosingReasonId).Select(y => y.LkpTypeCatName).Single()).Single()
                                           : "";
                    var lms = lactx.LoanMilestone.Where(x => x.LoanId == temp.LoanId).Include(x => x.Milestone).ToList();
                    var partaassign = lms.Where(x => x.Milestone.MilestoneType == "Part-A Assignment").SingleOrDefault();
                    var partbassign = lms.Where(x => x.Milestone.MilestoneType == "Part-B Assignment").SingleOrDefault();
                    if (partaassign != null)
                    {
                        temp.PartAAnalystId = partaassign.AssignedUser ?? 0;
                        temp.PartAAnalystName = temp.PartAAnalystId > 0 ? acctx.LkpUsers.Where(x => x.UserId == temp.PartAAnalystId).Select(x => x.UserName).SingleOrDefault()
                                : "";
                    }
                    else
                    {
                        temp.PartAAnalystId = 0;
                        temp.PartAAnalystName = "";
                    }
                    if (partbassign != null)
                    {
                        temp.PartBAnalystId = partbassign.AssignedUser ?? 0;
                        temp.PartBAnalystName = temp.PartBAnalystId > 0 ? acctx.LkpUsers.Where(x => x.UserId == temp.PartBAnalystId).Select(x => x.UserName).SingleOrDefault()
                                : "";
                    }
                    else
                    {
                        temp.PartBAnalystId = 0;
                        temp.PartBAnalystName = "";
                    }
                    var pacdate = lms.Where(x => x.Milestone.MilestoneType == "Part-A Complete Date").Select(x => x.MilestoneDate).SingleOrDefault();
                    var pbcdate = lms.Where(x => x.Milestone.MilestoneType == "Part-B Complete Date").Select(x => x.MilestoneDate).SingleOrDefault();
                    temp.PartACompleteDate = pacdate.GetSafeString();
                    temp.PartBCompleteDate = pbcdate.GetSafeString();
                    if (lms.Count > 0)
                    {
                        var maxorder = lms.Max(x => x.Milestone.MilestoneOrder);
                        var stt = lms.Where(x => /*x.MilestoneDate == lms.Max(y => y.MilestoneDate) 
                                                  &&*/ x.Milestone.MilestoneOrder == maxorder).SingleOrDefault();

                        if (stt != null)
                        {
                            temp.StatusId = stt.MilestoneId;
                            temp.StatusDate = stt.MilestoneDate.GetSafeString();
                            temp.StatusName = lactx.LkpMileStoneType.Where(x => x.MilestoneId == stt.MilestoneId).Select(x => x.MilestoneType).Single();
                        }
                    }
                    else
                    {
                        temp.StatusId = 0;
                        temp.StatusDate = "";
                        temp.StatusName = "";
                    }
                    ret = temp;
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                acctx.Dispose();
            }
            return ret;
        }
        public CompPartA GetCompPartA(int loanid)
        {
            var ret = new CompPartA();

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    //var lutypelist = 
                    var temp = lactx.LoanPartAcomp.Include(x => x.LoanLivingUnits)
                        .Include(x => x.Loan)
                        .Include(x => x.Loan.PropertyStateNavigation).Where(x => x.LoanId == loanid).SingleOrDefault();

                    ret.AuthorizedBidAmount = (double)temp.AuthorizedBidAmount.GetSafeValue<decimal?>();
                    ret.BankruptcyLiftDate = temp.BankruptcyLiftDate.GetSafeString();
                    ret.ClaimFiledDate = temp.ClaimFiledDate.GetSafeString();
                    ret.ConveyanceExtensionDate = temp.ConveyanceExtensionDate.GetSafeString();
                    ret.DateDeedOrAssignmentFiled = temp.DateDeedOrAssignmentFiled.GetSafeString();
                    ret.DateOfPossessionAcquisition = temp.DateOfPossessionAcquisition.GetSafeString();
                    ret.DebentureInterestRate = (double)temp.DebentureInterestRate.GetSafeValue<decimal?>();
                    ret.DeedInLieuDate = temp.DeedInLieuDate.GetSafeString();
                    ret.DueDateOfLastPaymentInstallment = temp.DueDateOfLastPaymentInstallment.GetSafeString();
                    ret.EndorsementDate = temp.EndorsementDate.GetSafeString();
                    ret.ForeclosureFirstLegalDate = temp.ForeclosureFirstLegalDate.GetSafeString();
                    ret.InstitutionExtensionDate = temp.InstitutionExtensionDate.GetSafeString();
                    ret.MortgageeCurtailmentDate = temp.MortgageeCurtailmentDate.GetSafeString();
                    ret.NumberOfLivingUnits = (int)temp.NumberOfLivingUnits.GetSafeValue<int?>();
                    ret.LoanId = temp.LoanId;
                    ret.OriginalPrincipalBalance = (double)temp.OriginalPrincipalBalance.GetSafeValue<decimal?>();
                    ret.PartACompId = temp.PartAcompId;
                    ret.UnpaidPrincipalBalance = (double)temp.UnpaidPrincipalBalance.GetSafeValue<decimal?>();
                    ret.BorrowerFirstName = temp.Loan.BorrowerFirstName.GetSafeString();
                    ret.BorrowerLastName = temp.Loan.BorrowerLastName.GetSafeString();
                    ret.PropertyCity = temp.Loan.PropertyCity.GetSafeString();
                    ret.PropertyStateId = (int)temp.Loan.PropertyState.GetSafeValue<int?>();
                    ret.PropertyStateName = temp.Loan.PropertyStateNavigation.StateName.GetSafeString();
                    ret.PropertyStreetAddressLine1 = temp.Loan.PropertyStreetAddressLine1.GetSafeString();
                    ret.PropertyStreetAddressLine2 = temp.Loan.PropertyStreetAddressLine2.GetSafeString();
                    ret.PropertyZipCode = temp.Loan.PropertyZipCode.GetSafeString();

                    foreach (var lu in temp.LoanLivingUnits)
                    {
                        ret.LivingUnits.Add(new LivingUnit
                        {
                            LivingUnitPartATypeId = lactx.LkpLivingUnitPartAtype.Where(x => x.LkpTypeCatName == "Part-A Completed").Select(x => x.LkpTypeCatId).Single(),
                            LoanLivingUnitId = lu.LoanLivUnitId,
                            PartAId = (int)lu.PartAcompId.GetSafeValue<int?>(),
                            UnitNum = lu.UnitNum,
                            UnitOccupancyStatusId = (int)lu.UnitOccupancyStatus.GetSafeValue<int?>(),
                            UnitOccupantName = lu.UnitOccupantName.GetSafeString(),
                            UnitSecuredDate = lu.UnitSecuredDate.GetSafeString(),
                            UnitVacatedDate = lu.UnitVacatedDate.GetSafeString()
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public string SaveCompPartA(CompPartA data)
        {
            var ret = Constant.Success;
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    using (var trans = lactx.Database.BeginTransaction())
                    {
                        try
                        {
                            var lutype = lactx.LkpLivingUnitPartAtype.Where(x => x.LkpTypeCatName == "Part-A Completed").Single();
                            if (data.PartACompId > 0)
                            {
                                var cpa = lactx.LoanPartAcomp.Where(x => x.PartAcompId == data.PartACompId).Single();
                                cpa.AuthorizedBidAmount = Convert.ToDecimal(data.AuthorizedBidAmount);
                                cpa.BankruptcyLiftDate = Convert.ToDateTime(data.BankruptcyLiftDate.GetSafeDateString());
                                cpa.ClaimFiledDate = Convert.ToDateTime(data.ClaimFiledDate.GetSafeDateString());
                                cpa.ConveyanceExtensionDate = Convert.ToDateTime(data.ConveyanceExtensionDate.GetSafeDateString());
                                cpa.DateDeedOrAssignmentFiled = Convert.ToDateTime(data.DateDeedOrAssignmentFiled.GetSafeDateString());
                                cpa.DateOfPossessionAcquisition = Convert.ToDateTime(data.DateOfPossessionAcquisition.GetSafeDateString());
                                cpa.DebentureInterestRate = Convert.ToDecimal(data.DebentureInterestRate);
                                cpa.DeedInLieuDate = Convert.ToDateTime(data.DeedInLieuDate.GetSafeDateString());
                                cpa.DueDateOfLastPaymentInstallment = Convert.ToDateTime(data.DueDateOfLastPaymentInstallment.GetSafeDateString());
                                cpa.EndorsementDate = Convert.ToDateTime(data.EndorsementDate.GetSafeDateString());
                                cpa.ForeclosureFirstLegalDate = Convert.ToDateTime(data.ForeclosureFirstLegalDate.GetSafeDateString());
                                cpa.InstitutionExtensionDate = Convert.ToDateTime(data.InstitutionExtensionDate.GetSafeDateString());
                                cpa.NumberOfLivingUnits = data.NumberOfLivingUnits;
                                cpa.ModifiedBy = _userid;
                                cpa.ModifiedDate = DateTime.Now;
                                cpa.MortgageeCurtailmentDate = Convert.ToDateTime(data.MortgageeCurtailmentDate.GetSafeDateString());
                                cpa.OriginalPrincipalBalance = Convert.ToDecimal(data.OriginalPrincipalBalance);
                                cpa.UnpaidPrincipalBalance = Convert.ToDecimal(data.UnpaidPrincipalBalance);

                                var lus = lactx.LoanLivingUnits.Where(x => x.PartAcompId == data.PartACompId).ToList();
                                lactx.LoanLivingUnits.RemoveRange(lus);

                                foreach (var d in data.LivingUnits)
                                {
                                    lactx.LoanLivingUnits.Add(new LoanLivingUnits
                                    {
                                        AddedBy = _userid,
                                        AddedDate = DateTime.Now,
                                        LivingUnitPartAtypeId = lutype.LkpTypeCatId,
                                        LoanLivUnitId = 0,
                                        ModifiedBy = _userid,
                                        ModifiedDate = DateTime.Now,
                                        PartAcompId = data.PartACompId,
                                        UnitNum = (short)d.UnitNum,
                                        UnitOccupancyStatus = d.UnitOccupancyStatusId,
                                        UnitOccupantName = d.UnitOccupantName,
                                        UnitSecuredDate = Convert.ToDateTime(d.UnitSecuredDate.GetSafeDateString()),
                                        UnitVacatedDate = Convert.ToDateTime(d.UnitVacatedDate.GetSafeDateString())
                                    });
                                }
                            }
                            else
                            {
                                var temp = new LoanPartAcomp
                                {
                                    AddedBy = _userid,
                                    AddedDate = DateTime.Now,
                                    AuthorizedBidAmount = Convert.ToDecimal(data.AuthorizedBidAmount),
                                    BankruptcyLiftDate = Convert.ToDateTime(data.BankruptcyLiftDate.GetSafeDateString()),
                                    ClaimFiledDate = Convert.ToDateTime(data.ClaimFiledDate.GetSafeDateString()),
                                    ConveyanceExtensionDate = Convert.ToDateTime(data.ConveyanceExtensionDate.GetSafeDateString()),
                                    DateDeedOrAssignmentFiled = Convert.ToDateTime(data.DateDeedOrAssignmentFiled.GetSafeDateString()),
                                    DateOfPossessionAcquisition = Convert.ToDateTime(data.DateOfPossessionAcquisition.GetSafeDateString()),
                                    DebentureInterestRate = Convert.ToDecimal(data.DebentureInterestRate),
                                    DeedInLieuDate = Convert.ToDateTime(data.DeedInLieuDate.GetSafeDateString()),
                                    DueDateOfLastPaymentInstallment = Convert.ToDateTime(data.DueDateOfLastPaymentInstallment.GetSafeDateString()),
                                    EndorsementDate = Convert.ToDateTime(data.EndorsementDate.GetSafeDateString()),
                                    ForeclosureFirstLegalDate = Convert.ToDateTime(data.ForeclosureFirstLegalDate.GetSafeDateString()),
                                    InstitutionExtensionDate = Convert.ToDateTime(data.InstitutionExtensionDate.GetSafeDateString()),
                                    LoanId = data.LoanId,
                                    ModifiedBy = _userid,
                                    ModifiedDate = DateTime.Now,
                                    MortgageeCurtailmentDate = Convert.ToDateTime(data.MortgageeCurtailmentDate.GetSafeString()),
                                    NumberOfLivingUnits = data.NumberOfLivingUnits,
                                    OriginalPrincipalBalance = Convert.ToDecimal(data.OriginalPrincipalBalance),
                                    UnpaidPrincipalBalance = Convert.ToDecimal(data.UnpaidPrincipalBalance),
                                    PartAcompId = 0
                                };
                                lactx.LoanPartAcomp.Add(temp);
                                lactx.SaveChanges();

                                foreach (var d in data.LivingUnits)
                                {
                                    lactx.LoanLivingUnits.Add(new LoanLivingUnits
                                    {
                                        AddedBy = _userid,
                                        AddedDate = DateTime.Now,
                                        LivingUnitPartAtypeId = lutype.LkpTypeCatId,
                                        LoanLivUnitId = 0,
                                        ModifiedBy = _userid,
                                        ModifiedDate = DateTime.Now,
                                        PartAcompId = temp.PartAcompId,
                                        UnitNum = (short)d.UnitNum,
                                        UnitOccupancyStatus = d.UnitOccupancyStatusId,
                                        UnitOccupantName = d.UnitOccupantName,
                                        UnitSecuredDate = Convert.ToDateTime(d.UnitSecuredDate.GetSafeDateString()),
                                        UnitVacatedDate = Convert.ToDateTime(d.UnitVacatedDate.GetSafeDateString())
                                    });
                                }
                            }
                            lactx.SaveChanges();
                            trans.Commit();
                        }
                        catch (Exception ex)
                        {
                            trans.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetCompAOPReply GetCompAOP(int loanid)
        {
            var ret = new GetCompAOPReply();

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    var aopt = lactx.LkpAoptype.ToList();
                    var compparta = lactx.LoanPartAcomp.Where(x => x.LoanId == loanid).Single();
                    var aops = lactx.LoanAop.Where(x => x.LoanId == loanid).ToList();
                    var temp = aops.Select(x => new CompAOP
                    {
                        AOPId = x.Aopid,
                        LoanId = x.LoanId,
                        AOPTypeId = x.Aoptype,
                        AOPTypeName = aopt.Where(y => y.LkpTypeCatId == x.Aoptype).Select(y => y.LkpTypeCatName).Single(),
                        FHASettlementAmount = (double)x.FhasettlementAmount.GetValueOrDefault(),
                        InterestEndDate = x.InterestEndDate.GetSafeString(),
                        InterestStartDate = x.InterestStartDate.GetSafeString(),
                        LessOffsetAmount = (double)x.LessOffsetAmount.GetSafeValue<decimal?>(),
                        ReceivedDate = x.ReceivedDate.GetSafeString(),
                        SettlementDate = x.SettlementDate.GetSafeString(),
                        TotalInterestPaid = (double)x.TotalInterestPaid.GetSafeValue<decimal?>()
                    }).ToList();


                    ret.CompAOPs.AddRange(temp);

                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public string SaveCompAOP(CompAOP data)
        {
            var ret = Constant.Success;
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    if (data.AOPId > 0)
                    {
                        var aop = lactx.LoanAop.Where(x => x.Aopid == data.AOPId).Single();
                        aop.ModifiedBy = _userid;
                        aop.ModifiedDate = DateTime.Now;
                        aop.FhasettlementAmount = Convert.ToDecimal(data.FHASettlementAmount);
                        aop.InterestEndDate = Convert.ToDateTime(data.InterestEndDate.GetSafeDateString());
                        //aop.Aoptype = data.AOPTypeId;
                        aop.InterestStartDate = Convert.ToDateTime(data.InterestStartDate.GetSafeDateString());
                        aop.LessOffsetAmount = Convert.ToDecimal(data.LessOffsetAmount);
                        aop.ReceivedDate = Convert.ToDateTime(data.ReceivedDate.GetSafeDateString());
                        aop.SettlementDate = Convert.ToDateTime(data.SettlementDate.GetSafeDateString());
                        aop.TotalInterestPaid = Convert.ToDecimal(data.TotalInterestPaid);
                    }
                    else
                    {
                        lactx.LoanAop.Add(new LoanAop
                        {
                            LoanId = data.LoanId,
                            Aopid = 0,
                            AddedBy = _userid,
                            AddedDate = DateTime.Now,
                            Aoptype = data.AOPTypeId,
                            FhasettlementAmount = Convert.ToDecimal(data.FHASettlementAmount),
                            InterestEndDate = Convert.ToDateTime(data.InterestEndDate.GetSafeDateString()),
                            InterestStartDate = Convert.ToDateTime(data.InterestStartDate.GetSafeDateString()),
                            LessOffsetAmount = Convert.ToDecimal(data.LessOffsetAmount),
                            ModifiedBy = _userid,
                            ModifiedDate = DateTime.Now,
                            ReceivedDate = Convert.ToDateTime(data.ReceivedDate.GetSafeDateString()),
                            SettlementDate = Convert.ToDateTime(data.SettlementDate.GetSafeDateString()),
                            TotalInterestPaid = Convert.ToDecimal(data.TotalInterestPaid)
                        });
                    }

                    lactx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetCompPartBReply GetCompPartB(int loanid)
        {
            var ret = new GetCompPartBReply();

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    var temp = lactx.VwLoanPartBdata.Where(x => x.LoanId == loanid).Select(x => new CompPartB
                    {
                        LoanId = x.LoanId,
                        // PartBId = x.PartBblockId,
                        AOPAdditionAmount = (double)x.AopadditionAmount.GetSafeValue<decimal?>(),
                        AOPDeductionAmount = (double)x.AopdeductionAmount.GetSafeValue<decimal?>(),
                        AOPInterestAmount = (double)x.AopinterestAmount.GetSafeValue<decimal?>(),
                        Note = x.Note.GetSafeString(),
                        PartBBlockId = x.PartBblockId,
                        PartBBlockName = x.PartBblockName,
                        SubAdditionAmount = (double)x.SubAdditionAmount.GetSafeValue<decimal?>(),
                        SubDeductionAmount = (double)x.SubDeductionAmount.GetSafeValue<decimal?>(),
                        SubInterestAmount = (double)x.SubInterestAmount.GetSafeValue<decimal?>()
                    }).ToList();
                    foreach (var pb in temp)
                    {
                        ret.CompPartBs.Add(pb);
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        private List<LoanPartBdata> FlatDataToPartBData(CompPartB pb, LossAnalysisNewContext ctx)
        {
            var ret = new List<LoanPartBdata>();
            var col = ctx.LkpPartBcolumn.ToList();
            var typ = ctx.LkpPartBtype.ToList();
            if (pb.SubAdditionAmount > 0)
            {
                ret.Add(new LoanPartBdata
                {
                    AddedBy = _userid,
                    AddedDate = DateTime.Now,
                    ModifiedBy = _userid,
                    ModifiedDate = DateTime.Now,
                    Amount = Convert.ToDecimal(pb.SubAdditionAmount),
                    LoanId = pb.LoanId,
                    PartBblockId = pb.PartBBlockId,
                    PartBcolumn = col.Where(x => x.LkpTypeCatName == "Addition").Select(x => x.LkpTypeCatId).Single(),
                    PartBtype = typ.Where(x => x.LkpTypeCatName == "Submitted Claim").Select(x => x.LkpTypeCatId).Single(),
                    PartBid = 0
                });
            }
            if (pb.SubDeductionAmount > 0)
            {
                ret.Add(new LoanPartBdata
                {
                    AddedBy = _userid,
                    AddedDate = DateTime.Now,
                    ModifiedBy = _userid,
                    ModifiedDate = DateTime.Now,
                    Amount = Convert.ToDecimal(pb.SubDeductionAmount),
                    LoanId = pb.LoanId,
                    PartBblockId = pb.PartBBlockId,
                    PartBcolumn = col.Where(x => x.LkpTypeCatName == "Deduction").Select(x => x.LkpTypeCatId).Single(),
                    PartBtype = typ.Where(x => x.LkpTypeCatName == "Submitted Claim").Select(x => x.LkpTypeCatId).Single(),
                    PartBid = 0
                });
            }
            if (pb.SubInterestAmount > 0)
            {
                ret.Add(new LoanPartBdata
                {
                    AddedBy = _userid,
                    AddedDate = DateTime.Now,
                    ModifiedBy = _userid,
                    ModifiedDate = DateTime.Now,
                    Amount = Convert.ToDecimal(pb.SubInterestAmount),
                    LoanId = pb.LoanId,
                    PartBblockId = pb.PartBBlockId,
                    PartBcolumn = col.Where(x => x.LkpTypeCatName == "Interest").Select(x => x.LkpTypeCatId).Single(),
                    PartBtype = typ.Where(x => x.LkpTypeCatName == "Submitted Claim").Select(x => x.LkpTypeCatId).Single(),
                    PartBid = 0
                });
            }
            if (pb.AOPAdditionAmount > 0)
            {
                ret.Add(new LoanPartBdata
                {
                    AddedBy = _userid,
                    AddedDate = DateTime.Now,
                    ModifiedBy = _userid,
                    ModifiedDate = DateTime.Now,
                    Amount = Convert.ToDecimal(pb.AOPAdditionAmount),
                    LoanId = pb.LoanId,
                    PartBblockId = pb.PartBBlockId,
                    PartBcolumn = col.Where(x => x.LkpTypeCatName == "Addition").Select(x => x.LkpTypeCatId).Single(),
                    PartBtype = typ.Where(x => x.LkpTypeCatName == "Advice of Payment").Select(x => x.LkpTypeCatId).Single(),
                    PartBid = 0
                });
            }
            if (pb.AOPDeductionAmount > 0)
            {
                ret.Add(new LoanPartBdata
                {
                    AddedBy = _userid,
                    AddedDate = DateTime.Now,
                    ModifiedBy = _userid,
                    ModifiedDate = DateTime.Now,
                    Amount = Convert.ToDecimal(pb.AOPDeductionAmount),
                    LoanId = pb.LoanId,
                    PartBblockId = pb.PartBBlockId,
                    PartBcolumn = col.Where(x => x.LkpTypeCatName == "Deduction").Select(x => x.LkpTypeCatId).Single(),
                    PartBtype = typ.Where(x => x.LkpTypeCatName == "Advice of Payment").Select(x => x.LkpTypeCatId).Single(),
                    PartBid = 0
                });
            }
            if (pb.AOPInterestAmount > 0)
            {
                ret.Add(new LoanPartBdata
                {
                    AddedBy = _userid,
                    AddedDate = DateTime.Now,
                    ModifiedBy = _userid,
                    ModifiedDate = DateTime.Now,
                    Amount = Convert.ToDecimal(pb.AOPInterestAmount),
                    LoanId = pb.LoanId,
                    PartBblockId = pb.PartBBlockId,
                    PartBcolumn = col.Where(x => x.LkpTypeCatName == "Interest").Select(x => x.LkpTypeCatId).Single(),
                    PartBtype = typ.Where(x => x.LkpTypeCatName == "Advice of Payment").Select(x => x.LkpTypeCatId).Single(),
                    PartBid = 0
                });
            }
            return ret;
        }
        public string SaveCompPartB(SaveCompPartBRequest data)
        {
            var ret = Constant.Success;
            if (data.CompPartBs.Count == 0)
                throw new Exception("No data to save");

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    using (var trans = lactx.Database.BeginTransaction())
                    {
                        try
                        {
                            var cpbs = lactx.LoanPartBdata.Where(x => x.LoanId == data.CompPartBs.First().LoanId).ToList();
                            var cpbns = lactx.LoanPartBdataNote.Where(x => x.LoanId == data.CompPartBs.First().LoanId).ToList();
                            lactx.LoanPartBdata.RemoveRange(cpbs);
                            lactx.LoanPartBdataNote.RemoveRange(cpbns);

                            foreach (var pb in data.CompPartBs)
                            {
                                var temp = FlatDataToPartBData(pb, lactx);
                                if (temp.Count > 0)
                                {
                                    lactx.LoanPartBdata.AddRange(temp);

                                    if (!string.IsNullOrEmpty(pb.Note))
                                    {
                                        lactx.LoanPartBdataNote.Add(new LoanPartBdataNote
                                        {
                                            AddedBy = _userid,
                                            AddedDate = DateTime.Now,
                                            ModifiedBy = _userid,
                                            ModifiedDate = DateTime.Now,
                                            LoanId = pb.LoanId,
                                            Note = pb.Note,
                                            PartBblockId = pb.PartBBlockId,
                                            PartBnoteId = 0,
                                            Passed = pb.Passed == 1
                                        });
                                    }
                                }
                            }

                            lactx.SaveChanges();
                            trans.Commit();
                        }
                        catch
                        {
                            trans.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public string SaveLoan(LoanData ld)
        {
            var ret = Constant.Success;
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    if (ld.LoanId > 0)
                    {
                        var loan = lactx.Loan.SingleOrDefault(x => x.LoanId == ld.LoanId);
                        loan.ModifiedBy = _userid;
                        loan.ModifiedDate = DateTime.Now;
                        loan.BorrowerFirstName = ld.BorrowerFirstName;
                        loan.BorrowerLastName = ld.BorrowerLastName;
                        loan.BuyOutDate = Convert.ToDateTime(ld.BuyOutDate.GetSafeDateString());
                        loan.ClaimTypeId = ld.ClaimTypeId;
                        loan.ClientId = ld.ClientId;
                        loan.CloseDate = Convert.ToDateTime(ld.CloseDate.GetSafeDateString());
                        loan.ClosingReason = ld.ClosingReasonId;
                        // loan.DebentureInterestRate = Convert.ToDecimal(Math.Round(ld.DebentureInterestRate, 4));
                        loan.FhacaseNumber = ld.FHACaseNumber;
                        loan.InvestorId = ld.InvestorId;
                        loan.LossAnalysisDueDate = Convert.ToDateTime(ld.LossAnalysisDueDate.GetSafeDateString());
                        loan.LossAnalysisReferralDate = Convert.ToDateTime(ld.LossAnalysisReferralDate.GetSafeDateString());
                        loan.NoteRate = Convert.ToDecimal(Math.Round(ld.NoteRate, 4));
                        loan.PropertyCity = ld.PropertyCity;
                        loan.PropertyLotSize = ld.PropertyLotSize;
                        loan.PropertyState = ld.PropertyStateId;
                        loan.PropertyStreetAddressLine1 = ld.PropertyStreetAddressLine1;
                        loan.PropertyStreetAddressLine2 = ld.PropertyStreetAddressLine2;
                        loan.PropertyZipCode = ld.PropertyZipCode;
                        loan.ServiceTransferDate = Convert.ToDateTime(ld.ServiceTransferDate.GetSafeDateString());

                        var lms = lactx.LoanMilestone.Where(x => x.LoanId == ld.LoanId).ToList();
                        if (!lms.Any(x => x.MilestoneId == ld.StatusId))
                        {
                            var ms = new LoanMilestone
                            {
                                LoanMilestoneId = 0,
                                LoanId = ld.LoanId,
                                MilestoneId = ld.StatusId,
                                MilestoneDate = Convert.ToDateTime(ld.StatusDate.GetSafeDateString()),
                                AddedBy = _userid,
                                AddedDate = DateTime.Now,
                                ModifiedBy = _userid,
                                ModifiedDate = DateTime.Now,
                                AssignedUser = 0
                            };
                            lactx.LoanMilestone.Add(ms);
                        }
                        else
                        {
                            var ms = lms.Where(x => x.MilestoneId == ld.StatusId).Single();
                            ms.MilestoneDate = Convert.ToDateTime(ld.StatusDate.GetSafeDateString());
                            ms.ModifiedBy = _userid;
                            ms.ModifiedDate = DateTime.Now;
                        }
                    }
                    else
                    {
                        var loan = new Loan
                        {
                            LoanId = ld.LoanId,
                            AddedBy = _userid,
                            AddedDate = DateTime.Now,
                            BorrowerFirstName = ld.BorrowerFirstName,
                            BorrowerLastName = ld.BorrowerLastName,
                            BuyOutDate = Convert.ToDateTime(ld.BuyOutDate.GetSafeDateString()),
                            ClaimTypeId = ld.ClaimTypeId,
                            ClientId = ld.ClientId,
                            CloseDate = Convert.ToDateTime(ld.CloseDate.GetSafeDateString()),
                            ClosingReason = ld.ClosingReasonId,
                            //    DebentureInterestRate = Convert.ToDecimal(Math.Round(ld.DebentureInterestRate, 4)),
                            FhacaseNumber = ld.FHACaseNumber,
                            InvestorId = ld.InvestorId,
                            LoanNumber = ld.LoanNumber,
                            LossAnalysisDueDate = Convert.ToDateTime(ld.LossAnalysisDueDate.GetSafeDateString()),
                            LossAnalysisReferralDate = Convert.ToDateTime(ld.LossAnalysisReferralDate.GetSafeDateString()),
                            ModifiedBy = _userid,
                            ModifiedDate = DateTime.Now,
                            NoteRate = Convert.ToDecimal(Math.Round(ld.NoteRate, 4)),
                            PropertyCity = ld.PropertyCity,
                            PropertyLotSize = ld.PropertyLotSize,
                            PropertyState = ld.PropertyStateId,
                            PropertyStreetAddressLine1 = ld.PropertyStreetAddressLine1,
                            PropertyStreetAddressLine2 = ld.PropertyStreetAddressLine2,
                            PropertyZipCode = ld.PropertyZipCode,
                            ServiceTransferDate = Convert.ToDateTime(ld.ServiceTransferDate.GetSafeDateString())
                        };
                        lactx.Loan.Add(loan);
                        lactx.SaveChanges();

                        lactx.LoanMilestone.Add(new LoanMilestone
                        {
                            LoanMilestoneId = 0,
                            LoanId = loan.LoanId,
                            MilestoneId = ld.StatusId,
                            MilestoneDate = Convert.ToDateTime(ld.StatusDate.GetSafeDateString()),
                            AddedBy = _userid,
                            AddedDate = DateTime.Now,
                            ModifiedBy = _userid,
                            ModifiedDate = DateTime.Now,
                            AssignedUser = 0
                        });
                    }
                    lactx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public string SaveMilestone(Milestone ms)
        {
            var ret = Constant.Success;
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    var lms = lactx.LoanMilestone.Where(x => x.LoanId == ms.LoanId).ToList();

                    if (lms.Any(x => x.MilestoneId == ms.MilestoneId))
                    {
                        var lm = lms.SingleOrDefault(x => x.MilestoneId == ms.MilestoneId);
                        lm.AssignedUser = ms.AssignedUserId;
                        // lm.MilestoneDate = ms.MilestoneDate.ToDateTime();
                        lm.ModifiedBy = _userid;
                        lm.ModifiedDate = DateTime.Now;
                    }
                    else
                    {
                        lactx.LoanMilestone.Add(new LoanMilestone
                        {
                            AddedBy = _userid,
                            AddedDate = DateTime.Now,
                            AssignedUser = ms.AssignedUserId,
                            LoanId = ms.LoanId,
                            LoanMilestoneId = 0,
                            MilestoneDate = Convert.ToDateTime(ms.MilestoneDate.GetSafeDateString()),
                            MilestoneId = ms.MilestoneId,
                            ModifiedBy = _userid,
                            ModifiedDate = DateTime.Now
                        });
                    }
                    lactx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public RecPartA GetRecPartA(int loanid)
        {
            var ret = new RecPartA();

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    var temp = lactx.LoanPartArec.Include(x => x.LoanLivingUnits)
                        .Include(x => x.Loan)
                        .Include(x => x.Loan.PropertyStateNavigation).Where(x => x.LoanId == loanid).SingleOrDefault();

                    ret.PartARecId = temp.PartArecId;
                    ret.LoanId = temp.LoanId;
                    ret.PartACompId = temp.PartAcompId ?? 0;

                    ret.ApprovalToParticipateDate = temp.ApprovalToParticipateDate.GetSafeString();
                    ret.AuthorizedBidAmount = (double)temp.AuthorizedBidAmount.GetSafeValue<decimal?>();
                    ret.BankruptcyLiftDate = temp.BankruptcyLiftDate.GetSafeString();
                    ret.BorrowerPaymentsMade = (temp.BorrowerPaymentsMade ?? false) ? 1 : 0;
                    ret.CheckWireDate = temp.CheckWireDate.GetSafeString();
                    ret.ClientSpecifiedBlock9 = temp.ClientSpecifiedBlock9.GetSafeString();
                    ret.DateOfInspectionPriorToFTV = temp.DateOfInspectionPriorToFtv.GetSafeString();
                    ret.DateOfPossessionAndAcquisition = temp.DateOfPossessionAndAcquisition.GetSafeString();
                    ret.DebentureInterestRate = Convert.ToDouble(temp.DebentureInterestRate);
                    ret.DeedInLieuDate = temp.DeedInLieuDate.GetSafeString();
                    ret.DeedInLieuTransferDate = temp.DeedInLieuTransferDate.GetSafeString();
                    ret.DefaultDate = temp.DefaultDate.GetSafeString();
                    ret.DueDate = temp.DueDate.GetSafeString();
                    ret.DueDateofLastPaymentInstallment = temp.DueDateofLastPaymentInstallment.GetSafeString();
                    ret.EndorsementDate = temp.EndorsementDate.GetSafeString();
                    ret.FirstInspectionDate = temp.FirstInspectionDate.GetSafeString();
                    ret.FirstInspectionStatus = temp.FirstInspectionStatus ?? 0;
                    ret.FirstSFDMSCode1ADate = temp.FirstSfdmscode1Adate.GetSafeString();
                    ret.FirstTimeVacancyDate = temp.FirstTimeVacancyDate.GetSafeString();
                    ret.ForeclosureDeedRecordedDate = temp.ForeclosureDeedRecordedDate.GetSafeString();
                    ret.ForeclosureSaleDate = temp.ForeclosureSaleDate.GetSafeString();
                    ret.HUDAssignmentDate = temp.HudassignmentDate.GetSafeString();
                    ret.HUDDeedFilingDate = temp.HuddeedFilingDate.GetSafeString();
                    ret.LastLoanModificationDate = temp.LastLoanModificationDate.GetSafeString();
                    ret.LastOnTimePaymentDate = temp.LastOnTimePaymentDate.GetSafeString();
                    ret.MarketableTitleDate = temp.MarketableTitleDate.GetSafeString();
                    ret.NumberOfLivingUnits = temp.NumberOfLivingUnits ?? 0;
                    ret.OriginalDefaultDate = temp.OriginalDefaultDate.GetSafeString();
                    ret.PFSSettlementDate = temp.PfssettlementDate.GetSafeString();
                    ret.PropertyREOSold = (temp.PropertyReosold ?? false) ? 1 : 0;
                    ret.RecentVacancyDate = temp.RecentVacancyDate.GetSafeString();
                    ret.RedemptionDate = temp.RedemptionDate.GetSafeString();
                    ret.RRCDate = temp.Rrcdate.GetSafeString();
                    ret.SaleBidAmount = Convert.ToDouble(temp.SaleBidAmount);
                    ret.SecondChanceSaleDate = temp.SecondChanceSaleDate.GetSafeString();
                    ret.SFDMSReportingMissedCycles = temp.SfdmsreportingMissedCycles ?? 0;
                    ret.SufficientPaymentHistory = (temp.SufficientPaymentHistory ?? false) ? 1 : 0;
                    ret.UnpaidPrincipalBalance = Convert.ToDouble(temp.UnpaidPrincipalBalance);

                    ret.BorrowerFirstName = temp.Loan.BorrowerFirstName.GetSafeString();
                    ret.BorrowerLastName = temp.Loan.BorrowerLastName.GetSafeString();
                    ret.PropertyCity = temp.Loan.PropertyCity.GetSafeString();
                    ret.PropertyStateId = (int)temp.Loan.PropertyState.GetSafeValue<int?>();
                    ret.PropertyStateName = temp.Loan.PropertyStateNavigation.StateName.GetSafeString();
                    ret.PropertyStreetAddressLine1 = temp.Loan.PropertyStreetAddressLine1.GetSafeString();
                    ret.PropertyStreetAddressLine2 = temp.Loan.PropertyStreetAddressLine2.GetSafeString();
                    ret.PropertyZipCode = temp.Loan.PropertyZipCode.GetSafeString();

                    foreach (var lu in temp.LoanLivingUnits)
                    {
                        ret.LivingUnits.Add(new LivingUnit
                        {
                            LivingUnitPartATypeId = lactx.LkpLivingUnitPartAtype.Where(x => x.LkpTypeCatName == "Part-A Completed").Select(x => x.LkpTypeCatId).Single(),
                            LoanLivingUnitId = lu.LoanLivUnitId,
                            PartAId = (int)lu.PartAcompId.GetSafeValue<int?>(),
                            UnitNum = lu.UnitNum,
                            UnitOccupancyStatusId = (int)lu.UnitOccupancyStatus.GetSafeValue<int?>(),
                            UnitOccupantName = lu.UnitOccupantName.GetSafeString(),
                            UnitSecuredDate = lu.UnitSecuredDate.GetSafeString(),
                            UnitVacatedDate = lu.UnitVacatedDate.GetSafeString()
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public string SaveRecPartA(RecPartA data)
        {
            var ret = Constant.Success;
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    using (var trans = lactx.Database.BeginTransaction())
                    {
                        try
                        {
                            var lutype = lactx.LkpLivingUnitPartAtype.Where(x => x.LkpTypeCatName == "Part-A Recommended").Single();
                            if (data.PartARecId > 0)
                            {
                                var cpa = lactx.LoanPartArec.Where(x => x.PartArecId == data.PartARecId).Single();
                                cpa.ModifiedBy = _userid;
                                cpa.ModifiedDate = DateTime.Now;
                                cpa.ApprovalToParticipateDate = Convert.ToDateTime(data.ApprovalToParticipateDate.GetSafeDateString());
                                cpa.AuthorizedBidAmount = Convert.ToDecimal(data.AuthorizedBidAmount);
                                cpa.BankruptcyLiftDate = Convert.ToDateTime(data.BankruptcyLiftDate.GetSafeDateString());
                                cpa.BorrowerPaymentsMade = data.BorrowerPaymentsMade == 1;
                                cpa.CheckWireDate = Convert.ToDateTime(data.CheckWireDate.GetSafeDateString());
                                cpa.ClientSpecifiedBlock9 = Convert.ToDateTime(data.ClientSpecifiedBlock9.GetSafeDateString());
                                cpa.DateOfInspectionPriorToFtv = Convert.ToDateTime(data.DateOfInspectionPriorToFTV.GetSafeDateString());
                                cpa.DateOfPossessionAndAcquisition = Convert.ToDateTime(data.DateOfPossessionAndAcquisition.GetSafeDateString());
                                cpa.DebentureInterestRate = Convert.ToDecimal(data.DebentureInterestRate);
                                cpa.DeedInLieuDate = Convert.ToDateTime(data.DeedInLieuDate.GetSafeDateString());
                                cpa.DeedInLieuTransferDate = Convert.ToDateTime(data.DeedInLieuTransferDate.GetSafeDateString());
                                cpa.DefaultDate = Convert.ToDateTime(data.DefaultDate.GetSafeDateString());
                                cpa.DueDate = Convert.ToDateTime(data.DueDate.GetSafeDateString());
                                cpa.DueDateofLastPaymentInstallment = Convert.ToDateTime(data.DueDateofLastPaymentInstallment.GetSafeDateString());
                                cpa.EndorsementDate = Convert.ToDateTime(data.EndorsementDate.GetSafeDateString());
                                cpa.FirstInspectionDate = Convert.ToDateTime(data.FirstInspectionDate.GetSafeDateString());
                                cpa.FirstInspectionStatus = data.FirstInspectionStatus;
                                cpa.FirstSfdmscode1Adate = Convert.ToDateTime(data.FirstSFDMSCode1ADate.GetSafeDateString());
                                cpa.FirstTimeVacancyDate = Convert.ToDateTime(data.FirstTimeVacancyDate.GetSafeDateString());
                                cpa.ForeclosureDeedRecordedDate = Convert.ToDateTime(data.ForeclosureDeedRecordedDate.GetSafeDateString());
                                cpa.ForeclosureSaleDate = Convert.ToDateTime(data.ForeclosureSaleDate.GetSafeDateString());
                                cpa.HudassignmentDate = Convert.ToDateTime(data.HUDAssignmentDate.GetSafeDateString());
                                cpa.HuddeedFilingDate = Convert.ToDateTime(data.HUDDeedFilingDate.GetSafeDateString());
                                cpa.LastLoanModificationDate = Convert.ToDateTime(data.LastLoanModificationDate.GetSafeDateString());
                                cpa.LastOnTimePaymentDate = Convert.ToDateTime(data.LastOnTimePaymentDate.GetSafeDateString());
                                cpa.MarketableTitleDate = Convert.ToDateTime(data.MarketableTitleDate.GetSafeDateString());
                                cpa.NumberOfLivingUnits = data.NumberOfLivingUnits;
                                cpa.OriginalDefaultDate = Convert.ToDateTime(data.OriginalDefaultDate.GetSafeDateString());
                                cpa.PfssettlementDate = Convert.ToDateTime(data.PFSSettlementDate.GetSafeDateString());
                                cpa.PropertyReosold = data.PropertyREOSold == 1;
                                cpa.RecentVacancyDate = Convert.ToDateTime(data.RecentVacancyDate.GetSafeDateString());
                                cpa.RedemptionDate = Convert.ToDateTime(data.RedemptionDate.GetSafeDateString());
                                cpa.Rrcdate = Convert.ToDateTime(data.RRCDate.GetSafeDateString());
                                cpa.SaleBidAmount = Convert.ToDecimal(data.SaleBidAmount);
                                cpa.SecondChanceSaleDate = Convert.ToDateTime(data.SecondChanceSaleDate.GetSafeDateString());
                                cpa.SfdmsreportingMissedCycles = data.SFDMSReportingMissedCycles;
                                cpa.SufficientPaymentHistory = data.SufficientPaymentHistory == 1;
                                cpa.UnpaidPrincipalBalance = Convert.ToDecimal(data.UnpaidPrincipalBalance);

                                var lus = lactx.LoanLivingUnits.Where(x => x.PartArecId == data.PartARecId).ToList();
                                lactx.LoanLivingUnits.RemoveRange(lus);

                                foreach (var d in data.LivingUnits)
                                {
                                    lactx.LoanLivingUnits.Add(new LoanLivingUnits
                                    {
                                        AddedBy = _userid,
                                        AddedDate = DateTime.Now,
                                        LivingUnitPartAtypeId = lutype.LkpTypeCatId,
                                        LoanLivUnitId = 0,
                                        ModifiedBy = _userid,
                                        ModifiedDate = DateTime.Now,
                                        PartArecId = data.PartARecId,
                                        UnitNum = (short)d.UnitNum,
                                        UnitOccupancyStatus = d.UnitOccupancyStatusId,
                                        UnitOccupantName = d.UnitOccupantName,
                                        UnitSecuredDate = Convert.ToDateTime(d.UnitSecuredDate.GetSafeDateString()),
                                        UnitVacatedDate = Convert.ToDateTime(d.UnitVacatedDate.GetSafeDateString())
                                    });
                                }
                            }
                            else
                            {
                                var temp = new LoanPartArec
                                {
                                    AddedBy = _userid,
                                    AddedDate = DateTime.Now,
                                    LoanId = data.LoanId,
                                    ModifiedBy = _userid,
                                    ModifiedDate = DateTime.Now,
                                    PartArecId = 0,
                                    PartAcompId = 0,
                                    ApprovalToParticipateDate = Convert.ToDateTime(data.ApprovalToParticipateDate.GetSafeDateString()),
                                    AuthorizedBidAmount = Convert.ToDecimal(data.AuthorizedBidAmount),
                                    BankruptcyLiftDate = Convert.ToDateTime(data.BankruptcyLiftDate),
                                    BorrowerPaymentsMade = data.BorrowerPaymentsMade == 1,
                                    CheckWireDate = Convert.ToDateTime(data.CheckWireDate.GetSafeDateString()),
                                    ClientSpecifiedBlock9 = Convert.ToDateTime(data.ClientSpecifiedBlock9.GetSafeDateString()),
                                    DateOfInspectionPriorToFtv = Convert.ToDateTime(data.DateOfInspectionPriorToFTV.GetSafeDateString()),
                                    DateOfPossessionAndAcquisition = Convert.ToDateTime(data.DateOfPossessionAndAcquisition.GetSafeDateString()),
                                    DebentureInterestRate = Convert.ToDecimal(data.DebentureInterestRate),
                                    DeedInLieuDate = Convert.ToDateTime(data.DeedInLieuDate.GetSafeDateString()),
                                    DeedInLieuTransferDate = Convert.ToDateTime(data.DeedInLieuTransferDate.GetSafeDateString()),
                                    DefaultDate = Convert.ToDateTime(data.DefaultDate.GetSafeDateString()),
                                    DueDate = Convert.ToDateTime(data.DueDate.GetSafeDateString()),
                                    DueDateofLastPaymentInstallment = Convert.ToDateTime(data.DueDateofLastPaymentInstallment.GetSafeDateString()),
                                    EndorsementDate = Convert.ToDateTime(data.EndorsementDate.GetSafeDateString()),
                                    FirstInspectionDate = Convert.ToDateTime(data.FirstInspectionDate.GetSafeDateString()),
                                    FirstInspectionStatus = data.FirstInspectionStatus,
                                    FirstSfdmscode1Adate = Convert.ToDateTime(data.FirstSFDMSCode1ADate.GetSafeDateString()),
                                    FirstTimeVacancyDate = Convert.ToDateTime(data.FirstTimeVacancyDate.GetSafeDateString()),
                                    ForeclosureDeedRecordedDate = Convert.ToDateTime(data.ForeclosureDeedRecordedDate.GetSafeDateString()),
                                    ForeclosureSaleDate = Convert.ToDateTime(data.ForeclosureSaleDate.GetSafeDateString()),
                                    HudassignmentDate = Convert.ToDateTime(data.HUDAssignmentDate.GetSafeDateString()),
                                    HuddeedFilingDate = Convert.ToDateTime(data.HUDDeedFilingDate.GetSafeDateString()),
                                    LastLoanModificationDate = Convert.ToDateTime(data.LastLoanModificationDate.GetSafeDateString()),
                                    LastOnTimePaymentDate = Convert.ToDateTime(data.LastOnTimePaymentDate.GetSafeDateString()),
                                    MarketableTitleDate = Convert.ToDateTime(data.MarketableTitleDate.GetSafeDateString()),
                                    NumberOfLivingUnits = data.NumberOfLivingUnits,
                                    OriginalDefaultDate = Convert.ToDateTime(data.OriginalDefaultDate.GetSafeDateString()),
                                    PfssettlementDate = Convert.ToDateTime(data.PFSSettlementDate.GetSafeDateString()),
                                    PropertyReosold = data.PropertyREOSold == 1,
                                    RecentVacancyDate = Convert.ToDateTime(data.RecentVacancyDate.GetSafeDateString()),
                                    RedemptionDate = Convert.ToDateTime(data.RedemptionDate.GetSafeDateString()),
                                    Rrcdate = Convert.ToDateTime(data.RRCDate.GetSafeDateString()),
                                    SaleBidAmount = Convert.ToDecimal(data.SaleBidAmount),
                                    SecondChanceSaleDate = Convert.ToDateTime(data.SecondChanceSaleDate.GetSafeDateString()),
                                    SfdmsreportingMissedCycles = data.SFDMSReportingMissedCycles,
                                    SufficientPaymentHistory = data.SufficientPaymentHistory == 1,
                                    UnpaidPrincipalBalance = Convert.ToDecimal(data.UnpaidPrincipalBalance)
                                };
                                lactx.LoanPartArec.Add(temp);
                                lactx.SaveChanges();

                                foreach (var d in data.LivingUnits)
                                {
                                    lactx.LoanLivingUnits.Add(new LoanLivingUnits
                                    {
                                        AddedBy = _userid,
                                        AddedDate = DateTime.Now,
                                        LivingUnitPartAtypeId = lutype.LkpTypeCatId,
                                        LoanLivUnitId = 0,
                                        ModifiedBy = _userid,
                                        ModifiedDate = DateTime.Now,
                                        PartArecId = temp.PartArecId,
                                        UnitNum = (short)d.UnitNum,
                                        UnitOccupancyStatus = d.UnitOccupancyStatusId,
                                        UnitOccupantName = d.UnitOccupantName,
                                        UnitSecuredDate = Convert.ToDateTime(d.UnitSecuredDate.GetSafeDateString()),
                                        UnitVacatedDate = Convert.ToDateTime(d.UnitVacatedDate.GetSafeDateString())
                                    });
                                }
                            }
                            lactx.SaveChanges();
                            trans.Commit();
                        }
                        catch (Exception ex)
                        {
                            trans.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetFCActionReply GetFCAction(int loanid)
        {
            var ret = new GetFCActionReply();

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    var temp = lactx.LoanForeclosure.Where(x => x.LoanId == loanid).Select(x => new FCAction
                    {
                        Comments = x.Comments.GetSafeString(),
                        LoanId = x.LoanId,
                        FirstLegalDate = x.FirstLegalDate.GetSafeString(),
                        LoanForeclosureId = x.LoanForeclosureId,
                        RestartReason = x.RestartReason ?? 0,
                        RestartValid = x.RestartValid ?? false ? 1 : 0,
                        SFDMSCode68Date = x.Sfdmscode68Date.GetSafeString(),
                        Type = x.Type ?? 0,
                        UIAct = ""
                    }).ToList();

                    ret.FCActions.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public string SaveFCAction(FCAction data)
        {
            var ret = Constant.Success;
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    if (data.LoanForeclosureId > 0)
                    {
                        var cpa = lactx.LoanForeclosure.Where(x => x.LoanForeclosureId == data.LoanForeclosureId).Single();
                        if (data.UIAct == "Delete")
                        {
                            lactx.LoanForeclosure.Remove(cpa);
                        }
                        else
                        {
                            cpa.Comments = data.Comments;
                            cpa.FirstLegalDate = Convert.ToDateTime(data.FirstLegalDate.GetSafeDateString());
                            cpa.ModifiedBy = _userid;
                            cpa.ModifiedDate = DateTime.Now;
                            cpa.RestartReason = data.RestartReason;
                            cpa.RestartValid = data.RestartValid == 1;
                            cpa.Sfdmscode68Date = Convert.ToDateTime(data.SFDMSCode68Date.GetSafeDateString());
                            cpa.Type = data.Type;
                        }
                    }
                    else
                    {
                        lactx.LoanForeclosure.Add(new LoanForeclosure
                        {
                            AddedBy = _userid,
                            AddedDate = DateTime.Now,
                            Comments = data.Comments,
                            FirstLegalDate = Convert.ToDateTime(data.FirstLegalDate.GetSafeDateString()),
                            LoanId = data.LoanId,
                            LoanForeclosureId = 0,
                            ModifiedBy = _userid,
                            ModifiedDate = DateTime.Now,
                            RestartReason = data.RestartReason,
                            RestartValid = data.RestartValid == 1,
                            Sfdmscode68Date = Convert.ToDateTime(data.SFDMSCode68Date.GetSafeDateString()),
                            Type = data.Type

                        });
                    }

                    lactx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetOtherExtReply GetOtherExt(int loanid)
        {
            var ret = new GetOtherExtReply();

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    var temp = lactx.LoanExtension.Where(x => x.LoanId == loanid).Select(x => new OtherExt
                    {
                        LoanExtensionId = x.LoanExtensionId,
                        ActiveDutyDischargeDate = x.ActiveDutyDischargeDate.GetSafeString(),
                        ActiveDutyStartDate = x.ActiveDutyStartDate.GetSafeString(),
                        DeclarationDate = x.DeclarationDate.GetSafeString(),
                        ExtensionType = x.ExtensionType,
                        FEMAExtensionDate = x.FemaextensionDate.GetSafeString(),
                        FirstActionDate = x.FirstActionDate.GetSafeString(),
                        HazardClaimDate = x.HazardClaimDate.GetSafeString(),
                        HazardClaimSettlementDate = x.HazardClaimSettlementDate.GetSafeString(),
                        HUDExtensionDate = x.HudextensionDate.GetSafeString(),
                        HUDExtensionRequestDate = x.HudextensionRequestDate.GetSafeString(),
                        LossDate = x.LossDate.GetSafeString(),
                        SaleContractApprovalDate = x.SaleContractApprovalDate.GetSafeString(),
                        StatuteEndDate = x.StatuteEndDate.GetSafeString(),
                        StatuteStartDate = x.StatuteStartDate.GetSafeString(),
                        LoanId = x.LoanId,
                        UIAct = ""
                    }).ToList();

                    ret.OtherExts.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public string SaveOtherExt(OtherExt data)
        {
            var ret = Constant.Success;
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    if (data.LoanExtensionId > 0)
                    {
                        var cpa = lactx.LoanExtension.Where(x => x.LoanExtensionId == data.LoanExtensionId).Single();
                        if (data.UIAct == "Delete")
                        {
                            lactx.LoanExtension.Remove(cpa);
                        }
                        else
                        {
                            cpa.ActiveDutyDischargeDate = Convert.ToDateTime(data.ActiveDutyDischargeDate.GetSafeDateString());
                            cpa.ActiveDutyStartDate = Convert.ToDateTime(data.ActiveDutyStartDate.GetSafeDateString());
                            cpa.DeclarationDate = Convert.ToDateTime(data.DeclarationDate.GetSafeDateString());
                            cpa.ExtensionType = data.ExtensionType;
                            cpa.FemaextensionDate = Convert.ToDateTime(data.FEMAExtensionDate.GetSafeDateString());
                            cpa.FirstActionDate = Convert.ToDateTime(data.FirstActionDate.GetSafeDateString());
                            cpa.HazardClaimDate = Convert.ToDateTime(data.HazardClaimDate.GetSafeDateString());
                            cpa.HazardClaimSettlementDate = Convert.ToDateTime(data.HazardClaimSettlementDate.GetSafeDateString());
                            cpa.HudextensionDate = Convert.ToDateTime(data.HUDExtensionDate.GetSafeDateString());
                            cpa.HudextensionRequestDate = Convert.ToDateTime(data.HUDExtensionRequestDate.GetSafeDateString());
                            cpa.LossDate = Convert.ToDateTime(data.LossDate.GetSafeDateString());
                            cpa.ModifiedBy = _userid;
                            cpa.ModifiedDate = DateTime.Now;
                        }
                    }
                    else
                    {
                        lactx.LoanExtension.Add(new LoanExtension
                        {
                            AddedBy = _userid,
                            AddedDate = DateTime.Now,
                            LoanId = data.LoanId,
                            ModifiedBy = _userid,
                            ModifiedDate = DateTime.Now,
                            ActiveDutyDischargeDate = Convert.ToDateTime(data.ActiveDutyDischargeDate.GetSafeDateString()),
                            ActiveDutyStartDate = Convert.ToDateTime(data.ActiveDutyStartDate.GetSafeDateString()),
                            DeclarationDate = Convert.ToDateTime(data.DeclarationDate.GetSafeDateString()),
                            ExtensionType = data.ExtensionType,
                            FemaextensionDate = Convert.ToDateTime(data.FEMAExtensionDate.GetSafeDateString()),
                            FirstActionDate = Convert.ToDateTime(data.FirstActionDate.GetSafeDateString()),
                            HazardClaimDate = Convert.ToDateTime(data.HazardClaimDate.GetSafeDateString()),
                            HazardClaimSettlementDate = Convert.ToDateTime(data.HazardClaimSettlementDate.GetSafeDateString()),
                            HudextensionDate = Convert.ToDateTime(data.HUDExtensionDate.GetSafeDateString()),
                            HudextensionRequestDate = Convert.ToDateTime(data.HUDExtensionRequestDate.GetSafeDateString()),
                            LossDate = Convert.ToDateTime(data.LossDate.GetSafeDateString()),
                            SaleContractApprovalDate = Convert.ToDateTime(data.SaleContractApprovalDate.GetSafeDateString()),
                            StatuteEndDate = Convert.ToDateTime(data.StatuteEndDate.GetSafeDateString()),
                            StatuteStartDate = Convert.ToDateTime(data.StatuteStartDate.GetSafeDateString()),
                            LoanExtensionId = 0
                        });
                    }
                    lactx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetTimeframeReply GetTimeframe(int loanid)
        {
            var ret = new GetTimeframeReply();

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    var tftypes = lactx.LkpTimeframeType.ToList();
                    var temp = lactx.LoanTimeframes.Where(x => x.LoanId == loanid).ToList()
                        .Select(x => new Timeframe
                        {
                            LoanTimeframeId = x.LoanTimeframeId,
                            TimeframeActivityDate = x.TimeframeActivityDate.GetSafeString(),
                            TimeframeCalcDeadlineDate = x.TimeframeCalcDeadlineDate.GetSafeString(),
                            TimeframeExtensionUsed = x.TimeframeExtensionUsed ?? false ? 1 : 0,
                            TimeframeOverrideDeadlineDate = x.TimeframeOverrideDeadlineDate.GetSafeString(),
                            TimeframeTypeId = x.TimeframeType,
                            TimeframeTestPass = x.TimeframeTestPass ?? false ? 1 : 0,
                            TimeframeTypeName = tftypes.Where(y => y.LkpTypeCatId == x.TimeframeType).Select(y => y.LkpTypeCatName).Single(),
                            LoanId = x.LoanId
                        }).ToList();

                    ret.Timeframes.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public string SaveTimeframe(SaveTimeframeRequest data)
        {
            var ret = Constant.Success;
            if (data.Timeframes.Count == 0)
                return ret; //no action is needed
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    using (var trans = lactx.Database.BeginTransaction())
                    {
                        try
                        {
                            var tfs = lactx.LoanTimeframes.Where(x => x.LoanId == data.Timeframes.First().LoanId).ToList();
                            lactx.LoanTimeframes.RemoveRange(tfs);

                            foreach (var d in data.Timeframes)
                            {
                                lactx.LoanTimeframes.Add(new LoanTimeframes
                                {
                                    LoanId = d.LoanId,
                                    LoanTimeframeId = 0,
                                    AddedBy = _userid,
                                    AddedDate = DateTime.Now,
                                    ModifiedBy = _userid,
                                    ModifiedDate = DateTime.Now,
                                    TimeframeActivityDate = Convert.ToDateTime(d.TimeframeActivityDate.GetSafeDateString()),
                                    TimeframeCalcDeadlineDate = Convert.ToDateTime(d.TimeframeCalcDeadlineDate.GetSafeDateString()),
                                    TimeframeExtensionUsed = d.TimeframeExtensionUsed == 1,
                                    TimeframeOverrideDeadlineDate = Convert.ToDateTime(d.TimeframeOverrideDeadlineDate.GetSafeDateString()),
                                    TimeframeTestPass = d.TimeframeTestPass == 1,
                                    TimeframeType = d.TimeframeTypeId
                                });
                            }
                            lactx.SaveChanges();
                            trans.Commit();
                        }
                        catch
                        {
                            trans.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetBankruptcyReply GetBankruptcy(int loanid)
        {
            var ret = new GetBankruptcyReply();

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    var temp = lactx.LoanBankruptcy.Where(x => x.LoanId == loanid).Select(x => new Bankruptcy
                    {
                        AttorneyProvidedLiftDate = x.AttorneyProvidedLiftDate.GetSafeString(),
                        BankruptcyCaseNumber = x.BankruptcyCaseNumber.GetSafeString(),
                        BankruptcyCompletionDate = x.BankruptcyCompletionDate.GetSafeString(),
                        BankruptcyCompletionDays = x.BankruptcyCompletionDays ?? 0,
                        BankruptcyType = x.BankruptcyType,
                        ClearanceDate = x.ClearanceDate.GetSafeString(),
                        ClosedSameDayAsDischarge = x.ClosedSameDayAsDischarge ?? false ? 1 : 0,
                        DelaysAcceptable = x.DelaysAcceptable ?? false ? 1 : 0,
                        DischargeDate = x.DischargeDate.GetSafeString(),
                        DismissalDate = x.DismissalDate.GetSafeString(),
                        FiledDate = x.FiledDate.GetSafeString(),
                        FirstActionDate = x.FirstActionDate.GetSafeString(),
                        FirstUnacceptableDelay = x.FirstUnacceptableDelay.GetSafeString(),
                        LoanBKExtensionId = x.LoanBkextensionId,
                        MotionForReliefDate = x.MotionForReliefDate.GetSafeString(),
                        OrderGrantingMFR = x.OrderGrantingMfr ?? false ? 1 : 0,
                        RuleWaived = x._4001ruleWaived ?? false ? 1 : 0,
                        Ruling = x.Ruling ?? 0,
                        LoanId = x.LoanId,
                        UIAct = ""
                    }).ToList();

                    ret.Bankruptcys.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public string SaveBankruptcy(Bankruptcy data)
        {
            var ret = Constant.Success;
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    if (data.LoanBKExtensionId > 0)
                    {
                        var cpa = lactx.LoanBankruptcy.Where(x => x.LoanBkextensionId == data.LoanBKExtensionId).Single();
                        if (data.UIAct == "Delete")
                        {
                            lactx.LoanBankruptcy.Remove(cpa);
                        }
                        else
                        {
                            cpa.AttorneyProvidedLiftDate = Convert.ToDateTime(data.AttorneyProvidedLiftDate.GetSafeDateString());
                            cpa.BankruptcyCaseNumber = data.BankruptcyCaseNumber;
                            cpa.BankruptcyCompletionDate = Convert.ToDateTime(data.BankruptcyCompletionDate.GetSafeDateString());
                            cpa.BankruptcyCompletionDays = data.BankruptcyCompletionDays;
                            cpa.BankruptcyType = data.BankruptcyType;
                            cpa.ClearanceDate = Convert.ToDateTime(data.ClearanceDate.GetSafeDateString());
                            cpa.ClosedSameDayAsDischarge = data.ClosedSameDayAsDischarge == 1;
                            cpa.DelaysAcceptable = data.DelaysAcceptable == 1;
                            cpa.DischargeDate = Convert.ToDateTime(data.DischargeDate.GetSafeDateString());
                            cpa.DismissalDate = Convert.ToDateTime(data.DismissalDate.GetSafeDateString());
                            cpa.FiledDate = Convert.ToDateTime(data.FiledDate.GetSafeDateString());
                            cpa.FirstActionDate = Convert.ToDateTime(data.FirstActionDate.GetSafeDateString());
                            cpa.FirstUnacceptableDelay = Convert.ToDateTime(data.FirstUnacceptableDelay.GetSafeDateString());
                            cpa.MotionForReliefDate = Convert.ToDateTime(data.MotionForReliefDate.GetSafeDateString());
                            cpa.OrderGrantingMfr = data.OrderGrantingMFR == 1;
                            cpa.Ruling = data.Ruling;
                            cpa._4001ruleWaived = data.RuleWaived == 1;
                            cpa.ModifiedBy = _userid;
                            cpa.ModifiedDate = DateTime.Now;
                        }
                    }
                    else
                    {
                        lactx.LoanBankruptcy.Add(new LoanBankruptcy
                        {
                            AddedBy = _userid,
                            AddedDate = DateTime.Now,
                            LoanId = data.LoanId,
                            ModifiedBy = _userid,
                            ModifiedDate = DateTime.Now,
                            AttorneyProvidedLiftDate = Convert.ToDateTime(data.AttorneyProvidedLiftDate.GetSafeDateString()),
                            BankruptcyCaseNumber = data.BankruptcyCaseNumber,
                            BankruptcyCompletionDate = Convert.ToDateTime(data.BankruptcyCompletionDate.GetSafeDateString()),
                            BankruptcyCompletionDays = data.BankruptcyCompletionDays,
                            BankruptcyType = data.BankruptcyType,
                            ClearanceDate = Convert.ToDateTime(data.ClearanceDate.GetSafeDateString()),
                            ClosedSameDayAsDischarge = data.ClosedSameDayAsDischarge == 1,
                            DelaysAcceptable = data.DelaysAcceptable == 1,
                            DischargeDate = Convert.ToDateTime(data.DischargeDate.GetSafeDateString()),
                            DismissalDate = Convert.ToDateTime(data.DismissalDate.GetSafeDateString()),
                            FiledDate = Convert.ToDateTime(data.FiledDate.GetSafeDateString()),
                            FirstActionDate = Convert.ToDateTime(data.FirstActionDate.GetSafeDateString()),
                            FirstUnacceptableDelay = Convert.ToDateTime(data.FirstUnacceptableDelay.GetSafeDateString()),
                            MotionForReliefDate = Convert.ToDateTime(data.MotionForReliefDate.GetSafeDateString()),
                            OrderGrantingMfr = data.OrderGrantingMFR == 1,
                            Ruling = data.Ruling,
                            _4001ruleWaived = data.RuleWaived == 1,
                            LoanBkextensionId = data.LoanBKExtensionId

                        });
                    }
                    lactx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetLossMitReply GetLossMit(int loanid)
        {
            var ret = new GetLossMitReply();

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    var temp = lactx.LoanLossMit.Where(x => x.LoanId == loanid).Select(x => new LossMit
                    {
                        LoanLMExtensionId = x.LoanLmextensionId,
                        LoanId = x.LoanId,
                        ApprovalToParticipateDate = x.ApprovalToParticipateDate.GetSafeString(),
                        ApprovalToParticipateExpirationDate = x.ApprovalToParticipateExpirationDate.GetSafeString(),
                        ApprovedContractDate = x.ApprovedContractDate.GetSafeString(),
                        ApprovedVariance = x.ApprovedVariance.GetIntValue(),
                        BorrowerVacatedDate = x.BorrowerVacatedDate.GetSafeString(),
                        DecisionDate = x.DecisionDate.GetSafeString(),
                        DocumentsAvailable = x.DocumentsAvailable.GetIntValue(),
                        DocumentSignDate = x.DocumentSignDate.GetSafeString(),
                        FirstActionDate = x.FirstActionDate.GetSafeString(),
                        FirstMissedPaymentDueDate = x.FirstMissedPaymentDueDate.GetSafeString(),
                        FirstPlanPaymentDueDate = x.FirstPlanPaymentDueDate.GetSafeString(),
                        LastPlanPaymentAppliedDate = x.LastPlanPaymentAppliedDate.GetSafeString(),
                        LastPlanPaymentDueDate = x.LastPlanPaymentDueDate.GetSafeString(),
                        LossMitigationType = x.LossMitigationType,
                        NextPlanPaymentDueDate = x.NextPlanPaymentDueDate.GetSafeString(),
                        OptOutDate = x.OptOutDate.GetSafeString(),
                        PlanComplete = x.PlanComplete.GetIntValue(),
                        PlanIncludesSFBExpiration = x.PlanIncludesSfbexpiration.GetIntValue(),
                        PlanPaymentsSuspendedReduced = x.PlanPaymentsSuspendedReduced ?? 0,
                        SFBExpirationDate = x.SfbexpirationDate.GetSafeString(),
                        SFDMSReportDate = x.SfdmsreportDate.GetSafeString(),
                        SFDMSReported = x.Sfdmsreported.GetIntValue(),
                        VarianceExtensionDate = x.VarianceExtensionDate.GetSafeString(),
                        VarianceRequestDate = x.VarianceRequestDate.GetSafeString(),
                        UIAct = ""
                    }).ToList();

                    ret.LossMits.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public string SaveLossMit(LossMit data)
        {
            var ret = Constant.Success;
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    if (data.LoanLMExtensionId > 0)
                    {
                        var cpa = lactx.LoanLossMit.Where(x => x.LoanLmextensionId == data.LoanLMExtensionId).Single();
                        if (data.UIAct == "Delete")
                        {
                            lactx.LoanLossMit.Remove(cpa);
                        }
                        else
                        {
                            cpa.ApprovalToParticipateDate = Convert.ToDateTime(data.ApprovalToParticipateDate.GetSafeDateString());
                            cpa.ApprovalToParticipateExpirationDate = Convert.ToDateTime(data.ApprovalToParticipateExpirationDate.GetSafeDateString());
                            cpa.ApprovedContractDate = Convert.ToDateTime(data.ApprovedContractDate.GetSafeDateString());
                            cpa.ApprovedVariance = data.ApprovedVariance.GetBoolValue();
                            cpa.BorrowerVacatedDate = Convert.ToDateTime(data.BorrowerVacatedDate.GetSafeDateString());
                            cpa.DecisionDate = Convert.ToDateTime(data.DecisionDate.GetSafeDateString());
                            cpa.DocumentsAvailable = data.DocumentsAvailable.GetBoolValue();
                            cpa.DocumentSignDate = Convert.ToDateTime(data.DocumentSignDate.GetSafeDateString());
                            cpa.FirstActionDate = Convert.ToDateTime(data.FirstActionDate.GetSafeDateString());
                            cpa.FirstMissedPaymentDueDate = Convert.ToDateTime(data.FirstMissedPaymentDueDate.GetSafeDateString());
                            cpa.FirstPlanPaymentDueDate = Convert.ToDateTime(data.FirstPlanPaymentDueDate.GetSafeDateString());
                            cpa.LastPlanPaymentAppliedDate = Convert.ToDateTime(data.LastPlanPaymentAppliedDate.GetSafeDateString());
                            cpa.LastPlanPaymentDueDate = Convert.ToDateTime(data.LastPlanPaymentDueDate.GetSafeDateString());
                            cpa.LossMitigationType = data.LossMitigationType;
                            cpa.NextPlanPaymentDueDate = Convert.ToDateTime(data.NextPlanPaymentDueDate.GetSafeDateString());
                            cpa.OptOutDate = Convert.ToDateTime(data.OptOutDate.GetSafeDateString());
                            cpa.PlanComplete = data.PlanComplete.GetBoolValue();
                            cpa.PlanIncludesSfbexpiration = data.PlanIncludesSFBExpiration.GetBoolValue();
                            cpa.PlanPaymentsSuspendedReduced = data.PlanPaymentsSuspendedReduced;
                            cpa.SfbexpirationDate = Convert.ToDateTime(data.SFBExpirationDate.GetSafeDateString());
                            cpa.SfdmsreportDate = Convert.ToDateTime(data.SFDMSReportDate.GetSafeDateString());
                            cpa.Sfdmsreported = data.SFDMSReported.GetBoolValue();
                            cpa.VarianceExtensionDate = Convert.ToDateTime(data.VarianceExtensionDate.GetSafeDateString());
                            cpa.VarianceRequestDate = Convert.ToDateTime(data.VarianceRequestDate.GetSafeDateString());
                            cpa.ModifiedBy = _userid;
                            cpa.ModifiedDate = DateTime.Now;
                        }
                    }
                    else
                    {
                        lactx.LoanLossMit.Add(new LoanLossMit
                        {
                            ApprovalToParticipateDate = Convert.ToDateTime(data.ApprovalToParticipateDate.GetSafeDateString()),
                            ApprovalToParticipateExpirationDate = Convert.ToDateTime(data.ApprovalToParticipateExpirationDate.GetSafeDateString()),
                            ApprovedContractDate = Convert.ToDateTime(data.ApprovedContractDate.GetSafeDateString()),
                            ApprovedVariance = data.ApprovedVariance.GetBoolValue(),
                            BorrowerVacatedDate = Convert.ToDateTime(data.BorrowerVacatedDate.GetSafeDateString()),
                            DecisionDate = Convert.ToDateTime(data.DecisionDate.GetSafeDateString()),
                            DocumentsAvailable = data.DocumentsAvailable.GetBoolValue(),
                            DocumentSignDate = Convert.ToDateTime(data.DocumentSignDate.GetSafeDateString()),
                            FirstActionDate = Convert.ToDateTime(data.FirstActionDate.GetSafeDateString()),
                            FirstMissedPaymentDueDate = Convert.ToDateTime(data.FirstMissedPaymentDueDate.GetSafeDateString()),
                            FirstPlanPaymentDueDate = Convert.ToDateTime(data.FirstPlanPaymentDueDate.GetSafeDateString()),
                            LastPlanPaymentAppliedDate = Convert.ToDateTime(data.LastPlanPaymentAppliedDate.GetSafeDateString()),
                            LastPlanPaymentDueDate = Convert.ToDateTime(data.LastPlanPaymentDueDate.GetSafeDateString()),
                            LossMitigationType = data.LossMitigationType,
                            NextPlanPaymentDueDate = Convert.ToDateTime(data.NextPlanPaymentDueDate.GetSafeDateString()),
                            OptOutDate = Convert.ToDateTime(data.OptOutDate.GetSafeDateString()),
                            PlanComplete = data.PlanComplete.GetBoolValue(),
                            PlanIncludesSfbexpiration = data.PlanIncludesSFBExpiration.GetBoolValue(),
                            PlanPaymentsSuspendedReduced = data.PlanPaymentsSuspendedReduced,
                            SfbexpirationDate = Convert.ToDateTime(data.SFBExpirationDate.GetSafeDateString()),
                            SfdmsreportDate = Convert.ToDateTime(data.SFDMSReportDate.GetSafeDateString()),
                            Sfdmsreported = data.SFDMSReported.GetBoolValue(),
                            VarianceExtensionDate = Convert.ToDateTime(data.VarianceExtensionDate.GetSafeDateString()),
                            VarianceRequestDate = Convert.ToDateTime(data.VarianceRequestDate.GetSafeDateString()),
                            ModifiedBy = _userid,
                            ModifiedDate = DateTime.Now,
                            AddedBy = _userid,
                            AddedDate = DateTime.Now,
                            LoanId = data.LoanId,
                            LoanLmextensionId = 0


                        });
                    }
                    lactx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetEvictionReply GetEviction(int loanid)
        {
            var ret = new GetEvictionReply();

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    var temp = lactx.LoanEviction.Where(x => x.LoanId == loanid).Select(x => new Eviction
                    {
                        LoanEvictionId = x.LoanEvictionId,
                        LoanId = x.LoanId,
                        CloseAndBillDate = x.CloseAndBillDate.GetSafeString(),
                        EvictionFirstLegalDate = x.EvictionFirstLegalDate.GetSafeString(),
                        ReoccupancyDate = x.ReoccupancyDate.GetSafeString(),
                        UnacceptableDelayStartDate = x.UnacceptableDelayStartDate.GetSafeString(),
                        VacancyDate = x.VacancyDate.GetSafeString(),
                        VacancyType = x.VacancyType ?? 0,
                        UIAct = ""
                    }).ToList();

                    ret.Evictions.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public string SaveEviction(Eviction data)
        {
            var ret = Constant.Success;
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    if (data.LoanEvictionId > 0)
                    {
                        var cpa = lactx.LoanEviction.Where(x => x.LoanEvictionId == data.LoanEvictionId).Single();
                        if (data.UIAct == "Delete")
                        {
                            lactx.LoanEviction.Remove(cpa);
                        }
                        else
                        {
                            cpa.CloseAndBillDate = Convert.ToDateTime(data.CloseAndBillDate.GetSafeDateString());
                            cpa.EvictionFirstLegalDate = Convert.ToDateTime(data.EvictionFirstLegalDate.GetSafeDateString());
                            cpa.ReoccupancyDate = Convert.ToDateTime(data.ReoccupancyDate.GetSafeDateString());
                            cpa.UnacceptableDelayStartDate = Convert.ToDateTime(data.UnacceptableDelayStartDate.GetSafeDateString());
                            cpa.VacancyDate = Convert.ToDateTime(data.VacancyDate.GetSafeDateString());
                            cpa.VacancyType = data.VacancyType;
                            cpa.ModifiedBy = _userid;
                            cpa.ModifiedDate = DateTime.Now;
                        }
                    }
                    else
                    {
                        lactx.LoanEviction.Add(new LoanEviction
                        {
                            CloseAndBillDate = Convert.ToDateTime(data.CloseAndBillDate.GetSafeDateString()),
                            EvictionFirstLegalDate = Convert.ToDateTime(data.EvictionFirstLegalDate.GetSafeDateString()),
                            ReoccupancyDate = Convert.ToDateTime(data.ReoccupancyDate.GetSafeDateString()),
                            UnacceptableDelayStartDate = Convert.ToDateTime(data.UnacceptableDelayStartDate.GetSafeDateString()),
                            VacancyDate = Convert.ToDateTime(data.VacancyDate.GetSafeDateString()),
                            VacancyType = data.VacancyType,
                            ModifiedBy = _userid,
                            ModifiedDate = DateTime.Now,
                            AddedBy = _userid,
                            AddedDate = DateTime.Now,
                            LoanId = data.LoanId,
                            LoanEvictionId = 0
                        });
                    }
                    lactx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetDelayReply GetDelay(int loanid)
        {
            var ret = new GetDelayReply();

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    var temp = lactx.LoanDelay.Where(x => x.LoanId == loanid).Select(x => new Delay
                    {
                        LoanDelayId = x.LoanDelayId,
                        LoanId = x.LoanId,
                        DelayAcceptable = x.DelayAcceptable.GetIntValue(),
                        DelayEndDate = x.DelayEndDate.GetSafeString(),
                        DelayReason = x.DelayReason.GetSafeString(),
                        DelayStartDate = x.DelayStartDate.GetSafeString(),
                        DelayType = x.DelayType,
                        UIAct = ""
                    }).ToList();

                    ret.Delays.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public string SaveDelay(Delay data)
        {
            var ret = Constant.Success;
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    if (data.LoanDelayId > 0)
                    {
                        var cpa = lactx.LoanDelay.Where(x => x.LoanDelayId == data.LoanDelayId).Single();
                        if (data.UIAct == "Delete")
                        {
                            lactx.LoanDelay.Remove(cpa);
                        }
                        else
                        {
                            cpa.DelayAcceptable = data.DelayAcceptable.GetBoolValue();
                            cpa.DelayEndDate = Convert.ToDateTime(data.DelayEndDate.GetSafeDateString());
                            cpa.DelayReason = data.DelayReason;
                            cpa.DelayStartDate = Convert.ToDateTime(data.DelayStartDate.GetSafeDateString());
                            cpa.DelayType = data.DelayType;
                            cpa.ModifiedBy = _userid;
                            cpa.ModifiedDate = DateTime.Now;
                        }
                    }
                    else
                    {
                        lactx.LoanDelay.Add(new LoanDelay
                        {
                            DelayAcceptable = data.DelayAcceptable.GetBoolValue(),
                            DelayEndDate = Convert.ToDateTime(data.DelayEndDate.GetSafeDateString()),
                            DelayReason = data.DelayReason,
                            DelayStartDate = Convert.ToDateTime(data.DelayStartDate.GetSafeDateString()),
                            DelayType = data.DelayType,
                            ModifiedBy = _userid,
                            ModifiedDate = DateTime.Now,
                            AddedBy = _userid,
                            AddedDate = DateTime.Now,
                            LoanId = data.LoanId,
                            LoanDelayId = 0
                        });
                    }
                    lactx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public ReconPartA GetReconPartA(int loanid)
        {
            var ret = new ReconPartA();

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    ret = lactx.VwLoanReconPartA.Where(x => x.LoanId == loanid).Select(x => new ReconPartA
                    {
                        LoanReconPartAId = x.LoanReconPartAid ?? 0,
                        LoanId = x.LoanId,
                        FiledExpenseAmount = (double)x.FiledExpenseAmount.GetSafeValue(),
                        InterestCurtAmount = (double)x.InterestCurtAmount.GetSafeValue(),
                        //    InterestCurtRespParty = x.InterestCurtRespParty ?? 0,
                        LoanComment = x.LoanComment.GetSafeString(),
                        SettledExpenseAmount = (double)x.SettledExpenseAmount.GetSafeValue(),
                        SettledInterestAmount = (double)x.SettledInterestAmount.GetSafeValue(),
                        SettledInterestCurtDate = x.SettledInterestCurtDate.GetSafeString(),
                        SettledUPB = (double)x.SettledUpb.GetSafeValue(),
                        UnpaidPrincipalBalance = (double)x.UnpaidPrincipalBalance.GetSafeValue(),
                        UpdatedInterestCurtDate = x.UpdatedInterestCurtDate.GetSafeString(),
                        UpdatedUPB = (double)x.UpdatedUpb.GetSafeValue(),
                        UpdateExpenseAmount = (double)x.UpdateExpenseAmount.GetSafeValue(),
                        UpdateInterestAmount = (double)x.UpdateInterestAmount.GetSafeValue(),
                        ExpenseCurtDate = x.ExpenseCurtDate.GetSafeString(),
                        InterestCurtRespParty = x.InterestCurtRespParty ?? 0
                    }).SingleOrDefault();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public ReconPartB GetReconPartB(int loanid)
        {
            var ret = new ReconPartB();

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    ret = lactx.VwLoanReconPartB.Where(x => x.LoanId == loanid).Select(x => new ReconPartB
                    {
                        LoanReconPartBId = x.LoanReconPartBid ?? 0,
                        LoanId = x.LoanId,
                        ReconAppliedFunds = (double)x.ReconAppliedFunds.GetSafeValue(),
                        ReconAttorneyCostsUL = (double)x.ReconAttorneyCostsUl.GetSafeValue(),
                        ReconAttorneyFeesUL = (double)x.ReconAttorneyFeesUl.GetSafeValue(),
                        ReconBankruptcyFeesUL = (double)x.ReconBankruptcyFeesUl.GetSafeValue(),
                        ReconControllableExpense = (double)x.ReconControllableExpense.GetSafeValue(),
                        ReconControllableInterest = (double)x.ReconControllableInterest.GetSafeValue(),
                        ReconCorporateBalance = (double)x.ReconCorporateBalance.GetSafeValue(),
                        ReconCreditAfterClaim = (double)x.ReconCreditAfterClaim.GetSafeValue(),
                        ReconEscrowBalance = (double)x.ReconEscrowBalance.GetSafeValue(),
                        ReconFinalProceeds = (double)x.ReconFinalProceeds.GetSafeValue(),
                        ReconInterest = (double)x.ReconInterest.GetSafeValue(),
                        ReconInterestDifferentialUL = (double)x.ReconInterestDifferentialUl.GetSafeValue(),
                        ReconLiquidationProceeds = (double)x.ReconLiquidationProceeds.GetSafeValue(),
                        ReconPaidAfterClaim = (double)x.ReconPaidAfterClaim.GetSafeValue(),
                        ReconPartialProceeds = (double)x.ReconPartialProceeds.GetSafeValue(),
                        ReconRestrictedBalance = (double)x.ReconRestrictedBalance.GetSafeValue(),
                        ReconSuspenseBalance = (double)x.ReconSuspenseBalance.GetSafeValue(),
                        ReconTwoMonthsInterestUL = (double)x.ReconTwoMonthsInterestUl.GetSafeValue(),
                        ReconUPB = (double)x.ReconUpb.GetSafeValue(),
                        CurrenSystemBalance = (double)x.CurrentSystemBalance.GetSafeValue(),
                        InterestCurtAmount = (double)x.InterestCurtAmount.GetSafeValue(),
                        TotalInterestPaid = (double)x.TotalInterestPaid.GetSafeValue()

                    }).SingleOrDefault();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public string SaveReconPartA(ReconPartA data)
        {
            var ret = Constant.Success;
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    if (data.LoanReconPartAId > 0)
                    {
                        var cpa = lactx.LoanReconPartA.Where(x => x.LoanReconPartAid == data.LoanReconPartAId).Single();
                        cpa.LoanComment = data.LoanComment;
                        cpa.UpdateInterestAmount = Convert.ToDecimal(data.UpdateInterestAmount);
                        cpa.InterestCurtAmount = Convert.ToDecimal(data.InterestCurtAmount);
                        cpa.InterestCurtRespParty = data.InterestCurtRespParty;
                        cpa.UpdatedInterestCurtDate = Convert.ToDateTime(data.UpdatedInterestCurtDate.GetSafeDateString());
                        cpa.ExpenseCurtDate = Convert.ToDateTime(data.ExpenseCurtDate.GetSafeDateString());
                        cpa.ExpenseCurtOverrideDate = null;
                        cpa.InterestCurtOverrideDate = null;
                        cpa.ModifiedBy = _userid;
                        cpa.ModifiedDate = DateTime.Now;
                    }
                    else
                    {
                        lactx.LoanReconPartA.Add(new LoanReconPartA
                        {
                            LoanId = data.LoanId,
                            LoanReconPartAid = 0,
                            AddedBy = _userid,
                            AddedDate = DateTime.Now,
                            ModifiedBy = _userid,
                            ModifiedDate = DateTime.Now,
                            LoanComment = data.LoanComment,
                            UpdateInterestAmount = Convert.ToDecimal(data.UpdateInterestAmount),
                            InterestCurtAmount = Convert.ToDecimal(data.InterestCurtAmount),
                            InterestCurtRespParty = data.InterestCurtRespParty,
                            UpdatedInterestCurtDate = Convert.ToDateTime(data.UpdatedInterestCurtDate.GetSafeDateString()),
                            ExpenseCurtDate = Convert.ToDateTime(data.ExpenseCurtDate.GetSafeDateString()),
                            ExpenseCurtOverrideDate = null,
                            InterestCurtOverrideDate = null
                        });
                    }
                    lactx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public string SaveReconPartB(ReconPartB data)
        {
            var ret = Constant.Success;
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    if (data.LoanReconPartBId > 0)
                    {
                        var cpa = lactx.LoanReconPartB.Where(x => x.LoanReconPartBid == data.LoanReconPartBId).Single();
                        cpa.ReconCorporateBalance = Convert.ToDecimal(data.ReconCorporateBalance);
                        cpa.ReconEscrowBalance = Convert.ToDecimal(data.ReconEscrowBalance);
                        cpa.ReconInterestDifferentialUl = Convert.ToDecimal(data.ReconInterestDifferentialUL);
                        cpa.ReconLiquidationProceeds = Convert.ToDecimal(data.ReconLiquidationProceeds);
                        cpa.ReconRestrictedBalance = Convert.ToDecimal(data.ReconRestrictedBalance);
                        cpa.ReconSuspenseBalance = Convert.ToDecimal(data.ReconSuspenseBalance);
                        cpa.CurrentSystemBalance = Convert.ToDecimal(data.CurrenSystemBalance);
                        cpa.ModifiedBy = _userid;
                        cpa.ModifiedDate = DateTime.Now;
                    }
                    else
                    {
                        lactx.LoanReconPartB.Add(new LoanReconPartB
                        {
                            AddedBy = _userid,
                            AddedDate = DateTime.Now,
                            ModifiedBy = _userid,
                            ModifiedDate = DateTime.Now,
                            LoanId = data.LoanId,
                            LoanReconPartBid = 0,
                            ReconCorporateBalance = Convert.ToDecimal(data.ReconCorporateBalance),
                            ReconEscrowBalance = Convert.ToDecimal(data.ReconEscrowBalance),
                            ReconInterestDifferentialUl = Convert.ToDecimal(data.ReconInterestDifferentialUL),
                            ReconLiquidationProceeds = Convert.ToDecimal(data.ReconLiquidationProceeds),
                            ReconRestrictedBalance = Convert.ToDecimal(data.ReconRestrictedBalance),
                            ReconSuspenseBalance = Convert.ToDecimal(data.ReconSuspenseBalance),
                            CurrentSystemBalance = Convert.ToDecimal(data.CurrenSystemBalance)
                        });
                    }
                    lactx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public ReconSupplemental GetSupplemental(int loanid)
        {
            var ret = new ReconSupplemental();

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    ret = lactx.VwLoanSupplemental.Where(x => x.LoanId == loanid).Select(x => new ReconSupplemental
                    {
                        LoanId = x.LoanId,
                        PartARecoveryAmount = (double)x.PartArecoveryAmount.GetSafeValue(),
                        PartARecoveryOverrideAmount = (double)x.PartArecoveryOverrideAmount.GetSafeValue(),
                        PartARefundAmount = (double)x.PartArefundAmount.GetSafeValue(),
                        PartARefundOverrideAmount = (double)x.PartArefundOverrideAmount.GetSafeValue(),
                        PartBRecoveryAmount = (double)x.PartBrecoveryAmount.GetSafeValue(),
                        PartBRecoveryOverrideAmount = (double)x.PartBrecoveryOverrideAmount.GetSafeValue(),
                        PartBRefundAmount = (double)x.PartBrefundAmount.GetSafeValue(),
                        PartBRefundOverrideAmount = (double)x.PartBrecoveryOverrideAmount.GetSafeValue(),
                        RecoveryAnalystId = x.RecoveryAnalystId ?? 0,
                        RefundAnalystId = x.RefundAnalystId ?? 0
                    }).SingleOrDefault();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public string SaveSupplemental(ReconSupplemental data)
        {
            var ret = Constant.Success;
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    using (var trans = lactx.Database.BeginTransaction())
                    {
                        try
                        {
                            var supptype = lactx.LkpSupplementalType.ToList();
                            var supppart = lactx.LkpSupplementalPart.ToList();

                            var supps = lactx.LoanSupplemental.Where(x => x.LoanId == data.LoanId).ToList();
                            var suppanalyst = lactx.LoanSupplementalAnalyst.Where(x => x.LoanId == data.LoanId).ToList();

                            lactx.LoanSupplementalAnalyst.RemoveRange(suppanalyst);
                            lactx.LoanSupplemental.RemoveRange(supps);

                            if (data.PartARecoveryAmount > 0 || data.PartARecoveryOverrideAmount > 0)
                            {
                                lactx.LoanSupplemental.Add(new LoanSupplemental
                                {
                                    LoanId = data.LoanId,
                                    LoanSuppId = 0,
                                    AddedBy = _userid,
                                    AddedDate = DateTime.Now,
                                    ModifiedBy = _userid,
                                    ModifiedDate = DateTime.Now,
                                    SupplementalType = supptype.Where(x => x.LkpTypeCatName == "Recovery" && x.LkpTypeName == "SupplementalType").Select(x => x.LkpTypeCatId).Single(),
                                    SuppAmtCalculated = Convert.ToDecimal(data.PartARecoveryAmount),
                                    SuppAmtOverride = Convert.ToDecimal(data.PartARecoveryOverrideAmount),
                                    SupplementalPart = supppart.Where(x => x.LkpTypeCatName == "Part A" && x.LkpTypeName == "SupplementalPart").Select(x => x.LkpTypeCatId).Single()
                                });
                            }
                            if (data.PartBRecoveryAmount > 0 || data.PartBRecoveryOverrideAmount > 0)
                            {
                                lactx.LoanSupplemental.Add(new LoanSupplemental
                                {
                                    LoanId = data.LoanId,
                                    LoanSuppId = 0,
                                    AddedBy = _userid,
                                    AddedDate = DateTime.Now,
                                    ModifiedBy = _userid,
                                    ModifiedDate = DateTime.Now,
                                    SupplementalType = supptype.Where(x => x.LkpTypeCatName == "Recovery" && x.LkpTypeName == "SupplementalType").Select(x => x.LkpTypeCatId).Single(),
                                    SuppAmtCalculated = Convert.ToDecimal(data.PartARecoveryAmount),
                                    SuppAmtOverride = Convert.ToDecimal(data.PartARecoveryOverrideAmount),
                                    SupplementalPart = supppart.Where(x => x.LkpTypeCatName == "Part B-E" && x.LkpTypeName == "SupplementalPart").Select(x => x.LkpTypeCatId).Single()
                                });
                            }
                            if (data.PartARefundAmount > 0 || data.PartARefundOverrideAmount > 0)
                            {
                                lactx.LoanSupplemental.Add(new LoanSupplemental
                                {
                                    LoanId = data.LoanId,
                                    LoanSuppId = 0,
                                    AddedBy = _userid,
                                    AddedDate = DateTime.Now,
                                    ModifiedBy = _userid,
                                    ModifiedDate = DateTime.Now,
                                    SupplementalType = supptype.Where(x => x.LkpTypeCatName == "Refund" && x.LkpTypeName == "SupplementalType").Select(x => x.LkpTypeCatId).Single(),
                                    SuppAmtCalculated = Convert.ToDecimal(data.PartARecoveryAmount),
                                    SuppAmtOverride = Convert.ToDecimal(data.PartARecoveryOverrideAmount),
                                    SupplementalPart = supppart.Where(x => x.LkpTypeCatName == "Part A" && x.LkpTypeName == "SupplementalPart").Select(x => x.LkpTypeCatId).Single()
                                });
                            }
                            if (data.PartBRefundAmount > 0 || data.PartBRefundOverrideAmount > 0)
                            {
                                lactx.LoanSupplemental.Add(new LoanSupplemental
                                {
                                    LoanId = data.LoanId,
                                    LoanSuppId = 0,
                                    AddedBy = _userid,
                                    AddedDate = DateTime.Now,
                                    ModifiedBy = _userid,
                                    ModifiedDate = DateTime.Now,
                                    SupplementalType = supptype.Where(x => x.LkpTypeCatName == "Refund" && x.LkpTypeName == "SupplementalType").Select(x => x.LkpTypeCatId).Single(),
                                    SuppAmtCalculated = Convert.ToDecimal(data.PartARecoveryAmount),
                                    SuppAmtOverride = Convert.ToDecimal(data.PartARecoveryOverrideAmount),
                                    SupplementalPart = supppart.Where(x => x.LkpTypeCatName == "Part B-E" && x.LkpTypeName == "SupplementalPart").Select(x => x.LkpTypeCatId).Single()
                                });
                            }
                            if (data.RecoveryAnalystId > 0 || data.RefundAnalystId > 0)
                            {
                                lactx.LoanSupplementalAnalyst.Add(new LoanSupplementalAnalyst
                                {
                                    LoanId = data.LoanId,
                                    RecoveryAnalystId = data.RecoveryAnalystId,
                                    RefundAnalystId = data.RefundAnalystId
                                });
                            }
                            lactx.SaveChanges();
                            trans.Commit();
                        }
                        catch (Exception)
                        {
                            trans.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public ServicerAccountBalancing GetServicerAccountBalancing(int loanid)
        {
            var ret = new ServicerAccountBalancing();

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    ret = lactx.VwServicerAccountBalancing.Where(x => x.LoanId == loanid).Select(x => new ServicerAccountBalancing
                    {
                        LoanId = x.LoanId,
                        CorporateDifference = (double)x.CorporateDifference.GetSafeValue(),
                        EscrowDifference = (double)x.EscrowDifference.GetSafeValue(),
                        HUD1Difference = (double)x.Hud1difference.GetSafeValue(),
                        RestricktedEscrowDifference = (double)x.RestricktedEscrowDifference.GetSafeValue(),
                        SuspenseDifference = (double)x.SuspenseDifference.GetSafeValue()
                    }).SingleOrDefault();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetSupplementalRecoveryReply GetSuppRecoveryRefund(int loanid, bool recovery = true)
        {
            var ret = new GetSupplementalRecoveryReply();

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    if (recovery)
                    {
                        var temp = lactx.VwRecommendedRecovery.Where(x => x.LoanId == loanid).Select(x => new SupplementalRecovery
                        {
                            LoanId = x.LoanId,
                            ClaimAmount = (double)x.ClaimAmount.GetSafeValue(),
                            DisbursedDate = x.DisbursedDate.GetSafeString(),
                            LkpTypeCatName = x.LkpTypeCatName.GetSafeString(),
                            LkpTypeSubCatName = x.LkpTypeSubCatName.GetSafeString()
                        }).ToList();
                        ret.SupplementalRecoveries.AddRange(temp);
                    }
                    else
                    {
                        var temp = lactx.VwRecommendedRefund.Where(x => x.LoanId == loanid).Select(x => new SupplementalRecovery
                        {
                            LoanId = x.LoanId,
                            ClaimAmount = (double)x.ClaimAmount.GetSafeValue(),
                            DisbursedDate = x.DisbursedDate.GetSafeString(),
                            LkpTypeCatName = x.LkpTypeCatName.GetSafeString(),
                            LkpTypeSubCatName = x.LkpTypeSubCatName.GetSafeString()
                        }).ToList();
                        ret.SupplementalRecoveries.AddRange(temp);
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public SupplementalDetail GetSupplementalDetail(int loanid)
        {
            var ret = new SupplementalDetail();

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    ret = lactx.VwSupplementalDetail.Where(x => x.LoanId == loanid).Select(x => new SupplementalDetail
                    {
                        LoanId = x.LoanId,
                        HUDRecvdAmt = (double)x.HudrecvdAmt.GetSafeValue(),
                        HUDRecvdDate = x.HudrecvdDate.GetSafeString(),
                        RecoveryAmount = (double)x.RecoveryAmount.GetSafeValue(),
                        RecoveryFiled = x.RecoveryFiled.GetSafeString(),
                        RefundAmount = (double)x.RefundAmount.GetSafeValue(),
                        RefundFiled = x.RefundFiled.GetSafeString(),
                        SuppTrackingInfo = x.SuppTrackingInfo.GetSafeString()
                    }).SingleOrDefault();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public ClientSpecificSuppDetail GetClientSpecificSuppDetail(int loanid)
        {
            var ret = new ClientSpecificSuppDetail { LoanId = 0, Delievered = "", StepComplete = "", RCAComplete = "" };

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    var temp = lactx.ClientReqLoanTracking.Where(x => x.LoanId == loanid).ToList();
                    if (temp.Count > 0)
                    {
                        ret = new ClientSpecificSuppDetail
                        {
                            LoanId = loanid,
                            Delievered = temp.Where(x => x.ClientReqTrackId == 3).Select(x => x.ReqInfoDate).SingleOrDefault().GetSafeString(),
                            RCAComplete = temp.Where(x => x.ClientReqTrackId == 2).Select(x => x.ReqInfoDate).SingleOrDefault().GetSafeString(),
                            StepComplete = temp.Where(x => x.ClientReqTrackId == 1).Select(x => x.ReqInfoDate).SingleOrDefault().GetSafeString()
                        };
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public string SaveSupplementalDetail(SupplementalDetail data)
        {
            var ret = Constant.Success;
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    using (var trans = lactx.Database.BeginTransaction())
                    {
                        try
                        {
                            if (data.RecoveryFiled.Length > 0)
                            {
                                if (lactx.LoanMilestone.Any(x => x.LoanId == data.LoanId && x.MilestoneId == 23))
                                {
                                    var temp = lactx.LoanMilestone.Where(x => x.LoanId == data.LoanId && x.MilestoneId == 23).Single();
                                    temp.MilestoneDate = Convert.ToDateTime(data.RecoveryFiled.GetSafeDateString());
                                    temp.ModifiedBy = _userid;
                                    temp.ModifiedDate = DateTime.Now;
                                }
                                else
                                {
                                    lactx.LoanMilestone.Add(new LoanMilestone
                                    {
                                        LoanId = data.LoanId,
                                        ModifiedBy = _userid,
                                        ModifiedDate = DateTime.Now,
                                        AddedBy = _userid,
                                        AddedDate = DateTime.Now,
                                        MilestoneId = 23,
                                        MilestoneDate = Convert.ToDateTime(data.RecoveryFiled.GetSafeDateString())
                                    });
                                }
                            }
                            if (data.RefundFiled.Length > 0)
                            {
                                if (lactx.LoanMilestone.Any(x => x.LoanId == data.LoanId && x.MilestoneId == 19))
                                {
                                    var temp = lactx.LoanMilestone.Where(x => x.LoanId == data.LoanId && x.MilestoneId == 19).Single();
                                    temp.MilestoneDate = Convert.ToDateTime(data.RecoveryFiled.GetSafeDateString());
                                    temp.ModifiedBy = _userid;
                                    temp.ModifiedDate = DateTime.Now;
                                }
                                else
                                {
                                    lactx.LoanMilestone.Add(new LoanMilestone
                                    {
                                        LoanId = data.LoanId,
                                        ModifiedBy = _userid,
                                        ModifiedDate = DateTime.Now,
                                        AddedBy = _userid,
                                        AddedDate = DateTime.Now,
                                        MilestoneId = 19,
                                        MilestoneDate = Convert.ToDateTime(data.RecoveryFiled.GetSafeDateString())
                                    });
                                }
                            }
                            if (lactx.LoanSuppTracking.Any(x => x.LoanId == data.LoanId))
                            {
                                var temp = lactx.LoanSuppTracking.Where(x => x.LoanId == data.LoanId).Single();
                                temp.ModifiedBy = _userid;
                                temp.ModifiedDate = DateTime.Now;
                                temp.HudrecvdAmt = Convert.ToDecimal(data.HUDRecvdAmt);
                                temp.HudrecvdDate = Convert.ToDateTime(data.HUDRecvdDate.GetSafeDateString());
                                temp.SuppTrackingInfo = data.SuppTrackingInfo;
                                //temp.SupplementalType Not used field?
                            }
                            else
                            {
                                lactx.LoanSuppTracking.Add(new LoanSuppTracking
                                {
                                    LoanId = data.LoanId,
                                    LoanSuppTrackId = 0,
                                    AddedBy = _userid,
                                    AddedDate = DateTime.Now,
                                    ModifiedBy = _userid,
                                    ModifiedDate = DateTime.Now,
                                    HudrecvdAmt = Convert.ToDecimal(data.HUDRecvdAmt),
                                    HudrecvdDate = Convert.ToDateTime(data.HUDRecvdDate.GetSafeDateString()),
                                    SuppTrackingInfo = data.SuppTrackingInfo
                                });
                            }

                            lactx.SaveChanges();
                            trans.Commit();
                        }
                        catch (Exception)
                        {
                            trans.Rollback();
                            throw;
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public string SaveClientSpecificSuppDetail(ClientSpecificSuppDetail data)
        {
            var ret = Constant.Success;
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    using (var trans = lactx.Database.BeginTransaction())
                    {
                        try
                        {
                            if (lactx.ClientReqLoanTracking.Any(x => x.LoanId == data.LoanId && x.ClientReqTrackId == 1))
                            {
                                var temp = lactx.ClientReqLoanTracking.Where(x => x.LoanId == data.LoanId && x.ClientReqTrackId == 1).Single();
                                temp.ModifiedBy = _userid;
                                temp.ModifiedDate = DateTime.Now;
                                temp.ReqInfoDate = Convert.ToDateTime(data.StepComplete.GetSafeDateString());
                            }
                            else
                            {
                                lactx.ClientReqLoanTracking.Add(new ClientReqLoanTracking
                                {
                                    LoanId = data.LoanId,
                                    ReqLoanTrackId = 0,
                                    AddedBy = _userid,
                                    AddedDate = DateTime.Now,
                                    ModifiedBy = _userid,
                                    ModifiedDate = DateTime.Now,
                                    ReqInfoDate = Convert.ToDateTime(data.StepComplete.GetSafeDateString())
                                });
                            }
                            if (lactx.ClientReqLoanTracking.Any(x => x.LoanId == data.LoanId && x.ClientReqTrackId == 2))
                            {
                                var temp = lactx.ClientReqLoanTracking.Where(x => x.LoanId == data.LoanId && x.ClientReqTrackId == 2).Single();
                                temp.ModifiedBy = _userid;
                                temp.ModifiedDate = DateTime.Now;
                                temp.ReqInfoDate = Convert.ToDateTime(data.RCAComplete.GetSafeDateString());
                            }
                            else
                            {
                                lactx.ClientReqLoanTracking.Add(new ClientReqLoanTracking
                                {
                                    LoanId = data.LoanId,
                                    ReqLoanTrackId = 0,
                                    AddedBy = _userid,
                                    AddedDate = DateTime.Now,
                                    ModifiedBy = _userid,
                                    ModifiedDate = DateTime.Now,
                                    ReqInfoDate = Convert.ToDateTime(data.RCAComplete.GetSafeDateString())
                                });
                            }
                            if (lactx.ClientReqLoanTracking.Any(x => x.LoanId == data.LoanId && x.ClientReqTrackId == 3))
                            {
                                var temp = lactx.ClientReqLoanTracking.Where(x => x.LoanId == data.LoanId && x.ClientReqTrackId == 3).Single();
                                temp.ModifiedBy = _userid;
                                temp.ModifiedDate = DateTime.Now;
                                temp.ReqInfoDate = Convert.ToDateTime(data.Delievered.GetSafeDateString());
                            }
                            else
                            {
                                lactx.ClientReqLoanTracking.Add(new ClientReqLoanTracking
                                {
                                    LoanId = data.LoanId,
                                    ReqLoanTrackId = 0,
                                    AddedBy = _userid,
                                    AddedDate = DateTime.Now,
                                    ModifiedBy = _userid,
                                    ModifiedDate = DateTime.Now,
                                    ReqInfoDate = Convert.ToDateTime(data.Delievered.GetSafeDateString())
                                });
                            }
                            lactx.SaveChanges();
                            trans.Commit();
                        }
                        catch (Exception)
                        {
                            trans.Rollback();
                            throw;
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetPartBExpenseReplay GetPartBExpense(int loanid)
        {
            var ret = new GetPartBExpenseReplay();

            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    var temp = lactx.VwLoanExpense.Where(x => x.LoanId == loanid).Select(x => new PartBExpense
                    {
                        LoanId = x.LoanId,
                        LoanExpenseId = x.LoanExpenseId,
                        AdvanceFrom = x.AdvanceFrom,
                        ChargeOffAmount = (double)x.ChargeOffAmount.GetSafeValue(),
                        ChargeOffReason = x.ChargeOffReason ?? 0,
                        ClaimAmount = (double)x.ClaimAmount.GetSafeValue(),
                        DebentureInterestAmount = (double)x.DebentureInterestAmount.GetSafeValue(),
                        DisbursedAmount = (double)x.DisbursedAmount.GetSafeValue(),
                        DisbursedDate = x.DisbursedDate.GetSafeString(),
                        EstimatedRefundAmount = (double)x.EstimatedRefundAmount.GetSafeValue(),
                        ExpenseCategory = x.ExpenseCategory,
                        ExpenseSubCategory = x.ExpenseSubCategory ?? 0,
                        ExpenseSubCategoryName = x.LkpTypeSubCatName,
                        ExpenseDescription = x.ExpenseDescription.GetSafeValue(),
                        InvoiceNumber = x.InvoiceNumber.GetSafeString(),
                        PreviousDebentureInterest = (double)x.PreviousDebentureInterest.GetSafeValue(),
                        PreviousChargeOffAmount = (double)x.PreviousChargeOffAmount.GetSafeValue(),
                        PreviousClaimAmount = (double)x.PreviousClaimAmount.GetSafeValue(),
                        RecoveryAmount = (double)x.RecoveryAmount.GetSafeValue(),
                        RefundAmount = (double)x.RefundAmount.GetSafeValue(),
                        ResponsibleParty = x.ResponsibleParty ?? 0,
                        UncontrollableLossAmount = (double)x.UncontrollableLossAmount.GetSafeValue(),
                        UIAct = ""
                    }).ToList();
                    ret.PartBExpenses.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public string SavePartBExpense(PartBExpense data)
        {
            var ret = Constant.Success;
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    if (data.LoanExpenseId > 0)
                    {
                        var temp = lactx.LoanExpense.Where(x => x.LoanExpenseId == data.LoanExpenseId).Single();
                        if (data.UIAct == "Delete")
                        {
                            if (temp.ParentLoanExpenseId > 0)
                            {
                                var p = lactx.LoanExpense.Where(x => x.LoanExpenseId == temp.ParentLoanExpenseId).Single();
                                lactx.LoanExpense.Remove(temp);
                                lactx.LoanExpense.Remove(p);
                            }
                            else
                            {
                                lactx.LoanExpense.Remove(temp);
                            }
                        }
                        else
                        {
                            if ((temp.ParentLoanExpenseId == null || temp.ParentLoanExpenseId == 0)
                                && (temp.ClaimAmount != Convert.ToDecimal(data.ClaimAmount)
                                || temp.DebentureInterestAmount != Convert.ToDecimal(data.DebentureInterestAmount)
                                || temp.LossAmount != Convert.ToDecimal(data.ChargeOffAmount)))
                            {
                                lactx.LoanExpense.Add(new LoanExpense
                                {
                                    LoanId = data.LoanId,
                                    LoanExpenseId = 0,
                                    ParentLoanExpenseId = temp.LoanExpenseId,
                                    AddedBy = _userid,
                                    AddedDate = DateTime.Now,
                                    ModifiedBy = _userid,
                                    ModifiedDate = DateTime.Now,
                                    AdvanceFrom = data.AdvanceFrom,
                                    ChargeOffReason = data.ChargeOffReason,
                                    ClaimAmount = Convert.ToDecimal(data.ClaimAmount),
                                    DebentureInterestAmount = Convert.ToDecimal(data.DebentureInterestAmount),
                                    DisbursedAmount = Convert.ToDecimal(data.DisbursedAmount),
                                    DisbursedDate = Convert.ToDateTime(data.DisbursedDate.GetSafeDateString()),
                                    EstimatedRefundAmount = Convert.ToDecimal(data.EstimatedRefundAmount),
                                    ExpenseCategory = data.ExpenseCategory,
                                    ExpenseSubCategory = data.ExpenseSubCategory,
                                    ExpenseDescription = data.ExpenseDescription,
                                    InvoiceNumber = data.InvoiceNumber,
                                    LossAmount = Convert.ToDecimal(data.ChargeOffAmount),
                                    ResponsibleParty = data.ResponsibleParty
                                });

                                temp.ModifiedBy = _userid;
                                temp.ModifiedDate = DateTime.Now;
                                temp.ClaimAmount = Convert.ToDecimal(data.PreviousClaimAmount);
                                temp.LossAmount = Convert.ToDecimal(data.PreviousChargeOffAmount);
                                temp.DebentureInterestAmount = Convert.ToDecimal(data.PreviousDebentureInterest);
                            }
                            else
                            {
                                temp.ModifiedBy = _userid;
                                temp.ModifiedDate = DateTime.Now;
                                temp.AdvanceFrom = data.AdvanceFrom;
                                temp.ChargeOffReason = data.ChargeOffReason;
                                temp.ClaimAmount = Convert.ToDecimal(data.ClaimAmount);
                                temp.DebentureInterestAmount = Convert.ToDecimal(data.DebentureInterestAmount);
                                temp.DisbursedAmount = Convert.ToDecimal(data.DisbursedAmount);
                                temp.DisbursedDate = Convert.ToDateTime(data.DisbursedDate);
                                temp.EstimatedRefundAmount = Convert.ToDecimal(data.EstimatedRefundAmount);
                                temp.ExpenseCategory = data.ExpenseCategory;
                                temp.ExpenseSubCategory = data.ExpenseSubCategory;
                                temp.ExpenseDescription = data.ExpenseDescription;
                                temp.InvoiceNumber = data.InvoiceNumber;
                                temp.LossAmount = Convert.ToDecimal(data.ChargeOffAmount);
                                temp.ResponsibleParty = data.ResponsibleParty;

                                if (temp.ParentLoanExpenseId != null)
                                {
                                    var p = lactx.LoanExpense.Where(x => x.LoanExpenseId == temp.ParentLoanExpenseId).Single();
                                    p.ModifiedBy = _userid;
                                    p.ModifiedDate = DateTime.Now;
                                    p.ClaimAmount = Convert.ToDecimal(data.PreviousClaimAmount);
                                    p.LossAmount = Convert.ToDecimal(data.PreviousChargeOffAmount);
                                    p.DebentureInterestAmount = Convert.ToDecimal(data.PreviousDebentureInterest);
                                }
                            }
                        }

                    }
                    else
                    {
                        //var temp = lactx.LoanExpense.Where(x => x.LoanId == data.LoanId).ToList();

                        lactx.LoanExpense.Add(new LoanExpense
                        {
                            LoanId = data.LoanId,
                            LoanExpenseId = 0,
                            AddedBy = _userid,
                            AddedDate = DateTime.Now,
                            ModifiedBy = _userid,
                            ModifiedDate = DateTime.Now,
                            AdvanceFrom = data.AdvanceFrom,
                            ChargeOffReason = data.ChargeOffReason,
                            ClaimAmount = Convert.ToDecimal(data.ClaimAmount),
                            DebentureInterestAmount = Convert.ToDecimal(data.DebentureInterestAmount),
                            DisbursedAmount = Convert.ToDecimal(data.DisbursedAmount),
                            DisbursedDate = Convert.ToDateTime(data.DisbursedDate.GetSafeDateString()),
                            EstimatedRefundAmount = Convert.ToDecimal(data.EstimatedRefundAmount),
                            ExpenseCategory = data.ExpenseCategory,
                            ExpenseSubCategory = data.ExpenseSubCategory,
                            ExpenseDescription = data.ExpenseDescription,
                            InvoiceNumber = data.InvoiceNumber,
                            LossAmount = Convert.ToDecimal(data.ChargeOffAmount),
                            ResponsibleParty = data.ResponsibleParty
                        });
                    }
                    lactx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public string LoadExpData(List<LAExpenseDTO> dto, int uploadid)
        {
            var ret = Constant.Success;
            var row = 0;
            var col = "";
            try
            {
                using (var lactx = new LossAnalysisNewContext())
                {
                    using (var trans = lactx.Database.BeginTransaction())
                    {
                        var di = lactx.TblDataImport.Where(x => x.UploadId == uploadid).Single();
                        di.Status = "Importing";
                        try
                        {
                            foreach(var d in dto)
                            {
                                ++row;
                                var exp = new LoanExpense();
                                exp.AddedBy = _userid;
                                exp.AddedDate = DateTime.Now;
                                exp.ModifiedBy = _userid;
                                exp.ModifiedDate = DateTime.Now;
                                col = "AdvanceFrom";
                                exp.AdvanceFrom = 
                            }

                            lactx.SaveChanges();
                            trans.Commit();
                        }
                        catch (Exception ex)
                        {
                            var msg = string.Format("Error: rownum {0} - {1}", rownum, )
                            trans.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        private int GetExpCategory(string s, DbContext ctx)
        {
            var cat = ((LossAnalysisNewContext)ctx).LkpExpCategory.ToList();
            string strcat = "Misc";

            switch (s)
            {
                case "Attorney Costs":
                    strcat = "Attorney Costs";
                    break;
                case "Attorney Fees":
                    strcat = "Attorney Fees";
                    break;   
                case "Bankruptcy Fees & Costs":
                    strcat = "Bankruptcy Fees & Costs";
                    break;
                case "BPO / Appraisal":
                    strcat = "BPO / Appraisal";
                    break;
                case "Eviction Fees / Costs":
                    strcat = "Eviction Fees / Costs";
                    break;    
                case "Homeowners Association":
                    strcat = "Homeowners Association";
                    break;
                case "Insurance":
                    strcat = "Insurance";
                    break;    
                case "Liens & Code Violations":
                    strcat = "Liens & Code Violations";
                    break;
                case "MIPs":
                    strcat = "MIPs";
                    break;    
                case "Mortgage Insurance Premiums":
                    strcat = "Mortgage Insurance Premiums";
                    break;
                case "Property Preservation":
                    strcat = "Property Preservation";
                    break;
                case "Taxes":
                    strcat = "Taxes";
                    break;
                case "Utilities":
                    strcat = "Utilities";
                    break;
            }

            return cat.Where(x => x.LkpTypeCatName == strcat).Select(x => x.LkpTypeCatId).Single();
        }
        private int GetChargeOffReason(string s, DbContext ctx)
        {
            var cat = ((LossAnalysisNewContext)ctx).LkpExpCategory.ToList();
            string strcat = "Misc";
            /*After CFR
After Conveyance
After ECD
After Sale
After Settlement
After Supplemental Timeframe
Duplicate
During Bankruptcy
During PFS
Exceeds Allowable
Excessive
Haircut
HUD Denied
Insufficient Documentation
Invalid Hold
Item Not Paid
Missed Conveyance
Missing Invoice
Missing Payment History
Non-Reimbursable Item
Not Approved
Other
Outside Acceptable Practices
Outside of Allowable Timeframe
Over Property Limit - no O/A
Overhead
Pending Refund
Reconveyance
Refund Received
REO
Supplemental Filed
Under Supplemental Minimum
             *
             * CASE WHEN @chargeOffReason= 'AfterCFR' THEN 'After CFR'
			WHEN @chargeOffReason= 'AfterConveyance' THEN 'After Conveyance'
			WHEN @chargeOffReason= 'AfterECD' THEN 'After ECD'
			WHEN @chargeOffReason= 'AfterSale' THEN 'After Sale'
			WHEN @chargeOffReason= 'AfterSettlement' THEN 'After Settlement'
			WHEN @chargeOffReason= 'AfterSuppTimeframe' THEN 'After Supplemental Timeframe'
			WHEN @chargeOffReason= 'DuringBK' THEN 'During Bankruptcy'
			WHEN @chargeOffReason= 'DuringPFS' THEN 'During PFS'
			WHEN @chargeOffReason= 'ExceedsAllowable' THEN 'Exceeds Allowable'
			WHEN @chargeOffReason= 'Excessive' THEN 'After ECD'
			WHEN @chargeOffReason= 'HUDDenied' THEN 'HUD Denied'
			WHEN @chargeOffReason= 'InsufDoc' THEN 'Insufficient Documentation'
			WHEN @chargeOffReason= 'InvalidHold' THEN 'Invalid Hold'
			WHEN @chargeOffReason= 'ItemNotPaid' THEN 'Item Not Paid'
			WHEN @chargeOffReason= 'MissedConveyance' THEN 'Missed Conveyance'
			WHEN @chargeOffReason= 'MissingInvoice' THEN 'Missing Invoice'
			WHEN @chargeOffReason= 'MissingPayHist' THEN 'Missing Payment History'
			WHEN @chargeOffReason= 'NonReimb' THEN 'Non-Reimbursable Item'
			WHEN @chargeOffReason= 'NotApproved' THEN 'Not Approved'
			WHEN @chargeOffReason= 'OutsideAcc' THEN 'Outside Acceptable Practices'
			WHEN @chargeOffReason= 'OutsideAllowable' THEN 'Outside of Allowable Timeframe'
			WHEN @chargeOffReason= 'OverPropertyLimit' THEN 'Over Property Limit - no O/A'
			WHEN @chargeOffReason= 'PendingRefund' THEN 'Pending Refund'
			WHEN @chargeOffReason= 'RefundReceived' THEN 'Refund Received'
			WHEN @chargeOffReason= 'SupplementalFiled' THEN 'Supplemental Filed'
			WHEN @chargeOffReason= 'UnderSuppMin' THEN 'Under Supplemental Minimum'*/
            switch (s)
            {
                case "Attorney Costs":
                    strcat = "Attorney Costs";
                    break;
                case "Attorney Fees":
                    strcat = "Attorney Fees";
                    break;
                case "Bankruptcy Fees & Costs":
                    strcat = "Bankruptcy Fees & Costs";
                    break;
                case "BPO / Appraisal":
                    strcat = "BPO / Appraisal";
                    break;
                case "Eviction Fees / Costs":
                    strcat = "Eviction Fees / Costs";
                    break;
                case "Homeowners Association":
                    strcat = "Homeowners Association";
                    break;
                case "Insurance":
                    strcat = "Insurance";
                    break;
                case "Liens & Code Violations":
                    strcat = "Liens & Code Violations";
                    break;
                case "MIPs":
                    strcat = "MIPs";
                    break;
                case "Mortgage Insurance Premiums":
                    strcat = "Mortgage Insurance Premiums";
                    break;
                case "Property Preservation":
                    strcat = "Property Preservation";
                    break;
                case "Taxes":
                    strcat = "Taxes";
                    break;
                case "Utilities":
                    strcat = "Utilities";
                    break;
            }

            return cat.Where(x => x.LkpTypeCatName == strcat).Select(x => x.LkpTypeCatId).Single();
        }
        private int GetRespParty(string s, DbContext ctx)
        {
            var cat = ((LossAnalysisNewContext)ctx).LkpExpCategory.ToList();
            string strcat = "Misc";
            /*	Attorney
Bankruptcy Dept
Claims Dept
Client
FCL Attorney Dept
FCL Process Dept
FCL Referral Dept
Insurance Dept
Investor
Invoicing Dept
Loss Analysis Dept
Loss Mitigation Dept
MIP Dept
No Loss
Origination Dept
Other
P&P Dept
Prior Servicer
Prior Servicer FCL Dept
Prior Servicer Loss Mit Dept
Property Preservation
Tax Dept
Third Party Vendor
Vendor Dept
             *	SET @responParty= CASE WHEN @responParty = 'Dean Morris LLP (Attorney)' THEN 'Attorney'
			WHEN @responParty = 'Fay' THEN 'Prior Servicer'
			WHEN @responParty = 'Mortgage Contracting Services (MCS) (PropPres)' THEN 'Property Preservation'
			WHEN @responParty = 'Petosa Petosa & Boecker LLP (Attorney)' THEN 'Attorney'
			WHEN @responParty = 'Phelan Hallinan Diamond & Jones LLP (Attorney)' THEN 'Attorney'
			WHEN @responParty = 'Roundpoint' THEN 'Prior Servicer'
			WHEN @responParty = 'Servicer Fay (PriorServicer)' THEN 'Prior Servicer'
			WHEN @responParty = 'Servicer Roundpoint (PriorServicer)' THEN 'Prior Servicer'*/
            switch (s)
            {
                case "Attorney Costs":
                    strcat = "Attorney Costs";
                    break;
                case "Attorney Fees":
                    strcat = "Attorney Fees";
                    break;
                case "Bankruptcy Fees & Costs":
                    strcat = "Bankruptcy Fees & Costs";
                    break;
                case "BPO / Appraisal":
                    strcat = "BPO / Appraisal";
                    break;
                case "Eviction Fees / Costs":
                    strcat = "Eviction Fees / Costs";
                    break;
                case "Homeowners Association":
                    strcat = "Homeowners Association";
                    break;
                case "Insurance":
                    strcat = "Insurance";
                    break;
                case "Liens & Code Violations":
                    strcat = "Liens & Code Violations";
                    break;
                case "MIPs":
                    strcat = "MIPs";
                    break;
                case "Mortgage Insurance Premiums":
                    strcat = "Mortgage Insurance Premiums";
                    break;
                case "Property Preservation":
                    strcat = "Property Preservation";
                    break;
                case "Taxes":
                    strcat = "Taxes";
                    break;
                case "Utilities":
                    strcat = "Utilities";
                    break;
            }

            return cat.Where(x => x.LkpTypeCatName == strcat).Select(x => x.LkpTypeCatId).Single();
        }
        private int GetAdvanceFrom(string s, DbContext ctx)
        {
            var cat = ((LossAnalysisNewContext)ctx).LkpExpCategory.ToList();
            /*Corporate
Escrow
HUD-1
Incentive
Proceeds To Corporate
Proceeds To Escrow
Restricted Escrow
Suspense
SET @advanceFrom= CASE WHEN @advanceFrom = '' then 'Corporate'
			WHEN @advanceFrom = '' then 'Corporate'
			WHEN @advanceFrom = 'HUD1' THEN 'HUD-1'
			WHEN @advanceFrom = 'ProceedsToCorporate' THEN 'Proceeds To Corporate'
			WHEN @advanceFrom = 'ProceedsToEscrow' THEN 'Proceeds To Escrow'
			WHEN @advanceFrom = 'ResEscrow' THEN 'Restricted Escrow'
			ELSE @advanceFrom END
 */
            string strcat = "Corporate";

            switch (s)
            {
                case "Attorney Costs":
                    strcat = "Attorney Costs";
                    break;
                case "Attorney Fees":
                    strcat = "Attorney Fees";
                    break;
                case "Bankruptcy Fees & Costs":
                    strcat = "Bankruptcy Fees & Costs";
                    break;
                case "BPO / Appraisal":
                    strcat = "BPO / Appraisal";
                    break;
                case "Eviction Fees / Costs":
                    strcat = "Eviction Fees / Costs";
                    break;
                case "Homeowners Association":
                    strcat = "Homeowners Association";
                    break;
                case "Insurance":
                    strcat = "Insurance";
                    break;
                case "Liens & Code Violations":
                    strcat = "Liens & Code Violations";
                    break;
                case "MIPs":
                    strcat = "MIPs";
                    break;
                case "Mortgage Insurance Premiums":
                    strcat = "Mortgage Insurance Premiums";
                    break;
                case "Property Preservation":
                    strcat = "Property Preservation";
                    break;
                case "Taxes":
                    strcat = "Taxes";
                    break;
                case "Utilities":
                    strcat = "Utilities";
                    break;
            }

            return cat.Where(x => x.LkpTypeCatName == strcat).Select(x => x.LkpTypeCatId).Single();
        }
    }
}
