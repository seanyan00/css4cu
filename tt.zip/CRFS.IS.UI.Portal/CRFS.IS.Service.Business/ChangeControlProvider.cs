﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using System.Reflection;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.Common;
using CRFS.IS.Service.Business.Jobs;
using CRFS.IS.Service.Business.Models;
using CRFS.IS.Service.Security;

namespace CRFS.IS.Service.Business
{
    public class ChangeControlProvider
    {
        private IConfiguration _config;
        private ILogger _logger;
        private int _userid;
        private static int _defectNo = GetTotalDefects();
        public int DefectNo { get { return ++_defectNo; } }

        public ChangeControlProvider(IConfiguration config, ILogger logger, int uid)
        {
            _config = config;
            _logger = logger;
            _userid = uid;
        }

        public GetDefectReply GetDefects()
        {
            var ret = new GetDefectReply();

            try
            {
                using (var ctx = new PortalContext())
                {
                    var temp = ctx.VwWorkItem.OrderByDescending(x => x.DateEntered).Select(x => new DefectView
                    {
                        Id = x.Id,
                        Name = x.Name,
                        AppId = x.AppId,
                        SubAppId = x.SubAppId.GetValueOrDefault(),
                        Environment = x.Environment.GetSafeString(),
                        AppName = x.AppName,
                        SubAppName = x.SubAppName.GetSafeString(),
                        ItemGroupId = x.ItemGroupId,
                        ItemGroupName = x.ItemGroupName,
                        StatusId = x.StatusId.GetSafeValue(),
                        StatusName = x.StatusName.GetSafeString(),
                        StatusDate = x.StatusDate.GetSafeDateTimeString(),
                        StatusPersonId = x.StatusPersonId.GetSafeValue(),
                        StatusPersonName = x.StatusPersonName.GetSafeString(),
                        Description = x.Description.GetSafeString(),
                        DateEntered = x.DateEntered.GetSafeDateTimeString()
                    }).ToList();
                    ret.DefectViews.AddRange(temp);
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public Defect GetDefect(int did)
        {
            var ret = new Defect();

            try
            {
                using (var ctx = new PortalContext())
                {
                    ret = ctx.TblDefect.Where(x => x.Id == did).Select(x => new Defect
                    {
                        Id = x.Id,
                        TypeId = x.TypeId,
                        Name = x.Name,
                        AppId = x.AppId,
                        SubAppId = x.SubAppId.GetSafeNullValue(),
                        Description = x.Description,
                        Environment = x.Environment.GetSafeString(),
                        IsReplicable = x.IsReplicable ?? false ? 1 : 0,
                        IsSystemwide = x.IsSystemwide ?? false ? 1 : 0,
                        ObservePersonId = x.ObservePersonId.GetSafeValue(),
                        ObserveTime = x.ObserveTime.GetSafeDateTimeString(),
                        ReferenceId = x.ReferenceId.GetSafeNullValue(),
                        ReferenceTypeId = x.ReferenceTypeId.GetSafeNullValue(),
                        TechSolution = x.TechResolution.GetSafeString(),
                        TestStepNum = x.TestStepNum.GetSafeNullValue()
                    }).SingleOrDefault();
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public GetWorkItemAttachmentReply GetWorkItemAttachment(int did)
        {
            var ret = new GetWorkItemAttachmentReply();

            try
            {
                using (var ctx = new PortalContext())
                {
                    var temp = ctx.TblWorkItemAttachment.Where(x => x.ItemId == did && !x.MarkedForDelete).Include(x => x.FileUpload).OrderByDescending(x => x.FileUpload.UploadDate)
                          .Select(x => new WorkItemAttachment
                          {
                              Id = x.Id,
                              AttachmentType = x.AttachmentType.GetSafeString(),
                              DateUploaded = x.FileUpload.UploadDate.GetSafeDateTimeString(),
                              FileUploadId = x.FileUploadId,
                              ItemGroupId = x.ItemGroupId,
                              ItemId = x.ItemId,
                              Name = x.FileUpload.FileName.GetSafeString(),
                              ServerPath = x.FileUpload.ServerPath,
                              UploadedBy = x.FileUpload.UploadedBy.GetSafeString(),
                              MarkedForDelete = x.MarkedForDelete ? 1 : 0
                          }).ToList();
                    ret.WorkItemAttachments.AddRange(temp);
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public GetWorkItemNotesReply GetWorkItemNotes(int did)
        {
            var ret = new GetWorkItemNotesReply();
            var users = new List<LkpUsers>();

            try
            {
                using (var appctx = new ApplicationConfigurationContext())
                {
                    users = appctx.LkpUsers.ToList();
                }
                using (var ctx = new PortalContext())
                {
                    var temp = ctx.TblWorkItemNotes.Where(x => x.ItemId == did).ToList()
                          .Select(x => new WorkItemNotes
                          {
                              Id = x.Id,
                              IsInvalidated = x.IsInvalidated ? 1 : 0,
                              ItemGroupId = x.ItemGroupId,
                              ItemId = x.ItemId,
                              Note = x.Note.GetSafeString(),
                              NoteDate = x.NoteDate.GetSafeDateTimeString(),
                              NotePersonId = x.NotePersonId,
                              NotePersonName = users.Single(y => y.UserId == x.NotePersonId).UserName
                          }).OrderByDescending(x => x.NoteDate).ToList();
                    ret.WorkItemNotesList.AddRange(temp);
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public GetWorkItemStatusLogReply GetWorkItemStatusLog(int did)
        {
            var ret = new GetWorkItemStatusLogReply();
            var users = new List<LkpUsers>();

            try
            {
                using(var acctx = new ApplicationConfigurationContext())
                {
                    users = acctx.LkpUsers.Where(x => x.Active).ToList();
                }
                using (var ctx = new PortalContext())
                {
                    var stts = ctx.LkpWorkItemStatus.ToList();

                    var temp = ctx.TblWorkItemStatusLog.Where(x => x.ItemId == did).ToList()
                          .Select(x => new WorkItemStatusLog
                          {
                              Id = x.Id,
                              ItemGroupId = x.ItemGroupId,
                              ItemId = x.ItemId,
                              Notes = x.Notes.GetSafeString(),
                              StatusDate = x.StatusDate.GetSafeDateTimeString(),
                              StatusId = x.StatusId,
                              StatusName = stts.Single(y => y.Id == x.StatusId).Code,
                              StatusPersonId = x.StatusPersonId,
                              StatusPersonName = users.Single(y => y.UserId == x.StatusPersonId).UserName
                          }).OrderByDescending(x => x.StatusDate).ToList();
                    ret.WorkItemStatusLogs.AddRange(temp);
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public GetStatusWithOrderReply GetWorkItemStatusWithOrder()
        {
            var ret = new GetStatusWithOrderReply();
            try
            {
                using (var ctx = new PortalContext())
                {
                    var temp = ctx.LkpWorkItemStatus
                          .Select(x => new WIStatusWithOrder
                          {
                              Id = x.Id,
                              Code = x.Code,
                              Order = x.StatusOrder,
                              ItemGroupId = x.ItemGroupId,
                              Description = x.Description.GetSafeString()
                          }).OrderBy(x => x.Order).ToList();
                    ret.WIStatusWithOrders.AddRange(temp);
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveDefect(Defect data)
        {
            var ret = new MessageReply { Id = 0, Message = Constant.Success };

            try
            {
                using (var ctx = new PortalContext())
                {
                    var temp = ctx.TblDefect.Where(x => x.Id == data.Id).SingleOrDefault();
                    if (temp == null)
                    {
                        var temp1 = new TblDefect
                        {
                            Id = data.Id,
                            IsReplicable = data.IsReplicable == 1,
                            IsSystemwide = data.IsSystemwide == 1,
                            AppId = data.AppId,
                            SubAppId = data.SubAppId.GetNullValue(),
                            DateEntered = DateTime.Now,
                            DateUpdated = DateTime.Now,
                            Description = data.Description,
                            EnteredBy = _userid,
                            Environment = data.Environment,
                            Name = data.Name,
                            ObservePersonId = _userid,
                            ObserveTime = DateTime.Now,
                            ReferenceId = data.ReferenceId.GetNullValue(),
                            ReferenceTypeId = data.ReferenceTypeId.GetNullValue(),
                            TechResolution = data.TechSolution,
                            TestStepNum = data.TestStepNum.GetNullValue(),
                            TypeId = data.TypeId,
                            UpdatedBy = _userid
                        };
                        ctx.TblDefect.Add(temp1);
                        ctx.SaveChanges();

                        ret.Id = temp1.Id;
                    }
                    else
                    {
                        temp.AppId = data.AppId;
                        temp.SubAppId = data.SubAppId.GetNullValue();
                        temp.DateUpdated = DateTime.Now;
                        temp.UpdatedBy = _userid;
                        temp.Description = data.Description;
                        temp.Environment = data.Environment;
                        temp.IsReplicable = data.IsReplicable == 1;
                        temp.IsSystemwide = data.IsSystemwide == 1;
                        temp.Name = data.Name;
                        // temp.ObservePersonId = data.ObservePersonId;
                        // temp.ObserveTime = Convert.ToDateTime(data.ObserveTime);
                        temp.ReferenceId = data.ReferenceId.GetNullValue();
                        temp.ReferenceTypeId = data.ReferenceTypeId.GetNullValue();
                        temp.TechResolution = data.TechSolution;
                        temp.TestStepNum = data.TestStepNum.GetNullValue();
                        temp.TypeId = data.TypeId;

                        ctx.SaveChanges();
                    }
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveWorkItemAttachment(WorkItemAttachment data)
        {
            var ret = new MessageReply { Id = 0, Message = Constant.Success };

            try
            {
                using (var ctx = new PortalContext())
                {
                    if (data.Id > 0)
                    {
                        var temp = ctx.TblWorkItemAttachment.Where(x => x.Id == data.Id).Single();
                        temp.ItemGroupId = data.ItemGroupId;
                        temp.ItemId = data.ItemId;
                        temp.MarkedForDelete = data.MarkedForDelete == 1;
                        temp.Name = data.Name;
                        temp.AttachmentType = data.AttachmentType;
                        temp.FileUploadId = data.FileUploadId;

                        ctx.SaveChanges();
                    }
                    else
                    {
                        var temp = new TblWorkItemAttachment
                        {
                            Id = data.Id,
                            AttachmentType = data.AttachmentType,
                            ItemGroupId = data.ItemGroupId,
                            ItemId = data.ItemId,
                            FileUploadId = data.FileUploadId,
                            MarkedForDelete = data.MarkedForDelete == 1,
                            Name = data.Name
                        };
                        ctx.TblWorkItemAttachment.Add(temp);
                        ctx.SaveChanges();

                        ret.Id = temp.Id;
                    }
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public MessageReply DeleteWorkItemAttachment(DeleteWorkItemAttachmentRequest data)
        {
            var ret = new MessageReply { Id = 0, Message = Constant.Success };

            try
            {
                using (var ctx = new PortalContext())
                {
                    var atts = ctx.TblWorkItemAttachment.ToList();
                    foreach(var id in data.Ids)
                    {
                        var temp = atts.Single(x => x.Id == id);
                        temp.MarkedForDelete = true; 
                        ctx.SaveChanges();
                    }
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveWorkItemNotes(WorkItemNotes data)
        {
            var ret = new MessageReply { Id = 0, Message = Constant.Success };

            try
            {
                using (var ctx = new PortalContext())
                {
                    if (data.Id > 0)
                    {
                        var temp = ctx.TblWorkItemNotes.Where(x => x.Id == data.Id).Single();
                        temp.ItemGroupId = data.ItemGroupId;
                        temp.ItemId = data.ItemId;
                        temp.IsInvalidated = data.IsInvalidated == 1;
                        temp.Note = data.Note;
                        temp.NoteDate = Convert.ToDateTime(data.NoteDate);
                        temp.NotePersonId = data.NotePersonId;

                        ctx.SaveChanges();
                    }
                    else
                    {
                        var temp = new TblWorkItemNotes
                        {
                            Id = data.Id,
                            ItemGroupId = data.ItemGroupId,
                            ItemId = data.ItemId,
                            IsInvalidated = true, //data.IsInvalidated == 1,
                            Note = data.Note,
                            NoteDate = DateTime.Now,
                            NotePersonId = _userid
                        };
                        ctx.TblWorkItemNotes.Add(temp);
                        ctx.SaveChanges();

                        ret.Id = temp.Id;
                    }
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveWorkItemStatusLog(WorkItemStatusLog data)
        {
            var ret = new MessageReply { Id = 0, Message = Constant.Success };

            try
            {
                using (var ctx = new PortalContext())
                {
                    if (data.Id > 0)
                    {
                        var temp = ctx.TblWorkItemStatusLog.Where(x => x.Id == data.Id).Single();
                        temp.ItemGroupId = data.ItemGroupId;
                        temp.ItemId = data.ItemId;
                        temp.Notes = data.Notes;
                     
                        ctx.SaveChanges();
                    }
                    else
                    {
                        var temp = new TblWorkItemStatusLog
                        {
                            Id = data.Id,
                            ItemGroupId = data.ItemGroupId,
                            ItemId = data.ItemId,
                            DateCreated = DateTime.Now,
                            CreatedBy = _userid,
                            Notes = data.Notes,
                            StatusDate = DateTime.Now,
                            StatusId = data.StatusId,
                            StatusPersonId = _userid
                        };
                        ctx.TblWorkItemStatusLog.Add(temp);
                        ctx.SaveChanges();

                        ret.Id = temp.Id;
                    }
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        private static int GetTotalDefects()
        {
            int ret = 0;

            using (var portalctx = new PortalContext())
            {
                try
                {
                    ret = portalctx.TblDefect.Max(x => (int?)x.Id) ?? 10001;
                }
                catch { throw; }

                return ret;
            }
        }
    }
}
