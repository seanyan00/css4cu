﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Google.Protobuf.WellKnownTypes;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.Common.TransferObjects;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Security;
using CRFS.IS.Service.Util;

namespace CRFS.IS.Service.Business
{
    public class APSProvider
    {
        private IConfiguration _config;
        private ILogger _logger;
        private int _userid;

        public APSProvider(IConfiguration config, ILogger logger, int uid)
        {
            _config = config;
            _logger = logger;
            _userid = uid;
        }

        public GetAPSLoansReply GetAPSLoans(GetAPSLoansRequest req)
        {
            var ret = new GetAPSLoansReply();
            if(req.PageSize == 0)
            {
                req.PageIndex = 0;
                req.PageSize = 20;//int.MaxValue;
            }
            try
            {
                using (var apsctx = new AppsDB_FNMAContext())
                {
                    var temp = apsctx.TblAdvPmtReferrals.Where(x => x.FnmaloanNumber.StartsWith(req.Keyword))
                                     .Select(x => x.FnmaloanNumber).Distinct().ToList()
                                     .OrderBy(x => x).Skip(req.PageIndex * req.PageSize).Take(req.PageSize).ToList();
                
                    ret.LoanNumbers.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public GetAPSLoanDataReply GetLoanData(string loannumber)
        {
            var ret = new GetAPSLoanDataReply();

            try
            {
                using (var apsctx = new AppsDB_FNMAContext())
                {
                   var temp = apsctx.VwAdvPmtReferralDetails.Where(x => x.FnmaloanNumber == loannumber).Select(x => new APSLoanData { 
                       BillingReasonId = x.BillingReasonId.GetSafeValue(),
                       TotalClaimableAmount = (double)x.TotalClaimableAmount.GetSafeValue(),
                       TotalExpenseBalance = (double)x.TotalExpenseBalance.GetSafeValue(),
                       TotalNonClaimableAmount = (double)x.TotalNonClaimableAmount.GetSafeValue(),
                       TotalWaivedAmount = (double)x.TotalWaivedAmount.GetSafeValue(),
                       FNMALoanNumber = x.FnmaloanNumber.GetSafeString(),
                       IsLocked = x.IsLocked ?? false ? 1 : 0,
                       LockedBy = x.LockedBy ?? 0,
                       InitialBillingDate = x.InitialBillingDate.GetSafeString(),
                       InvoiceStatusId = x.InvoiceStatusId.GetSafeValue(),
                       ClosedDate = x.ClosedDate.GetSafeString(),
                       IsClosed = x.IsClosed ? 1 : 0,
                       ServicerId = x.ServicerId.GetSafeValue(),
                       ReferralId = x.ReferralId,
                       ReferralDate = x.ReferralDate.GetSafeString(),
                       ReferralStatusId = x.ReferralStatusId.GetSafeValue(),
                       ServicerLoanNumber = x.ServicerLoanNumber.GetSafeString(),
                       ServicerNumber = x.ServicerNumber.GetSafeString()
                    }).Distinct().ToList();

                    foreach(var t in temp)
                    {
                        var tempislocked = t.IsLocked;
                        var templockedby = t.LockedBy;
                        t.IsLocked = 0;
                        t.LockedBy = 0;
                        t.CheckSum = t.GetHashCode().ToString();
                        t.IsLocked = tempislocked;
                        t.LockedBy = templockedby;
                        t.HasOtherLock = apsctx.VwAdvPmtReferralDetails.Any(x => (!x.IsClosed) && (x.IsLocked ?? false) 
                                                                                 && (x.LockedBy ?? 0) == _userid
                                                                                 && x.ReferralId != t.ReferralId) ? 1 : 0;
                    }
                    ret.APSLoanDatas.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public GetAPSLoanDataReply GetLoanDataByUser()
        {
            var ret = new GetAPSLoanDataReply();

            try
            {
                using (var apsctx = new AppsDB_FNMAContext())
                {
                    var lockedloans = apsctx.TblAdvPmtReferrals.Where(x => (x.IsLocked ?? false) && x.LockedBy == _userid && !x.IsClosed).ToList();
                    if (lockedloans.Count > 0)
                    {
                        var loannumber = "";
                        var lastdate = DateTime.MinValue;
                        foreach(var ln in lockedloans)
                        {
                            if(lastdate <= ln.LastUpdateDate)
                            {
                                loannumber = ln.FnmaloanNumber;
                                lastdate = ln.LastUpdateDate;
                            }
                        }
                        var temp = apsctx.VwAdvPmtReferralDetails.Where(x => x.FnmaloanNumber == loannumber).Select(x => new APSLoanData
                        {
                            BillingReasonId = x.BillingReasonId.GetSafeValue(),
                            TotalClaimableAmount = (double)x.TotalClaimableAmount.GetSafeValue(),
                            TotalExpenseBalance = (double)x.TotalExpenseBalance.GetSafeValue(),
                            TotalNonClaimableAmount = (double)x.TotalNonClaimableAmount.GetSafeValue(),
                            TotalWaivedAmount = (double)x.TotalWaivedAmount.GetSafeValue(),
                            FNMALoanNumber = x.FnmaloanNumber.GetSafeString(),
                            IsLocked = x.IsLocked ?? false ? 1 : 0,
                            LockedBy = x.LockedBy ?? 0,
                            InitialBillingDate = x.InitialBillingDate.GetSafeString(),
                            InvoiceStatusId = x.InvoiceStatusId.GetSafeValue(),
                            ClosedDate = x.ClosedDate.GetSafeString(),
                            IsClosed = x.IsClosed ? 1 : 0,
                            ServicerId = x.ServicerId.GetSafeValue(),
                            ReferralId = x.ReferralId,
                            ReferralDate = x.ReferralDate.GetSafeString(),
                            ReferralStatusId = x.ReferralStatusId.GetSafeValue(),
                            ServicerLoanNumber = x.ServicerLoanNumber.GetSafeString(),
                            ServicerNumber = x.ServicerNumber.GetSafeString()
                        }).Distinct().ToList();

                        foreach (var t in temp)
                        {
                            var tempislocked = t.IsLocked;
                            var templockedby = t.LockedBy;
                            t.IsLocked = 0;
                            t.LockedBy = 0;
                            t.CheckSum = t.GetHashCode().ToString();
                            t.IsLocked = tempislocked;
                            t.LockedBy = templockedby;
                        }
                        ret.APSLoanDatas.AddRange(temp);
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public MessageReply LockReferral(int id)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };
            var users = new List<LkpUsers>();
            try
            {
                using(var appcts = new ApplicationConfigurationContext())
                {
                    users = appcts.LkpUsers.ToList();
                }
                using(var apsctx = new AppsDB_FNMAContext())
                {
                    var temp = apsctx.TblAdvPmtReferrals.Single(x => x.ReferralId == id);
                    if ((temp.IsLocked ?? false) && (temp.LockedBy ?? 0) != _userid)
                    {
                        ret.Message = "Already locked by " + users.Single(x => x.UserId == temp.LockedBy).UserName;
                        return ret;
                    }

                    temp.IsLocked = true;
                    temp.LockedBy = _userid;
                    apsctx.SaveChanges();
                }
            }
            catch { throw; }
            return ret;
        }
        public MessageReply UnlockReferral(int id)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var apsctx = new AppsDB_FNMAContext())
                {
                    var temp = apsctx.TblAdvPmtReferrals.Single(x => x.ReferralId == id);
                    temp.IsLocked = false;
                    temp.LockedBy = null;
                    apsctx.SaveChanges();
                }
            }
            catch { throw; }
            return ret;
        }
        public MessageReply SaveLoanData(APSLoanData loan)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var apsctx = new AppsDB_FNMAContext())
                {
                    //no use. 'cause set lock will alter
                   
                    var checkitem =  apsctx.VwAdvPmtReferralDetails.Where(x => x.ReferralId == loan.ReferralId).Select(x => new APSLoanData
                    {
                        BillingReasonId = x.BillingReasonId.GetSafeValue(),
                        TotalClaimableAmount = (double)x.TotalClaimableAmount.GetSafeValue(),
                        TotalExpenseBalance = (double)x.TotalExpenseBalance.GetSafeValue(),
                        TotalNonClaimableAmount = (double)x.TotalNonClaimableAmount.GetSafeValue(),
                        TotalWaivedAmount = (double)x.TotalWaivedAmount.GetSafeValue(),
                        FNMALoanNumber = x.FnmaloanNumber.GetSafeString(),
                       // IsLocked = x.IsLocked ?? false ? 1 : 0,
                       // LockedBy = x.LockedBy ?? 0,
                        ClosedDate = x.ClosedDate.GetSafeString(),
                        InitialBillingDate = x.InitialBillingDate.GetSafeString(),
                        InvoiceStatusId = x.InvoiceStatusId.GetSafeValue(),
                        IsClosed = x.IsClosed ? 1 : 0,
                        ServicerId = x.ServicerId.GetSafeValue(),
                        ReferralId = x.ReferralId,
                        ReferralDate = x.ReferralDate.GetSafeString(),
                        ReferralStatusId = x.ReferralStatusId.GetSafeValue(),
                        ServicerLoanNumber = x.ServicerLoanNumber.GetSafeString(),
                        ServicerNumber = x.ServicerNumber.GetSafeString()
                    }).Single();
                    if(checkitem.GetHashCode().ToString() != loan.CheckSum)
                        throw new Exception("The value has be modified during editting.");
                    
                    var temp = apsctx.TblAdvPmtReferrals.Where(x => x.ReferralId == loan.ReferralId).Single();
                   
                    temp.BillingReasonId = loan.BillingReasonId;
                    temp.FnmaloanNumber = loan.FNMALoanNumber;
                    temp.ClosedDate = DateTime.Parse(loan.ClosedDate.GetSafeDateString());
                    temp.InitialBillingDate = Convert.ToDateTime(loan.InitialBillingDate.GetSafeDateString());
                    temp.InvoiceStatusId = loan.InvoiceStatusId;
                    temp.IsClosed = loan.IsClosed == 1;
                    temp.ServicerId = loan.ServicerId;
                    temp.ReferralDate = Convert.ToDateTime(loan.ReferralDate.GetSafeDateString());
                    temp.ReferralStatusId = loan.ReferralStatusId;
                    temp.ServicerLoanNumber = loan.ServicerLoanNumber;
                    temp.ServicerNumber = loan.ServicerNumber;
                    temp.IsLocked = false;
                    temp.LockedBy = _userid;
                    temp.LastUpdateDate = DateTime.Now;
                    temp.LastUpdateUserId = _userid;

                    apsctx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public MessageReply CheckOut(long id)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0};

            try
            {
                using (var apsctx = new AppsDB_FNMAContext())
                {
                    var temp = apsctx.TblAdvPmtReferralEdits.Where(x => x.ReferralId == id).SingleOrDefault();

                    if(temp == null)
                    {
                        var edit = new TblAdvPmtReferralEdits
                        {
                            ReferralId = id,
                            ReferralEditId = 0,
                            CheckoutDateTime = DateTime.Now,
                            CheckoutUserId = _userid,
                            WorkstationName = "",
                            EnteredByUserId = _userid,
                            EnteredDate = DateTime.Now,
                            MarkedForDelete = false,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUserId = _userid
                        };
                        apsctx.TblAdvPmtReferralEdits.Add(edit);
                        apsctx.SaveChanges();

                       // ret.Id = (int)edit.ReferralEditId;
                    } 
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public MessageReply CheckIn(long id)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var apsctx = new AppsDB_FNMAContext())
                {
                    var temp = apsctx.TblAdvPmtReferralEdits.Where(x => x.ReferralId == id).SingleOrDefault();

                    if (temp == null)
                    {
                        var edit = new TblAdvPmtReferralEdits
                        {
                            ReferralId = id,
                            ReferralEditId = 0,
                            CheckinDateTime = DateTime.Now,
                            CheckinUserId = _userid,
                            WorkstationName = "",
                            EnteredByUserId = _userid,
                            EnteredDate = DateTime.Now,
                            MarkedForDelete = false,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUserId = _userid
                        };
                        apsctx.TblAdvPmtReferralEdits.Add(edit);
                        apsctx.SaveChanges();

                        // ret.Id = (int)edit.ReferralEditId;
                    } else
                    {
                        temp.CheckinDateTime = DateTime.Now;
                        temp.CheckinUserId = _userid;
                        temp.LastUpdateDate = DateTime.Now;
                        temp.LastUpdateUserId = _userid;

                        apsctx.SaveChanges();
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public GetAPSDisbursementsReply GetDisbursements(long id)
        {
            var ret = new GetAPSDisbursementsReply();

            try
            {
                using (var apsctx = new AppsDB_FNMAContext())
                {
                    var temp = apsctx.TblAdvPmtDisbursements.Where(x => x.ReferralId == id && !(x.MarkedForDelete ?? false)).Select(x => new APSDisbursement
                    {
                        Id = x.DisbursementId,
                        Claim571Payee = x.Claim571Payee.GetSafeString(),
                        TransactionAmount = (double)x.TransactionAmount.GetSafeValue(),
                        TransactionDate = x.TransactionDate.GetSafeString(),
                        UIAct = "",
                        Claimable = x.Claimable ? 1 : 0,
                        DisbursementTypeId = x.DisbursementTypeId.GetValueOrDefault(),
                        PreparerName = x.PreparerName.GetSafeString(),
                        Waived = x.Waived ?? false ? 1 : 0,
                        MarkedForDelete = x.MarkedForDelete ?? false ? 1 : 0,
                        ReferralId = x.ReferralId
                    }).ToList();
                    foreach(var t in temp)
                    {
                        t.CheckSum = t.GetHashCode().ToString();
                    }
                    ret.APSDisbursements.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public GetAPSCommentsReply GetComments(long id)
        {
            var ret = new GetAPSCommentsReply();

            try
            {
                using (var apsctx = new AppsDB_FNMAContext())
                {
                    var temp = apsctx.TblAdvPmtComments.Where(x => x.ReferralId == id && !(x.MarkedForDelete ?? false)).Select(x => new APSComment { 
                       Id = x.CommentId,
                       CommentDate = x.CommentDate.GetSafeString(),
                       CommentText = x.CommentText,
                       CommentTypeId = x.CommentTypeId.GetSafeValue(),
                       FollowupComplete = x.FollowupComplete ? 1 : 0,
                       FollowupDate = x.FollowupDate.GetSafeString(),
                       MarkedForDelete = x.MarkedForDelete ?? false ? 1 : 0,
                       ReferralId = x.ReferralId,
                       EnteredBy = x.EnteredByUserId,
                       EnteredDate = x.EnteredDate.GetSafeString(),
                       UIAct = ""
                    }).ToList();
                    foreach(var t in temp)
                    {
                        t.CheckSum = t.GetHashCode().ToString();
                    }
                    ret.APSComments.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveDisbursement(APSDisbursement dist)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var apsctx = new AppsDB_FNMAContext())
                {
                    if(dist.Id > 0)
                    {
                        var checkitem = apsctx.TblAdvPmtDisbursements.Where(x => x.DisbursementId == dist.Id).Select(x => new APSDisbursement
                        {
                            Id = x.DisbursementId,
                            Claim571Payee = x.Claim571Payee.GetSafeString(),
                            TransactionAmount = (double)x.TransactionAmount.GetSafeValue(),
                            TransactionDate = x.TransactionDate.GetSafeString(),
                            UIAct = "",
                            Claimable = x.Claimable ? 1 : 0,
                            DisbursementTypeId = x.DisbursementTypeId.GetValueOrDefault(),
                            PreparerName = x.PreparerName.GetSafeString(),
                            Waived = x.Waived ?? false ? 1 : 0,
                            MarkedForDelete = x.MarkedForDelete ?? false ? 1 : 0,
                            ReferralId = x.ReferralId
                        }).Single();
                        if(dist.CheckSum != checkitem.GetHashCode().ToString())
                            throw new Exception("The value has be modified during editting.");
                        
                        var temp = apsctx.TblAdvPmtDisbursements.Single(x => x.DisbursementId == dist.Id);
                     
                        if(dist.UIAct == "Delete")
                        {
                            temp.MarkedForDelete = true;
                            temp.LastUpdateDate = DateTime.Now;
                            temp.LastUpdateUserId = _userid;
                        } else
                        {
                            temp.Claim571Payee = dist.Claim571Payee;
                            temp.TransactionAmount = Convert.ToDecimal(dist.TransactionAmount);
                            temp.TransactionDate = Convert.ToDateTime(dist.TransactionDate);
                            temp.DisbursementTypeId = dist.DisbursementTypeId;
                            temp.Claimable = dist.Claimable == 1;
                            temp.Waived = dist.Waived == 1;
                            temp.MarkedForDelete = dist.MarkedForDelete == 1;
                            temp.LastUpdateDate = DateTime.Now;
                            temp.LastUpdateUserId = _userid;
                        }
                        apsctx.SaveChanges();
                    } else
                    {
                        var temp = new TblAdvPmtDisbursements
                        {
                            DisbursementId = 0,
                            DisbursementTypeId = dist.DisbursementTypeId,
                            TransactionAmount = (decimal)dist.TransactionAmount,
                            TransactionDate = Convert.ToDateTime(dist.TransactionDate),
                            Claim571Payee = dist.Claim571Payee,
                            Claimable = dist.Claimable == 1,
                            Waived = dist.Waived == 1,
                            MarkedForDelete = false,
                            EnteredByUserId = _userid,
                            EnteredDate = DateTime.Now,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUserId = _userid,
                            PreparerName = dist.PreparerName,
                            ReferralId = dist.ReferralId
                        };
                        apsctx.TblAdvPmtDisbursements.Add(temp);
                        apsctx.SaveChanges();
                        ret.Id = (int)temp.DisbursementId;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveComment(APSComment comm)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var apsctx = new AppsDB_FNMAContext())
                {
                    if (comm.Id > 0)
                    {
                        var checkitem = apsctx.TblAdvPmtComments.Where(x => x.CommentId == comm.Id).Select(x => new APSComment
                        {
                            Id = x.CommentId,
                            CommentDate = x.CommentDate.GetSafeString(),
                            CommentText = x.CommentText,
                            CommentTypeId = x.CommentTypeId.GetSafeValue(),
                            FollowupComplete = x.FollowupComplete ? 1 : 0,
                            FollowupDate = x.FollowupDate.GetSafeString(),
                            MarkedForDelete = x.MarkedForDelete ?? false ? 1 : 0,
                            ReferralId = x.ReferralId,
                            EnteredBy = x.EnteredByUserId,
                            EnteredDate = x.EnteredDate.GetSafeString(),
                            UIAct = ""
                        }).Single();
                        if(comm.CheckSum != checkitem.GetHashCode().ToString())
                           throw new Exception("The value has be modified during editting.");
                        
                        var temp = apsctx.TblAdvPmtComments.Single(x => x.CommentId == comm.Id);
                        if (comm.UIAct == "Delete")
                        {
                            temp.MarkedForDelete = true;
                            temp.LastUpdateDate = DateTime.Now;
                            temp.LastUpdateUserId = _userid;
                        }
                        else
                        {
                            temp.CommentText = comm.CommentText;
                            temp.CommentTypeId = comm.CommentTypeId;
                            temp.CommentDate = Convert.ToDateTime(comm.CommentDate.GetSafeDateString());
                            temp.LastUpdateDate = DateTime.Now;
                            temp.LastUpdateUserId = _userid;
                            temp.FollowupComplete = comm.FollowupComplete == 1;
                            temp.FollowupDate = Convert.ToDateTime(comm.FollowupDate.GetSafeDateString());
                        }
                        apsctx.SaveChanges();
                    }
                    else
                    {
                        var temp = new TblAdvPmtComments
                        {
                            CommentId = 0,
                            CommentDate = Convert.ToDateTime(comm.CommentDate.GetSafeDateString()),
                            CommentText = comm.CommentText,
                            CommentTypeId = comm.CommentTypeId,
                            MarkedForDelete = false,
                            EnteredByUserId = _userid,
                            EnteredDate = DateTime.Now,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUserId = _userid,
                            ReferralId = comm.ReferralId,
                            FollowupComplete = comm.FollowupComplete == 1,
                            FollowupDate = Convert.ToDateTime(comm.FollowupDate.GetSafeDateString())
                        };
                        apsctx.TblAdvPmtComments.Add(temp);
                        apsctx.SaveChanges();
                        ret.Id = (int)temp.CommentId;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
    }
}
