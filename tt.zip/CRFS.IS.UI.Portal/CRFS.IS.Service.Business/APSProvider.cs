﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Google.Protobuf.WellKnownTypes;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.Common.TransferObjects;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Security;
using CRFS.IS.Service.Util;

namespace CRFS.IS.Service.Business
{
    public class APSProvider
    {
        private IConfiguration _config;
        private ILogger _logger;
        private int _userid;

        public APSProvider(IConfiguration config, ILogger logger, int uid)
        {
            _config = config;
            _logger = logger;
            _userid = uid;
        }

        public GetAPSLoansReply GetAPSLoans(string keyword)
        {
            var ret = new GetAPSLoansReply();

            try
            {
                using (var apsctx = new AppsDB_FNMAContext())
                {
                    var temp = apsctx.TblAdvPmtReferrals.Where(x => x.FnmaloanNumber.IndexOf(keyword) >= 0).Select(x => x.FnmaloanNumber).ToList();
                
                    ret.LoanNumbers.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
    }
}
