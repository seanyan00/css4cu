﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Google.Protobuf.WellKnownTypes;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.Common.TransferObjects;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Security;

namespace CRFS.IS.Service.Business
{
    public class DataManagementProvider
    {
        private IConfiguration _config;
        private ILogger _logger;
        private int _userid;

        public DataManagementProvider(IConfiguration config, ILogger logger, int uid)
        {
            _config = config;
            _logger = logger;
            _userid = uid;
        }

        public GetDatasetsReply GetDatasets()
        {
            var ret = new GetDatasetsReply();
            try
            {
                using (var pctx = new PortalContext())
                {
                    var temp = pctx.LkpDataset.Select(x => new Dataset
                    {
                        Id = x.Id,
                        Active = x.Active ? 1 : 0,
                        AccessLevel = x.AccessLevel,
                        //SheetNum = x.SheetNum,
                        ClearBeforeLoad = x.ClearBeforeLoad.GetIntValue(),
                        Delimiter = x.Delimiter.GetSafeString(),
                        Description = x.Description.GetSafeString(),
                        Name = x.Name,
                        Target = x.Target
                    }).ToList();

                    ret.Datesets.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetDatasetMappingReply GetDatasetMapping(int id)
        {
            var ret = new GetDatasetMappingReply();
            try
            {
                using (var pctx = new PortalContext())
                {
                    var temp = pctx.LkpDatasetFieldMapping.Where(x => x.Dsid == id).Select(x => new DatasetMapping
                    {
                        Id = x.Id,
                        AttributeName = x.AttributeName,
                        AutoFill = x.AutoFill.GetIntValue(),
                        DSId = x.Dsid,
                        FieldName = x.FieldName,
                        FillType = x.FillType.GetSafeString()
                    }).ToList();

                    ret.DatasetMappings.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public string SaveDataset(Dataset data)
        {
            var ret = Constant.Success;
            try
            {
                using(var pctx = new PortalContext())
                {
                    if(data.Id > 0)
                    {
                        var temp = pctx.LkpDataset.Where(x => x.Id == data.Id).Single();

                        if(data.UIAct == "Delete")
                        {
                            pctx.LkpDataset.Remove(temp);
                        } 
                        else
                        {
                            temp.Active = data.Active == 1;
                            temp.Name = data.Name;
                            temp.SheetNum = data.SheetNum;
                            temp.Target = data.Target;
                            temp.AccessLevel = data.AccessLevel;
                            temp.ClearBeforeLoad = data.ClearBeforeLoad.GetBoolValue();
                            temp.Delimiter = data.Delimiter;
                            temp.Description = data.Description;
                            temp.DateUpdated = DateTime.Now;
                            temp.UpdatedBy = _userid;
                        }
                    } else
                    {
                        pctx.LkpDataset.Add(new LkpDataset
                        {
                            Active = data.Active == 1,
                            EnteredBy = _userid,
                            DateEntered = DateTime.Now,
                            AccessLevel = data.AccessLevel,
                            ClearBeforeLoad = data.ClearBeforeLoad.GetBoolValue(),
                            Delimiter = data.Delimiter,
                            Description = data.Description,
                            Name = data.Name,
                            SheetNum = data.SheetNum.GetNullValue(),
                            Target = data.Target,
                            DateUpdated = DateTime.Now,
                            UpdatedBy = _userid
                        });
                    }
                    pctx.SaveChanges();
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public string SaveDatasetMapping(DatasetMapping data)
        {
            var ret = Constant.Success;

            try
            {
                using (var pctx = new PortalContext())
                {
                    if (data.Id > 0)
                    {
                        var temp = pctx.LkpDatasetFieldMapping.Where(x => x.Id == data.Id).Single();
                        if (data.UIAct == "Delete")
                        {
                            pctx.LkpDatasetFieldMapping.Remove(temp);
                        }
                        else
                        {
                            temp.Dsid = data.DSId;
                            temp.AttributeName = data.AttributeName;
                            temp.AutoFill = data.AutoFill.GetBoolValue();
                            temp.FieldName = data.FieldName;
                            temp.FillType = data.FillType.GetNullString();
                        }
                    }
                    else
                    {
                        pctx.LkpDatasetFieldMapping.Add(new LkpDatasetFieldMapping
                        {
                            AttributeName = data.AttributeName,
                            AutoFill = data.AutoFill.GetBoolValue(),
                            Dsid = data.DSId,
                            FieldName = data.FieldName,
                            FillType = data.FillType.GetNullString()
                        }) ;
                    }
                    pctx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public GetDIHistReplay GetDIHist()
        {
            var ret = new GetDIHistReplay();
                  
            try
            {
                using (var pctx = new PortalContext())
                {
                    var l = pctx.TblDataLoad.Include(x => x.Upload).ToList().OrderByDescending(x => x.Id);
                    var lkp = pctx.LkpDataset.ToList();

                    foreach (var di in l)
                    {
                        var ih = new DIHist
                        {
                            Id = di.Id,
                            FileName = di.Upload.FileName,
                            FilePath = di.Upload.ServerPath,
                            Size = (di.Upload.Size ?? 0L).ToString(),
                            Status = di.Status,
                            TemplateName = lkp.Where(x => x.Id == di.Dsid).Select(x => x.Name).Single(),
                            TotalRows = di.TotalRows ?? 0,
                            UploadDate = di.Upload.UploadDate.GetSafeDateTimeString(),
                            UploadPerson = di.Upload.UploadedBy.GetSafeString()
                        };

                        ret.DIHists.Add(ih);
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
           
            return ret;
        }
        public GetDIHistDetailReply GetDIHistDetail(int diid)
        {
            var ret = new GetDIHistDetailReply();

            try
            {
                using (var lactx = new PortalContext())
                {
                    var temp = lactx.TblDataLoadDetail.Where(x => x.Dlid == diid).Select(x => new DIDetail
                    {
                        Id = x.Id,
                        DIId = diid,
                        Message = x.Error.GetSafeString()
                    });
                    ret.DIDetails.AddRange(temp);
                }
            }
            catch (Exception)
            {
                throw;
            }

            return ret;
        }
    }
}
