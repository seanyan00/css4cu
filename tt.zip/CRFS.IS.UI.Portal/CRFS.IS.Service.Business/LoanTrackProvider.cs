﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Data.SqlClient;

using CRFS.IS.Service.Data;
using CRFS.IS.Service.Common;
using CRFS.IS.Service.GRpc;

namespace CRFS.IS.Service.Business
{
    public class LoanTrackProvider
    {
        private IConfiguration _config;
        private ILogger _logger;
        private LkpUsers _user;

        public LoanTrackProvider(IConfiguration config, ILogger logger, LkpUsers user)
        {
            _config = config;
            _logger = logger;
            _user = user;
        }

        public LTLoan GetLTLoan(string loannumber)
        {
            var ret = new LTLoan();
            string mortgagors = "";
            TblFhaloans fhaloan = null;
            var hudctx = new HUDClaimsContext();
            var cmsctx = new ClaimsManagementContext();

            var appctx = new ApplicationConfigurationContext();
            var lninfo = loannumber.Split(" ", StringSplitOptions.RemoveEmptyEntries);

            try
            {
                var clns = appctx.LkpClients.ToList();
               
                var lx = new TblInvestorTrackingLoans();
                if (lninfo.Length == 2) {
                    var clnid = clns.Single(x => x.ClientAbbreviation == lninfo[1].ToUpper()).ClientId;
                    lx = cmsctx.TblInvestorTrackingLoans.Single(x => x.LoanNumber == lninfo[0] && x.ClientId == clnid);
                } else
                {
                    lx = cmsctx.TblInvestorTrackingLoans.Where(x => x.LoanNumber == lninfo[0]).Take(1).Single();
                }

                fhaloan = hudctx.TblFhaloans.Where(x => x.InvTrkLoanId == lx.Id).SingleOrDefault();
                if(fhaloan != null)
                {
                    mortgagors = string.Join(", ", 
                        hudctx.TblFhamortgagors.Where(x => x.FhaloanId == fhaloan.FhaloanId).Select(x => x.MortgagorFirstName + " " + x.MortgagorLastName).ToList());
                }
                ret = new LTLoan
                    {
                        Id = lx.Id,
                        AcquisitionLoanSetByUserID = lx.AcquisitionLoanSetByUserId.GetIntValue(),
                        AquisitionLoanSetDate = lx.AquisitionLoanSetDate.GetSafeString(),
                        AquisitionLoanSetOnClaimID = lx.AquisitionLoanSetOnClaimId.GetIntValue(),
                        AttorneyName = lx.AttorneyName.GetSafeString(),
                        EvictionAttorney = lx.EvictionAttorney.GetSafeString(),
                        FHACaseNumber = lx.FhacaseNumber.GetSafeString(),
                        ForeClosureDate = lx.ForeClosureDate.GetSafeString(),
                        ForeclosureSaleDate = lx.ForeclosureSaleDate.GetSafeString(),
                        ForeclosureTypeID = lx.ForeclosureTypeId.GetIntValue(),
                        BorrowerFirstName = lx.BorrowerFirstName.GetSafeString(),
                        GADate = lx.Gadate.GetSafeString(),
                        IsAcquisitionLoan = lx.IsAcquisitionLoan.GetIntValue(),
                        InternalFormId = lx.InternalFormId.GetSafeValue(),
                        PropertyAcquisitionDate = lx.PropertyAcquisitionDate.GetSafeString(),
                        PropertyAddress = lx.PropertyAddress.GetSafeString(),
                        PandPCompany = lx.PandPcompany.GetSafeString(),
                        ServicerAddress = lx.ServicerAddress.GetSafeString(),
                        VACaseNumber = lx.VacaseNumber.GetSafeString(),
                        BorrowerLastName = lx.BorrowerLastName.GetSafeString(),
                        ClientId = lx.ClientId,
                        ClientName = "",
                        CMaxClientID = lx.CmaxClientId.GetSafeString(),
                        MICertNumber = lx.MicertNumber.GetSafeString(),
                        DeedInLeuRecordDate = lx.DeedInLeuRecordDate.GetSafeString(),
                        InvestorID = lx.InvestorId.GetSafeString(),
                        InvestorLoanNumber = lx.InvestorLoanNumber.GetSafeString(),
                        InvestorName = lx.InvestorName.GetSafeString(),
                        LiquidationDate = lx.LiquidationDate.GetSafeString(),
                        LoanNumber = lx.LoanNumber,
                        MarketingExpirationDate = lx.MarketingExpirationDate.GetSafeString(),
                        MICompanyID = lx.MicompanyId.GetIntValue(),
                        MIFiledDate = lx.MifiledDate.GetSafeString(),
                        MIGuarantyNumber = lx.MiguarantyNumber.GetSafeString(),
                        NonLiquidationDate = lx.NonLiquidationDate.GetSafeString(),
                        NPLSaleDate = lx.NplsaleDate.GetSafeString(),
                        OldLoanNumber = lx.OldLoanNumber.GetSafeString(),
                        PCCDate = lx.Pccdate.GetSafeString(),
                        PoolCertNumber = lx.PoolCertNumber.GetSafeString(),
                        PoolCompany = lx.PoolCompany.GetSafeString(),
                        PoolFiledDate = lx.PoolFiledDate.GetSafeString(),
                        PreForeclosureSettlementDate = lx.PreForeclosureSettlementDate.GetSafeString(),
                        PropertyCity = lx.PropertyCity.GetSafeString(),
                        PropertyState = lx.PropertyState.GetSafeString(),
                        PropertyZip = lx.PropertyZip.GetSafeString(),
                        ThirdPartySaleDate = lx.ThirdPartySaleDate.GetSafeString(),
                        ReferDateToMI = lx.ReferDateToMi.GetSafeString(),
                        RefundingDate = lx.RefundingDate.GetSafeString(),
                        REOSaleDate = lx.ReosaleDate.GetSafeString(),
                        RRCDate = lx.Rrcdate.GetSafeString(),
                        SellerServicerNumber = lx.SellerServicerNumber.GetSafeString(),
                        ServicerCity = lx.ServicerCity.GetSafeString(),
                        ServicerName = lx.ServicerName.GetSafeString(),
                        ServicerNumber = lx.ServicerNumber.GetSafeString(),
                        ServicerState = lx.ServicerState.GetSafeString(),
                        ServicerZip = lx.ServicerZip.GetSafeString(),
                        TitleCompany = lx.TitleCompany.GetSafeString(),
                        FHAMortgagors = mortgagors
                        };
                if(ret != null)
                {
                    ret.ClientName = clns.Where(x => x.ClientId == ret.ClientId).Select(x => x.ClientDisplayName).Single();
                }
                              
                if (ret != null &&  ret.Id > 0)
                {
                    var temp = hudctx.TblFhaloans.Where(x => x.InvTrkLoanId == ret.Id).SingleOrDefault();
                    if(temp != null)
                    {
                        ret.AuthorizedBidAmount = (double)temp.AuthorizedBidAmount.GetSafeValue();
                        ret.SuccessfulBidAmount = (double)temp.SuccessfulBidAmount.GetSafeValue();
                        ret.SecondChanceDate = temp.SecondChanceSaleDate.GetSafeString();
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                appctx.Dispose();
                hudctx.Dispose();
                cmsctx.Dispose();
            }
            return ret;
        }
        public GetLTClaimsReply GetClaims(int loanid)
        {
            var ret = new GetLTClaimsReply();
            try
            {
                var cl = new List<LTClaim>();
                using(var ctx = new ClaimsManagementContext())
                {
                    var clmtyp = ctx.TbllkpClaimTypesByForm.ToList();

                    var temp = ctx.TblInvestorTrackingClaims.Where(x => x.LoanId == loanid).Select(x => new 
                    {
                        Id = x.Id,
                        ClaimClosed = x.ClaimClosed ? "Yes" : "No",
                        ClaimTypeId = x.ClaimType,
                        DueDate = x.ClaimDueDate.GetSafeString(),
                        ReferralDate = x.ReferralDate.GetSafeString(),
                        NoteRate = ""
                    }).ToList();
                    foreach(var tt in temp)
                    {
                        cl.Add(new LTClaim
                        {
                            Id = tt.Id,
                            ClaimClosed = tt.ClaimClosed,
                            ClaimType = clmtyp.Where(x => x.Id == tt.ClaimTypeId).Select(x => x.ClaimType).Single(),
                            DueDate = tt.DueDate,
                            ReferralDate = tt.ReferralDate,
                            NoteRate = ""
                        });
                    }
                }
                using(var hudctx = new HUDClaimsContext())
                {
                    foreach(var t in cl)
                    {
                        if(hudctx.TblFhaclaims.Any(x => x.InvTrkClaimId == t.Id && x.NoteRate > 0))
                           t.NoteRate = hudctx.TblFhaclaims.Where(x => x.InvTrkClaimId == t.Id && x.NoteRate > 0).Select(x => (x.NoteRate * 100).ToString() + "%").FirstOrDefault();
                    }
                }
                ret.LTClaims.AddRange(cl);
            }
            catch(Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetClaimSubmitStatusReply GetClaimSubmitStatus(int claimid)
        {
            var ret = new GetClaimSubmitStatusReply();
            try
            {
                var cl = new List<LTClaim>();
                using (var ctx = new ClaimsManagementContext())
                {
                    var temp = ctx.TblSubmitActions.Where(x => x.CmsclaimId == claimid).OrderByDescending(x => x.ActionDateTime).ToList()
                        .Select(x => new ClaimSubmitStatus
                    {
                        Id = x.ActionId,
                        ActionDateTime = x.ActionDateTime.GetSafeDateTimeString(),
                        ActionDetail = x.ActionDetails.GetSafeString(),
                        ActionSummary = x.ActionSummary.GetSafeString()
                    }).ToList(); 
                    ret.ClaimSubmitStatuses.AddRange(temp);
                }
            }
            catch 
            {
                throw;
            }
            return ret;
        }
        public MessageReply SaveLTLoan(SaveLTLoanRequest data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };
           
            var loannumchanged = false;
            try
            {
                using (var cmsctx = new ClaimsManagementContext())
                {
                    var micoms = cmsctx.TbllkpMicompanies.ToList();

                    var temp = cmsctx.TblInvestorTrackingLoans.Where(x => x.Id == data.LoanId).Single();
                    if(temp.LoanNumber != data.LoanNumber)
                    {
                        loannumchanged = true;
                     
                        if (cmsctx.TblInvestorTrackingLoans.Any(x => x.Id != data.LoanId && x.LoanNumber == data.LoanNumber && x.ClientId == data.ClientId))
                        {
                            throw new Exception("Duplicated Loan# found");
                        }
                    }
                    if(loannumchanged
                        || temp.VacaseNumber != data.VACaseNumber
                        || temp.FhacaseNumber != data.FHACaseNumber
                        || (temp.MicompanyId ?? 0) != (data.MICompanyId.GetNullIntOrId() ?? 0)
                        || temp.MicertNumber != data.MICertNumber
                        || temp.PoolCompany != data.PoolCompany
                        || temp.PoolCertNumber != data.PoolCertNumber
                        || temp.InvestorId != data.InvestorID
                        || temp.InvestorName != data.InvestorName
                        || temp.InvestorLoanNumber != data.InvestorLoanNumber
                        || temp.PropertyAddress != data.PropertyAddress
                        || temp.PropertyCity != data.PropertyCity
                        || temp.PropertyState != data.PropertyState
                        || temp.PropertyZip != data.PropertyZip
                        || temp.AttorneyName != data.AttorneyName
                        || temp.EvictionAttorney != data.EvictionAttorney
                        || temp.BorrowerFirstName != data.BorrowerFirstName
                        || temp.BorrowerLastName != data.BorrowerLastName
                        || temp.TitleCompany != data.TitleCompany
                        || temp.PandPcompany != data.PandPCompany)
                    {
                        if (loannumchanged)
                            AddLoanNote(cmsctx, data.LoanId, "LoanNumber", temp.LoanNumber, data.LoanNumber);
                        if ((temp.MicompanyId ?? 0) != (data.MICompanyId.GetNullIntOrId() ?? 0))
                        {
                            AddLoanNote(cmsctx, data.LoanId, "MI Company Id", micoms.Single(x => x.Id == temp.MicompanyId).MicompanyName, 
                                                                      micoms.Single(x => x.Id == data.MICompanyId).MicompanyName);
                            temp.MicompanyId = data.MICompanyId.GetNullIntOrId();
                        }
                        if (temp.MicertNumber != data.MICertNumber)
                        {
                            AddLoanNote(cmsctx, data.LoanId, "MICertNumber", temp.MicertNumber, data.MICertNumber);
                            temp.MicertNumber = data.MICertNumber;
                        }
                        if (temp.PoolCompany != data.PoolCompany)
                        {
                            AddLoanNote(cmsctx, data.LoanId, "Pool Company", temp.PoolCompany, data.PoolCompany);
                            temp.PoolCompany = data.PoolCompany;
                        }
                        if (temp.PoolCertNumber != data.PoolCertNumber)
                        {
                            AddLoanNote(cmsctx, data.LoanId, "PoolCertNumber", temp.PoolCertNumber, data.PoolCertNumber);
                            temp.PoolCertNumber = data.PoolCertNumber;
                        }
                        if (temp.InvestorId != data.InvestorID)
                        {
                            AddLoanNote(cmsctx, data.LoanId, "InvestorId", temp.InvestorId, data.InvestorID);
                            temp.InvestorId = data.InvestorID;
                        }
                        if (temp.InvestorName != data.InvestorName)
                        {
                            AddLoanNote(cmsctx, data.LoanId, "InvestorName", temp.InvestorName, data.InvestorName);
                            temp.InvestorName = data.InvestorName;
                        }
                        if (temp.InvestorLoanNumber != data.InvestorLoanNumber)
                        {
                            AddLoanNote(cmsctx, data.LoanId, "InvestorLoanNumber", temp.InvestorLoanNumber, data.InvestorLoanNumber);
                            temp.InvestorLoanNumber = data.InvestorLoanNumber;
                        }
                        if (temp.PropertyAddress != data.PropertyAddress)
                        {
                            AddLoanNote(cmsctx, data.LoanId, "PropertyAddress", temp.PropertyAddress, data.PropertyAddress);
                            temp.PropertyAddress = data.PropertyAddress;
                        }
                        if (temp.PropertyCity != data.PropertyCity)
                        {
                            AddLoanNote(cmsctx, data.LoanId, "PropertyCity", temp.PropertyCity, data.PropertyCity);
                            temp.PropertyCity = data.PropertyCity;
                        }
                        if ((temp.PropertyState == null && !string.IsNullOrEmpty(data.PropertyState)) || (temp.PropertyState != null && temp.PropertyState.Trim() != data.PropertyState.Trim()))
                        {
                            AddLoanNote(cmsctx, data.LoanId, "PropertyState", temp.PropertyState, data.PropertyState);
                            temp.PropertyState = data.PropertyState;
                        }
                        if ((temp.PropertyZip == null && !string.IsNullOrEmpty(data.PropertyZip)) || (temp.PropertyZip != null && temp.PropertyZip.Trim() != data.PropertyZip.Trim()))
                        {
                            AddLoanNote(cmsctx, data.LoanId, "PropertyZip", temp.PropertyZip, data.PropertyZip);
                            temp.PropertyZip = data.PropertyZip;
                        }
                        if ((temp.AttorneyName == null && !string.IsNullOrEmpty(data.AttorneyName)) || (temp.AttorneyName != null && temp.AttorneyName.Trim() != data.AttorneyName.Trim()))
                        {
                            AddLoanNote(cmsctx, data.LoanId, "AttorneyName", temp.AttorneyName, data.AttorneyName);
                            temp.AttorneyName = data.AttorneyName;
                        }
                        if ((temp.EvictionAttorney == null && !string.IsNullOrEmpty(data.EvictionAttorney)) || (temp.EvictionAttorney != null && temp.EvictionAttorney.Trim() != data.EvictionAttorney.Trim()))
                        {
                            AddLoanNote(cmsctx, data.LoanId, "EvictionAttorney", temp.EvictionAttorney, data.EvictionAttorney);
                            temp.EvictionAttorney = data.EvictionAttorney;
                        }
                        if ((temp.BorrowerFirstName == null && !string.IsNullOrEmpty(data.BorrowerFirstName)) || (temp.BorrowerFirstName != null && temp.BorrowerFirstName.Trim() != data.BorrowerFirstName.Trim()))
                        {
                            AddLoanNote(cmsctx, data.LoanId, "BorrowerFirstName", temp.BorrowerFirstName, data.BorrowerFirstName);
                            temp.BorrowerFirstName = data.BorrowerFirstName;
                        }
                        if ((temp.BorrowerLastName == null && !string.IsNullOrEmpty(data.BorrowerLastName)) || (temp.BorrowerLastName != null && temp.BorrowerLastName.Trim() != data.BorrowerLastName.Trim()))
                        {
                            AddLoanNote(cmsctx, data.LoanId, "BorrowerLastName", temp.BorrowerLastName, data.BorrowerLastName);
                            temp.BorrowerLastName = data.BorrowerLastName;
                        }
                        if ((temp.TitleCompany == null && !string.IsNullOrEmpty(data.TitleCompany)) || (temp.TitleCompany != null && temp.TitleCompany.Trim() != data.TitleCompany.Trim()))
                        {
                            AddLoanNote(cmsctx, data.LoanId, "TitleCompany", temp.TitleCompany, data.TitleCompany);
                            temp.TitleCompany = data.TitleCompany;
                        }
                        if ((temp.PandPcompany == null && !string.IsNullOrEmpty(data.PandPCompany)) || (temp.PandPcompany != null && temp.PandPcompany.Trim() != data.PandPCompany.Trim()))
                        {
                            AddLoanNote(cmsctx, data.LoanId, "PandPcompany", temp.PandPcompany, data.PandPCompany);
                            temp.PandPcompany = data.PandPCompany;
                        }
                        temp.LastUpdateDate = DateTime.Now;
                        temp.LastUpdateUser = _user.UserId; 
                        if (loannumchanged)
                        {
                            temp.OldLoanNumber = temp.LoanNumber;
                            temp.LoanNumber = data.LoanNumber;
                        }  
                        cmsctx.SaveChanges();
                    }

                    if (temp.VacaseNumber != data.VACaseNumber)
                    { 
                        AddLoanNote(cmsctx, data.LoanId, "VACaseNumber", temp.VacaseNumber, data.VACaseNumber);
                        cmsctx.SaveChanges();
                        ChangeVANumber(cmsctx, temp, data.VACaseNumber);
                    }

                    if (temp.FhacaseNumber != data.FHACaseNumber)
                    {                        
                        AddLoanNote(cmsctx, data.LoanId, "FHACaseNumber", temp.FhacaseNumber, data.FHACaseNumber);
                        cmsctx.SaveChanges();
                        ChangeFHANumber(cmsctx, temp, data.FHACaseNumber);
                    }
                }
                if (loannumchanged)
                {
                    using(var hudctx = new HUDClaimsContext())
                    {
                        if (hudctx.TblFhaloans.Any(x => x.InvTrkLoanId == data.LoanId))
                        {
                            var htemp = hudctx.TblFhaloans.Where(x => x.InvTrkLoanId == data.LoanId).Single();
                            htemp.MortgageeLoanNumber = data.LoanNumber;
                            htemp.LastUpdateUser = _user.UserId;
                            htemp.LastUpdateDate = DateTime.Now;

                            hudctx.SaveChanges();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public MessageReply BackoutLoan(BackoutLoanRequest data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };
            try
            {
                using (var ctx = new ClaimsManagementContext())
                {
                    var loannum = ctx.TblInvestorTrackingLoans.Where(x => x.Id == data.LoanId).Select(x => x.LoanNumber).Single();
                    var ttlclm = ctx.TblInvestorTrackingClaims.Where(x => x.LoanId == data.LoanId).Count();
                    int prcd = 0;

                    System.Data.Common.DbCommand cmd = ctx.Database.GetDbConnection().CreateCommand();

                    cmd.CommandTimeout = Constant.DBCommandTimeout;

                    cmd.CommandText = "dbo.usp_AdminFunction_ReferralBackout";
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    if (cmd.Connection.State != System.Data.ConnectionState.Open)
                        cmd.Connection.Open();
                    if(data.ClaimIds.Count < 1)
                    {
                        SqlParameter p1 = new SqlParameter("@LoanNumber", loannum);
                        cmd.Parameters.Add(p1);
                        p1 = new SqlParameter("@ClientName", data.ClientName);
                        cmd.Parameters.Add(p1);
                        p1 = new SqlParameter("@ClaimNumber", DBNull.Value);
                        cmd.Parameters.Add(p1);
                        p1 = new SqlParameter("@BackoutUserLoginName", _user.Login);
                        cmd.Parameters.Add(p1);
                        p1 = new SqlParameter("@BackoutReason", data.BackoutReason);
                        cmd.Parameters.Add(p1);
                        cmd.ExecuteNonQuery();
                    } else
                    {
                        foreach(var clm in data.ClaimIds)
                        {
                            cmd.Parameters.Clear();
                            SqlParameter p1 = new SqlParameter("@LoanNumber", loannum);
                            cmd.Parameters.Add(p1);
                            p1 = new SqlParameter("@ClientName", data.ClientName);
                            cmd.Parameters.Add(p1);
                            p1 = new SqlParameter("@BackoutUserLoginName", _user.Login);
                            cmd.Parameters.Add(p1);
                            p1 = new SqlParameter("@BackoutReason", data.BackoutReason);
                            cmd.Parameters.Add(p1);
                            if (++prcd == ttlclm)
                                p1 = new SqlParameter("@ClaimNumber", DBNull.Value);
                            else
                                p1 = new SqlParameter("@ClaimNumber", clm);
                            cmd.Parameters.Add(p1);
                            cmd.ExecuteNonQuery();
                        }
                    }
                   
                    cmd.Dispose();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public LTClaimWithPart GetLTClaimWithPart(int id)
        {
            var ret = new LTClaimWithPart { Claim = new LTClaim(), PartA = new LTFHAClaimPartA(), PartB = new LTFHAClaimPartB { } };
            TblFhaclaims hudclaim = null;

            using(var hudctx = new HUDClaimsContext())
            {
                hudclaim = hudctx.TblFhaclaims.SingleOrDefault(x => x.InvTrkClaimId == id);
            }
            using (var cmsctx = new ClaimsManagementContext())
            {
                var clmtypes = cmsctx.TbllkpClaimTypesByForm.Where(x => x.FormId == 8 && (x.Active ?? false)).ToList();
                
                var temp = cmsctx.TblInvestorTrackingClaims.Include(x => x.TblInvestorTrackingClaimsFhaclaim).Single(x => x.Id == id);
                var fhaclm = temp.TblInvestorTrackingClaimsFhaclaim.SingleOrDefault();
                
                ret.Claim = new LTClaim
                {
                    ClaimClosed = temp.ClaimClosed ? "Yes" : "No",
                    Id = temp.Id,
                    ClaimSubTypeId = fhaclm == null ? 0 : fhaclm.ClaimSubTypeId ?? 0,
                    ClaimTypeId = temp.ClaimType,
                    ClaimType = clmtypes.Single(x => x.Id == temp.ClaimType).ClaimType,
                    FHAClaimId = fhaclm == null ? 0 : fhaclm.FhaclaimId,
                    DueDate = temp.ClaimDueDate.GetSafeString(),
                    HUDClaimId = hudclaim == null ? 0 : hudclaim.FhaclaimId,
                    NoteRate = "",
                    ReferralDate = temp.ReferralDate.GetSafeString()
                };
                if(fhaclm != null)
                {
                    ret.PartA = new LTFHAClaimPartA
                    {
                        EDIAuthAnalystId = fhaclm.ConvEdiauthorizedUserId ?? 0,
                        EDIAuthDate = fhaclm.ConvEdiauthorizedDate.GetSafeString(),
                        EDIAuthed = fhaclm.ConvPartAisEdiauthorized ? 1 : 0,
                        CompleteDate = fhaclm.PartAcompleteDate.GetSafeString(),
                        FHAClaimId = fhaclm.FhaclaimId,
                        PaidAmt = (double)fhaclm.ConvPartApaidAmount.GetSafeValue(),
                        ReSubDate = fhaclm.ConvPartAerrorSubmitDate.GetSafeDateTimeString(),
                        SettlementDate = fhaclm.ConvPartAsettlementDate.GetSafeDateTimeString(),
                        SubmitAmt = (double)fhaclm.ConvPartAclaimAmount.GetSafeValue(),
                        SubmitAnalystId = fhaclm.ConvPartAsubmittedAnalystId ?? 0,
                        SuspendDate = fhaclm.ConvPartAsuspendDate.GetSafeDateTimeString(),
                        EDIAllowed = IsEDIAllowed(id, "A").Message
                    };
                    ret.PartB = new LTFHAClaimPartB
                    {
                        EDIAuthAnalystId = fhaclm.EdiauthorizedUserId ?? 0,
                        EDIAuthDate = fhaclm.EdiauthorizedDate.GetSafeDateTimeString(),
                        EDIAuthed = fhaclm.IsEdiauthorized ? 1 : 0,
                        CompleteDate = fhaclm.ClaimSubmittedDate.GetSafeDateTimeString(),
                        FHAClaimId = fhaclm.FhaclaimId,
                        PaidAmt = (double)fhaclm.PaidAmount.GetSafeValue(),
                        SubmitAmt = (double)fhaclm.ClaimAmount.GetSafeValue(),
                        SubmitAnalystId = fhaclm.ClaimSubmittedAnalystId ?? 0,
                        ExpectedProceeds = (double)fhaclm.ExpectedPartBproceeds.GetSafeValue(),
                        ReSubDate = fhaclm.ErrorSubmitDate.GetSafeDateTimeString(),
                        SettlementDate = fhaclm.SettlementDate.GetSafeDateTimeString(),
                        SuspendDate = fhaclm.SuspendDate.GetSafeDateTimeString(),
                        EDIAllowed = IsEDIAllowed(id, "B").Message
                    };
                }
            }
            return ret;
        }
        public MessageReply SaveLTClaimWithPart(LTClaimWithPart clm)
        {
            var ret = new MessageReply { Id = 0, Message = Constant.Success };
            
            ClaimsManagementContext cmsctx = null;
            HUDClaimsContext hudctx = null;
            bool acheck = false;

            try
            {
                cmsctx = new ClaimsManagementContext();
                hudctx = new HUDClaimsContext();
                               
                var claim = cmsctx.TblInvestorTrackingClaims.Single(x => x.Id == clm.Claim.Id);
                var loan = cmsctx.TblInvestorTrackingLoans.Single(x => x.Id == claim.LoanId);

                var fhaclaim = cmsctx.TblInvestorTrackingClaimsFhaclaim.SingleOrDefault(x => x.ClaimId == clm.Claim.Id);

                var clmtyps = cmsctx.TbllkpClaimTypesByForm.Where(x => x.FormId == 8 && (x.Active ?? false)).ToList();
                var clmsubtyps = cmsctx.TbllkpFormsComboBoxValues.Where(x => x.FormId == 8 && x.ComboBoxTypeTag == "ClaimSubTypeId").ToList();
                var clmtypmap = hudctx.VwCmsclaimTypeHudclaimType.ToList();
                var clmsubtypmap = hudctx.VwCmsclaimSubTypeHudclaimSubType.ToList();
                var resubmittypeid = hudctx.LkpFhalookups.Single(x => x.Lucategory == "FHASubmitTypeID" && x.DisplayCode2 == "Resubmit" && x.DisplayCode1 == "EDIREV").FhalookupId;

                if(fhaclaim != null)
                {
                    var clmtyp = clmtyps.Single(x => x.Id == clm.Claim.ClaimTypeId).ClaimType;

                    var hudclaim = hudctx.TblFhaclaims.Single(x => x.InvTrkClaimId == clm.Claim.Id);
                    if(claim.ClaimType != clm.Claim.ClaimTypeId)
                    {
                        AddLoanNote(cmsctx, claim.LoanId, "ClaimType", clmtyps.Single(x => x.Id == claim.ClaimType).ClaimType, clmtyp);
                        claim.ClaimType = clm.Claim.ClaimTypeId;
                        hudclaim.ClaimTypeId = clmtypmap.Single(x => x.Id == clm.Claim.ClaimTypeId).FhalookupId;
                        
                    }
                    if(fhaclaim.ClaimSubTypeId != clm.Claim.ClaimSubTypeId)
                    {  
                        var osubtyp = clmsubtyps.SingleOrDefault(x => x.Id == fhaclaim.ClaimSubTypeId);
                        var nsubtyp = clmsubtyps.SingleOrDefault(x => x.Id == clm.Claim.ClaimSubTypeId);
                        AddLoanNote(cmsctx, claim.LoanId, "ClaimSubType", osubtyp == null ? "" : osubtyp.ComboBoxText,
                                                                nsubtyp == null ? "" : nsubtyp.ComboBoxText);
                        fhaclaim.ClaimSubTypeId = clm.Claim.ClaimSubTypeId;
                        hudclaim.FhaclaimSubTypeId = clmsubtypmap.Single(x => x.Id == clm.Claim.ClaimSubTypeId).FhalookupId;
                    }
                    fhaclaim.ConvPartAsettlementDate = clm.PartA.SettlementDate.GetNullDate();
                    fhaclaim.ConvPartApaidAmount = (decimal?)clm.PartA.PaidAmt;
                    fhaclaim.ConvPartAsuspendDate = clm.PartA.SuspendDate.GetNullDate();
                    fhaclaim.ConvPartAerrorSubmitDate = clm.PartA.ReSubDate.GetNullDate();

                    if (fhaclaim.ConvPartAisEdiauthorized != (clm.PartA.EDIAuthed == 1))
                    {
                        fhaclaim.ConvPartAisEdiauthorized = clm.PartA.EDIAuthed == 1;
                        fhaclaim.LastUpdateUser = _user.UserId;
                        fhaclaim.LastUpdateDate = DateTime.Now;

                        if (clm.PartA.EDIAuthed == 1)
                        {
                            fhaclaim.ConvEdiauthorizedDate = DateTime.Now;
                            fhaclaim.ConvEdiauthorizedUserId = _user.UserId;
                            acheck = true;

                            if(!string.IsNullOrEmpty(clm.PartA.SuspendDate))
                            {
                                 var asubmit = (from a in hudctx.TblFhaclaimEdilog 
                                                join b in hudctx.TblFhaclaimSubmitLog
                                                 on a.ClaimEdilogId equals b.ClaimEdilogId
                                               where a.FhaclaimId == hudclaim.FhaclaimId
                                                     && a.SubmitPart == "A"
                                                     && b.SubmitTypeId == null
                                               orderby b.FhaclaimSubmitLogId descending
                                               select b).FirstOrDefault();

                                if(asubmit != null)
                                {
                                    asubmit.SubmitTypeId = resubmittypeid;
                                    asubmit.LastUpdateDate = DateTime.Now;
                                    asubmit.LastUpdateUser = _user.UserId;
                                }
                            }
                        }
                        else
                        {
                            cmsctx.SaveChanges();
                            hudctx.SaveChanges();
                            UncheckEDI(clm.Claim.Id, loan.FhacaseNumber, loan.LoanNumber, clmtyp == "FHA Conveyance" ? "A" : "X");
                        }
                    }
                    fhaclaim.SettlementDate = clm.PartB.SettlementDate.GetNullDate();
                    fhaclaim.PaidAmount = (decimal?)clm.PartB.PaidAmt;
                    fhaclaim.SuspendDate = clm.PartB.SuspendDate.GetNullDate();
                    fhaclaim.ErrorSubmitDate = clm.PartB.ReSubDate.GetNullDate();

                    if (fhaclaim.IsEdiauthorized != (clm.PartB.EDIAuthed == 1))
                    {
                        fhaclaim.IsEdiauthorized = clm.PartB.EDIAuthed == 1;
                        fhaclaim.LastUpdateUser = _user.UserId;
                        fhaclaim.LastUpdateDate = DateTime.Now;

                        if (clm.PartB.EDIAuthed == 1)
                        {
                            if (acheck)
                                throw new Exception("Cannot Auth A and B at same time");

                            fhaclaim.EdiauthorizedDate = DateTime.Now;
                            fhaclaim.EdiauthorizedUserId = _user.UserId;

                            if (!string.IsNullOrEmpty(clm.PartB.SuspendDate))
                            {
                                var bsubmit = (from a in hudctx.TblFhaclaimEdilog
                                               join b in hudctx.TblFhaclaimSubmitLog
                                                on a.ClaimEdilogId equals b.ClaimEdilogId
                                               where a.FhaclaimId == hudclaim.FhaclaimId
                                                     && a.SubmitPart != "A"
                                                     && b.SubmitTypeId == null
                                               orderby b.FhaclaimSubmitLogId descending
                                               select b).FirstOrDefault();

                                if (bsubmit != null)
                                {
                                    bsubmit.SubmitTypeId = resubmittypeid;
                                    bsubmit.LastUpdateDate = DateTime.Now;
                                    bsubmit.LastUpdateUser = _user.UserId;
                                }
                            }
                        }
                        else
                        {
                            cmsctx.SaveChanges();
                            hudctx.SaveChanges();
                            UncheckEDI(clm.Claim.Id, loan.FhacaseNumber, loan.LoanNumber, clmtyp == "FHA Conveyance" ? "B" : "X");
                        }
                    }
                }
                cmsctx.SaveChanges();
                hudctx.SaveChanges();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if(cmsctx != null) { cmsctx.Dispose(); cmsctx = null; }
                if(hudctx != null) { hudctx.Dispose(); hudctx = null; }
            }
            return ret;
        }
        public GetClaimTypeSubTypeReply GetClaimTypeSubType()
        {
            var ret = new GetClaimTypeSubTypeReply();
        
            using (var hudctx = new HUDClaimsContext())
            {
                var temp = hudctx.VwHudclaimsInvTrkAndImportsClientClaimTypeClaimSubTypesOnboarded.Select(x => new ClaimTypeSubType
                {
                    ClientId = x.FhaclientId,
                    ClaimTypeId = x.InvTrkClaimTypeId,
                    ClaimSubTypeId = x.InvTrkClaimSubTypeId,
                    ClaimTypeName = x.InvTrkClaimTypeName,
                    ClaimSubTypeName = x.InvTrkClaimSubTypeName
                }).Distinct().ToList();
                ret.ClaimTypeSubTypes.AddRange(temp);
            }
            return ret;
        }
        public MessageReply IsEDIAllowed(int clmid, string part)
        {
            var ret = new MessageReply { Id = 0, Message = "" };

            using (var cmd = new ClaimsManagementContext().Database.GetDbConnection().CreateCommand())
            {
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT dbo.ufn_IsEDIAuthAllowed(" + clmid.ToString() + ",'" + part + "')";
                
                if (cmd.Connection.State != System.Data.ConnectionState.Open)
                    cmd.Connection.Open();

                ret.Message = cmd.ExecuteScalar().ToString();
            }

            return ret;      
        }
        private void UncheckEDI(int clmid, string fhacasenum, string loannum, string submitpart)
        {
            using (var cmd = new ClaimsManagementContext().Database.GetDbConnection().CreateCommand())
            {
                cmd.CommandText = "dbo.usp_ClaimsManagement_UncheckEDI";
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                if (cmd.Connection.State != System.Data.ConnectionState.Open)
                    cmd.Connection.Open();
             
                SqlParameter param = new SqlParameter("@UserID", System.Data.SqlDbType.BigInt);
                param.Value = _user.UserId;
                cmd.Parameters.Add(param);
                param = new SqlParameter("@ClaimID", System.Data.SqlDbType.BigInt);
                param.Value = clmid;
                cmd.Parameters.Add(param);
                param = new SqlParameter("@FHACaseNumber", System.Data.SqlDbType.VarChar, 12);
                param.Value = fhacasenum;
                cmd.Parameters.Add(param);
                param = new SqlParameter("@LoanNumber", System.Data.SqlDbType.VarChar, 10);
                param.Value = loannum;
                cmd.Parameters.Add(param);
                param = new SqlParameter("@Client", System.Data.SqlDbType.VarChar, 50);
                param.Value = "%";
                cmd.Parameters.Add(param);
                param = new SqlParameter("@ClaimType", System.Data.SqlDbType.VarChar, 50);
                param.Value = "%";
                cmd.Parameters.Add(param);
                param = new SqlParameter("@ClaimPart", System.Data.SqlDbType.VarChar, 1);
                param.Value = submitpart;
                cmd.Parameters.Add(param);
                var t2 = cmd.ExecuteScalar();
            }
        }
        private void ChangeVANumber(ClaimsManagementContext ctx, TblInvestorTrackingLoans loan, string vanum)
        {
            try
            {
                using (var cmd = ctx.Database.GetDbConnection().CreateCommand())
                {
                    cmd.CommandText = "dbo.usp_AdminFunction_UpdateVACaseNumber";
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    if (cmd.Connection.State != System.Data.ConnectionState.Open)
                        cmd.Connection.Open();

                    SqlParameter param = new SqlParameter("@LoanNumber", loan.LoanNumber);
                    cmd.Parameters.Add(param);
                    param = new SqlParameter("@OldVaCaseNumber", loan.VacaseNumber);
                    cmd.Parameters.Add(param);
                    param = new SqlParameter("@NewVaCaseNumber", vanum);
                    cmd.Parameters.Add(param);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        private void ChangeFHANumber(ClaimsManagementContext ctx, TblInvestorTrackingLoans loan, string fhanum)
        {
            try
            {
                using (var cmd = ctx.Database.GetDbConnection().CreateCommand())
                {
                    cmd.CommandText = "dbo.usp_AdminFunction_UpdateFHACaseNumber";
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    if (cmd.Connection.State != System.Data.ConnectionState.Open)
                        cmd.Connection.Open();

                    SqlParameter param = new SqlParameter("@LoanNumber", loan.LoanNumber);
                    cmd.Parameters.Add(param);
                    param = new SqlParameter("@OldFHACaseNumber", loan.FhacaseNumber);
                    cmd.Parameters.Add(param);
                    param = new SqlParameter("@NewFHACaseNumber", fhanum);
                    cmd.Parameters.Add(param);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        private void AddLoanNote(ClaimsManagementContext ctx, int lid, string field, string bval, string aval)
        {
            var comm = string.Format("{0} changed from {1} to {2} via Loan Tracking Portal",
                                     field, string.IsNullOrEmpty(bval) ? "" : bval, aval);

            var notetypeid = ctx.TbllkpFormsComboBoxValues.Single(x => x.ComboBoxTypeTag == "LoanNoteTypes" && x.ComboBoxText == "Data Edit").Id;

            ctx.TblInvestorTrackingLoansNotes.Add(new TblInvestorTrackingLoansNotes
            {
                Id = 0,
                LoanCommentTypeId = notetypeid,
                DateEntered = DateTime.Now,
                EnteredByUser = _user.UserId,
                LoanComment = comm,
                LoanId = lid
            });
        }
    }
}
