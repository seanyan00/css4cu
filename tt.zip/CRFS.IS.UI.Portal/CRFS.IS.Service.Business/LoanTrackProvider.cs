﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Data.SqlClient;

using CRFS.IS.Service.Data;
using CRFS.IS.Service.Common;
using CRFS.IS.Service.GRpc;

namespace CRFS.IS.Service.Business
{
    public class LoanTrackProvider
    {
        private IConfiguration _config;
        private ILogger _logger;
        private LkpUsers _user;

        public LoanTrackProvider(IConfiguration config, ILogger logger, LkpUsers user)
        {
            _config = config;
            _logger = logger;
            _user = user;
        }

        public LTLoan GetLTLoan(string loannumber)
        {
            var ret = new LTLoan();
            var appctx = new ApplicationConfigurationContext();
            try
            {
                var clns = appctx.LkpClients.ToList();

                using (var cmsctx = new ClaimsManagementContext())
                {
                    ret = cmsctx.TblInvestorTrackingLoans.Where(x => x.LoanNumber == loannumber).Select(
                        x => new LTLoan
                        {
                            Id = x.Id,
                            AcquisitionLoanSetByUserID = x.AcquisitionLoanSetByUserId.GetIntValue(),
                            AquisitionLoanSetDate = x.AquisitionLoanSetDate.GetSafeString(),
                            AquisitionLoanSetOnClaimID = x.AquisitionLoanSetOnClaimId.GetIntValue(),
                            AttorneyName = x.AttorneyName.GetSafeString(),
                            EvictionAttorney = x.EvictionAttorney.GetSafeString(),
                            FHACaseNumber = x.FhacaseNumber.GetSafeString(),
                            ForeClosureDate = x.ForeClosureDate.GetSafeString(),
                            ForeclosureSaleDate = x.ForeclosureSaleDate.GetSafeString(),
                            ForeclosureTypeID = x.ForeclosureTypeId.GetIntValue(),
                            BorrowerFirstName = x.BorrowerFirstName.GetSafeString(),
                            GADate = x.Gadate.GetSafeString(),
                            IsAcquisitionLoan = x.IsAcquisitionLoan.GetIntValue(),
                            InternalFormId = x.InternalFormId.GetSafeValue(),
                            PropertyAcquisitionDate = x.PropertyAcquisitionDate.GetSafeString(),
                            PropertyAddress = x.PropertyAddress.GetSafeString(),
                            PandPCompany = x.PandPcompany.GetSafeString(),
                            ServicerAddress = x.ServicerAddress.GetSafeString(),
                            VACaseNumber = x.VacaseNumber.GetSafeString(),
                            BorrowerLastName = x.BorrowerLastName.GetSafeString(),
                            ClientId = x.ClientId,
                            ClientName = "",
                            CMaxClientID = x.CmaxClientId.GetSafeString(),
                            MICertNumber = x.MicertNumber.GetSafeString(),
                            DeedInLeuRecordDate = x.DeedInLeuRecordDate.GetSafeString(),
                            InvestorID = x.InvestorId.GetSafeString(),
                            InvestorLoanNumber = x.InvestorLoanNumber.GetSafeString(),
                            InvestorName = x.InvestorName.GetSafeString(),
                            LiquidationDate = x.LiquidationDate.GetSafeString(),
                            LoanNumber = x.LoanNumber,
                            MarketingExpirationDate = x.MarketingExpirationDate.GetSafeString(),
                            MICompanyID = x.MicompanyId.GetIntValue(),
                            MIFiledDate = x.MifiledDate.GetSafeString(),
                            MIGuarantyNumber = x.MiguarantyNumber.GetSafeString(),
                            NonLiquidationDate = x.NonLiquidationDate.GetSafeString(),
                            NPLSaleDate = x.NplsaleDate.GetSafeString(),
                            OldLoanNumber = x.OldLoanNumber.GetSafeString(),
                            PCCDate = x.Pccdate.GetSafeString(),
                            PoolCertNumber = x.PoolCertNumber.GetSafeString(),
                            PoolCompany = x.PoolCompany.GetSafeString(),
                            PoolFiledDate = x.PoolFiledDate.GetSafeString(),
                            PreForeclosureSettlementDate = x.PreForeclosureSettlementDate.GetSafeString(),
                            PropertyCity = x.PropertyCity.GetSafeString(),
                            PropertyState = x.PropertyState.GetSafeString(),
                            PropertyZip = x.PropertyZip.GetSafeString(),
                            ThirdPartySaleDate = x.ThirdPartySaleDate.GetSafeString(),
                            ReferDateToMI = x.ReferDateToMi.GetSafeString(),
                            RefundingDate = x.RefundingDate.GetSafeString(),
                            REOSaleDate = x.ReosaleDate.GetSafeString(),
                            RRCDate = x.Rrcdate.GetSafeString(),
                            SellerServicerNumber = x.SellerServicerNumber.GetSafeString(),
                            ServicerCity = x.ServicerCity.GetSafeString(),
                            ServicerName = x.ServicerName.GetSafeString(),
                            ServicerNumber = x.ServicerNumber.GetSafeString(),
                            ServicerState = x.ServicerState.GetSafeString(),
                            ServicerZip = x.ServicerZip.GetSafeString(),
                            TitleCompany = x.TitleCompany.GetSafeString()
                            
                        }).FirstOrDefault();
                    if(ret != null)
                    {
                        ret.ClientName = clns.Where(x => x.ClientId == ret.ClientId).Select(x => x.ClientDisplayName).Single();
                    }
                }
                using(var hudctx = new HUDClaimsContext())
                {
                    if(ret.Id > 0)
                    {
                        var temp = hudctx.TblFhaloans.Where(x => x.InvTrkLoanId == ret.Id).SingleOrDefault();
                        if(temp != null)
                        {
                            ret.AuthorizedBidAmount = (double)temp.AuthorizedBidAmount.GetSafeValue();
                            ret.SuccessfulBidAmount = (double)temp.SuccessfulBidAmount.GetSafeValue();
                            ret.SecondChanceDate = temp.SecondChanceSaleDate.GetSafeString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                appctx.Dispose();
            }
            return ret;
        }
        public GetLTClaimsReply GetClaims(int loanid)
        {
            var ret = new GetLTClaimsReply();
            try
            {
                var cl = new List<LTClaim>();
                using(var ctx = new ClaimsManagementContext())
                {
                    var clmtyp = ctx.TbllkpClaimTypesByForm.ToList();

                    var temp = ctx.TblInvestorTrackingClaims.Where(x => x.LoanId == loanid).Select(x => new 
                    {
                        Id = x.Id,
                        ClaimClosed = x.ClaimClosed ? "Yes" : "No",
                        ClaimTypeId = x.ClaimType,
                        DueDate = x.ClaimDueDate.GetSafeString(),
                        ReferralDate = x.ReferralDate.GetSafeString(),
                        NoteRate = ""
                    }).ToList();
                    foreach(var tt in temp)
                    {
                        cl.Add(new LTClaim
                        {
                            Id = tt.Id,
                            ClaimClosed = tt.ClaimClosed,
                            ClaimType = clmtyp.Where(x => x.Id == tt.ClaimTypeId).Select(x => x.ClaimType).Single(),
                            DueDate = tt.DueDate,
                            ReferralDate = tt.ReferralDate,
                            NoteRate = ""
                        });
                    }
                }
                using(var hudctx = new HUDClaimsContext())
                {
                    foreach(var t in cl)
                    {
                        if(hudctx.TblFhaclaims.Any(x => x.InvTrkClaimId == t.Id && x.NoteRate > 0))
                           t.NoteRate = hudctx.TblFhaclaims.Where(x => x.InvTrkClaimId == t.Id && x.NoteRate > 0).Select(x => (x.NoteRate * 100).ToString() + "%").FirstOrDefault();
                    }
                }
                ret.LTClaims.AddRange(cl);
            }
            catch(Exception ex)
            {
                throw;
            }
            return ret;
        }
        public MessageReply SaveLTLoan(SaveLTLoanRequest data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };
            var loannumchanged = false;
            try
            {
                using (var cmsctx = new ClaimsManagementContext())
                {
                    var temp = cmsctx.TblInvestorTrackingLoans.Where(x => x.Id == data.LoanId).Single();
                    if (temp.LoanNumber != data.LoanNumber)
                    {
                        temp.OldLoanNumber = temp.LoanNumber;
                        temp.LoanNumber = data.LoanNumber;
                        temp.LastUpdateDate = DateTime.Now;
                        temp.LastUpdateUser = _user.UserId;

                        cmsctx.SaveChanges();
                        loannumchanged = true;
                    }
                    if (temp.VacaseNumber != data.VACaseNumber)
                        ChangeVANumber(cmsctx, temp, data.VACaseNumber);

                    if (temp.FhacaseNumber != data.FHACaseNumber)
                        ChangeFHANumber(cmsctx, temp, data.FHACaseNumber);
                    
                }
                if (loannumchanged)
                {
                    using(var hudctx = new HUDClaimsContext())
                    {
                        if (hudctx.TblFhaloans.Any(x => x.InvTrkLoanId == data.LoanId))
                        {
                            var htemp = hudctx.TblFhaloans.Where(x => x.InvTrkLoanId == data.LoanId).Single();
                            htemp.MortgageeLoanNumber = data.LoanNumber;
                            htemp.LastUpdateUser = _user.UserId;
                            htemp.LastUpdateDate = DateTime.Now;

                            hudctx.SaveChanges();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public MessageReply BackoutLoan(BackoutLoanRequest data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };
            try
            {
                using (var ctx = new ClaimsManagementContext())
                {
                    var loannum = ctx.TblInvestorTrackingLoans.Where(x => x.Id == data.LoanId).Select(x => x.LoanNumber).Single();
                    var ttlclm = ctx.TblInvestorTrackingClaims.Where(x => x.LoanId == data.LoanId).Count();
                    int prcd = 0;

                    System.Data.Common.DbCommand cmd = ctx.Database.GetDbConnection().CreateCommand();

                    cmd.CommandTimeout = Constant.DBCommandTimeout;

                    cmd.CommandText = "dbo.usp_AdminFunction_ReferralBackout";
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    if (cmd.Connection.State != System.Data.ConnectionState.Open)
                        cmd.Connection.Open();
                    if(data.ClaimIds.Count < 1)
                    {
                        SqlParameter p1 = new SqlParameter("@LoanNumber", loannum);
                        cmd.Parameters.Add(p1);
                        p1 = new SqlParameter("@ClientName", data.ClientName);
                        cmd.Parameters.Add(p1);
                        p1 = new SqlParameter("@ClaimNumber", DBNull.Value);
                        cmd.Parameters.Add(p1);
                        p1 = new SqlParameter("@BackoutUserLoginName", _user.Login);
                        cmd.Parameters.Add(p1);
                        p1 = new SqlParameter("@BackoutReason", data.BackoutReason);
                        cmd.Parameters.Add(p1);
                        cmd.ExecuteNonQuery();
                    } else
                    {
                        foreach(var clm in data.ClaimIds)
                        {
                            cmd.Parameters.Clear();
                            SqlParameter p1 = new SqlParameter("@LoanNumber", loannum);
                            cmd.Parameters.Add(p1);
                            p1 = new SqlParameter("@ClientName", data.ClientName);
                            cmd.Parameters.Add(p1);
                            p1 = new SqlParameter("@BackoutUserLoginName", _user.Login);
                            cmd.Parameters.Add(p1);
                            p1 = new SqlParameter("@BackoutReason", data.BackoutReason);
                            cmd.Parameters.Add(p1);
                            if (++prcd == ttlclm)
                                p1 = new SqlParameter("@ClaimNumber", DBNull.Value);
                            else
                                p1 = new SqlParameter("@ClaimNumber", clm);
                            cmd.Parameters.Add(p1);
                            cmd.ExecuteNonQuery();
                        }
                    }
                   
                    cmd.Dispose();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        private void ChangeVANumber(ClaimsManagementContext ctx, TblInvestorTrackingLoans loan, string vanum)
        {
            try
            {
                using (var cmd = ctx.Database.GetDbConnection().CreateCommand())
                {
                    cmd.CommandText = "dbo.usp_AdminFunction_UpdateVACaseNumber";
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    if (cmd.Connection.State != System.Data.ConnectionState.Open)
                        cmd.Connection.Open();

                    SqlParameter param = new SqlParameter("@LoanNumber", loan.LoanNumber);
                    cmd.Parameters.Add(param);
                    param = new SqlParameter("@OldVaCaseNumber", loan.VacaseNumber);
                    cmd.Parameters.Add(param);
                    param = new SqlParameter("@NewVaCaseNumber", vanum);
                    cmd.Parameters.Add(param);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        private void ChangeFHANumber(ClaimsManagementContext ctx, TblInvestorTrackingLoans loan, string fhanum)
        {
            try
            {
                using (var cmd = ctx.Database.GetDbConnection().CreateCommand())
                {
                    cmd.CommandText = "dbo.usp_AdminFunction_UpdateFHACaseNumber";
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    if (cmd.Connection.State != System.Data.ConnectionState.Open)
                        cmd.Connection.Open();

                    SqlParameter param = new SqlParameter("@LoanNumber", loan.LoanNumber);
                    cmd.Parameters.Add(param);
                    param = new SqlParameter("@OldFHACaseNumber", loan.FhacaseNumber);
                    cmd.Parameters.Add(param);
                    param = new SqlParameter("@NewFHACaseNumber", fhanum);
                    cmd.Parameters.Add(param);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
