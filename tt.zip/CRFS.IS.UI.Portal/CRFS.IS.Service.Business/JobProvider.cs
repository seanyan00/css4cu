﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using System.Reflection;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;

using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.Common;
using CRFS.IS.Service.Business.Jobs;
using CRFS.IS.Service.Business.Models;

namespace CRFS.IS.Service.Business
{
    public class JobProvider
    {
        private ILogger _logger;
        private AppSettings _appsetting;
        private LkpUsers _user;
        public JobProvider(ILogger logger, AppSettings appsetting, LkpUsers user)
        {
            _logger = logger;
            _appsetting = appsetting;
            _user = user;
        }
        public MessageReply RunJob(int id)
        {
            var ret = new MessageReply { Message = Constant.Success };

            try
            {
                using (var ctx = new PortalContext())
                {
                    var config = ctx.TblScheduledJob.Where(x => x.Id == id && x.Active).Select(x => new SchItem { 
                         Id = x.Id,
                         AppName = x.AppName,
                         ClassName = x.ClassName,
                         Params = x.Params,
                         Cron = x.Cron
                    }).Single();

                    ret.Message = new FHACatalystXMLJob(config, _logger, _appsetting).DoJob(_user.UserId, _user.UserName);
                }
            } 
            catch(Exception ex)
            {
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return ret;
        }

        public MessageReply SaveConfig(JobConfig config)
        {
            var ret = new MessageReply { Id = 0, Message = Constant.Success };

            try
            {
                using (var ctx = new PortalContext())
                {
                    if (config.Id > 0)
                    {
                        var jc = ctx.TblScheduledJob.Where(x => x.Id == config.Id).Single();
                        jc.ClassName = config.ClassName;
                        jc.Cron = config.Cron;
                        jc.Active = config.Active == 1;
                        jc.UpdatedBy = _user.UserId;
                        jc.UpdatedDate = DateTime.Now;
                        jc.Params = config.Params;
                        ctx.SaveChanges();
                    }
                    else
                    {
                        var temp = new TblScheduledJob
                        {
                            Id = 0,
                            AppName = config.AppName,
                            ClassName = config.ClassName,
                            Cron = config.Cron,
                            Params = config.Params,
                            Active = true,
                            EnteredBy = _user.UserId,
                            EnteredDate = DateTime.Now,
                            UpdatedBy = _user.UserId,
                            UpdatedDate = DateTime.Now

                        };
                        ctx.TblScheduledJob.Add(temp);
                        ctx.SaveChanges();
                        ret.Id = temp.Id;
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public JobConfig GetConfig(int id)
        {
            var ret = new JobConfig();

            try
            {
                using(var ctx = new PortalContext())
                {
                    if(id == 0)
                    {
                        ret = ctx.TblScheduledJob.Select(x => new JobConfig
                        {
                            Id = x.Id,
                            AppName = x.AppName,
                            ClassName = x.ClassName.GetSafeString(),
                            Cron = x.Cron,
                            Active = x.Active ? 1 : 0,
                            Params = x.Params.GetSafeString()
                        }).First();
                    }
                    if (id > 0)
                    {
                        ret = ctx.TblScheduledJob.Where(x => x.Id == id).Select(x => new JobConfig
                        {
                            Id = x.Id,
                            AppName = x.AppName,
                            ClassName = x.ClassName.GetSafeString(),
                            Cron = x.Cron,
                            Active = x.Active ? 1 : 0,
                            Params = x.Params.GetSafeString()
                        }).Single();
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public GetJobHistoryReply GetHistory()
        {
            var ret = new GetJobHistoryReply();
            try
            {
                using(var ctx = new PortalContext())
                {
                    var temp = ctx.TblScheduledJobStatus.Include(x => x.Job).ToList().Select(x => new JobHistory
                    {
                        Id = x.Id,
                        AppName = x.Job.AppName,
                        Message = x.Message,
                        Status = x.Status,
                        TimeEnd = x.TimeEnd.GetSafeDateTimeString(),
                        TimeStart = x.TimeStart.GetSafeDateTimeString(),
                        RunBy = x.RunBy,
                        RunDate = x.TimeStart.GetSafeString()
                    }).OrderByDescending(x => x.TimeStart).ToList();
                    ret.Hists.AddRange(temp);
                }
            }
            catch(Exception ex)
            {
                throw;
            }

            return ret;
        }
    }
}