﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Google.Protobuf.WellKnownTypes;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.Common.TransferObjects;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Security;

namespace CRFS.IS.Service.Business
{
    public class AdminProvider
    {
        private IConfiguration _config;
        private ILogger _logger;
        private int _userid;

        public AdminProvider(IConfiguration config, ILogger logger, int uid)
        {
            _config = config;
            _logger = logger;
            _userid = uid;
        }
        public GetUsersReply GetUsers()
        {
            var ret = new GetUsersReply();

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    var temp = acctx.LkpUsers.Select(x => new PortalUser
                    {
                        Active = x.Active ? 1 : 0,
                     //   AllClientAccess = x.AllClientAccess.GetIntValue(),
                        EmploymentTypeID = x.EmploymentTypeId.GetIntValue(),
                        FirstName = x.FirstName.GetSafeString(),
                        LastName = x.LastName.GetSafeString(),
                        LastPWChange = x.LastPwchange.GetSafeString(),
                        LegacyCMSUserID = x.LegacyCmsuserId.GetIntValue(),
                        Login = x.Login,
                        Password = Constant.PasswordStr,
                        PhoneNum = x.PhoneNum.GetSafeString(),
                        SecurityGroupID = x.SecurityGroupId.GetIntValue(),
                        UserEmailAddress = x.UserEmailAddress.GetSafeString(),
                        UserID = x.UserId,
                        UserName = x.UserName
                    }).ToList();

                    ret.Users.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveUser(PortalUser data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    if(data.UserID > 0)
                    {
                        var temp = acctx.LkpUsers.Where(x => x.UserId == data.UserID).Single();
                        temp.LastUpdateDate = DateTime.Now;
                        temp.LastUpdateUserId = _userid;

                        temp.Active = data.Active == 1;
                    //    temp.AllClientAccess = data.AllClientAccess.GetBoolValue();
                        temp.EmploymentTypeId = data.EmploymentTypeID.GetNullValue();
                        temp.FirstName = data.FirstName;
                        temp.LastName = data.LastName;
                        //temp.LastPwchange = Convert.ToDateTime(data.LastPWChange);
                        temp.LegacyCmsuserId = data.LegacyCMSUserID.GetNullValue();
                        //temp.Password =
                        temp.PhoneNum = data.PhoneNum;
                        temp.SecurityGroupId = data.SecurityGroupID.GetNullValue();
                        temp.UserEmailAddress = data.UserEmailAddress;
                        temp.UserName = data.UserName;

                        acctx.SaveChanges();
                    }
                    else
                    {
                        var temp = new LkpUsers
                        {
                            UserId = 0,
                            Active = data.Active == 1,
                            EmploymentTypeId = data.EmploymentTypeID,
                            EnteredByUserId = _userid,
                            EnteredDate = DateTime.Now,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUserId = _userid,
                            LastPwchange = DateTime.Now,
                            LastName = data.LastName,
                            FirstName = data.FirstName,
                            LegacyCmsuserId = data.LegacyCMSUserID.GetNullValue(),
                            Login = data.Login,
                            Password = PasswordSecurity.Encrypt(data.Password == Constant.PasswordStr ? Constant.InitPassword : data.Password, true),
                            UserEmailAddress = data.UserEmailAddress,
                            UserName = data.UserName,
                            SecurityGroupId = data.SecurityGroupID.GetNullValue()
                        };
                        acctx.LkpUsers.Add(temp); 
                        acctx.SaveChanges();

                        temp.LegacyCmsuserId = temp.UserId;
                        acctx.SaveChanges();

                        ret.Id = temp.UserId;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetGroupsReply GetGroups()
        {
            var ret = new GetGroupsReply();

            try
            {
                using (var portalctx = new PortalContext())
                {
                    var temp = portalctx.LkpGroup.Select(x => new PortalGroup
                    {
                        Id = x.Id,
                        Name = x.Name,
                        Description = x.Description.GetSafeString()
                    }).OrderBy(x => x.Name).ToList();

                    ret.Groups.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveGroup(PortalGroup data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var portalctx = new PortalContext())
                {
                    if (data.Id > 0)
                    {
                        var temp = portalctx.LkpGroup.Where(x => x.Id == data.Id).Single();
                        temp.Name = data.Name;
                        temp.Description = data.Description;
                        portalctx.SaveChanges();
                    }
                    else
                    {
                        var temp = new LkpGroup
                        {
                            Id = 0,
                            Name = data.Name,
                            Description = data.Description
                        };
                        portalctx.LkpGroup.Add(temp);
                        portalctx.SaveChanges();

                        ret.Id = temp.Id;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetUserPermitReply GetUserPermit()
        {
            var ret = new GetUserPermitReply();

            try
            {
                using (var portalctx = new PortalContext())
                {
                    var temp = portalctx.VwUserPermit.Select(x => new UserPermit
                    {
                        UId = x.Uid,
                        AccessLevel = x.AccessLevel,
                        AppId = x.AppId,
                        AppName = x.AppName,
                        AppPermit = x.AppPermit,
                        GId = x.Gid,
                        GName = x.Gname,
                        Login = x.Login,
                        UILink = x.Uilink.GetSafeString(),
                        PId = x.Pid.GetSafeValue(),
                        PName = x.Pname.GetSafeString(),
                        UIId = x.Uiid,
                        UIName = x.Uiname,
                        UIStyle = x.Uistyle.GetSafeString(),
                        UIPermit = x.Uipermit,
                        UIType = x.Uitype,
                        UserName = x.UserName
                    }).ToList();

                    ret.UserPermits.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public GetApplicationsReply GetApplications()
        {
            var ret = new GetApplicationsReply();

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    var temp = acctx.LkpApplications.Select(x => new Application
                    {
                        ApplicationID = x.ApplicationId,
                        Active = x.Active ?? false ? 1 : 0,
                        ApplicationName = x.ApplicationName,
                        ApplicationURL = x.ApplicationUrl.GetSafeString(),
                        CMSFormID = x.CmsformId.GetSafeNullValue(),
                        EffectiveFromDate = x.EffectiveFromDate.GetSafeString(),
                        EffectiveToDate = x.EffectiveToDate.GetSafeString(),
                    }).ToList();

                    ret.Applications.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveApplication(Application data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    if (data.ApplicationID > 0)
                    {
                        var temp = acctx.LkpApplications.Where(x => x.ApplicationId == data.ApplicationID).Single();
                        temp.LastUpdateDate = DateTime.Now;
                        temp.LastUpdateUserId = _userid;
                        temp.ApplicationName = data.ApplicationName;
                        temp.ApplicationUrl = data.ApplicationURL;
                        temp.CmsformId = data.CMSFormID.GetNullIntOrId();
                        temp.EffectiveFromDate = Convert.ToDateTime(data.EffectiveFromDate);
                        temp.EffectiveToDate = Convert.ToDateTime(data.EffectiveToDate);
                        temp.Active = data.Active == 1;
                        acctx.SaveChanges();
                    }
                    else
                    {
                        var temp = new LkpApplications
                        {
                             ApplicationId = 0,
                             ApplicationName = data.ApplicationName,
                             ApplicationUrl = data.ApplicationURL,
                             Active = data.Active == 1,
                             CmsformId = data.CMSFormID.GetNullIntOrId(),
                             EffectiveFromDate = Convert.ToDateTime(data.EffectiveFromDate),
                             EffectiveToDate = Convert.ToDateTime(data.EffectiveToDate),
                             LastUpdateDate = DateTime.Now,
                             LastUpdateUserId = _userid,
                             EnteredByUserId = _userid,
                             EnteredDate = DateTime.Now
                        };
                        acctx.LkpApplications.Add(temp);
                        acctx.SaveChanges();
                                              
                        ret.Id = temp.ApplicationId;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetApplicationUIsReply GetApplicationUIs()
        {
            var ret = new GetApplicationUIsReply();

            try
            {
                using (var portalctx = new PortalContext())
                {
                    var temp = portalctx.LkpApplicationUi.Select(x => new ApplicationUI
                    {
                        AccessLevel = x.AccessLevel,
                        Active = x.Active ? 1 : 0,
                        AppId = x.AppId,
                        Id = x.Id,
                        PId = x.Pid.GetSafeNullValue(),
                        Link = x.Link.GetSafeString(),
                        Name = x.Name,
                        Style = x.Style.GetSafeString(),
                        UIType = x.Uitype.GetSafeString()

                    }).ToList();

                    ret.ApplicationUIs.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveApplicationUI(PortalUser data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    if (data.UserID > 0)
                    {
                        var temp = acctx.LkpUsers.Where(x => x.UserId == data.UserID).Single();
                                           

                        acctx.SaveChanges();
                    }
                    else
                    {
                        var temp = new LkpUsers
                        {
                         
                        };
                        acctx.LkpUsers.Add(temp);
                        acctx.SaveChanges();

                        temp.LegacyCmsuserId = temp.UserId;
                        acctx.SaveChanges();

                        ret.Id = temp.UserId;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetUsersReply GetAppGrantByGroup()
        {
            var ret = new GetUsersReply();

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    var temp = acctx.LkpUsers.Select(x => new PortalUser
                    {
                      
                    }).ToList();

                    ret.Users.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveSaveAppGrant(PortalUser data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    if (data.UserID > 0)
                    {
                        var temp = acctx.LkpUsers.Where(x => x.UserId == data.UserID).Single();
                     
                        acctx.SaveChanges();
                    }
                    else
                    {
                        var temp = new LkpUsers
                        {
                           
                        };
                        acctx.LkpUsers.Add(temp);
                        acctx.SaveChanges();

                        temp.LegacyCmsuserId = temp.UserId;
                        acctx.SaveChanges();

                        ret.Id = temp.UserId;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetUsersReply GetAppUIGrantByGroup()
        {
            var ret = new GetUsersReply();

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    var temp = acctx.LkpUsers.Select(x => new PortalUser
                    {
                      
                    }).ToList();

                    ret.Users.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveAppUIGrant(PortalUser data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    if (data.UserID > 0)
                    {
                        var temp = acctx.LkpUsers.Where(x => x.UserId == data.UserID).Single();
                     
                        acctx.SaveChanges();
                    }
                    else
                    {
                        var temp = new LkpUsers
                        {
                           
                        };
                        acctx.LkpUsers.Add(temp);
                        acctx.SaveChanges();

                        temp.LegacyCmsuserId = temp.UserId;
                        acctx.SaveChanges();

                        ret.Id = temp.UserId;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetUsersReply GetUserGroup()
        {
            var ret = new GetUsersReply();

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    var temp = acctx.LkpUsers.Select(x => new PortalUser
                    {
                       
                    }).ToList();

                    ret.Users.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveUserGroup(PortalUser data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    if (data.UserID > 0)
                    {
                        var temp = acctx.LkpUsers.Where(x => x.UserId == data.UserID).Single();
                      

                        acctx.SaveChanges();
                    }
                    else
                    {
                        var temp = new LkpUsers
                        {
                          
                        };
                        acctx.LkpUsers.Add(temp);
                        acctx.SaveChanges();

                        temp.LegacyCmsuserId = temp.UserId;
                        acctx.SaveChanges();

                        ret.Id = temp.UserId;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
    }
}
