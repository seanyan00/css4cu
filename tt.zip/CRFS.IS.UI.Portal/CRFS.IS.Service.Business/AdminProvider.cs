﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Google.Protobuf.WellKnownTypes;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.Common.TransferObjects;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Security;
using CRFS.IS.Service.Util;

namespace CRFS.IS.Service.Business
{
    public class AdminProvider
    {
        public const string PWDRESETSTR = @"Temporary Password for {0} has been created as <b>{1}</b>. Please update it during next login.";
        public const string PWDRESETMSG1 = "A temporary password for CMS has been requested for {0}. The application has been made available on your desktop. "
                                           + "Please note, a separate email will be sent with your temporary password.<br /><br />Thank you.";
        public const string PWDRESETMSG2 = "Your temporary password for CMS has been created as {0}. Please update it during next login.<br /><br />Thank you.";
        private IConfiguration _config;
        private ILogger _logger;
        private int _userid;

        public AdminProvider(IConfiguration config, ILogger logger, int uid)
        {
            _config = config;
            _logger = logger;
            _userid = uid;
        }
        public GetUsersReply GetUsers()
        {
            var ret = new GetUsersReply();

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    var temp = acctx.LkpUsers.Select(x => new PortalUser
                    {
                        Active = x.Active ? 1 : 0,
                     //   AllClientAccess = x.AllClientAccess.GetIntValue(),
                        EmploymentTypeID = x.EmploymentTypeId.GetIntValue(),
                        FirstName = x.FirstName.GetSafeString(),
                        LastName = x.LastName.GetSafeString(),
                        LastPWChange = x.LastPwchange.GetSafeString(),
                        LegacyCMSUserID = x.LegacyCmsuserId.GetIntValue(),
                        Login = x.Login,
                        Password = Constant.PasswordStr,
                        PhoneNum = x.PhoneNum.GetSafeString(),
                        SecurityGroupID = x.SecurityGroupId.GetIntValue(),
                        UserEmailAddress = x.UserEmailAddress.GetSafeString(),
                        UserID = x.UserId,
                        UserName = x.UserName
                    }).ToList();

                    ret.Users.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public MessageReply ResetPassword(int uid)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            using(var appctx = new ApplicationConfigurationContext())
            {
                var user = appctx.LkpUsers.Single(x => x.UserId == uid && x.Active);
                var temppwd = CommonHelper.GetRondomDigits();

                user.Password = PasswordSecurity.Encrypt(temppwd, true);
                user.LastPwchange = Convert.ToDateTime("1/1/1900");
                user.LastUpdateDate = DateTime.Now;
                user.LastUpdateUserId = _userid;

                appctx.SaveChanges();

                var admin = appctx.LkpUsers.Single(x => x.UserId == _userid);
                var ms = _config.GetSection("AppSettings").Get<AppSettings>().MailServer;
                Email.SendMail(user.UserEmailAddress, "CMS Notification", string.Format(PWDRESETMSG1, user.Login), ms);
                Email.SendMail(user.UserEmailAddress, "Password Notification", string.Format(PWDRESETMSG2, temppwd), ms, admin.UserEmailAddress);
            }

            return ret;
        }
        public MessageReply SaveUser(PortalUser data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    if(data.UserID > 0)
                    {
                        var temp = acctx.LkpUsers.Where(x => x.UserId == data.UserID).Single();
                        temp.LastUpdateDate = DateTime.Now;
                        temp.LastUpdateUserId = _userid;

                        temp.Active = data.Active == 1;
                    //    temp.AllClientAccess = data.AllClientAccess.GetBoolValue();
                        temp.EmploymentTypeId = data.EmploymentTypeID.GetNullValue();
                        temp.FirstName = data.FirstName;
                        temp.LastName = data.LastName;
                        //temp.LastPwchange = Convert.ToDateTime(data.LastPWChange);
                        temp.LegacyCmsuserId = data.LegacyCMSUserID.GetNullValue();
                        //temp.Password =
                        temp.PhoneNum = data.PhoneNum;
                        temp.SecurityGroupId = data.SecurityGroupID.GetNullValue();
                        temp.UserEmailAddress = data.UserEmailAddress;
                        temp.UserName = data.UserName;

                        acctx.SaveChanges();
                    }
                    else
                    {
                        var temppwd = CommonHelper.GetRondomDigits();
                        var temp = new LkpUsers
                        {
                            UserId = 0,
                            Active = data.Active == 1,
                            EmploymentTypeId = data.EmploymentTypeID,
                            EnteredByUserId = _userid,
                            EnteredDate = DateTime.Now,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUserId = _userid,
                            LastPwchange = DateTime.Now,
                            LastName = data.LastName,
                            FirstName = data.FirstName,
                            LegacyCmsuserId = data.LegacyCMSUserID.GetNullValue(),
                            Login = data.Login,
                            Password = PasswordSecurity.Encrypt(temppwd, true),
                            UserEmailAddress = data.UserEmailAddress,
                            UserName = data.UserName,
                            SecurityGroupId = data.SecurityGroupID.GetNullValue()
                        };
                        acctx.LkpUsers.Add(temp); 
                        acctx.SaveChanges();

                        temp.LegacyCmsuserId = temp.UserId;
                        acctx.SaveChanges();

                        ret.Id = temp.UserId;

                        var admin = acctx.LkpUsers.Single(x => x.UserId == _userid);
                        var ms = _config.GetSection("AppSettings").Get<AppSettings>().MailServer;
                        Email.SendMail(temp.UserEmailAddress, "CMS Notification", string.Format(PWDRESETMSG1, temp.Login), ms);
                        Email.SendMail(temp.UserEmailAddress, "Password Notification", string.Format(PWDRESETMSG2, temppwd), ms, admin.UserEmailAddress);
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetGroupsReply GetGroups()
        {
            var ret = new GetGroupsReply();

            try
            {
                using (var portalctx = new PortalContext())
                {
                    var temp = portalctx.LkpGroup.Select(x => new PortalGroup
                    {
                        Id = x.Id,
                        Name = x.Name,
                        Description = x.Description.GetSafeString(),
                        UIAct = ""
                    }).OrderBy(x => x.Name).ToList();

                    ret.Groups.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveGroup(PortalGroup data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var portalctx = new PortalContext())
                {
                    if (data.Id > 0)
                    {
                        var temp = portalctx.LkpGroup.Where(x => x.Id == data.Id).Single();
                        if (data.UIAct == "Delete")
                        {
                            portalctx.Remove(temp);
                        }
                        else
                        {
                            temp.Name = data.Name;
                            temp.Description = data.Description;
                        }
                        portalctx.SaveChanges();
                    }
                    else
                    {
                        var temp = new LkpGroup
                        {
                            Id = 0,
                            Name = data.Name,
                            Description = data.Description
                        };
                        portalctx.LkpGroup.Add(temp);
                        portalctx.SaveChanges();

                        ret.Id = temp.Id;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }

        public GetCMSGroupsReply GetCMSGroups()
        {
            var ret = new GetCMSGroupsReply();

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    var temp = acctx.LkpRoles.Select(x => new CMSGroup
                    {
                        Id = x.RoleId,
                        RoleName = x.RoleName,
                        MarkedForDelete = x.MarkedForDelete ? 1 : 0,
                        SecurityGroup = x.LegacyCmsgroupId ?? 0,
                        SecurityLevel = x.LegacySecurityLevel ?? 0,
                        UIAct = ""
                    }).OrderBy(x => x.RoleName).ToList();

                    ret.CMSGroups.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveCMSGroup(CMSGroup data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    if (data.Id > 0)
                    {
                        var temp = acctx.LkpRoles.Where(x => x.RoleId == data.Id).Single();
                        if (data.UIAct == "Delete")
                        {
                            acctx.LkpRoles.Remove(temp);
                        }
                        else
                        {
                            temp.RoleName = data.RoleName;
                            temp.MarkedForDelete = data.MarkedForDelete == 1;
                            temp.LastUpdateUserId = _userid;
                            temp.LastUpdateDate = DateTime.Now;
                            temp.LegacySecurityLevel = data.SecurityLevel;
                            temp.LegacyCmsgroupId = data.SecurityGroup;
                        }
                        acctx.SaveChanges();
                    }
                    else
                    {
                        var temp = new LkpRoles{
                            RoleId = 0,
                            RoleName = data.RoleName,
                            MarkedForDelete = false,
                            LegacyCmsgroupId = data.SecurityGroup,
                            LegacySecurityLevel = data.SecurityLevel,
                            EnteredByUserId = _userid,
                            EnteredDate = DateTime.Now,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUserId = _userid
                        };
                        acctx.LkpRoles.Add(temp);
                        acctx.SaveChanges();

                        ret.Id = temp.RoleId;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetUserPermitsReply GetUserPermits()
        {
            var ret = new GetUserPermitsReply();

            try
            {
                using (var portalctx = new PortalContext())
                {
                    var temp = portalctx.VwUserPermit.Select(x => new UserPermit
                    {
                        UId = x.Uid,
                        AccessLevel = x.AccessLevel,
                        AppId = x.AppId,
                        AppName = x.AppName,
                        AppPermit = x.AppPermit,
                        GId = x.Gid,
                        GName = x.Gname,
                        Login = x.Login,
                        UILink = x.Uilink.GetSafeString(),
                        PId = x.Pid.GetSafeValue(),
                        PName = x.Pname.GetSafeString(),
                        UIId = x.Uiid,
                        UIName = x.Uiname,
                        UIStyle = x.Uistyle.GetSafeString(),
                        UIPermit = x.Uipermit,
                        UIType = x.Uitype,
                        UserName = x.UserName
                    }).ToList();

                    ret.UserPermits.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public GetApplicationsReply GetApplications()
        {
            var ret = new GetApplicationsReply();

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    var temp = acctx.LkpApplications.Select(x => new Application
                    {
                        ApplicationID = x.ApplicationId,
                        Active = x.Active ?? false ? 1 : 0,
                        ApplicationName = x.ApplicationName,
                        ApplicationURL = x.ApplicationUrl.GetSafeString(),
                        CMSFormID = x.CmsformId.GetSafeNullValue(),
                        EffectiveFromDate = x.EffectiveFromDate.GetSafeString(),
                        EffectiveToDate = x.EffectiveToDate.GetSafeString(),
                        UIAct = ""
                        
                    }).ToList();

                    ret.Applications.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveApplication(Application data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    if (data.ApplicationID > 0)
                    {
                        var temp = acctx.LkpApplications.Where(x => x.ApplicationId == data.ApplicationID).Single();
                        
                        temp.LastUpdateDate = DateTime.Now;
                        temp.LastUpdateUserId = _userid;
                        temp.ApplicationName = data.ApplicationName;
                        temp.ApplicationUrl = data.ApplicationURL;
                        temp.CmsformId = data.CMSFormID.GetNullIntOrId();
                        temp.EffectiveFromDate = Convert.ToDateTime(data.EffectiveFromDate);
                        temp.EffectiveToDate = Convert.ToDateTime(data.EffectiveToDate);
                        temp.Active = data.Active == 1;
                        acctx.SaveChanges();
                    }
                    else
                    {
                        var temp = new LkpApplications
                        {
                             ApplicationId = 0,
                             ApplicationName = data.ApplicationName,
                             ApplicationUrl = data.ApplicationURL,
                             Active = data.Active == 1,
                             CmsformId = data.CMSFormID.GetNullIntOrId(),
                             EffectiveFromDate = Convert.ToDateTime(data.EffectiveFromDate),
                             EffectiveToDate = Convert.ToDateTime(data.EffectiveToDate),
                             LastUpdateDate = DateTime.Now,
                             LastUpdateUserId = _userid,
                             EnteredByUserId = _userid,
                             EnteredDate = DateTime.Now
                        };
                        acctx.LkpApplications.Add(temp);
                        acctx.SaveChanges();
                                              
                        ret.Id = temp.ApplicationId;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetApplicationUIsReply GetApplicationUIs()
        {
            var ret = new GetApplicationUIsReply();

            try
            {
                using (var portalctx = new PortalContext())
                {
                    var temp = portalctx.LkpApplicationUi.Select(x => new ApplicationUI
                    {
                        AccessLevel = x.AccessLevel,
                        Active = x.Active ? 1 : 0,
                        AppId = x.AppId,
                        Id = x.Id,
                        PId = x.Pid.GetSafeNullValue(),
                        Link = x.Link.GetSafeString(),
                        Name = x.Name,
                        Style = x.Style.GetSafeString(),
                        UIType = x.Uitype.GetSafeString()
                    }).ToList();

                    ret.ApplicationUIs.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveApplicationUI(ApplicationUI data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var portalctx = new PortalContext())
                {
                    if (data.Id > 0)
                    {
                        var temp = portalctx.LkpApplicationUi.Where(x => x.Id == data.Id).Single();

                        temp.Link = data.Link;
                        temp.Name = data.Name;
                        temp.Pid = data.PId.GetNullValue();
                        temp.Style = data.Style;
                        temp.Uitype = data.UIType;
                        temp.UpdatedBy = _userid;
                        temp.UpdatedDate = DateTime.Now;
                        temp.AccessLevel = data.AccessLevel;
                        temp.Active = data.Active == 1;
                        temp.AppId = data.AppId;

                        portalctx.SaveChanges();
                    }
                    else
                    {
                        var temp = new LkpApplicationUi
                        {
                            Id = 0,
                            AccessLevel = data.AccessLevel,
                            Active = data.Active == 1,
                            AppId = data.AppId,
                            EnteredBy = _userid,
                            EnteredDate = DateTime.Now,
                            Link = data.Link,
                            Style = data.Style,
                            Name = data.Name,
                            Pid = data.PId.GetNullValue(),
                            Uitype = data.UIType,
                            UpdatedBy = _userid,
                            UpdatedDate = DateTime.Now
                        };
                        portalctx.LkpApplicationUi.Add(temp);
                        portalctx.SaveChanges();

                        ret.Id = temp.Id;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public MessageReply SaveGroupAssign(SaveGroupAssignRequest data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var portalctx = new PortalContext())
                {
                    using (var trans = portalctx.Database.BeginTransaction())
                    {
                        try
                        {
                            if(data.UserGroupAssigns.Count > 0)
                            {
                                var allgrants = portalctx.XrefUserGroup.Where(x => x.Gid == data.GId).ToList();
                                if (data.UserGroupAssigns[0].UIAct == "Delete")
                                {
                                    portalctx.XrefUserGroup.RemoveRange(allgrants);
                                } 
                                else
                                {
                                    foreach (var tg in allgrants)
                                    {
                                        if (!data.UserGroupAssigns.Any(x => x.XrefId == tg.Id))
                                        {
                                            portalctx.XrefUserGroup.Remove(tg);
                                        }
                                    }
                                    foreach (var d in data.UserGroupAssigns)
                                    {
                                        if (d.XrefId > 0)
                                        {
                                            var temp = allgrants.FirstOrDefault(x => x.Id == d.XrefId);
                                            temp.Active = true;
                                        }
                                        else
                                        {
                                            var temp = new XrefUserGroup
                                            {
                                                Id = 0,
                                                Gid = d.GId,
                                                Uid = d.UId,
                                                Active = true
                                            };
                                            portalctx.XrefUserGroup.Add(temp);
                                        }
                                    }
                                }
                                portalctx.SaveChanges();
                            }
                            if(data.GroupAppAssigns.Count > 0)
                            {
                                var allgrants = portalctx.XrefAppGrant.Where(x => x.Gid == data.GId).ToList();
                                if (data.GroupAppAssigns[0].UIAct == "Delete")
                                {
                                    portalctx.XrefAppGrant.RemoveRange(allgrants);
                                }
                                else
                                {
                                    foreach (var tg in allgrants)
                                    {
                                        if (!data.GroupAppAssigns.Any(x => x.XrefId == tg.Id))
                                        {
                                            portalctx.XrefAppGrant.Remove(tg);
                                        }
                                    }
                                    foreach (var d in data.GroupAppAssigns)
                                    {
                                        if (d.XrefId > 0)
                                        {
                                            var temp = allgrants.FirstOrDefault(x => x.Id == d.XrefId);
                                            temp.Permit = d.Grant;
                                        }
                                        else
                                        {
                                            var temp = new XrefAppGrant
                                            {
                                                Id = 0,
                                                Gid = d.GId,
                                                AppId = d.AppId,
                                                Permit = d.Grant
                                            };
                                            portalctx.XrefAppGrant.Add(temp);
                                        }
                                    }
                                }
                                portalctx.SaveChanges();
                            }
                            if(data.GroupAppUIAssigns.Count > 0)
                            {
                                var allgrants = portalctx.XrefUigrant.Where(x => x.Gid == data.GId).ToList();
                                if (data.GroupAppUIAssigns[0].UIAct == "Delete")
                                {
                                    portalctx.XrefUigrant.RemoveRange(allgrants);
                                }
                                else
                                {
                                    foreach (var tg in allgrants)
                                    {
                                        if (!data.GroupAppUIAssigns.Any(x => x.XrefId == tg.Id))
                                        {
                                            portalctx.XrefUigrant.Remove(tg);
                                        }
                                    }
                                    foreach (var d in data.GroupAppUIAssigns)
                                    {
                                        if (d.XrefId > 0)
                                        {
                                            var temp = allgrants.FirstOrDefault(x => x.Id == d.XrefId);
                                            temp.Permit = d.Grant;
                                        }
                                        else
                                        {
                                            var temp = new XrefUigrant
                                            {
                                                Id = 0,
                                                Gid = d.GId,
                                                Uiid = d.UIId,
                                                Permit = d.Grant
                                            };
                                            portalctx.XrefUigrant.Add(temp);
                                        }
                                    }
                                    
                                } 
                                portalctx.SaveChanges();
                            }
                            trans.Commit();
                        }
                        catch
                        {
                            trans.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetGroupApplicationsReply GetAppGrantByGroup(int id)
        {
            var ret = new GetGroupApplicationsReply();

            try
            {
                using (var portalctx = new PortalContext())
                {
                    var temp = portalctx.XrefAppGrant.Select(x => new GroupApplication
                    {
                        Id = x.Id,
                        GId = x.Gid,
                        AppId = x.AppId,
                        Permit = x.Permit,
                        UIAct = ""
                    }).ToList();

                    ret.GroupApplications.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveGroupAppGrant(SaveGroupApplicationsRequest data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var portalctx = new PortalContext())
                {
                    using(var trans = portalctx.Database.BeginTransaction())
                    {
                        try
                        {
                            var allgrants = portalctx.XrefAppGrant.ToList();
                            foreach (var gid in data.GroupApplications.Where(x => x.UIAct == "Delete").Select(x => x.GId).Distinct().ToList())
                            {
                                var tempdel = allgrants.Where(x => x.Gid == gid).ToList();
                                portalctx.XrefAppGrant.RemoveRange(tempdel);
                                portalctx.SaveChanges();
                                allgrants = portalctx.XrefAppGrant.ToList();
                            }
                            foreach (var tg in allgrants)
                            {
                                if (data.GroupApplications.Any(x => x.GId == tg.Gid) && !data.GroupApplications.Any(x => x.Id == tg.Id))
                                {
                                    portalctx.XrefAppGrant.Remove(tg);
                                }
                            }
                            foreach (var d in data.GroupApplications.Where(x => x.UIAct != "Delete").ToList())
                            {
                                if (d.Id > 0)
                                {
                                    var temp = allgrants.Where(x => x.Id == d.Id).Single();
                                    temp.Permit = d.Permit;
                                }
                                else
                                {
                                    var temp = new XrefAppGrant
                                    {
                                        Id = 0,
                                        Gid = d.GId,
                                        AppId = d.AppId,
                                        Permit = d.Permit
                                    };
                                    portalctx.XrefAppGrant.Add(temp);
                                }
                            }
                            portalctx.SaveChanges();
                            trans.Commit();
                        }
                        catch
                        {
                            trans.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetGroupApplicationUIsReply GetAppUIGrantByGroup(int id)
        {
            var ret = new GetGroupApplicationUIsReply();

            try
            {
                using (var portalctx = new PortalContext())
                {
                    var aui = portalctx.LkpApplicationUi.ToList();
                    var temp = portalctx.XrefUigrant.ToList().Select(x => new GroupApplicationUI
                    {
                        Id = x.Id,
                        UIId = x.Uiid,
                        UIName = aui.Where(y => y.Id == x.Uiid).Select(y => y.Name).Single(),
                        UIType = aui.Where(y => y.Id == x.Uiid).Select(y => y.Uitype).Single(),
                        GId = x.Gid,
                        Permit = x.Permit,
                        UIAct = ""
                    }).ToList();

                    ret.GroupApplicationUIs.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveAppUIGrant(SaveGroupApplicationUIRequest data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var portalctx = new PortalContext())
                {
                    using (var trans = portalctx.Database.BeginTransaction()) {
                        try
                        {
                            var allgrants = portalctx.XrefUigrant.ToList();
                            foreach (var gid in data.GroupApplicationUIs.Where(x => x.UIAct == "Delete").Select(x => x.GId).Distinct().ToList())
                            {
                                var tempdel = allgrants.Where(x => x.Gid == gid).ToList();
                                portalctx.XrefUigrant.RemoveRange(tempdel);
                                portalctx.SaveChanges();
                                allgrants = portalctx.XrefUigrant.ToList();
                            }
                            foreach (var tg in allgrants)
                            {
                                if(data.GroupApplicationUIs.Any(x => x.GId == tg.Gid && x.UIAct != "Delete") && !data.GroupApplicationUIs.Any(x => x.Id == tg.Id))
                                {
                                    portalctx.XrefUigrant.Remove(tg);
                                }
                            }
                            foreach(var d in data.GroupApplicationUIs.Where(x => x.UIAct != "Delete").ToList())
                            {
                                if(d.Id > 0)
                                {
                                    var temp = allgrants.Where(x => x.Id == d.Id).Single();
                                    temp.Permit = d.Permit;
                                } else
                                {
                                    var temp = new XrefUigrant
                                    {
                                        Id = 0,
                                        Gid = d.GId,
                                        Uiid = d.UIId,
                                        Permit = d.Permit
                                    };
                                    portalctx.XrefUigrant.Add(temp);
                                }
                            }
                            portalctx.SaveChanges();
                            trans.Commit();
                        }
                        catch 
                        {
                            trans.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetUserGroupsReply GetUserGroups(int id)
        {
            var ret = new GetUserGroupsReply();

            try
            {
                var users = new List<LkpUsers>();

                using(var acctx = new ApplicationConfigurationContext())
                {
                    users = acctx.LkpUsers.ToList();
                }
                using (var portalctx = new PortalContext())
                {
                    var temp = portalctx.XrefUserGroup.ToList().Select(x => new UserGroup
                    {
                       Id = x.Id,
                       UId = x.Uid,
                       GId = x.Gid,
                       UName = users.Where(y => y.UserId == x.Uid).Select(y => y.UserName).Single(),
                       Login = users.Where(y => y.UserId == x.Uid).Select(y => y.Login).Single(),
                       Active = x.Active ? 1 : 0,
                       UIAct = ""
                    }).ToList();

                    ret.UserGroups.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveUserGroups(SaveUserGroupsRequest data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var portalctx = new PortalContext())
                {
                    using(var trans = portalctx.Database.BeginTransaction())
                    {
                        try
                        {
                            var allgrants = portalctx.XrefUserGroup.ToList();
                            foreach (var gid in data.UserGroups.Where(x => x.UIAct == "Delete").Select(x => x.GId).Distinct().ToList())
                            {
                                var tempdel = allgrants.Where(x => x.Gid == gid).ToList();
                                portalctx.XrefUserGroup.RemoveRange(tempdel);
                                portalctx.SaveChanges();
                                allgrants = portalctx.XrefUserGroup.ToList();
                            }
                            foreach (var tg in allgrants)
                            {
                                if (data.UserGroups.Any(x => x.GId == tg.Gid && x.UIAct != "Delete") && !data.UserGroups.Any(x => x.Id == tg.Id))
                                {
                                    portalctx.XrefUserGroup.Remove(tg);
                                }
                            }
                            foreach (var d in data.UserGroups.Where(x => x.UIAct != "Delete").ToList())
                            {
                                if (d.Id > 0)
                                {
                                    var temp = allgrants.Where(x => x.Id == d.Id).Single();
                                    temp.Active = d.Active == 1;
                                }
                                else
                                {
                                    var temp = new XrefUserGroup
                                    {
                                        Id = 0,
                                        Gid = d.GId,
                                        Uid = d.UId,
                                        Active = d.Active == 1
                                    };
                                    portalctx.XrefUserGroup.Add(temp);
                                }
                            }
                            portalctx.SaveChanges();
                            trans.Commit();
                        }
                        catch
                        {
                            trans.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        } 
        public GetUserGroupAssignReply GetUserGroupAssign(int id)
        {
            var ret = new GetUserGroupAssignReply();

            try
            {
                var users = new List<UserGroupAssign>();
                using (var acctx = new ApplicationConfigurationContext())
                {
                    users = acctx.LkpUsers.Where(x => x.Active).Select(x => new UserGroupAssign
                    {
                        XrefId = 0,
                        UId = x.UserId,
                        UName = x.UserName,
                        Login = x.Login,
                        GId = id,
                        UIAct = ""
                    }).OrderBy(x => x.UName).ToList();
                }
                using (var portalctx = new PortalContext())
                {

                    var temp = portalctx.XrefUserGroup.Where(x => x.Gid == id && x.Active).Select(x => new UserGroupAssign
                    {
                        XrefId = x.Id,
                        UId = x.Uid,
                        GId = x.Gid,
                        UIAct = ""
                    }).ToList();

                    foreach (var t in users)
                    {
                        if (temp.Any(x => x.UId == t.UId))
                        {
                            var t1 = temp.Where(x => x.UId == t.UId).Single();
                            t1.UName = t.UName;
                            t1.Login = t.Login;
                        }
                        else
                        {
                            temp.Add(t);
                        }
                    }
                    ret.UserGroupAssigns.AddRange(temp);
                }
                return ret;
            }
            catch (Exception ex)
            {
                throw;
            }
          
        }
        public GetGroupAppAssignReply GetGroupAppAssign(int id)
        {
            var ret = new GetGroupAppAssignReply();

            try
            {
                var apps = new List<GroupAppAssign>();
                using (var acctx = new ApplicationConfigurationContext())
                {
                    apps = acctx.LkpApplications.Where(x => x.Active ?? false).Select(x => new GroupAppAssign
                    {
                        XrefId = 0,
                        GId = id,
                        AppId = x.ApplicationId,
                        AppName = x.ApplicationName,
                        Grant = 0,
                        UIAct = ""
                    }).OrderBy(x => x.AppName).ToList();
                }
                using (var portalctx = new PortalContext())
                {

                    var temp = portalctx.XrefAppGrant.Where(x => x.Gid == id).Select(x => new GroupAppAssign
                    {
                        XrefId = x.Id,
                        GId = x.Gid,
                        AppName = "",
                        AppId = x.AppId,
                        Grant = x.Permit,
                        UIAct = ""
                    }).ToList();

                    foreach (var t in apps)
                    {
                        if (temp.Any(x => x.AppId == t.AppId))
                        {
                            var t1 = temp.Where(x => x.AppId == t.AppId).Single();
                            t1.AppName = t.AppName;
                        }
                        else
                        {
                            temp.Add(t);
                        }
                    }
                    ret.GroupAppAssigns.AddRange(temp);
                }
                return ret;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public GetGroupAppUIAssignReply GetGroupAppUIAssign(int id)
        {
            var ret = new GetGroupAppUIAssignReply();

            try
            {
                var appuis = new List<GroupAppUIAssign>();
             
                using (var portalctx = new PortalContext())
                {
                    appuis = portalctx.LkpApplicationUi.Where(x => x.Active).Select(x => new GroupAppUIAssign
                    {
                        XrefId = 0,
                        GId = id,
                        UIId = x.Id,
                        UIName = x.Name,
                        UIType = x.Uitype,
                        Grant = 0,
                        UIAct = ""
                    }).OrderBy(x => x.UIName).ToList();

                    var temp = portalctx.XrefUigrant.Where(x => x.Gid == id).Select(x => new GroupAppUIAssign
                    {
                        XrefId = x.Id,
                        GId = x.Gid,
                        UIId = x.Uiid,
                        Grant = x.Permit,
                        UIAct = ""
                    }).ToList();

                    foreach (var t in appuis)
                    {
                        if (temp.Any(x => x.UIId == t.UIId))
                        {
                            var t1 = temp.Where(x => x.UIId == t.UIId).Single();
                            t1.UIName = t.UIName;
                            t1.UIType = t.UIType;
                        }
                        else
                        {
                            temp.Add(t);
                        }
                    }
                    ret.GroupAppUIAssigns.AddRange(temp);
                }
                return ret;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public GetClientsReply GetClients()
        {
            var ret = new GetClientsReply();

            try
            {
                var users = new List<LkpUsers>();
                //var clngroup = new List<LkpClientGroup>();
               
                using (var acctx = new ApplicationConfigurationContext())
                {
                    var temp = acctx.LkpClients.Select(x => new Client
                    {
                        Id = x.ClientId,
                        Active = x.Active ? 1 : 0,
                        Abbreviation = x.ClientAbbreviation.GetSafeString(),
                        DisplayName = x.ClientDisplayName.GetSafeString(),
                        EffectiveFromDate = x.EffectiveFromDate.GetSafeString(),
                        EffectiveToDate = x.EffectiveToDate.GetSafeString(),
                      //  EvokeReferral = x.EvokeReferral ? 1: 0,
                        LegalName = x.ClientLegalName.GetSafeString(),
                        MarkedForDelete = x.MarkedForDelete ? 1 : 0,
                        Name = x.ClientName.GetSafeString()
                    }).ToList();

                    ret.Clients.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveClient(Client data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    if (data.Id > 0)
                    {
                        var temp = acctx.LkpClients.Where(x => x.ClientId == data.Id).Single();

                        temp.ClientAbbreviation = data.Abbreviation;
                        temp.ClientDisplayName = data.DisplayName;
                        temp.ClientLegalName = data.LegalName;
                        temp.ClientName = data.Name;
                        temp.EffectiveFromDate = Convert.ToDateTime(data.EffectiveFromDate.GetDateString());
                        temp.EffectiveToDate = Convert.ToDateTime(data.EffectiveToDate.GetDateString());
                     //  temp.EvokeReferral = data.EvokeReferral == 1;
                        temp.Active = data.Active == 1;
                        temp.LastUpdateDate = DateTime.Now;
                        temp.LastUpdateUserId = _userid;

                        acctx.SaveChanges();
                    }
                    else
                    {
                        var temp = new LkpClients
                        {
                            ClientId = 0,
                            Active = data.Active == 1,
                            ClientAbbreviation = data.Abbreviation,
                            ClientDisplayName = data.DisplayName,
                            ClientLegalName = data.LegalName,
                            ClientName = data.Name,
                            EffectiveFromDate = Convert.ToDateTime(data.EffectiveFromDate.GetDateString()),
                            EffectiveToDate = Convert.ToDateTime(data.EffectiveToDate.GetDateString()),
                            EnteredByUserId = _userid,
                            EnteredDate = DateTime.Now,
                            //EvokeReferral = data.EvokeReferral == 1,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUserId = _userid,
                            MarkedForDelete = data.MarkedForDelete == 1
                            
                        };
                        acctx.LkpClients.Add(temp);
                        acctx.SaveChanges();

                        ret.Id = temp.ClientId;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetUserClientReply GetUserClient(int id)
        {
            var ret = new GetUserClientReply();

            try
            {
                var clns = new List<LkpClients>();

                using (var acctx = new ApplicationConfigurationContext())
                {
                    clns = acctx.LkpClients.Where(x => x.Active).OrderBy(x => x.ClientDisplayName).OrderBy(x => x.ClientDisplayName).ToList();

                    var temp = acctx.XrefClientsUsers.Where(x => x.UserId == id).Select(x => new UserClient
                    {
                        Id = x.ClientUserId,
                        UId = x.UserId,
                        CId = x.ClientId,
                        CName = x.Client.ClientDisplayName,
                        MarkedForDelete = x.MarkedForDelete ? 1 : 0
                    }).ToList();

                    ret.UserClients.AddRange(temp);
                    foreach(var c in clns)
                    {
                        if(!temp.Any(x => x.CId == c.ClientId))
                        {
                            ret.UserClients.Add(new UserClient { 
                               Id = 0,
                               UId = id,
                               CId = c.ClientId,
                               CName = clns.Single(x => x.ClientId == c.ClientId).ClientDisplayName,
                               MarkedForDelete = 0
                            });
                        }
                    }
                }
                return ret;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public MessageReply SaveUserClient(SaveUserClientRequest data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    using (var trans = acctx.Database.BeginTransaction())
                    {
                        try
                        {
                            var ucs = acctx.XrefClientsUsers.Where(x => x.UserId == data.UId).ToList();
                           
                            foreach (var tg in ucs)
                            {
                                if (!data.UserClients.Any(x => x.CId == tg.ClientId))
                                {
                                    acctx.XrefClientsUsers.Remove(tg);
                                }
                            }
                            foreach (var d in data.UserClients)
                            {
                                if (d.Id > 0)
                                {
                                    var temp = ucs.Where(x => x.ClientUserId == d.Id).Single();
                                    temp.MarkedForDelete = d.MarkedForDelete == 1;
                                    temp.LastUpdateDate = DateTime.Now;
                                    temp.LastUpdateUserId = _userid;
                                }
                                else
                                {
                                    var temp = new XrefClientsUsers
                                    {
                                        ClientUserId = 0,
                                        ClientId = d.CId,
                                        UserId = d.UId,
                                        MarkedForDelete = false,
                                        EnteredByUserId = _userid,
                                        EnteredDate = DateTime.Now,
                                        LastUpdateDate = DateTime.Now,
                                        LastUpdateUserId = _userid
                                    };
                                    acctx.XrefClientsUsers.Add(temp);
                                }
                            }
                            acctx.SaveChanges();
                            trans.Commit();
                        }
                        catch
                        {
                            trans.Rollback();
                            throw;
                        }
                    }
                }
               
                return ret;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public GetUserApplicationReply GetUserApplication(int id)
        {
            var ret = new GetUserApplicationReply();

            try
            {
                var apps = new List<LkpApplications>();

                using (var acctx = new ApplicationConfigurationContext())
                {
                    apps = acctx.LkpApplications.Where(x => x.Active ?? false).OrderBy(x => x.ApplicationName).ToList();

                    var temp = acctx.XrefApplicationUser.Where(x => x.UserId == id).Select(x => new UserApplication
                    {
                        AppId = x.ApplicationId,
                        AppName = x.Application.ApplicationName,
                        Id = x.ApplicationUserId,
                        UId = x.UserId,
                        MarkedForDelete = x.MarkedForDelete ? 1 : 0
                    }).ToList();

                    ret.UserApplications.AddRange(temp);
                    foreach (var c in apps)
                    {
                        if (!temp.Any(x => x.AppId == c.ApplicationId))
                        {
                            ret.UserApplications.Add(new UserApplication
                            {
                                Id = 0,
                                UId = id,
                                AppId = c.ApplicationId,
                                AppName = c.ApplicationName,
                                MarkedForDelete = 0
                            });
                        }
                    }
                }
                return ret;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public MessageReply SaveUserApplication(SaveUserApplicationRequest data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    var uas = acctx.XrefApplicationUser.Where(x => x.UserId == data.UId).ToList();

                    foreach (var tg in uas)
                    {
                        if (!data.UserApplications.Any(x => x.AppId == tg.ApplicationId))
                        {
                            acctx.XrefApplicationUser.Remove(tg);
                        }
                    }
                    foreach (var d in data.UserApplications)
                    {
                        if (d.Id > 0)
                        {
                            var temp = uas.Single(x => x.ApplicationUserId == d.Id);
                            temp.MarkedForDelete = d.MarkedForDelete == 1;
                            temp.LastUpdateDate = DateTime.Now;
                            temp.LastUpdateUserId = _userid;
                        }
                        else
                        {
                            var temp = new XrefApplicationUser
                            {
                                ApplicationUserId = 0,
                                ApplicationId = d.AppId,
                                UserId = d.UId,
                                MarkedForDelete = false,
                                EnteredByUserId = _userid,
                                EnteredDate = DateTime.Now,
                                LastUpdateDate = DateTime.Now,
                                LastUpdateUserId = _userid
                            };
                            acctx.XrefApplicationUser.Add(temp);
                        }
                    }
                    acctx.SaveChanges();
                }
                return ret;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public GetUserGroupApplicationAssignReply GetUserGroupApplicationAssign(int id)
        {
            var ret = new GetUserGroupApplicationAssignReply();
            var templ = new List<UserGroupApplicationAssign>();
            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    var aus = acctx.XrefApplicationUser.ToList();
                    var ars = acctx.XrefApplicationRoles.ToList();
                    var gs = acctx.LkpRoles.Where(x => !x.MarkedForDelete).ToList();
                    var apps = acctx.LkpApplications.Where(x => x.Active ?? false).ToList();

                    foreach (var au in aus.Where(x => x.UserId == id).ToList())
                    {
                        var temp = acctx.XrefAppplicationUserApplicationRole.Where(x => x.ApplicationUserId == au.ApplicationUserId)
                            .Select(x => new UserGroupApplicationAssign
                            {
                                Id = x.AppplicationUserApplicationRoleId,
                                UAppId = x.ApplicationUserId,
                                GAppId = x.ApplicationRoleId,
                                UAppName = x.ApplicationUser.Application.ApplicationName,
                                GAppName = x.ApplicationRole.Application.ApplicationName,
                                UId = id,
                                GId = x.ApplicationRole.RoleId,
                                GName = x.ApplicationRole.Role.RoleName,
                                MarkedForDelete = x.MarkedForDelete ? 1 : 0
                            }).ToList();
                        templ.AddRange(temp);
                                      
                        foreach (var c in ars.Where(x => x.ApplicationId == au.ApplicationId).ToList())
                        {
                            if (!templ.Any(x => x.UAppId == au.ApplicationUserId && x.GAppId == c.ApplicationRoleId))
                            {
                                templ.Add(new UserGroupApplicationAssign
                                {
                                    Id = 0,
                                    UAppId = au.ApplicationUserId,
                                    GAppId = c.ApplicationRoleId,
                                    UId = au.UserId,
                                    GId = c.RoleId,
                                    UAppName = apps.Single(x => x.ApplicationId == au.ApplicationId).ApplicationName,
                                    GAppName = apps.Single(x => x.ApplicationId == c.ApplicationId).ApplicationName,
                                    MarkedForDelete = 0,
                                    GName = gs.Single(x => x.RoleId == c.RoleId).RoleName
                                });
                            }
                        }
                    }
                    ret.UserGroupApplicationAssigns.AddRange(templ.OrderByDescending(x => x.Id).ThenBy(x => x.GAppName));
                }
                return ret;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public MessageReply SaveUserGroupApplicationAssign(SaveUserGroupApplicationAssignRequest data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    var ugaas = acctx.XrefAppplicationUserApplicationRole.Where(x => x.ApplicationUser.UserId == data.UId).ToList();

                    foreach (var tg in ugaas)
                    {
                        if (!data.UserGroupApplicationAssigns.Any(x => x.UAppId == tg.ApplicationUserId && x.GAppId == tg.ApplicationRoleId))
                        {
                            acctx.XrefAppplicationUserApplicationRole.Remove(tg);
                        }
                    }
                    foreach (var d in data.UserGroupApplicationAssigns)
                    {
                        if (d.Id > 0)
                        {
                            var temp = ugaas.Where(x => x.AppplicationUserApplicationRoleId == d.Id).Single();
                            temp.MarkedForDelete = d.MarkedForDelete == 1;
                            temp.LastUpdateDate = DateTime.Now;
                            temp.LastUpdateUserId = _userid;
                        }
                        else
                        {
                            var temp = new XrefAppplicationUserApplicationRole
                            {
                                AppplicationUserApplicationRoleId = 0,
                                ApplicationRoleId = (int)d.GAppId,
                                ApplicationUserId = (int)d.UAppId,
                                MarkedForDelete = false,
                                EnteredByUserId = _userid,
                                EnteredDate = DateTime.Now,
                                LastUpdateDate = DateTime.Now,
                                LastUpdateUserId = _userid
                            };
                            acctx.XrefAppplicationUserApplicationRole.Add(temp);
                        }
                    }
                    acctx.SaveChanges();
                }
                return ret;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public GetClientApplicationReply GetClientApplication(int id)
        {
            var ret = new GetClientApplicationReply();

            try
            {
                var apps = new List<LkpApplications>();

                using (var acctx = new ApplicationConfigurationContext())
                {
                    apps = acctx.LkpApplications.Where(x => x.Active ?? false).OrderBy(x => x.ApplicationName).ToList();

                    var temp = acctx.XrefApplicationsClients.Where(x => x.ClientId == id).Select(x => new ClientApplication
                    {
                        CId = id,
                        AppId = x.ApplicationId,
                        AppName = x.Application.ApplicationName,
                        Id = x.ApplicationClientId,
                        Active = x.Active ?? false ? 1 : 0,
                        ActiveFromDate = x.ActiveFromDate.GetSafeString(),
                        ActiveToDate = x.ActiveToDate.GetSafeString()
                    }).ToList();

                    ret.ClientApplications.AddRange(temp);
                    foreach (var c in apps)
                    {
                        if (!temp.Any(x => x.AppId == c.ApplicationId))
                        {
                            ret.ClientApplications.Add(new ClientApplication
                            {
                                Id = 0,
                                CId = id,
                                AppId = c.ApplicationId,
                                AppName = c.ApplicationName,
                                Active = 0,
                                ActiveFromDate = "",
                                ActiveToDate = ""
                            });
                        }
                    }
                }
                return ret;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public MessageReply SaveClientApplication(SaveClientApplicationRequest data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    var uas = acctx.XrefApplicationsClients.Where(x => x.ClientId == data.CId).ToList();

                    foreach (var tg in uas)
                    {
                        if (!data.ClientApplications.Any(x => x.AppId == tg.ApplicationId))
                        {
                            acctx.XrefApplicationsClients.Remove(tg);
                        }
                    }
                    foreach (var d in data.ClientApplications)
                    {
                        if (d.Id > 0)
                        {
                            var temp = uas.Single(x => x.ApplicationClientId == d.Id);
                            temp.Active = d.Active == 1;
                            temp.ActiveFromDate = Convert.ToDateTime(d.ActiveFromDate.GetDateString());
                            temp.LastUpdateDate = DateTime.Now;
                            temp.LastUpdateUserId = _userid;
                        }
                        else
                        {
                            var temp = new XrefApplicationsClients
                            {
                                ApplicationClientId = 0,
                                ApplicationId = d.AppId,
                                ClientId = d.CId,
                                Active = d.Active == 1,
                                ActiveFromDate = Convert.ToDateTime(d.ActiveFromDate.GetDateString()),
                                ActiveToDate = Convert.ToDateTime(d.ActiveToDate.GetDateString()),
                                EnteredByUserId = _userid,
                                EnteredDate = DateTime.Now,
                                LastUpdateDate = DateTime.Now,
                                LastUpdateUserId = _userid
                            };
                            acctx.XrefApplicationsClients.Add(temp);
                        }
                    }
                    acctx.SaveChanges();
                }
                return ret;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public GetClientInvGroupReply GetClientInvGroup(int id)
        {
            var ret = new GetClientInvGroupReply();

            try
            {
                var invgs = new List<TblControlInvestorGroup>();

                using (var acctx = new ApplicationConfigurationContext())
                {
                    invgs = acctx.TblControlInvestorGroup.ToList().Where(x => DateTime.Now <= x.EffectiveToDate && DateTime.Now >= x.EffectiveFromDate)
                                  .OrderBy(x => x.InvestorGroupName).ToList();

                    var temp = acctx.XrefClientInvestorGroupServices.Where(x => x.ClientId == id).Select(x => new ClientInvGroup
                    {
                        Id = x.ClientInvestorGroupServicesId,
                        CId = id,
                        InvGrpId = x.InvestorGroupId,
                        InvGrpName = ""
                    }).ToList();
                    foreach(var tt in temp)
                    {
                        tt.InvGrpName = invgs.Single(x => x.InvestorGroupId == tt.InvGrpId).InvestorGroupName;
                    }
                    ret.ClientInvGroups.AddRange(temp);
                    foreach (var c in invgs)
                    {
                        if (!temp.Any(x => x.InvGrpId == c.InvestorGroupId))
                        {
                            ret.ClientInvGroups.Add(new ClientInvGroup
                            {
                                Id = 0,
                                CId = id,
                                InvGrpId = c.InvestorGroupId,
                                InvGrpName = c.InvestorGroupName
                            });
                        }
                    }
                }
                return ret;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public MessageReply SaveClientInvGroup(SaveClientInvGroupRequest data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    var uas = acctx.XrefClientInvestorGroupServices.Where(x => x.ClientId == data.CId).ToList();

                    foreach (var tg in uas)
                    {
                        if (!data.ClientInvGroups.Any(x => x.InvGrpId == tg.InvestorGroupId))
                        {
                            acctx.XrefClientInvestorGroupServices.Remove(tg);
                        }
                    }
                    foreach (var d in data.ClientInvGroups)
                    {
                        if (d.Id > 0)
                        {
                            var temp = uas.Single(x => x.ClientInvestorGroupServicesId == d.Id);
                            temp.InvestorGroupId = d.InvGrpId;
                        }
                        else
                        {
                            var temp = new XrefClientInvestorGroupServices
                            {
                                ClientId = d.CId,
                                ClientInvestorGroupServicesId = 0,
                                InvestorGroupId = d.InvGrpId
                            };
                            acctx.XrefClientInvestorGroupServices.Add(temp);
                        }
                    }
                    acctx.SaveChanges();
                }
                return ret;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public GetClientMIReply GetClientMI(int id)
        {
            var ret = new GetClientMIReply();

            try
            {
                var mis = new List<TbllkpMicompanies>();

                using(var cmsctx = new ClaimsManagementContext())
                {
                    mis = cmsctx.TbllkpMicompanies.ToList();
                }
                using (var acctx = new ApplicationConfigurationContext())
                {
                    var temp = acctx.XrefClientMicompanyServices.Where(x => x.ClientId == id).ToList().Select(x => new ClientMI
                    {
                        Id = x.ClientMicompanyServicesId,
                        CId = id,
                        MIId = x.MicompanyId,
                        MIName = mis.Single(y => y.Id == x.MicompanyId).MicompanyName
                    }).ToList();

                    ret.ClientMIs.AddRange(temp);
                    foreach (var c in mis)
                    {
                        if (!temp.Any(x => x.MIId == c.Id))
                        {
                            ret.ClientMIs.Add(new ClientMI
                            {
                                Id = 0,
                                CId = id,
                                MIId = c.Id,
                                MIName = c.MicompanyName
                            });
                        }
                    }
                }
                return ret;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public MessageReply SaveClientMI(SaveClientMIRequest data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    var uas = acctx.XrefClientMicompanyServices.Where(x => x.ClientId == data.CId).ToList();

                    foreach (var tg in uas)
                    {
                        if (!data.ClientMIs.Any(x => x.MIId == tg.MicompanyId))
                        {
                            acctx.XrefClientMicompanyServices.Remove(tg);
                        }
                    }
                    foreach (var d in data.ClientMIs)
                    {
                        if (d.Id > 0)
                        {
                            var temp = uas.Single(x => x.ClientMicompanyServicesId == d.Id);
                            temp.MicompanyId = d.MIId;
                        }
                        else
                        {
                            var temp = new XrefClientMicompanyServices
                            {
                                ClientId = d.CId,
                                ClientMicompanyServicesId = 0,
                                MicompanyId = d.MIId
                            };
                            acctx.XrefClientMicompanyServices.Add(temp);
                        }
                    }
                    acctx.SaveChanges();
                }
                return ret;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public GetClientUSDAReply GetClientUSDA(int id)
        {
            var ret = new GetClientUSDAReply();

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    var usdaclmtyps = acctx.LkpUsdaclaimTypeMatrix.ToList();
                    var usdaimpmtds = acctx.LkpUsdaimportType.ToList();

                    var temp = acctx.XrefClientUsdaclaimScope.Where(x => x.ClientId == id).ToList().Select(x => new ClientUSDA
                    {
                        Id = x.ClientUsdaclaimScopeId,
                        CId = id,
                        ClmTypeMatrixId = x.UsdaclaimTypeMatrixId,
                        ClmTypeMatrixName = usdaclmtyps.Single(y => y.UsdaclaimTypeMatrixId == x.UsdaclaimTypeMatrixId).Result,
                        Active = x.Active ? 1 : 0,
                        ImpMethodId = x.UsdaimportTypeId,
                        ImpMethodName = usdaimpmtds.Single(y => y.UsdaimportTypeId == x.UsdaimportTypeId).ImportMethodName
                    }).ToList();

                    ret.ClientUSDAs.AddRange(temp);
                    foreach (var c in usdaimpmtds)
                    {
                        foreach (var d in usdaclmtyps)
                        {
                            if (!temp.Any(x => x.ClmTypeMatrixId == d.UsdaclaimTypeMatrixId && x.ImpMethodId == c.UsdaimportTypeId))
                            {
                                ret.ClientUSDAs.Add(new ClientUSDA
                                {
                                    Id = 0,
                                    CId = id,
                                    Active = 0,
                                    ClmTypeMatrixId = d.UsdaclaimTypeMatrixId,
                                    ClmTypeMatrixName = d.Result,
                                    ImpMethodId = c.UsdaimportTypeId,
                                    ImpMethodName = c.ImportMethodName
                                });
                            }
                        }
                    }
                }
                return ret;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public MessageReply SaveClientUSDA(SaveClientUSDARequest data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    var uas = acctx.XrefClientUsdaclaimScope.Where(x => x.ClientId == data.CId).ToList();

                    foreach (var tg in uas)
                    {
                        if (!data.ClientUSDAs.Any(x => x.ClmTypeMatrixId == tg.UsdaclaimTypeMatrixId && x.ImpMethodId == tg.UsdaimportTypeId))
                        {
                            acctx.XrefClientUsdaclaimScope.Remove(tg);
                        }
                    }
                    foreach (var d in data.ClientUSDAs)
                    {
                        if (d.Id > 0)
                        {
                            var temp = uas.Single(x => x.ClientUsdaclaimScopeId == d.Id);
                            temp.Active = d.Active == 1;
                            temp.UsdaclaimTypeMatrixId = d.ClmTypeMatrixId;
                            temp.UsdaimportTypeId = d.ImpMethodId;
                            temp.LastUpdateDate = DateTime.Now;
                            temp.LastUpdateUser = _userid;
                        }
                        else
                        {
                            var temp = new XrefClientUsdaclaimScope
                            {
                                Active = d.Active == 1,
                                ClientId = d.CId,
                                UsdaclaimTypeMatrixId = d.ClmTypeMatrixId,
                                UsdaimportTypeId = d.ImpMethodId,
                                EnteredDate = DateTime.Now,
                                EnteredUser = _userid,
                                LastUpdateDate = DateTime.Now,
                                LastUpdateUser = _userid
                            };
                            acctx.XrefClientUsdaclaimScope.Add(temp);
                        }
                    }
                    acctx.SaveChanges();
                }
                return ret;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public GetClientEDIReply GetClientEDI(int id)
        {
            var ret = new GetClientEDIReply();
                       
            try
            {
                using(var hcctx = new HUDClaimsContext())
                {
                    var clmtyps = hcctx.LkpFhalookups.Where(x => x.Lucategory == "FHAClaimType").ToList();
                    var subtyps = hcctx.LkpFhalookups.Where(x => x.Lucategory == "FHAClaimSubtype").ToList();
                                                 
                    var temp = hcctx.XrefFhaclientClaimTypeEdicontrol.Where(x => x.FhaclientId == id).ToList().Select(x => new ClientEDI
                    {
                       Id = x.FhaclientClaimTypeEdicontrolId,
                       CId = id,
                       ClaimTypeId = x.ClaimTypeId,
                       ClaimTypeName = clmtyps.Single(y => y.FhalookupId == x.ClaimTypeId).DisplayCode1,
                       SubTypeId = x.FhaclaimSubTypeId ?? 0,
                       SubTypeName = subtyps.Single(y => y.FhalookupId == x.FhaclaimSubTypeId).DisplayCode1,
                       Enabled = x.EnableHudEdi ? 1 : 0
                    }).ToList();

                    ret.ClientEDIs.AddRange(temp);
                }
                return ret;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public MessageReply SaveClientEDI(SaveClientEDIRequest data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
               using (var hudctx = new HUDClaimsContext())
                {
                    var uas = hudctx.XrefFhaclientClaimTypeEdicontrol.Where(x => x.FhaclientId == data.CId).ToList();

                    foreach (var tg in uas)
                    {
                        if (!data.ClientEDIs.Any(x => x.ClaimTypeId == tg.ClaimTypeId && x.SubTypeId == tg.FhaclaimSubTypeId))
                        {
                            hudctx.XrefFhaclientClaimTypeEdicontrol.Remove(tg);
                        }
                    }
                    foreach (var d in data.ClientEDIs)
                    {
                        if (d.Id > 0)
                        {
                            var temp = uas.Single(x => x.FhaclientClaimTypeEdicontrolId == d.Id);
                            temp.EnableHudEdi = d.Enabled == 1;
                        }
                        else
                        {
                            var temp = new XrefFhaclientClaimTypeEdicontrol
                            {
                                ClaimTypeId = d.ClaimTypeId,
                                FhaclientClaimTypeEdicontrolId = 0,
                                FhaclaimSubTypeId = d.SubTypeId.GetNullValue(),
                                EnableHudEdi = d.Enabled == 1,
                                FhaclientId = d.CId
                            };
                            hudctx.XrefFhaclientClaimTypeEdicontrol.Add(temp);
                        }
                    }
                    hudctx.SaveChanges();
                }
                return ret;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public GetCMSGroupApplicationReply GetCMSRoleApplication(int id)
        {
            var ret = new GetCMSGroupApplicationReply();

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    var apps = acctx.LkpApplications.Where(x => x.Active ?? false).OrderBy(x => x.ApplicationName).ToList();

                    var temp = acctx.XrefApplicationRoles.Where(x => x.RoleId == id).Select(x => new CMSGroupApplication
                    {
                        AppId = x.ApplicationId,
                        AppName = x.Application.ApplicationName,
                        Id = x.ApplicationRoleId,
                        GId = x.RoleId,
                        MarkedForDelete = x.MarkedForDelete ? 1 : 0
                    }).ToList();

                    ret.CMSGroupApplications.AddRange(temp);
                    foreach (var c in apps)
                    {
                        if (!temp.Any(x => x.AppId == c.ApplicationId))
                        {
                            ret.CMSGroupApplications.Add(new CMSGroupApplication
                            {
                                Id = 0,
                                GId = id,
                                AppId = c.ApplicationId,
                                AppName = c.ApplicationName,
                                MarkedForDelete = 0
                            });
                        }
                    }
                }
                return ret;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public MessageReply SaveCMSRoleApplication(SaveCMSGroupApplicationRequest data)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    var uas = acctx.XrefApplicationRoles.Where(x => x.RoleId == data.GId).ToList();

                    foreach (var tg in uas)
                    {
                        if (!data.CMSGroupApplications.Any(x => x.AppId == tg.ApplicationId))
                        {
                            acctx.XrefApplicationRoles.Remove(tg);
                        }
                    }
                    foreach (var d in data.CMSGroupApplications)
                    {
                        if (d.Id > 0)
                        {
                            var temp = uas.Single(x => x.ApplicationRoleId == d.Id);
                            temp.MarkedForDelete = d.MarkedForDelete == 1;
                            temp.LastUpdateDate = DateTime.Now;
                            temp.LastUpdateUserId = _userid;
                        }
                        else
                        {
                            var temp = new XrefApplicationRoles
                            {
                                ApplicationRoleId = 0,
                                ApplicationId = d.AppId,
                                RoleId = d.GId,
                                MarkedForDelete = false,
                                EnteredByUserId = _userid,
                                EnteredDate = DateTime.Now,
                                LastUpdateDate = DateTime.Now,
                                LastUpdateUserId = _userid
                            };
                            acctx.XrefApplicationRoles.Add(temp);
                        }
                    }
                    acctx.SaveChanges();
                }
                return ret;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
