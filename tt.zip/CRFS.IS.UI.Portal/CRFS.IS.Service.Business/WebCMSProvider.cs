﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Google.Protobuf.WellKnownTypes;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.Common.TransferObjects;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Security;
using CRFS.IS.Service.Util;

namespace CRFS.IS.Service.Business
{
    public class WebCMSProvider
    {
        private IConfiguration _config;
        private ILogger _logger;
        private int _userid;

        public WebCMSProvider(IConfiguration config, ILogger logger, int uid)
        {
            _config = config;
            _logger = logger;
            _userid = uid;
        }
        public HUDInitialInput GetHudInitialInput(int id)
        {
            var ret = new HUDInitialInput();
            try { 
                using(var ctx = new HUDClaimsContext())
                {
                    ret = ctx.VwHudInitialInput.Where(x => x.FhaclaimId == id).Select(x => new HUDInitialInput
                    {
                        FhaloanId = x.FhaloanId,
                        AuthorizedBidAmount = (double)x.AuthorizedBidAmount.GetSafeNullValue(),
                        PropertyAddress1 = x.PropertyAddress1.GetSafeString(),
                        PropertyAddress2 = x.PropertyAddress2.GetSafeString(),
                        LastArmrate = (double)x.LastArmrate.GetSafeNullValue(),
                        OriginalMortgageAmount = (double)x.OriginalMortgageAmount.GetSafeNullValue(),
                        PartAformPrepared = x.PartAformPrepared.GetSafeDateTimeString(),
                        SectionOfTheActCode = x.SectionOfTheActCode.GetSafeString(),
                        SectionOfTheActId = x.SectionOfTheActId.GetSafeNullValue(),
                        SuccessfulBidAmount = (double)x.SuccessfulBidAmount.GetSafeNullValue(),
                        ClaimType = x.ClaimType,
                        ClaimTypeId = x.ClaimTypeId,
                        ClientId = x.ClientId,
                        ClientName = x.ClientName,
                        CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                        DateOfNoticeToConvey = x.DateOfNoticeToConvey.GetSafeDateTimeString(),
                        DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeNullValue(),
                        DebentureInterestRateCalc = (double)x.DebentureInterestRateCalc.GetSafeNullValue(),
                        DebentureStartDate = x.DebentureStartDate.GetSafeDateTimeString(),
                        DefaultDate = x.DefaultDate.GetSafeDateTimeString(),
                        EndorsementDate = x.EndorsementDate.GetSafeDateTimeString(),
                        FhacaseNumber = x.FhacaseNumber,
                        FhaclaimId = x.FhaclaimId,
                        FhaclientId = x.FhaclientId,
                        FinalSettlementDate = x.FinalSettlementDate.GetSafeDateTimeString(),
                        McdequalCurtailDateForDi = x.McdequalCurtailDateForDi.GetIntValue(),
                        ModifiedInterestRate = (double)x.ModifiedInterestRate.GetSafeNullValue(),
                        MortgageeId = x.MortgageeId.GetSafeNullValue(),
                        MortgageeLoanNumber = x.MortgageeLoanNumber.GetSafeString(),
                        MortgageeName = x.MortgageeName.GetSafeString(),
                        MortgageeReportedCurtailmentDate = x.MortgageeReportedCurtailmentDate.GetSafeDateTimeString(),
                        MortgagorFullName = x.MortgagorFullName.GetSafeString(),
                        HoldingMortgageeNumber = x.HoldingMortgageeNumber.GetSafeString(),
                        LastUpdateDate = x.LastUpdateDate.GetSafeDateTimeString(),
                        LastUpdateUser = x.LastUpdateUser.GetSafeNullValue(),
                        NewMaturityDate = x.NewMaturityDate.GetSafeDateTimeString(),
                        NoteRate = (double)x.NoteRate.GetSafeNullValue(),
                        PartBformPrepared = x.PartBformPrepared.GetSafeDateTimeString(),
                        PropertyCity = x.PropertyCity.GetSafeString(),
                        PropertyStateCode = x.PropertyStateCode.GetSafeString(),
                        PropertyZipCode = x.PropertyZipCode.GetSafeString(),
                        SecondChanceSaleDate = x.SecondChanceSaleDate.GetSafeDateTimeString(),
                        ServicerId = x.ServicerId.GetSafeNullValue(),
                        ServicerName = x.ServicerName.GetSafeString(),
                        ServicingMortageeNumber = x.ServicingMortageeNumber.GetSafeString(),
                        UnpaidLoanBalance = (double)x.UnpaidLoanBalance.GetSafeNullValue(),
                    }).Single();

                    ret.CheckSum = ret.GetHashCode().ToString();
                }
                return ret;
            }
            catch
            {
                throw;
            }
        }
        public MessageReply SaveHudInitialInput(HUDInitialInput req)
        {
            var ret = new MessageReply { Message = Constant.Success };
            try
            {
                using(var ctx = new HUDClaimsContext())
                {
                    var temp = ctx.VwHudInitialInput.Where(x => x.FhaclaimId == req.FhaclaimId).Select(x => new HUDInitialInput
                    {
                        FhaloanId = x.FhaloanId,
                        AuthorizedBidAmount = (double)x.AuthorizedBidAmount.GetSafeNullValue(),
                        PropertyAddress1 = x.PropertyAddress1.GetSafeString(),
                        PropertyAddress2 = x.PropertyAddress2.GetSafeString(),
                        LastArmrate = (double)x.LastArmrate.GetSafeNullValue(),
                        OriginalMortgageAmount = (double)x.OriginalMortgageAmount.GetSafeNullValue(),
                        PartAformPrepared = x.PartAformPrepared.GetSafeDateTimeString(),
                        SectionOfTheActCode = x.SectionOfTheActCode.GetSafeString(),
                        SectionOfTheActId = x.SectionOfTheActId.GetSafeNullValue(),
                        SuccessfulBidAmount = (double)x.SuccessfulBidAmount.GetSafeNullValue(),
                        ClaimType = x.ClaimType,
                        ClaimTypeId = x.ClaimTypeId,
                        ClientId = x.ClientId,
                        ClientName = x.ClientName,
                        CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                        DateOfNoticeToConvey = x.DateOfNoticeToConvey.GetSafeDateTimeString(),
                        DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeNullValue(),
                        DebentureInterestRateCalc = (double)x.DebentureInterestRateCalc.GetSafeNullValue(),
                        DebentureStartDate = x.DebentureStartDate.GetSafeDateTimeString(),
                        DefaultDate = x.DefaultDate.GetSafeDateTimeString(),
                        EndorsementDate = x.EndorsementDate.GetSafeDateTimeString(),
                        FhacaseNumber = x.FhacaseNumber,
                        FhaclaimId = x.FhaclaimId,
                        FhaclientId = x.FhaclientId,
                        FinalSettlementDate = x.FinalSettlementDate.GetSafeDateTimeString(),
                        McdequalCurtailDateForDi = x.McdequalCurtailDateForDi ?? false ? 1 : 0,
                        ModifiedInterestRate = (double)x.ModifiedInterestRate.GetSafeNullValue(),
                        MortgageeId = x.MortgageeId.GetSafeNullValue(),
                        MortgageeLoanNumber = x.MortgageeLoanNumber.GetSafeString(),
                        MortgageeName = x.MortgageeName.GetSafeString(),
                        MortgageeReportedCurtailmentDate = x.MortgageeReportedCurtailmentDate.GetSafeDateTimeString(),
                        MortgagorFullName = x.MortgagorFullName.GetSafeString(),
                        HoldingMortgageeNumber = x.HoldingMortgageeNumber.GetSafeString(),
                        LastUpdateDate = x.LastUpdateDate.GetSafeDateTimeString(),
                        LastUpdateUser = x.LastUpdateUser.GetSafeNullValue(),
                        NewMaturityDate = x.NewMaturityDate.GetSafeDateTimeString(),
                        NoteRate = (double)x.NoteRate.GetSafeNullValue(),
                        PartBformPrepared = x.PartBformPrepared.GetSafeDateTimeString(),
                        PropertyCity = x.PropertyCity.GetSafeString(),
                        PropertyStateCode = x.PropertyStateCode.GetSafeString(),
                        PropertyZipCode = x.PropertyZipCode.GetSafeString(),
                        SecondChanceSaleDate = x.SecondChanceSaleDate.GetSafeDateTimeString(),
                        ServicerId = x.ServicerId.GetSafeNullValue(),
                        ServicerName = x.ServicerName.GetSafeString(),
                        ServicingMortageeNumber = x.ServicingMortageeNumber.GetSafeString(),
                        UnpaidLoanBalance = (double)x.UnpaidLoanBalance.GetSafeNullValue(),
                    }).Single();

                    if (req.CheckSum != temp.GetHashCode().ToString())
                        throw new Exception("The record was altered by another session during editing");

                    var loan = ctx.TblFhaloans.Single(x => x.FhaloanId == req.FhaloanId);
                    var claim = ctx.TblFhaclaims.Single(x => x.FhaclaimId == req.FhaclaimId);
                    var parta27011 = ctx.TblPartA27011.Single(x => x.FhaclaimId == req.FhaclaimId);

                    loan.PropertyAddress1 = req.PropertyAddress1;
                    loan.PropertyAddress2 = req.PropertyAddress2;
                    loan.PropertyCity = req.PropertyCity;
                    loan.PropertyStateCode = req.PropertyStateCode;
                    loan.PropertyZipCode = req.PropertyZipCode;
                    loan.ServicerId = req.ServicerId.GetNullValue();
                    loan.MortgageeId = req.MortgageeId.GetNullValue();
                    loan.LastUpdateDate = DateTime.Now;
                    loan.LastUpdateUser = _userid;

                    claim.SectionOfTheActId = req.SectionOfTheActId.GetNullValue();
                    claim.DefaultDate = req.DefaultDate.GetNullDate();
                    claim.CurtailDateForDi = req.CurtailDateForDi.GetNullDate();
                    claim.ModifiedInterestRate = (decimal?)req.ModifiedInterestRate.GetNullValue();
                    claim.NewMaturityDate = req.NewMaturityDate.GetNullDate();
                    claim.LastArmrate = (decimal?)req.LastArmrate.GetNullValue();
                    claim.LastUpdateUser = _userid;
                    claim.LastUpdateDate = DateTime.Now;

                    parta27011.EndorsementDate = req.EndorsementDate.GetNullDate();
                    parta27011.DateOfNoticeToConvey = req.DateOfNoticeToConvey.GetNullDate();
                    parta27011.Block15Original = (decimal?)req.OriginalMortgageAmount.GetNullValue();
                    parta27011.UnpaidLoanBalance = (decimal?)req.UnpaidLoanBalance.GetNullValue();
                    parta27011.LastUpdateDate = DateTime.Now;
                    parta27011.LastUpdateUser = _userid;

                    ctx.SaveChanges();
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public HUDPartA GetHudPartA(int id)
        {
            var ret = new HUDPartA();
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    ret = ctx.VwHudPartA.Where(x => x.FhaclaimId == id).Select(x => new HUDPartA
                    {
                        FhaloanId = x.FhaloanId,
                        AuthorizedBidAmount = (double)x.AuthorizedBidAmount.GetSafeNullValue(),
                        PropertyAddress1 = x.PropertyAddress1.GetSafeString(),
                        PropertyAddress2 = x.PropertyAddress2.GetSafeString(),
                        LastArmrate = (double)x.LastArmrate.GetSafeNullValue(),
                        SectionOfTheActCode = x.SectionOfTheActCode.GetSafeString(),
                        SectionOfTheActId = x.SectionOfTheActId.GetSafeNullValue(),
                        ClaimType = x.ClaimType,
                        ClaimTypeId = x.ClaimTypeId,
                        ClientName = x.ClientName,
                        DateOfNoticeToConvey = x.DateOfNoticeToConvey.GetSafeDateTimeString(),
                        DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeNullValue(),
                        EndorsementDate = x.EndorsementDate.GetSafeDateTimeString(),
                        FhacaseNumber = x.FhacaseNumber,
                        FhaclaimId = x.FhaclaimId,
                        FhaclientId = x.FhaclientId,
                        ModifiedInterestRate = (double)x.ModifiedInterestRate.GetSafeNullValue(),
                        MortgageeId = x.MortgageeId.GetSafeNullValue(),
                        MortgageeLoanNumber = x.MortgageeLoanNumber.GetSafeString(),
                        MortgageeName = x.MortgageeName.GetSafeString(),
                        MortgageeReportedCurtailmentDate = x.MortgageeReportedCurtailmentDate.GetSafeDateTimeString(),
                        MortgagorFullName = x.MortgagorFullName.GetSafeString(),
                        HoldingMortgageeNumber = x.HoldingMortgageeNumber.GetSafeString(),
                        NewMaturityDate = x.NewMaturityDate.GetSafeDateTimeString(),
                        PropertyCity = x.PropertyCity.GetSafeString(),
                        PropertyStateCode = x.PropertyStateCode.GetSafeString(),
                        PropertyZipCode = x.PropertyZipCode.GetSafeString(),
                        ServicerId = x.ServicerId.GetSafeNullValue(),
                        ServicerName = x.ServicerName.GetSafeString(),
                        ServicingMortageeNumber = x.ServicingMortageeNumber.GetSafeString(),
                        UnpaidLoanBalance = (double)x.UnpaidLoanBalance.GetSafeNullValue(),
                        DateAssignmentFiledForRecord = x.DateAssignmentFiledForRecord.GetSafeDateTimeString(),
                        DateLocalOfficeApprovalConveyanceDamaged = x.DateLocalOfficeApprovalConveyanceDamaged.GetSafeDateTimeString(),
                        DateLocalOfficeApprovalConveyanceOccupied = x.DateLocalOfficeApprovalConveyanceOccupied.GetSafeDateTimeString(),
                        DateOfAcquisitionOfTitle = x.DateOfAcquisitionOfTitle.GetSafeDateTimeString(),
                        DateDamaged = x.DateDamaged.GetSafeDateTimeString(),
                        DateDeedFiledForRecord = x.DateDeedFiledForRecord.GetSafeDateTimeString(),
                        DateOfAppraisal = x.DateOfAppraisal.GetSafeDateTimeString(),
                        ExpDateExtensionToAssign = x.ExpDateExtensionToAssign.GetSafeDateTimeString(),
                        MonthlyInterestAndPrincipal = (double)x.MonthlyInterestAndPrincipal.GetSafeNullValue(),
                        MortgageeAddress = x.MortgageeAddress.GetSafeString(),
                        MonthlyFhainsurance = (double)x.MonthlyFhainsurance.GetSafeNullValue(),
                        PartA27011Id = x.PartA27011id,
                        OrigMtgAmt = (double)x.OrigMtgAmt.GetSafeNullValue(),
                        SectionOfTheAct = x.SectionOfTheAct.GetSafeString(),
                        ServicerAddress = x.ServicerAddress.GetSafeString(),
                        BankruptcyDateFiled = x.BankruptcyDateFiled.GetSafeDateTimeString(),
                        Block10Date = x.Block10Date.GetSafeDateTimeString(),
                        Block10TypeId = x.Block10TypeId.GetSafeNullValue(),
                        Block11DateofDil = x.Block11DateofDil.GetIntValue(),
                        Block11Instituted = x.Block11Instituted.GetIntValue(),
                        Block15Modified = (double)x.Block15Modified.GetSafeNullValue(),
                        Block15Original = (double)x.Block15Original.GetSafeNullValue(),
                        Block19Date = x.Block19Date.GetSafeDateTimeString(),
                        Block20Date = x.Block20Date.GetSafeDateTimeString(),
                        Block9Date = x.Block9Date.GetSafeDateTimeString(),
                        Block9TypeId = x.Block9TypeId.GetSafeNullValue(),
                        IsMortgageeSuccessfulBidder = x.IsMortgageeSuccessfulBidder.GetIntValue(),
                        ClaimTypeText = x.ClaimTypeText,
                        DamageCode = x.DamageCode.GetSafeString(),
                        DamageTypeId = x.DamageTypeId.GetSafeNullValue(),
                        DateFormPrepared = x.DateFormPrepared.GetSafeDateTimeString(),
                        DateLocalOfficeCertificationConveyanceDamaged = x.DateLocalOfficeCertificationConveyanceDamaged.GetSafeDateTimeString(),
                        DateOfClosing = x.DateOfClosing.GetSafeDateTimeString(),
                        DateOfDeedInLieu = x.DateOfDeedInLieu.GetSafeDateTimeString(),
                        DateOfExtensionToConvey = x.DateOfExtensionToConvey.GetSafeDateTimeString(),
                        DateOfPossession = x.DateOfPossession.GetSafeDateTimeString(),
                        EstimateOfDamage = (double)x.EstimateOfDamage.GetSafeNullValue(),
                        DefaultReason = x.DefaultReason.GetSafeString(),
                        DefaultReasonId = x.DefaultReasonId.GetSafeNullValue(),
                        DefficiendyJudgementCode = x.DefficiendyJudgementCode.GetSafeString(),
                        DeficiencyJudgement = x.DeficiencyJudgement.GetSafeString(),
                        DeficiencyJudgementCodeId = x.DeficiencyJudgementCodeId.GetSafeNullValue(),
                        ExpDateExtensionToForeclose = x.ExpDateExtensionToForeclose.GetSafeDateTimeString(),
                        FirmCommitmentDate = x.FirmCommitmentDate.GetSafeDateTimeString(),
                        FirstPaymentDueDateModified = x.FirstPaymentDueDateModified.GetSafeDateTimeString(),
                        FirstPaymentDueDateOriginal = x.FirstPaymentDueDateOriginal.GetSafeDateTimeString(),
                        ForeclosureProceedingsDate = x.ForeclosureProceedingsDate.GetSafeDateTimeString(),
                        HipcancelledDate = x.HipcancelledDate.GetSafeDateTimeString(),
                        HiprefusedDate = x.HiprefusedDate.GetSafeDateTimeString(),
                        HoldingMortgageeEin = x.HoldingMortgageeEin.GetSafeString(),
                        InsuranceRecovery = (double)x.InsuranceRecovery.GetSafeNullValue(),
                        LastCompleteInstallmentPaidDate = x.LastCompleteInstallmentPaidDate.GetSafeDateTimeString(),
                        MortgagorLastName = x.MortgagorLastName.GetSafeString(),
                        MonthlyHazardInsurance = (double)x.MonthlyHazardInsurance.GetSafeNullValue(),
                        MonthlyTaxes = (double)x.MonthlyTaxes.GetSafeNullValue(),
                        MortgageeCity = x.MortgageeCity.GetSafeString(),
                        MortgageeComments = x.MortgageeComments.GetSafeString(),
                        MortgageeStateCode = x.MortgageeStateCode.GetSafeString(),
                        MortgageeZipCode = x.MortgageeZipCode.GetSafeString(),
                        MortgagorFirstName = x.MortgagorFirstName.GetSafeString(),
                        MortgagorMiddleName = x.MortgagorMiddleName.GetSafeString(),
                        MortgagorSsn = x.MortgagorSsn.GetSafeString(),
                        NumberOfLivingUnits = x.NumberOfLivingUnits.GetSafeNullValue(),
                        OccupancyStatus = x.OccupancyStatus.GetSafeString(),
                        OccupancyStatusId = x.OccupancyStatusId.GetSafeNullValue(),
                        ReleaseOfBankruptcyDate = x.ReleaseOfBankruptcyDate.GetSafeDateTimeString(),
                        PropertyCondition = x.PropertyCondition.GetSafeString(),
                        PropertyConditionId = x.PropertyConditionId.GetSafeNullValue(),
                        PropertyDescription = x.PropertyDescription.GetSafeString(),
                        ServicerCity = x.ServicerCity.GetSafeString(),
                        ServicerStateCode = x.ServicerStateCode.GetSafeString(),
                        ServicerZipCode = x.ServicerZipCode.GetSafeString()
                    }).Single();

                    ret.CheckSum = ret.GetHashCode().ToString();
                }
                return ret;
            }
            catch
            {
                throw;
            }
        }
        public MessageReply SaveHudPartA(HUDPartA req)
        {
            var ret = new MessageReply { Message = Constant.Success };
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    var temp = ctx.VwHudPartA.Where(x => x.FhaclaimId == req.FhaclaimId).Select(x => new HUDPartA
                    {
                        FhaloanId = x.FhaloanId,
                        AuthorizedBidAmount = (double)x.AuthorizedBidAmount.GetSafeNullValue(),
                        PropertyAddress1 = x.PropertyAddress1.GetSafeString(),
                        PropertyAddress2 = x.PropertyAddress2.GetSafeString(),
                        LastArmrate = (double)x.LastArmrate.GetSafeNullValue(),
                        SectionOfTheActCode = x.SectionOfTheActCode.GetSafeString(),
                        SectionOfTheActId = x.SectionOfTheActId.GetSafeNullValue(),
                        ClaimType = x.ClaimType,
                        ClaimTypeId = x.ClaimTypeId,
                        ClientName = x.ClientName,
                        DateOfNoticeToConvey = x.DateOfNoticeToConvey.GetSafeDateTimeString(),
                        DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeNullValue(),
                        EndorsementDate = x.EndorsementDate.GetSafeDateTimeString(),
                        FhacaseNumber = x.FhacaseNumber,
                        FhaclaimId = x.FhaclaimId,
                        FhaclientId = x.FhaclientId,
                        ModifiedInterestRate = (double)x.ModifiedInterestRate.GetSafeNullValue(),
                        MortgageeId = x.MortgageeId.GetSafeNullValue(),
                        MortgageeLoanNumber = x.MortgageeLoanNumber.GetSafeString(),
                        MortgageeName = x.MortgageeName.GetSafeString(),
                        MortgageeReportedCurtailmentDate = x.MortgageeReportedCurtailmentDate.GetSafeDateTimeString(),
                        MortgagorFullName = x.MortgagorFullName.GetSafeString(),
                        HoldingMortgageeNumber = x.HoldingMortgageeNumber.GetSafeString(),
                        NewMaturityDate = x.NewMaturityDate.GetSafeDateTimeString(),
                        PropertyCity = x.PropertyCity.GetSafeString(),
                        PropertyStateCode = x.PropertyStateCode.GetSafeString(),
                        PropertyZipCode = x.PropertyZipCode.GetSafeString(),
                        ServicerId = x.ServicerId.GetSafeNullValue(),
                        ServicerName = x.ServicerName.GetSafeString(),
                        ServicingMortageeNumber = x.ServicingMortageeNumber.GetSafeString(),
                        UnpaidLoanBalance = (double)x.UnpaidLoanBalance.GetSafeNullValue(),
                        DateAssignmentFiledForRecord = x.DateAssignmentFiledForRecord.GetSafeDateTimeString(),
                        DateLocalOfficeApprovalConveyanceDamaged = x.DateLocalOfficeApprovalConveyanceDamaged.GetSafeDateTimeString(),
                        DateLocalOfficeApprovalConveyanceOccupied = x.DateLocalOfficeApprovalConveyanceOccupied.GetSafeDateTimeString(),
                        DateOfAcquisitionOfTitle = x.DateOfAcquisitionOfTitle.GetSafeDateTimeString(),
                        DateDamaged = x.DateDamaged.GetSafeDateTimeString(),
                        DateDeedFiledForRecord = x.DateDeedFiledForRecord.GetSafeDateTimeString(),
                        DateOfAppraisal = x.DateOfAppraisal.GetSafeDateTimeString(),
                        ExpDateExtensionToAssign = x.ExpDateExtensionToAssign.GetSafeDateTimeString(),
                        MonthlyInterestAndPrincipal = (double)x.MonthlyInterestAndPrincipal.GetSafeNullValue(),
                        MortgageeAddress = x.MortgageeAddress.GetSafeString(),
                        MonthlyFhainsurance = (double)x.MonthlyFhainsurance.GetSafeNullValue(),
                        PartA27011Id = x.PartA27011id,
                        OrigMtgAmt = (double)x.OrigMtgAmt.GetSafeNullValue(),
                        SectionOfTheAct = x.SectionOfTheAct.GetSafeString(),
                        ServicerAddress = x.ServicerAddress.GetSafeString(),
                        BankruptcyDateFiled = x.BankruptcyDateFiled.GetSafeDateTimeString(),
                        Block10Date = x.Block10Date.GetSafeDateTimeString(),
                        Block10TypeId = x.Block10TypeId.GetSafeNullValue(),
                        Block11DateofDil = x.Block11DateofDil.GetIntValue(),
                        Block11Instituted = x.Block11Instituted.GetIntValue(),
                        Block15Modified = (double)x.Block15Modified.GetSafeNullValue(),
                        Block15Original = (double)x.Block15Original.GetSafeNullValue(),
                        Block19Date = x.Block19Date.GetSafeDateTimeString(),
                        Block20Date = x.Block20Date.GetSafeDateTimeString(),
                        Block9Date = x.Block9Date.GetSafeDateTimeString(),
                        Block9TypeId = x.Block9TypeId.GetSafeNullValue(),
                        IsMortgageeSuccessfulBidder = x.IsMortgageeSuccessfulBidder.GetIntValue(),
                        ClaimTypeText = x.ClaimTypeText,
                        DamageCode = x.DamageCode.GetSafeString(),
                        DamageTypeId = x.DamageTypeId.GetSafeNullValue(),
                        DateFormPrepared = x.DateFormPrepared.GetSafeDateTimeString(),
                        DateLocalOfficeCertificationConveyanceDamaged = x.DateLocalOfficeCertificationConveyanceDamaged.GetSafeDateTimeString(),
                        DateOfClosing = x.DateOfClosing.GetSafeDateTimeString(),
                        DateOfDeedInLieu = x.DateOfDeedInLieu.GetSafeDateTimeString(),
                        DateOfExtensionToConvey = x.DateOfExtensionToConvey.GetSafeDateTimeString(),
                        DateOfPossession = x.DateOfPossession.GetSafeDateTimeString(),
                        EstimateOfDamage = (double)x.EstimateOfDamage.GetSafeNullValue(),
                        DefaultReason = x.DefaultReason.GetSafeString(),
                        DefaultReasonId = x.DefaultReasonId.GetSafeNullValue(),
                        DefficiendyJudgementCode = x.DefficiendyJudgementCode.GetSafeString(),
                        DeficiencyJudgement = x.DeficiencyJudgement.GetSafeString(),
                        DeficiencyJudgementCodeId = x.DeficiencyJudgementCodeId.GetSafeNullValue(),
                        ExpDateExtensionToForeclose = x.ExpDateExtensionToForeclose.GetSafeDateTimeString(),
                        FirmCommitmentDate = x.FirmCommitmentDate.GetSafeDateTimeString(),
                        FirstPaymentDueDateModified = x.FirstPaymentDueDateModified.GetSafeDateTimeString(),
                        FirstPaymentDueDateOriginal = x.FirstPaymentDueDateOriginal.GetSafeDateTimeString(),
                        ForeclosureProceedingsDate = x.ForeclosureProceedingsDate.GetSafeDateTimeString(),
                        HipcancelledDate = x.HipcancelledDate.GetSafeDateTimeString(),
                        HiprefusedDate = x.HiprefusedDate.GetSafeDateTimeString(),
                        HoldingMortgageeEin = x.HoldingMortgageeEin.GetSafeString(),
                        InsuranceRecovery = (double)x.InsuranceRecovery.GetSafeNullValue(),
                        LastCompleteInstallmentPaidDate = x.LastCompleteInstallmentPaidDate.GetSafeDateTimeString(),
                        MortgagorLastName = x.MortgagorLastName.GetSafeString(),
                        MonthlyHazardInsurance = (double)x.MonthlyHazardInsurance.GetSafeNullValue(),
                        MonthlyTaxes = (double)x.MonthlyTaxes.GetSafeNullValue(),
                        MortgageeCity = x.MortgageeCity.GetSafeString(),
                        MortgageeComments = x.MortgageeComments.GetSafeString(),
                        MortgageeStateCode = x.MortgageeStateCode.GetSafeString(),
                        MortgageeZipCode = x.MortgageeZipCode.GetSafeString(),
                        MortgagorFirstName = x.MortgagorFirstName.GetSafeString(),
                        MortgagorMiddleName = x.MortgagorMiddleName.GetSafeString(),
                        MortgagorSsn = x.MortgagorSsn.GetSafeString(),
                        NumberOfLivingUnits = x.NumberOfLivingUnits.GetSafeNullValue(),
                        OccupancyStatus = x.OccupancyStatus.GetSafeString(),
                        OccupancyStatusId = x.OccupancyStatusId.GetSafeNullValue(),
                        ReleaseOfBankruptcyDate = x.ReleaseOfBankruptcyDate.GetSafeDateTimeString(),
                        PropertyCondition = x.PropertyCondition.GetSafeString(),
                        PropertyConditionId = x.PropertyConditionId.GetSafeNullValue(),
                        PropertyDescription = x.PropertyDescription.GetSafeString(),
                        ServicerCity = x.ServicerCity.GetSafeString(),
                        ServicerStateCode = x.ServicerStateCode.GetSafeString(),
                        ServicerZipCode = x.ServicerZipCode.GetSafeString()
                    }).Single();

                    if (req.CheckSum != temp.GetHashCode().ToString())
                        throw new Exception("The record was altered by another session during editing");

                    var parta27011 = ctx.TblPartA27011.Single(x => x.FhaclaimId == req.FhaclaimId);

                    parta27011.DefaultReasonId = req.DefaultReasonId.GetNullValue();
                    parta27011.FirstPaymentDueDateOriginal = req.FirstPaymentDueDateOriginal.GetNullDate();
                    parta27011.FirstPaymentDueDateModified = req.FirstPaymentDueDateModified.GetNullDate();
                    parta27011.LastCompleteInstallmentPaidDate = req.LastCompleteInstallmentPaidDate.GetNullDate();
                    parta27011.DateOfAcquisitionOfTitle = req.DateOfAcquisitionOfTitle.GetNullDate();
                    parta27011.DateOfPossession = req.DateOfPossession.GetNullDate();
                    parta27011.DateOfAppraisal = req.DateOfAppraisal.GetNullDate();
                    parta27011.Block9Date = req.Block9Date.GetNullDate();
                    parta27011.Block9TypeId = req.Block9TypeId.GetNullValue();
                    parta27011.Block10Date = req.Block10Date.GetNullDate();
                    parta27011.Block10TypeId = req.Block10TypeId.GetNullValue();
                    parta27011.Block11Instituted = req.Block11Instituted.GetBoolValue();
                    parta27011.LastUpdateDate = DateTime.Now;
                    parta27011.LastUpdateUser = _userid;
                    parta27011.DateOfDeedInLieu = req.DateOfDeedInLieu.GetNullDate();
                    parta27011.Block11DateofDil = req.Block11DateofDil.GetBoolValue();
                    parta27011.DateDeedFiledForRecord = req.DateDeedFiledForRecord.GetNullDate();
                    parta27011.DateOfClosing = req.DateOfClosing.GetNullDate();
                    parta27011.DateAssignmentFiledForRecord = req.DateAssignmentFiledForRecord.GetNullDate();
                    parta27011.Block15Original = (decimal?)req.Block15Original.GetNullValue();
                    parta27011.Block15Modified = (decimal?)req.Block15Modified.GetNullValue();
                    parta27011.FirmCommitmentDate = req.FirmCommitmentDate.GetNullDate();
                    parta27011.ExpDateExtensionToAssign = req.ExpDateExtensionToAssign.GetNullDate();
                    parta27011.ExpDateExtensionToForeclose = req.ExpDateExtensionToForeclose.GetNullDate();
                    parta27011.DateOfExtensionToConvey = req.DateOfExtensionToConvey.GetNullDate();
                    parta27011.DateOfNoticeToConvey = req.DateOfNoticeToConvey.GetNullDate();
                    parta27011.ReleaseOfBankruptcyDate = req.ReleaseOfBankruptcyDate.GetNullDate();
                    parta27011.OccupancyStatusId = req.OccupancyStatusId.GetNullValue();
                    parta27011.DateLocalOfficeApprovalConveyanceDamaged = req.DateLocalOfficeApprovalConveyanceDamaged.GetNullDate();
                    parta27011.DateLocalOfficeApprovalConveyanceOccupied = req.DateLocalOfficeApprovalConveyanceOccupied.GetNullDate();
                    parta27011.DateLocalOfficeCertificationConveyanceDamaged = req.DateLocalOfficeCertificationConveyanceDamaged.GetNullDate();
                    parta27011.PropertyConditionId = req.PropertyConditionId.GetNullValue();
                    parta27011.DamageTypeId = req.DamageTypeId.GetNullValue();
                    parta27011.InsuranceRecovery = (decimal?)req.InsuranceRecovery.GetNullValue();
                    parta27011.DateDamaged = req.DateDamaged.GetNullDate();
                    parta27011.EstimateOfDamage = (decimal?)req.EstimateOfDamage.GetNullValue();
                    parta27011.IsMortgageeSuccessfulBidder = req.IsMortgageeSuccessfulBidder.GetBoolValue();
                    parta27011.DeficiencyJudgementCodeId = req.DeficiencyJudgementCodeId.GetNullValue();
                    parta27011.AuthorizedBidAmount = (decimal?)req.AuthorizedBidAmount.GetNullValue();
                    parta27011.MortgageeReportedCurtailmentDate = req.MortgageeReportedCurtailmentDate.GetNullDate();
                    parta27011.PropertyDescription = req.PropertyDescription.GetSafeString();
                    parta27011.MonthlyFhainsurance = (decimal?)req.MonthlyFhainsurance.GetNullValue();
                    parta27011.MonthlyTaxes = (decimal?)req.MonthlyTaxes.GetNullValue();
                    parta27011.MonthlyHazardInsurance = (decimal?)req.MonthlyHazardInsurance.GetNullValue();
                    parta27011.MonthlyInterestAndPrincipal = (decimal?)req.MonthlyInterestAndPrincipal.GetNullValue();
                    parta27011.BankruptcyDateFiled = req.BankruptcyDateFiled.GetNullDate();
                    parta27011.Block19Date = req.Block19Date.GetNullDate();
                    parta27011.Block20Date = req.Block20Date.GetNullDate();
                    parta27011.HipcancelledDate = req.HipcancelledDate.GetNullDate();
                    parta27011.HiprefusedDate = req.HiprefusedDate.GetNullDate();
                    parta27011.MortgageeComments = req.MortgageeComments;
                    parta27011.NumberOfLivingUnits = req.NumberOfLivingUnits.GetNullValue();

                    ctx.SaveChanges();
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public HUDPartB GetHudPartB(int id)
        {
            var ret = new HUDPartB();
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    ret = ctx.VwHudPartB.Where(x => x.FhaclaimId == id).Select(x => new HUDPartB
                    {
                        PropertyAddress1 = x.PropertyAddress1.GetSafeString(),
                        PropertyAddress2 = x.PropertyAddress2.GetSafeString(),
                        SectionOfTheActId = x.SectionOfTheActId.GetSafeNullValue(),
                        ClaimTypeId = x.ClaimTypeId,
                        FhacaseNumber = x.FhacaseNumber,
                        MortgageeLoanNumber = x.MortgageeLoanNumber.GetSafeString(),
                        PropertyCity = x.PropertyCity.GetSafeString(),
                        PropertyStateCode = x.PropertyStateCode.GetSafeString(),
                        PropertyZipCode = x.PropertyZipCode.GetSafeString(),
                        Block105Date = x.Block105Date.GetSafeDateTimeString(),
                        Block107AAmount = (double)x.Block107aAmount.GetSafeNullValue(),
                        Block107BAmount = (double)x.Block107bAmount.GetSafeNullValue(),
                        Block108AAmount = (double)x.Block108aAmount.GetSafeNullValue(),
                        Block109AAmount = (double)x.Block109aAmount.GetSafeNullValue(),
                        Block110B = (double)x.Block110b.GetSafeNullValue(),
                        Block110C = (double)x.Block110c.GetSafeNullValue(),
                        Block111B = (double)x.Block111b.GetSafeNullValue(),
                        Block111C = (double)x.Block111c.GetSafeNullValue(),
                        Block112B = (double)x.Block112b.GetSafeNullValue(),
                        Block112C = (double)x.Block112c.GetSafeNullValue(),
                        Block113B = (double)x.Block113b.GetSafeNullValue(),
                        Block113C = (double)x.Block113c.GetSafeNullValue(),
                        Block114B = (double)x.Block114b.GetSafeNullValue(),
                        Block114C = (double)x.Block114c.GetSafeNullValue(),
                        Block115AAmount = (double)x.Block115aAmount.GetSafeNullValue(),
                        Block116BAmount = (double)x.Block116bAmount.GetSafeNullValue(),
                        Block117B = (double)x.Block117b.GetSafeNullValue(),
                        Block117C = (double)x.Block117c.GetSafeNullValue(),
                        Block118AAmount = (double)x.Block118aAmount.GetSafeNullValue(),
                        Block119AAmount = (double)x.Block119aAmount.GetSafeNullValue(),
                        Block119BAmount = (double)x.Block119bAmount.GetSafeNullValue(),
                        Block120B = (double)x.Block120b.GetSafeNullValue(),
                        Block120C = (double)x.Block120c.GetSafeNullValue(),
                        Block121Amount = (double)x.Block121Amount.GetSafeNullValue(),
                        Block122B = (double)x.Block122b.GetSafeNullValue(),
                        Block122C = (double)x.Block122c.GetSafeNullValue(),
                        Block123AAmount = (double)x.Block123aAmount.GetSafeNullValue(),
                        Block123BAmount = (double)x.Block123bAmount.GetSafeNullValue(),
                        Block123CAmount = (double)x.Block123cAmount.GetSafeNullValue(),
                        Block124AAmount = (double)x.Block124aAmount.GetSafeNullValue(),
                        Block124BAmount = (double)x.Block124bAmount.GetSafeNullValue(),
                        Block124CAmount = (double)x.Block124cAmount.GetSafeNullValue(),
                        Block125B = (double)x.Block125b.GetSafeNullValue(),
                        Block125C = (double)x.Block125c.GetSafeNullValue(),
                        Block126CAmount = (double)x.Block126cAmount.GetSafeNullValue(),
                        Block127A = (double)x.Block127a.GetSafeNullValue(),
                        Block128B = (double)x.Block128b.GetSafeNullValue(),
                        Block129B = (double)x.Block129b.GetSafeNullValue(),
                        CurtailmentDateFromAop = x.CurtailmentDateFromAop.GetSafeDateTimeString(),
                        SectionOfAct = x.SectionOfAct.GetSafeString(),
                        Wksheet119L1Amount = (double)x.Wksheet119L1amount.GetSafeNullValue(),
                        Wksheet119L2Amount = (double)x.Wksheet119L2amount.GetSafeNullValue(),
                        Wksheet119L3Amount = (double)x.Wksheet119L3amount.GetSafeNullValue(),
                        Wksheet121FromDate = x.Wksheet121FromDate.GetSafeDateTimeString(),
                        Wksheet121Rate = (double)x.Wksheet121Rate.GetSafeNullValue(),
                        Wksheet121ToDate = x.Wksheet121ToDate.GetSafeDateTimeString(),
                        DateFormPrepared = x.DateFormPrepared.GetSafeDateTimeString(),
                        ExpDateToSubmitTitleEvidence = x.ExpDateToSubmitTitleEvidence.GetSafeDateTimeString(),
                        ExpOfExtToSubmitFiscalData = x.ExpOfExtToSubmitFiscalData.GetSafeDateTimeString(),
                        IsSupplemental = x.IsSupplemental ?? false ? 1 : 0,
                        MortgagorFirstName = x.MortgagorFirstName.GetSafeString(),
                        MortgagorLastName = x.MortgagorLastName.GetSafeString(),
                        MortgagorMiddleName = x.MortgagorMiddleName.GetSafeString(),
                        AppraisalFeeAfromPtE130 = x._130appraisalFeeAfromPtE.GetSafeValue(),
                        NetclaimAmount137 = (double)x._137netclaimAmount.GetSafeNullValue(),
                        TotalAdditions135 = (double)x._135totalAdditions.GetSafeNullValue(),
                        TotalDeductions134 = (double)x._134totalDeductions.GetSafeNullValue(),
                        TotalInterest136 = (double)x._136totalInterest.GetSafeNullValue(),
                        Block105TypeId = x.Block105TypeId.GetSafeNullValue(),
                        Block108TypeId = x.Block108TypeId.GetSafeNullValue(),
                        Block130B = (double)x.Block130b.GetSafeNullValue(),
                        Block130C = (double)x.Block130c.GetSafeNullValue(),
                        Block131B = (double)x.Block131b.GetSafeNullValue(),
                        Block131C = (double)x.Block131c.GetSafeNullValue(),
                        Block132AAmount = (double)x.Block132aAmount.GetSafeNullValue(),
                        Block132BAmount = (double)x.Block132bAmount.GetSafeNullValue(),
                        Block132CAmount = (double)x.Block132cAmount.GetSafeNullValue(),
                        Block132Description = x.Block132Description.GetSafeString(),
                        PartB27011Id = x.PartB27011id,
                        DeficiencyAfromPtE131 = x._131deficiencyAfromPtE.GetSafeValue(),
                        ClaimTypeText = x.ClaimTypeText.GetSafeString(),
                        ClientName = x.ClientName.GetSafeString(),
                        SectionOfActCode = x.SectionOfActCode.GetSafeString(),
                        ServicerId = x.ServicerId.GetSafeNullValue(),
                        ServicerName = x.ServicerName.GetSafeString(),
                        FhaclaimId = x.FhaclaimId,
                        FhaclientId = x.FhaclientId.GetSafeValue(),
                        FhaloanId = x.FhaloanId,
                        MortgageeId = x.MortgageeId.GetSafeNullValue(),
                        MortgageeName = x.MortgageeName.GetSafeString()
                    }).Single();

                    ret.CheckSum = ret.GetHashCode().ToString();
                }
                return ret;
            }
            catch
            {
                throw;
            }
        }
        public MessageReply SaveHudPartB(HUDPartB req)
        {
            var ret = new MessageReply { Message = Constant.Success };
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    var temp = ctx.VwHudPartB.Where(x => x.FhaclaimId == req.FhaclaimId).Select(x => new HUDPartB
                    {
                        PropertyAddress1 = x.PropertyAddress1.GetSafeString(),
                        PropertyAddress2 = x.PropertyAddress2.GetSafeString(),
                        SectionOfTheActId = x.SectionOfTheActId.GetSafeNullValue(),
                        ClaimTypeId = x.ClaimTypeId,
                        FhacaseNumber = x.FhacaseNumber,
                        MortgageeLoanNumber = x.MortgageeLoanNumber.GetSafeString(),
                        PropertyCity = x.PropertyCity.GetSafeString(),
                        PropertyStateCode = x.PropertyStateCode.GetSafeString(),
                        PropertyZipCode = x.PropertyZipCode.GetSafeString(),
                        Block105Date = x.Block105Date.GetSafeDateTimeString(),
                        Block107AAmount = (double)x.Block107aAmount.GetSafeNullValue(),
                        Block107BAmount = (double)x.Block107bAmount.GetSafeNullValue(),
                        Block108AAmount = (double)x.Block108aAmount.GetSafeNullValue(),
                        Block109AAmount = (double)x.Block109aAmount.GetSafeNullValue(),
                        Block110B = (double)x.Block110b.GetSafeNullValue(),
                        Block110C = (double)x.Block110c.GetSafeNullValue(),
                        Block111B = (double)x.Block111b.GetSafeNullValue(),
                        Block111C = (double)x.Block111c.GetSafeNullValue(),
                        Block112B = (double)x.Block112b.GetSafeNullValue(),
                        Block112C = (double)x.Block112c.GetSafeNullValue(),
                        Block113B = (double)x.Block113b.GetSafeNullValue(),
                        Block113C = (double)x.Block113c.GetSafeNullValue(),
                        Block114B = (double)x.Block114b.GetSafeNullValue(),
                        Block114C = (double)x.Block114c.GetSafeNullValue(),
                        Block115AAmount = (double)x.Block115aAmount.GetSafeNullValue(),
                        Block116BAmount = (double)x.Block116bAmount.GetSafeNullValue(),
                        Block117B = (double)x.Block117b.GetSafeNullValue(),
                        Block117C = (double)x.Block117c.GetSafeNullValue(),
                        Block118AAmount = (double)x.Block118aAmount.GetSafeNullValue(),
                        Block119AAmount = (double)x.Block119aAmount.GetSafeNullValue(),
                        Block119BAmount = (double)x.Block119bAmount.GetSafeNullValue(),
                        Block120B = (double)x.Block120b.GetSafeNullValue(),
                        Block120C = (double)x.Block120c.GetSafeNullValue(),
                        Block121Amount = (double)x.Block121Amount.GetSafeNullValue(),
                        Block122B = (double)x.Block122b.GetSafeNullValue(),
                        Block122C = (double)x.Block122c.GetSafeNullValue(),
                        Block123AAmount = (double)x.Block123aAmount.GetSafeNullValue(),
                        Block123BAmount = (double)x.Block123bAmount.GetSafeNullValue(),
                        Block123CAmount = (double)x.Block123cAmount.GetSafeNullValue(),
                        Block124AAmount = (double)x.Block124aAmount.GetSafeNullValue(),
                        Block124BAmount = (double)x.Block124bAmount.GetSafeNullValue(),
                        Block124CAmount = (double)x.Block124cAmount.GetSafeNullValue(),
                        Block125B = (double)x.Block125b.GetSafeNullValue(),
                        Block125C = (double)x.Block125c.GetSafeNullValue(),
                        Block126CAmount = (double)x.Block126cAmount.GetSafeNullValue(),
                        Block127A = (double)x.Block127a.GetSafeNullValue(),
                        Block128B = (double)x.Block128b.GetSafeNullValue(),
                        Block129B = (double)x.Block129b.GetSafeNullValue(),
                        CurtailmentDateFromAop = x.CurtailmentDateFromAop.GetSafeDateTimeString(),
                        SectionOfAct = x.SectionOfAct.GetSafeString(),
                        Wksheet119L1Amount = (double)x.Wksheet119L1amount.GetSafeNullValue(),
                        Wksheet119L2Amount = (double)x.Wksheet119L2amount.GetSafeNullValue(),
                        Wksheet119L3Amount = (double)x.Wksheet119L3amount.GetSafeNullValue(),
                        Wksheet121FromDate = x.Wksheet121FromDate.GetSafeDateTimeString(),
                        Wksheet121Rate = (double)x.Wksheet121Rate.GetSafeNullValue(),
                        Wksheet121ToDate = x.Wksheet121ToDate.GetSafeDateTimeString(),
                        DateFormPrepared = x.DateFormPrepared.GetSafeDateTimeString(),
                        ExpDateToSubmitTitleEvidence = x.ExpDateToSubmitTitleEvidence.GetSafeDateTimeString(),
                        ExpOfExtToSubmitFiscalData = x.ExpOfExtToSubmitFiscalData.GetSafeDateTimeString(),
                        IsSupplemental = x.IsSupplemental ?? false ? 1 : 0,
                        MortgagorFirstName = x.MortgagorFirstName.GetSafeString(),
                        MortgagorLastName = x.MortgagorLastName.GetSafeString(),
                        MortgagorMiddleName = x.MortgagorMiddleName.GetSafeString(),
                        AppraisalFeeAfromPtE130 = x._130appraisalFeeAfromPtE.GetSafeValue(),
                        NetclaimAmount137 = (double)x._137netclaimAmount.GetSafeNullValue(),
                        TotalAdditions135 = (double)x._135totalAdditions.GetSafeNullValue(),
                        TotalDeductions134 = (double)x._134totalDeductions.GetSafeNullValue(),
                        TotalInterest136 = (double)x._136totalInterest.GetSafeNullValue(),
                        Block105TypeId = x.Block105TypeId.GetSafeNullValue(),
                        Block108TypeId = x.Block108TypeId.GetSafeNullValue(),
                        Block130B = (double)x.Block130b.GetSafeNullValue(),
                        Block130C = (double)x.Block130c.GetSafeNullValue(),
                        Block131B = (double)x.Block131b.GetSafeNullValue(),
                        Block131C = (double)x.Block131c.GetSafeNullValue(),
                        Block132AAmount = (double)x.Block132aAmount.GetSafeNullValue(),
                        Block132BAmount = (double)x.Block132bAmount.GetSafeNullValue(),
                        Block132CAmount = (double)x.Block132cAmount.GetSafeNullValue(),
                        Block132Description = x.Block132Description.GetSafeString(),
                        PartB27011Id = x.PartB27011id,
                        DeficiencyAfromPtE131 = x._131deficiencyAfromPtE.GetSafeValue(),
                        ClaimTypeText = x.ClaimTypeText.GetSafeString(),
                        ClientName = x.ClientName.GetSafeString(),
                        SectionOfActCode = x.SectionOfActCode.GetSafeString(),
                        ServicerId = x.ServicerId.GetSafeNullValue(),
                        ServicerName = x.ServicerName.GetSafeString(),
                        FhaclaimId = x.FhaclaimId,
                        FhaclientId = x.FhaclientId.GetSafeValue(),
                        FhaloanId = x.FhaloanId,
                        MortgageeId = x.MortgageeId.GetSafeNullValue(),
                        MortgageeName = x.MortgageeName.GetSafeString()
                    }).Single();

                    if (req.CheckSum != temp.GetHashCode().ToString())
                        throw new Exception("The record was altered by another session during editing");

                    var partb27011 = ctx.TblPartB27011.Single(x => x.FhaclaimId == req.FhaclaimId);
                    partb27011.DateFormPrepared = req.DateFormPrepared.GetNullDate();
                    partb27011.ExpDateToSubmitTitleEvidence = req.ExpDateToSubmitTitleEvidence.GetNullDate();
                    partb27011.ExpOfExtToSubmitFiscalData = req.ExpOfExtToSubmitFiscalData.GetNullDate();
                    partb27011.Block105Date = req.Block105Date.GetNullDate();
                    partb27011.Block105TypeId = req.Block105TypeId.GetNullValue();
                    partb27011.IsSupplemental = req.IsSupplemental.GetBoolValue();
                    partb27011.Block107aAmount = (decimal?)req.Block107AAmount.GetNullValue();
                    partb27011.Block107bAmount = (decimal?)req.Block107BAmount.GetNullValue();
                    partb27011.Block108TypeId = req.Block108TypeId.GetNullValue();
                    partb27011.Block108aAmount = (decimal?)req.Block108AAmount.GetNullValue();
                    partb27011.Block109aAmount = (decimal?)req.Block109AAmount.GetNullValue();
                    partb27011.Block115aAmount = (decimal?)req.Block109AAmount.GetNullValue();
                    partb27011.Block116bAmount = (decimal?)req.Block116BAmount.GetNullValue();
                    partb27011.Block118aAmount = (decimal?)req.Block118AAmount.GetNullValue();
                    partb27011.Block119aAmount = (decimal?)req.Block119AAmount.GetNullValue();
                    partb27011.Block119bAmount = (decimal?)req.Block119BAmount.GetNullValue();
                    partb27011.Wksheet119L1amount = (decimal?)req.Wksheet119L1Amount.GetNullValue();
                    partb27011.Wksheet119L2amount = (decimal?)req.Wksheet119L2Amount.GetNullValue();
                    partb27011.Wksheet119L3amount = (decimal?)req.Wksheet119L3Amount.GetNullValue();
                    partb27011.Wksheet121FromDate = req.Wksheet121FromDate.GetNullDate();
                    partb27011.Wksheet121Rate = (decimal?)req.Wksheet121Rate.GetNullValue();
                    partb27011.Wksheet121ToDate = req.Wksheet121ToDate.GetNullDate();
                    partb27011.Block121Amount = (decimal?)req.Block121Amount.GetNullValue();
                    partb27011.Block123aAmount = (decimal?)req.Block123AAmount.GetNullValue();
                    partb27011.Block123bAmount = (decimal?)req.Block123BAmount.GetNullValue();
                    partb27011.Block123cAmount = (decimal?)req.Block123CAmount.GetNullValue();
                    partb27011.Block124aAmount = (decimal?)req.Block124AAmount.GetNullValue();
                    partb27011.Block124bAmount = (decimal?)req.Block124BAmount.GetNullValue();
                    partb27011.Block124cAmount = (decimal?)req.Block124CAmount.GetNullValue();
                    partb27011.Block126cAmount = (decimal?)req.Block126CAmount.GetNullValue();
                    partb27011.Block132Description = req.Block132Description.GetSafeString();
                    partb27011.Block132aAmount = (decimal?)req.Block132AAmount.GetNullValue();
                    partb27011.Block132bAmount = (decimal?)req.Block132BAmount.GetNullValue();
                    partb27011.Block132cAmount = (decimal?)req.Block132CAmount.GetNullValue();
                    partb27011.LastUpdateDate = DateTime.Now;
                    partb27011.LastUpdateUser = _userid;

                    ctx.SaveChanges();
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public HUDPartC GetHudPartC(int id)
        {
            var ret = new HUDPartC();
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    ret = ctx.VwHudPartC.Where(x => x.FhaclaimId == id).Select(x => new HUDPartC
                    {
                        FhaclaimId = x.FhaclaimId,
                        DateFormPrepared = x.DateFormPrepared.GetSafeDateTimeString(),
                        MortgageeComments = x.MortgageeComments.GetSafeString(),
                        PartC27011Id = x.PartC27011id
                    }).Single();

                    ret.CheckSum = ret.GetHashCode().ToString();
                }
                return ret;
            }
            catch
            {
                throw;
            }
        }
        public MessageReply SaveHudPartC(HUDPartC req)
        {
            var ret = new MessageReply { Message = Constant.Success };
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    var temp = ctx.VwHudPartC.Where(x => x.FhaclaimId == req.FhaclaimId).Select(x => new HUDPartC
                    {
                        FhaclaimId = x.FhaclaimId,
                        DateFormPrepared = x.DateFormPrepared.GetSafeDateTimeString(),
                        MortgageeComments = x.MortgageeComments.GetSafeString(),
                        PartC27011Id = x.PartC27011id
                    }).Single();

                    if (req.CheckSum != temp.GetHashCode().ToString())
                        throw new Exception("The record was altered by another session during editing");

                    var partc27011 = ctx.TblPartC27011.Single(x => x.FhaclaimId == req.FhaclaimId);


                    partc27011.LastUpdateDate = DateTime.Now;
                    partc27011.LastUpdateUser = _userid;
                    partc27011.DateFormPrepared = req.DateFormPrepared.GetNullDate();
                    partc27011.MortgageeComments = req.MortgageeComments.GetSafeString();

                    ctx.SaveChanges();
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public HUDPartD GetHudPartD(int id)
        {
            var ret = new HUDPartD();
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    ret = ctx.VwHudPartD.Where(x => x.FhaclaimId == id).Select(x => new HUDPartD
                    {
                        FhaclaimId = x.FhaclaimId,
                        PartD27011Id = x.PartD27011id,
                        DateFormPrepared = x.DateFormPrepared.GetSafeDateTimeString()
                    }).Single();

                    ret.CheckSum = ret.GetHashCode().ToString();
                }
                return ret;
            }
            catch
            {
                throw;
            }
        }
        public MessageReply SaveHudPartD(HUDPartD req)
        {
            var ret = new MessageReply { Message = Constant.Success };
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    var temp = ctx.VwHudPartD.Where(x => x.FhaclaimId == req.FhaclaimId).Select(x => new HUDPartD
                    {
                        FhaclaimId = x.FhaclaimId,
                        PartD27011Id = x.PartD27011id,
                        DateFormPrepared = x.DateFormPrepared.GetSafeDateTimeString()
                    }).Single();

                    if (req.CheckSum != temp.GetHashCode().ToString())
                        throw new Exception("The record was altered by another session during editing");

                    var partd27011 = ctx.TblPartD27011.Single(x => x.FhaclaimId == req.FhaclaimId);
                    partd27011.LastUpdateDate = DateTime.Now;
                    partd27011.LastUpdateUser = _userid;
                    partd27011.DateFormPrepared = req.DateFormPrepared.GetNullDate();

                    ctx.SaveChanges();
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public HUDPartE GetHudPartE(int id)
        {
            var ret = new HUDPartE();
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    ret = ctx.VwHudPartE.Where(x => x.FhaclaimId == id).Select(x => new HUDPartE
                    {
                        DateFormPrepared = x.DateFormPrepared.GetSafeDateTimeString(),
                        PartE27011Id = x.PartE27011id,
                        FhaclaimId = x.FhaclaimId
                    }).Single();

                    ret.CheckSum = ret.GetHashCode().ToString();
                }
                return ret;
            }
            catch
            {
                throw;
            }
        }
        public MessageReply SaveHudPartE(HUDPartE req)
        {
            var ret = new MessageReply { Message = Constant.Success };
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    var temp = ctx.VwHudPartE.Where(x => x.FhaclaimId == req.FhaclaimId).Select(x => new HUDPartE
                    {
                        DateFormPrepared = x.DateFormPrepared.GetSafeDateTimeString(),
                        PartE27011Id = x.PartE27011id,
                        FhaclaimId = x.FhaclaimId
                    }).Single();

                    if (req.CheckSum != temp.GetHashCode().ToString())
                        throw new Exception("The record was altered by another session during editing");

                   
                    var parte27011 = ctx.TblPartE27011.Single(x => x.FhaclaimId == req.FhaclaimId);

                    parte27011.LastUpdateDate = DateTime.Now;
                    parte27011.LastUpdateUser = _userid;
                    parte27011.DateFormPrepared = req.DateFormPrepared.GetNullDate();
                  
                    ctx.SaveChanges();
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public GetFHAMortgagorsReply GetMortgagors(int id)
        {
            var ret = new GetFHAMortgagorsReply();

            try
            {
                using(var ctx = new HUDClaimsContext())
                {
                    var temp = ctx.TblFhamortgagors.Where(x => x.FhaloanId == id).Select(x => new FHAMortgagor
                    {
                        Id = x.MortgagorId,
                        CoMortgagor = x.CoMortgagor ? 1 : 0,
                        FhaloanId = x.FhaloanId,
                        MortgagorFirstName = x.MortgagorFirstName.GetSafeString(),
                        MortgagorLastName = x.MortgagorLastName.GetSafeString(),
                        MortgagorMiddleName = x.MortgagorMiddleName.GetSafeString(),
                        NonPersonEntity = x.NonPersonEntity ?? false ? 1 : 0,
                        Prefix = x.Prefix.GetSafeString(),
                        Ssn = x.Ssn.GetSafeString(),
                        Suffix = x.Suffix.GetSafeString(),
                        UIAct = ""
                    }).ToList();
                    foreach(var t in temp)
                    {
                        t.CheckSum = t.GetHashCode().ToString();
                    }
                    ret.FHAMortgagors.AddRange(temp);
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveMortgagor(FHAMortgagor req)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    if (req.Id > 0)
                    {
                        var temp = ctx.TblFhamortgagors.Where(x => x.MortgagorId == req.Id).Select(x => new FHAMortgagor
                        {
                            Id = x.MortgagorId,
                            CoMortgagor = x.CoMortgagor ? 1 : 0,
                            FhaloanId = x.FhaloanId,
                            MortgagorFirstName = x.MortgagorFirstName.GetSafeString(),
                            MortgagorLastName = x.MortgagorLastName.GetSafeString(),
                            MortgagorMiddleName = x.MortgagorMiddleName.GetSafeString(),
                            NonPersonEntity = x.NonPersonEntity ?? false ? 1 : 0,
                            Prefix = x.Prefix.GetSafeString(),
                            Ssn = x.Ssn.GetSafeString(),
                            Suffix = x.Suffix.GetSafeString(),
                            UIAct = ""
                        }).Single();
                                               
                        if (req.CheckSum != temp.GetHashCode().ToString())
                            throw new Exception("The record was altered by another session during editing");

                        var temp1 = ctx.TblFhamortgagors.Single(x => x.MortgagorId == req.Id);

                        if(req.UIAct == "Delete")
                        {
                            ctx.TblFhamortgagors.Remove(temp1);
                        } else
                        {
                            temp1.CoMortgagor = req.CoMortgagor == 1;
                            temp1.MortgagorFirstName = req.MortgagorFirstName;
                            temp1.MortgagorLastName = req.MortgagorLastName;
                            temp1.MortgagorMiddleName = req.MortgagorMiddleName;
                            temp1.NonPersonEntity = req.NonPersonEntity.GetBoolValue();
                            temp1.Prefix = req.Prefix;
                            temp1.Ssn = req.Ssn;
                            temp1.Suffix = req.Suffix;
                            temp1.LastUpdateDate = DateTime.Now;
                            temp1.LastUpdateUser = _userid;
                        }
                        ctx.SaveChanges();
                    } else
                    {
                        ctx.TblFhamortgagors.Add(new TblFhamortgagors { 
                            FhaloanId = req.FhaloanId,
                            MortgagorId = 0,
                            EnteredByUser = _userid,
                            EnteredDate = DateTime.Now,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUser = _userid,
                            CoMortgagor = req.CoMortgagor == 1,
                            MortgagorFirstName = req.MortgagorFirstName,
                            MortgagorLastName = req.MortgagorLastName,
                            MortgagorMiddleName = req.MortgagorMiddleName,
                            Prefix = req.Prefix,
                            Ssn = req.Ssn,
                            Suffix = req.Suffix,
                            NonPersonEntity = req.NonPersonEntity.GetBoolValue()
                        });
                        ctx.SaveChanges();
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public GetFHALivingUnitsReply GetLivingUnits(int id)
        {
            var ret = new GetFHALivingUnitsReply();

            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    var temp = ctx.TblFhalivingUnits.Where(x => x.PartA27011id == id).Select(x => new FHALivingUnit
                    {
                        Id = x.LivingUnitId,
                        DateSecured = x.DateSecured.GetSafeDateTimeString(),
                        PartA27011Id = x.PartA27011id,
                        DateVacated = x.DateVacated.GetSafeDateTimeString(),
                        OccupantName = x.OccupantName.GetSafeString(),
                        Occupied = x.Occupied ?? false ? 1 : 0,
                        UnitNumber = x.UnitNumber.GetSafeValue(),
                        Vacant = x.Vacant ?? false ? 1 : 0,
                        UIAct = ""
                    }).ToList();
                    foreach (var t in temp)
                    {
                        t.CheckSum = t.GetHashCode().ToString();
                    }
                    ret.FHALivingUnits.AddRange(temp);
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveLivingUnit(FHALivingUnit req)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    if (req.Id > 0)
                    {
                        var temp = ctx.TblFhalivingUnits.Where(x => x.LivingUnitId == req.Id).Select(x => new FHALivingUnit
                        {
                            Id = x.LivingUnitId,
                            DateSecured = x.DateSecured.GetSafeDateTimeString(),
                            PartA27011Id = x.PartA27011id,
                            DateVacated = x.DateVacated.GetSafeDateTimeString(),
                            OccupantName = x.OccupantName.GetSafeString(),
                            Occupied = x.Occupied ?? false ? 1 : 0,
                            UnitNumber = x.UnitNumber.GetSafeValue(),
                            Vacant = x.Vacant ?? false ? 1 : 0,
                            UIAct = ""
                        }).Single();

                        if (req.CheckSum != temp.GetHashCode().ToString())
                            throw new Exception("The record was altered by another session during editing");

                        var temp1 = ctx.TblFhalivingUnits.Single(x => x.LivingUnitId == req.Id);

                        if (req.UIAct == "Delete")
                        {
                            ctx.TblFhalivingUnits.Remove(temp1);
                        }
                        else
                        {
                            temp1.DateSecured = req.DateSecured.GetNullDate();
                            temp1.DateVacated = req.DateVacated.GetNullDate();
                            temp1.OccupantName = req.OccupantName;
                            temp1.Occupied = req.Occupied.GetBoolValue();
                            temp1.UnitNumber = req.UnitNumber;
                            temp1.Vacant = req.Vacant.GetBoolValue();

                            temp1.LastUpdateDate = DateTime.Now;
                            temp1.LastUpdateUser = _userid;
                        }
                        ctx.SaveChanges();
                    }
                    else
                    {
                        ctx.TblFhalivingUnits.Add(new TblFhalivingUnits
                        {
                            PartA27011id = req.PartA27011Id,
                            LivingUnitId = 0,
                            EnteredByUser = _userid,
                            EnteredDate = DateTime.Now,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUser = _userid,
                            DateSecured = req.DateSecured.GetNullDate(),
                            DateVacated = req.DateVacated.GetNullDate(),
                            OccupantName = req.OccupantName,
                            Occupied = req.Occupied.GetBoolValue(),
                            Vacant = req.Vacant.GetBoolValue(),
                            UnitNumber = req.UnitNumber
                        });
                        ctx.SaveChanges();
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public GetFHATaxSchedulesReply GetTaxSchedules(int id)
        {
            var ret = new GetFHATaxSchedulesReply();

            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    var temp = ctx.TblFhaTaxSchedule.Where(x => x.PartA27011id == id).Select(x => new FHATaxSchedule
                    {
                        Id = x.TaxScheduleId,
                        CollectorPropertyIdentification = x.CollectorPropertyIdentification.GetSafeString(),
                        AmountPaid = (double)x.AmountPaid.GetSafeZeroValue(),
                        PartA27011Id = x.PartA27011id,
                        DatePaid = x.DatePaid.GetSafeDateTimeString(),
                        EndDate = x.EndDate.GetSafeDateTimeString(),
                        StartDate = x.StartDate.GetSafeDateTimeString(),
                        TaxType = x.TaxType.GetSafeString(),
                        TaxYear = x.TaxYear.GetSafeValue(),
                        UIAct = ""
                    }).ToList();
                    foreach (var t in temp)
                    {
                        t.CheckSum = t.GetHashCode().ToString();
                    }
                    ret.FHATaxSchedules.AddRange(temp);
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveTaxSchedule(FHATaxSchedule req)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    if (req.Id > 0)
                    {
                        var temp = ctx.TblFhaTaxSchedule.Where(x => x.TaxScheduleId == req.Id).Select(x => new FHATaxSchedule
                        {
                            Id = x.TaxScheduleId,
                            CollectorPropertyIdentification = x.CollectorPropertyIdentification.GetSafeString(),
                            AmountPaid = (double)x.AmountPaid.GetSafeZeroValue(),
                            PartA27011Id = x.PartA27011id,
                            DatePaid = x.DatePaid.GetSafeDateTimeString(),
                            EndDate = x.EndDate.GetSafeDateTimeString(),
                            StartDate = x.StartDate.GetSafeDateTimeString(),
                            TaxType = x.TaxType.GetSafeString(),
                            TaxYear = x.TaxYear.GetSafeValue(),
                            UIAct = ""
                        }).Single();

                        if (req.CheckSum != temp.GetHashCode().ToString())
                            throw new Exception("The record was altered by another session during editing");

                        var temp1 = ctx.TblFhaTaxSchedule.Single(x => x.TaxScheduleId == req.Id);

                        if (req.UIAct == "Delete")
                        {
                            ctx.TblFhaTaxSchedule.Remove(temp1);
                        }
                        else
                        {
                            temp1.EndDate = req.EndDate.GetNullDate();
                            temp1.StartDate = req.StartDate.GetNullDate();
                            temp1.CollectorPropertyIdentification = req.CollectorPropertyIdentification;
                            temp1.AmountPaid = (decimal?)req.AmountPaid.GetNullValue();
                            temp1.DatePaid = req.DatePaid.GetNullDate();
                            temp1.TaxType = req.TaxType;
                            temp1.TaxYear = req.TaxYear;
                            temp1.LastUpdateDate = DateTime.Now;
                            temp1.LastUpdateUser = _userid;
                        }
                        ctx.SaveChanges();
                    }
                    else
                    {
                        ctx.TblFhaTaxSchedule.Add(new TblFhaTaxSchedule
                        {
                            PartA27011id = req.PartA27011Id,
                            TaxScheduleId = 0,
                            EnteredByUser = _userid,
                            EnteredDate = DateTime.Now,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUser = _userid,
                            AmountPaid = (decimal?)req.AmountPaid.GetNullValue(),
                            CollectorPropertyIdentification = req.CollectorPropertyIdentification,
                            DatePaid = req.DatePaid.GetNullDate(),
                            EndDate = req.EndDate.GetNullDate(),
                            StartDate = req.StartDate.GetNullDate(),
                            TaxType = req.TaxType,
                            TaxYear = req.TaxYear
                        });
                        ctx.SaveChanges();
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public GetFHAPartC27011ProtectionPreservationDisbursementsReply GetProtectionPreservationDisbursements(int id)
        {
            var ret = new GetFHAPartC27011ProtectionPreservationDisbursementsReply();

            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    var temp = ctx.VwFhaProtectionPreservationDisbursements.Where(x => x.PartC27011id == id).Select(x => new FHAPartC27011ProtectionPreservationDisbursement
                    {
                        Id = x.ProtectionPreservationDisbursementId,
                        ActualSqFt = x.ActualSqFt.GetSafeZeroValue(),
                        AmountPaid = (double)x.AmountPaid.GetNullValue(),
                        CostEstimator = x.CostEstimator ?? false ? 1 : 0,
                        DatePaid = x.DatePaid.GetSafeDateTimeString(),
                        DateWorkCompleted = x.DateWorkCompleted.GetSafeDateTimeString(),
                        DebentureInterest = (double)x.DebentureInterest.GetSafeZeroValue(),
                        DescriptionOfServicesPerformed = x.DescriptionOfServicesPerformed.GetSafeString(),
                        Hudapproved = x.Hudapproved ?? false ? 1 : 0,
                        PartC27011Id = x.PartC27011id,
                        Quantity = x.Quantity.GetSafeZeroValue(),
                        UIAct = ""
                    }).ToList();
                    foreach (var t in temp)
                    {
                        t.CheckSum = t.GetHashCode().ToString();
                    }
                    ret.FHAPartC27011ProtectionPreservationDisbursements.AddRange(temp);
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveProtectionPreservationDisbursement(FHAPartC27011ProtectionPreservationDisbursement req)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    if (req.Id > 0)
                    {
                        var temp = ctx.VwFhaProtectionPreservationDisbursements.Where(x => x.ProtectionPreservationDisbursementId == req.Id).
                            Select(x => new FHAPartC27011ProtectionPreservationDisbursement
                        {
                            Id = x.ProtectionPreservationDisbursementId,
                            ActualSqFt = x.ActualSqFt.GetSafeZeroValue(),
                            AmountPaid = (double)x.AmountPaid.GetNullValue(),
                            CostEstimator = x.CostEstimator ?? false ? 1 : 0,
                            DatePaid = x.DatePaid.GetSafeDateTimeString(),
                            DateWorkCompleted = x.DateWorkCompleted.GetSafeDateTimeString(),
                            DebentureInterest = (double)x.DebentureInterest.GetSafeZeroValue(),
                            DescriptionOfServicesPerformed = x.DescriptionOfServicesPerformed.GetSafeString(),
                            Hudapproved = x.Hudapproved ?? false ? 1 : 0,
                            PartC27011Id = x.PartC27011id,
                            Quantity = x.Quantity.GetSafeZeroValue(),
                            UIAct = ""
                        }).Single();

                        if (req.CheckSum != temp.GetHashCode().ToString())
                            throw new Exception("The record was altered by another session during editing");

                        var temp1 = ctx.TblProtectionPreservationDisbursements.Single(x => x.ProtectionPreservationDisbursementId == req.Id);

                        if (req.UIAct == "Delete")
                        {
                            ctx.TblProtectionPreservationDisbursements.Remove(temp1);
                        }
                        else
                        {
                            temp1.AmountPaid = (decimal)req.AmountPaid.GetNullValue();
                            temp1.DatePaid = (DateTime)req.DatePaid.GetNullDate();
                            temp1.DateWorkCompleted = Convert.ToDateTime(req.DateWorkCompleted);
                            temp1.DebentureInterest = (decimal?)req.DebentureInterest.GetNullValue();
                            temp1.DescriptionOfServicesPerformed = req.DescriptionOfServicesPerformed;
                            temp1.ActualSqFt = req.ActualSqFt.GetNullValue();
                            temp1.CostEstimator = req.CostEstimator.GetBoolValue();
                            temp1.Hudapproved = req.Hudapproved.GetBoolValue();
                            temp1.Quantity = req.Quantity.GetNullValue();
                            temp1.LastUpdateDate = DateTime.Now;
                            temp1.LastUpdateUser = _userid;
                        }
                        ctx.SaveChanges();
                    }
                    else
                    {
                        ctx.TblProtectionPreservationDisbursements.Add(new TblProtectionPreservationDisbursements
                        {
                            PartC27011id = req.PartC27011Id,
                            EnteredByUser = _userid,
                            EnteredDate = DateTime.Now,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUser = _userid,
                            AmountPaid = (decimal)req.AmountPaid.GetNullValue(),
                            DatePaid = Convert.ToDateTime(req.DatePaid),
                            ActualSqFt = req.ActualSqFt.GetNullValue(),
                            CostEstimator = req.CostEstimator.GetBoolValue(),
                            DateWorkCompleted = Convert.ToDateTime(req.DateWorkCompleted),
                            DebentureInterest = (decimal?)req.DebentureInterest.GetNullValue(),
                            DescriptionOfServicesPerformed = req.DescriptionOfServicesPerformed,
                            ProtectionPreservationDisbursementId = 0,
                            Hudapproved = req.Hudapproved.GetBoolValue(),
                            Quantity = req.Quantity.GetNullValue()
                        });
                        
                        ctx.SaveChanges();
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public GetFHABlock305sReply GetBlock305s(int id)
        {
            var ret = new GetFHABlock305sReply();

            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    var temp = ctx.VwFhaBlock305.Where(x => x.PartD27011id == id).Select(x => new FHABlock305
                    {
                        ActualSqFt = x.ActualSqFt.GetSafeZeroValue(),
                        AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                        Block305Id = x.Block305Id,
                        ClaimTypeId = x.ClaimTypeId,
                        CostEstimator = x.CostEstimator ?? false ? 1 : 0,
                        CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                        DatePaid = x.DatePaid.GetSafeDateTimeString(),
                        DebentureInterest = (double)x.DebentureInterest.GetSafeZeroValue(),
                        DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeZeroValue(),
                        DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeZeroValue(),
                        Description = x.Description.GetSafeString(),
                        FormDescription = x.FormDescription.GetSafeString(),
                        Form27011BlockId = x.Form27011BlockId,
                        UseDefaultDateForCalc = x.UseDefaultDateForCalc.GetSafeValue(),
                        Hudapproved = x.Hudapproved ?? false ? 1 : 0,
                        PartD27011Id = x.PartD27011id,
                        Quantity = x.Quantity.GetSafeZeroValue(),
                        UIAct = ""
                    }).ToList();
                    foreach (var t in temp)
                    {
                        t.CheckSum = t.GetHashCode().ToString();
                    }
                    ret.FHABlock305S.AddRange(temp);
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveBlock305(FHABlock305 req)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    if (req.Block305Id > 0)
                    {
                        var temp = ctx.VwFhaBlock305.Where(x => x.Block305Id == req.Block305Id).Select(x => new FHABlock305
                        {
                            ActualSqFt = x.ActualSqFt.GetSafeZeroValue(),
                            AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                            Block305Id = x.Block305Id,
                            ClaimTypeId = x.ClaimTypeId,
                            CostEstimator = x.CostEstimator ?? false ? 1 : 0,
                            CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                            DatePaid = x.DatePaid.GetSafeDateTimeString(),
                            DebentureInterest = (double)x.DebentureInterest.GetSafeZeroValue(),
                            DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeZeroValue(),
                            DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeZeroValue(),
                            Description = x.Description.GetSafeString(),
                            FormDescription = x.FormDescription.GetSafeString(),
                            Form27011BlockId = x.Form27011BlockId,
                            UseDefaultDateForCalc = x.UseDefaultDateForCalc.GetSafeValue(),
                            Hudapproved = x.Hudapproved ?? false ? 1 : 0,
                            PartD27011Id = x.PartD27011id,
                            Quantity = x.Quantity.GetSafeZeroValue(),
                            UIAct = ""
                        }).ToList();

                        if (req.CheckSum != temp.GetHashCode().ToString())
                            throw new Exception("The record was altered by another session during editing");

                        var temp1 = ctx.TblPartD27011MultiBlock.Single(x => x.MultiBlockId == req.Block305Id);

                        if (req.UIAct == "Delete")
                        {
                            ctx.TblPartD27011MultiBlock.Remove(temp1);
                        }
                        else
                        {
                            temp1.ActualSqFt = req.ActualSqFt.GetNullValue();
                            temp1.AmountPaid = (decimal)req.AmountPaid.GetNullValue();
                            temp1.CostEstimator = req.CostEstimator.GetBoolValue();
                            temp1.DatePaid = (DateTime)req.DatePaid.GetNullDate();
                            temp1.DebentureInterest = (decimal)req.DebentureInterest.GetNullValue();
                            temp1.Description = req.Description;
                            temp1.Hudapproved = req.Hudapproved.GetBoolValue();
                            temp1.Quantity = req.Quantity.GetNullValue();
                            temp1.LastUpdateDate = DateTime.Now;
                            temp1.LastUpdateUser = _userid;
                        }
                        ctx.SaveChanges();
                    }
                    else
                    {
                        var block = ctx.LkpForm27011Blocks.Single(x => x.BlockCode == "305");
                        ctx.TblPartD27011MultiBlock.Add(new TblPartD27011MultiBlock
                        {
                            PartD27011id = req.PartD27011Id,
                            MultiBlockId = 0,
                            Form27011BlockId = block.Form27011BlockId,
                            ActualSqFt = req.ActualSqFt.GetNullValue(),
                            AmountPaid = (decimal)req.AmountPaid.GetNullValue(),
                            CostEstimator = req.CostEstimator.GetBoolValue(),
                            DatePaid = (DateTime)req.DatePaid.GetNullDate(),
                            DebentureInterest = (decimal)req.DebentureInterest.GetNullValue(),
                            Description = req.Description,
                            Hudapproved = req.Hudapproved.GetBoolValue(),
                            Quantity = req.Quantity.GetNullValue(),
                            EnteredByUser = _userid,
                            EnteredDate = DateTime.Now,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUser = _userid,
                         
                        });
                        ctx.SaveChanges();
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public GetFHABlock306sReply GetBlock306s(int id)
        {
            var ret = new GetFHABlock306sReply();

            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    var temp = ctx.VwFhaBlock306.Where(x => x.PartD27011id == id).Select(x => new FHABlock306
                    {
                        AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                        Block306Id = x.Block306Id,
                        ClaimTypeId = x.ClaimTypeId,
                        CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                        DatePaid = x.DatePaid.GetSafeDateTimeString(),
                        DebentureInterest = (double)x.DebentureInterest.GetSafeZeroValue(),
                        DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeZeroValue(),
                        DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeZeroValue(),
                        Description = x.Description.GetSafeString(),
                        Form27011BlockId = x.Form27011BlockId,
                        PartD27011Id = x.PartD27011id,
                        UseDefaultDateForCalc = x.UseDefaultDateForCalc.GetSafeValue(),
                        UIAct = ""
                    }).ToList();
                    foreach (var t in temp)
                    {
                        t.CheckSum = t.GetHashCode().ToString();
                    }
                    ret.FHABlock306S.AddRange(temp);
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveBlock306(FHABlock306 req)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    if (req.Block306Id > 0)
                    {
                        var temp = ctx.VwFhaBlock306.Where(x => x.Block306Id == req.Block306Id).Select(x => new FHABlock306
                        {
                            AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                            Block306Id = x.Block306Id,
                            ClaimTypeId = x.ClaimTypeId,
                            CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                            DatePaid = x.DatePaid.GetSafeDateTimeString(),
                            DebentureInterest = (double)x.DebentureInterest.GetSafeZeroValue(),
                            DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeZeroValue(),
                            DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeZeroValue(),
                            Description = x.Description.GetSafeString(),
                            Form27011BlockId = x.Form27011BlockId,
                            PartD27011Id = x.PartD27011id,
                            UseDefaultDateForCalc = x.UseDefaultDateForCalc.GetSafeValue(),
                            UIAct = ""
                        }).Single();

                        if (req.CheckSum != temp.GetHashCode().ToString())
                            throw new Exception("The record was altered by another session during editing");

                        var temp1 = ctx.TblPartD27011MultiBlock.Single(x => x.MultiBlockId == req.Block306Id);

                        if (req.UIAct == "Delete")
                        {
                            ctx.TblPartD27011MultiBlock.Remove(temp1);
                        }
                        else
                        {
                            temp1.AmountPaid = (decimal)req.AmountPaid.GetNullValue();
                            temp1.DatePaid = (DateTime)req.DatePaid.GetNullDate();
                            temp1.DebentureInterest = (decimal)req.DebentureInterest.GetNullValue();
                            temp1.Description = req.Description;
                            temp1.LastUpdateDate = DateTime.Now;
                            temp1.LastUpdateUser = _userid;
                        }
                        ctx.SaveChanges();
                    }
                    else
                    {
                        var block = ctx.LkpForm27011Blocks.Single(x => x.BlockCode == "306");
                        ctx.TblPartD27011MultiBlock.Add(new TblPartD27011MultiBlock
                        {
                            PartD27011id = req.PartD27011Id,
                            MultiBlockId = 0,
                            Form27011BlockId = block.Form27011BlockId,
                            DatePaid = (DateTime)req.DatePaid.GetNullDate(),
                            AmountPaid = (decimal)req.AmountPaid.GetNullValue(),
                            DebentureInterest = (decimal)req.DebentureInterest.GetNullValue(),
                            Description = req.Description,
                            EnteredByUser = _userid,
                            EnteredDate = DateTime.Now,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUser = _userid,

                        });
                        ctx.SaveChanges();
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public GetFHABlock307sReply GetBlock307s(int id)
        {
            var ret = new GetFHABlock307sReply();

            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    var temp = ctx.VwFhaBlock307.Where(x => x.PartD27011id == id).Select(x => new FHABlock307
                    {
                        AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                        Block307Id = x.Block307Id,
                        ClaimTypeId = x.ClaimTypeId,
                        CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                        DatePaid = x.DatePaid.GetSafeDateTimeString(),
                        DebentureInterest = (double)x.DebentureInterest.GetSafeZeroValue(),
                        DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeZeroValue(),
                        DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeZeroValue(),
                        Description = x.Description.GetSafeString(),
                        PartD27011Id = x.PartD27011id,
                        Form27011BlockId = x.Form27011BlockId,
                        UseDefaultDateForCalc = x.UseDefaultDateForCalc.GetSafeValue(),
                        UIAct = ""
                    }).ToList();
                    foreach (var t in temp)
                    {
                        t.CheckSum = t.GetHashCode().ToString();
                    }
                    ret.FHABlock307S.AddRange(temp);
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveBlock307(FHABlock307 req)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    var block = ctx.LkpForm27011Blocks.Single(x => x.BlockCode == "307");
                    if (req.Block307Id > 0)
                    {
                        var temp = ctx.VwFhaBlock307.Where(x => x.Block307Id == req.Block307Id).Select(x => new FHABlock307
                        {
                            AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                            Block307Id = x.Block307Id,
                            ClaimTypeId = x.ClaimTypeId,
                            CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                            DatePaid = x.DatePaid.GetSafeDateTimeString(),
                            DebentureInterest = (double)x.DebentureInterest.GetSafeZeroValue(),
                            DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeZeroValue(),
                            DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeZeroValue(),
                            Description = x.Description.GetSafeString(),
                            PartD27011Id = x.PartD27011id,
                            Form27011BlockId = x.Form27011BlockId,
                            UseDefaultDateForCalc = x.UseDefaultDateForCalc.GetSafeValue(),
                            UIAct = ""
                        }).Single();

                        if (req.CheckSum != temp.GetHashCode().ToString())
                            throw new Exception("The record was altered by another session during editing");

                        var temp1 = ctx.TblPartD27011MultiBlock.Single(x => x.MultiBlockId == req.Block307Id);

                        if (req.UIAct == "Delete")
                        {
                            ctx.TblPartD27011MultiBlock.Remove(temp1);
                        }
                        else
                        {
                            temp1.AmountPaid = (decimal)req.AmountPaid.GetNullValue();
                            temp1.DatePaid = (DateTime)req.DatePaid.GetNullDate();
                            temp1.DebentureInterest = (decimal)req.DebentureInterest.GetNullValue();
                            temp1.Description = req.Description;
                            temp1.LastUpdateDate = DateTime.Now;
                            temp1.LastUpdateUser = _userid;
                        }
                        ctx.SaveChanges();
                    }
                    else
                    {
                        ctx.TblPartD27011MultiBlock.Add(new TblPartD27011MultiBlock
                        {
                            PartD27011id = req.PartD27011Id,
                            MultiBlockId = 0,
                            Form27011BlockId = block.Form27011BlockId,
                            DatePaid = (DateTime)req.DatePaid.GetNullDate(),
                            AmountPaid = (decimal)req.AmountPaid.GetNullValue(),
                            DebentureInterest = (decimal)req.DebentureInterest.GetNullValue(),
                            Description = req.Description,
                            EnteredByUser = _userid,
                            EnteredDate = DateTime.Now,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUser = _userid,

                        });
                        ctx.SaveChanges();
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public GetFHABlock308sReply GetBlock308s(int id)
        {
            var ret = new GetFHABlock308sReply();

            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    var temp = ctx.VwFhaBlock308.Where(x => x.PartD27011id == id).Select(x => new FHABlock308
                    {
                        AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                        ClaimTypeId = x.ClaimTypeId,
                        CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                        DatePaid = x.DatePaid.GetSafeDateTimeString(),
                        DebentureInterest = (double)x.DebentureInterest.GetSafeZeroValue(),
                        DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeZeroValue(),
                        DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeZeroValue(),
                        PartD27011Id = x.PartD27011id,
                        FhaclaimId = x.FhaclaimId,
                        TaxOnDeedId = x.TaxOnDeedId,
                        TaxType = x.TaxType.GetSafeString(),
                        ToHud = (double)x.ToHud.GetSafeZeroValue(),
                        ToMortgagee = (double)x.ToMortgagee.GetSafeZeroValue(),
                        UseDefaultDateForCalc = x.UseDefaultDateForCalc.GetSafeValue(),
                        UIAct = ""
                    }).ToList();
                    foreach (var t in temp)
                    {
                        t.CheckSum = t.GetHashCode().ToString();
                    }
                    ret.FHABlock308S.AddRange(temp);
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveBlock308(FHABlock308 req)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    if (req.TaxOnDeedId > 0)
                    {
                        var temp = ctx.VwFhaBlock308.Where(x => x.TaxOnDeedId == req.TaxOnDeedId).Select(x => new FHABlock308
                        {
                            AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                            ClaimTypeId = x.ClaimTypeId,
                            CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                            DatePaid = x.DatePaid.GetSafeDateTimeString(),
                            DebentureInterest = (double)x.DebentureInterest.GetSafeZeroValue(),
                            DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeZeroValue(),
                            DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeZeroValue(),
                            PartD27011Id = x.PartD27011id,
                            FhaclaimId = x.FhaclaimId,
                            TaxOnDeedId = x.TaxOnDeedId,
                            TaxType = x.TaxType.GetSafeString(),
                            ToHud = (double)x.ToHud.GetSafeZeroValue(),
                            ToMortgagee = (double)x.ToMortgagee.GetSafeZeroValue(),
                            UseDefaultDateForCalc = x.UseDefaultDateForCalc.GetSafeValue(),
                        }).Single();

                        if (req.CheckSum != temp.GetHashCode().ToString())
                            throw new Exception("The record was altered by another session during editing");

                        var temp1 = ctx.TblPartD27011TaxesOnDeed.Single(x => x.TaxOnDeedId == req.TaxOnDeedId);

                        if (req.UIAct == "Delete")
                        {
                            ctx.TblPartD27011TaxesOnDeed.Remove(temp1);
                        }
                        else
                        {
                            temp1.AmountPaid = (decimal)req.AmountPaid.GetNullValue();
                            temp1.DatePaid = (DateTime)req.DatePaid.GetNullDate();
                            temp1.DebentureInterest = (decimal)req.DebentureInterest.GetNullValue();
                            temp1.TaxType = req.TaxType;
                            temp1.ToHud = (decimal)req.ToHud.GetNullValue();
                            temp1.ToMortgagee = (decimal)req.ToMortgagee.GetNullValue();
                            temp1.LastUpdateDate = DateTime.Now;
                            temp1.LastUpdateUser = _userid;
                        }
                        ctx.SaveChanges();
                    }
                    else
                    {
                        ctx.TblPartD27011TaxesOnDeed.Add(new TblPartD27011TaxesOnDeed
                        {
                            PartD27011id = req.PartD27011Id,
                            TaxOnDeedId = 0,
                            AmountPaid = (decimal)req.AmountPaid.GetNullValue(),
                            DatePaid = (DateTime)req.DatePaid.GetNullDate(),
                            DebentureInterest = (decimal)req.DebentureInterest.GetNullValue(),
                            TaxType = req.TaxType,
                            ToHud = (decimal?)req.ToHud.GetNullValue(),
                            ToMortgagee = (decimal?)req.ToMortgagee.GetNullValue(),
                            EnteredByUser = _userid,
                            EnteredDate = DateTime.Now,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUser = _userid,

                        });
                        ctx.SaveChanges();
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public GetFHABlock309sReply GetBlock309s(int id)
        {
            var ret = new GetFHABlock309sReply();

            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    var temp = ctx.VwFhaBlock309.Where(x => x.PartD27011id == id).Select(x => new FHABlock309
                    {
                        AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                        DateLienAttached = x.DateLienAttached.GetSafeDateTimeString(),
                        SpecialAssessmentsId = x.SpecialAssessmentsId,
                        ClaimTypeId = x.ClaimTypeId,
                        CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                        DatePaid = x.DatePaid.GetSafeDateTimeString(),
                        DebentureInterest = (double)x.DebentureInterest.GetSafeZeroValue(),
                        DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeZeroValue(),
                        DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeZeroValue(),
                        Description = x.Description.GetSafeString(),
                        PartD27011Id = x.PartD27011id,
                        FhaclaimId = x.FhaclaimId,
                        UseDefaultDateForCalc = x.UseDefaultDateForCalc.GetSafeValue(),
                        UIAct = ""
                    }).ToList();
                    foreach (var t in temp)
                    {
                        t.CheckSum = t.GetHashCode().ToString();
                    }
                    ret.FHABlock309S.AddRange(temp);
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveBlock309(FHABlock309 req)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    if (req.SpecialAssessmentsId > 0)
                    {
                        var temp = ctx.VwFhaBlock309.Where(x => x.SpecialAssessmentsId == req.SpecialAssessmentsId).Select(x => new FHABlock309
                        {
                            AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                            DateLienAttached = x.DateLienAttached.GetSafeDateTimeString(),
                            SpecialAssessmentsId = x.SpecialAssessmentsId,
                            ClaimTypeId = x.ClaimTypeId,
                            CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                            DatePaid = x.DatePaid.GetSafeDateTimeString(),
                            DebentureInterest = (double)x.DebentureInterest.GetSafeValue(),
                            DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeZeroValue(),
                            DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeZeroValue(),
                            Description = x.Description.GetSafeString(),
                            PartD27011Id = x.PartD27011id,
                            FhaclaimId = x.FhaclaimId,
                            UseDefaultDateForCalc = x.UseDefaultDateForCalc.GetSafeValue(),
                            UIAct = ""
                        }).Single();

                        if (req.CheckSum != temp.GetHashCode().ToString())
                            throw new Exception("The record was altered by another session during editing");

                        var temp1 = ctx.TblPartD27011SpecialAssessments.Single(x => x.SpecialAssessmentsId == req.SpecialAssessmentsId);

                        if (req.UIAct == "Delete")
                        {
                            ctx.TblPartD27011SpecialAssessments.Remove(temp1);
                        }
                        else
                        {
                            temp1.AmountPaid = (decimal)req.AmountPaid;
                            temp1.DateLienAttached = req.DateLienAttached.GetEmptyDate();
                            temp1.DatePaid = req.DatePaid.GetEmptyDate();
                            temp1.DebentureInterest = (decimal)req.DebentureInterest.GetNullValue();
                            temp1.Description = req.Description;
                            temp1.LastUpdateDate = DateTime.Now;
                            temp1.LastUpdateUser = _userid;
                        }
                        ctx.SaveChanges();
                    }
                    else
                    {
                        ctx.TblPartD27011SpecialAssessments.Add(new TblPartD27011SpecialAssessments
                        {
                            PartD27011id = req.PartD27011Id,
                            SpecialAssessmentsId = 0,
                            AmountPaid = (decimal)req.AmountPaid.GetNullValue(),
                            DateLienAttached = req.DateLienAttached.GetEmptyDate(),
                            DatePaid = req.DatePaid.GetEmptyDate(),
                            DebentureInterest = (decimal)req.DebentureInterest.GetNullValue(),
                            Description = req.Description,
                            EnteredByUser = _userid,
                            EnteredDate = DateTime.Now,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUser = _userid,
                        });
                        ctx.SaveChanges();
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public GetFHABlock310sReply GetBlock310s(int id)
        {
            var ret = new GetFHABlock310sReply();

            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    var temp = ctx.VwFhaBlock310.Where(x => x.PartD27011id == id).Select(x => new FHABlock310
                    {
                        AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                        Block310Id = x.Block310Id,
                        Form27011BlockId = x.Form27011BlockId,
                        ClaimTypeId = x.ClaimTypeId,
                        CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                        DatePaid = x.DatePaid.GetSafeDateTimeString(),
                        DebentureInterest = (double)x.DebentureInterest.GetSafeValue(),
                        Description = x.Description.GetSafeString(),
                        DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeZeroValue(),
                        DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeZeroValue(),
                        PartD27011Id = x.PartD27011id,
                        UseDefaultDateForCalc = x.UseDefaultDateForCalc.GetSafeValue(),
                        UIAct = ""
                    }).ToList();
                    foreach (var t in temp)
                    {
                        t.CheckSum = t.GetHashCode().ToString();
                    }
                    ret.FHABlock310S.AddRange(temp);
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveBlock310(FHABlock310 req)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    var block = ctx.LkpForm27011Blocks.Single(x => x.BlockCode == "310");
                    if (req.Block310Id > 0)
                    {
                        var temp = ctx.VwFhaBlock310.Where(x => x.Block310Id == req.Block310Id).Select(x => new FHABlock310
                        {
                            AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                            Block310Id = x.Block310Id,
                            Form27011BlockId = x.Form27011BlockId,
                            ClaimTypeId = x.ClaimTypeId,
                            CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                            DatePaid = x.DatePaid.GetSafeDateTimeString(),
                            DebentureInterest = (double)x.DebentureInterest.GetSafeValue(),
                            Description = x.Description.GetSafeString(),
                            DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeZeroValue(),
                            DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeZeroValue(),
                            PartD27011Id = x.PartD27011id,
                            UseDefaultDateForCalc = x.UseDefaultDateForCalc.GetSafeValue(),
                            UIAct = ""
                        }).Single();

                        if (req.CheckSum != temp.GetHashCode().ToString())
                            throw new Exception("The record was altered by another session during editing");

                        var temp1 = ctx.TblPartD27011MultiBlock.Single(x => x.MultiBlockId == req.Block310Id);

                        if (req.UIAct == "Delete")
                        {
                            ctx.TblPartD27011MultiBlock.Remove(temp1);
                        }
                        else
                        {
                            temp1.AmountPaid = (decimal)req.AmountPaid.GetNullValue();
                            temp1.DatePaid = (DateTime)req.DatePaid.GetNullDate();
                            temp1.DebentureInterest = (decimal)req.DebentureInterest.GetNullValue();
                            temp1.Description = req.Description;
                            temp1.LastUpdateDate = DateTime.Now;
                            temp1.LastUpdateUser = _userid;
                        }
                        ctx.SaveChanges();
                    }
                    else
                    {
                        ctx.TblPartD27011MultiBlock.Add(new TblPartD27011MultiBlock
                        {
                            PartD27011id = req.PartD27011Id,
                            MultiBlockId = 0,
                            Form27011BlockId = block.Form27011BlockId,
                            AmountPaid = (decimal)req.AmountPaid.GetNullValue(),
                            DatePaid = (DateTime)req.DatePaid.GetNullDate(),
                            DebentureInterest = (decimal)req.DebentureInterest.GetNullValue(),
                            Description = req.Description,
                            EnteredByUser = _userid,
                            EnteredDate = DateTime.Now,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUser = _userid,

                        });
                        ctx.SaveChanges();
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public GetFHABlock311sReply GetBlock311s(int id)
        {
            var ret = new GetFHABlock311sReply();

            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    var temp = ctx.VwFhaBlock311.Where(x => x.PartD27011id == id).Select(x => new FHABlock311
                    {
                        AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                        ClaimTypeId = x.ClaimTypeId,
                        CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                        DatePaid = x.DatePaid.GetSafeDateTimeString(),
                        DebentureInterest = (double)x.DebentureInterest.GetSafeZeroValue(),
                        DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeZeroValue(),
                        DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeZeroValue(),
                        PartD27011Id = x.PartD27011id,
                        MipremiumId = x.MipremiumId,
                        PeriodCoveredFrom = x.PeriodCoveredFrom.GetSafeDateTimeString(),
                        PeriodCoveredTo = x.PeriodCoveredTo.GetSafeDateTimeString(),
                        UseDefaultDateForCalc = x.UseDefaultDateForCalc,
                        UIAct = ""
                    }).ToList();
                    foreach (var t in temp)
                    {
                        t.CheckSum = t.GetHashCode().ToString();
                    }
                    ret.FHABlock311S.AddRange(temp);
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveBlock311(FHABlock311 req)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    if (req.MipremiumId > 0)
                    {
                        var temp = ctx.VwFhaBlock311.Where(x => x.MipremiumId == req.MipremiumId).Select(x => new FHABlock311
                        {
                            AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                            ClaimTypeId = x.ClaimTypeId,
                            CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                            DatePaid = x.DatePaid.GetSafeDateTimeString(),
                            DebentureInterest = (double)x.DebentureInterest.GetSafeZeroValue(),
                            DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeZeroValue(),
                            DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeZeroValue(),
                            PartD27011Id = x.PartD27011id,
                            MipremiumId = x.MipremiumId,
                            PeriodCoveredFrom = x.PeriodCoveredFrom.GetSafeDateTimeString(),
                            PeriodCoveredTo = x.PeriodCoveredTo.GetSafeDateTimeString(),
                            UseDefaultDateForCalc = x.UseDefaultDateForCalc,
                            UIAct = ""
                        }).Single();

                        if (req.CheckSum != temp.GetHashCode().ToString())
                            throw new Exception("The record was altered by another session during editing");

                        var temp1 = ctx.TblPartD27011Mipremiums.Single(x => x.MipremiumId == req.MipremiumId);

                        if (req.UIAct == "Delete")
                        {
                            ctx.TblPartD27011Mipremiums.Remove(temp1);
                        }
                        else
                        {
                            temp1.AmountPaid = (decimal)req.AmountPaid;
                            temp1.DatePaid = (DateTime)req.DatePaid.GetNullDate();
                            temp1.DebentureInterest = (decimal)req.DebentureInterest.GetNullValue();
                            temp1.PeriodCoveredTo = (DateTime)req.PeriodCoveredTo.GetNullDate();
                            temp1.PeriodCoveredFrom = (DateTime)req.PeriodCoveredFrom.GetNullDate();
                            temp1.LastUpdateDate = DateTime.Now;
                            temp1.LastUpdateUser = _userid;
                        }
                        ctx.SaveChanges();
                    }
                    else
                    {
                        ctx.TblPartD27011Mipremiums.Add(new TblPartD27011Mipremiums
                        {
                            PartD27011id = req.PartD27011Id,
                            MipremiumId = 0,
                            AmountPaid = (decimal)req.AmountPaid,
                            DatePaid = (DateTime)req.DatePaid.GetNullDate(),
                            DebentureInterest = (decimal)req.DebentureInterest.GetNullValue(),
                            PeriodCoveredFrom = (DateTime)req.PeriodCoveredFrom.GetNullDate(),
                            PeriodCoveredTo = (DateTime)req.PeriodCoveredTo.GetNullDate(),
                            EnteredByUser = _userid,
                            EnteredDate = DateTime.Now,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUser = _userid,

                        });
                        ctx.SaveChanges();
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public GetFHABlock405sReply GetBlock405s(int id)
        {
            var ret = new GetFHABlock405sReply();

            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    var temp = ctx.VwFhaBlock405.Where(x => x.PartE27011id == id).Select(x => new FHABlock405
                    {
                        PartE27011Id = x.PartE27011id,
                        AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                        DatePaid = x.DatePaid.GetSafeDateTimeString(),
                        Block405Id = x.Block405Id,
                        ClaimTypeId = x.ClaimTypeId,
                        CurtailDateForDi = x.CurtailDateForDi.GetSafeString(),
                        DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeNullValue(),
                        DebentureInterest = (double)x.DebentureInterest.GetSafeNullValue(),
                        DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeNullValue(),
                        Description = x.Description.GetSafeString(),
                        Form27011BlockId = x.Form27011BlockId,
                        UIAct = ""
                    }).ToList();
                    foreach (var t in temp)
                    {
                        t.CheckSum = t.GetHashCode().ToString();
                    }
                    ret.FHABlock405S.AddRange(temp);
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveBlock405(FHABlock405 req)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    if (req.Block405Id > 0)
                    {
                        var temp = ctx.VwFhaBlock405.Where(x => x.Block405Id == req.Block405Id).Select(x => new FHABlock405
                        {
                            PartE27011Id = x.PartE27011id,
                            AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                            DatePaid = x.DatePaid.GetSafeDateTimeString(),
                            Block405Id = x.Block405Id,
                            ClaimTypeId = x.ClaimTypeId,
                            CurtailDateForDi = x.CurtailDateForDi.GetSafeString(),
                            DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeNullValue(),
                            DebentureInterest = (double)x.DebentureInterest.GetSafeNullValue(),
                            DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeNullValue(),
                            Description = x.Description.GetSafeString(),
                            Form27011BlockId = x.Form27011BlockId,
                            UIAct = ""
                        }).Single();

                        if (req.CheckSum != temp.GetHashCode().ToString())
                            throw new Exception("The record was altered by another session during editing");

                        var temp1 = ctx.TblPartE27011MultiBlock.Single(x => x.MultiBlockId == req.Block405Id);

                        if (req.UIAct == "Delete")
                        {
                            ctx.TblPartE27011MultiBlock.Remove(temp1);
                        }
                        else
                        {
                            temp1.AmountPaid = (decimal)req.AmountPaid;
                            temp1.DatePaid = req.DatePaid.GetNullDate();
                            temp1.DebentureInterest = (decimal?)req.DebentureInterest.GetNullValue();
                            temp1.Description = req.Description;
                            temp1.LastUpdateDate = DateTime.Now;
                            temp1.LastUpdateUser = _userid;
                        }
                        ctx.SaveChanges();
                    }
                    else
                    {
                        var block = ctx.LkpForm27011Blocks.Single(x => x.BlockCode == "405");
                        ctx.TblPartE27011MultiBlock.Add(new TblPartE27011MultiBlock
                        {
                            PartE27011id = req.PartE27011Id,
                            MultiBlockId = 0,
                            Form27011BlockId = block.Form27011BlockId,
                            AmountPaid = (decimal)req.AmountPaid.GetNullValue(),
                            DatePaid = req.DatePaid.GetNullDate(),
                            EnteredByUser = _userid,
                            EnteredDate = DateTime.Now,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUser = _userid,

                        });
                        ctx.SaveChanges();
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public GetFHABlock406sReply GetBlock406s(int id)
        {
            var ret = new GetFHABlock406sReply();

            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    var temp = ctx.VwFhaBlock406.Where(x => x.PartE27011id == id).Select(x => new FHABlock406
                    {
                        AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                        DatePaid = x.DatePaid.GetSafeDateTimeString(),
                        Block406Id = x.Block406Id,
                        ClaimTypeId = x.ClaimTypeId,
                        CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                        DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeNullValue(),
                        DebentureInterest = (double)x.DebentureInterest.GetSafeNullValue(),
                        DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeNullValue(),
                        Description = x.Description.GetSafeString(),
                        Form27011BlockId = x.Form27011BlockId,
                        PartE27011Id = x.PartE27011id,
                        UIAct = ""
                    }).ToList();
                    foreach (var t in temp)
                    {
                        t.CheckSum = t.GetHashCode().ToString();
                    }
                    ret.FHABlock406S.AddRange(temp);
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveBlock406(FHABlock406 req)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    if (req.Block406Id > 0)
                    {
                        var temp = ctx.VwFhaBlock406.Where(x => x.Block406Id == req.Block406Id).Select(x => new FHABlock406
                        {
                            AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                            DatePaid = x.DatePaid.GetSafeDateTimeString(),
                            Block406Id = x.Block406Id,
                            ClaimTypeId = x.ClaimTypeId,
                            CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                            DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeNullValue(),
                            DebentureInterest = (double)x.DebentureInterest.GetSafeNullValue(),
                            DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeNullValue(),
                            Description = x.Description.GetSafeString(),
                            Form27011BlockId = x.Form27011BlockId,
                            PartE27011Id = x.PartE27011id,
                            UIAct = ""
                        }).Single();

                        if (req.CheckSum != temp.GetHashCode().ToString())
                            throw new Exception("The record was altered by another session during editing");

                        var temp1 = ctx.TblPartE27011MultiBlock.Single(x => x.MultiBlockId == req.Block406Id);

                        if (req.UIAct == "Delete")
                        {
                            ctx.TblPartE27011MultiBlock.Remove(temp1);
                        }
                        else
                        {
                            temp1.AmountPaid = (decimal)req.AmountPaid.GetNullValue();
                            temp1.DatePaid = req.DatePaid.GetNullDate();
                            temp1.DebentureInterest = (decimal?)req.DebentureInterest.GetNullValue();
                            temp1.Description = req.Description;
                            temp1.LastUpdateDate = DateTime.Now;
                            temp1.LastUpdateUser = _userid;
                        }
                        ctx.SaveChanges();
                    }
                    else
                    {
                        var block = ctx.LkpForm27011Blocks.Single(x => x.BlockCode == "406");
                        ctx.TblPartE27011MultiBlock.Add(new TblPartE27011MultiBlock
                        {
                            PartE27011id = req.PartE27011Id,
                            MultiBlockId = 0,
                            Form27011BlockId = block.Form27011BlockId,
                            AmountPaid = (decimal)req.AmountPaid.GetNullValue(),
                            DatePaid = req.DatePaid.GetNullDate(),
                            DebentureInterest = (decimal?)req.DebentureInterest.GetNullValue(),
                            Description = req.Description,
                            EnteredByUser = _userid,
                            EnteredDate = DateTime.Now,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUser = _userid,

                        });
                        ctx.SaveChanges();
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public GetFHABlock407sReply GetBlock407s(int id)
        {
            var ret = new GetFHABlock407sReply();

            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    var temp = ctx.VwFhaBlock407.Where(x => x.PartE27011id == id).Select(x => new FHABlock407
                    {
                        AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                        DatePaid = x.DatePaid.GetSafeDateTimeString(),
                        Block407Id = x.Block407Id,
                        ClaimTypeId = x.ClaimTypeId,
                        CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                        DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeNullValue(),
                        DebentureInterest = (double)x.DebentureInterest.GetSafeNullValue(),
                        DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeNullValue(),
                        Description = x.Description.GetSafeString(),
                        Form27011BlockId = x.Form27011BlockId,
                        PartE27011Id = x.PartE27011id,
                        UIAct = ""
                    }).ToList();
                    foreach (var t in temp)
                    {
                        t.CheckSum = t.GetHashCode().ToString();
                    }
                    ret.FHABlock407S.AddRange(temp);
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveBlock407(FHABlock407 req)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    if (req.Block407Id > 0)
                    {
                        var temp = ctx.VwFhaBlock407.Where(x => x.Block407Id == req.Block407Id).Select(x => new FHABlock407
                        {
                            AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                            DatePaid = x.DatePaid.GetSafeDateTimeString(),
                            Block407Id = x.Block407Id,
                            ClaimTypeId = x.ClaimTypeId,
                            CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                            DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeNullValue(),
                            DebentureInterest = (double)x.DebentureInterest.GetSafeNullValue(),
                            DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeNullValue(),
                            Description = x.Description.GetSafeString(),
                            Form27011BlockId = x.Form27011BlockId,
                            PartE27011Id = x.PartE27011id,
                            UIAct = ""
                        }).Single();

                        if (req.CheckSum != temp.GetHashCode().ToString())
                            throw new Exception("The record was altered by another session during editing");

                        var temp1 = ctx.TblPartE27011MultiBlock.Single(x => x.MultiBlockId == req.Block407Id);

                        if (req.UIAct == "Delete")
                        {
                            ctx.TblPartE27011MultiBlock.Remove(temp1);
                        }
                        else
                        {
                            temp1.AmountPaid = (decimal)req.AmountPaid.GetNullValue();
                            temp1.DatePaid = req.DatePaid.GetNullDate();
                            temp1.DebentureInterest = (decimal?)req.DebentureInterest.GetNullValue();
                            temp1.Description = req.Description;
                            temp1.LastUpdateDate = DateTime.Now;
                            temp1.LastUpdateUser = _userid;
                        }
                        ctx.SaveChanges();
                    }
                    else
                    {
                        var block = ctx.LkpForm27011Blocks.Single(x => x.BlockCode == "407");
                        ctx.TblPartE27011MultiBlock.Add(new TblPartE27011MultiBlock
                        {
                            PartE27011id = req.PartE27011Id,
                            MultiBlockId = 0,
                            Form27011BlockId = block.Form27011BlockId,
                            AmountPaid = (decimal)req.AmountPaid.GetNullValue(),
                            DatePaid = req.DatePaid.GetNullDate(),
                            DebentureInterest = (decimal?)req.DebentureInterest.GetNullValue(),
                            Description = req.Description,
                            EnteredByUser = _userid,
                            EnteredDate = DateTime.Now,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUser = _userid,

                        });
                        ctx.SaveChanges();
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public GetFHABlock408sReply GetBlock408s(int id)
        {
            var ret = new GetFHABlock408sReply();

            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    var temp = ctx.VwFhaBlock408.Where(x => x.PartE27011id == id).Select(x => new FHABlock408
                    {
                        AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                        DatePaid = x.DatePaid.GetSafeDateTimeString(),
                        Block408Id = x.Block408Id,
                        ClaimTypeId = x.ClaimTypeId,
                        CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                        DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeNullValue(),
                        DebentureInterest = (double)x.DebentureInterest.GetSafeNullValue(),
                        DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeNullValue(),
                        Description = x.Description.GetSafeString(),
                        Form27011BlockId = x.Form27011BlockId,
                        PartE27011Id = x.PartE27011id,
                        UIAct = ""
                    }).ToList();
                    foreach (var t in temp)
                    {
                        t.CheckSum = t.GetHashCode().ToString();
                    }
                    ret.FHABlock408S.AddRange(temp);
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveBlock408(FHABlock408 req)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    if (req.Block408Id > 0)
                    {
                        var temp = ctx.VwFhaBlock408.Where(x => x.Block408Id == req.Block408Id).Select(x => new FHABlock408
                        {
                            AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                            DatePaid = x.DatePaid.GetSafeDateTimeString(),
                            Block408Id = x.Block408Id,
                            ClaimTypeId = x.ClaimTypeId,
                            CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                            DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeNullValue(),
                            DebentureInterest = (double)x.DebentureInterest.GetSafeNullValue(),
                            DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeNullValue(),
                            Description = x.Description.GetSafeString(),
                            Form27011BlockId = x.Form27011BlockId,
                            PartE27011Id = x.PartE27011id,
                            UIAct = ""
                        }).Single();

                        if (req.CheckSum != temp.GetHashCode().ToString())
                            throw new Exception("The record was altered by another session during editing");

                        var temp1 = ctx.TblPartE27011MultiBlock.Single(x => x.MultiBlockId == req.Block408Id);

                        if (req.UIAct == "Delete")
                        {
                            ctx.TblPartE27011MultiBlock.Remove(temp1);
                        }
                        else
                        {
                            temp1.AmountPaid = (decimal)req.AmountPaid.GetNullValue();
                            temp1.DatePaid = req.DatePaid.GetNullDate();
                            temp1.DebentureInterest = (decimal?)req.DebentureInterest.GetNullValue();
                            temp1.Description = req.Description;
                            temp1.LastUpdateDate = DateTime.Now;
                            temp1.LastUpdateUser = _userid;
                        }
                        ctx.SaveChanges();
                    }
                    else
                    {
                        var block = ctx.LkpForm27011Blocks.Single(x => x.BlockCode == "408");
                        ctx.TblPartE27011MultiBlock.Add(new TblPartE27011MultiBlock
                        {
                            PartE27011id = req.PartE27011Id,
                            MultiBlockId = 0,
                            Form27011BlockId = block.Form27011BlockId,
                            AmountPaid = (decimal)req.AmountPaid.GetNullValue(),
                            DatePaid = req.DatePaid.GetNullDate(),
                            DebentureInterest = (decimal?)req.DebentureInterest.GetNullValue(),
                            Description = req.Description,
                            EnteredByUser = _userid,
                            EnteredDate = DateTime.Now,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUser = _userid,

                        });
                        ctx.SaveChanges();
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public GetFHABlock409sReply GetBlock409s(int id)
        {
            var ret = new GetFHABlock409sReply();

            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    var temp = ctx.VwFhaBlock409.Where(x => x.PartE27011id == id).Select(x => new FHABlock409
                    {
                        AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                        DatePaid = x.DatePaid.GetSafeDateTimeString(),
                        Block409Id = x.Block409Id,
                        ClaimTypeId = x.ClaimTypeId,
                        CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                        DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeNullValue(),
                        DebentureInterest = (double)x.DebentureInterest.GetSafeNullValue(),
                        DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeNullValue(),
                        Description = x.Description.GetSafeString(),
                        Form27011BlockId = x.Form27011BlockId,
                        PartE27011Id = x.PartE27011id,
                        UIAct = ""
                    }).ToList();
                    foreach (var t in temp)
                    {
                        t.CheckSum = t.GetHashCode().ToString();
                    }
                    ret.FHABlock409S.AddRange(temp);
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveBlock409(FHABlock409 req)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    if (req.Block409Id > 0)
                    {
                        var temp = ctx.VwFhaBlock409.Where(x => x.Block409Id == req.Block409Id).Select(x => new FHABlock409
                        {
                            AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                            DatePaid = x.DatePaid.GetSafeDateTimeString(),
                            Block409Id = x.Block409Id,
                            ClaimTypeId = x.ClaimTypeId,
                            CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                            DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeNullValue(),
                            DebentureInterest = (double)x.DebentureInterest.GetSafeNullValue(),
                            DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeNullValue(),
                            Description = x.Description.GetSafeString(),
                            Form27011BlockId = x.Form27011BlockId,
                            PartE27011Id = x.PartE27011id,
                            UIAct = ""
                        }).Single();

                        if (req.CheckSum != temp.GetHashCode().ToString())
                            throw new Exception("The record was altered by another session during editing");

                        var temp1 = ctx.TblPartE27011MultiBlock.Single(x => x.MultiBlockId == req.Block409Id);

                        if (req.UIAct == "Delete")
                        {
                            ctx.TblPartE27011MultiBlock.Remove(temp1);
                        }
                        else
                        {
                            temp1.AmountPaid = (decimal)req.AmountPaid.GetNullValue();
                            temp1.DatePaid = req.DatePaid.GetNullDate();
                            temp1.DebentureInterest = (decimal?)req.DebentureInterest.GetNullValue();
                            temp1.Description = req.Description;
                            temp1.LastUpdateDate = DateTime.Now;
                            temp1.LastUpdateUser = _userid;
                        }
                        ctx.SaveChanges();
                    }
                    else
                    {
                        var block = ctx.LkpForm27011Blocks.Single(x => x.BlockCode == "409");
                        ctx.TblPartE27011MultiBlock.Add(new TblPartE27011MultiBlock
                        {
                            PartE27011id = req.PartE27011Id,
                            MultiBlockId = 0,
                            Form27011BlockId = block.Form27011BlockId,
                            AmountPaid = (decimal)req.AmountPaid.GetNullValue(),
                            DatePaid = req.DatePaid.GetNullDate(),
                            DebentureInterest = (decimal?)req.DebentureInterest.GetNullValue(),
                            Description = req.Description,
                            EnteredByUser = _userid,
                            EnteredDate = DateTime.Now,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUser = _userid,

                        });
                        ctx.SaveChanges();
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public GetFHABlock410sReply GetBlock410s(int id)
        {
            var ret = new GetFHABlock410sReply();

            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    var temp = ctx.VwFhaBlock410.Where(x => x.PartE27011id == id).Select(x => new FHABlock410
                    {
                        AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                        DatePaid = x.DatePaid.GetSafeDateTimeString(),
                        Block410Id = x.Block410Id,
                        ClaimTypeId = x.ClaimTypeId,
                        CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                        DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeNullValue(),
                        DebentureInterest = (double)x.DebentureInterest.GetSafeNullValue(),
                        DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeNullValue(),
                        Description = x.Description.GetSafeString(),
                        Form27011BlockId = x.Form27011BlockId,
                        PartE27011Id = x.PartE27011id,
                        UIAct = ""
                    }).ToList();
                    foreach (var t in temp)
                    {
                        t.CheckSum = t.GetHashCode().ToString();
                    }
                    ret.FHABlock410S.AddRange(temp);
                }
            }
            catch
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveBlock410(FHABlock410 req)
        {
            var ret = new MessageReply { Message = Constant.Success, Id = 0 };
            try
            {
                using (var ctx = new HUDClaimsContext())
                {
                    if (req.Block410Id > 0)
                    {
                        var temp = ctx.VwFhaBlock410.Where(x => x.Block410Id == req.Block410Id).Select(x => new FHABlock410
                        {
                            AmountPaid = (double)x.AmountPaid.GetSafeValue(),
                            DatePaid = x.DatePaid.GetSafeDateTimeString(),
                            Block410Id = x.Block410Id,
                            ClaimTypeId = x.ClaimTypeId,
                            CurtailDateForDi = x.CurtailDateForDi.GetSafeDateTimeString(),
                            DebentureInterestCalc = (double)x.DebentureInterestCalc.GetSafeNullValue(),
                            DebentureInterest = (double)x.DebentureInterest.GetSafeNullValue(),
                            DebentureInterestRate = (double)x.DebentureInterestRate.GetSafeNullValue(),
                            Description = x.Description.GetSafeString(),
                            Form27011BlockId = x.Form27011BlockId,
                            PartE27011Id = x.PartE27011id,
                            UIAct = ""
                        }).Single();

                        if (req.CheckSum != temp.GetHashCode().ToString())
                            throw new Exception("The record was altered by another session during editing");

                        var temp1 = ctx.TblPartE27011MultiBlock.Single(x => x.MultiBlockId == req.Block410Id);

                        if (req.UIAct == "Delete")
                        {
                            ctx.TblPartE27011MultiBlock.Remove(temp1);
                        }
                        else
                        {
                            temp1.AmountPaid = (decimal)req.AmountPaid.GetNullValue();
                            temp1.DatePaid = req.DatePaid.GetNullDate();
                            temp1.DebentureInterest = (decimal?)req.DebentureInterest.GetNullValue();
                            temp1.Description = req.Description;
                            temp1.LastUpdateDate = DateTime.Now;
                            temp1.LastUpdateUser = _userid;
                        }
                        ctx.SaveChanges();
                    }
                    else
                    {
                        var block = ctx.LkpForm27011Blocks.Single(x => x.BlockCode == "410");
                        ctx.TblPartE27011MultiBlock.Add(new TblPartE27011MultiBlock
                        {
                            PartE27011id = req.PartE27011Id,
                            MultiBlockId = 0,
                            Form27011BlockId = block.Form27011BlockId,
                            AmountPaid = (decimal)req.AmountPaid.GetNullValue(),
                            DatePaid = req.DatePaid.GetNullDate(),
                            DebentureInterest = (decimal?)req.DebentureInterest.GetNullValue(),
                            Description = req.Description,
                            EnteredByUser = _userid,
                            EnteredDate = DateTime.Now,
                            LastUpdateDate = DateTime.Now,
                            LastUpdateUser = _userid,

                        });
                        ctx.SaveChanges();
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
    }
}
