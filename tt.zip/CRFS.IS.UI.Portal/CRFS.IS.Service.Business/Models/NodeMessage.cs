﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Linq;

namespace CRFS.IS.Service.Business.Models
{
    public class NodeMessage
    {
        public XElement Node { get; set; }
        public string Message { get; set; }
    }
}
