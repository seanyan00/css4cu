﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRFS.IS.Service.Business.Models
{
    public class InvTrkLoan
    {
        public int Id { get; set; }
        public string LoanNum { get; set; }
        public int ClientId { get; set; }
    }
}
