﻿using System;
using System.Collections.Generic;
using System.ServiceModel.Channels;
using System.Text;

namespace CRFS.IS.Service.Business.Models
{
    public class SubmitItem
    {
        public string FHACaseNum { get; set; }
        public string ClaimTypeCode { get; set; }
        public string LoanNumber { get; set; }
        public string ClientName { get; set; }
        public string ClaimTypeName { get; set; }
        public string ClaimSubTypeName { get; set; }
        public string CMSSubmitTime { get; set; }
        public int InvTrkClaimId { get; set; }
        public bool IsError { get; set; }
        public string Message { get; set; }
    }
}
