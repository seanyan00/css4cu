﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRFS.IS.Service.Business.Models
{
    public class DWDialogExpression
    {
        public List<DWSearchCondition> Condition { get; set; }
        public string Operation { get; set; }
    }

    public class DWSearchCondition
    {
        public string DBName { get; set; }
        public List<String> Value { get; set; }
    }
}
