﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRFS.IS.Service.Business.Models
{
    public class SaveToDWError
    {
        public static readonly string MessageFmt = "Saving to Docuware raised an error for Loan# {0}, {1}, {2}. The error is: {3}";
        public string ErrorMessage { get; set; }
        public string MailingList { get; set; }
        public string Subject { get; set; }
       // public string LoanNumber { get; set; }
       // public string ClientName { get; set; }
       // public string ClaimTypeName { get; set; }
    }
}
