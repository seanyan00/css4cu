﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using NPOI;
using NPOI.SS.UserModel;
using NPOI.HSSF.UserModel;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.Common.TransferObjects;
using CRFS.IS.Service.Data;

namespace CRFS.IS.Service.Business
{
    public static class ExcelReaderHelper{
        public static T? GetCellValue<T>(this ICell cell) where T : struct
        {
            var t = typeof(T);

            if (cell == null || cell.CellType == CellType.Blank)
                return null;

            switch (t.FullName)
            {
                case "System.Boolean":
                    return (T)Convert.ChangeType(cell.BooleanCellValue, t);
                case "System.Int32":
                case "System.Double":
                    return (T)Convert.ChangeType(cell.NumericCellValue, t);
                case "System.DateTime":
                    return (T)Convert.ChangeType(cell.DateCellValue, t);
                default:
                    return default(T);
            }
        }
        public static string GetCellString(this ICell cell) 
        {
           if (cell == null || cell.CellType == CellType.Blank)
                return null;

            if (cell.CellType == CellType.Numeric)
                return cell.NumericCellValue.ToString();

            return cell.StringCellValue;
        }
    }
    public class ExpenseDataReader
    {
        public List<LAExpenseDTO> GetExpenseDTO(string fname, int uploadid, int type, out bool success)
        {
            var ret = new List<LAExpenseDTO>();
            var colnms = new Dictionary<int, string>();
            var errs = new List<string>();
            success = true;
            bool empty = false;

            try
            {
                using (var ctx = new LossAnalysisNewContext())
                {
                    var di = new TblDataImport
                    {
                        Id = 0,
                        Status = "Extracting",
                        TemplateId = type,
                        UploadId = uploadid,
                        TotalRows = 0
                    };
                    var ttlrows = 0;
                    
                    using (var fs = new FileStream(fname, FileMode.Open, FileAccess.Read))
                    {
                        var wb = WorkbookFactory.Create(fs);
                        var st = wb.GetSheetAt(0);

                        var hrow = st.GetRow(0);
                        for (var i = 0; i < hrow.Cells.Count; i++)
                        {
                            colnms.Add(i, hrow.GetCell(i).StringCellValue);
                        }
                        var cid = 0;

                        for (var i = 1; i <= Math.Min(st.LastRowNum, Constant.MAXEXPENSEROW); i++)
                        {
                            try
                            {
                                var row = st.GetRow(i);
                                var temp = new LAExpenseDTO();
                              
                                var er = IsRowEmpty(row);
                                if (empty && er)
                                {
                                    /*var msg = string.Format("Error at row {0}: Empty row encountered", i);
                                    errs.Add(msg);*/
                                    break;
                                }
                                if (er)
                                {
                                   empty = true; 
                                   var msg = string.Format("Error at row {0}: Empty row encountered", i);
                                    errs.Add(msg);

                                    continue;
                                }
                               
                                ttlrows += 1;
                                cid = 0;
                                temp.LoanNumber = row.GetCell(cid).StringCellValue;
                                cid = 1;
                                temp.FHACaseNumber = row.GetCell(cid).StringCellValue;
                                cid = 2;
                                temp.Category = row.GetCell(cid).StringCellValue;
                                cid = 3;
                                temp.PaidDate =  row.GetCell(cid).GetCellValue<DateTime>();
                                cid = 4;
                                temp.AmoutDisbursed = row.GetCell(cid).GetCellValue<double>();
                                cid = 5;
                                temp.AmoutClaimed = row.GetCell(cid).GetCellValue<double>();
                                cid = 6;
                                temp.ItemDescription = row.GetCell(cid).GetCellString();
                                cid = 7;
                                temp.AdvaceFrom = row.GetCell(cid).StringCellValue;
                                cid = 8;
                                temp.WorkCompleteDate = row.GetCell(cid).GetCellValue<DateTime>();
                                cid = 9;
                                temp.Quantity = row.GetCell(cid).GetCellValue<double>();
                                cid = 10;
                                temp.CoverageStartDate = row.GetCell(cid).GetCellValue<DateTime>();
                                cid = 11;
                                temp.CoverageEndDate = row.GetCell(cid).GetCellValue<DateTime>();
                                cid = 12;
                                temp.ChargeOffReason = row.GetCell(cid).GetCellString();
                                cid = 13;
                                temp.ClaimAmountOverride = row.GetCell(cid).GetCellValue<double>();
                                cid = 14;
                                temp.ResponsibleParty = row.GetCell(cid).GetCellString();
                                cid = 15;
                                temp.PenaltiesFeesInterest = default(double); // row.GetCell(cid).GetCellValue<double>();
                                cid = 15;
                                temp.InvoiceNumber = row.GetCell(cid).GetCellString();
                                cid = 16;
                                temp.Details = row.GetCell(cid).GetCellString();
                              
                                ret.Add(temp);
                            }
                            catch (Exception ex)
                            {
                                success = false;
                                var msg = string.Format("Error at row {0} column {1}: {2}", i, colnms[cid], ex.Message);

                                errs.Add(msg);
                                continue;
                            }
                        }  
                        di.TotalRows = ttlrows;
                        
                        ctx.TblDataImport.Add(di);

                        ctx.SaveChanges();
                        foreach(var m in errs)
                        {
                            ctx.TblDataImportDetail.Add(new TblDataImportDetail
                            {
                                Id = 0,
                                Diid = di.Id,
                                Error = m
                            });
                        }
                        ctx.SaveChanges();
                    }
                }
            }
            catch
            {
                success = false;
                throw;
            }
            return ret;
        }
        private bool IsRowEmpty(IRow row)
        {
            if (row == null)
                return true;
            if (row.LastCellNum <= 0)
                return true;
           
            for(int i = row.FirstCellNum; i < row.LastCellNum; i++)
            {
                ICell cell = row.GetCell(i);
                if(cell != null && cell.CellType != CellType.Blank && !string.IsNullOrEmpty(cell.ToString()))
                {
                    return false;
                }
            }

            return true;
        }
       
    }
}
