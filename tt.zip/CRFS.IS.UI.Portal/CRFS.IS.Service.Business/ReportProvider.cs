﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.IO;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Data.SqlClient;

using CRFS.IS.Service.Data;
using CRFS.IS.Service.Common;
using CRFS.IS.Service.GRpc;

namespace CRFS.IS.Service.Business
{
    public class ReportProvider
    {
        private IConfiguration _config;
        private ILogger _logger;
        private LkpUsers _user;

        public ReportProvider(IConfiguration config, ILogger logger, LkpUsers user)
        {
            _config = config;
            _logger = logger;
            _user = user;
        }
       
        public GetReportsReply GetReports()
        {
            var ret = new GetReportsReply();
            try
            {
                var rpts = new List<Report>();
                using (var ctx = new RGSContext())
                {
                    rpts = ctx.LkpReport.Select(x => new Report {
                        Active = x.Active ? 1 : 0,
                        Destination = x.Destination.GetSafeString(),
                        FileName = x.FileName.GetSafeString(),
                        Id = x.Id,
                        Name = x.Name,
                        Template = x.Template.GetSafeString(),
                        UIAct = ""
                    }).ToList();
                }
                ret.Reports.AddRange(rpts);
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetReportDatasetReply GetReportDataset()
        {
            var ret = new GetReportDatasetReply();
            try
            {
                var rpts = new List<ReportDataset>();
                using (var ctx = new RGSContext())
                {
                    rpts = ctx.LkpReportDataset.Select(x => new ReportDataset
                    {
                       Id = x.Id,
                       SProc = x.Sproc.GetSafeString(),
                       SqlStr = x.SqlStr.GetSafeString(),
                       UIAct = ""
                    }).ToList();
                }
                ret.ReportDatasets.AddRange(rpts);
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetReportDatasetViewReply GetReportDatasetView()
        {
            var ret = new GetReportDatasetViewReply();
            try
            {
                var rpts = new List<ReportView>();
                using (var ctx = new RGSContext())
                {
                    var vwrpts = ctx.VwClientReport.ToList();
                    var dsparams = ctx.LkpReportDatasetParameter.ToList();

                    rpts = vwrpts.Select(x => new ReportView
                    {
                       ReportId = x.ReportId,
                       ReportName = x.ReportName
                    }).Distinct().ToList();
                    foreach(var rpt in rpts)
                    {
                        var dss = vwrpts.Where(x => x.ReportId == rpt.ReportId).Select(x => new ReportDatasetView
                        {
                            DatasetId = x.DatasetId,
                            DatasetName = x.Sproc
                        }).Distinct().ToList();
                        foreach(var ds in dss)
                        {
                            var dsps = dsparams.Where(x => x.DataSetId == ds.DatasetId && x.Direction == "Input")
                                .Select(x => new ReportDatasetParameter
                                {
                                    Id = x.Id,
                                    DataSetId = x.DataSetId.GetSafeValue(),
                                    DataType = x.DataType,
                                    DBName = x.Dbname,
                                    ReportName = x.ReportName.GetSafeString(),
                                    DefaultValue = x.DefaultValue.GetSafeString(),
                                    Direction = x.Direction,
                                    PivotDirection = x.PivotDirection.GetSafeString(),
                                    ForReportName = x.ForReportName.GetValueOrDefault(),
                                    MaxLen = x.MaxLen.GetValueOrDefault(),
                                    Nullable = x.Nullable ? 1 : 0,
                                    Value = "",
                                    UIAct = "",
                                    Idx = x.Idx ?? 0
                                }).Distinct().ToList();
                            ds.ReportDatasetParameters.AddRange(dsps);
                        }
                        rpt.ReportDatasetViews.AddRange(dss);
                    }
                    ret.ReportViews.AddRange(rpts);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetReportDatasetParameterReply GetReportDatasetParameter(int id)
        {
            var ret = new GetReportDatasetParameterReply();
            try
            {
                var rpts = new List<ReportDatasetParameter>();
                using (var ctx = new RGSContext())
                {
                    rpts = ctx.LkpReportDatasetParameter.Where(x => x.DataSetId == id)
                           .Select(x => new ReportDatasetParameter
                           {
                               Id = x.Id,
                               DataSetId = x.DataSetId.GetSafeValue(),
                               DataType = x.DataType,
                               DBName = x.Dbname,
                               ReportName = x.ReportName.GetSafeString(),
                               DefaultValue = x.DefaultValue.GetSafeString(),
                               Direction = x.Direction,
                               PivotDirection = x.PivotDirection.GetSafeString(),
                               ForReportName = x.ForReportName.GetValueOrDefault(),
                               MaxLen = x.MaxLen.GetValueOrDefault(),
                               Nullable = x.Nullable ? 1 : 0,
                               Value = "",
                               UIAct = "",
                               Idx = x.Idx ?? 0
                           }).OrderByDescending(x => x.Id).ToList();
                }
                ret.ReportDatasetParameters.AddRange(rpts);
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetReportPageReply GetReportPage(int id)
        {
            var ret = new GetReportPageReply();
            try
            {
                var rpts = new List<ReportPage>();
                using (var ctx = new RGSContext())
                {
                    rpts = ctx.LkpReportPage.Where(x => x.ReportId == id)
                        .Select(x => new ReportPage
                        {
                           Id = x.Id,
                           DatasetId = x.DatasetId.GetSafeValue(),
                           ReportId = x.ReportId,
                           IsPivot = x.IsPivot ? 1 : 0,
                           PageName = x.PageName.GetSafeString(),
                           PageNum = x.PageNum.GetSafeValue(),
                           Template = x.Template.GetSafeString(),
                           UIAct = ""
                        }).ToList();
                }
                ret.ReportPages.AddRange(rpts);
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetClientReportReply GetClientReport(int id)
        {
            var ret = new GetClientReportReply();
            try
            {
                var rpts = new List<ClientReport>();
                var clns = new List<LkpClients>();

                using(var appctx = new ApplicationConfigurationContext())
                {
                    clns = appctx.LkpClients.Where(x => x.Active).ToList();
                }
                using (var ctx = new RGSContext())
                {
                    rpts = ctx.XrefClientReport.Where(x => x.ReportId == id).Include(x => x.Report).ToList()
                        .Select(x => new ClientReport
                        {
                            Active = x.Active ? 1 : 0,
                            ClientId = x.ClientId,
                            Id = x.Id,
                            Delimiter = x.Delimiter.GetSafeString(),
                            Holiday = x.Holiday.GetSafeString(),
                            ReportId = x.ReportId,
                            ClientName = clns.Single(y => y.ClientId == x.ClientId).ClientDisplayName,
                            ReportName = x.Report.Name
                        }).ToList();
                }
                ret.ClientReports.AddRange(rpts);
                ret.ClientReports.AddRange(clns.Where(x => !rpts.Any(y => x.ClientId == y.ClientId)).Select(x => new ClientReport
                {
                    Active = 0,
                    ClientId = x.ClientId,
                    Id = 0,
                    Delimiter = "",
                    Holiday = "",
                    ReportId = id,
                    ClientName = x.ClientDisplayName,
                    ReportName = ""
                }).ToList());
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetReportRunHistReply GetReportRunHistByClient(int id)
        {
            var ret = new GetReportRunHistReply();
            try
            {
                var rpts = new List<ReportRunHist>();
                using (var ctx = new RGSContext())
                {
                    rpts = ctx.VwReportRunHist.Where(x => x.ClientId == id)
                           .Select(x => new ReportRunHist
                           {
                               Id = x.Id,
                               AppName = x.AppName,
                               ClassName = x.ReportId.ToString(),
                               DatasetsParameters = x.DatasetsParameters.GetSafeString(),
                               FilePath = x.FileFullPath.GetSafeString(),
                               JobParameters = x.JobParameters.GetSafeString(),
                               JobStatusId = x.JobStatusId,
                               JobId = x.JobId,
                               Message = x.Message.GetSafeString(),
                               RunBy = x.RunBy,
                               Status = x.Status,
                               TimeStart = x.TimeStart.GetSafeDateTimeString(),
                               TimeEnd = x.TimeEnd.GetSafeDateTimeString(),
                               ClientName = x.ClientDisplayName.GetSafeString(),
                               ReportName = x.ReportName
                           }).ToList();
                }
                ret.ReportRunHists.AddRange(rpts);
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetReportRunHistReply GetReportRunHistByReport(int id)
        {
            var ret = new GetReportRunHistReply();
            try
            {
                var rpts = new List<ReportRunHist>();
                using (var ctx = new RGSContext())
                {
                    rpts = ctx.VwReportRunHist.Where(x => x.ReportId == id)
                           .Select(x => new ReportRunHist
                           {
                               Id = x.Id,
                               AppName = x.AppName,
                               ClassName = x.ReportId.ToString(),
                               DatasetsParameters = x.DatasetsParameters.GetSafeString(),
                               FilePath = x.FileFullPath.GetSafeString(),
                               JobParameters = x.JobParameters.GetSafeString(),
                               JobStatusId = x.JobStatusId,
                               JobId = x.JobId,
                               Message = x.Message.GetSafeString(),
                               RunBy = x.RunBy,
                               Status = x.Status,
                               TimeStart = x.TimeStart.GetSafeDateTimeString(),
                               TimeEnd = x.TimeEnd.GetSafeDateTimeString(),
                               ReportName = x.ReportName,
                               ClientName = x.ClientDisplayName.GetSafeString()
                           }).ToList();
                }
                ret.ReportRunHists.AddRange(rpts);
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public GetReportRunHistReply GetReportRunHistByUser()
        {
            var ret = new GetReportRunHistReply();
            try
            {
                var rpts = new List<ReportRunHist>();
                var ucln = new List<XrefClientsUsers>();
                using(var appctx = new ApplicationConfigurationContext())
                {
                    ucln = appctx.XrefClientsUsers.Where(x => x.UserId == _user.UserId && !x.MarkedForDelete).ToList();
                }
                using (var ctx = new RGSContext())
                {
                    rpts = ctx.VwReportRunHist.ToList().Where(x => string.IsNullOrEmpty(x.ClientDisplayName) || ucln.Any(y => y.ClientId == x.ClientId))
                           .Select(x => new ReportRunHist
                           {
                               Id = x.Id,
                               AppName = x.AppName,
                               ClassName = x.ReportId.ToString(),
                               DatasetsParameters = x.DatasetsParameters.GetSafeString(),
                               FilePath = x.FileFullPath.GetSafeString(),
                               JobParameters = x.JobParameters.GetSafeString(),
                               JobStatusId = x.JobStatusId,
                               JobId = x.JobId,
                               Message = x.Message.GetSafeString(),
                               RunBy = x.RunBy,
                               Status = x.Status,
                               TimeStart = x.TimeStart.GetSafeDateTimeString(),
                               TimeEnd = x.TimeEnd.GetSafeDateTimeString(),
                               ReportName = x.ReportName,
                               ClientName = x.ClientDisplayName.GetSafeString(),
                               FileName = Path.GetFileName(x.FileFullPath.GetSafeString()),
                           }).ToList();
                }
                ret.ReportRunHists.AddRange(rpts);
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public MessageReply SaveReport(Report rpt)
        {
            var ret = new MessageReply { Id = 0, Message = Constant.Success };

            try
            {
                using (var ctx = new RGSContext())
                {
                    if(rpt.Id == 0)
                    {
                        var temp = new LkpReport
                        {
                            Id = 0,
                            Active = true,
                            CreatedBy = _user.UserId,
                            DateCreated = DateTime.Now,
                            DateUpdated = DateTime.Now,
                            Destination = rpt.Destination,
                            FileName = rpt.FileName,
                            Name = rpt.Name,
                            Template = rpt.Template,
                            UpdatedBy = _user.UserId,
                        };
                        ctx.LkpReport.Add(temp);
                        ctx.SaveChanges();
                        ret.Id = temp.Id;
                    } else
                    {
                        var temp = ctx.LkpReport.Single(x => x.Id == rpt.Id);
                        temp.Active = rpt.Active == 1;
                        temp.DateUpdated = DateTime.Now;
                        temp.Destination = rpt.Destination;
                        temp.FileName = rpt.FileName;
                        temp.Name = rpt.Name;
                        temp.Template = rpt.Template;
                        temp.UpdatedBy = _user.UserId;
                        ctx.SaveChanges();
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public MessageReply SaveReportDataset(ReportDataset ds)
        {
            var ret = new MessageReply { Id = 0, Message = Constant.Success };

            try
            {
                using (var ctx = new RGSContext())
                {
                    if(ds.Id == 0)
                    {
                        var temp = new LkpReportDataset
                        {
                            Id = 0,
                            CreatedBy = _user.UserId,
                            DateCreated = DateTime.Now,
                            DateUpdated = DateTime.Now,
                            Sproc = ds.SProc,
                            SqlStr = ds.SqlStr,
                            UpdatedBy = _user.UserId
                        };
                        ctx.LkpReportDataset.Add(temp);
                        ctx.SaveChanges();
                        ret.Id = temp.Id;
                    } else
                    {
                        var temp = ctx.LkpReportDataset.Single(x => x.Id == ds.Id);
                        if (ds.UIAct == "Delete")
                        {
                            ctx.LkpReportDataset.Remove(temp);
                        }
                        else
                        {
                            temp.DateUpdated = DateTime.Now;
                            temp.UpdatedBy = _user.UserId;
                            temp.Sproc = ds.SProc;
                            temp.SqlStr = ds.SqlStr;
                        }

                        ctx.SaveChanges();
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public MessageReply SaveReportDatasetParameter(ReportDatasetParameter req)
        {
            var ret = new MessageReply { Id = 0, Message = Constant.Success };

            try
            {
                using (var ctx = new RGSContext())
                {
                    if (req.Id == 0)
                    {
                        ctx.LkpReportDatasetParameter.Add(new LkpReportDatasetParameter
                        {
                            Id = 0,
                            CreatedBy = _user.UserId,
                            DateCreated = DateTime.Now,
                            DataSetId = req.DataSetId,
                            DataType = req.DataType,
                            DateUpdated = DateTime.Now,
                            Dbname = req.DBName,
                            DefaultValue = req.DefaultValue,
                            Direction = req.Direction,
                            ForReportName = req.ForReportName,
                            MaxLen = req.MaxLen,
                            Nullable = req.Nullable == 1,
                            PivotDirection = req.PivotDirection,
                            Idx = req.Idx,
                            ReportName = req.ReportName,
                            UpdatedBy = _user.UserId
                        });
                    }
                    else
                    {
                        var temp = ctx.LkpReportDatasetParameter.Single(x => x.Id == req.Id);

                        if (req.UIAct == "Delete")
                        {
                            ctx.LkpReportDatasetParameter.Remove(temp);
                        }
                        else
                        {
                            temp.DataType = req.DataType;
                            temp.DateUpdated = DateTime.Now;
                            temp.Dbname = req.DBName;
                            temp.DefaultValue = req.DefaultValue;
                            temp.Direction = req.Direction;
                            temp.ForReportName = req.ForReportName;
                            temp.MaxLen = req.MaxLen;
                            temp.Idx = req.Idx;
                            temp.Nullable = req.Nullable == 1;
                            temp.PivotDirection = req.PivotDirection;
                            temp.ReportName = req.ReportName;
                            temp.UpdatedBy = _user.UserId;
                        }
                    }
                    ctx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public MessageReply SaveReportDatasetParameter(SaveReportDatasetParameterRequest req)
        {
            var ret = new MessageReply { Id = 0, Message = Constant.Success };

            try
            {
                using (var ctx = new RGSContext())
                {
                    var temp = ctx.LkpReportDatasetParameter.Where(x => x.DataSetId == req.DatasetId).ToList();
                    if (req.ReportDatasetParameters.Count == 0)
                    {
                        ctx.LkpReportDatasetParameter.RemoveRange(temp);
                    } else
                    {
                        foreach(var del in temp)
                        {
                            if(!req.ReportDatasetParameters.Any(x => x.Id == del.Id))
                            {
                                ctx.LkpReportDatasetParameter.Remove(del);
                            }
                        }
                        foreach(var p in req.ReportDatasetParameters)
                        {
                            if(p.Id == 0)
                                ctx.LkpReportDatasetParameter.Add(new LkpReportDatasetParameter
                                {
                                    Id = 0,
                                    CreatedBy = _user.UserId,
                                    DateCreated = DateTime.Now,
                                    DataSetId = req.DatasetId,
                                    DataType = p.DataType,
                                    DateUpdated = DateTime.Now,
                                    Dbname = p.DBName,
                                    DefaultValue = p.DefaultValue,
                                    Direction = p.Direction,
                                    ForReportName = p.ForReportName,
                                    MaxLen = p.MaxLen,
                                    Nullable = p.Nullable == 1,
                                    PivotDirection = p.PivotDirection,
                                    ReportName = p.ReportName,
                                    UpdatedBy = _user.UserId,
                                    Idx = p.Idx
                                });
                            else
                            {
                                var temp1 = temp.Single(x => x.Id == p.Id);
                                temp1.DataType = p.DataType;
                                temp1.DateUpdated = DateTime.Now;
                                temp1.Dbname = p.DBName;
                                temp1.DefaultValue = p.DefaultValue;
                                temp1.Direction = p.Direction;
                                temp1.ForReportName = p.ForReportName;
                                temp1.MaxLen = p.MaxLen;
                                temp1.Nullable = p.Nullable == 1;
                                temp1.PivotDirection = p.PivotDirection;
                                temp1.ReportName = p.ReportName;
                                temp1.UpdatedBy = _user.UserId;
                                temp1.Idx = p.Idx;
                            }
                        }
                    }
                    ctx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public MessageReply SaveReportPage(SaveReportPageRequest req)
        {
            var ret = new MessageReply { Id = 0, Message = Constant.Success };

            try
            {
                using (var ctx = new RGSContext())
                {
                    var temp = ctx.LkpReportPage.Where(x => x.ReportId == req.ReportId).ToList();
                    if (req.ReportPages.Count == 0)
                    {
                        ctx.LkpReportPage.RemoveRange(temp);
                    }
                    else
                    {
                        foreach (var p in req.ReportPages)
                        {
                            if (p.Id == 0)
                            {
                                ctx.LkpReportPage.Add(new LkpReportPage
                                {
                                    Id = 0,
                                    CreatedBy = _user.UserId,
                                    DateCreated = DateTime.Now,
                                    DateUpdated = DateTime.Now,
                                    UpdatedBy = _user.UserId,
                                    DatasetId = p.DatasetId,
                                    IsPivot = p.IsPivot == 1,
                                    ReportId = p.ReportId,
                                    PageName = p.PageName,
                                    PageNum = p.PageNum,
                                    Template = p.Template
                                });
                            }
                            else
                            {
                                var temp1 = temp.Single(x => x.Id == p.Id);
                                if (p.UIAct == "Delete")
                                {
                                    ctx.LkpReportPage.Remove(temp1);
                                }
                                else
                                {
                                    temp1.DateUpdated = DateTime.Now;
                                    temp1.UpdatedBy = _user.UserId;
                                    temp1.IsPivot = p.IsPivot == 1;
                                    temp1.PageName = p.PageName;
                                    temp1.PageNum = p.PageNum;
                                    temp1.ReportId = p.ReportId;
                                    temp1.DatasetId = p.DatasetId;
                                    temp1.Template = p.Template;
                                }
                            }
                        }
                    }
                    ctx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public MessageReply SaveClientReport(SaveClientReportRequest req)
        {
            var ret = new MessageReply { Id = 0, Message = Constant.Success };

            try
            {
                using (var ctx = new RGSContext())
                {
                    var temp = ctx.XrefClientReport.Where(x => x.ReportId == req.ReportId).ToList();
                    if (req.ClientReports.Count == 0)
                    {
                        ctx.XrefClientReport.RemoveRange(temp);
                    }
                    else
                    {
                        foreach (var del in temp)
                        {
                            if (!req.ClientReports.Any(x => x.Id == del.Id))
                            {
                                ctx.XrefClientReport.Remove(del);
                            }
                        }
                        foreach (var p in req.ClientReports)
                        {
                            if (p.Id == 0)
                                ctx.XrefClientReport.Add(new XrefClientReport
                                {
                                    Id = 0,
                                    CreatedBy = _user.UserId,
                                    DateCreated = DateTime.Now,
                                    DateUpdated = DateTime.Now,
                                    UpdatedBy = _user.UserId,
                                    Active = p.Active == 1,
                                    ClientId = p.ClientId,
                                    Delimiter = p.Delimiter,
                                    Holiday = p.Holiday,
                                    ReportId = p.ReportId
                                });
                            else
                            {
                                var temp1 = temp.Single(x => x.Id == p.Id);
                                temp1.DateUpdated = DateTime.Now;
                                temp1.UpdatedBy = _user.UserId;
                                temp1.Active = p.Active == 1;
                                temp1.ClientId = p.ClientId;
                                temp1.Delimiter = p.Delimiter;
                                temp1.Holiday = p.Holiday;
                                temp1.ReportId = p.ReportId;
                            }
                        }
                    }
                    ctx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
        public MessageReply RunReport(RunReportRequest req)
        {
            var ret = new MessageReply { Id = 0, Message = Constant.Success };

            try
            {
                using (var ctx = new RGSContext())
                {

                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
    }
}
