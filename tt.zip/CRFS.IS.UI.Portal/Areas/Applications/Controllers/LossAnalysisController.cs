﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Grpc.Core;
using Google.Protobuf.WellKnownTypes;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.GRpc;
using CRFS.IS.UI.Portal.Models;
using CRFS.IS.UI.Portal.Extensions;

namespace CRFS.IS.UI.Portal.Areas.Applications.Controllers
{
    [Area("Applications")]
    [Authorize]
    public class LossAnalysisController : Controller
    {
        private readonly ILogger<LossAnalysisController> _logger;
        private readonly IConfiguration _config;
        public LossAnalysisController(ILogger<LossAnalysisController> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
        }

        [Authorize(Policy = "TokenExists")]
        [AuthAction(Constant.UIPrivilege.Read, "LossAnalysis")]
        public ActionResult Index()
        {
            var ug = SessionExtension.GetSessionUser(HttpContext);

            return View(ug);
        }
        public ActionResult GetLoanData(string loannumber)
        {
            var ret = new LoanData();

            if (string.IsNullOrEmpty(loannumber))
            {
                return Json(new { success = false, message = "Loan Number is needed" });
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);
                ret = client.GetLoan(new GetLoanRequest { LoanNumber = loannumber }, mdata);
                
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(new { success = true, data = ret }); 
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Write, "LossAnalysis")]
        public ActionResult SaveLoan(Models.SaveLoanViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                var msg = string.Join("; ", ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage));
                return View("_Success", new ResponseMessageViewModel { title = "", message = msg });
            }
            var ret = new MessageReply();
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);
                var loandata = new LoanData { 
                   BorrowerFirstName = vm.BorrowerFirstName.GetSafeString(),
                   BorrowerLastName = vm.BorrowerLastName.GetSafeString(),
                   BuyOutDate = vm.BuyOutDate.GetSafeString(),
                   ClaimTypeId = vm.ClaimTypeID,
                   ClientId = vm.ClientID,
                   CloseDate = vm.CloseDate.GetSafeString(),
                   ClosingReasonId = vm.ClosingReasonId.GetSafeValue<int>(),
                 //  DebentureInterestRate = vm.DebentureInterestRate,
                   FHACaseNumber = vm.FHACaseNumber,
                   LoanId = vm.LoanId,
                   InvestorId = vm.InvestorID.GetSafeValue<int>(),
                   LoanNumber = vm.LoanNumber,
                   LossAnalysisDueDate = vm.LossAnalysisDueDate.GetSafeString(),
                   LossAnalysisReferralDate = vm.LossAnalysisReferralDate.GetSafeString(),
                   NoteRate = vm.NoteRate.GetSafeValue<double>(),
                   PropertyCity = vm.PropertyCity.GetSafeString(),
                   PropertyLotSize = vm.PropertyLotSize.GetSafeValue<int>(),
                   PropertyStateId = vm.PropertyStateId.GetSafeValue<int>(),
                   PropertyStreetAddressLine1 = vm.PropertyStreetAddressLine1.GetSafeString(),
                   PropertyStreetAddressLine2 = vm.PropertyStreetAddressLine2.GetSafeString(),
                   PropertyZipCode = vm.PropertyZipCode.GetSafeString(),
                   ServiceTransferDate = vm.ServiceTransferDate.GetSafeString(),
                   StatusId = vm.StatusId.GetSafeValue<int>(),
                   StatusDate = vm.StatusDate.GetSafeString()
                };

                ret = client.SaveLoan(loandata, mdata);
                if(ret.Message == Constant.Success)
                    return View("_Success", new ResponseMessageViewModel { title = "Success", message = "Data Saved" }); 
                else
                    return View("_Success", new ResponseMessageViewModel { title = "", message = ret.Message });
            }
            catch (Exception ex)
            {
                return View("_Success", new ResponseMessageViewModel { title = "", message = ex.Message });
            }
            
        }
        [AuthAction(Constant.UIPrivilege.Read, "LossAnalysis")]
        public ActionResult GetKeyValueList(string name, string id)
        {
            var ret = new List<KeyValuePair<string, string>>();

            var channel = ChannelHelper.GetChannel(_config);
            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };

            try
            {
                var client = new Common.CommonClient(channel);
                var reply = client.GetKeyValueList(new GetKeyValueListRequest
                    {
                        Type = name,
                        Id = string.IsNullOrEmpty(id) ? "" : id
                    }, mdata);
                foreach(var kv in reply.KVList)
                {
                    ret.Add(new KeyValuePair<string, string>(kv.Key, kv.Value));
                }
            }
            catch(Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(new { success = true, data = ret });
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Write, "LossAnalysis")]
        public ActionResult SaveMilestone(Models.SaveMilestoneViewModel vm)
        {

            if (!ModelState.IsValid)
            {
                var msg = string.Join("; ", ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage));
                return View("_Success", new ResponseMessageViewModel { title = "", message = msg });
            }
            var ret = new MessageReply();
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };

            var commonclient = new Common.CommonClient(channel);

            var reply = commonclient.GetKeyValueList(new GetKeyValueListRequest
            {
                Type = "LAMILESTONE",
                Id = "0"
            }, mdata);
            var lms = new List<KeyValuePair<string, string>>();
            foreach(var l in reply.KVList)
            {
                lms.Add(new KeyValuePair<string, string>(l.Key, l.Value));
            }
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);
                var loanms = new Milestone
                {
                    LoanId = vm.LoanId,
                    MilestoneDate = DateTime.Now.ToString(Constant.DateTimeString),
                    LoanMilestoneId = 0
          
                };
                if(vm.PartAAnalystId > 0)
                {
                    loanms.MilestoneId = Convert.ToInt32(lms.Where(x => x.Value == "Part-A Assignment").Select(x => x.Key).Single());
                    loanms.AssignedUserId = vm.PartAAnalystId;
                }
                ret = client.SaveMilestone(loanms, mdata);
                if (vm.PartBAnalystId > 0)
                {
                    loanms.MilestoneId = Convert.ToInt32(lms.Where(x => x.Value == "Part-B Assignment").Select(x => x.Key).Single());
                    loanms.AssignedUserId = vm.PartBAnalystId;
                }
                ret = client.SaveMilestone(loanms, mdata);
            }
            catch (Exception ex)
            {
                return View("_Success", new ResponseMessageViewModel { title = "", message = ex.Message });
            }
            return View("_Success", new ResponseMessageViewModel { title = "Success", message = "Data Saved"}); ;
        }
    }
}