﻿
namespace CRFS.IS.Service.Common.TransferObjects
{
    public class ElementDataDTO
    {
        public string TableName { get; set; }
        public string Action { get; set; }
        public string PId { get; set; }
        public string PName { get; set; }
        public bool Incl { get; set; }
        public Sort[] Sorts { get; set; }
        public EleRowDTO[] DataElements { get; set; }
        public ElementDataDTO()
        {
            DataElements = new EleRowDTO[] { };
            Sorts = new Sort[] { };
        }
    }
    public class EleRowDTO
    {
        public string RowId { get; set; }
        public string UIName { get; set; }
        public string DataType { get; set; }
        public string DataValue { get; set; }
        public string DefValue { get; set; }
        public bool Nullable { get; set; }
        public string DBName { get; set; }
        public bool IsKey { get; set; }
        public bool IsIden { get; set; }
        public bool ReserveOriginal { get; set; }
    }
    public class Sort
    {
        public string ColName { get; set; }
        public bool Asc { get; set; }
    }
    public class Filter
    {
        public string ColName { get; set; }
        public string DataType { get; set; }
        public string Value { get; set; }
        public string Oper { get; set; }
    }
}
