﻿using System.Collections.Generic;

namespace CRFS.IS.Service.Common.TransferObjects
{
    public class ElementRequestDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string NameType { get; set; }
        public int PageNum { get; set; }
        public int RowsPerPage { get; set; }
        public List<Filter> Filters { get; set; }
        public List<Sort> Sorts { get; set; }
      
        public ElementRequestDTO()
        {
            Filters = new List<Filter>();
            Sorts = new List<Sort>();
        }
    }
}
