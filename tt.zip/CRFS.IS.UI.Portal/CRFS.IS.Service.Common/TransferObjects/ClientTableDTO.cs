﻿using System.Collections.Generic;

namespace CRFS.IS.Service.Common.TransferObjects
{
    public class ClientTableDTO
    {
        public string Name { get; set; }
        public string TType { get; set; }
        public ClientTableColumn[] Cols { get; set; }
        public ClientTableDTO()
        {
            Cols = new ClientTableColumn[] { };
        }
    }
    public class ClientTableColumn
    {
        public string Name { get; set; }
        public string DataType { get; set; }
        public bool IsKey { get; set; }
        public int KeyIdx { get; set; }
        public bool IsNullable { get; set; }
        public bool HasDefaultValue { get; set; }
        public int MaxLength { get; set; }
    }

}

