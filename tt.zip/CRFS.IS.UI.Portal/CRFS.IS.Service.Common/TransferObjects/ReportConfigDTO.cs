﻿using System.Collections.Generic;

namespace CRFS.IS.Service.Common.TransferObjects
{
    public class ReportConfigDTO
    {
        public int id { get; set; }
        public string nm { get; set; }
        public int said { get; set; }
        public string sanm { get; set; }
        public string desc { get; set; }
        public string media { get; set; }
        public string dlm { get; set; }
        public string pntsz { get; set; }
        public string pntori { get; set; }
        public List<ReportQueryDTO> qrys { get; set; }
        public List<ReportElementDTO> eles { get; set; }
        public ReportConfigDTO()
        {
            qrys = new List<ReportQueryDTO>();
            eles = new List<ReportElementDTO>();
        }
    }
    public class ReportQueryDTO
    {
        public int id { get; set; }
        public int dtcid { get; set; }
        public int idx { get; set; }
        public int rid { get; set; }
        public List<ReportQueryParamDTO> pms { get; set; }
        public ReportQueryDTO()
        {
            pms = new List<ReportQueryParamDTO>();
        }
    }
    public class ReportQueryParamDTO
    {
        public int qid { get; set; }
        public string nm { get; set; }
        public string op { get; set; }
    }
    public class ReportQueryParamValueDTO
    {
        public int qid { get; set; }
        public string nm { get; set; }
        public string value { get; set; }
    }
    public class ReportElementDTO
    {
        public int id { get; set; }
        public string iconid { get; set; }
        public int rid { get; set; }
        public string nm { get; set; }
        public string piconid { get; set; }
        public string typ { get; set; }
        public string sz { get; set; }
        public string pos { get; set; }
        public int ep { get; set; }
        public int qryid { get; set; }//qry idx
        public string colnm { get; set; }
        public string fmt { get; set; }
        public string ffm { get; set; }
        public string fwt { get; set; }
        public float fsz { get; set; }
        public string fcl { get; set; }
        public int bgimg { get; set; }
        public string bgcl { get; set; }
        public string bd { get; set; }
        public int bdwt { get; set; }
        public string bdcl { get; set; }
        public string bdsty { get; set; }
        public ReportFooterDTO ft { get; set; }
        public ReportTextDTO txt { get; set; }
        public List<ReportTableColumnDTO> tblcols { get; set; }
        public ReportElementDTO()
        {
            tblcols = new List<ReportTableColumnDTO>();
        }
    }
    
    public class ReportFooterDTO
    {
        public int eid { get; set; }
        public string pna { get; set; }
        public string ts { get; set; }
    }
    
    public class ReportTextDTO
    {
        public int eid { get; set; }
        public string alg { get; set; }
        public string cnt { get; set; }
        public string ts { get; set; }
        public string fund { get; set; }
    }
    public class ReportTableColumnDTO
    {
        public int id { get; set; }
        public int tid { get; set; }
        public string nm { get; set; }
        public string dbnm { get; set; }
        public int idx { get; set; }
        public int wt { get; set; }
        public string align { get; set; }
        public string fmt { get; set; }
        public string ftyp { get; set; }
        public string ftxt { get; set; }
    }
}
