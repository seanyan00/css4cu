﻿using System;

namespace CRFS.IS.Service.Common
{
    public static class Constant
    {
        public const int MB = 1048576;
        public const string DOMAIN = "crfs.crfservices.com";
        public enum UIPrivilege
        {
            None = 0,
            Read,
            Write,
            Delete,
            Admin
        }       
    }
}
