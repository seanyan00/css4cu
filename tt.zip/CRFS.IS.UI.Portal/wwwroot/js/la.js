﻿var lossanalysis = {
    data: {
        dirty: false,
        lauserlist: {}, //{0:'Zero';1:'One'}
        investorlist: {},
        claimtypelist: {},
        milestonelist: {},
        closereasonlist: {},
        loans: [],
        head: {
            dirty: false
        }, 
        loan: {},
        parta: { faction: {
                            dirty: false,
                            lastselectedrow: 0,
                            restartreasonlist: "Bankruptcy: Bankruptcy;Porforminglossmit:Performing LossMit; Court Delays: Court Delays",
                            typelist: "Judical:Judical",
                            testdata: [
                                { Id: "1", FirstLegalDate: "01/30/2020", RestartValidity: "Invalid", RestartReason: "Court Delays", SFDMSCode68Date: "", ActionType: "Judical", Comments: ""},
                                { Id: "2", FirstLegalDate: "01/29/2020", RestartValidity: "Valid", RestartReason: "", SFDMSCode68Date: "", ActionType: "", Comments: ""}
                            ]
        }, oextension: {
                dirty: false,
                lastselectedrow: 0,
                data: []
            },
            bankruptcy: {
                dirty: false,
                lastselectedrow: 0,
                bankruptcytypelist: "",
                data: []
            },
            lossmit: {
                dirty: false,
                lastselectedrow: 0,
                lossmittypelist: "",
                codelist: "",
                data: []
            },
            eaction: {
                dirty: false,
                lastselectedrow: 0,
                data: []
            },
            odelay: {
                dirty: false,
                lastselectedrow: 0,
                typelist: [],
                data: []
            }
        },
        partb: {
                dirty: false,
                lastselectedrow: 0,
                categorylist: "",
                subcategorylist: "",
                advaccountlist: "",
                responsiblepartylist: "",
                chargeoffreasonlist: "",
                data: []
        },
        completedclaim: {
            parta: {
                dirty: false,
                occupancystatuslist: {}
            },
            aop: {
                dirty: false
            },
            partb: {
                dirty: false
            }
        },
        reconciliation: {
            categorylist: "",
            subcategorylist: "",
            supprecovery: {
                lastselectedrow: 0,
                data: []
            },
            supprefund: {
                lastselectedrow: 0,
                data: []
            }
        },
        workflow: {
            lastselectedrow: 0,
            milestonelist: "",
            milestonestatuslist: "",
            data: []
        },
        import: {
            data: [],
            error: [],
            files: null
        }
    },
    init: function () {
        $(".btn-collapse").click(function () {
            var $span = $(this).find("span");
            if ($span.hasClass("glyphicon-triangle-top")) {
                $span.removeClass("glyphicon-triangle-top");
                $span.addClass("glyphicon-triangle-bottom");
            } else {
                $span.removeClass("glyphicon-triangle-bottom");
                $span.addClass("glyphicon-triangle-top");
            }
        });
        $("select, input:checkbox, input:text", "form").on("change input click", function () {
            home.clearinfo();
        });
        //TODO: reminder dirty tab #############################
        $("#tb_completedclaim").on("shown.bs.tab", function (e) {
            lossanalysis.data.completedclaim.parta.occupancystatuslist = lossanalysis.loadlisttolocal("occupancystatus", "");
            lossanalysis.initialcompletedclaim();
        });
        $("#tb_parta").on("shown.bs.tab", function (e) {
            lossanalysis.loadfactiongrid(e);
            lossanalysis.loadoextensiongrid(e);
            lossanalysis.loadbankruptcygrid(e);
            lossanalysis.loadlossmitgrid(e);
            lossanalysis.loadeactiongrid(e);
            lossanalysis.loadodelaygrid(e);
        });
        $("#tb_partb").on("shown.bs.tab", function (e) {
            lossanalysis.loadpartbexpgrid(e);
        });
        $("#tb_recon").on("shown.bs.tab", function (e) {
            lossanalysis.loadreconrecoverygrid(e);
            lossanalysis.loadreconrefundgrid(e);
        });
        $("#tb_workflow").on("shown.bs.tab", function (e) {
            lossanalysis.loadworkflowgrid(e);
        });
        $("#tb_import").on("shown.bs.tab", function (e) {
            lossanalysis.loadimporthistgrid(e);
        });
        $("#btn_head_edit").click(function (e) {
            var $panel = $(e.target).closest(".panel").find(".panel-body");
            $(".toggle-title", $panel).hide();
            $(".toggle-input", $panel).show();

            var divs = $("div.toggle-title", $panel);
            $.each(divs, function () {
                var $this = $(this);
                var text = $this.find("label").text();
                var $input = $this.siblings("div.toggle-input").find("input");
                var $select = $this.siblings("div.toggle-input").find("select");
                if ($input.length === 1) 
                    $input.val(text);
                if ($select.length === 1) {
                    $select.find("option").filter(function () {
                        return $(this).text() == text;
                    }).prop('selected', true);
                }
            })
        });
        $("#btn_head_cancel").click(function (e) {
            lossanalysis.data.head.dirty = false;

            var $panel = $(e.target).closest(".panel").find(".panel-body");
            $(".toggle-input", $panel).hide();
            $(".toggle-title", $panel).show();
        });
        $("#btn_head_save").click(function (e) {
            var $panel = $(e.target).closest(".panel").find(".panel-body");
            $(".toggle-input", $panel).hide();
            $(".toggle-title", $panel).show();

            var divs = $("div.toggle-title", $panel);
            $.each(divs, function () {
                var $this = $(this);
                var $input = $this.siblings("div.toggle-input").find("input");
                var $select = $this.siblings("div.toggle-input").find("select");
                if ($input.length === 1)
                    $this.find("label").text($input.val());
                if ($select.length === 1) {
                    $this.find("label").text($select.find("option:selected").text());
                }
            });
            if (lossanalysis.data.head.dirty) {
                $("#fm_la_pagehead").find("button[type='submit']").trigger("click");
                lossanalysis.data.head.dirty = false;
            }
        });
        $("#dv_la_import_dropzone").on("dragenter", function (e) {
            e.preventDefault();
            e.stopPropagation();
        });
        $("#dv_la_import_dropzone").on("dragover", function (e) {
            e.preventDefault();
            e.stopPropagation();
        });
        $("#dv_la_import_dropzone").on("drop", function (e) {
            e.preventDefault();
            e.stopPropagation();
            lossanalysis.data.import.files = e.originalEvent.dataTransfer.files;
            if (lossanalysis.data.import.files.length > 0) {
                var html = "<div class='file-drop-icon'>" + lossanalysis.data.import.files[0].name + "</div";
                $(e.target).append(html);
            }
        });
        $("#fm_la_import").submit(function (e) {
            e.preventDefault();
            var $this = $(this);
            var data = null;
            if (lossanalysis.data.import.files !== null) {
                data = new FormData();
                data.append(lossanalysis.data.import.files[0].name, lossanalysis.data.import.files);
            } else {
                data = new FormData(this);
            }
            home.showloading();
            $.ajax({
                type: $this.attr('method'),
                url: $this.attr('action'),
                data: data,
                contentType: false,
                processData: false
            }).done(function (data) {
                home.removeloading();
                home.showinfo(data.message, !data.success);
            }).fail(ajaxFailed);
        });
        $("#btn_loan_search").on("click", function (e) {
            var loannumber = $("#txt_search_loannumber").val();
            $.ajax({
                url: getLoanDataUrl + "?loannumber=" + loannumber,
                dataType: "json",
                cache: false
            }).done(function (data) {
                if (data.success) {
                    lossanalysis.loadloandata(data.data);
                }
            }).fail(ajaxFailed);
        });
        $("#dv_loan_sum").on("change", " select", function (e) {
            lossanalysis.data.head.dirty = true;
        });
        $("#dv_loandetail").on("change click", "input[type='text'], select", function (e) {
            lossanalysis.data.loan.dirty = true;
        });
        $("#btn_loandetail_cancel").click(function () {
            lossanalysis.data.loan.dirty = false;
        });
        this.initialloanddls();
    },
    initialloanddls: function () {
        this.loadloanlist();
        lossanalysis.data.lauserlist = this.loadlisttolocal("lauser", "");
        lossanalysis.data.investorlist = this.loadlisttolocal("lainvestor", "");
        lossanalysis.data.claimtypelist = this.loadlisttolocal("laclaimtype", "");
        lossanalysis.data.milestonelist = this.loadlisttolocal("lamilestone", "");
        lossanalysis.data.closereasonlist = this.loadlisttolocal("laclosereason", "");

        this.getddlhtmlfromlist("ddl_partaanalyst", lossanalysis.data.lauserlist, 1);
        this.getddlhtmlfromlist("ddl_partbanalyst", lossanalysis.data.lauserlist, 1);
        this.getddlhtmlfromlist("ddl_investor", lossanalysis.data.investorlist, 1);
        this.getddlhtmlfromlist("ddl_claimtype", lossanalysis.data.claimtypelist, 1);
        this.getddlhtmlfromlist("ddl_loanstatus", lossanalysis.data.milestonelist, 1);
        this.getddlhtmlfromlist("ddl_closereason", lossanalysis.data.closereasonlist, 1);
    },
    initialcompletedclaim: function () {

    },
    loadloanlist: function () {
        $.ajax({
            url: getKeyValueListUrl + "?name=laloan&id=",
            dataType: "json",
            async: false
        }).done(function (data) {
            if (data.success) {
                lossanalysis.data.loans = [];
                $.each(data.data, function () {
                    lossanalysis.data.loans.push({ value: this.Value, data: this.Key });
                });
                $('.autocomplete').autocomplete({
                    lookup: lossanalysis.data.loans/*,
                    onSelect: function (p) {
                        $("#hdn_search_loannumber").val(p.data);
                    }*/
                });
            }
        }).fail(ajaxFailed);
    },
    loadlisttolocal: function (p, p1) {
        var ret = {};
        $.ajax({
            url: getKeyValueListUrl + "?name=" + p + "&id=" + p1,
            dataType: "json",
            async: false
        }).done(function (data) {
            if (data.success) {
                $.each(data.data, function () {
                    ret[this.Key] = this.Value;
                });
            }
        }).fail(ajaxFailed);
        return ret;
    },
    getddlhtmlfromlist: function (p, p1, p2) {
        var html = "";
        if (p2 === 1)
            html += "<option value=''></option>";

        $.each(p1, function (key, value) {
            html += "<option value='" + key + "'>" + value + "</option>"; 
        });
        $("#" + p).html(html);
    },
    loadloandata: function (p) {
        $("input:hidden[id^='hdn_loanid']").val(p.loanId);
        $("#lb_loannumber").text(p.loanNumber);
        $("#lb_fhacasenumber").text(p.fhaCaseNumber);
        $("#lb_clientname").text(p.clientName);
        $("#hdn_clientid").val(p.clientId);
        $("#hdn_partaanalystid").val(p.partAAnalystId);
        $("#hdn_partbanalystid").val(p.partBAnalystId);
        $("#lb_claimtypename").text(p.claimTypeName);
        $("#lb_partaanalystname").text(p.partAAnalystName);
        $("#lb_partbanalystname").text(p.partBAnalystName);
        $("#lb_statusname").text(p.statusName);
        $("#lb_completedate").text(p.completeDate);
        $("#lb_partacompletedate").text(p.partACompleteDate);
        $("#lb_partbcompletedate").text(p.partBCompleteDate);
        $("#lb_closereasonname").text(p.closingReasonName);
        $("#lb_referraldate").text(p.lossAnalysisReferralDate);
        $("#lb_duedate").text(p.lossAnalysisDueDate);

        $("#lb_loannumber_1").text(p.loanNumber);
        $("#hdn_loannumber").val(p.loanNumber);
        $("#hdn_fhacasenumber").val(p.fhaCaseNumber);
        $("#hdn_borrowerfirstname").val(p.borrowerFirstName);
        $("#hdn_borrowerlastname").val(p.borrowerLastName);
        $("#hdn_propertaddress1").val(p.propertyStreetAddressLine1);
        $("#hdn_propertycity").val(p.propertyCity);
        $("#hdn_propertyzipcode").val(p.propertyZipCode);

        $("#lb_firstname").text(p.borrowerFirstName);
        $("#lb_lastname").text(p.borrowerLastName);
        $("#lb_propertyaddress").text(p.propertyStreetAddressLine1);
        $("#lb_propertycity").text(p.propertyCity);
        $("#lb_propertystatename").text(p.propertyStateName);
        $("#hdn_propertystateid").val(p.propertyStateId);
        $("#lb_propertyzipcode").text(p.propertyZipCode);
        $("#ddl_investor").val(p.investorId);
        $("#ddl_claimtype").val(p.claimTypeId);
        $("#ddl_loanstatus").val(p.statusId);
        $("#txt_statusdate").val(p.statusDate);
        $("#txt_duedate").val(p.lossAnalysisDueDate);
        $("#txt_referraldate").val(p.lossAnalysisReferralDate);
        $("#txt_buyoutdate").val(p.buyOutDate);
        $("#txt_servicetransferdate").val(p.serviceTransferDate);
       // $("#txt_debentureinterestrate").val(p.debentureInterestRate);
        $("#txt_noterate").val(p.noteRate);
        $("#txt_lotsize").val(p.propertyLotSize);
        $("#txt_completedate").val(p.closeDate);
        $("#ddl_closereason").val(p.closingReasonId);
    },
    editrowfaction: function (p) {
        var $grid = $("#tbl_parta_faction");
        if (p && p !== lossanalysis.data.parta.faction.lastselectedrow) {
            $grid.jqGrid('restoreRow', lossanalysis.data.parta.faction.lastselectedrow);
            $grid.jqGrid('editRow', p, { keys: false }); /*key true enable Enter to save*/
            lossanalysis.data.parta.faction.lastselectedrow = p;
            $("#tbl_parta_faction_iledit", "#tbl_parta_faction_pager").trigger("click");
        } else {
            if (p == lossanalysis.data.parta.faction.lastselectedrow
                && $("#" + p, $grid).attr("editable") !== "1") {
                $grid.jqGrid('editRow', p, { keys: false });
                $("#tbl_parta_faction_iledit", "#tbl_parta_faction_pager").trigger("click");
            }
        }
    },
    enabledatepicker: function (p) {
        $(p).datepicker({
            format: 'mm/dd/yyyy',
            todayHighlight: true,
            autoclose: true
        }); 
    },
    loadfactiongrid: function (p) {
        $("#tbl_parta_faction").jqGrid({
            data: lossanalysis.data.parta.faction.testdata,
            datatype: "local",
            editurl: "clientArray",
            caption: "Foreclosure Action",
            colModel: [
                { label: "Id", name: "Id", key: true, hidden: true },
                { label: "First Legal Date", name: 'FirstLegalDate', width: 100, editable: true, editoptions: {  size: 20, dataInit: lossanalysis.enabledatepicker }},
                { label: "Restart Validity", name: 'RestartValidity', width: 140, editable: true, edittype: "select", formatter: "select", editoptions: { value: "Invalid:Invalid;Invalid:Valid" } },
                {
                    label: "Restart Reason", name: 'RestartReason', width: 100, editable: true, formatter: "select", formatoptions: { value: lossanalysis.data.parta.faction.restartreasonlist },
                        edittype: "select", editoptions: { value: lossanalysis.data.parta.faction.restartreasonlist }
                    
                },
                { label: "SFDMS Code 68 Date", name: 'SFDMSCode68Date', width: 120, editable: true, editoptions: { size : 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "Action Type", name: "ActionType", width: 100, editable: true, formatter: "select", formatoptions: {
                        value: lossanalysis.data.parta.faction.typelist
                    },
                        edittype: "select", editoptions: { value: lossanalysis.data.parta.faction.typelist } },
                { label: "Comments", name: "Comments", width: 200, editable: true}
            ],
            loadonce: true,
            autowidth: true,
            viewrecords: true,
            onSelectRow: lossanalysis.editrowfaction, 
            height: 200,
            rowNum: 10,
            pager: "#tbl_parta_faction_pager"

        });
        $("#tbl_parta_faction").navGrid("#tbl_parta_faction_pager", {
            add: false, edit: false, search: false, refresh: false/*,
            beforeRefresh: home.onbeforerefresh*/
        });
        $("#tbl_parta_faction").inlineNav("#tbl_parta_faction_pager", {});
            /*saveAfterSelect: true
            add: true, edit: true, cancel: true, resotrAfterSelect: false });*/
    },
    editrowoextension: function (p) {
        var $grid = $("#tbl_parta_oextension");
        if (p && p !== lossanalysis.data.parta.oextension.lastselectedrow) {
            $grid.jqGrid('restoreRow', lossanalysis.data.parta.oextension.lastselectedrow);
            $grid.jqGrid('editRow', p, { keys: false }); /*key true enable Enter to save*/
            lossanalysis.data.parta.oextension.lastselectedrow = p;
            $("#tbl_parta_oextension_iledit", "#tbl_parta_oextension_pager").trigger("click");
        } else {
            if (p == lossanalysis.data.parta.oextension.lastselectedrow
                && $("#" + p, $grid).attr("editable") !== "1") {
                $grid.jqGrid('editRow', p, { keys: false });
                $("#tbl_parta_oextension_iledit", "#tbl_parta_oextension_pager").trigger("click");
            }
        }
    },
    loadoextensiongrid: function (p) {
        $("#tbl_parta_oextension").jqGrid({
            data: lossanalysis.data.parta.oextension.data,
            datatype: "local",
            editurl: "clientArray",
            caption: "Other Extensions",
            colModel: [
                { label: "Id", name: "Id", key: true, hidden: true },
                {label: "Type", name: "Type", editable: true, width: 80 },
                { label: "Request Date", name: 'RequestDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Extension Date", name: 'ExtensionDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "HUD Specified Ext Date(FEMA)", name: 'HUDSpecifiedExtDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "First Action Date", name: 'FirstActionDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Statute Start Date", name: 'StatuteDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Statute End Date", name: 'StatuteEndDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Start of Active Duty Date", name: 'StartOfActiveDutyDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Discharge Date", name: 'DischargeDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Hazard Claim Date", name: 'HazardClaimDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Hazard Claim Settlement Date", name: 'HazardClaimSettlementDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Date of Loss", name: 'DateOfLoss', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Sales Contract Approval Date", name: 'SalesContractApprovalDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } }
            ],
            loadonce: true,
            autowidth: true,
            viewrecords: true,
            hiddengrid: true,
            onSelectRow: lossanalysis.editrowoextension,
            height: 200,
            rowNum: 10,
            pager: "#tbl_parta_oextension_pager"

        });
        $("#tbl_parta_oextension").navGrid("#tbl_parta_oextension_pager", {
            add: false, edit: false, search: false, refresh: false/*,
            beforeRefresh: home.onbeforerefresh*/
        });
        $("#tbl_parta_oextension").inlineNav("#tbl_parta_oextension_pager", {});
    },
    editrowbankruptcy: function (p) {
        var $grid = $("#tbl_parta_bankruptcy");
        if (p && p !== lossanalysis.data.parta.bankruptcy.lastselectedrow) {
            $grid.jqGrid('restoreRow', lossanalysis.data.parta.bankruptcy.lastselectedrow);
            $grid.jqGrid('editRow', p, { keys: false }); /*key true enable Enter to save*/
            lossanalysis.data.parta.bankruptcy.lastselectedrow = p;
            $("#tbl_parta_bankruptcy_iledit", "#tbl_parta_bankruptcy_pager").trigger("click");
        } else {
            if (p == lossanalysis.data.parta.bankruptcy.lastselectedrow
                && $("#" + p, $grid).attr("editable") !== "1") {
                $grid.jqGrid('editRow', p, { keys: false });
                $("#tbl_parta_bankruptcy_iledit", "#tbl_parta_bankruptcy_pager").trigger("click");
            }
        }
    },
    loadbankruptcygrid: function (p) {
        $("#tbl_parta_bankruptcy").jqGrid({
            data: lossanalysis.data.parta.bankruptcy.data,
            datatype: "local",
            editurl: "clientArray",
            caption: "Bankruptcy",
            colModel: [
                { label: "Id", name: "Id", key: true, hidden: true },
                {
                    label: "Bankruptcy Type", name: 'BankruptcyType', width: 100, editable: true, formatter: "select", edittype: "select",
                    editoptions: { value: lossanalysis.data.parta.bankruptcy.bankruptcytypelist },
                    formatoptions: { value: lossanalysis.data.parta.bankruptcy.bankruptcytypelist }
                },
                { label: "Filed Date", name: 'FiledDate', width: 120, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Clearance Date", name: 'ClearanceDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "Order Granting Motion for Relief", name: 'OrderGrantingMotionForRelief', width: 100, editable: true, edittype: "select", formatter: "select",
                    editoptions: { value: "No:No;Yes:Yes" }
                },
                { label: "Motion for Relief Date", name: 'MotionForReliefDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "4001 Rule Waived", name: '4001RuleWaived', width: 100, editable: true, edittype: "select", formatter: "select",
                    editoptions: { value: "No:No;Yes:Yes" }
                },
                {
                    label: "Ruling", name: 'Ruling', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: {"discharged" : "Discharged", "dismissed" : "Dismissed"}},
                    editoptions: { value: { "discharged": "Discharged", "dismissed": "Dismissed" } }
                },
                { label: "Dismissal Date", name: 'DismissalDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Discharge Date", name: 'DischargeDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Attorney Provided Lift Date", name: 'AttorneyProvidedLiftDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "Closed Same Day as Discharge", name: 'Closed Same Day as Discharge', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                { label: "BK Completion Date", name: 'BKCompletionDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Days of Acceptable BK Completion", name: 'DaysOfAcceptableBKCompletion', width: 80, editable: true },
                {
                    label: "Were Delays Acceptable?", name: 'WereDelaysAcceptable', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                { label: "Forclosure First Action Date", name: 'ForeclosureFirstActionDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Case Number", name: 'CaseNumber', width: 100, editable: true, editoptions: { maxlength: 20 }},
                { label: "First Unacceptable Delay", name: 'FirstUnacceptableDelay', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } }
            ],
            loadonce: true,
            autowidth: true,
            viewrecords: true,
            onSelectRow: lossanalysis.editrowbankruptcy,
            height: 200,
            rowNum: 10,
            pager: "#tbl_parta_bankruptcy_pager"

        });
        $("#tbl_parta_bankruptcy").navGrid("#tbl_parta_bankruptcy_pager", {
            add: false, edit: false, search: false, refresh: false/*,
            beforeRefresh: home.onbeforerefresh*/
        });
        $("#tbl_parta_bankruptcy").inlineNav("#tbl_parta_bankruptcy_pager", {});
    },
    loadlossmitgrid: function (p) {
        $("#tbl_parta_lossmit").jqGrid({
            data: lossanalysis.data.parta.lossmit.data,
            datatype: "local",
            editurl: "clientArray",
            caption: "Loss Mitigation",
            colModel: [
                { label: "Id", name: "Id", key: true, hidden: true },
                {
                    label: "Type", name: 'Type', width: 100, editable: true, formatter: "select", edittype: "select", formoptions: {rowpos: 1, colpos: 1},
                    editoptions: { value: lossanalysis.data.parta.lossmit.lossmittypelist },
                    formatoptions: { value: lossanalysis.data.parta.lossmit.lossmittypelist }
                },
                {
                    label: "Code", name: 'Code', width: 100, editable: true, formatter: "select", edittype: "select", formoptions: { rowpos: 1, colpos: 2 },
                    editoptions: { value: lossanalysis.data.parta.lossmit.codelist },
                    formatoptions: { value: lossanalysis.data.parta.lossmit.codelist }
                },
                {
                    label: "Rpts to SFDMS", name: 'ReportsToSFDMS', width: 80, editable: true, edittype: "select", formatter: "select", formoptions: { rowpos: 2, colpos: 1 },
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                { label: "Rpts to SFDMS Date", name: 'ReportsToSFDMSDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 2, colpos: 2 }},
                {
                    label: "Doc Available", name: 'DocumentationAvailable', width: 80, editable: true, edittype: "select", formatter: "select", formoptions: { rowpos: 2, colpos: 3 },
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                { label: "Doc Signed Date", name: 'DocumentSignedDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 3, colpos: 1 } },
                { label: "Decision Date", name: 'DecisionDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 3, colpos: 2 } },
                {
                    label: "Plan Complete", name: 'PlanComplete', width: 80, editable: true, edittype: "select", formatter: "select", formoptions: { rowpos: 3, colpos: 3 },
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                { label: "Vacated Date", name: 'VacatedDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 4, colpos: 1 } },
                {
                    label: "Borrower Opted Out", name: 'BorrowerOptedOut', width: 80, editable: true, edittype: "select", formatter: "select", formoptions: { rowpos: 4, colpos: 2 },
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                { label: "Opted Out Date", name: 'OptedOutDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 4, colpos: 3 } },
                { label: "ATP Date", name: 'ApprovalToParticipateDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 5, colpos: 1 } },
                { label: "ATP Exp Date", name: 'ApprovalToParaticipateExpirationDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 5, colpos: 2 } },
                { label: "Last Plan Pymt Due Date", name: 'LastPlanPaymentDueDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 5, colpos: 3 } },
                { label: "Next Plan Pymt Due Date", name: 'NextPlanPaymentDueDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 6, colpos: 1 }},
                { label: "First Missed Pymt Due Date", name: 'FirstMissedPaymentDueDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 6, colpos: 2 }},
                { label: "First Plan Pymt Due Date", name: 'FirstPlanPaymentDueDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 6, colpos: 3 } },
                {
                    label: "Incl SFB Exp Date",
                    name: 'PlanIncludesSFBExpirationDate', width: 80, editable: true, hidden: true, editrules: { edithidden: true }, edittype: "select", formatter: "select", formoptions: { rowpos: 7, colpos: 1 },
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                {
                    label: "Pymt Susp/Redu',",
                    name: 'PlanPaymentsSuspended', width: 80, editable: true, hidden: true, editrules: { edithidden: true }, edittype: "select", formatter: "select", formoptions: { rowpos: 7, colpos: 2 },
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                { label: "Spcl Forbe Exp Date", name: 'SpecialForbearanceExpirationDate', width: 80, editable: true, hidden: true, editrules: { edithidden: true }, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 7, colpos: 3 },},
                { label: "Lst Plan Pymt Appl Date", name: 'LastPlanPaymentAppliedToLoanDate', width: 80, editable: true, hidden: true, editrules: { edithidden: true }, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 8, colpos: 1 },},

                { label: "Appd Contr Date", name: 'ApprovedContractDate', width: 80, editable: true, hidden: true, editrules: { edithidden: true }, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 8, colpos: 2 } },
                {
                    label: "Appd Var",
                    name: 'ApprovedVariance', width: 80, editable: true, hidden: true, editrules: { edithidden: true }, edittype: "select", formatter: "select", formoptions: { rowpos: 8, colpos: 3 },
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                { label: "Var Req Date", name: 'VarianceRequestDate', width: 80, editable: true, hidden: true, editrules: { edithidden: true }, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 9, colpos: 1 } },
                { label: "Var Ext Date", name: 'VarianceExtensionDate', width: 80, editable: true, hidden: true, editrules: { edithidden: true }, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 9, colpos: 2 }},
                { label: "FC 1st Act Date", name: 'ForeclosureFirstActionDate', width: 80, editable: true, hidden: true, editrules: { edithidden: true }, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 9, colpos: 3 } }
            ],
            loadonce: true,
            autowidth: true,
            viewrecords: true,
            height: 200,
            rowNum: 10,
            pager: "#tbl_parta_lossmit_pager",
            subGrid: true,
            subGridRowExpanded: function (subgridid, rowid) {
                var subgrid_table_id;
                var rowdata = $(this).getRowData(rowid);
                subgrid_table_id = subgridid + "_t";
                $("#" + subgridid).html("<table id='" + subgrid_table_id + "'></table>");
                var sgdata = [{
                    PlanIncludesSFBExpirationDate: rowdata["PlanIncludesSFBExpirationDate"],
                    PlanPaymentsSuspended: rowdata["PlanPaymentsSuspended"],
                    SpecialForbearanceExpirationDate: rowdata["SpecialForbearanceExpirationDate"],
                    LastPlanPaymentAppliedToLoanDate: rowdata["LastPlanPaymentAppliedToLoanDate"],
                    ApprovedContractDate: rowdata["ApprovedContractDate"],
                    ApprovedVariance: rowdata["ApprovedVariance"],
                    VarianceRequestDate: rowdata["VarianceRequestDate"],
                    VarianceExtensionDate: rowdata["VarianceExtensionDate"],
                    ForeclosureFirstActionDate: rowdata["ForeclosureFirstActionDate"]
                }];
                $("#" + subgrid_table_id).jqGrid({
                    data: sgdata,
                    datatype: "local",
                    colNames: ['Incl SFB Exp Date', 'Pymt Susp/Redu', 'Spcl Forbe Exp Date', 'Lst Plan Pymt Appl Date',
                        'Appd Contr Date', 'Appd Var', 'Var Req Date', 'Var Ext Date', 'FC 1st Act Date'],
                    colModel: [
                        {
                            name: 'PlanIncludesSFBExpirationDate', width: 80, editable: true, edittype: "select", formatter: "select",
                            formatoptions: { value: { "0": "No", "1": "Yes" } },
                            editoptions: { value: { "0": "No", "1": "Yes" } }
                        },
                        {
                            name: 'PlanPaymentsSuspended', width: 80, editable: true, edittype: "select", formatter: "select",
                            formatoptions: { value: { "0": "No", "1": "Yes" } },
                            editoptions: { value: { "0": "No", "1": "Yes" } }
                        },
                        { name: 'SpecialForbearanceExpirationDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                        { name : 'LastPlanPaymentAppliedToLoanDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },

                        { name: 'ApprovedContractDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                        {
                            name: 'ApprovedVariance', width: 80, editable: true, edittype: "select", formatter: "select",
                            formatoptions: { value: { "0": "No", "1": "Yes" } },
                            editoptions: { value: { "0": "No", "1": "Yes" } }
                        },
                        { name: 'VarianceRequestDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                        { name: 'VarianceExtensionDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                        { name: 'ForeclosureFirstActionDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } }
                    ],
                    height: 'auto',
                    autowidth: true
                });
            }

        });
        $("#tbl_parta_lossmit").navGrid("#tbl_parta_lossmit_pager", {
            add: true, edit: true, del: true, search: false, refresh: true,
            beforeRefresh: home.onbeforerefresh
        }, {closeAfterEdit: true, width: 800}, {closeAfterAdd: true, width: 800});
    },
    editroweaction: function (p) {
        var $grid = $("#tbl_parta_eaction");
        if (p && p !== lossanalysis.data.parta.eaction.lastselectedrow) {
            $grid.jqGrid('restoreRow', lossanalysis.data.parta.eaction.lastselectedrow);
            $grid.jqGrid('editRow', p, { keys: false }); /*key true enable Enter to save*/
            lossanalysis.data.parta.eaction.lastselectedrow = p;
            $("#tbl_parta_eaction_iledit", "#tbl_parta_eaction_pager").trigger("click");
        } else {
            if (p == lossanalysis.data.parta.eaction.lastselectedrow
                && $("#" + p, $grid).attr("editable") !== "1") {
                $grid.jqGrid('editRow', p, { keys: false });
                $("#tbl_parta_eaction_iledit", "#tbl_parta_eaction_pager").trigger("click");
            }
        }
    },
    loadeactiongrid: function (p) {
        $("#tbl_parta_eaction").jqGrid({
            data: lossanalysis.data.parta.eaction.data,
            datatype: "local",
            editurl: "clientArray",
            caption: "Eviction Action",
            colModel: [
                { label: "Id", name: "Id", key: true, hidden: true },
                { label: "Eviction First Legal Date", name: 'EvictionFirstLegalDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Unacceptable Delay Start Date", name: 'UnacceptableDelayStartDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Vacancy Date", name: 'VacancyDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Close and Bill Date", name: 'CloseAndBillDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Reoccupancy Date", name: 'ReoccupancyDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "Vacancy Type", name: 'VacancyType', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: { "lockout": "Lockout", "voluntary": "Voluntary" } },
                    editoptions: { value: { "lockout": "Lockout", "voluntary": "Voluntary" } }
                }
            ],
            loadonce: true,
            autowidth: true,
            viewrecords: true,
            onSelectRow: lossanalysis.editroweaction,
            height: 200,
            rowNum: 10,
            pager: "#tbl_parta_eaction_pager"

        });
        $("#tbl_parta_eaction").navGrid("#tbl_parta_eaction_pager", {
            add: false, edit: false, search: false, refresh: false/*,
            beforeRefresh: home.onbeforerefresh*/
        });
        $("#tbl_parta_eaction").inlineNav("#tbl_parta_eaction_pager", {});
    },
    editrowodelay: function (p) {
        var $grid = $("#tbl_parta_odelay");
        if (p && p !== lossanalysis.data.parta.odelay.lastselectedrow) {
            $grid.jqGrid('restoreRow', lossanalysis.data.parta.odelay.lastselectedrow);
            $grid.jqGrid('editRow', p, { keys: false }); /*key true enable Enter to save*/
            lossanalysis.data.parta.odelay.lastselectedrow = p;
            $("#tbl_parta_odelay_iledit", "#tbl_parta_odelay_pager").trigger("click");
        } else {
            if (p == lossanalysis.data.parta.odelay.lastselectedrow
                && $("#" + p, $grid).attr("editable") !== "1") {
                $grid.jqGrid('editRow', p, { keys: false });
                $("#tbl_parta_odelay_iledit", "#tbl_parta_odelay_pager").trigger("click");
            }
        }
    },
    loadodelaygrid: function (p) {
        $("#tbl_parta_odelay").jqGrid({
            data: lossanalysis.data.parta.odelay.data,
            datatype: "local",
            editurl: "clientArray",
            caption: "Other Delays",
            colModel: [
                { label: "Id", name: "Id", key: true, hidden: true },
                { label: "Start Date", name: 'StartDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "End Date", name: 'EndDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "Acceptable", name: 'Acceptable', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: { "acceptable": "Acceptable", "unacceptable": "Unacceptable" } },
                    editoptions: { value: { "acceptable": "Acceptable", "unacceptable": "Unacceptable" } }
                },
                { label: "Reason", name: "Reason", width: 100, editable: true },
                {
                    label: "Type", name: 'Type', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: lossanalysis.data.parta.odelay.typelist },
                    editoptions: { value: lossanalysis.data.parta.odelay.typelist }
                }
            ],
            loadonce: true,
            autowidth: true,
            viewrecords: true,
            onSelectRow: lossanalysis.editrowodelay,
            height: 200,
            rowNum: 10,
            pager: "#tbl_parta_odelay_pager"

        });
        $("#tbl_parta_odelay").navGrid("#tbl_parta_odelay_pager", {
            add: false, edit: false, search: false, refresh: false/*,
            beforeRefresh: home.onbeforerefresh*/
        });
        $("#tbl_parta_odelay").inlineNav("#tbl_parta_odelay_pager", {});
    },
    loadpartbexpgrid: function () {
        $("#tbl_partb_exp").jqGrid({
            data: lossanalysis.data.partb.data,
            datatype: "local",
            editurl: "clientArray",
            caption: "Expenses",
            colModel: [
                { label: "Id", name: "Id", key: true, hidden: true },
                {
                    label: "Category", name: 'Category', index: "Category", width: 100, editable: true, formatter: "select", edittype: "select", formoptions: { rowpos: 1, colpos: 1 },
                    editoptions: { value: lossanalysis.data.partb.categorylist },
                    formatoptions: { value: lossanalysis.data.partb.categorylist }
                },
                {
                    label: "SubCategory", name: 'SubCategory', index: "SubCategory", width: 100, editable: true, formatter: "select", edittype: "select", formoptions: { rowpos: 1, colpos: 2 },
                    editoptions: { value: lossanalysis.data.partb.subcategorylist },
                    formatoptions: { value: lossanalysis.data.partb.subcategorylist }
                },
                {   label: "Description", name: 'Description', width: 150, editable: true, formoptions: { rowpos: 2, colpos: 1 }, editoptions: { maxlength: 200 } },
                {
                    label: "Advanced Account", name: 'AdvancedAccount', index: "AdvancedAccount", width: 80, editable: true, formoptions: { rowpos: 2, colpos: 2 },
                    formatter: "select", edittype: "select",
                    formatoptions: { value: lossanalysis.data.partb.advaccountlist },
                    editoptions: { value: lossanalysis.data.partb.advaccountlist }
                },
                {
                    label: "Invoice Number", name: 'InvoiceNumber', index: "InvoiceNumber", width: 80, editable: true, hidden: true, editrules: { edithidden: true }, formoptions: { rowpos: 3, colpos: 1 }
                },
                { label: "Date Disbursed", name: 'DateDisbursed', index: "DateDisbursed", width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 3, colpos: 2 } },
                {
                    label: "Amount Disbursed", name: 'AmountDisbursed', index: "AmountDisbursed", width: 80, editable: true, formoptions: { rowpos: 4, colpos: 1 }, editoptions: { maxlength: 20 },
                    formatter: "currency", formatoptions: { decimalSeparator: ",", thousandsSeparator: ",", decimalPlaces: 2, prefix: "$" } 
                },
                {
                    label: "Amount Refunded", name: 'AmountRefunded', index: "AmountRefunded", width: 80, editable: true, hidden: true, editrules: {edithidden: true}, formoptions: { rowpos: 4, colpos: 2 }, editoptions: { maxlength: 20 }
                },
                {
                    label: "Previous Claim Amount", name: 'PreviousClaimAmount', index: "PreviousClaimAmount", width: 80, editable: true, formoptions: { rowpos: 5, colpos: 1 },
                    formatter: "currency",formatoptions: { decimalSeparator: ",", thousandsSeparator: ",", decimalPlaces: 2, prefix: "$" } 
                },
                {
                    label: "Previous Debenture Interest", name: 'PreviousDebentureInterest', index: "PreviousDebentureInterest", width: 80, editable: true, formoptions: { rowpos: 7, colpos: 1 },
                    hidden: true, editrules: { edithidden: true}
                },
                {
                    label: "Previous Charge Off Amount", name: 'PreviousChargeOffAmount', index: "PreviousChargeOffAmount", width: 80, editable: true, formoptions: { rowpos: 6, colpos: 1 }, editoptions: { maxlength: 20 },
                    formatter: "currency", formatoptions: { decimalSeparator: ",", thousandsSeparator: ",", decimalPlaces: 2, prefix: "$" }
                },
                {
                    label: "Current Claim Amount", name: 'CurrentClaimAmount', index: "CurrentClaimAmount", width: 80, editable: true, formoptions: { rowpos: 5, colpos: 2 }, editoptions: { maxlength: 20 },
                    formatter: "currency", formatoptions: { decimalSeparator: ",", thousandsSeparator: ",", decimalPlaces: 2, prefix: "$" }
                },
                {
                    label: "Current Debenture Interest", name: 'CurrentDebentureInterest', index: "CurrentDebentureInterest", width: 80, editable: true, formoptions: { rowpos: 7, colpos: 2 }, editoptions: { maxlength: 10 },
                    hidden: true, editrules: { edithidden: true }
                },
                {
                    label: "Current Charge Off Amount", name: 'CurrentChargeOffAmount', index: "CurrentChargeOffAmount", width: 80, editable: true, formoptions: { rowpos: 6, colpos: 2 }, editoptions: { maxlength: 20 },
                    formatter: "currency", formatoptions: { decimalSeparator: ",", thousandsSeparator: ",", decimalPlaces: 2, prefix: "$" }
                },
                {
                    label: "Current Charge Off Reason", name: 'CurrentChargeOffReason', index: "CurrentChargeOffReason", width: 100, editable: true, formatter: "select", edittype: "select", formoptions: { rowpos: 8, colpos: 1 },
                    editoptions: { value: lossanalysis.data.partb.chargeoffreasonlist },
                    formatoptions: { value: lossanalysis.data.partb.chargeoffreasonlist }
                },
                {
                    label: "Current Responsible Party", name: 'CurrentResponsibleParty', index: "CurrentResponsibleParty", width: 100, editable: true, formatter: "select", edittype: "select", formoptions: { rowpos: 8, colpos: 2 },
                    editoptions: { value: lossanalysis.data.partb.responsiblepartylist },
                    formatoptions: { value: lossanalysis.data.partb.responsiblepartylist }
                },
                {
                    label: "Recovery Amount", name: 'RecoveryAmount', index: "RecoveryAmount", width: 80, editable: true, formoptions: { rowpos: 9, colpos: 1 }, editoptions: { maxlength: 20 },
                    formatter: "currency", formatoptions: { decimalSeparator: ",", thousandsSeparator: ",", decimalPlaces: 2, prefix: "$" },
                    hidden: true, editrules: {edithidden: true }
                },
                {
                    label: "Refund Amount", name: 'RefundAmount', index: "RefundAmount", width: 80, editable: true, formoptions: { rowpos: 9, colpos: 2 }, editoptions: { maxlength: 20 },
                    formatter: "currency", formatoptions: { decimalSeparator: ",", thousandsSeparator: ",", decimalPlaces: 2, prefix: "$" },
                    hidden: true, editrules: { edithidden: true }
                },
                {
                    label: "Uncontrollable Loss Amount", name: 'UncontrollableLossAmount', index: "UncontrollableLossAmount", width: 80, editable: true, formoptions: { rowpos: 10, colpos: 1 }, editoptions: { maxlength: 20 },
                    formatter: "currency", formatoptions: { decimalSeparator: ",", thousandsSeparator: ",", decimalPlaces: 2, prefix: "$" },
                    hidden: true, editrules: { edithidden: true }
                }
            ],
            loadonce: true,
            autowidth: true,
            viewrecords: true,
            height: 450,
            rowNum: 50,
            rowList: [50,100,200],
            pager: "#tbl_partb_exp_pager",
            subGrid: true,
            subGridRowExpanded: function (subgridid, rowid) {
                var subgrid_table_id;
                var rowdata = $(this).getRowData(rowid);
                subgrid_table_id = subgridid + "_t";
                $("#" + subgridid).html("<table id='" + subgrid_table_id + "'></table>");
                var sgdata = [{
                    InvoiceNumber : rowdata["InvoiceNumber"],
                    AmountRefunded: rowdata["AmountRefunded"],
                    PreviousDebentureInterest: rowdata["PreviousDebentureInterest"],
                    CurrentDebentureInterest: rowdata["CurrentDebentureInterest"],
                    RecoveryAmount: rowdata["RecoveryAmount"],
                    RefundAmount : rowdata["RefundAmount"],
                    UncontrollableLossAmount: rowdata["UncontrollableLossAmount"]
                }];
                $("#" + subgrid_table_id).jqGrid({
                    data: sgdata,
                    datatype: "local",
                    colNames: ['Inv Num', 'Amt Refun', 'Pre Deb Int', 'Curr Deb Int', 'Recvy Amt', 'Refun Amt', 'Uncon Loss Amt'],
                    colModel: [
                        { name: 'InvoiceNumber', width: 80 },
                        { name: 'AmountRefunded', width: 80 },
                        { name: 'PreviousDebentureInterest', width: 80 },
                        { name: 'CurrentDebentureInterest', width: 80 },
                        { name: 'RecoveryAmount', width: 80 },
                        { name: 'RefundAmount', width: 80 },
                        { name: 'UncontrollableLossAmount', width: 80 }
                    ],
                    height: 'auto',
                    autowidth: true
                });
            }

        });
        $("#tbl_partb_exp").navGrid("#tbl_partb_exp_pager", {
            add: true, edit: true, del: true, search: true, refresh: true,
            beforeRefresh: home.onbeforerefresh
        }, { closeAfterEdit: true, width: 800 }, { closeAfterAdd: true, width: 800 });
    },
    editrowreconrecovery: function (p) {
        var $grid = $("#tbl_recon_supprecovery");
        if (p && p !== lossanalysis.data.reconciliation.supprecovery.lastselectedrow) {
            $grid.jqGrid('restoreRow', lossanalysis.data.reconciliation.supprecovery.lastselectedrow);
            $grid.jqGrid('editRow', p, { keys: false }); 
            lossanalysis.data.reconciliation.supprecovery.lastselectedrow = p;
            $("#tbl_recon_supprecovery_iledit", "#tbl_recon_supprecovery_pager").trigger("click");
        } else {
            if (p == lossanalysis.data.reconciliation.supprecovery.lastselectedrow
                && $("#" + p, $grid).attr("editable") !== "1") {
                $grid.jqGrid('editRow', p, { keys: false });
                $("#tbl_recon_supprecovery_iledit", "#tbl_recon_supprecovery_pager").trigger("click");
            }
        }
    },
    loadreconrecoverygrid: function (p) {
        $("#tbl_recon_supprecovery").jqGrid({
            data: lossanalysis.data.reconciliation.supprecovery.data,
            datatype: "local",
            editurl: "clientArray",
            caption: "Supplemental Recovery",
            colModel: [
                { label: "Id", name: "Id", key: true, hidden: true },
                {
                    label: "Category", name: 'Category', width: 100, editable: true, formatter: "select", edittype: "select",
                    editoptions: { value: lossanalysis.data.reconciliation.categorylist },
                    formatoptions: { value: lossanalysis.data.reconciliation.categorylist }
                },
                {
                    label: "Sub-Category", name: 'SubCategory', width: 100, editable: true, formatter: "select", edittype: "select",
                    editoptions: { value: lossanalysis.data.reconciliation.subcategorylist },
                    formatoptions: { value: lossanalysis.data.reconciliation.subcategorylist }
                },
                { label: "Date Disbursed", name: 'DateDisbursed', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "Supplemental Amount", name: 'SupplementalAmount', width: 80, editable: true, formoptions: { rowpos: 6, colpos: 1 }, editoptions: { maxlength: 20 },
                    formatter: "currency", formatoptions: { decimalSeparator: ",", thousandsSeparator: ",", decimalPlaces: 2, prefix: "$" }
                }
            ],
            loadonce: true,
            autowidth: true,
            viewrecords: true,
            onSelectRow: lossanalysis.editrowreconrecovery,
            height: 100,
            rowNum: 10,
            pager: "#tbl_recon_supprecovery_pager"

        });
        $("#tbl_recon_supprecovery").navGrid("#tbl_recon_supprecovery_pager", {
            add: false, edit: false, search: false, refresh: false });
        $("#tbl_recon_supprecovery").inlineNav("#tbl_recon_supprecovery_pager", {});
    },
    editrowreconrefund: function (p) {
        var $grid = $("#tbl_recon_supprefund");
        if (p && p !== lossanalysis.data.reconciliation.supprefund.lastselectedrow) {
            $grid.jqGrid('restoreRow', lossanalysis.data.reconciliation.supprefund.lastselectedrow);
            $grid.jqGrid('editRow', p, { keys: false });
            lossanalysis.data.reconciliation.supprefund.lastselectedrow = p;
            $("#tbl_recon_supprefund_iledit", "#tbl_recon_supprefund_pager").trigger("click");
        } else {
            if (p == lossanalysis.data.reconciliation.supprefund.lastselectedrow
                && $("#" + p, $grid).attr("editable") !== "1") {
                $grid.jqGrid('editRow', p, { keys: false });
                $("#tbl_recon_supprefund_iledit", "#tbl_recon_supprefund_pager").trigger("click");
            }
        }
    },
    loadreconrefundgrid: function (p) {
        $("#tbl_recon_supprefund").jqGrid({
            data: lossanalysis.data.reconciliation.supprefund.data,
            datatype: "local",
            editurl: "clientArray",
            caption: "Supplemental Refund",
            colModel: [
                { label: "Id", name: "Id", key: true, hidden: true },
                {
                    label: "Category", name: 'Category', width: 100, editable: true, formatter: "select", edittype: "select",
                    editoptions: { value: lossanalysis.data.reconciliation.categorylist },
                    formatoptions: { value: lossanalysis.data.reconciliation.categorylist }
                },
                {
                    label: "Sub-Category", name: 'SubCategory', width: 100, editable: true, formatter: "select", edittype: "select",
                    editoptions: { value: lossanalysis.data.reconciliation.subcategorylist },
                    formatoptions: { value: lossanalysis.data.reconciliation.subcategorylist }
                },
                { label: "Date Disbursed", name: 'DateDisbursed', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "Supplemental Amount", name: 'SupplementalAmount', width: 80, editable: true, formoptions: { rowpos: 6, colpos: 1 }, editoptions: { maxlength: 20 },
                    formatter: "currency", formatoptions: { decimalSeparator: ",", thousandsSeparator: ",", decimalPlaces: 2, prefix: "$" }
                }
            ],
            loadonce: true,
            autowidth: true,
            viewrecords: true,
            onSelectRow: lossanalysis.editrowreconrefund,
            height: 100,
            rowNum: 10,
            pager: "#tbl_recon_supprefund_pager"

        });
        $("#tbl_recon_supprefund").navGrid("#tbl_recon_supprefund_pager", {
            add: false, edit: false, search: false, refresh: false
        });
        $("#tbl_recon_supprefund").inlineNav("#tbl_recon_supprefund_pager", {});
    },
    editrowworkflow: function (p) {
        var $grid = $("#tbl_workflow");
        if (p && p !== lossanalysis.data.workflow.lastselectedrow) {
            $grid.jqGrid('restoreRow', lossanalysis.data.workflow.lastselectedrow);
            $grid.jqGrid('editRow', p, { keys: false });
            lossanalysis.data.workflow.lastselectedrow = p;
            $("#tbl_workflow_iledit", "#tbl_workflow_pager").trigger("click");
        } else {
            if (p == lossanalysis.data.workflow.lastselectedrow
                && $("#" + p, $grid).attr("editable") !== "1") {
                $grid.jqGrid('editRow', p, { keys: false });
                $("#tbl_workflow_iledit", "#tbl_workflow_pager").trigger("click");
            }
        }
    },
    loadworkflowgrid: function (p) {
        $("#tbl_workflow").jqGrid({
            data: lossanalysis.data.workflow.data,
            datatype: "local",
            editurl: "clientArray",
            caption: "Active Workflow",
            colModel: [
                { label: "Id", name: "Id", key: true, hidden: true },
                {
                    label: "Workflow", name: 'Milestaone', width: 100, editable: true, formatter: "select", edittype: "select",
                    editoptions: { value: lossanalysis.data.workflow.milestonelist },
                    formatoptions: { value: lossanalysis.data.workflow.milestonelist }
                },
                {
                    label: "Created Person", name: 'CreatedPerson', width: 100, editable: true, formatter: "select", edittype: "select",
                    editoptions: { value: lossanalysis.data.lauserlist },
                    formatoptions: { value: lossanalysis.data.lauserlist }
                },
                { label: "Date Created", name: 'DateCreated', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "Assigned To", name: 'AssignedTo', width: 100, editable: true, formatter: "select", edittype: "select",
                    editoptions: { value: lossanalysis.data.lauserlist },
                    formatoptions: { value: lossanalysis.data.lauserlist }
                },
                {
                    label: "Status", name: 'Status', width: 80, editable: true, formatter: "select", edittype: "select",
                    editoptions: { value: lossanalysis.data.workflow.milestonestatuslist },
                    formatoptions: { value: lossanalysis.data.workflow.milestonestatuslist }
                },
                { label: "Status Date", name: 'StatusDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } }
            ],
            loadonce: true,
            autowidth: true,
            viewrecords: true,
            onSelectRow: lossanalysis.editrowworkflow,
            height: 300,
            rowNum: 30,
            pager: "#tbl_workflow_pager"

        });
        $("#tbl_workflow").navGrid("#tbl_workflow_pager", {
            add: false, edit: false, search: false, refresh: false
        });
        $("#tbl_workflow").inlineNav("#tbl_workflow_pager", {});
    },
    loadimporthistgrid: function (p) {
        $("#tbl_import_hist").jqGrid({
            data: lossanalysis.data.import.data,
            datatype: "local",
            editurl: "clientArray",
            caption: "Data Import History",
            colModel: [
                { label: "Id", name: "Id", key: true, hidden: true },
                { label: "File Name", name: 'FileName', width: 100 },
                { label: "Template", name: 'Template', width: 100 },
                { label: "Status", name: 'Status', width: 100 },
                { label: "Size", name: 'Size', width: 100 },
                { label: "Total Rows", name: 'TotalRows', width: 100 },
                { label: "Uploaded Person", name: 'UploadedPerson', width: 100 },
                { label: "Date Uploaded", name: 'DateUploaded', width: 100 }
            ],
            loadonce: true,
            autowidth: true,
            viewrecords: true,
            height: 300,
            rowNum: 50,
            pager: "#tbl_import_hist_pager",
            subGrid: true,
            subGridRowExpanded: function (sgdivid, rowid) {
                home.collopsesgrows(this, sgdivid, rowid);
                var subgrid_table_id;
                subgrid_table_id = sgdivid + "_t";
                $("#" + sgdivid).html("<table id='" + subgrid_table_id + "' class='scroll'></table>");
                $("#" + subgrid_table_id).jqGrid({
                    datatype: "local",
                    data: lossanalysis.data.import.error,
                    colNames: ['', 'Error Message'],
                    colModel: [
                        { name: "Id", key: true, hidden: true },
                        { name: "Message", width: 150, sortable: false }
                     
                    ],
                    height: 'auto',
                    rowNum: 50
                });
            }
        });
        $("#tbl_import_hist").navGrid("#tbl_import_hist_pager", {
            add: false, edit: false, del: false, search: false, refresh: true
        });
    }
};