﻿using Microsoft.AspNetCore.Http;

namespace CRFS.IS.UI.Portal.Models
{
    public class UploadFileViewModel
    {
        public string Template { get; set; }
        public IFormFile DataFile { get; set; }
    }
}
