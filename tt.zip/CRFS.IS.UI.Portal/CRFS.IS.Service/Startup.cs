﻿using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Hosting.WindowsServices;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

using CRFS.IS.Service.Security;

namespace CRFS.IS.Service
{
    public class Startup
    {
        private Scheduler.Scheduler _scheduler; 
        public IConfiguration _config { get; set; }
        
        public Startup(IConfiguration config)
        {
            _config = config;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddGrpc();
            services.AddSingleton(_config);
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, 
            ILoggerFactory loggerFactory, IHostApplicationLifetime lifetime)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
       //    loggerFactory.AddFile(@"Logs\service.log");

            app.UseRouting();
                     
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapGrpcService<Services.PdfCompressorService>();
                endpoints.MapGrpcService<Services.SecurityProviderService>();
                endpoints.MapGrpcService<Services.AdminService>();
                endpoints.MapGrpcService<Services.CommonService>();
                endpoints.MapGrpcService<Services.LossAnalysisService>();
                endpoints.MapGrpcService<Services.FileTransferService>();

                endpoints.MapGet("/", async context =>
                {
                    await context.Response.WriteAsync("Communication with gRPC endpoints must be made through a gRPC client.");
                });
            });

            SessionProvider.AddSession("PortalService", "PortalService", "StartUpToken");

            _scheduler = new Scheduler.SchedulerFactory(_config, loggerFactory.CreateLogger<Scheduler.Scheduler>()).Create();
            Task.Factory.StartNew(_scheduler.Run);

            lifetime.ApplicationStopping.Register(OnShutDown);
        }
        private void OnShutDown()
        {
            SessionProvider.AddSession("PortalService", "PortalService", "ShutDownToken");
            _scheduler.Stop();

            Thread.Sleep(1000);
        }
    }
}
