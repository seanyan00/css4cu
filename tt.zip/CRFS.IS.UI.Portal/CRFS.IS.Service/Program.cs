using System;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Hosting.WindowsServices;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.Extensions.Logging;

using Serilog;
using Serilog.Events;
using Serilog.Sinks.EventLog;

namespace CRFS.IS.Service
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var basedir = AppDomain.CurrentDomain.BaseDirectory;
            if (basedir.LastIndexOf("\\") == basedir.Length - 1)
                basedir = basedir.Substring(0, basedir.Length - 1);
            var ppath = System.IO.Directory.GetParent(basedir).FullName;
            var fpath = Path.Combine(ppath, "Logs", "service.log");
            Log.Logger = new LoggerConfiguration()
            .MinimumLevel.Override("Microsoft", LogEventLevel.Information)
            .Enrich.FromLogContext()
            .WriteTo.Console()
            .WriteTo.EventLog("CRFS Portal Service", restrictedToMinimumLevel: LogEventLevel.Fatal)
            .WriteTo.File(fpath, rollingInterval: RollingInterval.Day)
            .CreateLogger();

            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .UseWindowsService()
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.ConfigureKestrel(options =>
                    {
                        // Setup a HTTP/2 endpoint without TLS.
                       // options.ListenLocalhost(5000, o => o.Protocols =
                        //    HttpProtocols.Http2);
                        options.ListenAnyIP(50012, o => o.Protocols = HttpProtocols.Http2);
                    });

                    webBuilder.UseStartup<Startup>();
                    webBuilder.UseSerilog();
                });
    }
}
