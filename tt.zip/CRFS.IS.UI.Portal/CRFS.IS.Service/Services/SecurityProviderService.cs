﻿using System;
using System.Threading.Tasks;
using System.Linq;
using Grpc.Core;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;

using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Util;
using CRFS.IS.Service.Security;

namespace CRFS.IS.Service.Services
{
    public class  SecurityProviderService: SecurityProvider.SecurityProviderBase
    {
        private readonly IConfiguration _config;
        private readonly ILogger<SecurityProviderService> _logger;
        public SecurityProviderService(ILogger<SecurityProviderService> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
        }
        public override Task<GetAppRoleReply> GetAppRoleAD(GetAppRoleRequest request, ServerCallContext context)
        {
            var ret = new GetAppRoleReply();

            try
            {
                ret = new AuthProvider(_config, _logger).GetAppRoleAD(request);
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.Message);
            }
            return Task.FromResult(ret);
        }
        public override Task<GetSessionTokenReply> GetSessionToken(GetSessionTokenRequest request, ServerCallContext context)
        {
            string token = "";
            try
            {
                token = SessionProvider.GetSessionToken(request.Uname, request.Appname, _config); 
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.Message);
            }
            return Task.FromResult(new GetSessionTokenReply { Token = token });
        }
    }
}