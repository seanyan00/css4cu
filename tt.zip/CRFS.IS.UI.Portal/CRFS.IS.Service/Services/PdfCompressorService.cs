﻿using System;
using System.Threading.Tasks;
using System.Linq;
using System.Threading;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Grpc.Core;

using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Util;
using CRFS.IS.Service.Security;
using CRFS.IS.Service.Common;
using CRFS.IS.Service.Business;

namespace CRFS.IS.Service.Services
{
    public class PdfCompressorService : PdfCompressor.PdfCompressorBase
    {
        private readonly ILogger<PdfCompressorService> _logger;
        private readonly IConfiguration _config;
        private static CancellationTokenSource _cts;
        public PdfCompressorService(ILogger<PdfCompressorService> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
            if(_cts == null)
            {
                _cts = new CancellationTokenSource();
            }
        }

        public override Task<CompressReply> Compress(CompressRequest request, ServerCallContext context)
        {
            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");
                
                if (token == null || !SessionProvider.IsValidSession(token.Value, "Compress", true))
                {
                    _logger.LogWarning("Compress: Not a valid token or timed out");
                    return Task.FromResult(new CompressReply { });
                }
                //context.ResponseTrailers.Add("ErrorToken", token.Value);
                var appsetting = _config.GetSection("AppSettings").Get<AppSettings>();
                _cts = new CancellationTokenSource();

                return Task.FromResult(PDFCompressor.Compress(_cts.Token, request, _logger, token.Value, appsetting));
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.Message);
                return Task.FromResult(new CompressReply { });
            }
        }
        public override Task<Config> GetConfig(GetConfigRequest request, ServerCallContext context)
        {
            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "Portal.UI", true))
                {
                    _logger.LogWarning("Not a valid token or timed out");
                    return Task.FromResult(new Config { });
                }
                //context.ResponseTrailers.Add("ErrorToken", token.Value);
                var appsetting = _config.GetSection("AppSettings").Get<AppSettings>();

                return Task.FromResult(PortalProvider.GetPDFConfig(request));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Task.FromResult(new Config {});
            }
        }
        public override Task<SaveConfigReply> SaveConfig(Config request, ServerCallContext context)
        {
            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "Portal.UI", true))
                {
                    _logger.LogWarning("Not a valid token or timed out");
                    return Task.FromResult(new SaveConfigReply { Msg = "Invalid session token" });
                }
                //context.ResponseTrailers.Add("ErrorToken", token.Value);
                var appsetting = _config.GetSection("AppSettings").Get<AppSettings>();

                return Task.FromResult(PortalProvider.SavePDFConfig(request, token.Value));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Task.FromResult(new SaveConfigReply { Msg = ex.Message });
            }
        }
        public override Task<GetHistoryReply> GetHistory(GetHistoryRequest request, ServerCallContext context)
        {
            try
            {
                 return Task.FromResult(PortalProvider.GetCompressionHist());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Task.FromResult(new GetHistoryReply {});
            }
        }
        public override Task<GetBatchDetailReply> GetBatchDetail(GetBatchDetailRequest request, ServerCallContext context)
        {
            try
            {
                return Task.FromResult(PortalProvider.GetBatchDetail(request.BatchId));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Task.FromResult(new GetBatchDetailReply { });
            }
        }
        public override Task<CancelReply> Cancel(CancelRequest request, ServerCallContext context)
        {
            _cts.Cancel(false);
            return Task.FromResult(new CancelReply());
        }
    }
}
