﻿using System;
using System.Threading.Tasks;
using System.IO;
using System.Linq;
using System.Reflection;
using Grpc.Core;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;

using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Util;
using CRFS.IS.Service.Security;
using CRFS.IS.Service.Common;
using CRFS.IS.Service.Business;

namespace CRFS.IS.Service.Services
{
    public class FileTransferService : FileTransfer.FileTransferBase
    {
        private readonly IConfiguration _config;
        private readonly ILogger<FileTransferService> _logger;
        public FileTransferService(ILogger<FileTransferService> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
        }
        public override async Task<UploadFileReply> UploadFile(Grpc.Core.IAsyncStreamReader<UploadFileRequest> request, ServerCallContext context)
        {
            var ret = new UploadFileReply {
                Message = Constant.Success
            };  
            var firstround = true;
            var req = new UploadFileRequest();
            var pos = 0;
            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);
                var appsetting = _config.GetSection("AppSettings").Get<AppSettings>();
                var id = 0;
                var fpath = "";
                var type = 0;
                using (var ms = new MemoryStream()) {
                    while (await request.MoveNext())
                    {
                        var sm = request.Current;
                        if (firstround) {
                            req.Appname = sm.Appname;
                            req.Name = sm.Name;
                            req.Type = sm.Type;
                            firstround = false;
                        }
                        ms.Write(sm.Content.ToByteArray(), pos, sm.Content.Length);
                    }

                    fpath = Path.Combine(appsetting.FilePath, req.Name);
                    id = await FileProvider.UploadFile(ms, req.Appname, req.Name, user.UserName, fpath);
                }
                bool success = false;
                var exps = new ExpenseDataReader().GetExpenseDTO(fpath, id, req.Type, out success);

                if (success)
                {
                    switch (req.Appname) {
                        case "LossAnalysis":
                           ret.Message =  new LossAnalysisProvider(_config, _logger, user.UserId).LoadExpData(exps, id);
                            break;
                        default:
                            break;
                    }
                }
                else
                    ret.Message = "Error: Errors dring initial parsing. See history log for details";
            }
            catch (Exception ex)
            {  
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex.Message);
                ret.Message = "Error: " + ex.Message;
            }
            return ret;
        }
    }
}

