﻿using System;
using System.Threading.Tasks;
using System.Linq;
using System.Reflection;
using Grpc.Core;
using Google.Protobuf.WellKnownTypes;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;

using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Util;
using CRFS.IS.Service.Security;
using CRFS.IS.Service.Business;

namespace CRFS.IS.Service.Services
{
    public class LossAnalysisService : LossAnalysis.LossAnalysisBase
    {
        private readonly IConfiguration _config;
        private readonly ILogger<LossAnalysisService> _logger;
        public LossAnalysisService(ILogger<LossAnalysisService> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
        }
        public override Task<LoanData> GetLoan(GetLoanRequest request, ServerCallContext context)
        {
            var ret = new LoanData();
            
            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetLoanData(request.LoanNumber));
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<CompPartA> GetCompPartA(LoanRequest request, ServerCallContext context)
        {
            var ret = new CompPartA();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    return Task.FromResult(ret);
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetCompPartA(request.LoanId));
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<GetCompAOPReply> GetCompAOP(LoanRequest request, ServerCallContext context)
        {
            var ret = new GetCompAOPReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetCompAOP(request.LoanId));
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<GetCompPartBReply> GetCompPartB(LoanRequest request, ServerCallContext context)
        {
            var ret = new GetCompPartBReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetCompPartB(request.LoanId));
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SaveCompPartA(CompPartA request, ServerCallContext context)
        {
             var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                     throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SaveCompPartA(request);
                return Task.FromResult(ret);
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SaveCompAOP(CompAOP request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SaveCompAOP(request);
                return Task.FromResult(ret);
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SaveCompPartB(SaveCompPartBRequest request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SaveCompPartB(request);
                return Task.FromResult(ret);
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SaveLoan(LoanData request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SaveLoan(request);
                return Task.FromResult(ret);
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SaveMilestone(Milestone request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SaveMilestone(request);
                return Task.FromResult(ret);
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
        public override Task<RecPartA> GetRecPartA(LoanRequest request, ServerCallContext context)
        {
            var ret = new RecPartA();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetRecPartA(request.LoanId));
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<GetImportHistReplay> GetImportHist(Empty _, ServerCallContext context) {
            var ret = new GetImportHistReplay();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetImportHist());
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<GetImportHistDetailReply> GetImportHistDetail(GetImportHistDetailRequest request, ServerCallContext context)
        {
            var ret = new GetImportHistDetailReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetImportHistDetail(request.DIId));
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SaveRecPartA(RecPartA request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SaveRecPartA(request);
                return Task.FromResult(ret);
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
        public override Task<GetFCActionReply> GetFCAction(LoanRequest request, ServerCallContext context)
        {
            var ret = new GetFCActionReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetFCAction(request.LoanId));
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SaveFCAction(FCAction request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SaveFCAction(request);
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                throw new Exception("Not a valid token or timed out");
            }
            return Task.FromResult(ret);
        }
        public override Task<GetOtherExtReply> GetOtherExt(LoanRequest request, ServerCallContext context)
        {
            var ret = new GetOtherExtReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetOtherExt(request.LoanId));
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SaveOtherExt(OtherExt request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SaveOtherExt(request);
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
        public override Task<GetTimeframeReply> GetTimeframe(LoanRequest request, ServerCallContext context)
        {
            var ret = new GetTimeframeReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetTimeframe(request.LoanId));
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SaveTimeframe(SaveTimeframeRequest request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SaveTimeframe(request);
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
        public override Task<GetBankruptcyReply> GetBankruptcy(LoanRequest request, ServerCallContext context)
        {
            var ret = new GetBankruptcyReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetBankruptcy(request.LoanId));
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SaveBankruptcy(Bankruptcy request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SaveBankruptcy(request);
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
        public override Task<GetLossMitReply> GetLossMit(LoanRequest request, ServerCallContext context)
        {
            var ret = new GetLossMitReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetLossMit(request.LoanId));
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SaveLossMit(LossMit request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SaveLossMit(request);
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
        public override Task<GetEvictionReply> GetEviction(LoanRequest request, ServerCallContext context)
        {
            var ret = new GetEvictionReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetEviction(request.LoanId));
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SaveEviction(Eviction request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SaveEviction(request);
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
        public override Task<GetDelayReply> GetDelay(LoanRequest request, ServerCallContext context)
        {
            var ret = new GetDelayReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetDelay(request.LoanId));
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SaveDelay(Delay request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SaveDelay(request);
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
        public override Task<ReconPartA> GetReconPartA(LoanRequest request, ServerCallContext context)
        {
            var ret = new ReconPartA();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetReconPartA(request.LoanId));
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SaveReconPartA(ReconPartA request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SaveReconPartA(request);
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
        public override Task<ReconPartB> GetReconPartB(LoanRequest request, ServerCallContext context)
        {
            var ret = new ReconPartB();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetReconPartB(request.LoanId));
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SaveReconPartB(ReconPartB request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SaveReconPartB(request);
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
        public override Task<ReconSupplemental> GetReconSupplemental(LoanRequest request, ServerCallContext context)
        {
            var ret = new ReconSupplemental();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetSupplemental(request.LoanId));
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SaveReconSupplemental(ReconSupplemental request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SaveSupplemental(request);
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
        public override Task<ServicerAccountBalancing> GetServicerAccountBalancing(LoanRequest request, ServerCallContext context)
        {
            var ret = new ServicerAccountBalancing();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetServicerAccountBalancing(request.LoanId));
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<GetSupplementalRecoveryReply> GetSupplementalRecovery(GetSupplementalRecoveryRequest request, ServerCallContext context)
        {
            var ret = new GetSupplementalRecoveryReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetSuppRecoveryRefund(request.LoanId, request.Recovery == 1));
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<SupplementalDetail> GetSupplementalDetail(LoanRequest request, ServerCallContext context)
        {
            var ret = new SupplementalDetail();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetSupplementalDetail(request.LoanId));
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<ClientSpecificSuppDetail> GetClentSpecificDetail(LoanRequest request, ServerCallContext context)
        {
            var ret = new ClientSpecificSuppDetail();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetClientSpecificSuppDetail(request.LoanId));
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SaveSupplementalDetail(SupplementalDetail request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SaveSupplementalDetail(request);
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SaveClientSpecificSuppDetail(ClientSpecificSuppDetail request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SaveClientSpecificSuppDetail(request);
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
        public override Task<GetPartBExpenseReplay> GetPartBExpense(LoanRequest request, ServerCallContext context)
        {
            var ret = new GetPartBExpenseReplay();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetPartBExpense(request.LoanId));
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<PartBExpense> GetPartBExpenseParent(GetPartBExpenseParentRequest request, ServerCallContext context)
        {
            var ret = new PartBExpense();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new LossAnalysisProvider(_config, _logger, user.UserId).GetPartBExpenseParent(request.LoanExpenseId));
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SavePartBExpense(PartBExpense request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SavePartBExpense(request);
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
        public override Task<MessageReply> SavePartBExpenseParent(PartBExpense request, ServerCallContext context)
        {
            var ret = new MessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new LossAnalysisProvider(_config, _logger, user.UserId).SavePartBExpenseParent(request);
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
    }
}
