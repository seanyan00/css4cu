﻿using System;
using System.Threading.Tasks;
using System.Linq;
using Grpc.Core;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;

using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Util;
using CRFS.IS.Service.Security;

namespace CRFS.IS.Service.Services
{
    public class LossAnalysisService : LossAnalysis.LossAnalysisBase
    {
        private readonly IConfiguration _config;
        private readonly ILogger<LossAnalysisService> _logger;
        public LossAnalysisService(ILogger<LossAnalysisService> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
        }
        public override Task<GetLoanNumbersReply> GetLoanNumbers(GetLoanNumbersRequest request, ServerCallContext context)
        {
            var ret = new GetLoanNumbersReply();

            try
            {
                // ret = new AuthProvider(_config, _logger).GetAppRoleAD(request);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
            }
            return Task.FromResult(ret);
        }
    }
}
