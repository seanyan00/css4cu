﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;

namespace CRFS.IS.UI.Portal.Extensions
{
    public class JsonStringResult<T> : ContentResult
    {
        public JsonStringResult(string json)
        {
            Content = json;
            ContentType = "application/json";
        }
        public JsonStringResult(List<T> list)
        {
            Content = JsonSerializer.Serialize(list);
            ContentType = "application/json";
        }
    }
}
