﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Session;
using Microsoft.Extensions.Configuration;
using Grpc.Net.Client;
using Grpc.Core;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.GRpc;
using CRFS.IS.UI.Portal.Models;
using CRFS.IS.UI.Portal.Extensions;

namespace CRFS.IS.UI.Portal.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IConfiguration _config;

        public HomeController(ILogger<HomeController> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
        }
        public IActionResult Index()
        {
            ViewBag.UName = User.Identity.Name;

            if(string.IsNullOrEmpty(HttpContext.Session.Get<string>("SessionToken"))
                || HttpContext.Session.Get<UserGrantViewModel>("UserGrants") == null)
                  return Json(new { success = false, message = "No domain session variables" });
           
            return View(HttpContext.Session.Get<UserGrantViewModel>("UserGrants"));
        }
        [Authorize(Policy = "TokenExists")]
        public IActionResult GetDDL(string type)
        {
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };

            var client = new Common.CommonClient(channel);
            var reply = client.GetKeyValueList(new GetKeyValueListRequest
            {
                Type = "Client",
                Id = "0"
            }, mdata);

            var ret = new StringBuilder();
            string end = null;

            ret.Append("<option value='0'>-- Select --</option>");
            end = "";
            foreach(var item in reply.KVList)
            {
                ret.Append("<option value='" + item.Key + "'>" + item.Value + "</option>");
            }
            ret.Append(end);
            // return Json(reply);
            return Content(ret.ToString());
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
