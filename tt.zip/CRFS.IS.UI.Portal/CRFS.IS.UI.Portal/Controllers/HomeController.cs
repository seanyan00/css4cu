﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Text;
using System.IO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Session;
using Microsoft.Extensions.Configuration;
using Grpc.Net.Client;
using Grpc.Core;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.GRpc;
using CRFS.IS.UI.Portal.Models;
using CRFS.IS.UI.Portal.Extensions;

namespace CRFS.IS.UI.Portal.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IConfiguration _config;

        public HomeController(ILogger<HomeController> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
        }
        public IActionResult Index()
        {
            ViewBag.UName = User.Identity.Name;

            if(string.IsNullOrEmpty(HttpContext.Session.Get<string>("SessionToken"))
                || HttpContext.Session.Get<UserGrantViewModel>("UserGrants") == null)
                  return Json(new { success = false, message = "No domain session variables" });
           
            return View(HttpContext.Session.Get<UserGrantViewModel>("UserGrants"));
        }
        [Authorize(Policy = "TokenExists")]
        public IActionResult GetDDL(string type)
        {
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };

            var client = new Common.CommonClient(channel);
            var reply = client.GetKeyValueList(new GetKeyValueListRequest
            {
                Type = "Client",
                Id = "0"
            }, mdata);

            var ret = new StringBuilder();
            string end = null;

            ret.Append("<option value='0'>-- Select --</option>");
            end = "";
            foreach(var item in reply.KVList)
            {
                ret.Append("<option value='" + item.Key + "'>" + item.Value + "</option>");
            }
            ret.Append(end);
            // return Json(reply);
            return Content(ret.ToString());
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        //[Comsumes("multipart/form-data")]
        public async Task<IActionResult> UploadFile(/*[FromForm]*/UploadFileViewModel vm)
        {
           // return Json(new { success = false, message = "Not Implemented" });
            if ((vm.Template == null || vm.Template == 0) || (vm.DataFiles != null && vm.DataFiles.Count == 0 && vm.DataFile == null)
                                                 || (vm.DataFile != null && (vm.DataFile.Length == 0 || vm.DataFile.Length > Constant.MB * 4))
                                                 || (vm.DataFiles != null && vm.DataFiles.Count > 0 && (vm.DataFiles.Sum(x => x.DF.Length) > Constant.MB * 4)
                                                                                                        || vm.DataFiles.Any(x => x.DF.Length == 0)))
                return Json(new { success = false, message = "No Template, or No File or Exceeded Size Limit (4 MB)" });
            try
            {
                var mdata = new Metadata {
                               new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
                           };
                if (vm.DataFile != null && vm.DataFile.Length > 0)
                {
                    using (var ms = new MemoryStream())
                    {
                        vm.DataFile.CopyTo(ms);
                        await new Extensions.FileTransfer().FileUpload(ms, "LoassAnalysis", Path.GetFileName(vm.DataFile.FileName), 
                            vm.Template, _config, mdata);
                    }
                } else
                {
                    foreach(var df in vm.DataFiles)
                    {
                        if(df.DF.Length > 0)
                        {
                            using (var ms = new MemoryStream())
                            {
                                df.DF.CopyTo(ms);
                                await new Extensions.FileTransfer().FileUpload(ms, "LoassAnalysis", df.DF.FileName, vm.Template, _config, mdata);
                            }
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(new { success = true, message = "Uploaded" });
        }
    }
}
