﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace CRFS.IS.UI.Portal.Extensions
{
    public static class ModelStateHelper
    {
        public static string GetErrorString(ModelStateDictionary ms)
        {
            var ret = new StringBuilder();

            foreach (var key in ms.Keys)
            {
                foreach (var err in ms[key].Errors)
                {
                    ret.Append(string.Format("{0}: {1};", key, err.ErrorMessage));
                }
            }
            return ret.ToString();
        }
    }
}
