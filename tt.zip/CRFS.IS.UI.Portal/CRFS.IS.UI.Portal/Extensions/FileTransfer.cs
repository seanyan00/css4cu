﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using Microsoft.Extensions.Configuration;
using Google.Protobuf.WellKnownTypes;

using CRFS.IS.Service.GRpc;

namespace CRFS.IS.UI.Portal.Extensions
{
    public class FileTransfer
    {
        public async Task<string> FileUpload(MemoryStream ms, string appname, string filename, string filetype, IConfiguration config)
        {
            var ret = "Success";
            var buffsize = 512 * 1024;
            byte[] buffer = new byte[buffsize];

            try
            {
                var channel = ChannelHelper.GetChannel(config);
                
                var client = new Service.GRpc.FileTransfer.FileTransferClient(channel);
                using(var call = client.UploadFile())
                {
                    var br = ms.Read(buffer, 0, buffsize);
                    await call.RequestStream.WriteAsync(new UploadFileRequest
                    {
                        Appname = appname,
                        Name = filename,
                        Type = filetype,
                        Content = Google.Protobuf.ByteString.CopyFrom(buffer)
                    });
                    if(br == buffsize)
                    {
                        while((br = ms.Read(buffer, br, buffsize)) > 0)
                        {
                            await call.RequestStream.WriteAsync(new UploadFileRequest
                            {
                                Content = Google.Protobuf.ByteString.CopyFrom(buffer)
                            });
                        }
                    }
                    await call.RequestStream.CompleteAsync();

                    var reply = await call.ResponseAsync;
                    ret = reply.Message;
                }
            }
            catch(Exception ex)
            {
                ret = ex.Message;
            }
            return ret;
        }
    }
}
