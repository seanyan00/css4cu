﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRFS.IS.UI.Portal.Helpers
{
    public static class Authorization
    {

    }
}
