﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using CRFS.IS.UI.Portal.Models;

namespace CRFS.IS.UI.Portal.Extensions
{
    public static class CommonHelper
    {
        public static UserGrantViewModel GetSessionUser(HttpContext context)
        {
            if(context.Session.Get<UserGrantViewModel>("UserGrants") == null)
                return new UserGrantViewModel();

            return context.Session.Get<UserGrantViewModel>("UserGrants");
        }
    }
}
