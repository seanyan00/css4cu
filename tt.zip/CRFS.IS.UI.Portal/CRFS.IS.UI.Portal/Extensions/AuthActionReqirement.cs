﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Filters;

using CRFS.IS.Service.Common;

namespace CRFS.IS.UI.Portal.Extensions
{
    public class AuthActionRequirement : IAuthorizationRequirement
    {
        public Constant.UIPrivilege Privilege { get; }
        public string Appname { get; }
        public AuthActionRequirement() : this((int)Constant.UIPrivilege.None, ""){}
        public AuthActionRequirement(Constant.UIPrivilege privilege, string appname)
        {
            Privilege = privilege;
            Appname = appname;
        }
    }
    public class AuthActionHandler : AuthorizationHandler<AuthActionRequirement>
    {
        IHttpContextAccessor _httpContextAccessor;

        public AuthActionHandler(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        protected override Task Handle​Requirement​Async(AuthorizationHandlerContext context, AuthActionRequirement requirement)
        {
            var ug = _httpContextAccessor.HttpContext.Session.Get<Models.UserGrantViewModel>("UserGrants");

            if (ug.UserGrants.Any(x => x.UIType == "SubApp" & x.UIName == requirement.Appname && x.UIPermit >= Convert.ToInt32(requirement.Privilege)))
                context.Succeed(requirement);
            else
            {
                context.Fail();
            }

            return Task.CompletedTask;
        }
    }
}
