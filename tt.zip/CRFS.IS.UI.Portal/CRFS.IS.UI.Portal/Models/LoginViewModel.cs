﻿using System.ComponentModel.DataAnnotations;

namespace CRFS.IS.UI.Portal.Models
{
    public class LoginViewModel
    {
        [Required]
        [StringLength(50, ErrorMessage = "MaxLength 50 exceeded")]
        public string Username { get; set; }
        [Required]
        [StringLength(50, ErrorMessage = "MaxLength 50 exceeded")]
        public string Password { get; set; }
        public string Message { get; set; }
        public LoginViewModel()
        {
            Username = "";
            Password = "";
            Message = "";
        }
    }
}
