﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CRFS.IS.UI.Portal.Models
{
    public class RunCompressViewModel
    {
        [Required]
        public int ClientId { get; set; }
        [StringLength(200, ErrorMessage ="MaxLength 200 exceeded")]
        public string SourceDir { get; set; }
        [StringLength(200, ErrorMessage = "MaxLength 200 exceeded")]
        public string TargetDir { get; set; }
        [StringLength(200, ErrorMessage = "MaxLength 200 exceeded")]
        public string ErrorDir { get; set; }
        public int? Limit { get; set; }

        public RunCompressViewModel()
        {
            SourceDir = "";
            TargetDir = "";
            ErrorDir = "";
            Limit = 0;
        }
    }
}
