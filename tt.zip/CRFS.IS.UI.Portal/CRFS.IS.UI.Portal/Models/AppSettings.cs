﻿namespace CRFS.IS.UI.Portal.Models
{
    public class AppSettings
    {
        public string Security_User { get; set; }
        public string Service_Address { get; set; }
        public string Service_Port { get; set; }
    }
}
