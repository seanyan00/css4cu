﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Grpc.Core;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.GRpc;
using CRFS.IS.UI.Portal.Models;
using CRFS.IS.UI.Portal.Extensions;

namespace CRFS.IS.UI.Portal.Areas.Applications.Controllers
{
    [Area("Applications")]
    [Authorize]
    public class LossAnalysisController : Controller
    {
        [Authorize(Policy = "TokenExists")]
        [AuthAction(Constant.UIPrivilege.Read, "LossAnalysis")]
        public ActionResult Index()
        {
            var ug = CommonHelper.GetSessionUser(HttpContext);

            return View(ug);
        }
    }
}