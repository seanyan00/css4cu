﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Grpc.Core;
using Google.Protobuf.WellKnownTypes;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.GRpc;
using CRFS.IS.UI.Portal.Models;
using CRFS.IS.UI.Portal.Extensions;

namespace CRFS.IS.UI.Portal.Areas.Applications.Controllers
{
    [Area("Applications")]
    [Authorize]
    public class LossAnalysisController : Controller
    {
        private readonly ILogger<LossAnalysisController> _logger;
        private readonly IConfiguration _config;
        public LossAnalysisController(ILogger<LossAnalysisController> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
        }

        [Authorize(Policy = "TokenExists")]
        [AuthAction(Constant.UIPrivilege.Read, "LossAnalysis")]
        public ActionResult Index()
        {
            var ug = SessionExtension.GetSessionUser(HttpContext);

            return View(ug);
        }
        public ActionResult GetLoanData(string loannumber)
        {
            var ret = new LoanData();

            if (string.IsNullOrEmpty(loannumber))
            {
                return Json(new { success = false, message = "Loan Number is needed" });
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);
                ret = client.GetLoan(new GetLoanRequest { LoanNumber = loannumber }, mdata);
                
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(new { success = true, data = ret }); 
        }
        public ActionResult GetCompPartA(int loanid)
        {
            var ret = new CompPartA();

            if (loanid == 0)
            {
                return Json(new { success = false, message = "Loan Id is needed" });
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);
                ret = client.GetCompPartA(new LoanRequest { LoanId = loanid }, mdata);

            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(new { success = true, data = ret });
        }
        public ActionResult GetCompAOP(int loanid)
        {
            var ret = new GetCompAOPReply();

            if (loanid == 0)
            {
                return Json(new { success = false, message = "Loan Id is needed" });
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);
                ret = client.GetCompAOP(new LoanRequest { LoanId = loanid }, mdata);

            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(new { success = true, data = ret });
        }
        public ActionResult GetCompPartB(int loanid)
        {
            var ret = new GetCompPartBReply();

            if (loanid == 0)
            {
                return Json(new { success = false, message = "Loan Id is needed" });
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);
                ret = client.GetCompPartB(new LoanRequest { LoanId = loanid }, mdata);

            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(new { success = true, data = ret });
        }
        public ActionResult GetRecPartAInput(int loanid)
        {
            var ret = new RecPartA();

            if (loanid == 0)
            {
                return Json(new { success = false, message = "Loan Id is needed" });
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);
                ret = client.GetRecPartA(new LoanRequest { LoanId = loanid }, mdata);

            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(new { success = true, data = ret });
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Write, "LossAnalysis")]
        public ActionResult SaveLoan(Models.SaveLoanViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                var msg = string.Join("; ", ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage));
                return View("_Success", new ResponseMessageViewModel { title = "", message = msg });
            }
            var ret = new MessageReply();
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);
                var loandata = new LoanData { 
                   BorrowerFirstName = vm.BorrowerFirstName.GetSafeString(),
                   BorrowerLastName = vm.BorrowerLastName.GetSafeString(),
                   BuyOutDate = vm.BuyOutDate.GetSafeString(),
                   ClaimTypeId = vm.ClaimTypeID,
                   ClientId = vm.ClientID,
                   CloseDate = vm.CloseDate.GetSafeString(),
                   ClosingReasonId = vm.ClosingReasonId.GetSafeValue<int>(),
                 //  DebentureInterestRate = vm.DebentureInterestRate,
                   FHACaseNumber = vm.FHACaseNumber,
                   LoanId = vm.LoanId,
                   InvestorId = vm.InvestorID.GetSafeValue<int>(),
                   LoanNumber = vm.LoanNumber,
                   LossAnalysisDueDate = vm.LossAnalysisDueDate.GetSafeString(),
                   LossAnalysisReferralDate = vm.LossAnalysisReferralDate.GetSafeString(),
                   NoteRate = vm.NoteRate.GetSafeValue<double>(),
                   PropertyCity = vm.PropertyCity.GetSafeString(),
                   PropertyLotSize = vm.PropertyLotSize.GetSafeValue<int>(),
                   PropertyStateId = vm.PropertyStateId.GetSafeValue<int>(),
                   PropertyStreetAddressLine1 = vm.PropertyStreetAddressLine1.GetSafeString(),
                   PropertyStreetAddressLine2 = vm.PropertyStreetAddressLine2.GetSafeString(),
                   PropertyZipCode = vm.PropertyZipCode.GetSafeString(),
                   ServiceTransferDate = vm.ServiceTransferDate.GetSafeString(),
                   StatusId = vm.StatusId.GetSafeValue<int>(),
                   StatusDate = vm.StatusDate.GetSafeString()
                };

                ret = client.SaveLoan(loandata, mdata);
                if(ret.Message == Constant.Success)
                    return View("_Success", new ResponseMessageViewModel { title = "Success", message = "Data Saved" }); 
                else
                    return View("_Success", new ResponseMessageViewModel { title = "", message = ret.Message });
            }
            catch (Exception ex)
            {
                return View("_Success", new ResponseMessageViewModel { title = "", message = ex.Message });
            }
            
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Write, "LossAnalysis")]
        public ActionResult SaveCompPartA(Models.SaveCompPartAViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                var msg = string.Join("; ", ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage));
                return View("_Success", new ResponseMessageViewModel { title = "", message = msg });
            }
            var ret = new MessageReply();
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);

                var cpa = new CompPartA{ 
                   AuthorizedBidAmount = vm.AuthorizedBidAmount.GetSafeValue(),
                   BankruptcyLiftDate = vm.BankruptcyLiftDate.GetSafeString(),
                   ClaimFiledDate = vm.ClaimFiledDate.GetSafeString(),
                   ConveyanceExtensionDate = vm.ConveyanceExtensionDate.GetSafeString(),
                   DateDeedOrAssignmentFiled = vm.DateDeedOrAssignmentFiled.GetSafeString(),
                   DateOfPossessionAcquisition = vm.DateOfPossessionAcquisition.GetSafeString(),
                   DebentureInterestRate = vm.DebentureInterestRate.GetSafeValue(),
                   DeedInLieuDate = vm.DeedInLieuDate.GetSafeString(),
                   DueDateOfLastPaymentInstallment = vm.DueDateOfLastPaymentInstallment.GetSafeString(),
                   EndorsementDate = vm.EndorsementDate.GetSafeString(),
                   ForeclosureFirstLegalDate = vm.ForeclosureFirstLegalDate.GetSafeString(),
                   InstitutionExtensionDate = vm.InstitutionExtensionDate.GetSafeString(),
                   LoanId = vm.LoanId,
                   MortgageeCurtailmentDate = vm.MortgageeCurtailmentDate.GetSafeString(),
                   NumberOfLivingUnits = vm.NumberOfLivingUnits.GetSafeValue(),
                   OriginalPrincipalBalance = vm.OriginalPrincipalBalance.GetSafeValue(),
                   UnpaidPrincipalBalance = vm.UnpaidPrincipalBalance.GetSafeValue(),
                   PartACompId = vm.PartACompId.GetSafeValue()
                };
                foreach(var t in vm.LivingUnits)
                {
                    cpa.LivingUnits.Add(new LivingUnit
                    {
                        LivingUnitPartATypeId = t.LivingUnitPartATypeId,
                        LoanLivingUnitId = t.LoanLivingUnitId,
                        PartAId = t.PartAId,
                        UnitNum = t.UnitNum,
                        UnitOccupancyStatusId = t.UnitOccupancyStatusId,
                        UnitOccupantName = t.UnitOccupantName.GetSafeString(),
                        UnitSecuredDate = t.UnitSecuredDate.GetSafeString(),
                        UnitVacatedDate = t.UnitVacatedDate.GetSafeString()
                    });
                }

                ret = client.SaveCompPartA(cpa, mdata);

                if (ret.Message == Constant.Success)
                    return View("_Success", new ResponseMessageViewModel { title = "Success", message = "Data Saved" });
                else
                    return View("_Success", new ResponseMessageViewModel { title = "", message = ret.Message });
            }
            catch (Exception ex)
            {
                return View("_Success", new ResponseMessageViewModel { title = "", message = ex.Message });
            }

        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Write, "LossAnalysis")]
        public ActionResult SaveCompPartB(Models.SaveCompPartBViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                var msg = string.Join("; ", ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage));
                return View("_Success", new ResponseMessageViewModel { title = "", message = msg });
            }
            var ret = new MessageReply();
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);

                var cpb = new SaveCompPartBRequest { };
                foreach(var pb in vm.CompPartBs)
                {
                    pb.LoanId = vm.LoanId;
                    cpb.CompPartBs.Add(new CompPartB { 
                        LoanId = pb.LoanId,
                        PartBBlockId = pb.PartBBlockId.GetSafeValue(),
                        AOPAdditionAmount = pb.AOPAdditionAmount ?? 0.0,
                        AOPDeductionAmount = pb.AOPDeductionAmount ?? 0.0,
                        AOPInterestAmount = pb.AOPInterestAmount ?? 0.0,
                        Note = pb.Note.GetSafeString(),
                        Passed = pb.Passed.GetSafeValue(),
                        SubAdditionAmount = pb.SubAdditionAmount ?? 0.0,
                        SubDeductionAmount = pb.SubDeductionAmount ?? 0.0,
                        SubInterestAmount = pb.SubInterestAmount ?? 0.0
                    });
                }
                ret = client.SaveCompPartB(cpb, mdata);

                if (ret.Message == Constant.Success)
                    return View("_Success", new ResponseMessageViewModel { title = "Success", message = "Data Saved" });
                else
                    return View("_Success", new ResponseMessageViewModel { title = "", message = ret.Message });
            }
            catch (Exception ex)
            {
                return View("_Success", new ResponseMessageViewModel { title = "", message = ex.Message });
            }

        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Write, "LossAnalysis")]
        public ActionResult SaveCompAOP(Models.SaveCompAOPViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                var msg = string.Join("; ", ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage));
                return View("_Success", new ResponseMessageViewModel { title = "", message = msg });
            }
            var ret = new MessageReply();
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);

                var cpa = new CompAOP {
                   AOPId = vm.AOPId.GetSafeValue(),
                   AOPTypeId = vm.AOPTypeId.GetSafeValue(),
                   FHASettlementAmount = vm.FHASettlementAmount.GetSafeValue(),
                   InterestEndDate = vm.InterestEndDate.GetSafeString(),
                   InterestStartDate = vm.InterestStartDate.GetSafeString(),
                   LessOffsetAmount = vm.LessOffsetAmount.GetSafeValue(),
                   LoanId = vm.LoanId,
                   ReceivedDate = vm.ReceivedDate.GetSafeString(),
                   SettlementDate = vm.SettlementDate.GetSafeString(),
                   TotalInterestPaid = vm.TotalInterestPaid.GetSafeValue()
                };
                ret = client.SaveCompAOP(cpa, mdata);

                if (ret.Message == Constant.Success)
                    return View("_Success", new ResponseMessageViewModel { title = "Success", message = "Data Saved" });
                else
                    return View("_Success", new ResponseMessageViewModel { title = "", message = ret.Message });
            }
            catch (Exception ex)
            {
                return View("_Success", new ResponseMessageViewModel { title = "", message = ex.Message });
            }

        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Write, "LossAnalysis")]
        public ActionResult SaveRecPartAInput(Models.SaveRecPartAInputViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                var msg = string.Join("; ", ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage));
                return View("_Success", new ResponseMessageViewModel { title = "", message = msg });
            }
            var ret = new MessageReply();
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);

                var cpa = new RecPartA
                {
                    AuthorizedBidAmount = vm.AuthorizedBidAmount.GetSafeValue(),
                    BankruptcyLiftDate = vm.BankruptcyLiftDate.GetSafeString(),
                    RecentVacancyDate = vm.RecentVacancyDate.GetSafeString(),
                    DebentureInterestRate = vm.DebentureInterestRate.GetSafeValue(),
                    DeedInLieuDate = vm.DeedInLieuDate.GetSafeString(),
                    ApprovalToParticipateDate = vm.ApprovalToParticipateDate.GetSafeString(),
                    EndorsementDate = vm.EndorsementDate.GetSafeString(),
                    BorrowerPaymentsMade = vm.BorrowerPaymentsMade.GetSafeValue() ? 1 : 0,
                    CheckWireDate = vm.CheckWireDate.GetSafeString(),
                    ClientSpecifiedBlock9 = vm.ClientSpecifiedBlock9.GetSafeString(),
                    DateOfInspectionPriorToFTV = vm.DateOfInspectionPriorToFTV.GetSafeString(),
                    DateOfPossessionAndAcquisition = vm.DateOfPossessionAndAcquisition.GetSafeString(),
                    DeedInLieuTransferDate = vm.DeedInLieuTransferDate.GetSafeString(),
                    DefaultDate = vm.DefaultDate.GetSafeString(),
                    DueDate = vm.DueDate.GetSafeString(),
                    DueDateofLastPaymentInstallment = vm.DueDateofLastPaymentInstallment.GetSafeString(),
                    FirstInspectionDate = vm.FirstInspectionDate.GetSafeString(),
                    FirstInspectionStatus = vm.FirstInspectionStatus,
                    FirstSFDMSCode1ADate = vm.FirstSFDMSCode1ADate.GetSafeString(),
                    FirstTimeVacancyDate = vm.FirstTimeVacancyDate.GetSafeString(),
                    ForeclosureDeedRecordedDate = vm.ForeclosureDeedRecordedDate.GetSafeString(),
                    ForeclosureSaleDate = vm.ForeclosureSaleDate.GetSafeString(),
                    HUDAssignmentDate = vm.HUDAssignmentDate.GetSafeString(),
                    HUDDeedFilingDate = vm.HUDDeedFilingDate.GetSafeString(),
                    LastLoanModificationDate = vm.LastLoanModificationDate.GetSafeString(),
                    LastOnTimePaymentDate = vm.LastOnTimePaymentDate.GetSafeString(),
                    LoanId = vm.LoanId,
                    MarketableTitleDate = vm.MarketableTitleDate.GetSafeString(),
                    NumberOfLivingUnits = vm.NumberOfLivingUnits.GetSafeValue(),
                    OriginalDefaultDate = vm.OriginalDefaultDate.GetSafeString(),
                    PartACompId = vm.PartACompId.GetSafeValue(),
                    PartARecId = vm.PartARecId,
                    PFSSettlementDate = vm.PFSSettlementDate.GetSafeString(),
                    PropertyREOSold = vm.PropertyREOSold.GetSafeValue() ? 1 : 0,
                    RedemptionDate = vm.RedemptionDate.GetSafeString(),
                    RRCDate = vm.RRCDate.GetSafeString(),
                    SaleBidAmount = vm.SaleBidAmount.GetSafeValue(),
                    SecondChanceSaleDate = vm.SecondChanceSaleDate.GetSafeString(),
                    SFDMSReportingMissedCycles = vm.SFDMSReportingMissedCycles.GetSafeValue(),
                    SufficientPaymentHistory = vm.SufficientPaymentHistory.GetSafeValue() ? 1 : 0,
                    UnpaidPrincipalBalance = vm.UnpaidPrincipalBalance.GetSafeValue()
                };
                foreach (var t in vm.LivingUnits)
                {
                    cpa.LivingUnits.Add(new LivingUnit
                    {
                        LivingUnitPartATypeId = t.LivingUnitPartATypeId,
                        LoanLivingUnitId = t.LoanLivingUnitId,
                        PartAId = t.PartAId,
                        UnitNum = t.UnitNum,
                        UnitOccupancyStatusId = t.UnitOccupancyStatusId,
                        UnitOccupantName = t.UnitOccupantName.GetSafeString(),
                        UnitSecuredDate = t.UnitSecuredDate.GetSafeString(),
                        UnitVacatedDate = t.UnitVacatedDate.GetSafeString()
                    });
                }

                ret = client.SaveRecPartA(cpa, mdata);

                if (ret.Message == Constant.Success)
                    return View("_Success", new ResponseMessageViewModel { title = "Success", message = "Data Saved" });
                else
                    return View("_Success", new ResponseMessageViewModel { title = "", message = ret.Message });
            }
            catch (Exception ex)
            {
                return View("_Success", new ResponseMessageViewModel { title = "", message = ex.Message });
            }

        }
        [AuthAction(Constant.UIPrivilege.Read, "LossAnalysis")]
        public ActionResult GetKeyValueList(string name, string id)
        {
            var ret = new List<KeyValuePair<string, string>>();

            var channel = ChannelHelper.GetChannel(_config);
            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };

            try
            {
                var client = new Common.CommonClient(channel);
                var reply = client.GetKeyValueList(new GetKeyValueListRequest
                    {
                        Type = name,
                        Id = string.IsNullOrEmpty(id) ? "" : id
                    }, mdata);
                foreach(var kv in reply.KVList)
                {
                    ret.Add(new KeyValuePair<string, string>(kv.Key, kv.Value));
                }
            }
            catch(Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(new { success = true, data = ret });
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Write, "LossAnalysis")]
        public ActionResult SaveMilestone(Models.SaveMilestoneViewModel vm)
        {

            if (!ModelState.IsValid)
            {
                var msg = string.Join("; ", ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage));
                return View("_Success", new ResponseMessageViewModel { title = "", message = msg });
            }
            var ret = new MessageReply();
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };

            var commonclient = new Common.CommonClient(channel);

            var reply = commonclient.GetKeyValueList(new GetKeyValueListRequest
            {
                Type = "LAMILESTONE",
                Id = "0"
            }, mdata);
            var lms = new List<KeyValuePair<string, string>>();
            foreach(var l in reply.KVList)
            {
                lms.Add(new KeyValuePair<string, string>(l.Key, l.Value));
            }
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);  
                var loanms = new Milestone
                {
                    LoanId = vm.LoanId,
                    MilestoneDate = DateTime.Now.ToString(Constant.DateTimeString),
                };
                if(vm.MilestoneId > 0)
                {
                    loanms.MilestoneId = vm.MilestoneId;
                    loanms.AssignedUserId = vm.PartAAnalystId;
                    ret = client.SaveMilestone(loanms, mdata);
                } else
                {
                    if (vm.PartAAnalystId > 0)
                    {
                        loanms.MilestoneId = Convert.ToInt32(lms.Where(x => x.Value == "Part-A Assignment").Select(x => x.Key).Single());
                        loanms.AssignedUserId = vm.PartAAnalystId;
                        ret = client.SaveMilestone(loanms, mdata);
                    }
                   
                    if (vm.PartBAnalystId > 0)
                    {
                        loanms.MilestoneId = Convert.ToInt32(lms.Where(x => x.Value == "Part-B Assignment").Select(x => x.Key).Single());
                        loanms.AssignedUserId = vm.PartBAnalystId;  
                        ret = client.SaveMilestone(loanms, mdata);
                    }
                }
            }
            catch (Exception ex)
            {
                return View("_Success", new ResponseMessageViewModel { title = "", message = ex.Message });
            }
            return View("_Success", new ResponseMessageViewModel { title = "Success", message = "Data Saved"}); ;
        }
        public ActionResult GetFCAction(int loanid)
        {
            var ret = new List<Models.FCActionViewModel>();

            if (loanid == 0)
            {
                return Json(new { success = false, message = "Loan Id is needed" });
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);
                var temp = client.GetFCAction(new LoanRequest { LoanId = loanid }, mdata);
                foreach(var t in temp.FCActions)
                {
                    ret.Add(new Models.FCActionViewModel
                    {
                        id = t.LoanForeclosureId,
                        Comments = t.Comments,
                        FirstLegalDate = t.FirstLegalDate,
                        LoanId = t.LoanId,
                        RestartReason = t.RestartReason,
                        RestartValid = t.RestartValid,
                        SFDMSCode68Date = t.SFDMSCode68Date,
                        Type = t.Type
                    });
                }
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(ret);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Write, "LossAnalysis")]
        public ActionResult SaveFCAction(Models.FCActionViewModel vm)
        {
            var ret = new MessageReply();
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);

                var cpa = new FCAction
                {
                    Comments = vm.Comments.GetSafeString(),
                    FirstLegalDate = vm.FirstLegalDate,
                    LoanForeclosureId = vm.oper == "add" ? 0 : vm.id,
                    LoanId = vm.LoanId,
                    RestartReason = vm.RestartReason,
                    RestartValid = vm.RestartValid,
                    SFDMSCode68Date = vm.SFDMSCode68Date,
                    Type = vm.Type
                };
               

                ret = client.SaveFCAction(cpa, mdata);

                if (ret.Message == Constant.Success)
                    return Json(new { success = true, message = "Data Saved" });
                else
                    return Json(new { success = false, message = ret.Message });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }
        public ActionResult GetOtherExt(int loanid)
        {
            var ret = new List<Models.OtherExtViewModel>();

            if (loanid == 0)
            {
                return Json(new { success = false, message = "Loan Id is needed" });
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);
                var temp = client.GetOtherExt(new LoanRequest { LoanId = loanid }, mdata);
                foreach (var t in temp.OtherExts)
                {
                    ret.Add(new Models.OtherExtViewModel
                    {
                        id = t.LoanExtensionId,
                        ActiveDutyDischargeDate = t.ActiveDutyDischargeDate,
                        ActiveDutyStartDate = t.ActiveDutyStartDate,
                        DeclarationDate = t.DeclarationDate,
                        ExtensionType = t.ExtensionType,
                        FEMAExtensionDate = t.FEMAExtensionDate,
                        FirstActionDate = t.FirstActionDate,
                        HazardClaimDate = t.HazardClaimDate,
                        HazardClaimSettlementDate = t.HazardClaimSettlementDate,
                        HUDExtensionDate = t.HUDExtensionDate,
                        HUDExtensionRequestDate = t.HUDExtensionRequestDate,
                        LoanId = t.LoanId,
                        LossDate = t.LossDate,
                        SaleContractApprovalDate = t.SaleContractApprovalDate,
                        StatuteEndDate = t.StatuteEndDate,
                        StatuteStartDate = t.StatuteStartDate
                       
                    });
                }
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(ret);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Write, "LossAnalysis")]
        public ActionResult SaveOtherExt(Models.OtherExtViewModel vm)
        {
            var ret = new MessageReply();
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);

                var cpa = new OtherExt
                {
                    LoanExtensionId = vm.oper == "add" ? 0 : vm.id,
                    LoanId = vm.LoanId,
                    ActiveDutyDischargeDate = vm.ActiveDutyDischargeDate.GetSafeString(),
                    ActiveDutyStartDate = vm.ActiveDutyStartDate.GetSafeString(),
                    DeclarationDate = vm.DeclarationDate.GetSafeString(),
                    ExtensionType = vm.ExtensionType,
                    FEMAExtensionDate = vm.FEMAExtensionDate.GetSafeString(),
                    FirstActionDate = vm.FirstActionDate.GetSafeString(),
                    HazardClaimDate = vm.HazardClaimDate.GetSafeString(),
                    HazardClaimSettlementDate = vm.HazardClaimSettlementDate.GetSafeString(),
                    HUDExtensionDate = vm.HUDExtensionDate.GetSafeString(),
                    HUDExtensionRequestDate = vm.HUDExtensionRequestDate.GetSafeString(),
                    LossDate = vm.LossDate.GetSafeString(),
                    SaleContractApprovalDate = vm.SaleContractApprovalDate.GetSafeString(),
                    StatuteEndDate = vm.StatuteEndDate.GetSafeString(),
                    StatuteStartDate = vm.StatuteStartDate.GetSafeString()
                };


                ret = client.SaveOtherExt(cpa, mdata);

                if (ret.Message == Constant.Success)
                    return Json(new { success = true, message = "Data Saved" });
                else
                    return Json(new { success = false, message = ret.Message });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }
        public ActionResult GetPartATimeframe(int loanid)
        {
            var ret = new Models.TimeframeViewModel();

            if (loanid == 0)
            {
                return Json(new { success = false, message = "Loan Id is needed" });
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);
                var temp = client.GetTimeframe(new LoanRequest { LoanId = loanid }, mdata);
                ret.Timeframes.AddRange(temp.Timeframes);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(new { success = true, data = ret });
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Write, "LossAnalysis")]
        public ActionResult SavePartATimeframe(Models.TimeframeViewModel vm)
        {
            var ret = new MessageReply();
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);

                var cpa = new SaveTimeframeRequest();
                cpa.Timeframes.AddRange(vm.Timeframes);
               
                foreach(var v in cpa.Timeframes)
                {
                    v.LoanId = vm.LoanId;
                    v.LoanTimeframeId = 0;
                    v.TimeframeExtensionUsed = 0;
                    v.TimeframeOverrideDeadlineDate = "";
                }
                ret = client.SaveTimeframe(cpa, mdata);

                if (ret.Message == Constant.Success)
                    return View("_Success", new ResponseMessageViewModel { title = "Success", message = "Data Saved" });
                else
                    return View("_Success", new ResponseMessageViewModel { title = "", message = ret.Message });
            }
            catch (Exception ex)
            {
                return View("_Success", new ResponseMessageViewModel { title = "", message = ex.Message });
            }

        }
        public ActionResult GetBankruptcy(int loanid)
        {
            var ret = new List<Models.BankruptcyViewModel>();

            if (loanid == 0)
            {
                return Json(new { success = false, message = "Loan Id is needed" });
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);
                var temp = client.GetBankruptcy(new LoanRequest { LoanId = loanid }, mdata);
                foreach (var t in temp.Bankruptcys)
                {
                    ret.Add(new Models.BankruptcyViewModel
                    {
                        id = t.LoanBKExtensionId,
                        LoanId = t.LoanId,
                        AttorneyProvidedLiftDate = t.AttorneyProvidedLiftDate,
                        BankruptcyCaseNumber = t.BankruptcyCaseNumber,
                        BankruptcyCompletionDate = t.BankruptcyCompletionDate,
                        BankruptcyCompletionDays = t.BankruptcyCompletionDays,
                        BankruptcyType = t.BankruptcyType,
                        ClearanceDate = t.ClearanceDate,
                        ClosedSameDayAsDischarge = t.ClosedSameDayAsDischarge,
                        DelaysAcceptable = t.DelaysAcceptable,
                        DischargeDate = t.DischargeDate,
                        DismissalDate = t.DismissalDate,
                        FiledDate = t.FiledDate,
                        FirstActionDate = t.FirstActionDate,
                        FirstUnacceptableDelay = t.FirstUnacceptableDelay,
                        MotionForReliefDate = t.MotionForReliefDate,
                        OrderGrantingMFR = t.OrderGrantingMFR,
                        RuleWaived = t.RuleWaived,
                        Ruling = t.Ruling

                    });
                }
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(ret);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Write, "LossAnalysis")]
        public ActionResult SaveBankruptcy(Models.BankruptcyViewModel vm)
        {
            var ret = new MessageReply();
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);

                var cpa = new Bankruptcy
                {
                    LoanBKExtensionId = vm.oper == "add" ? 0 : vm.id,
                    LoanId = vm.LoanId,
                    AttorneyProvidedLiftDate = vm.AttorneyProvidedLiftDate.GetSafeString(),
                    BankruptcyCaseNumber = vm.BankruptcyCaseNumber.GetSafeString(),
                    BankruptcyCompletionDate = vm.BankruptcyCompletionDate.GetSafeString(),
                    BankruptcyCompletionDays = vm.BankruptcyCompletionDays.GetSafeValue(),
                    BankruptcyType = vm.BankruptcyType.GetSafeValue(),
                    ClearanceDate = vm.ClearanceDate.GetSafeString(),
                    ClosedSameDayAsDischarge = vm.ClosedSameDayAsDischarge.GetSafeValue(),
                    DelaysAcceptable = vm.DelaysAcceptable.GetSafeValue(),
                    DischargeDate = vm.DischargeDate.GetSafeString(),
                    DismissalDate = vm.DismissalDate.GetSafeString(),
                    FiledDate = vm.FiledDate.GetSafeString(),
                    FirstActionDate = vm.FirstActionDate.GetSafeString(),
                    FirstUnacceptableDelay = vm.FirstUnacceptableDelay.GetSafeString(),
                    MotionForReliefDate = vm.MotionForReliefDate.GetSafeString(),
                    OrderGrantingMFR = vm.OrderGrantingMFR.GetSafeValue(),
                    RuleWaived = vm.RuleWaived.GetSafeValue(),
                    Ruling = vm.Ruling
                };


                ret = client.SaveBankruptcy(cpa, mdata);

                if (ret.Message == Constant.Success)
                    return Json(new { success = true, message = "Data Saved" });
                else
                    return Json(new { success = false, message = ret.Message });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }
        public ActionResult GetLossMit(int loanid)
        {
            var ret = new List<Models.LossMitViewModel>();

            if (loanid == 0)
            {
                return Json(new { success = false, message = "Loan Id is needed" });
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);
                var temp = client.GetLossMit(new LoanRequest { LoanId = loanid }, mdata);
                foreach (var t in temp.LossMits)
                {
                    ret.Add(new Models.LossMitViewModel
                    {
                        id = t.LoanLMExtensionId,
                        LoanId = t.LoanId,
                        ApprovalToParticipateDate = t.ApprovalToParticipateDate,
                        ApprovalToParticipateExpirationDate = t.ApprovalToParticipateExpirationDate,
                        ApprovedContractDate = t.ApprovedContractDate,
                        ApprovedVariance = t.ApprovedVariance,
                        DocumentsAvailable = t.DocumentsAvailable,
                        BorrowerVacatedDate = t.BorrowerVacatedDate,
                        DecisionDate = t.DecisionDate,
                        DocumentSignDate = t.DocumentSignDate,
                        FirstActionDate = t.FirstActionDate,
                        FirstMissedPaymentDueDate = t.FirstMissedPaymentDueDate,
                        FirstPlanPaymentDueDate = t.FirstPlanPaymentDueDate,
                        LastPlanPaymentAppliedDate = t.LastPlanPaymentAppliedDate,
                        LastPlanPaymentDueDate = t.LastPlanPaymentDueDate,
                        LossMitigationType = t.LossMitigationType,
                        NextPlanPaymentDueDate = t.NextPlanPaymentDueDate,
                        OptOutDate = t.OptOutDate,
                        PlanComplete = t.PlanComplete,
                        PlanIncludesSFBExpiration = t.PlanIncludesSFBExpiration,
                        PlanPaymentsSuspendedReduced = t.PlanPaymentsSuspendedReduced,
                        SFBExpirationDate = t.SFBExpirationDate,
                        SFDMSReportDate = t.SFDMSReportDate,
                        SFDMSReported = t.SFDMSReported,
                        VarianceExtensionDate = t.VarianceExtensionDate,
                        VarianceRequestDate = t.VarianceRequestDate

                    });
                }
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(ret);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Write, "LossAnalysis")]
        public ActionResult SaveLossMit(Models.LossMitViewModel vm)
        {
            var ret = new MessageReply();
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);

                var cpa = new LossMit
                {
                    LoanLMExtensionId = vm.oper == "add" ? 0 : vm.id,
                    LoanId = vm.LoanId,
                    ApprovalToParticipateDate = vm.ApprovalToParticipateDate.GetSafeString(),
                    ApprovalToParticipateExpirationDate = vm.ApprovalToParticipateExpirationDate.GetSafeString(),
                    ApprovedContractDate = vm.ApprovedContractDate.GetSafeString(),
                    ApprovedVariance = vm.ApprovedVariance,
                    BorrowerVacatedDate = vm.BorrowerVacatedDate.GetSafeString(),
                    DecisionDate = vm.DecisionDate.GetSafeString(),
                    DocumentsAvailable = vm.DocumentsAvailable,
                    DocumentSignDate = vm.DocumentSignDate.GetSafeString(),
                    FirstActionDate = vm.FirstActionDate.GetSafeString(),
                    FirstMissedPaymentDueDate = vm.FirstMissedPaymentDueDate.GetSafeString(),
                    FirstPlanPaymentDueDate = vm.FirstPlanPaymentDueDate.GetSafeString(),
                    LastPlanPaymentAppliedDate = vm.LastPlanPaymentAppliedDate.GetSafeString(),
                    LastPlanPaymentDueDate = vm.LastPlanPaymentDueDate.GetSafeString(),
                    LossMitigationType = vm.LossMitigationType,
                    NextPlanPaymentDueDate = vm.NextPlanPaymentDueDate.GetSafeString(),
                    OptOutDate = vm.OptOutDate.GetSafeString(),
                    PlanComplete = vm.PlanComplete,
                    PlanIncludesSFBExpiration = vm.PlanIncludesSFBExpiration,
                    PlanPaymentsSuspendedReduced = vm.PlanPaymentsSuspendedReduced,
                    SFBExpirationDate = vm.SFBExpirationDate.GetSafeString(),
                    SFDMSReportDate = vm.SFDMSReportDate.GetSafeString(),
                    SFDMSReported = vm.SFDMSReported,
                    VarianceExtensionDate = vm.VarianceExtensionDate.GetSafeString(),
                    VarianceRequestDate = vm.VarianceRequestDate.GetSafeString()
                };


                ret = client.SaveLossMit(cpa, mdata);

                if (ret.Message == Constant.Success)
                    return Json(new { success = true, message = "Data Saved" });
                else
                    return Json(new { success = false, message = ret.Message });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }
        public ActionResult GetEviction(int loanid)
        {
            var ret = new List<Models.EvictionViewModel>();

            if (loanid == 0)
            {
                return Json(new { success = false, message = "Loan Id is needed" });
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);
                var temp = client.GetEviction(new LoanRequest { LoanId = loanid }, mdata);
                foreach (var t in temp.Evictions)
                {
                    ret.Add(new Models.EvictionViewModel
                    {
                        id = t.LoanEvictionId,
                        LoanId = t.LoanId,
                        CloseAndBillDate = t.CloseAndBillDate,
                        EvictionFirstLegalDate = t.EvictionFirstLegalDate,
                        ReoccupancyDate = t.ReoccupancyDate,
                        UnacceptableDelayStartDate = t.UnacceptableDelayStartDate,
                        VacancyDate = t.VacancyDate,
                        VacancyType = t.VacancyType
                    });
                }
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(ret);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Write, "LossAnalysis")]
        public ActionResult SaveEviction(Models.EvictionViewModel vm)
        {
            var ret = new MessageReply();
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);

                var cpa = new Eviction
                {
                    LoanEvictionId = vm.oper == "add" ? 0 : vm.id,
                    LoanId = vm.LoanId,
                    CloseAndBillDate = vm.CloseAndBillDate.GetSafeString(),
                    EvictionFirstLegalDate = vm.EvictionFirstLegalDate.GetSafeString(),
                    ReoccupancyDate = vm.ReoccupancyDate.GetSafeString(),
                    UnacceptableDelayStartDate = vm.UnacceptableDelayStartDate.GetSafeString(),
                    VacancyDate = vm.VacancyDate.GetSafeString(),
                    VacancyType = vm.VacancyType.GetSafeValue()
                };


                ret = client.SaveEviction(cpa, mdata);

                if (ret.Message == Constant.Success)
                    return Json(new { success = true, message = "Data Saved" });
                else
                    return Json(new { success = false, message = ret.Message });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }

        }
        public ActionResult GetDelay(int loanid)
        {
            var ret = new List<Models.DelayViewModel>();

            if (loanid == 0)
            {
                return Json(new { success = false, message = "Loan Id is needed" });
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);
                var temp = client.GetDelay(new LoanRequest { LoanId = loanid }, mdata);
                foreach (var t in temp.Delays)
                {
                    ret.Add(new Models.DelayViewModel
                    {
                        id = t.LoanDelayId,
                        LoanId = t.LoanId,
                        DelayAcceptable = t.DelayAcceptable.GetSafeValue(),
                        DelayEndDate = t.DelayEndDate.GetSafeString(),
                        DelayReason = t.DelayReason.GetSafeString(),
                        DelayStartDate = t.DelayStartDate.GetSafeString(),
                        DelayType = t.DelayType.GetSafeValue()
                    });
                }
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(ret);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Write, "LossAnalysis")]
        public ActionResult SaveDelay(Models.DelayViewModel vm)
        {
            var ret = new MessageReply();
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);

                var cpa = new Delay
                {
                    LoanDelayId = vm.oper == "add" ? 0 : vm.id,
                    LoanId = vm.LoanId,
                    DelayAcceptable = vm.DelayAcceptable,
                    DelayEndDate = vm.DelayEndDate,
                    DelayReason = vm.DelayReason,
                    DelayStartDate = vm.DelayStartDate,
                    DelayType = vm.DelayType
                };


                ret = client.SaveDelay(cpa, mdata);

                if (ret.Message == Constant.Success)
                    return Json(new { success = true, message = "Data Saved" });
                else
                    return Json(new { success = false, message = ret.Message });
            }
            catch (Exception ex)
            {
                return Json(new {success = false, message = ex.Message });
            }

        }
        public ActionResult GetReconPartA(int loanid)
        {
            var ret = new ReconPartA();

            if (loanid == 0)
            {
                return Json(new { success = false, message = "Loan Id is needed" });
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);
                ret = client.GetReconPartA(new LoanRequest { LoanId = loanid }, mdata);

            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(new { success = true, data = ret });
        }
        public ActionResult GetReconPartB(int loanid)
        {
            var ret = new ReconPartB();

            if (loanid == 0)
            {
                return Json(new { success = false, message = "Loan Id is needed" });
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);
                ret = client.GetReconPartB(new LoanRequest { LoanId = loanid }, mdata);

            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(new { success = true, data = ret });
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Write, "LossAnalysis")]
        public ActionResult SaveReconPartA(Models.SaveReconPartAViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                var msg = string.Join("; ", ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage));
                return View("_Success", new ResponseMessageViewModel { title = "", message = msg });
            }
            var ret = new MessageReply();
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);

                var cpa = new ReconPartA
                {
                    LoanId = vm.LoanId,
                    LoanReconPartAId = vm.LoanReconPartAId.GetSafeValue(),
                    InterestCurtAmount = vm.InterestCurtAmount.GetSafeValue(),
                    InterestCurtRespParty = vm.InterestCurtRespParty.GetSafeValue(),
                    LoanComment = vm.LoanComment.GetSafeString(),
                    UpdatedInterestCurtDate = vm.UpdatedInterestCurtDate.GetSafeString(),
                    UpdateInterestAmount = vm.UpdateInterestAmount.GetSafeValue(),
                    ExpenseCurtDate = vm.ExpenseCurtDate.GetSafeString()
                };
              

                ret = client.SaveReconPartA(cpa, mdata);

                if (ret.Message == Constant.Success)
                    return View("_Success", new ResponseMessageViewModel { title = "Success", message = "Data Saved" });
                else
                    return View("_Success", new ResponseMessageViewModel { title = "", message = ret.Message });
            }
            catch (Exception ex)
            {
                return View("_Success", new ResponseMessageViewModel { title = "", message = ex.Message });
            }

        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Write, "LossAnalysis")]
        public ActionResult SaveReconPartB(Models.SaveReconPartBViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                var msg = string.Join("; ", ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage));
                return View("_Success", new ResponseMessageViewModel { title = "", message = msg });
            }
            var ret = new MessageReply();
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);

                var cpa = new ReconPartB
                {
                    LoanId = vm.LoanId,
                    LoanReconPartBId = vm.LoanReconPartBId.GetSafeValue(),
                    ReconEscrowBalance = vm.ReconEscrowBalance.GetSafeValue(),
                    ReconCorporateBalance = vm.ReconCorporateBalance.GetSafeValue(),
                    ReconSuspenseBalance = vm.ReconSuspenseBalance.GetSafeValue(),
                    ReconRestrictedBalance = vm.ReconRestrictedBalance.GetSafeValue(),
                    ReconLiquidationProceeds = vm.ReconLiquidationProceeds.GetSafeValue(),
                    ReconInterestDifferentialUL = vm.ReconInterestDifferentialUL.GetSafeValue(),
                    CurrenSystemBalance = vm.CurrentSystemBalance.GetSafeValue()
                };
               
                ret = client.SaveReconPartB(cpa, mdata);

                if (ret.Message == Constant.Success)
                    return View("_Success", new ResponseMessageViewModel { title = "Success", message = "Data Saved" });
                else
                    return View("_Success", new ResponseMessageViewModel { title = "", message = ret.Message });
            }
            catch (Exception ex)
            {
                return View("_Success", new ResponseMessageViewModel { title = "", message = ex.Message });
            }

        }
        public ActionResult GetReconSupplemental(int loanid)
        {
            var ret = new ReconSupplemental();

            if (loanid == 0)
            {
                return Json(new { success = false, message = "Loan Id is needed" });
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);
                ret = client.GetReconSupplemental(new LoanRequest { LoanId = loanid }, mdata);

            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(new { success = true, data = ret });
        }
        public ActionResult GetReconSuppDetail(int loanid)
        {
            var ret = new SupplementalDetail();

            if (loanid == 0)
            {
                return Json(new { success = false, message = "Loan Id is needed" });
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);
                ret = client.GetSupplementalDetail(new LoanRequest { LoanId = loanid }, mdata);

            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(new { success = true, data = ret });
        }
        public ActionResult GetReconClientSpecificSuppDetail(int loanid)
        {
            var ret = new ClientSpecificSuppDetail();

            if (loanid == 0)
            {
                return Json(new { success = false, message = "Loan Id is needed" });
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);
                ret = client.GetClentSpecificDetail(new LoanRequest { LoanId = loanid }, mdata);

            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(new { success = true, data = ret });
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Write, "LossAnalysis")]
        public ActionResult SaveReconSupplemental(Models.SaveReconSupplementalViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                var msg = string.Join("; ", ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage));
                return View("_Success", new ResponseMessageViewModel { title = "", message = msg });
            }
            var ret = new MessageReply();
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);

                var cpa = new ReconSupplemental
                {
                    LoanId = vm.LoanId,
                    PartARecoveryAmount = vm.PartARecoveryAmount.GetSafeValue(),
                    PartARecoveryOverrideAmount = vm.PartARecoveryOverrideAmount.GetSafeValue(),
                    PartARefundAmount = vm.PartARefundAmount.GetSafeValue(),
                    PartARefundOverrideAmount = vm.PartARefundOverrideAmount.GetSafeValue(),
                    PartBRecoveryAmount = vm.PartBRecoveryAmount.GetSafeValue(),
                    PartBRecoveryOverrideAmount = vm.PartBRecoveryOverrideAmount.GetSafeValue(),
                    PartBRefundAmount = vm.PartBRefundAmount.GetSafeValue(),
                    PartBRefundOverrideAmount = vm.PartBRefundOverrideAmount.GetSafeValue(),
                    RecoveryAnalystId = vm.RecoveryAnalystId.GetSafeValue(),
                    RefundAnalystId = vm.RefundAnalystId.GetSafeValue()
                };

                ret = client.SaveReconSupplemental(cpa, mdata);

                if (ret.Message == Constant.Success)
                    return View("_Success", new ResponseMessageViewModel { title = "Success", message = "Data Saved" });
                else
                    return View("_Success", new ResponseMessageViewModel { title = "", message = ret.Message });
            }
            catch (Exception ex)
            {
                return View("_Success", new ResponseMessageViewModel { title = "", message = ex.Message });
            }

        }
        public ActionResult GetServicerAccountBalancing(int loanid)
        {
            var ret = new ServicerAccountBalancing();

            if (loanid == 0)
            {
                return Json(new { success = false, message = "Loan Id is needed" });
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);
                ret = client.GetServicerAccountBalancing(new LoanRequest { LoanId = loanid }, mdata);

            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(new { success = true, data = ret });
        } 
        public ActionResult GetReconSuppRecovery(int loanid, int recovery)
        {
            var ret = new List<SupplementalRecovery>();

            if (loanid == 0)
            {
                return Json(new { success = false, message = "Loan Id is needed" });
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                    new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
                };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);
                var temp = client.GetSupplementalRecovery(new GetSupplementalRecoveryRequest { LoanId = loanid, Recovery = recovery}, mdata);
                    ret.AddRange(temp.SupplementalRecoveries);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(ret);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Write, "LossAnalysis")]
        public ActionResult SaveReconSuppDetail(Models.SaveSupplementalDetailViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                var msg = string.Join("; ", ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage));
                return View("_Success", new ResponseMessageViewModel { title = "", message = msg });
            }
            var ret = new MessageReply();
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);

                var cpa = new SupplementalDetail
                {
                    LoanId = vm.LoanId,
                    HUDRecvdAmt = vm.HUDRecvdAmt.GetSafeValue(),
                    HUDRecvdDate = vm.HUDRecvdDate.GetSafeString(),
                    RecoveryAmount = vm.RecoveryAmount.GetSafeValue(),
                    RecoveryFiled = vm.RecoveryFiled.GetSafeString(),
                    RefundAmount = vm.RefundAmount.GetSafeValue(),
                    RefundFiled = vm.RefundFiled.GetSafeString(),
                    SuppTrackingInfo = vm.SuppTrackingInfo.GetSafeString(),
                };

                ret = client.SaveSupplementalDetail(cpa, mdata);

                if (ret.Message == Constant.Success)
                    return View("_Success", new ResponseMessageViewModel { title = "Success", message = "Data Saved" });
                else
                    return View("_Success", new ResponseMessageViewModel { title = "", message = ret.Message });
            }
            catch (Exception ex)
            {
                return View("_Success", new ResponseMessageViewModel { title = "", message = ex.Message });
            }

        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Write, "LossAnalysis")]
        public ActionResult SaveReconClientSuppDetail(Models.SaveClientSpecificViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                var msg = string.Join("; ", ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage));
                return View("_Success", new ResponseMessageViewModel { title = "", message = msg });
            }
            var ret = new MessageReply();
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new LossAnalysis.LossAnalysisClient(channel);

                var cpa = new ClientSpecificSuppDetail
                {
                    LoanId = vm.LoanId,
                    Delievered = vm.Delievered.GetSafeString(),
                    RCAComplete = vm.RCAComplete.GetSafeString(),
                    StepComplete = vm.StepComplete.GetSafeString()
                };

                ret = client.SaveClientSpecificSuppDetail(cpa, mdata);

                if (ret.Message == Constant.Success)
                    return View("_Success", new ResponseMessageViewModel { title = "Success", message = "Data Saved" });
                else
                    return View("_Success", new ResponseMessageViewModel { title = "", message = ret.Message });
            }
            catch (Exception ex)
            {
                return View("_Success", new ResponseMessageViewModel { title = "", message = ex.Message });
            }

        }
    }
  
}