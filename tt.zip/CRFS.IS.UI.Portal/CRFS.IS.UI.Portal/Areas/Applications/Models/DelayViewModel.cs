﻿using System.ComponentModel.DataAnnotations;

namespace CRFS.IS.UI.Portal.Areas.Applications.Models
{
    public class DelayViewModel
    {
        [Required]
        public int id { get; set; }
        [Required]
        public int LoanId { get; set; }
        public int DelayType { get; set; }
        public string DelayStartDate { get; set; }
        public string DelayEndDate { get; set; }
        public string DelayReason { get; set; }
        public int DelayAcceptable { get; set; }
        public string oper { get; set; }
    }
}
