﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CRFS.IS.UI.Portal.Areas.Applications.Models
{
    public class SaveMilestoneViewModel
    {
        public int LoanMilestoneId { get; set; }
        [Required]
        public int LoanId { get; set; }
        public int MilestoneId { get; set; }
        [StringLength(30, ErrorMessage = "Exceeded 30 characters")]
        public string MilestoneName { get; set; }
        public string MilestoneDate { get; set; }
        public int PartAAnalystId { get; set; }
        public int PartBAnalystId { get; set; }
    }
}
