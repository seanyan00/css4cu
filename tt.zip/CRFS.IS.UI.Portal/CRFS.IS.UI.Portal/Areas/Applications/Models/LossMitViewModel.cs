﻿using System.ComponentModel.DataAnnotations;

namespace CRFS.IS.UI.Portal.Areas.Applications.Models
{
    public class LossMitViewModel
    {
        [Required]
        public int id { get; set; }
        [Required]
        public int LoanId { get; set; }
        public int LossMitigationType { get; set; }
        public int SFDMSReported { get; set; }
        public string SFDMSReportDate { get; set; }
        public int DocumentsAvailable { get; set; }
        public string DocumentSignDate { get; set; }
        public string DecisionDate { get; set; }
        public int PlanComplete { get; set; }
        public string BorrowerVacatedDate { get; set; }
        public string LastPlanPaymentDueDate { get; set; }
        public string NextPlanPaymentDueDate { get; set; }
        public string FirstMissedPaymentDueDate { get; set; }
        public string FirstPlanPaymentDueDate { get; set; }
        public string OptOutDate { get; set; }
        public int PlanIncludesSFBExpiration { get; set; }
        public int PlanPaymentsSuspendedReduced { get; set; }
        public string SFBExpirationDate { get; set; }
        public string LastPlanPaymentAppliedDate { get; set; }
        public string ApprovalToParticipateDate { get; set; }
        public string ApprovalToParticipateExpirationDate { get; set; }
        public string ApprovedContractDate { get; set; }
        public int ApprovedVariance { get; set; }
        public string VarianceRequestDate { get; set; }
        public string VarianceExtensionDate { get; set; }
        public string FirstActionDate { get; set; }
        public string oper { get; set; }
    }
}
