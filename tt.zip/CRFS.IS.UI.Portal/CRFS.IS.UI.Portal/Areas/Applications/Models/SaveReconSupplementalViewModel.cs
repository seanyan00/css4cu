﻿using System.ComponentModel.DataAnnotations;

namespace CRFS.IS.UI.Portal.Areas.Applications.Models
{
    public class SaveReconSupplementalViewModel
    {
        [Required]
        public int LoanId { get; set; }
        public double PartARecoveryAmount { get; set; }
        public double PartARecoveryOverrideAmount { get; set; }
        public double PartBRecoveryAmount { get; set; }
        public double PartBRecoveryOverrideAmount { get; set; }
        public double PartARefundAmount { get; set; }
        public double PartARefundOverrideAmount { get; set; }
        public double PartBRefundAmount { get; set; }
        public double PartBRefundOverrideAmount { get; set; }
        public int RecoveryAnalystId { get; set; }
        public int RefundAnalystId { get; set; }
    }
}
