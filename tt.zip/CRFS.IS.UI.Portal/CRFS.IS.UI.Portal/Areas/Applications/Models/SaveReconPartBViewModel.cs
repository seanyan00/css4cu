﻿using System.ComponentModel.DataAnnotations;

namespace CRFS.IS.UI.Portal.Areas.Applications.Models
{
    public class SaveReconPartBViewModel
    {
        public int LoanReconPartBId { get; set; }
        public int LoanId { get; set; }
        public double ReconEscrowBalance { get; set; }
        public double ReconCorporateBalance { get; set; }
        public double ReconLiquidationProceeds { get; set; }
        public double ReconInterestDifferentialUL { get; set; }
        public double ReconSuspenseBalance { get; set; }
        public double ReconRestrictedBalance { get; set; }
        public double CurrentSystemBalance { get; set; }
    }
}
