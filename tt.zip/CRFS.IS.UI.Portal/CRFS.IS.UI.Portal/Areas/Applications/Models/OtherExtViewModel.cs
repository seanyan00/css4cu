﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CRFS.IS.UI.Portal.Areas.Applications.Models
{
    public class OtherExtViewModel
    {
        [Required]
        public int id { get; set; }
        [Required]
        public int LoanId { get; set; }
        public int ExtensionType { get; set; }
        public string HUDExtensionRequestDate { get; set; }
        public string HUDExtensionDate { get; set; }
        public string DeclarationDate { get; set; }
        public string FEMAExtensionDate { get; set; }
        public string FirstActionDate { get; set; }
        public string StatuteStartDate { get; set; }
        public string StatuteEndDate { get; set; }
        public string ActiveDutyStartDate { get; set; }
        public string ActiveDutyDischargeDate { get; set; }
        public string HazardClaimDate { get; set; }
        public string HazardClaimSettlementDate { get; set; }
        public string LossDate { get; set; }
        public string SaleContractApprovalDate { get; set; }
        public string oper { get; set; }
    }
}
