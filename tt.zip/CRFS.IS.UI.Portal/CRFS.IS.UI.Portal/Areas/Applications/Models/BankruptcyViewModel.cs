﻿using System.ComponentModel.DataAnnotations;

namespace CRFS.IS.UI.Portal.Areas.Applications.Models
{
    public class BankruptcyViewModel
    {
        [Required]
        public int id { get; set; }
        [Required]
        public int LoanId { get; set; }
        public int BankruptcyType { get; set; }
        public string BankruptcyCaseNumber { get; set; }
        public string FiledDate { get; set; }
        public string ClearanceDate { get; set; }
        public int OrderGrantingMFR { get; set; }
        public string MotionForReliefDate { get; set; }
        public int RuleWaived { get; set; }
        public int Ruling { get; set; }
        public string DismissalDate { get; set; }
        public string DischargeDate { get; set; }
        public string AttorneyProvidedLiftDate { get; set; }
        public int ClosedSameDayAsDischarge { get; set; }
        public string BankruptcyCompletionDate { get; set; }
        public int BankruptcyCompletionDays { get; set; }
        public int DelaysAcceptable { get; set; }
        public string FirstActionDate { get; set; }
        public string FirstUnacceptableDelay { get; set; }
        public string oper { get; set; }
    }
}
