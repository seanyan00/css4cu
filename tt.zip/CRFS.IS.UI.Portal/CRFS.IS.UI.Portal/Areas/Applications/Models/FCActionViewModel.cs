﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CRFS.IS.UI.Portal.Areas.Applications.Models
{
    public class FCActionViewModel
    {
        [Required]
        public int id { get; set; }
        [Required]
        public int LoanId { get; set; }
        public string FirstLegalDate { get; set; }
        public int? RestartValid { get; set; }
        public int? RestartReason { get; set; }
        public string SFDMSCode68Date { get; set; }
        public int Type { get; set; }
        public string Comments { get; set; }
        public string oper { get; set; }
    }
}
