﻿using System.ComponentModel.DataAnnotations;

namespace CRFS.IS.UI.Portal.Areas.Applications.Models
{
    public class SaveClientSpecificViewModel
    {
        [Required]
        public int LoanId { get; set; }
        public string StepComplete { get; set; }
        public string RCAComplete { get; set; }
        public string Delievered { get; set; }
    }
}
