﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CRFS.IS.UI.Portal.Areas.Applications.Models
{
    public class SaveRecPartAInputViewModel
    {
        [Required]
        public int PartARecId { get; set; }
        [Required]
        public int LoanId { get; set; }
        public int PartACompId { get; set; }
        public double UnpaidPrincipalBalance { get; set; }
        public double AuthorizedBidAmount { get; set; }
        public string EndorsementDate { get; set; }
        public string MarketableTitleDate { get; set; }
        public string DateOfPossessionAndAcquisition { get; set; }
        public string ClientSpecifiedBlock9 { get; set; }
        public string BankruptcyLiftDate { get; set; }
        public string CheckWireDate { get; set; }
        public string SecondChanceSaleDate { get; set; }
        public string ForeclosureDeedRecordedDate { get; set; }
        public string DueDateofLastPaymentInstallment { get; set; }
        public string LastOnTimePaymentDate { get; set; }
        public string DefaultDate { get; set; }
        public string DueDate { get; set; }
        public string OriginalDefaultDate { get; set; }
        public string ForeclosureSaleDate { get; set; }
        public string HUDAssignmentDate { get; set; }
        public string HUDDeedFilingDate { get; set; }
        public string PFSSettlementDate { get; set; }
        public string DeedInLieuDate { get; set; }
        public string DeedInLieuTransferDate { get; set; }
        public string LastLoanModificationDate { get; set; }
        public string ApprovalToParticipateDate { get; set; }
        public string RRCDate { get; set; }
        public string RedemptionDate { get; set; }
        public string FirstInspectionDate { get; set; }
        public int FirstInspectionStatus { get; set; }
        public string DateOfInspectionPriorToFTV { get; set; }
        public string FirstTimeVacancyDate { get; set; }
        public string RecentVacancyDate { get; set; }
        public string FirstSFDMSCode1ADate { get; set; }
        public int SFDMSReportingMissedCycles { get; set; }
        public bool PropertyREOSold { get; set; }
        public bool SufficientPaymentHistory { get; set; }
        public bool BorrowerPaymentsMade { get; set; }
        public double SaleBidAmount { get; set; }
        public int NumberOfLivingUnits { get; set; }
        public double DebentureInterestRate { get; set; }

        public List<LivingUnitViewModel> LivingUnits { get; set; }
        public SaveRecPartAInputViewModel()
        {
            LivingUnits = new List<LivingUnitViewModel>();
        }
    }
}
