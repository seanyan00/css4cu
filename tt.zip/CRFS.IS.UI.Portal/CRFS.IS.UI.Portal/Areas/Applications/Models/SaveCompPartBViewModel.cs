﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

using CRFS.IS.Service.GRpc;

namespace CRFS.IS.UI.Portal.Areas.Applications.Models
{
    public class CompPartBViewModel
    {
        public int LoanId { get; set; }
        public int? PartBBlockId { get; set; }
        public double? SubDeductionAmount { get; set; }
        public double? SubAdditionAmount { get; set; }
        public double? SubInterestAmount { get; set; }
        public double? AOPDeductionAmount { get; set; }
        public double? AOPAdditionAmount { get; set; }
        public double? AOPInterestAmount { get; set; }
        public int? Passed { get; set; }
        public string Note { get; set; }
    }
    public class SaveCompPartBViewModel
    {
        public int LoanId { get; set; }
        public List<CompPartBViewModel> CompPartBs { get; set; }
        public SaveCompPartBViewModel()
        {
            CompPartBs = new List<CompPartBViewModel>();
        }
    }
}
