﻿using System.Collections.Generic;

using CRFS.IS.Service.GRpc;

namespace CRFS.IS.UI.Portal.Areas.Applications.Models
{
    public class ImportHistViewModel
    {
        public List<DataImportHist> DataImportHists { get; set; }
        public ImportHistViewModel()
        {
            DataImportHists = new List<DataImportHist>();
        }
        
    }
}
