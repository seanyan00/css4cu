﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CRFS.IS.UI.Portal.Areas.Applications.Models
{
    public class SaveCompAOPViewModel
    {
        [Required]
        public int AOPId { get; set; }
        [Required]
        public int LoanId { get; set; }
        [Required]
        public int AOPTypeId { get; set; }
        public string ReceivedDate { get; set; }
        public string SettlementDate { get; set; }
        public string InterestStartDate { get; set; }
        public string InterestEndDate { get; set; }
        public double FHASettlementAmount { get; set; }
        public double LessOffsetAmount { get; set; }
        public double TotalInterestPaid { get; set; }
       /* public string DueDateOfLastPaymentInstallment { get; set; }
        public double DebentureInterestRate { get; set; }
        public double UnpaidPrincipalBalance { get; set; }*/
    }
}
