﻿using System.ComponentModel.DataAnnotations;

namespace CRFS.IS.UI.Portal.Areas.Applications.Models
{
    public class EvictionViewModel
    {
        [Required]
        public int id { get; set; }
        [Required]
        public int LoanId { get; set; }
        public int VacancyType { get; set; }
        public string VacancyDate { get; set; }
        public string EvictionFirstLegalDate { get; set; }
        public string CloseAndBillDate { get; set; }
        public string ReoccupancyDate { get; set; }
        public string UnacceptableDelayStartDate { get; set; }
        public string oper { get; set; }
    }
}
