﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

using CRFS.IS.Service.GRpc;

namespace CRFS.IS.UI.Portal.Areas.Applications.Models
{
    public class TimeframeViewModel
    {
        [Required]
        public int LoanId { get; set; }
        public List<Timeframe> Timeframes { get; set; }
        public TimeframeViewModel()
        {
            Timeframes = new List<Timeframe>();
        }
    }
}
