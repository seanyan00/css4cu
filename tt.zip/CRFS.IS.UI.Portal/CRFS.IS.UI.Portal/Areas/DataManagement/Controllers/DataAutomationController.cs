﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Grpc.Core;
using Google.Protobuf.WellKnownTypes;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.GRpc;
using CRFS.IS.UI.Portal.Models;
using CRFS.IS.UI.Portal.Extensions;

namespace CRFS.IS.UI.Portal.Areas.DataManagement.Controllers
{
    [Area("DataManagement")]
    [Authorize]
    public class DataAutomationController : Controller
    {
        private readonly ILogger<DataAutomationController> _logger;
        private readonly IConfiguration _config;
        public DataAutomationController(ILogger<DataAutomationController> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
        }

       [Authorize(Policy = "TokenExists")]
       [AuthAction(Constant.UIPrivilege.Read, "DataAutomation")]
        public ActionResult Index()
        {
            var ug = SessionExtension.GetSessionUser(HttpContext);

            return View(ug);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Write, "DataAutomation")]
        public ActionResult SaveAutoSystemAccount(Models.AutoSystemViewModel vm)
        {
            var ret = new DAMessageReply();
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new DataAutomation.DataAutomationClient(channel);

                var cpa = new AutoSystem
                {
                    Id = vm.oper == "add" ? 0 : vm.id,
                    Active = vm.Active ?? true ? 1 : 0,
                    AuthPmtAdvRetrieve = vm.Auth_PmtAdv_Retrieve ?? false ? 1 : 0,
                    AuthSS820Alt = vm.AuthSS_820Alt ?? false ? 1 : 0,
                    AuthSS824Alt = vm.AuthSS_824Alt ?? false ? 1 : 0,
                    CMSClientId = vm.CMS_ClientId.GetSafeValue(),
                    CredentialsValid = vm.CredentialsValid.GetIntValue(),
                    MainFrameCommand = vm.MainFrameCommand.GetSafeString(),
                    OwnerId = vm.OwnerId.GetSafeValue(),
                    SystemId = vm.SystemId,
                    SystemKey = vm.SystemKey.GetSafeString(),
                    SystemName = vm.SystemName.GetSafeString(),
                    SystemOtherCode = vm.SystemOtherCode.GetSafeString(),
                    SystemPageCheck = vm.SystemPageCheck.GetSafeString(),
                    SystemPassword = vm.SystemPassword.GetSafeString(),
                    SystemType = vm.SystemType.GetSafeString(),
                    SystemURL = vm.SystemURL.GetSafeString(),
                    UsedFor = vm.UsedFor.GetSafeString(),
                    WebCMSClientID = vm.WebCMS_ClientID.GetSafeValue(),
                    UIAct = vm.oper == "del" ? "Delete" : ""
                };

                ret = client.SaveFHAConnectionAccount(cpa, mdata);

                if (ret.Message == Constant.Success)
                    return Json(new { success = true, message = "Data Saved" });
                else
                    return Json(new { success = false, message = ret.Message });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }

        }
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Read, "DataAutomation")]
        public ActionResult GetDAPassword(int id)
        {
            var pwd = Constant.PasswordStr;

            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                if (!(id > 0))
                    throw new Exception("Not valid autosystem ID");

                var client = new DataAutomation.DataAutomationClient(channel);

                var temp = client.GetFHAConnPwd(new DAIdRequest { Id = id }, mdata);
                pwd = temp.Message;
            }
            catch(Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(new { success = true, message = pwd });
        }
        [AuthAction(Constant.UIPrivilege.Write, "DataAutomation")]
        public ActionResult GetAutoSystemAccounts(int gid)
        {
            var ret = new List<Models.AutoSystemViewModel>();
            var ug = SessionExtension.GetSessionUser(HttpContext);

            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new DataAutomation.DataAutomationClient(channel);
                var t = client.GetFHAConnectionAccounts(new Empty(), mdata);
                foreach(var asa in t.AutoSystems)
                {
                    ret.Add(new Models.AutoSystemViewModel
                    {
                        id = asa.Id,
                        Active = asa.Active == 1 || asa.Active == Constant.NULLINT,
                        AuthSS_820Alt = asa.AuthSS820Alt.GetBoolValue(),
                        AuthSS_824Alt = asa.AuthSS824Alt.GetBoolValue(),
                        Auth_PmtAdv_Retrieve = asa.AuthPmtAdvRetrieve.GetBoolValue(),
                        CMS_ClientId = asa.CMSClientId,
                        CredentialsValid = asa.CredentialsValid.GetBoolValue(),
                        MainFrameCommand = asa.MainFrameCommand,
                        OwnerId = asa.OwnerId,
                        PWDChangeDate = asa.PWDChangeDate,
                        SystemId = asa.SystemId,
                        SystemKey = asa.SystemKey,
                        SystemName = asa.SystemName,
                        SystemOtherCode = asa.SystemOtherCode,
                        SystemPageCheck = asa.SystemPageCheck,
                        SystemPassword = asa.SystemPassword,
                        SystemType = asa.SystemType,
                        SystemURL = asa.SystemURL,
                        UsedFor = asa.UsedFor,
                        WebCMS_ClientID = asa.WebCMSClientID
                    });
                }
                if(gid == 1 && !ug.UserGrants.Any(x => x.UIName == "DataAutomation" && x.UIType == "SubApp" && x.UIPermit >= (int)Constant.UIPrivilege.Write))
                {
                    ret = ret.Where(x => x.OwnerId == ug.UserGrants.Select(x => x.UId).First()).ToList();
                }
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(ret);
        }
    }
}