﻿var PWDSTR = "************";
var dm = {
    data: {
        dataautomation: {
            cmsclientlist: {},
            cmsclientlistabbr: {},
            webcmsclientlist: {},
            userlist: {},
            autosystypelist: {}
        }
    },
    init: function () {
        $("#btn_da_fhaconnedit").on("click", function () {
            $("#dv_da_fhaconnedit").removeClass("d-none");
            dm.loadfhaconncredgridadmin();
        });
        $("#dv_da_fhaconncred").on("click change input", "select, input, a.btn, button", function (e) {
            dm.clearpwd();
        });
        $(document).on("click", "a.btngetpwd", function (e) {
            dm.getpwd(e);
        });
        this.disableedit();
        this.loadlists();
        this.loadfhaconncredgriduser();
    },
    loadlists: function () {
        this.data.dataautomation.cmsclientlist = home.loadlisttolocal("cmsclient", "");
        this.data.dataautomation.cmsclientlistabbr = home.loadlisttolocal("cmsclientabbr", "");
        this.data.dataautomation.webcmsclientlist = home.loadlisttolocal("webcmsclient", "");
        this.data.dataautomation.userlist = home.loadlisttolocal("dauser", "");
        this.data.dataautomation.autosystypelist = home.loadlisttolocal("dasystemtype", "");
    },
    disableedit: function () {
        var perm = this.getapppermit("DataAutomation");
        if (!perm || perm < 3)
            $("#btn_da_fhaconnedit").attr("disabled", true);
    },
    getpwd: function (p) {
        p.preventDefault();
        p.stopPropagation();
        var $tr = $(p.target).closest("tr"), id = $tr[0].id;
        $.ajax({
            headers: tokenhead,
            url: getDAPasswordUrl,
            data: {id: id},
            cache: false,
            dataType: "json"
        }).done(function (data) {
            if (data.success) {
                $tr.find("td:nth-child(8)").html(data.message);
                home.copytoclipboard(data.message);
            }
        }).fail(ajaxFailed);
    },
    clearpwd: function () {
        var $trs = $("tr.jqgrow", "#tbl_da_fhaconncred_ro");
        $.each($trs, function () {
            $(this).find("td:nth-child(8)").html(PWDSTR);
        });
    },
    getapppermit: function (p) {
        var ret = 0;

        $.each(userperms, function () {
            if (this.uiType === "SubApp" && this.uiName === p) {
                if (this.uiPermit > ret)
                    ret = this.uiPermit;
            }
        })
        return ret;
    },
    onbeforeshowformfhaconncrededit: function (p) {
        $("#pData, #nData", "#Act_Buttons").hide();
        var perm = dm.getapppermit("DataAutomation");
        $("#systemName", p).attr("disabled", true);
        $("#cmS_ClientId", p).attr("disabled", true);
        if (perm === 3) {
            $("#systemId", p).attr("disabled", true);
            $("#systemKey", p).hide();
            $("#systemPageCheck", p).hide();
            $("#mainFrameCommand", p).hide();
            $("#systemOtherCode", p).hide();
            $("#systemURL", p).hide();
            $("#auth_PmtAdv_Retrieve", p).hide();
            $("#authSS_820Alt", p).hide();
            $("#authSS_824Alt", p).hide();
            $("#credentialsValid", p).hide();
        }
    },
    onbeforeshowformfhaconncredadd: function (p) {
        var perm = dm.getapppermit("DataAutomation");
        $("#systemName", p).attr("disabled", true);

        if (perm === 3) {
            $("#systemKey", p).hide();
            $("#systemPageCheck", p).hide();
            $("#mainFrameCommand", p).hide();
            $("#systemOtherCode", p).hide();
            $("#systemURL", p).hide();
            $("#auth_PmtAdv_Retrieve", p).hide();
            $("#authSS_820Alt", p).hide();
            $("#authSS_824Alt", p).hide();
            $("#credentialsValid", p).hide();
        }
    },
    getpwdformatter: function () {
        return "<a href='#' class='btn btn-xxs btn-primary btngetpwd'>Get Password</a>";
    },
    onaftersubmitfhaconn: function (p) {
        $("#tbl_da_fhaconncred_ro").jqGrid("setGridParam", { datatype: "json" }).trigger("reloadGrid");
        return home.onaftersubmit(p);
    },
    loadfhaconncredgridadmin: function () {
        $("#tbl_da_fhaconncred").jqGrid({
            editurl: saveDAAccountUrl,
            url: getDAAccountUrl,
            datatype: "json",
            postData: { gid: 1 },
            caption: "FHA Connection Accounts",
            colModel: [
                { label: "Id", name: "id", key: true, hidden: true, editable: true },
                {
                    label: "CMS Client", name: 'cmS_ClientId', width: 120, editable: true,
                    edittype: "select", formatter: 'select', editrules: { required: true }, 
                    formatoptions: { value: dm.data.dataautomation.cmsclientlist },
                    editoptions: {
                        value: dm.data.dataautomation.cmsclientlist,
                        dataEvents: [{
                            type: "change", fn: function (e) {
                                var selval = $(e.target).val();
                                var $fm = $(e.target).closest("form");
                                $("#systemName", $fm).val("FHA_" + dm.data.dataautomation.cmsclientlistabbr[selval]);
                            }
                        }]
                    }
                },
                { label: "System Name", name: "systemName", width: 120, editable: true, editrules: { required: true } },
                { label: "System ID", name: "systemId", width: 100, editable: true, editrules: { required: true } },
                {
                    label: "Account Owner", name: 'ownerId', width: 100, editable: true, edittype: "select", formatter: 'select', editrules: { required: true },
                    editoptions: {
                        value: dm.data.dataautomation.userlist
                    }
                },
                {
                    label: "System Type", name: "systemType", width: 100, editable: true, edittype: "select", formatter: 'select', editrules: { required: true },
                    editoptions: {
                        value: dm.data.dataautomation.autosystypelist
                    }
                },
                { label: "Purpose", name: 'usedFor', width: 150, editable: true, editoptions: { maxlength: 256 }, editrules: { required: true } },
                {
                    label: "PmtAdv", name: 'auth_PmtAdv_Retrieve', width: 80, editable: true, align: 'center', formatter: 'checkbox', edittype: 'checkbox', editoptions: {value: "True: False"}
                },
                {
                    label: "820Alt", name: 'authSS_820Alt', width: 80, editable: true, align: 'center', formatter: 'checkbox', edittype: 'checkbox', editoptions: { value: "True: False" }
                },
                {
                    label: "824Alt", name: 'authSS_824Alt', width: 80, editable: true, align: 'center', formatter: 'checkbox', edittype: 'checkbox', editoptions: { value: "True: False" }
                },
                {
                    label: "WebCMS Client", name: 'webCMS_ClientID', width: 120, editable: true,
                    formatter: "select", edittype: "select", editrules: { required: true },
                    editoptions: {
                        value: dm.data.dataautomation.webcmsclientlist
                    }
                },
                {
                    label: "Valid Credential", name: 'credentialsValid', width: 80, editable: true, align: 'center', formatter: 'checkbox', edittype: 'checkbox', editoptions: { value: "True: False" }
                },
                {
                    label: "Active", name: 'active', width: 80, editable: true, align: 'center', formatter: 'checkbox', edittype: 'checkbox', editoptions: { value: "True: False" }
                },
                {
                    label: "Password", name: 'systemPassword', width: 120, editable: true, hidden: true, edittype: 'password', editoptions: { size: 30, maxLength: 20 },
                    editrules: { edithidden: true, required: true}
                },
                { label: "PWD Change Date", name: 'pwdChangeDate', width: 100 },
                {
                    label: "Url", name: "systemURL", width: 120, editable: true, hidden: true, editrules: {edithidden: true}
                },
                {
                    label: "Other Code", name: "systemOtherCode", width: 120, editable: true, hidden: true, editrules: { edithidden: true }
                },
                {
                    label: "Mainframe CMD", name: "mainFrameCommand", width: 120, editable: true, hidden: true, editrules: { edithidden: true }
                },
                {
                    label: "PageCheck", name: "systemPageCheck", width: 120, editable: true, hidden: true, editrules: { edithidden: true }
                },
                {
                    label: "Key", name: "systemKey", width: 120, editable: true, hidden: true, editrules: { edithidden: true }
                }
            ],
            loadonce: true,
            autowidth: true,
            viewrecords: true,
            pginput: false,
            pgbuttons: false,
            height: 300,
            rowNum: 300,
            pager: "#tbl_da_fhaconncred_pager"
        });
        $("#tbl_da_fhaconncred").navGrid("#tbl_da_fhaconncred_pager", {
            del: false, search: false, beforeRefresh: home.onbeforerefresh
        }, { closeAfterEdit: true, recreateForm: true, beforeShowForm: dm.onbeforeshowformfhaconncrededit, afterSubmit: dm.onaftersubmitfhaconn },
            { closeAfterAdd: true, recreateForm: true, beforeShowForm: dm.onbeforeshowformfhaconncredadd, afterSubmit: dm.onaftersubmitfhaconn }
        );
        $("#tbl_da_fhaconncred").jqGrid("setGroupHeaders", {
            groupHeaders: [
                { startColumnName: 'auth_PmtAdv_Retrieve', numberOfColumns: 3, titleText: 'Used by Automation' }
            ]
        });
    },
    loadfhaconncredgriduser: function () {
        $("#tbl_da_fhaconncred_ro").jqGrid({
            url: getDAAccountUrl,
            datatype: "json",
            postData: { gid: 2 },
            colModel: [
                { label: "Id", name: "id", key: true, hidden: true},
                {
                    label: "CMS Client", name: 'cmS_ClientId', width: 120,
                    formatter: "select", formatoptions: { value: dm.data.dataautomation.cmsclientlist }
                },
                { label: "System Name", name: "systemName", width: 120},
                { label: "System ID", name: "systemId", width: 100},
                {
                    label: "Account Owner", name: 'ownerId', width: 100, formatter: 'select',
                    formatoptions: {
                        value: dm.data.dataautomation.userlist
                    }
                },
                {
                    label: "System Type", name: "systemType", width: 100, formatter: 'select',
                    formatoptions: {
                        value: dm.data.dataautomation.autosystypelist
                    }
                },
                { label: "Purpose", name: 'usedFor', width: 150 },
                {
                    label: "Password", name: 'systemPassword', width: 100
                },
                {
                    label: " ", name: 'act', width: 100, align: 'center', formatter: dm.getpwdformatter
                }               
            ],
            loadonce: true,
            width: 1200,
            viewrecords: true,
            height: 250,
            rowNum: 300,
            pginput: false,
            pgbuttons: false,
            pager: "#tbl_da_fhaconncred_ro_pager"
        });
      
    }
}