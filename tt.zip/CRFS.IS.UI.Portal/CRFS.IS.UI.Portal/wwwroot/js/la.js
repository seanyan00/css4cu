﻿var lossanalysis = {
    data: {
        dirty: false,
        loans: [{ value: '0084912062', data: '0084912062' }, { value: '0074912222', data: '0074912222' },
        { value: '1064916666', data: '1064916666' }, { value: '1074917777', data: '1074917777' }],
        loan: {},
        parta: { faction: {
                            dirty: false,
                            lastselectedrow: 0,
                            restartreasonlist: "Bankruptcy: Bankruptcy;Porforminglossmit:Performing LossMit; Court Delays: Court Delays",
                            typelist: "Judical:Judical",
                            testdata: [
                                { Id: "1", FirstLegalDate: "01/30/2020", RestartValidity: "Invalid", RestartReason: "Court Delays", SFDMSCode68Date: "", ActionType: "Judical", Comments: ""},
                                { Id: "2", FirstLegalDate: "01/29/2020", RestartValidity: "Valid", RestartReason: "", SFDMSCode68Date: "", ActionType: "", Comments: ""}
                            ]
        }, oextension: {
                dirty: false,
                lastselectedrow: 0,
                data: []
            },
            bankruptcy: {
                dirty: false,
                lastselectedrow: 0,
                bankruptcytypelist: "",
                data: []
            },
            lossmit: {
                dirty: false,
                lastselectedrow: 0,
                lossmittypelist: "",
                data: []
            },
            eaction: {
                dirty: false,
                lastselectedrow: 0,
                data: []
            },
            odelay: {
                dirty: false,
                lastselectedrow: 0,
                typelist: [],
                data: []
            }
        },
        partb: {},
        completedclaim: {},
        reconciliation: {},
        workflow: {}

    },
    init: function () {
        $('.autocomplete').autocomplete({
            lookup: lossanalysis.data.loans
           /* onSelect: function (p) {
                alert(p.value + ', ' + p.data);
            }*/
        });
        $(".btn-collapse").click(function () {
            var $span = $(this).find("span");
            if ($span.hasClass("glyphicon-triangle-top")) {
                $span.removeClass("glyphicon-triangle-top");
                $span.addClass("glyphicon-triangle-bottom");
            } else {
                $span.removeClass("glyphicon-triangle-bottom");
                $span.addClass("glyphicon-triangle-top");
            }
        });
       /* $('.datepicker').datepicker({
            format: 'mm/dd/yyyy',
            todayHighlight: true
        });*/
        $("select, input:checkbox, input:text", "form[id^='fm_la_']").on("change input click", function () {
            home.clearinfo();
        });
        $("#tb_parta").on("shown.bs.tab", function (e) {
            lossanalysis.loadfactiongrid(e);
            lossanalysis.loadoextensiongrid(e);
            lossanalysis.loadbankruptcygrid(e);
            lossanalysis.loadlossmitgrid(e);
            lossanalysis.loadeactiongrid(e);
            lossanalysis.loadodelaygrid(e);
        })
    },
    editrowfaction: function (p) {
        var $grid = $("#tbl_parta_faction");
        if (p && p !== lossanalysis.data.parta.faction.lastselectedrow) {
            $grid.jqGrid('restoreRow', lossanalysis.data.parta.faction.lastselectedrow);
            $grid.jqGrid('editRow', p, { keys: false }); /*key true enable Enter to save*/
            lossanalysis.data.parta.faction.lastselectedrow = p;
            $("#tbl_parta_faction_iledit", "#tbl_parta_faction_pager").trigger("click");
        } else {
            if (p == lossanalysis.data.parta.faction.lastselectedrow
                && $("#" + p, $grid).attr("editable") !== "1") {
                $grid.jqGrid('editRow', p, { keys: false });
                $("#tbl_parta_faction_iledit", "#tbl_parta_faction_pager").trigger("click");
            }
        }
    },
    enabledatepicker: function (p) {
        $(p).datepicker({
            format: 'mm/dd/yyyy',
            todayHighlight: true,
            autoclose: true
        }); 
    },
    loadfactiongrid: function (p) {
        $("#tbl_parta_faction").jqGrid({
            data: lossanalysis.data.parta.faction.testdata,
            datatype: "local",
            editurl: "clientArray",
            caption: "Foreclosure Action",
            colModel: [
                { label: "Id", name: "Id", key: true, hidden: true },
                { label: "First Legal Date", name: 'FirstLegalDate', width: 100, editable: true, editoptions: {  size: 20, dataInit: lossanalysis.enabledatepicker }},
                { label: "Restart Validity", name: 'RestartValidity', width: 140, editable: true, edittype: "select", formatter: "select", editoptions: { value: "Invalid:Invalid;Invalid:Valid" } },
                {
                    label: "Restart Reason", name: 'RestartReason', width: 100, editable: true, formatter: "select", formatoptions: { value: lossanalysis.data.parta.faction.restartreasonlist },
                        edittype: "select", editoptions: { value: lossanalysis.data.parta.faction.restartreasonlist }
                    
                },
                { label: "SFDMS Code 68 Date", name: 'SFDMSCode68Date', width: 120, editable: true, editoptions: { size : 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "Action Type", name: "ActionType", width: 100, editable: true, formatter: "select", formatoptions: {
                        value: lossanalysis.data.parta.faction.typelist
                    },
                        edittype: "select", editoptions: { value: lossanalysis.data.parta.faction.typelist } },
                { label: "Comments", name: "Comments", width: 200, editable: true}
            ],
            loadonce: true,
            autowidth: true,
            viewrecords: true,
            onSelectRow: lossanalysis.editrowfaction, 
            height: 200,
            rowNum: 10,
            pager: "#tbl_parta_faction_pager"

        });
        $("#tbl_parta_faction").navGrid("#tbl_parta_faction_pager", {
            add: false, edit: false, search: false, refresh: false/*,
            beforeRefresh: home.onbeforerefresh*/
        });
        $("#tbl_parta_faction").inlineNav("#tbl_parta_faction_pager", {});
            /*saveAfterSelect: true
            add: true, edit: true, cancel: true, resotrAfterSelect: false });*/
    },
    editrowoextension: function (p) {
        var $grid = $("#tbl_parta_oextension");
        if (p && p !== lossanalysis.data.parta.oextension.lastselectedrow) {
            $grid.jqGrid('restoreRow', lossanalysis.data.parta.oextension.lastselectedrow);
            $grid.jqGrid('editRow', p, { keys: false }); /*key true enable Enter to save*/
            lossanalysis.data.parta.oextension.lastselectedrow = p;
            $("#tbl_parta_oextension_iledit", "#tbl_parta_oextension_pager").trigger("click");
        } else {
            if (p == lossanalysis.data.parta.oextension.lastselectedrow
                && $("#" + p, $grid).attr("editable") !== "1") {
                $grid.jqGrid('editRow', p, { keys: false });
                $("#tbl_parta_oextension_iledit", "#tbl_parta_oextension_pager").trigger("click");
            }
        }
    },
    loadoextensiongrid: function (p) {
        $("#tbl_parta_oextension").jqGrid({
            data: lossanalysis.data.parta.oextension.data,
            datatype: "local",
            editurl: "clientArray",
            caption: "Other Extensions",
            colModel: [
                { label: "Id", name: "Id", key: true, hidden: true },
                {label: "TYpe", name: "Type", editable: true, width: 80 },
                { label: "Request Date", name: 'RequestDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Extension Date", name: 'ExtensionDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "HUD Specified Ext Date(FEMA)", name: 'HUDSpecifiedExtDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "First Action Date", name: 'FirstActionDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Statute Start Date", name: 'StatuteDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Statute End Date", name: 'StatuteEndDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Start of Active Duty Date", name: 'StartOfActiveDutyDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Discharge Date", name: 'DischargeDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Hazard Claim Date", name: 'HazardClaimDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Hazard Claim Settlement Date", name: 'HazardClaimSettlementDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Date of Loss", name: 'DateOfLoss', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Sales Contract Approval Date", name: 'SalesContractApprovalDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } }
            ],
            loadonce: true,
            autowidth: true,
            viewrecords: true,
            onSelectRow: lossanalysis.editrowoextension,
            height: 200,
            rowNum: 10,
            pager: "#tbl_parta_oextension_pager"

        });
        $("#tbl_parta_oextension").navGrid("#tbl_parta_oextension_pager", {
            add: false, edit: false, search: false, refresh: false/*,
            beforeRefresh: home.onbeforerefresh*/
        });
        $("#tbl_parta_oextension").inlineNav("#tbl_parta_oextension_pager", {});
    },
    editrowbankruptcy: function (p) {
        var $grid = $("#tbl_parta_bankruptcy");
        if (p && p !== lossanalysis.data.parta.bankruptcy.lastselectedrow) {
            $grid.jqGrid('restoreRow', lossanalysis.data.parta.bankruptcy.lastselectedrow);
            $grid.jqGrid('editRow', p, { keys: false }); /*key true enable Enter to save*/
            lossanalysis.data.parta.bankruptcy.lastselectedrow = p;
            $("#tbl_parta_bankruptcy_iledit", "#tbl_parta_bankruptcy_pager").trigger("click");
        } else {
            if (p == lossanalysis.data.parta.bankruptcy.lastselectedrow
                && $("#" + p, $grid).attr("editable") !== "1") {
                $grid.jqGrid('editRow', p, { keys: false });
                $("#tbl_parta_bankruptcy_iledit", "#tbl_parta_bankruptcy_pager").trigger("click");
            }
        }
    },
    loadbankruptcygrid: function (p) {
        $("#tbl_parta_bankruptcy").jqGrid({
            data: lossanalysis.data.parta.bankruptcy.data,
            datatype: "local",
            editurl: "clientArray",
            caption: "Bankruptcy",
            colModel: [
                { label: "Id", name: "Id", key: true, hidden: true },
                {
                    label: "Bankruptcy Type", name: 'BankruptcyType', width: 100, editable: true, formatter: "select", edittype: "select",
                    editoptions: { value: lossanalysis.data.parta.bankruptcy.bankruptcytypelist },
                    formatoptions: { value: lossanalysis.data.parta.bankruptcy.bankruptcytypelist }
                },
                { label: "Filed Date", name: 'FiledDate', width: 120, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Clearance Date", name: 'ClearanceDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "Order Granting Motion for Relief", name: 'OrderGrantingMotionForRelief', width: 100, editable: true, edittype: "select", formatter: "select",
                    editoptions: { value: "No:No;Yes:Yes" }
                },
                { label: "Motion for Relief Date", name: 'MotionForReliefDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "4001 Rule Waived", name: '4001RuleWaived', width: 100, editable: true, edittype: "select", formatter: "select",
                    editoptions: { value: "No:No;Yes:Yes" }
                },
                {
                    label: "Ruling", name: 'Ruling', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: {"discharged" : "Discharged", "dismissed" : "Dismissed"}},
                    editoptions: { value: { "discharged": "Discharged", "dismissed": "Dismissed" } }
                },
                { label: "Dismissal Date", name: 'DismissalDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Discharge Date", name: 'DischargeDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Attorney Provided Lift Date", name: 'AttorneyProvidedLiftDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "Closed Same Day as Discharge", name: 'Closed Same Day as Discharge', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                { label: "BK Completion Date", name: 'BKCompletionDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Days of Acceptable BK Completion", name: 'DaysOfAcceptableBKCompletion', width: 80, editable: true },
                {
                    label: "Were Delays Acceptable?", name: 'WereDelaysAcceptable', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                { label: "Forclosure First Action Date", name: 'ForeclosureFirstActionDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Case Number", name: 'CaseNumber', width: 100, editable: true},
                { label: "First Unacceptable Delay", name: 'FirstUnacceptableDelay', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } }
            ],
            loadonce: true,
            autowidth: true,
            viewrecords: true,
            onSelectRow: lossanalysis.editrowbankruptcy,
            height: 200,
            rowNum: 10,
            pager: "#tbl_parta_bankruptcy_pager"

        });
        $("#tbl_parta_bankruptcy").navGrid("#tbl_parta_bankruptcy_pager", {
            add: false, edit: false, search: false, refresh: false/*,
            beforeRefresh: home.onbeforerefresh*/
        });
        $("#tbl_parta_bankruptcy").inlineNav("#tbl_parta_bankruptcy_pager", {});
    },
    editrowlossmit: function (p) {
        var $grid = $("#tbl_parta_lossmit");
        if (p && p !== lossanalysis.data.parta.lossmit.lastselectedrow) {
            $grid.jqGrid('restoreRow', lossanalysis.data.parta.lossmit.lastselectedrow);
            $grid.jqGrid('editRow', p, { keys: false }); /*key true enable Enter to save*/
            lossanalysis.data.parta.lossmit.lastselectedrow = p;
            $("#tbl_parta_lossmit_iledit", "#tbl_parta_lossmit_pager").trigger("click");
        } else {
            if (p == lossanalysis.data.parta.lossmit.lastselectedrow
                && $("#" + p, $grid).attr("editable") !== "1") {
                $grid.jqGrid('editRow', p, { keys: false });
                $("#tbl_parta_lossmit_iledit", "#tbl_parta_lossmit_pager").trigger("click");
            }
        }
    },
    loadlossmitgrid: function (p) {
        $("#tbl_parta_lossmit").jqGrid({
            data: lossanalysis.data.parta.lossmit.data,
            datatype: "local",
            editurl: "clientArray",
            caption: "Loss Mitigation",
            colModel: [
                { label: "Id", name: "Id", key: true, hidden: true },
                {
                    label: "Loss Mitigation Type", name: 'LossMitigationType', width: 100, editable: true, formatter: "select", edittype: "select",
                    editoptions: { value: lossanalysis.data.parta.lossmit.lossmittypelist },
                    formatoptions: { value: lossanalysis.data.parta.lossmit.lossmittypelist }
                },
                {
                    label: "Reports to SFDMS", name: 'ReportsToSFDMS', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                { label: "Reports to SFDMS Date", name: 'ReportsToSFDMSDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "Documentation Available", name: 'DocumentationAvailable', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                { label: "Document Signed Date", name: 'DocumentSignedDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Decision Date", name: 'DecisionDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "Plan Complete", name: 'WereDelaysAcceptable', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                { label: "Borrower Vacated Date", name: 'BorrowerVacatedDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Last Plan Payment Due Date", name: 'LastPlanPaymentDueDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Next Plan Payment Due Date", name: 'NextPlanPaymentDueDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "First Missed Payment Due Date", name: 'FirstMissedPaymentDueDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "First Plan Payment Due Date", name: 'FirstPlanPaymentDueDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "Borrower Opted Out", name: 'BorrowerOptedOut', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                { label: "Opted Out Date", name: 'OptedOutDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "Plan Includes SFB Expiration Date", name: 'PlanIncludesSFBExpirationDate', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                {
                    label: "Plan Payments Suspended or Reduced", name: 'PlanPaymentsSuspended', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                { label: "Special Forbearance Expiration Date", name: 'SpecialForbearanceExpirationDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Last Plan Payment Applied to Loan Date", name: 'LastPlanPaymentAppliedToLoanDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Approval to Participate Date", name: 'ApprovalToParticipateDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Approval to Participate Expiration Date", name: 'ApprovalToParaticipateExpirationDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Approved Contract Date", name: 'ApprovedContractDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "Approved Variance", name: 'ApprovedVariance', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                { label: "Variance Request Date", name: 'VarianceRequestDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Variance Extension Date", name: 'VarianceExtensionDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Foreclosure First Action Date", name: 'ForeclosureFirstActionDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } }
            ],
            loadonce: true,
            autowidth: true,
            viewrecords: true,
            onSelectRow: lossanalysis.editrowlossmit,
            height: 200,
            rowNum: 10,
            pager: "#tbl_parta_lossmit_pager"

        });
        $("#tbl_parta_lossmit").navGrid("#tbl_parta_lossmit_pager", {
            add: false, edit: false, search: false, refresh: false/*,
            beforeRefresh: home.onbeforerefresh*/
        });
        $("#tbl_parta_lossmit").inlineNav("#tbl_parta_lossmit_pager", {});
    },
    editroweaction: function (p) {
        var $grid = $("#tbl_parta_eaction");
        if (p && p !== lossanalysis.data.parta.eaction.lastselectedrow) {
            $grid.jqGrid('restoreRow', lossanalysis.data.parta.eaction.lastselectedrow);
            $grid.jqGrid('editRow', p, { keys: false }); /*key true enable Enter to save*/
            lossanalysis.data.parta.eaction.lastselectedrow = p;
            $("#tbl_parta_eaction_iledit", "#tbl_parta_eaction_pager").trigger("click");
        } else {
            if (p == lossanalysis.data.parta.eaction.lastselectedrow
                && $("#" + p, $grid).attr("editable") !== "1") {
                $grid.jqGrid('editRow', p, { keys: false });
                $("#tbl_parta_eaction_iledit", "#tbl_parta_eaction_pager").trigger("click");
            }
        }
    },
    loadeactiongrid: function (p) {
        $("#tbl_parta_eaction").jqGrid({
            data: lossanalysis.data.parta.eaction.data,
            datatype: "local",
            editurl: "clientArray",
            caption: "Eviction Action",
            colModel: [
                { label: "Id", name: "Id", key: true, hidden: true },
                { label: "Eviction First Legal Date", name: 'EvictionFirstLegalDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Unacceptable Delay Start Date", name: 'UnacceptableDelayStartDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Vacancy Date", name: 'VacancyDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Close and Bill Date", name: 'CloseAndBillDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Reoccupancy Date", name: 'ReoccupancyDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "Vacancy Type", name: 'VacancyType', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: { "lockout": "Lockout", "voluntary": "Voluntary" } },
                    editoptions: { value: { "lockout": "Lockout", "voluntary": "Voluntary" } }
                }
            ],
            loadonce: true,
            autowidth: true,
            viewrecords: true,
            onSelectRow: lossanalysis.editroweaction,
            height: 200,
            rowNum: 10,
            pager: "#tbl_parta_eaction_pager"

        });
        $("#tbl_parta_eaction").navGrid("#tbl_parta_eaction_pager", {
            add: false, edit: false, search: false, refresh: false/*,
            beforeRefresh: home.onbeforerefresh*/
        });
        $("#tbl_parta_eaction").inlineNav("#tbl_parta_eaction_pager", {});
    },
    editrowodelay: function (p) {
        var $grid = $("#tbl_parta_odelay");
        if (p && p !== lossanalysis.data.parta.odelay.lastselectedrow) {
            $grid.jqGrid('restoreRow', lossanalysis.data.parta.odelay.lastselectedrow);
            $grid.jqGrid('editRow', p, { keys: false }); /*key true enable Enter to save*/
            lossanalysis.data.parta.odelay.lastselectedrow = p;
            $("#tbl_parta_odelay_iledit", "#tbl_parta_odelay_pager").trigger("click");
        } else {
            if (p == lossanalysis.data.parta.odelay.lastselectedrow
                && $("#" + p, $grid).attr("editable") !== "1") {
                $grid.jqGrid('editRow', p, { keys: false });
                $("#tbl_parta_odelay_iledit", "#tbl_parta_odelay_pager").trigger("click");
            }
        }
    },
    loadodelaygrid: function (p) {
        $("#tbl_parta_odelay").jqGrid({
            data: lossanalysis.data.parta.odelay.data,
            datatype: "local",
            editurl: "clientArray",
            caption: "Other Delays",
            colModel: [
                { label: "Id", name: "Id", key: true, hidden: true },
                { label: "Start Date", name: 'StartDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "End Date", name: 'EndDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "Acceptable", name: 'Acceptable', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: { "acceptable": "Acceptable", "unacceptable": "Unacceptable" } },
                    editoptions: { value: { "acceptable": "Acceptable", "unacceptable": "Unacceptable" } }
                },
                { label: "Reason", name: "Reason", width: 100, editable: true },
                {
                    label: "Type", name: 'Type', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: lossanalysis.data.parta.odelay.typelist },
                    editoptions: { value: lossanalysis.data.parta.odelay.typelist }
                }
            ],
            loadonce: true,
            autowidth: true,
            viewrecords: true,
            onSelectRow: lossanalysis.editrowodelay,
            height: 200,
            rowNum: 10,
            pager: "#tbl_parta_odelay_pager"

        });
        $("#tbl_parta_odelay").navGrid("#tbl_parta_odelay_pager", {
            add: false, edit: false, search: false, refresh: false/*,
            beforeRefresh: home.onbeforerefresh*/
        });
        $("#tbl_parta_odelay").inlineNav("#tbl_parta_odelay_pager", {});
    }
};