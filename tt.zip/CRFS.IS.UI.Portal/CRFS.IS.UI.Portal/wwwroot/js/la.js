﻿var lossanalysis = {
    data: {
        dirty: false,
        dirtyobj: null,
        lauserlist: {},
        investorlist: {},
        statelist: {},
        claimtypelist: {},
        milestonelist: {},
        closereasonlist: {},
        occupancystatuslist: {},
        resppartylist: {},
        partatypelist: {},
        loans: [],
        head: {
            dirty: false
        },
        loan: {
            dirty: false
        },
        parta: {
            input: {
                dirty: false
            },
            timeframe: {
                dirty: false
            },
            faction: {
                dirty: false,
                lastselectedrow: 0,
                restartreasonlist: {},
                typelist: {},
                testdata: [
                    { Id: "1", FirstLegalDate: "01/30/2020", RestartValidity: "Invalid", RestartReason: "Court Delays", SFDMSCode68Date: "", ActionType: "Judical", Comments: "" },
                    { Id: "2", FirstLegalDate: "01/29/2020", RestartValidity: "Valid", RestartReason: "", SFDMSCode68Date: "", ActionType: "", Comments: "" }
                ]
            }, oextension: {
                dirty: false,
                lastselectedrow: 0,
                exttypelist: {},
                data: []
            },
            bankruptcy: {
                dirty: false,
                lastselectedrow: 0,
                bankruptcytypelist: {},
                rulinglist: {},
                data: []
            },
            lossmit: {
                dirty: false,
                lastselectedrow: 0,
                lossmittypelist: {},
                codelist: {},
                data: []
            },
            eviction: {
                dirty: false,
                lastselectedrow: 0,
                evictiontypelist: {},
                data: []
            },
            odelay: {
                dirty: false,
                lastselectedrow: 0,
                delaytypelist: [],
                data: []
            }
        },
        partb: {
            dirty: false,
            lastselectedrow: 0,
            expcatlist: {},
            expsubcatlist: {},
            expadvfromlist: {},
            expchargeoffreason: {},
        
        },
        completedclaim: {
            aoptypelist: {},
            tierratelist: {},
            parta: {
                dirty: false

            },
            aop1: {
                dirty: false
            },
            aop2: {
                dirty: false
            },
            partb: {
                dirty: false
            }
        },
        reconciliation: {
            categorylist: "",
            subcategorylist: "",
            supprecovery: {
                lastselectedrow: 0,
                data: []
            },
            supprefund: {
                lastselectedrow: 0,
                data: []
            },
            parta: {
                dirty: false
            },
            partb: {
                dirty: false,
            },
            supp: {
                dirty: false
            },
            suppdetail: {
                dirty: false
            },
            clientspec: {
                dirty: false
            }
        },
        workflow: {
            lastselectedrow: 0,
            milestonelist: "",
            milestonestatuslist: "",
            data: []
        },
        import: {
            importtemplist: {},
            data: [],
            error: [],
            files: []
        }
    },
    init: function () {
        $(".btn-collapse").click(function () {
            var $span = $(this).find("span");
            if ($span.hasClass("glyphicon-triangle-top")) {
                $span.removeClass("glyphicon-triangle-top");
                $span.addClass("glyphicon-triangle-bottom");
            } else {
                $span.removeClass("glyphicon-triangle-bottom");
                $span.addClass("glyphicon-triangle-top");
            }
        });
        $("select, input:checkbox, input:text", "form").on("change input click", function () {
            home.clearinfo();
        });
        $("input:text", "form").on("change", function (e) {
            var $ele = $(e.target);
            if ($ele.closest("div").hasClass("datepicker")) {
                $ele.val(home.datenorm($ele.val()));
            }
        });
        $("#tb_completedclaim").on("show.bs.tab", function (e) {
            if (lossanalysis.getloanid() <= 0) {
                e.preventDefault();
                return false;
            }
        });
        $("#tb_parta").on("show.bs.tab", function (e) {
            if (lossanalysis.getloanid() <= 0) {
                e.preventDefault();
                return false;
            }
        });
        $("#tb_partb").on("show.bs.tab", function (e) {
            if (lossanalysis.getloanid() <= 0) {
                e.preventDefault();
                return false;
            }
        });
        $("#tb_recon").on("show.bs.tab", function (e) {
            if (lossanalysis.getloanid() <= 0) {
                e.preventDefault();
                return false;
            }
        });
     /*   $("#tb_import").on("show.bs.tab", function (e) {
            if (lossanalysis.getloanid() <= 0) {
                e.preventDefault();
                return false;
            }
        });*/
        $("#tb_completedclaim").on("shown.bs.tab", function (e) {
            lossanalysis.initialcompletedclaim();

        });
        $("#tb_parta").on("shown.bs.tab", function (e) {
            lossanalysis.initialrecparta(e);
        });
        $("#tb_partb").on("shown.bs.tab", function (e) {
            lossanalysis.loadpartbexpgrid(e);
        });
        $("#tb_recon").on("shown.bs.tab", function (e) {
            lossanalysis.initialreconciliation(e);
        });
        $("#tb_workflow").on("shown.bs.tab", function (e) {
            lossanalysis.loadworkflowgrid(e);
        });
        $("#tb_import").on("shown.bs.tab", function (e) {
            lossanalysis.getddlhtmlfromlist("ddl_importtemp", lossanalysis.data.import.importtemplist, 1);
            lossanalysis.loadimporthistgrid(e);
        });
        $("a[data-toggle='tab']").on("hide.bs.tab", function (e) {
            var dirty = false;
            switch (e.target.id) {
                case "tb_loan":
                    dirty = lossanalysis.data.loan.dirty;
                    break;
                case "tb_completedclaim":
                    dirty = lossanalysis.data.completedclaim.parta.dirty || lossanalysis.data.completedclaim.aop1.dirty
                        || lossanalysis.data.completedclaim.aop2.dirty || lossanalysis.data.completedclaim.partb.dirty;
                    break;
                case "tb_parta":
                    dirty = lossanalysis.data.parta.input.dirty || lossanalysis.data.parta.timeframe.dirty;
                    break;
                case "tb_partb":
                    break;
                case "tb_recon":
                    dirty = lossanalysis.data.reconciliation.parta.dirty || lossanalysis.data.reconciliation.partb.dirty
                        || lossanalysis.data.reconciliation.supp.dirty || lossanalysis.data.reconciliation.suppdetail.dirty
                        || lossanalysis.data.reconciliation.clientspec.dirty;
                    break;
                default:
                    break;
            }
            if (dirty) {
                if (!window.confirm("There are uncommitted changes. OK to leave this tab?")) {
                    e.preventDefault();
                    e.stopPropagation();
                    return false;
                }
            }
        });
        $("#btn_head_edit").click(function (e) {
            var $panel = $(e.target).closest(".panel").find(".panel-body");
            $(".toggle-title", $panel).hide();
            $(".toggle-input", $panel).show();

            var divs = $("div.toggle-title", $panel);
            $.each(divs, function () {
                var $this = $(this);
                var text = $this.find("label").text();
                var $input = $this.siblings("div.toggle-input").find("input");
                var $select = $this.siblings("div.toggle-input").find("select");
                if ($input.length === 1) 
                    $input.val(text);
                if ($select.length === 1) {
                    $select.find("option").filter(function () {
                        return $(this).text() == text;
                    }).prop('selected', true);
                }
            })
        });
        $("#btn_head_cancel").click(function (e) {
            lossanalysis.data.head.dirty = false;

            var $panel = $(e.target).closest(".panel").find(".panel-body");
            $(".toggle-input", $panel).hide();
            $(".toggle-title", $panel).show();
        });
        $("#btn_head_save").click(function (e) {
            var $panel = $(e.target).closest(".panel").find(".panel-body");
            $(".toggle-input", $panel).hide();
            $(".toggle-title", $panel).show();

            var divs = $("div.toggle-title", $panel);
            $.each(divs, function () {
                var $this = $(this);
                var $input = $this.siblings("div.toggle-input").find("input");
                var $select = $this.siblings("div.toggle-input").find("select");
                if ($input.length === 1)
                    $this.find("label").text($input.val());
                if ($select.length === 1) {
                    $this.find("label").text($select.find("option:selected").text());
                }
            });
            if (lossanalysis.data.head.dirty) {
                home.setelepos(e.target);
                home.data.submitcallback = lossanalysis.loanheadsubmitcallback;
                $("#fm_la_pagehead").find("button[type='submit']").trigger("click");
               
            }
        });
        $("#dv_la_import_dropzone").on("dragenter", function (e) {
            e.preventDefault();
            e.stopPropagation();
        });
        $("#dv_la_import_dropzone").on("dragover", function (e) {
            e.preventDefault();
            e.stopPropagation();
        });
        $("#dv_la_import_dropzone").on("drop", function (e) {
            e.preventDefault();
            e.stopPropagation();

            var $dv = $("#dv_dropicon");
            if (e.originalEvent.dataTransfer.files.length > 0) {
                if (e.originalEvent.dataTransfer.files.length + lossanalysis.data.import.files >= 5) {
                    home.showinfo("Only 5 files are allowed", true);
                    return;
                }
                for (var i = 0; i < e.originalEvent.dataTransfer.files.length; i++) {
                    lossanalysis.data.import.files.push(e.originalEvent.dataTransfer.files[i]);

                    var html = "<div class='file-drop-icon' draggable='true' ondragstart='lossanalysis.ondragstartfileicon(event)'"
                             + " >" + e.originalEvent.dataTransfer.files[i].name + "</div";
                    $dv.append(html);
                }
            }
        });
        $("#dv_import").on("dragenter", function (e) {
            e.preventDefault();
            e.stopPropagation();
        });
        $("#dv_import").on("dragover", function (e) {
            e.preventDefault();
            e.stopPropagation();
        });
        $("#dv_import").on("drop", function (e) {
            e.preventDefault();
            e.stopPropagation();
            var f = home.data.dragfileicon;

            if (lossanalysis.data.import.files.length > 0) { 
                lossanalysis.data.import.files = $.grep(lossanalysis.data.import.files, function (t) {
                    return t.name != f;
                });
            }
            $.each($("div.file-drop-icon", "#dv_dropicon"), function () {
                if ($(this).html() === f) {
                    $(this).remove();
                    return false;
                }
            });
            home.data.dragfileicon = null;
        });
        $("#fm_la_import").submit(function (e) {
            e.preventDefault();
            var $this = $(this);
            var fdata = new FormData(this);
       
            if (lossanalysis.data.import.files !== null && lossanalysis.data.import.files.length > 0) {
                for (var i = 0; i < lossanalysis.data.import.files.length; i++)
                    fdata.append("DataFiles[" + i + "].DF", lossanalysis.data.import.files[i], lossanalysis.data.import.files[i].name);
            } else {
                if ($("#fl_datafile").val().length === 0) {
                    home.showinfo("No file has been selected", true);
                    return;
                }
            }
        
            home.showloading();
            $.ajax({
                type: $this.attr('method'),
                url: $this.attr('action'),
                data: fdata,
                contentType: false,
                processData: false
            }).done(function (data) {
                home.removeloading();

                if (data.success) {
                    home.removeloading();
                    lossanalysis.data.import.files = [];
                    $this[0].reset();
                    $("#dv_dropicon").html("");
                }
                home.showinfo(data.message, !data.success);
            }).fail(ajaxFailed);
        });
        $("#txt_search_loannumber").on("click", function () {
            home.clearinfo();
        });
        $("#txt_search_loannumber").on("keyup", function (e) {
            if (e.keyCode === 13)
                $("#btn_loan_search").trigger("click");      
        });
        $("#btn_loan_search").on("click", function (e) {
            var loannumber = $("#txt_search_loannumber").val();
            if (loannumber.length < 5)
                return;

            $.ajax({
                url: getLoanDataUrl + "?loannumber=" + loannumber,
                dataType: "json",
                cache: false
            }).done(function (data) {
                if (data.success) {
                    lossanalysis.resetforms();

                    $("#tb_loan").trigger("click");
                    lossanalysis.loadloandata(data.data);

                    window.setTimeout(function () { lossanalysis.refreshgrids(); }, 2000);
                } else {
                    home.showinfo("No Loan was found", true);
                }

            }).fail(ajaxFailed);
        });
        $("#dv_loan_sum").on("change", " select", function (e) {
            lossanalysis.data.head.dirty = true;
        });
        $("#dv_loandetail").on("change click", "input:text, select", function (e) {
            lossanalysis.data.loan.dirty = true;
        });
        $("#dv_completed_parta").on("change click", "input:text, select", function (e) {
            lossanalysis.data.completedclaim.parta.dirty = true;
        });
        $("#dv_completed_aop_1").on("change click", "input:text, select", function (e) {
            lossanalysis.data.completedclaim.aop1.dirty = true;
        }); 
        $("#dv_completed_aop_2").on("change click", "input:text, select", function (e) {
            lossanalysis.data.completedclaim.aop2.dirty = true;
        }); 
        $("#dv_completed_formpartb").on("change click", "input:text, select", function (e) {
            lossanalysis.data.completedclaim.partb.dirty = true;
        }); 
        $("#dv_parta_input").on("change click", "input:text, select", function (e) {
            lossanalysis.data.parta.input.dirty = true;
        }); 
        $("#dv_parta_tf").on("change click", ":text, select, :checkbox", function (e) {
            lossanalysis.data.parta.timeframe.dirty = true;
        }); 
        $("#dv_recon_parta").on("change click", "input:text, select", function (e) {
            lossanalysis.data.reconciliation.parta.dirty = true;
        }); 
        $("#dv_recon_partb").on("change click", "input:text", function (e) {
            lossanalysis.data.reconciliation.partb.dirty = true;
            lossanalysis.setreconpartbamounts();
        }); 
        $("#dv_recon_supp").on("chnage click", "input:text, select", function (e) {
            lossanalysis.data.reconciliation.supp.dirty = true;
        });
        $("#dv_recon_suppd").on("change click", "input:text", function (e) {
            lossanalysis.data.reconciliation.suppdetail.dirty = true;
        }); 
        $("#dv_recon_clnspec").on("change click", "input:text", function (e) {
            lossanalysis.data.reconciliation.clientspec.dirty = true;
        }); 
        $("#btn_comparta_cancel").click(function () {
            lossanalysis.data.completedclaim.parta.dirty = false;
        });
        $("#btn_compaop_cancel_1").click(function () {
            lossanalysis.data.completedclaim.aop1.dirty = false;
        });
        $("#btn_compaop_cancel_2").click(function () {
            lossanalysis.data.completedclaim.aop2.dirty = false;
        });
        $("#btn_compartb_cancel").click(function () {
            lossanalysis.data.completedclaim.partb.dirty = false;
        });
        $("#btn_loandetail_cancel").click(function () {
            lossanalysis.data.loan.dirty = false;
        });
        $("#btn_parta_input_cancel").click(function () {
            lossanalysis.data.parta.input.dirty = false;
        });
        $("#btn_parta_tf_cancel").click(function () {
            lossanalysis.data.parta.timeframe.dirty = false;
        });
       /* $("#fm_compartb").on("submit", function (e) {
            $(this).append("<input type='hidden' name='LoanId' value='" + lossanalysis.getloanid() + "' />")
            return true;
        });*/
        $("#btn_reconparta_cancel").click(function () {
            lossanalysis.data.reconciliation.parta.dirty = false;
        });
        $("#btn_reconpartb_cancel").click(function () {
            lossanalysis.data.reconciliation.partb.dirty = false;
        });
        $("#btn_reconsupp_cancel").click(function () {
            lossanalysis.data.reconciliation.supp.dirty = false;
        });
        $("#btn_reconsuppd_cancel").click(function () {
            lossanalysis.data.reconciliation.suppdetail.dirty = false;
        });
        $("#btn_reconcln_cancel").click(function () {
            lossanalysis.data.reconciliation.clientspec.dirty = false;
        });
        $("#tbl_comppartb tr").on("click", function (e) {
            var $self = $(this);
            $self.siblings().removeClass("bg-highlight");
            $self.addClass("bg-highlight");
        });
        $("#txt_comparta_lunum").on("change", function (e) {
            var v = $(e.target).val();
            if (v > 4) {
                e.preventDefault();
                return false;
            }
            var $ludv = $("#dv_comparta_lus");
            var lus = $("div.lurow", $ludv);
            var diff = v - lus.length;
            if (diff > 0) {
                for (var i = lus.length; i < v; i++) {
                    lossanalysis.appendlu($ludv, i);
                }
            }
        });
        $("#dv_completed_formpartb :text:not([id^='txt_note_'])").on("change", function (e) {
            var $row = $(e.target).closest("tr");
            lossanalysis.setpass($row);
            lossanalysis.settotal();
        });
        $("#dv_parta_tf :text:not([readonly])").on("change", function (e) {
            var $row = $(e.target).closest(".row");
            lossanalysis.settfpass($row);
        });
        $("#btn_compparta_save").on("click", function (e) {
            e.preventDefault();
            e.stopPropagation();
            if (lossanalysis.data.completedclaim.parta.dirty) {
                home.setelepos(e.target);
                lossanalysis.data.completedclaim.parta.dirty = false;
                $("#fm_comparta").submit();
            }
        });
        $("#btn_compaop_save_1").on("click", function (e) {
            e.preventDefault();
            e.stopPropagation(); 
            if (lossanalysis.data.completedclaim.aop1.dirty) {
                home.setelepos(e.target);
                home.data.submitcallback = lossanalysis.compaop1callback;
                
                $("#fm_compaop_1").submit();
            }
        });
        $("#btn_compaop_save_2").on("click", function (e) {
            e.preventDefault();
            e.stopPropagation();
            if (lossanalysis.data.completedclaim.aop2.dirty) {
                home.setelepos(e.target);
                home.data.submitcallback = lossanalysis.compaop2callback;
                $("#fm_compaop_2").submit();
            }
        });
        $("#btn_compartb_save").on("click", function (e) {
            e.preventDefault();
            e.stopPropagation();
            if (lossanalysis.data.completedclaim.partb.dirty) {
                home.setelepos(e.target);
                home.data.submitcallback = lossanalysis.compartbcallback;
                $("#fm_comppartb").submit();
            }
        });
        $("#btn_parta_input_save").on("click", function (e) {
            e.preventDefault();
            e.stopPropagation();
            if (lossanalysis.data.parta.input.dirty) {
                home.setelepos(e.target);
                home.data.submitcallback = lossanalysis.partainputcallback;
                $("#fm_parta_input").submit();
            }
        });
        $("#btn_parta_tf_save").on("click", function (e) {
            e.preventDefault();
            e.stopPropagation();
            if (lossanalysis.data.parta.timeframe.dirty) {
                home.setelepos(e.target);
                home.data.submitcallback = lossanalysis.partatfcallback;
                $("#fm_partatimeframe").submit();
            }
        });
        $("#btn_loandetail_save").on("click", function (e) {
            e.preventDefault();
            e.stopPropagation();
            if (lossanalysis.data.loan.dirty) {
                home.setelepos(e.target);
                home.data.submitcallback = lossanalysis.loansubmitcallback;
                $("#fm_la_saveloan").submit();
            }
        });
        $("#btn_reconparta_save").on("click", function (e) {
            e.preventDefault();
            e.stopPropagation();
            if (lossanalysis.data.reconciliation.parta.dirty) {
                home.setelepos(e.target);
                home.data.submitcallback = lossanalysis.reconpartacallback;
                $("#fm_reconparta").submit();
            }
        });
        $("#btn_reconpartb_save").on("click", function (e) {
            e.preventDefault();
            e.stopPropagation();
            if (lossanalysis.data.reconciliation.partb.dirty) {
                home.setelepos(e.target);
                home.data.submitcallback = lossanalysis.reconpartbcallback;
                $("#fm_reconpartb").submit();
            }
        });
        $("#btn_reconsupp_save").on("click", function (e) {
            e.preventDefault();
            e.stopPropagation();
            if (lossanalysis.data.reconciliation.supp.dirty) {
                home.setelepos(e.target);
                home.data.submitcallback = lossanalysis.reconsuppcallback;
                $("#fm_reconsupp").submit();
            }
        });
        $("#btn_reconsuppd_save").on("click", function () {
            e.preventDefault();
            e.stopPropagation();
            if (lossanalysis.data.reconciliation.suppdetail.dirty) {
                home.setelepos(e.target);
                home.data.submitcallback = lossanalysis.reconsuppdcallback;
                $("#fm_reconsuppd").submit();
            }
        });
        $("#btn_reconcln_save").on("click", function (e) {
            e.preventDefault();
            e.stopPropagation();
            if (lossanalysis.data.reconciliation.clientspec.dirty) {
                home.setelepos(e.target);
                home.data.submitcallback = lossanalysis.reconclncallback;
                $("#fm_reconcln").submit();
            }
        });
        $("#btn_recparta_setcomp").on("click", function (e) {
            home.setelepos(e.target);
            e.preventDefault();
            e.stopPropagation();
            lossanalysis.savemilestone("Part-A Complete Date");
        });
        $("#btn_partb_setcomp").on("click", function (e) {
            home.setelepos(e.target);
            e.preventDefault();
            e.stopPropagation();
            lossanalysis.savemilestone("Part-B Complete Date");
        });
        this.initialloanddls();
    },

    resetforms: function () {
        $("#fm_comppartb")[0].reset();
    },
    ondragstartfileicon: function (p) {
        p.stopPropagation();
        home.data.dragfileicon = $(p.target).html();
    },
    initialloanddls: function () {
        this.loadloanlist();
        lossanalysis.data.lauserlist = this.loadlisttolocal("lauser", "");
        lossanalysis.data.investorlist = this.loadlisttolocal("lainvestor", "");
        lossanalysis.data.claimtypelist = this.loadlisttolocal("laclaimtype", "");
        lossanalysis.data.statelist = this.loadlisttolocal("states", "");
        lossanalysis.data.milestonelist = this.loadlisttolocal("lamilestone", "");
        lossanalysis.data.closereasonlist = this.loadlisttolocal("laclosereason", "");
        lossanalysis.data.occupancystatuslist = this.loadlisttolocal("occupancystatus", "");
        lossanalysis.data.partatypelist = this.loadlisttolocal("partatype", "");
        lossanalysis.data.resppartylist = this.loadlisttolocal("respparty", "");
        lossanalysis.data.partb.expcatlist = this.loadlisttolocal("expcategory", "");
        lossanalysis.data.partb.expadvfromlist = this.loadlisttolocal("expadvancefrom", "");
        lossanalysis.data.partb.expchargeoffreason = this.loadlisttolocal("expchargeoffreason", "");
        lossanalysis.data.import.importtemplist = this.loadlisttolocal("importtemplate", "");

        lossanalysis.data.resppartylist = home.prepand({ "0": "" }, lossanalysis.data.resppartylist);
        lossanalysis.data.partb.expchargeoffreason = home.prepand({ "0": "" }, lossanalysis.data.partb.expchargeoffreason);

        this.getddlhtmlfromlist("ddl_partaanalyst", lossanalysis.data.lauserlist, 1);
        this.getddlhtmlfromlist("ddl_partbanalyst", lossanalysis.data.lauserlist, 1);
        this.getddlhtmlfromlist("ddl_investor", lossanalysis.data.investorlist, 1);
        this.getddlhtmlfromlist("ddl_claimtype", lossanalysis.data.claimtypelist, 1);
        this.getddlhtmlfromlist("ddl_propertystateid", lossanalysis.data.statelist, 1);
        this.getddlhtmlfromlist("ddl_loanstatus", lossanalysis.data.milestonelist, 1);
        this.getddlhtmlfromlist("ddl_closereason", lossanalysis.data.closereasonlist, 1);
       
    },
    initialcompletedclaim: function () {
        $("#dv_compaop_partial").hide();
        $("form input:hidden[id^='hdn_loanid_']").val(lossanalysis.getloanid());
        lossanalysis.data.completedclaim.aoptypelist = lossanalysis.loadlisttolocal("aoptype", "");
        lossanalysis.data.completedclaim.tierratelist = lossanalysis.loadlisttolocal("clienttierrate", "");

        lossanalysis.loadcompparta();
        lossanalysis.loadcompaop();
        lossanalysis.loadcomppartb();
    },
    initialrecparta: function (p) {
        lossanalysis.data.parta.faction.restartreasonlist = lossanalysis.loadlisttolocal("fcrestartreason", "");
        lossanalysis.data.parta.faction.typelist = lossanalysis.loadlisttolocal("fcactiontype", "");
        lossanalysis.data.parta.oextension.exttypelist = lossanalysis.loadlisttolocal("laloanexttype", "");
        lossanalysis.data.parta.bankruptcy.bankruptcytypelist = lossanalysis.loadlisttolocal("bankruptcytype", "");
        lossanalysis.data.parta.bankruptcy.rulinglist = lossanalysis.loadlisttolocal("bankruptcyruling", "");
        lossanalysis.data.parta.lossmit.lossmittypelist = lossanalysis.loadlisttolocal("lossmittype", "");
        lossanalysis.data.parta.eviction.evictiontypelist = lossanalysis.loadlisttolocal("evictiontype", "");
        lossanalysis.data.parta.odelay.delaytypelist = lossanalysis.loadlisttolocal("delaytype", "");

        $("form input:hidden[id^='hdn_loanid_']").val(lossanalysis.getloanid());

        lossanalysis.loadsection(getRecPartAInputUrl, lossanalysis.loadrecpartainputdata);
        lossanalysis.loadsection(getPartATimeframeUrl, lossanalysis.loadrecpartatimeframedata);
        lossanalysis.loadfactiongrid(p);
        lossanalysis.loadoextensiongrid(p);
        lossanalysis.loadbankruptcygrid(p);
        lossanalysis.loadlossmitgrid(p);
        lossanalysis.loadeactiongrid(p);
        lossanalysis.loadodelaygrid(p);
    },
    initialreconciliation: function (p) {
        lossanalysis.getddlhtmlfromlist("ddl_reconparta_respparty", lossanalysis.data.resppartylist, 1);
        lossanalysis.getddlhtmlfromlist("ddl_reconsupp_recanalyst", lossanalysis.data.lauserlist, 1);
        lossanalysis.getddlhtmlfromlist("ddl_reconsupp_refanalyst", lossanalysis.data.lauserlist, 1);
  
        $("form input:hidden[id^='hdn_loanid_']").val(lossanalysis.getloanid());
        
        lossanalysis.loadsection(getReconPartAUrl, lossanalysis.loadreconpartadata);
        lossanalysis.loadsection(getReconPartBUrl, lossanalysis.loadreconpartbdata);
        lossanalysis.loadsection(getReconSuppUrl, lossanalysis.loadreconsuppdata);
        lossanalysis.loadsection(getServicerAccountBalancingUrl, lossanalysis.loadreconsabdata);
        lossanalysis.loadsection(getReconSuppDetailUrl, lossanalysis.loadreconsuppdetaildata);
        lossanalysis.loadsection(getReconClientSpecificSuppRecoveryUrl, lossanalysis.loadreconclnspecdata);

        lossanalysis.loadreconrecoverygrid(p);
        lossanalysis.loadreconrefundgrid(p);
    },
    refreshgrids: function () {
        var grids = $("div.la-content table.ui-jqgrid-btable");
        $.each(grids, function () {
            var id = $(this).attr("id");
            $("#" + id).jqGrid("clearGridData");
            $("#" + id).jqGrid("setGridParam", { datatype: "json" }).trigger("reloadGrid");
        });
    },
    loadloanlist: function () {
        $.ajax({
            url: getKeyValueListUrl + "?name=laloan&id=",
            dataType: "json",
            async: false
        }).done(function (data) {
            if (data.success) {
                lossanalysis.data.loans = [];
                $.each(data.data, function () {
                    lossanalysis.data.loans.push({ value: this.Value, data: this.Key });
                });
                $('.autocomplete').autocomplete({
                    lookup: lossanalysis.data.loans,
                    lookupFilter: function (p, p1, p2) {
                        return p.value.toLowerCase().indexOf(p2) == 0;
                    }
                });
            }
        }).fail(ajaxFailed);
    },
    loadlisttolocal: function (p, p1) {
        var ret = {};
        $.ajax({
            url: getKeyValueListUrl + "?name=" + p + "&id=" + p1,
            dataType: "json",
            async: false
        }).done(function (data) {
            if (data.success) {
                $.each(data.data, function () {
                    ret[this.Key] = this.Value;
                });
            }
        }).fail(ajaxFailed);
        return ret;
    },
    getddlhtmlfromlist: function (p, p1, p2) {
        var html = "";
        if (p2 === 1)
            html += "<option value=''></option>";

        $.each(p1, function (key, value) {
            html += "<option value='" + key + "'>" + value + "</option>"; 
        });
        $("#" + p).html(html);
    },
    getobjhtmlfromlist: function (p, p1, p2) {
        var html = "";
        if (p2 === 1)
            html += "<option value=''></option>";

        $.each(p1, function (key, value) {
            html += "<option value='" + key + "'>" + value + "</option>";
        });
        p.html(html);
    },
    getddlhtmlstringfromlist: function (p, p1) {
        /* p1: 0, no select; 1: select val is empty; 2: select val = 0 */
        var html = "";

        if (p1 === 1)
            html += "<option value=''></option>";
        if (p1 === 2)
            html += "<option value='0'></option>";
        $.each(p, function (key, value) {
            html += "<option value='" + key + "'>" + value + "</option>";
        });
        return html;
    },
    getclientid: function () {
        return $("#hdn_clientid", "#dv_loandetail").val();
    },
    getloanid: function () {
        return $("#hdn_loanid", "#dv_loan_sum").val();
    },
    loadsection: function (p, p1) {
        var loanid = lossanalysis.getloanid();
        $.ajax({
            url: p + "?loanid=" + loanid,
            dataType: "json",
            cache: false
        }).done(function (data) {
            if (data.success) {
                p1(data.data);
            }
        }).fail(ajaxFailed);
    },
    savemilestone: function (p) {
        var loanid = lossanalysis.getloanid();
        var milestoneid = 0;
        $.each(lossanalysis.data.milestonelist, function (key, value) {
            if (value == p) {
                milestoneid = key;
                return false;
            }
        });
        var vm = {
            LoanMilestoneId: 0,
            LoanId: loanid,
            MilestoneId: milestoneid,
            MilestoneName: p,
            MilestoneDate: new Date().toLocaleString(),
            PartAAnalystId: 0,
            PartBAnalystId: 0
        };
        $.ajax({
            url: saveMilestoneUrl,
            type: "POST",
            headers: tokenhead,
            data: vm,
            cache: false
        }).done(function (data) {
            if (data.indexOf("Success") >= 0) {
                home.showinfo("Data Saved", false);
                $("#btn_loan_search").trigger("click");
            }
            else
                home.showinfo("Not Saved", true);
        }).fail(ajaxFailed);
    },
    loanheadsubmitcallback: function () {
        lossanalysis.data.head.dirty = false;
    },
    loansubmitcallback: function () {
        lossanalysis.data.loan.dirty = false;
        $("#btn_loan_search").trigger("click");
    },
    compaop1callback: function () {
        lossanalysis.data.completedclaim.aop1.dirty = false;
    },
    compaop2callback: function () {
        lossanalysis.data.completedclaim.aop2.dirty = false;
    },
    compartbcallback: function () {
        lossanalysis.data.completedclaim.partb.dirty = false;
    },
    partainputcallback: function () {
        lossanalysis.data.parta.input.dirty = false;
    },
    partatfcallback: function () {
        lossanalysis.data.parta.timeframe.dirty = false;
    },
    reconpartacallback: function () {
        lossanalysis.data.reconciliation.parta.dirty = false;
    },
    reconpartbcallback: function () {
        lossanalysis.data.reconciliation.partb.dirty = false;
    },
    reconsuppcallback: function () {
        lossanalysis.data.reconciliation.supp.dirty = false;
    },
    reconsuppdcallback: function () {
        lossanalysis.data.reconciliation.suppdetail.dirty = false;
    },
    reconclncallback: function () {
        lossanalysis.data.reconciliation.clientspec.dirty = false;
    },
    loadloandata: function (p) {
        $("input:hidden[id^='hdn_loanid']").val(p.loanId);
        $("#lb_loannumber").text(p.loanNumber);
        $("#lb_fhacasenumber").text(p.fhaCaseNumber);
        $("#lb_clientname").text(p.clientName);
        $("#hdn_clientid").val(p.clientId);
        $("#hdn_partaanalystid").val(p.partAAnalystId);
        $("#hdn_partbanalystid").val(p.partBAnalystId);
        $("#lb_claimtypename").text(p.claimTypeName);
        $("#lb_partaanalystname").text(p.partAAnalystName);
        $("#lb_partbanalystname").text(p.partBAnalystName);
        $("#lb_statusname").text(p.statusName);
        $("#lb_completedate").text(p.closeDate);
        $("#lb_partacompletedate").text(p.partACompleteDate);
        $("#lb_partbcompletedate").text(p.partBCompleteDate);
        $("#lb_closereasonname").text(p.closingReasonName);
        $("#lb_referraldate").text(p.lossAnalysisReferralDate);
        $("#lb_duedate").text(p.lossAnalysisDueDate);

        $("#lb_loannumber_1").text(p.loanNumber);
        $("#hdn_loannumber").val(p.loanNumber);
        $("#hdn_fhacasenumber").val(p.fhaCaseNumber);
      
        $("#txt_firstname").val(p.borrowerFirstName);
        $("#txt_lastname").val(p.borrowerLastName);
        $("#txt_propertyaddress1").val(p.propertyStreetAddressLine1);
        $("#txt_propertyaddress2").val(p.propertyStreetAddressLine2);
        $("#txt_propertycity").val(p.propertyCity);
        $("#ddl_propertystateid").val(p.propertyStateId);
        $("#txt_propertyzipcode").val(p.propertyZipCode);
        $("#ddl_investor").val(p.investorId);
        $("#ddl_claimtype").val(p.claimTypeId);
        $("#ddl_loanstatus").val(p.statusId);
        $("#txt_statusdate").val(p.statusDate);
        $("#txt_duedate").val(p.lossAnalysisDueDate);
        $("#txt_referraldate").val(p.lossAnalysisReferralDate);
        $("#txt_buyoutdate").val(p.buyOutDate);
        $("#txt_servicetransferdate").val(p.serviceTransferDate);
       // $("#txt_debentureinterestrate").val(p.debentureInterestRate);
        $("#txt_noterate").val(p.noteRate);
        $("#txt_lotsize").val(p.propertyLotSize);
        $("#txt_completedate").val(p.closeDate);
        $("#ddl_closereason").val(p.closingReasonId);
    },
    loadcompparta: function () {
        var loanid = lossanalysis.getloanid();
        $.ajax({
            url: getCompPartAUrl + "?loanid=" + loanid,
            dataType: "json",
            cache: false
        }).done(function (data) {
            if (data.success) {
                lossanalysis.loadcomppartadata(data.data);
            }
        }).fail(ajaxFailed);
    },
    loadcomppartadata: function (p) {
        var $dv = $("#dv_completed_parta");
        $("#hdn_loanid_comparta", $dv).val(p.loanId);
        $("#hdn_comparta_id", $dv).val(p.partACompId);
        $("#txt_comparta_endorsementdate", $dv).val(p.endorsementDate);
        $("#txt_comparta_fileddate", $dv).val(p.claimFiledDate);
        $("#txt_comparta_debentureinterest", $dv).val(p.debentureInterestRate);
        $("#txt_comparta_duedatelastinstallment", $dv).val(p.dueDateOfLastPaymentInstallment);
        $("#txt_comparta_possessionacqudate", $dv).val(p.dateOfPossessionAcquisition);
        $("#txt_comparta_datedeed", $dv).val(p.dateDeedOrAssignmentFiled);
        $("#txt_comparta_fcdate", $dv).val(p.foreclosureFirstLegalDate);
        $("#txt_comparta_deedinliudate", $dv).val(p.deedInLieuDate);
        $("#txt_comparta_origprincipal", $dv).val(p.originalPrincipalBalance);
        $("#txt_comparta_unpaidprincipal", $dv).val(p.unpaidPrincipalBalance);
        $("#txt_comparta_instextensiondate", $dv).val(p.institutionExtensionDate);
        $("#txt_comparta_convextensiondate", $dv).val(p.conveyanceExtensionDate);
        $("#txt_comparta_bcliftdate", $dv).val(p.bankruptcyLiftDate);
        $("#txt_comparta_commadjfmv", $dv).val(p.authorizedBidAmount);
        $("#txt_comparta_mortgageecurtdate", $dv).val(p.mortgageeCurtailmentDate);
        $("#lb_comparta_firstname", $dv).text(p.borrowerFirstName);
        $("#lb_comparta_lastname", $dv).text(p.borrowerLastName);
        $("#lb_comparta_address1", $dv).text(p.propertyStreetAddressLine1);
        $("#lb_comparta_address2", $dv).text(p.propertyStreetAddressLine2);
        $("#lb_comparta_city", $dv).text(p.propertyCity);
        $("#lb_comparta_state", $dv).text(p.propertyStateName);
        $("#lb_comparta_zip", $dv).text(p.propertyZipCode);
        $("#txt_comparta_lunum", $dv).val(p.numberOfLivingUnits);
        var $ludv = $("#dv_comparta_lus", $dv);
        $ludv.empty();
        var len = p.livingUnits == null ? 0 : p.livingUnits.length;
       
        for (var i = 0; i < len; i++) {
            lossanalysis.appendlu($ludv, i);
            $row = $ludv.find("div.lurow").last();
          /*  $("input:hidden[id^='hdn_comparta_lunum_']", $row).val(i + 1); */
            $("select[id^='ddl_comparta_lustatus_']", $row).val(p.livingUnits[i].unitOccupancyStatusId);
            $("input[id^='txt_comparta_luname_']", $row).val(p.livingUnits[i].unitOccupantName);
            $("input[id^='txt_comparta_lusecdate_']", $row).val(p.livingUnits[i].unitSecuredDate);
            $("input[id^='txt_comparta_luvacdate_']", $row).val(p.livingUnits[i].unitVacatedDate);
        }
          
        var diff = p.numberOfLivingUnits - len;
        if (diff > 0) {
            for (var i = len; i < p.numberOfLivingUnits; i++) {
                lossanalysis.appendlu($ludv, i);
            }
        }
    },
    appendlu: function (p, p1) {
        var html = $("#scp_comparta_lu").html();
        var temp = html.replace(/\{0\}/g, p1);
        temp = temp.replace(/\{1\}/g, p1 + 1);
        p.append(temp);
        var $row = p.find("div.lurow").last();
        var $ddlst = $("select[id^='ddl_comparta_lustatus_']", $row);
        var opts = lossanalysis.getddlhtmlstringfromlist(lossanalysis.data.occupancystatuslist, 2);
        $ddlst.html(opts);
    },
    loadcompaop: function () {
        var loanid = lossanalysis.getloanid();
        $.ajax({
            url: getCompAOPUrl + "?loanid=" + loanid,
            dataType: "json",
            cache: false
        }).done(function (data) {
            if (data.success) {
                lossanalysis.loadcompaopdata(data.data);
            }
        }).fail(ajaxFailed);
    },
    loadcompaopdata: function (p) {
        var clmtyp = $("#lb_claimtypename", "#dv_loan_sum").text();
        if (clmtyp.toUpperCase().indexOf("CONVEYANCE") >= 0) {
            $("#dv_compaop_partial").show();
        }

        $.each(p.compAOPs, function () {
            var $dv = null;
            if (this.aopTypeName.indexOf("Full") >= 0)
                $dv = $("#dv_compaop_full");
            else
                $dv = $("#dv_compaop_partial");

            $("input:hidden[id^='hdn_loanid_compaop_']", $dv).val(this.loanId);
            $("input:hidden[id^='hdn_compaop_aopid_']", $dv).val(this.aopId);
            $("input:hidden[id^='hdn_compaop_aoptypeid_']", $dv).val(this.aopTypeId);
            $("input[id^='txt_compaop_setdate_']", $dv).val(this.settlementDate);
            $("input[id^='txt_compaop_receiveddate_']", $dv).val(this.receivedDate);
            $("input[id^='txt_compaop_interestsatrt_']", $dv).val(this.interestStartDate);
            $("input[id^='txt_compaop_interestend_']", $dv).val(this.interestEndDate);
            $("input[id^='txt_compaop_ttlinst_']", $dv).val(this.totalInterestPaid);
            $("input[id^='txt_compaop_fhaamount_']", $dv).val(this.fhaSettlementAmount);
            $("input[id^='txt_compaop_lessoffamount_']", $dv).val(this.lessOffsetAmount);
        });
    },
    loadcomppartb: function () {
        var loanid = lossanalysis.getloanid();
        $.ajax({
            url: getCompPartBUrl + "?loanid=" + loanid,
            dataType: "json",
            cache: false
        }).done(function (data) {
            if (data.success) {
                lossanalysis.loadcomppartbdata(data.data);
            }
        }).fail(ajaxFailed);
    },
    loadcomppartbdata: function (p) {
        var $dv = $("#dv_completed_formpartb");
        var tr = 0;
        $.each(lossanalysis.data.completedclaim.tierratelist, function (Key, Value) {
            if (Key == lossanalysis.getclientid()) {
                tr = Value;
                return false;
            }
        })
        $("#lb_tierrate").text(tr);
        var $trs = $("table", $dv).find("tr:gt(1)").not(":last");
        $.each(p.compPartBs, function () {
            var data = this;
            var bid = data.partBBlockName.substr(0, 3);
            $.each($trs, function () {
                var $row = $(this);
                var tds = $row.find("td").toArray();
                if (tds[0].innerHTML.substr(0, 3) == bid) {
                    $row.find("input:hidden[id^='hdn_blockid_']").val(data.partBBlockId);

                    if ($(tds[1]).find(":text").length > 0) {
                        $(tds[1]).find(":text").val(data.subDeductionAmount);
                        $(tds[4]).find(":text").val(data.aopDeductionAmount);
                    }
                    if ($(tds[2]).find(":text").length > 0) {
                        $(tds[2]).find(":text").val(data.subAdditionAmount);
                        $(tds[5]).find(":text").val(data.aopAdditionAmount);
                    }
                    if ($(tds[3]).find(":text").length > 0) {
                        $(tds[3]).find(":text").val(data.subInterestAmount);
                        $(tds[6]).find(":text").val(data.aopInterestAmount);
                    }
                    $(tds[8]).find(":text").val(data.note);
                    return false;
                }
            });
        });
        $.each($trs, function () {
            lossanalysis.setpass($(this));
        });
        lossanalysis.settotal();
    },
    settotal: function () {
        var $dv = $("#dv_completed_formpartb");
        var $trs = $("table", $dv).find("tr:gt(1)").not(":last");
        var ttds = $("table", $dv).find("tr:last").find("td").toArray();
        var v1 = 0, v2 = 0, v3 = 0, v4 = 0, v5 = 0, v6 = 0;
        $.each($trs, function () {
            var temptds = $(this).find("td").toArray();
            if ($(temptds[1]).find(":text").length > 0) {
                var tv = parseFloat($(temptds[1]).find(":text").val());
                v1 += (isNaN(tv) ? 0 : tv); 
            }
            if ($(temptds[2]).find(":text").length > 0) {
                var tv = parseFloat($(temptds[2]).find(":text").val());
                v2 += (isNaN(tv) ? 0 : tv); 
            }
            if ($(temptds[3]).find(":text").length > 0) {
                var tv = parseFloat($(temptds[3]).find(":text").val());
                v3 += (isNaN(tv) ? 0 : tv); 
            }
            if ($(temptds[4]).find(":text").length > 0) {
                var tv = parseFloat($(temptds[4]).find(":text").val());
                v4 += (isNaN(tv) ? 0 : tv); 
            }
            if ($(temptds[5]).find(":text").length > 0) {
                var tv = parseFloat($(temptds[5]).find(":text").val());
                v5 += (isNaN(tv) ? 0 : tv); 
            }
            if ($(temptds[6]).find(":text").length > 0) {
                var tv = parseFloat($(temptds[6]).find(":text").val());
                v6 += (isNaN(tv) ? 0 : tv); 
            }
        });
        $(ttds[1]).find(":text").val(v1.toFixed(2));
        $(ttds[2]).find(":text").val(v2.toFixed(2));
        $(ttds[3]).find(":text").val(v3.toFixed(2));
        $(ttds[4]).find(":text").val(v4.toFixed(2));
        $(ttds[5]).find(":text").val(v5.toFixed(2));
        $(ttds[6]).find(":text").val(v6.toFixed(2));
    },
    setpass: function (p) {
        var tr = parseFloat($("#lb_tierrate").text());
        var tds = p.find("td").toArray();
        var pass = true;
        var bid = $(tds[0]).html().substr(0, 3);

        for (var i = 1; i <= 3; i++) {
            if ($(tds[i]).find("input:text").length > 0) {
                var v1 = parseFloat($(tds[i]).find("input:text").val());
                v1 = isNaN(v1) ? 0 : v1;
                var v2 = parseFloat($(tds[i + 3]).find("input:text").val());
                v2 = isNaN(v2) ? 0 : v2;
                if (bid == "112" || bid == "113" || bid == "114") {
                    v1 = (v1 * tr).toFixed(2);
                }
                if ((v1 > 0 || v2 > 0) && v1 != v2) {
                    pass = false;
                    break;
                }
            }
        }
        $td = $(tds[7]);
        if (pass) {
            $td.removeClass("bg-lightred");
            $td.removeClass("bg-lightgreen");
            $td.addClass("bg-lightgreen");
            $td.html("Pass");
        } else {
            $td.removeClass("bg-lightred");
            $td.removeClass("bg-lightgreen");
            $td.addClass("bg-lightred");
            $td.html("Fail");
        }
    },
    setreconpartbamounts: function () {
        var $dv = $("#dv_recon_partb");
        var temp = home.getfloat($("#lb_reconpartb_upb", $dv).text())
            + home.getfloat($("#lb_reconpartb_inst", $dv).text())
            + home.getfloat($("#txt_reconpartb_excrowbl", $dv).val())
            + home.getfloat($("#txt_reconpartb_corp", $dv).val())
            + home.getfloat($("#txt_reconpartb_susp", $dv).val())
            + home.getfloat($("#txt_reconpartb_restrict", $dv).val())
            + home.getfloat($("#lb_reconpartb_fundapp", $dv).text())
            + home.getfloat($("#lb_reconpartb_paidafter", $dv).text())
            + home.getfloat($("#lb_reconpartb_creditafter", $dv).text());
        $("#lb_reconpartb_ttldebt", $dv).text("$" + temp.toFixed(2));
        temp = home.getfloat($("#lb_reconpartb_partialpro", $dv).text())
            + home.getfloat($("#lb_reconpartb_finalpro", $dv).text())
            + home.getfloat($("#txt_reconpartb_liq", $dv).val());
        $("#lb_reconpartb_ttlpro", $dv).text("$" + temp.toFixed(2));
        temp = home.getfloat($("#lb_reconpartb_ttldebt", $dv).text())
            - home.getfloat($("#lb_reconpartb_ttlpro", $dv).text());
        $("#lb_reconpartb_writeoff", $dv).text("$" + temp.toFixed(2));
        temp = home.getfloat($("#lb_reconpartb_2month", $dv).text())
            + home.getfloat($("#txt_reconpartb_instdiff", $dv).val())
            + home.getfloat($("#lb_reconpartb_attfee", $dv).text())
            + home.getfloat($("#lb_reconpartb_attcost", $dv).text())
            + home.getfloat($("#lb_reconpartb_bankruptcy", $dv).text());
        $("#lb_reconpartb_ttlucloss", $dv).text("$" + temp.toFixed(2));
        temp = home.getfloat($("#lb_reconpartb_cinstloss", $dv).text())
            + home.getfloat($("#lb_reconpartb_cexploss", $dv).text());
        $("#lb_reconpartb_ttlcloss", $dv).text("$" + temp.toFixed(2));
        temp = home.getfloat($("#lb_reconpartb_ttlcloss", $dv).text())
            + home.getfloat($("#lb_reconpartb_ttlucloss", $dv).text());
        $("#lb_reconpartb_ttlloss", $dv).text("$" + temp.toFixed(2));
        temp = home.getfloat($("#lb_reconpartb_writeoff", $dv).text())
            - home.getfloat($("#lb_reconpartb_ttlloss", $dv).text());
        $("#lb_reconpartb_baldiff", $dv).text("$" + temp.toFixed(2));
        temp = home.getfloat($("#lb_reconpartb_2month").text())
            + home.getfloat($("#txt_reconpartb_instdiff").val())
            + home.getfloat($("#hdn_reconpartb_instcurtamt").val())
            + home.getfloat($("#hdn_reconpartb_ttlinstpaid").val());
        $("#lb_reconpartb_inst", $dv).text("$" + temp.toFixed(2));
    },
    loadrecpartainputdata: function (p) {
        var $dv = $("#dv_parta_input");
        $("#hdn_loanid_recparta", $dv).val(p.loanId);
        $("#hdn_recparta_partrecid", $dv).val(p.partARecId);
        $("#hdn_recparta_partacompid", $dv).val(p.partACompId);

        $("#txt_parta_endordate", $dv).val(p.endorsementDate);
        $("#txt_parta_duedatelastpay", $dv).val(p.dueDateofLastPaymentInstallment);
        $("#txt_parta_salebid", $dv).val(p.saleBidAmount);
        $("#txt_parta_fcdeeddate", $dv).val(p.foreclosureDeedRecordedDate);
        $("#txt_parta_posdate", $dv).val(p.dateOfPossessionAndAcquisition);
        $("#txt_parta_deedinliudate", $dv).val(p.deedInLieuDate);
        $("#txt_parta_deedinliutransdate", $dv).val(p.deedInLieuTransferDate);
        $("#txt_parta_unpaidprincipal", $dv).val(p.unpaidPrincipalBalance);
        $("#txt_parta_bankrupt", $dv).val(p.bankruptcyLiftDate);
        $("#txt_parta_authbid", $dv).val(p.authorizedBidAmount);
        $("#txt_parta_lastloanmod", $dv).val(p.lastLoanModificationDate);
        $("#txt_parta_debrate", $dv).val(p.debentureInterestRate);

        $("#lb_parta_input_firstname", $dv).text(p.borrowerFirstName);
        $("#lb_parta_input_lastname", $dv).text(p.borrowerLastName);
        $("#lb_parta_input_address1", $dv).text(p.propertyStreetAddressLine1);
        $("#lb_parta_input_address2", $dv).text(p.propertyStreetAddressLine2);
        $("#lb_parta_input_city", $dv).text(p.propertyCity);
        $("#lb_parta_input_state", $dv).text(p.propertyStateName);
        $("#lb_parta_input_zip", $dv).text(p.propertyZipCode);
        $("#txt_parta_lunum", $dv).val(p.numberOfLivingUnits);

        $("#txt_parta_recentvac", $dv).val(p.recentVacancyDate);
        $("#txt_parta_firstvac", $dv).val(p.firstTimeVacancyDate);
        $("#txt_parta_inspprior", $dv).val(p.dateOfInspectionPriorToFTV);
        $("#txt_parta_origdefaultdate", $dv).val(p.originalDefaultDate);
        $("#txt_parta_fcsaledate", $dv).val(p.foreclosureSaleDate);
        $("#txt_parta_huddeedfiling", $dv).val(p.hudDeedFilingDate);
        $("#txt_parta_hudassign", $dv).val(p.hudAssignmentDate);
        $("#txt_parta_defaultdate", $dv).val(p.defaultDate);
        $("#txt_parta_rrcdate", $dv).val(p.rrcDate);
        $("#txt_parta_marketable", $dv).val(p.marketableTitleDate);
        $("#txt_parta_duedate", $dv).val(p.dueDate);
        $("#txt_parta_firstinspdate", $dv).val(p.firstInspectionDate);
        $("#ddl_parta_firstinspstatus", $dv).val(p.firstInspectionStatus);
        $("#txt_parta_sfdms1a", $dv).val(p.firstSFDMSCode1ADate);
        $("#txt_parta_sfdmsmissed", $dv).val(p.sfdmsReportingMissedCycles);
        $("#chk_parta_suffpayhis", $dv).prop("checked", p.sufficientPaymentHistory == 1 );
        $("#txt_parta_lastontime", $dv).val(p.lastOnTimePaymentDate);
        $("#txt_parta_2chance", $dv).val(p.secondChanceSaleDate);
        $("#txt_parta_checkdate", $dv).val(p.checkWireDate);
        $("#txt_parta_approvaltopart", $dv).val(p.approvalToParticipateDate);
        $("#txt_parta_pfsset", $dv).val(p.pfsSettlementDate);
        $("#txt_parta_redem", $dv).val(p.redemptionDate);
        $("#chk_parta_paymade", $dv).prop("checked", p.borrowerPaymentsMade == 1);
        $("#chk_parta_reosold", $dv).prop("checked", p.propertyREOSold == 1);
        $("#txt_parta_clientspec", $dv).val(p.clientSpecifiedBlock9);
  
        var $ludv = $("#dv_recparta_input_lus", $dv);
        $ludv.empty();
        var len = p.livingUnits == null ? 0 : p.livingUnits.length;

        for (var i = 0; i < len; i++) {
            lossanalysis.appendlu($ludv, i);
            $row = $ludv.find("div.lurow").last();
            $("select[id^='ddl_comparta_lustatus_']", $row).val(p.livingUnits[i].unitOccupancyStatusId);
            $("input[id^='txt_comparta_luname_']", $row).val(p.livingUnits[i].unitOccupantName);
            $("input[id^='txt_comparta_lusecdate_']", $row).val(p.livingUnits[i].unitSecuredDate);
            $("input[id^='txt_comparta_luvacdate_']", $row).val(p.livingUnits[i].unitVacatedDate);
        }

        var diff = p.numberOfLivingUnits - len;
        if (diff > 0) {
            for (var i = len; i < p.numberOfLivingUnits; i++) {
                lossanalysis.appendlu($ludv, i);
            }
        }
    },
    loadreconpartadata: function (p) {
        var $dv = $("#dv_recon_parta");
        $("#hdn_loanid_reconparta", $dv).val(p.loanId);
        $("#hdn_recparta_id", $dv).val(p.loanReconPartAId);
        $("#lb_reconparta_filedupb", $dv).text("$" + p.unpaidPrincipalBalance); 
        $("#lb_reconparta_updatedupb", $dv).text("$" + p.updatedUPB); 
        $("#lb_reconparta_settledupb", $dv).text("$" + p.settledUPB); 
        $("#lb_reconparta_filedexp", $dv).text("$" + p.filedExpenseAmount); 
        $("#lb_reconparta_settledexp", $dv).text("$" + p.settledExpenseAmount); 
        $("#UpdatedInterestCurtDate", $dv).val(p.updatedInterestCurtDate); 
        $("#lb_reconparta_settledinstdate", $dv).text(p.settledInterestCurtDate); 
        $("#txt_reconparta_updatedinstamt", $dv).val(p.updateInterestAmount); 
        $("#lb_reconparta_settledinstamt", $dv).text("$" + p.settledInterestAmount); 
        $("#txt_reconparta_instcurtamt", $dv).val(p.interestCurtAmount); 
        $("#ddl_reconparta_respparty", $dv).val(p.interestCurtRespParty); 
        $("#txt_reconparta_comment", $dv).val(p.loanComment); 
    },
    loadreconpartbdata: function (p) {
        var $dv = $("#dv_recon_partb");
        $("#hdn_loanid_reconpartb", $dv).val(p.loanId);
        $("#hdn_reconpartb_id", $dv).val(p.loanReconPartBId);
        $("#hdn_reconpartb_instcurtamt").val(p.interestCurtAmount);
        $("#hdn_reconpartb_ttlinstpaid").val(p.totalInterestPaid);
        $("#lb_reconpartb_upb", $dv).text("$" + p.reconUPB); 
        $("#lb_reconpartb_inst", $dv).text("$" + p.reconInterest); 
        $("#lb_reconpartb_partialpro", $dv).text("$" + p.reconPartialProceeds); 
        $("#lb_reconpartb_finalpro", $dv).text("$" + p.reconFinalProceeds); 
        $("#txt_reconpartb_excrowbl", $dv).val(p.reconEscrowBalance); 
        $("#txt_reconpartb_corp", $dv).val(p.reconCorporateBalance); 
        $("#txt_reconpartb_susp", $dv).val(p.reconSuspenseBalance); 
        $("#txt_reconpartb_restrict", $dv).val(p.reconRestrictedBalance); 
        $("#txt_reconpartb_liq", $dv).val(p.reconLiquidationProceeds); 
        $("#lb_reconpartb_fundapp", $dv).text("$" + p.reconAppliedFunds); 
        $("#lb_reconpartb_paidafter", $dv).text("$" + p.reconPaidAfterClaim); 
        $("#lb_reconpartb_creditafter", $dv).text("$" + p.reconCreditAfterClaim); 
        $("#lb_reconpartb_2month", $dv).text("$" + p.reconTwoMonthsInterestUL); 
        $("#txt_reconpartb_instdiff", $dv).val(p.reconInterestDifferentialUL); 
        $("#lb_reconpartb_attfee", $dv).text("$" + p.reconAttorneyFeesUL); 
        $("#lb_reconpartb_attcost", $dv).text("$" + p.reconAttorneyCostsUL); 
        $("#lb_reconpartb_bankruptcy", $dv).text("$" + p.reconBankruptcyFeesUL); 
        $("#lb_reconpartb_cinstloss", $dv).text("$" + p.reconControllableInterest); 
        $("#lb_reconpartb_cexploss", $dv).text("$" + p.reconControllableExpense); 
      
        lossanalysis.setreconpartbamounts();
    },
    loadreconsuppdata: function (p) {
        var $dv = $("#dv_recon_supp");
        $("#hdn_loanid_reconsupp", $dv).val(p.loanId);
        $("#txt_reconsupp_arec", $dv).val(p.partARecoveryAmount);
        $("#txt_reconsupp_arecover", $dv).val(p.partARecoveryOverrideAmount);
        $("#txt_reconsupp_brec", $dv).val(p.partBRecoveryAmount);
        $("#txt_reconsupp_brecover", $dv).val(p.partBRecoveryOverrideAmount);
        $("#txt_reconsupp_aref", $dv).val(p.partARefundAmount);
        $("#txt_reconsupp_arefover", $dv).val(p.partARefundOverrideAmount);
        $("#txt_reconsupp_bref", $dv).val(p.partBRefundAmount);
        $("#txt_reconsupp_brefover", $dv).val(p.partBRefundOverrideAmount);
        $("#ddl_reconsupp_recanalyst", $dv).val(p.recoveryAnalystId);
        $("#ddl_reconsupp_refanalyst", $dv).val(p.refundAnalystId);
    },
    loadreconsabdata: function (p) {
        var $dv = $("#dv_recon_bal");
        $("#lb_reconsab_escrow", $dv).text("$" + (p.escrowDifference == 0 ? "0.00" : p.escrowDifference.toString()));
        $("#lb_reconsab_corp", $dv).text("$" + (p.corporateDifference == 0 ? "0.00" : p.corporateDifference.toString()));
        $("#lb_reconsab_susp", $dv).text("$" + (p.suspenseDifference == 0 ? "0.00" : p.suspenseDifference.toString()));
        $("#lb_reconsab_rest", $dv).text("$" + (p.restricktedEscrowDifference == 0 ? "0.00" : p.restricktedEscrowDifference.toString()));
        $("#lb_reconsab_hud", $dv).text("$" + (p.huD1Difference == 0 ? "0.00" : p.huD1Difference.toString()));
    },
    loadreconsuppdetaildata: function (p) {
        var $dv = $("#dv_recon_suppd");
        $("#hdn_loanid_reconsuppd", $dv).val(p.loanId);
        $("#txt_reconsuppd_recfiled", $dv).val(p.recoveryFiled);
        $("#lb_reconsuppd_recamt", $dv).text("$" + (p.recoveryAmount == 0 ? "0.00" : p.recoveryAmount.toString()));
        $("#txt_reconsuppd_reffiled", $dv).val(p.refundFiled);
        $("#lb_reconsuppd_refamt", $dv).text("$" + (p.refundAmount == 0 ? "0.00" : p.refundAmount.toString()));
        $("#txt_reconsuppd_track", $dv).val(p.suppTrackingInfo);
        $("#txt_reconsuppd_hudrecdate", $dv).val(p.hudRecvdDate);
        $("#txt_reconsuppd_hudrecamt", $dv).val(p.hudRecvdAmt);
    },
    loadreconclnspecdata: function (p) {
        var $dv = $("#dv_recon_clnspec");
        $("#txt_loanid_clnspec", $dv).val(p.loanId);
        $("#txt_reconcln_stepcom", $dv).val(p.stepComplete);
        $("#txt_reconcln_rca", $dv).val(p.rcaComplete);
        $("#txt_reconcln_delv", $dv).val(p.delievered);
       
    },
    settfpass: function (p) {
        var txts = p.find(":text").toArray();
        var pass = 0;
        if (isNaN(Date.parse(txts[0].value)) && isNaN(Date.parse(txts[1].value)))
            pass = 2;
        else {
            if (isNaN(Date.parse(txts[0].value)) || Date.parse(txts[0].value) > Date.parse(txts[1].value))
                pass = 0;
            else
                pass = 1;
        }
        
        $txt = $(txts[2]);

        switch (pass) {
            case 0:
                $txt.removeClass("bg-lightred");
                $txt.removeClass("bg-lightgreen");
                $txt.addClass("bg-lightred");
                $txt.val("Fail");
                break;
            case 1:
                $txt.removeClass("bg-lightred");
                $txt.removeClass("bg-lightgreen");
                $txt.addClass("bg-lightgreen");
                $txt.val("Pass");
                break;
            default:
                $txt.removeClass("bg-lightred");
                $txt.removeClass("bg-lightgreen");
                $txt.val("N/A");
                break;
        }
        if (pass) {
           
        } else {
            
        }
    },
    loadrecpartatimeframedata: function (p) {
        var $dv = $("#dv_parta_tf");
        $("#hdn_loanid_partatimeframe", $dv).val(lossanalysis.getloanid());

        $.each(p.timeframes, function () {
            var d = this;
            var $row = null;
            switch (d.timeframeTypeName) {
                case "Institution":
                    $row = $("#txt_parta_tf_fcinstaadate", $dv).closest(".datarow");
                    break;
                case "SFDMS":
                    $row = $("#txt_parta_tf_repaadate", $dv).closest(".datarow");
                    break;
                case "Reasonable Diligence":
                    $row = $("#txt_parta_tf_redaadate", $dv).closest(".datarow");
                    break;
                case "Eviction":
                    $row = $("#txt_parta_tf_eviaadate", $dv).closest(".datarow");
                    break;
                case "Claim Due":
                    $row = $("#txt_parta_tf_dueaadate", $dv).closest(".datarow");
                    break;
                case "Conveyance":
                    $row = $("#txt_parta_tf_conaadate", $dv).closest(".datarow");
                    break;
                default:
                    break;
            }
            if ($row && $row.length > 0) {
                $row.find("input:hidden").val(d.timeframeTypeId);
                $row.find(":text[id$='aadate']").val(d.timeframeActivityDate);
                $row.find(":text[id$='dldate']").val(d.timeframeCalcDeadlineDate);
                $row.find(":checkbox").attr("checked", d.timeframeExtensionUsed);
                lossanalysis.settfpass($row);
            }
        });
    },
    editrowfaction: function (p) {
        var $grid = $("#tbl_parta_faction");
        if (p && p !== lossanalysis.data.parta.faction.lastselectedrow) {
            $grid.jqGrid('restoreRow', lossanalysis.data.parta.faction.lastselectedrow);
            $grid.jqGrid('editRow', p, { keys: false }); /*key true enable Enter to save*/
            lossanalysis.data.parta.faction.lastselectedrow = p;
            $("#tbl_parta_faction_iledit", "#tbl_parta_faction_pager").trigger("click");
        } else {
            if (p == lossanalysis.data.parta.faction.lastselectedrow
                && $("#" + p, $grid).attr("editable") !== "1") {
                $grid.jqGrid('editRow', p, { keys: false });
                $("#tbl_parta_faction_iledit", "#tbl_parta_faction_pager").trigger("click");
            }
        }
    },
    enabledatepicker: function (p) {
        $(p).datepicker({
            format: 'mm/dd/yyyy',
            todayHighlight: true,
            autoclose: true,
            forceParse: false
        }); 
    },
    loadfactiongrid: function (p) {
        $("#tbl_parta_faction").jqGrid({
           /* data: lossanalysis.data.parta.faction.testdata,
            datatype: "local",
            editurl: "clientArray",
            */
            editurl: saveFCActionUrl,
            url: getFCActionUrl,
            postData: { LoanId: function () { return lossanalysis.getloanid(); } },
            datatype: "json",
            caption: "Foreclosure Action",
            colModel: [
                { label: "Id", name: "id", key: true, hidden: true },
                { label: "First Legal Date", name: 'firstLegalDate', width: 100, editable: true, formatter: home.griddateformatter, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Restart Validity", name: 'restartValid', width: 140, editable: true, edittype: "select", formatter: "select", editoptions: { value: "0:Invalid;1:Valid" } },
                {
                    label: "Restart Reason", name: 'restartReason', width: 100, editable: true, formatter: "select", formatoptions: { value: lossanalysis.data.parta.faction.restartreasonlist },
                    edittype: "select", editoptions: { value: lossanalysis.data.parta.faction.restartreasonlist }
                    
                },
                { label: "SFDMS Code 68 Date", name: 'sfdmsCode68Date', width: 120, editable: true, editoptions: { size : 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "Action Type", name: "type", width: 100, editable: true, formatter: "select", formatoptions: {
                        value: lossanalysis.data.parta.faction.typelist
                    },
                    edittype: "select", editoptions: { value: lossanalysis.data.parta.faction.typelist }
                },
                { label: "Comments", name: "comments", width: 200, editable: true}
            ],
            inlineData: { LoanId: function () { return lossanalysis.getloanid(); } }, 
           // loadonce: true,
            autowidth: true,
            viewrecords: true,
            onSelectRow: lossanalysis.editrowfaction, 
            height: 200,
            rowNum: 10,
            pager: "#tbl_parta_faction_pager"
        });
        $("#tbl_parta_faction").navGrid("#tbl_parta_faction_pager", {
            add: false, edit: false, search: false, refresh: false/*
            beforeRefresh: home.onbeforerefresh*/
        });
        $("#tbl_parta_faction").inlineNav("#tbl_parta_faction_pager", {
             cancelicon: "fa fa-undo",
        });
            /*saveAfterSelect: true
             resotrAfterSelect: false });*/
    },
    editrowoextension: function (p) {
        var $grid = $("#tbl_parta_oextension");
        if (p && p !== lossanalysis.data.parta.oextension.lastselectedrow) {
            $grid.jqGrid('restoreRow', lossanalysis.data.parta.oextension.lastselectedrow);
            $grid.jqGrid('editRow', p, { keys: false }); /*key true enable Enter to save*/
            lossanalysis.data.parta.oextension.lastselectedrow = p;
            $("#tbl_parta_oextension_iledit", "#tbl_parta_oextension_pager").trigger("click");
        } else {
            if (p == lossanalysis.data.parta.oextension.lastselectedrow
                && $("#" + p, $grid).attr("editable") !== "1") {
                $grid.jqGrid('editRow', p, { keys: false });
                $("#tbl_parta_oextension_iledit", "#tbl_parta_oextension_pager").trigger("click");
            }
        }
    },
    loadoextensiongrid: function (p) {
        $("#tbl_parta_oextension").jqGrid({
            editurl: saveOtherExtUrl,
            url: getOtherExtUrl,
            postData: { LoanId: function () { return lossanalysis.getloanid(); } },
            datatype: "json",
            caption: "Other Extensions",
            colModel: [
                { label: "Id", name: "id", key: true, hidden: true },
                {
                    label: "Type", name: "extensionType", editable: true, width: 80, formatter: "select", formatoptions: { value: lossanalysis.data.parta.oextension.exttypelist },
                    edittype: "select", editoptions: { value: lossanalysis.data.parta.oextension.exttypelist }
                },
                { label: "Request Date", name: 'hudExtensionRequestDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Extension Date", name: 'hudExtensionDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "HUD Specified Ext Date(FEMA)", name: 'femaExtensionDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "First Action Date", name: 'firstActionDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Statute Start Date", name: 'statuteStartDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Statute End Date", name: 'statuteEndDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Start of Active Duty Date", name: 'activeDutyStartDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Discharge Date", name: 'activeDutyDischargeDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Hazard Claim Date", name: 'hazardClaimDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Hazard Claim Settlement Date", name: 'hazardClaimSettlementDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Date of Loss", name: 'lossDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Sales Contract Approval Date", name: 'saleContractApprovalDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Declaration Date", name: 'declarationDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }}
            ],
          //  loadonce: true,
            autowidth: true,
            viewrecords: true,
           // hiddengrid: true,
            onSelectRow: lossanalysis.editrowoextension,
            height: 200,
            rowNum: 10,
            inlineData: { LoanId: function () { return lossanalysis.getloanid(); } }, 
            pager: "#tbl_parta_oextension_pager"

        });
        $("#tbl_parta_oextension").navGrid("#tbl_parta_oextension_pager", {
            add: false, edit: false, search: false, refresh: false/*,
            beforeRefresh: home.onbeforerefresh*/
        });
        $("#tbl_parta_oextension").inlineNav("#tbl_parta_oextension_pager", { 
            cancelicon: "fa fa-undo"/*,
            addParams: {
                addRowParams: { extraparam: { LoanId: function () { return lossanalysis.getloanid(); } }}
            },
            editParams: { extraparam: { LoanId: function () { return lossanalysis.getloanid(); } } }*/
        });
    },
    editrowbankruptcy: function (p) {
        var $grid = $("#tbl_parta_bankruptcy");
        if (p && p !== lossanalysis.data.parta.bankruptcy.lastselectedrow) {
            $grid.jqGrid('restoreRow', lossanalysis.data.parta.bankruptcy.lastselectedrow);
            $grid.jqGrid('editRow', p, { keys: false }); /*key true enable Enter to save*/
            lossanalysis.data.parta.bankruptcy.lastselectedrow = p;
            $("#tbl_parta_bankruptcy_iledit", "#tbl_parta_bankruptcy_pager").trigger("click");
        } else {
            if (p == lossanalysis.data.parta.bankruptcy.lastselectedrow
                && $("#" + p, $grid).attr("editable") !== "1") {
                $grid.jqGrid('editRow', p, { keys: false });
                $("#tbl_parta_bankruptcy_iledit", "#tbl_parta_bankruptcy_pager").trigger("click");
            }
        }
    },
    loadbankruptcygrid: function (p) {
        $("#tbl_parta_bankruptcy").jqGrid({
            editurl: saveBankruptcyUrl,
            url: getBankruptcyUrl,
            postData: { LoanId: function () { return lossanalysis.getloanid(); } },
            datatype: "json",
            caption: "Bankruptcy",
            colModel: [
                { label: "Id", name: "id", key: true, hidden: true },
                { label: "Case Number", name: 'bankruptcyCaseNumber', width: 100, editable: true, editoptions: { maxlength: 20 } },
                {
                    label: "Bankruptcy Type", name: 'bankruptcyType', width: 100, editable: true, formatter: "select", edittype: "select",
                    editoptions: { value: lossanalysis.data.parta.bankruptcy.bankruptcytypelist },
                    formatoptions: { value: lossanalysis.data.parta.bankruptcy.bankruptcytypelist }
                },
                { label: "Filed Date", name: 'filedDate', width: 120, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Clearance Date", name: 'clearanceDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "Order Granting MFR", name: 'orderGrantingMFR', width: 100, editable: true, edittype: "select", formatter: "select",
                    editoptions: { value: "9999:;0:No;1:Yes" }
                },
                { label: "Motion for Relief Date", name: 'motionForReliefDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "4001 Rule Waived", name: 'ruleWaived', width: 100, editable: true, edittype: "select", formatter: "select",
                    editoptions: { value: "9999:;0:No;1:Yes" }
                },
                {
                    label: "Ruling", name: 'ruling', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: lossanalysis.data.parta.bankruptcy.rulinglist },
                    editoptions: { value: lossanalysis.data.parta.bankruptcy.rulinglist }
                },
                { label: "Dismissal Date", name: 'dismissalDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Discharge Date", name: 'dischargeDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Attorney Provided Lift Date", name: 'attorneyProvidedLiftDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "Closed Same Day as Discharge", name: 'closedSameDayAsDischarge', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: { "9999": "", "0": "No", "1": "Yes" } },
                    editoptions: { value: { "9999": "", "0": "No", "1": "Yes" } }
                },
                { label: "BK Completion Date", name: 'bankruptcyCompletionDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Days of Acceptable BK Completion", name: 'bankruptcyCompletionDays', width: 80, editable: true },
                {
                    label: "Were Delays Acceptable?", name: 'delaysAcceptable', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: { "9999": "", "0": "No", "1": "Yes" } },
                    editoptions: { value: { "9999": "", "0": "No", "1": "Yes" } }
                },
                { label: "Forclosure First Action Date", name: 'firstActionDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
            
                { label: "First Unacceptable Delay", name: 'firstUnacceptableDelay', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } }
            ],
            //loadonce: true,
            autowidth: true,
            viewrecords: true,
            onSelectRow: lossanalysis.editrowbankruptcy,
            height: 200,
            rowNum: 10,
            inlineData: { LoanId: function () { return lossanalysis.getloanid(); } }, 
            pager: "#tbl_parta_bankruptcy_pager"

        });
        $("#tbl_parta_bankruptcy").navGrid("#tbl_parta_bankruptcy_pager", {
            add: false, edit: false, search: false,
            beforeRefresh: home.onbeforerefresh
        });
        $("#tbl_parta_bankruptcy").inlineNav("#tbl_parta_bankruptcy_pager", {
            cancelicon: "fa fa-undo"
        });
    },
    loadlossmitgrid: function (p) {
        $("#tbl_parta_lossmit").jqGrid({
            editurl: saveLossMitUrl,
            url: getLossMitUrl,
            postData: { LoanId: function () { return lossanalysis.getloanid(); } },
            datatype: "json",
            caption: "Loss Mitigation",
            colModel: [
                { label: "Id", name: "id", key: true, hidden: true },
                {
                    label: "Type", name: 'lossMitigationType', width: 100, editable: true, formatter: "select", edittype: "select", formoptions: {rowpos: 1, colpos: 1},
                    editoptions: { value: lossanalysis.data.parta.lossmit.lossmittypelist },
                    formatoptions: { value: lossanalysis.data.parta.lossmit.lossmittypelist }
                },
                /*{
                    label: "Code", name: 'Code', width: 100, editable: true, formatter: "select", edittype: "select", formoptions: { rowpos: 1, colpos: 2 },
                    editoptions: { value: lossanalysis.data.parta.lossmit.codelist },
                    formatoptions: { value: lossanalysis.data.parta.lossmit.codelist }
                },*/
                {
                    label: "Rpts to SFDMS", name: 'sfdmsReported', width: 80, editable: true, edittype: "select", formatter: "select", formoptions: { rowpos: 2, colpos: 1 },
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                { label: "Rpts to SFDMS Date", name: 'sfdmsReportDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 2, colpos: 2 }},
                {
                    label: "Doc Available", name: 'documentsAvailable', width: 80, editable: true, edittype: "select", formatter: "select", formoptions: { rowpos: 2, colpos: 3 },
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                { label: "Doc Signed Date", name: 'documentSignDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 3, colpos: 1 } },
                { label: "Decision Date", name: 'decisionDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 3, colpos: 2 } },
                {
                    label: "Plan Complete", name: 'planComplete', width: 80, editable: true, edittype: "select", formatter: "select", formoptions: { rowpos: 3, colpos: 3 },
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                { label: "Vacated Date", name: 'borrowerVacatedDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 4, colpos: 1 } },
              /*  {
                    label: "Borrower Opted Out", name: 'BorrowerOptedOut', width: 80, editable: true, edittype: "select", formatter: "select", formoptions: { rowpos: 4, colpos: 2 },
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },*/
                { label: "Opted Out Date", name: 'optOutDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 4, colpos: 3 } },
                { label: "ATP Date", name: 'approvalToParticipateDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 5, colpos: 1 } },
                { label: "ATP Exp Date", name: 'approvalToParticipateExpirationDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 5, colpos: 2 } },
                { label: "Last Plan Pymt Due Date", name: 'lastPlanPaymentDueDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 5, colpos: 3 } },
                { label: "Next Plan Pymt Due Date", name: 'nextPlanPaymentDueDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 6, colpos: 1 }},
                { label: "First Missed Pymt Due Date", name: 'firstMissedPaymentDueDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 6, colpos: 2 }},
                { label: "First Plan Pymt Due Date", name: 'firstPlanPaymentDueDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 6, colpos: 3 } },
                {
                    label: "Incl SFB Exp",
                    name: 'planIncludesSFBExpiration', width: 80, editable: true, hidden: true, editrules: { edithidden: true }, edittype: "select", formatter: "select", formoptions: { rowpos: 7, colpos: 1 },
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                {
                    label: "Pymt Susp/Redu',",
                    name: 'planPaymentsSuspendedReduced', width: 80, editable: true, hidden: true, editrules: { edithidden: true }, edittype: "select", formatter: "select", formoptions: { rowpos: 7, colpos: 2 },
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                { label: "Spcl Forbe Exp Date", name: 'sfbExpirationDate', width: 80, editable: true, hidden: true, editrules: { edithidden: true }, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 7, colpos: 3 },},
                { label: "Lst Plan Pymt Appl Date", name: 'lastPlanPaymentAppliedDate', width: 80, editable: true, hidden: true, editrules: { edithidden: true }, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 8, colpos: 1 },},

                { label: "Appd Contr Date", name: 'approvedContractDate', width: 80, editable: true, hidden: true, editrules: { edithidden: true }, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 8, colpos: 2 } },
                {
                    label: "Appd Var",
                    name: 'approvedVariance', width: 80, editable: true, hidden: true, editrules: { edithidden: true }, edittype: "select", formatter: "select", formoptions: { rowpos: 8, colpos: 3 },
                    formatoptions: { value: { "0": "No", "1": "Yes" } },
                    editoptions: { value: { "0": "No", "1": "Yes" } }
                },
                { label: "Var Req Date", name: 'varianceRequestDate', width: 80, editable: true, hidden: true, editrules: { edithidden: true }, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 9, colpos: 1 } },
                { label: "Var Ext Date", name: 'varianceExtensionDate', width: 80, editable: true, hidden: true, editrules: { edithidden: true }, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 9, colpos: 2 }},
                { label: "FC 1st Act Date", name: 'firstActionDate', width: 80, editable: true, hidden: true, editrules: { edithidden: true }, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 9, colpos: 3 } }
            ],
            //loadonce: true,
            autowidth: true,
            viewrecords: true,
            height: 200,
            rowNum: 10,
            pager: "#tbl_parta_lossmit_pager",
            subGrid: true,
            subGridRowExpanded: function (subgridid, rowid) {
               // home.collopsesgrows(this, subgridid, rowid);
                var subgrid_table_id;
                var rowdata = $(this).getRowData(rowid);
                subgrid_table_id = subgridid + "_t";
                $("#" + subgridid).html("<table id='" + subgrid_table_id + "'></table>");
                var sgdata = [{
                    PlanIncludesSFBExpiration: rowdata["planIncludesSFBExpiration"],
                    PlanPaymentsSuspended: rowdata["planPaymentsSuspendedReduced"],
                    SpecialForbearanceExpirationDate: rowdata["sfbExpirationDate"],
                    LastPlanPaymentAppliedToLoanDate: rowdata["lastPlanPaymentAppliedDate"],
                    ApprovedContractDate: rowdata["approvedContractDate"],
                    ApprovedVariance: rowdata["approvedVariance"],
                    VarianceRequestDate: rowdata["varianceRequestDate"],
                    VarianceExtensionDate: rowdata["varianceExtensionDate"],
                    ForeclosureFirstActionDate: rowdata["firstActionDate"]
                }];
                $("#" + subgrid_table_id).jqGrid({
                    data: sgdata,
                    datatype: "local",
                    colNames: ['Incl SFB Exp Date', 'Pymt Susp/Redu', 'Spcl Forbe Exp Date', 'Lst Plan Pymt Appl Date',
                        'Appd Contr Date', 'Appd Var', 'Var Req Date', 'Var Ext Date', 'FC 1st Act Date'],
                    colModel: [
                        {
                            name: 'PlanIncludesSFBExpiration', width: 80, formatter: "select",
                            formatoptions: { value: { "0": "No", "1": "Yes" } }
                        },
                        {
                            name: 'PlanPaymentsSuspended', width: 80, formatter: "select",
                            formatoptions: { value: { "0": "No", "1": "Yes" } }
                        },
                        { name: 'SpecialForbearanceExpirationDate', width: 80 },
                        { name: 'LastPlanPaymentAppliedToLoanDate', width: 80},

                        { name: 'ApprovedContractDate', width: 80},
                        {
                            name: 'ApprovedVariance', width: 80, formatter: "select",
                            formatoptions: { value: { "0": "No", "1": "Yes" } }
                        },
                        { name: 'VarianceRequestDate', width: 80},
                        { name: 'VarianceExtensionDate', width: 80 },
                        { name: 'ForeclosureFirstActionDate', width: 80 }
                    ],
                    height: 'auto',
                    autowidth: true
                });
            }

        });
        $("#tbl_parta_lossmit").navGrid("#tbl_parta_lossmit_pager", {
            add: true, edit: true, del: true, search: false, refresh: true,
            beforeRefresh: home.onbeforerefresh
        }, { closeAfterEdit: true, /*reloadAfterSubmit: true,*/ recreateForm: true, beforeShowForm: home.onbeforeshowform, afterSubmit: home.onaftersubmit, width: 800, editData: { LoanId: function () { return lossanalysis.getloanid(); } } },
            { closeAfterAdd: true, /*reloadAfterSubmit: true,*/ recreateForm: true, beforeShowForm: home.onbeforeshowform, afterSubmit: home.onaftersubmit, width: 800, editData: { LoanId: function () { return lossanalysis.getloanid(); } } });
    },
    editroweaction: function (p) {
        var $grid = $("#tbl_parta_eaction");
        if (p && p !== lossanalysis.data.parta.eviction.lastselectedrow) {
            $grid.jqGrid('restoreRow', lossanalysis.data.parta.eviction.lastselectedrow);
            $grid.jqGrid('editRow', p, { keys: false }); /*key true enable Enter to save*/
            lossanalysis.data.parta.eviction.lastselectedrow = p;
            $("#tbl_parta_eaction_iledit", "#tbl_parta_eaction_pager").trigger("click");
        } else {
            if (p == lossanalysis.data.parta.eviction.lastselectedrow
                && $("#" + p, $grid).attr("editable") !== "1") {
                $grid.jqGrid('editRow', p, { keys: false });
                $("#tbl_parta_eaction_iledit", "#tbl_parta_eaction_pager").trigger("click");
            }
        }
    },
    loadeactiongrid: function (p) {
        $("#tbl_parta_eaction").jqGrid({
            editurl: saveEvictionUrl,
            url: getEvictionUrl,
            datatype: "json",
            postData: { LoanId: function () { return lossanalysis.getloanid(); } },
            caption: "Eviction Action",
            colModel: [
                { label: "Id", name: "id", key: true, hidden: true },
                {
                    label: "Vacancy Type", name: 'vacancyType', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: lossanalysis.data.parta.eviction.evictiontypelist },
                    editoptions: { value: lossanalysis.data.parta.eviction.evictiontypelist }
                },
                { label: "Vacancy Date", name: 'vacancyDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Eviction First Legal Date", name: 'evictionFirstLegalDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Unacceptable Delay Start Date", name: 'unacceptableDelayStartDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
              
                { label: "Close and Bill Date", name: 'closeAndBillDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "Reoccupancy Date", name: 'reoccupancyDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } }
               
            ],
           // loadonce: true,
            autowidth: true,
            onSelectRow: lossanalysis.editroweaction,
            height: 150,
            rowNum: 100,
            pgbuttons: false,
            pginput: false,
            inlineData: { LoanId: function () { return lossanalysis.getloanid(); } }, 
           /* pgtext: "",*/
            pager: "#tbl_parta_eaction_pager"

        });
        $("#tbl_parta_eaction").navGrid("#tbl_parta_eaction_pager", {
            add: false, edit: false, search: false, refresh: false
        });
        $("#tbl_parta_eaction").inlineNav("#tbl_parta_eaction_pager", {
            cancelicon: "fa fa-undo"
        });
    },
    editrowodelay: function (p) {
        var $grid = $("#tbl_parta_odelay");
        if (p && p !== lossanalysis.data.parta.odelay.lastselectedrow) {
            $grid.jqGrid('restoreRow', lossanalysis.data.parta.odelay.lastselectedrow);
            $grid.jqGrid('editRow', p, { keys: false }); /*key true enable Enter to save*/
            lossanalysis.data.parta.odelay.lastselectedrow = p;
            $("#tbl_parta_odelay_iledit", "#tbl_parta_odelay_pager").trigger("click");
        } else {
            if (p == lossanalysis.data.parta.odelay.lastselectedrow
                && $("#" + p, $grid).attr("editable") !== "1") {
                $grid.jqGrid('editRow', p, { keys: false });
                $("#tbl_parta_odelay_iledit", "#tbl_parta_odelay_pager").trigger("click");
            }
        }
    },
    loadodelaygrid: function (p) {
        $("#tbl_parta_odelay").jqGrid({
            editurl: saveDelayUrl,
            url: getDelayUrl,
            datatype: "json",
            postData: { LoanId: function () { return lossanalysis.getloanid(); } },
            caption: "Other Delays",
            colModel: [
                { label: "Id", name: "id", key: true, hidden: true },
                {
                    label: "Type", name: 'delayType', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: lossanalysis.data.parta.odelay.delaytypelist },
                    editoptions: { value: lossanalysis.data.parta.odelay.delaytypelist }
                },
                { label: "Start Date", name: 'delayStartDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                { label: "End Date", name: 'delayEndDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "Acceptable", name: 'delayAcceptable', width: 80, editable: true, edittype: "select", formatter: "select",
                    formatoptions: { value: {"9999": "", "1": "Acceptable", "0": "Unacceptable" } },
                    editoptions: { value: {"9999": "", "1": "Acceptable", "0": "Unacceptable" } }
                },
                { label: "Reason", name: "delayReason", width: 150, editable: true }
                
            ],
        //    loadonce: true,
            autowidth: true,
            viewrecords: true,
            onSelectRow: lossanalysis.editrowodelay,
            height: 200,
            rowNum: 20,
            inlineData: { LoanId: function () { return lossanalysis.getloanid(); } }, 
            pager: "#tbl_parta_odelay_pager"

        });
        $("#tbl_parta_odelay").navGrid("#tbl_parta_odelay_pager", {
            add: false, edit: false, search: false, refresh: false
        });
        $("#tbl_parta_odelay").inlineNav("#tbl_parta_odelay_pager", {
            cancelicon: "fa fa-undo"
        });
    },
    loadpartbexpgrid: function () {
        $("#tbl_partb_exp").jqGrid({
            editurl: savePartBExpenseUrl,
            url: getPartBExpenseUrl,
            datatype: "json",
            postData: { LoanId: function () { return lossanalysis.getloanid(); } },
            caption: "Expenses",
            colModel: [
                { label: "Id", name: "id", key: true, hidden: true, editable: true },
                {
                    label: "Category", name: 'expenseCategory', index: "expenseCategory", width: 100, editable: true, 
                    formatter: "select", edittype: "select", editrules: { required: true }, formoptions: { rowpos: 2, colpos: 1 },
                    stype: "select", searchoptions: { sopt: ["eq", "ne"], value: lossanalysis.data.partb.expcatlist },
                    editoptions: { value: lossanalysis.data.partb.expcatlist },
                    formatoptions: { value: lossanalysis.data.partb.expcatlist }
                },
                { label: "SubCategory", name: "expenseSubCategoryName", width: 100, editable: false},
                {
                    label: "Sub Category", name: 'expenseSubCategory', width: 100, editable: true, editrules: { edithidden: true }, hidden: true,
                    edittype: "select", formoptions: { rowpos: 2, colpos: 2 }
                   /*, editoptions: { value: lossanalysis.data.partb.expsubcatlist }*/
                },
                { label: "Description", name: 'expenseDescription', width: 150, editable: true, formoptions: { rowpos: 3, colpos: 1 }, editoptions: { maxlength: 500 } },
                {
                    label: "Advanced Account", name: 'advanceFrom', index: "advanceFrom", width: 80, editable: true, formoptions: { rowpos: 3, colpos: 2 },
                    formatter: "select", edittype: "select",
                    formatoptions: { value: lossanalysis.data.partb.expadvfromlist },
                    editoptions: { value: lossanalysis.data.partb.expadvfromlist }
                },
                {
                    label: "Date Disbursed", name: 'disbursedDate', sorttype: "date", datefmt:"m/d/Y", index: "disbursedDate", width: 80, editable: true,
                    editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker }, formoptions: { rowpos: 4, colpos: 1 }
                },
                {
                    label: "Amount Disbursed", name: 'disbursedAmount', width: 80, editable: true, sorttype: "currency", formoptions: { rowpos: 4, colpos: 2 }, editoptions: { maxlength: 20 },
                    formatter: "currency", formatoptions: { decimalSeparator: ".", thousandsSeparator: ",", decimalPlaces: 2, prefix: "$" } 
                },
            
                {
                    label: "Previous Claim Amount", name: 'previousClaimAmount', width: 80, editable: true, sorttype: "currency",  formoptions: { rowpos: 5, colpos: 1 },
                    formatter: "currency",formatoptions: { decimalSeparator: ".", thousandsSeparator: ",", decimalPlaces: 2, prefix: "$" } 
                },
                {
                    label: "Previous Charge Off Amount", name: 'previousChargeOffAmount', width: 80, editable: true, sorttype: "currency", 
                    formoptions: { rowpos: 5, colpos: 2 }, editoptions: { maxlength: 20 },
                    formatter: "currency", formatoptions: { decimalSeparator: ".", thousandsSeparator: ",", decimalPlaces: 2, prefix: "$" }
                },
                {
                    label: "Current Claim Amount", name: 'claimAmount', width: 80, editable: true, formoptions: { rowpos: 6, colpos: 1 }, editoptions: { maxlength: 20 }, sorttype: "currency", 
                    formatter: "currency", formatoptions: { decimalSeparator: ".", thousandsSeparator: ",", decimalPlaces: 2, prefix: "$" }
                },
                {
                    label: "Current Charge Off Amount", name: 'chargeOffAmount', width: 80, editable: true, formoptions: { rowpos: 6, colpos: 2 }, editoptions: { maxlength: 20 }, sorttype: "currency", 
                    formatter: "currency", formatoptions: { decimalSeparator: ".", thousandsSeparator: ",", decimalPlaces: 2, prefix: "$" }
                },
                {
                    label: "Current Charge Off Reason", name: 'chargeOffReason', index: "chargeOffReason", width: 100, editable: true, formatter: "select", 
                    edittype: "select", formoptions: { rowpos: 7, colpos: 1 },
                    stype: "select", searchoptions: { sopt: ["eq", "ne"], value: lossanalysis.data.partb.expchargeoffreason },
                    editoptions: { value: lossanalysis.data.partb.expchargeoffreason },
                    formatoptions: { value: lossanalysis.data.partb.expchargeoffreason }
                },
                {
                    label: "Current Responsible Party", name: 'responsibleParty', index: "responsibleParty", width: 100, editable: true, formatter: "select", 
                    edittype: "select", formoptions: { rowpos: 7, colpos: 2 },
                    stype: "select", searchoptions: { sopt: ["eq", "ne"], value: lossanalysis.data.partb.resppartylist },
                    editoptions: { value: lossanalysis.data.resppartylist },
                    formatoptions: { value: lossanalysis.data.resppartylist }
                },
               {
                    label: "Previous Debenture Interest", name: 'previousDebentureInterest', width: 80, editable: true, formoptions: { rowpos: 8, colpos: 1 },
                    hidden: true, editrules: { edithidden: true}
                },
                {
                    label: "Current Debenture Interest", name: 'debentureInterestAmount', width: 80, editable: true, formoptions: { rowpos: 8, colpos: 2 }, editoptions: { maxlength: 10 },
                    hidden: true, editrules: { edithidden: true }
                },
                {
                    label: "Invoice Number", name: 'invoiceNumber', index: "invoiceNumber", width: 80, editable: true, hidden: true,
                    editrules: { edithidden: true }, editoptions: { maxlength: 50 }, formoptions: { rowpos: 9, colpos: 1 }
                },
                {
                    label: "Est Refund Amount", name: 'estimatedRefundAmount', width: 80, editable: true, hidden: true,
                    editrules: { edithidden: true }, formoptions: { rowpos: 9, colpos: 2 }, editoptions: { maxlength: 20 }
                },
                {
                    label: "Recovery Amount", name: 'recoveryAmount', width: 80, editable: true, formoptions: { rowpos: 10, colpos: 1 }, editoptions: { maxlength: 20 },
                     hidden: true
                },
                {
                    label: "Refund Amount", name: 'refundAmount', width: 80, editable: true, formoptions: { rowpos: 10, colpos: 2 }, editoptions: { maxlength: 20 },
                    hidden: true
                },
                {
                    label: "Uncontrollable Loss Amount", name: 'uncontrollableLossAmount', width: 80, editable: true, formoptions: { rowpos: 11, colpos: 1 }, editoptions: { maxlength: 20 },
                    hidden: true
                }
            ],
            loadonce: true,
            autowidth: true,
            viewrecords: true,
            height: 450,
            rowNum: 50,
            rowList: [50,100,200],
            pager: "#tbl_partb_exp_pager",
            subGrid: true,
            subGridRowExpanded: function (subgridid, rowid) {
                var subgrid_table_id;
                var rowdata = $(this).getRowData(rowid);
                subgrid_table_id = subgridid + "_t";
                $("#" + subgridid).html("<table id='" + subgrid_table_id + "'></table>");
                var sgdata = [{
                    invoiceNumber: rowdata["invoiceNumber"],
                    estimatedRefundAmount: rowdata["estimatedRefundAmount"],
                    previousDebentureInterest: rowdata["previousDebentureInterest"],
                    debentureInterestAmount: rowdata["debentureInterestAmount"],
                    recoveryAmount: rowdata["recoveryAmount"],
                    refundAmount : rowdata["refundAmount"],
                    uncontrollableLossAmount: rowdata["uncontrollableLossAmount"]
                }];
                $("#" + subgrid_table_id).jqGrid({
                    data: sgdata,
                    datatype: "local",
                    colNames: ['Inv Num', 'Est Refun Amt', 'Pre Deb Int', 'Curr Deb Int', 'Recvy Amt', 'Refun Amt', 'Uncon Loss Amt'],
                    colModel: [
                        { name: 'invoiceNumber', width: 80 },
                        { name: 'estimatedRefundAmount', formatter: "currency", formatoptions: { decimalSeparator: ".", thousandsSeparator: ",", decimalPlaces: 2, prefix: "$" }, width: 80 },
                        { name: 'previousDebentureInterest', formatter: "currency", formatoptions: { decimalSeparator: ".", thousandsSeparator: ",", decimalPlaces: 2, prefix: "$" }, width: 80 },
                        { name: 'debentureInterestAmount', formatter: "currency", formatoptions: { decimalSeparator: ".", thousandsSeparator: ",", decimalPlaces: 2, prefix: "$" }, width: 80 },
                        { name: 'recoveryAmount', formatter: "currency", formatoptions: { decimalSeparator: ".", thousandsSeparator: ",", decimalPlaces: 2, prefix: "$" }, width: 80 },
                        { name: 'refundAmount', width: 80, formatter: "currency", formatoptions: { decimalSeparator: ".", thousandsSeparator: ",", decimalPlaces: 2, prefix: "$" } },
                        { name: 'uncontrollableLossAmount', width: 80, formatter: "currency", formatoptions: { decimalSeparator: ".", thousandsSeparator: ",", decimalPlaces: 2, prefix: "$" } }
                    ],
                    height: 'auto',
                    autowidth: true
                });
            }
        });
        $("#tbl_partb_exp").navGrid("#tbl_partb_exp_pager", {
            add: true, edit: true, del: true, search: true, refresh: true,
            beforeRefresh: home.onbeforerefresh
        }, { closeAfterEdit: true, recreateForm: true, afterSubmit: lossanalysis.onaftersubmitexp, beforeShowForm: lossanalysis.onbeforeshowformexp, width: 800, editData: { LoanId: function () { return lossanalysis.getloanid(); } } },
            { closeAfterAdd: true, recreateForm: true, afterSubmit: lossanalysis.onaftersubmitexp, beforeShowForm: lossanalysis.onbeforeshowformexpadd, width: 800, editData: { LoanId: function () { return lossanalysis.getloanid(); } } });
    },
    onaftersubmitexp: function (p) {
        $("#tbl_partb_exp").jqGrid("clearGridData");
        $("#tbl_partb_exp").jqGrid("setGridParam", { datatype: "json" }).trigger("reloadGrid");
        return home.onaftersubmit(p);
    },
    onbeforeshowformexp: function (p) {
        $("#pData, #nData", "#Act_Buttons").hide();
        var $self = $(this);
        var rd = $self.jqGrid("getRowData", $self.jqGrid("getGridParam", "selrow"));
        lossanalysis.data.partb.expsubcatlist = lossanalysis.loadlisttolocal("expsubcategory", rd.expenseCategory);
        var $ddl = $("#expenseSubCategory", p);
        lossanalysis.getobjhtmlfromlist($ddl, lossanalysis.data.partb.expsubcatlist, 1);
       
        window.setTimeout(function () {
            $ddl.val(rd.expenseSubCategory);
        }, 1000);
        $("select#expenseCategory", p).on("change", function (e) {
            lossanalysis.onexpcatchange(e);
        });
    },
    onbeforeshowformexpadd: function (p) {
        $("select#expenseCategory", p).on("change", function (e) {
            lossanalysis.onexpcatchange(e);
        });
    },
    onexpcatchange: function (e) {
        lossanalysis.data.partb.expsubcatlist = lossanalysis.loadlisttolocal("expsubcategory", $(e.target).val());
        var $ddl = $("#expenseSubCategory", $(e.target).closest("table"));
        lossanalysis.getobjhtmlfromlist($ddl, lossanalysis.data.partb.expsubcatlist, 1);
    },
    
    editrowreconrecovery: function (p) {
        var $grid = $("#tbl_recon_supprecovery");
        if (p && p !== lossanalysis.data.reconciliation.supprecovery.lastselectedrow) {
            $grid.jqGrid('restoreRow', lossanalysis.data.reconciliation.supprecovery.lastselectedrow);
            $grid.jqGrid('editRow', p, { keys: false }); 
            lossanalysis.data.reconciliation.supprecovery.lastselectedrow = p;
            $("#tbl_recon_supprecovery_iledit", "#tbl_recon_supprecovery_pager").trigger("click");
        } else {
            if (p == lossanalysis.data.reconciliation.supprecovery.lastselectedrow
                && $("#" + p, $grid).attr("editable") !== "1") {
                $grid.jqGrid('editRow', p, { keys: false });
                $("#tbl_recon_supprecovery_iledit", "#tbl_recon_supprecovery_pager").trigger("click");
            }
        }
    },
    loadreconrecoverygrid: function (p) {
        $("#tbl_recon_supprecovery").jqGrid({
            url: getReconSuppRecoveryUrl,
            postData: { loanid: function () { return lossanalysis.getloanid(); }, recovery: 1 },
            datatype: "json",
            caption: "Supplemental Recovery",
            colModel: [
                { label: "Id", name: "loanId", key: true, hidden: true },
                { label: "Category", name: 'lkpTypeCatName', width: 100 },
                {
                    label: "Sub-Category", name: 'lkpTypeSubCatName', width: 100
                },
                { label: "Date Disbursed", name: 'disbursedDate', width: 80 },
                {
                    label: "Supplemental Amount", name: 'claimAmount', width: 80, 
                    formatter: "currency", formatoptions: { decimalSeparator: ".", thousandsSeparator: ",", decimalPlaces: 2, prefix: "$" }
                }
            ],
            loadonce: true,
            autowidth: true,
            viewrecords: true,
            height: 100,
            rowList: [20, 40, 80],
            pginput: false,
            rowNum: 20,
            pager: "#tbl_recon_supprecovery_pager"

        });
        $("#tbl_recon_supprecovery").navGrid("#tbl_recon_supprecovery_pager", {
            add: false, edit: false, del: false, search: false, beforeRefresh: home.onbeforerefresh });
    },
    loadreconrefundgrid: function (p) {
        $("#tbl_recon_supprefund").jqGrid({
            url: getReconSuppRecoveryUrl,
            postData: { loanid: function () { return lossanalysis.getloanid(); }, recovery: 0 },
            datatype: "json",
            caption: "Supplemental Refund",
            colModel: [
                { label: "Id", name: "loanId", key: true, hidden: true },
                { label: "Category", name: 'lkpTypeCatName', width: 100 },
                {
                    label: "Sub-Category", name: 'lkpTypeSubCatName', width: 100
                },
                { label: "Date Disbursed", name: 'disbursedDate', width: 80 },
                {
                    label: "Supplemental Amount", name: 'claimAmount', width: 80,
                    formatter: "currency", formatoptions: { decimalSeparator: ".", thousandsSeparator: ",", decimalPlaces: 2, prefix: "$" }
                }
            ],
            loadonce: true,
            autowidth: true,
            viewrecords: true,
            height: 100,
            rowList: [20, 40, 80],
            pginput: false,
            rowNum: 20,
            pager: "#tbl_recon_supprefund_pager"

        });
        $("#tbl_recon_supprefund").navGrid("#tbl_recon_supprefund_pager", {
            add: false, edit: false, del: false, search: false, refresh: true, beforeRefresh: home.onbeforerefresh
        });
    },
    editrowworkflow: function (p) {
        var $grid = $("#tbl_workflow");
        if (p && p !== lossanalysis.data.workflow.lastselectedrow) {
            $grid.jqGrid('restoreRow', lossanalysis.data.workflow.lastselectedrow);
            $grid.jqGrid('editRow', p, { keys: false });
            lossanalysis.data.workflow.lastselectedrow = p;
            $("#tbl_workflow_iledit", "#tbl_workflow_pager").trigger("click");
        } else {
            if (p == lossanalysis.data.workflow.lastselectedrow
                && $("#" + p, $grid).attr("editable") !== "1") {
                $grid.jqGrid('editRow', p, { keys: false });
                $("#tbl_workflow_iledit", "#tbl_workflow_pager").trigger("click");
            }
        }
    },
    loadworkflowgrid: function (p) {
        $("#tbl_workflow").jqGrid({
            data: lossanalysis.data.workflow.data,
            datatype: "local",
            editurl: "clientArray",
            postData: { LoanId: function () { return lossanalysis.getloanid(); } },
            caption: "Active Workflow",
            colModel: [
                { label: "Id", name: "Id", key: true, hidden: true },
                {
                    label: "Workflow", name: 'Milestaone', width: 100, editable: true, formatter: "select", edittype: "select",
                    editoptions: { value: lossanalysis.data.workflow.milestonelist },
                    formatoptions: { value: lossanalysis.data.workflow.milestonelist }
                },
                {
                    label: "Created Person", name: 'CreatedPerson', width: 100, editable: true, formatter: "select", edittype: "select",
                    editoptions: { value: lossanalysis.data.lauserlist },
                    formatoptions: { value: lossanalysis.data.lauserlist }
                },
                { label: "Date Created", name: 'DateCreated', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } },
                {
                    label: "Assigned To", name: 'AssignedTo', width: 100, editable: true, formatter: "select", edittype: "select",
                    editoptions: { value: lossanalysis.data.lauserlist },
                    formatoptions: { value: lossanalysis.data.lauserlist }
                },
                {
                    label: "Status", name: 'Status', width: 80, editable: true, formatter: "select", edittype: "select",
                    editoptions: { value: lossanalysis.data.workflow.milestonestatuslist },
                    formatoptions: { value: lossanalysis.data.workflow.milestonestatuslist }
                },
                { label: "Status Date", name: 'StatusDate', width: 80, editable: true, editoptions: { size: 20, dataInit: lossanalysis.enabledatepicker } }
            ],
          //  loadonce: true,
            autowidth: true,
            viewrecords: true,
            onSelectRow: lossanalysis.editrowworkflow,
            height: 300,
            rowNum: 30,
            inlineData: { LoanId: function () { return lossanalysis.getloanid(); } }, 
            pager: "#tbl_workflow_pager"

        });
        $("#tbl_workflow").navGrid("#tbl_workflow_pager", {
            add: false, edit: false, search: false, refresh: false
        });
        $("#tbl_workflow").inlineNav("#tbl_workflow_pager", { cancelicon: "fa fa-undo"});
    },
    loadimporthistgrid: function (p) {
        $("#tbl_import_hist").jqGrid({
            data: lossanalysis.data.import.data,
            datatype: "local",
            editurl: "clientArray",
            postData: { LoanId: function () { return lossanalysis.getloanid(); } },
            caption: "Data Import History",
            colModel: [
                { label: "Id", name: "Id", key: true, hidden: true },
                { label: "File Name", name: 'FileName', width: 100 },
                { label: "Template", name: 'Template', width: 100 },
                { label: "Status", name: 'Status', width: 100 },
                { label: "Size", name: 'Size', width: 100 },
                { label: "Total Rows", name: 'TotalRows', width: 100 },
                { label: "Uploaded Person", name: 'UploadedPerson', width: 100 },
                { label: "Date Uploaded", name: 'DateUploaded', width: 100 }
            ],
          //  loadonce: true,
            autowidth: true,
            viewrecords: true,
            height: 300,
            rowNum: 50,
            pager: "#tbl_import_hist_pager",
            subGrid: true,
            subGridRowExpanded: function (sgdivid, rowid) {
                home.collopsesgrows(this, sgdivid, rowid);
                var subgrid_table_id;
                subgrid_table_id = sgdivid + "_t";
                $("#" + sgdivid).html("<table id='" + subgrid_table_id + "' class='scroll'></table>");
                $("#" + subgrid_table_id).jqGrid({
                    datatype: "local",
                    data: lossanalysis.data.import.error,
                    colNames: ['', 'Error Message'],
                    colModel: [
                        { name: "Id", key: true, hidden: true },
                        { name: "Message", width: 150, sortable: false }
                     
                    ],
                    height: 'auto',
                    rowNum: 50
                });
            }
        });
        $("#tbl_import_hist").navGrid("#tbl_import_hist_pager", {
            add: false, edit: false, del: false, search: false, refresh: true
        });
    }
};