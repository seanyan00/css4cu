﻿/* jquery 3.3.1, jqgrid 5.4.0 */

function ajaxFailed(jqXHR, status, errmsg) {
    alert(errmsg);
}
var home = {
    data: {
        gridid: "",
        elepos: null,
        dragfileicon: null,
        scrolltop: 0,
        orgviewmodal: $.jgrid.viewModal,
        submitcallback: null
    },
    init: function () {
        $.extend($.jgrid, {
            viewModal: function (selector, o) {
                if (selector.indexOf("#alertmod_") === 0) {
                    var $gbox = $(o.gbox), $selector = $(selector);
                    var of = $gbox.offset(), w = $gbox.width(), h = $gbox.height();
                    var w1 = $selector.width(), h1 = $selector.height();
                    $selector.css({
                        'top': of.top + ((h - h1) / 2),
                        'left': of.left + ((w - w1) / 2)
                    });
                }
                home.data.orgviewmodal.call(this, selector, o);
            }
        });
        $(".datepicker").datepicker({
            format: 'mm/dd/yyyy',
            todayHighlight: true,
            autoclose: true,
            forceParse: false
        })/*
         .on("show", function (e) {
            if (e.date) {
                $(this).data("stickydate", e.date);
            } else {
                $(this).data("stickydate", null);
            }
        }).on("hide", function (e) {
            var sd = $(this).data("stickydate");
            if (!e.date && sd) {
                $(this).datepicker("setDate", sd);
                $(this).data("stickydate", null);
            }
        }); */;
        $("#frm_dummy").on("load", function () {
            var message = $("#frm_dummy").contents().find("body").html();
            var ttl = $("#frm_dummy").contents()[0].title;
            var $dlg = $("#dlg_info"), $lbr = $dlg.find(".row"), $lb = $dlg.find("label");
            if (ttl.length > 0 && ttl === "Success") {
                if (home.data.submitcallback != null) {
                    home.data.submitcallback();
                    home.data.submitcallback = null;
                }

                $lbr.removeClass("bg-warning");
                $lbr.addClass("bg-success");
                $lb.text(message);
                $dlg.modal({
                    backdrop: false,
                    show: true
                });
           
                window.setTimeout(function () { $("#dlg_info").modal("hide"); }, 2500);
             
                // home.showinfo(message, false);
            }
            else {
               $lbr.removeClass("bg-success");
                $lbr.addClass("bg-warning");
                $lb.text(message);
                $dlg.modal({
                    backdrop: true,
                    show: true
                });
            //    home.showinfo(message, true);
            }
            $dlg[0].style.top = (home.data.elepos.top - 50) + "px";
           // $(window)['scrollTop'](home.data.scrolltop);
        });
        $('#sidebar .sub-menu > a').click(function () {
            var last = $('.sub-menu.open', $('#sidebar'));
            $('.menu-arrow').removeClass('arrow_carrot-right');
            $('.sub', last).slideUp(200);
            var sub = $(this).next();
            if (sub.is(":visible")) {
                $('.menu-arrow').addClass('arrow_carrot-right');
                sub.slideUp(200);
            } else {
                $('.menu-arrow').addClass('arrow_carrot-down');
                sub.slideDown(200);
            }
            var o = ($(this).offset());
            diff = 200 - o.top;
            if (diff > 0) {
                $("#sidebar").scrollTop = 500;
                $("#sidebar").scrollLeft -= Math.abs(diff);
            }
            else {
                $("#sidebar").scrollTop = 500;
                $("#sidebar").scrollLeft += Math.abs(diff);
            }
        });
        $(window).on('load', home.responsive);
        $(window).on('resize', home.responsive);
                 
        $('.toggle-nav').click(function () {
            if ($('#sidebar > ul').is(":visible") === true) {
                $('#main-content').css({
                    'margin-left': '0px'
                });
                $('#sidebar').css({
                    'margin-left': '-200px'
                });
                $('#sidebar > ul').hide();
                $("#container").addClass("sidebar-closed");
            } else {
                $('#main-content').css({
                    'margin-left': '200px'
                });
                $('#sidebar > ul').show();
                $('#sidebar').css({
                    'margin-left': '0'
                });
                $("#container").removeClass("sidebar-closed");
            }
        });
    },
    responsive: function() {
        var wSize = $(window).width();
        if (wSize <= 768) {
            $('#container').addClass('sidebar-close');
            $('#sidebar > ul').hide();
        }
        if (wSize > 768) {
            $('#container').removeClass('sidebar-close');
            $('#sidebar > ul').show();
        }
    },
    showinfo: function (p, p1) {
        var $lb = $(".lb-info");
        $lb.text(p);
        if (p1) {
            $lb.removeClass("bg-success");
            $lb.addClass("bg-danger");
        } else {
            $lb.removeClass("bg-danger");
            $lb.addClass("bg-success");
        }
    },
    clearinfo: function () {
        $(".lb-info").text("");
    },
    showloading: function () {
        var html = $("#scp_loading").html();
        $("body").append(html);
    },
    removeloading: function () {
        $("div.loading-overlay").remove();
    },
    logout: function () {
        $.ajax({
            type: "POST",
            headers: tokenhead,
            url: logoutUrl
        }).done(function () {}).fail(ajaxFailed);
    },
    onbeforerefresh: function () {
        $(this).jqGrid("setGridParam", { datatype: "json" });
        return [true, "", ""];
    },
    onbeforeshowform: function (p) {
        var gid = p[0].id.substr("FrmGrid_".length); //FrmGrid_tbl_parta_lossmit
        home.data.gridid = gid;
    },
    onaftersubmit: function (p) {
        if (p.status == 200) {
            var res = $.parseJSON(p.responseText);
          
            var msg = res.message;
            
          /*  var html = "<div class='bg-success text-white' style='padding: 5px;'>Data Saved</div>";
         
            if (!res.success)
                html = "<div class='bg-warning text-white' style='padding: 5px;'>" + msg + "</div>";

            if (home.data.gridid.length > 0) {
                var $grid = $("#" + home.data.gridid);
                home.data.gridid = "";
                $.jgrid.info_dialog("", html);

                $("#info_dialog")[0].style.top = ($grid.offset().top + 100) + "px";
                $("#info_dialog")[0].style.left = ($grid.offset().left + 300) + "px";

                $("#info_dialog").focus();
                $("#info_dialog").delay(3000).fadeOut();
            }*/
            return [true, msg];
        } else
            return [false, "Error Occurred"];
    },
    collopsesgrows: function (p, p1, p2) {
        var $grid = $(p);
        var trs = $("tr:has('.sgexpanded')", $grid);
        $.each(trs, function () {
            $grid.collapseSubGridRow(this.id);
        });
    },
    getfloat: function (p) {
        var ret = 0;
        if (p.length > 0) {
            var temp = p.indexOf("$") >= 0 ? p.substring(p.indexOf("$") + 1) : p;
            ret = isNaN(parseFloat(temp)) ? 0 : parseFloat(temp);
        }
        return ret;
    },
    setelepos: function (p) {
        home.data.elepos = p.getBoundingClientRect();
        home.data.scrolltop = $(window)['scrollTop']();
    },
    datenorm: function (p) {
        var ret = p;
        var reg = /^\d{1,2}\/\d{1,2}\/(\d{2}|\d{4})$/;
        var cy = parseInt(new Date().getFullYear().toString().substr(-2));
        if (reg.test(p)) {
            var darr = p.split("/");
            var m = ("0" + darr[0]).slice(-2), d = ("0" + darr[1]).slice(-2);
            var y = darr[2].length == 4 ? darr[2]
                : (parseInt(darr[2]) > cy ? ("19" + darr[2]) : ("20" + darr[2]));
            ret = m + "/" + d + "/" + y;
        } 
        return ret;
    },
    griddateformatter: function (p, p1, p2) {
        return home.datenorm(p);
    },
    prepand: function (p, p1) {
        var ret = p;
        $.each(p1, function (key, value) {
            ret[key] = value;
        });
        return p;
    }
};
var compressor = {
    data: { done: false, dirty: true },
    init: function () {
        $("#tb_his").on('shown.bs.tab', function (e) {
            compressor.loadhistgrid();
        });
        $("select[id^='ddl_client']").on("change", function (e) {
            compressor.loadclientconfig(e);
        });
        $("#btn_cancel").on("click", function (e) {
            compressor.onbtncancelclick(e);
        });
        $("select, input:checkbox, input:text", "#fm_config").on("change input click", function () {
            compressor.data.dirty = true;
            home.clearinfo();
        });
        $("#fm_config").submit(function (e) {
            e.preventDefault();
            if (compressor.data.dirty) {
                var $this = $(this);
                var vm = $this.serialize();

                vm += "&Cron=" + $('#txt_min').val() + "+" + $('#txt_hr').val() + "+" + $('#txt_day').val()
                    + "+" + $('#txt_mon').val() + "+" + $('#txt_dow').val() + "&Active=" + ($("#chk_act").is(":checked") ? "True" : "False");
                $.ajax({
                    type: $this.attr('method'),
                    url: $this.attr('action'),
                    data: vm
                }).done(function (data) {
                    compressor.data.dirty = false;

                    if (data.success) {
                        home.showinfo("Data saved", false);
                    } else {
                        home.showinfo(data.message, true);
                    }
                }).fail(ajaxFailed);
            }
        });
        $("#fm_run").submit(function (e) {
            e.preventDefault();
            $("#txt_msg").val("");

            var $this = $(this);
            var vm = $this.serialize();
            compressor.data.done = false;

            $.ajax({
                type: $this.attr('method'),
                url: $this.attr('action'),
                data: vm
            }).done(function (data) {
                if (data.success) {
                    $("#hdn_msgid").val("0");
                    compressor.getsessionmsg();
                }
            }).fail(ajaxFailed);
        })
        compressor.loadddls();
    },
    onbtncancelclick: function (p) {
        p.preventDefault();
        $.ajax({
            url: cancelUrl,
            cache: false
        }).done(function (data) { }).fail(ajaxFailed);
    },
    getsessionmsg: function () {
        var id = $("#hdn_msgid").val();
        $.ajax({
            url: getSessionMsgUrl + "?id=" + id,
            async: false,
            cache: false
        }).done(function (data) {
            var $text = $("#txt_msg");
            $.each(data, function () {
                if (this.Value === "Done" || this.Value == "Cancelled")
                    compressor.data.done = true;

                if (parseInt(this.Key) > parseInt(id)) {
                    id = this.Key;
                    $text.val($text.val() + "\n" + this.Value);
                    $text.scrollTop($text[0].scrollHeight - $text.height());
                }
            })
            $("#hdn_msgid").val(id);
            if (!compressor.data.done)
                window.setTimeout(compressor.getsessionmsg, 30000);

        }).fail(ajaxFailed);
    },
    loadddls: function () {
        $.ajax({
            url: getDDLUrl + "?type=client",
            success: function (data) {
                $("#ddl_client").html(data);
                $("#ddl_client_l").html(data);
            }
        })
    },
    loadclientconfig: function (p) {
        var id = $(p.target).val();
        if (id.length === 0)
            return;
        $.ajax({
            url: getCompressConfigUrl + "?clientid=" + id,
            success: function (data) {
                if (p.target.id === "ddl_client") {
                    $("#txt_srcdir").val(data.sourceDir);
                    $("#txt_tardir").val(data.targetDir);
                    $("#txt_errdir").val(data.errorDir);
                    $("#txt_limit").val(data.limit);
                } else {
                    $("#txt_srcdir_l").val(data.sourceDir);
                    $("#txt_tardir_l").val(data.targetDir);
                    $("#txt_errdir_l").val(data.errorDir);
                    $("#txt_limit_l").val(data.limit);
                    var cron = data.cron.split(" ");
                    if (cron.length < 5)
                        return;
                    $("#txt_min").val(cron[0]);
                    $("#txt_hr").val(cron[1]);
                    $("#txt_day").val(cron[2]);
                    $("#txt_mon").val(cron[3]);
                    $("#txt_dow").val(cron[4]);
                    $("#txt_crfsdl").val(data.crfsDL);
                    $("#txt_clientdl").val(data.clientDL);
                    $("#txt_comment").val(data.comment);

                    $("#chk_act").prop("checked", data.active ? "checked" : "");
                }
            }
        });
    },
    loadhistgrid: function () {
        $("#tbl_hist").jqGrid({
            url: getCompressHistUrl,
            mtype: "GET",
            datatype: "json",
            colModel: [
                { label: 'Id', name: 'BatchId', key: true, width: 50 },
                { label: 'Client', name: 'ClientName', width: 150 },
                { label: 'Run Date', name: 'RunDate', width: 150 },
                { label: 'Run By', name: 'RunBy', width: 150 },
                { label: 'Total Time', name: 'TtlTime', sortable: false, width: 80 },
                { label: 'Total File', name: 'TtlFile', sortable: false, width: 80 },
                { label: 'Compressed', name: 'TtlCompressed', sortable: false, width: 80 },
                { label: 'Error', name: 'TtlError', sortable: false, width: 150 }
            ],
            viewrecords: true,
            autowidth: true,
            height: 350,
            rowNum: 50,
            loadonce: true,
            pager: "#tbl_hist_pager",
            subGrid: true,
            subGridRowExpanded: function (subgrid_id, row_id) {
                var subgrid_table_id;
                subgrid_table_id = subgrid_id + "_t";
                $("#" + subgrid_id).html("<table id='" + subgrid_table_id + "' class='scroll'></table>");
                $("#" + subgrid_table_id).jqGrid({
                    url: getCompressHistDetailUrl + "?batchid=" + row_id,
                    datatype: "json",
                    colNames: ['', 'File Name', 'Size Before', 'Size After', 'Time Start', 'Time End', 'Status', 'Reason'],
                    colModel: [
                        { name: "DetailId", key: true, hidden: true },
                        { name: "FName", width: 150, sortable: false },
                        { name: "SizeBefore", width: 50, sortable: false },
                        { name: "SizeAfter", width: 50, sortable: false },
                        { name: "TimeStart", width: 110, sortable: false },
                        { name: "TimeEnd", width: 110, sortable: false },
                        { name: "Status", width: 80, sortable: false },
                        { name: "Reason", sortable: false }
                    ],
                    height: 'auto',
                    rowNum: 50,
                    sortname: 'DetailId',
                    sortorder: "asc"
                });
            }
        });
        $("#tbl_hist").navGrid("#tbl_hist_pager", {
            edit: false,
            add: false,
            del: false,
            search: false,
            beforeRefresh: home.onbeforerefresh
        });
    }
}
