﻿/* jquery 3.3.1, jqgrid 5.4.0 */

function ajaxFailed(jqXHR, status, errmsg) {
    alert(errmsg);
}
var home = {
    data: {
        dirtyobj: null
    },
    init: function () {
        $(".datepicker").datepicker({
            format: 'mm/dd/yyyy',
            todayHighlight: true,
            autoclose: true
        });
        $("#frm_dummy").on("load", function () {
            var message = $("#frm_dummy").contents().find("body").html();
            var ttl = $("#frm_dummy").contents()[0].title;
            if (ttl.length > 0 && ttl === "Success") {
             /*   if (home.data.dirtyobj != null)
                    home.data.dirtyobj = false;*/
                home.showinfo(message, false);
            }
            else
                home.showinfo(message, true);

        });
        $('#sidebar .sub-menu > a').click(function () {
            var last = $('.sub-menu.open', $('#sidebar'));
            $('.menu-arrow').removeClass('arrow_carrot-right');
            $('.sub', last).slideUp(200);
            var sub = $(this).next();
            if (sub.is(":visible")) {
                $('.menu-arrow').addClass('arrow_carrot-right');
                sub.slideUp(200);
            } else {
                $('.menu-arrow').addClass('arrow_carrot-down');
                sub.slideDown(200);
            }
            var o = ($(this).offset());
            diff = 200 - o.top;
            if (diff > 0) {
                $("#sidebar").scrollTop = 500;
                $("#sidebar").scrollLeft -= Math.abs(diff);
            }
            else {
                $("#sidebar").scrollTop = 500;
                $("#sidebar").scrollLeft += Math.abs(diff);
            }
        });
        $(window).on('load', home.responsive);
        $(window).on('resize', home.responsive);
                 
        $('.toggle-nav').click(function () {
            if ($('#sidebar > ul').is(":visible") === true) {
                $('#main-content').css({
                    'margin-left': '0px'
                });
                $('#sidebar').css({
                    'margin-left': '-200px'
                });
                $('#sidebar > ul').hide();
                $("#container").addClass("sidebar-closed");
            } else {
                $('#main-content').css({
                    'margin-left': '200px'
                });
                $('#sidebar > ul').show();
                $('#sidebar').css({
                    'margin-left': '0'
                });
                $("#container").removeClass("sidebar-closed");
            }
        });
    },
    responsive: function() {
        var wSize = $(window).width();
        if (wSize <= 768) {
            $('#container').addClass('sidebar-close');
            $('#sidebar > ul').hide();
        }
        if (wSize > 768) {
            $('#container').removeClass('sidebar-close');
            $('#sidebar > ul').show();
        }
    },
    showinfo: function (p, p1) {
        var $lb = $(".lb-info");
        $lb.text(p);
        if (p1) {
            $lb.removeClass("bg-success");
            $lb.addClass("bg-danger");
        } else {
            $lb.removeClass("bg-danger");
            $lb.addClass("bg-success");
        }
    },
    clearinfo: function () {
        $(".lb-info").text("");
    },
    showloading: function () {
        var html = $("#scp_loading").html();
        $("body").append(html);
    },
    removeloading: function () {
        $("div.loading-overlay").remove();
    },
    logout: function () {
        $.ajax({
            type: "POST",
            headers: tokenhead,
            url: logoutUrl
        }).done(function () {}).fail(ajaxFailed);
    },
    onbeforerefresh: function () {
        $(this).jqGrid("setGridParam", { datatype: "json" });
        return [true, "", ""];
    },
    onaftersubmit: function (p) {
        if (p.status == 200) {
            var res = $.parseJSON(p.responseText);

            var html = "<div class='bg-lightgreen' style='padding: 5px;'>Data Saved</div>";
            var msg = res.message;
            if (!res.success)
                html = "<div class='text-warning' style='padding: 5px;'>" + msg + "</div>";

            $.jgrid.info_dialog("", html);
            $("#info_dialog").addClass("centerdlg");
            $("#info_dialog").delay(3000).fadeOut();
            return [true, msg];
        } else
            return [false, "Error Occurred"];
    },
    collopsesgrows: function (p, p1, p2) {
        var $grid = $(p);
        var trs = $("tr:has('.sgexpanded')", $grid);
        $.each(trs, function () {
            $grid.collapseSubGridRow(this.id);
        });
    },
    getfloat: function (p) {
        var ret = 0;
        if (p.length > 0) {
            var temp = p.indexOf("$") >= 0 ? p.substring(p.indexOf("$") + 1) : p;
            ret = isNaN(parseFloat(temp)) ? 0 : parseFloat(temp);
        }
        return ret;
    }
};
var compressor = {
    data: { done: false, dirty: true },
    init: function () {
        $("#tb_his").on('shown.bs.tab', function (e) {
            compressor.loadhistgrid();
        });
        $("select[id^='ddl_client']").on("change", function (e) {
            compressor.loadclientconfig(e);
        });
        $("#btn_cancel").on("click", function (e) {
            compressor.onbtncancelclick(e);
        });
        $("select, input:checkbox, input:text", "#fm_config").on("change input click", function () {
            compressor.data.dirty = true;
            home.clearinfo();
        });
        $("#fm_config").submit(function (e) {
            e.preventDefault();
            if (compressor.data.dirty) {
                var $this = $(this);
                var vm = $this.serialize();

                vm += "&Cron=" + $('#txt_min').val() + "+" + $('#txt_hr').val() + "+" + $('#txt_day').val()
                    + "+" + $('#txt_mon').val() + "+" + $('#txt_dow').val() + "&Active=" + ($("#chk_act").is(":checked") ? "True" : "False");
                $.ajax({
                    type: $this.attr('method'),
                    url: $this.attr('action'),
                    data: vm
                }).done(function (data) {
                    compressor.data.dirty = false;

                    if (data.success) {
                        home.showinfo("Data saved", false);
                    } else {
                        home.showinfo(data.message, true);
                    }
                }).fail(ajaxFailed);
            }
        });
        $("#fm_run").submit(function (e) {
            e.preventDefault();
            $("#txt_msg").val("");

            var $this = $(this);
            var vm = $this.serialize();
            compressor.data.done = false;

            $.ajax({
                type: $this.attr('method'),
                url: $this.attr('action'),
                data: vm
            }).done(function (data) {
                if (data.success) {
                    $("#hdn_msgid").val("0");
                    compressor.getsessionmsg();
                }
            }).fail(ajaxFailed);
        })
        compressor.loadddls();
    },
    onbtncancelclick: function (p) {
        p.preventDefault();
        $.ajax({
            url: cancelUrl,
            cache: false
        }).done(function (data) { }).fail(ajaxFailed);
    },
    getsessionmsg: function () {
        var id = $("#hdn_msgid").val();
        $.ajax({
            url: getSessionMsgUrl + "?id=" + id,
            async: false,
            cache: false
        }).done(function (data) {
            var $text = $("#txt_msg");
            $.each(data, function () {
                if (this.Value === "Done" || this.Value == "Cancelled")
                    compressor.data.done = true;

                if (parseInt(this.Key) > parseInt(id)) {
                    id = this.Key;
                    $text.val($text.val() + "\n" + this.Value);
                    $text.scrollTop($text[0].scrollHeight - $text.height());
                }
            })
            $("#hdn_msgid").val(id);
            if (!compressor.data.done)
                window.setTimeout(compressor.getsessionmsg, 30000);

        }).fail(ajaxFailed);
    },
    loadddls: function () {
        $.ajax({
            url: getDDLUrl + "?type=client",
            success: function (data) {
                $("#ddl_client").html(data);
                $("#ddl_client_l").html(data);
            }
        })
    },
    loadclientconfig: function (p) {
        var id = $(p.target).val();
        if (id.length === 0)
            return;
        $.ajax({
            url: getCompressConfigUrl + "?clientid=" + id,
            success: function (data) {
                if (p.target.id === "ddl_client") {
                    $("#txt_srcdir").val(data.sourceDir);
                    $("#txt_tardir").val(data.targetDir);
                    $("#txt_errdir").val(data.errorDir);
                    $("#txt_limit").val(data.limit);
                } else {
                    $("#txt_srcdir_l").val(data.sourceDir);
                    $("#txt_tardir_l").val(data.targetDir);
                    $("#txt_errdir_l").val(data.errorDir);
                    $("#txt_limit_l").val(data.limit);
                    var cron = data.cron.split(" ");
                    if (cron.length < 5)
                        return;
                    $("#txt_min").val(cron[0]);
                    $("#txt_hr").val(cron[1]);
                    $("#txt_day").val(cron[2]);
                    $("#txt_mon").val(cron[3]);
                    $("#txt_dow").val(cron[4]);
                    $("#txt_crfsdl").val(data.crfsDL);
                    $("#txt_clientdl").val(data.clientDL);
                    $("#txt_comment").val(data.comment);

                    $("#chk_act").prop("checked", data.active ? "checked" : "");
                }
            }
        });
    },
    loadhistgrid: function () {
        $("#tbl_hist").jqGrid({
            url: getCompressHistUrl,
            mtype: "GET",
            datatype: "json",
            colModel: [
                { label: 'Id', name: 'BatchId', key: true, width: 50 },
                { label: 'Client', name: 'ClientName', width: 150 },
                { label: 'Run Date', name: 'RunDate', width: 150 },
                { label: 'Run By', name: 'RunBy', width: 150 },
                { label: 'Total Time', name: 'TtlTime', sortable: false, width: 80 },
                { label: 'Total File', name: 'TtlFile', sortable: false, width: 80 },
                { label: 'Compressed', name: 'TtlCompressed', sortable: false, width: 80 },
                { label: 'Error', name: 'TtlError', sortable: false, width: 150 }
            ],
            viewrecords: true,
            autowidth: true,
            height: 350,
            rowNum: 50,
            loadonce: true,
            pager: "#tbl_hist_pager",
            subGrid: true,
            subGridRowExpanded: function (subgrid_id, row_id) {
                var subgrid_table_id;
                subgrid_table_id = subgrid_id + "_t";
                $("#" + subgrid_id).html("<table id='" + subgrid_table_id + "' class='scroll'></table>");
                $("#" + subgrid_table_id).jqGrid({
                    url: getCompressHistDetailUrl + "?batchid=" + row_id,
                    datatype: "json",
                    colNames: ['', 'File Name', 'Size Before', 'Size After', 'Time Start', 'Time End', 'Status', 'Reason'],
                    colModel: [
                        { name: "DetailId", key: true, hidden: true },
                        { name: "FName", width: 150, sortable: false },
                        { name: "SizeBefore", width: 50, sortable: false },
                        { name: "SizeAfter", width: 50, sortable: false },
                        { name: "TimeStart", width: 110, sortable: false },
                        { name: "TimeEnd", width: 110, sortable: false },
                        { name: "Status", width: 80, sortable: false },
                        { name: "Reason", sortable: false }
                    ],
                    height: 'auto',
                    rowNum: 50,
                    sortname: 'DetailId',
                    sortorder: "asc"
                });
            }
        });
        $("#tbl_hist").navGrid("#tbl_hist_pager", {
            edit: false,
            add: false,
            del: false,
            search: false,
            beforeRefresh: home.onbeforerefresh
        });
    }
}
