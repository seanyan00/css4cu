﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRFS.IS.Service.Scheduler
{
    interface ISchedulerFactory
    {
        Scheduler Create();
    }
}
