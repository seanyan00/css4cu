 #region Imports

    using System;    
    using System.Runtime.Serialization;
    
 #endregion
namespace CRFS.IS.Service.Scheduler.Cron
{
    [ Serializable ]
    public class CronException : Exception
    {
        public CronException() :
            base("Crontab error.") {} // TODO: Fix message and add it to resource.

        public CronException(string message) : 
            base(message) {}

        public CronException(string message, Exception innerException) :
            base(message, innerException) {}

        protected CronException(SerializationInfo info, StreamingContext context) : 
            base(info, context) {}
    }
}