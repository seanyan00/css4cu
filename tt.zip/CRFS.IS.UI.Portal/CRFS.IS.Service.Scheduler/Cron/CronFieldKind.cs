using System;
namespace CRFS.IS.Service.Scheduler.Cron
{
    [ Serializable ]
    public enum CronFieldKind
    {
        Minute = 0, // Keep in order of appearance in expression
        Hour, 
        Day, 
        Month, 
        DayOfWeek   
    }
}