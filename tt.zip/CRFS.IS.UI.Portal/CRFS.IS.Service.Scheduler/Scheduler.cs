﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

using CRFS.IS.Service.Data;
using CRFS.IS.Service.Util;
using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Common;

namespace CRFS.IS.Service.Scheduler
{
    public sealed class Scheduler
    {
        private IConfiguration _config;
        private ILogger _logger;
        private static Scheduler _instance = null;
        private static readonly object _locker = new object();
        private static CancellationTokenSource _cts = new CancellationTokenSource();

        private Scheduler(IConfiguration config, ILogger logger) {
            _config = config;
            _logger = logger;
        }
        public static Scheduler CreateInstance(IConfiguration config, ILogger logger)
        {
            lock (_locker)
            {
                if (_instance == null)
                {
                    _instance = new Scheduler(config, logger);
                }
                return _instance;
            }
        }
        public async void Run()
        {
            var appsetting = _config.GetSection("AppSettings").Get<AppSettings>();
            
            List<TblClientPdfcompression> configs;
          
            try
            {
                while (true)
                {
                    if (_cts.Token.IsCancellationRequested)
                        break;
                   
                    using (var ctx = new ApplicationConfigurationContext())
                    {
                        configs = ctx.TblClientPdfcompression.Where(x => x.Active).ToList();
                    }
                    var now = DateTime.Now;
                    var endtime = DateTime.Now.AddMonths(3);

                    foreach (var config in configs)
                    {
                        try
                        {
                            var cron = new Cron.CronSchedule(config.Cron);
                            var occus = cron.GetNextOccurrences(now, endtime);

                            foreach(var nextrun in occus.Where(x => x >= now && x < now.AddMinutes(appsetting.Scheduler_Interval)).ToList())
                            {
                                var cr = new CompressRequest
                                {
                                    SourceDir = config.SourceFolder,
                                    TargetDir = config.DestinationFolder,
                                    ErrorDir = config.ErrorFolder,
                                    Limit = config.SizeLimitMb ?? 0,
                                    ClientId = config.ClientId
                                };
                                //new thread? uniprocessor?
                                // no wait on below
                                Task.Delay((int)(nextrun - now).TotalSeconds * 1000)
                                    .ContinueWith(t => PDFCompressor.Compress(_cts.Token, cr, _logger, "", appsetting));
                            }
                        }
                        catch(Exception ex)
                        {
                            _logger.LogError("Scheduler:Run:Loop: " + ex.Message);
                            continue;
                        }
                    }
                    await Task.Delay(appsetting.Scheduler_Interval * 1000 * 60, _cts.Token);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("" + ex.Message);
            }
        }
        public void Stop()
        {
            _cts.Cancel();
        }
    }
}
