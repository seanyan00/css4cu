﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace CRFS.IS.Service.Scheduler.Tasks
{
    public class CompressTask : Base.IScheduledTask
    {
        public async void Run(CancellationToken token)
        {

        }
    }
}
