﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRFS.IS.Service.Scheduler.Models
{
    public class SchItem
    {
        public string AppName { get; set; }
        public string Cron { get; set; }
    }
}
