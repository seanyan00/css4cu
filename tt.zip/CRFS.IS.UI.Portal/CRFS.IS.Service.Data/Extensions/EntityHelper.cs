﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.Common.TransferObjects;

namespace CRFS.IS.Service.Data.Extensions
{
    public class EntityHelper<T> where T : class, new()
    {
        private DbContext _ctx;
        public int UID { get; }
        public List<DataEntityDTO> DED { get; private set; }
        public LkpDataset LDS { get; private set; }
    
        public EntityHelper(DbContext ctx, int userid)
        {
            _ctx = ctx;
            _ctx.Database.SetCommandTimeout(Constant.DBCommandTimeout);

            UID = userid;
        }
        public int SaveDTO(List<DataEntityDTO> ded, LkpDataset lds)
        {
            DED = ded;
            LDS = lds;

            try
            {
                var st = _ctx.Set<T>();
                if(LDS.ClearBeforeLoad ?? false)
                {
                    foreach(var p in st)
                    {
                        _ctx.Entry(p).State = EntityState.Deleted;
                    }
                    _ctx.SaveChanges();
                }
                var ret = AddEntities(st);
                _ctx.SaveChanges();

                return ret;
            }
            catch
            {
                throw;
            }
        }
        private int AddEntities(DbSet<T> st)
        {
            var ret = 0;
            var rowid = 0;
            try
            {
                foreach (var dr in DED)
                {
                    ++rowid;
                    var et = new T();
                    SetObjectValues(et, dr);
                    st.Add(et);
                }
            }
            catch(Exception ex)
            {
                 throw new Exception(string.Format("Error: Row# {0}, Message: {1}", rowid, ex.Message));
            }
            return ret;
        }
        private string GetKey()
        {
            var knm = _ctx.Model.FindEntityType(typeof(T)).FindPrimaryKey().Properties.Select(x => x.Name).Single();
            return knm;
        }
        private PropertyInfo[] GetProps(T obj)
        {
            var props = obj.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);
            return props.Where(x => x.PropertyType.Namespace == "System").ToArray();
        }
        private void SetObjectValues(object obj, DataEntityDTO ded)
        {
            bool found = false;
            var propname = "";
            try
            {
                var mds = LDS.LkpDatasetFieldMapping.ToList();

                var pk = GetKey();
                var pts = GetProps((T)obj);
                foreach (var p in pts)
                {
                    if (p.Name == pk)
                        continue;
                    var pname = p.Name;
                    LkpDatasetFieldMapping md = null;
                    if (mds.Any(x => x.AttributeName.NormalName().ToUpper() == p.Name.NormalName().ToUpper()))
                    {
                        md = mds.Where(x => x.AttributeName.NormalName().ToUpper() == p.Name.NormalName().ToUpper()).Single();
                        pname = string.IsNullOrEmpty(md.FieldName) ? pname : md.FieldName;

                        if (md.AutoFill ?? false)
                        {
                            switch (md.FillType)
                            {
                                case "UserID":
                                    p.SetValue(obj, UID);
                                    break;
                                case "Date":
                                    p.SetValue(obj, DateTime.Now);
                                    break;
                                default:
                                    break;
                            }
                            continue;
                        }
                    }
                    found = false;

                    foreach (var d in ded.DataFields)
                    {
                        if (IsMatchedFieldName(pname, d.Name))
                        {
                            var tname = p.PropertyType.IsNullable() ?
                                Nullable.GetUnderlyingType(p.PropertyType).FullName :
                                p.PropertyType.FullName;

                            if (tname == "System.DateTime")
                                p.SetValue(obj, EntityAttributeHelper.GetDateTimeValue(d.Value == null ? "" : d.Value.ToString()));
                            else
                                p.SetValue(obj, EntityAttributeHelper.GetValue(d.Value, p.PropertyType));

                            found = true;
                            break;
                        }
                    }
                    if (!found)
                    {
                        p.SetValue(obj, EntityAttributeHelper.GetDefaultValue(p.PropertyType));
                    }
                }
            }
            catch(Exception ex)
            {
                throw new Exception(string.Format("Property: {0}, Exception: {1}", propname, ex.Message));
            }
        }
        private bool IsMatchedFieldName(string attrname, string fname)
        {
             return attrname.NormalName().ToUpper() == fname.NormalName().ToUpper();
        }
    }
}
