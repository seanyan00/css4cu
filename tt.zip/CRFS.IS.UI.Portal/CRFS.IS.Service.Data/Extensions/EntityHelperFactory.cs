﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.Logging;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.Common.TransferObjects;

namespace CRFS.IS.Service.Data.Extensions
{
    public static class EntityHelperFactory
    {
        public static object CreateInstance(DbContext ctx, string classname, int uid)
        {
            Type targ = Extensions.TypeHelper.GetDataType(classname, Constant.TypeNamespace);

            Type gclass = typeof(Extensions.EntityHelper<>);
            Type cclass = gclass.MakeGenericType(targ);

            return Activator.CreateInstance(cclass, new object[] { ctx, uid });
        }
        public static int SaveDTO(DbContext ctx, List<DataEntityDTO> ded, string classname, LkpDataset lds, int uid)
        {
            try
            {
                object obj = CreateInstance(ctx, classname, uid);
                Type otype = obj.GetType();

                MethodInfo m1 = otype.GetMethod("SaveDTO");

                return (int)m1.Invoke(obj, new object[] { ded, lds });
            } 
            catch(TargetInvocationException ex)
            {
                throw new Exception("SaveDTO", ex.InnerException);
            }
            catch
            {
                throw;
            }
        }
    }
}
