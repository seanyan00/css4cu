﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRFS.IS.Service.Data.DAOs.Models
{
    public class ClientTable
    {
        public string Name { get; set; }
        public string TType { get; set; }
        public int ObjId { get; set; }
        public List<ClientTableColumn> Cols { get; set; }
        public ClientTable()
        {
            Cols = new List<ClientTableColumn>();
        }
    }

    public class ClientTableColumn
    {
        public string Name { get; set; }
        public string DataType { get; set; }
        public bool IsKey { get; set; }
        public int ColId { get; set; }
        public bool IsNullable { get; set; }
        public string DefaultValue { get; set; }
        public int MaxLength { get; set; }
        public string FK { get; set; }
        public bool IsIdentity { get; set; }
    }

}
