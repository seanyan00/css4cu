﻿namespace CRFS.IS.Service.Data.DAOs.Models
{
    public class SiteRole
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int SiteAppId { get; set; }
        public int Status { get; set; }
    }
}
