﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRFS.IS.Service.Data.DAOs.Models
{
    public class AssignedTable
    {
        public int id { get; set; }
        public int dbcid { get; set; }
        public string nm { get; set; }
    }
}
