﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpDataset
    {
        public LkpDataset()
        {
            LkpDatasetFieldMapping = new HashSet<LkpDatasetFieldMapping>();
            TblDataLoad = new HashSet<TblDataLoad>();
            XrefDatasetGrant = new HashSet<XrefDatasetGrant>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Target { get; set; }
        public bool? ClearBeforeLoad { get; set; }
        public string Delimiter { get; set; }
        public int AccessLevel { get; set; }
        public bool Active { get; set; }
        public DateTime DateEntered { get; set; }
        public int EnteredBy { get; set; }
        public DateTime? DateUpdated { get; set; }
        public int? UpdatedBy { get; set; }
        public int? SheetNum { get; set; }

        public virtual ICollection<LkpDatasetFieldMapping> LkpDatasetFieldMapping { get; set; }
        public virtual ICollection<TblDataLoad> TblDataLoad { get; set; }
        public virtual ICollection<XrefDatasetGrant> XrefDatasetGrant { get; set; }
    }
}
