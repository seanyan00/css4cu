﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpDatasetFieldMapping
    {
        public int Id { get; set; }
        public int Dsid { get; set; }
        public string FieldName { get; set; }
        public string AttributeName { get; set; }
        public bool? AutoFill { get; set; }
        public string FillType { get; set; }

        public virtual LkpDataset Ds { get; set; }
    }
}
