﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblDataLoadDetail
    {
        public int Id { get; set; }
        public int Dlid { get; set; }
        public string Error { get; set; }

        public virtual TblDataLoad Dl { get; set; }
    }
}
