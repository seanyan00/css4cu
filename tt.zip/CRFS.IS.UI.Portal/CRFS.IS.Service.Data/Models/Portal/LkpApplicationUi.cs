﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpApplicationUi
    {
        public LkpApplicationUi()
        {
            InverseP = new HashSet<LkpApplicationUi>();
            XrefUigrant = new HashSet<XrefUigrant>();
        }

        public int Id { get; set; }
        public int AppId { get; set; }
        public int? Pid { get; set; }
        public string Uitype { get; set; }
        public string Name { get; set; }
        public string Link { get; set; }
        public string Style { get; set; }
        public int AccessLevel { get; set; }
        public bool Active { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public int? UpdatedBy { get; set; }

        public virtual LkpApplicationUi P { get; set; }
        public virtual ICollection<LkpApplicationUi> InverseP { get; set; }
        public virtual ICollection<XrefUigrant> XrefUigrant { get; set; }
    }
}
