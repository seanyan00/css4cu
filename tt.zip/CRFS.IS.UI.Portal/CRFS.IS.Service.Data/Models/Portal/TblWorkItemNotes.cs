﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblWorkItemNotes
    {
        public int Id { get; set; }
        public int ItemGroupId { get; set; }
        public int ItemId { get; set; }
        public string Note { get; set; }
        public int NotePersonId { get; set; }
        public DateTime NoteDate { get; set; }
        public bool IsInvalidated { get; set; }

        public virtual LkpWorkItemGroup ItemGroup { get; set; }
    }
}
