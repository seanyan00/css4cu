﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CRFS.IS.Service.Data
{
    public partial class PortalContext : DbContext
    {
        public PortalContext()
        {
        }

        public PortalContext(DbContextOptions<PortalContext> options)
            : base(options)
        {
        }

        public virtual DbSet<LkpAccessLevel> LkpAccessLevel { get; set; }
        public virtual DbSet<LkpApplicationUi> LkpApplicationUi { get; set; }
        public virtual DbSet<LkpDataset> LkpDataset { get; set; }
        public virtual DbSet<LkpDatasetFieldMapping> LkpDatasetFieldMapping { get; set; }
        public virtual DbSet<LkpDatasetFieldMappingHist> LkpDatasetFieldMappingHist { get; set; }
        public virtual DbSet<LkpDatasetHist> LkpDatasetHist { get; set; }
        public virtual DbSet<LkpGroup> LkpGroup { get; set; }
        public virtual DbSet<TblClientPdfcompressionBatch> TblClientPdfcompressionBatch { get; set; }
        public virtual DbSet<TblClientPdfcompressionBatchDetail> TblClientPdfcompressionBatchDetail { get; set; }
        public virtual DbSet<TblDataLoad> TblDataLoad { get; set; }
        public virtual DbSet<TblDataLoadDetail> TblDataLoadDetail { get; set; }
        public virtual DbSet<TblFileUpload> TblFileUpload { get; set; }
        public virtual DbSet<TblScheduledJob> TblScheduledJob { get; set; }
        public virtual DbSet<TblScheduledJobStatus> TblScheduledJobStatus { get; set; }
        public virtual DbSet<TblSession> TblSession { get; set; }
        public virtual DbSet<TblSessionDetail> TblSessionDetail { get; set; }
        public virtual DbSet<TblSessionMessage> TblSessionMessage { get; set; }
        public virtual DbSet<VwClientPdfcompressionSummary> VwClientPdfcompressionSummary { get; set; }
        public virtual DbSet<VwPortalUserRole> VwPortalUserRole { get; set; }
        public virtual DbSet<VwUserPermit> VwUserPermit { get; set; }
        public virtual DbSet<XrefAppGrant> XrefAppGrant { get; set; }
        public virtual DbSet<XrefDatasetGrant> XrefDatasetGrant { get; set; }
        public virtual DbSet<XrefUigrant> XrefUigrant { get; set; }
        public virtual DbSet<XrefUserGroup> XrefUserGroup { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=vm-sql1-dev.dev.crfs.crfservices.com\\cms_d;Initial Catalog=Portal;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<LkpAccessLevel>(entity =>
            {
                entity.HasKey(e => e.Lvl)
                    .HasName("PK__lkp_Acce__C650C1533A156642");

                entity.ToTable("lkp_AccessLevel");

                entity.Property(e => e.Lvl).ValueGeneratedNever();

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpApplicationUi>(entity =>
            {
                entity.ToTable("lkp_ApplicationUI");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.Link)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Pid).HasColumnName("PId");

                entity.Property(e => e.Style)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Uitype)
                    .IsRequired()
                    .HasColumnName("UIType")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.HasOne(d => d.P)
                    .WithMany(p => p.InverseP)
                    .HasForeignKey(d => d.Pid)
                    .HasConstraintName("FK_lkp_ApplicationUI_lkp_ApplicationUI");
            });

            modelBuilder.Entity<LkpDataset>(entity =>
            {
                entity.ToTable("lkp_Dataset");

                entity.Property(e => e.DateEntered).HasColumnType("datetime");

                entity.Property(e => e.DateUpdated).HasColumnType("datetime");

                entity.Property(e => e.Delimiter)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Description)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Target)
                    .IsRequired()
                    .HasMaxLength(150)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpDatasetFieldMapping>(entity =>
            {
                entity.ToTable("lkp_DatasetFieldMapping");

                entity.Property(e => e.AttributeName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Dsid).HasColumnName("DSId");

                entity.Property(e => e.FieldName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FillType)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Ds)
                    .WithMany(p => p.LkpDatasetFieldMapping)
                    .HasForeignKey(d => d.Dsid)
                    .HasConstraintName("FK_lkp_DatasetFieldMapping_lkp_Dataset");
            });

            modelBuilder.Entity<LkpDatasetFieldMappingHist>(entity =>
            {
                entity.ToTable("lkp_DatasetFieldMapping_Hist");

                entity.Property(e => e.Act)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AttributeName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.Dsid).HasColumnName("DSId");

                entity.Property(e => e.FieldName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FillType)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpDatasetHist>(entity =>
            {
                entity.ToTable("lkp_Dataset_Hist");

                entity.Property(e => e.Act)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DateAdded).HasColumnType("datetime");

                entity.Property(e => e.DateEntered).HasColumnType("datetime");

                entity.Property(e => e.DateUpdated).HasColumnType("datetime");

                entity.Property(e => e.Delimiter)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Description)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Target)
                    .IsRequired()
                    .HasMaxLength(150)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpGroup>(entity =>
            {
                entity.ToTable("lkp_Group");

                entity.Property(e => e.Description)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblClientPdfcompressionBatch>(entity =>
            {
                entity.ToTable("tbl_ClientPDFCompressionBatch");

                entity.Property(e => e.RunBy)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.RunDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<TblClientPdfcompressionBatchDetail>(entity =>
            {
                entity.HasKey(e => new { e.BatchId, e.ClientId, e.FileName, e.TimeStart });

                entity.ToTable("tbl_ClientPDFCompressionBatchDetail");

                entity.Property(e => e.FileName)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.TimeStart).HasColumnType("datetime");

                entity.Property(e => e.Reason)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TimeEnd).HasColumnType("datetime");

                entity.HasOne(d => d.Batch)
                    .WithMany(p => p.TblClientPdfcompressionBatchDetail)
                    .HasForeignKey(d => d.BatchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tbl_ClientPDFCompressionBatchDetail_tbl_ClientPDFCompressionBatch");
            });

            modelBuilder.Entity<TblDataLoad>(entity =>
            {
                entity.ToTable("tbl_DataLoad");

                entity.Property(e => e.Dsid).HasColumnName("DSId");

                entity.Property(e => e.Status)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Ds)
                    .WithMany(p => p.TblDataLoad)
                    .HasForeignKey(d => d.Dsid)
                    .HasConstraintName("FK_tbl_DataImport_lkp_Dataset");

                entity.HasOne(d => d.Upload)
                    .WithMany(p => p.TblDataLoad)
                    .HasForeignKey(d => d.UploadId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tbl_DataImport_tbl_FileUpload");
            });

            modelBuilder.Entity<TblDataLoadDetail>(entity =>
            {
                entity.ToTable("tbl_DataLoadDetail");

                entity.Property(e => e.Dlid).HasColumnName("DLId");

                entity.Property(e => e.Error)
                    .IsRequired()
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.HasOne(d => d.Dl)
                    .WithMany(p => p.TblDataLoadDetail)
                    .HasForeignKey(d => d.Dlid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tbl_DataImportDetail_tbl_DataImport");
            });

            modelBuilder.Entity<TblFileUpload>(entity =>
            {
                entity.ToTable("tbl_FileUpload");

                entity.Property(e => e.AppName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.FileName)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.ServerPath)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.UploadDate).HasColumnType("datetime");

                entity.Property(e => e.UploadedBy)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblScheduledJob>(entity =>
            {
                entity.ToTable("tbl_ScheduledJob");

                entity.Property(e => e.AppName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ClassName)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Cron)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.Params)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<TblScheduledJobStatus>(entity =>
            {
                entity.ToTable("tbl_ScheduledJobStatus");

                entity.Property(e => e.Message)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.RunBy)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TimeEnd).HasColumnType("datetime");

                entity.Property(e => e.TimeStart).HasColumnType("datetime");

                entity.HasOne(d => d.Job)
                    .WithMany(p => p.TblScheduledJobStatus)
                    .HasForeignKey(d => d.JobId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Tbl_ScheduledJobStatus_Tbl_ScheduledJob");
            });

            modelBuilder.Entity<TblSession>(entity =>
            {
                entity.ToTable("tbl_Session");

                entity.Property(e => e.AppFrom)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.EndTime).HasColumnType("datetime");

                entity.Property(e => e.StartTime).HasColumnType("datetime");

                entity.Property(e => e.Token)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.Uname)
                    .IsRequired()
                    .HasColumnName("UName")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblSessionDetail>(entity =>
            {
                entity.ToTable("tbl_SessionDetail");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.SvcName)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.SvcParams)
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.HasOne(d => d.Session)
                    .WithMany(p => p.TblSessionDetail)
                    .HasForeignKey(d => d.SessionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tbl_SessionDetail_tbl_Session");
            });

            modelBuilder.Entity<TblSessionMessage>(entity =>
            {
                entity.ToTable("tbl_SessionMessage");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.Msg)
                    .IsRequired()
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.HasOne(d => d.SessionDetail)
                    .WithMany(p => p.TblSessionMessage)
                    .HasForeignKey(d => d.SessionDetailId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tbl_SessionMessage_tbl_SessionDetail");
            });

            modelBuilder.Entity<VwClientPdfcompressionSummary>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_ClientPDFCompressionSummary");

                entity.Property(e => e.ClientDisplayName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.RunBy)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.RunDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<VwPortalUserRole>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_PortalUserRole");

                entity.Property(e => e.Rid).HasColumnName("RId");

                entity.Property(e => e.RoleName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Uid).HasColumnName("UId");

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwUserPermit>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_UserPermit");

                entity.Property(e => e.AppName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Gid).HasColumnName("GId");

                entity.Property(e => e.Gname)
                    .IsRequired()
                    .HasColumnName("GName")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Login)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Pid).HasColumnName("PId");

                entity.Property(e => e.Pname)
                    .IsRequired()
                    .HasColumnName("PName")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Uid).HasColumnName("UId");

                entity.Property(e => e.Uiid).HasColumnName("UIId");

                entity.Property(e => e.Uilink)
                    .IsRequired()
                    .HasColumnName("UILink")
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.Uiname)
                    .IsRequired()
                    .HasColumnName("UIName")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Uipermit).HasColumnName("UIPermit");

                entity.Property(e => e.Uistyle)
                    .IsRequired()
                    .HasColumnName("UIStyle")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Uitype)
                    .IsRequired()
                    .HasColumnName("UIType")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<XrefAppGrant>(entity =>
            {
                entity.ToTable("xref_AppGrant");

                entity.Property(e => e.Gid).HasColumnName("GId");

                entity.HasOne(d => d.G)
                    .WithMany(p => p.XrefAppGrant)
                    .HasForeignKey(d => d.Gid)
                    .HasConstraintName("FK_xref_AppGrant_lkp_Group");
            });

            modelBuilder.Entity<XrefDatasetGrant>(entity =>
            {
                entity.ToTable("xref_DatasetGrant");

                entity.Property(e => e.Dsid).HasColumnName("DSId");

                entity.Property(e => e.Gid).HasColumnName("GId");

                entity.HasOne(d => d.Ds)
                    .WithMany(p => p.XrefDatasetGrant)
                    .HasForeignKey(d => d.Dsid)
                    .HasConstraintName("FK_xref_DatasetGrant_lkp_Dataset");
            });

            modelBuilder.Entity<XrefUigrant>(entity =>
            {
                entity.ToTable("xref_UIGrant");

                entity.Property(e => e.Gid).HasColumnName("GId");

                entity.Property(e => e.Uiid).HasColumnName("UIId");

                entity.HasOne(d => d.G)
                    .WithMany(p => p.XrefUigrant)
                    .HasForeignKey(d => d.Gid)
                    .HasConstraintName("FK_xref_UIGrant_lkp_Group");

                entity.HasOne(d => d.Ui)
                    .WithMany(p => p.XrefUigrant)
                    .HasForeignKey(d => d.Uiid)
                    .HasConstraintName("FK_xref_UIGrant_lkp_ApplicationUI");
            });

            modelBuilder.Entity<XrefUserGroup>(entity =>
            {
                entity.ToTable("xref_UserGroup");

                entity.Property(e => e.Gid).HasColumnName("GId");

                entity.Property(e => e.Uid).HasColumnName("UId");

                entity.HasOne(d => d.G)
                    .WithMany(p => p.XrefUserGroup)
                    .HasForeignKey(d => d.Gid)
                    .HasConstraintName("FK_xref_UserGroup_lkp_Group");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
