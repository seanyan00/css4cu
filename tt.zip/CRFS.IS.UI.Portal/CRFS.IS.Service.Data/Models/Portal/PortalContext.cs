﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CRFS.IS.Service.Data
{
    public partial class PortalContext : DbContext
    {
        public PortalContext()
        {
        }

        public PortalContext(DbContextOptions<PortalContext> options)
            : base(options)
        {
        }

        public virtual DbSet<LkpAccessLevel> LkpAccessLevel { get; set; }
        public virtual DbSet<LkpApplicationUi> LkpApplicationUi { get; set; }
        public virtual DbSet<LkpGroup> LkpGroup { get; set; }
        public virtual DbSet<TblClientPdfcompressionBatch> TblClientPdfcompressionBatch { get; set; }
        public virtual DbSet<TblClientPdfcompressionBatchDetail> TblClientPdfcompressionBatchDetail { get; set; }
        public virtual DbSet<TblFileUpload> TblFileUpload { get; set; }
        public virtual DbSet<TblSession> TblSession { get; set; }
        public virtual DbSet<TblSessionDetail> TblSessionDetail { get; set; }
        public virtual DbSet<TblSessionMessage> TblSessionMessage { get; set; }
        public virtual DbSet<VwClientPdfcompressionSummary> VwClientPdfcompressionSummary { get; set; }
        public virtual DbSet<VwPortalUserRole> VwPortalUserRole { get; set; }
        public virtual DbSet<VwUserPermit> VwUserPermit { get; set; }
        public virtual DbSet<XrefAppGrant> XrefAppGrant { get; set; }
        public virtual DbSet<XrefUigrant> XrefUigrant { get; set; }
        public virtual DbSet<XrefUserGroup> XrefUserGroup { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=vm-sql1-dev.dev.crfs.crfservices.com\\cms_d;Initial Catalog=Portal;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<LkpAccessLevel>(entity =>
            {
                entity.HasKey(e => e.Lvl)
                    .HasName("PK__lkp_Acce__C650C1533A156642");

                entity.ToTable("lkp_AccessLevel");

                entity.Property(e => e.Lvl).ValueGeneratedNever();

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpApplicationUi>(entity =>
            {
                entity.ToTable("lkp_ApplicationUI");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.Link)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Pid).HasColumnName("PId");

                entity.Property(e => e.Style)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Uitype)
                    .IsRequired()
                    .HasColumnName("UIType")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.HasOne(d => d.P)
                    .WithMany(p => p.InverseP)
                    .HasForeignKey(d => d.Pid)
                    .HasConstraintName("FK_lkp_ApplicationUI_lkp_ApplicationUI");
            });

            modelBuilder.Entity<LkpGroup>(entity =>
            {
                entity.ToTable("lkp_Group");

                entity.Property(e => e.Description)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblClientPdfcompressionBatch>(entity =>
            {
                entity.ToTable("tbl_ClientPDFCompressionBatch");

                entity.Property(e => e.RunBy)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.RunDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<TblClientPdfcompressionBatchDetail>(entity =>
            {
                entity.HasKey(e => new { e.BatchId, e.ClientId, e.FileName, e.TimeStart });

                entity.ToTable("tbl_ClientPDFCompressionBatchDetail");

                entity.Property(e => e.FileName)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.TimeStart).HasColumnType("datetime");

                entity.Property(e => e.Reason)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TimeEnd).HasColumnType("datetime");

                entity.HasOne(d => d.Batch)
                    .WithMany(p => p.TblClientPdfcompressionBatchDetail)
                    .HasForeignKey(d => d.BatchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tbl_ClientPDFCompressionBatchDetail_tbl_ClientPDFCompressionBatch");
            });

            modelBuilder.Entity<TblFileUpload>(entity =>
            {
                entity.ToTable("tbl_FileUpload");

                entity.Property(e => e.AppName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.FileName)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.ServerPath)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.UploadDate).HasColumnType("datetime");

                entity.Property(e => e.UploadedBy)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblSession>(entity =>
            {
                entity.ToTable("tbl_Session");

                entity.Property(e => e.AppFrom)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.EndTime).HasColumnType("datetime");

                entity.Property(e => e.StartTime).HasColumnType("datetime");

                entity.Property(e => e.Token)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.Uname)
                    .IsRequired()
                    .HasColumnName("UName")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblSessionDetail>(entity =>
            {
                entity.ToTable("tbl_SessionDetail");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.SvcName)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.SvcParams)
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.HasOne(d => d.Session)
                    .WithMany(p => p.TblSessionDetail)
                    .HasForeignKey(d => d.SessionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tbl_SessionDetail_tbl_Session");
            });

            modelBuilder.Entity<TblSessionMessage>(entity =>
            {
                entity.ToTable("tbl_SessionMessage");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.Msg)
                    .IsRequired()
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.HasOne(d => d.SessionDetail)
                    .WithMany(p => p.TblSessionMessage)
                    .HasForeignKey(d => d.SessionDetailId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tbl_SessionMessage_tbl_SessionDetail");
            });

            modelBuilder.Entity<VwClientPdfcompressionSummary>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_ClientPDFCompressionSummary");

                entity.Property(e => e.ClientDisplayName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.RunBy)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.RunDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<VwPortalUserRole>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_PortalUserRole");

                entity.Property(e => e.Rid).HasColumnName("RId");

                entity.Property(e => e.RoleName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Uid).HasColumnName("UId");

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwUserPermit>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_UserPermit");

                entity.Property(e => e.AppName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Gid).HasColumnName("GId");

                entity.Property(e => e.Gname)
                    .IsRequired()
                    .HasColumnName("GName")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Login)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Pid).HasColumnName("PId");

                entity.Property(e => e.Pname)
                    .IsRequired()
                    .HasColumnName("PName")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Uid).HasColumnName("UId");

                entity.Property(e => e.Uiid).HasColumnName("UIId");

                entity.Property(e => e.Uilink)
                    .IsRequired()
                    .HasColumnName("UILink")
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.Uiname)
                    .IsRequired()
                    .HasColumnName("UIName")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Uipermit).HasColumnName("UIPermit");

                entity.Property(e => e.Uistyle)
                    .IsRequired()
                    .HasColumnName("UIStyle")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Uitype)
                    .IsRequired()
                    .HasColumnName("UIType")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<XrefAppGrant>(entity =>
            {
                entity.ToTable("xref_AppGrant");

                entity.Property(e => e.Gid).HasColumnName("GId");

                entity.HasOne(d => d.G)
                    .WithMany(p => p.XrefAppGrant)
                    .HasForeignKey(d => d.Gid)
                    .HasConstraintName("FK_xref_AppGrant_lkp_Group");
            });

            modelBuilder.Entity<XrefUigrant>(entity =>
            {
                entity.ToTable("xref_UIGrant");

                entity.Property(e => e.Gid).HasColumnName("GId");

                entity.Property(e => e.Uiid).HasColumnName("UIId");

                entity.HasOne(d => d.G)
                    .WithMany(p => p.XrefUigrant)
                    .HasForeignKey(d => d.Gid)
                    .HasConstraintName("FK_xref_UIGrant_lkp_Group");

                entity.HasOne(d => d.Ui)
                    .WithMany(p => p.XrefUigrant)
                    .HasForeignKey(d => d.Uiid)
                    .HasConstraintName("FK_xref_UIGrant_lkp_ApplicationUI");
            });

            modelBuilder.Entity<XrefUserGroup>(entity =>
            {
                entity.ToTable("xref_UserGroup");

                entity.Property(e => e.Gid).HasColumnName("GId");

                entity.Property(e => e.Uid).HasColumnName("UId");

                entity.HasOne(d => d.G)
                    .WithMany(p => p.XrefUserGroup)
                    .HasForeignKey(d => d.Gid)
                    .HasConstraintName("FK_xref_UserGroup_lkp_Group");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
