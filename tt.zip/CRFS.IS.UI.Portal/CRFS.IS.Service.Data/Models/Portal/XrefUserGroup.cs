﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefUserGroup
    {
        public int Id { get; set; }
        public int Gid { get; set; }
        public int Uid { get; set; }
        public bool Active { get; set; }

        public virtual LkpGroup G { get; set; }
    }
}
