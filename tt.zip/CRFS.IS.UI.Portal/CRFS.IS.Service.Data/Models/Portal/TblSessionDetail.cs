﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblSessionDetail
    {
        public TblSessionDetail()
        {
            TblSessionMessage = new HashSet<TblSessionMessage>();
        }

        public int Id { get; set; }
        public int SessionId { get; set; }
        public string SvcName { get; set; }
        public string SvcParams { get; set; }
        public DateTime EnteredDate { get; set; }

        public virtual TblSession Session { get; set; }
        public virtual ICollection<TblSessionMessage> TblSessionMessage { get; set; }
    }
}
