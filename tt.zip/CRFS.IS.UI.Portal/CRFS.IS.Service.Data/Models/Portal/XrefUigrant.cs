﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefUigrant
    {
        public int Id { get; set; }
        public int Uiid { get; set; }
        public int Gid { get; set; }
        public int Permit { get; set; }

        public virtual LkpGroup G { get; set; }
        public virtual LkpApplicationUi Ui { get; set; }
    }
}
