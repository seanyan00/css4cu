﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpGroup
    {
        public LkpGroup()
        {
            XrefAppGrant = new HashSet<XrefAppGrant>();
            XrefUigrant = new HashSet<XrefUigrant>();
            XrefUserGroup = new HashSet<XrefUserGroup>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public virtual ICollection<XrefAppGrant> XrefAppGrant { get; set; }
        public virtual ICollection<XrefUigrant> XrefUigrant { get; set; }
        public virtual ICollection<XrefUserGroup> XrefUserGroup { get; set; }
    }
}
