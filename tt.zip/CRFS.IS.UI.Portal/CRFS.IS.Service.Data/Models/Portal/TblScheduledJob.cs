﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblScheduledJob
    {
        public TblScheduledJob()
        {
            TblScheduledJobStatus = new HashSet<TblScheduledJobStatus>();
        }

        public int Id { get; set; }
        public string AppName { get; set; }
        public string ClassName { get; set; }
        public string Cron { get; set; }
        public string Params { get; set; }
        public bool Active { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public int? UpdatedBy { get; set; }

        public virtual ICollection<TblScheduledJobStatus> TblScheduledJobStatus { get; set; }
    }
}
