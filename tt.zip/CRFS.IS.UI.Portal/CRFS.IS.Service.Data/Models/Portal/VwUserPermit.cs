﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwUserPermit
    {
        public int Uid { get; set; }
        public string Login { get; set; }
        public int Gid { get; set; }
        public string Gname { get; set; }
        public int AppId { get; set; }
        public string AppName { get; set; }
        public int AppPermit { get; set; }
        public int Uiid { get; set; }
        public string Uitype { get; set; }
        public string Uiname { get; set; }
        public int AccessLevel { get; set; }
        public int Uipermit { get; set; }
        public string Uilink { get; set; }
        public string Uistyle { get; set; }
        public int Pid { get; set; }
        public string Pname { get; set; }
    }
}
