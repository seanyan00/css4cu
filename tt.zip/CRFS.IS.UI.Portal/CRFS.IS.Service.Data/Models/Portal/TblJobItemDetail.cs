﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblJobItemDetail
    {
        public int Id { get; set; }
        public int ScheduledJobId { get; set; }
        public string KeyName { get; set; }
        public string KeyTable { get; set; }
        public string KeyValue { get; set; }
        public string Message { get; set; }
        public DateTime EnteredDate { get; set; }
    }
}
