﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgPartAotherExtensionsReportOnetime
    {
        public string LoanNumber { get; set; }
        public string FhaCaseNumber { get; set; }
        public string DateOfHazardClaim { get; set; }
        public string DateOfLoss { get; set; }
        public string DeclarationDate { get; set; }
        public string DischargeDate { get; set; }
        public string ExtensionType { get; set; }
        public string FirstActionDate { get; set; }
        public string HazardClaimSettlementDate { get; set; }
        public string HudExtensionDate { get; set; }
        public string HudExtensionRequestDate { get; set; }
        public string HudSpecifiedExtensionDate { get; set; }
        public string SalesContractApprovalDate { get; set; }
        public string StartOfActiveDuty { get; set; }
        public string StatuteEndDate { get; set; }
        public string StatuteStartDate { get; set; }
    }
}
