﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpMileStoneType
    {
        public LkpMileStoneType()
        {
            LoanMilestone = new HashSet<LoanMilestone>();
        }

        public int MilestoneId { get; set; }
        public string MilestoneType { get; set; }
        public short MilestoneOrder { get; set; }
        public bool ActiveInd { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual ICollection<LoanMilestone> LoanMilestone { get; set; }
    }
}
