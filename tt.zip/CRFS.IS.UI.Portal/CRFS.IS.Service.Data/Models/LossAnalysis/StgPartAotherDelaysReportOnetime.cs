﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgPartAotherDelaysReportOnetime
    {
        public string LoanNumber { get; set; }
        public string FhaCaseNumber { get; set; }
        public string Acceptable { get; set; }
        public string EndDate { get; set; }
        public string Reason { get; set; }
        public string StartDate { get; set; }
        public string Type { get; set; }
    }
}
