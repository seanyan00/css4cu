﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class SupplementClaimInfo
    {
        public int LoanId { get; set; }
        public decimal? SuppRecoveryAmount { get; set; }
        public string SuppRecoveryNeeded { get; set; }
        public decimal? SuppRecOverrideAmount { get; set; }
        public string SuppRecoveryTrackInfo { get; set; }
        public DateTime? SuppRecoveryHudrecDate { get; set; }
        public decimal? SuppRecoveryHudrecAmount { get; set; }
        public decimal? SuppRefundAmount { get; set; }
        public string SuppRefundNeeded { get; set; }
        public decimal? SuppRefOverrideAmount { get; set; }
        public string SuppRefundTrackInfo { get; set; }
        public DateTime? SuppRefundHudrecDate { get; set; }
        public decimal? SuppRefundHudrecAmount { get; set; }
        public decimal? PartAsuppRecoveryAmount { get; set; }
        public decimal? PartBesuppRecoveryAmount { get; set; }
        public decimal? PartAsuppRefundAmount { get; set; }
        public decimal? PartBesuppRefundAmount { get; set; }
    }
}
