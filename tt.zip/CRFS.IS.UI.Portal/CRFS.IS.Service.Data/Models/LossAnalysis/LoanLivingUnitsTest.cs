﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LoanLivingUnitsTest
    {
        public int LoanLivUnitId { get; set; }
        public int LivingUnitPartAtypeId { get; set; }
        public int? PartAcompId { get; set; }
        public int? PartArecId { get; set; }
        public short UnitNum { get; set; }
        public DateTime? UnitSecuredDate { get; set; }
        public DateTime? UnitVacatedDate { get; set; }
        public string UnitOccupantName { get; set; }
        public int? UnitOccupancyStatus { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual LoanPartAcomp PartAcomp { get; set; }
        public virtual LoanPartArec PartArec { get; set; }
    }
}
