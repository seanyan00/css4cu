﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwRecommendedRefund
    {
        public int LoanId { get; set; }
        public string LkpTypeCatName { get; set; }
        public string LkpTypeSubCatName { get; set; }
        public DateTime? DisbursedDate { get; set; }
        public decimal? ClaimAmount { get; set; }
    }
}
