﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LoanTimeframes
    {
        public int LoanTimeframeId { get; set; }
        public int LoanId { get; set; }
        public int TimeframeType { get; set; }
        public DateTime? TimeframeActivityDate { get; set; }
        public DateTime? TimeframeCalcDeadlineDate { get; set; }
        public DateTime? TimeframeOverrideDeadlineDate { get; set; }
        public bool? TimeframeExtensionUsed { get; set; }
        public bool? TimeframeTestPass { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual Loan Loan { get; set; }
    }
}
