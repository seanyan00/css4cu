﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class RecommendedRefRecByCat
    {
        public int LoanId { get; set; }
        public decimal? RecomRefundBk { get; set; }
        public decimal? RecomRefundBpo { get; set; }
        public decimal? RecomRefundPp { get; set; }
        public decimal? RecomRefundAc { get; set; }
        public decimal? RecomRefundAf { get; set; }
        public decimal? RecomRefundIns { get; set; }
        public decimal? RecomRefundEvi { get; set; }
        public decimal? RecomRefundHoa { get; set; }
        public decimal? RecomRefundUti { get; set; }
        public decimal? RecomRefundLcv { get; set; }
        public decimal? RecomRefundMip { get; set; }
        public decimal? RecomRefundTax { get; set; }
        public decimal? RecomRefundMisc { get; set; }
        public decimal? RecomRefundInterest { get; set; }
        public decimal? RecomRecoveryBk { get; set; }
        public decimal? RecomRecoveryBpo { get; set; }
        public decimal? RecomRecoveryPp { get; set; }
        public decimal? RecomRecoveryAc { get; set; }
        public decimal? RecomRecoveryAf { get; set; }
        public decimal? RecomRecoveryIns { get; set; }
        public decimal? RecomRecoveryEvi { get; set; }
        public decimal? RecomRecoveryHoa { get; set; }
        public decimal? RecomRecoveryUti { get; set; }
        public decimal? RecomRecoveryLcv { get; set; }
        public decimal? RecomRecoveryMip { get; set; }
        public decimal? RecomRecoveryTax { get; set; }
        public decimal? RecomRecoveryMisc { get; set; }
        public decimal? RecomRecoveryInterest { get; set; }
    }
}
