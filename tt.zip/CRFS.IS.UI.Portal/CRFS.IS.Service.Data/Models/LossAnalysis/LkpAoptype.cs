﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpAoptype
    {
        public int LkpTypeCatId { get; set; }
        public string LkpTypeName { get; set; }
        public int LkpTypeId { get; set; }
        public string LkpTypeCatName { get; set; }
        public bool Active { get; set; }
        public DateTime DateAdded { get; set; }
        public int AddedBy { get; set; }
        public DateTime DateModified { get; set; }
        public int ModifiedBy { get; set; }
    }
}
