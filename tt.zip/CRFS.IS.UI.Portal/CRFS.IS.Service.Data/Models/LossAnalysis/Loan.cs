﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class Loan
    {
        public Loan()
        {
            ClientReqLoanTracking = new HashSet<ClientReqLoanTracking>();
            LoanAop = new HashSet<LoanAop>();
            LoanBankruptcy = new HashSet<LoanBankruptcy>();
            LoanDelay = new HashSet<LoanDelay>();
            LoanEviction = new HashSet<LoanEviction>();
            LoanExpense = new HashSet<LoanExpense>();
            LoanExtension = new HashSet<LoanExtension>();
            LoanForeclosure = new HashSet<LoanForeclosure>();
            LoanLossMit = new HashSet<LoanLossMit>();
            LoanMilestone = new HashSet<LoanMilestone>();
            LoanPartAcomp = new HashSet<LoanPartAcomp>();
            LoanPartArec = new HashSet<LoanPartArec>();
            LoanPartBdata = new HashSet<LoanPartBdata>();
            LoanPartBdataNote = new HashSet<LoanPartBdataNote>();
            LoanReconciliationOg = new HashSet<LoanReconciliationOg>();
            LoanSuppTracking = new HashSet<LoanSuppTracking>();
            LoanSupplemental = new HashSet<LoanSupplemental>();
            LoanTimeframes = new HashSet<LoanTimeframes>();
        }

        public int LoanId { get; set; }
        public string LoanNumber { get; set; }
        public string FhacaseNumber { get; set; }
        public int ClientId { get; set; }
        public int ClaimTypeId { get; set; }
        public int? InvestorId { get; set; }
        public string BorrowerFirstName { get; set; }
        public string BorrowerLastName { get; set; }
        public string PropertyStreetAddressLine1 { get; set; }
        public string PropertyStreetAddressLine2 { get; set; }
        public string PropertyCity { get; set; }
        public int? PropertyState { get; set; }
        public string PropertyZipCode { get; set; }
        public int? PropertyLotSize { get; set; }
        public DateTime? LossAnalysisReferralDate { get; set; }
        public DateTime? LossAnalysisDueDate { get; set; }
        public DateTime? BuyOutDate { get; set; }
        public DateTime? ServiceTransferDate { get; set; }
        public decimal? NoteRate { get; set; }
        public DateTime? CloseDate { get; set; }
        public int? ClosingReason { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual Investor Investor { get; set; }
        public virtual LkpStates PropertyStateNavigation { get; set; }
        public virtual LoanSupplementalAnalyst LoanSupplementalAnalyst { get; set; }
        public virtual ICollection<ClientReqLoanTracking> ClientReqLoanTracking { get; set; }
        public virtual ICollection<LoanAop> LoanAop { get; set; }
        public virtual ICollection<LoanBankruptcy> LoanBankruptcy { get; set; }
        public virtual ICollection<LoanDelay> LoanDelay { get; set; }
        public virtual ICollection<LoanEviction> LoanEviction { get; set; }
        public virtual ICollection<LoanExpense> LoanExpense { get; set; }
        public virtual ICollection<LoanExtension> LoanExtension { get; set; }
        public virtual ICollection<LoanForeclosure> LoanForeclosure { get; set; }
        public virtual ICollection<LoanLossMit> LoanLossMit { get; set; }
        public virtual ICollection<LoanMilestone> LoanMilestone { get; set; }
        public virtual ICollection<LoanPartAcomp> LoanPartAcomp { get; set; }
        public virtual ICollection<LoanPartArec> LoanPartArec { get; set; }
        public virtual ICollection<LoanPartBdata> LoanPartBdata { get; set; }
        public virtual ICollection<LoanPartBdataNote> LoanPartBdataNote { get; set; }
        public virtual ICollection<LoanReconciliationOg> LoanReconciliationOg { get; set; }
        public virtual ICollection<LoanSuppTracking> LoanSuppTracking { get; set; }
        public virtual ICollection<LoanSupplemental> LoanSupplemental { get; set; }
        public virtual ICollection<LoanTimeframes> LoanTimeframes { get; set; }
    }
}
