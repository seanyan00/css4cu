﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwSupplementalDetail
    {
        public int LoanId { get; set; }
        public string SuppTrackingInfo { get; set; }
        public DateTime? HudrecvdDate { get; set; }
        public decimal? HudrecvdAmt { get; set; }
        public DateTime? RecoveryFiled { get; set; }
        public DateTime? RefundFiled { get; set; }
        public decimal? RecoveryAmount { get; set; }
        public decimal? RefundAmount { get; set; }
    }
}
