﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgCompletedClaimAopreportOnetime
    {
        public string LoanNumber { get; set; }
        public string FhacaseNumber { get; set; }
        public string AoppartialClaimReceivedDate { get; set; }
        public string AoppartialDebentureInterestRate { get; set; }
        public string AoppartialDueDateofLastPaymentInstallment { get; set; }
        public string AoppartialFhasettlementAmount { get; set; }
        public string AoppartialInterestEndDate { get; set; }
        public string AoppartialInterestStartDate { get; set; }
        public string AoppartialLessOffsetAmount { get; set; }
        public string AoppartialSettlementDate { get; set; }
        public string AoppartialTotalInterestPaid { get; set; }
        public string AoppartialUnpaidPrincipalBalance { get; set; }
        public string AopfinalFullClaimReceivedDate { get; set; }
        public string AopfinalFullDebentureInterestRate { get; set; }
        public string AopfinalFullDueDateofLastPaymentInstallment { get; set; }
        public string AopfinalFullFhasettlmentAmount { get; set; }
        public string AopfinalFullInterestEndDate { get; set; }
        public string AopfinalFullInterstStartDate { get; set; }
        public string AopfinalFullLessOffsetAmount { get; set; }
        public string AopfinalFullSettlementDate { get; set; }
        public string AopfinalFullTotalInterestPaid { get; set; }
        public string AopfinalFullUnpaidPrincipalBalance { get; set; }
    }
}
