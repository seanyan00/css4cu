﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LoanDelay
    {
        public int LoanDelayId { get; set; }
        public int LoanId { get; set; }
        public int DelayType { get; set; }
        public DateTime? DelayStartDate { get; set; }
        public DateTime? DelayEndDate { get; set; }
        public string DelayReason { get; set; }
        public bool? DelayAcceptable { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual Loan Loan { get; set; }
    }
}
