﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblDataImport
    {
        public TblDataImport()
        {
            TblDataImportDetail = new HashSet<TblDataImportDetail>();
        }

        public int Id { get; set; }
        public int UploadId { get; set; }
        public int TemplateId { get; set; }
        public string Status { get; set; }
        public int? TotalRows { get; set; }

        public virtual ICollection<TblDataImportDetail> TblDataImportDetail { get; set; }
    }
}
