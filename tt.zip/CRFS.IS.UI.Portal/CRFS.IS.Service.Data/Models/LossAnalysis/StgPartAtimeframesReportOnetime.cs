﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgPartAtimeframesReportOnetime
    {
        public string LoanNumber { get; set; }
        public string FhaCaseNumber { get; set; }
        public string ClaimDueActualActivityDate { get; set; }
        public string ClaimDueExtensions { get; set; }
        public string ClaimDueTest { get; set; }
        public string ClaimDueDeadline { get; set; }
        public string ClaimDueDeadlineOverride { get; set; }
        public string ConveyanceActualActivityDate { get; set; }
        public string ConveyanceExtensions { get; set; }
        public string ConveyanceTest { get; set; }
        public string ConveyanceTestDeadline { get; set; }
        public string ConveyanceTestDeadlineOverride { get; set; }
        public string EvictionActualActivityDate { get; set; }
        public string EvictionExtensions { get; set; }
        public string EvictionTest { get; set; }
        public string EvictionTestDeadline { get; set; }
        public string EvictionTestDeadlineOverride { get; set; }
        public string ExpenseCurtailmentDate { get; set; }
        public string ExpenseCurtailmentDateOverride { get; set; }
        public string ForeclosureInstitutionActualActivityDate { get; set; }
        public string ForeclosureInstitutionTestDeadline { get; set; }
        public string ForeclosureInstitutionTestDeadlineOverride { get; set; }
        public string ForeclosureInstitutionExtensions { get; set; }
        public string ForeclosureInstitutionTest { get; set; }
        public string HasExpenseCurtailment { get; set; }
        public string HasInterestCurtailment { get; set; }
        public string ReasonableDiligenceActualActivityDate { get; set; }
        public string ReasonableDiligenceTestDeadline { get; set; }
        public string ReasonableDiligenceTestDeadlineOverride { get; set; }
        public string ReasonableDiligenceTest { get; set; }
        public string ReasonableDiligenceExtensions { get; set; }
        public string SfdmsActualActivityDate { get; set; }
        public string SfdmsExtensions { get; set; }
        public string SfdmsTest { get; set; }
        public string SfdmsTestDeadline { get; set; }
        public string SfdmsTestDeadlineOverride { get; set; }
        public string UpdatedCurtailmentDateOverride { get; set; }
        public string UpdatedCurtailmentDate { get; set; }
    }
}
