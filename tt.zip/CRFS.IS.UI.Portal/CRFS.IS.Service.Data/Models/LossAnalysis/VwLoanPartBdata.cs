﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwLoanPartBdata
    {
        public int LoanId { get; set; }
        public int PartBblockId { get; set; }
        public string PartBblockName { get; set; }
        public decimal? SubDeductionAmount { get; set; }
        public decimal? SubAdditionAmount { get; set; }
        public decimal? SubInterestAmount { get; set; }
        public decimal? AopdeductionAmount { get; set; }
        public decimal? AopadditionAmount { get; set; }
        public decimal? AopinterestAmount { get; set; }
        public string Note { get; set; }
    }
}
