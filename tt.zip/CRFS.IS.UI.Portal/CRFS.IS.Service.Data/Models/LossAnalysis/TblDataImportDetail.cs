﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblDataImportDetail
    {
        public int Id { get; set; }
        public int Diid { get; set; }
        public string Error { get; set; }

        public virtual TblDataImport Di { get; set; }
    }
}
