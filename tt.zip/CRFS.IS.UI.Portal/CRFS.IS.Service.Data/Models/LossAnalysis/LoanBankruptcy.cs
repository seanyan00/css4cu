﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LoanBankruptcy
    {
        public int LoanBkextensionId { get; set; }
        public int LoanId { get; set; }
        public int BankruptcyType { get; set; }
        public string BankruptcyCaseNumber { get; set; }
        public DateTime? FiledDate { get; set; }
        public DateTime? ClearanceDate { get; set; }
        public bool? OrderGrantingMfr { get; set; }
        public DateTime? MotionForReliefDate { get; set; }
        public bool? _4001ruleWaived { get; set; }
        public int? Ruling { get; set; }
        public DateTime? DismissalDate { get; set; }
        public DateTime? DischargeDate { get; set; }
        public DateTime? AttorneyProvidedLiftDate { get; set; }
        public bool? ClosedSameDayAsDischarge { get; set; }
        public DateTime? BankruptcyCompletionDate { get; set; }
        public int? BankruptcyCompletionDays { get; set; }
        public bool? DelaysAcceptable { get; set; }
        public DateTime? FirstActionDate { get; set; }
        public DateTime? FirstUnacceptableDelay { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual Loan Loan { get; set; }
    }
}
