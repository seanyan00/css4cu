﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class ClientReqTrackView
    {
        public int LoanId { get; set; }
        public DateTime? CloseOutStepComplete { get; set; }
        public DateTime? RcaComplete { get; set; }
        public DateTime? DeliveredDate { get; set; }
    }
}
