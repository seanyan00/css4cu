﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgCompletedClaimPartAreportOnetime
    {
        public string LoanNumber { get; set; }
        public string FhacaseNumber { get; set; }
        public string BankruptcyLifyDate { get; set; }
        public string Block9 { get; set; }
        public string BorrowerFirstName { get; set; }
        public string BorrowerLastName { get; set; }
        public string ClaimFiledDate { get; set; }
        public string CommissionersAdjustedFairMarketValue { get; set; }
        public string ConveyanceExtensionDate { get; set; }
        public string DateDeedorAssignmentFiled { get; set; }
        public string DeedInLieuDate { get; set; }
        public string DueDateLastPaymentInstallment { get; set; }
        public string EndorsementDate { get; set; }
        public string ForeclosureFirstLegalDate { get; set; }
        public string InstitutionExtensionDate { get; set; }
        public string MortgageeCurtailmentDate { get; set; }
        public string NumberLivingUnits { get; set; }
        public string OriginalPrincipalBalance { get; set; }
        public string PropertyCity { get; set; }
        public string PropertyState { get; set; }
        public string PropertyStreetAddressLine1 { get; set; }
        public string PropertyStreetAddressLine2 { get; set; }
        public string PropertyZipCode { get; set; }
        public string Unit1DateSecured { get; set; }
        public string Unit1DateVacated { get; set; }
        public string Unit1NameofOccupant { get; set; }
        public string Unit1OccupancyStatus { get; set; }
        public string Unit2DateSecured { get; set; }
        public string Unit2DateVacated { get; set; }
        public string Unit2NameofOccupant { get; set; }
        public string Unit2OccupancyStatus { get; set; }
        public string Unit3DateSecured { get; set; }
        public string Unit3DateVacated { get; set; }
        public string Unit3NameofOccupant { get; set; }
        public string Unit3OccupancyStatus { get; set; }
        public string Unit4DateSecured { get; set; }
        public string Unit4DateVacated { get; set; }
        public string Unit4NameofOccupant { get; set; }
        public string Unit4OccupancyStatus { get; set; }
        public string UnpaidPrincipalBalance { get; set; }
        public int StgRowId { get; set; }
    }
}
