﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LoanPartBdataNote
    {
        public int PartBnoteId { get; set; }
        public int LoanId { get; set; }
        public int PartBblockId { get; set; }
        public bool Passed { get; set; }
        public string Note { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual Loan Loan { get; set; }
    }
}
