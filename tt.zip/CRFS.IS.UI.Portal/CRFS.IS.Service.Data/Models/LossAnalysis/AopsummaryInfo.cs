﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class AopsummaryInfo
    {
        public int LoanId { get; set; }
        public DateTime? PartialSettlementDate { get; set; }
        public DateTime? PartialReceivedDate { get; set; }
        public decimal? PartialTotalInterestPaid { get; set; }
        public decimal? PartialSettlementAmount { get; set; }
        public DateTime? FinalSettlementDate { get; set; }
        public DateTime? FinalReceivedDate { get; set; }
        public decimal? FinalTotalInterestPaid { get; set; }
        public decimal? FinalSettlementAmount { get; set; }
        public decimal? LessOffsetAmount { get; set; }
    }
}
