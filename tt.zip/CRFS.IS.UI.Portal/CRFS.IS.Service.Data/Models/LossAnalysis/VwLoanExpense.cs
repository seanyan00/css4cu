﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwLoanExpense
    {
        public int LoanId { get; set; }
        public int LoanExpenseId { get; set; }
        public int? ParentLoanExpenseId { get; set; }
        public int ExpenseCategory { get; set; }
        public int? ExpenseSubCategory { get; set; }
        public string LkpTypeSubCatName { get; set; }
        public string ExpenseDescription { get; set; }
        public int AdvanceFrom { get; set; }
        public string InvoiceNumber { get; set; }
        public DateTime? DisbursedDate { get; set; }
        public decimal? DisbursedAmount { get; set; }
        public decimal? EstimatedRefundAmount { get; set; }
        public decimal? PreviousClaimAmount { get; set; }
        public decimal? PreviousDebentureInterest { get; set; }
        public decimal? PreviousChargeOffAmount { get; set; }
        public decimal? PreviousEstimatedRefundAmount { get; set; }
        public decimal? ClaimAmount { get; set; }
        public decimal? DebentureInterestAmount { get; set; }
        public decimal? ChargeOffAmount { get; set; }
        public int? ChargeOffReason { get; set; }
        public int? ResponsibleParty { get; set; }
        public decimal? RecoveryAmount { get; set; }
        public decimal? RefundAmount { get; set; }
        public decimal? UncontrollableLossAmount { get; set; }
    }
}
