﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class ControllableLossesByPartyByCat
    {
        public int LoanId { get; set; }
        public decimal ClientLossAmount { get; set; }
        public decimal PriorServicerLossAmount { get; set; }
        public decimal VendorLossAmount { get; set; }
        public decimal InvestorLossAmount { get; set; }
        public decimal ClientLossAmountBk { get; set; }
        public decimal ClientLossAmountBpo { get; set; }
        public decimal ClientLossAmountPp { get; set; }
        public decimal ClientLossAmountAc { get; set; }
        public decimal ClientLossAmountAf { get; set; }
        public decimal ClientLossAmountIns { get; set; }
        public decimal ClientLossAmountEvi { get; set; }
        public decimal ClientLossAmountHoa { get; set; }
        public decimal ClientLossAmountUti { get; set; }
        public decimal ClientLossAmountLcv { get; set; }
        public decimal ClientLossAmountMip { get; set; }
        public decimal ClientLossAmountTax { get; set; }
        public decimal ClientLossAmountMisc { get; set; }
        public decimal ClientLossAmountIntCurt { get; set; }
        public decimal PslossAmountBk { get; set; }
        public decimal PslossAmountBpo { get; set; }
        public decimal PslossAmountPp { get; set; }
        public decimal PslossAmountAc { get; set; }
        public decimal PslossAmountAf { get; set; }
        public decimal PslossAmountIns { get; set; }
        public decimal PslossAmountEvi { get; set; }
        public decimal PslossAmountHoa { get; set; }
        public decimal PslossAmountUti { get; set; }
        public decimal PslossAmountLcv { get; set; }
        public decimal PslossAmountMip { get; set; }
        public decimal PslossAmountTax { get; set; }
        public decimal PslossAmountMisc { get; set; }
        public decimal PslossAmountIntCurt { get; set; }
        public decimal VenLossAmountBk { get; set; }
        public decimal VenLossAmountBpo { get; set; }
        public decimal VenLossAmountPp { get; set; }
        public decimal VenLossAmountAc { get; set; }
        public decimal VenLossAmountAf { get; set; }
        public decimal VenLossAmountIns { get; set; }
        public decimal VenLossAmountEvi { get; set; }
        public decimal VenLossAmountHoa { get; set; }
        public decimal VenLossAmountUti { get; set; }
        public decimal VenLossAmountLcv { get; set; }
        public decimal VenLossAmountMip { get; set; }
        public decimal VenLossAmountTax { get; set; }
        public decimal VenLossAmountMisc { get; set; }
        public decimal VenLossAmountIntCurt { get; set; }
        public decimal InvLossAmountBk { get; set; }
        public decimal InvLossAmountBpo { get; set; }
        public decimal InvLossAmountPp { get; set; }
        public decimal InvLossAmountAc { get; set; }
        public decimal InvLossAmountAf { get; set; }
        public decimal InvLossAmountIns { get; set; }
        public decimal InvLossAmountEvi { get; set; }
        public decimal InvLossAmountHoa { get; set; }
        public decimal InvLossAmountUti { get; set; }
        public decimal InvLossAmountLcv { get; set; }
        public decimal InvLossAmountMip { get; set; }
        public decimal InvLossAmountTax { get; set; }
        public decimal InvLossAmountMisc { get; set; }
        public decimal InvLossAmountIntCurt { get; set; }
    }
}
