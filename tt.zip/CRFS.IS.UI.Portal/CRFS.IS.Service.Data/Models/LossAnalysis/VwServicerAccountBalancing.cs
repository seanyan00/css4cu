﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwServicerAccountBalancing
    {
        public int LoanId { get; set; }
        public decimal? EscrowDifference { get; set; }
        public decimal? CorporateDifference { get; set; }
        public decimal? SuspenseDifference { get; set; }
        public decimal? RestricktedEscrowDifference { get; set; }
        public decimal? Hud1difference { get; set; }
    }
}
