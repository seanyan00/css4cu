﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class MilestoneDates
    {
        public int LoanId { get; set; }
        public DateTime? ReferralLoad { get; set; }
        public DateTime? PartAAssignment { get; set; }
        public DateTime? PartAStartDate { get; set; }
        public DateTime? PartACompleteDate { get; set; }
        public DateTime? PartAQcAssignment { get; set; }
        public DateTime? PartAQcStartDate { get; set; }
        public DateTime? PartAQcComplete { get; set; }
        public DateTime? PartBAssignment { get; set; }
        public DateTime? PartBStartDate { get; set; }
        public DateTime? PartBCompleteDate { get; set; }
        public DateTime? PartBQcAssignment { get; set; }
        public DateTime? PartBQcStartDate { get; set; }
        public DateTime? PartBQcComplete { get; set; }
        public DateTime? ReportGenerated { get; set; }
        public DateTime? ReportDelivered { get; set; }
        public DateTime? SuppRefClaimReq { get; set; }
        public DateTime? SuppRefAnalystAssigned { get; set; }
        public DateTime? SuppRefStartDate { get; set; }
        public DateTime? SuppRefCompleteDate { get; set; }
        public DateTime? SuppRecClaimReq { get; set; }
        public DateTime? SuppRecAnalystAssigned { get; set; }
        public DateTime? SuppRecStartDate { get; set; }
        public DateTime? SuppRecCompleteDate { get; set; }
        public DateTime? ReadyToBill { get; set; }
    }
}
