﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgExpenseCatSubCatLookup
    {
        public int LookupId { get; set; }
        public int ClientId { get; set; }
        public string ExpenseCategory { get; set; }
        public string ExpenseSubCategory { get; set; }
        public int CrfsSubCategoryId { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual LkpTypeSubCat CrfsSubCategory { get; set; }
    }
}
