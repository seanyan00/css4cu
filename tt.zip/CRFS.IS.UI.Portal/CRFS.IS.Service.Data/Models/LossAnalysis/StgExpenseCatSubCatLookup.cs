﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgExpenseCatSubCatLookup
    {
        public int LookupId { get; set; }
        public int ClientId { get; set; }
        public string ExpenseCategory { get; set; }
        public string ExpenseSubCategory { get; set; }
        public int CrfsSubCategoryId { get; set; }

        public virtual LkpTypeSubCat CrfsSubCategory { get; set; }
    }
}
