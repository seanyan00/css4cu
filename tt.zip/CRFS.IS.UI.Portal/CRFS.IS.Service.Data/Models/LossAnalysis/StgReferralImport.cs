﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgReferralImport
    {
        public int ReferralRowId { get; set; }
        public int? ReferralBatchId { get; set; }
        public string LoanNumber { get; set; }
        public string FhacaseNumber { get; set; }
        public string ClaimType { get; set; }
        public string ClaimSettlementDate { get; set; }
        public string DueDate { get; set; }
        public string NoteRate { get; set; }
        public string PassThroughRate { get; set; }
        public string DebentureInterestRate { get; set; }
        public string Investor { get; set; }
        public string Attorney { get; set; }
        public string PropertyPreservationCompany { get; set; }
        public string PriorServicer { get; set; }
        public string MortgagorFirstName { get; set; }
        public string MortgagorLastName { get; set; }
        public string PropertyAddress { get; set; }
        public string PropertyCity { get; set; }
        public string PropertyState { get; set; }
        public string PropertyZip { get; set; }
        public string EndorsementDate { get; set; }
        public string LastPaidInstallmentDate { get; set; }
        public string OriginalDefaultDate { get; set; }
        public string FirstTimeVacantDate { get; set; }
        public string ForeclosureFirstLegalFiledDate { get; set; }
        public string ForeclosureSaleDate { get; set; }
        public string _2ndChanceSaleDate { get; set; }
        public string RedemptionDate { get; set; }
        public string CheckWireDate { get; set; }
        public string DateofApprovaltoParticipate { get; set; }
        public string PfssettlementDate { get; set; }
        public string DilrecordedDate { get; set; }
        public string RrcexpirationDate { get; set; }
        public string ForeclosureDeedRecordedDate { get; set; }
        public string HuddeedFilingDate { get; set; }
        public string HudassignmentDate { get; set; }
        public string PartAclaimFiledDate { get; set; }
        public string Cafmvamount { get; set; }
        public string OriginalPrincipalBalance { get; set; }
        public string UnpaidPrincipalBalance { get; set; }
        public string MarketableTitleDate { get; set; }
        public string DateDeed { get; set; }
        public string InstitutionExtensionDate { get; set; }
        public string ConveyanceExtensionDate { get; set; }
        public string BankruptcyLiftDate { get; set; }
        public string MortgageeCurtailmentDate { get; set; }
        public string NumberOfLivingUnits { get; set; }
        public string Client { get; set; }

        public virtual ReferralImportBatches ReferralBatch { get; set; }
    }
}
