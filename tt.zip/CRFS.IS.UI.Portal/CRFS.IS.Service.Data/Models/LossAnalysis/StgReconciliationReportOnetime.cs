﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgReconciliationReportOnetime
    {
        public string LoanNumber { get; set; }
        public string FhaCaseNumber { get; set; }
        public string ClaimFiledExpense { get; set; }
        public string ClaimFiledInterest { get; set; }
        public string ClaimFiledInterestDate { get; set; }
        public string ClaimFiledUnpaidPrincipalBalance { get; set; }
        public string InterestCurtailmentAmount { get; set; }
        public string InterestResponsibleParty { get; set; }
        public string SettledExpense { get; set; }
        public string SettledInterest { get; set; }
        public string SettledInterestDate { get; set; }
        public string SettledUnpaidPrincipalBalance { get; set; }
        public string UpdatedCurtailmentDate { get; set; }
        public string UpdatedExpenseAmount { get; set; }
        public string UpdatedInterestAmount { get; set; }
        public string UpdatedUnpaidPrincipalBalance { get; set; }
        public string _2MonthsInterest { get; set; }
        public string AttorneyCosts { get; set; }
        public string AttorneyFees { get; set; }
        public string BalancingDifference { get; set; }
        public string BankruptcyFees { get; set; }
        public string ControllableExpenseLosses { get; set; }
        public string ControllableInterestLosses { get; set; }
        public string CorporateBalance { get; set; }
        public string CreditsAfterClaim { get; set; }
        public string EscrowBalance { get; set; }
        public string FinalFullProceeds { get; set; }
        public string FundsAppliedToEscrowCorporate { get; set; }
        public string Hud1 { get; set; }
        public string Interest { get; set; }
        public string InterestDifferential { get; set; }
        public string LiquidationProceeds { get; set; }
        public string PaidAfterClaim { get; set; }
        public string PartialProceeds { get; set; }
        public string RestrictedEscrowBalance { get; set; }
        public string SuspenseEscrowBalance { get; set; }
        public string TotalControllableLosses { get; set; }
        public string TotalDebt { get; set; }
        public string TotalLosses { get; set; }
        public string TotalProceeds { get; set; }
        public string TotalUncrontrollableLosses { get; set; }
        public string Upb { get; set; }
        public string WriteOffTotal { get; set; }
        public string CorporateDifference { get; set; }
        public string EscrowDifference { get; set; }
        public string Hud1Difference { get; set; }
        public string RestrictedEscrowDifference { get; set; }
        public string SuspenseDifference { get; set; }
        public string ARecoveryAmount { get; set; }
        public string ARecoveryAmountOverride { get; set; }
        public string ARefundAmount { get; set; }
        public string ARefundAmountOverride { get; set; }
        public string BERecoveryAmount { get; set; }
        public string BERecoveryAmountOverride { get; set; }
        public string BERefundAmount { get; set; }
        public string BERefundAmountOverride { get; set; }
        public string RecoveryYesNo { get; set; }
        public string RefundYesNo { get; set; }
    }
}
