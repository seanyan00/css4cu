﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblConLoan
    {
        public TblConLoan()
        {
            TblConExpense = new HashSet<TblConExpense>();
            TblConReconSummary = new HashSet<TblConReconSummary>();
            TblConReconSupplemental = new HashSet<TblConReconSupplemental>();
        }

        public int Id { get; set; }
        public int InvTrkLoanId { get; set; }
        public string LoanNumber { get; set; }
        public int ClientId { get; set; }
        public string InvestorName { get; set; }
        public int? MicompanyId { get; set; }
        public string BorrowerFirstName { get; set; }
        public string BorrowerLastName { get; set; }
        public int ClaimType { get; set; }
        public DateTime? ClosingDate { get; set; }
        public DateTime? ThirdPartFundReceived { get; set; }
        public DateTime? Reodisposition { get; set; }
        public string PriorServicer { get; set; }
        public DateTime? InitialClaimDate { get; set; }
        public DateTime? InitialClaimPaymentReceived { get; set; }
        public string ClaimFiledBy { get; set; }
        public DateTime? FinalClaimDate { get; set; }
        public DateTime? FinalClaimPaymentReceived { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? AddedDate { get; set; }
        public string SaleType { get; set; }
        public bool? Lacompleted { get; set; }
        public DateTime? LacompletedDate { get; set; }
        public int? LacompletedBy { get; set; }
        public int? AssignedAnalyst { get; set; }
        public int? InvTrkClaimId { get; set; }

        public virtual ICollection<TblConExpense> TblConExpense { get; set; }
        public virtual ICollection<TblConReconSummary> TblConReconSummary { get; set; }
        public virtual ICollection<TblConReconSupplemental> TblConReconSupplemental { get; set; }
    }
}
