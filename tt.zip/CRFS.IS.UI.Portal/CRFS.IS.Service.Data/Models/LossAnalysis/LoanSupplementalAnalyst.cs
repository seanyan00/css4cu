﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LoanSupplementalAnalyst
    {
        public int LoanId { get; set; }
        public int? RecoveryAnalystId { get; set; }
        public int? RefundAnalystId { get; set; }

        public virtual Loan Loan { get; set; }
    }
}
