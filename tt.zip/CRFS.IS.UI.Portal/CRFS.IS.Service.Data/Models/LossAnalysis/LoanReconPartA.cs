﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LoanReconPartA
    {
        public int LoanReconPartAid { get; set; }
        public int LoanId { get; set; }
        public decimal? InterestCurtAmount { get; set; }
        public DateTime? UpdatedInterestCurtDate { get; set; }
        public decimal? UpdateInterestAmount { get; set; }
        public int? InterestCurtRespParty { get; set; }
        public DateTime? ExpenseCurtDate { get; set; }
        public DateTime? InterestCurtOverrideDate { get; set; }
        public DateTime? ExpenseCurtOverrideDate { get; set; }
        public string LoanComment { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }
}
