﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgExpenseImport
    {
        public int ExpenseRowId { get; set; }
        public int? BatchId { get; set; }
        public string LoanNumber { get; set; }
        public string FhacaseNumber { get; set; }
        public string ExpenseCategory { get; set; }
        public string PaidDate { get; set; }
        public string AmountDispersed { get; set; }
        public string AmountClaimed { get; set; }
        public string ItemDescription { get; set; }
        public string AdvanceFrom { get; set; }
        public string DateWorkCompleted { get; set; }
        public string Quantity { get; set; }
        public string InvoiceNumber { get; set; }
        public string CoverageStartDate { get; set; }
        public string CoverageEndDate { get; set; }
        public string ChargeOffReason { get; set; }
        public string ClaimAmountOverride { get; set; }
        public string ResponsibleParty { get; set; }
        public string Client { get; set; }
        public string Details { get; set; }

        public virtual ExpenseImportBatches Batch { get; set; }
    }
}
