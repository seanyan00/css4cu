﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LoanLossMit
    {
        public int LoanLmextensionId { get; set; }
        public int LoanId { get; set; }
        public int LossMitigationType { get; set; }
        public bool? Sfdmsreported { get; set; }
        public DateTime? SfdmsreportDate { get; set; }
        public bool? DocumentsAvailable { get; set; }
        public DateTime? DocumentSignDate { get; set; }
        public DateTime? DecisionDate { get; set; }
        public bool? PlanComplete { get; set; }
        public DateTime? BorrowerVacatedDate { get; set; }
        public DateTime? LastPlanPaymentDueDate { get; set; }
        public DateTime? NextPlanPaymentDueDate { get; set; }
        public DateTime? FirstMissedPaymentDueDate { get; set; }
        public DateTime? FirstPlanPaymentDueDate { get; set; }
        public DateTime? OptOutDate { get; set; }
        public bool? PlanIncludesSfbexpiration { get; set; }
        public int? PlanPaymentsSuspendedReduced { get; set; }
        public DateTime? SfbexpirationDate { get; set; }
        public DateTime? LastPlanPaymentAppliedDate { get; set; }
        public DateTime? ApprovalToParticipateDate { get; set; }
        public DateTime? ApprovalToParticipateExpirationDate { get; set; }
        public DateTime? ApprovedContractDate { get; set; }
        public bool? ApprovedVariance { get; set; }
        public DateTime? VarianceRequestDate { get; set; }
        public DateTime? VarianceExtensionDate { get; set; }
        public DateTime? FirstActionDate { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual Loan Loan { get; set; }
    }
}
