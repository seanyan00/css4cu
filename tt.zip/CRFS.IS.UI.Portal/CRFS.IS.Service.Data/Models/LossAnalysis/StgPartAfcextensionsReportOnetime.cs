﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgPartAfcextensionsReportOnetime
    {
        public string LoanNumber { get; set; }
        public string FhaCaseNumber { get; set; }
        public string Comments { get; set; }
        public string FirstLegalDate { get; set; }
        public string RestartReason { get; set; }
        public string RestartValidity { get; set; }
        public string SfdmsCode68Date { get; set; }
        public string Type { get; set; }
    }
}
