﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgAopimport
    {
        public int AoprowId { get; set; }
        public int? BatchId { get; set; }
        public string LoanNumber { get; set; }
        public string FhacaseNumber { get; set; }
        public string PaymentAdviceType { get; set; }
        public string SettlementDate { get; set; }
        public string ClaimReceivedDate { get; set; }
        public string LastPaymentInstallmentDueDate { get; set; }
        public string UnpaidPrincipalBalance { get; set; }
        public string InterestStartDate { get; set; }
        public string InterestEndDate { get; set; }
        public string DebentureInterestRate { get; set; }
        public string InterestOnUpbamount { get; set; }
        public string FhasettlementAmount { get; set; }
        public string LessOffsetAmount { get; set; }
        public string Line107A { get; set; }
        public string Line108A { get; set; }
        public string Line109A { get; set; }
        public string Line115A { get; set; }
        public string Line118A { get; set; }
        public string Line119A { get; set; }
        public string Line123A { get; set; }
        public string Line124A { get; set; }
        public string Line127A { get; set; }
        public string Line130A { get; set; }
        public string Line131A { get; set; }
        public string Line107B { get; set; }
        public string Line110B { get; set; }
        public string Line111B { get; set; }
        public string Line112B { get; set; }
        public string Line113B { get; set; }
        public string Line114B { get; set; }
        public string Line116B { get; set; }
        public string Line117B { get; set; }
        public string Line119B { get; set; }
        public string Line120B { get; set; }
        public string Line122B { get; set; }
        public string Line123B { get; set; }
        public string Line124B { get; set; }
        public string Line125B { get; set; }
        public string Line128B { get; set; }
        public string Line129B { get; set; }
        public string Line130B { get; set; }
        public string Line131B { get; set; }
        public string Line110C { get; set; }
        public string Line111C { get; set; }
        public string Line112C { get; set; }
        public string Line113C { get; set; }
        public string Line114C { get; set; }
        public string Line117C { get; set; }
        public string Line120C { get; set; }
        public string Line121C { get; set; }
        public string Line122C { get; set; }
        public string Line123C { get; set; }
        public string Line124C { get; set; }
        public string Line125C { get; set; }
        public string Line126C { get; set; }
        public string Line130C { get; set; }
        public string Line131C { get; set; }
        public string Client { get; set; }

        public virtual AopimportBatches Batch { get; set; }
    }
}
