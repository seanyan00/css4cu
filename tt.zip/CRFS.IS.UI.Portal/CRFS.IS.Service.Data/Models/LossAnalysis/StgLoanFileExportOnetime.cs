﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgLoanFileExportOnetime
    {
        public string LoanNumber { get; set; }
        public string FhaCaseNumber { get; set; }
        public string ClaimType { get; set; }
        public string BuyoutDate { get; set; }
        public string MortgagorLastName { get; set; }
        public string InvestorName { get; set; }
        public string PropertyState { get; set; }
        public string UnpaidBalance { get; set; }
        public string OriginalDefaultDate { get; set; }
        public string DefaultDate { get; set; }
        public string NoteRate { get; set; }
        public string DebentureRate { get; set; }
        public string ForeclosureDeedRecordingDate { get; set; }
        public string DueDateOfLastPaymentInstallment { get; set; }
        public string DeedInLieuDate { get; set; }
        public string RecentVacancyDate { get; set; }
        public string FirstTimeVacancyDate { get; set; }
        public string ForeclosureSaleDate { get; set; }
        public string RrcDate { get; set; }
        public string HudAssignmentDate { get; set; }
        public string MarketableTitleDate { get; set; }
        public string PfsSettlementDate { get; set; }
        public string ForeclosureFirstLegalDate { get; set; }
        public string EvictionFirstLegalDate { get; set; }
        public string ForeclosureInstitutionTest { get; set; }
        public string ForeclosureInstitutionExtension { get; set; }
        public string ReasonableDiligenceTest { get; set; }
        public string ReasonableDiligenceExtension { get; set; }
        public string ConveyanceTest { get; set; }
        public string ConveyanceExtension { get; set; }
        public string EvictionTest { get; set; }
        public string EvictionExtension { get; set; }
        public string SfdmsTest { get; set; }
        public string SfdmsExtension { get; set; }
        public string ClaimDueTest { get; set; }
        public string ClaimDueExtension { get; set; }
        public string InterestCurtailmentDate { get; set; }
        public string ExpenseCurtailmentDate { get; set; }
        public string _2MonthsInterestAmount { get; set; }
        public string InterestDifferentialAmount { get; set; }
        public string AttorneyFees { get; set; }
        public string AttorneyCosts { get; set; }
        public string BankruptcyFeeCosts { get; set; }
        public string TotalUncontrollable { get; set; }
        public string InterestCurtailmentAmount { get; set; }
        public string AttorneyCostsCl { get; set; }
        public string AttorneyFeesCl { get; set; }
        public string BankruptcyFeesCostsCl { get; set; }
        public string BpoAppraisalCl { get; set; }
        public string EvictionFeesCostsCl { get; set; }
        public string HomeownersAssociationCl { get; set; }
        public string InsuranceCl { get; set; }
        public string LiensCodeViolationsCl { get; set; }
        public string MortgageInsurancePremiumsCl { get; set; }
        public string PropertyPreservationCl { get; set; }
        public string TaxesCl { get; set; }
        public string UtilitiesCl { get; set; }
        public string MiscCl { get; set; }
        public string TotalControllable { get; set; }
        public string RefundAmount { get; set; }
        public string RecoveryAmount { get; set; }
        public string PropertyPreservation { get; set; }
        public string Attorney { get; set; }
        public string PriorServicer { get; set; }
        public string HudOffset { get; set; }
        public string OtherAccountingItems { get; set; }
        public string OtherAccountingItemsDescription { get; set; }
    }
}
