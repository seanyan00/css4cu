﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblConReconSupplemental
    {
        public int Id { get; set; }
        public int LoanId { get; set; }
        public bool? IsSupplemental { get; set; }
        public DateTime? FiledDate { get; set; }
        public decimal? Amount { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public int? UpdatedBy { get; set; }

        public virtual TblConLoan Loan { get; set; }
    }
}
