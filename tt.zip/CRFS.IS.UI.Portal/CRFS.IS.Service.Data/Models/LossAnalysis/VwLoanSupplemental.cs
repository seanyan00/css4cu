﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwLoanSupplemental
    {
        public int LoanId { get; set; }
        public decimal? PartArecoveryAmount { get; set; }
        public decimal? PartArecoveryOverrideAmount { get; set; }
        public decimal? PartBrecoveryAmount { get; set; }
        public decimal? PartBrecoveryOverrideAmount { get; set; }
        public decimal? PartArefundAmount { get; set; }
        public decimal? PartArefundOverrideAmount { get; set; }
        public decimal? PartBrefundAmount { get; set; }
        public decimal? PartBrefundOverrideAmount { get; set; }
        public int? RecoveryAnalystId { get; set; }
        public int? RefundAnalystId { get; set; }
    }
}
