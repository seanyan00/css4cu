﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TimeframeTestandExt
    {
        public int LoanId { get; set; }
        public byte? ConveyanceTest { get; set; }
        public byte? ClaimDueTest { get; set; }
        public byte? EvictionTest { get; set; }
        public byte? ReasonableDiligenceTest { get; set; }
        public byte? Sfdmstest { get; set; }
        public byte? InstitutionTest { get; set; }
        public byte? ConveyanceExtension { get; set; }
        public byte? ClaimDueExtension { get; set; }
        public byte? EvictionExtension { get; set; }
        public byte? ReasonableDiligenceExtension { get; set; }
        public byte? Sfdmsextension { get; set; }
        public byte? InstitutionExtension { get; set; }
    }
}
