﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LoanReconPartB
    {
        public int LoanReconPartBid { get; set; }
        public int LoanId { get; set; }
        public decimal? ReconEscrowBalance { get; set; }
        public decimal? ReconCorporateBalance { get; set; }
        public decimal? ReconLiquidationProceeds { get; set; }
        public decimal? ReconInterestDifferentialUl { get; set; }
        public decimal? ReconSuspenseBalance { get; set; }
        public decimal? ReconRestrictedBalance { get; set; }
        public decimal? CurrentSystemBalance { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }
}
