﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwLoanReconPartA
    {
        public int LoanId { get; set; }
        public int? LoanReconPartAid { get; set; }
        public decimal? UnpaidPrincipalBalance { get; set; }
        public decimal? InterestCurtAmount { get; set; }
        public decimal? UpdatedUpb { get; set; }
        public DateTime? UpdatedInterestCurtDate { get; set; }
        public decimal? UpdateInterestAmount { get; set; }
        public decimal? SettledUpb { get; set; }
        public DateTime? SettledInterestCurtDate { get; set; }
        public decimal? SettledInterestAmount { get; set; }
        public string LoanComment { get; set; }
        public DateTime? ExpenseCurtDate { get; set; }
        public int? InterestCurtRespParty { get; set; }
        public decimal? UpdateExpenseAmount { get; set; }
        public decimal? FiledExpenseAmount { get; set; }
        public decimal? SettledExpenseAmount { get; set; }
    }
}
