﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgPartAdataInputReportOnetime
    {
        public string LoanNumber { get; set; }
        public string FhaCaseNumber { get; set; }
        public string BankruptcyLiftDateBlock21 { get; set; }
        public string Block108 { get; set; }
        public string BorrowerFirstName { get; set; }
        public string BorrowerLastName { get; set; }
        public string CommissionersAdjustedFairMarketValueBlock30 { get; set; }
        public string DeedInLieuDateBlock11b { get; set; }
        public string DueDateOfLastPaymentInstallmentBlock8 { get; set; }
        public string EndorsementDateBlock5 { get; set; }
        public string ForeclosureDeedRecordingDate { get; set; }
        public string LastLoanModificationDate { get; set; }
        public string NumberOfLivingUnits { get; set; }
        public string OwnerSAssociation { get; set; }
        public string PropertyCity { get; set; }
        public string PropertyState { get; set; }
        public string PropertyStreetAddressLine1 { get; set; }
        public string PropertyStreetAddressLine2 { get; set; }
        public string PropertyZipCode { get; set; }
        public string Unit1DateSecured { get; set; }
        public string Unit1DateVacated { get; set; }
        public string Unit1NameOfOccupant { get; set; }
        public string Unit1OccupancyStatus { get; set; }
        public string Unit2DateSecured { get; set; }
        public string Unit2DateVacated { get; set; }
        public string Unit2NameOfOccupant { get; set; }
        public string Unit2OccupancyStatus { get; set; }
        public string Unit3DateSecured { get; set; }
        public string Unit3DateVacated { get; set; }
        public string Unit3NameOfOccupant { get; set; }
        public string Unit3OccupancyStatus { get; set; }
        public string Unit4DateSecured { get; set; }
        public string Unit4DateVacated { get; set; }
        public string Unit4NameOfOccupant { get; set; }
        public string Unit4OccupancyStatus { get; set; }
        public string UnpaidPrincipalBalanceBlock17 { get; set; }
        public string _2ndChanceSaleDate { get; set; }
        public string ApprovalToParticipateDate { get; set; }
        public string Block9 { get; set; }
        public string BorrowerPaymentsMade { get; set; }
        public string CheckOrWireDate { get; set; }
        public string ClientSpecifiedBlock9Date { get; set; }
        public string DateOfInspectionPriorToFirstTimeVacancy { get; set; }
        public string DeedInLieuTransferDate { get; set; }
        public string DefaultDate { get; set; }
        public string DueDate { get; set; }
        public string FirstInspectionDate { get; set; }
        public string FirstInspectionStatus { get; set; }
        public string FirstSfdmsCode1aDate { get; set; }
        public string FirstTimeVacancyDate { get; set; }
        public string ForeclosureSaleDate { get; set; }
        public string HudAssignmentDate { get; set; }
        public string HudDeedFilingDate { get; set; }
        public string LastOnTimePaymentDate { get; set; }
        public string MarketableTitleDate { get; set; }
        public string OriginalDefaultDate { get; set; }
        public string PfsSettlementDate { get; set; }
        public string PropertyReoSold { get; set; }
        public string RecentVacancyDate { get; set; }
        public string RedemptionDate { get; set; }
        public string RrcDate { get; set; }
        public string SfdmsReportingMissedCycles { get; set; }
        public string SufficientPaymentHistory { get; set; }
    }
}
