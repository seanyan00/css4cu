﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LoanAop
    {
        public int Aopid { get; set; }
        public int LoanId { get; set; }
        public int Aoptype { get; set; }
        public DateTime? ReceivedDate { get; set; }
        public DateTime? SettlementDate { get; set; }
        public DateTime? InterestStartDate { get; set; }
        public DateTime? InterestEndDate { get; set; }
        public decimal? FhasettlementAmount { get; set; }
        public decimal? LessOffsetAmount { get; set; }
        public decimal? TotalInterestPaid { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual Loan Loan { get; set; }
    }
}
