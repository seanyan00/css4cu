﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LoanSuppTracking
    {
        public int LoanSuppTrackId { get; set; }
        public int LoanId { get; set; }
        public int SupplementalType { get; set; }
        public string SuppTrackingInfo { get; set; }
        public DateTime? HudrecvdDate { get; set; }
        public decimal? HudrecvdAmt { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual Loan Loan { get; set; }
    }
}
