﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class InvestorMapping
    {
        public int InvestorMapId { get; set; }
        public string InvestorName { get; set; }
        public int InvestorId { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual Investor Investor { get; set; }
    }
}
