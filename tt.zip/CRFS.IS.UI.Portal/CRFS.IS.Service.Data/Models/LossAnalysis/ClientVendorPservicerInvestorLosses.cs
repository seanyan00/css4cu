﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class ClientVendorPservicerInvestorLosses
    {
        public int LoanId { get; set; }
        public decimal ClientLossAmount { get; set; }
        public decimal PriorServicerLossAmount { get; set; }
        public decimal VendorLossAmount { get; set; }
        public decimal InvestorLossAmount { get; set; }
    }
}
