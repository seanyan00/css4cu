﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class EvictionInfoLatest
    {
        public int LoanId { get; set; }
        public int? MaxLoanEvictionId { get; set; }
        public int? VacancyType { get; set; }
        public DateTime? VacancyDate { get; set; }
        public DateTime? EvictionFirstLegalDate { get; set; }
        public DateTime? CloseAndBillDate { get; set; }
        public DateTime? ReoccupancyDate { get; set; }
        public DateTime? UnacceptableDelayStartDate { get; set; }
    }
}
