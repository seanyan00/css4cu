﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LoanReconciliation
    {
        public int LoanId { get; set; }
        public decimal? FiledUpb { get; set; }
        public decimal? SettledInterestAmount { get; set; }
        public DateTime? SettledInterestCurtDate { get; set; }
        public decimal? SettledUpb { get; set; }
        public decimal? UpdateInterestAmount { get; set; }
        public DateTime? UpdateInterestCurtDate { get; set; }
        public decimal? UpdateUpb { get; set; }
        public decimal? FiledExpenseAmount { get; set; }
        public decimal? SettledExpenseAmount { get; set; }
        public decimal? UpdateExpenseAmount { get; set; }
        public int? InterestCurtRespParty { get; set; }
        public decimal? InterestCurtAmount { get; set; }
        public DateTime? ExpenseCurtDate { get; set; }
        public decimal? ReconUpb { get; set; }
        public decimal? ReconInterest { get; set; }
        public decimal? ReconEscrowBalance { get; set; }
        public decimal? ReconCorporateBalance { get; set; }
        public decimal? ReconSuspenseBalance { get; set; }
        public decimal? ReconRestrictedBalance { get; set; }
        public decimal? ReconAppliedFunds { get; set; }
        public decimal? ReconPaidAfterClaim { get; set; }
        public decimal? ReconCreditAfterClaim { get; set; }
        public decimal? ReconPartialProceeds { get; set; }
        public decimal? ReconFinalProceeds { get; set; }
        public decimal? ReconLiquidationProceeds { get; set; }
        public decimal? ReconTwoMonthsInterestUl { get; set; }
        public decimal? ReconInterestDifferentialUl { get; set; }
        public decimal? ReconAttorneyCostsUl { get; set; }
        public decimal? ReconAttorneyFeesUl { get; set; }
        public decimal? ReconBankruptcyFeesUl { get; set; }
        public decimal? ReconControllableInterest { get; set; }
        public decimal? ReconControllableExpense { get; set; }
        public DateTime? InterestCurtOverrideDate { get; set; }
        public DateTime? ExpenseCurtOverrideDate { get; set; }
        public decimal? CurrentSystemBalance { get; set; }
        public string LoanComment { get; set; }
        public decimal? TotalInterest { get; set; }
        public decimal PostClaimAmount { get; set; }
        public decimal? TotalDebt { get; set; }
        public decimal? TotalReceipts { get; set; }
        public decimal? TotalLossesByAccount { get; set; }
        public decimal? TotalLossesByCategory { get; set; }
        public decimal? TotalUncontrollableInterestLosses { get; set; }
        public decimal? TotalUncontrollableExpenseLosses { get; set; }
        public decimal? TotalRecovery { get; set; }
        public decimal? TotalRefund { get; set; }
        public decimal? TotalControllableExpenseLosses { get; set; }
        public decimal TotalControllableInterestLosses { get; set; }
    }
}
