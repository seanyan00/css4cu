﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgDueReportOnetime
    {
        public string ClientName { get; set; }
        public string LoanNumber { get; set; }
        public string CaseNumber { get; set; }
        public string ClaimType { get; set; }
        public string BorrowerName { get; set; }
        public string ReferralDate { get; set; }
        public string SettlementDate { get; set; }
        public string DueDate { get; set; }
        public string SupplementalDueDate { get; set; }
        public string PartAProcessor { get; set; }
        public string Ecd { get; set; }
        public string PartAStartDate { get; set; }
        public string MissingDoc { get; set; }
        public string PartACompleteDate { get; set; }
        public string PartBProcessor { get; set; }
        public string PartBStartDate { get; set; }
        public string MissingDoc2 { get; set; }
        public string PartBCompleteDate { get; set; }
        public string SupplementalRecoveryNeeded { get; set; }
        public string SuppAnalyst { get; set; }
        public string SupplementalRecoveryClaimFiled { get; set; }
        public string SupplementalRecoveryAmount { get; set; }
        public string SupplementalRefundNeeded { get; set; }
        public string SuppAnalyst2 { get; set; }
        public string SupplementalRefundClaimFiled { get; set; }
        public string SupplementalRefundAmount { get; set; }
        public string SupplementalTracking { get; set; }
        public string HudRecvdSupplementalDate { get; set; }
        public string HudRecvdAmount { get; set; }
        public string CloseOutStepComplete { get; set; }
        public string RcaComplete { get; set; }
        public string Delivered { get; set; }
    }
}
