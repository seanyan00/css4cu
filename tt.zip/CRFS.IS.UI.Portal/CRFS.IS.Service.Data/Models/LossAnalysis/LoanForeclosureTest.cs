﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LoanForeclosureTest
    {
        public int LoanForeclosureId { get; set; }
        public int LoanId { get; set; }
        public int? Type { get; set; }
        public DateTime? FirstLegalDate { get; set; }
        public DateTime? Sfdmscode68Date { get; set; }
        public int? RestartReason { get; set; }
        public bool? RestartValid { get; set; }
        public string Comments { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
