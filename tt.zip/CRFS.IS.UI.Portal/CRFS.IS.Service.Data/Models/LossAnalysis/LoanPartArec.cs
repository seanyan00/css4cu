﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LoanPartArec
    {
        public LoanPartArec()
        {
            LoanLivingUnits = new HashSet<LoanLivingUnits>();
        }

        public int PartArecId { get; set; }
        public int LoanId { get; set; }
        public int? PartAcompId { get; set; }
        public decimal? UnpaidPrincipalBalance { get; set; }
        public decimal? AuthorizedBidAmount { get; set; }
        public DateTime? EndorsementDate { get; set; }
        public DateTime? MarketableTitleDate { get; set; }
        public DateTime? DateOfPossessionAndAcquisition { get; set; }
        public DateTime? ClientSpecifiedBlock9 { get; set; }
        public DateTime? BankruptcyLiftDate { get; set; }
        public DateTime? CheckWireDate { get; set; }
        public DateTime? SecondChanceSaleDate { get; set; }
        public DateTime? ForeclosureDeedRecordedDate { get; set; }
        public DateTime? DueDateofLastPaymentInstallment { get; set; }
        public DateTime? LastOnTimePaymentDate { get; set; }
        public DateTime? DefaultDate { get; set; }
        public DateTime? DueDate { get; set; }
        public DateTime? OriginalDefaultDate { get; set; }
        public DateTime? ForeclosureSaleDate { get; set; }
        public DateTime? HudassignmentDate { get; set; }
        public DateTime? HuddeedFilingDate { get; set; }
        public DateTime? PfssettlementDate { get; set; }
        public DateTime? DeedInLieuDate { get; set; }
        public DateTime? DeedInLieuTransferDate { get; set; }
        public DateTime? LastLoanModificationDate { get; set; }
        public DateTime? ApprovalToParticipateDate { get; set; }
        public DateTime? Rrcdate { get; set; }
        public DateTime? RedemptionDate { get; set; }
        public DateTime? FirstInspectionDate { get; set; }
        public int? FirstInspectionStatus { get; set; }
        public DateTime? DateOfInspectionPriorToFtv { get; set; }
        public DateTime? FirstTimeVacancyDate { get; set; }
        public DateTime? RecentVacancyDate { get; set; }
        public DateTime? FirstSfdmscode1Adate { get; set; }
        public int? SfdmsreportingMissedCycles { get; set; }
        public bool? PropertyReosold { get; set; }
        public bool? SufficientPaymentHistory { get; set; }
        public bool? BorrowerPaymentsMade { get; set; }
        public decimal? SaleBidAmount { get; set; }
        public int? NumberOfLivingUnits { get; set; }
        public decimal? DebentureInterestRate { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual Loan Loan { get; set; }
        public virtual ICollection<LoanLivingUnits> LoanLivingUnits { get; set; }
    }
}
