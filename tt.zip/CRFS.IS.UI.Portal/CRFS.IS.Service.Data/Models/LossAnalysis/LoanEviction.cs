﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LoanEviction
    {
        public int LoanEvictionId { get; set; }
        public int LoanId { get; set; }
        public int? VacancyType { get; set; }
        public DateTime? VacancyDate { get; set; }
        public DateTime? EvictionFirstLegalDate { get; set; }
        public DateTime? CloseAndBillDate { get; set; }
        public DateTime? ReoccupancyDate { get; set; }
        public DateTime? UnacceptableDelayStartDate { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual Loan Loan { get; set; }
    }
}
