﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpFtmsJobTasks
    {
        public int TaskId { get; set; }
        public int JobId { get; set; }
        public string TaskName { get; set; }
        public int TaskTypeId { get; set; }
        public bool TaskEnabled { get; set; }
        public int JobTaskPriority { get; set; }
        public string SourceFolder { get; set; }
        public string SourceMask { get; set; }
        public string DestinationFolder { get; set; }
        public string ZipFileName { get; set; }
        public bool? FtpremoveFolder { get; set; }
        public string RenamePrefix { get; set; }
        public string RenameSuffix { get; set; }
        public bool FtpdeleteAfterPut { get; set; }
        public string RenameLeadingSuppresion { get; set; }

        public virtual LkpFtmstaskTypes TaskType { get; set; }
        public virtual LkpFtmsEmailTasks LkpFtmsEmailTasks { get; set; }
    }
}
