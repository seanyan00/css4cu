﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwGenerateFreqTypeValues
    {
        public int? Number { get; set; }
        public string Meaning { get; set; }
    }
}
