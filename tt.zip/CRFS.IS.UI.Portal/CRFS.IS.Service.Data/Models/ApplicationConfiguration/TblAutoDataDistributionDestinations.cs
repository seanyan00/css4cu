﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblAutoDataDistributionDestinations
    {
        public int AutoDataDistributionDestinationId { get; set; }
        public int ProcessId { get; set; }
        public int EnvironmentId { get; set; }
        public long DestinationTypeId { get; set; }
        public string Path { get; set; }
        public string Filename { get; set; }

        public virtual LkpDestinationTypes DestinationType { get; set; }
        public virtual LkpEnvironments Environment { get; set; }
        public virtual TblProcesses Process { get; set; }
    }
}
