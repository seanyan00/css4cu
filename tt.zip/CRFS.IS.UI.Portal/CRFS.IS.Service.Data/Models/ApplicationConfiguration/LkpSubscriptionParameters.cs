﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpSubscriptionParameters
    {
        public LkpSubscriptionParameters()
        {
            TblSubscriptionUserParameters = new HashSet<TblSubscriptionUserParameters>();
        }

        public int ParameterId { get; set; }
        public string ParameterName { get; set; }
        public string ParameterDataType { get; set; }

        public virtual ICollection<TblSubscriptionUserParameters> TblSubscriptionUserParameters { get; set; }
    }
}
