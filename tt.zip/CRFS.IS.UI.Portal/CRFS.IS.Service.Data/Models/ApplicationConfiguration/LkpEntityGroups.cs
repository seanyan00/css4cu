﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpEntityGroups
    {
        public LkpEntityGroups()
        {
            LkpGroupContacts = new HashSet<LkpGroupContacts>();
            TblEntityGroupContacts = new HashSet<TblEntityGroupContacts>();
            XrefBusinessEntityGroup = new HashSet<XrefBusinessEntityGroup>();
        }

        public int GroupId { get; set; }
        public string GroupName { get; set; }
        public int ApplicationId { get; set; }
        public DateTime EffectiveFromDate { get; set; }
        public DateTime EffectiveToDate { get; set; }
        public DateTime EnteredDate { get; set; }

        public virtual LkpApplications Application { get; set; }
        public virtual XrefEntityGroupUserAssignment XrefEntityGroupUserAssignment { get; set; }
        public virtual ICollection<LkpGroupContacts> LkpGroupContacts { get; set; }
        public virtual ICollection<TblEntityGroupContacts> TblEntityGroupContacts { get; set; }
        public virtual ICollection<XrefBusinessEntityGroup> XrefBusinessEntityGroup { get; set; }
    }
}
