﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefReportProcedures
    {
        public XrefReportProcedures()
        {
            XrefAppClientReportProcedureParameterValues = new HashSet<XrefAppClientReportProcedureParameterValues>();
        }

        public int ReportProcedureId { get; set; }
        public int ReportId { get; set; }
        public int StoredProcedureId { get; set; }
        public int ExecOrder { get; set; }
        public bool? Active { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual LkpReports Report { get; set; }
        public virtual StoredProcedures StoredProcedure { get; set; }
        public virtual ICollection<XrefAppClientReportProcedureParameterValues> XrefAppClientReportProcedureParameterValues { get; set; }
    }
}
