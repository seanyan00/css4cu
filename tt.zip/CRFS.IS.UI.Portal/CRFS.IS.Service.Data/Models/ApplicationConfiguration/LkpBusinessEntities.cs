﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpBusinessEntities
    {
        public LkpBusinessEntities()
        {
            Hoadestinations = new HashSet<Hoadestinations>();
        }

        public int BusinessEntityId { get; set; }
        public string BusinessEntityName { get; set; }
        public int ApplicationId { get; set; }
        public int EntityTypeId { get; set; }
        public DateTime EffectiveFromDate { get; set; }
        public DateTime EffectiveToDate { get; set; }
        public DateTime EnteredDate { get; set; }

        public virtual LkpApplications Application { get; set; }
        public virtual LkpEntityTypes EntityType { get; set; }
        public virtual ICollection<Hoadestinations> Hoadestinations { get; set; }
    }
}
