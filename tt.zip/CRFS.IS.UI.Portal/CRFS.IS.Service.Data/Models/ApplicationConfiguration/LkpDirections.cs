﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpDirections
    {
        public LkpDirections()
        {
            Hoadestinations = new HashSet<Hoadestinations>();
        }

        public int DirectionId { get; set; }
        public string DirectionName { get; set; }
        public bool? Active { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }

        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual ICollection<Hoadestinations> Hoadestinations { get; set; }
    }
}
