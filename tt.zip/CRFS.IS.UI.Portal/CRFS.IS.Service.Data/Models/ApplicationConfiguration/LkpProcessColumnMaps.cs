﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpProcessColumnMaps
    {
        public int ProcessColumnMapId { get; set; }
        public int ProcessId { get; set; }
        public string ColumnName { get; set; }
        public string ColumnType { get; set; }
        public bool Required { get; set; }
        public int Ordering { get; set; }
        public DateTime DateEntered { get; set; }
    }
}
