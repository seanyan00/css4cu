﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpInvestorFollowup
    {
        public int InvestorFollowupId { get; set; }
        public int InvestorId { get; set; }
        public int ClaimTypeId { get; set; }
        public int FollowupDaysAfterSubmit { get; set; }
        public int SubsequentFollowupDays { get; set; }

        public virtual TblControlInvestorGroup Investor { get; set; }
    }
}
