﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpEmploymentTypes
    {
        public LkpEmploymentTypes()
        {
            LkpUsers = new HashSet<LkpUsers>();
        }

        public int EmploymentTypeId { get; set; }
        public string EmploymentType { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual ICollection<LkpUsers> LkpUsers { get; set; }
    }
}
