﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class DatabaseInstances
    {
        public DatabaseInstances()
        {
            DatabaseInstanceDatabases = new HashSet<DatabaseInstanceDatabases>();
            DocuwareInstanceDatabaseInstanceDatabases = new HashSet<DocuwareInstanceDatabaseInstanceDatabases>();
        }

        public int DatabaseInstanceId { get; set; }
        public string DatabaseInstanceName { get; set; }
        public int ServerId { get; set; }
        public bool MarkedForDelete { get; set; }
        public bool? Active { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }

        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual Servers Server { get; set; }
        public virtual ICollection<DatabaseInstanceDatabases> DatabaseInstanceDatabases { get; set; }
        public virtual ICollection<DocuwareInstanceDatabaseInstanceDatabases> DocuwareInstanceDatabaseInstanceDatabases { get; set; }
    }
}
