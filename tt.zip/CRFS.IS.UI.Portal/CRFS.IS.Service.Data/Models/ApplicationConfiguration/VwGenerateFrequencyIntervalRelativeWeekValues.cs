﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwGenerateFrequencyIntervalRelativeWeekValues
    {
        public int? Number { get; set; }
        public string RunWeek { get; set; }
    }
}
