﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpUsers
    {
        public LkpUsers()
        {
            DatabaseInstanceDatabasesEnteredByUser = new HashSet<DatabaseInstanceDatabases>();
            DatabaseInstanceDatabasesLastUpdateUser = new HashSet<DatabaseInstanceDatabases>();
            DatabaseInstancesEnteredByUser = new HashSet<DatabaseInstances>();
            DatabaseInstancesLastUpdateUser = new HashSet<DatabaseInstances>();
            DatabasesEnteredByUser = new HashSet<Databases>();
            DatabasesLastUpdateUser = new HashSet<Databases>();
            DeliveryFormatsEnteredByUser = new HashSet<DeliveryFormats>();
            DeliveryFormatsLastUpdateUser = new HashSet<DeliveryFormats>();
            DocuWareCabinetDocumentStatusesEnteredByUser = new HashSet<DocuWareCabinetDocumentStatuses>();
            DocuWareCabinetDocumentStatusesLastUpdateUser = new HashSet<DocuWareCabinetDocumentStatuses>();
            DocumentTypesDocuwareProcessNamesEnteredByUser = new HashSet<DocumentTypesDocuwareProcessNames>();
            DocumentTypesDocuwareProcessNamesLastUpdateUser = new HashSet<DocumentTypesDocuwareProcessNames>();
            DocumentTypesEnteredByUser = new HashSet<DocumentTypes>();
            DocumentTypesLastUpdateUser = new HashSet<DocumentTypes>();
            DocuwareCabinetApplicationClientsEnteredByUser = new HashSet<DocuwareCabinetApplicationClients>();
            DocuwareCabinetApplicationClientsLastUpdteUser = new HashSet<DocuwareCabinetApplicationClients>();
            DocuwareCabinetDocumentTypesEnteredByUser = new HashSet<DocuwareCabinetDocumentTypes>();
            DocuwareCabinetDocumentTypesLastUpdateUser = new HashSet<DocuwareCabinetDocumentTypes>();
            DocuwareCabinetsEnteredByUser = new HashSet<DocuwareCabinets>();
            DocuwareCabinetsLastUpdateUser = new HashSet<DocuwareCabinets>();
            DocuwareColumnsEnteredByUser = new HashSet<DocuwareColumns>();
            DocuwareColumnsLastUpdateUser = new HashSet<DocuwareColumns>();
            DocuwareDocumentStatusesEnteredByUser = new HashSet<DocuwareDocumentStatuses>();
            DocuwareDocumentStatusesLastUpdateUser = new HashSet<DocuwareDocumentStatuses>();
            DocuwareInstanceDatabaseInstanceDatabasesEnteredByUser = new HashSet<DocuwareInstanceDatabaseInstanceDatabases>();
            DocuwareInstanceDatabaseInstanceDatabasesLastUpdateUser = new HashSet<DocuwareInstanceDatabaseInstanceDatabases>();
            DocuwareInstanceDocuwareCabinetColumnsEnteredByUser = new HashSet<DocuwareInstanceDocuwareCabinetColumns>();
            DocuwareInstanceDocuwareCabinetColumnsLastUpdateUser = new HashSet<DocuwareInstanceDocuwareCabinetColumns>();
            DocuwareInstanceDocuwareCabinetsEnteredByUser = new HashSet<DocuwareInstanceDocuwareCabinets>();
            DocuwareInstanceDocuwareCabinetsLastUpdateUser = new HashSet<DocuwareInstanceDocuwareCabinets>();
            DocuwareProcessNamesEnteredByUser = new HashSet<DocuwareProcessNames>();
            DocuwareProcessNamesLastUpdateUser = new HashSet<DocuwareProcessNames>();
            HoadestinationsEnteredByUser = new HashSet<Hoadestinations>();
            HoadestinationsLastUpdateUser = new HashSet<Hoadestinations>();
            LkpApplicationClientDestinationsEnteredByUser = new HashSet<LkpApplicationClientDestinations>();
            LkpApplicationClientDestinationsLastUpdateUser = new HashSet<LkpApplicationClientDestinations>();
            LkpApplicationsEnteredByUser = new HashSet<LkpApplications>();
            LkpApplicationsLastUpdateUser = new HashSet<LkpApplications>();
            LkpClientsEnteredByUser = new HashSet<LkpClients>();
            LkpClientsLastUpdateUser = new HashSet<LkpClients>();
            LkpContactTypesEnteredByUser = new HashSet<LkpContactTypes>();
            LkpContactTypesLastUpdateUser = new HashSet<LkpContactTypes>();
            LkpDirectionsEnteredByUser = new HashSet<LkpDirections>();
            LkpDirectionsLastUpdateUser = new HashSet<LkpDirections>();
            LkpEmploymentTypesEnteredByUser = new HashSet<LkpEmploymentTypes>();
            LkpEmploymentTypesLastUpdateUser = new HashSet<LkpEmploymentTypes>();
            LkpEnvironmentsEnteredByUser = new HashSet<LkpEnvironments>();
            LkpEnvironmentsLastUpdateUser = new HashSet<LkpEnvironments>();
            LkpFtmsEmailRecipientsEnteredByNavigation = new HashSet<LkpFtmsEmailRecipients>();
            LkpFtmsEmailRecipientsUpdatedByNavigation = new HashSet<LkpFtmsEmailRecipients>();
            LkpReportsEnteredByUser = new HashSet<LkpReports>();
            LkpReportsLastUpdateUser = new HashSet<LkpReports>();
            LkpRolesEnteredByUser = new HashSet<LkpRoles>();
            LkpRolesLastUpdateUser = new HashSet<LkpRoles>();
            LkpUsdaclaimTypeMatrixEnteredByUser = new HashSet<LkpUsdaclaimTypeMatrix>();
            LkpUsdaclaimTypeMatrixLastUpdateUser = new HashSet<LkpUsdaclaimTypeMatrix>();
            LkpUsdafollowupEnteredByUser = new HashSet<LkpUsdafollowup>();
            LkpUsdafollowupLastUpdateUser = new HashSet<LkpUsdafollowup>();
            LkpUserAttributesEnteredByUser = new HashSet<LkpUserAttributes>();
            LkpUserAttributesLastUpdateUser = new HashSet<LkpUserAttributes>();
            LogoutActivitiesEnteredByUser = new HashSet<LogoutActivities>();
            LogoutActivitiesLastUpdateUser = new HashSet<LogoutActivities>();
            ParametersEnteredByUser = new HashSet<Parameters>();
            ParametersLastUpdateUser = new HashSet<Parameters>();
            ServerTypesEnteredByUser = new HashSet<ServerTypes>();
            ServerTypesLastUpdateUser = new HashSet<ServerTypes>();
            ServersEnterdByUser = new HashSet<Servers>();
            ServersLastUpdateUser = new HashSet<Servers>();
            StoredProceduresEnteredByUser = new HashSet<StoredProcedures>();
            StoredProceduresLastUpdateUser = new HashSet<StoredProcedures>();
            TblClientContactsEnteredByUser = new HashSet<TblClientContacts>();
            TblClientContactsLastUpdateUser = new HashSet<TblClientContacts>();
            TblClientPdfcompressionAddedByNavigation = new HashSet<TblClientPdfcompression>();
            TblClientPdfcompressionUpdatedByNavigation = new HashSet<TblClientPdfcompression>();
            WebServiceDocuwareInstancesEnteredByUser = new HashSet<WebServiceDocuwareInstances>();
            WebServiceDocuwareInstancesLastUpdateUser = new HashSet<WebServiceDocuwareInstances>();
            WebServiceTypesEnteredByUser = new HashSet<WebServiceTypes>();
            WebServiceTypesLastUpdateUser = new HashSet<WebServiceTypes>();
            WebServicesEnteredByUser = new HashSet<WebServices>();
            WebServicesLastUpdateUser = new HashSet<WebServices>();
            XrefAppClientReportProcedureParameterValuesEnteredByUser = new HashSet<XrefAppClientReportProcedureParameterValues>();
            XrefAppClientReportProcedureParameterValuesLastUpdateUser = new HashSet<XrefAppClientReportProcedureParameterValues>();
            XrefApplicationClientReportsEnteredByUser = new HashSet<XrefApplicationClientReports>();
            XrefApplicationClientReportsLastUpdateUser = new HashSet<XrefApplicationClientReports>();
            XrefApplicationRolesEnteredByUser = new HashSet<XrefApplicationRoles>();
            XrefApplicationRolesLastUpdateUser = new HashSet<XrefApplicationRoles>();
            XrefApplicationUserEnteredByUser = new HashSet<XrefApplicationUser>();
            XrefApplicationUserLastUpdateUser = new HashSet<XrefApplicationUser>();
            XrefApplicationUserUser = new HashSet<XrefApplicationUser>();
            XrefApplicationsClientsEnteredByUser = new HashSet<XrefApplicationsClients>();
            XrefApplicationsClientsLastUpdateUser = new HashSet<XrefApplicationsClients>();
            XrefAppplicationUserApplicationRoleEnteredByUser = new HashSet<XrefAppplicationUserApplicationRole>();
            XrefAppplicationUserApplicationRoleLastUpdateUser = new HashSet<XrefAppplicationUserApplicationRole>();
            XrefClientsUsersEnteredByUser = new HashSet<XrefClientsUsers>();
            XrefClientsUsersLastUpdateUser = new HashSet<XrefClientsUsers>();
            XrefClientsUsersUser = new HashSet<XrefClientsUsers>();
            XrefProcessesClientsEnteredByUser = new HashSet<XrefProcessesClients>();
            XrefProcessesClientsLastUpdateUser = new HashSet<XrefProcessesClients>();
            XrefReportProceduresEnteredByUser = new HashSet<XrefReportProcedures>();
            XrefReportProceduresLastUpdateUser = new HashSet<XrefReportProcedures>();
            XrefReportRecipientsEnteredByUser = new HashSet<XrefReportRecipients>();
            XrefReportRecipientsLastUpdateUser = new HashSet<XrefReportRecipients>();
            XrefStoredProcedureParametersEnteredByUser = new HashSet<XrefStoredProcedureParameters>();
            XrefStoredProcedureParametersLastUpdateUser = new HashSet<XrefStoredProcedureParameters>();
            XrefUserReportRecipientsEnteredByUser = new HashSet<XrefUserReportRecipients>();
            XrefUserReportRecipientsLastUpdateUser = new HashSet<XrefUserReportRecipients>();
            XrefUserReportRecipientsUser = new HashSet<XrefUserReportRecipients>();
            XrefUserUserAttributesEnteredByUser = new HashSet<XrefUserUserAttributes>();
            XrefUserUserAttributesLastUpdateUser = new HashSet<XrefUserUserAttributes>();
            XrefUserUserAttributesUser = new HashSet<XrefUserUserAttributes>();
        }

        public int UserId { get; set; }
        public string Login { get; set; }
        public string UserName { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public bool Active { get; set; }
        public string Password { get; set; }
        public DateTime LastPwchange { get; set; }
        public int? SecurityGroupId { get; set; }
        public string PhoneNum { get; set; }
        public string UserEmailAddress { get; set; }
        public int? LegacyCmsuserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int? EmploymentTypeId { get; set; }
        public bool? AllClientAccess { get; set; }

        public virtual LkpEmploymentTypes EmploymentType { get; set; }
        public virtual ICollection<DatabaseInstanceDatabases> DatabaseInstanceDatabasesEnteredByUser { get; set; }
        public virtual ICollection<DatabaseInstanceDatabases> DatabaseInstanceDatabasesLastUpdateUser { get; set; }
        public virtual ICollection<DatabaseInstances> DatabaseInstancesEnteredByUser { get; set; }
        public virtual ICollection<DatabaseInstances> DatabaseInstancesLastUpdateUser { get; set; }
        public virtual ICollection<Databases> DatabasesEnteredByUser { get; set; }
        public virtual ICollection<Databases> DatabasesLastUpdateUser { get; set; }
        public virtual ICollection<DeliveryFormats> DeliveryFormatsEnteredByUser { get; set; }
        public virtual ICollection<DeliveryFormats> DeliveryFormatsLastUpdateUser { get; set; }
        public virtual ICollection<DocuWareCabinetDocumentStatuses> DocuWareCabinetDocumentStatusesEnteredByUser { get; set; }
        public virtual ICollection<DocuWareCabinetDocumentStatuses> DocuWareCabinetDocumentStatusesLastUpdateUser { get; set; }
        public virtual ICollection<DocumentTypesDocuwareProcessNames> DocumentTypesDocuwareProcessNamesEnteredByUser { get; set; }
        public virtual ICollection<DocumentTypesDocuwareProcessNames> DocumentTypesDocuwareProcessNamesLastUpdateUser { get; set; }
        public virtual ICollection<DocumentTypes> DocumentTypesEnteredByUser { get; set; }
        public virtual ICollection<DocumentTypes> DocumentTypesLastUpdateUser { get; set; }
        public virtual ICollection<DocuwareCabinetApplicationClients> DocuwareCabinetApplicationClientsEnteredByUser { get; set; }
        public virtual ICollection<DocuwareCabinetApplicationClients> DocuwareCabinetApplicationClientsLastUpdteUser { get; set; }
        public virtual ICollection<DocuwareCabinetDocumentTypes> DocuwareCabinetDocumentTypesEnteredByUser { get; set; }
        public virtual ICollection<DocuwareCabinetDocumentTypes> DocuwareCabinetDocumentTypesLastUpdateUser { get; set; }
        public virtual ICollection<DocuwareCabinets> DocuwareCabinetsEnteredByUser { get; set; }
        public virtual ICollection<DocuwareCabinets> DocuwareCabinetsLastUpdateUser { get; set; }
        public virtual ICollection<DocuwareColumns> DocuwareColumnsEnteredByUser { get; set; }
        public virtual ICollection<DocuwareColumns> DocuwareColumnsLastUpdateUser { get; set; }
        public virtual ICollection<DocuwareDocumentStatuses> DocuwareDocumentStatusesEnteredByUser { get; set; }
        public virtual ICollection<DocuwareDocumentStatuses> DocuwareDocumentStatusesLastUpdateUser { get; set; }
        public virtual ICollection<DocuwareInstanceDatabaseInstanceDatabases> DocuwareInstanceDatabaseInstanceDatabasesEnteredByUser { get; set; }
        public virtual ICollection<DocuwareInstanceDatabaseInstanceDatabases> DocuwareInstanceDatabaseInstanceDatabasesLastUpdateUser { get; set; }
        public virtual ICollection<DocuwareInstanceDocuwareCabinetColumns> DocuwareInstanceDocuwareCabinetColumnsEnteredByUser { get; set; }
        public virtual ICollection<DocuwareInstanceDocuwareCabinetColumns> DocuwareInstanceDocuwareCabinetColumnsLastUpdateUser { get; set; }
        public virtual ICollection<DocuwareInstanceDocuwareCabinets> DocuwareInstanceDocuwareCabinetsEnteredByUser { get; set; }
        public virtual ICollection<DocuwareInstanceDocuwareCabinets> DocuwareInstanceDocuwareCabinetsLastUpdateUser { get; set; }
        public virtual ICollection<DocuwareProcessNames> DocuwareProcessNamesEnteredByUser { get; set; }
        public virtual ICollection<DocuwareProcessNames> DocuwareProcessNamesLastUpdateUser { get; set; }
        public virtual ICollection<Hoadestinations> HoadestinationsEnteredByUser { get; set; }
        public virtual ICollection<Hoadestinations> HoadestinationsLastUpdateUser { get; set; }
        public virtual ICollection<LkpApplicationClientDestinations> LkpApplicationClientDestinationsEnteredByUser { get; set; }
        public virtual ICollection<LkpApplicationClientDestinations> LkpApplicationClientDestinationsLastUpdateUser { get; set; }
        public virtual ICollection<LkpApplications> LkpApplicationsEnteredByUser { get; set; }
        public virtual ICollection<LkpApplications> LkpApplicationsLastUpdateUser { get; set; }
        public virtual ICollection<LkpClients> LkpClientsEnteredByUser { get; set; }
        public virtual ICollection<LkpClients> LkpClientsLastUpdateUser { get; set; }
        public virtual ICollection<LkpContactTypes> LkpContactTypesEnteredByUser { get; set; }
        public virtual ICollection<LkpContactTypes> LkpContactTypesLastUpdateUser { get; set; }
        public virtual ICollection<LkpDirections> LkpDirectionsEnteredByUser { get; set; }
        public virtual ICollection<LkpDirections> LkpDirectionsLastUpdateUser { get; set; }
        public virtual ICollection<LkpEmploymentTypes> LkpEmploymentTypesEnteredByUser { get; set; }
        public virtual ICollection<LkpEmploymentTypes> LkpEmploymentTypesLastUpdateUser { get; set; }
        public virtual ICollection<LkpEnvironments> LkpEnvironmentsEnteredByUser { get; set; }
        public virtual ICollection<LkpEnvironments> LkpEnvironmentsLastUpdateUser { get; set; }
        public virtual ICollection<LkpFtmsEmailRecipients> LkpFtmsEmailRecipientsEnteredByNavigation { get; set; }
        public virtual ICollection<LkpFtmsEmailRecipients> LkpFtmsEmailRecipientsUpdatedByNavigation { get; set; }
        public virtual ICollection<LkpReports> LkpReportsEnteredByUser { get; set; }
        public virtual ICollection<LkpReports> LkpReportsLastUpdateUser { get; set; }
        public virtual ICollection<LkpRoles> LkpRolesEnteredByUser { get; set; }
        public virtual ICollection<LkpRoles> LkpRolesLastUpdateUser { get; set; }
        public virtual ICollection<LkpUsdaclaimTypeMatrix> LkpUsdaclaimTypeMatrixEnteredByUser { get; set; }
        public virtual ICollection<LkpUsdaclaimTypeMatrix> LkpUsdaclaimTypeMatrixLastUpdateUser { get; set; }
        public virtual ICollection<LkpUsdafollowup> LkpUsdafollowupEnteredByUser { get; set; }
        public virtual ICollection<LkpUsdafollowup> LkpUsdafollowupLastUpdateUser { get; set; }
        public virtual ICollection<LkpUserAttributes> LkpUserAttributesEnteredByUser { get; set; }
        public virtual ICollection<LkpUserAttributes> LkpUserAttributesLastUpdateUser { get; set; }
        public virtual ICollection<LogoutActivities> LogoutActivitiesEnteredByUser { get; set; }
        public virtual ICollection<LogoutActivities> LogoutActivitiesLastUpdateUser { get; set; }
        public virtual ICollection<Parameters> ParametersEnteredByUser { get; set; }
        public virtual ICollection<Parameters> ParametersLastUpdateUser { get; set; }
        public virtual ICollection<ServerTypes> ServerTypesEnteredByUser { get; set; }
        public virtual ICollection<ServerTypes> ServerTypesLastUpdateUser { get; set; }
        public virtual ICollection<Servers> ServersEnterdByUser { get; set; }
        public virtual ICollection<Servers> ServersLastUpdateUser { get; set; }
        public virtual ICollection<StoredProcedures> StoredProceduresEnteredByUser { get; set; }
        public virtual ICollection<StoredProcedures> StoredProceduresLastUpdateUser { get; set; }
        public virtual ICollection<TblClientContacts> TblClientContactsEnteredByUser { get; set; }
        public virtual ICollection<TblClientContacts> TblClientContactsLastUpdateUser { get; set; }
        public virtual ICollection<TblClientPdfcompression> TblClientPdfcompressionAddedByNavigation { get; set; }
        public virtual ICollection<TblClientPdfcompression> TblClientPdfcompressionUpdatedByNavigation { get; set; }
        public virtual ICollection<WebServiceDocuwareInstances> WebServiceDocuwareInstancesEnteredByUser { get; set; }
        public virtual ICollection<WebServiceDocuwareInstances> WebServiceDocuwareInstancesLastUpdateUser { get; set; }
        public virtual ICollection<WebServiceTypes> WebServiceTypesEnteredByUser { get; set; }
        public virtual ICollection<WebServiceTypes> WebServiceTypesLastUpdateUser { get; set; }
        public virtual ICollection<WebServices> WebServicesEnteredByUser { get; set; }
        public virtual ICollection<WebServices> WebServicesLastUpdateUser { get; set; }
        public virtual ICollection<XrefAppClientReportProcedureParameterValues> XrefAppClientReportProcedureParameterValuesEnteredByUser { get; set; }
        public virtual ICollection<XrefAppClientReportProcedureParameterValues> XrefAppClientReportProcedureParameterValuesLastUpdateUser { get; set; }
        public virtual ICollection<XrefApplicationClientReports> XrefApplicationClientReportsEnteredByUser { get; set; }
        public virtual ICollection<XrefApplicationClientReports> XrefApplicationClientReportsLastUpdateUser { get; set; }
        public virtual ICollection<XrefApplicationRoles> XrefApplicationRolesEnteredByUser { get; set; }
        public virtual ICollection<XrefApplicationRoles> XrefApplicationRolesLastUpdateUser { get; set; }
        public virtual ICollection<XrefApplicationUser> XrefApplicationUserEnteredByUser { get; set; }
        public virtual ICollection<XrefApplicationUser> XrefApplicationUserLastUpdateUser { get; set; }
        public virtual ICollection<XrefApplicationUser> XrefApplicationUserUser { get; set; }
        public virtual ICollection<XrefApplicationsClients> XrefApplicationsClientsEnteredByUser { get; set; }
        public virtual ICollection<XrefApplicationsClients> XrefApplicationsClientsLastUpdateUser { get; set; }
        public virtual ICollection<XrefAppplicationUserApplicationRole> XrefAppplicationUserApplicationRoleEnteredByUser { get; set; }
        public virtual ICollection<XrefAppplicationUserApplicationRole> XrefAppplicationUserApplicationRoleLastUpdateUser { get; set; }
        public virtual ICollection<XrefClientsUsers> XrefClientsUsersEnteredByUser { get; set; }
        public virtual ICollection<XrefClientsUsers> XrefClientsUsersLastUpdateUser { get; set; }
        public virtual ICollection<XrefClientsUsers> XrefClientsUsersUser { get; set; }
        public virtual ICollection<XrefProcessesClients> XrefProcessesClientsEnteredByUser { get; set; }
        public virtual ICollection<XrefProcessesClients> XrefProcessesClientsLastUpdateUser { get; set; }
        public virtual ICollection<XrefReportProcedures> XrefReportProceduresEnteredByUser { get; set; }
        public virtual ICollection<XrefReportProcedures> XrefReportProceduresLastUpdateUser { get; set; }
        public virtual ICollection<XrefReportRecipients> XrefReportRecipientsEnteredByUser { get; set; }
        public virtual ICollection<XrefReportRecipients> XrefReportRecipientsLastUpdateUser { get; set; }
        public virtual ICollection<XrefStoredProcedureParameters> XrefStoredProcedureParametersEnteredByUser { get; set; }
        public virtual ICollection<XrefStoredProcedureParameters> XrefStoredProcedureParametersLastUpdateUser { get; set; }
        public virtual ICollection<XrefUserReportRecipients> XrefUserReportRecipientsEnteredByUser { get; set; }
        public virtual ICollection<XrefUserReportRecipients> XrefUserReportRecipientsLastUpdateUser { get; set; }
        public virtual ICollection<XrefUserReportRecipients> XrefUserReportRecipientsUser { get; set; }
        public virtual ICollection<XrefUserUserAttributes> XrefUserUserAttributesEnteredByUser { get; set; }
        public virtual ICollection<XrefUserUserAttributes> XrefUserUserAttributesLastUpdateUser { get; set; }
        public virtual ICollection<XrefUserUserAttributes> XrefUserUserAttributesUser { get; set; }
    }
}
