﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpClaimGroup
    {
        public int Id { get; set; }
        public string GroupName { get; set; }
        public string SendToEmail { get; set; }
        public string ErrorEmail { get; set; }
        public string Destination { get; set; }
        public string Code1 { get; set; }
        public string Code2 { get; set; }
        public DateTime DateCreated { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? DateUpdated { get; set; }
        public int UpdatedBy { get; set; }
        public int? FhaclaimGroup { get; set; }
    }
}
