﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LoginActivities
    {
        public LoginActivities()
        {
            LogoutActivities = new HashSet<LogoutActivities>();
        }

        public long LoginActivityId { get; set; }
        public int? UserId { get; set; }
        public string Login { get; set; }
        public string UserName { get; set; }
        public string HostName { get; set; }
        public string HostAddress { get; set; }
        public DateTime? LoginDate { get; set; }
        public bool? LoginSuccessful { get; set; }
        public DateTime? LastHeartbeat { get; set; }
        public bool? LoginRevoked { get; set; }
        public int? ApplicationId { get; set; }
        public string ApplicationVersion { get; set; }

        public virtual ICollection<LogoutActivities> LogoutActivities { get; set; }
    }
}
