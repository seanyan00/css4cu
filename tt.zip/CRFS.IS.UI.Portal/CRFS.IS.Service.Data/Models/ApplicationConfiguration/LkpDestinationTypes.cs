﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpDestinationTypes
    {
        public LkpDestinationTypes()
        {
            LkpApplicationClientDestinationsArchiveType = new HashSet<LkpApplicationClientDestinations>();
            LkpApplicationClientDestinationsDelieveryType = new HashSet<LkpApplicationClientDestinations>();
            TblAutoDataDistributionDestinations = new HashSet<TblAutoDataDistributionDestinations>();
        }

        public long DestinationTypeId { get; set; }
        public string Description { get; set; }

        public virtual ICollection<LkpApplicationClientDestinations> LkpApplicationClientDestinationsArchiveType { get; set; }
        public virtual ICollection<LkpApplicationClientDestinations> LkpApplicationClientDestinationsDelieveryType { get; set; }
        public virtual ICollection<TblAutoDataDistributionDestinations> TblAutoDataDistributionDestinations { get; set; }
    }
}
