﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class EdiauthTruthSources
    {
        public int EdiauthTruthSourceId { get; set; }
        public string ClaimTypeName { get; set; }
        public string SubmitPart { get; set; }
        public string BitName { get; set; }
        public byte BitValue { get; set; }
        public string ErrorMessage { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUser { get; set; }
    }
}
