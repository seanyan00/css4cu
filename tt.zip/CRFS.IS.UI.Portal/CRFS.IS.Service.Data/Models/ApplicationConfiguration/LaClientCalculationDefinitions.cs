﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LaClientCalculationDefinitions
    {
        public int ClientCalculationDefinitionId { get; set; }
        public int ClientId { get; set; }
        public int SixtyDayInterestCalculationId { get; set; }
        public int TotalUncontrollableLossesCalculationId { get; set; }
        public int? TotalControllableLossesCalculationId { get; set; }

        public virtual LkpClients Client { get; set; }
        public virtual LaSixtyDayInterestCalculations SixtyDayInterestCalculation { get; set; }
        public virtual LaTotalControllableLossesCalculations TotalControllableLossesCalculation { get; set; }
        public virtual LaTotalUncontrollableLossesCalculations TotalUncontrollableLossesCalculation { get; set; }
    }
}
