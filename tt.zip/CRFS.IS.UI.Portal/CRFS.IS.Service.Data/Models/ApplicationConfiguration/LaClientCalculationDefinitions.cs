﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LaClientCalculationDefinitions
    {
        public int ClientCalculationDefinitionId { get; set; }
        public int ClientId { get; set; }
        public int SixtyDayInterestCalculationId { get; set; }
        public int TotalUncontrollableLossesCalculationId { get; set; }
        public int? TotalControllableLossesCalculationId { get; set; }

        public virtual LkpClients Client { get; set; }
        public virtual LaSixtyDayInterestCalculations SixtyDayInterestCalculation { get; set; }
        public virtual LaTotalControllableLossesCalculations TotalControllableLossesCalculation { get; set; }
        public virtual LaTotalUncontrollableLossesCalculations TotalUncontrollableLossesCalculation { get; set; }
    }
}
