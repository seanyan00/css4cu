﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class Parameters
    {
        public Parameters()
        {
            XrefStoredProcedureParameters = new HashSet<XrefStoredProcedureParameters>();
        }

        public int ParameterId { get; set; }
        public string ParameterName { get; set; }
        public string DataType { get; set; }
        public int? Length { get; set; }
        public int? Scale { get; set; }
        public int? Precision { get; set; }
        public bool? Active { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual ICollection<XrefStoredProcedureParameters> XrefStoredProcedureParameters { get; set; }
    }
}
