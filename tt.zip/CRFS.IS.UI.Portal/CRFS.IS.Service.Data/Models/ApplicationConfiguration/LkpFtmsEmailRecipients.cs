﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpFtmsEmailRecipients
    {
        public int RecipientId { get; set; }
        public string EmailAddress { get; set; }
        public bool? Active { get; set; }
        public DateTime DateEntered { get; set; }
        public int EnteredBy { get; set; }
        public DateTime DateUpdated { get; set; }
        public int UpdatedBy { get; set; }

        public virtual LkpUsers EnteredByNavigation { get; set; }
        public virtual LkpUsers UpdatedByNavigation { get; set; }
        public virtual XrefFtmsTaskEmailRecipients XrefFtmsTaskEmailRecipients { get; set; }
    }
}
