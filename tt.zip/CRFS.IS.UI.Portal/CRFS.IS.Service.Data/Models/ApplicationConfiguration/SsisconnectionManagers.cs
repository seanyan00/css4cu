﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class SsisconnectionManagers
    {
        public SsisconnectionManagers()
        {
            SsisconnectionManagerColumns = new HashSet<SsisconnectionManagerColumns>();
        }

        public int ConnectionManagerId { get; set; }
        public string ConnectionManagerName { get; set; }
        public int PackageId { get; set; }
        public string FilePath { get; set; }
        public string BaseFileName { get; set; }
        public bool Outbound { get; set; }
        public string ConnectionManagerType { get; set; }

        public virtual Ssispackages Package { get; set; }
        public virtual ICollection<SsisconnectionManagerColumns> SsisconnectionManagerColumns { get; set; }
    }
}
