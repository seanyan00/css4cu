﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class FileTransferManagementTasks
    {
        public long TaskId { get; set; }
        public int ClientId { get; set; }
        public string TaskName { get; set; }
        public bool? TaskEnabled { get; set; }
        public string TaskAction { get; set; }
        public int PriorityWithinClientTasks { get; set; }
        public string SourceFolder { get; set; }
        public string SourceMask { get; set; }
        public string DestinationFolder { get; set; }
        public string DestinationTimeFormatOrMask { get; set; }
        public bool SendEmail { get; set; }
        public string EmailNotificationList { get; set; }
        public string EmailText { get; set; }
        public string EmailSubject { get; set; }
        public bool EmailFilesAsAttachments { get; set; }
        public bool IncludeFileDetailsInEmailBody { get; set; }
        public bool SendEachMatchingFileAsSeparateEmail { get; set; }
        public bool? NotifyRecipientsIfNoSourceFile { get; set; }
        public DateTime DateEntered { get; set; }
        public int EnteredUser { get; set; }
        public DateTime DateUpdated { get; set; }
        public int UpdateUser { get; set; }
        public bool LogFileMoves { get; set; }

        public virtual LkpClients Client { get; set; }
        public virtual LkpUsers EnteredUserNavigation { get; set; }
        public virtual LkpUsers UpdateUserNavigation { get; set; }
    }
}
