﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class InterimGroupContactsConversionControl
    {
        public int GroupContactId { get; set; }
        public int LegacyFormId { get; set; }
        public int ApplicationId { get; set; }
        public int LegacyGroupId { get; set; }
        public int GroupId { get; set; }
    }
}
