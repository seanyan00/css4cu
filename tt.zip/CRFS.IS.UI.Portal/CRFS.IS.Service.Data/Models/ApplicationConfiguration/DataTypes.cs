﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class DataTypes
    {
        public DataTypes()
        {
            LkpEndPointAttributes = new HashSet<LkpEndPointAttributes>();
            LkpUserAttributes = new HashSet<LkpUserAttributes>();
        }

        public int DataTypeId { get; set; }
        public string DataTypeName { get; set; }
        public int? Length { get; set; }
        public int? Precision { get; set; }
        public int? Scale { get; set; }

        public virtual ICollection<LkpEndPointAttributes> LkpEndPointAttributes { get; set; }
        public virtual ICollection<LkpUserAttributes> LkpUserAttributes { get; set; }
    }
}
