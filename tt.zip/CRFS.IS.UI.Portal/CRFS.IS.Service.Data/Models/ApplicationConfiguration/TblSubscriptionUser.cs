﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblSubscriptionUser
    {
        public TblSubscriptionUser()
        {
            TblSubscriptionUserParameters = new HashSet<TblSubscriptionUserParameters>();
        }

        public int SubscriptionUserId { get; set; }
        public int? SubscriptionId { get; set; }
        public int? UserId { get; set; }

        public virtual TblSubscriptionsDataDriven Subscription { get; set; }
        public virtual ICollection<TblSubscriptionUserParameters> TblSubscriptionUserParameters { get; set; }
    }
}
