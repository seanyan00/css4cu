﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblAutoDataDistributionParameterValues
    {
        public int AutoDataDistributionParameterValueId { get; set; }
        public int ProcessId { get; set; }
        public int EnvironmentId { get; set; }
        public int AutoDataDistributionParameterId { get; set; }
        public string Value { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual LkpAutoDataDistributionParameters AutoDataDistributionParameter { get; set; }
        public virtual LkpEnvironments Environment { get; set; }
        public virtual TblProcesses Process { get; set; }
    }
}
