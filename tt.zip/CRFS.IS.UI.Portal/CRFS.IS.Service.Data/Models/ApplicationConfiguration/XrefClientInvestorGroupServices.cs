﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefClientInvestorGroupServices
    {
        public int ClientInvestorGroupServicesId { get; set; }
        public int ClientId { get; set; }
        public int InvestorGroupId { get; set; }
    }
}
