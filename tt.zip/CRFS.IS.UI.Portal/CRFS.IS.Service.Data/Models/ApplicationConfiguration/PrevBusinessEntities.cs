﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class PrevBusinessEntities
    {
        public int BusinessEntityId { get; set; }
        public string BusinessEntityName { get; set; }
        public int ApplicationId { get; set; }
        public int EntityTypeId { get; set; }
        public DateTime EffectiveFromDate { get; set; }
        public DateTime EffectiveToDate { get; set; }
        public DateTime EnteredDate { get; set; }
    }
}
