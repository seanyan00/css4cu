﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LaTotalUncontrollableLossesCalculations
    {
        public LaTotalUncontrollableLossesCalculations()
        {
            LaClientCalculationDefinitions = new HashSet<LaClientCalculationDefinitions>();
        }

        public int TotalUncontrollableLossesCalculationId { get; set; }
        public string CalculationName { get; set; }
        public string CalculationDescription { get; set; }

        public virtual ICollection<LaClientCalculationDefinitions> LaClientCalculationDefinitions { get; set; }
    }
}
