﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblCntlTabControl
    {
        public int TabControlId { get; set; }
        public int FormId { get; set; }
        public string ClaimGroupText { get; set; }
        public string TabControlName { get; set; }
        public bool AllowedToUse { get; set; }
    }
}
