﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblCntlTabControl
    {
        public int TabControlId { get; set; }
        public int FormId { get; set; }
        public string ClaimGroupText { get; set; }
        public string TabControlName { get; set; }
        public bool AllowedToUse { get; set; }
    }
}
