﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LaTotalControllableLossesCalculations
    {
        public LaTotalControllableLossesCalculations()
        {
            LaClientCalculationDefinitions = new HashSet<LaClientCalculationDefinitions>();
        }

        public int TotalControllableLossesCalculationId { get; set; }
        public string CalculationName { get; set; }
        public string CalculationDescription { get; set; }

        public virtual ICollection<LaClientCalculationDefinitions> LaClientCalculationDefinitions { get; set; }
    }
}
