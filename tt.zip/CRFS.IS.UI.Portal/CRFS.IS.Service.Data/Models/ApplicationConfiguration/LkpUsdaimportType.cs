﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpUsdaimportType
    {
        public LkpUsdaimportType()
        {
            XrefClientUsdaclaimScope = new HashSet<XrefClientUsdaclaimScope>();
        }

        public int UsdaimportTypeId { get; set; }
        public int ImportMethod { get; set; }
        public string ImportMethodName { get; set; }
        public string Description { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredUser { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUser { get; set; }

        public virtual ICollection<XrefClientUsdaclaimScope> XrefClientUsdaclaimScope { get; set; }
    }
}
