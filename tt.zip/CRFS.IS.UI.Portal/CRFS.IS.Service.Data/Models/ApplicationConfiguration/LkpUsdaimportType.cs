﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpUsdaimportType
    {
        public LkpUsdaimportType()
        {
            XrefClientUsdaclaimScope = new HashSet<XrefClientUsdaclaimScope>();
        }

        public int UsdaimportTypeId { get; set; }
        public int ImportMethod { get; set; }
        public string ImportMethodName { get; set; }
        public string Description { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredUser { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUser { get; set; }

        public virtual ICollection<XrefClientUsdaclaimScope> XrefClientUsdaclaimScope { get; set; }
    }
}
