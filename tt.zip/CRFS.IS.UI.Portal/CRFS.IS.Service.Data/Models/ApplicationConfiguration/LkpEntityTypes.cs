﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpEntityTypes
    {
        public LkpEntityTypes()
        {
            LkpBusinessEntities = new HashSet<LkpBusinessEntities>();
        }

        public int EntityTypeId { get; set; }
        public string EntityTypeName { get; set; }
        public DateTime EffectiveFromDate { get; set; }
        public DateTime EffectiveToDate { get; set; }
        public DateTime EnteredDate { get; set; }

        public virtual ICollection<LkpBusinessEntities> LkpBusinessEntities { get; set; }
    }
}
