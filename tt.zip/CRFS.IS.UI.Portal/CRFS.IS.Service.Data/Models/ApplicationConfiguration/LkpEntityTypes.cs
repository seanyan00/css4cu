﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpEntityTypes
    {
        public LkpEntityTypes()
        {
            LkpBusinessEntities = new HashSet<LkpBusinessEntities>();
        }

        public int EntityTypeId { get; set; }
        public string EntityTypeName { get; set; }
        public DateTime EffectiveFromDate { get; set; }
        public DateTime EffectiveToDate { get; set; }
        public DateTime EnteredDate { get; set; }

        public virtual ICollection<LkpBusinessEntities> LkpBusinessEntities { get; set; }
    }
}
