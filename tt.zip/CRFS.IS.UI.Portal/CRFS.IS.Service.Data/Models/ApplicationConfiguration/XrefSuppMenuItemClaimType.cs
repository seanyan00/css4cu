﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefSuppMenuItemClaimType
    {
        public int ValidSuppMenuItemId { get; set; }
        public int ClaimTypeId { get; set; }
        public int SuppMenuItemNameId { get; set; }

        public virtual LkpSuppMenuItemName SuppMenuItemName { get; set; }
    }
}
