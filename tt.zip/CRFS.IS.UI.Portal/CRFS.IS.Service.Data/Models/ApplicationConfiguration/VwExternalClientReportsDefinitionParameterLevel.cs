﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwExternalClientReportsDefinitionParameterLevel
    {
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public int ReportId { get; set; }
        public string ReportName { get; set; }
        public int StoredProcedureId { get; set; }
        public string StoredProcedureName { get; set; }
        public int ParameterId { get; set; }
        public string ParameterName { get; set; }
        public int ParameterOrdinalPosition { get; set; }
        public string DataType { get; set; }
        public int? Length { get; set; }
        public int? Scale { get; set; }
        public int? Precision { get; set; }
        public string ParameterValue { get; set; }
    }
}
