﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StoredProcedures
    {
        public StoredProcedures()
        {
            XrefReportProcedures = new HashSet<XrefReportProcedures>();
            XrefStoredProcedureParameters = new HashSet<XrefStoredProcedureParameters>();
        }

        public int StoredProcedureId { get; set; }
        public int DatabaseId { get; set; }
        public string SchemaName { get; set; }
        public string StoredProcedureName { get; set; }
        public bool? Active { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual Databases Database { get; set; }
        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual ICollection<XrefReportProcedures> XrefReportProcedures { get; set; }
        public virtual ICollection<XrefStoredProcedureParameters> XrefStoredProcedureParameters { get; set; }
    }
}
