﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class SsisconnectionManagerColumns
    {
        public int ConnectionManagerColumnId { get; set; }
        public int ConnectionManagerId { get; set; }
        public string ColumnName { get; set; }
        public int? ColumnOrder { get; set; }
        public string ColumnDataType { get; set; }
        public int? ColumnWidth { get; set; }

        public virtual SsisconnectionManagers ConnectionManager { get; set; }
    }
}
