﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class SsisconnectionManagerColumns
    {
        public int ConnectionManagerColumnId { get; set; }
        public int ConnectionManagerId { get; set; }
        public string ColumnName { get; set; }
        public int? ColumnOrder { get; set; }
        public string ColumnDataType { get; set; }
        public int? ColumnWidth { get; set; }

        public virtual SsisconnectionManagers ConnectionManager { get; set; }
    }
}
