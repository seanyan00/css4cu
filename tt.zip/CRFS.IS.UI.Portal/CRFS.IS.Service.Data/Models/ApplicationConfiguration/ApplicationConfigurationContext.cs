﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CRFS.IS.Service.Data
{
    public partial class ApplicationConfigurationContext : DbContext
    {
        public ApplicationConfigurationContext()
        {
        }

        public ApplicationConfigurationContext(DbContextOptions<ApplicationConfigurationContext> options)
            : base(options)
        {
        }

        public virtual DbSet<LkpApplications> LkpApplications { get; set; }
        public virtual DbSet<LkpClients> LkpClients { get; set; }
        public virtual DbSet<LkpEmploymentTypes> LkpEmploymentTypes { get; set; }
        public virtual DbSet<LkpUsers> LkpUsers { get; set; }
        public virtual DbSet<TblClientPdfcompression> TblClientPdfcompression { get; set; }
        public virtual DbSet<TblControlInvestors> TblControlInvestors { get; set; }
        public virtual DbSet<XrefClientsUsers> XrefClientsUsers { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=vm-sql1-dev.dev.crfs.crfservices.com\\cms_d;Initial Catalog=ApplicationConfiguration;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<LkpApplications>(entity =>
            {
                entity.HasKey(e => e.ApplicationId)
                    .HasName("PK_Applications");

                entity.ToTable("lkp_Applications");

                entity.HasComment("A lookup table that lists User levels and roles within the application.");

                entity.HasIndex(e => e.ApplicationName)
                    .HasName("UK1_lkp_Applications_ApplicationName")
                    .IsUnique();

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.ApplicationName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ApplicationUrl)
                    .HasColumnName("ApplicationURL")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.CmsformId).HasColumnName("CMSFormID");

                entity.Property(e => e.EffectiveFromDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.EffectiveToDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("('12/31/2078')");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.LkpApplicationsEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId);

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.LkpApplicationsLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId);
            });

            modelBuilder.Entity<LkpClients>(entity =>
            {
                entity.HasKey(e => e.ClientId);

                entity.ToTable("lkp_Clients");

                entity.HasComment("A lookup table that displays Client Names, in addition to their abbreviations. ");

                entity.HasIndex(e => e.ClientAbbreviation)
                    .HasName("UK2_lkp_Clients_ClientAbbreviation")
                    .IsUnique();

                entity.HasIndex(e => e.ClientName)
                    .HasName("UK1_lkp_Clients_ClientName")
                    .IsUnique();

                entity.HasIndex(e => new { e.ClientName, e.ClientAbbreviation })
                    .HasName("UK3_lkp_Clients_ClientName_ClientAbbreviation")
                    .IsUnique();

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.ClientAbbreviation)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ClientDisplayName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ClientLegalName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EffectiveFromDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.EffectiveToDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("('12/31/2015')");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.LkpClientsEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_lkp_Users_lkp_Clients_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.LkpClientsLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_lkp_Users_lkp_Clients_LastUpdateUserID");
            });

            modelBuilder.Entity<LkpEmploymentTypes>(entity =>
            {
                entity.HasKey(e => e.EmploymentTypeId);

                entity.ToTable("lkp_EmploymentTypes");

                entity.HasIndex(e => e.EmploymentType)
                    .HasName("UK1_EmploymentTypes_EmploymentType")
                    .IsUnique();

                entity.Property(e => e.EmploymentTypeId).HasColumnName("EmploymentTypeID");

                entity.Property(e => e.EmploymentType)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.LkpEmploymentTypesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_lkp_EmploymentTypes_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.LkpEmploymentTypesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_lkp_EmploymentTypes_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<LkpUsers>(entity =>
            {
                entity.HasKey(e => e.UserId);

                entity.ToTable("lkp_Users");

                entity.HasComment("A lookup table that contains user data. Utilized by a variety of tables within the database.");

                entity.HasIndex(e => e.Login)
                    .HasName("UK1_lkp_Users_Login")
                    .IsUnique();

                entity.HasIndex(e => e.UserName)
                    .HasName("idx_lkp_Users_UserName");

                entity.HasIndex(e => new { e.UserId, e.FirstName, e.LastName })
                    .HasName("idx_lkp_Users_FirstName_LastName_UserID");

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.Property(e => e.AllClientAccess)
                    .IsRequired()
                    .HasDefaultValueSql("('FALSE')");

                entity.Property(e => e.EmploymentTypeId).HasColumnName("EmploymentTypeID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.FirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastPwchange)
                    .HasColumnName("LastPWChange")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.LegacyCmsuserId).HasColumnName("LegacyCMSUserID");

                entity.Property(e => e.Login)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.PhoneNum)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.SecurityGroupId).HasColumnName("SecurityGroupID");

                entity.Property(e => e.UserEmailAddress)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.EmploymentType)
                    .WithMany(p => p.LkpUsers)
                    .HasForeignKey(d => d.EmploymentTypeId)
                    .HasConstraintName("FK1_lkp_Users_lkp_EmploymentTypes");
            });

            modelBuilder.Entity<TblClientPdfcompression>(entity =>
            {
                entity.HasKey(e => e.ClientId)
                    .HasName("PK_ClientPDFCompression");

                entity.ToTable("tbl_ClientPDFCompression");

                entity.Property(e => e.ClientId)
                    .HasColumnName("ClientID")
                    .ValueGeneratedNever();

                entity.Property(e => e.AddedDate).HasColumnType("datetime");

                entity.Property(e => e.Comment)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.Cron)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DestinationFolder).HasMaxLength(200);

                entity.Property(e => e.ErrorFolder).HasMaxLength(200);

                entity.Property(e => e.NotifyClientDl).HasColumnName("NotifyClientDL");

                entity.Property(e => e.NotifyCrfsDl).HasColumnName("NotifyCrfsDL");

                entity.Property(e => e.SizeLimitMb).HasColumnName("SizeLimit_MB");

                entity.Property(e => e.SourceFolder).HasMaxLength(200);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.HasOne(d => d.AddedByNavigation)
                    .WithMany(p => p.TblClientPdfcompressionAddedByNavigation)
                    .HasForeignKey(d => d.AddedBy)
                    .HasConstraintName("FK_ClientPDFCompression_lkp_Users");

                entity.HasOne(d => d.Client)
                    .WithOne(p => p.TblClientPdfcompression)
                    .HasForeignKey<TblClientPdfcompression>(d => d.ClientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ClientPDFCompression_lkp_Clients");

                entity.HasOne(d => d.UpdatedByNavigation)
                    .WithMany(p => p.TblClientPdfcompressionUpdatedByNavigation)
                    .HasForeignKey(d => d.UpdatedBy)
                    .HasConstraintName("FK_ClientPDFCompression_lkp_Users1");
            });

            modelBuilder.Entity<TblControlInvestors>(entity =>
            {
                entity.HasKey(e => e.InvestorId)
                    .HasName("tbl_Control_Investors_PK");

                entity.ToTable("tbl_Control_Investors");

                entity.HasComment("Table that contains Investor Names and IDs.");

                entity.HasIndex(e => e.InvestorName)
                    .HasName("UK1_InvestorName")
                    .IsUnique();

                entity.Property(e => e.InvestorId).HasColumnName("InvestorID");

                entity.Property(e => e.DateEntered)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EffectiveFromDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.EffectiveToDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('12/31/2078')");

                entity.Property(e => e.InvestorName)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<XrefClientsUsers>(entity =>
            {
                entity.HasKey(e => e.ClientUserId);

                entity.ToTable("xref_ClientsUsers");

                entity.HasComment("Cross ref table that contains ClientIDs and ClientUserIDs.");

                entity.HasIndex(e => new { e.ClientId, e.UserId })
                    .HasName("UK1_xref_ClientsUsers_ClientIDUserID")
                    .IsUnique();

                entity.Property(e => e.ClientUserId).HasColumnName("ClientUserID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.HasOne(d => d.Client)
                    .WithMany(p => p.XrefClientsUsers)
                    .HasForeignKey(d => d.ClientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_ClientsUsers_lkp_Clients_ClientID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.XrefClientsUsersEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_xref_ClientsUsers_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.XrefClientsUsersLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_xref_ClientsUsers_lkp_Users_LastUpdateUserID");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.XrefClientsUsersUser)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_ClientsUsers_lkp_Users_UserID");
            });

            modelBuilder.HasSequence("FIleTransferDuplicateFIleSequence");

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
