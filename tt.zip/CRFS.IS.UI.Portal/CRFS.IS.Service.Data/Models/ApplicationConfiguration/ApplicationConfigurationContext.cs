﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class ApplicationConfigurationContext : DbContext
    {
        public ApplicationConfigurationContext()
        {
        }

        public ApplicationConfigurationContext(DbContextOptions<ApplicationConfigurationContext> options)
            : base(options)
        {
        }

        public virtual DbSet<ApplicationAliases> ApplicationAliases { get; set; }
        public virtual DbSet<ConfigurationSettings> ConfigurationSettings { get; set; }
        public virtual DbSet<DataTypes> DataTypes { get; set; }
        public virtual DbSet<DatabaseInstanceDatabases> DatabaseInstanceDatabases { get; set; }
        public virtual DbSet<DatabaseInstances> DatabaseInstances { get; set; }
        public virtual DbSet<Databases> Databases { get; set; }
        public virtual DbSet<DeliveryEndPoints> DeliveryEndPoints { get; set; }
        public virtual DbSet<DeliveryFormats> DeliveryFormats { get; set; }
        public virtual DbSet<DeliveryMethods> DeliveryMethods { get; set; }
        public virtual DbSet<DocuWareCabinetDocumentStatuses> DocuWareCabinetDocumentStatuses { get; set; }
        public virtual DbSet<DocumentTypes> DocumentTypes { get; set; }
        public virtual DbSet<DocumentTypesDocuwareProcessNames> DocumentTypesDocuwareProcessNames { get; set; }
        public virtual DbSet<DocuwareCabinetApplicationClients> DocuwareCabinetApplicationClients { get; set; }
        public virtual DbSet<DocuwareCabinetDocumentTypes> DocuwareCabinetDocumentTypes { get; set; }
        public virtual DbSet<DocuwareCabinets> DocuwareCabinets { get; set; }
        public virtual DbSet<DocuwareColumns> DocuwareColumns { get; set; }
        public virtual DbSet<DocuwareDocumentStatuses> DocuwareDocumentStatuses { get; set; }
        public virtual DbSet<DocuwareInstanceDatabaseInstanceDatabases> DocuwareInstanceDatabaseInstanceDatabases { get; set; }
        public virtual DbSet<DocuwareInstanceDocuwareCabinetColumns> DocuwareInstanceDocuwareCabinetColumns { get; set; }
        public virtual DbSet<DocuwareInstanceDocuwareCabinets> DocuwareInstanceDocuwareCabinets { get; set; }
        public virtual DbSet<DocuwareInstances> DocuwareInstances { get; set; }
        public virtual DbSet<DocuwareInstancesBak> DocuwareInstancesBak { get; set; }
        public virtual DbSet<DocuwareProcessNames> DocuwareProcessNames { get; set; }
        public virtual DbSet<EdiauthTruthSources> EdiauthTruthSources { get; set; }
        public virtual DbSet<Hoadestinations> Hoadestinations { get; set; }
        public virtual DbSet<InterimGroupContactsConversionControl> InterimGroupContactsConversionControl { get; set; }
        public virtual DbSet<LaClientCalculationDefinitions> LaClientCalculationDefinitions { get; set; }
        public virtual DbSet<LaSixtyDayInterestCalculations> LaSixtyDayInterestCalculations { get; set; }
        public virtual DbSet<LaTotalControllableLossesCalculations> LaTotalControllableLossesCalculations { get; set; }
        public virtual DbSet<LaTotalUncontrollableLossesCalculations> LaTotalUncontrollableLossesCalculations { get; set; }
        public virtual DbSet<LkpApplicationClientDestinations> LkpApplicationClientDestinations { get; set; }
        public virtual DbSet<LkpApplications> LkpApplications { get; set; }
        public virtual DbSet<LkpAutoDataDistributionParameters> LkpAutoDataDistributionParameters { get; set; }
        public virtual DbSet<LkpBusinessEntities> LkpBusinessEntities { get; set; }
        public virtual DbSet<LkpCategories> LkpCategories { get; set; }
        public virtual DbSet<LkpClaimGroup> LkpClaimGroup { get; set; }
        public virtual DbSet<LkpClientFtpsites> LkpClientFtpsites { get; set; }
        public virtual DbSet<LkpClientPoolClaimScope> LkpClientPoolClaimScope { get; set; }
        public virtual DbSet<LkpClients> LkpClients { get; set; }
        public virtual DbSet<LkpContactTypes> LkpContactTypes { get; set; }
        public virtual DbSet<LkpDestinationTypes> LkpDestinationTypes { get; set; }
        public virtual DbSet<LkpDirections> LkpDirections { get; set; }
        public virtual DbSet<LkpEmploymentTypes> LkpEmploymentTypes { get; set; }
        public virtual DbSet<LkpEndPointAttributes> LkpEndPointAttributes { get; set; }
        public virtual DbSet<LkpEntityGroups> LkpEntityGroups { get; set; }
        public virtual DbSet<LkpEntityTypes> LkpEntityTypes { get; set; }
        public virtual DbSet<LkpEnvironments> LkpEnvironments { get; set; }
        public virtual DbSet<LkpFtmsEmailRecipients> LkpFtmsEmailRecipients { get; set; }
        public virtual DbSet<LkpFtmsEmailTasks> LkpFtmsEmailTasks { get; set; }
        public virtual DbSet<LkpFtmsJobTasks> LkpFtmsJobTasks { get; set; }
        public virtual DbSet<LkpFtmsJobs> LkpFtmsJobs { get; set; }
        public virtual DbSet<LkpFtmstaskTypes> LkpFtmstaskTypes { get; set; }
        public virtual DbSet<LkpGroupContacts> LkpGroupContacts { get; set; }
        public virtual DbSet<LkpInvestorFollowup> LkpInvestorFollowup { get; set; }
        public virtual DbSet<LkpLocations> LkpLocations { get; set; }
        public virtual DbSet<LkpMifollowup> LkpMifollowup { get; set; }
        public virtual DbSet<LkpOrganizationHoliday> LkpOrganizationHoliday { get; set; }
        public virtual DbSet<LkpPfueobCompleteMatrix> LkpPfueobCompleteMatrix { get; set; }
        public virtual DbSet<LkpProcessColumnMaps> LkpProcessColumnMaps { get; set; }
        public virtual DbSet<LkpReports> LkpReports { get; set; }
        public virtual DbSet<LkpRoles> LkpRoles { get; set; }
        public virtual DbSet<LkpShippingVendors> LkpShippingVendors { get; set; }
        public virtual DbSet<LkpSubscriptionParameters> LkpSubscriptionParameters { get; set; }
        public virtual DbSet<LkpSuppMenuItemName> LkpSuppMenuItemName { get; set; }
        public virtual DbSet<LkpUitype> LkpUitype { get; set; }
        public virtual DbSet<LkpUsdaclaimTypeMatrix> LkpUsdaclaimTypeMatrix { get; set; }
        public virtual DbSet<LkpUsdafollowup> LkpUsdafollowup { get; set; }
        public virtual DbSet<LkpUsdaimportType> LkpUsdaimportType { get; set; }
        public virtual DbSet<LkpUserAttributes> LkpUserAttributes { get; set; }
        public virtual DbSet<LkpUsers> LkpUsers { get; set; }
        public virtual DbSet<LoginActivities> LoginActivities { get; set; }
        public virtual DbSet<LogoutActivities> LogoutActivities { get; set; }
        public virtual DbSet<OtherParameters> OtherParameters { get; set; }
        public virtual DbSet<Parameters> Parameters { get; set; }
        public virtual DbSet<PrevBusinessEntities> PrevBusinessEntities { get; set; }
        public virtual DbSet<ServerTypes> ServerTypes { get; set; }
        public virtual DbSet<Servers> Servers { get; set; }
        public virtual DbSet<SsisconnectionManagerColumns> SsisconnectionManagerColumns { get; set; }
        public virtual DbSet<SsisconnectionManagers> SsisconnectionManagers { get; set; }
        public virtual DbSet<Ssispackages> Ssispackages { get; set; }
        public virtual DbSet<StoredProcedures> StoredProcedures { get; set; }
        public virtual DbSet<TblAutoDataDistributionDestinations> TblAutoDataDistributionDestinations { get; set; }
        public virtual DbSet<TblAutoDataDistributionParameterValues> TblAutoDataDistributionParameterValues { get; set; }
        public virtual DbSet<TblClientContacts> TblClientContacts { get; set; }
        public virtual DbSet<TblClientPdfcompression> TblClientPdfcompression { get; set; }
        public virtual DbSet<TblCntlTabControl> TblCntlTabControl { get; set; }
        public virtual DbSet<TblControlInvestorGroup> TblControlInvestorGroup { get; set; }
        public virtual DbSet<TblControlInvestors> TblControlInvestors { get; set; }
        public virtual DbSet<TblEntityGroupContacts> TblEntityGroupContacts { get; set; }
        public virtual DbSet<TblProcesses> TblProcesses { get; set; }
        public virtual DbSet<TblSubscriptionInstance> TblSubscriptionInstance { get; set; }
        public virtual DbSet<TblSubscriptionUser> TblSubscriptionUser { get; set; }
        public virtual DbSet<TblSubscriptionUserParameters> TblSubscriptionUserParameters { get; set; }
        public virtual DbSet<TblSubscriptionsDataDriven> TblSubscriptionsDataDriven { get; set; }
        public virtual DbSet<TblUserEmailSignature> TblUserEmailSignature { get; set; }
        public virtual DbSet<VwClientApplicationAccess> VwClientApplicationAccess { get; set; }
        public virtual DbSet<VwDw1Clients> VwDw1Clients { get; set; }
        public virtual DbSet<VwDwDocumentStatusesSelectableIsSldccab> VwDwDocumentStatusesSelectableIsSldccab { get; set; }
        public virtual DbSet<VwDwDocumentsClaimsBcab> VwDwDocumentsClaimsBcab { get; set; }
        public virtual DbSet<VwDwDocumentsClaimsCab> VwDwDocumentsClaimsCab { get; set; }
        public virtual DbSet<VwDwDocumentsClientUploadsCab> VwDwDocumentsClientUploadsCab { get; set; }
        public virtual DbSet<VwDwDocumentsConventionalCab> VwDwDocumentsConventionalCab { get; set; }
        public virtual DbSet<VwDwDocumentsCustomerFilesCab> VwDwDocumentsCustomerFilesCab { get; set; }
        public virtual DbSet<VwDwDocumentsCwcotcab> VwDwDocumentsCwcotcab { get; set; }
        public virtual DbSet<VwDwDocumentsFnmacab> VwDwDocumentsFnmacab { get; set; }
        public virtual DbSet<VwDwDocumentsIscab> VwDwDocumentsIscab { get; set; }
        public virtual DbSet<VwDwDocumentsJpmcClaimsCab> VwDwDocumentsJpmcClaimsCab { get; set; }
        public virtual DbSet<VwDwDocumentsJpmcP260cab> VwDwDocumentsJpmcP260cab { get; set; }
        public virtual DbSet<VwDwDocumentsLossMitCab> VwDwDocumentsLossMitCab { get; set; }
        public virtual DbSet<VwDwDocumentsP260cab> VwDwDocumentsP260cab { get; set; }
        public virtual DbSet<VwDwDocumentsPfscab> VwDwDocumentsPfscab { get; set; }
        public virtual DbSet<VwDwDocumentsSflscab> VwDwDocumentsSflscab { get; set; }
        public virtual DbSet<VwDwDocumentsTitleCab> VwDwDocumentsTitleCab { get; set; }
        public virtual DbSet<VwDwDocumentsVacab> VwDwDocumentsVacab { get; set; }
        public virtual DbSet<VwExternalClientReportingConfiguredClients> VwExternalClientReportingConfiguredClients { get; set; }
        public virtual DbSet<VwExternalClientReportsDefinitionParameterLevel> VwExternalClientReportsDefinitionParameterLevel { get; set; }
        public virtual DbSet<VwExternalClientReportsDefinitionTopLevel> VwExternalClientReportsDefinitionTopLevel { get; set; }
        public virtual DbSet<VwGenerateFreqTypeValues> VwGenerateFreqTypeValues { get; set; }
        public virtual DbSet<VwGenerateFrequencyIntervalRelativeWeekValues> VwGenerateFrequencyIntervalRelativeWeekValues { get; set; }
        public virtual DbSet<VwGenerateMonthlyRelativeFrequencyIntervals> VwGenerateMonthlyRelativeFrequencyIntervals { get; set; }
        public virtual DbSet<VwGenerateRunSessionValues> VwGenerateRunSessionValues { get; set; }
        public virtual DbSet<VwGenerateWeeklyFreqIntervalDayOfWeekValues> VwGenerateWeeklyFreqIntervalDayOfWeekValues { get; set; }
        public virtual DbSet<VwUsers> VwUsers { get; set; }
        public virtual DbSet<WebServiceDocuwareInstances> WebServiceDocuwareInstances { get; set; }
        public virtual DbSet<WebServiceDocuwareInstancesBak> WebServiceDocuwareInstancesBak { get; set; }
        public virtual DbSet<WebServiceTypes> WebServiceTypes { get; set; }
        public virtual DbSet<WebServices> WebServices { get; set; }
        public virtual DbSet<XmlExtractionClaimTypeConfig> XmlExtractionClaimTypeConfig { get; set; }
        public virtual DbSet<XrefAppClientReportProcedureParameterValues> XrefAppClientReportProcedureParameterValues { get; set; }
        public virtual DbSet<XrefApplicationClientReports> XrefApplicationClientReports { get; set; }
        public virtual DbSet<XrefApplicationRoles> XrefApplicationRoles { get; set; }
        public virtual DbSet<XrefApplicationUser> XrefApplicationUser { get; set; }
        public virtual DbSet<XrefApplicationsClients> XrefApplicationsClients { get; set; }
        public virtual DbSet<XrefAppplicationUserApplicationRole> XrefAppplicationUserApplicationRole { get; set; }
        public virtual DbSet<XrefBusinessEntityGroup> XrefBusinessEntityGroup { get; set; }
        public virtual DbSet<XrefClaimsManagementHudclaimsClaimType> XrefClaimsManagementHudclaimsClaimType { get; set; }
        public virtual DbSet<XrefClientInvestorGroupServices> XrefClientInvestorGroupServices { get; set; }
        public virtual DbSet<XrefClientMicompanyServices> XrefClientMicompanyServices { get; set; }
        public virtual DbSet<XrefClientUsdaclaimScope> XrefClientUsdaclaimScope { get; set; }
        public virtual DbSet<XrefClientsUsers> XrefClientsUsers { get; set; }
        public virtual DbSet<XrefControlInvestorInvestorGroup> XrefControlInvestorInvestorGroup { get; set; }
        public virtual DbSet<XrefEntityGroupUserAssignment> XrefEntityGroupUserAssignment { get; set; }
        public virtual DbSet<XrefFtmsTaskEmailRecipients> XrefFtmsTaskEmailRecipients { get; set; }
        public virtual DbSet<XrefProcessUserEmail> XrefProcessUserEmail { get; set; }
        public virtual DbSet<XrefProcessesClients> XrefProcessesClients { get; set; }
        public virtual DbSet<XrefReportProcedures> XrefReportProcedures { get; set; }
        public virtual DbSet<XrefReportRecipients> XrefReportRecipients { get; set; }
        public virtual DbSet<XrefStoredProcedureParameters> XrefStoredProcedureParameters { get; set; }
        public virtual DbSet<XrefSuppMenuItemClaimType> XrefSuppMenuItemClaimType { get; set; }
        public virtual DbSet<XrefUserReportRecipients> XrefUserReportRecipients { get; set; }
        public virtual DbSet<XrefUserUserAttributes> XrefUserUserAttributes { get; set; }
        public virtual DbSet<XrefVaTocExcludedClients> XrefVaTocExcludedClients { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=vm-sql1-dev.dev.crfs.crfservices.com\\cms_d;Initial Catalog=ApplicationConfiguration;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ApplicationAliases>(entity =>
            {
                entity.HasKey(e => e.ApplicationAliasId);

                entity.HasIndex(e => e.ApplicationAlias)
                    .HasName("UK1_ApplicationAliases_ApplicationAlias")
                    .IsUnique();

                entity.Property(e => e.ApplicationAliasId).HasColumnName("ApplicationAliasID");

                entity.Property(e => e.ApplicationAlias)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.EnterdByUserId).HasColumnName("EnterdByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.Application)
                    .WithMany(p => p.ApplicationAliases)
                    .HasForeignKey(d => d.ApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_ApplicationAliases_lkp_Applications");
            });

            modelBuilder.Entity<ConfigurationSettings>(entity =>
            {
                entity.HasKey(e => e.SettingId)
                    .HasName("PK__Configur__54372AFDD927267A");

                entity.Property(e => e.SettingId).HasColumnName("SettingID");

                entity.Property(e => e.Application)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Description).IsUnicode(false);

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.SettingName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SettingValue)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<DataTypes>(entity =>
            {
                entity.HasKey(e => e.DataTypeId);

                entity.HasComment("Empty table. Possible removal.");

                entity.HasIndex(e => e.DataTypeName)
                    .HasName("UK1_DataTypes")
                    .IsUnique();

                entity.Property(e => e.DataTypeId).HasColumnName("DataTypeID");

                entity.Property(e => e.DataTypeName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Length).HasColumnName("length");

                entity.Property(e => e.Precision).HasColumnName("precision");

                entity.Property(e => e.Scale).HasColumnName("scale");
            });

            modelBuilder.Entity<DatabaseInstanceDatabases>(entity =>
            {
                entity.HasKey(e => e.DatabaseInstanceDatabaseId);

                entity.HasComment("Table that contains Database and Database Instance IDs.");

                entity.Property(e => e.DatabaseInstanceDatabaseId).HasColumnName("DatabaseInstanceDatabaseID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.DatabaseId).HasColumnName("DatabaseID");

                entity.Property(e => e.DatabaseInstanceId).HasColumnName("DatabaseInstanceID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.Database)
                    .WithMany(p => p.DatabaseInstanceDatabases)
                    .HasForeignKey(d => d.DatabaseId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_DatabaseInstanceDatabases_Databases");

                entity.HasOne(d => d.DatabaseInstance)
                    .WithMany(p => p.DatabaseInstanceDatabases)
                    .HasForeignKey(d => d.DatabaseInstanceId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_DatabaseInstanceDatabases_DatabaseInstances");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.DatabaseInstanceDatabasesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_DatabaseInstanceDatabases_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.DatabaseInstanceDatabasesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_DatabaseInstanceDatabases_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<DatabaseInstances>(entity =>
            {
                entity.HasKey(e => e.DatabaseInstanceId);

                entity.HasComment("Table that lists the various server connections for Sql Server.");

                entity.Property(e => e.DatabaseInstanceId).HasColumnName("DatabaseInstanceID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.DatabaseInstanceName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ServerId).HasColumnName("ServerID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.DatabaseInstancesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_DatabaseInstances_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.DatabaseInstancesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_DatabaseInstances_lkp_Users_LastUpdateUserID");

                entity.HasOne(d => d.Server)
                    .WithMany(p => p.DatabaseInstances)
                    .HasForeignKey(d => d.ServerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_DatabaseInstances_Servers");
            });

            modelBuilder.Entity<Databases>(entity =>
            {
                entity.HasKey(e => e.DatabaseId);

                entity.HasComment("Table that lists the various database names in each instance.");

                entity.Property(e => e.DatabaseId).HasColumnName("DatabaseID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.DatabaseName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.DatabasesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_Databases_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.DatabasesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_Databases_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<DeliveryEndPoints>(entity =>
            {
                entity.HasKey(e => e.DeliveryEndPointId)
                    .HasName("DeliveryEndPoints_PK");

                entity.HasIndex(e => e.ApplicationClientReportId)
                    .HasName("IX_FK1_DeliveryEndPoints");

                entity.HasIndex(e => e.DeliveryMethodId)
                    .HasName("IX_FK2_DeliveryEndPoints");

                entity.HasIndex(e => new { e.ApplicationClientReportId, e.DeliveryMethodId, e.DeliveryPointValue })
                    .HasName("UK1_DeliveryEndPoints_ReportMethodValue")
                    .IsUnique();

                entity.Property(e => e.DeliveryEndPointId).HasColumnName("DeliveryEndPointID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ApplicationClientReportId).HasColumnName("ApplicationClientReportID");

                entity.Property(e => e.ConversionDataType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DeliveryMethodId).HasColumnName("DeliveryMethodID");

                entity.Property(e => e.DeliveryPointValue)
                    .IsRequired()
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.ApplicationClientReport)
                    .WithMany(p => p.DeliveryEndPoints)
                    .HasForeignKey(d => d.ApplicationClientReportId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_DeliveryEndPoints_xref_ApplicationClientReports");

                entity.HasOne(d => d.DeliveryMethod)
                    .WithMany(p => p.DeliveryEndPoints)
                    .HasForeignKey(d => d.DeliveryMethodId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_DeliveryEndPoints_DeliveryMethods");
            });

            modelBuilder.Entity<DeliveryFormats>(entity =>
            {
                entity.HasKey(e => e.DeliveryFormatId);

                entity.HasIndex(e => e.DeliveryFormatName)
                    .HasName("UK1_DeliveryFormats")
                    .IsUnique();

                entity.Property(e => e.DeliveryFormatId).HasColumnName("DeliveryFormatID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.DeliveryFormatName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.FileExtension)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.TextQualifier)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.DeliveryFormatsEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_DeliveryFormats_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.DeliveryFormatsLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_DeliveryFormats_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<DeliveryMethods>(entity =>
            {
                entity.HasKey(e => e.DeliveryMethodId)
                    .HasName("DeliveryMethods_PK");

                entity.HasIndex(e => e.DeliveryMethodCode)
                    .HasName("UK1_DeliveryMethods_DeliveryMethodCode")
                    .IsUnique();

                entity.Property(e => e.DeliveryMethodId).HasColumnName("DeliveryMethodID");

                entity.Property(e => e.DeliveryMethodCode)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.DeliveryMethodDescription)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");
            });

            modelBuilder.Entity<DocuWareCabinetDocumentStatuses>(entity =>
            {
                entity.HasKey(e => e.DocuWareCabinetDocumentStatusId);

                entity.Property(e => e.DocuWareCabinetDocumentStatusId).HasColumnName("DocuWareCabinetDocumentStatusID");

                entity.Property(e => e.DocumentStatusId).HasColumnName("DocumentStatusID");

                entity.Property(e => e.DocuwareCabinetId).HasColumnName("DocuwareCabinetID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.DocumentStatus)
                    .WithMany(p => p.DocuWareCabinetDocumentStatuses)
                    .HasForeignKey(d => d.DocumentStatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DocuWareCabinetDocumentStatuses_DocuwareDocumentStatuses");

                entity.HasOne(d => d.DocuwareCabinet)
                    .WithMany(p => p.DocuWareCabinetDocumentStatuses)
                    .HasForeignKey(d => d.DocuwareCabinetId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DocuWareCabinetDocumentStatuses_DocuwareCabinets");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.DocuWareCabinetDocumentStatusesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DocuWareCabinetDocumentStatuses_lkp_Users");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.DocuWareCabinetDocumentStatusesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DocuWareCabinetDocumentStatuses_lkp_Users1");
            });

            modelBuilder.Entity<DocumentTypes>(entity =>
            {
                entity.HasKey(e => e.DocumentTypeId);

                entity.HasComment("Table that lists different form types for HUD.");

                entity.Property(e => e.DocumentTypeId).HasColumnName("DocumentTypeID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.DocumentDescription)
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.DocumentName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.DocumentTypesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_DocumentTypes_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.DocumentTypesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_DocumentTypes_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<DocumentTypesDocuwareProcessNames>(entity =>
            {
                entity.HasKey(e => e.DocumentTypeDocuwareProcessNameId);

                entity.HasComment("Table that stores procedures and documents for docuware application.");

                entity.Property(e => e.DocumentTypeDocuwareProcessNameId).HasColumnName("DocumentTypeDocuwareProcessNameID");

                entity.Property(e => e.DocumentTypeId).HasColumnName("DocumentTypeID");

                entity.Property(e => e.DocuwareProcessNameId).HasColumnName("DocuwareProcessNameID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.DocumentType)
                    .WithMany(p => p.DocumentTypesDocuwareProcessNames)
                    .HasForeignKey(d => d.DocumentTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_DocumentTypesDocuwareProcessNames_DocumentTypes");

                entity.HasOne(d => d.DocuwareProcessName)
                    .WithMany(p => p.DocumentTypesDocuwareProcessNames)
                    .HasForeignKey(d => d.DocuwareProcessNameId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_DocumentTypesDocuwareProcessNames_DocuwareProcessNames");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.DocumentTypesDocuwareProcessNamesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_DocumentTypesDocuwareProcessNames_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.DocumentTypesDocuwareProcessNamesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_DocumentTypesDocuwareProcessNames_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<DocuwareCabinetApplicationClients>(entity =>
            {
                entity.HasKey(e => e.DocuwareCabinetApplicationClientId);

                entity.HasComment("Empty table. Used by Document Types, Docuware Process Names, and Users(lookup) table. Also utilized by 'DWLocator_EndpointRequest' stored procedure.");

                entity.Property(e => e.DocuwareCabinetApplicationClientId).HasColumnName("DocuwareCabinetApplicationClientID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ApplicationClientId).HasColumnName("ApplicationClientID");

                entity.Property(e => e.DocuwareCabinetId).HasColumnName("DocuwareCabinetID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdteUserId).HasColumnName("LastUpdteUserID");

                entity.Property(e => e.LastpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.HasOne(d => d.ApplicationClient)
                    .WithMany(p => p.DocuwareCabinetApplicationClients)
                    .HasForeignKey(d => d.ApplicationClientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_DocuwareCabinetApplicationClients_xref_ApplicationsClients");

                entity.HasOne(d => d.DocuwareCabinet)
                    .WithMany(p => p.DocuwareCabinetApplicationClients)
                    .HasForeignKey(d => d.DocuwareCabinetId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_DocuwareCabinetApplicationClients_DocuwareCabinets");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.DocuwareCabinetApplicationClientsEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_DocuwareCabinetApplicationClients_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdteUser)
                    .WithMany(p => p.DocuwareCabinetApplicationClientsLastUpdteUser)
                    .HasForeignKey(d => d.LastUpdteUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_DocuwareCabinetApplicationClients_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<DocuwareCabinetDocumentTypes>(entity =>
            {
                entity.HasKey(e => e.DocuwareCabinetDocumentTypeId);

                entity.HasComment("Table that stores information about Docuware Cabinets and Document ID's.");

                entity.Property(e => e.DocuwareCabinetDocumentTypeId).HasColumnName("DocuwareCabinetDocumentTypeID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.DocumentTypeId).HasColumnName("DocumentTypeID");

                entity.Property(e => e.DocuwareCabinetId).HasColumnName("DocuwareCabinetID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.DocumentType)
                    .WithMany(p => p.DocuwareCabinetDocumentTypes)
                    .HasForeignKey(d => d.DocumentTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_DocuwareCabinetDocumentTypes_DocumentTypes");

                entity.HasOne(d => d.DocuwareCabinet)
                    .WithMany(p => p.DocuwareCabinetDocumentTypes)
                    .HasForeignKey(d => d.DocuwareCabinetId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_DocuwareCabinetDocumentTypes_DocuwareCabinets");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.DocuwareCabinetDocumentTypesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_DocuwareCabinetDocumentTypes_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.DocuwareCabinetDocumentTypesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_DocuwareCabinetDocumentTypes_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<DocuwareCabinets>(entity =>
            {
                entity.HasKey(e => e.DocuwareCabinetId);

                entity.HasComment("Table that stores information about Docuware Cabinets. ");

                entity.Property(e => e.DocuwareCabinetId).HasColumnName("DocuwareCabinetID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.DocuwareCabinetName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.DocuwareCabinetsEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_DocuwareCabinets_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.DocuwareCabinetsLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_DocuwareCabinets_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<DocuwareColumns>(entity =>
            {
                entity.HasKey(e => e.DocuwareColumnId);

                entity.HasComment("Table that contains information about Docuware Cabinets and Cabinet IDs.");

                entity.HasIndex(e => e.ColumnName)
                    .HasName("UK1_DocuwareColumns_ColumnName")
                    .IsUnique();

                entity.Property(e => e.DocuwareColumnId).HasColumnName("DocuwareColumnID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ColumnName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.DocuwareColumnsEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_DocuwareColumns_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.DocuwareColumnsLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_DocuwareColumns_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<DocuwareDocumentStatuses>(entity =>
            {
                entity.HasKey(e => e.DocumentStatusId)
                    .HasName("PK__DocuwareDocumentStatuses_StatusID");

                entity.Property(e => e.DocumentStatusId).HasColumnName("DocumentStatusID");

                entity.Property(e => e.DocumentStatusName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.DocuwareDocumentStatusesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull);

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.DocuwareDocumentStatusesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<DocuwareInstanceDatabaseInstanceDatabases>(entity =>
            {
                entity.HasKey(e => e.DocuwareInstanceDatabaseInstanceDatabaseId);

                entity.HasComment("Table that lists Docuware Database instance information. ");

                entity.Property(e => e.DocuwareInstanceDatabaseInstanceDatabaseId).HasColumnName("DocuwareInstanceDatabaseInstanceDatabaseID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.DatabaseId).HasColumnName("DatabaseID");

                entity.Property(e => e.DatabaseInstanceId).HasColumnName("DatabaseInstanceID");

                entity.Property(e => e.DocuwareInstanceId).HasColumnName("DocuwareInstanceID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.Database)
                    .WithMany(p => p.DocuwareInstanceDatabaseInstanceDatabases)
                    .HasForeignKey(d => d.DatabaseId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_DocuwareInstanceDatabaseInstanceDatabases_Databases");

                entity.HasOne(d => d.DatabaseInstance)
                    .WithMany(p => p.DocuwareInstanceDatabaseInstanceDatabases)
                    .HasForeignKey(d => d.DatabaseInstanceId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_DocuwareInstanceDatabaseInstanceDatabases_DatabaseInstances");

                entity.HasOne(d => d.DocuwareInstance)
                    .WithMany(p => p.DocuwareInstanceDatabaseInstanceDatabases)
                    .HasForeignKey(d => d.DocuwareInstanceId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_DocuwareInstanceDatabaseInstanceDatabases_DocuwareInstances");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.DocuwareInstanceDatabaseInstanceDatabasesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_DocuwareInstanceDatabaseInstanceDatabases_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.DocuwareInstanceDatabaseInstanceDatabasesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK5_DocuwareInstanceDatabaseInstanceDatabases_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<DocuwareInstanceDocuwareCabinetColumns>(entity =>
            {
                entity.HasKey(e => e.DocuwareInstanceDocuwareCabinetColumnId);

                entity.HasComment("Table that lists Douware Column and Docuware Cabinet IDs. Utilized by procedure 'DWLocator_EndpointRequest' which connects to a document storage web service.");

                entity.Property(e => e.DocuwareInstanceDocuwareCabinetColumnId).HasColumnName("DocuwareInstanceDocuwareCabinetColumnID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.DocuwareColumnId).HasColumnName("DocuwareColumnID");

                entity.Property(e => e.DocuwareInstanceDocuwareCabinetId).HasColumnName("DocuwareInstanceDocuwareCabinetID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.DocuwareColumn)
                    .WithMany(p => p.DocuwareInstanceDocuwareCabinetColumns)
                    .HasForeignKey(d => d.DocuwareColumnId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_DocuwareInstanceDocuwareCabinetColumns_DocuwareColumns");

                entity.HasOne(d => d.DocuwareInstanceDocuwareCabinet)
                    .WithMany(p => p.DocuwareInstanceDocuwareCabinetColumns)
                    .HasForeignKey(d => d.DocuwareInstanceDocuwareCabinetId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_DocuwareInstanceDocuwareCabinetColumns_DocuwareInstanceDocuwareCabinets");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.DocuwareInstanceDocuwareCabinetColumnsEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_DocuwareInstanceDocuwareCabinetColumns_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.DocuwareInstanceDocuwareCabinetColumnsLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_DocuwareInstanceDocuwareCabinetColumns_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<DocuwareInstanceDocuwareCabinets>(entity =>
            {
                entity.HasKey(e => e.DocuwareInstanceDocuwareCabinetId);

                entity.HasComment("Table for Docuware that is also utilized by 'DWLocator_EndpointRequest'. ");

                entity.HasIndex(e => new { e.DocuwareInstanceId, e.DocuwareCabinetId })
                    .HasName("UK1_DocuwareInstanceDocuwareCabinets")
                    .IsUnique();

                entity.Property(e => e.DocuwareInstanceDocuwareCabinetId).HasColumnName("DocuwareInstanceDocuwareCabinetID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.DocuwareCabinetId).HasColumnName("DocuwareCabinetID");

                entity.Property(e => e.DocuwareInstanceId).HasColumnName("DocuwareInstanceID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.DocuwareCabinet)
                    .WithMany(p => p.DocuwareInstanceDocuwareCabinets)
                    .HasForeignKey(d => d.DocuwareCabinetId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_DocuwareInstanceDocuwareCabinets_DocuwareCabinets");

                entity.HasOne(d => d.DocuwareInstance)
                    .WithMany(p => p.DocuwareInstanceDocuwareCabinets)
                    .HasForeignKey(d => d.DocuwareInstanceId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_DocuwareInstanceDocuwareCabinets_DocuwareInstances");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.DocuwareInstanceDocuwareCabinetsEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_DocuwareInstanceDocuwareCabinets_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.DocuwareInstanceDocuwareCabinetsLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_DocuwareInstanceDocuwareCabinets_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<DocuwareInstances>(entity =>
            {
                entity.HasKey(e => e.DocuwareInstanceId);

                entity.HasComment("Table that lists the Various instances of Docuware.");

                entity.Property(e => e.DocuwareInstanceId).HasColumnName("DocuwareInstanceID");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.DocuwareName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ServerId).HasColumnName("ServerID");

                entity.HasOne(d => d.Application)
                    .WithMany(p => p.DocuwareInstances)
                    .HasForeignKey(d => d.ApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_DocuwareInstances_lkp_Applications");

                entity.HasOne(d => d.Server)
                    .WithMany(p => p.DocuwareInstances)
                    .HasForeignKey(d => d.ServerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_DocuwareInstances_Servers");
            });

            modelBuilder.Entity<DocuwareInstancesBak>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("DocuwareInstances_bak");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.DocuwareInstanceId).HasColumnName("DocuwareInstanceID");

                entity.Property(e => e.DocuwareName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ServerId).HasColumnName("ServerID");
            });

            modelBuilder.Entity<DocuwareProcessNames>(entity =>
            {
                entity.HasKey(e => e.DocuwareProcessNameId);

                entity.HasComment("Table that contains list of processes for the Docuware application.");

                entity.Property(e => e.DocuwareProcessNameId).HasColumnName("DocuwareProcessNameID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.DocuwareProcessName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.DocuwareProcessNamesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_DocuwareProcessNames_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.DocuwareProcessNamesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_DocuwareProcessNames_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<EdiauthTruthSources>(entity =>
            {
                entity.HasKey(e => e.EdiauthTruthSourceId);

                entity.ToTable("EDIAuthTruthSources");

                entity.HasComment("Table that is utilized by stored procedure 'ufn_EDIAuthMatrixByClaimType' that generates a truth table of claim conditions. ");

                entity.Property(e => e.EdiauthTruthSourceId).HasColumnName("EDIAuthTruthSourceID");

                entity.Property(e => e.BitName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimTypeName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.ErrorMessage)
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.SubmitPart)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Hoadestinations>(entity =>
            {
                entity.HasKey(e => e.HoadestinationId);

                entity.ToTable("HOADestinations");

                entity.HasIndex(e => new { e.ClientId, e.BusinessEntityId, e.DirectionId })
                    .HasName("UK1_HOADestinations_ClientIDBusinessEntityIDDirectionID")
                    .IsUnique();

                entity.Property(e => e.HoadestinationId).HasColumnName("HOADestinationID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ArchiveFolder)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.DirectionId).HasColumnName("DirectionID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.Sftpfolder)
                    .HasColumnName("SFTPFolder")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SourceFolder)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SourceHost)
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.TargetFolder)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.TargetHost)
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.HasOne(d => d.BusinessEntity)
                    .WithMany(p => p.Hoadestinations)
                    .HasForeignKey(d => d.BusinessEntityId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_HOADestinations_lkp_BusinessEntities");

                entity.HasOne(d => d.Client)
                    .WithMany(p => p.Hoadestinations)
                    .HasForeignKey(d => d.ClientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_HOADestinations_lkp_Clients");

                entity.HasOne(d => d.Direction)
                    .WithMany(p => p.Hoadestinations)
                    .HasForeignKey(d => d.DirectionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_HOADestinations_lkp_Directions");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.HoadestinationsEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_HOADestinations_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.HoadestinationsLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK5_HOADestinations_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<InterimGroupContactsConversionControl>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("interim_GroupContacts_ConversionControl");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.GroupContactId).HasColumnName("GroupContactID");

                entity.Property(e => e.GroupId).HasColumnName("GroupID");

                entity.Property(e => e.LegacyFormId).HasColumnName("LegacyFormID");

                entity.Property(e => e.LegacyGroupId).HasColumnName("LegacyGroupID");
            });

            modelBuilder.Entity<LaClientCalculationDefinitions>(entity =>
            {
                entity.HasKey(e => e.ClientCalculationDefinitionId)
                    .HasName("LA_ClientCalculationDefinitions_PK");

                entity.ToTable("LA_ClientCalculationDefinitions");

                entity.HasComment("A calculation table for the Loss analysis application Calculations for 60 day interest, Uncontrollable Losses, and Controllable Losses.");

                entity.HasIndex(e => e.ClientId)
                    .HasName("UK1_LA_ClientCalculationDefinitions_ClientID")
                    .IsUnique();

                entity.Property(e => e.ClientCalculationDefinitionId).HasColumnName("ClientCalculationDefinitionID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.SixtyDayInterestCalculationId).HasColumnName("SixtyDayInterestCalculationID");

                entity.Property(e => e.TotalControllableLossesCalculationId).HasColumnName("TotalControllableLossesCalculationID");

                entity.Property(e => e.TotalUncontrollableLossesCalculationId).HasColumnName("TotalUncontrollableLossesCalculationID");

                entity.HasOne(d => d.Client)
                    .WithOne(p => p.LaClientCalculationDefinitions)
                    .HasForeignKey<LaClientCalculationDefinitions>(d => d.ClientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_LA_ClientCalculationDefinitions_lkp_Clients");

                entity.HasOne(d => d.SixtyDayInterestCalculation)
                    .WithMany(p => p.LaClientCalculationDefinitions)
                    .HasForeignKey(d => d.SixtyDayInterestCalculationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_LA_ClientCalculationDefinitions_LA_SixtyDayInterestCalculations");

                entity.HasOne(d => d.TotalControllableLossesCalculation)
                    .WithMany(p => p.LaClientCalculationDefinitions)
                    .HasForeignKey(d => d.TotalControllableLossesCalculationId)
                    .HasConstraintName("FK4_LA_ClientCalculationDefinitions_LA_TotalControllableLossesCalculations");

                entity.HasOne(d => d.TotalUncontrollableLossesCalculation)
                    .WithMany(p => p.LaClientCalculationDefinitions)
                    .HasForeignKey(d => d.TotalUncontrollableLossesCalculationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_LA_ClientCalculationDefinitions_LA_TotalUncontrollableLossesCalculations");
            });

            modelBuilder.Entity<LaSixtyDayInterestCalculations>(entity =>
            {
                entity.HasKey(e => e.SixtyDayInterestCalculationId)
                    .HasName("LA_SixtyDayInterestCalculations_PK");

                entity.ToTable("LA_SixtyDayInterestCalculations");

                entity.HasComment("A calculation table for the Loss analysis application. Calculation for 60 day interest.");

                entity.HasIndex(e => e.CalculationName)
                    .HasName("UK1_SixtyDayInterestCalculationName")
                    .IsUnique();

                entity.Property(e => e.SixtyDayInterestCalculationId).HasColumnName("SixtyDayInterestCalculationID");

                entity.Property(e => e.CalculationDescription)
                    .IsRequired()
                    .HasMaxLength(512)
                    .IsUnicode(false);

                entity.Property(e => e.CalculationName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LaTotalControllableLossesCalculations>(entity =>
            {
                entity.HasKey(e => e.TotalControllableLossesCalculationId)
                    .HasName("LA_TotalControllableLossesCalculations_PK");

                entity.ToTable("LA_TotalControllableLossesCalculations");

                entity.HasComment("A calculation table for the Loss analysis application. Calculation for Total Controllable Losses.");

                entity.HasIndex(e => e.CalculationName)
                    .HasName("UK1_TotalControllableLossesCalculationName")
                    .IsUnique();

                entity.Property(e => e.TotalControllableLossesCalculationId).HasColumnName("TotalControllableLossesCalculationID");

                entity.Property(e => e.CalculationDescription)
                    .IsRequired()
                    .HasMaxLength(512)
                    .IsUnicode(false);

                entity.Property(e => e.CalculationName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LaTotalUncontrollableLossesCalculations>(entity =>
            {
                entity.HasKey(e => e.TotalUncontrollableLossesCalculationId)
                    .HasName("LA_TotalUncontrollableLossesCalculations_PK");

                entity.ToTable("LA_TotalUncontrollableLossesCalculations");

                entity.HasComment("A calculation table for the Loss analysis application. Calculation for Total  Uncontrollable Losses.");

                entity.HasIndex(e => e.CalculationName)
                    .HasName("UK1_TotalUncontrollableLossesCalculationName")
                    .IsUnique();

                entity.Property(e => e.TotalUncontrollableLossesCalculationId).HasColumnName("TotalUncontrollableLossesCalculationID");

                entity.Property(e => e.CalculationDescription)
                    .IsRequired()
                    .HasMaxLength(512)
                    .IsUnicode(false);

                entity.Property(e => e.CalculationName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpApplicationClientDestinations>(entity =>
            {
                entity.HasKey(e => e.ApplicationClientDestinationId);

                entity.ToTable("lkp_ApplicationClientDestinations");

                entity.HasComment("A lookup table. Contains three records. Includes Application Client Destination ID field.");

                entity.Property(e => e.ApplicationClientDestinationId).HasColumnName("ApplicationClientDestinationID");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.ArchiveLocation)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.ArchiveTypeId).HasColumnName("ArchiveTypeID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.DelieveryTypeId).HasColumnName("DelieveryTypeID");

                entity.Property(e => e.DeliveryLocation)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.EneredDate).HasColumnType("datetime");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.Application)
                    .WithMany(p => p.LkpApplicationClientDestinations)
                    .HasForeignKey(d => d.ApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK5_lkp_ApplicationClientDestinations_lkp_Applications");

                entity.HasOne(d => d.ArchiveType)
                    .WithMany(p => p.LkpApplicationClientDestinationsArchiveType)
                    .HasForeignKey(d => d.ArchiveTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK7_lkp_ApplicationClientDestinations_lkp_DestinationTypes_Archive");

                entity.HasOne(d => d.DelieveryType)
                    .WithMany(p => p.LkpApplicationClientDestinationsDelieveryType)
                    .HasForeignKey(d => d.DelieveryTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK6_lkp_ApplicationClientDestinations_lkp_DestionationTypes_Destionation");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.LkpApplicationClientDestinationsEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_lkp_ApplicationClientDestinations_lkp_Users_EnteredBy");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.LkpApplicationClientDestinationsLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_lkp_ApplicationClientDestinations_lkp_Users_LastUpdate");
            });

            modelBuilder.Entity<LkpApplications>(entity =>
            {
                entity.HasKey(e => e.ApplicationId)
                    .HasName("PK_Applications");

                entity.ToTable("lkp_Applications");

                entity.HasComment("A lookup table that lists User levels and roles within the application.");

                entity.HasIndex(e => e.ApplicationName)
                    .HasName("UK1_lkp_Applications_ApplicationName")
                    .IsUnique();

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.ApplicationName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ApplicationUrl)
                    .HasColumnName("ApplicationURL")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.CmsformId).HasColumnName("CMSFormID");

                entity.Property(e => e.EffectiveFromDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.EffectiveToDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("('12/31/2078')");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.LkpApplicationsEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId);

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.LkpApplicationsLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId);
            });

            modelBuilder.Entity<LkpAutoDataDistributionParameters>(entity =>
            {
                entity.HasKey(e => e.AutoDataDistributionParameterId);

                entity.ToTable("lkp_AutoDataDistributionParameters");

                entity.HasComment("A lookup table that lists parameter names for SSIS.");

                entity.Property(e => e.AutoDataDistributionParameterId).HasColumnName("AutoDataDistributionParameterID");

                entity.Property(e => e.Comment).IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ParameterName)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpBusinessEntities>(entity =>
            {
                entity.HasKey(e => e.BusinessEntityId);

                entity.ToTable("lkp_BusinessEntities");

                entity.HasComment("A lookup table that lists Business entities.");

                entity.HasIndex(e => new { e.BusinessEntityId, e.BusinessEntityName })
                    .HasName("IDX_BusinessEntities_BusinessEntityName");

                entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.BusinessEntityName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EffectiveFromDate).HasColumnType("date");

                entity.Property(e => e.EffectiveToDate).HasColumnType("date");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.EntityTypeId).HasColumnName("EntityTypeID");

                entity.HasOne(d => d.Application)
                    .WithMany(p => p.LkpBusinessEntities)
                    .HasForeignKey(d => d.ApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_lkp_BusinessEntities_lkp_Applications");

                entity.HasOne(d => d.EntityType)
                    .WithMany(p => p.LkpBusinessEntities)
                    .HasForeignKey(d => d.EntityTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_lkp_BusinessEntities_lkp_EntityTypes");
            });

            modelBuilder.Entity<LkpCategories>(entity =>
            {
                entity.HasKey(e => e.CategoryId)
                    .HasName("lkp_Categories_PK");

                entity.ToTable("lkp_Categories");

                entity.HasComment("Application Categories");

                entity.HasIndex(e => e.CategoryName)
                    .HasName("UK1_CategoryName")
                    .IsUnique();

                entity.Property(e => e.CategoryId).HasColumnName("CategoryID");

                entity.Property(e => e.CategoryName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DateEntered)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DateUpdated)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<LkpClaimGroup>(entity =>
            {
                entity.ToTable("lkp_ClaimGroup");

                entity.Property(e => e.Code1)
                    .HasMaxLength(512)
                    .IsUnicode(false);

                entity.Property(e => e.Code2)
                    .HasMaxLength(512)
                    .IsUnicode(false);

                entity.Property(e => e.DateCreated).HasColumnType("datetime");

                entity.Property(e => e.DateUpdated).HasColumnType("datetime");

                entity.Property(e => e.Destination)
                    .HasMaxLength(512)
                    .IsUnicode(false);

                entity.Property(e => e.ErrorEmail)
                    .HasMaxLength(512)
                    .IsUnicode(false);

                entity.Property(e => e.FhaclaimGroup).HasColumnName("FHAClaimGroup");

                entity.Property(e => e.GroupName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.SendToEmail)
                    .IsRequired()
                    .HasMaxLength(512)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpClientFtpsites>(entity =>
            {
                entity.HasKey(e => e.FtpsiteId)
                    .HasName("PK_lkp_FTMS_FTPJobParameters");

                entity.ToTable("lkp_ClientFTPSites");

                entity.Property(e => e.FtpsiteId).HasColumnName("FTPSiteID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.SftpsiteUrl)
                    .IsRequired()
                    .HasColumnName("SFTPSiteURL")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UserId)
                    .IsRequired()
                    .HasColumnName("UserID")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.Client)
                    .WithMany(p => p.LkpClientFtpsites)
                    .HasForeignKey(d => d.ClientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_lkp_ClientFTPSites_lkp_Clients");
            });

            modelBuilder.Entity<LkpClientPoolClaimScope>(entity =>
            {
                entity.HasKey(e => e.ClientPoolClaimScopeId);

                entity.ToTable("lkp_Client_PoolClaimScope");

                entity.HasComment("A lookup table for the PoolClaimScope ID.");

                entity.HasIndex(e => e.ClientId)
                    .HasName("UK1_lkp_Client_PoolClaimScope")
                    .IsUnique();

                entity.Property(e => e.ClientPoolClaimScopeId).HasColumnName("Client_PoolClaimScopeID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");
            });

            modelBuilder.Entity<LkpClients>(entity =>
            {
                entity.HasKey(e => e.ClientId);

                entity.ToTable("lkp_Clients");

                entity.HasComment("A lookup table that displays Client Names, in addition to their abbreviations. ");

                entity.HasIndex(e => e.ClientAbbreviation)
                    .HasName("UK2_lkp_Clients_ClientAbbreviation")
                    .IsUnique();

                entity.HasIndex(e => e.ClientName)
                    .HasName("UK1_lkp_Clients_ClientName")
                    .IsUnique();

                entity.HasIndex(e => new { e.ClientName, e.ClientAbbreviation })
                    .HasName("UK3_lkp_Clients_ClientName_ClientAbbreviation")
                    .IsUnique();

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.ClientAbbreviation)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ClientDisplayName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ClientLegalName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EffectiveFromDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.EffectiveToDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("('12/31/2015')");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.LkpClientsEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_lkp_Users_lkp_Clients_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.LkpClientsLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_lkp_Users_lkp_Clients_LastUpdateUserID");
            });

            modelBuilder.Entity<LkpContactTypes>(entity =>
            {
                entity.HasKey(e => e.ContactTypeId)
                    .HasName("lkp_ContactTypes_PK");

                entity.ToTable("lkp_ContactTypes");

                entity.HasComment("A one record lookup table that contains the Contact Type ID.");

                entity.HasIndex(e => e.ContactTypeName)
                    .HasName("UK1_lkp_ContactTypes")
                    .IsUnique();

                entity.Property(e => e.ContactTypeId).HasColumnName("ContactTypeID");

                entity.Property(e => e.ContactTypeName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("date");

                entity.Property(e => e.LastUpdateDate).HasColumnType("date");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.LkpContactTypesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_lkp_ContactTypes_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.LkpContactTypesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_lkp_ContactTypes_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<LkpDestinationTypes>(entity =>
            {
                entity.HasKey(e => e.DestinationTypeId)
                    .HasName("PK_lkp_DestionationTypes");

                entity.ToTable("lkp_DestinationTypes");

                entity.HasComment("A one record lookup table for destination types.");

                entity.Property(e => e.DestinationTypeId).HasColumnName("DestinationTypeID");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpDirections>(entity =>
            {
                entity.HasKey(e => e.DirectionId);

                entity.ToTable("lkp_Directions");

                entity.HasIndex(e => e.DirectionName)
                    .HasName("UK1_lkp_Directions_DirectionName")
                    .IsUnique();

                entity.Property(e => e.DirectionId).HasColumnName("DirectionID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.DirectionName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.LkpDirectionsEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_lkp_Directions_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.LkpDirectionsLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_lkp_Directions_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<LkpEmploymentTypes>(entity =>
            {
                entity.HasKey(e => e.EmploymentTypeId);

                entity.ToTable("lkp_EmploymentTypes");

                entity.HasIndex(e => e.EmploymentType)
                    .HasName("UK1_EmploymentTypes_EmploymentType")
                    .IsUnique();

                entity.Property(e => e.EmploymentTypeId).HasColumnName("EmploymentTypeID");

                entity.Property(e => e.EmploymentType)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.LkpEmploymentTypesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_lkp_EmploymentTypes_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.LkpEmploymentTypesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_lkp_EmploymentTypes_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<LkpEndPointAttributes>(entity =>
            {
                entity.HasKey(e => e.EndPointAttributeId);

                entity.ToTable("lkp_EndPointAttributes");

                entity.HasIndex(e => e.DataTypeId)
                    .HasName("IX1_FK1_lkp_EndPointAttributes");

                entity.HasIndex(e => e.EndPointAttributeName)
                    .HasName("UK1_lkp_EndPointAttributes")
                    .IsUnique();

                entity.Property(e => e.EndPointAttributeId).HasColumnName("EndPointAttributeID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.DataTypeId).HasColumnName("DataTypeID");

                entity.Property(e => e.EndPointAttributeName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.InactiveEffectiveDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(CONVERT([datetime],'1/1/1900'))");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.DataType)
                    .WithMany(p => p.LkpEndPointAttributes)
                    .HasForeignKey(d => d.DataTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_lkp_EndPointAttributes_DataTypes");
            });

            modelBuilder.Entity<LkpEntityGroups>(entity =>
            {
                entity.HasKey(e => e.GroupId)
                    .HasName("PK_lkp_Group");

                entity.ToTable("lkp_EntityGroups");

                entity.HasComment("A lookup table for Entity Groups.");

                entity.Property(e => e.GroupId).HasColumnName("GroupID");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.EffectiveFromDate).HasColumnType("date");

                entity.Property(e => e.EffectiveToDate).HasColumnType("date");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.GroupName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.Application)
                    .WithMany(p => p.LkpEntityGroups)
                    .HasForeignKey(d => d.ApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_lkp_EntityGroups_lkp_Applications");
            });

            modelBuilder.Entity<LkpEntityTypes>(entity =>
            {
                entity.HasKey(e => e.EntityTypeId)
                    .HasName("PK_lkp_EntityType");

                entity.ToTable("lkp_EntityTypes");

                entity.HasComment("A lookup table for Entity Types.");

                entity.Property(e => e.EntityTypeId).HasColumnName("EntityTypeID");

                entity.Property(e => e.EffectiveFromDate).HasColumnType("date");

                entity.Property(e => e.EffectiveToDate).HasColumnType("date");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.EntityTypeName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpEnvironments>(entity =>
            {
                entity.HasKey(e => e.EnvironmentId)
                    .HasName("PK_Environments");

                entity.ToTable("lkp_Environments");

                entity.HasComment("A lookup table. Corresponds to DEV, UAT, SIT, OR PROD.");

                entity.HasIndex(e => e.EnvName)
                    .HasName("UK1_lkp_Environments_EnvName")
                    .IsUnique();

                entity.Property(e => e.EnvironmentId).HasColumnName("EnvironmentID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.EnvDescription)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EnvName)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.LkpEnvironmentsEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_lkp_Environments_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.LkpEnvironmentsLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_lkp_Environments_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<LkpFtmsEmailRecipients>(entity =>
            {
                entity.HasKey(e => e.RecipientId)
                    .HasName("PK__FileTransferTasksRecipients_pk_RecipientID");

                entity.ToTable("lkp_FTMS_EmailRecipients");

                entity.HasIndex(e => e.EmailAddress)
                    .HasName("UIX_FileTransferTasksRecipients_EmailAddress")
                    .IsUnique();

                entity.Property(e => e.RecipientId).HasColumnName("RecipientID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.DateEntered)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DateUpdated)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EmailAddress)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.HasOne(d => d.EnteredByNavigation)
                    .WithMany(p => p.LkpFtmsEmailRecipientsEnteredByNavigation)
                    .HasForeignKey(d => d.EnteredBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FileTransferTasksRecipients_EnteredBy_lkpUsers_UserID");

                entity.HasOne(d => d.UpdatedByNavigation)
                    .WithMany(p => p.LkpFtmsEmailRecipientsUpdatedByNavigation)
                    .HasForeignKey(d => d.UpdatedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FileTransferTasksRecipients_UpdatedBy_lkpUsers_UserID");
            });

            modelBuilder.Entity<LkpFtmsEmailTasks>(entity =>
            {
                entity.HasKey(e => e.TaskId)
                    .HasName("PK_lkp_FTMSEmailTasks_TaskID");

                entity.ToTable("lkp_FTMS_EmailTasks");

                entity.Property(e => e.TaskId)
                    .HasColumnName("TaskID")
                    .ValueGeneratedNever();

                entity.Property(e => e.EmailSubject)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EmailText)
                    .IsRequired()
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.HasOne(d => d.Task)
                    .WithOne(p => p.LkpFtmsEmailTasks)
                    .HasForeignKey<LkpFtmsEmailTasks>(d => d.TaskId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_lkp_FTMSEmailTaskProperties_TaskID_lkp_FTMSTasks");
            });

            modelBuilder.Entity<LkpFtmsJobTasks>(entity =>
            {
                entity.HasKey(e => e.TaskId)
                    .HasName("PK__lkp_FTMS__7C6949D1A1B8C9DE");

                entity.ToTable("lkp_FTMS_JobTasks");

                entity.Property(e => e.TaskId).HasColumnName("TaskID");

                entity.Property(e => e.DestinationFolder)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.FtpdeleteAfterPut).HasColumnName("FTPDeleteAfterPut");

                entity.Property(e => e.FtpremoveFolder).HasColumnName("FTPRemoveFolder");

                entity.Property(e => e.JobId).HasColumnName("JobID");

                entity.Property(e => e.RenameLeadingSuppresion)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.RenamePrefix)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RenameSuffix)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SourceFolder)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.SourceMask)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TaskName)
                    .IsRequired()
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.TaskTypeId).HasColumnName("TaskTypeID");

                entity.Property(e => e.ZipFileName)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.HasOne(d => d.TaskType)
                    .WithMany(p => p.LkpFtmsJobTasks)
                    .HasForeignKey(d => d.TaskTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_lkp_FTMSTasks_TaskType_lkp_FTMSTaskTypes");
            });

            modelBuilder.Entity<LkpFtmsJobs>(entity =>
            {
                entity.HasKey(e => e.JobId)
                    .HasName("PK_lkp_FTMS_Jobs_JobID");

                entity.ToTable("lkp_FTMS_Jobs");

                entity.Property(e => e.JobId).HasColumnName("JobID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.EndHour).HasDefaultValueSql("((23))");

                entity.Property(e => e.JobName)
                    .IsRequired()
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.HasOne(d => d.Client)
                    .WithMany(p => p.LkpFtmsJobs)
                    .HasForeignKey(d => d.ClientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_lkp_FTMSJobs_ClientID_lkp_Clients");
            });

            modelBuilder.Entity<LkpFtmstaskTypes>(entity =>
            {
                entity.HasKey(e => e.TaskTypeId)
                    .HasName("PK__lkp_FTMSTaskTypes_TaskTypeID");

                entity.ToTable("lkp_FTMSTaskTypes");

                entity.Property(e => e.TaskTypeId).HasColumnName("TaskTypeID");

                entity.Property(e => e.TaskType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpGroupContacts>(entity =>
            {
                entity.HasKey(e => e.GroupContactId)
                    .HasName("lkp_GroupContacts_PK");

                entity.ToTable("lkp_GroupContacts");

                entity.HasComment("Look-up table. Contains contact names and email addresses of persons outside of CRFS.");

                entity.HasIndex(e => new { e.GroupId, e.ApplicationId, e.EmailAddress })
                    .HasName("UK1_lkp_GroupContacts")
                    .IsUnique();

                entity.Property(e => e.GroupContactId).HasColumnName("GroupContactID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.ContactName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EmailAddress)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.GroupId).HasColumnName("GroupID");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.Application)
                    .WithMany(p => p.LkpGroupContacts)
                    .HasForeignKey(d => d.ApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_lkp_GroupContacts_lkp_Applications_ApplicationID");

                entity.HasOne(d => d.Group)
                    .WithMany(p => p.LkpGroupContacts)
                    .HasForeignKey(d => d.GroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_lkp_GroupContacts_lkp_EntityGroups_GroupID");
            });

            modelBuilder.Entity<LkpInvestorFollowup>(entity =>
            {
                entity.HasKey(e => e.InvestorFollowupId);

                entity.ToTable("lkp_InvestorFollowup");

                entity.HasComment("Investor Tracking application - Payment Followup intervals by investor.  Allows different investors to have unique followup intervals.");

                entity.HasIndex(e => new { e.InvestorId, e.ClaimTypeId })
                    .HasName("UK1_lkp_InvestorFollowup")
                    .IsUnique();

                entity.Property(e => e.InvestorFollowupId).HasColumnName("InvestorFollowupID");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.InvestorId).HasColumnName("InvestorID");

                entity.HasOne(d => d.Investor)
                    .WithMany(p => p.LkpInvestorFollowup)
                    .HasForeignKey(d => d.InvestorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_lkp_InvestorFollowup_tbl_Control_InvestorGroup");
            });

            modelBuilder.Entity<LkpLocations>(entity =>
            {
                entity.HasKey(e => e.LocationId);

                entity.ToTable("lkp_Locations");

                entity.HasIndex(e => e.LocationCode)
                    .HasName("UK1_Table_1_LocationCode")
                    .IsUnique();

                entity.Property(e => e.LocationId).HasColumnName("LocationID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.LocationCode)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.LocationDescription)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpMifollowup>(entity =>
            {
                entity.HasKey(e => e.MifollowupId);

                entity.ToTable("lkp_MIFollowup");

                entity.HasComment("A lookup table that contains the MIFollowupID field.");

                entity.HasIndex(e => new { e.MicompanyId, e.ClaimTypeId })
                    .HasName("UK1_lkp_MIFollowup")
                    .IsUnique();

                entity.Property(e => e.MifollowupId).HasColumnName("MIFollowupID");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.MicompanyId).HasColumnName("MICompanyID");
            });

            modelBuilder.Entity<LkpOrganizationHoliday>(entity =>
            {
                entity.HasKey(e => e.HolidayId)
                    .HasName("PK_OrganizationHoliday");

                entity.ToTable("lkp_OrganizationHoliday");

                entity.HasComment("Holiday schedules for various organizations, including CRFS, FHA, etc.");

                entity.HasIndex(e => new { e.Organization, e.HolidayDate })
                    .HasName("UK1_OrganizationHoliday")
                    .IsUnique();

                entity.Property(e => e.HolidayId)
                    .HasColumnName("HolidayID")
                    .HasComment("Uniquely identifies a holiday date for an organization");

                entity.Property(e => e.HolidayDate)
                    .HasColumnType("smalldatetime")
                    .HasComment("The date a holiday is observed");

                entity.Property(e => e.HolidayDescription)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasComment("Text name of a Holiday.  May indicate the fact that the holiday is the observed date instead of the actual holiday.");

                entity.Property(e => e.Organization)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasComment("Text name of an organization");
            });

            modelBuilder.Entity<LkpPfueobCompleteMatrix>(entity =>
            {
                entity.HasKey(e => e.PfueobCompleteMatrixId);

                entity.ToTable("lkp_PFUEOB_CompleteMatrix");

                entity.HasComment("A lookup table. The stored procedure  'usp_CNTL_PFUEOB_CompleteMatrix' utilizes this table.");

                entity.HasIndex(e => e.Bitvalue)
                    .HasName("UK1_lkp_PFUEOB_CompleteMatrix_BitValue")
                    .IsUnique();

                entity.HasIndex(e => new { e.CancellationDateSet, e.ClaimPaidDateSet, e.ClaimPaidAmountSet, e.DeniedDateSet, e.RecissionDateSet })
                    .HasName("UK2_lkp_PFUEOB_CompleteMatrix_AllBits")
                    .IsUnique();

                entity.Property(e => e.PfueobCompleteMatrixId).HasColumnName("PFUEOB_CompleteMatrixID");

                entity.Property(e => e.AllowPfueobComplete).HasColumnName("Allow_PFUEOB_Complete");

                entity.Property(e => e.Bitvalue).HasColumnName("bitvalue");
            });

            modelBuilder.Entity<LkpProcessColumnMaps>(entity =>
            {
                entity.HasKey(e => e.ProcessColumnMapId)
                    .HasName("lkp_ProcessColumnMaps_PK");

                entity.ToTable("lkp_ProcessColumnMaps");

                entity.HasComment("A lookup table that lists the Process Column Maps.");

                entity.HasIndex(e => new { e.ColumnName, e.ProcessId })
                    .HasName("UK1_lkp_ProcessColumnMaps")
                    .IsUnique();

                entity.Property(e => e.ProcessColumnMapId).HasColumnName("ProcessColumnMapID");

                entity.Property(e => e.ColumnName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ColumnType)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DateEntered)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ProcessId).HasColumnName("ProcessID");
            });

            modelBuilder.Entity<LkpReports>(entity =>
            {
                entity.HasKey(e => e.ReportId);

                entity.ToTable("lkp_Reports");

                entity.HasIndex(e => e.ReportName)
                    .HasName("UK1_lkp_Reports")
                    .IsUnique();

                entity.Property(e => e.ReportId).HasColumnName("ReportID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.InterimCsv)
                    .IsRequired()
                    .HasColumnName("interimCSV")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ReportName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.TabName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.LkpReportsEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_lkp_Reports_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.LkpReportsLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_lkp_Reports_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<LkpRoles>(entity =>
            {
                entity.HasKey(e => e.RoleId);

                entity.ToTable("lkp_Roles");

                entity.HasComment("An empty lookup table.");

                entity.HasIndex(e => e.RoleName)
                    .HasName("UK1_lkp_Roles_RoleName")
                    .IsUnique();

                entity.Property(e => e.RoleId).HasColumnName("RoleID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.LegacyCmsgroupId).HasColumnName("LegacyCMSGroupID");

                entity.Property(e => e.RoleName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.LkpRolesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_lkp_Roles_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.LkpRolesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_lkp_Roles_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<LkpShippingVendors>(entity =>
            {
                entity.HasKey(e => e.ShippingVendorId)
                    .HasName("PK_ShippingVendors");

                entity.ToTable("lkp_ShippingVendors");

                entity.HasComment("A lookup table for both shipping vendors.(UPS and FedEx)");

                entity.Property(e => e.ShippingVendorId).HasColumnName("ShippingVendorID");

                entity.Property(e => e.EffectiveFromDate).HasColumnType("date");

                entity.Property(e => e.EffectiveToDate).HasColumnType("date");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.ShippingVendorName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpSubscriptionParameters>(entity =>
            {
                entity.HasKey(e => e.ParameterId)
                    .HasName("PK__lkp_Subscription_Parameters");

                entity.ToTable("lkp_Subscription_Parameters");

                entity.HasComment(@"Parameter types used in Stored procedures feeding reports.
Example @ClientID -> ClientID for parameter name.
These will be used in the vw_SubscriptionQuery view.
Simple view modification needed to use new parameters. ");

                entity.Property(e => e.ParameterId).HasColumnName("ParameterID");

                entity.Property(e => e.ParameterDataType)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ParameterName)
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpSuppMenuItemName>(entity =>
            {
                entity.HasKey(e => e.SuppMenuItemNameId);

                entity.ToTable("lkp_SuppMenuItemName");

                entity.HasComment("all the menu items associated with creating supp in CMS");

                entity.Property(e => e.SuppMenuItemNameId).HasColumnName("SuppMenuItemNameID");

                entity.Property(e => e.MenuItemDescription)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.SuppMenuItemName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasComment("name matches menuitem in cms");
            });

            modelBuilder.Entity<LkpUitype>(entity =>
            {
                entity.HasKey(e => e.Code)
                    .HasName("PK__lkp_UITy__A25C5AA62B76CE8C");

                entity.ToTable("lkp_UIType");

                entity.Property(e => e.Code)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Description)
                    .HasMaxLength(200)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpUsdaclaimTypeMatrix>(entity =>
            {
                entity.HasKey(e => e.UsdaclaimTypeMatrixId);

                entity.ToTable("lkp_USDAClaimTypeMatrix");

                entity.HasIndex(e => e.BitValue)
                    .HasName("UK2_lkp_USDAClaimTypeMatrix")
                    .IsUnique();

                entity.HasIndex(e => new { e.UsdaMraClaim, e.UsdaSafpClaim, e.UsdaGeneralClaim })
                    .HasName("UK1_lkp_USDAClaimTypeMatrix")
                    .IsUnique();

                entity.Property(e => e.UsdaclaimTypeMatrixId).HasColumnName("USDAClaimTypeMatrixID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.Result)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UsdaGeneralClaim).HasColumnName("USDA_general_Claim");

                entity.Property(e => e.UsdaMraClaim).HasColumnName("USDA_MRA_Claim");

                entity.Property(e => e.UsdaSafpClaim).HasColumnName("USDA_SAFP_Claim");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.LkpUsdaclaimTypeMatrixEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_lkp_USDAClaimTypeMatrix_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.LkpUsdaclaimTypeMatrixLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_lkp_USDAClaimTypeMatrix_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<LkpUsdafollowup>(entity =>
            {
                entity.HasKey(e => e.UsdafollowupId);

                entity.ToTable("lkp_USDAFollowup");

                entity.HasIndex(e => e.ClaimTypeId)
                    .HasName("UK1_lkp_USDAFollowup")
                    .IsUnique();

                entity.Property(e => e.UsdafollowupId).HasColumnName("USDAFollowupID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.LkpUsdafollowupEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_lkp_USDAFollowup_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.LkpUsdafollowupLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_lkp_USDAFollowup_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<LkpUsdaimportType>(entity =>
            {
                entity.HasKey(e => e.UsdaimportTypeId);

                entity.ToTable("lkp_USDAImportType");

                entity.HasComment("Lookup table based on Claim types. If the Claim is a MI, LO, or Investor claim, this table is then utilized to a pull a list of clients based on the claim.");

                entity.HasIndex(e => e.ImportMethod)
                    .HasName("UK1_lkp_USDAImportType")
                    .IsUnique();

                entity.HasIndex(e => e.ImportMethodName)
                    .HasName("UK2_lkp_USDAImportType")
                    .IsUnique();

                entity.Property(e => e.UsdaimportTypeId).HasColumnName("USDAImportTypeID");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.ImportMethodName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<LkpUserAttributes>(entity =>
            {
                entity.HasKey(e => e.UserAttributeId);

                entity.ToTable("lkp_UserAttributes");

                entity.HasComment("An empty lookup table. Possible removal. Utilized by various Docuware, lookup, and cross reference tables. ");

                entity.HasIndex(e => e.UserAttributeName)
                    .HasName("UK1_lkp_UserAttibutes_UserAttributeName")
                    .IsUnique();

                entity.Property(e => e.UserAttributeId).HasColumnName("UserAttributeID");

                entity.Property(e => e.DataTypeId).HasColumnName("DataTypeID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.UserAttributeName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.DataType)
                    .WithMany(p => p.LkpUserAttributes)
                    .HasForeignKey(d => d.DataTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_lkp_UserAttributes_DataTypes");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.LkpUserAttributesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("F2_lkp_UserAttributes_lkp_Users");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.LkpUserAttributesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_lkp_UserAttributes_lkp_Users");
            });

            modelBuilder.Entity<LkpUsers>(entity =>
            {
                entity.HasKey(e => e.UserId);

                entity.ToTable("lkp_Users");

                entity.HasComment("A lookup table that contains user data. Utilized by a variety of tables within the database.");

                entity.HasIndex(e => e.Login)
                    .HasName("UK1_lkp_Users_Login")
                    .IsUnique();

                entity.HasIndex(e => e.UserName)
                    .HasName("idx_lkp_Users_UserName");

                entity.HasIndex(e => new { e.UserId, e.FirstName, e.LastName })
                    .HasName("idx_lkp_Users_FirstName_LastName_UserID");

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.Property(e => e.AllClientAccess)
                    .IsRequired()
                    .HasDefaultValueSql("('FALSE')");

                entity.Property(e => e.EmploymentTypeId).HasColumnName("EmploymentTypeID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.FirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastPwchange)
                    .HasColumnName("LastPWChange")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.LegacyCmsuserId).HasColumnName("LegacyCMSUserID");

                entity.Property(e => e.Login)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.PhoneNum)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.SecurityGroupId).HasColumnName("SecurityGroupID");

                entity.Property(e => e.UserEmailAddress)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.EmploymentType)
                    .WithMany(p => p.LkpUsers)
                    .HasForeignKey(d => d.EmploymentTypeId)
                    .HasConstraintName("FK1_lkp_Users_lkp_EmploymentTypes");
            });

            modelBuilder.Entity<LoginActivities>(entity =>
            {
                entity.HasKey(e => e.LoginActivityId);

                entity.Property(e => e.LoginActivityId).HasColumnName("LoginActivityID");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.ApplicationVersion)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.HostAddress)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.HostName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.LastHeartbeat).HasColumnType("datetime");

                entity.Property(e => e.Login)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LoginDate).HasColumnType("datetime");

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.Property(e => e.UserName)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LogoutActivities>(entity =>
            {
                entity.HasKey(e => e.LogoutActivityId);

                entity.Property(e => e.LogoutActivityId).HasColumnName("LogoutActivityID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.LoginActivityId).HasColumnName("LoginActivityID");

                entity.Property(e => e.LogoutDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.LogoutActivitiesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_LogoutActivities_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.LogoutActivitiesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_LogoutActivities_lkp_Users_LastUpdateUserID");

                entity.HasOne(d => d.LoginActivity)
                    .WithMany(p => p.LogoutActivities)
                    .HasForeignKey(d => d.LoginActivityId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_LogoutActivities_LoginActivities");
            });

            modelBuilder.Entity<OtherParameters>(entity =>
            {
                entity.HasKey(e => e.OtherParameterId);

                entity.HasComment("A table that contains one record for an \"other parameter.\"");

                entity.Property(e => e.OtherParameterId).HasColumnName("OtherParameterID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ParameterName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ParameterValue)
                    .IsRequired()
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Parameters>(entity =>
            {
                entity.HasKey(e => e.ParameterId);

                entity.HasIndex(e => e.ParameterName)
                    .HasName("UK1_Parameters_ParameterName")
                    .IsUnique();

                entity.Property(e => e.ParameterId).HasColumnName("ParameterID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.DataType)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ParameterName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.ParametersEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_Parameters_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.ParametersLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_Parameters_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<PrevBusinessEntities>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("prev_BusinessEntities");

                entity.HasComment("A table that contains data for previous business entities. ");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");

                entity.Property(e => e.BusinessEntityName)
                    .IsRequired()
                    .HasMaxLength(75)
                    .IsUnicode(false);

                entity.Property(e => e.EffectiveFromDate).HasColumnType("date");

                entity.Property(e => e.EffectiveToDate).HasColumnType("date");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.EntityTypeId).HasColumnName("EntityTypeID");
            });

            modelBuilder.Entity<ServerTypes>(entity =>
            {
                entity.HasKey(e => e.ServerTypeId);

                entity.HasComment("Table that contains information in regards to types of Servers within our network.");

                entity.HasIndex(e => e.ServerType)
                    .HasName("UC1_ServerTypes")
                    .IsUnique();

                entity.Property(e => e.ServerTypeId).HasColumnName("ServerTypeID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ServerType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.ServerTypesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_ServerTypes_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.ServerTypesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_ServerTypes_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<Servers>(entity =>
            {
                entity.HasKey(e => e.ServerId);

                entity.HasComment("Table that lists various servers within our network.");

                entity.HasIndex(e => e.ServerName)
                    .HasName("UK1_Servers_ServerName")
                    .IsUnique();

                entity.Property(e => e.ServerId).HasColumnName("ServerID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.EnterdByUserId).HasColumnName("EnterdByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.EnvironmentId).HasColumnName("EnvironmentID");

                entity.Property(e => e.Fqdn)
                    .IsRequired()
                    .HasColumnName("FQDN")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Ipaddress)
                    .IsRequired()
                    .HasColumnName("IPAddress")
                    .HasMaxLength(19)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ServerName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ServerTypeId).HasColumnName("ServerTypeID");

                entity.HasOne(d => d.EnterdByUser)
                    .WithMany(p => p.ServersEnterdByUser)
                    .HasForeignKey(d => d.EnterdByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_Servers_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.Environment)
                    .WithMany(p => p.Servers)
                    .HasForeignKey(d => d.EnvironmentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_Servers_lkp_Environments");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.ServersLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_Servers_lkp_Users_LastUpdateUserID");

                entity.HasOne(d => d.ServerType)
                    .WithMany(p => p.Servers)
                    .HasForeignKey(d => d.ServerTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_Servers_ServerTypes");
            });

            modelBuilder.Entity<SsisconnectionManagerColumns>(entity =>
            {
                entity.HasKey(e => e.ConnectionManagerColumnId)
                    .HasName("PK__SSISConn__733DD5F0B0F35AD1");

                entity.ToTable("SSISConnectionManagerColumns");

                entity.Property(e => e.ConnectionManagerColumnId).HasColumnName("ConnectionManagerColumnID");

                entity.Property(e => e.ColumnDataType)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ColumnName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ConnectionManagerId).HasColumnName("ConnectionManagerID");

                entity.HasOne(d => d.ConnectionManager)
                    .WithMany(p => p.SsisconnectionManagerColumns)
                    .HasForeignKey(d => d.ConnectionManagerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__SSISConne__Conne__46535886");
            });

            modelBuilder.Entity<SsisconnectionManagers>(entity =>
            {
                entity.HasKey(e => e.ConnectionManagerId)
                    .HasName("PK__SSISConn__ED13A738C34B9390");

                entity.ToTable("SSISConnectionManagers");

                entity.Property(e => e.ConnectionManagerId).HasColumnName("ConnectionManagerID");

                entity.Property(e => e.BaseFileName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ConnectionManagerName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ConnectionManagerType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FilePath)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.PackageId).HasColumnName("PackageID");

                entity.HasOne(d => d.Package)
                    .WithMany(p => p.SsisconnectionManagers)
                    .HasForeignKey(d => d.PackageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__SSISConne__Packa__4282C7A2");
            });

            modelBuilder.Entity<Ssispackages>(entity =>
            {
                entity.HasKey(e => e.PackageId)
                    .HasName("PK__SSISPack__322035EC6FE5E803");

                entity.ToTable("SSISPackages");

                entity.Property(e => e.PackageId).HasColumnName("PackageID");

                entity.Property(e => e.PackageName)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StoredProcedures>(entity =>
            {
                entity.HasKey(e => e.StoredProcedureId);

                entity.HasIndex(e => e.DatabaseId)
                    .HasName("IDX1_StoredProcedures_DatabaseID");

                entity.HasIndex(e => new { e.DatabaseId, e.SchemaName, e.StoredProcedureName })
                    .HasName("UK1_StoredProcedures")
                    .IsUnique();

                entity.Property(e => e.StoredProcedureId).HasColumnName("StoredProcedureID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.DatabaseId).HasColumnName("DatabaseID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.SchemaName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.StoredProcedureName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.HasOne(d => d.Database)
                    .WithMany(p => p.StoredProcedures)
                    .HasForeignKey(d => d.DatabaseId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_StoredProcedures_Databases");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.StoredProceduresEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_StoredProcedures_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.StoredProceduresLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_StoredProcedures_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<TblAutoDataDistributionDestinations>(entity =>
            {
                entity.HasKey(e => e.AutoDataDistributionDestinationId);

                entity.ToTable("tbl_AutoDataDistributionDestinations");

                entity.HasComment("Table that is utilized by procedure 'GetAutoDataDistributionDestinations' that returns the destinations for data distribution. ");

                entity.Property(e => e.AutoDataDistributionDestinationId).HasColumnName("AutoDataDistributionDestinationID");

                entity.Property(e => e.DestinationTypeId).HasColumnName("DestinationTypeID");

                entity.Property(e => e.EnvironmentId).HasColumnName("EnvironmentID");

                entity.Property(e => e.Filename)
                    .IsRequired()
                    .HasColumnName("filename")
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.Path)
                    .IsRequired()
                    .HasColumnName("path")
                    .HasMaxLength(400)
                    .IsUnicode(false);

                entity.Property(e => e.ProcessId).HasColumnName("ProcessID");

                entity.HasOne(d => d.DestinationType)
                    .WithMany(p => p.TblAutoDataDistributionDestinations)
                    .HasForeignKey(d => d.DestinationTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AutoDataDistributionDestinations_DestinationTypes");

                entity.HasOne(d => d.Environment)
                    .WithMany(p => p.TblAutoDataDistributionDestinations)
                    .HasForeignKey(d => d.EnvironmentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AutoDataDistributinDestinations_Environments");

                entity.HasOne(d => d.Process)
                    .WithMany(p => p.TblAutoDataDistributionDestinations)
                    .HasForeignKey(d => d.ProcessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AutoDataDistributionDestinations_Processes");
            });

            modelBuilder.Entity<TblAutoDataDistributionParameterValues>(entity =>
            {
                entity.HasKey(e => e.AutoDataDistributionParameterValueId);

                entity.ToTable("tbl_AutoDataDistributionParameterValues");

                entity.HasComment("Table that is also utilized by procedure 'GetAutoDataDistributionDestinations'. ");

                entity.Property(e => e.AutoDataDistributionParameterValueId).HasColumnName("AutoDataDistributionParameterValueID");

                entity.Property(e => e.AutoDataDistributionParameterId).HasColumnName("AutoDataDistributionParameterID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.EnvironmentId).HasColumnName("EnvironmentID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ProcessId).HasColumnName("ProcessID");

                entity.Property(e => e.Value)
                    .IsRequired()
                    .HasMaxLength(400)
                    .IsUnicode(false);

                entity.HasOne(d => d.AutoDataDistributionParameter)
                    .WithMany(p => p.TblAutoDataDistributionParameterValues)
                    .HasForeignKey(d => d.AutoDataDistributionParameterId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AutoDataDistributionParameterValue_AutoDataDistributionParameter");

                entity.HasOne(d => d.Environment)
                    .WithMany(p => p.TblAutoDataDistributionParameterValues)
                    .HasForeignKey(d => d.EnvironmentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AutoDataDistributionParameterValues_Environments");

                entity.HasOne(d => d.Process)
                    .WithMany(p => p.TblAutoDataDistributionParameterValues)
                    .HasForeignKey(d => d.ProcessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AutoDataDistributionParameterValue_Process");
            });

            modelBuilder.Entity<TblClientContacts>(entity =>
            {
                entity.HasKey(e => e.ContactId);

                entity.ToTable("tbl_ClientContacts");

                entity.HasComment("A table that contains Client contact information, in addition to External Client contact ID.");

                entity.HasIndex(e => new { e.ContactTypeId, e.ClientId, e.LastName, e.FirstName })
                    .HasName("UK1_tbl_ClientContacts")
                    .IsUnique();

                entity.Property(e => e.ContactId).HasColumnName("ContactID");

                entity.Property(e => e.Address)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Address2)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.City)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.ContactTypeId).HasColumnName("ContactTypeID");

                entity.Property(e => e.Department)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EmailAddress)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.Extension)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Fax)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.Phone)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.State)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.ZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.HasOne(d => d.Client)
                    .WithMany(p => p.TblClientContacts)
                    .HasForeignKey(d => d.ClientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_tbl_ClientContacts_lkp_Clients");

                entity.HasOne(d => d.ContactType)
                    .WithMany(p => p.TblClientContacts)
                    .HasForeignKey(d => d.ContactTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_ClientContacts_lkp_ContactTypes");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.TblClientContactsEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_tbl_ClientContacts_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.TblClientContactsLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_tbl_ClientContacts_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<TblClientPdfcompression>(entity =>
            {
                entity.HasKey(e => e.ClientId)
                    .HasName("PK_ClientPDFCompression");

                entity.ToTable("tbl_ClientPDFCompression");

                entity.Property(e => e.ClientId)
                    .HasColumnName("ClientID")
                    .ValueGeneratedNever();

                entity.Property(e => e.AddedDate).HasColumnType("datetime");

                entity.Property(e => e.Comment)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.Cron)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DestinationFolder).HasMaxLength(200);

                entity.Property(e => e.ErrorFolder).HasMaxLength(200);

                entity.Property(e => e.NotifyClientDl).HasColumnName("NotifyClientDL");

                entity.Property(e => e.NotifyCrfsDl).HasColumnName("NotifyCrfsDL");

                entity.Property(e => e.SizeLimitMb).HasColumnName("SizeLimit_MB");

                entity.Property(e => e.SourceFolder).HasMaxLength(200);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.HasOne(d => d.AddedByNavigation)
                    .WithMany(p => p.TblClientPdfcompressionAddedByNavigation)
                    .HasForeignKey(d => d.AddedBy)
                    .HasConstraintName("FK_ClientPDFCompression_lkp_Users");

                entity.HasOne(d => d.Client)
                    .WithOne(p => p.TblClientPdfcompression)
                    .HasForeignKey<TblClientPdfcompression>(d => d.ClientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ClientPDFCompression_lkp_Clients");

                entity.HasOne(d => d.UpdatedByNavigation)
                    .WithMany(p => p.TblClientPdfcompressionUpdatedByNavigation)
                    .HasForeignKey(d => d.UpdatedBy)
                    .HasConstraintName("FK_ClientPDFCompression_lkp_Users1");
            });

            modelBuilder.Entity<TblCntlTabControl>(entity =>
            {
                entity.HasKey(e => e.TabControlId);

                entity.ToTable("tbl_CNTL_TabControl");

                entity.HasComment("Table that contains the Tab ID's when the FormID = 8");

                entity.HasIndex(e => new { e.FormId, e.ClaimGroupText, e.TabControlName })
                    .HasName("UK1_tbl_CNTL_TabControl")
                    .IsUnique();

                entity.Property(e => e.TabControlId).HasColumnName("TabControlID");

                entity.Property(e => e.ClaimGroupText)
                    .IsRequired()
                    .HasMaxLength(55)
                    .IsUnicode(false);

                entity.Property(e => e.FormId).HasColumnName("FormID");

                entity.Property(e => e.TabControlName)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblControlInvestorGroup>(entity =>
            {
                entity.HasKey(e => e.InvestorGroupId)
                    .HasName("tbl_Control_InvestorGroup_PK");

                entity.ToTable("tbl_Control_InvestorGroup");

                entity.HasComment("Table that lists the various Investor Group names.");

                entity.HasIndex(e => e.InvestorGroupName)
                    .HasName("UK1_InvestorGroupName")
                    .IsUnique();

                entity.Property(e => e.InvestorGroupId).HasColumnName("InvestorGroupID");

                entity.Property(e => e.DateEntered)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EffectiveFromDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.EffectiveToDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('12/31/2078')");

                entity.Property(e => e.InvestorGroupName)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblControlInvestors>(entity =>
            {
                entity.HasKey(e => e.InvestorId)
                    .HasName("tbl_Control_Investors_PK");

                entity.ToTable("tbl_Control_Investors");

                entity.HasComment("Table that contains Investor Names and IDs.");

                entity.HasIndex(e => e.InvestorName)
                    .HasName("UK1_InvestorName")
                    .IsUnique();

                entity.Property(e => e.InvestorId).HasColumnName("InvestorID");

                entity.Property(e => e.DateEntered)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EffectiveFromDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.EffectiveToDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('12/31/2078')");

                entity.Property(e => e.InvestorName)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblEntityGroupContacts>(entity =>
            {
                entity.HasKey(e => e.EntityGroupContactId);

                entity.ToTable("tbl_EntityGroupContacts");

                entity.HasComment("Table that contains the EntityGroupContactID, ApplicationID, and GroupID. Utilized by the stored procedure 'usp_AppConfig_BusEntityGroup_GetContact_ByGroupID' that compiles a list of group contact info.");

                entity.Property(e => e.EntityGroupContactId).HasColumnName("EntityGroupContactID");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.ContactName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EmailAddress)
                    .IsRequired()
                    .HasColumnName("emailAddress")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.GroupId).HasColumnName("GroupID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.HasOne(d => d.Application)
                    .WithMany(p => p.TblEntityGroupContacts)
                    .HasForeignKey(d => d.ApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tbl_EntityGroupContacts_lkp_Applications");

                entity.HasOne(d => d.Group)
                    .WithMany(p => p.TblEntityGroupContacts)
                    .HasForeignKey(d => d.GroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tbl_EntityGroupContacts_lkp_EntityGroups");
            });

            modelBuilder.Entity<TblProcesses>(entity =>
            {
                entity.HasKey(e => e.ProcessId)
                    .HasName("tbl_Processes_PK");

                entity.ToTable("tbl_Processes");

                entity.HasComment("A table that contains various processes for each application. ");

                entity.HasIndex(e => e.ProcessName)
                    .HasName("UK1_ProcessName")
                    .IsUnique();

                entity.Property(e => e.ProcessId).HasColumnName("ProcessID");

                entity.Property(e => e.CategoryId).HasColumnName("CategoryID");

                entity.Property(e => e.DatabaseId).HasColumnName("DatabaseID");

                entity.Property(e => e.DateEntered)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DateUpdated)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ProcessName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Category)
                    .WithMany(p => p.TblProcesses)
                    .HasForeignKey(d => d.CategoryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_Processes_lkp_Categories");
            });

            modelBuilder.Entity<TblSubscriptionInstance>(entity =>
            {
                entity.HasKey(e => e.SubscriptionInstanceId)
                    .HasName("PK_Subscription_Instance_ID");

                entity.ToTable("tbl_SubscriptionInstance");

                entity.HasComment(@"Needed to create several records in Data driven view for same user but different parameters.

Add a Subscription and the Instance note.

For example:
      If the same user wants to have multiple results returned based on different parameters
           1. FNMA - Servicer1 - REO
           2. FNMA - Servicer1 - Non-REO
           3. FNMA - Servicer2 - REO
           4. FNMA - Servicer2 - Non-REO ..........");

                entity.Property(e => e.SubscriptionInstanceId).HasColumnName("SubscriptionInstanceID");

                entity.Property(e => e.SubscriptionId).HasColumnName("SubscriptionID");

                entity.Property(e => e.SubscriptionInstanceNote)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.Subscription)
                    .WithMany(p => p.TblSubscriptionInstance)
                    .HasForeignKey(d => d.SubscriptionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Instance_Subscription_ID");
            });

            modelBuilder.Entity<TblSubscriptionUser>(entity =>
            {
                entity.HasKey(e => e.SubscriptionUserId)
                    .HasName("PK_Subscription_User_ID");

                entity.ToTable("tbl_SubscriptionUser");

                entity.HasComment("Add a subscription and the user that gets the Subscription");

                entity.Property(e => e.SubscriptionUserId).HasColumnName("SubscriptionUserID");

                entity.Property(e => e.SubscriptionId).HasColumnName("SubscriptionID");

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.HasOne(d => d.Subscription)
                    .WithMany(p => p.TblSubscriptionUser)
                    .HasForeignKey(d => d.SubscriptionId)
                    .HasConstraintName("FK_Subscription_ID");
            });

            modelBuilder.Entity<TblSubscriptionUserParameters>(entity =>
            {
                entity.HasKey(e => e.SubscriptionParameterId)
                    .HasName("PK_Subscription_Parameter_ID");

                entity.ToTable("tbl_SubscriptionUserParameters");

                entity.HasComment("Add the SubscriptionUserID, InstanceID and parameterID as a unique entry. The value entered will be the value used in the data driven query.");

                entity.Property(e => e.SubscriptionParameterId).HasColumnName("SubscriptionParameterID");

                entity.Property(e => e.ParameterId).HasColumnName("ParameterID");

                entity.Property(e => e.ParameterValue)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.SubscriptionInstanceId).HasColumnName("SubscriptionInstanceID");

                entity.Property(e => e.SubscriptionUserId).HasColumnName("SubscriptionUserID");

                entity.HasOne(d => d.Parameter)
                    .WithMany(p => p.TblSubscriptionUserParameters)
                    .HasForeignKey(d => d.ParameterId)
                    .HasConstraintName("FK_Subscription_Parameter_ID");

                entity.HasOne(d => d.SubscriptionInstance)
                    .WithMany(p => p.TblSubscriptionUserParameters)
                    .HasForeignKey(d => d.SubscriptionInstanceId)
                    .HasConstraintName("FK_Subscription_Instance_ID");

                entity.HasOne(d => d.SubscriptionUser)
                    .WithMany(p => p.TblSubscriptionUserParameters)
                    .HasForeignKey(d => d.SubscriptionUserId)
                    .HasConstraintName("FK_Subscription_Parameter_User_ID");
            });

            modelBuilder.Entity<TblSubscriptionsDataDriven>(entity =>
            {
                entity.HasKey(e => e.SubscriptionId)
                    .HasName("PK_Subscription_ID");

                entity.ToTable("tbl_SubscriptionsDataDriven");

                entity.HasComment(@"
Holds information about the Report ID from CRFSReportServer DB.
From CRFSReportServer.dbo.Catalog.ItemID where Type = 2 (Report).
This will be used in tghe view to return report name etc.");

                entity.Property(e => e.SubscriptionId).HasColumnName("SubscriptionID");

                entity.Property(e => e.ReportId).HasColumnName("ReportID");

                entity.Property(e => e.SubscriptionName)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblUserEmailSignature>(entity =>
            {
                entity.HasKey(e => e.UserEmailSignatureId);

                entity.ToTable("tbl_UserEmailSignature");

                entity.HasComment("Table that stores end user's email signature. Not utilized by any table or procedure. Doesn't utilize a table or procedure. ");

                entity.HasIndex(e => e.Name)
                    .HasName("UK1_tbl_UserEmailSignature")
                    .IsUnique();

                entity.HasIndex(e => e.UserId)
                    .HasName("IX_tbl_UserEmailSignature")
                    .IsUnique();

                entity.Property(e => e.UserEmailSignatureId).HasColumnName("UserEmailSignatureID");

                entity.Property(e => e.CityStateZip)
                    .HasMaxLength(75)
                    .IsUnicode(false);

                entity.Property(e => e.Crfsname)
                    .HasColumnName("CRFSName")
                    .HasMaxLength(75)
                    .IsUnicode(false);

                entity.Property(e => e.Email)
                    .HasMaxLength(75)
                    .IsUnicode(false);

                entity.Property(e => e.Fax)
                    .HasColumnName("FAX")
                    .HasMaxLength(75)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(75)
                    .IsUnicode(false);

                entity.Property(e => e.Phone)
                    .HasMaxLength(75)
                    .IsUnicode(false);

                entity.Property(e => e.StreetAddress)
                    .HasMaxLength(75)
                    .IsUnicode(false);

                entity.Property(e => e.Title)
                    .HasMaxLength(75)
                    .IsUnicode(false);

                entity.Property(e => e.UserId).HasColumnName("UserID");
            });

            modelBuilder.Entity<VwClientApplicationAccess>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_ClientApplication_access");

                entity.Property(e => e.ApplicationName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwDw1Clients>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DW1_Clients");

                entity.Property(e => e.ApplicationClientId).HasColumnName("ApplicationClientID");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.ApplicationName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClientDisplayName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ClientId).HasColumnName("ClientID");
            });

            modelBuilder.Entity<VwDwDocumentStatusesSelectableIsSldccab>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DW_DocumentStatuses_Selectable_IS_SLDCCab");

                entity.Property(e => e.DocuWareCabinetName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.DocumentStatusName)
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwDwDocumentsClaimsBcab>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DW_Documents_ClaimsBCab");

                entity.Property(e => e.DocuWareCabinetName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.DocumentName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwDwDocumentsClaimsCab>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DW_Documents_ClaimsCab");

                entity.Property(e => e.DocuWareCabinetName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.DocumentName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwDwDocumentsClientUploadsCab>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DW_Documents_ClientUploadsCab");

                entity.Property(e => e.DocuWareCabinetName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.DocumentName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwDwDocumentsConventionalCab>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DW_Documents_ConventionalCab");

                entity.Property(e => e.DocuWareCabinetName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.DocumentName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwDwDocumentsCustomerFilesCab>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DW_Documents_Customer_FilesCab");

                entity.Property(e => e.DocuWareCabinetName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.DocumentName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwDwDocumentsCwcotcab>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DW_Documents_CWCOTCab");

                entity.Property(e => e.DocuWareCabinetName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.DocumentName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwDwDocumentsFnmacab>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DW_Documents_FNMACab");

                entity.Property(e => e.DocuWareCabinetName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.DocumentName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwDwDocumentsIscab>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DW_Documents_ISCab");

                entity.Property(e => e.DocuWareCabinetName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.DocumentName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwDwDocumentsJpmcClaimsCab>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DW_Documents_JPMC_ClaimsCab");

                entity.Property(e => e.DocuWareCabinetName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.DocumentName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwDwDocumentsJpmcP260cab>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DW_Documents_JPMC P260Cab");

                entity.Property(e => e.DocuWareCabinetName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.DocumentName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwDwDocumentsLossMitCab>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DW_Documents_LossMitCab");

                entity.Property(e => e.DocuWareCabinetName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.DocumentName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwDwDocumentsP260cab>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DW_Documents_P260Cab");

                entity.Property(e => e.DocuWareCabinetName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.DocumentName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwDwDocumentsPfscab>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DW_Documents_PFSCab");

                entity.Property(e => e.DocuWareCabinetName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.DocumentName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwDwDocumentsSflscab>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DW_Documents_SFLSCab");

                entity.Property(e => e.DocuWareCabinetName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.DocumentName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwDwDocumentsTitleCab>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DW_Documents_TitleCab");

                entity.Property(e => e.DocuWareCabinetName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.DocumentName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwDwDocumentsVacab>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DW_Documents_VACab");

                entity.Property(e => e.DocuWareCabinetName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.DocumentName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwExternalClientReportingConfiguredClients>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_ExternalClientReporting_ConfiguredClients");

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwExternalClientReportsDefinitionParameterLevel>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_ExternalClientReportsDefinition_ParameterLevel");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DataType)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.ParameterId).HasColumnName("ParameterID");

                entity.Property(e => e.ParameterName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.ParameterValue)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ReportId).HasColumnName("ReportID");

                entity.Property(e => e.ReportName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.StoredProcedureId).HasColumnName("StoredProcedureID");

                entity.Property(e => e.StoredProcedureName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwExternalClientReportsDefinitionTopLevel>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_ExternalClientReportsDefinition_TopLevel");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.ApplicationName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DatabaseName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.DeliveryFormatId).HasColumnName("DeliveryFormatID");

                entity.Property(e => e.DeliveryFormatName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FileExtension)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ReportId).HasColumnName("ReportID");

                entity.Property(e => e.ReportName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.SchemaName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.StoredProcedureId).HasColumnName("StoredProcedureID");

                entity.Property(e => e.StoredProcedureName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwGenerateFreqTypeValues>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_GenerateFreqTypeValues");

                entity.Property(e => e.Meaning)
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwGenerateFrequencyIntervalRelativeWeekValues>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_GenerateFrequencyInterval_Relative_WeekValues");

                entity.Property(e => e.RunWeek)
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwGenerateMonthlyRelativeFrequencyIntervals>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_GenerateMonthlyRelative_FrequencyIntervals");

                entity.Property(e => e.Interval)
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwGenerateRunSessionValues>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_Generate_RunSessionValues");

                entity.Property(e => e.RunSession)
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwGenerateWeeklyFreqIntervalDayOfWeekValues>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_GenerateWeeklyFreqIntervalDayOfWeekValues");
            });

            modelBuilder.Entity<VwUsers>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_Users");

                entity.Property(e => e.LastPwchange)
                    .HasColumnName("LastPWChange")
                    .HasColumnType("smalldatetime");

                entity.Property(e => e.Login)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.PhoneNum)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.SecurityGroupId).HasColumnName("SecurityGroupID");

                entity.Property(e => e.UserEmailAddress)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UserId)
                    .HasColumnName("UserID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<WebServiceDocuwareInstances>(entity =>
            {
                entity.HasKey(e => e.WebServiceDocuwareInstanceId);

                entity.HasComment("A table that corresponds to Docuware web services. Contains the WebServiceID and Docuware Instance ID fields.");

                entity.Property(e => e.WebServiceDocuwareInstanceId).HasColumnName("WebServiceDocuwareInstanceID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.DocuwareInstanceId).HasColumnName("DocuwareInstanceID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.WebServiceId).HasColumnName("WebServiceID");

                entity.HasOne(d => d.DocuwareInstance)
                    .WithMany(p => p.WebServiceDocuwareInstances)
                    .HasForeignKey(d => d.DocuwareInstanceId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_WebServiceDocuwareInstances_DocuwareInstances");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.WebServiceDocuwareInstancesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_WebServiceDocuwareInstances_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.WebServiceDocuwareInstancesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_WebServiceDocuwareInstances_lkp_Users_LastUpdateUserID");

                entity.HasOne(d => d.WebService)
                    .WithMany(p => p.WebServiceDocuwareInstances)
                    .HasForeignKey(d => d.WebServiceId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_WebServiceDocuwareInstances_WebServices");
            });

            modelBuilder.Entity<WebServiceDocuwareInstancesBak>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("WebServiceDocuwareInstances_bak");

                entity.Property(e => e.DocuwareInstanceId).HasColumnName("DocuwareInstanceID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.WebServiceDocuwareInstanceId).HasColumnName("WebServiceDocuwareInstanceID");

                entity.Property(e => e.WebServiceId).HasColumnName("WebServiceID");
            });

            modelBuilder.Entity<WebServiceTypes>(entity =>
            {
                entity.HasKey(e => e.WebServiceTypeId);

                entity.HasComment("Utilized by table webservices. Linked to Users lookup table. ");

                entity.Property(e => e.WebServiceTypeId).HasColumnName("WebServiceTypeID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.WebServiceType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.WebServiceTypesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_WebServiceTypes_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.WebServiceTypesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_WebServiceTypes_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<WebServices>(entity =>
            {
                entity.HasKey(e => e.WebServiceId);

                entity.HasComment("A table that contains Web Service name and Web Service Type ID. Utilized by the 'usp_DWLocator_EndpointRequest' stored procedure.");

                entity.Property(e => e.WebServiceId).HasColumnName("WebServiceID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ServerId).HasColumnName("ServerID");

                entity.Property(e => e.WebServiceName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.WebServiceTypeId).HasColumnName("WebServiceTypeID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.WebServicesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_WebServices_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.WebServicesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_WebServices_lkp_Users_LastUpdateUswerID");

                entity.HasOne(d => d.Server)
                    .WithMany(p => p.WebServices)
                    .HasForeignKey(d => d.ServerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_WebServices_Servers");

                entity.HasOne(d => d.WebServiceType)
                    .WithMany(p => p.WebServices)
                    .HasForeignKey(d => d.WebServiceTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_WebServices_WebServiceTypes");
            });

            modelBuilder.Entity<XmlExtractionClaimTypeConfig>(entity =>
            {
                entity.HasKey(e => e.XmlextractionId)
                    .HasName("PK__XML_Extr__D13C73FA43B873E0");

                entity.ToTable("XML_Extraction_ClaimType_Config");

                entity.Property(e => e.XmlextractionId).HasColumnName("XMLExtractionID");

                entity.Property(e => e.DateAdded)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DateUpdated)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.FhaclaimGroup).HasColumnName("FHAClaimGroup");

                entity.Property(e => e.FhalookUpId).HasColumnName("FHALookUpID");

                entity.Property(e => e.SubmitPart)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<XrefAppClientReportProcedureParameterValues>(entity =>
            {
                entity.HasKey(e => e.AppClientReportProcedureParameterValueId);

                entity.ToTable("xref_AppClientReportProcedureParameterValues");

                entity.HasIndex(e => e.ApplicationClientReportId)
                    .HasName("IDX1_xref_AppClientReportProcedureParameterValues_ApplicationClientReportID");

                entity.HasIndex(e => e.ReportProcedureId)
                    .HasName("IDX2_xref_AppClientReportProcedureParameterValues_ReportProcedureID");

                entity.HasIndex(e => e.StoredProcedureParameterId)
                    .HasName("IDX3_xref_AppClientReportProcedureParameterValues_StoredProcedureParameterID");

                entity.HasIndex(e => new { e.ApplicationClientReportId, e.ReportProcedureId, e.StoredProcedureParameterId })
                    .HasName("UK1_xref_AppClientReportProcedureParameterValues")
                    .IsUnique();

                entity.Property(e => e.AppClientReportProcedureParameterValueId).HasColumnName("AppClientReportProcedureParameterValueID");

                entity.Property(e => e.ApplicationClientReportId).HasColumnName("ApplicationClientReportID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ParameterValue)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ReportProcedureId).HasColumnName("ReportProcedureID");

                entity.Property(e => e.StoredProcedureParameterId).HasColumnName("StoredProcedureParameterID");

                entity.HasOne(d => d.ApplicationClientReport)
                    .WithMany(p => p.XrefAppClientReportProcedureParameterValues)
                    .HasForeignKey(d => d.ApplicationClientReportId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_AppClientReportProcedureParameterValues_xref_ApplicationClientReports");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.XrefAppClientReportProcedureParameterValuesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_xref_AppClientReportProcedureParameterValues_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.XrefAppClientReportProcedureParameterValuesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK5_xref_AppClientReportProcedureParameterValues_lkp_Users_LastUpdateUserID");

                entity.HasOne(d => d.ReportProcedure)
                    .WithMany(p => p.XrefAppClientReportProcedureParameterValues)
                    .HasForeignKey(d => d.ReportProcedureId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_AppClientReportProcedureParameterValues_xref_ReportProcedures");

                entity.HasOne(d => d.StoredProcedureParameter)
                    .WithMany(p => p.XrefAppClientReportProcedureParameterValues)
                    .HasForeignKey(d => d.StoredProcedureParameterId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_xref_AppClientReportProcedureParameterValues_xref_StoredProcedureParameters");
            });

            modelBuilder.Entity<XrefApplicationClientReports>(entity =>
            {
                entity.HasKey(e => e.ApplicationClientReportId);

                entity.ToTable("xref_ApplicationClientReports");

                entity.HasIndex(e => e.ApplicationClientId)
                    .HasName("IDX1_xref_ApplicationClientReports_ApplicationClientID");

                entity.HasIndex(e => e.DeliveryFormatId)
                    .HasName("IDX3_xref_ApplicationClientReports_DeliveryFormatID");

                entity.HasIndex(e => e.ReportId)
                    .HasName("IDX2_xref_ApplicationClientReports_ReportID");

                entity.HasIndex(e => new { e.ApplicationClientId, e.ReportId })
                    .HasName("UK1_xref_ApplicationClientReports")
                    .IsUnique();

                entity.Property(e => e.ApplicationClientReportId).HasColumnName("ApplicationClientReportID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ApplicationClientId).HasColumnName("ApplicationClientID");

                entity.Property(e => e.DeliveryFormatId).HasColumnName("DeliveryFormatID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ReportId).HasColumnName("ReportID");

                entity.HasOne(d => d.ApplicationClient)
                    .WithMany(p => p.XrefApplicationClientReports)
                    .HasForeignKey(d => d.ApplicationClientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_ApplicationClientReports_xref_ApplicationsClients");

                entity.HasOne(d => d.DeliveryFormat)
                    .WithMany(p => p.XrefApplicationClientReports)
                    .HasForeignKey(d => d.DeliveryFormatId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_xref_ApplicationClientReports_DeliveryFormats");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.XrefApplicationClientReportsEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_xref_ApplicationClientReports_lkp_Users");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.XrefApplicationClientReportsLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK5_xref_ApplicationClientReports_lkp_Users");

                entity.HasOne(d => d.Report)
                    .WithMany(p => p.XrefApplicationClientReports)
                    .HasForeignKey(d => d.ReportId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_ApplicationClientReports_lkp_Reports");
            });

            modelBuilder.Entity<XrefApplicationRoles>(entity =>
            {
                entity.HasKey(e => e.ApplicationRoleId);

                entity.ToTable("xref_ApplicationRoles");

                entity.HasComment("Cross ref table that contains the Application Roles");

                entity.HasIndex(e => new { e.ApplicationId, e.RoleId })
                    .HasName("UK1_lkp_ApplicationRoles_ApplicationIDRoleID")
                    .IsUnique();

                entity.Property(e => e.ApplicationRoleId).HasColumnName("ApplicationRoleID");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.RoleId).HasColumnName("RoleID");

                entity.HasOne(d => d.Application)
                    .WithMany(p => p.XrefApplicationRoles)
                    .HasForeignKey(d => d.ApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_ApplicationRoles_lkp_Applications");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.XrefApplicationRolesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_xref_ApplicationRoles_lkp_Users");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.XrefApplicationRolesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_xref_ApplicationRoles_lkp_Users");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.XrefApplicationRoles)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_ApplicationRoles_lkp_Roles");
            });

            modelBuilder.Entity<XrefApplicationUser>(entity =>
            {
                entity.HasKey(e => e.ApplicationUserId);

                entity.ToTable("xref_ApplicationUser");

                entity.HasComment("Cross ref table that contains various Users of the Applications.");

                entity.HasIndex(e => new { e.ApplicationId, e.UserId })
                    .HasName("UK1_xref_ApplicationUser_ApplicationIDUserID")
                    .IsUnique();

                entity.Property(e => e.ApplicationUserId).HasColumnName("ApplicationUserID");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.HasOne(d => d.Application)
                    .WithMany(p => p.XrefApplicationUser)
                    .HasForeignKey(d => d.ApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_ApplicationUser_lkp_Applications");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.XrefApplicationUserEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .HasConstraintName("FK3_xref_ApplicationUser_lkp_Users");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.XrefApplicationUserLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .HasConstraintName("FK4_xref_ApplicationUser_lkp_Users");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.XrefApplicationUserUser)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_ApplicationUser_lkp_Users");
            });

            modelBuilder.Entity<XrefApplicationsClients>(entity =>
            {
                entity.HasKey(e => e.ApplicationClientId);

                entity.ToTable("xref_ApplicationsClients");

                entity.HasComment("Cross ref table that contains Application Clients.");

                entity.HasIndex(e => new { e.ApplicationId, e.ClientId })
                    .HasName("UK1_xref_ApplicationsClients_ApplicationID_ClientID")
                    .IsUnique();

                entity.Property(e => e.ApplicationClientId).HasColumnName("ApplicationClientID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ActiveFromDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ActiveToDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("('12/31/2078')");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.Application)
                    .WithMany(p => p.XrefApplicationsClients)
                    .HasForeignKey(d => d.ApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_ApplicationsClients_lkp_Applications");

                entity.HasOne(d => d.Client)
                    .WithMany(p => p.XrefApplicationsClients)
                    .HasForeignKey(d => d.ClientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_ApplicationsClients_lkp_Clients");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.XrefApplicationsClientsEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_xref_ApplicationsClients_lkp_Users");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.XrefApplicationsClientsLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_xref_ApplicationsClients_lkp_Users");
            });

            modelBuilder.Entity<XrefAppplicationUserApplicationRole>(entity =>
            {
                entity.HasKey(e => e.AppplicationUserApplicationRoleId);

                entity.ToTable("xref_AppplicationUserApplicationRole");

                entity.HasComment("An empty cross ref table. Not utilized by any other table or procedure. ");

                entity.HasIndex(e => new { e.ApplicationUserId, e.ApplicationRoleId })
                    .HasName("UK1_xref_AppplicationUserApplicationRole_ApplicationUserIDApplicationRoleID")
                    .IsUnique();

                entity.Property(e => e.AppplicationUserApplicationRoleId).HasColumnName("AppplicationUserApplicationRoleID");

                entity.Property(e => e.ApplicationRoleId).HasColumnName("ApplicationRoleID");

                entity.Property(e => e.ApplicationUserId).HasColumnName("ApplicationUserID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.ApplicationRole)
                    .WithMany(p => p.XrefAppplicationUserApplicationRole)
                    .HasForeignKey(d => d.ApplicationRoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_AppplicationUserApplicationRole_xref_ApplicationRoles");

                entity.HasOne(d => d.ApplicationUser)
                    .WithMany(p => p.XrefAppplicationUserApplicationRole)
                    .HasForeignKey(d => d.ApplicationUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_AppplicationUserApplicationRole_xref_ApplicationUser");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.XrefAppplicationUserApplicationRoleEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_xref_AppplicationUserApplicationRole_lkp_Users");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.XrefAppplicationUserApplicationRoleLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_xref_AppplicationUserApplicationRole_lkp_Users");
            });

            modelBuilder.Entity<XrefBusinessEntityGroup>(entity =>
            {
                entity.HasKey(e => e.BusinessEntityGroupId);

                entity.ToTable("xref_BusinessEntityGroup");

                entity.HasComment("Cross ref table that contains data in relation to Business Entity Groups.");

                entity.HasIndex(e => new { e.BusinessEntityId, e.GroupId })
                    .HasName("UK_xref_BusinessEntityGroup")
                    .IsUnique();

                entity.Property(e => e.BusinessEntityGroupId).HasColumnName("BusinessEntityGroupID");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");

                entity.Property(e => e.EffectiveFromDate).HasColumnType("date");

                entity.Property(e => e.EffectiveToDate).HasColumnType("date");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.GroupId).HasColumnName("GroupID");

                entity.HasOne(d => d.Application)
                    .WithMany(p => p.XrefBusinessEntityGroup)
                    .HasForeignKey(d => d.ApplicationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_xref_BusinessEntityGroup_lkp_Applications");

                entity.HasOne(d => d.Group)
                    .WithMany(p => p.XrefBusinessEntityGroup)
                    .HasForeignKey(d => d.GroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_xref_BusinessEntityGroup_lkp_EntityGroups");
            });

            modelBuilder.Entity<XrefClaimsManagementHudclaimsClaimType>(entity =>
            {
                entity.HasKey(e => e.ClaimsManagementHudclaimsClaimTypeId);

                entity.ToTable("xref_ClaimsManagement_HUDClaims_ClaimType");

                entity.HasComment("Cross ref table that contains HUD Claim types.");

                entity.HasIndex(e => e.ClaimsManagementClaimTypeId)
                    .HasName("UK1_xref_ClaimsManagement_HUDClaims_ClaimType_ClaimsManagementClaimType")
                    .IsUnique();

                entity.HasIndex(e => e.HudclaimsClaimTypeId)
                    .HasName("UK2_xref_ClaimsManagement_HUDClaims_ClaimType_HUDClaimsClaimTypeID")
                    .IsUnique();

                entity.Property(e => e.ClaimsManagementHudclaimsClaimTypeId).HasColumnName("ClaimsManagement_HUDClaims_ClaimType_ID");

                entity.Property(e => e.ClaimsManagementClaimTypeId).HasColumnName("ClaimsManagement_ClaimTypeID");

                entity.Property(e => e.HudclaimsClaimTypeId).HasColumnName("HUDClaims_ClaimTypeID");
            });

            modelBuilder.Entity<XrefClientInvestorGroupServices>(entity =>
            {
                entity.HasKey(e => e.ClientInvestorGroupServicesId);

                entity.ToTable("xref_Client_InvestorGroup_Services");

                entity.HasComment("Cross ref table that lists various Investor Group Services.");

                entity.HasIndex(e => new { e.ClientId, e.InvestorGroupId })
                    .HasName("UK1_xref_Client_InvestorGroup_Services")
                    .IsUnique();

                entity.Property(e => e.ClientInvestorGroupServicesId).HasColumnName("Client_InvestorGroup_ServicesID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.InvestorGroupId).HasColumnName("InvestorGroupID");
            });

            modelBuilder.Entity<XrefClientMicompanyServices>(entity =>
            {
                entity.HasKey(e => e.ClientMicompanyServicesId);

                entity.ToTable("xref_Client_MICompany_Services");

                entity.HasComment("Cross ref table. Utilized by the stored procedure 'usp_CNTL_ClientMICompanyServiceMatrix_Select' .");

                entity.HasIndex(e => new { e.ClientId, e.MicompanyId })
                    .HasName("UK1_xref_Client_MICompany_Services")
                    .IsUnique();

                entity.Property(e => e.ClientMicompanyServicesId).HasColumnName("Client_MICompany_ServicesID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.MicompanyId).HasColumnName("MICompanyID");
            });

            modelBuilder.Entity<XrefClientUsdaclaimScope>(entity =>
            {
                entity.HasKey(e => e.ClientUsdaclaimScopeId);

                entity.ToTable("xref_Client_USDAClaim_Scope");

                entity.HasComment("Cross ref table for USDA Claim Scope.");

                entity.HasIndex(e => e.ClientId)
                    .HasName("IDX1_xref_Client_USDAClaim_Scope_ClientID");

                entity.HasIndex(e => e.UsdaclaimTypeMatrixId)
                    .HasName("IDX3_xref_Client_USDAClaim_Scope_USDAClaimTypeMatrixID");

                entity.HasIndex(e => e.UsdaimportTypeId)
                    .HasName("IDX2_xref_Client_USDAClaim_Scope_USDAImportTypeID");

                entity.Property(e => e.ClientUsdaclaimScopeId).HasColumnName("Client_USDAClaim_ScopeID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.UsdaclaimTypeMatrixId).HasColumnName("USDAClaimTypeMatrixID");

                entity.Property(e => e.UsdaimportTypeId).HasColumnName("USDAImportTypeID");

                entity.HasOne(d => d.Client)
                    .WithMany(p => p.XrefClientUsdaclaimScope)
                    .HasForeignKey(d => d.ClientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_Client_USDAClaim_Scope_lkp_Clients");

                entity.HasOne(d => d.UsdaclaimTypeMatrix)
                    .WithMany(p => p.XrefClientUsdaclaimScope)
                    .HasForeignKey(d => d.UsdaclaimTypeMatrixId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_xref_Client_USDAClaim_Scope_lkp_USDAClaimTypeMatrix");

                entity.HasOne(d => d.UsdaimportType)
                    .WithMany(p => p.XrefClientUsdaclaimScope)
                    .HasForeignKey(d => d.UsdaimportTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_Client_USDAClaim_Scope_lkp_USDAImportType");
            });

            modelBuilder.Entity<XrefClientsUsers>(entity =>
            {
                entity.HasKey(e => e.ClientUserId);

                entity.ToTable("xref_ClientsUsers");

                entity.HasComment("Cross ref table that contains ClientIDs and ClientUserIDs.");

                entity.HasIndex(e => new { e.ClientId, e.UserId })
                    .HasName("UK1_xref_ClientsUsers_ClientIDUserID")
                    .IsUnique();

                entity.Property(e => e.ClientUserId).HasColumnName("ClientUserID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.HasOne(d => d.Client)
                    .WithMany(p => p.XrefClientsUsers)
                    .HasForeignKey(d => d.ClientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_ClientsUsers_lkp_Clients_ClientID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.XrefClientsUsersEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_xref_ClientsUsers_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.XrefClientsUsersLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_xref_ClientsUsers_lkp_Users_LastUpdateUserID");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.XrefClientsUsersUser)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_ClientsUsers_lkp_Users_UserID");
            });

            modelBuilder.Entity<XrefControlInvestorInvestorGroup>(entity =>
            {
                entity.HasKey(e => e.InvestorInvestorGroupId)
                    .HasName("xref_Control_Investor_InvestorGroup_PK");

                entity.ToTable("xref_Control_Investor_InvestorGroup");

                entity.HasComment("Cross ref table that lists Investor Group names and IDs.");

                entity.HasIndex(e => new { e.InvestorGroupId, e.InvestorId })
                    .HasName("UK1_InvestorID_InvestorGroupID")
                    .IsUnique();

                entity.Property(e => e.InvestorInvestorGroupId).HasColumnName("Investor_InvestorGroup_ID");

                entity.Property(e => e.InvestorGroupId).HasColumnName("InvestorGroupID");

                entity.Property(e => e.InvestorId).HasColumnName("InvestorID");

                entity.HasOne(d => d.InvestorGroup)
                    .WithMany(p => p.XrefControlInvestorInvestorGroup)
                    .HasForeignKey(d => d.InvestorGroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("tbl_Control_InvestorGroup_xref_Control_Investor_InvestorGroup_FK1");

                entity.HasOne(d => d.Investor)
                    .WithMany(p => p.XrefControlInvestorInvestorGroup)
                    .HasForeignKey(d => d.InvestorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("tbl_Control_Investors_xref_Control_Investor_InvestorGroup_FK1");
            });

            modelBuilder.Entity<XrefEntityGroupUserAssignment>(entity =>
            {
                entity.HasKey(e => e.EntityGroupUserAssignmentId);

                entity.ToTable("xref_EntityGroup_User_Assignment");

                entity.HasComment("Cross ref table. Contains data for entity groups that each user is in. Utilized by Entity Groups lookup table. ");

                entity.HasIndex(e => e.GroupId)
                    .HasName("UK_xref_EntityGroup_User_Assignment")
                    .IsUnique();

                entity.Property(e => e.EntityGroupUserAssignmentId).HasColumnName("EntityGroup_User_AssignmentID");

                entity.Property(e => e.GroupId).HasColumnName("GroupID");

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.HasOne(d => d.Group)
                    .WithOne(p => p.XrefEntityGroupUserAssignment)
                    .HasForeignKey<XrefEntityGroupUserAssignment>(d => d.GroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_xref_EntityGroup_User_Assignment_lkp_EntityGroups");
            });

            modelBuilder.Entity<XrefFtmsTaskEmailRecipients>(entity =>
            {
                entity.HasKey(e => e.TaskRecipientId)
                    .HasName("PK__FTMSTask__EmailRecipientID");

                entity.ToTable("xref_FTMS_TaskEmailRecipients");

                entity.HasIndex(e => new { e.JobId, e.TaskId, e.RecipientId, e.RecipientType, e.MessageType })
                    .HasName("UIX_FileTransferTaskEmailRecipients")
                    .IsUnique();

                entity.Property(e => e.TaskRecipientId)
                    .HasColumnName("TaskRecipientID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.JobId).HasColumnName("JobID");

                entity.Property(e => e.MessageType)
                    .IsRequired()
                    .HasMaxLength(7)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('=\"Message\"')");

                entity.Property(e => e.RecipientId).HasColumnName("RecipientID");

                entity.Property(e => e.RecipientType)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TaskId).HasColumnName("TaskID");

                entity.HasOne(d => d.TaskRecipient)
                    .WithOne(p => p.XrefFtmsTaskEmailRecipients)
                    .HasForeignKey<XrefFtmsTaskEmailRecipients>(d => d.TaskRecipientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FileTransferTaskEmailRecipients_FTMSRecipientID_FileTransferTaskEmailRecipients_RecipientID");
            });

            modelBuilder.Entity<XrefProcessUserEmail>(entity =>
            {
                entity.HasKey(e => e.ProcessUserEmailId);

                entity.ToTable("xref_Process_User_Email");

                entity.HasComment("Cross ref table. Utilized by the Processes table. Stored procedures associated: 'usp_CRFSBilling_SelectEmails' and 'usp_ProcessUserEMail_List_withClientPermissions_SELECT'");

                entity.Property(e => e.ProcessUserEmailId).HasColumnName("ProcessUserEmailID");

                entity.Property(e => e.ExcludeUntilProduction)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ProcessId).HasColumnName("ProcessID");

                entity.Property(e => e.SecurityUserId).HasColumnName("SecurityUserID");

                entity.HasOne(d => d.Process)
                    .WithMany(p => p.XrefProcessUserEmail)
                    .HasForeignKey(d => d.ProcessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_process_user_email_tbl_Processes");
            });

            modelBuilder.Entity<XrefProcessesClients>(entity =>
            {
                entity.HasKey(e => e.ProcessClientId);

                entity.ToTable("xref_Processes_Clients");

                entity.HasComment("Cross ref table. Used by Client and Users lookup tables. Also utilized by Processes table. Related stored procedure: 'usp_ProcessUserEMail_List_withClientPermissions_SELECT'");

                entity.Property(e => e.ProcessClientId).HasColumnName("ProcessClientID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ProcessId).HasColumnName("ProcessID");

                entity.HasOne(d => d.Client)
                    .WithMany(p => p.XrefProcessesClients)
                    .HasForeignKey(d => d.ClientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_Processes_Clients_lkp_Clients");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.XrefProcessesClientsEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_xref_Processes_Clients_lkp_Users");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.XrefProcessesClientsLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_ xref_Processes_Clients_lkp_Users");

                entity.HasOne(d => d.Process)
                    .WithMany(p => p.XrefProcessesClients)
                    .HasForeignKey(d => d.ProcessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_Processes_Clients_tbl_Processes");
            });

            modelBuilder.Entity<XrefReportProcedures>(entity =>
            {
                entity.HasKey(e => e.ReportProcedureId);

                entity.ToTable("xref_ReportProcedures");

                entity.HasIndex(e => e.ReportId)
                    .HasName("IDX1_xref_ReportProcedures_ReportID");

                entity.HasIndex(e => e.StoredProcedureId)
                    .HasName("IDX2_xref_ReportProcedures_StoredProcedureID");

                entity.HasIndex(e => new { e.ReportId, e.StoredProcedureId })
                    .HasName("UK1_xref_ReportProcedures")
                    .IsUnique();

                entity.Property(e => e.ReportProcedureId).HasColumnName("ReportProcedureID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ReportId).HasColumnName("ReportID");

                entity.Property(e => e.StoredProcedureId).HasColumnName("StoredProcedureID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.XrefReportProceduresEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_xref_ReportProcedures_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.XrefReportProceduresLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_xref_ReportProcedures_lkp_Users_LastUpdateUserID");

                entity.HasOne(d => d.Report)
                    .WithMany(p => p.XrefReportProcedures)
                    .HasForeignKey(d => d.ReportId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_ReportProcedures_lkp_Reports");

                entity.HasOne(d => d.StoredProcedure)
                    .WithMany(p => p.XrefReportProcedures)
                    .HasForeignKey(d => d.StoredProcedureId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_ReportProcedures_StoredProcedures");
            });

            modelBuilder.Entity<XrefReportRecipients>(entity =>
            {
                entity.HasKey(e => e.ReportRecipientId);

                entity.ToTable("xref_ReportRecipients");

                entity.HasIndex(e => e.ApplicationClientReportId)
                    .HasName("IDX1_xref_ReportRecipients_ApplicationClientReportID");

                entity.HasIndex(e => e.ContactId)
                    .HasName("IDX2_xref_ReportRecipients_ExternalContactID");

                entity.HasIndex(e => new { e.ApplicationClientReportId, e.ContactId })
                    .HasName("UK1_xref_ReportRecipients")
                    .IsUnique();

                entity.Property(e => e.ReportRecipientId).HasColumnName("ReportRecipientID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ApplicationClientReportId).HasColumnName("ApplicationClientReportID");

                entity.Property(e => e.ContactId).HasColumnName("ContactID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.ApplicationClientReport)
                    .WithMany(p => p.XrefReportRecipients)
                    .HasForeignKey(d => d.ApplicationClientReportId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_ReportRecipients_xref_ApplicationClientReports");

                entity.HasOne(d => d.Contact)
                    .WithMany(p => p.XrefReportRecipients)
                    .HasForeignKey(d => d.ContactId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_ReportRecipients_tbl_ClientContacts");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.XrefReportRecipientsEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_xref_ReportRecipients_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.XrefReportRecipientsLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_xref_ReportRecipients_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<XrefStoredProcedureParameters>(entity =>
            {
                entity.HasKey(e => e.StoredProcedureParameterId);

                entity.ToTable("xref_StoredProcedureParameters");

                entity.HasIndex(e => e.ParameterId)
                    .HasName("IDX2_xref_StoredProcedureParameters_ParameterID");

                entity.HasIndex(e => e.StoredProcedureId)
                    .HasName("IDX1_xref_StoredProcedureParameters_StoredProcedureID");

                entity.HasIndex(e => new { e.StoredProcedureId, e.ParameterId })
                    .HasName("UK1_xref_StoredProcedureParameters")
                    .IsUnique();

                entity.Property(e => e.StoredProcedureParameterId).HasColumnName("StoredProcedureParameterID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ParameterId).HasColumnName("ParameterID");

                entity.Property(e => e.StoredProcedureId).HasColumnName("StoredProcedureID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.XrefStoredProcedureParametersEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_xref_StoredProcedureParameters_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.XrefStoredProcedureParametersLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_xref_StoredProcedureParameters_lkp_Users_LastUpdateUserID");

                entity.HasOne(d => d.Parameter)
                    .WithMany(p => p.XrefStoredProcedureParameters)
                    .HasForeignKey(d => d.ParameterId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_StoredProcedureParameters_Parameters");

                entity.HasOne(d => d.StoredProcedure)
                    .WithMany(p => p.XrefStoredProcedureParameters)
                    .HasForeignKey(d => d.StoredProcedureId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_StoredProcedureParameters_StoredProcedures");
            });

            modelBuilder.Entity<XrefSuppMenuItemClaimType>(entity =>
            {
                entity.HasKey(e => e.ValidSuppMenuItemId)
                    .HasName("PK_tbl_ValidSuppMenuItem");

                entity.ToTable("xref_SuppMenuItem_ClaimType");

                entity.HasComment("cross reference between create supp menu items in cms and claimtypes");

                entity.Property(e => e.ValidSuppMenuItemId).HasColumnName("ValidSuppMenuItemID");

                entity.Property(e => e.ClaimTypeId)
                    .HasColumnName("ClaimTypeID")
                    .HasComment("from ClaimsManagement.dbo.ClaimTypesByForm");

                entity.Property(e => e.SuppMenuItemNameId)
                    .HasColumnName("SuppMenuItemNameID")
                    .HasComment("from SuppMenuItemName");

                entity.HasOne(d => d.SuppMenuItemName)
                    .WithMany(p => p.XrefSuppMenuItemClaimType)
                    .HasForeignKey(d => d.SuppMenuItemNameId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_SuppMenuItem_ClaimType_lkp_SuppMenuItemName");
            });

            modelBuilder.Entity<XrefUserReportRecipients>(entity =>
            {
                entity.HasKey(e => e.UserReportRecipientId);

                entity.ToTable("xref_UserReportRecipients");

                entity.HasIndex(e => e.ApplicationClientReportId)
                    .HasName("IDX1_xref_UserReportRecipients_ApplicationReportID");

                entity.HasIndex(e => e.UserId)
                    .HasName("IDX2_xref_UserReportRecipients_UserID");

                entity.Property(e => e.UserReportRecipientId).HasColumnName("UserReportRecipientID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ApplicationClientReportId).HasColumnName("ApplicationClientReportID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.HasOne(d => d.ApplicationClientReport)
                    .WithMany(p => p.XrefUserReportRecipients)
                    .HasForeignKey(d => d.ApplicationClientReportId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_UserReportRecipients_xref_ApplicationClientReports");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.XrefUserReportRecipientsEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_xref_UserReportRecipients_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.XrefUserReportRecipientsLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_xref_UserReportRecipients_lkp_Users_LastUpdateUserID");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.XrefUserReportRecipientsUser)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_UserReportRecipients_lkp_Users");
            });

            modelBuilder.Entity<XrefUserUserAttributes>(entity =>
            {
                entity.HasKey(e => e.UserUserAttributeId);

                entity.ToTable("xref_UserUserAttributes");

                entity.HasComment("No records in this table. Possible removal.");

                entity.HasIndex(e => new { e.UserId, e.UserAttributeId })
                    .HasName("UK1_xref_UserUserAttributes_UserID_UserAttributeID")
                    .IsUnique();

                entity.Property(e => e.UserUserAttributeId).HasColumnName("UserUserAttributeID");

                entity.Property(e => e.AttributeValue)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.UserAttributeId).HasColumnName("UserAttributeID");

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.XrefUserUserAttributesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_xref_UserUserAttributes_lkp_Users");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.XrefUserUserAttributesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_xref_UserUserAttributes_lkp_Users");

                entity.HasOne(d => d.UserAttribute)
                    .WithMany(p => p.XrefUserUserAttributes)
                    .HasForeignKey(d => d.UserAttributeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_UserUserAttributes_lkp_UserAttributes");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.XrefUserUserAttributesUser)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_UserUserAttributes_lkp_Users");
            });

            modelBuilder.Entity<XrefVaTocExcludedClients>(entity =>
            {
                entity.HasKey(e => e.VatocexcludedClientId)
                    .HasName("PK_xref_VA_TOC_ExcludedClientID");

                entity.ToTable("xref_VA_TOC_ExcludedClients");

                entity.Property(e => e.VatocexcludedClientId).HasColumnName("VATOCExcludedClientID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.EffectiveFromDate).HasColumnType("date");

                entity.Property(e => e.EffectiveToDate).HasColumnType("date");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");
            });

            modelBuilder.HasSequence("FIleTransferDuplicateFIleSequence");

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
