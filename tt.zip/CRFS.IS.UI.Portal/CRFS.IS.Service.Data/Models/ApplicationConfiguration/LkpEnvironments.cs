﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpEnvironments
    {
        public LkpEnvironments()
        {
            Servers = new HashSet<Servers>();
            TblAutoDataDistributionDestinations = new HashSet<TblAutoDataDistributionDestinations>();
            TblAutoDataDistributionParameterValues = new HashSet<TblAutoDataDistributionParameterValues>();
        }

        public int EnvironmentId { get; set; }
        public string EnvName { get; set; }
        public string EnvDescription { get; set; }
        public bool MarkedForDelete { get; set; }
        public bool Active { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }

        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual ICollection<Servers> Servers { get; set; }
        public virtual ICollection<TblAutoDataDistributionDestinations> TblAutoDataDistributionDestinations { get; set; }
        public virtual ICollection<TblAutoDataDistributionParameterValues> TblAutoDataDistributionParameterValues { get; set; }
    }
}
