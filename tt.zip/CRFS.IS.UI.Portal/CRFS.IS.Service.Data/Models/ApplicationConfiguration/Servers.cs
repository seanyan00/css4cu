﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class Servers
    {
        public Servers()
        {
            DatabaseInstances = new HashSet<DatabaseInstances>();
            DocuwareInstances = new HashSet<DocuwareInstances>();
            WebServices = new HashSet<WebServices>();
        }

        public int ServerId { get; set; }
        public int ServerTypeId { get; set; }
        public string ServerName { get; set; }
        public int EnvironmentId { get; set; }
        public string Fqdn { get; set; }
        public string Ipaddress { get; set; }
        public bool MarkedForDelete { get; set; }
        public bool? Active { get; set; }
        public int EnterdByUserId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }

        public virtual LkpUsers EnterdByUser { get; set; }
        public virtual LkpEnvironments Environment { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual ServerTypes ServerType { get; set; }
        public virtual ICollection<DatabaseInstances> DatabaseInstances { get; set; }
        public virtual ICollection<DocuwareInstances> DocuwareInstances { get; set; }
        public virtual ICollection<WebServices> WebServices { get; set; }
    }
}
