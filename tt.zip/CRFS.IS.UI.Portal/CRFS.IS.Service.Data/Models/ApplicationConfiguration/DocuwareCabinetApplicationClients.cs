﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class DocuwareCabinetApplicationClients
    {
        public int DocuwareCabinetApplicationClientId { get; set; }
        public int DocuwareCabinetId { get; set; }
        public int ApplicationClientId { get; set; }
        public bool MarkedForDelete { get; set; }
        public bool? Active { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdteUserId { get; set; }
        public DateTime LastpdateDate { get; set; }

        public virtual XrefApplicationsClients ApplicationClient { get; set; }
        public virtual DocuwareCabinets DocuwareCabinet { get; set; }
        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdteUser { get; set; }
    }
}
