﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class DatabaseInstanceDatabases
    {
        public int DatabaseInstanceDatabaseId { get; set; }
        public int DatabaseInstanceId { get; set; }
        public int DatabaseId { get; set; }
        public bool MarkedForDelete { get; set; }
        public bool? Active { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }

        public virtual Databases Database { get; set; }
        public virtual DatabaseInstances DatabaseInstance { get; set; }
        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
    }
}
