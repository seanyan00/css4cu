﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblSubscriptionUserParameters
    {
        public int SubscriptionParameterId { get; set; }
        public int? SubscriptionUserId { get; set; }
        public int? SubscriptionInstanceId { get; set; }
        public int? ParameterId { get; set; }
        public string ParameterValue { get; set; }

        public virtual LkpSubscriptionParameters Parameter { get; set; }
        public virtual TblSubscriptionInstance SubscriptionInstance { get; set; }
        public virtual TblSubscriptionUser SubscriptionUser { get; set; }
    }
}
