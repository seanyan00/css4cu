﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpSuppMenuItemName
    {
        public LkpSuppMenuItemName()
        {
            XrefSuppMenuItemClaimType = new HashSet<XrefSuppMenuItemClaimType>();
        }

        public int SuppMenuItemNameId { get; set; }
        public string SuppMenuItemName { get; set; }
        public string MenuItemDescription { get; set; }

        public virtual ICollection<XrefSuppMenuItemClaimType> XrefSuppMenuItemClaimType { get; set; }
    }
}
