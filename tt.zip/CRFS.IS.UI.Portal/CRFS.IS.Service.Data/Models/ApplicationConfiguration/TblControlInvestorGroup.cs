﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblControlInvestorGroup
    {
        public TblControlInvestorGroup()
        {
            LkpInvestorFollowup = new HashSet<LkpInvestorFollowup>();
            XrefControlInvestorInvestorGroup = new HashSet<XrefControlInvestorInvestorGroup>();
        }

        public int InvestorGroupId { get; set; }
        public string InvestorGroupName { get; set; }
        public DateTime DateEntered { get; set; }
        public DateTime EffectiveFromDate { get; set; }
        public DateTime EffectiveToDate { get; set; }

        public virtual ICollection<LkpInvestorFollowup> LkpInvestorFollowup { get; set; }
        public virtual ICollection<XrefControlInvestorInvestorGroup> XrefControlInvestorInvestorGroup { get; set; }
    }
}
