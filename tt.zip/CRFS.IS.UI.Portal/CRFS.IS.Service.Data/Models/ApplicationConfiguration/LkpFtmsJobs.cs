﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpFtmsJobs
    {
        public int JobId { get; set; }
        public string JobName { get; set; }
        public int ClientId { get; set; }
        public bool JobEnabled { get; set; }
        public int StartHour { get; set; }
        public int EndHour { get; set; }

        public virtual LkpClients Client { get; set; }
    }
}
