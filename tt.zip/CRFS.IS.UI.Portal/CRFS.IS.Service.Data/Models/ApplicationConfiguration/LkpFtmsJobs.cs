﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpFtmsJobs
    {
        public int JobId { get; set; }
        public string JobName { get; set; }
        public int ClientId { get; set; }
        public bool JobEnabled { get; set; }
        public int StartHour { get; set; }
        public int EndHour { get; set; }

        public virtual LkpClients Client { get; set; }
    }
}
