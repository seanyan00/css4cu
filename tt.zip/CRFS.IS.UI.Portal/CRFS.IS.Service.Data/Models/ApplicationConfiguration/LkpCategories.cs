﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpCategories
    {
        public LkpCategories()
        {
            TblProcesses = new HashSet<TblProcesses>();
        }

        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public bool Active { get; set; }
        public DateTime DateEntered { get; set; }
        public DateTime? DateUpdated { get; set; }

        public virtual ICollection<TblProcesses> TblProcesses { get; set; }
    }
}
