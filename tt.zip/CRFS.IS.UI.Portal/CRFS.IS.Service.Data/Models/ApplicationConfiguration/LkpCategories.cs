﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpCategories
    {
        public LkpCategories()
        {
            TblProcesses = new HashSet<TblProcesses>();
        }

        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public bool Active { get; set; }
        public DateTime DateEntered { get; set; }
        public DateTime? DateUpdated { get; set; }

        public virtual ICollection<TblProcesses> TblProcesses { get; set; }
    }
}
