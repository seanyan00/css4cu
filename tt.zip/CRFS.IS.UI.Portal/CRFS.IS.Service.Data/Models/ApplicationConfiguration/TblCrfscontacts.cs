﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblCrfscontacts
    {
        public int CrfscontactId { get; set; }
        public int ContactTypeId { get; set; }
        public string Crfsname { get; set; }
        public string Crfsaddress { get; set; }
        public string Crfscity { get; set; }
        public string Crfsstate { get; set; }
        public string CrfszipCode { get; set; }
        public string CrfsphoneNumber { get; set; }
        public string CrfsfaxNumber { get; set; }
        public string CrfscontactName { get; set; }
        public string ContactEmailAddress { get; set; }
        public string ContactPhoneNumber { get; set; }
        public string ContactExtension { get; set; }
        public bool MarkedForDelete { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual LkpContactTypes ContactType { get; set; }
    }
}
