﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpAutoDataDistributionParameters
    {
        public LkpAutoDataDistributionParameters()
        {
            TblAutoDataDistributionParameterValues = new HashSet<TblAutoDataDistributionParameterValues>();
        }

        public int AutoDataDistributionParameterId { get; set; }
        public string ParameterName { get; set; }
        public string Comment { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual ICollection<TblAutoDataDistributionParameterValues> TblAutoDataDistributionParameterValues { get; set; }
    }
}
