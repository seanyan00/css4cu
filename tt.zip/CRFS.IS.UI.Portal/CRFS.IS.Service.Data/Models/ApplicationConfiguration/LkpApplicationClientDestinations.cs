﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpApplicationClientDestinations
    {
        public long ApplicationClientDestinationId { get; set; }
        public DateTime EneredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public int ClientId { get; set; }
        public int ApplicationId { get; set; }
        public long DelieveryTypeId { get; set; }
        public string DeliveryLocation { get; set; }
        public long ArchiveTypeId { get; set; }
        public string ArchiveLocation { get; set; }

        public virtual LkpApplications Application { get; set; }
        public virtual LkpDestinationTypes ArchiveType { get; set; }
        public virtual LkpDestinationTypes DelieveryType { get; set; }
        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
    }
}
