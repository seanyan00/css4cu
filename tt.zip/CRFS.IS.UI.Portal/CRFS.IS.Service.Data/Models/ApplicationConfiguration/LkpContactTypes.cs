﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpContactTypes
    {
        public LkpContactTypes()
        {
            TblClientContacts = new HashSet<TblClientContacts>();
        }

        public int ContactTypeId { get; set; }
        public string ContactTypeName { get; set; }
        public bool MarkedForDelete { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual ICollection<TblClientContacts> TblClientContacts { get; set; }
    }
}
