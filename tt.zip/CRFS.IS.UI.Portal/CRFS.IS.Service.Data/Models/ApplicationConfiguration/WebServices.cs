﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class WebServices
    {
        public WebServices()
        {
            WebServiceDocuwareInstances = new HashSet<WebServiceDocuwareInstances>();
        }

        public int WebServiceId { get; set; }
        public int WebServiceTypeId { get; set; }
        public string WebServiceName { get; set; }
        public int PortNumber { get; set; }
        public int ServerId { get; set; }
        public bool MarkedForDelete { get; set; }
        public bool? Active { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }

        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual Servers Server { get; set; }
        public virtual WebServiceTypes WebServiceType { get; set; }
        public virtual ICollection<WebServiceDocuwareInstances> WebServiceDocuwareInstances { get; set; }
    }
}
