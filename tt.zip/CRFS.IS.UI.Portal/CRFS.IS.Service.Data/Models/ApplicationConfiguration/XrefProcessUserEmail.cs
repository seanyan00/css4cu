﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefProcessUserEmail
    {
        public int ProcessUserEmailId { get; set; }
        public int ProcessId { get; set; }
        public int SecurityUserId { get; set; }
        public bool? ExcludeUntilProduction { get; set; }

        public virtual TblProcesses Process { get; set; }
    }
}
