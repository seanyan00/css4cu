﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class XrefProcessUserEmail
    {
        public int ProcessUserEmailId { get; set; }
        public int ProcessId { get; set; }
        public int SecurityUserId { get; set; }
        public bool? ExcludeUntilProduction { get; set; }

        public virtual TblProcesses Process { get; set; }
    }
}
