﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblSubscriptionsDataDriven
    {
        public TblSubscriptionsDataDriven()
        {
            TblSubscriptionInstance = new HashSet<TblSubscriptionInstance>();
            TblSubscriptionUser = new HashSet<TblSubscriptionUser>();
        }

        public int SubscriptionId { get; set; }
        public Guid? ReportId { get; set; }
        public string SubscriptionName { get; set; }

        public virtual ICollection<TblSubscriptionInstance> TblSubscriptionInstance { get; set; }
        public virtual ICollection<TblSubscriptionUser> TblSubscriptionUser { get; set; }
    }
}
