﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class VwExternalClientReportsDefinitionTopLevel
    {
        public int ApplicationId { get; set; }
        public string ApplicationName { get; set; }
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public int ReportId { get; set; }
        public string ReportName { get; set; }
        public int DeliveryFormatId { get; set; }
        public string DeliveryFormatName { get; set; }
        public string FileExtension { get; set; }
        public int StoredProcedureId { get; set; }
        public string DatabaseName { get; set; }
        public string SchemaName { get; set; }
        public string StoredProcedureName { get; set; }
        public int ExecOrder { get; set; }
    }
}
