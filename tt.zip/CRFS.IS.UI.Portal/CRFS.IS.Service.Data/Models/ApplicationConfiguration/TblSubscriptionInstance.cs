﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblSubscriptionInstance
    {
        public TblSubscriptionInstance()
        {
            TblSubscriptionUserParameters = new HashSet<TblSubscriptionUserParameters>();
        }

        public int SubscriptionInstanceId { get; set; }
        public int SubscriptionId { get; set; }
        public string SubscriptionInstanceNote { get; set; }

        public virtual TblSubscriptionsDataDriven Subscription { get; set; }
        public virtual ICollection<TblSubscriptionUserParameters> TblSubscriptionUserParameters { get; set; }
    }
}
