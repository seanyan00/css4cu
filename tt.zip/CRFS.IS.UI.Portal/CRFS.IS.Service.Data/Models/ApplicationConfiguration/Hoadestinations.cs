﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class Hoadestinations
    {
        public int HoadestinationId { get; set; }
        public int ClientId { get; set; }
        public int BusinessEntityId { get; set; }
        public int DirectionId { get; set; }
        public bool? Active { get; set; }
        public string ArchiveFolder { get; set; }
        public string Sftpfolder { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public string SourceHost { get; set; }
        public string SourceFolder { get; set; }
        public string TargetHost { get; set; }
        public string TargetFolder { get; set; }

        public virtual LkpBusinessEntities BusinessEntity { get; set; }
        public virtual LkpClients Client { get; set; }
        public virtual LkpDirections Direction { get; set; }
        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
    }
}
