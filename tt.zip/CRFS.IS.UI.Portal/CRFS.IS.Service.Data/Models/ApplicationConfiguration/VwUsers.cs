﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class VwUsers
    {
        public int UserId { get; set; }
        public string Login { get; set; }
        public string UserName { get; set; }
        public int SecurityGroupId { get; set; }
        public bool? Active { get; set; }
        public string PhoneNum { get; set; }
        public DateTime LastPwchange { get; set; }
        public string UserEmailAddress { get; set; }
    }
}
