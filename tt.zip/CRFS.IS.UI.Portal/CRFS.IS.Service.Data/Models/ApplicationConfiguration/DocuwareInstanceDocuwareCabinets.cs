﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class DocuwareInstanceDocuwareCabinets
    {
        public DocuwareInstanceDocuwareCabinets()
        {
            DocuwareInstanceDocuwareCabinetColumns = new HashSet<DocuwareInstanceDocuwareCabinetColumns>();
        }

        public int DocuwareInstanceDocuwareCabinetId { get; set; }
        public int DocuwareInstanceId { get; set; }
        public int DocuwareCabinetId { get; set; }
        public bool MarkedForDelete { get; set; }
        public bool? Active { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }

        public virtual DocuwareCabinets DocuwareCabinet { get; set; }
        public virtual DocuwareInstances DocuwareInstance { get; set; }
        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual ICollection<DocuwareInstanceDocuwareCabinetColumns> DocuwareInstanceDocuwareCabinetColumns { get; set; }
    }
}
