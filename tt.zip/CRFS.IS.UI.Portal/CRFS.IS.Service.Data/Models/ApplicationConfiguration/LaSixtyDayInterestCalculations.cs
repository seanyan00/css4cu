﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LaSixtyDayInterestCalculations
    {
        public LaSixtyDayInterestCalculations()
        {
            LaClientCalculationDefinitions = new HashSet<LaClientCalculationDefinitions>();
        }

        public int SixtyDayInterestCalculationId { get; set; }
        public string CalculationName { get; set; }
        public string CalculationDescription { get; set; }

        public virtual ICollection<LaClientCalculationDefinitions> LaClientCalculationDefinitions { get; set; }
    }
}
