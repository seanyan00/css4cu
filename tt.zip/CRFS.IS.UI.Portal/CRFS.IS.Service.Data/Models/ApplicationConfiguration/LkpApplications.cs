﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpApplications
    {
        public LkpApplications()
        {
            ApplicationAliases = new HashSet<ApplicationAliases>();
            DocuwareInstances = new HashSet<DocuwareInstances>();
            LkpApplicationClientDestinations = new HashSet<LkpApplicationClientDestinations>();
            LkpBusinessEntities = new HashSet<LkpBusinessEntities>();
            LkpEntityGroups = new HashSet<LkpEntityGroups>();
            LkpGroupContacts = new HashSet<LkpGroupContacts>();
            TblEntityGroupContacts = new HashSet<TblEntityGroupContacts>();
            XrefApplicationRoles = new HashSet<XrefApplicationRoles>();
            XrefApplicationUser = new HashSet<XrefApplicationUser>();
            XrefApplicationsClients = new HashSet<XrefApplicationsClients>();
            XrefBusinessEntityGroup = new HashSet<XrefBusinessEntityGroup>();
        }

        public int ApplicationId { get; set; }
        public string ApplicationName { get; set; }
        public string ApplicationUrl { get; set; }
        public int? CmsformId { get; set; }
        public DateTime EffectiveFromDate { get; set; }
        public DateTime EffectiveToDate { get; set; }
        public bool? Active { get; set; }
        public DateTime EnteredDate { get; set; }
        public int? EnteredByUserId { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUserId { get; set; }

        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual ICollection<ApplicationAliases> ApplicationAliases { get; set; }
        public virtual ICollection<DocuwareInstances> DocuwareInstances { get; set; }
        public virtual ICollection<LkpApplicationClientDestinations> LkpApplicationClientDestinations { get; set; }
        public virtual ICollection<LkpBusinessEntities> LkpBusinessEntities { get; set; }
        public virtual ICollection<LkpEntityGroups> LkpEntityGroups { get; set; }
        public virtual ICollection<LkpGroupContacts> LkpGroupContacts { get; set; }
        public virtual ICollection<TblEntityGroupContacts> TblEntityGroupContacts { get; set; }
        public virtual ICollection<XrefApplicationRoles> XrefApplicationRoles { get; set; }
        public virtual ICollection<XrefApplicationUser> XrefApplicationUser { get; set; }
        public virtual ICollection<XrefApplicationsClients> XrefApplicationsClients { get; set; }
        public virtual ICollection<XrefBusinessEntityGroup> XrefBusinessEntityGroup { get; set; }
    }
}
