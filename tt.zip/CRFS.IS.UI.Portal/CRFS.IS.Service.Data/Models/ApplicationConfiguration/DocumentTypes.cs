﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class DocumentTypes
    {
        public DocumentTypes()
        {
            DocumentTypesDocuwareProcessNames = new HashSet<DocumentTypesDocuwareProcessNames>();
            DocuwareCabinetDocumentTypes = new HashSet<DocuwareCabinetDocumentTypes>();
        }

        public int DocumentTypeId { get; set; }
        public string DocumentName { get; set; }
        public string DocumentDescription { get; set; }
        public bool MarkedForDelete { get; set; }
        public bool? Active { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }

        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual ICollection<DocumentTypesDocuwareProcessNames> DocumentTypesDocuwareProcessNames { get; set; }
        public virtual ICollection<DocuwareCabinetDocumentTypes> DocuwareCabinetDocumentTypes { get; set; }
    }
}
