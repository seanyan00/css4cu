﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class DeliveryFormats
    {
        public DeliveryFormats()
        {
            XrefApplicationClientReports = new HashSet<XrefApplicationClientReports>();
        }

        public int DeliveryFormatId { get; set; }
        public string DeliveryFormatName { get; set; }
        public string FileExtension { get; set; }
        public bool UseTextQualifier { get; set; }
        public string TextQualifier { get; set; }
        public bool? Active { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual ICollection<XrefApplicationClientReports> XrefApplicationClientReports { get; set; }
    }
}
