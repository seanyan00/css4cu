﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class XrefFtmsTaskEmailRecipients
    {
        public int TaskRecipientId { get; set; }
        public int JobId { get; set; }
        public int? TaskId { get; set; }
        public int RecipientId { get; set; }
        public string RecipientType { get; set; }
        public string MessageType { get; set; }

        public virtual LkpFtmsEmailRecipients TaskRecipient { get; set; }
    }
}
