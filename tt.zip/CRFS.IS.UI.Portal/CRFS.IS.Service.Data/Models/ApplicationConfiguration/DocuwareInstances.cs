﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class DocuwareInstances
    {
        public DocuwareInstances()
        {
            DocuwareInstanceDatabaseInstanceDatabases = new HashSet<DocuwareInstanceDatabaseInstanceDatabases>();
            DocuwareInstanceDocuwareCabinets = new HashSet<DocuwareInstanceDocuwareCabinets>();
            WebServiceDocuwareInstances = new HashSet<WebServiceDocuwareInstances>();
        }

        public int DocuwareInstanceId { get; set; }
        public string DocuwareName { get; set; }
        public int ApplicationId { get; set; }
        public int ServerId { get; set; }
        public bool MarkedForDelete { get; set; }
        public bool Active { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }

        public virtual LkpApplications Application { get; set; }
        public virtual Servers Server { get; set; }
        public virtual ICollection<DocuwareInstanceDatabaseInstanceDatabases> DocuwareInstanceDatabaseInstanceDatabases { get; set; }
        public virtual ICollection<DocuwareInstanceDocuwareCabinets> DocuwareInstanceDocuwareCabinets { get; set; }
        public virtual ICollection<WebServiceDocuwareInstances> WebServiceDocuwareInstances { get; set; }
    }
}
