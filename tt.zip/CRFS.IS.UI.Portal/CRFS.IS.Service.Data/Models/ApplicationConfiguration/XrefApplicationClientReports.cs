﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefApplicationClientReports
    {
        public XrefApplicationClientReports()
        {
            ClientReportJobs = new HashSet<ClientReportJobs>();
            DeliveryEndPoints = new HashSet<DeliveryEndPoints>();
            XrefAppClientReportProcedureParameterValues = new HashSet<XrefAppClientReportProcedureParameterValues>();
            XrefReportRecipients = new HashSet<XrefReportRecipients>();
            XrefUserReportRecipients = new HashSet<XrefUserReportRecipients>();
        }

        public int ApplicationClientReportId { get; set; }
        public int ApplicationClientId { get; set; }
        public int ReportId { get; set; }
        public int DeliveryFormatId { get; set; }
        public bool? Active { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual XrefApplicationsClients ApplicationClient { get; set; }
        public virtual DeliveryFormats DeliveryFormat { get; set; }
        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual LkpReports Report { get; set; }
        public virtual ICollection<ClientReportJobs> ClientReportJobs { get; set; }
        public virtual ICollection<DeliveryEndPoints> DeliveryEndPoints { get; set; }
        public virtual ICollection<XrefAppClientReportProcedureParameterValues> XrefAppClientReportProcedureParameterValues { get; set; }
        public virtual ICollection<XrefReportRecipients> XrefReportRecipients { get; set; }
        public virtual ICollection<XrefUserReportRecipients> XrefUserReportRecipients { get; set; }
    }
}
