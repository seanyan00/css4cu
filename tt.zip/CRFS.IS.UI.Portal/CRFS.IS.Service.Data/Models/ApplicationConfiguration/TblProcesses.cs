﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblProcesses
    {
        public TblProcesses()
        {
            TblAutoDataDistributionDestinations = new HashSet<TblAutoDataDistributionDestinations>();
            TblAutoDataDistributionParameterValues = new HashSet<TblAutoDataDistributionParameterValues>();
            XrefProcessUserEmail = new HashSet<XrefProcessUserEmail>();
            XrefProcessesClients = new HashSet<XrefProcessesClients>();
        }

        public int ProcessId { get; set; }
        public int CategoryId { get; set; }
        public int DatabaseId { get; set; }
        public string ProcessName { get; set; }
        public bool Active { get; set; }
        public bool RequiresIntegrationSetup { get; set; }
        public DateTime DateEntered { get; set; }
        public DateTime? DateUpdated { get; set; }

        public virtual LkpCategories Category { get; set; }
        public virtual ICollection<TblAutoDataDistributionDestinations> TblAutoDataDistributionDestinations { get; set; }
        public virtual ICollection<TblAutoDataDistributionParameterValues> TblAutoDataDistributionParameterValues { get; set; }
        public virtual ICollection<XrefProcessUserEmail> XrefProcessUserEmail { get; set; }
        public virtual ICollection<XrefProcessesClients> XrefProcessesClients { get; set; }
    }
}
