﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class Rcosschedules
    {
        public Rcosschedules()
        {
            ClientReportJobs = new HashSet<ClientReportJobs>();
        }

        public int RcosscheduleId { get; set; }
        public string ScheduleName { get; set; }
        public bool? Enabled { get; set; }
        public int FrequencyType { get; set; }
        public int FrequencyInterval { get; set; }
        public int FrequencyIntervalRelative { get; set; }
        public int RunSession { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual ICollection<ClientReportJobs> ClientReportJobs { get; set; }
    }
}
