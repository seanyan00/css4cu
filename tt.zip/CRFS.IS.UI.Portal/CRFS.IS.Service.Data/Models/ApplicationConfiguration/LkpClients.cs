﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpClients
    {
        public LkpClients()
        {
            FileTransferManagementTasks = new HashSet<FileTransferManagementTasks>();
            Hoadestinations = new HashSet<Hoadestinations>();
            TblClientContacts = new HashSet<TblClientContacts>();
            XrefApplicationsClients = new HashSet<XrefApplicationsClients>();
            XrefClientUsdaclaimScope = new HashSet<XrefClientUsdaclaimScope>();
            XrefClientsUsers = new HashSet<XrefClientsUsers>();
            XrefProcessesClients = new HashSet<XrefProcessesClients>();
        }

        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public string ClientDisplayName { get; set; }
        public string ClientLegalName { get; set; }
        public string ClientAbbreviation { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public bool Active { get; set; }
        public bool MarkedForDelete { get; set; }
        public DateTime EffectiveFromDate { get; set; }
        public DateTime EffectiveToDate { get; set; }

        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual LaClientCalculationDefinitions LaClientCalculationDefinitions { get; set; }
        public virtual TblClientPdfcompression TblClientPdfcompression { get; set; }
        public virtual ICollection<FileTransferManagementTasks> FileTransferManagementTasks { get; set; }
        public virtual ICollection<Hoadestinations> Hoadestinations { get; set; }
        public virtual ICollection<TblClientContacts> TblClientContacts { get; set; }
        public virtual ICollection<XrefApplicationsClients> XrefApplicationsClients { get; set; }
        public virtual ICollection<XrefClientUsdaclaimScope> XrefClientUsdaclaimScope { get; set; }
        public virtual ICollection<XrefClientsUsers> XrefClientsUsers { get; set; }
        public virtual ICollection<XrefProcessesClients> XrefProcessesClients { get; set; }
    }
}
