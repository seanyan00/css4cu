﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpClientPoolClaimScope
    {
        public int ClientPoolClaimScopeId { get; set; }
        public int ClientId { get; set; }
    }
}
