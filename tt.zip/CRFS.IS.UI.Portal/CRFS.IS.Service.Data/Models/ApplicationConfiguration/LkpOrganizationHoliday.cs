﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpOrganizationHoliday
    {
        public int HolidayId { get; set; }
        public string Organization { get; set; }
        public DateTime HolidayDate { get; set; }
        public string HolidayDescription { get; set; }
    }
}
