﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpOrganizationHoliday
    {
        public int HolidayId { get; set; }
        public string Organization { get; set; }
        public DateTime HolidayDate { get; set; }
        public string HolidayDescription { get; set; }
    }
}
