﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpFtmstaskTypes
    {
        public LkpFtmstaskTypes()
        {
            LkpFtmsJobTasks = new HashSet<LkpFtmsJobTasks>();
        }

        public int TaskTypeId { get; set; }
        public string TaskType { get; set; }

        public virtual ICollection<LkpFtmsJobTasks> LkpFtmsJobTasks { get; set; }
    }
}
