﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpFtmsEmailTasks
    {
        public int TaskId { get; set; }
        public string EmailText { get; set; }
        public string EmailSubject { get; set; }
        public bool EmailFilesAsAttachments { get; set; }
        public bool SendEachMatchingFileAsSeparateEmail { get; set; }
        public bool IncludeFileDetailsInEmailBody { get; set; }
        public bool SendIfNoFilesProcessed { get; set; }

        public virtual LkpFtmsJobTasks Task { get; set; }
    }
}
