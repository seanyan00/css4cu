﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpFtmsEmailTasks
    {
        public int TaskId { get; set; }
        public string EmailText { get; set; }
        public string EmailSubject { get; set; }
        public bool EmailFilesAsAttachments { get; set; }
        public bool SendEachMatchingFileAsSeparateEmail { get; set; }
        public bool IncludeFileDetailsInEmailBody { get; set; }
        public bool SendIfNoFilesProcessed { get; set; }

        public virtual LkpFtmsJobTasks Task { get; set; }
    }
}
