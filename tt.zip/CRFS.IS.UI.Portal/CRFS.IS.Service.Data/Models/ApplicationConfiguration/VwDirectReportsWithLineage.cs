﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwDirectReportsWithLineage
    {
        public int? UserUserReportsToRelationshipId { get; set; }
        public int? ReportsToUserId { get; set; }
        public string ReportsToUser { get; set; }
        public int? UserId { get; set; }
        public string DirectReport { get; set; }
        public bool? MarkedForDelete { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUserId { get; set; }
        public int? Level { get; set; }
        public string Lineage { get; set; }
    }
}
