﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefClaimsManagementHudclaimsClaimType
    {
        public int ClaimsManagementHudclaimsClaimTypeId { get; set; }
        public int ClaimsManagementClaimTypeId { get; set; }
        public long HudclaimsClaimTypeId { get; set; }
    }
}
