﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class DocuwareCabinetDocumentTypes
    {
        public int DocuwareCabinetDocumentTypeId { get; set; }
        public int DocuwareCabinetId { get; set; }
        public int DocumentTypeId { get; set; }
        public bool MarkedForDelete { get; set; }
        public bool? Active { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }

        public virtual DocumentTypes DocumentType { get; set; }
        public virtual DocuwareCabinets DocuwareCabinet { get; set; }
        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
    }
}
