﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefAppplicationUserApplicationRole
    {
        public int AppplicationUserApplicationRoleId { get; set; }
        public long ApplicationUserId { get; set; }
        public int ApplicationRoleId { get; set; }
        public bool MarkedForDelete { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual XrefApplicationRoles ApplicationRole { get; set; }
        public virtual XrefApplicationUser ApplicationUser { get; set; }
        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
    }
}
