﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class XmlExtractionClaimTypeConfig
    {
        public int XmlextractionId { get; set; }
        public long ClaimType { get; set; }
        public long FhalookUpId { get; set; }
        public bool Active { get; set; }
        public DateTime DateAdded { get; set; }
        public int AddedBy { get; set; }
        public DateTime DateUpdated { get; set; }
        public int UpdatedBy { get; set; }
        public int FhaclaimGroup { get; set; }
        public string SubmitPart { get; set; }
    }
}
