﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class Ssispackages
    {
        public Ssispackages()
        {
            SsisconnectionManagers = new HashSet<SsisconnectionManagers>();
        }

        public int PackageId { get; set; }
        public string PackageName { get; set; }

        public virtual ICollection<SsisconnectionManagers> SsisconnectionManagers { get; set; }
    }
}
