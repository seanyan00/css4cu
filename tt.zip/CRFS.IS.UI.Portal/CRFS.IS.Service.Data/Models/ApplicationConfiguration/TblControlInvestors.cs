﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblControlInvestors
    {
        public TblControlInvestors()
        {
            XrefControlInvestorInvestorGroup = new HashSet<XrefControlInvestorInvestorGroup>();
        }

        public int InvestorId { get; set; }
        public string InvestorName { get; set; }
        public DateTime DateEntered { get; set; }
        public DateTime EffectiveFromDate { get; set; }
        public DateTime EffectiveToDate { get; set; }

        public virtual ICollection<XrefControlInvestorInvestorGroup> XrefControlInvestorInvestorGroup { get; set; }
    }
}
