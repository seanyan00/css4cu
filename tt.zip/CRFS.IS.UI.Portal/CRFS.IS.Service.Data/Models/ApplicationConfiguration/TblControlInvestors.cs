﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblControlInvestors
    {
        public int InvestorId { get; set; }
        public string InvestorName { get; set; }
        public DateTime DateEntered { get; set; }
        public DateTime EffectiveFromDate { get; set; }
        public DateTime EffectiveToDate { get; set; }
    }
}
