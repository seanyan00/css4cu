﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpUserAttributes
    {
        public LkpUserAttributes()
        {
            XrefUserUserAttributes = new HashSet<XrefUserUserAttributes>();
        }

        public int UserAttributeId { get; set; }
        public string UserAttributeName { get; set; }
        public int DataTypeId { get; set; }
        public bool MarkedForDelete { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual DataTypes DataType { get; set; }
        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual ICollection<XrefUserUserAttributes> XrefUserUserAttributes { get; set; }
    }
}
