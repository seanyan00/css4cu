﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefControlInvestorInvestorGroup
    {
        public int InvestorInvestorGroupId { get; set; }
        public int InvestorId { get; set; }
        public int InvestorGroupId { get; set; }

        public virtual TblControlInvestors Investor { get; set; }
        public virtual TblControlInvestorGroup InvestorGroup { get; set; }
    }
}
