﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class ClearTitleUpdateExceptions
    {
        public ClearTitleUpdateExceptions()
        {
            XrefClearTitleUpdateClearTitleExceptions = new HashSet<XrefClearTitleUpdateClearTitleExceptions>();
        }

        public long ClearTitleUpdateExceptionId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public bool MarkedForDelete { get; set; }
        public string Description { get; set; }

        public virtual ICollection<XrefClearTitleUpdateClearTitleExceptions> XrefClearTitleUpdateClearTitleExceptions { get; set; }
    }
}
