﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblDaLpsImportInvoiceMgmtExistingClaim
    {
        public int ReportRecordId { get; set; }
        public DateTime ImportDate { get; set; }
        public int? ImportedByUserId { get; set; }
        public string LpsServicer { get; set; }
        public string LpsClaimType { get; set; }
        public string LpsClaimNumber { get; set; }
        public string LpsInvestorLoanNumber { get; set; }
        public string LpsServicerLoanNumber { get; set; }
        public string LpsClaimStatus { get; set; }
        public string LpsCheckAchnumber { get; set; }
        public int? LpsCurrentStatusProcDays { get; set; }
        public DateTime? LpsSubmittedDate { get; set; }
        public int? LpsClaimAge { get; set; }
        public decimal? LpsRequestedAmount { get; set; }
        public decimal? LpsAmountToPay { get; set; }
        public DateTime? LpsClaimExportDate { get; set; }
        public string LpsProcessor { get; set; }
        public int? CmsClaimId { get; set; }
        public int? UpdateType { get; set; }
    }
}
