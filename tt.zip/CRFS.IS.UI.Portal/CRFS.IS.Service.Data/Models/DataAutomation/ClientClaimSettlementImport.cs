﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class ClientClaimSettlementImport
    {
        public string SettlementDateAmount { get; set; }
        public string Client { get; set; }
        public string FhacaseNumber { get; set; }
        public double? LoanNumber { get; set; }
        public string ClaimType { get; set; }
        public DateTime? SubmitDate { get; set; }
        public DateTime? SettlementDate { get; set; }
        public decimal? SettlementAmount { get; set; }
        public int? ClaimId { get; set; }
    }
}
