﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwPrecedentHoareferrals
    {
        public long DelegatedReferralId { get; set; }
        public int? HoaresponseId { get; set; }
        public string ClientName { get; set; }
        public string LoanNumber { get; set; }
        public string FhacaseNumber { get; set; }
        public int FhaclaimId { get; set; }
        public DateTime? DateReferredToVendor { get; set; }
        public DateTime? PrecedentInitialResponseDate { get; set; }
        public string PositiveHoadetermination { get; set; }
        public DateTime? OrgConfirmationDate { get; set; }
        public DateTime? PrecedentDocumentsProvidedDate { get; set; }
    }
}
