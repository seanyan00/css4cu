﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class WrkChaseIcc
    {
        public long Id { get; set; }
        public string LoanNo { get; set; }
        public string ClientNo { get; set; }
        public string FhaCaseNo { get; set; }
        public short BatchNo { get; set; }
        public string Mortgagor { get; set; }
        public string State { get; set; }
        public DateTime? SaleDate { get; set; }
        public DateTime? MarketableTitle { get; set; }
        public DateTime? ExpOfRedemption { get; set; }
        public DateTime? VacancyDate { get; set; }
        public DateTime? CcCompletedDt { get; set; }
        public string Analyst { get; set; }
        public DateTime? EditedDate { get; set; }
        public string CommentText { get; set; }
        public DateTime? LastPaidTaxDate { get; set; }
        public DateTime? ClearTitleDate { get; set; }
        public string FirmName { get; set; }
        public string IccAnalyst { get; set; }
        public DateTime? IccPrepDate { get; set; }
        public string ThirdPartyDeed { get; set; }
        public string PartaAnalyst { get; set; }
        public DateTime? AInQcr { get; set; }
        public DateTime? FileRcd { get; set; }
        public DateTime? PartaApproved { get; set; }
        public string SubjectCode { get; set; }
        public DateTime? ARtnToAnalyst { get; set; }
        public DateTime? PartaSub { get; set; }
    }
}
