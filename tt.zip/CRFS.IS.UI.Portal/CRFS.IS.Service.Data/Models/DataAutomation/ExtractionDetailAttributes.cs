﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class ExtractionDetailAttributes
    {
        public ExtractionDetailAttributes()
        {
            DataExtractionDetails = new HashSet<DataExtractionDetails>();
            XrefClientProcessExtractionDetailAttributeSortOrders = new HashSet<XrefClientProcessExtractionDetailAttributeSortOrders>();
        }

        public int ExtractionDetailAttributeId { get; set; }
        public string ExtractionDetailAttributeName { get; set; }
        public bool Active { get; set; }

        public virtual ICollection<DataExtractionDetails> DataExtractionDetails { get; set; }
        public virtual ICollection<XrefClientProcessExtractionDetailAttributeSortOrders> XrefClientProcessExtractionDetailAttributeSortOrders { get; set; }
    }
}
