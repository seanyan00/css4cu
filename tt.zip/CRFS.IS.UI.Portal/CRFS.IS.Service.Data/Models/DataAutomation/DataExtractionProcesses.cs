﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class DataExtractionProcesses
    {
        public DataExtractionProcesses()
        {
            DataExtractionLogs = new HashSet<DataExtractionLogs>();
            XrefClientProcessExtractionDetailAttributeSortOrders = new HashSet<XrefClientProcessExtractionDetailAttributeSortOrders>();
        }

        public int DataExtractionProcessId { get; set; }
        public string DataExtractionProcessName { get; set; }
        public bool Active { get; set; }

        public virtual ICollection<DataExtractionLogs> DataExtractionLogs { get; set; }
        public virtual ICollection<XrefClientProcessExtractionDetailAttributeSortOrders> XrefClientProcessExtractionDetailAttributeSortOrders { get; set; }
    }
}
