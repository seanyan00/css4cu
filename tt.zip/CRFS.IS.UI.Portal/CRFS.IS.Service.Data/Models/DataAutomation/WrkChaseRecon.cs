﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class WrkChaseRecon
    {
        public long Id { get; set; }
        public string FhaCaseNo { get; set; }
        public string LoanNumber { get; set; }
        public string ClientNo { get; set; }
        public int? BatchNo { get; set; }
        public string Mortgagor { get; set; }
        public string PropState { get; set; }
        public DateTime? CommentDate { get; set; }
        public string CommentText { get; set; }
        public string CommentCode { get; set; }
        public string CommentAnalyst { get; set; }
        public string ItemType { get; set; }
        public string Descr { get; set; }
        public string InfoComments { get; set; }
        public DateTime? InfoRequested { get; set; }
        public string FirmName { get; set; }
        public DateTime? SaleDate { get; set; }
    }
}
