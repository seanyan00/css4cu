﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpAutosystemtype
    {
        public string Code { get; set; }
        public string Description { get; set; }
    }
}
