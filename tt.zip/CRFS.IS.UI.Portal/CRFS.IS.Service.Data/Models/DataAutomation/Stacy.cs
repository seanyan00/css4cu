﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class Stacy
    {
        public string ClientName { get; set; }
        public string LoanNumber { get; set; }
        public string ClaimType { get; set; }
        public string InvestorName { get; set; }
        public string InvestorLoanNumber { get; set; }
        public DateTime? ReceivedDate { get; set; }
        public DateTime? ClaimDueDate { get; set; }
        public DateTime? SlaDueDate { get; set; }
        public DateTime? IndustryDueDate { get; set; }
        public DateTime? PfsSettlementDate { get; set; }
        public string TpsDate { get; set; }
        public DateTime? GaDate { get; set; }
    }
}
