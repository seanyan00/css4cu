﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpTargets
    {
        public LkpTargets()
        {
            TblSystemTargetLog = new HashSet<TblSystemTargetLog>();
        }

        public long TargetId { get; set; }
        public string TargetCommandCode { get; set; }
        public string TargetDescription { get; set; }

        public virtual ICollection<TblSystemTargetLog> TblSystemTargetLog { get; set; }
    }
}
