﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefClientProcessExtractionDetailAttributeSortOrders
    {
        public int ClientProcessExtractionDetailAttributeSortOrderId { get; set; }
        public int DataExtractionProcessId { get; set; }
        public int ExtractionDetailAttributeId { get; set; }
        public int ClientId { get; set; }
        public int SortOrder { get; set; }

        public virtual DataExtractionProcesses DataExtractionProcess { get; set; }
        public virtual ExtractionDetailAttributes ExtractionDetailAttribute { get; set; }
    }
}
