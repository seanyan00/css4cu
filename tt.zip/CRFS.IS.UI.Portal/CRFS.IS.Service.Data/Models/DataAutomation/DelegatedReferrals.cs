﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class DelegatedReferrals
    {
        public long DelegatedReferralId { get; set; }
        public long AutomationJobLogId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public int FhaclaimId { get; set; }
        public int ReferredToBusinessEntityId { get; set; }
        public bool FollowUpCreated { get; set; }
        public DateTime? FollowUpCreatedDate { get; set; }
        public int? FollowUpId { get; set; }
        public bool SftpfileCreated { get; set; }
        public DateTime? SftpfileCreateDate { get; set; }
        public bool OutboundSuccessful { get; set; }
        public bool IdreportReturned { get; set; }
        public DateTime? IdreportDate { get; set; }
        public string IdreportName { get; set; }
        public bool FollowUpNotOpenException { get; set; }
        public bool IdentifiedAsHoa { get; set; }
        public bool ClosedFirstFollowup { get; set; }
        public DateTime? ClosedFirstFollowupDate { get; set; }
        public bool NewHoafollowUpCreated { get; set; }
        public DateTime? NewHoafollowUpCreateDate { get; set; }
        public int? NewHoafollowUpId { get; set; }
        public bool InboundSuccessful { get; set; }
        public bool? MarkedForDelete { get; set; }
        public int? CharacterizationResult { get; set; }

        public virtual TblAutomationJobLog AutomationJobLog { get; set; }
    }
}
