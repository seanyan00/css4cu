﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwWfbiRoles
    {
        public int ApplicationRoleId { get; set; }
        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public int ApplicationId { get; set; }
        public string ApplicationName { get; set; }
    }
}
