﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpAutomationProcess
    {
        public LkpAutomationProcess()
        {
            LkpSpecialProcess = new HashSet<LkpSpecialProcess>();
            XrefClientProcess = new HashSet<XrefClientProcess>();
            XrefDataAutomationDocuware = new HashSet<XrefDataAutomationDocuware>();
        }

        public int AutomationProcessId { get; set; }
        public int ProcessNumber { get; set; }
        public string ProcessDescription { get; set; }

        public virtual ICollection<LkpSpecialProcess> LkpSpecialProcess { get; set; }
        public virtual ICollection<XrefClientProcess> XrefClientProcess { get; set; }
        public virtual ICollection<XrefDataAutomationDocuware> XrefDataAutomationDocuware { get; set; }
    }
}
