﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblTargetActionLog
    {
        public long TargetActionLogId { get; set; }
        public long SystemTargetLogId { get; set; }
        public long ActionId { get; set; }
        public DateTime? ActionStartDate { get; set; }
        public DateTime? ActionEndDate { get; set; }
        public long? ResultId { get; set; }
        public string ResultAttribute { get; set; }
        public string ResultValue { get; set; }

        public virtual LkpActions Action { get; set; }
        public virtual LkpResults Result { get; set; }
        public virtual TblSystemTargetLog SystemTargetLog { get; set; }
    }
}
