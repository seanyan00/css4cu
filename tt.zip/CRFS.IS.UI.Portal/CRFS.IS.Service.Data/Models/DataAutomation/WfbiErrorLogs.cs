﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class WfbiErrorLogs
    {
        public long ErrorLogId { get; set; }
        public long WfbiBatchLogId { get; set; }
        public DateTime Datestamp { get; set; }
        public string ErrorText { get; set; }

        public virtual WfbiBatchLogs WfbiBatchLog { get; set; }
    }
}
