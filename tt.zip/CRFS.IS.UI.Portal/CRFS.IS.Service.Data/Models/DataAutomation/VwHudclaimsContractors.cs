﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwHudclaimsContractors
    {
        public string ApplicationName { get; set; }
        public int ApplicationId { get; set; }
        public int? CmsformId { get; set; }
        public int EntityTypeId { get; set; }
        public string EntityTypeName { get; set; }
        public int BusinessEntityId { get; set; }
        public string BusinessEntityName { get; set; }
    }
}
