﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class ClearTitleBatches
    {
        public ClearTitleBatches()
        {
            ClearTitleUpdates = new HashSet<ClearTitleUpdates>();
        }

        public long ClearTitleBatchId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public bool MarkedForDelete { get; set; }
        public string FileName { get; set; }

        public virtual ICollection<ClearTitleUpdates> ClearTitleUpdates { get; set; }
    }
}
