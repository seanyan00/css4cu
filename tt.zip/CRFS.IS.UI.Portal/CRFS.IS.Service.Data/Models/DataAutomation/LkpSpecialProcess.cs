﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpSpecialProcess
    {
        public int SpecialProcessId { get; set; }
        public int AutomationProcessId { get; set; }
        public string Reason { get; set; }
        public DateTime DateEntered { get; set; }
        public DateTime DateUpdated { get; set; }

        public virtual LkpAutomationProcess AutomationProcess { get; set; }
    }
}
