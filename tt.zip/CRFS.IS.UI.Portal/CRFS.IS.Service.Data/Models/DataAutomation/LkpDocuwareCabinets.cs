﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpDocuwareCabinets
    {
        public LkpDocuwareCabinets()
        {
            XrefDataAutomationDocuware = new HashSet<XrefDataAutomationDocuware>();
        }

        public int CabinetId { get; set; }
        public string CabinetName { get; set; }

        public virtual ICollection<XrefDataAutomationDocuware> XrefDataAutomationDocuware { get; set; }
    }
}
