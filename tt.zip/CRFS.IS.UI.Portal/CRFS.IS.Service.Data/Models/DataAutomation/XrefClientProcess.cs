﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefClientProcess
    {
        public XrefClientProcess()
        {
            TblMachineProcessAssignments = new HashSet<TblMachineProcessAssignments>();
        }

        public int ClientProcessId { get; set; }
        public int AutomationClientId { get; set; }
        public int AutomationProcessId { get; set; }
        public int? AutomationSystemId { get; set; }
        public int ProcessOrder { get; set; }
        public int ProcessNumber { get; set; }

        public virtual LkpAutomationClients AutomationClient { get; set; }
        public virtual LkpAutomationProcess AutomationProcess { get; set; }
        public virtual LkpAutomationSystems AutomationSystem { get; set; }
        public virtual ICollection<TblMachineProcessAssignments> TblMachineProcessAssignments { get; set; }
    }
}
