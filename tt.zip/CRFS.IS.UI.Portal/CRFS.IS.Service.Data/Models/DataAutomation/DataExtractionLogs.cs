﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class DataExtractionLogs
    {
        public DataExtractionLogs()
        {
            DataExtractionDetails = new HashSet<DataExtractionDetails>();
        }

        public long DataExtractionLogId { get; set; }
        public int DataExtractionProcessId { get; set; }
        public int DataExtractionStatusId { get; set; }
        public int ClientId { get; set; }
        public DateTime DateStart { get; set; }
        public DateTime? DateEnd { get; set; }
        public bool MarkedForDelete { get; set; }

        public virtual DataExtractionProcesses DataExtractionProcess { get; set; }
        public virtual DataExtractionStatuses DataExtractionStatus { get; set; }
        public virtual ICollection<DataExtractionDetails> DataExtractionDetails { get; set; }
    }
}
