﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpDocType
    {
        public LkpDocType()
        {
            XrefDataAutomationDocuware = new HashSet<XrefDataAutomationDocuware>();
        }

        public int DocTypeId { get; set; }
        public string Type { get; set; }
        public string TypeDesc { get; set; }

        public virtual ICollection<XrefDataAutomationDocuware> XrefDataAutomationDocuware { get; set; }
    }
}
