﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CRFS.IS.Service.Data
{
    public partial class DataAutomationContext : DbContext
    {
        public DataAutomationContext()
        {
        }

        public DataAutomationContext(DbContextOptions<DataAutomationContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AssurantAutomationExceptionMatrix> AssurantAutomationExceptionMatrix { get; set; }
        public virtual DbSet<ClearTitleBatches> ClearTitleBatches { get; set; }
        public virtual DbSet<ClearTitleUpdateExceptions> ClearTitleUpdateExceptions { get; set; }
        public virtual DbSet<ClearTitleUpdates> ClearTitleUpdates { get; set; }
        public virtual DbSet<ClientClaimPackagesSent> ClientClaimPackagesSent { get; set; }
        public virtual DbSet<DataExtractionDetails> DataExtractionDetails { get; set; }
        public virtual DbSet<DataExtractionLogs> DataExtractionLogs { get; set; }
        public virtual DbSet<DataExtractionProcesses> DataExtractionProcesses { get; set; }
        public virtual DbSet<DataExtractionStatuses> DataExtractionStatuses { get; set; }
        public virtual DbSet<DelegatedReferrals> DelegatedReferrals { get; set; }
        public virtual DbSet<ExtractionDetailAttributes> ExtractionDetailAttributes { get; set; }
        public virtual DbSet<HoaImportProcessing> HoaImportProcessing { get; set; }
        public virtual DbSet<Hoaresponses> Hoaresponses { get; set; }
        public virtual DbSet<LkpActions> LkpActions { get; set; }
        public virtual DbSet<LkpAutomationClients> LkpAutomationClients { get; set; }
        public virtual DbSet<LkpAutomationProcess> LkpAutomationProcess { get; set; }
        public virtual DbSet<LkpAutomationSystems> LkpAutomationSystems { get; set; }
        public virtual DbSet<LkpAutosystemtype> LkpAutosystemtype { get; set; }
        public virtual DbSet<LkpDocType> LkpDocType { get; set; }
        public virtual DbSet<LkpDocuwareCabinets> LkpDocuwareCabinets { get; set; }
        public virtual DbSet<LkpDocuwareProcesses> LkpDocuwareProcesses { get; set; }
        public virtual DbSet<LkpResults> LkpResults { get; set; }
        public virtual DbSet<LkpSpecialProcess> LkpSpecialProcess { get; set; }
        public virtual DbSet<LkpTargets> LkpTargets { get; set; }
        public virtual DbSet<ManualDelegatedReferralRequests> ManualDelegatedReferralRequests { get; set; }
        public virtual DbSet<StgHoaresponse> StgHoaresponse { get; set; }
        public virtual DbSet<TblAutomationJobLog> TblAutomationJobLog { get; set; }
        public virtual DbSet<TblDaLpsImportInvoiceMgmtExistingClaim> TblDaLpsImportInvoiceMgmtExistingClaim { get; set; }
        public virtual DbSet<TblDaLpsImportInvoiceMgmtExistingClaimHistory> TblDaLpsImportInvoiceMgmtExistingClaimHistory { get; set; }
        public virtual DbSet<TblJobSystemLog> TblJobSystemLog { get; set; }
        public virtual DbSet<TblMachineProcessAssignments> TblMachineProcessAssignments { get; set; }
        public virtual DbSet<TblSystemTargetLog> TblSystemTargetLog { get; set; }
        public virtual DbSet<TblTargetActionLog> TblTargetActionLog { get; set; }
        public virtual DbSet<VwDaIncompleteManualDelegatedReferrals> VwDaIncompleteManualDelegatedReferrals { get; set; }
        public virtual DbSet<VwHudclaimsContractors> VwHudclaimsContractors { get; set; }
        public virtual DbSet<VwPrecedentHoareferrals> VwPrecedentHoareferrals { get; set; }
        public virtual DbSet<VwUsers> VwUsers { get; set; }
        public virtual DbSet<VwWfbiRoles> VwWfbiRoles { get; set; }
        public virtual DbSet<VwWfbiUserApplicationRole> VwWfbiUserApplicationRole { get; set; }
        public virtual DbSet<WfbiBatchLogs> WfbiBatchLogs { get; set; }
        public virtual DbSet<WfbiBatchStatuses> WfbiBatchStatuses { get; set; }
        public virtual DbSet<WfbiErrorLogs> WfbiErrorLogs { get; set; }
        public virtual DbSet<XrefClearTitleUpdateClearTitleExceptions> XrefClearTitleUpdateClearTitleExceptions { get; set; }
        public virtual DbSet<XrefClientProcess> XrefClientProcess { get; set; }
        public virtual DbSet<XrefClientProcessExtractionDetailAttributeSortOrders> XrefClientProcessExtractionDetailAttributeSortOrders { get; set; }
        public virtual DbSet<XrefDataAutomationDocuware> XrefDataAutomationDocuware { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=vm-sql1-dev.dev.crfs.crfservices.com\\cms_d;Initial Catalog=DataAutomation;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AssurantAutomationExceptionMatrix>(entity =>
            {
                entity.HasComment("A table that contains a list of Exceptions in relation to the Assurant Automation Matrix.");

                entity.HasIndex(e => e.BitValue)
                    .HasName("UK1_AssurantAutomationExceptionMatrix")
                    .IsUnique();

                entity.HasIndex(e => new { e.ReferredByCrfs, e.ReturnedByAssurant, e.Hoadetermination, e.FollowupExists, e.FollowupComplete })
                    .HasName("UK2_AssurantAutomationExceptionMatrix")
                    .IsUnique();

                entity.Property(e => e.AssurantAutomationExceptionMatrixId).HasColumnName("AssurantAutomationExceptionMatrixID");

                entity.Property(e => e.Hoadetermination).HasColumnName("HOADetermination");

                entity.Property(e => e.ReferredByCrfs).HasColumnName("ReferredByCRFS");

                entity.Property(e => e.Result)
                    .IsRequired()
                    .HasMaxLength(150)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ClearTitleBatches>(entity =>
            {
                entity.HasKey(e => e.ClearTitleBatchId);

                entity.HasComment("An empty table. Possible removal.");

                entity.Property(e => e.ClearTitleBatchId).HasColumnName("ClearTitleBatchID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FileName)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");
            });

            modelBuilder.Entity<ClearTitleUpdateExceptions>(entity =>
            {
                entity.HasKey(e => e.ClearTitleUpdateExceptionId);

                entity.HasComment("A table that contains Exception status updates with various descriptions.");

                entity.Property(e => e.ClearTitleUpdateExceptionId).HasColumnName("ClearTitleUpdateExceptionID");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");
            });

            modelBuilder.Entity<ClearTitleUpdates>(entity =>
            {
                entity.HasKey(e => e.ClearTitleUpdateId);

                entity.HasComment("An empty table that utilizes the ClearTitleBatches table. Possible removal.");

                entity.Property(e => e.ClearTitleUpdateId).HasColumnName("ClearTitleUpdateID");

                entity.Property(e => e.ClearTitleBatchId).HasColumnName("ClearTitleBatchID");

                entity.Property(e => e.ClearTitleDataRemove)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.ClearTitleDate).HasColumnType("datetime");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FhacaseNumber)
                    .IsRequired()
                    .HasColumnName("FHACaseNumber")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.InvTrkClaimId).HasColumnName("InvTrkClaimID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.LoanNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.ClearTitleBatch)
                    .WithMany(p => p.ClearTitleUpdates)
                    .HasForeignKey(d => d.ClearTitleBatchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ClearTitleBatches_ClearTitleUpdates");
            });

            modelBuilder.Entity<ClientClaimPackagesSent>(entity =>
            {
                entity.HasKey(e => e.PackageSentId)
                    .HasName("PK__ClientCl__AE9B04DCDE558613");

                entity.Property(e => e.PackageSentId).HasColumnName("PackageSentID");

                entity.Property(e => e.ClaimCategory)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimPackageSentDate).HasColumnType("date");

                entity.Property(e => e.ClaimSubmitDate).HasColumnType("date");

                entity.Property(e => e.ClaimType)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.LoanNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<DataExtractionDetails>(entity =>
            {
                entity.HasKey(e => e.DataExtractionDetailId);

                entity.HasComment("A table that logs data extractions, their DetailAttributeID, and what the DetailValue is.");

                entity.HasIndex(e => new { e.DataExtractionLogId, e.ExtractionDetailAttributeId })
                    .HasName("UK1_DataExtractionDetails_DataExtractionLogIDExtractionDetailAttributeID")
                    .IsUnique();

                entity.Property(e => e.DataExtractionDetailId).HasColumnName("DataExtractionDetailID");

                entity.Property(e => e.DataExtractionLogId).HasColumnName("DataExtractionLogID");

                entity.Property(e => e.ExtractionDetailAttributeId).HasColumnName("ExtractionDetailAttributeID");

                entity.Property(e => e.ExtractionDetailValue)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.DataExtractionLog)
                    .WithMany(p => p.DataExtractionDetails)
                    .HasForeignKey(d => d.DataExtractionLogId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_DataExtractionDetails_DataExtractionLogs");

                entity.HasOne(d => d.ExtractionDetailAttribute)
                    .WithMany(p => p.DataExtractionDetails)
                    .HasForeignKey(d => d.ExtractionDetailAttributeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_DataExtractionDetails_ExtractionDetailAttributes");
            });

            modelBuilder.Entity<DataExtractionLogs>(entity =>
            {
                entity.HasKey(e => e.DataExtractionLogId);

                entity.HasComment("A table that keeps track of the extraction process. Each extract is associated with an ID and ClientID.");

                entity.Property(e => e.DataExtractionLogId).HasColumnName("DataExtractionLogID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.DataExtractionProcessId).HasColumnName("DataExtractionProcessID");

                entity.Property(e => e.DataExtractionStatusId).HasColumnName("DataExtractionStatusID");

                entity.Property(e => e.DateEnd).HasColumnType("datetime");

                entity.Property(e => e.DateStart).HasColumnType("datetime");

                entity.HasOne(d => d.DataExtractionProcess)
                    .WithMany(p => p.DataExtractionLogs)
                    .HasForeignKey(d => d.DataExtractionProcessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_DataExtractionLogs_DataExtractionProcesses");

                entity.HasOne(d => d.DataExtractionStatus)
                    .WithMany(p => p.DataExtractionLogs)
                    .HasForeignKey(d => d.DataExtractionStatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_DataExtractionLogs_DataExtractionStatuses");
            });

            modelBuilder.Entity<DataExtractionProcesses>(entity =>
            {
                entity.HasKey(e => e.DataExtractionProcessId);

                entity.HasComment("A table that contains two rows which contain the Data Extraction Process Name.");

                entity.HasIndex(e => e.DataExtractionProcessName)
                    .HasName("UK1_DataExtractionProcesses_DataExtractionProcessName")
                    .IsUnique();

                entity.Property(e => e.DataExtractionProcessId).HasColumnName("DataExtractionProcessID");

                entity.Property(e => e.DataExtractionProcessName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<DataExtractionStatuses>(entity =>
            {
                entity.HasKey(e => e.DataExtractionStatusId);

                entity.HasComment("A table that lists each Data Extraction Status and whether they are active(or not).");

                entity.HasIndex(e => e.DataExtractionStatus)
                    .HasName("UK1_DataExtractionStatuses_DataExtractionStatus")
                    .IsUnique();

                entity.Property(e => e.DataExtractionStatusId).HasColumnName("DataExtractionStatusID");

                entity.Property(e => e.DataExtractionStatus)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<DelegatedReferrals>(entity =>
            {
                entity.HasKey(e => e.DelegatedReferralId);

                entity.HasComment("A table that contains the log information of each DelegatedReferral in addition to relevant claim information.");

                entity.Property(e => e.DelegatedReferralId).HasColumnName("DelegatedReferralID");

                entity.Property(e => e.AutomationJobLogId).HasColumnName("AutomationJobLogID");

                entity.Property(e => e.ClosedFirstFollowupDate).HasColumnType("datetime");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.FollowUpCreatedDate).HasColumnType("datetime");

                entity.Property(e => e.FollowUpId).HasColumnName("FollowUpID");

                entity.Property(e => e.IdentifiedAsHoa).HasColumnName("IdentifiedAsHOA");

                entity.Property(e => e.IdreportDate)
                    .HasColumnName("IDReportDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.IdreportName)
                    .HasColumnName("IDReportName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.IdreportReturned).HasColumnName("IDReportReturned");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.MarkedForDelete).HasDefaultValueSql("((0))");

                entity.Property(e => e.NewHoafollowUpCreateDate)
                    .HasColumnName("NewHOAFollowUpCreateDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.NewHoafollowUpCreated).HasColumnName("NewHOAFollowUpCreated");

                entity.Property(e => e.NewHoafollowUpId).HasColumnName("NewHOAFollowUpID");

                entity.Property(e => e.ReferredToBusinessEntityId).HasColumnName("ReferredToBusinessEntityID");

                entity.Property(e => e.SftpfileCreateDate)
                    .HasColumnName("SFTPFileCreateDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.SftpfileCreated).HasColumnName("SFTPFileCreated");

                entity.HasOne(d => d.AutomationJobLog)
                    .WithMany(p => p.DelegatedReferrals)
                    .HasForeignKey(d => d.AutomationJobLogId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_DelegatedReferrals_tbl_AutomationJobLog");
            });

            modelBuilder.Entity<ExtractionDetailAttributes>(entity =>
            {
                entity.HasKey(e => e.ExtractionDetailAttributeId);

                entity.HasComment("A table that lists the Extraction Attribute Names and whether they are active or not.");

                entity.HasIndex(e => e.ExtractionDetailAttributeName)
                    .HasName("UK1_ExtractionDetailAttributes_ExtractionDetailAttributeName")
                    .IsUnique();

                entity.Property(e => e.ExtractionDetailAttributeId).HasColumnName("ExtractionDetailAttributeID");

                entity.Property(e => e.ExtractionDetailAttributeName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<HoaImportProcessing>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.ProcessDate).HasColumnType("datetime");

                entity.Property(e => e.ProcessId)
                    .HasColumnName("ProcessID")
                    .ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<Hoaresponses>(entity =>
            {
                entity.HasKey(e => e.HoaresponseId);

                entity.ToTable("HOAResponses");

                entity.Property(e => e.HoaresponseId).HasColumnName("HOAResponseID");

                entity.Property(e => e.AssignmentDate).HasColumnType("date");

                entity.Property(e => e.AssignmentStatus)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AssignmentStatusDate).HasColumnType("date");

                entity.Property(e => e.BorrowerFirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BorrowerFullName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.BorrowerLastName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CaseNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Contract)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Crfsclient)
                    .HasColumnName("CRFSClient")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.HoareferralId).HasColumnName("HOAReferralID");

                entity.Property(e => e.InvestorLoanNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.InvestorName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.OrgAddress)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OrgCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OrgConfirmationDate).HasColumnType("date");

                entity.Property(e => e.OrgConfirmationResult)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.OrgCounty)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.OrgDateDelinquencyCleared).HasColumnType("date");

                entity.Property(e => e.OrgEmail)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.OrgFax)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.OrgName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.OrgPaidThroughDate).HasColumnType("date");

                entity.Property(e => e.OrgPaymentFrequency)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.OrgPhone)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.OrgPositionType)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.OrgReoccurringPaymentAmt).HasColumnType("decimal(10, 2)");

                entity.Property(e => e.OrgRole)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.OrgState)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.OrgStatus)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OrgStatusDate).HasColumnType("date");

                entity.Property(e => e.OrgWebsite)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.OrgZip)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.PortfolioDescription)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PrecedentClient)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyAddress)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyState)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyStatus)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyStatusDate).HasColumnType("date");

                entity.Property(e => e.PropertyZip)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Sowdate)
                    .HasColumnName("SOWDate")
                    .HasColumnType("date");
            });

            modelBuilder.Entity<LkpActions>(entity =>
            {
                entity.HasKey(e => e.ActionId);

                entity.ToTable("lkp_Actions");

                entity.HasComment("A lookup table that contains various action descriptions listed by ActionID.");

                entity.HasIndex(e => e.ActionCode)
                    .HasName("UK1_lkp_Actions")
                    .IsUnique();

                entity.Property(e => e.ActionId).HasColumnName("ActionID");

                entity.Property(e => e.ActionCode)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ActionDescription)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpAutomationClients>(entity =>
            {
                entity.HasKey(e => e.AutomationClientId);

                entity.ToTable("lkp_AutomationClients");

                entity.HasComment("A lookup table that lists different Client Names and their abbreviations in regards to Automation.");

                entity.HasIndex(e => new { e.ClientName, e.ImportClientId })
                    .HasName("UK1_lkp_AutomationClients_ClientNameImportClientID")
                    .IsUnique();

                entity.Property(e => e.AutomationClientId).HasColumnName("AutomationClientID");

                entity.Property(e => e.ClientAbbreviation)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DateEntered)
                    .HasColumnType("smalldatetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ImportClientId)
                    .IsRequired()
                    .HasColumnName("ImportClientID")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpAutomationProcess>(entity =>
            {
                entity.HasKey(e => e.AutomationProcessId)
                    .HasName("lkp_AutomationProcess_PK");

                entity.ToTable("lkp_AutomationProcess");

                entity.HasComment("A lookup table that describes each stage of the automation process.");

                entity.Property(e => e.AutomationProcessId).HasColumnName("AutomationProcessID");

                entity.Property(e => e.ProcessDescription)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpAutomationSystems>(entity =>
            {
                entity.HasKey(e => e.AutomationSystemId);

                entity.ToTable("lkp_AutomationSystems");

                entity.HasComment("A lookup table that lists the System Name, Type, and the System URL.");

                entity.Property(e => e.AutomationSystemId).HasColumnName("AutomationSystemID");

                entity.Property(e => e.AuthPmtAdvRetrieve)
                    .HasColumnName("Auth_PmtAdv_Retrieve")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.AuthSs820alt)
                    .HasColumnName("AuthSS_820Alt")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.AuthSs824alt)
                    .HasColumnName("AuthSS_824Alt")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.CmsClientId).HasColumnName("CMS_ClientID");

                entity.Property(e => e.CredentialsValid).HasDefaultValueSql("((0))");

                entity.Property(e => e.DateEntered)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DateUpdated)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.MainFrameCommand)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PwdchangeDate)
                    .HasColumnName("PWDChangeDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.SystemId)
                    .IsRequired()
                    .HasColumnName("SystemID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SystemKey)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.SystemName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SystemOtherCode)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SystemPageCheck)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SystemPassword)
                    .IsRequired()
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.SystemType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SystemUrl)
                    .HasColumnName("SystemURL")
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.UsedFor)
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.WebCmsClientId).HasColumnName("WebCMS_ClientID");
            });

            modelBuilder.Entity<LkpAutosystemtype>(entity =>
            {
                entity.HasKey(e => e.Code)
                    .HasName("PK__lkp_auto__A25C5AA6BE93BF7D");

                entity.ToTable("lkp_autosystemtype");

                entity.Property(e => e.Code)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Description)
                    .HasMaxLength(200)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpDocType>(entity =>
            {
                entity.HasKey(e => e.DocTypeId);

                entity.ToTable("lkp_DocType");

                entity.HasComment("A lookup table that lists the document type and provides a description.");

                entity.Property(e => e.DocTypeId).HasColumnName("DocTypeID");

                entity.Property(e => e.Type)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TypeDesc)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpDocuwareCabinets>(entity =>
            {
                entity.HasKey(e => e.CabinetId);

                entity.ToTable("lkp_DocuwareCabinets");

                entity.HasComment("A lookup table that provides a list of Cabinets within the Docuware application.");

                entity.HasIndex(e => e.CabinetName)
                    .HasName("UK1_lkp_DocuwareCabinets_CabinetName")
                    .IsUnique();

                entity.Property(e => e.CabinetId).HasColumnName("CabinetID");

                entity.Property(e => e.CabinetName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpDocuwareProcesses>(entity =>
            {
                entity.HasKey(e => e.ProcessId);

                entity.ToTable("lkp_DocuwareProcesses");

                entity.HasComment("A lookup table that provides a list of Processes within the Docuware application.");

                entity.HasIndex(e => e.ProcessName)
                    .HasName("UK1_lkp_DocuwareProcesses_ProcessName")
                    .IsUnique();

                entity.Property(e => e.ProcessId).HasColumnName("ProcessID");

                entity.Property(e => e.ProcessName)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpResults>(entity =>
            {
                entity.HasKey(e => e.ResultCode);

                entity.ToTable("lkp_Results");

                entity.HasComment("A lookup table that contains a list of results(including exceptions).");

                entity.HasIndex(e => e.ResultId)
                    .HasName("UK1_lkp_Results")
                    .IsUnique();

                entity.Property(e => e.ResultCode)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ResultDescription)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ResultId)
                    .HasColumnName("ResultID")
                    .ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<LkpSpecialProcess>(entity =>
            {
                entity.HasKey(e => e.SpecialProcessId);

                entity.ToTable("lkp_SpecialProcess");

                entity.HasComment("A one record lookup table that contains the AutomationProcessID 19, a Multiclient batch.");

                entity.Property(e => e.SpecialProcessId).HasColumnName("SpecialProcessID");

                entity.Property(e => e.AutomationProcessId).HasColumnName("AutomationProcessID");

                entity.Property(e => e.DateEntered)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DateUpdated)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Reason)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.HasOne(d => d.AutomationProcess)
                    .WithMany(p => p.LkpSpecialProcess)
                    .HasForeignKey(d => d.AutomationProcessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_lkp_SpecialProcess_lkp_AutomationProcess");
            });

            modelBuilder.Entity<LkpTargets>(entity =>
            {
                entity.HasKey(e => e.TargetId);

                entity.ToTable("lkp_Targets");

                entity.HasComment("A one record lookup table that lists the 'PmtAdvice' TargetCommandCode.");

                entity.HasIndex(e => e.TargetCommandCode)
                    .HasName("UK1_lkp_Targets")
                    .IsUnique();

                entity.Property(e => e.TargetId).HasColumnName("TargetID");

                entity.Property(e => e.TargetCommandCode)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.TargetDescription)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ManualDelegatedReferralRequests>(entity =>
            {
                entity.HasKey(e => e.ManualDelegatedReferralRequestId);

                entity.Property(e => e.ManualDelegatedReferralRequestId).HasColumnName("ManualDelegatedReferralRequestID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.InvTrkFhaclaimSubtypeFhaclaimId).HasColumnName("InvTrk_FHAClaimSubtype_FHAClaimID");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ProcessDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(((1)/(1))/(1900))");
            });

            modelBuilder.Entity<StgHoaresponse>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("stg_HOAResponse");

                entity.Property(e => e.AssignmentDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AssignmentStatus)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AssignmentStatusDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BorrowerFirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BorrowerFullName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.BorrowerLastName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CaseNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Client)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Contract)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HoareferralId)
                    .HasColumnName("HOAReferralID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ImportBatchId).HasColumnName("ImportBatchID");

                entity.Property(e => e.InvestorLoanNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InvestorName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OrgAddress)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OrgCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OrgConfirmationDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OrgConfirmationResult)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OrgCounty)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OrgDateDelinquencyCleared)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OrgEmail)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.OrgFax)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OrgName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.OrgPaidThroughDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OrgPaymentFrequency)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OrgPhone)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OrgPositionType)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OrgReoccurringPaymentAmt)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OrgRole)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OrgState)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OrgStatus)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OrgStatusDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OrgWebsite)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.OrgZip)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Portfolio)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PortfolioDescription)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PrecedentResponseDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyAddress)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyState)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyStatus)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyStatusDate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyZip)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SourceFile)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.Sowdate)
                    .HasColumnName("SOWDate")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblAutomationJobLog>(entity =>
            {
                entity.HasKey(e => e.AutomationJobLogId);

                entity.ToTable("tbl_AutomationJobLog");

                entity.HasComment("A table that logs the automated commands of various Machines.");

                entity.Property(e => e.AutomationJobLogId).HasColumnName("AutomationJobLogID");

                entity.Property(e => e.Arguments)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Command)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EndTime).HasColumnType("datetime");

                entity.Property(e => e.MachineName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.RestartFileName)
                    .HasColumnName("RestartFIleName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.StartTime).HasColumnType("datetime");
            });

            modelBuilder.Entity<TblDaLpsImportInvoiceMgmtExistingClaim>(entity =>
            {
                entity.HasKey(e => e.ReportRecordId)
                    .HasName("tbl_DA_LPS_Import_InvoiceMgmtExistingClaim_PK");

                entity.ToTable("tbl_DA_LPS_Import_InvoiceMgmtExistingClaim");

                entity.HasComment("An empty Import table for existing claims. A possible removal.");

                entity.Property(e => e.ReportRecordId).HasColumnName("ReportRecordID");

                entity.Property(e => e.CmsClaimId).HasColumnName("CMS_ClaimID");

                entity.Property(e => e.ImportDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.ImportedByUserId).HasColumnName("ImportedByUserID");

                entity.Property(e => e.LpsAmountToPay)
                    .HasColumnName("LPS_AmountToPay")
                    .HasColumnType("money");

                entity.Property(e => e.LpsCheckAchnumber)
                    .HasColumnName("LPS_Check_ACHNumber")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.LpsClaimAge).HasColumnName("LPS_ClaimAge");

                entity.Property(e => e.LpsClaimExportDate)
                    .HasColumnName("LPS_ClaimExportDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.LpsClaimNumber)
                    .HasColumnName("LPS_ClaimNumber")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LpsClaimStatus)
                    .HasColumnName("LPS_ClaimStatus")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.LpsClaimType)
                    .HasColumnName("LPS_ClaimType")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.LpsCurrentStatusProcDays).HasColumnName("LPS_CurrentStatusProcDays");

                entity.Property(e => e.LpsInvestorLoanNumber)
                    .HasColumnName("LPS_InvestorLoanNumber")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.LpsProcessor)
                    .HasColumnName("LPS_Processor")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LpsRequestedAmount)
                    .HasColumnName("LPS_RequestedAmount")
                    .HasColumnType("money");

                entity.Property(e => e.LpsServicer)
                    .HasColumnName("LPS_Servicer")
                    .HasMaxLength(75)
                    .IsUnicode(false);

                entity.Property(e => e.LpsServicerLoanNumber)
                    .HasColumnName("LPS_ServicerLoanNumber")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.LpsSubmittedDate)
                    .HasColumnName("LPS_SubmittedDate")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<TblDaLpsImportInvoiceMgmtExistingClaimHistory>(entity =>
            {
                entity.HasKey(e => e.CmsClaimId);

                entity.ToTable("tbl_DA_LPS_Import_InvoiceMgmtExistingClaim_History");

                entity.HasComment("An import table that is utilized to Import existing Invoices within claims.");

                entity.Property(e => e.CmsClaimId)
                    .HasColumnName("CMS_ClaimID")
                    .ValueGeneratedNever();

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.Pfudate)
                    .HasColumnName("PFUDate")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<TblJobSystemLog>(entity =>
            {
                entity.HasKey(e => e.JobSystemLogId);

                entity.ToTable("tbl_JobSystemLog");

                entity.HasComment("A table that contains the JobSystemLogID and logs their start and end times.");

                entity.Property(e => e.JobSystemLogId).HasColumnName("JobSystemLogID");

                entity.Property(e => e.AutomationJobLogId).HasColumnName("AutomationJobLogID");

                entity.Property(e => e.AutomationSystemId).HasColumnName("AutomationSystemID");

                entity.Property(e => e.EndTime).HasColumnType("datetime");

                entity.Property(e => e.StartTime).HasColumnType("datetime");

                entity.HasOne(d => d.AutomationJobLog)
                    .WithMany(p => p.TblJobSystemLog)
                    .HasForeignKey(d => d.AutomationJobLogId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_JobSystemLog_tbl_AutomationJobLog");

                entity.HasOne(d => d.AutomationSystem)
                    .WithMany(p => p.TblJobSystemLog)
                    .HasForeignKey(d => d.AutomationSystemId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_tbl_JobSystemLog_lkp_AutomationSystems");
            });

            modelBuilder.Entity<TblMachineProcessAssignments>(entity =>
            {
                entity.HasKey(e => e.MachineProcessAssignmentId)
                    .IsClustered(false);

                entity.ToTable("tbl_MachineProcessAssignments");

                entity.HasComment("A table that contains each ClientProcessID, various machine names, and logs the process start and end time.");

                entity.HasIndex(e => new { e.ClientProcessId, e.ImportBatchGuid })
                    .HasName("UK1_tbl_MachineProcessAssignments")
                    .IsUnique();

                entity.Property(e => e.MachineProcessAssignmentId).HasColumnName("MachineProcessAssignmentID");

                entity.Property(e => e.ClientProcessId).HasColumnName("ClientProcessID");

                entity.Property(e => e.DateEntered)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ImportBatchGuid)
                    .IsRequired()
                    .HasColumnName("ImportBatchGUID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MachineName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ProcessCompleteDate).HasColumnType("datetime");

                entity.HasOne(d => d.ClientProcess)
                    .WithMany(p => p.TblMachineProcessAssignments)
                    .HasForeignKey(d => d.ClientProcessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_ClientProcess_tbl_MachineProcessAssignments");
            });

            modelBuilder.Entity<TblSystemTargetLog>(entity =>
            {
                entity.HasKey(e => e.SystemTargetLogId);

                entity.ToTable("tbl_SystemTargetLog");

                entity.HasComment("A table that contains the SystemTargetLog, JobsystemLog, and Target ID fields.");

                entity.Property(e => e.SystemTargetLogId).HasColumnName("SystemTargetLogID");

                entity.Property(e => e.JobSystemLogId).HasColumnName("JobSystemLogID");

                entity.Property(e => e.TargetId).HasColumnName("TargetID");

                entity.HasOne(d => d.JobSystemLog)
                    .WithMany(p => p.TblSystemTargetLog)
                    .HasForeignKey(d => d.JobSystemLogId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_SystemTargetLog_tbl_JobSystemLog");

                entity.HasOne(d => d.Target)
                    .WithMany(p => p.TblSystemTargetLog)
                    .HasForeignKey(d => d.TargetId)
                    .HasConstraintName("FK2_tbl_SystemTargetLog_tbl_SystemTargetLog");
            });

            modelBuilder.Entity<TblTargetActionLog>(entity =>
            {
                entity.HasKey(e => e.TargetActionLogId);

                entity.ToTable("tbl_TargetActionLog");

                entity.HasComment("A table that logs the start date, end date, and the Result ID of each TargetActionID.");

                entity.Property(e => e.TargetActionLogId).HasColumnName("TargetActionLogID");

                entity.Property(e => e.ActionEndDate).HasColumnType("datetime");

                entity.Property(e => e.ActionId).HasColumnName("ActionID");

                entity.Property(e => e.ActionStartDate).HasColumnType("datetime");

                entity.Property(e => e.ResultAttribute)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ResultId).HasColumnName("ResultID");

                entity.Property(e => e.ResultValue)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.SystemTargetLogId).HasColumnName("SystemTargetLogID");

                entity.HasOne(d => d.Action)
                    .WithMany(p => p.TblTargetActionLog)
                    .HasForeignKey(d => d.ActionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_tbl_TargetActionLog_lkp_Actions");

                entity.HasOne(d => d.Result)
                    .WithMany(p => p.TblTargetActionLog)
                    .HasPrincipalKey(p => p.ResultId)
                    .HasForeignKey(d => d.ResultId)
                    .HasConstraintName("FK_tbl_TargetActionLog_lkp_Results");

                entity.HasOne(d => d.SystemTargetLog)
                    .WithMany(p => p.TblTargetActionLog)
                    .HasForeignKey(d => d.SystemTargetLogId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_TargetActionLog_tbl_SystemTargetLog");
            });

            modelBuilder.Entity<VwDaIncompleteManualDelegatedReferrals>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DA_IncompleteManualDelegatedReferrals");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.InvTrkFhaclaimSubtypeFhaclaimId).HasColumnName("InvTrk_FHAClaimSubtype_FHAClaimID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ManualDelegatedReferralRequestId)
                    .HasColumnName("ManualDelegatedReferralRequestID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.ProcessDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<VwHudclaimsContractors>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_HUDClaims_Contractors");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.ApplicationName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BusinessEntityId).HasColumnName("BusinessEntityID");

                entity.Property(e => e.BusinessEntityName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CmsformId).HasColumnName("CMSFormID");

                entity.Property(e => e.EntityTypeId).HasColumnName("EntityTypeID");

                entity.Property(e => e.EntityTypeName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwPrecedentHoareferrals>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_PrecedentHOAReferrals");

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DateReferredToVendor).HasColumnType("date");

                entity.Property(e => e.DelegatedReferralId).HasColumnName("DelegatedReferralID");

                entity.Property(e => e.FhacaseNumber)
                    .HasColumnName("FHACaseNumber")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.HoaresponseId).HasColumnName("HOAResponseID");

                entity.Property(e => e.LoanNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PositiveHoadetermination)
                    .IsRequired()
                    .HasColumnName("PositiveHOADetermination")
                    .HasMaxLength(18)
                    .IsUnicode(false);

                entity.Property(e => e.PrecedentResponseDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<VwUsers>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_Users");

                entity.Property(e => e.LastPwchange)
                    .HasColumnName("LastPWChange")
                    .HasColumnType("datetime");

                entity.Property(e => e.LegacyCmsuserId).HasColumnName("LegacyCMSUserID");

                entity.Property(e => e.Login)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.PhoneNum)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.UserEmailAddress)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwWfbiRoles>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_WFBI_Roles");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.ApplicationName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ApplicationRoleId).HasColumnName("ApplicationRoleID");

                entity.Property(e => e.RoleId).HasColumnName("roleID");

                entity.Property(e => e.RoleName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwWfbiUserApplicationRole>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_WFBI_UserApplicationRole");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.RoleId).HasColumnName("RoleID");

                entity.Property(e => e.UserId).HasColumnName("UserID");
            });

            modelBuilder.Entity<WfbiBatchLogs>(entity =>
            {
                entity.HasKey(e => e.WfbiBatchLogId);

                entity.ToTable("WFBI_BatchLogs");

                entity.HasComment("A table that tracks the WFBI_Batch Logs. This table logs start and end times, in addition to loan numbers.");

                entity.Property(e => e.WfbiBatchLogId).HasColumnName("WFBI_BatchLogID");

                entity.Property(e => e.BatchStatusId).HasColumnName("BatchStatusID");

                entity.Property(e => e.Block2XxentriesDetected)
                    .HasColumnName("Block2XXEntriesDetected")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Block2XxentriesLoaded)
                    .HasColumnName("Block2XXEntriesLoaded")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Block305EntriesDetected).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block305EntriesLoaded).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block306EntriesDetected).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block306EntriesLoaded).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block307EntriesDetected).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block307EntriesLoaded).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block308EntriesDetected).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block308EntriesLoaded).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block309EntriesDetected).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block309EntriesLoaded).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block310EntriesDetected).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block310EntriesLoaded).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block311EntriesDetected).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block311EntriesLoaded).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block405EntriesDetected).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block405EntriesLoaded).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block406EntriesDetected).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block406EntriesLoaded).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block407EntriesDetected).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block407EntriesLoaded).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block408EntriesDetected).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block408EntriesLoaded).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block409EntriesDetected).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block409EntriesLoaded).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block410EntriesDetected).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block410EntriesLoaded).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block411EntriesLoaded).HasDefaultValueSql("((0))");

                entity.Property(e => e.Block412EntriesLoaded).HasDefaultValueSql("((0))");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.FhaloanId).HasColumnName("FHALoanID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.LoanNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PartA27011id).HasColumnName("PartA27011ID");

                entity.Property(e => e.PartB27011id).HasColumnName("PartB27011ID");

                entity.Property(e => e.PartC27011id).HasColumnName("PartC27011ID");

                entity.Property(e => e.PartD27011id).HasColumnName("PartD27011ID");

                entity.Property(e => e.PartE27011id).HasColumnName("PartE27011ID");

                entity.Property(e => e.SourceFile)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.HasOne(d => d.BatchStatus)
                    .WithMany(p => p.WfbiBatchLogs)
                    .HasForeignKey(d => d.BatchStatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_WFBI_BatchLogs_WFBI_BatchStatuses");
            });

            modelBuilder.Entity<WfbiBatchStatuses>(entity =>
            {
                entity.HasKey(e => e.BatchStatusId)
                    .HasName("PK_BatchStatuses");

                entity.ToTable("WFBI_BatchStatuses");

                entity.HasComment("A table that contains the descriptions of each BachStatusID.");

                entity.HasIndex(e => e.BatchStatus)
                    .HasName("UK1_BatchStatuses")
                    .IsUnique();

                entity.Property(e => e.BatchStatusId).HasColumnName("BatchStatusID");

                entity.Property(e => e.BatchStatus)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<WfbiErrorLogs>(entity =>
            {
                entity.HasKey(e => e.ErrorLogId);

                entity.ToTable("WFBI_ErrorLogs");

                entity.HasComment("An empty table that contains WFBI Error Log descriptions. Possible removal.");

                entity.Property(e => e.ErrorLogId).HasColumnName("ErrorLogID");

                entity.Property(e => e.Datestamp)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.ErrorText)
                    .IsRequired()
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.WfbiBatchLogId).HasColumnName("WFBI_BatchLogID");

                entity.HasOne(d => d.WfbiBatchLog)
                    .WithMany(p => p.WfbiErrorLogs)
                    .HasForeignKey(d => d.WfbiBatchLogId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_WFBI_ErrorLogs_WFBI_BatchLogs");
            });

            modelBuilder.Entity<XrefClearTitleUpdateClearTitleExceptions>(entity =>
            {
                entity.HasKey(e => e.ClearTitleUpdateXexceptionId)
                    .HasName("PK_ClearTitleUpdateXExceptions");

                entity.ToTable("xref_ClearTitleUpdate_ClearTitleExceptions");

                entity.HasComment("An empty cross reference table that utilizes tables 'Clear Tile Updates' and 'Clear Tile Update exceptions'. Possible removal.");

                entity.Property(e => e.ClearTitleUpdateXexceptionId).HasColumnName("ClearTitleUpdateXExceptionID");

                entity.Property(e => e.ClearTitleUpdateExceptionId).HasColumnName("ClearTitleUpdateExceptionID");

                entity.Property(e => e.ClearTitleUpdateId).HasColumnName("ClearTitleUpdateID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.ClearTitleUpdateException)
                    .WithMany(p => p.XrefClearTitleUpdateClearTitleExceptions)
                    .HasForeignKey(d => d.ClearTitleUpdateExceptionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ClearTitleUpdateExceptions_ClearTitleUpdateXExceptions");

                entity.HasOne(d => d.ClearTitleUpdate)
                    .WithMany(p => p.XrefClearTitleUpdateClearTitleExceptions)
                    .HasForeignKey(d => d.ClearTitleUpdateId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ClearTitleUpdate_ClearTitleUpdateXException");
            });

            modelBuilder.Entity<XrefClientProcess>(entity =>
            {
                entity.HasKey(e => e.ClientProcessId)
                    .HasName("AutomationProcessID_PK");

                entity.ToTable("xref_ClientProcess");

                entity.HasComment("A cross reference table that contains the ClientProcess, AutomationClient, and AutomationProcess ID fields.");

                entity.Property(e => e.ClientProcessId).HasColumnName("ClientProcessID");

                entity.Property(e => e.AutomationClientId).HasColumnName("AutomationClientID");

                entity.Property(e => e.AutomationProcessId).HasColumnName("AutomationProcessID");

                entity.Property(e => e.AutomationSystemId).HasColumnName("AutomationSystemID");

                entity.Property(e => e.ProcessNumber).HasColumnName("processNumber");

                entity.Property(e => e.ProcessOrder).HasColumnName("processOrder");

                entity.HasOne(d => d.AutomationClient)
                    .WithMany(p => p.XrefClientProcess)
                    .HasForeignKey(d => d.AutomationClientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_lkp_AutomationProcess_lkp_AutomationClients");

                entity.HasOne(d => d.AutomationProcess)
                    .WithMany(p => p.XrefClientProcess)
                    .HasForeignKey(d => d.AutomationProcessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_lkp_AutomationProcess_xref_ClientProcess");

                entity.HasOne(d => d.AutomationSystem)
                    .WithMany(p => p.XrefClientProcess)
                    .HasForeignKey(d => d.AutomationSystemId)
                    .HasConstraintName("FK3_lkp_AutomationSystems_xref_ClientProcess");
            });

            modelBuilder.Entity<XrefClientProcessExtractionDetailAttributeSortOrders>(entity =>
            {
                entity.HasKey(e => e.ClientProcessExtractionDetailAttributeSortOrderId);

                entity.ToTable("xref_ClientProcessExtractionDetailAttributeSortOrders");

                entity.HasComment("A cross reference table that lists the DataExtractionProcessID, in addition to the ExtractuionDetailAttributeID, and the Client ID.");

                entity.Property(e => e.ClientProcessExtractionDetailAttributeSortOrderId).HasColumnName("ClientProcessExtractionDetailAttributeSortOrderID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.DataExtractionProcessId).HasColumnName("DataExtractionProcessID");

                entity.Property(e => e.ExtractionDetailAttributeId).HasColumnName("ExtractionDetailAttributeID");

                entity.HasOne(d => d.DataExtractionProcess)
                    .WithMany(p => p.XrefClientProcessExtractionDetailAttributeSortOrders)
                    .HasForeignKey(d => d.DataExtractionProcessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_ClientProcessExtractionDetailAttributeSortOrders_DataExtractionProcesses");

                entity.HasOne(d => d.ExtractionDetailAttribute)
                    .WithMany(p => p.XrefClientProcessExtractionDetailAttributeSortOrders)
                    .HasForeignKey(d => d.ExtractionDetailAttributeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_ClientProcessExtractionDetailAttributeSortOrders_ExtractionDetailAttributes");
            });

            modelBuilder.Entity<XrefDataAutomationDocuware>(entity =>
            {
                entity.HasKey(e => e.AutomationXrefDocuwareId)
                    .HasName("PK_xref_DocCabProcAutoProc");

                entity.ToTable("xref_DataAutomation_Docuware");

                entity.HasComment("A cross reference table that contains DocuwareType, DocuwareCabinet, and DocuwareProcess ID fields.");

                entity.Property(e => e.AutomationXrefDocuwareId).HasColumnName("AutomationXRefDocuwareID");

                entity.Property(e => e.AutomationProcessId).HasColumnName("AutomationProcessID");

                entity.Property(e => e.DwcabinetId).HasColumnName("DWCabinetID");

                entity.Property(e => e.DwdocTypeId).HasColumnName("DWDocTypeID");

                entity.Property(e => e.DwprocessId).HasColumnName("DWProcessID");

                entity.HasOne(d => d.AutomationProcess)
                    .WithMany(p => p.XrefDataAutomationDocuware)
                    .HasForeignKey(d => d.AutomationProcessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_xref_DataAutomation_Docuware_xref_DataAutomation_Docuware");

                entity.HasOne(d => d.Dwcabinet)
                    .WithMany(p => p.XrefDataAutomationDocuware)
                    .HasForeignKey(d => d.DwcabinetId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_DataAutomation_Docuware_xref_DataAutomation_Docuware");

                entity.HasOne(d => d.DwdocType)
                    .WithMany(p => p.XrefDataAutomationDocuware)
                    .HasForeignKey(d => d.DwdocTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_DataAutomation_Docuware_xref_DataAutomation_Docuware");

                entity.HasOne(d => d.Dwprocess)
                    .WithMany(p => p.XrefDataAutomationDocuware)
                    .HasForeignKey(d => d.DwprocessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_xref_DataAutomation_Docuware_xref_DataAutomation_Docuware");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
