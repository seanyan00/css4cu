﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpAutomationClients
    {
        public LkpAutomationClients()
        {
            XrefClientProcess = new HashSet<XrefClientProcess>();
        }

        public int AutomationClientId { get; set; }
        public string ClientName { get; set; }
        public string ClientAbbreviation { get; set; }
        public string ImportClientId { get; set; }
        public DateTime DateEntered { get; set; }

        public virtual ICollection<XrefClientProcess> XrefClientProcess { get; set; }
    }
}
