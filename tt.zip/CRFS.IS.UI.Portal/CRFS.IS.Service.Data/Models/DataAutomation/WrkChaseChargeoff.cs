﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class WrkChaseChargeoff
    {
        public long Id { get; set; }
        public string FhaCaseNo { get; set; }
        public string LoanNo { get; set; }
        public string ClaimType { get; set; }
        public string State { get; set; }
        public int? ClientNo { get; set; }
        public int? ClaimTypeNo { get; set; }
        public int? BatchNo { get; set; }
        public string ChargeoffCode { get; set; }
        public string Descr { get; set; }
        public string CrChargeoffDescription { get; set; }
        public string ChargeoffDetail { get; set; }
        public DateTime? BInQcr { get; set; }
        public DateTime? PartbDue { get; set; }
        public DateTime? BSubmit { get; set; }
        public string ProcessingAnalyst { get; set; }
        public string QcAnalyst { get; set; }
    }
}
