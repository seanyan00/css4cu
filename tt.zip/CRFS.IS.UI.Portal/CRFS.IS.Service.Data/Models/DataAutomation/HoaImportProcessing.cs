﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class HoaImportProcessing
    {
        public int ProcessId { get; set; }
        public DateTime? ProcessDate { get; set; }
        public int? ProcessedStageBatch { get; set; }
    }
}
