﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class ClearTitleUpdates
    {
        public ClearTitleUpdates()
        {
            XrefClearTitleUpdateClearTitleExceptions = new HashSet<XrefClearTitleUpdateClearTitleExceptions>();
        }

        public long ClearTitleUpdateId { get; set; }
        public long ClearTitleBatchId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public bool MarkedForDelete { get; set; }
        public string ClientName { get; set; }
        public int ClientId { get; set; }
        public string LoanNumber { get; set; }
        public string FhacaseNumber { get; set; }
        public int? InvTrkClaimId { get; set; }
        public DateTime? ClearTitleDate { get; set; }
        public string ClearTitleDataRemove { get; set; }

        public virtual ClearTitleBatches ClearTitleBatch { get; set; }
        public virtual ICollection<XrefClearTitleUpdateClearTitleExceptions> XrefClearTitleUpdateClearTitleExceptions { get; set; }
    }
}
