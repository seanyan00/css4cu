﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblJobSystemLog
    {
        public TblJobSystemLog()
        {
            TblSystemTargetLog = new HashSet<TblSystemTargetLog>();
        }

        public long JobSystemLogId { get; set; }
        public long AutomationJobLogId { get; set; }
        public int AutomationSystemId { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }

        public virtual TblAutomationJobLog AutomationJobLog { get; set; }
        public virtual LkpAutomationSystems AutomationSystem { get; set; }
        public virtual ICollection<TblSystemTargetLog> TblSystemTargetLog { get; set; }
    }
}
