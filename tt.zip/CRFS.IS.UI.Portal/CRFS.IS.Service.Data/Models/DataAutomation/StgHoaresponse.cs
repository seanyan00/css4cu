﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgHoaresponse
    {
        public int ImportBatchId { get; set; }
        public string Client { get; set; }
        public string Contract { get; set; }
        public string Portfolio { get; set; }
        public string PortfolioDescription { get; set; }
        public string CaseNumber { get; set; }
        public string AssignmentDate { get; set; }
        public string Sowdate { get; set; }
        public string PropertyAddress { get; set; }
        public string PropertyCity { get; set; }
        public string PropertyState { get; set; }
        public string PropertyZip { get; set; }
        public string BorrowerFullName { get; set; }
        public string BorrowerFirstName { get; set; }
        public string BorrowerLastName { get; set; }
        public string InvestorLoanNumber { get; set; }
        public string InvestorName { get; set; }
        public string AssignmentStatus { get; set; }
        public string AssignmentStatusDate { get; set; }
        public string PropertyStatus { get; set; }
        public string PropertyStatusDate { get; set; }
        public string HoareferralId { get; set; }
        public string OrgPositionType { get; set; }
        public string OrgRole { get; set; }
        public string OrgName { get; set; }
        public string OrgAddress { get; set; }
        public string OrgCity { get; set; }
        public string OrgState { get; set; }
        public string OrgZip { get; set; }
        public string OrgCounty { get; set; }
        public string OrgPhone { get; set; }
        public string OrgEmail { get; set; }
        public string OrgFax { get; set; }
        public string OrgWebsite { get; set; }
        public string OrgConfirmationResult { get; set; }
        public string OrgConfirmationDate { get; set; }
        public string OrgDateDelinquencyCleared { get; set; }
        public string OrgPaidThroughDate { get; set; }
        public string OrgPaymentFrequency { get; set; }
        public string OrgReoccurringPaymentAmt { get; set; }
        public string OrgStatus { get; set; }
        public string OrgStatusDate { get; set; }
        public string PrecedentResponseDate { get; set; }
        public string SourceFile { get; set; }
    }
}
