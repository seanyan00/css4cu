﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpActions
    {
        public LkpActions()
        {
            TblTargetActionLog = new HashSet<TblTargetActionLog>();
        }

        public long ActionId { get; set; }
        public string ActionCode { get; set; }
        public string ActionDescription { get; set; }

        public virtual ICollection<TblTargetActionLog> TblTargetActionLog { get; set; }
    }
}
