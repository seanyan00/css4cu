﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class DataImportLogs
    {
        public DataImportLogs()
        {
            DataImportDetails = new HashSet<DataImportDetails>();
        }

        public long DataImportLogId { get; set; }
        public int DataImportProcessId { get; set; }
        public int DataImportStatusId { get; set; }
        public int DataImportBatchId { get; set; }
        public int ClientId { get; set; }
        public DateTime DateStart { get; set; }
        public DateTime? DateEnd { get; set; }
        public bool MarkedForDelete { get; set; }

        public virtual DataImportBatch DataImportBatch { get; set; }
        public virtual DataImportProcesses DataImportProcess { get; set; }
        public virtual DataImportStatuses DataImportStatus { get; set; }
        public virtual ICollection<DataImportDetails> DataImportDetails { get; set; }
    }
}
