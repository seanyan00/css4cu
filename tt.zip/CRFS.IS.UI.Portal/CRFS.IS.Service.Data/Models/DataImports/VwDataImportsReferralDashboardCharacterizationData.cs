﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwDataImportsReferralDashboardCharacterizationData
    {
        public int ImportBatchId { get; set; }
        public long ImportRecordId { get; set; }
        public string ClientName { get; set; }
        public bool ClientActive { get; set; }
        public string ReferralOrigin { get; set; }
        public bool? Iccreferral { get; set; }
        public DateTime? ProcessedDate { get; set; }
        public int? BatchRecordCount { get; set; }
        public string LoadedBy { get; set; }
        public string LoanNumber { get; set; }
        public string CharacterizationStatusCode { get; set; }
        public string CharacterizationDescription { get; set; }
        public string StatusAttribute { get; set; }
        public string StatusValue { get; set; }
        public string CharacterizationStatusValue { get; set; }
        public string CharacterizationResult { get; set; }
        public string OriginalFileName { get; set; }
    }
}
