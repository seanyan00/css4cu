﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblImportBatch
    {
        public TblImportBatch()
        {
            TblBatchDispositionHistory = new HashSet<TblBatchDispositionHistory>();
            TblImportRecord = new HashSet<TblImportRecord>();
        }

        public int ImportBatchId { get; set; }
        public int ClientId { get; set; }
        public string OriginalFileName { get; set; }
        public int FileTypeId { get; set; }
        public int? BatchRecordCount { get; set; }
        public bool MarkedForDelete { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual LkpFileTypes FileType { get; set; }
        public virtual ICollection<TblBatchDispositionHistory> TblBatchDispositionHistory { get; set; }
        public virtual ICollection<TblImportRecord> TblImportRecord { get; set; }
    }
}
