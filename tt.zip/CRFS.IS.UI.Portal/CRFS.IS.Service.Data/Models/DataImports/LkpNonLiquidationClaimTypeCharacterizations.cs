﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpNonLiquidationClaimTypeCharacterizations
    {
        public LkpNonLiquidationClaimTypeCharacterizations()
        {
            TblNonLiquidationClaimTypeValidations = new HashSet<TblNonLiquidationClaimTypeValidations>();
        }

        public int NonLiquidationClaimTypeCharacterizationId { get; set; }
        public int InvTrkClaimTypeId { get; set; }
        public int ClaimDueDateDaysToAdd { get; set; }
        public int CharacterizationDispositionStatusId { get; set; }
        public int LoanReleasedDispositionStatusId { get; set; }
        public int LoanNotReleasedDispositionStatusId { get; set; }
        public int ClaimReleasedDispositionStatusId { get; set; }
        public int ClaimNotReleasedDispositionStatusId { get; set; }
        public bool Active { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public int? IndustryDueDateDaysToAdd { get; set; }

        public virtual LkpDispositionStatus CharacterizationDispositionStatus { get; set; }
        public virtual LkpDispositionStatus ClaimNotReleasedDispositionStatus { get; set; }
        public virtual LkpDispositionStatus ClaimReleasedDispositionStatus { get; set; }
        public virtual LkpDispositionStatus LoanNotReleasedDispositionStatus { get; set; }
        public virtual LkpDispositionStatus LoanReleasedDispositionStatus { get; set; }
        public virtual ICollection<TblNonLiquidationClaimTypeValidations> TblNonLiquidationClaimTypeValidations { get; set; }
    }
}
