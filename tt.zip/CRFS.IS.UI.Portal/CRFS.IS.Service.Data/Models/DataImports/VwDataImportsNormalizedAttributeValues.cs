﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwDataImportsNormalizedAttributeValues
    {
        public long ImportRecordId { get; set; }
        public long ImportDataId { get; set; }
        public string ImportAttributeName { get; set; }
        public string ImportAttributeValue { get; set; }
    }
}
