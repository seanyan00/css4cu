﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class DataImportStatuses
    {
        public DataImportStatuses()
        {
            DataImportLogs = new HashSet<DataImportLogs>();
        }

        public int DataImportStatusId { get; set; }
        public string DataImportStatus { get; set; }
        public bool Active { get; set; }

        public virtual ICollection<DataImportLogs> DataImportLogs { get; set; }
    }
}
