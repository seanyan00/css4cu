﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpMiclaimTypeMatrix
    {
        public int MiclaimTypeMatrixId { get; set; }
        public int ClientId { get; set; }
        public string Result { get; set; }
        public int? ClaimTypeId { get; set; }
        public int? ImportAttributeId { get; set; }
        public int? DaysToAdd { get; set; }
        public int BitValue { get; set; }
        public bool IsPfsdateSet { get; set; }
        public bool IsTpsdateSet { get; set; }
        public bool IsDildateSet { get; set; }
        public bool IsFcsaleDateSet { get; set; }
        public bool IsRrcdateSet { get; set; }

        public virtual LkpImportAttribute ImportAttribute { get; set; }
    }
}
