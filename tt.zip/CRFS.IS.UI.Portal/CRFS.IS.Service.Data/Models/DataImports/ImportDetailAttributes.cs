﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class ImportDetailAttributes
    {
        public ImportDetailAttributes()
        {
            DataImportDetails = new HashSet<DataImportDetails>();
            XrefClientProcessImportDetailAttributeSortOrders = new HashSet<XrefClientProcessImportDetailAttributeSortOrders>();
        }

        public int ImportDetailAttributeId { get; set; }
        public string ImportDetailAttributeName { get; set; }
        public bool Active { get; set; }

        public virtual ICollection<DataImportDetails> DataImportDetails { get; set; }
        public virtual ICollection<XrefClientProcessImportDetailAttributeSortOrders> XrefClientProcessImportDetailAttributeSortOrders { get; set; }
    }
}
