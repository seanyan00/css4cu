﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpCntlImportsCategorizationRules
    {
        public int CategorizationRuleId { get; set; }
        public int BitValue { get; set; }
        public bool Bit17RplsaleDateSet { get; set; }
        public bool Bit16PaymentDeferralCompletionDateSet { get; set; }
        public bool Bit15SettlementDateSet { get; set; }
        public bool Bit14NplsaleDateSet { get; set; }
        public bool Bit13AdpcodeSet { get; set; }
        public bool Bit12ExecutionDateSet { get; set; }
        public bool Bit11HudiddateSet { get; set; }
        public bool Bit10CwcotdateSet { get; set; }
        public bool Bit9IccdateSet { get; set; }
        public bool Bit8FhacaseNumberSet { get; set; }
        public bool Bit7LoanNumberSet { get; set; }
        public bool Bit6VacaseNumberSet { get; set; }
        public bool Bit5FcsaleDateSet { get; set; }
        public bool Bit4DildateSet { get; set; }
        public bool Bit3PartAfiledDateSet { get; set; }
        public bool Bit2PfsdateSet { get; set; }
        public bool Bit1TpsdateSet { get; set; }
        public bool Bit0InvestorClaimTypeSet { get; set; }
        public string CharacterizationResult { get; set; }
    }
}
