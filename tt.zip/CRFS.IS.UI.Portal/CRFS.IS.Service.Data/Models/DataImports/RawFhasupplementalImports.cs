﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class RawFhasupplementalImports
    {
        public int RawFhasupplementalImportId { get; set; }
        public string ClientName { get; set; }
        public string FhacaseNumber { get; set; }
        public string LoanNumber { get; set; }
        public DateTime? SettlementDate { get; set; }
        public DateTime? SuppDueDate { get; set; }
        public DateTime ReferralDate { get; set; }
        public string ParentClaimType { get; set; }
    }
}
