﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblImportRecord
    {
        public TblImportRecord()
        {
            TblFnmaadvPmtImportData = new HashSet<TblFnmaadvPmtImportData>();
            TblImportRecordData = new HashSet<TblImportRecordData>();
            TblRecordDispositionHistory = new HashSet<TblRecordDispositionHistory>();
        }

        public long ImportRecordId { get; set; }
        public int ImportBatchId { get; set; }
        public bool MarkedForDelete { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual TblImportBatch ImportBatch { get; set; }
        public virtual ICollection<TblFnmaadvPmtImportData> TblFnmaadvPmtImportData { get; set; }
        public virtual ICollection<TblImportRecordData> TblImportRecordData { get; set; }
        public virtual ICollection<TblRecordDispositionHistory> TblRecordDispositionHistory { get; set; }
    }
}
