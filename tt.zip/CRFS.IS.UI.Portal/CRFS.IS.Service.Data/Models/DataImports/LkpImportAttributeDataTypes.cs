﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpImportAttributeDataTypes
    {
        public LkpImportAttributeDataTypes()
        {
            LkpImportAttribute = new HashSet<LkpImportAttribute>();
        }

        public int ImportAttributeDataTypeId { get; set; }
        public string DataTypeName { get; set; }
        public int? Length { get; set; }
        public int? Scale { get; set; }
        public int? Precision { get; set; }
        public string Format { get; set; }

        public virtual ICollection<LkpImportAttribute> LkpImportAttribute { get; set; }
    }
}
