﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class Rhiannon
    {
        public int Idcolumn { get; set; }
        public string Field1 { get; set; }
        public string Field2 { get; set; }
        public int? Field3 { get; set; }
        public decimal? Field4 { get; set; }
        public DateTime? Field5 { get; set; }
        public DateTime? Field6 { get; set; }
        public bool? Field7 { get; set; }
    }
}
