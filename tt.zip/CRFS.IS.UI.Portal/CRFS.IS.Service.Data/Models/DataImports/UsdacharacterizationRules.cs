﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class UsdacharacterizationRules
    {
        public int UsdacharacterizationRuleId { get; set; }
        public int UsdaclaimTypeId { get; set; }
        public string PropertyAcquisitionDatePopulated { get; set; }
        public string FclsaleDatePopulated { get; set; }
        public string RrcdatePopulated { get; set; }
        public string DilrecordedDatePopulated { get; set; }
        public string TpsdatePopulated { get; set; }
        public string PfsdatePopulated { get; set; }
        public string ReosaleDatePopulated { get; set; }
        public string NextPmtDueDtPlusOneMnthLt20141201 { get; set; }
        public string NextPmtDueDtPlusOneMnthGte20141201 { get; set; }
        public int ImportAttributeIdAnchorDate { get; set; }
        public int DaysToAdd { get; set; }

        public virtual LkpImportAttribute ImportAttributeIdAnchorDateNavigation { get; set; }
    }
}
