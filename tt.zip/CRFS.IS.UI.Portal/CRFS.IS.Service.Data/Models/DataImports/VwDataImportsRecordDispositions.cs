﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwDataImportsRecordDispositions
    {
        public long RecordDispositionHistoryId { get; set; }
        public long ImportRecordId { get; set; }
        public string DispositionStatusCode { get; set; }
        public string DispositionStatusDescription { get; set; }
        public string StatusAttribute { get; set; }
        public string StatusValue { get; set; }
    }
}
