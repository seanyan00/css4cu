﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblNonLiquidationClaimTypeValidations
    {
        public int NonLiquidationClaimTypeValidationId { get; set; }
        public int NonLiquidationClaimTypeCharacterizationId { get; set; }
        public string ClientReferredValue { get; set; }
        public bool Active { get; set; }
        public DateTime EffectiveFromDate { get; set; }
        public DateTime EffectiveToDate { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual LkpNonLiquidationClaimTypeCharacterizations NonLiquidationClaimTypeCharacterization { get; set; }
    }
}
