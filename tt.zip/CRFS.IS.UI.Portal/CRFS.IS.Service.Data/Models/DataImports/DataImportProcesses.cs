﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class DataImportProcesses
    {
        public DataImportProcesses()
        {
            DataImportLogs = new HashSet<DataImportLogs>();
            XrefClientProcessImportDetailAttributeSortOrders = new HashSet<XrefClientProcessImportDetailAttributeSortOrders>();
        }

        public int DataImportProcessId { get; set; }
        public string DataImportProcessName { get; set; }
        public bool Active { get; set; }

        public virtual ICollection<DataImportLogs> DataImportLogs { get; set; }
        public virtual ICollection<XrefClientProcessImportDetailAttributeSortOrders> XrefClientProcessImportDetailAttributeSortOrders { get; set; }
    }
}
