﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpCntlInvtrkDateValidationRules
    {
        public int DateValidationId { get; set; }
        public int DateBitValue { get; set; }
        public bool Bit9RplsaleDate { get; set; }
        public bool Bit8PaymentDeferralCompletionDate { get; set; }
        public bool Bit7NplsaleDate { get; set; }
        public bool Bit6Rrcdate { get; set; }
        public bool Bit5LiquidationDate { get; set; }
        public bool Bit4ReosaleDate { get; set; }
        public bool Bit3Tpsdate { get; set; }
        public bool Bit2Dildate { get; set; }
        public bool Bit1Pfsdate { get; set; }
        public bool Bit0FcsaleDate { get; set; }
        public string Result { get; set; }
    }
}
