﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpMicompanySuppliedNameMicompanyId
    {
        public int MicompanyTextLookupId { get; set; }
        public string MitextLookup { get; set; }
        public int CmsInvTrkMicompanyId { get; set; }
        public DateTime DateEntered { get; set; }
        public bool Active { get; set; }
    }
}
