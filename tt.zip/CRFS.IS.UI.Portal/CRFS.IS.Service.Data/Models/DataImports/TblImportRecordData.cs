﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblImportRecordData
    {
        public long ImportDataId { get; set; }
        public long ImportRecordId { get; set; }
        public int ImportAttributeId { get; set; }
        public string ImportAttributeValue { get; set; }

        public virtual LkpImportAttribute ImportAttribute { get; set; }
        public virtual TblImportRecord ImportRecord { get; set; }
    }
}
