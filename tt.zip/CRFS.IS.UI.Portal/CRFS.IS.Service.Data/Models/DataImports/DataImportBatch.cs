﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class DataImportBatch
    {
        public DataImportBatch()
        {
            DataImportLogs = new HashSet<DataImportLogs>();
        }

        public int DataImportBatchId { get; set; }
        public int ApplicationId { get; set; }
        public string FileName { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUser { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUser { get; set; }
        public bool MarkedForDelete { get; set; }

        public virtual ICollection<DataImportLogs> DataImportLogs { get; set; }
    }
}
