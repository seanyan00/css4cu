﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwImportsColumnNormalizationMappings
    {
        public string SuppliedFieldName { get; set; }
        public int ImportAttributeId { get; set; }
        public string NormalizedColumnName { get; set; }
        public string MappingSourceTable { get; set; }
        public string DestTable { get; set; }
        public string DestColumn { get; set; }
    }
}
