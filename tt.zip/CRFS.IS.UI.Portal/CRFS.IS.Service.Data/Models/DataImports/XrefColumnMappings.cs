﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefColumnMappings
    {
        public int ColumnMapId { get; set; }
        public string SuppliedFieldName { get; set; }
        public int ImportAttributeId { get; set; }

        public virtual LkpImportAttribute ImportAttribute { get; set; }
    }
}
