﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpImportAttribute
    {
        public LkpImportAttribute()
        {
            LkpImportTableMapping = new HashSet<LkpImportTableMapping>();
            LkpInvestorClaimTypeMatrix = new HashSet<LkpInvestorClaimTypeMatrix>();
            LkpMiclaimTypeMatrix = new HashSet<LkpMiclaimTypeMatrix>();
            LkpMiscClaimTypeMatrix = new HashSet<LkpMiscClaimTypeMatrix>();
            LkpPoolClaimTypeMatrix = new HashSet<LkpPoolClaimTypeMatrix>();
            TblImportRecordData = new HashSet<TblImportRecordData>();
            UsdacharacterizationRules = new HashSet<UsdacharacterizationRules>();
            XrefColumnMappings = new HashSet<XrefColumnMappings>();
        }

        public int ImportAttributeId { get; set; }
        public string ImportAttributeName { get; set; }
        public int ImportAttributeDataTypeId { get; set; }
        public string TableDirect { get; set; }

        public virtual LkpImportAttributeDataTypes ImportAttributeDataType { get; set; }
        public virtual ICollection<LkpImportTableMapping> LkpImportTableMapping { get; set; }
        public virtual ICollection<LkpInvestorClaimTypeMatrix> LkpInvestorClaimTypeMatrix { get; set; }
        public virtual ICollection<LkpMiclaimTypeMatrix> LkpMiclaimTypeMatrix { get; set; }
        public virtual ICollection<LkpMiscClaimTypeMatrix> LkpMiscClaimTypeMatrix { get; set; }
        public virtual ICollection<LkpPoolClaimTypeMatrix> LkpPoolClaimTypeMatrix { get; set; }
        public virtual ICollection<TblImportRecordData> TblImportRecordData { get; set; }
        public virtual ICollection<UsdacharacterizationRules> UsdacharacterizationRules { get; set; }
        public virtual ICollection<XrefColumnMappings> XrefColumnMappings { get; set; }
    }
}
