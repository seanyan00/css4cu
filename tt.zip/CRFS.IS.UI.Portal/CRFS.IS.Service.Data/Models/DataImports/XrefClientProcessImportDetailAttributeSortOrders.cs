﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefClientProcessImportDetailAttributeSortOrders
    {
        public int ClientProcessImportDetailAttributeSortOrderId { get; set; }
        public int DataImportProcessId { get; set; }
        public int ImportDetailAttributeId { get; set; }
        public int ClientId { get; set; }
        public int SortOrder { get; set; }

        public virtual DataImportProcesses DataImportProcess { get; set; }
        public virtual ImportDetailAttributes ImportDetailAttribute { get; set; }
    }
}
