﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpImportTableMapping
    {
        public int ImportTableMappingId { get; set; }
        public string TableName { get; set; }
        public string ColumnName { get; set; }
        public string ColumnDataType { get; set; }
        public bool Required { get; set; }
        public int Ordering { get; set; }
        public int? ImportAttributeId { get; set; }
        public DateTime DateEntered { get; set; }

        public virtual LkpImportAttribute ImportAttribute { get; set; }
    }
}
