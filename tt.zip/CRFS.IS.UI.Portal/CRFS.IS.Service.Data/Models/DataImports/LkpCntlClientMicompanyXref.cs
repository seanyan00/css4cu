﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpCntlClientMicompanyXref
    {
        public int ClientMicompanyXrefId { get; set; }
        public int ClientId { get; set; }
        public string MicompanyValueSent { get; set; }
        public int CmsInvTrkMicompanyId { get; set; }
        public DateTime DateEntered { get; set; }
        public bool? Active { get; set; }
    }
}
