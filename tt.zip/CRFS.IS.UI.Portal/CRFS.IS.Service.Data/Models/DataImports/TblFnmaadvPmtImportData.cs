﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblFnmaadvPmtImportData
    {
        public long FnmaadvPmtImportDataId { get; set; }
        public long ImportRecordId { get; set; }
        public string FnmaloanNumber { get; set; }
        public string BusinessEntityName { get; set; }
        public string ServicerNumber { get; set; }
        public string ServicerLoanNumber { get; set; }
        public string PropertyStateCode { get; set; }
        public string LoanStatusCode { get; set; }
        public string PreparerName { get; set; }
        public decimal? TransactionAmount { get; set; }

        public virtual TblImportRecord ImportRecord { get; set; }
    }
}
