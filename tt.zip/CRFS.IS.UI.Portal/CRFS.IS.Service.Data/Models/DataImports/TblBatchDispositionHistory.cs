﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblBatchDispositionHistory
    {
        public int BatchDispositionHistoryId { get; set; }
        public int ImportBatchId { get; set; }
        public int DispositionStatusId { get; set; }
        public string StatusAttribute { get; set; }
        public string StatusValue { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual LkpDispositionStatus DispositionStatus { get; set; }
        public virtual TblImportBatch ImportBatch { get; set; }
    }
}
