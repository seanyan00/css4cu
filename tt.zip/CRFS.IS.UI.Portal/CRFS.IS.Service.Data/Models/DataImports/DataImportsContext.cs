﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CRFS.IS.Service.Data
{
    public partial class DataImportsContext : DbContext
    {
        public DataImportsContext()
        {
        }

        public DataImportsContext(DbContextOptions<DataImportsContext> options)
            : base(options)
        {
        }

        public virtual DbSet<DataImportBatch> DataImportBatch { get; set; }
        public virtual DbSet<DataImportDetails> DataImportDetails { get; set; }
        public virtual DbSet<DataImportLogs> DataImportLogs { get; set; }
        public virtual DbSet<DataImportProcesses> DataImportProcesses { get; set; }
        public virtual DbSet<DataImportStatuses> DataImportStatuses { get; set; }
        public virtual DbSet<ImportDetailAttributes> ImportDetailAttributes { get; set; }
        public virtual DbSet<Kyle> Kyle { get; set; }
        public virtual DbSet<LkpAssignmentClaimSubtypeCharacterizationRules> LkpAssignmentClaimSubtypeCharacterizationRules { get; set; }
        public virtual DbSet<LkpCntlClientMicompanyXref> LkpCntlClientMicompanyXref { get; set; }
        public virtual DbSet<LkpCntlImportsCategorizationRules> LkpCntlImportsCategorizationRules { get; set; }
        public virtual DbSet<LkpCntlInvtrkDateValidationRules> LkpCntlInvtrkDateValidationRules { get; set; }
        public virtual DbSet<LkpDispositionStatus> LkpDispositionStatus { get; set; }
        public virtual DbSet<LkpFileTypes> LkpFileTypes { get; set; }
        public virtual DbSet<LkpImportAttribute> LkpImportAttribute { get; set; }
        public virtual DbSet<LkpImportAttributeDataTypes> LkpImportAttributeDataTypes { get; set; }
        public virtual DbSet<LkpImportTableMapping> LkpImportTableMapping { get; set; }
        public virtual DbSet<LkpInvestorClaimTypeMatrix> LkpInvestorClaimTypeMatrix { get; set; }
        public virtual DbSet<LkpMiclaimTypeMatrix> LkpMiclaimTypeMatrix { get; set; }
        public virtual DbSet<LkpMicompanySuppliedNameMicompanyId> LkpMicompanySuppliedNameMicompanyId { get; set; }
        public virtual DbSet<LkpMiscClaimTypeMatrix> LkpMiscClaimTypeMatrix { get; set; }
        public virtual DbSet<LkpNonLiquidationClaimTypeCharacterizations> LkpNonLiquidationClaimTypeCharacterizations { get; set; }
        public virtual DbSet<LkpPoolClaimTypeMatrix> LkpPoolClaimTypeMatrix { get; set; }
        public virtual DbSet<RawFhasupplementalImports> RawFhasupplementalImports { get; set; }
        public virtual DbSet<Rhiannon> Rhiannon { get; set; }
        public virtual DbSet<TblBatchDispositionHistory> TblBatchDispositionHistory { get; set; }
        public virtual DbSet<TblFnmaadvPmtImportData> TblFnmaadvPmtImportData { get; set; }
        public virtual DbSet<TblImportBatch> TblImportBatch { get; set; }
        public virtual DbSet<TblImportRecord> TblImportRecord { get; set; }
        public virtual DbSet<TblImportRecordData> TblImportRecordData { get; set; }
        public virtual DbSet<TblNonLiquidationClaimTypeValidations> TblNonLiquidationClaimTypeValidations { get; set; }
        public virtual DbSet<TblRecordDispositionHistory> TblRecordDispositionHistory { get; set; }
        public virtual DbSet<UsdacharacterizationRules> UsdacharacterizationRules { get; set; }
      
        public virtual DbSet<VwDataImportsBatches> VwDataImportsBatches { get; set; }
        public virtual DbSet<VwDataImportsNormalizedAttributeValues> VwDataImportsNormalizedAttributeValues { get; set; }
        public virtual DbSet<VwDataImportsRecordDispositions> VwDataImportsRecordDispositions { get; set; }
        public virtual DbSet<VwDataImportsReferralDashboardCharacterizationData> VwDataImportsReferralDashboardCharacterizationData { get; set; }
        public virtual DbSet<VwImportsColumnNormalizationMappings> VwImportsColumnNormalizationMappings { get; set; }
        public virtual DbSet<XrefClientProcessImportDetailAttributeSortOrders> XrefClientProcessImportDetailAttributeSortOrders { get; set; }
        public virtual DbSet<XrefColumnMappings> XrefColumnMappings { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=vm-sql1-dev.dev.crfs.crfservices.com\\cms_d;Initial Catalog=DataImports;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DataImportBatch>(entity =>
            {
                entity.Property(e => e.DataImportBatchId).HasColumnName("DataImportBatchID");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FileName)
                    .IsRequired()
                    .HasMaxLength(510)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<DataImportDetails>(entity =>
            {
                entity.HasKey(e => e.DataImportDetailId)
                    .HasName("PK_DataExtractionDetails");

                entity.Property(e => e.DataImportDetailId).HasColumnName("DataImportDetailID");

                entity.Property(e => e.DataImportLogId).HasColumnName("DataImportLogID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.ImportDetailAttributeId).HasColumnName("ImportDetailAttributeID");

                entity.Property(e => e.ImportDetailValue)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.DataImportLog)
                    .WithMany(p => p.DataImportDetails)
                    .HasForeignKey(d => d.DataImportLogId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_DataImportDetails_DataImportLogs");

                entity.HasOne(d => d.ImportDetailAttribute)
                    .WithMany(p => p.DataImportDetails)
                    .HasForeignKey(d => d.ImportDetailAttributeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_DataImportDetails_ImportDetailAttributes");
            });

            modelBuilder.Entity<DataImportLogs>(entity =>
            {
                entity.HasKey(e => e.DataImportLogId)
                    .HasName("PK_DataExtractionLogs");

                entity.Property(e => e.DataImportLogId).HasColumnName("DataImportLogID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.DataImportBatchId).HasColumnName("DataImportBatchID");

                entity.Property(e => e.DataImportProcessId).HasColumnName("DataImportProcessID");

                entity.Property(e => e.DataImportStatusId).HasColumnName("DataImportStatusID");

                entity.Property(e => e.DateEnd).HasColumnType("datetime");

                entity.Property(e => e.DateStart).HasColumnType("datetime");

                entity.HasOne(d => d.DataImportBatch)
                    .WithMany(p => p.DataImportLogs)
                    .HasForeignKey(d => d.DataImportBatchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_DataImportLogs_DataImportBatch");

                entity.HasOne(d => d.DataImportProcess)
                    .WithMany(p => p.DataImportLogs)
                    .HasForeignKey(d => d.DataImportProcessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_DataImportLogs_DataImportProcesses");

                entity.HasOne(d => d.DataImportStatus)
                    .WithMany(p => p.DataImportLogs)
                    .HasForeignKey(d => d.DataImportStatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_DataImportLogs_DataImportStatuses");
            });

            modelBuilder.Entity<DataImportProcesses>(entity =>
            {
                entity.HasKey(e => e.DataImportProcessId);

                entity.HasIndex(e => e.DataImportProcessName)
                    .HasName("UK1_DataExtractionProcesses_DataExtractionProcessName")
                    .IsUnique();

                entity.Property(e => e.DataImportProcessId).HasColumnName("DataImportProcessID");

                entity.Property(e => e.DataImportProcessName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<DataImportStatuses>(entity =>
            {
                entity.HasKey(e => e.DataImportStatusId);

                entity.HasIndex(e => e.DataImportStatus)
                    .HasName("UK1_DataExtractionStatuses_DataExtractionStatus")
                    .IsUnique();

                entity.Property(e => e.DataImportStatusId).HasColumnName("DataImportStatusID");

                entity.Property(e => e.DataImportStatus)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ImportDetailAttributes>(entity =>
            {
                entity.HasKey(e => e.ImportDetailAttributeId);

                entity.Property(e => e.ImportDetailAttributeId).HasColumnName("ImportDetailAttributeID");

                entity.Property(e => e.ImportDetailAttributeName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Kyle>(entity =>
            {
                entity.HasKey(e => e.Idcolumn)
                    .HasName("PK__Kyle__06C682321B776058");

                entity.Property(e => e.Idcolumn).HasColumnName("IDColumn");

                entity.Property(e => e.Field1)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Field2)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Field4).HasColumnType("decimal(8, 4)");

                entity.Property(e => e.Field5).HasColumnType("datetime");

                entity.Property(e => e.Field6).HasColumnType("date");
            });

            modelBuilder.Entity<LkpAssignmentClaimSubtypeCharacterizationRules>(entity =>
            {
                entity.HasKey(e => e.AssignmentClaimSubtypeCharacterizationRuleId);

                entity.ToTable("lkp_AssignmentClaimSubtypeCharacterization_rules");

                entity.HasIndex(e => e.SectionOfActId)
                    .HasName("UK1_lkp_AssignmentClaimSubtypeCharacterization_rules_SectionOfTheActID")
                    .IsUnique();

                entity.Property(e => e.AssignmentClaimSubtypeCharacterizationRuleId).HasColumnName("AssignmentClaimSubtypeCharacterization_ruleID");

                entity.Property(e => e.ResultMessage)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SectionOfActId).HasColumnName("SectionOfActID");
            });

            modelBuilder.Entity<LkpCntlClientMicompanyXref>(entity =>
            {
                entity.HasKey(e => e.ClientMicompanyXrefId);

                entity.ToTable("lkp_CNTL_Client_MICompany_xref");

                entity.HasIndex(e => new { e.ClientId, e.MicompanyValueSent })
                    .HasName("UK1_lkp_CNTL_Client_MICompany_xref_Client_MIValueSent")
                    .IsUnique();

                entity.Property(e => e.ClientMicompanyXrefId).HasColumnName("Client_MICompany_xref_ID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.CmsInvTrkMicompanyId).HasColumnName("CMS_InvTrk_MICompanyID");

                entity.Property(e => e.DateEntered)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.MicompanyValueSent)
                    .IsRequired()
                    .HasColumnName("MICompanyValueSent")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpCntlImportsCategorizationRules>(entity =>
            {
                entity.HasKey(e => e.CategorizationRuleId)
                    .HasName("PK_lkp_CNTL_Imports_CategorizationRules1");

                entity.ToTable("lkp_CNTL_Imports_CategorizationRules");

                entity.HasIndex(e => e.BitValue)
                    .HasName("UK1_CategorizationRule_BitValue1")
                    .IsUnique();

                entity.HasIndex(e => new { e.Bit0InvestorClaimTypeSet, e.Bit1TpsdateSet, e.Bit2PfsdateSet, e.Bit3PartAfiledDateSet, e.Bit4DildateSet, e.Bit5FcsaleDateSet, e.Bit6VacaseNumberSet, e.Bit7LoanNumberSet, e.Bit8FhacaseNumberSet, e.Bit9IccdateSet, e.Bit10CwcotdateSet, e.Bit11HudiddateSet, e.Bit12ExecutionDateSet, e.Bit13AdpcodeSet, e.Bit14NplsaleDateSet, e.Bit15SettlementDateSet, e.Bit16PaymentDeferralCompletionDateSet, e.Bit17RplsaleDateSet })
                    .HasName("UK2_CategorizationRule_AllBits1")
                    .IsUnique();

                entity.Property(e => e.CategorizationRuleId).HasColumnName("CategorizationRuleID");

                entity.Property(e => e.Bit0InvestorClaimTypeSet).HasColumnName("Bit0_InvestorClaimTypeSet");

                entity.Property(e => e.Bit10CwcotdateSet).HasColumnName("Bit10_CWCOTDateSet");

                entity.Property(e => e.Bit11HudiddateSet).HasColumnName("Bit11_HUDIDDateSet");

                entity.Property(e => e.Bit12ExecutionDateSet).HasColumnName("Bit12_ExecutionDateSet");

                entity.Property(e => e.Bit13AdpcodeSet).HasColumnName("Bit13_ADPCodeSet");

                entity.Property(e => e.Bit14NplsaleDateSet).HasColumnName("Bit14_NPLSaleDateSet");

                entity.Property(e => e.Bit15SettlementDateSet).HasColumnName("Bit15_SettlementDateSet");

                entity.Property(e => e.Bit16PaymentDeferralCompletionDateSet).HasColumnName("Bit16_PaymentDeferralCompletionDateSet");

                entity.Property(e => e.Bit17RplsaleDateSet).HasColumnName("Bit17_RPLSaleDateSet");

                entity.Property(e => e.Bit1TpsdateSet).HasColumnName("Bit1_TPSDateSet");

                entity.Property(e => e.Bit2PfsdateSet).HasColumnName("Bit2_PFSDateSet");

                entity.Property(e => e.Bit3PartAfiledDateSet).HasColumnName("Bit3_PartAFiledDateSet");

                entity.Property(e => e.Bit4DildateSet).HasColumnName("Bit4_DILDateSet");

                entity.Property(e => e.Bit5FcsaleDateSet).HasColumnName("Bit5_FCSaleDateSet");

                entity.Property(e => e.Bit6VacaseNumberSet).HasColumnName("Bit6_VACaseNumberSet");

                entity.Property(e => e.Bit7LoanNumberSet).HasColumnName("Bit7_LoanNumberSet");

                entity.Property(e => e.Bit8FhacaseNumberSet).HasColumnName("Bit8_FHACaseNumberSet");

                entity.Property(e => e.Bit9IccdateSet).HasColumnName("Bit9_ICCDateSet");

                entity.Property(e => e.CharacterizationResult)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpCntlInvtrkDateValidationRules>(entity =>
            {
                entity.HasKey(e => e.DateValidationId)
                    .HasName("PK_lkp_CNTL_InvTrk_Date_Validation_rules1");

                entity.ToTable("lkp_cntl_invtrk_date_validation_rules");

                entity.HasIndex(e => e.DateBitValue)
                    .HasName("UK1_lkp_CNTL_InvTrk_Date_Validation_rules_BitValue1")
                    .IsUnique();

                entity.HasIndex(e => new { e.Bit0FcsaleDate, e.Bit1Pfsdate, e.Bit2Dildate, e.Bit3Tpsdate, e.Bit4ReosaleDate, e.Bit5LiquidationDate, e.Bit6Rrcdate, e.Bit7NplsaleDate, e.Bit8PaymentDeferralCompletionDate, e.Bit9RplsaleDate })
                    .HasName("UK2_lkp_CNTL_InvTrk_Date_Validation_rules_AllBits1")
                    .IsUnique();

                entity.Property(e => e.DateValidationId).HasColumnName("DateValidationID");

                entity.Property(e => e.Bit0FcsaleDate).HasColumnName("Bit0_FCSaleDate");

                entity.Property(e => e.Bit1Pfsdate).HasColumnName("Bit1_PFSDate");

                entity.Property(e => e.Bit2Dildate).HasColumnName("Bit2_DILDate");

                entity.Property(e => e.Bit3Tpsdate).HasColumnName("Bit3_TPSDate");

                entity.Property(e => e.Bit4ReosaleDate).HasColumnName("Bit4_REOSaleDate");

                entity.Property(e => e.Bit5LiquidationDate).HasColumnName("Bit5_LiquidationDate");

                entity.Property(e => e.Bit6Rrcdate).HasColumnName("Bit6_RRCDate");

                entity.Property(e => e.Bit7NplsaleDate).HasColumnName("Bit7_NPLSaleDate");

                entity.Property(e => e.Bit8PaymentDeferralCompletionDate).HasColumnName("Bit8_PaymentDeferralCompletionDate");

                entity.Property(e => e.Bit9RplsaleDate).HasColumnName("Bit9_RPLSaleDate");

                entity.Property(e => e.Result)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpDispositionStatus>(entity =>
            {
                entity.HasKey(e => e.DispositionStatusId)
                    .HasName("DispositionStatus_PK");

                entity.ToTable("lkp_DispositionStatus");

                entity.HasComment("A table of Status Codes and Descriptions indicating the disposition or state of a particular import record or artifact.");

                entity.HasIndex(e => e.DispositionStatusCode)
                    .HasName("UK1_lkp_DispositionStatus")
                    .IsUnique();

                entity.Property(e => e.DispositionStatusId)
                    .HasColumnName("DispositionStatusID")
                    .HasComment("Unique identifier for a record in the disposition Status lookup table");

                entity.Property(e => e.DispositionStatusCode)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasComment("A mnemonic code indicating the status.  Must be unique.  These mnemonics are used within C# application code to generate the log and status reports for imports");

                entity.Property(e => e.DispositionStatusDescription)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false)
                    .HasComment("A detailed description of the status.");
            });

            modelBuilder.Entity<LkpFileTypes>(entity =>
            {
                entity.HasKey(e => e.FileTypeId)
                    .HasName("FileTypes_PK");

                entity.ToTable("lkp_FileTypes");

                entity.Property(e => e.FileTypeId).HasColumnName("FileTypeID");

                entity.Property(e => e.FileTypeDescription)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.FileTypeExtension)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpImportAttribute>(entity =>
            {
                entity.HasKey(e => e.ImportAttributeId)
                    .HasName("ImportAttribute_PK");

                entity.ToTable("lkp_ImportAttribute");

                entity.HasIndex(e => new { e.ImportAttributeName, e.TableDirect })
                    .HasName("UK1_lkp_ImportAttribute")
                    .IsUnique();

                entity.Property(e => e.ImportAttributeId).HasColumnName("ImportAttributeID");

                entity.Property(e => e.ImportAttributeDataTypeId).HasColumnName("ImportAttributeDataTypeID");

                entity.Property(e => e.ImportAttributeName)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.TableDirect)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.HasOne(d => d.ImportAttributeDataType)
                    .WithMany(p => p.LkpImportAttribute)
                    .HasForeignKey(d => d.ImportAttributeDataTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_ImportAttribute_ImportAttributeDataTypes");
            });

            modelBuilder.Entity<LkpImportAttributeDataTypes>(entity =>
            {
                entity.HasKey(e => e.ImportAttributeDataTypeId)
                    .HasName("ImportAttributeDataTypes_PK");

                entity.ToTable("lkp_ImportAttributeDataTypes");

                entity.Property(e => e.ImportAttributeDataTypeId).HasColumnName("ImportAttributeDataTypeID");

                entity.Property(e => e.DataTypeName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Format)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpImportTableMapping>(entity =>
            {
                entity.HasKey(e => e.ImportTableMappingId);

                entity.ToTable("lkp_ImportTableMapping");

                entity.Property(e => e.ImportTableMappingId).HasColumnName("ImportTableMappingID");

                entity.Property(e => e.ColumnDataType)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.ColumnName)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.DateEntered).HasColumnType("datetime");

                entity.Property(e => e.ImportAttributeId).HasColumnName("ImportAttributeID");

                entity.Property(e => e.TableName)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.HasOne(d => d.ImportAttribute)
                    .WithMany(p => p.LkpImportTableMapping)
                    .HasForeignKey(d => d.ImportAttributeId)
                    .HasConstraintName("FK1_lkp_ImportTableMapping_lkp_ImportAttribute");
            });

            modelBuilder.Entity<LkpInvestorClaimTypeMatrix>(entity =>
            {
                entity.HasKey(e => e.InvestorClaimTypeMatrixId)
                    .HasName("PK_InvestorClaimTypeMatrix1");

                entity.ToTable("lkp_InvestorClaimTypeMatrix");

                entity.HasIndex(e => new { e.InvestorGroupId, e.BitValue })
                    .HasName("UK1_lkp_InvestorClaimTypeMatrix1")
                    .IsUnique();

                entity.Property(e => e.InvestorClaimTypeMatrixId).HasColumnName("InvestorClaimTypeMatrixID");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.ImportAttributeId).HasColumnName("ImportAttributeID");

                entity.Property(e => e.InvestorGroupId).HasColumnName("InvestorGroupID");

                entity.Property(e => e.IsDildateSet).HasColumnName("IsDILDateSet");

                entity.Property(e => e.IsFcsaleDateSet).HasColumnName("IsFCSaleDateSet");

                entity.Property(e => e.IsNplsaleDateSet).HasColumnName("IsNPLSaleDateSet");

                entity.Property(e => e.IsPfsdateSet).HasColumnName("IsPFSDateSet");

                entity.Property(e => e.IsReosaleDdateSet).HasColumnName("IsREOSaleDDateSet");

                entity.Property(e => e.IsRplsaleDateSet).HasColumnName("IsRPLSaleDateSet");

                entity.Property(e => e.IsRrcdateSet).HasColumnName("IsRRCDateSet");

                entity.Property(e => e.IsTpsdateSet).HasColumnName("IsTPSDateSet");

                entity.Property(e => e.Result)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.ImportAttribute)
                    .WithMany(p => p.LkpInvestorClaimTypeMatrix)
                    .HasForeignKey(d => d.ImportAttributeId)
                    .HasConstraintName("FK1_InvestorClaimTypeMatrix_ImportAttribute1");
            });

            modelBuilder.Entity<LkpMiclaimTypeMatrix>(entity =>
            {
                entity.HasKey(e => e.MiclaimTypeMatrixId)
                    .HasName("PK_MIClaimTypeMatrix");

                entity.ToTable("lkp_MIClaimTypeMatrix");

                entity.HasIndex(e => new { e.ClientId, e.BitValue })
                    .HasName("UK1_lkp_MIClaimTypeMatrix")
                    .IsUnique();

                entity.Property(e => e.MiclaimTypeMatrixId).HasColumnName("MIClaimTypeMatrixID");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.ImportAttributeId).HasColumnName("ImportAttributeID");

                entity.Property(e => e.IsDildateSet).HasColumnName("IsDILDateSet");

                entity.Property(e => e.IsFcsaleDateSet).HasColumnName("IsFCSaleDateSet");

                entity.Property(e => e.IsPfsdateSet).HasColumnName("IsPFSDateSet");

                entity.Property(e => e.IsRrcdateSet).HasColumnName("IsRRCDateSet");

                entity.Property(e => e.IsTpsdateSet).HasColumnName("IsTPSDateSet");

                entity.Property(e => e.Result)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.ImportAttribute)
                    .WithMany(p => p.LkpMiclaimTypeMatrix)
                    .HasForeignKey(d => d.ImportAttributeId)
                    .HasConstraintName("FK1_lkp_MIClaimTypeMatrix_lkp_ImportAttribute");
            });

            modelBuilder.Entity<LkpMicompanySuppliedNameMicompanyId>(entity =>
            {
                entity.HasKey(e => e.MicompanyTextLookupId);

                entity.ToTable("lkp_MICompanySuppliedName_MICompanyID");

                entity.Property(e => e.MicompanyTextLookupId).HasColumnName("MICompanyTextLookupID");

                entity.Property(e => e.CmsInvTrkMicompanyId).HasColumnName("CMS_InvTrk_MICompanyID");

                entity.Property(e => e.DateEntered)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.MitextLookup)
                    .IsRequired()
                    .HasColumnName("MITextLookup")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpMiscClaimTypeMatrix>(entity =>
            {
                entity.HasKey(e => e.MiscClaimTypeMatrixId);

                entity.ToTable("lkp_MiscClaimTypeMatrix");

                entity.Property(e => e.MiscClaimTypeMatrixId).HasColumnName("MiscClaimTypeMatrixID");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.ClaimTypeLookup)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ImportAttributeId).HasColumnName("ImportAttributeID");

                entity.Property(e => e.Result)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.ImportAttribute)
                    .WithMany(p => p.LkpMiscClaimTypeMatrix)
                    .HasForeignKey(d => d.ImportAttributeId)
                    .HasConstraintName("FK1_Table_1_lkp_ImportAttribute");
            });

            modelBuilder.Entity<LkpNonLiquidationClaimTypeCharacterizations>(entity =>
            {
                entity.HasKey(e => e.NonLiquidationClaimTypeCharacterizationId);

                entity.ToTable("lkp_NonLiquidationClaimTypeCharacterizations");

                entity.HasIndex(e => e.CharacterizationDispositionStatusId)
                    .HasName("UK2_lkp_NonLiquidationClaimTypeCharacterizations_CharacterizationDispositionStatusID")
                    .IsUnique();

                entity.HasIndex(e => e.ClaimNotReleasedDispositionStatusId)
                    .HasName("UK6_lkp_NonLiquidationClaimTypeCharacterizations_ClaimNotReleasedDispositionStatusID")
                    .IsUnique();

                entity.HasIndex(e => e.ClaimReleasedDispositionStatusId)
                    .HasName("UK5_lkp_NonLiquidationClaimTypeCharacterizations_ClaimReleasedDispositionStatusID")
                    .IsUnique();

                entity.HasIndex(e => e.InvTrkClaimTypeId)
                    .HasName("UK1_lkp_NonLiquidationClaimTypeCharacterizations_InvTrkClaimTypeID")
                    .IsUnique();

                entity.HasIndex(e => e.LoanNotReleasedDispositionStatusId)
                    .HasName("UK4_lkp_NonLiquidationClaimTypeCharacterizations_LoanNotReleasedDispositionStatusID")
                    .IsUnique();

                entity.HasIndex(e => e.LoanReleasedDispositionStatusId)
                    .HasName("UK3_lkp_NonLiquidationClaimTypeCharacterizations_LoanReleasedDispositionStatusID")
                    .IsUnique();

                entity.Property(e => e.NonLiquidationClaimTypeCharacterizationId).HasColumnName("NonLiquidationClaimTypeCharacterizationID");

                entity.Property(e => e.CharacterizationDispositionStatusId).HasColumnName("CharacterizationDispositionStatusID");

                entity.Property(e => e.ClaimNotReleasedDispositionStatusId).HasColumnName("ClaimNotReleasedDispositionStatusID");

                entity.Property(e => e.ClaimReleasedDispositionStatusId).HasColumnName("ClaimReleasedDispositionStatusID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.InvTrkClaimTypeId).HasColumnName("InvTrkClaimTypeID");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.LoanNotReleasedDispositionStatusId).HasColumnName("LoanNotReleasedDispositionStatusID");

                entity.Property(e => e.LoanReleasedDispositionStatusId).HasColumnName("LoanReleasedDispositionStatusID");

                entity.HasOne(d => d.CharacterizationDispositionStatus)
                    .WithOne(p => p.LkpNonLiquidationClaimTypeCharacterizationsCharacterizationDispositionStatus)
                    .HasForeignKey<LkpNonLiquidationClaimTypeCharacterizations>(d => d.CharacterizationDispositionStatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_lkp_NonLiquidationClaimTypeCharacterizations_lkp_DispositionStatus");

                entity.HasOne(d => d.ClaimNotReleasedDispositionStatus)
                    .WithOne(p => p.LkpNonLiquidationClaimTypeCharacterizationsClaimNotReleasedDispositionStatus)
                    .HasForeignKey<LkpNonLiquidationClaimTypeCharacterizations>(d => d.ClaimNotReleasedDispositionStatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK5_lkp_NonLiquidationClaimTypeCharacterizations_lkp_DispositionStatus");

                entity.HasOne(d => d.ClaimReleasedDispositionStatus)
                    .WithOne(p => p.LkpNonLiquidationClaimTypeCharacterizationsClaimReleasedDispositionStatus)
                    .HasForeignKey<LkpNonLiquidationClaimTypeCharacterizations>(d => d.ClaimReleasedDispositionStatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_lkp_NonLiquidationClaimTypeCharacterizations_lkp_DispositionStatus");

                entity.HasOne(d => d.LoanNotReleasedDispositionStatus)
                    .WithOne(p => p.LkpNonLiquidationClaimTypeCharacterizationsLoanNotReleasedDispositionStatus)
                    .HasForeignKey<LkpNonLiquidationClaimTypeCharacterizations>(d => d.LoanNotReleasedDispositionStatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_lkp_NonLiquidationClaimTypeCharacterizations_lkp_DispositionStatus");

                entity.HasOne(d => d.LoanReleasedDispositionStatus)
                    .WithOne(p => p.LkpNonLiquidationClaimTypeCharacterizationsLoanReleasedDispositionStatus)
                    .HasForeignKey<LkpNonLiquidationClaimTypeCharacterizations>(d => d.LoanReleasedDispositionStatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_lkp_NonLiquidationClaimTypeCharacterizations_lkp_DispositionStatus");
            });

            modelBuilder.Entity<LkpPoolClaimTypeMatrix>(entity =>
            {
                entity.HasKey(e => e.PoolClaimTypeMatrixId)
                    .HasName("PK_PoolClaimTypeMatrix");

                entity.ToTable("lkp_PoolClaimTypeMatrix");

                entity.HasIndex(e => new { e.ClientId, e.BitValue })
                    .HasName("UK1_lkp_PoolClaimTypeMatrix")
                    .IsUnique();

                entity.Property(e => e.PoolClaimTypeMatrixId).HasColumnName("PoolClaimTypeMatrixID");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.ImportAttributeId).HasColumnName("ImportAttributeID");

                entity.Property(e => e.IsDildateSet).HasColumnName("IsDILDateSet");

                entity.Property(e => e.IsFcsaleDateSet).HasColumnName("IsFCSaleDateSet");

                entity.Property(e => e.IsPfsdateSet).HasColumnName("IsPFSDateSet");

                entity.Property(e => e.IsReosaleDateSet).HasColumnName("IsREOSaleDateSet");

                entity.Property(e => e.IsRrcdateSet).HasColumnName("IsRRCDateSet");

                entity.Property(e => e.IsTpsdateSet).HasColumnName("IsTPSDateSet");

                entity.Property(e => e.Result)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.ImportAttribute)
                    .WithMany(p => p.LkpPoolClaimTypeMatrix)
                    .HasForeignKey(d => d.ImportAttributeId)
                    .HasConstraintName("FK1_lkp_PoolClaimTypeMatrix_lkp_ImportAttribute");
            });

            modelBuilder.Entity<RawFhasupplementalImports>(entity =>
            {
                entity.HasKey(e => e.RawFhasupplementalImportId);

                entity.ToTable("RawFHASupplementalImports");

                entity.Property(e => e.RawFhasupplementalImportId).HasColumnName("RawFHASupplementalImportID");

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.FhacaseNumber)
                    .IsRequired()
                    .HasColumnName("FHACaseNumber")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.LoanNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ParentClaimType)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ReferralDate).HasColumnType("date");

                entity.Property(e => e.SettlementDate).HasColumnType("date");

                entity.Property(e => e.SuppDueDate).HasColumnType("date");
            });

            modelBuilder.Entity<Rhiannon>(entity =>
            {
                entity.HasKey(e => e.Idcolumn)
                    .HasName("PK__Rhiannon__06C68232783153A5");

                entity.Property(e => e.Idcolumn).HasColumnName("IDColumn");

                entity.Property(e => e.Field1)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Field2)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Field4).HasColumnType("decimal(8, 4)");

                entity.Property(e => e.Field5).HasColumnType("datetime");

                entity.Property(e => e.Field6).HasColumnType("date");
            });

            modelBuilder.Entity<TblBatchDispositionHistory>(entity =>
            {
                entity.HasKey(e => e.BatchDispositionHistoryId);

                entity.ToTable("tbl_BatchDispositionHistory");

                entity.Property(e => e.BatchDispositionHistoryId).HasColumnName("BatchDispositionHistoryID");

                entity.Property(e => e.DispositionStatusId).HasColumnName("DispositionStatusID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.ImportBatchId).HasColumnName("Import_BatchID");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.StatusAttribute)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.StatusValue)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.DispositionStatus)
                    .WithMany(p => p.TblBatchDispositionHistory)
                    .HasForeignKey(d => d.DispositionStatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_tbl_BatchDispositionHistory_lkp_DispositionStatus");

                entity.HasOne(d => d.ImportBatch)
                    .WithMany(p => p.TblBatchDispositionHistory)
                    .HasForeignKey(d => d.ImportBatchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_BatchDispositionHistory_tbl_ImportBatch");
            });

            modelBuilder.Entity<TblFnmaadvPmtImportData>(entity =>
            {
                entity.HasKey(e => e.FnmaadvPmtImportDataId);

                entity.ToTable("tbl_FNMAAdvPmt_ImportData");

                entity.Property(e => e.FnmaadvPmtImportDataId).HasColumnName("FNMAAdvPmt_ImportDataID");

                entity.Property(e => e.BusinessEntityName)
                    .HasMaxLength(75)
                    .IsUnicode(false);

                entity.Property(e => e.FnmaloanNumber)
                    .HasColumnName("FNMALoanNumber")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ImportRecordId).HasColumnName("ImportRecordID");

                entity.Property(e => e.LoanStatusCode)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.PreparerName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyStateCode)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerLoanNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.TransactionAmount).HasColumnType("money");

                entity.HasOne(d => d.ImportRecord)
                    .WithMany(p => p.TblFnmaadvPmtImportData)
                    .HasForeignKey(d => d.ImportRecordId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tbl_FNMAAdvPmt_ImportData_tbl_ImportRecord");
            });

            modelBuilder.Entity<TblImportBatch>(entity =>
            {
                entity.HasKey(e => e.ImportBatchId)
                    .HasName("ImportBatch_PK");

                entity.ToTable("tbl_ImportBatch");

                entity.HasIndex(e => new { e.ImportBatchId, e.OriginalFileName, e.FileTypeId, e.BatchRecordCount, e.EnteredDate, e.EnteredByUserId, e.ClientId })
                    .HasName("idx_tbl_ImportBatch_ClientID");

                entity.Property(e => e.ImportBatchId).HasColumnName("Import_BatchID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FileTypeId).HasColumnName("FileTypeID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.OriginalFileName)
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.HasOne(d => d.FileType)
                    .WithMany(p => p.TblImportBatch)
                    .HasForeignKey(d => d.FileTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_ImportBatch_FileTypes");
            });

            modelBuilder.Entity<TblImportRecord>(entity =>
            {
                entity.HasKey(e => e.ImportRecordId)
                    .HasName("ImportRecord_PK");

                entity.ToTable("tbl_ImportRecord");

                entity.Property(e => e.ImportRecordId).HasColumnName("ImportRecordID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.ImportBatchId).HasColumnName("Import_BatchID");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.ImportBatch)
                    .WithMany(p => p.TblImportRecord)
                    .HasForeignKey(d => d.ImportBatchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_ImportRecord_tbl_ImportBatch");
            });

            modelBuilder.Entity<TblImportRecordData>(entity =>
            {
                entity.HasKey(e => e.ImportDataId)
                    .HasName("Import_Data_PK");

                entity.ToTable("tbl_ImportRecordData");

                entity.HasIndex(e => new { e.ImportRecordId, e.ImportAttributeId })
                    .HasName("idx_ImportRecordData_RecordID_AttributeID");

                entity.HasIndex(e => new { e.ImportRecordId, e.ImportAttributeValue, e.ImportAttributeId })
                    .HasName("idx_tbl_ImportRecordData_ImportAttributeIDImportRecordIDImportAttributeValue");

                entity.Property(e => e.ImportDataId).HasColumnName("ImportDataID");

                entity.Property(e => e.ImportAttributeId).HasColumnName("ImportAttributeID");

                entity.Property(e => e.ImportAttributeValue)
                    .IsRequired()
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.ImportRecordId).HasColumnName("ImportRecordID");

                entity.HasOne(d => d.ImportAttribute)
                    .WithMany(p => p.TblImportRecordData)
                    .HasForeignKey(d => d.ImportAttributeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_Import_Data_ImportAttributes");

                entity.HasOne(d => d.ImportRecord)
                    .WithMany(p => p.TblImportRecordData)
                    .HasForeignKey(d => d.ImportRecordId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_ImportRecordData_tbl_ImportRecord");
            });

            modelBuilder.Entity<TblNonLiquidationClaimTypeValidations>(entity =>
            {
                entity.HasKey(e => e.NonLiquidationClaimTypeValidationId);

                entity.ToTable("tbl_NonLiquidationClaimTypeValidations");

                entity.HasIndex(e => e.ClientReferredValue)
                    .HasName("UK1_NonLiquidationClaimTypeValidations_ClientReferredValue")
                    .IsUnique();

                entity.HasIndex(e => new { e.NonLiquidationClaimTypeCharacterizationId, e.ClientReferredValue })
                    .HasName("UK2_tbl_NonLiquidationClaimTypeValidations")
                    .IsUnique();

                entity.Property(e => e.NonLiquidationClaimTypeValidationId).HasColumnName("NonLiquidationClaimTypeValidationID");

                entity.Property(e => e.ClientReferredValue)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EffectiveFromDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.EffectiveToDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("('12/31/2078')");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.NonLiquidationClaimTypeCharacterizationId).HasColumnName("NonLiquidationClaimTypeCharacterizationID");

                entity.HasOne(d => d.NonLiquidationClaimTypeCharacterization)
                    .WithMany(p => p.TblNonLiquidationClaimTypeValidations)
                    .HasForeignKey(d => d.NonLiquidationClaimTypeCharacterizationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_NonLiquidationClaimTypeValidations_lkp_NonLiquidationClaimTypeCharacterizations");
            });

            modelBuilder.Entity<TblRecordDispositionHistory>(entity =>
            {
                entity.HasKey(e => e.RecordDispositionHistoryId);

                entity.ToTable("tbl_RecordDispositionHistory");

                entity.HasIndex(e => new { e.DispositionStatusId, e.StatusAttribute, e.StatusValue, e.ImportRecordId })
                    .HasName("idx_tbl_RecordDispositionHistory_ImportRecordID");

                entity.Property(e => e.RecordDispositionHistoryId).HasColumnName("RecordDispositionHistoryID");

                entity.Property(e => e.DispositionStatusId).HasColumnName("DispositionStatusID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.ImportRecordId).HasColumnName("ImportRecordID");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.StatusAttribute)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.StatusValue).HasColumnType("varchar(max)");

                entity.HasOne(d => d.DispositionStatus)
                    .WithMany(p => p.TblRecordDispositionHistory)
                    .HasForeignKey(d => d.DispositionStatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_tbl_RecordDispositionHistory_lkp_DispositionStatus");

                entity.HasOne(d => d.ImportRecord)
                    .WithMany(p => p.TblRecordDispositionHistory)
                    .HasForeignKey(d => d.ImportRecordId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_RecordDispositionHistory_tbl_ImportRecord");
            });

            modelBuilder.Entity<UsdacharacterizationRules>(entity =>
            {
                entity.HasKey(e => e.UsdacharacterizationRuleId)
                    .HasName("PK__USDAChar__17BADE3B23902FAA");

                entity.ToTable("USDACharacterizationRules");

                entity.HasIndex(e => new { e.PropertyAcquisitionDatePopulated, e.FclsaleDatePopulated, e.RrcdatePopulated, e.DilrecordedDatePopulated, e.TpsdatePopulated, e.PfsdatePopulated, e.ReosaleDatePopulated, e.NextPmtDueDtPlusOneMnthLt20141201, e.NextPmtDueDtPlusOneMnthGte20141201, e.ImportAttributeIdAnchorDate })
                    .HasName("UK1_USDACharacterizationRules2")
                    .IsUnique();

                entity.Property(e => e.UsdacharacterizationRuleId).HasColumnName("USDACharacterizationRuleID");

                entity.Property(e => e.DilrecordedDatePopulated)
                    .IsRequired()
                    .HasColumnName("DILRecordedDatePopulated")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.FclsaleDatePopulated)
                    .IsRequired()
                    .HasColumnName("FCLSaleDate_Populated")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.ImportAttributeIdAnchorDate).HasColumnName("ImportAttributeID_AnchorDate");

                entity.Property(e => e.NextPmtDueDtPlusOneMnthGte20141201)
                    .IsRequired()
                    .HasColumnName("NextPmtDueDtPlusOneMnth_GTE_20141201")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.NextPmtDueDtPlusOneMnthLt20141201)
                    .IsRequired()
                    .HasColumnName("NextPmtDueDtPlusOneMnth_LT_20141201")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.PfsdatePopulated)
                    .IsRequired()
                    .HasColumnName("PFSDate_Populated")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.PropertyAcquisitionDatePopulated)
                    .IsRequired()
                    .HasColumnName("PropertyAcquisitionDate_Populated")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength()
                    .HasDefaultValueSql("('N')");

                entity.Property(e => e.ReosaleDatePopulated)
                    .IsRequired()
                    .HasColumnName("REOSaleDate_Populated")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.RrcdatePopulated)
                    .IsRequired()
                    .HasColumnName("RRCDate_Populated")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.TpsdatePopulated)
                    .IsRequired()
                    .HasColumnName("TPSDate_Populated")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.UsdaclaimTypeId).HasColumnName("USDAClaimTypeID");

                entity.HasOne(d => d.ImportAttributeIdAnchorDateNavigation)
                    .WithMany(p => p.UsdacharacterizationRules)
                    .HasForeignKey(d => d.ImportAttributeIdAnchorDate)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_USDACharacterizationRules_lkp_ImportAttribute2");
            });

           

            modelBuilder.Entity<VwDataImportsBatches>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DataImports_Batches");

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDateTz5)
                    .HasColumnName("EnteredDate_TZ5")
                    .HasColumnType("datetime");

                entity.Property(e => e.FileTypeDescription)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ImportBatchId).HasColumnName("Import_BatchID");

                entity.Property(e => e.OriginalFileName)
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwDataImportsNormalizedAttributeValues>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DataImports_NormalizedAttributeValues");

                entity.Property(e => e.ImportAttributeName)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.ImportAttributeValue)
                    .IsRequired()
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.ImportDataId).HasColumnName("ImportDataID");

                entity.Property(e => e.ImportRecordId).HasColumnName("ImportRecordID");
            });

            modelBuilder.Entity<VwDataImportsRecordDispositions>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DataImports_RecordDispositions");

                entity.Property(e => e.DispositionStatusCode)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DispositionStatusDescription)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.ImportRecordId).HasColumnName("ImportRecordID");

                entity.Property(e => e.RecordDispositionHistoryId).HasColumnName("RecordDispositionHistoryID");

                entity.Property(e => e.StatusAttribute)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.StatusValue)
                    .HasMaxLength(200)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwDataImportsReferralDashboardCharacterizationData>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DataImports_ReferralDashboard_CharacterizationData");

                entity.Property(e => e.CharacterizationDescription)
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.CharacterizationResult)
                    .IsRequired()
                    .HasMaxLength(26)
                    .IsUnicode(false);

                entity.Property(e => e.CharacterizationStatusCode)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CharacterizationStatusValue)
                    .HasMaxLength(301)
                    .IsUnicode(false);

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Iccreferral).HasColumnName("ICCReferral");

                entity.Property(e => e.ImportBatchId).HasColumnName("Import_BatchID");

                entity.Property(e => e.ImportRecordId).HasColumnName("ImportRecordID");

                entity.Property(e => e.LoadedBy)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.LoanNumber)
                    .HasMaxLength(8000)
                    .IsUnicode(false);

                entity.Property(e => e.OriginalFileName)
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.ProcessedDate).HasColumnType("date");

                entity.Property(e => e.ReferralOrigin)
                    .IsRequired()
                    .HasMaxLength(14)
                    .IsUnicode(false);

                entity.Property(e => e.StatusAttribute)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.StatusValue)
                    .HasMaxLength(200)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwImportsColumnNormalizationMappings>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_Imports_ColumnNormalizationMappings");

                entity.Property(e => e.DestColumn)
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.DestTable)
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.ImportAttributeId).HasColumnName("ImportAttributeID");

                entity.Property(e => e.MappingSourceTable)
                    .IsRequired()
                    .HasMaxLength(23)
                    .IsUnicode(false);

                entity.Property(e => e.NormalizedColumnName)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.SuppliedFieldName)
                    .IsRequired()
                    .HasMaxLength(2000)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<XrefClientProcessImportDetailAttributeSortOrders>(entity =>
            {
                entity.HasKey(e => e.ClientProcessImportDetailAttributeSortOrderId)
                    .HasName("PK_xref_ClientProcessExtractionDetailAttributeSortOrders");

                entity.ToTable("xref_ClientProcessImportDetailAttributeSortOrders");

                entity.Property(e => e.ClientProcessImportDetailAttributeSortOrderId).HasColumnName("ClientProcessImportDetailAttributeSortOrderID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.DataImportProcessId).HasColumnName("DataImportProcessID");

                entity.Property(e => e.ImportDetailAttributeId).HasColumnName("ImportDetailAttributeID");

                entity.HasOne(d => d.DataImportProcess)
                    .WithMany(p => p.XrefClientProcessImportDetailAttributeSortOrders)
                    .HasForeignKey(d => d.DataImportProcessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_ClientProcessExtractionDetailAttributeSortOrders_DataExtractionProcesses");

                entity.HasOne(d => d.ImportDetailAttribute)
                    .WithMany(p => p.XrefClientProcessImportDetailAttributeSortOrders)
                    .HasForeignKey(d => d.ImportDetailAttributeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_ClientProcessExtractionDetailAttributeSortOrders_ExtractionDetailAttributes");
            });

            modelBuilder.Entity<XrefColumnMappings>(entity =>
            {
                entity.HasKey(e => e.ColumnMapId);

                entity.ToTable("xref_ColumnMappings");

                entity.Property(e => e.ColumnMapId).HasColumnName("ColumnMapID");

                entity.Property(e => e.ImportAttributeId).HasColumnName("ImportAttributeID");

                entity.Property(e => e.SuppliedFieldName)
                    .IsRequired()
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.HasOne(d => d.ImportAttribute)
                    .WithMany(p => p.XrefColumnMappings)
                    .HasForeignKey(d => d.ImportAttributeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_xref_ColumnMappings_lkp_ImportAttribute");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
