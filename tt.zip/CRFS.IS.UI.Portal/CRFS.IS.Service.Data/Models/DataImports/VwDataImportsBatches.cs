﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwDataImportsBatches
    {
        public string ClientName { get; set; }
        public string OriginalFileName { get; set; }
        public string FileTypeDescription { get; set; }
        public int? BatchRecordCount { get; set; }
        public string UserName { get; set; }
        public DateTime? EnteredDateTz5 { get; set; }
        public int ImportBatchId { get; set; }
    }
}
