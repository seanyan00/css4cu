﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class DataImportDetails
    {
        public long DataImportDetailId { get; set; }
        public long DataImportLogId { get; set; }
        public int ImportDetailAttributeId { get; set; }
        public string ImportDetailValue { get; set; }
        public bool MarkedForDelete { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUserId { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUserId { get; set; }

        public virtual DataImportLogs DataImportLog { get; set; }
        public virtual ImportDetailAttributes ImportDetailAttribute { get; set; }
    }
}
