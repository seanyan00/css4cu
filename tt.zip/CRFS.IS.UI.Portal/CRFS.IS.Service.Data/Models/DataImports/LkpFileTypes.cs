﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpFileTypes
    {
        public LkpFileTypes()
        {
            TblImportBatch = new HashSet<TblImportBatch>();
        }

        public int FileTypeId { get; set; }
        public string FileTypeDescription { get; set; }
        public string FileTypeExtension { get; set; }

        public virtual ICollection<TblImportBatch> TblImportBatch { get; set; }
    }
}
