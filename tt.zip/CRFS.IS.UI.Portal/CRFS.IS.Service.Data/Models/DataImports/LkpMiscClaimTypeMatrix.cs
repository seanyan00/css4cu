﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpMiscClaimTypeMatrix
    {
        public int MiscClaimTypeMatrixId { get; set; }
        public string ClaimTypeLookup { get; set; }
        public string Result { get; set; }
        public int? ClaimTypeId { get; set; }
        public int? ImportAttributeId { get; set; }
        public int? DaysToAdd { get; set; }

        public virtual LkpImportAttribute ImportAttribute { get; set; }
    }
}
