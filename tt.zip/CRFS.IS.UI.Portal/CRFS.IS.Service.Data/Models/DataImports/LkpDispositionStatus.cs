﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpDispositionStatus
    {
        public LkpDispositionStatus()
        {
            TblBatchDispositionHistory = new HashSet<TblBatchDispositionHistory>();
            TblRecordDispositionHistory = new HashSet<TblRecordDispositionHistory>();
        }

        public int DispositionStatusId { get; set; }
        public string DispositionStatusCode { get; set; }
        public string DispositionStatusDescription { get; set; }

        public virtual LkpNonLiquidationClaimTypeCharacterizations LkpNonLiquidationClaimTypeCharacterizationsCharacterizationDispositionStatus { get; set; }
        public virtual LkpNonLiquidationClaimTypeCharacterizations LkpNonLiquidationClaimTypeCharacterizationsClaimNotReleasedDispositionStatus { get; set; }
        public virtual LkpNonLiquidationClaimTypeCharacterizations LkpNonLiquidationClaimTypeCharacterizationsClaimReleasedDispositionStatus { get; set; }
        public virtual LkpNonLiquidationClaimTypeCharacterizations LkpNonLiquidationClaimTypeCharacterizationsLoanNotReleasedDispositionStatus { get; set; }
        public virtual LkpNonLiquidationClaimTypeCharacterizations LkpNonLiquidationClaimTypeCharacterizationsLoanReleasedDispositionStatus { get; set; }
        public virtual ICollection<TblBatchDispositionHistory> TblBatchDispositionHistory { get; set; }
        public virtual ICollection<TblRecordDispositionHistory> TblRecordDispositionHistory { get; set; }
    }
}
