﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpAssignmentClaimSubtypeCharacterizationRules
    {
        public long AssignmentClaimSubtypeCharacterizationRuleId { get; set; }
        public long SectionOfActId { get; set; }
        public string ResultMessage { get; set; }
    }
}
