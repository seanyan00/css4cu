﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpClientGroup
    {
        public int ClientGroupId { get; set; }
        public string ClientGroupName { get; set; }
    }
}
