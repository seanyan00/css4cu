﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CRFS.IS.Service.Data
{
    public partial class ClaimsManagementContext : DbContext
    {
        public ClaimsManagementContext()
        {
        }

        public ClaimsManagementContext(DbContextOptions<ClaimsManagementContext> options)
            : base(options)
        {
        }

        public virtual DbSet<LkpClientGroup> LkpClientGroup { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=vm-sql1-dev.dev.crfs.crfservices.com\\cms_d;Initial Catalog=ClaimsManagement;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<LkpClientGroup>(entity =>
            {
                entity.HasKey(e => e.ClientGroupId);

                entity.ToTable("lkp_ClientGroup");

                entity.HasComment("Look-up table. Contains names and ids for client group.");

                entity.HasIndex(e => e.ClientGroupName)
                    .HasName("UK1_ClientGroup_ClientGroupName")
                    .IsUnique();

                entity.Property(e => e.ClientGroupId).HasColumnName("ClientGroupID");

                entity.Property(e => e.ClientGroupName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
