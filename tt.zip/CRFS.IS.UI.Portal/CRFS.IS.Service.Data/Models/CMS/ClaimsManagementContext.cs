﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CRFS.IS.Service.Data
{
    public partial class ClaimsManagementContext : DbContext
    {
        public ClaimsManagementContext()
        {
        }

        public ClaimsManagementContext(DbContextOptions<ClaimsManagementContext> options)
            : base(options)
        {
        }

        public virtual DbSet<LkpInvTrkClaimGroups> LkpInvTrkClaimGroups { get; set; }
        public virtual DbSet<TblInvestorTrackingClaims> TblInvestorTrackingClaims { get; set; }
        public virtual DbSet<TblInvestorTrackingClaimsFhaclaim> TblInvestorTrackingClaimsFhaclaim { get; set; }
        public virtual DbSet<TblInvestorTrackingClaimsVaclaim> TblInvestorTrackingClaimsVaclaim { get; set; }
        public virtual DbSet<TblInvestorTrackingLoans> TblInvestorTrackingLoans { get; set; }
        public virtual DbSet<TblInvestorTrackingLoansNotes> TblInvestorTrackingLoansNotes { get; set; }
        public virtual DbSet<TblSubmitActions> TblSubmitActions { get; set; }
        public virtual DbSet<TbllkpClaimTypesByForm> TbllkpClaimTypesByForm { get; set; }
        public virtual DbSet<TbllkpForms> TbllkpForms { get; set; }
        public virtual DbSet<TbllkpFormsComboBoxValues> TbllkpFormsComboBoxValues { get; set; }
        public virtual DbSet<TbllkpMicompanies> TbllkpMicompanies { get; set; }
        public virtual DbSet<TbllkpSecurityGroups> TbllkpSecurityGroups { get; set; }
        public virtual DbSet<VwApplicationConfigurationCMSUsers> VwApplicationConfigurationCMSUsers { get; set; }
        public virtual DbSet<XrefInvTrkClaimGroupClaimType> XrefInvTrkClaimGroupClaimType { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=vm-sql1-dev.dev.crfs.crfservices.com\\cms_d;Initial Catalog=ClaimsManagement;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<LkpInvTrkClaimGroups>(entity =>
            {
                entity.HasKey(e => e.ClaimGroupId);

                entity.ToTable("lkp_InvTrk_ClaimGroups");

                entity.HasComment("Look-up table. Contains Investor Tracking claim groups data.");

                entity.HasIndex(e => e.ClaimGroupName)
                    .HasName("UK1_lkp_InvTrk_ClaimGroups_ClaimGroupName")
                    .IsUnique();

                entity.Property(e => e.ClaimGroupId).HasColumnName("ClaimGroupID");

                entity.Property(e => e.ClaimGroupName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<TblInvestorTrackingClaims>(entity =>
            {
                entity.ToTable("tblInvestorTracking_Claims");

                entity.HasComment("Contains Investor Tracking claims information.");

                entity.HasIndex(e => e.ClaimType)
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K3");

                entity.HasIndex(e => e.Id)
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K1");

                entity.HasIndex(e => e.LoanId)
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K2");

                entity.HasIndex(e => e.ReferralDate)
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K18");

                entity.HasIndex(e => new { e.ClaimType, e.ClaimClosed })
                    .HasName("_dta_stat_1115151018_3_11");

                entity.HasIndex(e => new { e.ClaimType, e.Id })
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K3_K1");

                entity.HasIndex(e => new { e.ClaimType, e.LoanId })
                    .HasName("_dta_stat_1115151018_3_2");

                entity.HasIndex(e => new { e.Id, e.ClaimType })
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K1_K3");

                entity.HasIndex(e => new { e.Id, e.LoanId })
                    .HasName("_dta_stat_1115151018_1_2");

                entity.HasIndex(e => new { e.LoanId, e.ClaimType })
                    .HasName("idx_tblInvestorTracking_Claims_ClaimType");

                entity.HasIndex(e => new { e.ClaimType, e.Id, e.LoanId })
                    .HasName("idx_tblInvestorTracking_Claims_LoanID");

                entity.HasIndex(e => new { e.ClaimType, e.Id, e.ClaimClosed, e.LoanId })
                    .HasName("_dta_stat_1115151018_3_1_11_2");

                entity.HasIndex(e => new { e.Id, e.LoanId, e.ClaimClosed, e.ClaimType })
                    .HasName("idx_tblInvestorTracking_Claims_ClaimType_incl_ID_LoanID_ClaimClosed");

                entity.HasIndex(e => new { e.Id, e.LoanId, e.ClaimType, e.ClaimClosedDate })
                    .HasName("idx_tblInvestorTracking_Claims_ClaimClosedDate_incl_id_LoanID_ClaimType");

                entity.HasIndex(e => new { e.Id, e.LoanId, e.NoBill, e.ClaimType })
                    .HasName("idx_tblInvestorTracking_Claims_ClaimType_incl_id_LoanID_NoBill");

                entity.HasIndex(e => new { e.ClaimType, e.Id, e.LoanId, e.ReferralDate, e.ClaimClosed })
                    .HasName("idx_tblInvestorTracking_Claims_ClaimClosed_incl_id_LoanID_ClaimType_ReferralDate");

                entity.HasIndex(e => new { e.ClaimDueDate, e.ClaimAmount, e.NoBill, e.NoClaimSubmitted, e.ClaimType, e.Id, e.LoanId })
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K3_K1_K2_4_5_6_7");

                entity.HasIndex(e => new { e.ClaimDueDate, e.ClaimAmount, e.NoBill, e.NoClaimSubmitted, e.ClaimType, e.LoanId, e.Id })
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K3_K2_K1_4_5_6_7");

                entity.HasIndex(e => new { e.ClaimDueDate, e.ClaimAmount, e.NoBill, e.NoClaimSubmitted, e.Id, e.ClaimType, e.LoanId })
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K1_K3_K2_4_5_6_7");

                entity.HasIndex(e => new { e.ClaimDueDate, e.ClaimAmount, e.NoBill, e.NoClaimSubmitted, e.Id, e.LoanId, e.ClaimType })
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K1_K2_K3_4_5_6_7");

                entity.HasIndex(e => new { e.ClaimDueDate, e.ClaimAmount, e.NoBill, e.NoClaimSubmitted, e.LoanId, e.ClaimType, e.Id })
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K2_K3_K1_4_5_6_7");

                entity.HasIndex(e => new { e.ClaimDueDate, e.ClaimAmount, e.NoClaimSubmitted, e.ClaimClosed, e.ClaimType, e.Id, e.LoanId })
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K11_K3_K1_K2_4_5_7");

                entity.HasIndex(e => new { e.ClaimDueDate, e.ClaimAmount, e.NoClaimSubmitted, e.ClaimType, e.Id, e.ClaimClosed, e.LoanId })
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K3_K1_K11_K2_4_5_7");

                entity.HasIndex(e => new { e.ClaimDueDate, e.ClaimAmount, e.NoClaimSubmitted, e.ClaimType, e.LoanId, e.Id, e.ClaimClosed })
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K3_K2_K1_K11_4_5_7");

                entity.HasIndex(e => new { e.ClaimDueDate, e.ClaimAmount, e.NoClaimSubmitted, e.Id, e.ClaimType, e.ClaimClosed, e.LoanId })
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K1_K3_K11_K2_4_5_7");

                entity.HasIndex(e => new { e.ClaimDueDate, e.ClaimAmount, e.NoClaimSubmitted, e.Id, e.ClaimType, e.LoanId, e.ClaimClosed })
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K1_K3_K2_K11_4_5_7");

                entity.HasIndex(e => new { e.ClaimDueDate, e.ClaimAmount, e.NoClaimSubmitted, e.LoanId, e.ClaimType, e.Id, e.ClaimClosed })
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K2_K3_K1_K11_4_5_7");

                entity.HasIndex(e => new { e.Id, e.ClaimType, e.ClaimDueDate, e.ClaimAmount, e.NoBill, e.NoClaimSubmitted, e.LoanId })
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K2_1_3_4_5_6_7");

                entity.HasIndex(e => new { e.Id, e.LoanId, e.ClaimDueDate, e.ClaimAmount, e.NoClaimSubmitted, e.ClaimType, e.ClaimClosed })
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K3_K11_1_2_4_5_7");

                entity.HasIndex(e => new { e.Id, e.LoanId, e.ClaimPaidDate, e.ClaimClosed, e.DateEntered, e.ReferralDate, e.ClaimType })
                    .HasName("idx_tblInvestorTracking_Claims_ClaimTypeID");

                entity.HasIndex(e => new { e.ClaimDueDate, e.ClaimAmount, e.NoBill, e.NoClaimSubmitted, e.ClaimPaidDate, e.ClaimType, e.Id, e.LoanId })
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K3_K1_K2_4_5_6_7_9");

                entity.HasIndex(e => new { e.ClaimDueDate, e.ClaimAmount, e.NoBill, e.NoClaimSubmitted, e.ClaimPaidDate, e.Id, e.ClaimType, e.LoanId })
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K1_K3_K2_4_5_6_7_9");

                entity.HasIndex(e => new { e.ClaimDueDate, e.ClaimAmount, e.NoBill, e.NoClaimSubmitted, e.ClaimPaidDate, e.LoanId, e.Id, e.ClaimType })
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K2_K1_K3_4_5_6_7_9");

                entity.HasIndex(e => new { e.Id, e.ClaimType, e.ClaimDueDate, e.ClaimAmount, e.NoBill, e.NoClaimSubmitted, e.ClaimPaidDate, e.LoanId })
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K2_1_3_4_5_6_7_9");

                entity.HasIndex(e => new { e.LoanId, e.ClaimType, e.ClaimDueDate, e.ClaimAmount, e.NoBill, e.NoClaimSubmitted, e.ClaimPaidDate, e.Id })
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K1_2_3_4_5_6_7_9");

                entity.HasIndex(e => new { e.Id, e.ClaimType, e.ClaimDueDate, e.ClaimAmount, e.NoBill, e.NoClaimSubmitted, e.ClaimPaidDate, e.ClaimClosed, e.LoanId })
                    .HasName("_dta_index_tblInvestorTracking_Claims_6_1115151018__K2_1_3_4_5_6_7_9_11");

                entity.HasIndex(e => new { e.Id, e.LoanId, e.ClaimType, e.ClaimAmount, e.ClaimPerfectionDate, e.RejectedDate, e.RecissionDate, e.CancellationDate, e.ClosedWithoutPaymentDate, e.ClaimClosed })
                    .HasName("idx_tblInvestorTracking_Claims_ClaimClosed");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.CancellationDate).HasColumnType("datetime");

                entity.Property(e => e.ClaimAmount).HasColumnType("money");

                entity.Property(e => e.ClaimCancelledDate).HasColumnType("datetime");

                entity.Property(e => e.ClaimCancelledUserId).HasColumnName("ClaimCancelledUserID");

                entity.Property(e => e.ClaimClosedDate).HasColumnType("datetime");

                entity.Property(e => e.ClaimDueDate).HasColumnType("smalldatetime");

                entity.Property(e => e.ClaimPaidAmount).HasColumnType("money");

                entity.Property(e => e.ClaimPaidDate).HasColumnType("smalldatetime");

                entity.Property(e => e.ClaimPerfectionDate).HasColumnType("smalldatetime");

                entity.Property(e => e.ClientUniqueId)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClosedWithoutPaymentDate).HasColumnType("datetime");

                entity.Property(e => e.ConventionalUsdasupplemental).HasColumnName("ConventionalUSDASupplemental");

                entity.Property(e => e.DateEntered)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IndustryClaimDueDate).HasColumnType("date");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");

                entity.Property(e => e.NoBill).HasDefaultValueSql("((0))");

                entity.Property(e => e.NoClaimSubmitted).HasDefaultValueSql("((0))");

                entity.Property(e => e.OpsModifiableIndustryDueDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.OpsModifiableNotWorkable).HasDefaultValueSql("((0))");

                entity.Property(e => e.OpsModifiableSladueDate)
                    .HasColumnName("OpsModifiableSLADueDate")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.OptionSettlementCoveragePct).HasColumnType("decimal(18, 0)");

                entity.Property(e => e.PaymentDeferralCompletionDate).HasColumnType("datetime");

                entity.Property(e => e.PfuEobreviewOnly)
                    .HasColumnName("PFU_EOBReviewOnly")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.PreSaleSettlementProceedsAmount).HasColumnType("money");

                entity.Property(e => e.RecissionDate).HasColumnType("datetime");

                entity.Property(e => e.ReferralDate).HasColumnType("smalldatetime");

                entity.Property(e => e.RejectedDate).HasColumnType("smalldatetime");

                entity.Property(e => e.RevisedClaimAmt).HasColumnType("money");

                entity.Property(e => e.RevisedEstSettlementAmt).HasColumnType("money");

                entity.Property(e => e.RevisedProceedsAmt).HasColumnType("money");

                entity.Property(e => e.SecondaryClaimDueDate).HasColumnType("date");

                entity.Property(e => e.SingleUseImportGuid)
                    .HasColumnName("SingleUse_ImportGUID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SuppParentClaimId).HasColumnName("SuppParentClaimID");

                entity.Property(e => e.ZeroNegDate).HasColumnType("datetime");

                entity.Property(e => e.ZeroNegUserId).HasColumnName("ZeroNegUserID");

                entity.HasOne(d => d.Loan)
                    .WithMany(p => p.TblInvestorTrackingClaims)
                    .HasForeignKey(d => d.LoanId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tblInvestorTracking_Claims_tblInvestorTracking_Loans");
            });

            modelBuilder.Entity<TblInvestorTrackingClaimsFhaclaim>(entity =>
            {
                entity.HasKey(e => e.FhaclaimId);

                entity.ToTable("tblInvestorTracking_Claims_FHAClaim");

                entity.HasComment("Contains FHA claims Investor Tracking information.");

                entity.HasIndex(e => e.ClaimId)
                    .HasName("tblInvestorTracking_Claims_FHAClaim_ClaimID");

                entity.HasIndex(e => e.SuppParentFhaclaimId)
                    .HasName("tblInvestorTracking_Claims_FHAClaim_SuppParentFHAClaimID");

                entity.HasIndex(e => new { e.ClaimId, e.ConvPartAsubmittedDate, e.ConvPartBonly })
                    .HasName("idx_tblInvestorTracking_Claims_FHAClaim_ConvPartBOnly_incl_ClaimID_ConvPartASubmittedDate");

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.ClaimAmount).HasColumnType("money");

                entity.Property(e => e.ClaimId).HasColumnName("ClaimID");

                entity.Property(e => e.ClaimSubTypeId).HasColumnName("ClaimSubTypeID");

                entity.Property(e => e.ClaimSubmittedAnalystId).HasColumnName("ClaimSubmittedAnalystID");

                entity.Property(e => e.ClaimSubmittedDate).HasColumnType("datetime");

                entity.Property(e => e.ClearMarketableTitleDate).HasColumnType("date");

                entity.Property(e => e.ClearTitleDate).HasColumnType("datetime");

                entity.Property(e => e.ClientSystemUpdatedDate).HasColumnType("datetime");

                entity.Property(e => e.ConvEdiauthorizedDate)
                    .HasColumnName("ConvEDIAuthorizedDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.ConvEdiauthorizedUserId).HasColumnName("ConvEDIAuthorizedUserID");

                entity.Property(e => e.ConvPartAclaimAmount)
                    .HasColumnName("ConvPartAClaimAmount")
                    .HasColumnType("money");

                entity.Property(e => e.ConvPartAclientSystemUpdatedDate)
                    .HasColumnName("ConvPartAClientSystemUpdatedDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.ConvPartAclientSystemUpdatedUser).HasColumnName("ConvPartAClientSystemUpdatedUser");

                entity.Property(e => e.ConvPartAerrorSubmitDate)
                    .HasColumnName("ConvPartAErrorSubmitDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.ConvPartAisEdiauthorized).HasColumnName("ConvPartAIsEDIAuthorized");

                entity.Property(e => e.ConvPartApaidAmount)
                    .HasColumnName("ConvPartAPaidAmount")
                    .HasColumnType("money");

                entity.Property(e => e.ConvPartAprepAnalyst).HasColumnName("ConvPartAPrepAnalyst");

                entity.Property(e => e.ConvPartAprepCompleteDate)
                    .HasColumnName("ConvPartAPrepCompleteDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.ConvPartAsettlementDate)
                    .HasColumnName("ConvPartASettlementDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.ConvPartAsubmittedAnalystId).HasColumnName("ConvPartASubmittedAnalystID");

                entity.Property(e => e.ConvPartAsubmittedDate)
                    .HasColumnName("ConvPartASubmittedDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.ConvPartAsuspendDate)
                    .HasColumnName("ConvPartASuspendDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.ConvPartBonly).HasColumnName("ConvPartBOnly");

                entity.Property(e => e.ConveyanceExtensionExpirationDate).HasColumnType("date");

                entity.Property(e => e.CurtailmentCodeId).HasColumnName("CurtailmentCodeID");

                entity.Property(e => e.CurtailmentDate).HasColumnType("date");

                entity.Property(e => e.EdiauthorizedDate)
                    .HasColumnName("EDIAuthorizedDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.EdiauthorizedUserId).HasColumnName("EDIAuthorizedUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.ErrorSubmitDate).HasColumnType("datetime");

                entity.Property(e => e.ExpectedPartBproceeds)
                    .HasColumnName("ExpectedPartBProceeds")
                    .HasColumnType("money");

                entity.Property(e => e.FcldeedRecordedDate)
                    .HasColumnName("FCLDeedRecordedDate")
                    .HasColumnType("date");

                entity.Property(e => e.FclfirstLegalDate)
                    .HasColumnName("FCLFirstLegalDate")
                    .HasColumnType("date");

                entity.Property(e => e.FhamodificationDate)
                    .HasColumnName("FHAModificationDate")
                    .HasColumnType("date");

                entity.Property(e => e.Ftvdate)
                    .HasColumnName("FTVDate")
                    .HasColumnType("date");

                entity.Property(e => e.FtvdateReported)
                    .HasColumnName("FTVDateReported")
                    .HasColumnType("date");

                entity.Property(e => e.HuddeedRecordedDate)
                    .HasColumnName("HUDDeedRecordedDate")
                    .HasColumnType("date");

                entity.Property(e => e.Hudiddate)
                    .HasColumnName("HUDIDDate")
                    .HasColumnType("date");

                entity.Property(e => e.Iccdate)
                    .HasColumnName("ICCDate")
                    .HasColumnType("date");

                entity.Property(e => e.IccreportDate)
                    .HasColumnName("ICCReportDate")
                    .HasColumnType("date");

                entity.Property(e => e.IneligibilityDate).HasColumnType("date");

                entity.Property(e => e.IneligibilityReasonId).HasColumnName("IneligibilityReasonID");

                entity.Property(e => e.IsEdiauthorized).HasColumnName("IsEDIAuthorized");

                entity.Property(e => e.IsHamp).HasColumnName("IsHAMP");

                entity.Property(e => e.IsSuppReview).HasDefaultValueSql("((0))");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.MarketableTitleDate).HasColumnType("datetime");

                entity.Property(e => e.MhtendDate)
                    .HasColumnName("MHTEndDate")
                    .HasColumnType("date");

                entity.Property(e => e.MhtreviewedDate)
                    .HasColumnName("MHTReviewedDate")
                    .HasColumnType("date");

                entity.Property(e => e.MhtstartDate)
                    .HasColumnName("MHTStartDate")
                    .HasColumnType("date");

                entity.Property(e => e.PaidAmount).HasColumnType("money");

                entity.Property(e => e.PartAanalyst).HasColumnName("PartAAnalyst");

                entity.Property(e => e.PartAcompleteDate)
                    .HasColumnName("PartACompleteDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.PartAqcanalyst).HasColumnName("PartAQCAnalyst");

                entity.Property(e => e.PartAqccompleteDate)
                    .HasColumnName("PartAQCCompleteDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.PartBanalyst).HasColumnName("PartBAnalyst");

                entity.Property(e => e.PartBcompleteDate)
                    .HasColumnName("PartBCompleteDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.PartBqcanalyst).HasColumnName("PartBQCAnalyst");

                entity.Property(e => e.PartBqccompleteDate)
                    .HasColumnName("PartBQCCompleteDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.PrepCompleteDate).HasColumnType("datetime");

                entity.Property(e => e.PrepReferralCompleteDate).HasColumnType("datetime");

                entity.Property(e => e.RecorderLetterReceiveDate).HasColumnType("date");

                entity.Property(e => e.RecorderLetterVerified).HasColumnType("datetime");

                entity.Property(e => e.RecordingInstructionsSentDate).HasColumnType("date");

                entity.Property(e => e.ReviewedForInvestorClaim).HasColumnType("datetime");

                entity.Property(e => e.ServiceTransferDate).HasColumnType("date");

                entity.Property(e => e.SettlementDate).HasColumnType("datetime");

                entity.Property(e => e.SuppParentFhaclaimId).HasColumnName("SuppParentFHAClaimID");

                entity.Property(e => e.SuppRefundDueHud).HasColumnName("SuppRefundDueHUD");

                entity.Property(e => e.SuppReviewSetDate).HasColumnType("datetime");

                entity.Property(e => e.SuppReviewSetUserId).HasColumnName("SuppReviewSetUserID");

                entity.Property(e => e.SupplementalClaimTypeId).HasColumnName("SupplementalClaimTypeID");

                entity.Property(e => e.SuspendDate).HasColumnType("datetime");

                entity.Property(e => e.Taldate)
                    .HasColumnName("TALDate")
                    .HasColumnType("date");

                entity.Property(e => e.TitleExtensionDate).HasColumnType("date");

                entity.Property(e => e.TitleSubmitAnalystId).HasColumnName("TitleSubmitAnalystID");

                entity.Property(e => e.TitleSubmitDate).HasColumnType("datetime");

                entity.Property(e => e.UnpaidBalance).HasColumnType("money");

                entity.HasOne(d => d.Claim)
                    .WithMany(p => p.TblInvestorTrackingClaimsFhaclaim)
                    .HasForeignKey(d => d.ClaimId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tblInvestorTracking_Claims_FHAClaim_tblInvestorTracking_Claims");

                entity.HasOne(d => d.SuppParentFhaclaim)
                    .WithMany(p => p.InverseSuppParentFhaclaim)
                    .HasForeignKey(d => d.SuppParentFhaclaimId)
                    .HasConstraintName("FK2_tblInvestorTracking_Claims_FHAClaim_tblInvestorTracking_Claims_FHAClaim");
            });

            modelBuilder.Entity<TblInvestorTrackingClaimsVaclaim>(entity =>
            {
                entity.HasKey(e => e.VaclaimId);

                entity.ToTable("tblInvestorTracking_Claims_VAClaim");

                entity.HasComment("Contains VA claims Investor Tracking information.");

                entity.HasIndex(e => e.ClaimId)
                    .HasName("idx_tblInvestorTracking_Claims_VAClaim_ClaimID");

                entity.Property(e => e.VaclaimId).HasColumnName("VAClaimID");

                entity.Property(e => e.Claim3rdPartyProceedsRecievedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.ClaimAmount).HasColumnType("money");

                entity.Property(e => e.ClaimId).HasColumnName("ClaimID");

                entity.Property(e => e.ClaimNoBillDate).HasColumnType("datetime");

                entity.Property(e => e.ClaimPaidAmount)
                    .HasColumnType("money")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.ClaimPaidDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.ClaimPrepDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.ClaimPrepId)
                    .HasColumnName("ClaimPrepID")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.ClaimResubmitDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.ClaimResubmitProcessorId)
                    .HasColumnName("ClaimResubmitProcessorID")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.ClaimSubmitDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.ClaimSubmitProcessorId)
                    .HasColumnName("ClaimSubmitProcessorID")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.InvestorClaimAmount)
                    .HasColumnType("money")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.InvestorClaimDue).HasDefaultValueSql("((0))");

                entity.Property(e => e.InvestorClaimFiledDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.InvestorClaimNoBillDate).HasColumnType("datetime");

                entity.Property(e => e.InvestorClaimOutcomeChangeDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.PrepDueDate).HasColumnType("datetime");

                entity.Property(e => e.SupplementalAmount).HasColumnType("money");

                entity.Property(e => e.SupplementalClaimDue).HasDefaultValueSql("((0))");

                entity.Property(e => e.SupplementalDeniedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.SupplementalFiledDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.SupplementalFiledProcessorId)
                    .HasColumnName("SupplementalFiledProcessorID")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.SupplementalNoBillDate).HasColumnType("datetime");

                entity.Property(e => e.SupplementalPaidAmount)
                    .HasColumnType("money")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.SupplementalPaidDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.TerminationDate).HasColumnType("datetime");

                entity.Property(e => e.TitlePkgExtensionDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.TitlePkgExtensionProcessorId)
                    .HasColumnName("TitlePkgExtensionProcessorID")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.TitlePkgNoBillDate).HasColumnType("datetime");

                entity.Property(e => e.TitlePkgRefundPkgSubmitDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.TitlePkgSubmitDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.TitlePkgSubmitProcessorId)
                    .HasColumnName("TitlePkgSubmitProcessorID")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Tocamount)
                    .HasColumnName("TOCAmount")
                    .HasColumnType("money");

                entity.Property(e => e.TocfiledDate)
                    .HasColumnName("TOCFiledDate")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.TocfiledProcessorId)
                    .HasColumnName("TOCFiledProcessorID")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.TocnoBill).HasColumnName("TOCNoBill");

                entity.Property(e => e.TocnoBillBy).HasColumnName("TOCNoBillBy");

                entity.Property(e => e.TocnoBillDate)
                    .HasColumnName("TOCNoBillDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.TocpaidAmount)
                    .HasColumnName("TOCPaidAmount")
                    .HasColumnType("money")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.TocpaidDate)
                    .HasColumnName("TOCPaidDate")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.TocresubmitDate)
                    .HasColumnName("TOCResubmitDate")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.TocresubmitProcessorId)
                    .HasColumnName("TOCResubmitProcessorID")
                    .HasDefaultValueSql("((0))");

                entity.HasOne(d => d.Claim)
                    .WithMany(p => p.TblInvestorTrackingClaimsVaclaim)
                    .HasForeignKey(d => d.ClaimId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tblInvestorTracking_Claims_VAClaim_tblInvestorTracking_Claims");
            });

            modelBuilder.Entity<TblInvestorTrackingLoans>(entity =>
            {
                entity.ToTable("tblInvestorTracking_Loans");

                entity.HasComment("Contains loan information.");

                entity.HasIndex(e => e.ClientId)
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K3");

                entity.HasIndex(e => e.Id)
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K1");

                entity.HasIndex(e => e.InvestorName)
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K16");

                entity.HasIndex(e => new { e.ClientId, e.Id })
                    .HasName("_dta_stat_987150562_3_1");

                entity.HasIndex(e => new { e.ClientId, e.InvestorName })
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K3_K16");

                entity.HasIndex(e => new { e.InvestorLoanNumber, e.Id })
                    .HasName("idxtblInvestorTracking_Loans_InvestorLoanNumber");

                entity.HasIndex(e => new { e.InvestorName, e.Id })
                    .HasName("_dta_stat_987150562_16_1");

                entity.HasIndex(e => new { e.LoanNumber, e.Id })
                    .HasName("idxtblInvestorTracking_Loans_LoanNumber");

                entity.HasIndex(e => new { e.ClientId, e.Id, e.PropertyState })
                    .HasName("idx_tblInvestorTracking_Loans_PropertyState");

                entity.HasIndex(e => new { e.ClientId, e.InvestorName, e.Id })
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K3_K16_K1");

                entity.HasIndex(e => new { e.Id, e.ClientId, e.InvestorName })
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K1_K3_K16");

                entity.HasIndex(e => new { e.Id, e.ClientId, e.MicompanyId })
                    .HasName("_dta_stat_987150562_1_3_17");

                entity.HasIndex(e => new { e.InvestorName, e.ClientId, e.Id })
                    .HasName("_dta_stat_987150562_16_3_1");

                entity.HasIndex(e => new { e.InvestorName, e.Id, e.ClientId })
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K16_K1_K3");

                entity.HasIndex(e => new { e.LoanNumber, e.InvestorLoanNumber, e.Id })
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K1_2_21");

                entity.HasIndex(e => new { e.ClientId, e.Id, e.LoanNumber, e.InvestorName })
                    .HasName("idx_tblInvestorTracking_Loans_InvestorName");

                entity.HasIndex(e => new { e.Id, e.LoanNumber, e.FhacaseNumber, e.ClientId })
                    .HasName("tblInvestorTracking_Loans_ClientID");

                entity.HasIndex(e => new { e.ClaimGroupId, e.Id, e.LoanNumber, e.ClientId, e.InvestorName })
                    .HasName("idx_tblInvestorTracking_Loans_ClientID_InvestorName");

                entity.HasIndex(e => new { e.Id, e.InvestorName, e.LoanNumber, e.MicertNumber, e.MicompanyId, e.PoolCertNumber, e.PoolCompany, e.ClientId })
                    .HasName("idx_tblInvestorTracking_Loans_ClientID_2");

                entity.HasIndex(e => new { e.FhacaseNumber, e.Id, e.InvestorLoanNumber, e.InvestorName, e.LoanNumber, e.MicompanyId, e.PoolCompany, e.VacaseNumber, e.ClientId })
                    .HasName("idx_tblInvestorTracking_Loans_ClientID");

                entity.HasIndex(e => new { e.LoanNumber, e.ClientId, e.PropertyState, e.InvestorName, e.InvestorLoanNumber, e.PreForeclosureSettlementDate, e.DeedInLeuRecordDate, e.ForeclosureSaleDate, e.ReosaleDate, e.ThirdPartySaleDate, e.Id })
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K1_2_3_6_16_21_23_24_26_27_35");

                entity.HasIndex(e => new { e.LoanNumber, e.PropertyState, e.InvestorLoanNumber, e.PreForeclosureSettlementDate, e.DeedInLeuRecordDate, e.ForeclosureSaleDate, e.ReosaleDate, e.ThirdPartySaleDate, e.ClientId, e.Id, e.InvestorName })
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K3_K1_K16_2_6_21_23_24_26_27_35");

                entity.HasIndex(e => new { e.LoanNumber, e.PropertyState, e.InvestorLoanNumber, e.PreForeclosureSettlementDate, e.DeedInLeuRecordDate, e.ForeclosureSaleDate, e.ReosaleDate, e.ThirdPartySaleDate, e.ClientId, e.InvestorName, e.Id })
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K3_K16_K1_2_6_21_23_24_26_27_35");

                entity.HasIndex(e => new { e.LoanNumber, e.PropertyState, e.InvestorLoanNumber, e.PreForeclosureSettlementDate, e.DeedInLeuRecordDate, e.ForeclosureSaleDate, e.ReosaleDate, e.ThirdPartySaleDate, e.Id, e.ClientId, e.InvestorName })
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K1_K3_K16_2_6_21_23_24_26_27_35");

                entity.HasIndex(e => new { e.LoanNumber, e.PropertyState, e.InvestorLoanNumber, e.PreForeclosureSettlementDate, e.DeedInLeuRecordDate, e.ForeclosureSaleDate, e.ReosaleDate, e.ThirdPartySaleDate, e.InvestorName, e.ClientId, e.Id })
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K16_K3_K1_2_6_21_23_24_26_27_35");

                entity.HasIndex(e => new { e.LoanNumber, e.ClientId, e.InvestorLoanNumber, e.PreForeclosureSettlementDate, e.DeedInLeuRecordDate, e.ForeclosureSaleDate, e.ReosaleDate, e.Rrcdate, e.ThirdPartySaleDate, e.DateEntered, e.LiquidationDate, e.InvestorName, e.Id })
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K16_K1_2_3_21_23_24_26_27_28_35_38_49");

                entity.HasIndex(e => new { e.LoanNumber, e.InvestorLoanNumber, e.PreForeclosureSettlementDate, e.DeedInLeuRecordDate, e.ForeclosureSaleDate, e.ReosaleDate, e.Rrcdate, e.ThirdPartySaleDate, e.DateEntered, e.LiquidationDate, e.ClientId, e.Id, e.InvestorName })
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K3_K1_K16_2_21_23_24_26_27_28_35_38_49");

                entity.HasIndex(e => new { e.LoanNumber, e.InvestorLoanNumber, e.PreForeclosureSettlementDate, e.DeedInLeuRecordDate, e.ForeclosureSaleDate, e.ReosaleDate, e.Rrcdate, e.ThirdPartySaleDate, e.DateEntered, e.LiquidationDate, e.ClientId, e.InvestorName, e.Id })
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K3_K16_K1_2_21_23_24_26_27_28_35_38_49");

                entity.HasIndex(e => new { e.LoanNumber, e.InvestorLoanNumber, e.PreForeclosureSettlementDate, e.DeedInLeuRecordDate, e.ForeclosureSaleDate, e.ReosaleDate, e.Rrcdate, e.ThirdPartySaleDate, e.DateEntered, e.LiquidationDate, e.Id, e.ClientId, e.InvestorName })
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K1_K3_K16_2_21_23_24_26_27_28_35_38_49");

                entity.HasIndex(e => new { e.LoanNumber, e.InvestorLoanNumber, e.PreForeclosureSettlementDate, e.DeedInLeuRecordDate, e.ForeclosureSaleDate, e.ReosaleDate, e.Rrcdate, e.ThirdPartySaleDate, e.DateEntered, e.LiquidationDate, e.InvestorName, e.ClientId, e.Id })
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K16_K3_K1_2_21_23_24_26_27_28_35_38_49");

                entity.HasIndex(e => new { e.LoanNumber, e.InvestorLoanNumber, e.PreForeclosureSettlementDate, e.DeedInLeuRecordDate, e.ForeclosureSaleDate, e.ReosaleDate, e.Rrcdate, e.ThirdPartySaleDate, e.DateEntered, e.LiquidationDate, e.InvestorName, e.Id, e.ClientId })
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K16_K1_K3_2_21_23_24_26_27_28_35_38_49");

                entity.HasIndex(e => new { e.LoanNumber, e.PropertyState, e.InvestorLoanNumber, e.PreForeclosureSettlementDate, e.DeedInLeuRecordDate, e.ForeclosureSaleDate, e.ReosaleDate, e.Rrcdate, e.ThirdPartySaleDate, e.DateEntered, e.LiquidationDate, e.ClientId, e.InvestorName, e.Id })
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K3_K16_K1_2_6_21_23_24_26_27_28_35_38_49");

                entity.HasIndex(e => new { e.ClientId, e.PropertyState, e.InvestorName, e.MicompanyId, e.InvestorLoanNumber, e.PreForeclosureSettlementDate, e.DeedInLeuRecordDate, e.ForeclosureSaleDate, e.ReosaleDate, e.Rrcdate, e.MicertNumber, e.PoolCompany, e.PoolCertNumber, e.ThirdPartySaleDate, e.DateEntered, e.LoanNumber })
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K2_3_6_16_17_21_23_24_26_27_28_30_32_33_35_38");

                entity.HasIndex(e => new { e.ClientId, e.PropertyState, e.InvestorName, e.MicompanyId, e.InvestorLoanNumber, e.PreForeclosureSettlementDate, e.DeedInLeuRecordDate, e.ForeclosureSaleDate, e.ReosaleDate, e.Rrcdate, e.MicertNumber, e.PoolCompany, e.PoolCertNumber, e.ThirdPartySaleDate, e.DateEntered, e.LoanNumber, e.Id })
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K2_K1_3_6_16_17_21_23_24_26_27_28_30_32_33_35_38");

                entity.HasIndex(e => new { e.LoanNumber, e.PropertyState, e.InvestorName, e.InvestorLoanNumber, e.PreForeclosureSettlementDate, e.DeedInLeuRecordDate, e.ForeclosureSaleDate, e.ReosaleDate, e.Rrcdate, e.MicertNumber, e.PoolCompany, e.PoolCertNumber, e.ThirdPartySaleDate, e.DateEntered, e.ClientId, e.Id, e.MicompanyId })
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K3_K1_K17_2_6_16_21_23_24_26_27_28_30_32_33_35_38");

                entity.HasIndex(e => new { e.LoanNumber, e.PropertyState, e.InvestorName, e.InvestorLoanNumber, e.PreForeclosureSettlementDate, e.DeedInLeuRecordDate, e.ForeclosureSaleDate, e.ReosaleDate, e.Rrcdate, e.MicertNumber, e.PoolCompany, e.PoolCertNumber, e.ThirdPartySaleDate, e.DateEntered, e.Id, e.ClientId, e.MicompanyId })
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K1_K3_K17_2_6_16_21_23_24_26_27_28_30_32_33_35_38");

                entity.HasIndex(e => new { e.LoanNumber, e.PropertyState, e.MicompanyId, e.InvestorLoanNumber, e.PreForeclosureSettlementDate, e.DeedInLeuRecordDate, e.ForeclosureSaleDate, e.ReosaleDate, e.Rrcdate, e.MicertNumber, e.PoolCompany, e.PoolCertNumber, e.ThirdPartySaleDate, e.DateEntered, e.LiquidationDate, e.ClientId, e.InvestorName, e.Id })
                    .HasName("_dta_index_tblInvestorTracking_Loans_6_987150562__K3_K16_K1_2_6_17_21_23_24_26_27_28_30_32_33_35_38_49");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.AcquisitionLoanSetByUserId).HasColumnName("AcquisitionLoanSetByUserID");

                entity.Property(e => e.AquisitionLoanSetDate).HasColumnType("datetime");

                entity.Property(e => e.AquisitionLoanSetOnClaimId).HasColumnName("AquisitionLoanSetOnClaimID");

                entity.Property(e => e.AttorneyName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasComment("The name of the foreclosure attorney");

                entity.Property(e => e.BorrowerFirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BorrowerLastName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimGroupId).HasColumnName("ClaimGroupID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.ClientUniqueId)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CmaxClientId)
                    .HasColumnName("CMaxClientID")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.DateEntered)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DeedInLeuRecordDate).HasColumnType("smalldatetime");

                entity.Property(e => e.EvictionAttorney)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FhacaseNumber)
                    .HasColumnName("FHACaseNumber")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.ForeClosureDate).HasColumnType("datetime");

                entity.Property(e => e.ForeclosureSaleDate)
                    .HasColumnType("smalldatetime")
                    .HasComment("The date of the foreclosure sale");

                entity.Property(e => e.ForeclosureTypeId)
                    .HasColumnName("ForeclosureTypeID")
                    .HasComment("The type of foreclosure (Judicial, Non Judicial)");

                entity.Property(e => e.Gadate)
                    .HasColumnName("GADate")
                    .HasColumnType("datetime");

                entity.Property(e => e.InternalFormId).HasColumnName("InternalFormID");

                entity.Property(e => e.InvestorId)
                    .HasColumnName("InvestorID")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.InvestorLoanNumber)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.InvestorName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.IsAcquisitionLoan).HasDefaultValueSql("((0))");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LiquidationDate).HasColumnType("datetime");

                entity.Property(e => e.LoanNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.MarketingExpirationDate).HasColumnType("datetime");

                entity.Property(e => e.MicertNumber)
                    .HasColumnName("MICertNumber")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.MicompanyId).HasColumnName("MICompanyID");

                entity.Property(e => e.MifiledDate)
                    .HasColumnName("MIFiledDate")
                    .HasColumnType("smalldatetime");

                entity.Property(e => e.MiguarantyNumber)
                    .HasColumnName("MIGuarantyNumber")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.NonLiquidationDate).HasColumnType("datetime");

                entity.Property(e => e.NplsaleDate)
                    .HasColumnName("NPLSaleDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.OldLoanNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PandPcompany)
                    .HasColumnName("PandPCompany")
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasComment("The name of the P&P Company");

                entity.Property(e => e.Pccdate)
                    .HasColumnName("PCCDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.PoolCertNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PoolCompany)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.PoolFiledDate).HasColumnType("smalldatetime");

                entity.Property(e => e.PreForeclosureSettlementDate)
                    .HasColumnType("smalldatetime")
                    .HasComment("The date of the settlement of the pre foreclosure sale");

                entity.Property(e => e.PropertyAcquisitionDate).HasColumnType("datetime");

                entity.Property(e => e.PropertyAddress)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyState)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.PropertyZip)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.ReferDateToMi)
                    .HasColumnName("ReferDateToMI")
                    .HasColumnType("datetime");

                entity.Property(e => e.RefundingDate).HasColumnType("datetime");

                entity.Property(e => e.ReosaleDate)
                    .HasColumnName("REOSaleDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.RplsaleDate)
                    .HasColumnName("RPLSaleDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.Rrcdate)
                    .HasColumnName("RRCDate")
                    .HasColumnType("datetime")
                    .HasComment("The date on which the redemption, ratification, confirmation period ended");

                entity.Property(e => e.SellerServicerNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerAddress)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerState)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.ServicerZip)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.ThirdPartySaleDate)
                    .HasColumnType("smalldatetime")
                    .HasComment("The date of the third party sale");

                entity.Property(e => e.TitleCompany)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasComment("The name of the title company");

                entity.Property(e => e.VacaseNumber)
                    .HasColumnName("VACaseNumber")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblInvestorTrackingLoansNotes>(entity =>
            {
                entity.ToTable("tblInvestorTracking_Loans_Notes");

                entity.HasComment("Contains comments about loans.");

                entity.HasIndex(e => e.LoanId)
                    .HasName("idx_tblInvestorTracking_Loans_Notes_LoanID");

                entity.HasIndex(e => new { e.EnteredByUser, e.LoanId })
                    .HasName("_dta_index_tblInvestorTracking_Loans_Notes_6_1291151645__K6_K2");

                entity.HasIndex(e => new { e.LoanCommentTypeId, e.LoanId })
                    .HasName("_dta_index_tblInvestorTracking_Loans_Notes_6_1291151645__K3_K2");

                entity.HasIndex(e => new { e.LoanId, e.DateEntered })
                    .HasName("_dta_stat_1291151645_2_5");

                entity.HasIndex(e => new { e.LoanId, e.EnteredByUser })
                    .HasName("_dta_index_tblInvestorTracking_Loans_Notes_6_1291151645__K2_K6");

                entity.HasIndex(e => new { e.LoanId, e.LoanCommentTypeId })
                    .HasName("_dta_stat_1291151645_2_3");

                entity.HasIndex(e => new { e.LoanComment, e.LoanId, e.DateEntered })
                    .HasName("_dta_index_tblInvestorTracking_Loans_Notes_6_1291151645__K2_K5_4");

                entity.HasIndex(e => new { e.LoanCommentTypeId, e.EnteredByUser, e.LoanId })
                    .HasName("_dta_stat_1291151645_3_6_2");

                entity.HasIndex(e => new { e.LoanId, e.LoanComment, e.DateEntered })
                    .HasName("_dta_index_tblInvestorTracking_Loans_Notes_6_1291151645__K5D_2_4");

                entity.HasIndex(e => new { e.Id, e.LoanComment, e.DateEntered, e.EnteredByUser, e.LoanCommentTypeId, e.LoanId })
                    .HasName("_dta_index_tblInvestorTracking_Loans_Notes_6_1291151645__K3_K2_1_4_5_6");

                entity.HasIndex(e => new { e.Id, e.LoanComment, e.DateEntered, e.EnteredByUser, e.LoanId, e.LoanCommentTypeId })
                    .HasName("_dta_index_tblInvestorTracking_Loans_Notes_6_1291151645__K6_K2_K3_1_4_5");

                entity.HasIndex(e => new { e.Id, e.LoanComment, e.DateEntered, e.LoanCommentTypeId, e.EnteredByUser, e.LoanId })
                    .HasName("_dta_index_tblInvestorTracking_Loans_Notes_6_1291151645__K3_K6_K2_1_4_5");

                entity.HasIndex(e => new { e.Id, e.LoanComment, e.DateEntered, e.LoanCommentTypeId, e.LoanId, e.EnteredByUser })
                    .HasName("_dta_index_tblInvestorTracking_Loans_Notes_6_1291151645__K3_K2_K6_1_4_5");

                entity.HasIndex(e => new { e.Id, e.LoanComment, e.DateEntered, e.LoanId, e.EnteredByUser, e.LoanCommentTypeId })
                    .HasName("_dta_index_tblInvestorTracking_Loans_Notes_6_1291151645__K2_K6_K3_1_4_5");

                entity.HasIndex(e => new { e.Id, e.LoanComment, e.DateEntered, e.LoanId, e.LoanCommentTypeId, e.EnteredByUser })
                    .HasName("_dta_index_tblInvestorTracking_Loans_Notes_6_1291151645__K2_K3_K6_1_4_5");

                entity.HasIndex(e => new { e.Id, e.LoanCommentTypeId, e.LoanComment, e.EnteredByUser, e.LoanId, e.DateEntered })
                    .HasName("_dta_index_tblInvestorTracking_Loans_Notes_6_1291151645__K2_K5_1_3_4_6");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.DateEntered)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LoanComment)
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.LoanCommentTypeId).HasColumnName("LoanCommentTypeID");

                entity.Property(e => e.LoanId).HasColumnName("LoanID");
            });

            modelBuilder.Entity<TblSubmitActions>(entity =>
            {
                entity.HasKey(e => e.ActionId)
                    .HasName("PK__tbl_Subm__FFE3F4B96832E948");

                entity.ToTable("tbl_SubmitActions");

                entity.Property(e => e.ActionId).HasColumnName("ActionID");

                entity.Property(e => e.ActionDateTime).HasColumnType("datetime");

                entity.Property(e => e.ActionDetails)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.ActionLoginId)
                    .IsRequired()
                    .HasColumnName("ActionLoginID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ActionSummary)
                    .IsRequired()
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.ActionUserId).HasColumnName("ActionUserID");

                entity.Property(e => e.CmsclaimId).HasColumnName("CMSClaimID");

                entity.HasOne(d => d.Cmsclaim)
                    .WithMany(p => p.TblSubmitActions)
                    .HasForeignKey(d => d.CmsclaimId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tbl_SubmitActions_tblInvestorTracking_Claims");
            });

            modelBuilder.Entity<TbllkpClaimTypesByForm>(entity =>
            {
                entity.ToTable("tbllkp_ClaimTypesByForm");

                entity.HasComment("Look-up table. Contains information for claim types by form.");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ClaimType)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DateEntered)
                    .HasColumnType("smalldatetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.FormId).HasColumnName("FormID");
            });

            modelBuilder.Entity<TbllkpForms>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("tbllkp_Forms");

                entity.HasComment("Look-up table. Contains names, entered dates and effective date ranges for forms.");

                entity.Property(e => e.DateEntered)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EffectiveFromDate)
                    .HasColumnType("smalldatetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.EffectiveToDate)
                    .HasColumnType("smalldatetime")
                    .HasDefaultValueSql("('12/31/2078')");

                entity.Property(e => e.FormName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.PrimaryFormId).HasColumnName("PrimaryFormID");
            });

            modelBuilder.Entity<TbllkpFormsComboBoxValues>(entity =>
            {
                entity.ToTable("tbllkp_Forms_ComboBoxValues");

                entity.HasComment("Look-up table. Contains information for combo box type tags and text.");

                entity.HasIndex(e => new { e.FormId, e.ComboBoxTypeTag, e.ComboBoxText })
                    .HasName("idx_tbllkp_Forms_ComboBoxValues_FormID_TypeTag_Text")
                    .IsUnique();

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.ComboBoxText)
                    .IsRequired()
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.ComboBoxTypeTag)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DateEntered)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EffectiveFromDate)
                    .HasColumnType("smalldatetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.EffectiveToDate)
                    .HasColumnType("smalldatetime")
                    .HasDefaultValueSql("('12/31/2078')");

                entity.Property(e => e.FormId).HasColumnName("FormID");

                entity.Property(e => e.ToolTip)
                    .HasMaxLength(500)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbllkpMicompanies>(entity =>
            {
                entity.ToTable("tbllkp_MICompanies");

                entity.HasComment("Look-up table. Contains MI Company Names, CMAX MI Names, and CMAX MI Codes.");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.CmaxMiCode)
                    .HasColumnName("CMAX_MI_Code")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.CmaxMiName)
                    .HasColumnName("CMAX_MI_Name")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DateEntered)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.MicompanyName)
                    .IsRequired()
                    .HasColumnName("MICompanyName")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbllkpSecurityGroups>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("tbllkp_Security_Groups");

                entity.HasComment("Look-up table. Contains name and level of security groups.");

                entity.Property(e => e.DateEntered)
                    .HasColumnType("smalldatetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.SecurityGroup)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwApplicationConfigurationCMSUsers>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_ApplicationConfigurationUsers");

                entity.Property(e => e.DateEntered).HasColumnType("datetime");

                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.LastPwchange)
                    .HasColumnName("LastPWChange")
                    .HasColumnType("datetime");

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.PhoneNum)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.SecurityGroupId).HasColumnName("SecurityGroupID");

                entity.Property(e => e.UserEmailAddress)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UserId)
                    .IsRequired()
                    .HasColumnName("UserID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<XrefInvTrkClaimGroupClaimType>(entity =>
            {
                entity.HasKey(e => e.ClaimGroupClaimTypeId);

                entity.ToTable("xref_InvTrk_ClaimGroupClaimType");

                entity.HasComment("Cross ref table. Contains claim group ID and claim type ID.");

                entity.HasIndex(e => e.ClaimTypeId)
                    .HasName("UK1_ClaimGroupID_ClaimTypeID")
                    .IsUnique();

                entity.Property(e => e.ClaimGroupClaimTypeId).HasColumnName("ClaimGroupClaimTypeID");

                entity.Property(e => e.ClaimGroupId).HasColumnName("ClaimGroupID");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.HasOne(d => d.ClaimGroup)
                    .WithMany(p => p.XrefInvTrkClaimGroupClaimType)
                    .HasForeignKey(d => d.ClaimGroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_InvTrk_ClaimGroupClaimType_lkp_InvTrk_ClaimGroups");

                entity.HasOne(d => d.ClaimType)
                    .WithOne(p => p.XrefInvTrkClaimGroupClaimType)
                    .HasForeignKey<XrefInvTrkClaimGroupClaimType>(d => d.ClaimTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_InvTrk_ClaimGroupClaimType_tbllkp_ClaimTypesByForm");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
