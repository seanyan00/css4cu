﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblInvestorTrackingLoansNotes
    {
        public int Id { get; set; }
        public int LoanId { get; set; }
        public int LoanCommentTypeId { get; set; }
        public string LoanComment { get; set; }
        public DateTime DateEntered { get; set; }
        public int? EnteredByUser { get; set; }
    }
}
