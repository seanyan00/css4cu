﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TbllkpMicompanies
    {
        public int Id { get; set; }
        public string MicompanyName { get; set; }
        public DateTime DateEntered { get; set; }
        public string CmaxMiName { get; set; }
        public string CmaxMiCode { get; set; }
    }
}
