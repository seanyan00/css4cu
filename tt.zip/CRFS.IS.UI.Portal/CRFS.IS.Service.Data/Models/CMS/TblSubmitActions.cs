﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblSubmitActions
    {
        public long ActionId { get; set; }
        public int CmsclaimId { get; set; }
        public string ActionSummary { get; set; }
        public string ActionDetails { get; set; }
        public int? ActionUserId { get; set; }
        public string ActionLoginId { get; set; }
        public DateTime ActionDateTime { get; set; }

        public virtual TblInvestorTrackingClaims Cmsclaim { get; set; }
    }
}
