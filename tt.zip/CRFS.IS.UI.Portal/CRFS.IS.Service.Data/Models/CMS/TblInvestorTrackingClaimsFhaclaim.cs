﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblInvestorTrackingClaimsFhaclaim
    {
        public TblInvestorTrackingClaimsFhaclaim()
        {
            InverseSuppParentFhaclaim = new HashSet<TblInvestorTrackingClaimsFhaclaim>();
        }

        public int FhaclaimId { get; set; }
        public int ClaimId { get; set; }
        public int? SuppParentFhaclaimId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUser { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUser { get; set; }
        public decimal? ClaimAmount { get; set; }
        public decimal? ConvPartAclaimAmount { get; set; }
        public DateTime? ClearMarketableTitleDate { get; set; }
        public DateTime? ConveyanceExtensionExpirationDate { get; set; }
        public int? CurtailmentCodeId { get; set; }
        public DateTime? CurtailmentDate { get; set; }
        public DateTime? FhamodificationDate { get; set; }
        public decimal? ExpectedPartBproceeds { get; set; }
        public DateTime? FcldeedRecordedDate { get; set; }
        public DateTime? FclfirstLegalDate { get; set; }
        public DateTime? Ftvdate { get; set; }
        public DateTime? HuddeedRecordedDate { get; set; }
        public DateTime? Hudiddate { get; set; }
        public DateTime? Iccdate { get; set; }
        public DateTime? IccreportDate { get; set; }
        public DateTime? IneligibilityDate { get; set; }
        public int? IneligibilityReasonId { get; set; }
        public bool IsHamp { get; set; }
        public bool IsInvestorClaimDue { get; set; }
        public bool IsMobileHomeTrailer { get; set; }
        public DateTime? MhtendDate { get; set; }
        public DateTime? MhtreviewedDate { get; set; }
        public DateTime? MhtstartDate { get; set; }
        public decimal? PaidAmount { get; set; }
        public decimal? ConvPartApaidAmount { get; set; }
        public DateTime? RecorderLetterReceiveDate { get; set; }
        public DateTime? RecordingInstructionsSentDate { get; set; }
        public DateTime? RecorderLetterVerified { get; set; }
        public int? RecorderLetterVerifiedUser { get; set; }
        public DateTime? FtvdateReported { get; set; }
        public DateTime? ReviewedForInvestorClaim { get; set; }
        public DateTime? ServiceTransferDate { get; set; }
        public DateTime? SettlementDate { get; set; }
        public DateTime? ConvPartAsettlementDate { get; set; }
        public bool SuppRecoveryDue { get; set; }
        public bool SuppRefundDueHud { get; set; }
        public DateTime? SuspendDate { get; set; }
        public DateTime? ConvPartAsuspendDate { get; set; }
        public DateTime? Taldate { get; set; }
        public DateTime? TitleExtensionDate { get; set; }
        public int? TitleSubmitAnalystId { get; set; }
        public DateTime? TitleSubmitDate { get; set; }
        public decimal? UnpaidBalance { get; set; }
        public int? ClaimSubmittedAnalystId { get; set; }
        public int? ConvPartAsubmittedAnalystId { get; set; }
        public DateTime? ClaimSubmittedDate { get; set; }
        public DateTime? ConvPartAsubmittedDate { get; set; }
        public DateTime? ClientSystemUpdatedDate { get; set; }
        public DateTime? ConvPartAclientSystemUpdatedDate { get; set; }
        public int? ClientSystemUpdatedUser { get; set; }
        public int? ConvPartAclientSystemUpdatedUser { get; set; }
        public DateTime? EdiauthorizedDate { get; set; }
        public DateTime? ConvEdiauthorizedDate { get; set; }
        public int? EdiauthorizedUserId { get; set; }
        public int? ConvEdiauthorizedUserId { get; set; }
        public DateTime? ErrorSubmitDate { get; set; }
        public DateTime? ConvPartAerrorSubmitDate { get; set; }
        public bool IsEdiauthorized { get; set; }
        public bool ConvPartAisEdiauthorized { get; set; }
        public int? PartAanalyst { get; set; }
        public DateTime? PartAcompleteDate { get; set; }
        public int? PartBanalyst { get; set; }
        public DateTime? PartBcompleteDate { get; set; }
        public int? PartAqcanalyst { get; set; }
        public DateTime? PartAqccompleteDate { get; set; }
        public int? PartBqcanalyst { get; set; }
        public DateTime? PartBqccompleteDate { get; set; }
        public int? PrepAnalyst { get; set; }
        public DateTime? PrepCompleteDate { get; set; }
        public int? ConvPartAprepAnalyst { get; set; }
        public DateTime? ConvPartAprepCompleteDate { get; set; }
        public int? PrepReferralAnalyst { get; set; }
        public DateTime? PrepReferralCompleteDate { get; set; }
        public bool ConvPartBonly { get; set; }
        public int? SupplementalClaimTypeId { get; set; }
        public int? ClaimSubTypeId { get; set; }
        public bool? IsSuppReview { get; set; }
        public DateTime? SuppReviewSetDate { get; set; }
        public int? SuppReviewSetUserId { get; set; }
        public DateTime? ClearTitleDate { get; set; }
        public DateTime? MarketableTitleDate { get; set; }

        public virtual TblInvestorTrackingClaims Claim { get; set; }
        public virtual TblInvestorTrackingClaimsFhaclaim SuppParentFhaclaim { get; set; }
        public virtual ICollection<TblInvestorTrackingClaimsFhaclaim> InverseSuppParentFhaclaim { get; set; }
    }
}
