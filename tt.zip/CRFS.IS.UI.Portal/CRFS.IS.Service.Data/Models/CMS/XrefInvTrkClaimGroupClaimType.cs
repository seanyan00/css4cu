﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefInvTrkClaimGroupClaimType
    {
        public int ClaimGroupClaimTypeId { get; set; }
        public int ClaimGroupId { get; set; }
        public int ClaimTypeId { get; set; }

        public virtual LkpInvTrkClaimGroups ClaimGroup { get; set; }
        public virtual TbllkpClaimTypesByForm ClaimType { get; set; }
    }
}
