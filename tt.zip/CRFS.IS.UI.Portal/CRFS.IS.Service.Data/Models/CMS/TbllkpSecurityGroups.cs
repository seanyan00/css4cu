﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TbllkpSecurityGroups
    {
        public int Id { get; set; }
        public string SecurityGroup { get; set; }
        public short? SecurityLevel { get; set; }
        public DateTime DateEntered { get; set; }
    }
}
