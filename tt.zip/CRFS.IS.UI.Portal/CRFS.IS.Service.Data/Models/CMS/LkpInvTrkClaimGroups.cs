﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpInvTrkClaimGroups
    {
        public LkpInvTrkClaimGroups()
        {
            XrefInvTrkClaimGroupClaimType = new HashSet<XrefInvTrkClaimGroupClaimType>();
        }

        public int ClaimGroupId { get; set; }
        public string ClaimGroupName { get; set; }
        public bool IsActiveClaimGroup { get; set; }
        public DateTime EnteredDate { get; set; }

        public virtual ICollection<XrefInvTrkClaimGroupClaimType> XrefInvTrkClaimGroupClaimType { get; set; }
    }
}
