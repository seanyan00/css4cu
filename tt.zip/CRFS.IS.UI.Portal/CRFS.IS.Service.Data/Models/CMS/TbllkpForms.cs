﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TbllkpForms
    {
        public int Id { get; set; }
        public string FormName { get; set; }
        public DateTime DateEntered { get; set; }
        public DateTime EffectiveFromDate { get; set; }
        public DateTime EffectiveToDate { get; set; }
        public int PrimaryFormId { get; set; }
    }
}
