﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblInvestorTrackingClaimsVaclaim
    {
        public int VaclaimId { get; set; }
        public int ClaimId { get; set; }
        public DateTime? TocfiledDate { get; set; }
        public int? TocfiledProcessorId { get; set; }
        public DateTime? TocresubmitDate { get; set; }
        public int? TocresubmitProcessorId { get; set; }
        public DateTime? TocpaidDate { get; set; }
        public decimal? TocpaidAmount { get; set; }
        public DateTime? TitlePkgExtensionDate { get; set; }
        public int? TitlePkgExtensionProcessorId { get; set; }
        public DateTime? TitlePkgSubmitDate { get; set; }
        public int? TitlePkgSubmitProcessorId { get; set; }
        public DateTime? TitlePkgRefundPkgSubmitDate { get; set; }
        public DateTime? ClaimPrepDate { get; set; }
        public int? ClaimPrepId { get; set; }
        public DateTime? ClaimSubmitDate { get; set; }
        public int? ClaimSubmitProcessorId { get; set; }
        public DateTime? ClaimResubmitDate { get; set; }
        public int? ClaimResubmitProcessorId { get; set; }
        public DateTime? Claim3rdPartyProceedsRecievedDate { get; set; }
        public DateTime? ClaimPaidDate { get; set; }
        public decimal? ClaimPaidAmount { get; set; }
        public bool? SupplementalClaimDue { get; set; }
        public DateTime? SupplementalFiledDate { get; set; }
        public int? SupplementalFiledProcessorId { get; set; }
        public DateTime? SupplementalPaidDate { get; set; }
        public decimal? SupplementalPaidAmount { get; set; }
        public DateTime? SupplementalDeniedDate { get; set; }
        public bool? InvestorClaimDue { get; set; }
        public DateTime? InvestorClaimFiledDate { get; set; }
        public decimal? InvestorClaimAmount { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUser { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUser { get; set; }
        public decimal? Tocamount { get; set; }
        public decimal? ClaimAmount { get; set; }
        public decimal? SupplementalAmount { get; set; }
        public DateTime? TerminationDate { get; set; }
        public DateTime? PrepDueDate { get; set; }
        public int? InvestorClaimType { get; set; }
        public int? InvestorClaimOutcome { get; set; }
        public int? InvestorClaimOutcomeChangedBy { get; set; }
        public DateTime? InvestorClaimOutcomeChangeDate { get; set; }
        public bool? TocnoBill { get; set; }
        public DateTime? TocnoBillDate { get; set; }
        public int? TocnoBillBy { get; set; }
        public bool? TitlePkgNoBill { get; set; }
        public DateTime? TitlePkgNoBillDate { get; set; }
        public int? TitlePkgNoBillBy { get; set; }
        public bool? ClaimNoBill { get; set; }
        public DateTime? ClaimNoBillDate { get; set; }
        public int? ClaimNoBillBy { get; set; }
        public bool? SupplementalNoBill { get; set; }
        public DateTime? SupplementalNoBillDate { get; set; }
        public int? SupplementalNoBillBy { get; set; }
        public bool? InvestorClaimNoBill { get; set; }
        public DateTime? InvestorClaimNoBillDate { get; set; }
        public int? InvestorClaimNoBillBy { get; set; }
        public int? ClaimSubTypeId { get; set; }

        public virtual TblInvestorTrackingClaims Claim { get; set; }
    }
}
