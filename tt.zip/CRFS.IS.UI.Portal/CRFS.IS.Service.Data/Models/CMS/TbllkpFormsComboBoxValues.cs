﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TbllkpFormsComboBoxValues
    {
        public int Id { get; set; }
        public int FormId { get; set; }
        public string ComboBoxTypeTag { get; set; }
        public string ComboBoxText { get; set; }
        public DateTime DateEntered { get; set; }
        public DateTime EffectiveFromDate { get; set; }
        public DateTime EffectiveToDate { get; set; }
    }
}
