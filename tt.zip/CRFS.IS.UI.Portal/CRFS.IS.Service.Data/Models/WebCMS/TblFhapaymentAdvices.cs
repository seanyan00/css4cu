﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblFhapaymentAdvices
    {
        public TblFhapaymentAdvices()
        {
            TblAopAdjustmentMessages = new HashSet<TblAopAdjustmentMessages>();
            TblAopLineItems = new HashSet<TblAopLineItems>();
        }

        public long PaymentAdviceId { get; set; }
        public long FhaclaimId { get; set; }
        public long AdviceTypeId { get; set; }
        public decimal PaymentAmount { get; set; }
        public long PaymentMethodId { get; set; }
        public DateTime PaymentAdviceDate { get; set; }
        public DateTime SettlementDate { get; set; }
        public DateTime ClaimReceivedDate { get; set; }
        public string ScheduleReferenceNumber { get; set; }
        public long PaymentActionId { get; set; }
        public DateTime EnteredDate { get; set; }
        public DateTime LastUpdateDate { get; set; }

        public virtual TblFhaclaims Fhaclaim { get; set; }
        public virtual ICollection<TblAopAdjustmentMessages> TblAopAdjustmentMessages { get; set; }
        public virtual ICollection<TblAopLineItems> TblAopLineItems { get; set; }
    }
}
