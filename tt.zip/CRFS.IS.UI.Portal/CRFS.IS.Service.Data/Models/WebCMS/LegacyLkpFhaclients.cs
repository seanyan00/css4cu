﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LegacyLkpFhaclients
    {
        public long FhaclientId { get; set; }
        public int? CmsclientId { get; set; }
        public string ClientName { get; set; }
        public bool EnableHudEdi { get; set; }
    }
}
