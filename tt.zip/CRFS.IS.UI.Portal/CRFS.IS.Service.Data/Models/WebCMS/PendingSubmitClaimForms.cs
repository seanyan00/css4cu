﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class PendingSubmitClaimForms
    {
        public long PendingSubmitClaimFormId { get; set; }
        public long FhaclaimId { get; set; }
        public long ClaimEdilogId { get; set; }
        public bool IsComplete { get; set; }
        public DateTime CompletedDate { get; set; }
        public bool MarkedForDelete { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdateUser { get; set; }
        public DateTime LastUpdateDate { get; set; }

        public virtual TblFhaclaimEdilog ClaimEdilog { get; set; }
        public virtual TblFhaclaims Fhaclaim { get; set; }
    }
}
