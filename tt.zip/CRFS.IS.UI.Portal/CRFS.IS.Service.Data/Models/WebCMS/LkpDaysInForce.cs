﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpDaysInForce
    {
        public int DaysInForceId { get; set; }
        public int DaysInForce { get; set; }
        public double CoverageUsed { get; set; }
    }
}
