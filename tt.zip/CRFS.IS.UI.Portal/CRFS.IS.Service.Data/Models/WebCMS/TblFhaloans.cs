﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblFhaloans
    {
        public TblFhaloans()
        {
            TblFhaclaims = new HashSet<TblFhaclaims>();
            TblFhamortgagors = new HashSet<TblFhamortgagors>();
            TblLoanClaimExtendedAttributes = new HashSet<TblLoanClaimExtendedAttributes>();
        }

        public long FhaloanId { get; set; }
        public long FhaclientId { get; set; }
        public string FhacaseNumber { get; set; }
        public long? MortgageeId { get; set; }
        public string MortgageeLoanNumber { get; set; }
        public string MortgageeContactName { get; set; }
        public string MortgageeContactTelephone { get; set; }
        public long? ServicerId { get; set; }
        public string ServicerContactName { get; set; }
        public string ServicerContactTelephone { get; set; }
        public string PropertyAddress1 { get; set; }
        public string PropertyAddress2 { get; set; }
        public string PropertyCity { get; set; }
        public string PropertyStateCode { get; set; }
        public string PropertyZipCode { get; set; }
        public int? InvTrkLoanId { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUser { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUser { get; set; }
        public DateTime? SecondChanceSaleDate { get; set; }
        public decimal? AuthorizedBidAmount { get; set; }
        public decimal? SuccessfulBidAmount { get; set; }

        public virtual TblFhamortgagees Mortgagee { get; set; }
        public virtual TblFhaservicers Servicer { get; set; }
        public virtual ICollection<TblFhaclaims> TblFhaclaims { get; set; }
        public virtual ICollection<TblFhamortgagors> TblFhamortgagors { get; set; }
        public virtual ICollection<TblLoanClaimExtendedAttributes> TblLoanClaimExtendedAttributes { get; set; }
    }
}
