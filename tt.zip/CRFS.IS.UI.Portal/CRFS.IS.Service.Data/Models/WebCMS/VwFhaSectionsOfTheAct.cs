﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaSectionsOfTheAct
    {
        public long SectionOfTheActId { get; set; }
        public string Adpcode { get; set; }
        public string SectionOfTheActCode { get; set; }
        public string SectionOfTheActDescription { get; set; }
    }
}
