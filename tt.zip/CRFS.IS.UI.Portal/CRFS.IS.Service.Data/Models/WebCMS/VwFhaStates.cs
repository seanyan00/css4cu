﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaStates
    {
        public long StateId { get; set; }
        public string StateCode { get; set; }
        public string StateName { get; set; }
    }
}
