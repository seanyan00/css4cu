﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblFhaEdiCutoffs
    {
        public long FhaEdiCutoffId { get; set; }
        public DateTime EdiCutOffDate { get; set; }
    }
}
