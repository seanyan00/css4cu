﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaClients
    {
        public int FhaclientId { get; set; }
        public int CmsclientId { get; set; }
        public string ClientName { get; set; }
        public int? EnableHudEdi { get; set; }
    }
}
