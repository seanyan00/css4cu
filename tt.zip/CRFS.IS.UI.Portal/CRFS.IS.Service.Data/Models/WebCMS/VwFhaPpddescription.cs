﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaPpddescription
    {
        public string Lutext { get; set; }
    }
}
