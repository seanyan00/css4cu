﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblFhaclaimEdilog
    {
        public TblFhaclaimEdilog()
        {
            PendingSubmitClaimForms = new HashSet<PendingSubmitClaimForms>();
            TblFhaclaimSubmitLog = new HashSet<TblFhaclaimSubmitLog>();
        }

        public long ClaimEdilogId { get; set; }
        public long FhaclaimId { get; set; }
        public DateTime? OutboundExtractDate { get; set; }
        public DateTime? OutboundTranslateDate { get; set; }
        public DateTime? OutboundBundleDate { get; set; }
        public DateTime? OutboundTransferDate { get; set; }
        public DateTime? InboundReceiptDate { get; set; }
        public bool MarkedForDelete { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUser { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUser { get; set; }
        public string SubmitPart { get; set; }

        public virtual TblFhaclaims Fhaclaim { get; set; }
        public virtual ICollection<PendingSubmitClaimForms> PendingSubmitClaimForms { get; set; }
        public virtual ICollection<TblFhaclaimSubmitLog> TblFhaclaimSubmitLog { get; set; }
    }
}
