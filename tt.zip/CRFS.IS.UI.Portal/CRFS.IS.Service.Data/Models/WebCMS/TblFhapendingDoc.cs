﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblFhapendingDoc
    {
        public long FhapendingDocId { get; set; }
        public long FharetrievedDocumentTypeId { get; set; }
        public long FhaclientId { get; set; }
        public long? FhaclaimId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public bool Complete { get; set; }
        public bool MarkedForDelete { get; set; }

        public virtual LkpFharetrievedDocumentTypes FharetrievedDocumentType { get; set; }
    }
}
