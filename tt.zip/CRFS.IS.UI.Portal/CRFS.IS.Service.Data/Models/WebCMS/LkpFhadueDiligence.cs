﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpFhadueDiligence
    {
        public int FhadueDiligenceId { get; set; }
        public DateTime EffectiveDateRangeStart { get; set; }
        public DateTime EffectiveDateRangeEnd { get; set; }
        public long StateId { get; set; }
        public string ConveyanceTypeCode { get; set; }
        public int TimeFrameMonths { get; set; }
    }
}
