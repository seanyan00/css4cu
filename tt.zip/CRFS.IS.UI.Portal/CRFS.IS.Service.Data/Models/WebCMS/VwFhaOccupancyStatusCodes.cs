﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaOccupancyStatusCodes
    {
        public long OccupancyStatusId { get; set; }
        public string OccupancyStatusCode { get; set; }
        public string OccupancyStatusDescription { get; set; }
    }
}
