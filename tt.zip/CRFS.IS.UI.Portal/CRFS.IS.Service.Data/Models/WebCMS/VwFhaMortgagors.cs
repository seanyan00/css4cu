﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaMortgagors
    {
        public long FhaclaimId { get; set; }
        public long FhaloanId { get; set; }
        public string MortgagorLastName { get; set; }
        public string MortgagorFirstName { get; set; }
        public long MortgagorId { get; set; }
        public string MortgagorMiddleName { get; set; }
        public string Prefix { get; set; }
        public string Suffix { get; set; }
        public string Ssn { get; set; }
        public bool CoMortgagor { get; set; }
        public bool? NonPersonEntity { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUser { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUser { get; set; }
    }
}
