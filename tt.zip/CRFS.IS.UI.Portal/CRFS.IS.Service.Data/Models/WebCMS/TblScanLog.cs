﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblScanLog
    {
        public int ClaimScanId { get; set; }
        public string FileName { get; set; }
        public string FhacaseNumber { get; set; }
        public DateTime RunDate { get; set; }
        public string Exception { get; set; }
        public int? PartClineCount { get; set; }
        public decimal? PartCpaid { get; set; }
        public decimal? PartCdeb { get; set; }
        public int? Block305LineCount { get; set; }
        public decimal? Block305Paid { get; set; }
        public decimal? Block305Deb { get; set; }
        public int? Block306LineCount { get; set; }
        public decimal? Block306Paid { get; set; }
        public decimal? Block306Deb { get; set; }
        public int? Block307LineCount { get; set; }
        public decimal? Block307Paid { get; set; }
        public decimal? Block307Deb { get; set; }
        public int? Block308LineCount { get; set; }
        public decimal? Block308Paid { get; set; }
        public decimal? Block308Deb { get; set; }
        public int? Block309LineCount { get; set; }
        public decimal? Block309Paid { get; set; }
        public decimal? Block309Deb { get; set; }
        public int? Block310LineCount { get; set; }
        public decimal? Block310Paid { get; set; }
        public decimal? Block310Deb { get; set; }
        public int? Block311LineCount { get; set; }
        public decimal? Block311Paid { get; set; }
        public decimal? Block311Deb { get; set; }
        public int? Block405LineCount { get; set; }
        public decimal? Block405Paid { get; set; }
        public decimal? Block405Deb { get; set; }
        public int? Block406LineCount { get; set; }
        public decimal? Block406Paid { get; set; }
        public decimal? Block406Deb { get; set; }
        public int? Block407LineCount { get; set; }
        public decimal? Block407Paid { get; set; }
        public decimal? Block407Deb { get; set; }
        public int? Block408LineCount { get; set; }
        public decimal? Block408Paid { get; set; }
        public decimal? Block408Deb { get; set; }
        public int? Block409LineCount { get; set; }
        public decimal? Block409Paid { get; set; }
        public decimal? Block409Deb { get; set; }
        public int? Block410LineCount { get; set; }
        public decimal? Block410Paid { get; set; }
        public decimal? Block410Deb { get; set; }
    }
}
