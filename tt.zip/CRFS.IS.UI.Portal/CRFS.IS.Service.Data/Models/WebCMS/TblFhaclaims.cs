﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblFhaclaims
    {
        public TblFhaclaims()
        {
            PendingSubmitClaimForms = new HashSet<PendingSubmitClaimForms>();
            TblDataAutomationFhaDocRetrieveHistories = new HashSet<TblDataAutomationFhaDocRetrieveHistories>();
            TblFhaclaimEdilog = new HashSet<TblFhaclaimEdilog>();
            TblFhaclaimSubmitLog = new HashSet<TblFhaclaimSubmitLog>();
            TblFhaediTransmitAck = new HashSet<TblFhaediTransmitAck>();
            TblFhaediclaimErrors = new HashSet<TblFhaediclaimErrors>();
            TblFhapaymentAdvices = new HashSet<TblFhapaymentAdvices>();
            TblLoanClaimExtendedAttributes = new HashSet<TblLoanClaimExtendedAttributes>();
            TblPendingTaldocument = new HashSet<TblPendingTaldocument>();
        }

        public long FhaclaimId { get; set; }
        public long FhaloanId { get; set; }
        public long ClaimStatusId { get; set; }
        public long ClaimTypeId { get; set; }
        public long? SectionOfTheActId { get; set; }
        public DateTime? DefaultDate { get; set; }
        public DateTime? LoanDate { get; set; }
        public decimal? DebentureInterestRate { get; set; }
        public decimal? NoteRate { get; set; }
        public int? InvTrkClaimId { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUser { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUser { get; set; }
        public DateTime? CurtailDateForDi { get; set; }
        public bool? McdequalCurtailDateForDi { get; set; }
        public long? FhasuppClaimTypeId { get; set; }
        public long? FhasuppClaimParentId { get; set; }
        public long? FhaclaimSubTypeId { get; set; }
        public decimal? ModifiedInterestRate { get; set; }
        public DateTime? NewMaturityDate { get; set; }
        public decimal? LastArmrate { get; set; }

        public virtual TblFhaloans Fhaloan { get; set; }
        public virtual TblPartA27011 TblPartA27011 { get; set; }
        public virtual TblPartB27011 TblPartB27011 { get; set; }
        public virtual TblPartC27011 TblPartC27011 { get; set; }
        public virtual TblPartD27011 TblPartD27011 { get; set; }
        public virtual TblPartE27011 TblPartE27011 { get; set; }
        public virtual ICollection<PendingSubmitClaimForms> PendingSubmitClaimForms { get; set; }
        public virtual ICollection<TblDataAutomationFhaDocRetrieveHistories> TblDataAutomationFhaDocRetrieveHistories { get; set; }
        public virtual ICollection<TblFhaclaimEdilog> TblFhaclaimEdilog { get; set; }
        public virtual ICollection<TblFhaclaimSubmitLog> TblFhaclaimSubmitLog { get; set; }
        public virtual ICollection<TblFhaediTransmitAck> TblFhaediTransmitAck { get; set; }
        public virtual ICollection<TblFhaediclaimErrors> TblFhaediclaimErrors { get; set; }
        public virtual ICollection<TblFhapaymentAdvices> TblFhapaymentAdvices { get; set; }
        public virtual ICollection<TblLoanClaimExtendedAttributes> TblLoanClaimExtendedAttributes { get; set; }
        public virtual ICollection<TblPendingTaldocument> TblPendingTaldocument { get; set; }
    }
}
