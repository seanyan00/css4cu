﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblPartB27011
    {
        public long PartB27011id { get; set; }
        public long FhaclaimId { get; set; }
        public DateTime? DateFormPrepared { get; set; }
        public DateTime? Block105Date { get; set; }
        public DateTime? ExpDateToSubmitTitleEvidence { get; set; }
        public DateTime? CurtailmentDateFromAop { get; set; }
        public DateTime? ExpOfExtToSubmitFiscalData { get; set; }
        public bool? IsSupplemental { get; set; }
        public decimal? Block107aAmount { get; set; }
        public decimal? Block107bAmount { get; set; }
        public decimal? Block108aAmount { get; set; }
        public decimal? Block109aAmount { get; set; }
        public decimal? Block115aAmount { get; set; }
        public decimal? Block116bAmount { get; set; }
        public decimal? Block118aAmount { get; set; }
        public decimal? Wksheet119L1amount { get; set; }
        public decimal? Wksheet119L2amount { get; set; }
        public decimal? Wksheet119L3amount { get; set; }
        public decimal? Block119aAmount { get; set; }
        public decimal? Block119bAmount { get; set; }
        public DateTime? Wksheet121FromDate { get; set; }
        public DateTime? Wksheet121ToDate { get; set; }
        public decimal? Wksheet121Rate { get; set; }
        public decimal? Block121Amount { get; set; }
        public decimal? Block123aAmount { get; set; }
        public decimal? Block123bAmount { get; set; }
        public decimal? Block123cAmount { get; set; }
        public decimal? Block124aAmount { get; set; }
        public decimal? Block124bAmount { get; set; }
        public decimal? Block124cAmount { get; set; }
        public decimal? Block126cAmount { get; set; }
        public string Block132Description { get; set; }
        public decimal? Block132aAmount { get; set; }
        public decimal? Block132bAmount { get; set; }
        public decimal? Block132cAmount { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUser { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUser { get; set; }
        public long? Block108TypeId { get; set; }
        public long? Block105TypeId { get; set; }

        public virtual TblFhaclaims Fhaclaim { get; set; }
    }
}
