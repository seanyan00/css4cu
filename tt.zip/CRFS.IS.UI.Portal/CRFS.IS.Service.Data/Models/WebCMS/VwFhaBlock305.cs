﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaBlock305
    {
        public long Block305Id { get; set; }
        public long PartD27011id { get; set; }
        public int Form27011BlockId { get; set; }
        public DateTime DatePaid { get; set; }
        public string Description { get; set; }
        public decimal AmountPaid { get; set; }
        public decimal? DebentureInterest { get; set; }
        public decimal? DebentureInterestCalc { get; set; }
        public DateTime? CurtailDateForDi { get; set; }
        public decimal? DebentureInterestRate { get; set; }
        public long ClaimTypeId { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUser { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUser { get; set; }
        public bool? Hudapproved { get; set; }
        public bool? CostEstimator { get; set; }
        public int? Quantity { get; set; }
        public long? ActualSqFt { get; set; }
        public string FormDescription { get; set; }
        public int UseDefaultDateForCalc { get; set; }
    }
}
