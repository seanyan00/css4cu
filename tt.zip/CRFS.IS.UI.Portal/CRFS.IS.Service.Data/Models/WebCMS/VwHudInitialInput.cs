﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwHudInitialInput
    {
        public string ClientName { get; set; }
        public int ClientId { get; set; }
        public long FhaclaimId { get; set; }
        public string MortgageeLoanNumber { get; set; }
        public long FhaloanId { get; set; }
        public long FhaclientId { get; set; }
        public string ClaimType { get; set; }
        public long ClaimTypeId { get; set; }
        public string FhacaseNumber { get; set; }
        public string SectionOfTheActCode { get; set; }
        public long? SectionOfTheActId { get; set; }
        public DateTime? EndorsementDate { get; set; }
        public DateTime? DefaultDate { get; set; }
        public DateTime? PartAformPrepared { get; set; }
        public DateTime? PartBformPrepared { get; set; }
        public DateTime? MortgageeReportedCurtailmentDate { get; set; }
        public DateTime? DateOfNoticeToConvey { get; set; }
        public DateTime? FinalSettlementDate { get; set; }
        public DateTime? DebentureStartDate { get; set; }
        public string MortgageeName { get; set; }
        public long? MortgageeId { get; set; }
        public string ServicerName { get; set; }
        public long? ServicerId { get; set; }
        public decimal? OriginalMortgageAmount { get; set; }
        public decimal? UnpaidLoanBalance { get; set; }
        public string PropertyAddress1 { get; set; }
        public string PropertyAddress2 { get; set; }
        public string PropertyCity { get; set; }
        public string PropertyStateCode { get; set; }
        public string PropertyZipCode { get; set; }
        public decimal? DebentureInterestRate { get; set; }
        public DateTime? CurtailDateForDi { get; set; }
        public bool? McdequalCurtailDateForDi { get; set; }
        public decimal? DebentureInterestRateCalc { get; set; }
        public string HoldingMortgageeNumber { get; set; }
        public string ServicingMortageeNumber { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUser { get; set; }
        public decimal? NoteRate { get; set; }
        public string MortgagorFullName { get; set; }
        public DateTime? SecondChanceSaleDate { get; set; }
        public decimal? AuthorizedBidAmount { get; set; }
        public decimal? SuccessfulBidAmount { get; set; }
        public decimal? ModifiedInterestRate { get; set; }
        public DateTime? NewMaturityDate { get; set; }
        public decimal? LastArmrate { get; set; }
    }
}
