﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblPartD27011MultiBlock
    {
        public long MultiBlockId { get; set; }
        public long PartD27011id { get; set; }
        public int Form27011BlockId { get; set; }
        public DateTime DatePaid { get; set; }
        public string Description { get; set; }
        public decimal AmountPaid { get; set; }
        public decimal? DebentureInterest { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUser { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUser { get; set; }
        public bool? Hudapproved { get; set; }
        public bool? CostEstimator { get; set; }
        public int? Quantity { get; set; }
        public long? ActualSqFt { get; set; }

        public virtual LkpForm27011Blocks Form27011Block { get; set; }
        public virtual TblPartD27011 PartD27011 { get; set; }
    }
}
