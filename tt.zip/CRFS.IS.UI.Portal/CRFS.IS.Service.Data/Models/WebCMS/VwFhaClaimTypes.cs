﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaClaimTypes
    {
        public long ClaimTypeId { get; set; }
        public string ClaimTypeCode { get; set; }
        public string ClaimTypeName { get; set; }
    }
}
