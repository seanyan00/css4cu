﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblPendingTaldocument
    {
        public long PendingTaldocumentId { get; set; }
        public long FhaclaimId { get; set; }

        public virtual TblFhaclaims Fhaclaim { get; set; }
    }
}
