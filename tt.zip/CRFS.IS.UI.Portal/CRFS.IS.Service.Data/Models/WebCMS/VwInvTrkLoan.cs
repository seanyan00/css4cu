﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwInvTrkLoan
    {
        public int Id { get; set; }
        public string LoanNumber { get; set; }
        public int ClientId { get; set; }
        public string FhacaseNumber { get; set; }
    }
}
