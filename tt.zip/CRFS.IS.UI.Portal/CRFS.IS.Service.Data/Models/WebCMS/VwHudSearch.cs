﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwHudSearch
    {
        public string FhacaseNumber { get; set; }
        public string MortgageeLoanNumber { get; set; }
        public long FhaclaimId { get; set; }
        public string ClaimType { get; set; }
        public string ClientName { get; set; }
        public string MortgagorFirstName { get; set; }
        public string MortgagorLastName { get; set; }
        public string PropertyAddress1 { get; set; }
        public string PropertyCity { get; set; }
        public string PropertyStateCode { get; set; }
        public string PropertyZipCode { get; set; }
        public long PartA27011id { get; set; }
        public long PartB27011id { get; set; }
        public long PartC27011id { get; set; }
        public long PartD27011id { get; set; }
        public long PartE27011id { get; set; }
        public DateTime? DateFormBprepared { get; set; }
        public int ClientId { get; set; }
        public long FhaloanId { get; set; }
        public long ClaimTypeId { get; set; }
        public string UserId { get; set; }
        public string UserName { get; set; }
        public string ClaimStatus { get; set; }
        public string MortgagorFullName { get; set; }
        public string SuppClaimType { get; set; }
        public long? FhasuppClaimParentId { get; set; }
    }
}
