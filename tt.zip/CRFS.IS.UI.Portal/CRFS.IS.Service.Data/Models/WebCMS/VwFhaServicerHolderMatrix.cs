﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaServicerHolderMatrix
    {
        public long ServicerHolderXrefId { get; set; }
        public long ServicerId { get; set; }
        public string ServicerName { get; set; }
        public string ServicingMortageeNumber { get; set; }
        public long HolderId { get; set; }
        public string HolderName { get; set; }
        public string HoldingMortgageeNumber { get; set; }
        public int? ClientId { get; set; }
        public bool Active { get; set; }
    }
}
