﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblFhamortgagees
    {
        public TblFhamortgagees()
        {
            TblFhaloans = new HashSet<TblFhaloans>();
            XrefServicerHolder = new HashSet<XrefServicerHolder>();
        }

        public long MortgageeId { get; set; }
        public string MortgageeName { get; set; }
        public string HoldingMortgageeNumber { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string StateCode { get; set; }
        public string ZipCode { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUser { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUser { get; set; }

        public virtual ICollection<TblFhaloans> TblFhaloans { get; set; }
        public virtual ICollection<XrefServicerHolder> XrefServicerHolder { get; set; }
    }
}
