﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaTs997ackCodes
    {
        public long HudackCodeId { get; set; }
        public string HudackCode { get; set; }
        public string HudackCodeDescription { get; set; }
    }
}
