﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaClaimStatus
    {
        public long ClaimStatusId { get; set; }
        public string ClaimStatus { get; set; }
    }
}
