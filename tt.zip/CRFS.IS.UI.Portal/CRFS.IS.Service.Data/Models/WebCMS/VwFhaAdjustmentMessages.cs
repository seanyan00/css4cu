﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaAdjustmentMessages
    {
        public long FhalookupId { get; set; }
        public string AdjustmentCode { get; set; }
        public string LineBlock { get; set; }
        public string AdjustmentMessage { get; set; }
        public string AlternateMesssage { get; set; }
    }
}
