﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwHudPartD
    {
        public long ClaimTypeId { get; set; }
        public string MortgagorFirstName { get; set; }
        public string MortgagorMiddleName { get; set; }
        public string MortgagorLastName { get; set; }
        public string PropertyAddress1 { get; set; }
        public string PropertyAddress2 { get; set; }
        public string PropertyCity { get; set; }
        public string PropertyStateCode { get; set; }
        public string PropertyZipCode { get; set; }
        public string FhacaseNumber { get; set; }
        public string MortgageeLoanNumber { get; set; }
        public long PartD27011id { get; set; }
        public long FhaclaimId { get; set; }
        public DateTime? DateFormPrepared { get; set; }
        public string ClientName { get; set; }
        public string SectionOfActCode { get; set; }
        public decimal? DebentureInterestRate { get; set; }
        public DateTime? DefaultDate { get; set; }
        public string MortgageeName { get; set; }
        public string ServicerName { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUser { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUser { get; set; }
    }
}
