﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblFhaediclaimErrors
    {
        public long ClaimErrorId { get; set; }
        public long FhaclaimId { get; set; }
        public string ClaimPartErrorIndication { get; set; }
        public DateTime TransmissionDate { get; set; }
        public DateTime DateClaimReceived { get; set; }
        public string ErrorCodeInstance { get; set; }
        public long ErrorId { get; set; }
        public DateTime ErrorReceivedDate { get; set; }
        public DateTime? ResubmitDate { get; set; }

        public virtual TblFhaclaims Fhaclaim { get; set; }
    }
}
