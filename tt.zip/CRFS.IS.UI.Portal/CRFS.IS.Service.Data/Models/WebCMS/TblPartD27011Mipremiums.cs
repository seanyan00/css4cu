﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblPartD27011Mipremiums
    {
        public long MipremiumId { get; set; }
        public long PartD27011id { get; set; }
        public DateTime DatePaid { get; set; }
        public DateTime PeriodCoveredFrom { get; set; }
        public DateTime PeriodCoveredTo { get; set; }
        public decimal AmountPaid { get; set; }
        public decimal? DebentureInterest { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUser { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUser { get; set; }

        public virtual TblPartD27011 PartD27011 { get; set; }
    }
}
