﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpFhawebDisplayState
    {
        public int WebDisplayState { get; set; }
        public int StateNumber { get; set; }
        public string StateDescription { get; set; }
    }
}
