﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefClientAttributeRegistrations
    {
        public XrefClientAttributeRegistrations()
        {
            TblLoanClaimExtendedAttributes = new HashSet<TblLoanClaimExtendedAttributes>();
        }

        public long ClientAttributeRegistrationId { get; set; }
        public long FhaclientId { get; set; }
        public long ExtendedAttributeId { get; set; }
        public DateTime EnteredDate { get; set; }

        public virtual LkpExtendedAttributes ExtendedAttribute { get; set; }
        public virtual ICollection<TblLoanClaimExtendedAttributes> TblLoanClaimExtendedAttributes { get; set; }
    }
}
