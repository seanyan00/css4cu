﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CRFS.IS.Service.Data
{
    public partial class HUDClaimsContext : DbContext
    {
        public HUDClaimsContext()
        {
        }

        public HUDClaimsContext(DbContextOptions<HUDClaimsContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AaaSupps2remove> AaaSupps2remove { get; set; }
        public virtual DbSet<EdiextractLoggingRecords> EdiextractLoggingRecords { get; set; }
        public virtual DbSet<LegacyLkpFhaclients> LegacyLkpFhaclients { get; set; }
        public virtual DbSet<LkpAlternateAopmesssages> LkpAlternateAopmesssages { get; set; }
        public virtual DbSet<LkpDaysInForce> LkpDaysInForce { get; set; }
        public virtual DbSet<LkpDebentureRates10Yr> LkpDebentureRates10Yr { get; set; }
        public virtual DbSet<LkpDebentureRates6Mth> LkpDebentureRates6Mth { get; set; }
        public virtual DbSet<LkpExtendedAttributes> LkpExtendedAttributes { get; set; }
        public virtual DbSet<LkpFhadueDiligence> LkpFhadueDiligence { get; set; }
        public virtual DbSet<LkpFhalookups> LkpFhalookups { get; set; }
        public virtual DbSet<LkpFharetrievedDocumentTypes> LkpFharetrievedDocumentTypes { get; set; }
        public virtual DbSet<LkpFhawebDisplayState> LkpFhawebDisplayState { get; set; }
        public virtual DbSet<LkpForm27011Blocks> LkpForm27011Blocks { get; set; }
        public virtual DbSet<PendingSubmitClaimForms> PendingSubmitClaimForms { get; set; }
        public virtual DbSet<PendingSubmits> PendingSubmits { get; set; }
        public virtual DbSet<TblAopAdjustmentMessages> TblAopAdjustmentMessages { get; set; }
        public virtual DbSet<TblAopLineItems> TblAopLineItems { get; set; }
        public virtual DbSet<TblDataAutomationFhaDocRetrieveHistories> TblDataAutomationFhaDocRetrieveHistories { get; set; }
        public virtual DbSet<TblDocuwareClientCabinetClientName> TblDocuwareClientCabinetClientName { get; set; }
        public virtual DbSet<TblFhaEdiCutoffs> TblFhaEdiCutoffs { get; set; }
        public virtual DbSet<TblFhaTaxSchedule> TblFhaTaxSchedule { get; set; }
        public virtual DbSet<TblFhaclaimEdilog> TblFhaclaimEdilog { get; set; }
        public virtual DbSet<TblFhaclaimSubmitLog> TblFhaclaimSubmitLog { get; set; }
        public virtual DbSet<TblFhaclaims> TblFhaclaims { get; set; }
        public virtual DbSet<TblFhaediTransmitAck> TblFhaediTransmitAck { get; set; }
        public virtual DbSet<TblFhaediclaimErrors> TblFhaediclaimErrors { get; set; }
        public virtual DbSet<TblFhaedicontrol> TblFhaedicontrol { get; set; }
        public virtual DbSet<TblFhalivingUnits> TblFhalivingUnits { get; set; }
        public virtual DbSet<TblFhaloans> TblFhaloans { get; set; }
        public virtual DbSet<TblFhamortgagees> TblFhamortgagees { get; set; }
        public virtual DbSet<TblFhamortgagors> TblFhamortgagors { get; set; }
        public virtual DbSet<TblFhapaymentAdvices> TblFhapaymentAdvices { get; set; }
        public virtual DbSet<TblFhapendingDoc> TblFhapendingDoc { get; set; }
        public virtual DbSet<TblFhaservicers> TblFhaservicers { get; set; }
        public virtual DbSet<TblFhawebDisplayControl> TblFhawebDisplayControl { get; set; }
        public virtual DbSet<TblLoanClaimExtendedAttributes> TblLoanClaimExtendedAttributes { get; set; }
        public virtual DbSet<TblPartA27011> TblPartA27011 { get; set; }
        public virtual DbSet<TblPartB27011> TblPartB27011 { get; set; }
        public virtual DbSet<TblPartC27011> TblPartC27011 { get; set; }
        public virtual DbSet<TblPartD27011> TblPartD27011 { get; set; }
        public virtual DbSet<TblPartD27011Mipremiums> TblPartD27011Mipremiums { get; set; }
        public virtual DbSet<TblPartD27011MultiBlock> TblPartD27011MultiBlock { get; set; }
        public virtual DbSet<TblPartD27011SpecialAssessments> TblPartD27011SpecialAssessments { get; set; }
        public virtual DbSet<TblPartD27011TaxesOnDeed> TblPartD27011TaxesOnDeed { get; set; }
        public virtual DbSet<TblPartE27011> TblPartE27011 { get; set; }
        public virtual DbSet<TblPartE27011MultiBlock> TblPartE27011MultiBlock { get; set; }
        public virtual DbSet<TblPendingTaldocument> TblPendingTaldocument { get; set; }
        public virtual DbSet<TblProtectionPreservationDisbursements> TblProtectionPreservationDisbursements { get; set; }
        public virtual DbSet<TblScanLog> TblScanLog { get; set; }
       
        public virtual DbSet<VwFhaAdjustmentMessages> VwFhaAdjustmentMessages { get; set; }
        public virtual DbSet<VwFhaBlock105Types> VwFhaBlock105Types { get; set; }
        public virtual DbSet<VwFhaBlock108Types> VwFhaBlock108Types { get; set; }
        public virtual DbSet<VwFhaBlock10Types> VwFhaBlock10Types { get; set; }
        public virtual DbSet<VwFhaBlock305> VwFhaBlock305 { get; set; }
        public virtual DbSet<VwFhaBlock305Description> VwFhaBlock305Description { get; set; }
        public virtual DbSet<VwFhaBlock306> VwFhaBlock306 { get; set; }
        public virtual DbSet<VwFhaBlock306Description> VwFhaBlock306Description { get; set; }
        public virtual DbSet<VwFhaBlock307> VwFhaBlock307 { get; set; }
        public virtual DbSet<VwFhaBlock307Description> VwFhaBlock307Description { get; set; }
        public virtual DbSet<VwFhaBlock308> VwFhaBlock308 { get; set; }
        public virtual DbSet<VwFhaBlock308Description> VwFhaBlock308Description { get; set; }
        public virtual DbSet<VwFhaBlock309> VwFhaBlock309 { get; set; }
        public virtual DbSet<VwFhaBlock310> VwFhaBlock310 { get; set; }
        public virtual DbSet<VwFhaBlock311> VwFhaBlock311 { get; set; }
        public virtual DbSet<VwFhaBlock405> VwFhaBlock405 { get; set; }
        public virtual DbSet<VwFhaBlock406> VwFhaBlock406 { get; set; }
        public virtual DbSet<VwFhaBlock407> VwFhaBlock407 { get; set; }
        public virtual DbSet<VwFhaBlock408> VwFhaBlock408 { get; set; }
        public virtual DbSet<VwFhaBlock409> VwFhaBlock409 { get; set; }
        public virtual DbSet<VwFhaBlock410> VwFhaBlock410 { get; set; }
        public virtual DbSet<VwFhaBlock9Types> VwFhaBlock9Types { get; set; }
        public virtual DbSet<VwFhaClaimStatus> VwFhaClaimStatus { get; set; }
        public virtual DbSet<VwFhaClaimTypes> VwFhaClaimTypes { get; set; }
        public virtual DbSet<VwFhaClients> VwFhaClients { get; set; }
        public virtual DbSet<VwFhaDamageTypes> VwFhaDamageTypes { get; set; }
        public virtual DbSet<VwFhaDefaultReasons> VwFhaDefaultReasons { get; set; }
        public virtual DbSet<VwFhaDeficiencyJudgementCodes> VwFhaDeficiencyJudgementCodes { get; set; }
        public virtual DbSet<VwFhaEdiDefaultReasons> VwFhaEdiDefaultReasons { get; set; }
        public virtual DbSet<VwFhaErrorCodes> VwFhaErrorCodes { get; set; }
        public virtual DbSet<VwFhaMortgagors> VwFhaMortgagors { get; set; }
        public virtual DbSet<VwFhaOccupancyStatusCodes> VwFhaOccupancyStatusCodes { get; set; }
        public virtual DbSet<VwFhaPpddescription> VwFhaPpddescription { get; set; }
        public virtual DbSet<VwFhaPropertyConditionCodes> VwFhaPropertyConditionCodes { get; set; }
        public virtual DbSet<VwFhaProtectionPreservationDisbursements> VwFhaProtectionPreservationDisbursements { get; set; }
        public virtual DbSet<VwFhaSectionsOfTheAct> VwFhaSectionsOfTheAct { get; set; }
        public virtual DbSet<VwFhaServicerHolderMatrix> VwFhaServicerHolderMatrix { get; set; }
        public virtual DbSet<VwFhaStates> VwFhaStates { get; set; }
        public virtual DbSet<VwFhaTaxSchedule> VwFhaTaxSchedule { get; set; }
        public virtual DbSet<VwFhaTs997ackCodes> VwFhaTs997ackCodes { get; set; }
        public virtual DbSet<VwFhalivingUnits> VwFhalivingUnits { get; set; }
        public virtual DbSet<VwHudClaimStatus> VwHudClaimStatus { get; set; }
        public virtual DbSet<VwHudInitialInput> VwHudInitialInput { get; set; }
        public virtual DbSet<VwHudPartA> VwHudPartA { get; set; }
        public virtual DbSet<VwHudPartB> VwHudPartB { get; set; }
        public virtual DbSet<VwHudPartC> VwHudPartC { get; set; }
        public virtual DbSet<VwHudPartD> VwHudPartD { get; set; }
        public virtual DbSet<VwHudPartE> VwHudPartE { get; set; }
        public virtual DbSet<VwHudSearch> VwHudSearch { get; set; }
        public virtual DbSet<VwHudclaimsInvTrkAndImportsClientClaimTypeClaimSubTypesOnboarded> VwHudclaimsInvTrkAndImportsClientClaimTypeClaimSubTypesOnboarded { get; set; }
        public virtual DbSet<VwInvTrkFhaclaim> VwInvTrkFhaclaim { get; set; }
        public virtual DbSet<VwInvTrkLoan> VwInvTrkLoan { get; set; }
        public virtual DbSet<VwPartB> VwPartB { get; set; }
        public virtual DbSet<VwRecSheetDeductAmountByClientClaim> VwRecSheetDeductAmountByClientClaim { get; set; }
    
        public virtual DbSet<XrefClaimDocuments> XrefClaimDocuments { get; set; }
        public virtual DbSet<XrefClientAttributeRegistrations> XrefClientAttributeRegistrations { get; set; }
        public virtual DbSet<XrefEnvironmentClientCabinet> XrefEnvironmentClientCabinet { get; set; }
        public virtual DbSet<XrefFhaclientClaimTypeEdicontrol> XrefFhaclientClaimTypeEdicontrol { get; set; }
        public virtual DbSet<XrefServicerHolder> XrefServicerHolder { get; set; }
        public virtual DbSet<ZzTableDropCandidateTblControlAllowEdiauthConditions> ZzTableDropCandidateTblControlAllowEdiauthConditions { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=vm-sql1-dev.dev.crfs.crfservices.com\\cms_d;Initial Catalog=HUDClaims;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AaaSupps2remove>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("aaa_supps2remove");

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.FhaloanId).HasColumnName("FHALoanID");
            });

            modelBuilder.Entity<EdiextractLoggingRecords>(entity =>
            {
                entity.HasKey(e => e.EdiextractLoggingRecordId);

                entity.ToTable("EDIExtractLoggingRecords");

                entity.Property(e => e.EdiextractLoggingRecordId).HasColumnName("EDIExtractLoggingRecordID");

                entity.Property(e => e.Data)
                    .IsRequired()
                    .HasMaxLength(3000)
                    .IsUnicode(false);

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.LogDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");
            });

            modelBuilder.Entity<LegacyLkpFhaclients>(entity =>
            {
                entity.HasKey(e => e.FhaclientId)
                    .HasName("PK_lkp_FHAClients");

                entity.ToTable("Legacy_lkp_FHAClients");

                entity.HasComment("Legacy look-up table.");

                entity.Property(e => e.FhaclientId).HasColumnName("FHAClientID");

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CmsclientId).HasColumnName("CMSClientID");

                entity.Property(e => e.EnableHudEdi).HasColumnName("Enable_HUD_EDI");
            });

            modelBuilder.Entity<LkpAlternateAopmesssages>(entity =>
            {
                entity.HasKey(e => e.AlternateMessageId);

                entity.ToTable("lkp_AlternateAOPMesssages");

                entity.HasComment("Look-up table. Contains alternate AOP messages.");

                entity.Property(e => e.AlternateMessageId).HasColumnName("AlternateMessageID");

                entity.Property(e => e.AlternateMesssage)
                    .IsRequired()
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.EffectiveFromDate).HasColumnType("datetime");

                entity.Property(e => e.EffectiveToDate).HasColumnType("datetime");

                entity.Property(e => e.FhalookupId).HasColumnName("FHALookupID");

                entity.HasOne(d => d.Fhalookup)
                    .WithMany(p => p.LkpAlternateAopmesssages)
                    .HasForeignKey(d => d.FhalookupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_lkp_FHALookups_lkp_AlternateAOPMesssages");
            });

            modelBuilder.Entity<LkpDaysInForce>(entity =>
            {
                entity.HasKey(e => e.DaysInForceId)
                    .HasName("PK__lkp_Days__D52CBEEA484DB3FF");

                entity.ToTable("lkp_DaysInForce");

                entity.HasComment("Empty look-up table.");

                entity.Property(e => e.DaysInForceId).HasColumnName("DaysInForceID");
            });

            modelBuilder.Entity<LkpDebentureRates10Yr>(entity =>
            {
                entity.HasKey(e => e.DebentureRate10YrId);

                entity.ToTable("lkp_DebentureRates10Yr");

                entity.HasComment("Look-up table. Contains debenture rates, 10 yr");

                entity.HasIndex(e => e.StartDate)
                    .HasName("UK1_StartDate")
                    .IsUnique();

                entity.Property(e => e.DebentureRate10YrId).HasColumnName("DebentureRate10YrID");

                entity.Property(e => e.EndDate).HasColumnType("datetime");

                entity.Property(e => e.StartDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<LkpDebentureRates6Mth>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("lkp_DebentureRates6Mth");

                entity.HasComment("Look-up table. Contains debenture rates, 6 mth");

                entity.HasIndex(e => e.StartDate)
                    .HasName("UK1_StartDate")
                    .IsUnique();

                entity.Property(e => e.DebentureRate6MthId)
                    .HasColumnName("DebentureRate6MthID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.EndDate).HasColumnType("datetime");

                entity.Property(e => e.StartDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<LkpExtendedAttributes>(entity =>
            {
                entity.HasKey(e => e.ExtendedAttributeId);

                entity.ToTable("lkp_ExtendedAttributes");

                entity.HasComment("Look-up table. Contains extended attributes.");

                entity.HasIndex(e => e.ExtendedAttributeName)
                    .HasName("UK1_lkp_ExtendedAttributes")
                    .IsUnique();

                entity.Property(e => e.ExtendedAttributeId).HasColumnName("ExtendedAttributeID");

                entity.Property(e => e.ExtendedAttributeDataType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ExtendedAttributeName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpFhadueDiligence>(entity =>
            {
                entity.HasKey(e => e.FhadueDiligenceId);

                entity.ToTable("lkp_FHADueDiligence");

                entity.HasComment("Look-up table. Contains FHA Due Diligence information.");

                entity.Property(e => e.FhadueDiligenceId).HasColumnName("FHADueDiligenceID");

                entity.Property(e => e.ConveyanceTypeCode)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.EffectiveDateRangeEnd).HasColumnType("date");

                entity.Property(e => e.EffectiveDateRangeStart).HasColumnType("date");

                entity.Property(e => e.StateId).HasColumnName("StateID");
            });

            modelBuilder.Entity<LkpFhalookups>(entity =>
            {
                entity.HasKey(e => e.FhalookupId);

                entity.ToTable("lkp_FHALookups");

                entity.HasComment("Look-up table. Contains FHA Look-up information.");

                entity.HasIndex(e => new { e.Lucategory, e.DisplayCode1, e.DisplayCode2, e.Lutext })
                    .HasName("UK1_lkp_FHALookUps")
                    .IsUnique();

                entity.Property(e => e.FhalookupId).HasColumnName("FHALookupID");

                entity.Property(e => e.DisplayCode1)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.DisplayCode2)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EffectiveFromDate).HasColumnType("datetime");

                entity.Property(e => e.EffectiveToDate).HasColumnType("datetime");

                entity.Property(e => e.Lucategory)
                    .IsRequired()
                    .HasColumnName("LUCategory")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Lutext)
                    .HasColumnName("LUText")
                    .HasMaxLength(300)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpFharetrievedDocumentTypes>(entity =>
            {
                entity.HasKey(e => e.FharetrievedDocumentTypeId)
                    .HasName("lkp_FHARetrievedDocumentTypes_PK");

                entity.ToTable("lkp_FHARetrievedDocumentTypes");

                entity.HasComment("Look-up table. Contains FHA retrieved document types.");

                entity.Property(e => e.FharetrievedDocumentTypeId).HasColumnName("FHARetrievedDocumentTypeID");

                entity.Property(e => e.DateEntered)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.RetrievedDocumentName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpFhawebDisplayState>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("lkp_FHAWebDisplayState");

                entity.HasComment("Look-up table. Contains FHA web display states.");

                entity.Property(e => e.StateDescription)
                    .IsRequired()
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.WebDisplayState).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<LkpForm27011Blocks>(entity =>
            {
                entity.HasKey(e => e.Form27011BlockId);

                entity.ToTable("lkp_Form27011Blocks");

                entity.HasComment("Look-up table. Contains information about form 27011 blocks.");

                entity.Property(e => e.Form27011BlockId).HasColumnName("Form27011BlockID");

                entity.Property(e => e.BlockCode)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.BlockName)
                    .IsRequired()
                    .HasMaxLength(150)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<PendingSubmitClaimForms>(entity =>
            {
                entity.HasKey(e => e.PendingSubmitClaimFormId);

                entity.HasComment("Contains information about pending submit claim forms.");

                entity.Property(e => e.PendingSubmitClaimFormId).HasColumnName("PendingSubmitClaimFormID");

                entity.Property(e => e.ClaimEdilogId).HasColumnName("ClaimEDILogID");

                entity.Property(e => e.CompletedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.HasOne(d => d.ClaimEdilog)
                    .WithMany(p => p.PendingSubmitClaimForms)
                    .HasForeignKey(d => d.ClaimEdilogId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_PendingSubmitClaimForms_tbl_FHAClaimEDILog");

                entity.HasOne(d => d.Fhaclaim)
                    .WithMany(p => p.PendingSubmitClaimForms)
                    .HasForeignKey(d => d.FhaclaimId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_PendingSubmitClaimForms_tbl_FHAClaims");
            });

            modelBuilder.Entity<PendingSubmits>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.ClaimEdilogId).HasColumnName("ClaimEDILogID");

                entity.Property(e => e.ClaimTypeName)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.ClientName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DateTimeStamp)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DefaultReason)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.FhacaseNumber)
                    .HasColumnName("FHACaseNumber")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.FhaclaimId).HasColumnName("FHACLaimID");

                entity.Property(e => e.LoanNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.SubType)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.SubmitType)
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblAopAdjustmentMessages>(entity =>
            {
                entity.HasKey(e => e.AopAdjustmentMessageId)
                    .HasName("tbl_AOP_AdjustmentMessages_PK");

                entity.ToTable("tbl_AOP_AdjustmentMessages");

                entity.HasComment("Contains AOP adjustment messages.");

                entity.Property(e => e.AopAdjustmentMessageId).HasColumnName("AOP_AdjustmentMessageID");

                entity.Property(e => e.AdjustmentCodeId).HasColumnName("AdjustmentCodeID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.PaymentAdviceId).HasColumnName("PaymentAdviceID");

                entity.HasOne(d => d.PaymentAdvice)
                    .WithMany(p => p.TblAopAdjustmentMessages)
                    .HasForeignKey(d => d.PaymentAdviceId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_FHAPaymentAdvices_tbl_AOP_AdjustmentMessages");
            });

            modelBuilder.Entity<TblAopLineItems>(entity =>
            {
                entity.HasKey(e => e.AopLineItemId)
                    .HasName("tbl_AOP_LineItems_PK");

                entity.ToTable("tbl_AOP_LineItems");

                entity.HasComment("Contains AOP line items for payment advices.");

                entity.HasIndex(e => new { e.LineId, e.LineAmount, e.PaymentAdviceId })
                    .HasName("idx_AOPLineItems_PaymentAdvice");

                entity.Property(e => e.AopLineItemId).HasColumnName("AOP_LineItemID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.InterestBeginDate).HasColumnType("date");

                entity.Property(e => e.InterestEndDate).HasColumnType("date");

                entity.Property(e => e.InterestRate).HasColumnType("decimal(8, 4)");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LineAmount).HasColumnType("money");

                entity.Property(e => e.LineId).HasColumnName("LineID");

                entity.Property(e => e.PaymentAdviceId).HasColumnName("PaymentAdviceID");

                entity.HasOne(d => d.PaymentAdvice)
                    .WithMany(p => p.TblAopLineItems)
                    .HasForeignKey(d => d.PaymentAdviceId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_tbl_FHAPaymentAdvices_tbl_AOP_LineItems");
            });

            modelBuilder.Entity<TblDataAutomationFhaDocRetrieveHistories>(entity =>
            {
                entity.HasKey(e => e.FhaDocRetrieveHistoryId)
                    .HasName("tbl_DataAutomation_FHA_Doc_Retrieve_Histories_PK");

                entity.ToTable("tbl_DataAutomation_FHA_Doc_Retrieve_Histories");

                entity.HasComment("Contains retrieve histories for FHA documents.");

                entity.Property(e => e.FhaDocRetrieveHistoryId).HasColumnName("FHA_Doc_Retrieve_HistoryID");

                entity.Property(e => e.DocumentRetrieveDate).HasColumnType("datetime");

                entity.Property(e => e.DocuwareCabinet)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DocuwareStorageDate).HasColumnType("datetime");

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.FharetrievedDocumentTypeId).HasColumnName("FHARetrievedDocumentTypeID");

                entity.HasOne(d => d.Fhaclaim)
                    .WithMany(p => p.TblDataAutomationFhaDocRetrieveHistories)
                    .HasForeignKey(d => d.FhaclaimId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("tbl_FHALoans_tbl_DataAutomation_FHA_Doc_Retrieve_Histories_FK1");

                entity.HasOne(d => d.FharetrievedDocumentType)
                    .WithMany(p => p.TblDataAutomationFhaDocRetrieveHistories)
                    .HasForeignKey(d => d.FharetrievedDocumentTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("lkp_FHARetrievedDocumentTypes_tbl_DataAutomation_FHA_Doc_Retrieve_Histories_FK1");
            });

            modelBuilder.Entity<TblDocuwareClientCabinetClientName>(entity =>
            {
                entity.HasKey(e => e.DocuwareClientCabinetClientName);

                entity.ToTable("tbl_DocuwareClientCabinetClientName");

                entity.HasComment("Contains Docuware client cabinet client names.");

                entity.Property(e => e.Cabinet)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FhaclientId).HasColumnName("FHAClientID");
            });

            modelBuilder.Entity<TblFhaEdiCutoffs>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("tbl_FHA_EDI_Cutoffs");

                entity.HasComment("Contains EDI cutoff dates.");

                entity.Property(e => e.EdiCutOffDate)
                    .HasColumnName("EDI_CutOffDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.FhaEdiCutoffId)
                    .HasColumnName("FHA_EDI_CutoffID")
                    .ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<TblFhaTaxSchedule>(entity =>
            {
                entity.HasKey(e => e.TaxScheduleId);

                entity.ToTable("tbl_FHA_TaxSchedule");

                entity.HasComment("Contains FHA tax schedule information.");

                entity.HasIndex(e => new { e.PartA27011id, e.TaxYear, e.TaxType, e.CollectorPropertyIdentification })
                    .HasName("UK1_FHA_TaxSchedule_PartA27011ID_TaxYear_TaxType")
                    .IsUnique();

                entity.Property(e => e.TaxScheduleId).HasColumnName("TaxScheduleID");

                entity.Property(e => e.AmountPaid).HasColumnType("money");

                entity.Property(e => e.CollectorPropertyIdentification)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DatePaid).HasColumnType("date");

                entity.Property(e => e.EndDate).HasColumnType("date");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.PartA27011id).HasColumnName("PartA27011ID");

                entity.Property(e => e.StartDate).HasColumnType("date");

                entity.Property(e => e.TaxType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.PartA27011)
                    .WithMany(p => p.TblFhaTaxSchedule)
                    .HasForeignKey(d => d.PartA27011id)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_PartA27011_tbl_FHA_TaxSchedule");
            });

            modelBuilder.Entity<TblFhaclaimEdilog>(entity =>
            {
                entity.HasKey(e => e.ClaimEdilogId);

                entity.ToTable("tbl_FHAClaimEDILog");

                entity.HasComment("Contains a log of dates for Extract, Translate, Bundle, Transfer and Receipt for FHA claims.");

                entity.HasIndex(e => new { e.OutboundExtractDate, e.MarkedForDelete })
                    .HasName("idx_tbl_FHAClaimEDILog_OutboundExtractDate_MarkedForDelete");

                entity.Property(e => e.ClaimEdilogId).HasColumnName("ClaimEDILogID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.InboundReceiptDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.OutboundBundleDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.OutboundExtractDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.OutboundTransferDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.OutboundTranslateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.SubmitPart)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.HasOne(d => d.Fhaclaim)
                    .WithMany(p => p.TblFhaclaimEdilog)
                    .HasForeignKey(d => d.FhaclaimId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_FHAClaimEDILog_tbl_FHAClaims");
            });

            modelBuilder.Entity<TblFhaclaimSubmitLog>(entity =>
            {
                entity.HasKey(e => e.FhaclaimSubmitLogId)
                    .HasName("PK_FHAClaimSubmitLog");

                entity.ToTable("tbl_FHAClaimSubmitLog");

                entity.HasComment("Contains an FHA claim submit log.");

                entity.HasIndex(e => new { e.EnteredDate, e.SubmitTypeId, e.FhaclaimId, e.ClaimEdilogId })
                    .HasName("idx_tbl_FHAClaimSubmitLog_FHAClaimID_ClaimEDILogID");

                entity.Property(e => e.FhaclaimSubmitLogId).HasColumnName("FHAClaimSubmitLogID");

                entity.Property(e => e.AssembledCommentText)
                    .HasMaxLength(180)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimEdilogId).HasColumnName("ClaimEDILogID");

                entity.Property(e => e.Comment1)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.Comment2)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.ShippingVendorId).HasColumnName("ShippingVendorID");

                entity.Property(e => e.SubmitTypeId).HasColumnName("SubmitTypeID");

                entity.Property(e => e.TrackingNumber)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.HasOne(d => d.ClaimEdilog)
                    .WithMany(p => p.TblFhaclaimSubmitLog)
                    .HasForeignKey(d => d.ClaimEdilogId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_tbl_FHAClaimSubmitLog_tbl_FHAClaimEDILog");

                entity.HasOne(d => d.Fhaclaim)
                    .WithMany(p => p.TblFhaclaimSubmitLog)
                    .HasForeignKey(d => d.FhaclaimId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_FHAClaimSubmitLog_tbl_FHAClaims");
            });

            modelBuilder.Entity<TblFhaclaims>(entity =>
            {
                entity.HasKey(e => e.FhaclaimId);

                entity.ToTable("tbl_FHAClaims");

                entity.HasComment("Contains information about FHA claims.");

                entity.HasIndex(e => e.FhaloanId)
                    .HasName("idx_tbl_FHAClaims_FHALoanID");

                entity.HasIndex(e => new { e.FhaclaimId, e.InvTrkClaimId })
                    .HasName("idx_tbl_FHAClaims_InvTrk_ClaimID");

                entity.HasIndex(e => new { e.FhaclaimId, e.FhaloanId, e.ClaimTypeId })
                    .HasName("idx_tbl_FHAClaims_ClaimTypeID");

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.ClaimStatusId).HasColumnName("ClaimStatusID");

                entity.Property(e => e.ClaimTypeId)
                    .HasColumnName("ClaimTypeID")
                    .HasComment("code specifying the type of claim being filed");

                entity.Property(e => e.CurtailDateForDi)
                    .HasColumnName("CurtailDateForDI")
                    .HasColumnType("date");

                entity.Property(e => e.DebentureInterestRate).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.DefaultDate)
                    .HasColumnType("date")
                    .HasComment("Date on which the loan went into default");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FhaclaimSubTypeId)
                    .HasColumnName("FHAClaimSubTypeID")
                    .HasComment("The sub type of the claim being filed (ex. IL, DHHL, SFLS for Assignment)");

                entity.Property(e => e.FhaloanId).HasColumnName("FHALoanID");

                entity.Property(e => e.FhasuppClaimParentId).HasColumnName("FHASuppClaimParentID");

                entity.Property(e => e.FhasuppClaimTypeId)
                    .HasColumnName("FHASuppClaimTypeID")
                    .HasComment("The type of supplemental claim (Refund or Recover) if applicable");

                entity.Property(e => e.InvTrkClaimId).HasColumnName("InvTrk_ClaimID");

                entity.Property(e => e.LastArmrate)
                    .HasColumnName("LastARMRate")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LoanDate).HasColumnType("date");

                entity.Property(e => e.McdequalCurtailDateForDi).HasColumnName("MCDEqualCurtailDateForDI");

                entity.Property(e => e.ModifiedInterestRate).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.NewMaturityDate).HasColumnType("date");

                entity.Property(e => e.NoteRate)
                    .HasColumnType("decimal(18, 5)")
                    .HasComment("The interest rate on the mortgage note");

                entity.Property(e => e.SectionOfTheActId)
                    .HasColumnName("SectionOfTheActID")
                    .HasComment("code specifying the section of the national housing act under which the mortage was insured");

                entity.HasOne(d => d.Fhaloan)
                    .WithMany(p => p.TblFhaclaims)
                    .HasForeignKey(d => d.FhaloanId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_FHALoans_tbl_FHAClaims");
            });

            modelBuilder.Entity<TblFhaediTransmitAck>(entity =>
            {
                entity.HasKey(e => e.TransmitAckId);

                entity.ToTable("tbl_FHAEDI_TransmitAck");

                entity.HasComment("Contains FHA EDI Transmit Ack information.");

                entity.HasIndex(e => new { e.FhaclaimId, e.ServicerId, e.ControlNumber })
                    .HasName("UK1_tbl_FHAEDI_TransmitAck")
                    .IsUnique();

                entity.Property(e => e.TransmitAckId).HasColumnName("TransmitAckID");

                entity.Property(e => e.AckDate).HasColumnType("datetime");

                entity.Property(e => e.ControlNumber)
                    .IsRequired()
                    .HasMaxLength(8)
                    .IsUnicode(false);

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.ServicerId).HasColumnName("ServicerID");

                entity.Property(e => e.TransmitDate).HasColumnType("datetime");

                entity.Property(e => e.XactSetAckCodeId).HasColumnName("XactSetAckCodeID");

                entity.Property(e => e.XactSetAckSyntaxErrorCodeId).HasColumnName("XactSetAckSyntaxErrorCodeID");

                entity.HasOne(d => d.Fhaclaim)
                    .WithMany(p => p.TblFhaediTransmitAck)
                    .HasForeignKey(d => d.FhaclaimId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_FHAEDI_TransmitAck_tbl_FHAClaims");

                entity.HasOne(d => d.Servicer)
                    .WithMany(p => p.TblFhaediTransmitAck)
                    .HasForeignKey(d => d.ServicerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_tbl_FHAEDI_TransmitAck_tbl_FHAServicers");
            });

            modelBuilder.Entity<TblFhaediclaimErrors>(entity =>
            {
                entity.HasKey(e => e.ClaimErrorId);

                entity.ToTable("tbl_FHAEDIClaimErrors");

                entity.HasComment("Contains information about errors on FHA claims.");

                entity.Property(e => e.ClaimErrorId).HasColumnName("ClaimErrorID");

                entity.Property(e => e.ClaimPartErrorIndication)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.DateClaimReceived).HasColumnType("date");

                entity.Property(e => e.ErrorCodeInstance)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.ErrorId).HasColumnName("ErrorID");

                entity.Property(e => e.ErrorReceivedDate).HasColumnType("datetime");

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.ResubmitDate).HasColumnType("date");

                entity.Property(e => e.TransmissionDate).HasColumnType("date");

                entity.HasOne(d => d.Fhaclaim)
                    .WithMany(p => p.TblFhaediclaimErrors)
                    .HasForeignKey(d => d.FhaclaimId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_Table_1_tbl_FHAClaims");
            });

            modelBuilder.Entity<TblFhaedicontrol>(entity =>
            {
                entity.HasKey(e => e.EdicontrolId);

                entity.ToTable("tbl_FHAEDIControl");

                entity.HasComment("Contains FHA EDI control records.");

                entity.HasIndex(e => e.ClaimTypeId)
                    .HasName("UK1_tbl_FHAEDIControl")
                    .IsUnique();

                entity.Property(e => e.EdicontrolId).HasColumnName("EDIControlID");

                entity.Property(e => e.Block1)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block10)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block100)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block101)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block102)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block103)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block104)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block105)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block106)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block107)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block108)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block109)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block11)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block110)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block111)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block112)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block113)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block114)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block115)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block116)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block117)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block118)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block119)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block12)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block120)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block121)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block122)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block123)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block124)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block125)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block126)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block127)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block128)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block129)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block13)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block130)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block131)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block132)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block133)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block134)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block135)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block136)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block137)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block14)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block15)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block16)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block17)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block18)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block19)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block2)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block20)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block21)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block22)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block23)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block24)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block25)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block26)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block27)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block28)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block29)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block3)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block30)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block31)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block32)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block33)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block34)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block35)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block36)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block37)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block38)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block39)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block4)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block40)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block41)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block42)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block43)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block44)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block45)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block5)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block6)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block7)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block8)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block9)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");
            });

            modelBuilder.Entity<TblFhalivingUnits>(entity =>
            {
                entity.HasKey(e => e.LivingUnitId);

                entity.ToTable("tbl_FHALivingUnits");

                entity.HasComment("Contains information on if an FHA Living unit is occupied and who occupies it.");

                entity.Property(e => e.LivingUnitId).HasColumnName("LivingUnitID");

                entity.Property(e => e.DateSecured).HasColumnType("date");

                entity.Property(e => e.DateVacated).HasColumnType("date");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.OccupantName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PartA27011id).HasColumnName("PartA27011ID");

                entity.HasOne(d => d.PartA27011)
                    .WithMany(p => p.TblFhalivingUnits)
                    .HasForeignKey(d => d.PartA27011id)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_PartA27011_tbl_FHALivingUnits");
            });

            modelBuilder.Entity<TblFhaloans>(entity =>
            {
                entity.HasKey(e => e.FhaloanId);

                entity.ToTable("tbl_FHALoans");

                entity.HasComment("Contains information about FHA loans.");

                entity.HasIndex(e => new { e.FhacaseNumber, e.FhaclientId })
                    .HasName("UK1_FHACaseNumberClientID")
                    .IsUnique();

                entity.HasIndex(e => new { e.FhaloanId, e.InvTrkLoanId })
                    .HasName("IDX_tbl_FHALoans_InvTrk_LoanID_incl_FHALoanID");

                entity.HasIndex(e => new { e.MortgageeLoanNumber, e.MortgageeId, e.FhaclientId })
                    .HasName("UK2_Mortgagee_MortgageeLoanNumberClientID")
                    .IsUnique();

                entity.Property(e => e.FhaloanId).HasColumnName("FHALoanID");

                entity.Property(e => e.AuthorizedBidAmount)
                    .HasColumnType("money")
                    .HasComment("The amount of the Comissioner's Adjusted Fair Market Value");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FhacaseNumber)
                    .IsRequired()
                    .HasColumnName("FHACaseNumber")
                    .HasMaxLength(11)
                    .IsUnicode(false)
                    .HasComment("Case number assigned by the Federal Housing Administration to identify the loan");

                entity.Property(e => e.FhaclientId).HasColumnName("FHAClientID");

                entity.Property(e => e.InvTrkLoanId).HasColumnName("InvTrk_LoanID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.MortgageeContactName)
                    .HasMaxLength(75)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageeContactTelephone)
                    .HasMaxLength(14)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageeId).HasColumnName("MortgageeID");

                entity.Property(e => e.MortgageeLoanNumber)
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasComment("Number assigned to the loan by the mortgagee");

                entity.Property(e => e.PropertyAddress1)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasComment("Street address of the property");

                entity.Property(e => e.PropertyAddress2)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyCity)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasComment("City in which the property in located");

                entity.Property(e => e.PropertyStateCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasComment("State in which the property is located");

                entity.Property(e => e.PropertyZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasComment("Zip Code of the property");

                entity.Property(e => e.SecondChanceSaleDate)
                    .HasColumnType("date")
                    .HasComment("Sale date for a loan participating in the HUD Second Chance program");

                entity.Property(e => e.ServicerContactName)
                    .HasMaxLength(75)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerContactTelephone)
                    .HasMaxLength(14)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerId).HasColumnName("ServicerID");

                entity.Property(e => e.SuccessfulBidAmount)
                    .HasColumnType("money")
                    .HasComment("The amount of the winning bid at the sale");

                entity.HasOne(d => d.Mortgagee)
                    .WithMany(p => p.TblFhaloans)
                    .HasForeignKey(d => d.MortgageeId)
                    .HasConstraintName("FK2_tbl_FHAMortgagees_tbl_FHALoans");

                entity.HasOne(d => d.Servicer)
                    .WithMany(p => p.TblFhaloans)
                    .HasForeignKey(d => d.ServicerId)
                    .HasConstraintName("FK3_tbl_FHAServicers_tbl_FHALoans");
            });

            modelBuilder.Entity<TblFhamortgagees>(entity =>
            {
                entity.HasKey(e => e.MortgageeId);

                entity.ToTable("tbl_FHAMortgagees");

                entity.HasComment("Contains names and addresses for FHA mortgagees.");

                entity.Property(e => e.MortgageeId).HasColumnName("MortgageeID");

                entity.Property(e => e.Address1)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Address2)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.City)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.HoldingMortgageeNumber)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.MortgageeName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.StateCode)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.ZipCode)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblFhamortgagors>(entity =>
            {
                entity.HasKey(e => e.MortgagorId);

                entity.ToTable("tbl_FHAMortgagors");

                entity.HasComment("Contains names and information about FHA mortgagors.");

                entity.HasIndex(e => new { e.FhaloanId, e.CoMortgagor })
                    .HasName("IDX_tbl_FHAMortgagors_FHALoanID_CoMortgagor");

                entity.Property(e => e.MortgagorId).HasColumnName("MortgagorID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FhaloanId).HasColumnName("FHALoanID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.MortgagorFirstName)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorLastName)
                    .HasMaxLength(35)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorMiddleName)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.NonPersonEntity).HasDefaultValueSql("((0))");

                entity.Property(e => e.Prefix)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Ssn)
                    .HasColumnName("SSN")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.Suffix)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.HasOne(d => d.Fhaloan)
                    .WithMany(p => p.TblFhamortgagors)
                    .HasForeignKey(d => d.FhaloanId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_ tbl_FHALoans_tbl_FHAMortgagors");
            });

            modelBuilder.Entity<TblFhapaymentAdvices>(entity =>
            {
                entity.HasKey(e => e.PaymentAdviceId)
                    .HasName("tbl_FHAPaymentAdvices_PK");

                entity.ToTable("tbl_FHAPaymentAdvices");

                entity.HasComment("Contains FHA payment advice information.");

                entity.HasIndex(e => new { e.PaymentAdviceId, e.FhaclaimId, e.AdviceTypeId, e.SettlementDate })
                    .HasName("idx_FHAPaymentAdvices_SettlementDate");

                entity.Property(e => e.PaymentAdviceId).HasColumnName("PaymentAdviceID");

                entity.Property(e => e.AdviceTypeId)
                    .HasColumnName("AdviceTypeID")
                    .HasComment("3 digit code specifying if a AOP is Partial, Final or Full");

                entity.Property(e => e.ClaimReceivedDate)
                    .HasColumnType("date")
                    .HasComment("The date that the claim was received by HUD");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.PaymentActionId).HasColumnName("PaymentActionID");

                entity.Property(e => e.PaymentAdviceDate)
                    .HasColumnType("date")
                    .HasComment("The date on which the payment advice was issued");

                entity.Property(e => e.PaymentAmount)
                    .HasColumnType("money")
                    .HasComment("Actual payment amount by HUD to the servicer");

                entity.Property(e => e.PaymentMethodId).HasColumnName("PaymentMethodID");

                entity.Property(e => e.ScheduleReferenceNumber)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SettlementDate)
                    .HasColumnType("date")
                    .HasComment("The date of the settlement of the claim");

                entity.HasOne(d => d.Fhaclaim)
                    .WithMany(p => p.TblFhapaymentAdvices)
                    .HasForeignKey(d => d.FhaclaimId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_FHAClaims_tbl_FHAPaymentAdvices");
            });

            modelBuilder.Entity<TblFhapendingDoc>(entity =>
            {
                entity.HasKey(e => e.FhapendingDocId);

                entity.ToTable("tbl_FHAPendingDoc");

                entity.HasComment("Contains start and end dates for FHA pending documents.");

                entity.Property(e => e.FhapendingDocId).HasColumnName("FHAPendingDocID");

                entity.Property(e => e.EndDate).HasColumnType("datetime");

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.FhaclientId).HasColumnName("FHAClientID");

                entity.Property(e => e.FharetrievedDocumentTypeId).HasColumnName("FHARetrievedDocumentTypeID");

                entity.Property(e => e.StartDate).HasColumnType("datetime");

                entity.HasOne(d => d.FharetrievedDocumentType)
                    .WithMany(p => p.TblFhapendingDoc)
                    .HasForeignKey(d => d.FharetrievedDocumentTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tbl_FHAPendingDoc_lkp_FHARetrievedDocumentTypes");
            });

            modelBuilder.Entity<TblFhaservicers>(entity =>
            {
                entity.HasKey(e => e.ServicerId);

                entity.ToTable("tbl_FHAServicers");

                entity.HasComment("Contains names, addresses and servicing mortgagee numbers for FHA servicers.");

                entity.Property(e => e.ServicerId).HasColumnName("ServicerID");

                entity.Property(e => e.Address1)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Address2)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.City)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.ServicerName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ServicingMortageeNumber)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.StateCode)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.ZipCode)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblFhawebDisplayControl>(entity =>
            {
                entity.HasKey(e => e.WebControlId);

                entity.ToTable("tbl_FHAWebDisplayControl");

                entity.HasComment("Contains FHA web display control information.");

                entity.Property(e => e.WebControlId).HasColumnName("WebControlID");

                entity.Property(e => e.ObjectName)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.ObjectType)
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblLoanClaimExtendedAttributes>(entity =>
            {
                entity.HasKey(e => e.LoanClaimExtendedAttributeId);

                entity.ToTable("tbl_LoanClaim_ExtendedAttributes");

                entity.HasComment("Contains extended attribute information for loans claims.");

                entity.HasIndex(e => new { e.FhaclaimId, e.ClientAttributeRegistrationId })
                    .HasName("UK1_tbl_LoanClaim_ExtendedAttributes")
                    .IsUnique();

                entity.Property(e => e.LoanClaimExtendedAttributeId).HasColumnName("LoanClaim_ExtendedAttributeID");

                entity.Property(e => e.AttributeValue)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ClientAttributeRegistrationId).HasColumnName("ClientAttribute_RegistrationID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.FhaloanId).HasColumnName("FHALoanID");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.HasOne(d => d.ClientAttributeRegistration)
                    .WithMany(p => p.TblLoanClaimExtendedAttributes)
                    .HasForeignKey(d => d.ClientAttributeRegistrationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_tbl_LoanClaim_ExtendedAttributes_xref_ClientAttribute_Registrations");

                entity.HasOne(d => d.Fhaclaim)
                    .WithMany(p => p.TblLoanClaimExtendedAttributes)
                    .HasForeignKey(d => d.FhaclaimId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_tbl_LoanClaim_ExtendedAttributes_tbl_FHAClaims");

                entity.HasOne(d => d.Fhaloan)
                    .WithMany(p => p.TblLoanClaimExtendedAttributes)
                    .HasForeignKey(d => d.FhaloanId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_LoanClaim_ExtendedAttributes_tbl_FHALoans");
            });

            modelBuilder.Entity<TblPartA27011>(entity =>
            {
                entity.HasKey(e => e.PartA27011id);

                entity.ToTable("tbl_PartA27011");

                entity.HasComment("Contains Part A information for 27011 form.");

                entity.HasIndex(e => e.FhaclaimId)
                    .HasName("UK1_tbl_PartA27011_FHAClaimID")
                    .IsUnique();

                entity.Property(e => e.PartA27011id).HasColumnName("PartA27011ID");

                entity.Property(e => e.AuthorizedBidAmount)
                    .HasColumnType("money")
                    .HasComment("The amount of the Comissioner's Adjusted Fair Market Value");

                entity.Property(e => e.BankruptcyDateFiled)
                    .HasColumnType("date")
                    .HasComment("the date that the last bankruptcy was filed");

                entity.Property(e => e.Block10Date)
                    .HasColumnType("date")
                    .HasComment("The date the deed or assignment was filed for record or date the of closing or appraisal");

                entity.Property(e => e.Block10TypeId).HasColumnName("Block10TypeID");

                entity.Property(e => e.Block11DateofDil).HasColumnName("Block11DateofDIL");

                entity.Property(e => e.Block15Modified)
                    .HasColumnType("money")
                    .HasComment("The amount of the mortage following a modification");

                entity.Property(e => e.Block15Original)
                    .HasColumnType("money")
                    .HasComment("The amount of the original mortgage");

                entity.Property(e => e.Block19Date)
                    .HasColumnType("date")
                    .HasComment("The date that a HUD provided extension to foreclose or assign expired");

                entity.Property(e => e.Block20Date)
                    .HasColumnType("date")
                    .HasComment("The date on which the extension to convey expires");

                entity.Property(e => e.Block9Date)
                    .HasColumnType("date")
                    .HasComment("The date by which both marketable title and possession of the property were obtained");

                entity.Property(e => e.Block9TypeId).HasColumnName("Block9TypeID");

                entity.Property(e => e.DamageTypeId)
                    .HasColumnName("DamageTypeID")
                    .HasComment("The type of damage sustained by the property (Tornado, Boiler explosion, fire, Damage, Flood, Earthquake)");

                entity.Property(e => e.DateAssignmentFiledForRecord).HasColumnType("date");

                entity.Property(e => e.DateDamaged)
                    .HasColumnType("date")
                    .HasComment("The date that damage occurred to the property");

                entity.Property(e => e.DateDeedFiledForRecord).HasColumnType("date");

                entity.Property(e => e.DateFormPrepared)
                    .HasColumnType("date")
                    .HasComment("The date that the HUD claim form was prepared");

                entity.Property(e => e.DateLocalOfficeApprovalConveyanceDamaged)
                    .HasColumnType("date")
                    .HasComment("The date that the Mortgagee Compliance Manager approved conveyance of the property while damaged");

                entity.Property(e => e.DateLocalOfficeApprovalConveyanceOccupied)
                    .HasColumnType("date")
                    .HasComment("The date that the Management and Marketing Contractor approved conveyance of the property while occupied");

                entity.Property(e => e.DateLocalOfficeCertificationConveyanceDamaged)
                    .HasColumnType("date")
                    .HasComment("The date of the mortgagee certification letter");

                entity.Property(e => e.DateOfAcquisitionOfTitle).HasColumnType("date");

                entity.Property(e => e.DateOfAppraisal).HasColumnType("date");

                entity.Property(e => e.DateOfClosing).HasColumnType("date");

                entity.Property(e => e.DateOfDeedInLieu)
                    .HasColumnType("date")
                    .HasComment("The date that the Deed in Lieu was recorded");

                entity.Property(e => e.DateOfExtensionToConvey).HasColumnType("date");

                entity.Property(e => e.DateOfNoticeToConvey).HasColumnType("date");

                entity.Property(e => e.DateOfPossession).HasColumnType("date");

                entity.Property(e => e.DefaultReasonId)
                    .HasColumnName("DefaultReasonID")
                    .HasComment("Code specifying the reason the borrower went into default");

                entity.Property(e => e.DeficiencyJudgementCodeId)
                    .HasColumnName("DeficiencyJudgementCodeID")
                    .HasComment("Indicates if HUD authorized a deficiency judgement and if the mortgagee obtained a deficiency judgment");

                entity.Property(e => e.EndorsementDate)
                    .HasColumnType("date")
                    .HasComment("The endorsement date from the mortgage note");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.EstimateOfDamage).HasColumnType("money");

                entity.Property(e => e.ExpDateExtensionToAssign).HasColumnType("date");

                entity.Property(e => e.ExpDateExtensionToForeclose).HasColumnType("date");

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.FirmCommitmentDate)
                    .HasColumnType("date")
                    .HasComment("The date of firm commitment as listed on the firm commitment document");

                entity.Property(e => e.FirstPaymentDueDateModified).HasColumnType("date");

                entity.Property(e => e.FirstPaymentDueDateOriginal)
                    .HasColumnType("date")
                    .HasComment("The due date of the first payment of the mortgage");

                entity.Property(e => e.ForeclosureProceedingsDate)
                    .HasColumnType("date")
                    .HasComment("The date of the first legal action to initiate foreclosure");

                entity.Property(e => e.HipcancelledDate)
                    .HasColumnName("HIPCancelledDate")
                    .HasColumnType("date");

                entity.Property(e => e.HiprefusedDate)
                    .HasColumnName("HIPRefusedDate")
                    .HasColumnType("date");

                entity.Property(e => e.HoldingMortgageeEin)
                    .HasColumnName("HoldingMortgageeEIN")
                    .HasMaxLength(9)
                    .IsUnicode(false);

                entity.Property(e => e.InsuranceRecovery).HasColumnType("money");

                entity.Property(e => e.IsMortgageeSuccessfulBidder).HasComment("Indicates if the mortgagee is the successful bidder at sale");

                entity.Property(e => e.LastCompleteInstallmentPaidDate)
                    .HasColumnType("date")
                    .HasComment("The due date of the last complete installment which was paid");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.MonthlyFhainsurance)
                    .HasColumnName("MonthlyFHAInsurance")
                    .HasColumnType("money")
                    .HasComment("The amount of the monthly FHA Insurance Payment");

                entity.Property(e => e.MonthlyHazardInsurance)
                    .HasColumnType("money")
                    .HasComment("The amount of the monthly Hazard Insurance Payment");

                entity.Property(e => e.MonthlyInterestAndPrincipal)
                    .HasColumnType("money")
                    .HasComment("The amount of the monthly principal & interest Payment");

                entity.Property(e => e.MonthlyTaxes)
                    .HasColumnType("money")
                    .HasComment("The amount of the monthly Tax Payment");

                entity.Property(e => e.MortgageeComments)
                    .HasMaxLength(420)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageeReportedCurtailmentDate)
                    .HasColumnType("date")
                    .HasComment("The date that the Mortgagee first failed to meet a time requirement");

                entity.Property(e => e.NumberOfLivingUnits).HasComment("The number of living units on the property");

                entity.Property(e => e.OccupancyStatusId)
                    .HasColumnName("OccupancyStatusID")
                    .HasComment("specifies if the property is vacant or not");

                entity.Property(e => e.PropertyConditionId)
                    .HasColumnName("PropertyConditionID")
                    .HasComment("specifies if the property is being conveyed damaged");

                entity.Property(e => e.PropertyDescription)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ReleaseOfBankruptcyDate)
                    .HasColumnType("date")
                    .HasComment("The date that the most recent bankruptcy stay was released");

                entity.Property(e => e.UnpaidLoanBalance)
                    .HasColumnType("money")
                    .HasComment("The amount of the principal balance which was unpaid");

                entity.HasOne(d => d.Fhaclaim)
                    .WithOne(p => p.TblPartA27011)
                    .HasForeignKey<TblPartA27011>(d => d.FhaclaimId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_FHAClaims_tbl_PartA27011");
            });

            modelBuilder.Entity<TblPartB27011>(entity =>
            {
                entity.HasKey(e => e.PartB27011id)
                    .HasName("tbl_PartB27011_PK");

                entity.ToTable("tbl_PartB27011");

                entity.HasComment("Contains Part B information for 27011 form.");

                entity.HasIndex(e => e.FhaclaimId)
                    .HasName("UK1_tbl_PartB27011_FHAClaimID")
                    .IsUnique();

                entity.Property(e => e.PartB27011id).HasColumnName("PartB27011ID");

                entity.Property(e => e.Block105Date).HasColumnType("date");

                entity.Property(e => e.Block105TypeId).HasColumnName("Block105TypeID");

                entity.Property(e => e.Block107aAmount).HasColumnType("money");

                entity.Property(e => e.Block107bAmount).HasColumnType("money");

                entity.Property(e => e.Block108TypeId).HasColumnName("Block108TypeID");

                entity.Property(e => e.Block108aAmount).HasColumnType("money");

                entity.Property(e => e.Block109aAmount).HasColumnType("money");

                entity.Property(e => e.Block115aAmount).HasColumnType("money");

                entity.Property(e => e.Block116bAmount).HasColumnType("money");

                entity.Property(e => e.Block118aAmount).HasColumnType("money");

                entity.Property(e => e.Block119aAmount).HasColumnType("money");

                entity.Property(e => e.Block119bAmount).HasColumnType("money");

                entity.Property(e => e.Block121Amount).HasColumnType("money");

                entity.Property(e => e.Block123aAmount).HasColumnType("money");

                entity.Property(e => e.Block123bAmount).HasColumnType("money");

                entity.Property(e => e.Block123cAmount).HasColumnType("money");

                entity.Property(e => e.Block124aAmount).HasColumnType("money");

                entity.Property(e => e.Block124bAmount).HasColumnType("money");

                entity.Property(e => e.Block124cAmount).HasColumnType("money");

                entity.Property(e => e.Block126cAmount).HasColumnType("money");

                entity.Property(e => e.Block132Description)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Block132aAmount).HasColumnType("money");

                entity.Property(e => e.Block132bAmount).HasColumnType("money");

                entity.Property(e => e.Block132cAmount).HasColumnType("money");

                entity.Property(e => e.CurtailmentDateFromAop)
                    .HasColumnName("CurtailmentDateFromAOP")
                    .HasColumnType("date");

                entity.Property(e => e.DateFormPrepared).HasColumnType("date");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.ExpDateToSubmitTitleEvidence).HasColumnType("date");

                entity.Property(e => e.ExpOfExtToSubmitFiscalData).HasColumnType("date");

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.Wksheet119L1amount)
                    .HasColumnName("wksheet119L1Amount")
                    .HasColumnType("money");

                entity.Property(e => e.Wksheet119L2amount)
                    .HasColumnName("wksheet119L2Amount")
                    .HasColumnType("money");

                entity.Property(e => e.Wksheet119L3amount)
                    .HasColumnName("wksheet119L3Amount")
                    .HasColumnType("money");

                entity.Property(e => e.Wksheet121FromDate)
                    .HasColumnName("wksheet121FromDate")
                    .HasColumnType("date");

                entity.Property(e => e.Wksheet121Rate)
                    .HasColumnName("wksheet121Rate")
                    .HasColumnType("decimal(4, 2)");

                entity.Property(e => e.Wksheet121ToDate)
                    .HasColumnName("wksheet121ToDate")
                    .HasColumnType("date");

                entity.HasOne(d => d.Fhaclaim)
                    .WithOne(p => p.TblPartB27011)
                    .HasForeignKey<TblPartB27011>(d => d.FhaclaimId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_FHAClaims_tbl_PartB27011");
            });

            modelBuilder.Entity<TblPartC27011>(entity =>
            {
                entity.HasKey(e => e.PartC27011id);

                entity.ToTable("tbl_PartC27011");

                entity.HasComment("Contains Part C information for 27011 form.");

                entity.HasIndex(e => e.FhaclaimId)
                    .HasName("UK1_tbl_PartC27011_FHAClaimID")
                    .IsUnique();

                entity.Property(e => e.PartC27011id).HasColumnName("PartC27011ID");

                entity.Property(e => e.DateFormPrepared).HasColumnType("date");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.MortgageeComments)
                    .HasMaxLength(700)
                    .IsUnicode(false);

                entity.HasOne(d => d.Fhaclaim)
                    .WithOne(p => p.TblPartC27011)
                    .HasForeignKey<TblPartC27011>(d => d.FhaclaimId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_FHAClaims_tbl_PartC27011");
            });

            modelBuilder.Entity<TblPartD27011>(entity =>
            {
                entity.HasKey(e => e.PartD27011id)
                    .HasName("tbl_PartD27011_PK");

                entity.ToTable("tbl_PartD27011");

                entity.HasComment("Contains Part D information for 27011 form.");

                entity.HasIndex(e => e.FhaclaimId)
                    .HasName("UK1_tbl_PartD27011_FHAClaimID")
                    .IsUnique();

                entity.Property(e => e.PartD27011id).HasColumnName("PartD27011ID");

                entity.Property(e => e.DateFormPrepared).HasColumnType("date");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.HasOne(d => d.Fhaclaim)
                    .WithOne(p => p.TblPartD27011)
                    .HasForeignKey<TblPartD27011>(d => d.FhaclaimId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_FHAClaims_tbl_PartD27011");
            });

            modelBuilder.Entity<TblPartD27011Mipremiums>(entity =>
            {
                entity.HasKey(e => e.MipremiumId)
                    .HasName("tbl_PartD27011_MIPremiums_PK");

                entity.ToTable("tbl_PartD27011_MIPremiums");

                entity.HasComment("Contains MI premium information for Part D of 27011 form.");

                entity.HasIndex(e => new { e.MipremiumId, e.AmountPaid, e.PartD27011id })
                    .HasName("idx_tbl_PartD27011_MIPremiums_PartD27011ID_incl_MIPremiumID_AmountPaid");

                entity.Property(e => e.MipremiumId).HasColumnName("MIPremiumID");

                entity.Property(e => e.AmountPaid).HasColumnType("money");

                entity.Property(e => e.DatePaid).HasColumnType("date");

                entity.Property(e => e.DebentureInterest).HasColumnType("money");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.PartD27011id).HasColumnName("PartD27011ID");

                entity.Property(e => e.PeriodCoveredFrom).HasColumnType("date");

                entity.Property(e => e.PeriodCoveredTo).HasColumnType("date");

                entity.HasOne(d => d.PartD27011)
                    .WithMany(p => p.TblPartD27011Mipremiums)
                    .HasForeignKey(d => d.PartD27011id)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_PartD27011_tbl_PartD27011_MIPremiums");
            });

            modelBuilder.Entity<TblPartD27011MultiBlock>(entity =>
            {
                entity.HasKey(e => e.MultiBlockId)
                    .HasName("tbl_PartD27011_MultiBlock_PK");

                entity.ToTable("tbl_PartD27011_MultiBlock");

                entity.HasComment("Contains multi-block information for Part D of 27011 form.");

                entity.HasIndex(e => e.PartD27011id)
                    .HasName("idx_tbl_PartD27011_MultiBlock_PartD27011ID");

                entity.Property(e => e.MultiBlockId).HasColumnName("MultiBlockID");

                entity.Property(e => e.AmountPaid).HasColumnType("money");

                entity.Property(e => e.DatePaid).HasColumnType("date");

                entity.Property(e => e.DebentureInterest).HasColumnType("money");

                entity.Property(e => e.Description)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.Form27011BlockId).HasColumnName("Form27011BlockID");

                entity.Property(e => e.Hudapproved).HasColumnName("HUDApproved");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.PartD27011id).HasColumnName("PartD27011ID");

                entity.HasOne(d => d.Form27011Block)
                    .WithMany(p => p.TblPartD27011MultiBlock)
                    .HasForeignKey(d => d.Form27011BlockId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_lkp_Form27011Blocks_tbl_PartD27011_MultiBlock");

                entity.HasOne(d => d.PartD27011)
                    .WithMany(p => p.TblPartD27011MultiBlock)
                    .HasForeignKey(d => d.PartD27011id)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_PartD27011_tbl_PartD27011_MultiBlock");
            });

            modelBuilder.Entity<TblPartD27011SpecialAssessments>(entity =>
            {
                entity.HasKey(e => e.SpecialAssessmentsId)
                    .HasName("tbl_PartD27011_SpecialAssessments_PK");

                entity.ToTable("tbl_PartD27011_SpecialAssessments");

                entity.HasComment("Contains special assessments information for Part D of 27011 form.");

                entity.Property(e => e.SpecialAssessmentsId).HasColumnName("SpecialAssessmentsID");

                entity.Property(e => e.AmountPaid).HasColumnType("money");

                entity.Property(e => e.DateLienAttached).HasColumnType("date");

                entity.Property(e => e.DatePaid).HasColumnType("date");

                entity.Property(e => e.DebentureInterest).HasColumnType("money");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.PartD27011id).HasColumnName("PartD27011ID");

                entity.HasOne(d => d.PartD27011)
                    .WithMany(p => p.TblPartD27011SpecialAssessments)
                    .HasForeignKey(d => d.PartD27011id)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_PartD27011_tbl_PartD27011_SpecialAssessments");
            });

            modelBuilder.Entity<TblPartD27011TaxesOnDeed>(entity =>
            {
                entity.HasKey(e => e.TaxOnDeedId)
                    .HasName("tbl_PartD27011_TaxesOnDeed_PK");

                entity.ToTable("tbl_PartD27011_TaxesOnDeed");

                entity.HasComment("Contains taxes on deeds for Part D of 27011 form.");

                entity.Property(e => e.TaxOnDeedId).HasColumnName("TaxOnDeedID");

                entity.Property(e => e.AmountPaid).HasColumnType("money");

                entity.Property(e => e.DatePaid).HasColumnType("date");

                entity.Property(e => e.DebentureInterest).HasColumnType("money");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.PartD27011id).HasColumnName("PartD27011ID");

                entity.Property(e => e.TaxType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ToHud)
                    .HasColumnName("ToHUD")
                    .HasColumnType("money");

                entity.Property(e => e.ToMortgagee).HasColumnType("money");

                entity.HasOne(d => d.PartD27011)
                    .WithMany(p => p.TblPartD27011TaxesOnDeed)
                    .HasForeignKey(d => d.PartD27011id)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_PartD27011_tbl_PartD27011_TaxesOnDeed");
            });

            modelBuilder.Entity<TblPartE27011>(entity =>
            {
                entity.HasKey(e => e.PartE27011id)
                    .HasName("tbl_PartE27011_PK");

                entity.ToTable("tbl_PartE27011");

                entity.HasComment("Contains Part E information for 27011 form.");

                entity.HasIndex(e => e.FhaclaimId)
                    .HasName("UK1_tbl_PartE27011_FHAClaimID")
                    .IsUnique();

                entity.Property(e => e.PartE27011id).HasColumnName("PartE27011ID");

                entity.Property(e => e.DateFormPrepared).HasColumnType("date");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.HasOne(d => d.Fhaclaim)
                    .WithOne(p => p.TblPartE27011)
                    .HasForeignKey<TblPartE27011>(d => d.FhaclaimId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_FHAClaims_tbl_PartE27011");
            });

            modelBuilder.Entity<TblPartE27011MultiBlock>(entity =>
            {
                entity.HasKey(e => e.MultiBlockId)
                    .HasName("tbl_PartE27011_MultiBlock_PK");

                entity.ToTable("tbl_PartE27011_MultiBlock");

                entity.HasComment("Contains multi-block information for Part E of 27011 form.");

                entity.Property(e => e.MultiBlockId).HasColumnName("MultiBlockID");

                entity.Property(e => e.AmountPaid).HasColumnType("money");

                entity.Property(e => e.DatePaid).HasColumnType("date");

                entity.Property(e => e.DebentureInterest).HasColumnType("money");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.Form27011BlockId).HasColumnName("Form27011BlockID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.PartE27011id).HasColumnName("PartE27011ID");

                entity.HasOne(d => d.Form27011Block)
                    .WithMany(p => p.TblPartE27011MultiBlock)
                    .HasForeignKey(d => d.Form27011BlockId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_lkp_Form27011Blocks_tbl_PartE_MultiBlock");

                entity.HasOne(d => d.PartE27011)
                    .WithMany(p => p.TblPartE27011MultiBlock)
                    .HasForeignKey(d => d.PartE27011id)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_PartE27011_tbl_PartE_MultiBlock");
            });

            modelBuilder.Entity<TblPendingTaldocument>(entity =>
            {
                entity.HasKey(e => e.PendingTaldocumentId);

                entity.ToTable("tbl_PendingTALDocument");

                entity.HasComment("Empty table.");

                entity.Property(e => e.PendingTaldocumentId).HasColumnName("PendingTALDocumentID");

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.HasOne(d => d.Fhaclaim)
                    .WithMany(p => p.TblPendingTaldocument)
                    .HasForeignKey(d => d.FhaclaimId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tbl_PendingTALDocument_tbl_FHAClaims1");
            });

            modelBuilder.Entity<TblProtectionPreservationDisbursements>(entity =>
            {
                entity.HasKey(e => e.ProtectionPreservationDisbursementId);

                entity.ToTable("tbl_ProtectionPreservationDisbursements");

                entity.HasComment("Contains Protection preservation disbursement records.");

                entity.HasIndex(e => new { e.AmountPaid, e.ProtectionPreservationDisbursementId, e.PartC27011id })
                    .HasName("idx_tbl_ProtectionPreservationDisbursements_PartC27011ID_incl_ProtectionPreservationDisbursementID_AmountPaid");

                entity.Property(e => e.ProtectionPreservationDisbursementId).HasColumnName("ProtectionPreservationDisbursementID");

                entity.Property(e => e.AmountPaid).HasColumnType("money");

                entity.Property(e => e.DatePaid).HasColumnType("date");

                entity.Property(e => e.DateWorkCompleted).HasColumnType("date");

                entity.Property(e => e.DebentureInterest).HasColumnType("money");

                entity.Property(e => e.DescriptionOfServicesPerformed)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.Hudapproved).HasColumnName("HUDApproved");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.PartC27011id).HasColumnName("PartC27011ID");

                entity.HasOne(d => d.PartC27011)
                    .WithMany(p => p.TblProtectionPreservationDisbursements)
                    .HasForeignKey(d => d.PartC27011id)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_PartC27011_tbl_ProtectionPreservationDisbursements");
            });

            modelBuilder.Entity<TblScanLog>(entity =>
            {
                entity.HasKey(e => e.ClaimScanId);

                entity.ToTable("tbl_ScanLog");

                entity.HasComment("Contains records of scan logs.");

                entity.Property(e => e.ClaimScanId).HasColumnName("ClaimScanID");

                entity.Property(e => e.Block305Deb).HasColumnType("money");

                entity.Property(e => e.Block305Paid).HasColumnType("money");

                entity.Property(e => e.Block306Deb).HasColumnType("money");

                entity.Property(e => e.Block306Paid).HasColumnType("money");

                entity.Property(e => e.Block307Deb).HasColumnType("money");

                entity.Property(e => e.Block307Paid).HasColumnType("money");

                entity.Property(e => e.Block308Deb).HasColumnType("money");

                entity.Property(e => e.Block308Paid).HasColumnType("money");

                entity.Property(e => e.Block309Deb).HasColumnType("money");

                entity.Property(e => e.Block309Paid).HasColumnType("money");

                entity.Property(e => e.Block310Deb).HasColumnType("money");

                entity.Property(e => e.Block310Paid).HasColumnType("money");

                entity.Property(e => e.Block311Deb).HasColumnType("money");

                entity.Property(e => e.Block311Paid).HasColumnType("money");

                entity.Property(e => e.Block405Deb).HasColumnType("money");

                entity.Property(e => e.Block405Paid).HasColumnType("money");

                entity.Property(e => e.Block406Deb).HasColumnType("money");

                entity.Property(e => e.Block406Paid).HasColumnType("money");

                entity.Property(e => e.Block407Deb).HasColumnType("money");

                entity.Property(e => e.Block407Paid).HasColumnType("money");

                entity.Property(e => e.Block408Deb).HasColumnType("money");

                entity.Property(e => e.Block408Paid).HasColumnType("money");

                entity.Property(e => e.Block409Deb).HasColumnType("money");

                entity.Property(e => e.Block409Paid).HasColumnType("money");

                entity.Property(e => e.Block410Deb).HasColumnType("money");

                entity.Property(e => e.Block410Paid).HasColumnType("money");

                entity.Property(e => e.Exception)
                    .HasColumnName("exception")
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.FhacaseNumber)
                    .HasColumnName("FHACaseNumber")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.FileName)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.PartCdeb)
                    .HasColumnName("PartCDeb")
                    .HasColumnType("money");

                entity.Property(e => e.PartClineCount).HasColumnName("PartCLineCount");

                entity.Property(e => e.PartCpaid)
                    .HasColumnName("PartCPaid")
                    .HasColumnType("money");

                entity.Property(e => e.RunDate).HasColumnType("datetime");
            });

         

            modelBuilder.Entity<VwFhaAdjustmentMessages>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_AdjustmentMessages");

                entity.Property(e => e.AdjustmentCode)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.AdjustmentMessage)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.AlternateMesssage)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.FhalookupId).HasColumnName("FHALookupID");

                entity.Property(e => e.LineBlock)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwFhaBlock105Types>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_Block105Types");

                entity.Property(e => e.Block105Description)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.Block105TypeId)
                    .HasColumnName("Block105TypeID")
                    .ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VwFhaBlock108Types>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_Block108Types");

                entity.Property(e => e.Block108Description)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.Block108TypeId)
                    .HasColumnName("Block108TypeID")
                    .ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VwFhaBlock10Types>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_Block10Types");

                entity.Property(e => e.Block10Description)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.Block10TypeId)
                    .HasColumnName("Block10TypeID")
                    .ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VwFhaBlock305>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_Block305");

                entity.Property(e => e.AmountPaid).HasColumnType("money");

                entity.Property(e => e.Block305Id).HasColumnName("Block305ID");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.CurtailDateForDi)
                    .HasColumnName("CurtailDateForDI")
                    .HasColumnType("date");

                entity.Property(e => e.DatePaid).HasColumnType("date");

                entity.Property(e => e.DebentureInterest).HasColumnType("money");

                entity.Property(e => e.DebentureInterestCalc).HasColumnType("money");

                entity.Property(e => e.DebentureInterestRate).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.Description)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.Form27011BlockId).HasColumnName("Form27011BlockID");

                entity.Property(e => e.FormDescription)
                    .HasMaxLength(8000)
                    .IsUnicode(false);

                entity.Property(e => e.Hudapproved).HasColumnName("HUDApproved");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.PartD27011id).HasColumnName("PartD27011ID");
            });

            modelBuilder.Entity<VwFhaBlock305Description>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_Block305Description");

                entity.Property(e => e.Lutext)
                    .HasColumnName("LUText")
                    .HasMaxLength(300)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwFhaBlock306>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_Block306");

                entity.Property(e => e.AmountPaid).HasColumnType("money");

                entity.Property(e => e.Block306Id).HasColumnName("Block306ID");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.CurtailDateForDi)
                    .HasColumnName("CurtailDateForDI")
                    .HasColumnType("date");

                entity.Property(e => e.DatePaid).HasColumnType("date");

                entity.Property(e => e.DebentureInterest).HasColumnType("money");

                entity.Property(e => e.DebentureInterestCalc).HasColumnType("money");

                entity.Property(e => e.DebentureInterestRate).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.Description)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.Form27011BlockId).HasColumnName("Form27011BlockID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.PartD27011id).HasColumnName("PartD27011ID");
            });

            modelBuilder.Entity<VwFhaBlock306Description>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_Block306Description");

                entity.Property(e => e.Lutext)
                    .HasColumnName("LUText")
                    .HasMaxLength(300)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwFhaBlock307>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_Block307");

                entity.Property(e => e.AmountPaid).HasColumnType("money");

                entity.Property(e => e.Block307Id).HasColumnName("Block307ID");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.CurtailDateForDi)
                    .HasColumnName("CurtailDateForDI")
                    .HasColumnType("date");

                entity.Property(e => e.DatePaid).HasColumnType("date");

                entity.Property(e => e.DebentureInterest).HasColumnType("money");

                entity.Property(e => e.DebentureInterestCalc).HasColumnType("money");

                entity.Property(e => e.DebentureInterestRate).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.Description)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.Form27011BlockId).HasColumnName("Form27011BlockID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.PartD27011id).HasColumnName("PartD27011ID");
            });

            modelBuilder.Entity<VwFhaBlock307Description>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_Block307Description");

                entity.Property(e => e.Lutext)
                    .HasColumnName("LUText")
                    .HasMaxLength(300)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwFhaBlock308>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_Block308");

                entity.Property(e => e.AmountPaid).HasColumnType("money");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.CurtailDateForDi)
                    .HasColumnName("CurtailDateForDI")
                    .HasColumnType("date");

                entity.Property(e => e.DatePaid).HasColumnType("date");

                entity.Property(e => e.DebentureInterest).HasColumnType("money");

                entity.Property(e => e.DebentureInterestCalc).HasColumnType("money");

                entity.Property(e => e.DebentureInterestRate).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.PartD27011id).HasColumnName("PartD27011ID");

                entity.Property(e => e.TaxOnDeedId).HasColumnName("TaxOnDeedID");

                entity.Property(e => e.TaxType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ToHud)
                    .HasColumnName("ToHUD")
                    .HasColumnType("money");

                entity.Property(e => e.ToMortgagee).HasColumnType("money");
            });

            modelBuilder.Entity<VwFhaBlock308Description>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_Block308Description");

                entity.Property(e => e.Lutext)
                    .HasColumnName("LUText")
                    .HasMaxLength(300)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwFhaBlock309>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_Block309");

                entity.Property(e => e.AmountPaid).HasColumnType("money");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.CurtailDateForDi)
                    .HasColumnName("CurtailDateForDI")
                    .HasColumnType("date");

                entity.Property(e => e.DateLienAttached).HasColumnType("date");

                entity.Property(e => e.DatePaid).HasColumnType("date");

                entity.Property(e => e.DebentureInterest).HasColumnType("money");

                entity.Property(e => e.DebentureInterestCalc).HasColumnType("money");

                entity.Property(e => e.DebentureInterestRate).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.PartD27011id).HasColumnName("PartD27011ID");

                entity.Property(e => e.SpecialAssessmentsId).HasColumnName("SpecialAssessmentsID");
            });

            modelBuilder.Entity<VwFhaBlock310>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_Block310");

                entity.Property(e => e.AmountPaid).HasColumnType("money");

                entity.Property(e => e.Block310Id).HasColumnName("Block310ID");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.CurtailDateForDi)
                    .HasColumnName("CurtailDateForDI")
                    .HasColumnType("date");

                entity.Property(e => e.DatePaid).HasColumnType("date");

                entity.Property(e => e.DebentureInterest).HasColumnType("money");

                entity.Property(e => e.DebentureInterestCalc).HasColumnType("money");

                entity.Property(e => e.DebentureInterestRate).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.Description)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.Form27011BlockId).HasColumnName("Form27011BlockID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.PartD27011id).HasColumnName("PartD27011ID");
            });

            modelBuilder.Entity<VwFhaBlock311>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_Block311");

                entity.Property(e => e.AmountPaid).HasColumnType("money");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.CurtailDateForDi)
                    .HasColumnName("CurtailDateForDI")
                    .HasColumnType("date");

                entity.Property(e => e.DatePaid).HasColumnType("date");

                entity.Property(e => e.DebentureInterest).HasColumnType("money");

                entity.Property(e => e.DebentureInterestCalc).HasColumnType("money");

                entity.Property(e => e.DebentureInterestRate).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.MipremiumId).HasColumnName("MIPremiumID");

                entity.Property(e => e.PartD27011id).HasColumnName("PartD27011ID");

                entity.Property(e => e.PeriodCoveredFrom).HasColumnType("date");

                entity.Property(e => e.PeriodCoveredTo).HasColumnType("date");
            });

            modelBuilder.Entity<VwFhaBlock405>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_Block405");

                entity.Property(e => e.AmountPaid).HasColumnType("money");

                entity.Property(e => e.Block405Id).HasColumnName("Block405ID");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.CurtailDateForDi)
                    .HasColumnName("CurtailDateForDI")
                    .HasColumnType("date");

                entity.Property(e => e.DatePaid).HasColumnType("date");

                entity.Property(e => e.DebentureInterest).HasColumnType("money");

                entity.Property(e => e.DebentureInterestCalc).HasColumnType("money");

                entity.Property(e => e.DebentureInterestRate).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.Form27011BlockId).HasColumnName("Form27011BlockID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.PartE27011id).HasColumnName("PartE27011ID");
            });

            modelBuilder.Entity<VwFhaBlock406>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_Block406");

                entity.Property(e => e.AmountPaid).HasColumnType("money");

                entity.Property(e => e.Block406Id).HasColumnName("Block406ID");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.CurtailDateForDi)
                    .HasColumnName("CurtailDateForDI")
                    .HasColumnType("date");

                entity.Property(e => e.DatePaid).HasColumnType("date");

                entity.Property(e => e.DebentureInterest).HasColumnType("money");

                entity.Property(e => e.DebentureInterestCalc).HasColumnType("money");

                entity.Property(e => e.DebentureInterestRate).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.Form27011BlockId).HasColumnName("Form27011BlockID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.PartE27011id).HasColumnName("PartE27011ID");
            });

            modelBuilder.Entity<VwFhaBlock407>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_Block407");

                entity.Property(e => e.AmountPaid).HasColumnType("money");

                entity.Property(e => e.Block407Id).HasColumnName("Block407ID");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.CurtailDateForDi)
                    .HasColumnName("CurtailDateForDI")
                    .HasColumnType("date");

                entity.Property(e => e.DatePaid).HasColumnType("date");

                entity.Property(e => e.DebentureInterest).HasColumnType("money");

                entity.Property(e => e.DebentureInterestCalc).HasColumnType("money");

                entity.Property(e => e.DebentureInterestRate).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.Form27011BlockId).HasColumnName("Form27011BlockID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.PartE27011id).HasColumnName("PartE27011ID");
            });

            modelBuilder.Entity<VwFhaBlock408>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_Block408");

                entity.Property(e => e.AmountPaid).HasColumnType("money");

                entity.Property(e => e.Block408Id).HasColumnName("Block408ID");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.CurtailDateForDi)
                    .HasColumnName("CurtailDateForDI")
                    .HasColumnType("date");

                entity.Property(e => e.DatePaid).HasColumnType("date");

                entity.Property(e => e.DebentureInterest).HasColumnType("money");

                entity.Property(e => e.DebentureInterestCalc).HasColumnType("money");

                entity.Property(e => e.DebentureInterestRate).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.Form27011BlockId).HasColumnName("Form27011BlockID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.PartE27011id).HasColumnName("PartE27011ID");
            });

            modelBuilder.Entity<VwFhaBlock409>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_Block409");

                entity.Property(e => e.AmountPaid).HasColumnType("money");

                entity.Property(e => e.Block409Id).HasColumnName("Block409ID");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.CurtailDateForDi)
                    .HasColumnName("CurtailDateForDI")
                    .HasColumnType("date");

                entity.Property(e => e.DatePaid).HasColumnType("date");

                entity.Property(e => e.DebentureInterest).HasColumnType("money");

                entity.Property(e => e.DebentureInterestCalc).HasColumnType("money");

                entity.Property(e => e.DebentureInterestRate).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.Form27011BlockId).HasColumnName("Form27011BlockID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.PartE27011id).HasColumnName("PartE27011ID");
            });

            modelBuilder.Entity<VwFhaBlock410>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_Block410");

                entity.Property(e => e.AmountPaid).HasColumnType("money");

                entity.Property(e => e.Block410Id).HasColumnName("Block410ID");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.CurtailDateForDi)
                    .HasColumnName("CurtailDateForDI")
                    .HasColumnType("date");

                entity.Property(e => e.DatePaid).HasColumnType("date");

                entity.Property(e => e.DebentureInterest).HasColumnType("money");

                entity.Property(e => e.DebentureInterestCalc).HasColumnType("money");

                entity.Property(e => e.DebentureInterestRate).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.Form27011BlockId).HasColumnName("Form27011BlockID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.PartE27011id).HasColumnName("PartE27011ID");
            });

            modelBuilder.Entity<VwFhaBlock9Types>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_Block9Types");

                entity.Property(e => e.Block9Description)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.Block9TypeId)
                    .HasColumnName("Block9TypeID")
                    .ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VwFhaClaimStatus>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_ClaimStatus");

                entity.Property(e => e.ClaimStatus)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimStatusId)
                    .HasColumnName("ClaimStatusID")
                    .ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VwFhaClaimTypes>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_ClaimTypes");

                entity.Property(e => e.ClaimTypeCode)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimTypeId)
                    .HasColumnName("ClaimTypeID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.ClaimTypeName)
                    .HasMaxLength(300)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwFhaClients>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_Clients");

                entity.Property(e => e.ClientName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CmsclientId).HasColumnName("CMSClientID");

                entity.Property(e => e.EnableHudEdi).HasColumnName("Enable_HUD_EDI");

                entity.Property(e => e.FhaclientId).HasColumnName("FHAClientID");
            });

            modelBuilder.Entity<VwFhaDamageTypes>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_DamageTypes");

                entity.Property(e => e.DamageName)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.DamageTypeCode)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.DamageTypeId)
                    .HasColumnName("DamageTypeID")
                    .ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VwFhaDefaultReasons>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_DefaultReasons");

                entity.Property(e => e.DefaultReasonCode)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DefaultReasonDescription)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.DefaultReasonId)
                    .HasColumnName("DefaultReasonID")
                    .ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VwFhaDeficiencyJudgementCodes>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_DeficiencyJudgementCodes");

                entity.Property(e => e.DeficiencyJudgementCode)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.DeficiencyJudgementCodeId)
                    .HasColumnName("DeficiencyJudgementCodeID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.DeficiencyJudgementDescription)
                    .HasMaxLength(300)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwFhaEdiDefaultReasons>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_EDI_DefaultReasons");

                entity.Property(e => e.DefaultReasonCode)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.DefaultReasonDescription)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.DefaultReasonId)
                    .HasColumnName("DefaultReasonID")
                    .ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VwFhaErrorCodes>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_ErrorCodes");

                entity.Property(e => e.ErrorCode)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ErrorDescription)
                    .IsRequired()
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.ErrorId)
                    .HasColumnName("ErrorID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.ErrorType)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwFhaMortgagors>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_Mortgagors");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.FhaloanId).HasColumnName("FHALoanID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.MortgagorFirstName)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorId).HasColumnName("MortgagorID");

                entity.Property(e => e.MortgagorLastName)
                    .HasMaxLength(35)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorMiddleName)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.Prefix)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Ssn)
                    .HasColumnName("SSN")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.Suffix)
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwFhaOccupancyStatusCodes>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_OccupancyStatusCodes");

                entity.Property(e => e.OccupancyStatusCode)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.OccupancyStatusDescription)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.OccupancyStatusId)
                    .HasColumnName("OccupancyStatusID")
                    .ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VwFhaPpddescription>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_PPDDescription");

                entity.Property(e => e.Lutext)
                    .HasColumnName("LUText")
                    .HasMaxLength(300)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwFhaPropertyConditionCodes>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_PropertyConditionCodes");

                entity.Property(e => e.PropertyConditionCode)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyConditionDescription)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyConditionId)
                    .HasColumnName("PropertyConditionID")
                    .ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VwFhaProtectionPreservationDisbursements>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_ProtectionPreservationDisbursements");

                entity.Property(e => e.AmountPaid).HasColumnType("money");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.CurtailDateForDi)
                    .HasColumnName("CurtailDateForDI")
                    .HasColumnType("date");

                entity.Property(e => e.DatePaid).HasColumnType("date");

                entity.Property(e => e.DateWorkCompleted).HasColumnType("date");

                entity.Property(e => e.DebentureInterest).HasColumnType("money");

                entity.Property(e => e.DebentureInterestCalc).HasColumnType("money");

                entity.Property(e => e.DebentureInterestRate).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.DescriptionOfServicesPerformed)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.FormDescription)
                    .HasMaxLength(8000)
                    .IsUnicode(false);

                entity.Property(e => e.Hudapproved).HasColumnName("HUDApproved");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.PartC27011id).HasColumnName("PartC27011ID");

                entity.Property(e => e.ProtectionPreservationDisbursementId).HasColumnName("ProtectionPreservationDisbursementID");
            });

            modelBuilder.Entity<VwFhaSectionsOfTheAct>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_SectionsOfTheAct");

                entity.Property(e => e.Adpcode)
                    .HasColumnName("ADPCode")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.SectionOfTheActCode)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SectionOfTheActDescription)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.SectionOfTheActId)
                    .HasColumnName("SectionOfTheActID")
                    .ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VwFhaServicerHolderMatrix>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_ServicerHolder_Matrix");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.HolderId).HasColumnName("HolderID");

                entity.Property(e => e.HolderName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HoldingMortgageeNumber)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerHolderXrefId).HasColumnName("Servicer_Holder_xrefID");

                entity.Property(e => e.ServicerId).HasColumnName("ServicerID");

                entity.Property(e => e.ServicerName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ServicingMortageeNumber)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwFhaStates>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_States");

                entity.Property(e => e.StateCode)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.StateId)
                    .HasColumnName("StateID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.StateName)
                    .IsRequired()
                    .HasMaxLength(150)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwFhaTaxSchedule>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_TaxSchedule");

                entity.Property(e => e.AmountPaid).HasColumnType("money");

                entity.Property(e => e.CollectorPropertyIdentification)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DatePaid).HasColumnType("date");

                entity.Property(e => e.EndDate).HasColumnType("date");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.PartA27011id).HasColumnName("PartA27011ID");

                entity.Property(e => e.StartDate).HasColumnType("date");

                entity.Property(e => e.TaxScheduleId)
                    .HasColumnName("TaxScheduleID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.TaxType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwFhaTs997ackCodes>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHA_TS997AckCodes");

                entity.Property(e => e.HudackCode)
                    .HasColumnName("HUDAckCode")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.HudackCodeDescription)
                    .HasColumnName("HUDAckCodeDescription")
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.HudackCodeId)
                    .HasColumnName("HUDAckCodeID")
                    .ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VwFhalivingUnits>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_FHALivingUnits");

                entity.Property(e => e.DateSecured).HasColumnType("date");

                entity.Property(e => e.DateVacated).HasColumnType("date");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LivingUnitId)
                    .HasColumnName("LivingUnitID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.OccupantName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PartA27011id).HasColumnName("PartA27011ID");
            });

            modelBuilder.Entity<VwHudClaimStatus>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_HUD_Claim_Status");

                entity.Property(e => e.ClaimStatus)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");
            });

            modelBuilder.Entity<VwHudInitialInput>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_HUD_InitialInput");

                entity.Property(e => e.AuthorizedBidAmount).HasColumnType("money");

                entity.Property(e => e.ClaimType)
                    .HasColumnName("Claim Type")
                    .HasMaxLength(333)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CurtailDateForDi)
                    .HasColumnName("CurtailDateForDI")
                    .HasColumnType("date");

                entity.Property(e => e.DateOfNoticeToConvey).HasColumnType("date");

                entity.Property(e => e.DebentureInterestRate).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.DebentureInterestRateCalc).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.DebentureStartDate).HasColumnType("date");

                entity.Property(e => e.DefaultDate).HasColumnType("date");

                entity.Property(e => e.EndorsementDate).HasColumnType("date");

                entity.Property(e => e.FhacaseNumber)
                    .IsRequired()
                    .HasColumnName("FHACaseNumber")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.FhaclientId).HasColumnName("FHAClientID");

                entity.Property(e => e.FhaloanId).HasColumnName("FHALoanID");

                entity.Property(e => e.FinalSettlementDate).HasColumnType("datetime");

                entity.Property(e => e.HoldingMortgageeNumber)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.LastArmrate)
                    .HasColumnName("LastARMRate")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.McdequalCurtailDateForDi).HasColumnName("MCDEqualCurtailDateForDI");

                entity.Property(e => e.ModifiedInterestRate).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.MortgageeId).HasColumnName("MortgageeID");

                entity.Property(e => e.MortgageeLoanNumber)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageeName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageeReportedCurtailmentDate).HasColumnType("date");

                entity.Property(e => e.MortgagorFullName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NewMaturityDate).HasColumnType("date");

                entity.Property(e => e.NoteRate).HasColumnType("decimal(18, 5)");

                entity.Property(e => e.OriginalMortgageAmount).HasColumnType("money");

                entity.Property(e => e.PartAformPrepared)
                    .HasColumnName("PartAFormPrepared")
                    .HasColumnType("date");

                entity.Property(e => e.PartBformPrepared)
                    .HasColumnName("PartBFormPrepared")
                    .HasColumnType("date");

                entity.Property(e => e.PropertyAddress1)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyAddress2)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyStateCode)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SecondChanceSaleDate).HasColumnType("date");

                entity.Property(e => e.SectionOfTheActCode)
                    .HasMaxLength(333)
                    .IsUnicode(false);

                entity.Property(e => e.SectionOfTheActId).HasColumnName("SectionOfTheActID");

                entity.Property(e => e.ServicerId).HasColumnName("ServicerID");

                entity.Property(e => e.ServicerName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ServicingMortageeNumber)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SuccessfulBidAmount).HasColumnType("money");

                entity.Property(e => e.UnpaidLoanBalance).HasColumnType("money");
            });

            modelBuilder.Entity<VwHudPartA>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_HUD_PartA");

                entity.Property(e => e.AuthorizedBidAmount).HasColumnType("money");

                entity.Property(e => e.BankruptcyDateFiled).HasColumnType("date");

                entity.Property(e => e.Block10Date).HasColumnType("date");

                entity.Property(e => e.Block10TypeId).HasColumnName("Block10TypeID");

                entity.Property(e => e.Block11DateofDil).HasColumnName("Block11DateofDIL");

                entity.Property(e => e.Block15Modified).HasColumnType("money");

                entity.Property(e => e.Block15Original).HasColumnType("money");

                entity.Property(e => e.Block19Date).HasColumnType("date");

                entity.Property(e => e.Block20Date).HasColumnType("date");

                entity.Property(e => e.Block9Date).HasColumnType("date");

                entity.Property(e => e.Block9TypeId).HasColumnName("Block9TypeID");

                entity.Property(e => e.ClaimType)
                    .HasMaxLength(333)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.ClaimTypeText)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DamageCode)
                    .HasMaxLength(333)
                    .IsUnicode(false);

                entity.Property(e => e.DamageTypeId).HasColumnName("DamageTypeID");

                entity.Property(e => e.DateAssignmentFiledForRecord).HasColumnType("date");

                entity.Property(e => e.DateDamaged).HasColumnType("date");

                entity.Property(e => e.DateDeedFiledForRecord).HasColumnType("date");

                entity.Property(e => e.DateFormPrepared).HasColumnType("date");

                entity.Property(e => e.DateLocalOfficeApprovalConveyanceDamaged).HasColumnType("date");

                entity.Property(e => e.DateLocalOfficeApprovalConveyanceOccupied).HasColumnType("date");

                entity.Property(e => e.DateLocalOfficeCertificationConveyanceDamaged).HasColumnType("date");

                entity.Property(e => e.DateOfAcquisitionOfTitle).HasColumnType("date");

                entity.Property(e => e.DateOfAppraisal).HasColumnType("date");

                entity.Property(e => e.DateOfClosing).HasColumnType("date");

                entity.Property(e => e.DateOfDeedInLieu).HasColumnType("date");

                entity.Property(e => e.DateOfExtensionToConvey).HasColumnType("date");

                entity.Property(e => e.DateOfNoticeToConvey).HasColumnType("date");

                entity.Property(e => e.DateOfPossession).HasColumnType("date");

                entity.Property(e => e.DebentureInterestRate).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.DefaultReason)
                    .HasMaxLength(353)
                    .IsUnicode(false);

                entity.Property(e => e.DefaultReasonId).HasColumnName("DefaultReasonID");

                entity.Property(e => e.DefficiendyJudgementCode)
                    .HasMaxLength(333)
                    .IsUnicode(false);

                entity.Property(e => e.DeficiencyJudgement)
                    .HasMaxLength(333)
                    .IsUnicode(false);

                entity.Property(e => e.DeficiencyJudgementCodeId).HasColumnName("DeficiencyJudgementCodeID");

                entity.Property(e => e.EndorsementDate).HasColumnType("date");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.EstimateOfDamage).HasColumnType("money");

                entity.Property(e => e.ExpDateExtensionToAssign).HasColumnType("date");

                entity.Property(e => e.ExpDateExtensionToForeclose).HasColumnType("date");

                entity.Property(e => e.FhacaseNumber)
                    .IsRequired()
                    .HasColumnName("FHACaseNumber")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.FhaclientId).HasColumnName("FHAClientID");

                entity.Property(e => e.FhaloanId).HasColumnName("FHALoanID");

                entity.Property(e => e.FirmCommitmentDate).HasColumnType("date");

                entity.Property(e => e.FirstPaymentDueDateModified).HasColumnType("date");

                entity.Property(e => e.FirstPaymentDueDateOriginal).HasColumnType("date");

                entity.Property(e => e.ForeclosureProceedingsDate).HasColumnType("date");

                entity.Property(e => e.HipcancelledDate)
                    .HasColumnName("HIPCancelledDate")
                    .HasColumnType("date");

                entity.Property(e => e.HiprefusedDate)
                    .HasColumnName("HIPRefusedDate")
                    .HasColumnType("date");

                entity.Property(e => e.HoldingMortgageeEin)
                    .HasColumnName("HoldingMortgageeEIN")
                    .HasMaxLength(9)
                    .IsUnicode(false);

                entity.Property(e => e.HoldingMortgageeNumber)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.InsuranceRecovery).HasColumnType("money");

                entity.Property(e => e.LastArmrate)
                    .HasColumnName("LastARMRate")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.LastCompleteInstallmentPaidDate).HasColumnType("date");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedInterestRate).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.MonthlyFhainsurance)
                    .HasColumnName("MonthlyFHAInsurance")
                    .HasColumnType("money");

                entity.Property(e => e.MonthlyHazardInsurance).HasColumnType("money");

                entity.Property(e => e.MonthlyInterestAndPrincipal).HasColumnType("money");

                entity.Property(e => e.MonthlyTaxes).HasColumnType("money");

                entity.Property(e => e.MortgageeAddress)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageeCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageeComments)
                    .HasMaxLength(420)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageeId).HasColumnName("MortgageeID");

                entity.Property(e => e.MortgageeLoanNumber)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageeName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageeReportedCurtailmentDate).HasColumnType("date");

                entity.Property(e => e.MortgageeStateCode)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageeZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorFirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorFullName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorLastName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorMiddleName)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorSsn)
                    .HasColumnName("MortgagorSSN")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NewMaturityDate).HasColumnType("date");

                entity.Property(e => e.OccupancyStatus)
                    .HasMaxLength(333)
                    .IsUnicode(false);

                entity.Property(e => e.OccupancyStatusId).HasColumnName("OccupancyStatusID");

                entity.Property(e => e.OrigMtgAmt).HasColumnType("money");

                entity.Property(e => e.PartA27011id).HasColumnName("PartA27011ID");

                entity.Property(e => e.PropertyAddress1)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyAddress2)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyCondition)
                    .HasMaxLength(333)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyConditionId).HasColumnName("PropertyConditionID");

                entity.Property(e => e.PropertyDescription)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyStateCode)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ReleaseOfBankruptcyDate).HasColumnType("date");

                entity.Property(e => e.SectionOfTheAct)
                    .HasMaxLength(333)
                    .IsUnicode(false);

                entity.Property(e => e.SectionOfTheActCode)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.SectionOfTheActId).HasColumnName("SectionOfTheActID");

                entity.Property(e => e.ServicerAddress)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerId).HasColumnName("ServicerID");

                entity.Property(e => e.ServicerName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerStateCode)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ServicingMortageeNumber)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.UnpaidLoanBalance).HasColumnType("money");
            });

            modelBuilder.Entity<VwHudPartB>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_HUD_PartB");

                entity.Property(e => e.Block105Date).HasColumnType("date");

                entity.Property(e => e.Block105TypeId).HasColumnName("Block105TypeID");

                entity.Property(e => e.Block107aAmount).HasColumnType("money");

                entity.Property(e => e.Block107bAmount).HasColumnType("money");

                entity.Property(e => e.Block108TypeId).HasColumnName("Block108TypeID");

                entity.Property(e => e.Block108aAmount).HasColumnType("money");

                entity.Property(e => e.Block109aAmount).HasColumnType("money");

                entity.Property(e => e.Block110b).HasColumnType("money");

                entity.Property(e => e.Block110c).HasColumnType("money");

                entity.Property(e => e.Block111b).HasColumnType("money");

                entity.Property(e => e.Block111c).HasColumnType("money");

                entity.Property(e => e.Block112b).HasColumnType("money");

                entity.Property(e => e.Block112c).HasColumnType("money");

                entity.Property(e => e.Block113b).HasColumnType("money");

                entity.Property(e => e.Block113c).HasColumnType("money");

                entity.Property(e => e.Block114b).HasColumnType("money");

                entity.Property(e => e.Block114c).HasColumnType("money");

                entity.Property(e => e.Block115aAmount).HasColumnType("money");

                entity.Property(e => e.Block116bAmount).HasColumnType("money");

                entity.Property(e => e.Block117b).HasColumnType("money");

                entity.Property(e => e.Block117c).HasColumnType("money");

                entity.Property(e => e.Block118aAmount).HasColumnType("money");

                entity.Property(e => e.Block119aAmount).HasColumnType("money");

                entity.Property(e => e.Block119bAmount).HasColumnType("money");

                entity.Property(e => e.Block120b).HasColumnType("money");

                entity.Property(e => e.Block120c).HasColumnType("money");

                entity.Property(e => e.Block121Amount).HasColumnType("money");

                entity.Property(e => e.Block122b).HasColumnType("money");

                entity.Property(e => e.Block122c).HasColumnType("money");

                entity.Property(e => e.Block123aAmount).HasColumnType("money");

                entity.Property(e => e.Block123bAmount).HasColumnType("money");

                entity.Property(e => e.Block123cAmount).HasColumnType("money");

                entity.Property(e => e.Block124aAmount).HasColumnType("money");

                entity.Property(e => e.Block124bAmount).HasColumnType("money");

                entity.Property(e => e.Block124cAmount).HasColumnType("money");

                entity.Property(e => e.Block125b).HasColumnType("money");

                entity.Property(e => e.Block125c).HasColumnType("money");

                entity.Property(e => e.Block126cAmount).HasColumnType("money");

                entity.Property(e => e.Block127a).HasColumnType("money");

                entity.Property(e => e.Block128b).HasColumnType("money");

                entity.Property(e => e.Block129b).HasColumnType("money");

                entity.Property(e => e.Block130b).HasColumnType("money");

                entity.Property(e => e.Block130c).HasColumnType("money");

                entity.Property(e => e.Block131b).HasColumnType("money");

                entity.Property(e => e.Block131c).HasColumnType("money");

                entity.Property(e => e.Block132Description)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Block132aAmount).HasColumnType("money");

                entity.Property(e => e.Block132bAmount).HasColumnType("money");

                entity.Property(e => e.Block132cAmount).HasColumnType("money");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.ClaimTypeText)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CurtailmentDateFromAop)
                    .HasColumnName("CurtailmentDateFromAOP")
                    .HasColumnType("date");

                entity.Property(e => e.DateFormPrepared).HasColumnType("date");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.ExpDateToSubmitTitleEvidence).HasColumnType("date");

                entity.Property(e => e.ExpOfExtToSubmitFiscalData).HasColumnType("date");

                entity.Property(e => e.FhacaseNumber)
                    .IsRequired()
                    .HasColumnName("FHACaseNumber")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.FhaclientId).HasColumnName("FHAClientID");

                entity.Property(e => e.FhaloanId).HasColumnName("FHALoanID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.MortgageeId).HasColumnName("MortgageeID");

                entity.Property(e => e.MortgageeLoanNumber)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageeName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorFirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorLastName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorMiddleName)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.PartB27011id).HasColumnName("PartB27011ID");

                entity.Property(e => e.PropertyAddress1)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyAddress2)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyStateCode)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SectionOfAct)
                    .HasMaxLength(333)
                    .IsUnicode(false);

                entity.Property(e => e.SectionOfActCode)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.SectionOfTheActId).HasColumnName("SectionOfTheActID");

                entity.Property(e => e.ServicerId).HasColumnName("ServicerID");

                entity.Property(e => e.ServicerName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Wksheet119L1amount)
                    .HasColumnName("wksheet119L1Amount")
                    .HasColumnType("money");

                entity.Property(e => e.Wksheet119L2amount)
                    .HasColumnName("wksheet119L2Amount")
                    .HasColumnType("money");

                entity.Property(e => e.Wksheet119L3amount)
                    .HasColumnName("wksheet119L3Amount")
                    .HasColumnType("money");

                entity.Property(e => e.Wksheet121FromDate)
                    .HasColumnName("wksheet121FromDate")
                    .HasColumnType("date");

                entity.Property(e => e.Wksheet121Rate)
                    .HasColumnName("wksheet121Rate")
                    .HasColumnType("decimal(4, 2)");

                entity.Property(e => e.Wksheet121ToDate)
                    .HasColumnName("wksheet121ToDate")
                    .HasColumnType("date");

                entity.Property(e => e._130appraisalFeeAfromPtE).HasColumnName("130AppraisalFeeAFromPtE");

                entity.Property(e => e._131deficiencyAfromPtE).HasColumnName("131DeficiencyAFromPtE");

                entity.Property(e => e._134totalDeductions)
                    .HasColumnName("134TotalDeductions")
                    .HasColumnType("money");

                entity.Property(e => e._135totalAdditions)
                    .HasColumnName("135TotalAdditions")
                    .HasColumnType("money");

                entity.Property(e => e._136totalInterest)
                    .HasColumnName("136TotalInterest")
                    .HasColumnType("money");

                entity.Property(e => e._137netclaimAmount)
                    .HasColumnName("137NetclaimAmount")
                    .HasColumnType("money");
            });

            modelBuilder.Entity<VwHudPartC>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_HUD_PartC");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DateFormPrepared).HasColumnType("date");

                entity.Property(e => e.DebentureInterestRate).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.DefaultDate).HasColumnType("date");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FhacaseNumber)
                    .IsRequired()
                    .HasColumnName("FHACaseNumber")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.MortgageeComments)
                    .HasMaxLength(700)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageeLoanNumber)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageeName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorFirstName)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorLastName)
                    .HasMaxLength(35)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorMiddleName)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.PartC27011id).HasColumnName("PartC27011ID");

                entity.Property(e => e.PropertyAddress1)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyAddress2)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyStateCode)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SectionOfActCode)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerName)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwHudPartD>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_HUD_PartD");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DateFormPrepared).HasColumnType("date");

                entity.Property(e => e.DebentureInterestRate).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.DefaultDate).HasColumnType("date");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FhacaseNumber)
                    .IsRequired()
                    .HasColumnName("FHACaseNumber")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.MortgageeLoanNumber)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageeName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorFirstName)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorLastName)
                    .HasMaxLength(35)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorMiddleName)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.PartD27011id).HasColumnName("PartD27011ID");

                entity.Property(e => e.PropertyAddress1)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyAddress2)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyStateCode)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SectionOfActCode)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerName)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwHudPartE>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_HUD_PartE");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DateFormPrepared).HasColumnType("date");

                entity.Property(e => e.DebentureInterestRate).HasColumnType("decimal(6, 4)");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FhacaseNumber)
                    .IsRequired()
                    .HasColumnName("FHACaseNumber")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.MortgageeLoanNumber)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.MortgageeName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorFirstName)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorLastName)
                    .HasMaxLength(35)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorMiddleName)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.PartE27011id).HasColumnName("PartE27011ID");

                entity.Property(e => e.PropertyAddress1)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyAddress2)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyStateCode)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SectionOfActCode)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerName)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwHudSearch>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_HUD_Search");

                entity.Property(e => e.ClaimStatus)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimType)
                    .HasMaxLength(939)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DateFormBprepared)
                    .HasColumnName("DateFormBPrepared")
                    .HasColumnType("date");

                entity.Property(e => e.FhacaseNumber)
                    .IsRequired()
                    .HasColumnName("FHACaseNumber")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.FhaloanId).HasColumnName("FHALoanID");

                entity.Property(e => e.FhasuppClaimParentId).HasColumnName("FHASuppClaimParentID");

                entity.Property(e => e.MortgageeLoanNumber)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorFirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorFullName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MortgagorLastName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PartA27011id).HasColumnName("PartA27011ID");

                entity.Property(e => e.PartB27011id).HasColumnName("PartB27011ID");

                entity.Property(e => e.PartC27011id).HasColumnName("PartC27011ID");

                entity.Property(e => e.PartD27011id).HasColumnName("PartD27011ID");

                entity.Property(e => e.PartE27011id).HasColumnName("PartE27011ID");

                entity.Property(e => e.PropertyAddress1)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyStateCode)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SuppClaimType)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.UserId)
                    .IsRequired()
                    .HasColumnName("UserID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwHudclaimsInvTrkAndImportsClientClaimTypeClaimSubTypesOnboarded>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_HUDClaims_InvTrkAndImports_ClientClaimTypeClaimSubTypesOnboarded");

                entity.Property(e => e.ClientDisplayName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EnableHudEdi).HasColumnName("Enable_HUD_EDI");

                entity.Property(e => e.FhaclientClaimTypeEdicontrolId).HasColumnName("FHAClientClaimTypeEDIControlID");

                entity.Property(e => e.FhaclientId).HasColumnName("FHAClientID");

                entity.Property(e => e.HudclaimsClaimSubTypeId).HasColumnName("HUDClaimsClaimSubTypeID");

                entity.Property(e => e.HudclaimsClaimSubTypeName)
                    .HasColumnName("HUDClaimsClaimSubTypeName")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.HudclaimsClaimTypeId).HasColumnName("HUDClaimsClaimTypeID");

                entity.Property(e => e.HudclaimsClaimTypeName)
                    .HasColumnName("HUDClaimsClaimTypeName")
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.InvTrkClaimSubTypeId).HasColumnName("InvTrkClaimSubTypeID");

                entity.Property(e => e.InvTrkClaimSubTypeName)
                    .IsRequired()
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.InvTrkClaimTypeId).HasColumnName("InvTrkClaimTypeID");

                entity.Property(e => e.InvTrkClaimTypeName)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwInvTrkFhaclaim>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_InvTrkFHAClaim");

                entity.Property(e => e.ClaimAmount).HasColumnType("money");

                entity.Property(e => e.ClaimId).HasColumnName("ClaimID");

                entity.Property(e => e.EdiauthorizedDate)
                    .HasColumnName("EDIAuthorizedDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.FhaclaimId)
                    .HasColumnName("FHAClaimID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.IsEdiauthorized).HasColumnName("IsEDIAuthorized");

                entity.Property(e => e.PaidAmount).HasColumnType("money");

                entity.Property(e => e.PartAanalyst).HasColumnName("PartAAnalyst");

                entity.Property(e => e.PartBqcanalyst).HasColumnName("PartBQCAnalyst");

                entity.Property(e => e.UnpaidBalance).HasColumnType("money");
            });

            modelBuilder.Entity<VwInvTrkLoan>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_InvTrkLoan");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.FhacaseNumber)
                    .HasColumnName("FHACaseNumber")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.LoanNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwPartB>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_PartB");

                entity.Property(e => e.Block100)
                    .HasMaxLength(170)
                    .IsUnicode(false);

                entity.Property(e => e.Block101)
                    .IsRequired()
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.Block102)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Block103)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.Block104).HasColumnType("date");

                entity.Property(e => e.Block105).HasColumnType("date");

                entity.Property(e => e.Block105TypeId).HasColumnName("Block105TypeID");

                entity.Property(e => e.Block107aAmount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block107bAmount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block108TypeId).HasColumnName("Block108TypeID");

                entity.Property(e => e.Block108aAmount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block109aAmount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block110b)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block110c)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block111b)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block111c)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block112b)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block112c)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block113b)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block113c)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block114b)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block114c)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block115aAmount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block116bAmount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block117b)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block117c)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block118aAmount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block119aAmount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block119bAmount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block120b)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block120c)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block121Amount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block122b)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block122c)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block123aAmount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block123bAmount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block123cAmount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block124aAmount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block124bAmount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block124cAmount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block125b)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block125c)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block126cAmount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block127a)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block128b)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block129b)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block130b)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block130c)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block131b)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block131c)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block132Description)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Block132aAmount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block132bAmount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block132cAmount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block133a)
                    .HasMaxLength(91)
                    .IsUnicode(false);

                entity.Property(e => e.Block133b)
                    .HasMaxLength(91)
                    .IsUnicode(false);

                entity.Property(e => e.Block134Amount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block135Amount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block136Amount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Block137Amount)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.FhaclaimId).HasColumnName("FHAClaimID");

                entity.Property(e => e.PartB27011id).HasColumnName("PartB27011ID");

                entity.Property(e => e.Wksheet119L1amount)
                    .HasColumnName("wksheet119L1Amount")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Wksheet119L2amount)
                    .HasColumnName("wksheet119L2Amount")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Wksheet119L3amount)
                    .HasColumnName("wksheet119L3Amount")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Wksheet121FromDate)
                    .HasColumnName("wksheet121FromDate")
                    .HasColumnType("date");

                entity.Property(e => e.Wksheet121Rate)
                    .HasColumnName("wksheet121Rate")
                    .HasColumnType("decimal(4, 2)");

                entity.Property(e => e.Wksheet121ToDate)
                    .HasColumnName("wksheet121ToDate")
                    .HasColumnType("date");
            });

            modelBuilder.Entity<VwRecSheetDeductAmountByClientClaim>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_Rec_Sheet_Deduct_Amount_By_Client_Claim");

                entity.Property(e => e.Amount).HasColumnType("money");

                entity.Property(e => e.ClaimId).HasColumnName("ClaimID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");
            });

          

            modelBuilder.Entity<XrefClaimDocuments>(entity =>
            {
                entity.HasKey(e => e.ClaimDocumentXrefId);

                entity.ToTable("xref_ClaimDocuments");

                entity.HasComment("Cross ref table. Contains claim types, document types, and docuware cabinets.");

                entity.Property(e => e.ClaimDocumentXrefId).HasColumnName("Claim_Document_xrefID");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.DocuwareCabinet)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FharetrievedDocumentTypeId).HasColumnName("FHARetrievedDocumentTypeID");

                entity.HasOne(d => d.ClaimType)
                    .WithMany(p => p.XrefClaimDocuments)
                    .HasForeignKey(d => d.ClaimTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_ClaimDocuments_ClaimType");

                entity.HasOne(d => d.FharetrievedDocumentType)
                    .WithMany(p => p.XrefClaimDocuments)
                    .HasForeignKey(d => d.FharetrievedDocumentTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_ClaimDocuments_lkp_FHARetrievedDocumentTypes");
            });

            modelBuilder.Entity<XrefClientAttributeRegistrations>(entity =>
            {
                entity.HasKey(e => e.ClientAttributeRegistrationId);

                entity.ToTable("xref_ClientAttribute_Registrations");

                entity.HasComment("Cross ref table. Contains FHA client id and extended attribute.");

                entity.HasIndex(e => new { e.FhaclientId, e.ExtendedAttributeId })
                    .HasName("UK1_xref_ClientAttribute_Registrations")
                    .IsUnique();

                entity.Property(e => e.ClientAttributeRegistrationId).HasColumnName("ClientAttribute_RegistrationID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.ExtendedAttributeId).HasColumnName("ExtendedAttributeID");

                entity.Property(e => e.FhaclientId).HasColumnName("FHAClientID");

                entity.HasOne(d => d.ExtendedAttribute)
                    .WithMany(p => p.XrefClientAttributeRegistrations)
                    .HasForeignKey(d => d.ExtendedAttributeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_ClientAttribute_Registrations_lkp_ExtendedAttributes");
            });

            modelBuilder.Entity<XrefEnvironmentClientCabinet>(entity =>
            {
                entity.HasKey(e => e.EnvironmentClientDocuwareCabinetId);

                entity.ToTable("xref_Environment_Client_Cabinet");

                entity.HasComment("Cross ref table. Empty table.");

                entity.Property(e => e.EnvironmentClientDocuwareCabinetId)
                    .HasColumnName("Environment_Client_DocuwareCabinetID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.DocuwareCabinetId).HasColumnName("DocuwareCabinetID");

                entity.Property(e => e.EnvironmentId).HasColumnName("EnvironmentID");

                entity.Property(e => e.FhaclientId).HasColumnName("FHAClientID");

                entity.HasOne(d => d.EnvironmentClientDocuwareCabinet)
                    .WithOne(p => p.XrefEnvironmentClientCabinet)
                    .HasForeignKey<XrefEnvironmentClientCabinet>(d => d.EnvironmentClientDocuwareCabinetId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_Environment_Client_Cabinet_lkp_FHALookups");
            });

            modelBuilder.Entity<XrefFhaclientClaimTypeEdicontrol>(entity =>
            {
                entity.HasKey(e => e.FhaclientClaimTypeEdicontrolId);

                entity.ToTable("xref_FHAClient_ClaimType_EDIControl");

                entity.HasComment("Cross ref table. Contains FHA client, claim type and subtype, and a bit to enable HUD EDI.");

                entity.HasIndex(e => new { e.FhaclientId, e.ClaimTypeId, e.FhaclaimSubTypeId })
                    .HasName("UK1_xref_FHAClient_ClaimType_EDIControl")
                    .IsUnique();

                entity.Property(e => e.FhaclientClaimTypeEdicontrolId).HasColumnName("FHAClientClaimTypeEDIControlID");

                entity.Property(e => e.ClaimTypeId).HasColumnName("ClaimTypeID");

                entity.Property(e => e.EnableHudEdi).HasColumnName("Enable_HUD_EDI");

                entity.Property(e => e.FhaclaimSubTypeId).HasColumnName("FHAClaimSubTypeID");

                entity.Property(e => e.FhaclientId).HasColumnName("FHAClientID");
            });

            modelBuilder.Entity<XrefServicerHolder>(entity =>
            {
                entity.HasKey(e => e.ServicerHolderXrefId);

                entity.ToTable("xref_ServicerHolder");

                entity.HasComment("Cross ref table. Contains servicer and holder IDs.");

                entity.HasIndex(e => new { e.ServicerId, e.HolderId, e.ClientId })
                    .HasName("UK1_xref_ServicerHolder_ServicerID_HolderID_ClientID")
                    .IsUnique();

                entity.Property(e => e.ServicerHolderXrefId).HasColumnName("Servicer_Holder_xrefID");

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.HolderId).HasColumnName("HolderID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.ServicerId).HasColumnName("ServicerID");

                entity.HasOne(d => d.Holder)
                    .WithMany(p => p.XrefServicerHolder)
                    .HasForeignKey(d => d.HolderId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_ServicerHolder_tbl_FHAMortgagees");

                entity.HasOne(d => d.Servicer)
                    .WithMany(p => p.XrefServicerHolder)
                    .HasForeignKey(d => d.ServicerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_ServicerHolder_tbl_FHAServicers");
            });

            modelBuilder.Entity<ZzTableDropCandidateTblControlAllowEdiauthConditions>(entity =>
            {
                entity.HasKey(e => e.AllowEdiauthConditionId)
                    .HasName("PK_tbl_Control_AllowEDIAuth_Conditions");

                entity.ToTable("zzTableDropCandidate_tbl_Control_AllowEDIAuth_Conditions");

                entity.Property(e => e.AllowEdiauthConditionId).HasColumnName("AllowEDIAuth_ConditionID");

                entity.Property(e => e.ClaimTypeName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CurtailmentDatePopulated).HasColumnName("CurtailmentDate_Populated");

                entity.Property(e => e.DateFormPreparedLteCurrentDate).HasColumnName("DateFormPrepared_LTE_CurrentDate");

                entity.Property(e => e.IneligibleCodePopulated).HasColumnName("IneligibleCode_Populated");

                entity.Property(e => e.MortgageeIdPopulated).HasColumnName("MortgageeID_Populated");

                entity.Property(e => e.PartAqcComplete).HasColumnName("PartAQC_Complete");

                entity.Property(e => e.PartBqcComplete).HasColumnName("PartBQC_Complete");

                entity.Property(e => e.RuleResult)
                    .IsRequired()
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerIdPopulated).HasColumnName("ServicerID_Populated");

                entity.Property(e => e.TaldatePopulated).HasColumnName("TALDate_Populated");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
