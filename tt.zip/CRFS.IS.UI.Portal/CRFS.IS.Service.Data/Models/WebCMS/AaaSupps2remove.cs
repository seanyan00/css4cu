﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class AaaSupps2remove
    {
        public long FhaloanId { get; set; }
        public long FhaclaimId { get; set; }
    }
}
