﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblPartD27011
    {
        public TblPartD27011()
        {
            TblPartD27011Mipremiums = new HashSet<TblPartD27011Mipremiums>();
            TblPartD27011MultiBlock = new HashSet<TblPartD27011MultiBlock>();
            TblPartD27011SpecialAssessments = new HashSet<TblPartD27011SpecialAssessments>();
            TblPartD27011TaxesOnDeed = new HashSet<TblPartD27011TaxesOnDeed>();
        }

        public long PartD27011id { get; set; }
        public long FhaclaimId { get; set; }
        public DateTime? DateFormPrepared { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUser { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUser { get; set; }

        public virtual TblFhaclaims Fhaclaim { get; set; }
        public virtual ICollection<TblPartD27011Mipremiums> TblPartD27011Mipremiums { get; set; }
        public virtual ICollection<TblPartD27011MultiBlock> TblPartD27011MultiBlock { get; set; }
        public virtual ICollection<TblPartD27011SpecialAssessments> TblPartD27011SpecialAssessments { get; set; }
        public virtual ICollection<TblPartD27011TaxesOnDeed> TblPartD27011TaxesOnDeed { get; set; }
    }
}
