﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaBlock308Description
    {
        public string Lutext { get; set; }
    }
}
