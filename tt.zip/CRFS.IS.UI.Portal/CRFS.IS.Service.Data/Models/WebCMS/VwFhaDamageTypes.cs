﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaDamageTypes
    {
        public long DamageTypeId { get; set; }
        public string DamageTypeCode { get; set; }
        public string DamageName { get; set; }
    }
}
