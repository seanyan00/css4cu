﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpFharetrievedDocumentTypes
    {
        public LkpFharetrievedDocumentTypes()
        {
            TblDataAutomationFhaDocRetrieveHistories = new HashSet<TblDataAutomationFhaDocRetrieveHistories>();
            TblFhapendingDoc = new HashSet<TblFhapendingDoc>();
            XrefClaimDocuments = new HashSet<XrefClaimDocuments>();
        }

        public long FharetrievedDocumentTypeId { get; set; }
        public string RetrievedDocumentName { get; set; }
        public DateTime DateEntered { get; set; }

        public virtual ICollection<TblDataAutomationFhaDocRetrieveHistories> TblDataAutomationFhaDocRetrieveHistories { get; set; }
        public virtual ICollection<TblFhapendingDoc> TblFhapendingDoc { get; set; }
        public virtual ICollection<XrefClaimDocuments> XrefClaimDocuments { get; set; }
    }
}
