﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefServicerHolder
    {
        public long ServicerHolderXrefId { get; set; }
        public long ServicerId { get; set; }
        public long HolderId { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUser { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUser { get; set; }
        public bool Active { get; set; }
        public int? ClientId { get; set; }

        public virtual TblFhamortgagees Holder { get; set; }
        public virtual TblFhaservicers Servicer { get; set; }
    }
}
