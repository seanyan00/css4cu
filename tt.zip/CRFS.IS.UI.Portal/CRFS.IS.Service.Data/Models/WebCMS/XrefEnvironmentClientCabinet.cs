﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefEnvironmentClientCabinet
    {
        public long EnvironmentClientDocuwareCabinetId { get; set; }
        public int EnvironmentId { get; set; }
        public long FhaclientId { get; set; }
        public long DocuwareCabinetId { get; set; }
        public long ClaimTypeId { get; set; }

        public virtual LkpFhalookups EnvironmentClientDocuwareCabinet { get; set; }
    }
}
