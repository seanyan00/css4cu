﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpExtendedAttributes
    {
        public LkpExtendedAttributes()
        {
            XrefClientAttributeRegistrations = new HashSet<XrefClientAttributeRegistrations>();
        }

        public long ExtendedAttributeId { get; set; }
        public string ExtendedAttributeName { get; set; }
        public string ExtendedAttributeDataType { get; set; }

        public virtual ICollection<XrefClientAttributeRegistrations> XrefClientAttributeRegistrations { get; set; }
    }
}
