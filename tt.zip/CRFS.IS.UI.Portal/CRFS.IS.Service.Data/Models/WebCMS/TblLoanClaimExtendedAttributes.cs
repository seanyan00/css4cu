﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblLoanClaimExtendedAttributes
    {
        public long LoanClaimExtendedAttributeId { get; set; }
        public long FhaloanId { get; set; }
        public long FhaclaimId { get; set; }
        public long ClientAttributeRegistrationId { get; set; }
        public string AttributeValue { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUser { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUser { get; set; }

        public virtual XrefClientAttributeRegistrations ClientAttributeRegistration { get; set; }
        public virtual TblFhaclaims Fhaclaim { get; set; }
        public virtual TblFhaloans Fhaloan { get; set; }
    }
}
