﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class ZzTableDropCandidateTblControlAllowEdiauthConditions
    {
        public int AllowEdiauthConditionId { get; set; }
        public string ClaimTypeName { get; set; }
        public bool ServicerIdPopulated { get; set; }
        public bool MortgageeIdPopulated { get; set; }
        public bool? TaldatePopulated { get; set; }
        public bool IneligibleCodePopulated { get; set; }
        public bool PartAqcComplete { get; set; }
        public bool PartBqcComplete { get; set; }
        public bool CurtailmentDatePopulated { get; set; }
        public bool DateFormPreparedLteCurrentDate { get; set; }
        public string RuleResult { get; set; }
    }
}
