﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhaBlock105Types
    {
        public long Block105TypeId { get; set; }
        public string Block105Description { get; set; }
    }
}
