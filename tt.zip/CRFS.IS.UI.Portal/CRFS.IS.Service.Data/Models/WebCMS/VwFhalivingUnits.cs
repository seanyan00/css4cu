﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwFhalivingUnits
    {
        public long LivingUnitId { get; set; }
        public long PartA27011id { get; set; }
        public int UnitNumber { get; set; }
        public bool? Vacant { get; set; }
        public bool? Occupied { get; set; }
        public string OccupantName { get; set; }
        public DateTime? DateVacated { get; set; }
        public DateTime? DateSecured { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUser { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUser { get; set; }
    }
}
