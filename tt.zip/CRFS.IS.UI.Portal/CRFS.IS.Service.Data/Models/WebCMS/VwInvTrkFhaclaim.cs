﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwInvTrkFhaclaim
    {
        public int FhaclaimId { get; set; }
        public int ClaimId { get; set; }
        public decimal? ClaimAmount { get; set; }
        public decimal? PaidAmount { get; set; }
        public decimal? UnpaidBalance { get; set; }
        public DateTime? EdiauthorizedDate { get; set; }
        public bool IsEdiauthorized { get; set; }
        public int? PartAanalyst { get; set; }
        public int? PartBqcanalyst { get; set; }
    }
}
