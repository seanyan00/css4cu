﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpReportDataset
    {
        public LkpReportDataset()
        {
            LkpReportDatasetParameter = new HashSet<LkpReportDatasetParameter>();
            LkpReportPage = new HashSet<LkpReportPage>();
        }

        public int Id { get; set; }
        public string Sproc { get; set; }
        public string SqlStr { get; set; }
        public DateTime DateCreated { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? DateUpdated { get; set; }
        public int? UpdatedBy { get; set; }

        public virtual ICollection<LkpReportDatasetParameter> LkpReportDatasetParameter { get; set; }
        public virtual ICollection<LkpReportPage> LkpReportPage { get; set; }
    }
}
