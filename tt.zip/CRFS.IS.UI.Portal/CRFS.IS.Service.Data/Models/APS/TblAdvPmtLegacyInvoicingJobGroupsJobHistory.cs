﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblAdvPmtLegacyInvoicingJobGroupsJobHistory
    {
        public int LegacyInvoicingJobGroupJobHistoryId { get; set; }
        public int LegacyInvoicingJobHistoryId { get; set; }
        public int LegacyInvoicingJobsGroupsId { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public bool WasSuccessful { get; set; }
        public string ErrorMessage { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }

        public virtual TblAdvPmtLegacyInvoicingJobHistory LegacyInvoicingJobHistory { get; set; }
        public virtual XrefAdvPmtLegacyInvoicingJobsGroup LegacyInvoicingJobsGroups { get; set; }
    }
}
