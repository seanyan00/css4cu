﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpReconEobheader
    {
        public LkpReconEobheader()
        {
            TblReconEobvalues = new HashSet<TblReconEobvalue>();
        }

        public int EobheaderId { get; set; }
        public string EobheaderName { get; set; }
        public int? SortOrder { get; set; }
        public bool? Active { get; set; }
        public DateTime? ActiveToDate { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUserId { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUserId { get; set; }
        public bool? MarkedForDelete { get; set; }

        public virtual ICollection<TblReconEobvalue> TblReconEobvalues { get; set; }
    }
}
