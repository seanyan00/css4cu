﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class VwAdvPmtAllServicersUngrouped
    {
        public int ServicerId { get; set; }
        public string ServicerName { get; set; }
        public int? GroupId { get; set; }
    }
}
