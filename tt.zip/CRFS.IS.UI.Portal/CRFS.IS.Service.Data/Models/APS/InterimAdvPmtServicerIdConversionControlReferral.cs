﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class InterimAdvPmtServicerIdConversionControlReferral
    {
        public long ReferralId { get; set; }
        public int LegacyBusinessEntityId { get; set; }
        public int NewServicerId { get; set; }
    }
}
