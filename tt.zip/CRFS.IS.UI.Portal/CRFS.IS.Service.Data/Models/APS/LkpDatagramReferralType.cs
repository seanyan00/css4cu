﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpDatagramReferralType
    {
        public LkpDatagramReferralType()
        {
            TblDatagramReferrals = new HashSet<TblDatagramReferral>();
        }

        public int ReferralTypeId { get; set; }
        public string ReferralType { get; set; }
        public bool? Active { get; set; }
        public DateTime ActiveToDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public bool MarkedForDelete { get; set; }

        public virtual ICollection<TblDatagramReferral> TblDatagramReferrals { get; set; }
    }
}
