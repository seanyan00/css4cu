﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpAdvPmtReferralStatus
    {
        public LkpAdvPmtReferralStatus()
        {
            TblAdvPmtReferrals = new HashSet<TblAdvPmtReferral>();
        }

        public int ReferralStatusId { get; set; }
        public string ReferralStatusDescription { get; set; }
        public bool? Active { get; set; }
        public DateTime ActiveToDate { get; set; }
        public int EnteredByuserId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public bool MarkedForDelete { get; set; }
        public bool? IsUserSelectable { get; set; }

        public virtual ICollection<TblAdvPmtReferral> TblAdvPmtReferrals { get; set; }
    }
}
