﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblReconEobvalues
    {
        public int EobvalueId { get; set; }
        public int ReferralId { get; set; }
        public int EobheaderId { get; set; }
        public decimal? SubmittedAmount { get; set; }
        public decimal? PaidAmount { get; set; }
        public decimal? Eobdifference { get; set; }
        public bool IsCurtailment { get; set; }
        public bool IsDisallowance { get; set; }
        public bool IsSupplemental { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public bool IsOther { get; set; }

        public virtual LkpReconEobheaders Eobheader { get; set; }
        public virtual TblReconReferral Referral { get; set; }
    }
}
