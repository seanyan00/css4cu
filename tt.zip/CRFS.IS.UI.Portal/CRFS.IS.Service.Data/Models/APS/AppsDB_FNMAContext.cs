﻿using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class AppsDB_FNMAContext : DbContext
    {
        public AppsDB_FNMAContext()
        {
        }

        public AppsDB_FNMAContext(DbContextOptions<AppsDB_FNMAContext> options)
            : base(options)
        {
        }

        public virtual DbSet<ImportsReferral> ImportsReferrals { get; set; }
        public virtual DbSet<InterimAdvPmtGroupIdConversionControl> InterimAdvPmtGroupIdConversionControls { get; set; }
        public virtual DbSet<InterimAdvPmtServicerIdConversionControl> InterimAdvPmtServicerIdConversionControls { get; set; }
        public virtual DbSet<InterimAdvPmtServicerIdConversionControlReferral> InterimAdvPmtServicerIdConversionControlReferrals { get; set; }
        public virtual DbSet<InterimDatagramBusinessEntityConversionControl> InterimDatagramBusinessEntityConversionControls { get; set; }
        public virtual DbSet<InterimDatagramCommentTypesConversionControl> InterimDatagramCommentTypesConversionControls { get; set; }
        public virtual DbSet<InterimDatagramInvoiceStatusTypesConversionControl> InterimDatagramInvoiceStatusTypesConversionControls { get; set; }
        public virtual DbSet<InterimDatagramReferralTypesConversionControl> InterimDatagramReferralTypesConversionControls { get; set; }
        public virtual DbSet<InterimDatagramStatusTypesConversionControl> InterimDatagramStatusTypesConversionControls { get; set; }
        public virtual DbSet<LkpAdvPmtBillingReason> LkpAdvPmtBillingReasons { get; set; }
        public virtual DbSet<LkpAdvPmtCommentType> LkpAdvPmtCommentTypes { get; set; }
        public virtual DbSet<LkpAdvPmtDisbursementType> LkpAdvPmtDisbursementTypes { get; set; }
        public virtual DbSet<LkpAdvPmtGroup> LkpAdvPmtGroups { get; set; }
        public virtual DbSet<LkpAdvPmtInvoiceStatus> LkpAdvPmtInvoiceStatuses { get; set; }
        public virtual DbSet<LkpAdvPmtReferralStatus> LkpAdvPmtReferralStatuses { get; set; }
        public virtual DbSet<LkpAdvPmtServicer> LkpAdvPmtServicers { get; set; }
        public virtual DbSet<LkpDatagramCommentType> LkpDatagramCommentTypes { get; set; }
        public virtual DbSet<LkpDatagramInvoiceStatusType> LkpDatagramInvoiceStatusTypes { get; set; }
        public virtual DbSet<LkpDatagramReferralType> LkpDatagramReferralTypes { get; set; }
        public virtual DbSet<LkpDatagramStatusType> LkpDatagramStatusTypes { get; set; }
        public virtual DbSet<LkpReconBillingStatusType> LkpReconBillingStatusTypes { get; set; }
        public virtual DbSet<LkpReconCategoryCode> LkpReconCategoryCodes { get; set; }
        public virtual DbSet<LkpReconClaimItemAttribute> LkpReconClaimItemAttributes { get; set; }
        public virtual DbSet<LkpReconCommentType> LkpReconCommentTypes { get; set; }
        public virtual DbSet<LkpReconDispositionStatusType> LkpReconDispositionStatusTypes { get; set; }
        public virtual DbSet<LkpReconEobheader> LkpReconEobheaders { get; set; }
        public virtual DbSet<LkpReconNoBillReason> LkpReconNoBillReasons { get; set; }
        public virtual DbSet<LkpReconReferralType> LkpReconReferralTypes { get; set; }
        public virtual DbSet<LkpReconSettlementType> LkpReconSettlementTypes { get; set; }
        public virtual DbSet<LkpReconStatusType> LkpReconStatusTypes { get; set; }
        public virtual DbSet<TblAdvPmtComment> TblAdvPmtComments { get; set; }
        public virtual DbSet<TblAdvPmtDisbursement> TblAdvPmtDisbursements { get; set; }
        public virtual DbSet<TblAdvPmtLegacyInvoicingJob> TblAdvPmtLegacyInvoicingJobs { get; set; }
        public virtual DbSet<TblAdvPmtLegacyInvoicingJobGroupsJobHistory> TblAdvPmtLegacyInvoicingJobGroupsJobHistories { get; set; }
        public virtual DbSet<TblAdvPmtLegacyInvoicingJobHistory> TblAdvPmtLegacyInvoicingJobHistories { get; set; }
        public virtual DbSet<TblAdvPmtReferral> TblAdvPmtReferrals { get; set; }
        public virtual DbSet<TblAdvPmtReferralEdit> TblAdvPmtReferralEdits { get; set; }
        public virtual DbSet<TblDatagramComment> TblDatagramComments { get; set; }
        public virtual DbSet<TblDatagramImport> TblDatagramImports { get; set; }
        public virtual DbSet<TblDatagramReferral> TblDatagramReferrals { get; set; }
        public virtual DbSet<TblReconClaimItem> TblReconClaimItems { get; set; }
        public virtual DbSet<TblReconComment> TblReconComments { get; set; }
        public virtual DbSet<TblReconEobvalue> TblReconEobvalues { get; set; }
        public virtual DbSet<TblReconReferral> TblReconReferrals { get; set; }
        public virtual DbSet<TblReconTransaction> TblReconTransactions { get; set; }
        public virtual DbSet<VwAdvPmtAllServicerGroupsInclUserAssignment> VwAdvPmtAllServicerGroupsInclUserAssignments { get; set; }
        public virtual DbSet<VwAdvPmtAllServicerGroupsUnassigned> VwAdvPmtAllServicerGroupsUnassigneds { get; set; }
        public virtual DbSet<VwAdvPmtAllServicersInclServicerGroup> VwAdvPmtAllServicersInclServicerGroups { get; set; }
        public virtual DbSet<VwAdvPmtAllServicersUngrouped> VwAdvPmtAllServicersUngroupeds { get; set; }
        public virtual DbSet<VwAdvPmtCheckedOutReferral> VwAdvPmtCheckedOutReferrals { get; set; }
        public virtual DbSet<VwAdvPmtGroupsToBeInvoiced> VwAdvPmtGroupsToBeInvoiceds { get; set; }
        public virtual DbSet<VwAdvPmtReferralDetail> VwAdvPmtReferralDetails { get; set; }
        public virtual DbSet<VwAdvPmtRole> VwAdvPmtRoles { get; set; }
        public virtual DbSet<VwAdvPmtUser> VwAdvPmtUsers { get; set; }
        public virtual DbSet<VwAdvPmtUserApplicationRole> VwAdvPmtUserApplicationRoles { get; set; }
        public virtual DbSet<VwDataGramFindClaim> VwDataGramFindClaims { get; set; }
        public virtual DbSet<VwEmployee> VwEmployees { get; set; }
        public virtual DbSet<VwReconCore> VwReconCores { get; set; }
        public virtual DbSet<VwReconMonthlyReconcile> VwReconMonthlyReconciles { get; set; }
        public virtual DbSet<VwReconQueue> VwReconQueues { get; set; }
        public virtual DbSet<VwReconQueueBulkReferral> VwReconQueueBulkReferrals { get; set; }
        public virtual DbSet<VwReconQueueCommentFollowUp> VwReconQueueCommentFollowUps { get; set; }
        public virtual DbSet<VwReconQueueProcessor> VwReconQueueProcessors { get; set; }
        public virtual DbSet<VwReconQueueSupervisor> VwReconQueueSupervisors { get; set; }
        public virtual DbSet<VwReconReportChaseCurtailmentBillingLetter> VwReconReportChaseCurtailmentBillingLetters { get; set; }
        public virtual DbSet<VwReconReportClaimItemAttributeValue> VwReconReportClaimItemAttributeValues { get; set; }
        public virtual DbSet<VwReconReportClosedReferral> VwReconReportClosedReferrals { get; set; }
        public virtual DbSet<VwReconReportWorkflowDisposition> VwReconReportWorkflowDispositions { get; set; }
        public virtual DbSet<VwReconSettlementAmount> VwReconSettlementAmounts { get; set; }
        public virtual DbSet<XrefAdvPmtLegacyInvoicingJobsGroup> XrefAdvPmtLegacyInvoicingJobsGroups { get; set; }
        public virtual DbSet<XrefAdvPmtServicersGroup> XrefAdvPmtServicersGroups { get; set; }
        public virtual DbSet<XrefServicerGroupUserAssignment> XrefServicerGroupUserAssignments { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Data Source=vm-sql1-dev.dev.crfs.crfservices.com\\cms_d;Initial Catalog=AppsDB_FNMA;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<ImportsReferral>(entity =>
            {
                entity.HasKey(e => e.ImportId);

                entity.ToTable("Imports_referral", "advpmt");

                entity.Property(e => e.ImportId).HasColumnName("ImportID");

                entity.Property(e => e.Comment).HasMaxLength(255);

                entity.Property(e => e.Crfsstatus)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("CRFSStatus");

                entity.Property(e => e.FnmaloanNumber)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("FNMALoanNumber");

                entity.Property(e => e.LoanStatusCode)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.ReferralFile).HasColumnType("date");

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");

                entity.Property(e => e.ServicerLoanNumber)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerNumber)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.State)
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<InterimAdvPmtGroupIdConversionControl>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("interim_AdvPmt_GroupID_ConversionControl", "advpmt");

                entity.Property(e => e.GroupName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.LegacyGroupId).HasColumnName("LegacyGroupID");

                entity.Property(e => e.NewGroupId).HasColumnName("NewGroupID");
            });

            modelBuilder.Entity<InterimAdvPmtServicerIdConversionControl>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("interim_AdvPmt_ServicerID_ConversionControl", "advpmt");

                entity.Property(e => e.LegacyServicerId).HasColumnName("LegacyServicerID");

                entity.Property(e => e.NewServicerId).HasColumnName("NewServicerID");

                entity.Property(e => e.ServicerName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<InterimAdvPmtServicerIdConversionControlReferral>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("interim_AdvPmt_ServicerID_ConversionControl_Referrals", "advpmt");

                entity.Property(e => e.LegacyBusinessEntityId).HasColumnName("LegacyBusinessEntityID");

                entity.Property(e => e.NewServicerId).HasColumnName("NewServicerID");

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");
            });

            modelBuilder.Entity<InterimDatagramBusinessEntityConversionControl>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("interim_Datagram_BusinessEntity_ConversionControl", "Datagram");

                entity.Property(e => e.DatagramReferralId).HasColumnName("DatagramReferralID");

                entity.Property(e => e.LegacyServicerId).HasColumnName("LegacyServicerID");

                entity.Property(e => e.NewServicerId).HasColumnName("NewServicerID");
            });

            modelBuilder.Entity<InterimDatagramCommentTypesConversionControl>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("interim_Datagram_CommentTypes_ConversionControl", "Datagram");

                entity.Property(e => e.DatagramCommentId).HasColumnName("DatagramCommentID");

                entity.Property(e => e.NewCommentTypeId).HasColumnName("NewCommentTypeID");

                entity.Property(e => e.OldCommentTypeId).HasColumnName("OldCommentTypeID");
            });

            modelBuilder.Entity<InterimDatagramInvoiceStatusTypesConversionControl>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("interim_Datagram_InvoiceStatusTypes_ConversionControl", "Datagram");

                entity.Property(e => e.DatagramReferralId).HasColumnName("DatagramReferralID");

                entity.Property(e => e.NewInvoiceStatusId).HasColumnName("NewInvoiceStatusID");

                entity.Property(e => e.OldInvoiceStatusId).HasColumnName("OldInvoiceStatusID");
            });

            modelBuilder.Entity<InterimDatagramReferralTypesConversionControl>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("interim_Datagram_ReferralTypes_ConversionControl", "Datagram");

                entity.Property(e => e.DatagramReferralId).HasColumnName("DatagramReferralID");

                entity.Property(e => e.NewReferralTypeId).HasColumnName("NewReferralTypeID");

                entity.Property(e => e.OldReferralTypeId).HasColumnName("OldReferralTypeID");
            });

            modelBuilder.Entity<InterimDatagramStatusTypesConversionControl>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("interim_Datagram_StatusTypes_ConversionControl", "Datagram");

                entity.Property(e => e.DatagramReferralId).HasColumnName("DatagramReferralID");

                entity.Property(e => e.NewStatusId).HasColumnName("NewStatusID");

                entity.Property(e => e.OldDatagramStatusId).HasColumnName("OldDatagramStatusID");
            });

            modelBuilder.Entity<LkpAdvPmtBillingReason>(entity =>
            {
                entity.HasKey(e => e.ReasonId);

                entity.ToTable("lkp_AdvPmt_BillingReasons", "advpmt");

                entity.Property(e => e.ReasonId).HasColumnName("ReasonID");

                entity.Property(e => e.ActiveToDate).HasColumnType("date");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(64)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpAdvPmtCommentType>(entity =>
            {
                entity.HasKey(e => e.CommentTypeId)
                    .HasName("PK_lkp_AdvPmt_CommentType");

                entity.ToTable("lkp_AdvPmt_CommentTypes", "advpmt");

                entity.HasIndex(e => e.CommentTypeDescription, "UK_AdvPmt_CommentType")
                    .IsUnique();

                entity.Property(e => e.CommentTypeId).HasColumnName("CommentTypeID");

                entity.Property(e => e.ActiveToDate).HasColumnType("date");

                entity.Property(e => e.CommentFilterType)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CommentTypeDescription)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");
            });

            modelBuilder.Entity<LkpAdvPmtDisbursementType>(entity =>
            {
                entity.HasKey(e => e.DisbursementTypeId)
                    .HasName("PK_lkp_AdvPmt_DisbursementType");

                entity.ToTable("lkp_AdvPmt_DisbursementTypes", "advpmt");

                entity.HasIndex(e => e.DisbursementTypeDescription, "UK_AdvPmt_DisbursementType")
                    .IsUnique();

                entity.Property(e => e.DisbursementTypeId).HasColumnName("DisbursementTypeID");

                entity.Property(e => e.ActiveToDate).HasColumnType("date");

                entity.Property(e => e.DisbursementTypeDescription)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.MarkedForDelete).HasColumnName("MarkedFOrDelete");
            });

            modelBuilder.Entity<LkpAdvPmtGroup>(entity =>
            {
                entity.HasKey(e => e.GroupId)
                    .HasName("PK_lkp_AdvPmt_ServicerGroups");

                entity.ToTable("lkp_AdvPmt_Groups", "advpmt");

                entity.HasIndex(e => e.GroupName, "UK1_lkp_AdvPmt_ServicerGroups_GroupName")
                    .IsUnique();

                entity.Property(e => e.GroupId).HasColumnName("GroupID");

                entity.Property(e => e.EffectiveFromDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.EffectiveToDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('12/31/2078')");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.GroupName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");
            });

            modelBuilder.Entity<LkpAdvPmtInvoiceStatus>(entity =>
            {
                entity.HasKey(e => e.InvoiceStatusId);

                entity.ToTable("lkp_AdvPmt_InvoiceStatuses", "advpmt");

                entity.Property(e => e.InvoiceStatusId).HasColumnName("InvoiceStatusID");

                entity.Property(e => e.ActiveToDate).HasColumnType("date");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.InvoiceStatusDescription)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");
            });

            modelBuilder.Entity<LkpAdvPmtReferralStatus>(entity =>
            {
                entity.HasKey(e => e.ReferralStatusId)
                    .HasName("PK_lkp_AdvPmt_ReferralStatus");

                entity.ToTable("lkp_AdvPmt_ReferralStatuses", "advpmt");

                entity.Property(e => e.ReferralStatusId).HasColumnName("ReferralStatusID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ActiveToDate).HasColumnType("date");

                entity.Property(e => e.EnteredByuserId).HasColumnName("EnteredByuserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.IsUserSelectable)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ReferralStatusDescription)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpAdvPmtServicer>(entity =>
            {
                entity.HasKey(e => e.ServicerId);

                entity.ToTable("lkp_AdvPmt_Servicers", "advpmt");

                entity.HasIndex(e => e.ServicerName, "UK1_lkp_AdvPmt_Servicers_ServicerName")
                    .IsUnique();

                entity.Property(e => e.ServicerId).HasColumnName("ServicerID");

                entity.Property(e => e.EffectiveFromDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.EffectiveToDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('12/31/2078')");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId)
                    .HasColumnType("datetime")
                    .HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ServicerName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpDatagramCommentType>(entity =>
            {
                entity.HasKey(e => e.CommentTypeId)
                    .HasName("pk_CommentTypeID");

                entity.ToTable("lkp_Datagram_CommentTypes", "Datagram");

                entity.Property(e => e.CommentTypeId).HasColumnName("CommentTypeID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ActiveToDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("('12/31/2078')");

                entity.Property(e => e.CommentType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");
            });

            modelBuilder.Entity<LkpDatagramInvoiceStatusType>(entity =>
            {
                entity.HasKey(e => e.InvoiceStatusId)
                    .HasName("pk_InvoiceStatusID");

                entity.ToTable("lkp_Datagram_InvoiceStatusTypes", "Datagram");

                entity.Property(e => e.InvoiceStatusId).HasColumnName("InvoiceStatusID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ActiveToDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("('12/31/2078')");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.InvoiceStatus)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");
            });

            modelBuilder.Entity<LkpDatagramReferralType>(entity =>
            {
                entity.HasKey(e => e.ReferralTypeId)
                    .HasName("pk_ReferralTypeID");

                entity.ToTable("lkp_Datagram_ReferralTypes", "Datagram");

                entity.Property(e => e.ReferralTypeId).HasColumnName("ReferralTypeID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ActiveToDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("('12/31/2078')");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ReferralType)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpDatagramStatusType>(entity =>
            {
                entity.HasKey(e => e.StatusId)
                    .HasName("pk_StatusID");

                entity.ToTable("lkp_Datagram_StatusTypes", "Datagram");

                entity.Property(e => e.StatusId).HasColumnName("StatusID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ActiveToDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("('12/31/2078')");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.StatusType)
                    .IsRequired()
                    .HasMaxLength(35)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpReconBillingStatusType>(entity =>
            {
                entity.HasKey(e => e.BillingStatusId)
                    .HasName("PK_lkp_Recon_BillingStatusTypes_BillingStatusID");

                entity.ToTable("lkp_Recon_BillingStatusTypes", "recon");

                entity.HasIndex(e => e.BillingStatus, "UK1_lkp_Recon_BillingStatusTypes_BillingStatus")
                    .IsUnique()
                    .HasFillFactor((byte)80);

                entity.Property(e => e.BillingStatusId).HasColumnName("BillingStatusID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ActiveToDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("('12/31/2078')");

                entity.Property(e => e.BillingStatus)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");
            });

            modelBuilder.Entity<LkpReconCategoryCode>(entity =>
            {
                entity.HasKey(e => e.CategoryCodeOfReceiptId);

                entity.ToTable("lkp_Recon_CategoryCodes", "recon");

                entity.HasComment("Look-up table. Contains information about category code of receipts.");

                entity.HasIndex(e => e.CategoryCodeOfReceipt, "UK1_lkp_Recon_CategoryCodes_CategoryCodeOfReceipt")
                    .IsUnique();

                entity.Property(e => e.CategoryCodeOfReceiptId).HasColumnName("CategoryCodeOfReceiptID");

                entity.Property(e => e.ActiveToDate).HasColumnType("date");

                entity.Property(e => e.CategoryCodeOfReceipt)
                    .IsRequired()
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(75)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");
            });

            modelBuilder.Entity<LkpReconClaimItemAttribute>(entity =>
            {
                entity.HasKey(e => e.ClaimItemAttributeId);

                entity.ToTable("lkp_Recon_ClaimItemAttribute", "recon");

                entity.HasComment("Look-up table. Contains datatypes and names for claim item attributes.Â ");

                entity.HasIndex(e => e.ClaimItemAttributeName, "UK1_lkp_Recon_ClaimItemAttribute_ClaimItemAttributeName")
                    .IsUnique();

                entity.Property(e => e.ClaimItemAttributeId).HasColumnName("ClaimItemAttributeID");

                entity.Property(e => e.ActiveToDate).HasColumnType("date");

                entity.Property(e => e.ClaimItemAttributeDataType)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimItemAttributeName)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");
            });

            modelBuilder.Entity<LkpReconCommentType>(entity =>
            {
                entity.HasKey(e => e.CommentTypeId)
                    .HasName("PK_lkp_Recon_CommentTypes_CommentTypeID");

                entity.ToTable("lkp_Recon_CommentTypes", "recon");

                entity.HasIndex(e => e.CommentType, "UK1_lkp_Recon_CommentTypes_CommentType")
                    .IsUnique()
                    .HasFillFactor((byte)80);

                entity.Property(e => e.CommentTypeId).HasColumnName("CommentTypeID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ActiveToDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("('12/31/2078')");

                entity.Property(e => e.CommentType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");
            });

            modelBuilder.Entity<LkpReconDispositionStatusType>(entity =>
            {
                entity.HasKey(e => e.DispositionStatusId)
                    .HasName("PK_lkp_Recon_DispositionStatusTypes_DispositionStatusID");

                entity.ToTable("lkp_Recon_DispositionStatusTypes", "recon");

                entity.HasIndex(e => e.DispositionStatus, "UK1_lkp_Recon_DispositionStatusTypes_DispositionStatus")
                    .IsUnique()
                    .HasFillFactor((byte)80);

                entity.Property(e => e.DispositionStatusId).HasColumnName("DispositionStatusID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ActiveToDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("('12/31/2078')");

                entity.Property(e => e.DispositionStatus)
                    .IsRequired()
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");
            });

            modelBuilder.Entity<LkpReconEobheader>(entity =>
            {
                entity.HasKey(e => e.EobheaderId);

                entity.ToTable("lkp_Recon_EOBHeaders", "recon");

                entity.HasComment("Look-up table. Contains names and sort orders for EOB headers.");

                entity.HasIndex(e => e.EobheaderName, "UK1_lkp_EOBHeaders_EOBHeaderName")
                    .IsUnique();

                entity.Property(e => e.EobheaderId).HasColumnName("EOBHeaderID");

                entity.Property(e => e.ActiveToDate).HasColumnType("date");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.EobheaderName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("EOBHeaderName");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");
            });

            modelBuilder.Entity<LkpReconNoBillReason>(entity =>
            {
                entity.HasKey(e => e.NoBillReasonId)
                    .HasName("PK_lkp_Recon_NoBillReasons_NoBillReasonID");

                entity.ToTable("lkp_Recon_NoBillReasons", "recon");

                entity.HasIndex(e => e.NoBillReasonDescription, "UK1_lkp_Recon_NoBillReasons_NoBillReasonDescription")
                    .IsUnique()
                    .HasFillFactor((byte)80);

                entity.Property(e => e.NoBillReasonId).HasColumnName("NoBillReasonID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ActiveToDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("('12/31/2078')");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.NoBillReasonDescription)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpReconReferralType>(entity =>
            {
                entity.HasKey(e => e.ReferralTypeId)
                    .HasName("PK_lkp_Recon_ReferralTypes_ReferralTypeID");

                entity.ToTable("lkp_Recon_ReferralTypes", "recon");

                entity.HasIndex(e => e.ReferralType, "UK1_lkp_Recon_ReferralTypes_ReferralType")
                    .IsUnique()
                    .HasFillFactor((byte)80);

                entity.Property(e => e.ReferralTypeId).HasColumnName("ReferralTypeID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ActiveToDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("('12/31/2078')");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ReferralType)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpReconSettlementType>(entity =>
            {
                entity.HasKey(e => e.SettlementTypeId)
                    .HasName("PK_lkp_Recon_SettlementTypes_SettlementTypeID");

                entity.ToTable("lkp_Recon_SettlementTypes", "recon");

                entity.HasIndex(e => e.SettlementType, "UK1_lkp_Recon_SettlementTypes_SettlementType")
                    .IsUnique()
                    .HasFillFactor((byte)80);

                entity.Property(e => e.SettlementTypeId).HasColumnName("SettlementTypeID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ActiveToDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("('12/31/2078')");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.SettlementType)
                    .IsRequired()
                    .HasMaxLength(25)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpReconStatusType>(entity =>
            {
                entity.HasKey(e => e.StatusId)
                    .HasName("PK_lkp_Recon_StatusTypes_StatusID");

                entity.ToTable("lkp_Recon_StatusTypes", "recon");

                entity.HasIndex(e => e.StatusType, "UK1_lkp_Recon_StatusTypes_StatusType")
                    .IsUnique()
                    .HasFillFactor((byte)80);

                entity.Property(e => e.StatusId).HasColumnName("StatusID");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ActiveToDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("('12/31/2078')");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.StatusType)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblAdvPmtComment>(entity =>
            {
                entity.HasKey(e => e.CommentId)
                    .HasName("PK_tbl_AdvPmt_Comment");

                entity.ToTable("tbl_AdvPmt_Comments", "advpmt");

                entity.HasIndex(e => e.CommentTypeId, "idx_tbl_AdvPmt_Comments_CommentTypeID");

                entity.HasIndex(e => e.ReferralId, "idx_tbl_AdvPmt_Comments_ReferralID");

                entity.Property(e => e.CommentId).HasColumnName("CommentID");

                entity.Property(e => e.CommentDate).HasColumnType("date");

                entity.Property(e => e.CommentText)
                    .IsRequired()
                    .HasMaxLength(333)
                    .IsUnicode(false);

                entity.Property(e => e.CommentTypeId).HasColumnName("CommentTypeID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FollowupDate).HasColumnType("date");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");

                entity.HasOne(d => d.CommentType)
                    .WithMany(p => p.TblAdvPmtComments)
                    .HasForeignKey(d => d.CommentTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_tbl_AdvPmt_Comment_lkp_AdvPmt_CommentType");

                entity.HasOne(d => d.Referral)
                    .WithMany(p => p.TblAdvPmtComments)
                    .HasForeignKey(d => d.ReferralId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_AdvPmt_Comment_tbl_AdvPmt_Referral");
            });

            modelBuilder.Entity<TblAdvPmtDisbursement>(entity =>
            {
                entity.HasKey(e => e.DisbursementId)
                    .HasName("PK_tbl_AdvPmt_Disbursement");

                entity.ToTable("tbl_AdvPmt_Disbursements", "advpmt");

                entity.HasIndex(e => e.DisbursementTypeId, "IDX_tbl_AdvPmt_Disbursements_DisbursementTypeID");

                entity.HasIndex(e => e.ReferralId, "IDX_tbl_AdvPmt_Disbursements_referralID");

                entity.HasIndex(e => new { e.Claimable, e.Waived }, "idx_tbl_AdvPmt_Disbursements_ClaimableWaived");

                entity.Property(e => e.DisbursementId).HasColumnName("DisbursementID");

                entity.Property(e => e.Claim571Payee)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DisbursementTypeId).HasColumnName("DisbursementTypeID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.PreparerName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");

                entity.Property(e => e.TransactionAmount).HasColumnType("money");

                entity.Property(e => e.TransactionDate).HasColumnType("date");

                entity.Property(e => e.Waived).HasDefaultValueSql("((0))");

                entity.HasOne(d => d.DisbursementType)
                    .WithMany(p => p.TblAdvPmtDisbursements)
                    .HasForeignKey(d => d.DisbursementTypeId)
                    .HasConstraintName("FK2_tbl_AdvPmt_Disbursements_lkp_AdvPmt_DisbursementTypes");

                entity.HasOne(d => d.Referral)
                    .WithMany(p => p.TblAdvPmtDisbursements)
                    .HasForeignKey(d => d.ReferralId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_AdvPmt_Disbursements_tbl_AdvPmt_Referrals");
            });

            modelBuilder.Entity<TblAdvPmtLegacyInvoicingJob>(entity =>
            {
                entity.HasKey(e => e.LegacyInvoicingJobId);

                entity.ToTable("tbl_AdvPmt_LegacyInvoicingJobs", "advpmt");

                entity.HasIndex(e => e.JobName, "UK1_tbl_AdvPmt_LegacyInvoicingJobs_JobName")
                    .IsUnique();

                entity.Property(e => e.LegacyInvoicingJobId).HasColumnName("LegacyInvoicingJobID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.JobDescription)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.JobName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");
            });

            modelBuilder.Entity<TblAdvPmtLegacyInvoicingJobGroupsJobHistory>(entity =>
            {
                entity.HasKey(e => e.LegacyInvoicingJobGroupJobHistoryId)
                    .HasName("PK_LegacyInvoicingJobGroupsJobHistories");

                entity.ToTable("tbl_AdvPmt_LegacyInvoicingJobGroupsJobHistories", "advpmt");

                entity.Property(e => e.LegacyInvoicingJobGroupJobHistoryId).HasColumnName("LegacyInvoicingJobGroupJobHistoryID");

                entity.Property(e => e.EndDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.ErrorMessage)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.LegacyInvoicingJobHistoryId).HasColumnName("LegacyInvoicingJobHistoryID");

                entity.Property(e => e.LegacyInvoicingJobsGroupsId).HasColumnName("LegacyInvoicingJobsGroupsID");

                entity.Property(e => e.StartDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.HasOne(d => d.LegacyInvoicingJobHistory)
                    .WithMany(p => p.TblAdvPmtLegacyInvoicingJobGroupsJobHistories)
                    .HasForeignKey(d => d.LegacyInvoicingJobHistoryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_AdvPmt_LegacyInvoicingJobGroupsJobHistories_tbl_AdvPmt_LegacyInvoicingJobHistories");

                entity.HasOne(d => d.LegacyInvoicingJobsGroups)
                    .WithMany(p => p.TblAdvPmtLegacyInvoicingJobGroupsJobHistories)
                    .HasForeignKey(d => d.LegacyInvoicingJobsGroupsId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_tbl_AdvPmt_LegacyInvoicingJobGroupsJobHistories_xref_AdvPmt_LegacyInvoicingJobsGroups");
            });

            modelBuilder.Entity<TblAdvPmtLegacyInvoicingJobHistory>(entity =>
            {
                entity.HasKey(e => e.LegacyInvoicingJobHistoryId);

                entity.ToTable("tbl_AdvPmt_LegacyInvoicingJobHistories", "advpmt");

                entity.Property(e => e.LegacyInvoicingJobHistoryId).HasColumnName("LegacyInvoicingJobHistoryID");

                entity.Property(e => e.EndDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.LegacyInvoicingJobId).HasColumnName("LegacyInvoicingJobID");

                entity.Property(e => e.StartDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.StatusMessage)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.HasOne(d => d.LegacyInvoicingJob)
                    .WithMany(p => p.TblAdvPmtLegacyInvoicingJobHistories)
                    .HasForeignKey(d => d.LegacyInvoicingJobId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_AdvPmt_LegacyInvoicingJobHistories_tbl_AdvPmt_LegacyInvoicingJobs");
            });

            modelBuilder.Entity<TblAdvPmtReferral>(entity =>
            {
                entity.HasKey(e => e.ReferralId)
                    .HasName("PK_tbl_AdvPmt_Referral");

                entity.ToTable("tbl_AdvPmt_Referrals", "advpmt");

                entity.HasIndex(e => e.BillingReasonId, "idx1_tbl_AdvPmt_Referrals_BillingReasonID");

                entity.HasIndex(e => e.ReferralStatusId, "idx2_tbl_AdvPmt_Referrals_ReferralStatusID");

                entity.HasIndex(e => e.InvoiceStatusId, "idx3_tbl_AdvPmt_Referrals_InvoiceStatusID");

                entity.HasIndex(e => e.FnmaloanNumber, "idx4_tbl_AdvPmt_Referrals_FNMALoanNumber");

                entity.HasIndex(e => e.ServicerId, "idx5_tbl_AdvPmt_Referrals_BusinessEntityID");

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.BillingReasonId).HasColumnName("BillingReasonID");

                entity.Property(e => e.ClosedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FnmaloanNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("FNMALoanNumber");

                entity.Property(e => e.InitialBillingDate).HasColumnType("datetime");

                entity.Property(e => e.InvoiceStatusId).HasColumnName("InvoiceStatusID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.PropertyStateCode)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.ReferralDate).HasColumnType("datetime");

                entity.Property(e => e.ReferralStatusId).HasColumnName("ReferralStatusID");

                entity.Property(e => e.ServicerId).HasColumnName("ServicerID");

                entity.Property(e => e.ServicerLoanNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.BillingReason)
                    .WithMany(p => p.TblAdvPmtReferrals)
                    .HasForeignKey(d => d.BillingReasonId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_AdvPmt_Referrals_lkp_AdvPmt_BillingReasons");

                entity.HasOne(d => d.InvoiceStatus)
                    .WithMany(p => p.TblAdvPmtReferrals)
                    .HasForeignKey(d => d.InvoiceStatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK3_tbl_AdvPmt_Referrals_lkp_AdvPmt_InvoiceStatus");

                entity.HasOne(d => d.ReferralStatus)
                    .WithMany(p => p.TblAdvPmtReferrals)
                    .HasForeignKey(d => d.ReferralStatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_tbl_AdvPmt_Referrals_lkp_AdvPmt_ReferralStatus");

                entity.HasOne(d => d.Servicer)
                    .WithMany(p => p.TblAdvPmtReferrals)
                    .HasForeignKey(d => d.ServicerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK4_tbl_AdvPmt_Referrals_lkp_AdvPmt_Servicers");
            });

            modelBuilder.Entity<TblAdvPmtReferralEdit>(entity =>
            {
                entity.HasKey(e => e.ReferralEditId)
                    .HasName("PK_tbl_Referral_Edits");

                entity.ToTable("tbl_AdvPmt_Referral_Edits", "advpmt");

                entity.Property(e => e.ReferralEditId).HasColumnName("Referral_EditID");

                entity.Property(e => e.CheckinDateTime).HasColumnType("datetime");

                entity.Property(e => e.CheckinUserId).HasColumnName("CheckinUserID");

                entity.Property(e => e.CheckoutDateTime)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.CheckoutUserId).HasColumnName("CheckoutUserID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");

                entity.Property(e => e.WorkstationName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.HasOne(d => d.Referral)
                    .WithMany(p => p.TblAdvPmtReferralEdits)
                    .HasForeignKey(d => d.ReferralId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_Referral_Edits_tbl_AdvPmt_Referrals");
            });

            modelBuilder.Entity<TblDatagramComment>(entity =>
            {
                entity.HasKey(e => e.DatagramCommentId)
                    .HasName("PK_tbl_AssetColl_DatagramComment");

                entity.ToTable("tbl_DatagramComment", "Datagram");

                entity.HasComment("Contains AssetColl Datagram comment information.");

                entity.HasIndex(e => e.CommentTypeId, "idx_AssetColl_DatagramComment_CommentTypeID")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.DatagramReferralId, e.CommentTypeId }, "idx_AssetColl_DatagramComment_DatagramReferralID_CommentTypeID")
                    .HasFillFactor((byte)80);

                entity.Property(e => e.DatagramCommentId).HasColumnName("DatagramCommentID");

                entity.Property(e => e.CommentText)
                    .IsRequired()
                    .HasMaxLength(3000)
                    .IsUnicode(false);

                entity.Property(e => e.CommentTypeId).HasColumnName("CommentTypeID");

                entity.Property(e => e.DatagramReferralId).HasColumnName("DatagramReferralID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.FollowupDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.CommentType)
                    .WithMany(p => p.TblDatagramComments)
                    .HasForeignKey(d => d.CommentTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_tbl_DatagramComment_lkp_Datagram_CommentTypes");

                entity.HasOne(d => d.DatagramReferral)
                    .WithMany(p => p.TblDatagramComments)
                    .HasForeignKey(d => d.DatagramReferralId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_DatagramComment_tbl_DatagramReferral_DataGramReferralID");
            });

            modelBuilder.Entity<TblDatagramImport>(entity =>
            {
                entity.HasKey(e => e.DatagramImportId)
                    .HasName("PK_tbl_AssetColl_Datagram_Import");

                entity.ToTable("tbl_Datagram_Import", "Datagram");

                entity.HasComment("Contains AssetColl Datagram import information.");

                entity.HasIndex(e => new { e.FnmaLoanNumber, e.ReoId }, "UK1_tbl_AssetColl_Datagram_Import_REOID_FNMALoanNumber")
                    .IsUnique();

                entity.Property(e => e.DatagramImportId).HasColumnName("DatagramImportID");

                entity.Property(e => e.DatagramReferralId).HasColumnName("DatagramReferralID");

                entity.Property(e => e.FclSaleDate)
                    .HasColumnType("datetime")
                    .HasColumnName("FCL_SaleDate");

                entity.Property(e => e.FnmaLoanNumber)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("FNMA_LoanNumber");

                entity.Property(e => e.FnmaReceivedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("FNMA_ReceivedDate");

                entity.Property(e => e.ForgivenAmount).HasColumnType("money");

                entity.Property(e => e.PropertyState)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.ReoId)
                    .HasMaxLength(7)
                    .IsUnicode(false)
                    .HasColumnName("REO_ID");

                entity.Property(e => e.RequestedAmount).HasColumnType("money");

                entity.Property(e => e.ServicerLoanNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.TotalPenalty).HasColumnType("money");
            });

            modelBuilder.Entity<TblDatagramReferral>(entity =>
            {
                entity.HasKey(e => e.DatagramReferralId)
                    .HasName("PK_tbl_AssetColl_DatagramReferral");

                entity.ToTable("tbl_DatagramReferral", "Datagram");

                entity.HasComment("Contains AssetColl Datagram referral information.");

                entity.HasIndex(e => new { e.FnmaLoanNumber, e.ReoId }, "UK1_tbl_AssetColl_DatagramReferral_REOID_FNMALoanNumber")
                    .IsUnique();

                entity.HasIndex(e => e.Imported, "idx_AssetColl_DatagramReferral_Imported")
                    .HasFillFactor((byte)80);

                entity.Property(e => e.DatagramReferralId).HasColumnName("DatagramReferralID");

                entity.Property(e => e.DatagramStatusId).HasColumnName("DatagramStatusID");

                entity.Property(e => e.DispositionStatus)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.DispositionStatusDate).HasColumnType("datetime");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.EstimatedReceiptDate).HasColumnType("datetime");

                entity.Property(e => e.FclSaleDate)
                    .HasColumnType("datetime")
                    .HasColumnName("FCL_SaleDate");

                entity.Property(e => e.FnmaLoanNumber)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("FNMA_LoanNumber");

                entity.Property(e => e.FnmaReceivedDate)
                    .HasColumnType("datetime")
                    .HasColumnName("FNMA_ReceivedDate");

                entity.Property(e => e.ForgivenAmount).HasColumnType("money");

                entity.Property(e => e.ImportDate).HasColumnType("datetime");

                entity.Property(e => e.InvoiceDate).HasColumnType("datetime");

                entity.Property(e => e.InvoiceStatusId).HasColumnName("InvoiceStatusID");

                entity.Property(e => e.Invoiced).HasDefaultValueSql("((0))");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.PropertyState)
                    .IsRequired()
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.ReceiptAmount).HasColumnType("money");

                entity.Property(e => e.ReceiptDate).HasColumnType("datetime");

                entity.Property(e => e.ReceivableAmount).HasColumnType("money");

                entity.Property(e => e.ReceivableDate).HasColumnType("datetime");

                entity.Property(e => e.ReceivableStatus)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ReceivableWaivedIndicator)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.ReferralDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ReferralTypeId).HasColumnName("ReferralTypeID");

                entity.Property(e => e.ReoId)
                    .HasMaxLength(7)
                    .IsUnicode(false)
                    .HasColumnName("REO_ID");

                entity.Property(e => e.RequestedAmount).HasColumnType("money");

                entity.Property(e => e.ResponsiblePartyServicerNumber)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerId).HasColumnName("ServicerID");

                entity.Property(e => e.ServicerLoanNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.TotalPenalty).HasColumnType("money");

                entity.Property(e => e.TraxWaiveCodeId).HasColumnName("TRAX_WaiveCodeID");

                entity.Property(e => e.WaivedAmount).HasColumnType("money");

                entity.Property(e => e.WaivedAmountDate).HasColumnType("datetime");

                entity.HasOne(d => d.DatagramStatus)
                    .WithMany(p => p.TblDatagramReferrals)
                    .HasForeignKey(d => d.DatagramStatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_tbl_DatagramReferral_lkp_Datagram_StatusTypes_DataGramStatusID");

                entity.HasOne(d => d.ReferralType)
                    .WithMany(p => p.TblDatagramReferrals)
                    .HasForeignKey(d => d.ReferralTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_DatagramReferral_lkp_Datagram_ReferralTypes_ReferralTypeID");
            });

            modelBuilder.Entity<TblReconClaimItem>(entity =>
            {
                entity.HasKey(e => e.ClaimItemId);

                entity.ToTable("tbl_Recon_ClaimItem", "recon");

                entity.HasComment("Contains referral ID, claim item attribute ID, and claim item attribute value.");

                entity.HasIndex(e => e.ClaimItemAttributeId, "IDX_tbl_Recon_ClaimItem_ClaimItemAttributeID");

                entity.HasIndex(e => new { e.ReferralId, e.ClaimItemAttributeId }, "UK1_tbl_Recon_ClaimItem_ReferralIDClaimItemAttributeID")
                    .IsUnique();

                entity.Property(e => e.ClaimItemId).HasColumnName("ClaimItemID");

                entity.Property(e => e.ClaimItemAttributeId).HasColumnName("ClaimItemAttributeID");

                entity.Property(e => e.ClaimItemAttributeValue)
                    .IsRequired()
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");

                entity.HasOne(d => d.ClaimItemAttribute)
                    .WithMany(p => p.TblReconClaimItems)
                    .HasForeignKey(d => d.ClaimItemAttributeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_tbl_Recon_ClaimItem_lkp_Recon_ClaimItemAttribute");

                entity.HasOne(d => d.Referral)
                    .WithMany(p => p.TblReconClaimItems)
                    .HasForeignKey(d => d.ReferralId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_Recon_ClaimItem_tbl_Recon_Referral");
            });

            modelBuilder.Entity<TblReconComment>(entity =>
            {
                entity.HasKey(e => e.CommentId);

                entity.ToTable("tbl_Recon_Comment", "recon");

                entity.HasComment("Contains referral ID, comment type ID, a bit value to denote if follow up is complete, and a follow up date.");

                entity.HasIndex(e => e.FollowupComplete, "idx_tbl_Recon_Comment_FollowupComplete")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => e.ReferralId, "idx_tbl_Recon_Comment_ReferralID")
                    .HasFillFactor((byte)80);

                entity.Property(e => e.CommentId).HasColumnName("CommentID");

                entity.Property(e => e.CommentText)
                    .IsRequired()
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.CommentTypeId).HasColumnName("CommentTypeID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.FollowupDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");

                entity.HasOne(d => d.CommentType)
                    .WithMany(p => p.TblReconComments)
                    .HasForeignKey(d => d.CommentTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_Recon_Comment_lkp_Recon_CommentTypes");

                entity.HasOne(d => d.Referral)
                    .WithMany(p => p.TblReconComments)
                    .HasForeignKey(d => d.ReferralId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_Recon_Comment_tbl_Recon_Referral");
            });

            modelBuilder.Entity<TblReconEobvalue>(entity =>
            {
                entity.HasKey(e => e.EobvalueId);

                entity.ToTable("tbl_Recon_EOBValues", "recon");

                entity.HasComment("Contains information about Recon EOB Values.");

                entity.HasIndex(e => new { e.ReferralId, e.EobheaderId }, "UK1_tbl_Recon_EOBValues_ReferralID_EOBHeaderID")
                    .IsUnique()
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => e.ReferralId, "idx_tbl_Recon_EOBValues_ReferralID")
                    .HasFillFactor((byte)80);

                entity.Property(e => e.EobvalueId).HasColumnName("EOBValueID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Eobdifference)
                    .HasColumnType("money")
                    .HasColumnName("EOBDifference");

                entity.Property(e => e.EobheaderId).HasColumnName("EOBHeaderID");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.PaidAmount).HasColumnType("money");

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");

                entity.Property(e => e.SubmittedAmount).HasColumnType("money");

                entity.HasOne(d => d.Eobheader)
                    .WithMany(p => p.TblReconEobvalues)
                    .HasForeignKey(d => d.EobheaderId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_tbl_Recon_EOBValues_lkp_Recon_EOBHeaders");

                entity.HasOne(d => d.Referral)
                    .WithMany(p => p.TblReconEobvalues)
                    .HasForeignKey(d => d.ReferralId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_Recon_EOBValues_tbl_Recon_Referral");
            });

            modelBuilder.Entity<TblReconReferral>(entity =>
            {
                entity.HasKey(e => e.ReferralId);

                entity.ToTable("tbl_Recon_Referral", "recon");

                entity.HasComment("Contains information about FNMA Recon referrals.");

                entity.HasIndex(e => e.ReferralTypeId, "IDX_tbl_Recon_Referral_ReferralTypeID");

                entity.HasIndex(e => new { e.ReoId, e.FnmaloanNumber, e.ReferralTypeId }, "UK1_tbl_Recon_Referral_REO_ID_FNMALoanNumber_ReferralTypeID")
                    .IsUnique()
                    .HasFillFactor((byte)80);

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.FnmaloanNumber)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("FNMALoanNumber");

                entity.Property(e => e.InternalFormId).HasColumnName("InternalFormID");

                entity.Property(e => e.IsQcmcfile)
                    .HasColumnName("IsQCMCFile")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.MiclaimFiledDate)
                    .HasColumnType("date")
                    .HasColumnName("MIClaimFiledDate");

                entity.Property(e => e.ReceivedDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.ReconStatusId).HasColumnName("ReconStatusID");

                entity.Property(e => e.ReferralTypeId).HasColumnName("ReferralTypeID");

                entity.Property(e => e.ReoId)
                    .HasMaxLength(7)
                    .IsUnicode(false)
                    .HasColumnName("REO_ID");

                entity.Property(e => e.ResponsiblePartySvcrNbr)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.HasOne(d => d.ReconStatus)
                    .WithMany(p => p.TblReconReferrals)
                    .HasForeignKey(d => d.ReconStatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_Recon_Referral_lkp_Recon_StatusTypes");

                entity.HasOne(d => d.ReferralType)
                    .WithMany(p => p.TblReconReferrals)
                    .HasForeignKey(d => d.ReferralTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_Recon_Referral_lkp_Recon_ReferralTypes");
            });

            modelBuilder.Entity<TblReconTransaction>(entity =>
            {
                entity.HasKey(e => e.TransactionId);

                entity.ToTable("tbl_Recon_Transactions", "recon");

                entity.HasComment("Contains information about recon transactions.");

                entity.HasIndex(e => e.MarkAsRemoved, "IDX_tbl_Recon_Transactions_MarkedAsRemoved");

                entity.HasIndex(e => new { e.ReferralId, e.MarkAsRemoved }, "IDX_tbl_Recon_Transactions_ReferralID_MarkedAsRemoved");

                entity.Property(e => e.TransactionId).HasColumnName("TransactionID");

                entity.Property(e => e.CategoryCodeOfReceiptId).HasColumnName("CategoryCodeOfReceiptID");

                entity.Property(e => e.DateReferral).HasColumnType("datetime");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");

                entity.Property(e => e.TransactionAmount).HasColumnType("money");

                entity.HasOne(d => d.CategoryCodeOfReceipt)
                    .WithMany(p => p.TblReconTransactions)
                    .HasForeignKey(d => d.CategoryCodeOfReceiptId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_tbl_Recon_Transactions_lkp_Recon_CategoryCodes");

                entity.HasOne(d => d.Referral)
                    .WithMany(p => p.TblReconTransactions)
                    .HasForeignKey(d => d.ReferralId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_tbl_Recon_Transactions_tbl_Recon_Referral");
            });

            modelBuilder.Entity<VwAdvPmtAllServicerGroupsInclUserAssignment>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_AdvPmt_AllServicerGroups_incl_UserAssignment", "advpmt");

                entity.Property(e => e.GroupId).HasColumnName("GroupID");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ServicerGroupUserAssignmentId).HasColumnName("ServicerGroup_User_AssignmentID");

                entity.Property(e => e.UserId).HasColumnName("UserID");
            });

            modelBuilder.Entity<VwAdvPmtAllServicerGroupsUnassigned>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_AdvPmt_AllServicerGroups_Unassigned", "advpmt");

                entity.Property(e => e.GroupId).HasColumnName("GroupID");

                entity.Property(e => e.ServicerGroupUserAssignmentId).HasColumnName("ServicerGroup_User_AssignmentID");

                entity.Property(e => e.UserId).HasColumnName("UserID");
            });

            modelBuilder.Entity<VwAdvPmtAllServicersInclServicerGroup>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_AdvPmt_AllServicers_inclServicerGroup", "advpmt");

                entity.Property(e => e.GroupId).HasColumnName("GroupID");

                entity.Property(e => e.ServicerId).HasColumnName("ServicerID");

                entity.Property(e => e.ServicerName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwAdvPmtAllServicersUngrouped>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_AdvPmt_AllServicers_Ungrouped", "advpmt");

                entity.Property(e => e.GroupId).HasColumnName("GroupID");

                entity.Property(e => e.ServicerId).HasColumnName("ServicerID");

                entity.Property(e => e.ServicerName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwAdvPmtCheckedOutReferral>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_AdvPmt_CheckedOutReferrals", "advpmt");

                entity.Property(e => e.CheckOutDateTime).HasColumnType("datetime");

                entity.Property(e => e.CheckinUserId).HasColumnName("CheckinUserID");

                entity.Property(e => e.CheckoutUserId).HasColumnName("CheckoutUserID");

                entity.Property(e => e.FnmaloanNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("FNMALoanNumber");

                entity.Property(e => e.ReferralEditId).HasColumnName("Referral_EditID");

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.WorkstationName)
                    .IsRequired()
                    .HasMaxLength(128)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwAdvPmtGroupsToBeInvoiced>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_AdvPmt_GroupsToBeInvoiced", "advpmt");

                entity.Property(e => e.GroupId).HasColumnName("GroupID");

                entity.Property(e => e.GroupName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwAdvPmtReferralDetail>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_AdvPmt_ReferralDetails", "advpmt");

                entity.Property(e => e.BillingReasonId).HasColumnName("BillingReasonID");

                entity.Property(e => e.CheckoutDateTime).HasColumnType("datetime");

                entity.Property(e => e.CheckoutUserId).HasColumnName("CheckoutUserID");

                entity.Property(e => e.ClosedDate).HasColumnType("datetime");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.FnmaloanNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("FNMALoanNumber");

                entity.Property(e => e.InitialBillingDate).HasColumnType("datetime");

                entity.Property(e => e.InvoiceStatusId).HasColumnName("InvoiceStatusID");

                entity.Property(e => e.LastUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.ReferralDate).HasColumnType("datetime");

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");

                entity.Property(e => e.ReferralStatusId).HasColumnName("ReferralStatusID");

                entity.Property(e => e.ServicerId).HasColumnName("ServicerID");

                entity.Property(e => e.ServicerLoanNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.TotalClaimableAmount).HasColumnType("numeric(19, 4)");

                entity.Property(e => e.TotalExpenseBalance).HasColumnType("numeric(38, 4)");

                entity.Property(e => e.TotalNonClaimableAmount).HasColumnType("numeric(19, 4)");

                entity.Property(e => e.TotalWaivedAmount).HasColumnType("numeric(38, 4)");

                entity.Property(e => e.WorkstationName)
                    .HasMaxLength(128)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwAdvPmtRole>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_AdvPmt_Roles", "advpmt");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.ApplicationName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ApplicationRoleId).HasColumnName("ApplicationRoleID");

                entity.Property(e => e.RoleId).HasColumnName("roleID");

                entity.Property(e => e.RoleName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwAdvPmtUser>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_AdvPmt_Users", "advpmt");

                entity.Property(e => e.Login)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PhoneNum)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.UserEmailAddress)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwAdvPmtUserApplicationRole>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_AdvPmt_UserApplicationRole", "advpmt");

                entity.Property(e => e.ApplicationId).HasColumnName("ApplicationID");

                entity.Property(e => e.RoleId).HasColumnName("RoleID");

                entity.Property(e => e.UserId).HasColumnName("UserID");
            });

            modelBuilder.Entity<VwDataGramFindClaim>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_DataGram_FindClaims", "Datagram");

                entity.Property(e => e.FnmaLoanNumber)
                    .HasMaxLength(8000)
                    .IsUnicode(false)
                    .HasColumnName("FNMA_LoanNumber");

                entity.Property(e => e.ReferralDate).HasColumnType("datetime");

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");

                entity.Property(e => e.ReferralType)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ReferralTypeId).HasColumnName("ReferralTypeID");

                entity.Property(e => e.ReoId)
                    .HasMaxLength(7)
                    .IsUnicode(false)
                    .HasColumnName("REO_ID");

                entity.Property(e => e.StatusId).HasColumnName("StatusID");

                entity.Property(e => e.StatusType)
                    .IsRequired()
                    .HasMaxLength(35)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwEmployee>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_Employees", "advpmt");

                entity.Property(e => e.Login)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserEmailAddress)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UserId)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("UserID");

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwReconCore>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_Recon_Core", "recon");

                entity.Property(e => e.FnmaloanNumber)
                    .HasMaxLength(8000)
                    .IsUnicode(false)
                    .HasColumnName("FNMALoanNumber");

                entity.Property(e => e.MicertificateNumber)
                    .HasMaxLength(8000)
                    .IsUnicode(false)
                    .HasColumnName("MICertificateNumber");

                entity.Property(e => e.Micompany)
                    .HasMaxLength(75)
                    .IsUnicode(false)
                    .HasColumnName("MICompany");

                entity.Property(e => e.MicompanyId).HasColumnName("MICompanyID");

                entity.Property(e => e.ReconStatus)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");

                entity.Property(e => e.ReferralType)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ReferralTypeId).HasColumnName("ReferralTypeID");

                entity.Property(e => e.ReoId)
                    .HasMaxLength(7)
                    .IsUnicode(false)
                    .HasColumnName("REO_ID");

                entity.Property(e => e.ServicerId).HasColumnName("ServicerID");

                entity.Property(e => e.ServicerLoanNumber)
                    .HasMaxLength(8000)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerName)
                    .HasMaxLength(75)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwReconMonthlyReconcile>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_Recon_Monthly_Reconcile", "recon");

                entity.Property(e => e.CategoryCodeOfReceipt)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ClosedDate).HasColumnType("smalldatetime");

                entity.Property(e => e.LoanNo)
                    .HasMaxLength(8000)
                    .IsUnicode(false)
                    .HasColumnName("LOAN_NO");

                entity.Property(e => e.ReferralDate).HasColumnType("smalldatetime");

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");

                entity.Property(e => e.ReferralStatus)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ReferralType)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ReoId)
                    .HasMaxLength(7)
                    .IsUnicode(false)
                    .HasColumnName("REO_ID");

                entity.Property(e => e.StatusDate).HasColumnType("smalldatetime");
            });

            modelBuilder.Entity<VwReconQueue>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_Recon_Queue", "recon");

                entity.Property(e => e.FnmaloanNumber)
                    .HasMaxLength(8000)
                    .IsUnicode(false)
                    .HasColumnName("FNMALoanNumber");

                entity.Property(e => e.FollowUpType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FollowupDate).HasColumnType("datetime");

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");

                entity.Property(e => e.ReferralTypeId).HasColumnName("ReferralTypeID");

                entity.Property(e => e.ReoId)
                    .HasMaxLength(7)
                    .IsUnicode(false)
                    .HasColumnName("REO_ID");
            });

            modelBuilder.Entity<VwReconQueueBulkReferral>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_Recon_Queue_BulkReferrals", "recon");

                entity.Property(e => e.FnmaloanNumber)
                    .HasMaxLength(8000)
                    .IsUnicode(false)
                    .HasColumnName("FNMALoanNumber");

                entity.Property(e => e.FollowUpType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FollowupDate).HasColumnType("datetime");

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");

                entity.Property(e => e.ReferralTypeId).HasColumnName("ReferralTypeID");

                entity.Property(e => e.ReoId)
                    .HasMaxLength(7)
                    .IsUnicode(false)
                    .HasColumnName("REO_ID");
            });

            modelBuilder.Entity<VwReconQueueCommentFollowUp>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_Recon_Queue_CommentFollowUp", "recon");

                entity.Property(e => e.FnmaloanNumber)
                    .HasMaxLength(8000)
                    .IsUnicode(false)
                    .HasColumnName("FNMALoanNumber");

                entity.Property(e => e.FollowUpType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FollowupDate).HasColumnType("datetime");

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");

                entity.Property(e => e.ReferralTypeId).HasColumnName("ReferralTypeID");

                entity.Property(e => e.ReoId)
                    .HasMaxLength(7)
                    .IsUnicode(false)
                    .HasColumnName("REO_ID");
            });

            modelBuilder.Entity<VwReconQueueProcessor>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_Recon_Queue_Processor", "recon");

                entity.Property(e => e.FnmaloanNumber)
                    .HasMaxLength(8000)
                    .IsUnicode(false)
                    .HasColumnName("FNMALoanNumber");

                entity.Property(e => e.FollowUpType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FollowupDate).HasColumnType("datetime");

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");

                entity.Property(e => e.ReferralTypeId).HasColumnName("ReferralTypeID");

                entity.Property(e => e.ReoId)
                    .HasMaxLength(7)
                    .IsUnicode(false)
                    .HasColumnName("REO_ID");
            });

            modelBuilder.Entity<VwReconQueueSupervisor>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_Recon_Queue_Supervisor", "recon");

                entity.Property(e => e.FnmaloanNumber)
                    .HasMaxLength(8000)
                    .IsUnicode(false)
                    .HasColumnName("FNMALoanNumber");

                entity.Property(e => e.FollowUpType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FollowupDate).HasColumnType("datetime");

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");

                entity.Property(e => e.ReferralTypeId).HasColumnName("ReferralTypeID");

                entity.Property(e => e.ReoId)
                    .HasMaxLength(7)
                    .IsUnicode(false)
                    .HasColumnName("REO_ID");
            });

            modelBuilder.Entity<VwReconReportChaseCurtailmentBillingLetter>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_Recon_Report_ChaseCurtailmentBillingLetter", "recon");

                entity.Property(e => e.ClaimItemAttributeId).HasColumnName("ClaimItemAttributeID");

                entity.Property(e => e.ClaimItemAttributeValue)
                    .IsRequired()
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.CurtailmentAmount).HasColumnType("money");

                entity.Property(e => e.FnmaloanNumber)
                    .HasMaxLength(8000)
                    .IsUnicode(false)
                    .HasColumnName("FNMALoanNumber");

                entity.Property(e => e.MicertificateNumber)
                    .HasMaxLength(8000)
                    .IsUnicode(false)
                    .HasColumnName("MICertificateNumber");

                entity.Property(e => e.Micompany)
                    .HasMaxLength(75)
                    .IsUnicode(false)
                    .HasColumnName("MICompany");

                entity.Property(e => e.ReferralTypeId).HasColumnName("ReferralTypeID");

                entity.Property(e => e.ServicerBillingDate).HasColumnType("datetime");

                entity.Property(e => e.ServicerLoanNumber)
                    .HasMaxLength(8000)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerName)
                    .HasMaxLength(75)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwReconReportClaimItemAttributeValue>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_Recon_Report_ClaimItemAttributeValues", "recon");

                entity.Property(e => e.AdditionalExpensesAmount)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.BillingStatusId)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("BillingStatusID");

                entity.Property(e => e.City)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.ClosedDate)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.CurrtailmentRequested)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.CurtailmentDifference)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.CurtailmentReceived)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.DisallowanceRequested)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.DiscrepanciesOutsideParamsDate)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.DiscrepanciesWithinParamsDate)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.DispositionDate)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.DispositionStatusId)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("DispositionStatusID");

                entity.Property(e => e.IsCompensatoryFee)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.IsDiscrepanciesOutsideParams)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.IsDiscrepanciesWithinParams)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.IsFileDateVerified)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.IsFiledAmountVerified)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.IsMiCurtailedInError)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("IsMI_CurtailedInError");

                entity.Property(e => e.IsMicoverageVerified)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("IsMICoverageVerified");

                entity.Property(e => e.IsPropertyAddressVerified)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.IsReconciledProceeds)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.IsServiceBilling)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.IsSupplementalFiledInTrax)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("IsSupplementalFiledInTRAX");

                entity.Property(e => e.MiCurtailedInErrorDate)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("MI_CurtailedInErrorDate");

                entity.Property(e => e.MicertificateNumber)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("MICertificateNumber");

                entity.Property(e => e.MicompanyBusinessEntityId)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("MICompanyBusinessEntityID");

                entity.Property(e => e.MipercentCoverage)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("MIPercentCoverage");

                entity.Property(e => e.NetworkFcl)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("Network_FCL");

                entity.Property(e => e.NoBillReasonId)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("NoBillReasonID");

                entity.Property(e => e.OldServicerLoanNumber)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.OtherReceivedFunds)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.PresaleSettlementAmount)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyAddress)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.ReconciledProceedsDate)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.ReconciliationDueDate)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");

                entity.Property(e => e.ServiceBillingDate)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerBusinessEntityId)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("ServicerBusinessEntityID");

                entity.Property(e => e.ServicerLoanNumber)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.SettlementReceivedDate)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.SettlementTypeId)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("SettlementTypeID");

                entity.Property(e => e.State)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.SupplementalDifference)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.SupplementalFiledInTraxdate)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("SupplementalFiledInTRAXDate");

                entity.Property(e => e.SupplementalReceived)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.SupplementalRequested)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.TraxUpbAmount)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("TRAX_UPB_Amount");

                entity.Property(e => e.UpbDifference)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("UPB_Difference");

                entity.Property(e => e.UpbPctDifference)
                    .HasMaxLength(2000)
                    .IsUnicode(false)
                    .HasColumnName("UPB_Pct_Difference");

                entity.Property(e => e.ZipCode)
                    .HasMaxLength(2000)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwReconReportClosedReferral>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_Recon_Report_Closed_Referrals", "recon");

                entity.Property(e => e.BillingStatus)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.CategoryCodeOfReceipt)
                    .IsRequired()
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.CompletedDate).HasColumnType("datetime");

                entity.Property(e => e.FnmaloanNumber)
                    .HasMaxLength(8000)
                    .IsUnicode(false)
                    .HasColumnName("FNMALoanNumber");

                entity.Property(e => e.MicertificateNumber)
                    .HasMaxLength(8000)
                    .IsUnicode(false)
                    .HasColumnName("MICertificateNumber");

                entity.Property(e => e.Micompany)
                    .HasMaxLength(75)
                    .IsUnicode(false)
                    .HasColumnName("MICompany");

                entity.Property(e => e.ReconStatus)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");

                entity.Property(e => e.ReferralTypeId).HasColumnName("ReferralTypeID");

                entity.Property(e => e.ReoId)
                    .HasMaxLength(7)
                    .IsUnicode(false)
                    .HasColumnName("REO_ID");

                entity.Property(e => e.ServicerLoanNumber)
                    .HasMaxLength(8000)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerName)
                    .HasMaxLength(75)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<VwReconReportWorkflowDisposition>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_Recon_Report_Workflow_Disposition", "recon");

                entity.Property(e => e.CategoryCodeOfReceipt)
                    .IsRequired()
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.FnmaloanNumber)
                    .HasMaxLength(8000)
                    .IsUnicode(false)
                    .HasColumnName("FNMALoanNumber");

                entity.Property(e => e.FollowupCompleted)
                    .IsRequired()
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.FollowupDate).HasColumnType("datetime");

                entity.Property(e => e.FollowupType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MicertificateNumber)
                    .HasMaxLength(8000)
                    .IsUnicode(false)
                    .HasColumnName("MICertificateNumber");

                entity.Property(e => e.Micompany)
                    .HasMaxLength(75)
                    .IsUnicode(false)
                    .HasColumnName("MICompany");

                entity.Property(e => e.ReferralTypeId).HasColumnName("ReferralTypeID");

                entity.Property(e => e.ReoId)
                    .HasMaxLength(7)
                    .IsUnicode(false)
                    .HasColumnName("REO_ID");

                entity.Property(e => e.ServicerLoanNumber)
                    .HasMaxLength(8000)
                    .IsUnicode(false);

                entity.Property(e => e.ServicerName)
                    .HasMaxLength(75)
                    .IsUnicode(false);

                entity.Property(e => e.TransactionAmount).HasColumnType("money");
            });

            modelBuilder.Entity<VwReconSettlementAmount>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_Recon_Settlement_Amounts", "recon");

                entity.Property(e => e.CurtailmentDifference).HasColumnType("money");

                entity.Property(e => e.CurtailmentReceived).HasColumnType("money");

                entity.Property(e => e.CurtailmentRequested).HasColumnType("money");

                entity.Property(e => e.DisallowanceRequested).HasColumnType("money");

                entity.Property(e => e.OtherFundsRequested).HasColumnType("money");

                entity.Property(e => e.ReferralId).HasColumnName("ReferralID");

                entity.Property(e => e.SupplementalDifference).HasColumnType("money");

                entity.Property(e => e.SupplementalReceived).HasColumnType("money");

                entity.Property(e => e.SupplementalRequested).HasColumnType("money");
            });

            modelBuilder.Entity<XrefAdvPmtLegacyInvoicingJobsGroup>(entity =>
            {
                entity.HasKey(e => e.LegacyInvoicingJobsGroupsId);

                entity.ToTable("xref_AdvPmt_LegacyInvoicingJobsGroups", "advpmt");

                entity.Property(e => e.LegacyInvoicingJobsGroupsId).HasColumnName("LegacyInvoicingJobsGroupsID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.GroupId).HasColumnName("GroupID");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.LegacyInvoicingJobId).HasColumnName("LegacyInvoicingJobID");

                entity.HasOne(d => d.Group)
                    .WithMany(p => p.XrefAdvPmtLegacyInvoicingJobsGroups)
                    .HasForeignKey(d => d.GroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_AdvPmt_LegacyInvoicingJobsGroups_lkp_AdvPmt_Groups");

                entity.HasOne(d => d.LegacyInvoicingJob)
                    .WithMany(p => p.XrefAdvPmtLegacyInvoicingJobsGroups)
                    .HasForeignKey(d => d.LegacyInvoicingJobId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_AdvPmt_LegacyInvoicingJobsGroups_tbl_AdvPmt_LegacyInvoicingJobs");
            });

            modelBuilder.Entity<XrefAdvPmtServicersGroup>(entity =>
            {
                entity.HasKey(e => e.ServicerGroupId)
                    .HasName("PK_xref_Servicer_ServicerGroup");

                entity.ToTable("xref_AdvPmt_Servicers_Groups", "advpmt");

                entity.HasIndex(e => new { e.ServicerId, e.GroupId }, "UK1_xref_AdvPmt_Servicers_Groups_ServicerID_GroupID")
                    .IsUnique();

                entity.Property(e => e.ServicerGroupId).HasColumnName("ServicerGroupID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.GroupId).HasColumnName("GroupID");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.ServicerId).HasColumnName("ServicerID");

                entity.HasOne(d => d.Group)
                    .WithMany(p => p.XrefAdvPmtServicersGroups)
                    .HasForeignKey(d => d.GroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_xref_AdvPmt_Servicers_Groups_lkp_AdvPmt_Groups");

                entity.HasOne(d => d.Servicer)
                    .WithMany(p => p.XrefAdvPmtServicersGroups)
                    .HasForeignKey(d => d.ServicerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_xref_AdvPmt_Servicers_Groups_lkp_AdvPmt_Servicers");
            });

            modelBuilder.Entity<XrefServicerGroupUserAssignment>(entity =>
            {
                entity.HasKey(e => e.ServicerGroupUserAssignmentId)
                    .HasName("PK_xref_ServicerGroup_User_Assignment");

                entity.ToTable("xref_ServicerGroup_User_Assignments", "advpmt");

                entity.Property(e => e.ServicerGroupUserAssignmentId).HasColumnName("ServicerGroup_User_AssignmentID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.GroupId).HasColumnName("GroupID");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.UserId).HasColumnName("UserID");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
