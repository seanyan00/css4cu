﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblDatagramReferral
    {
        public TblDatagramReferral()
        {
            TblDatagramComment = new HashSet<TblDatagramComment>();
        }

        public int DatagramReferralId { get; set; }
        public string ReoId { get; set; }
        public string FnmaLoanNumber { get; set; }
        public int ReferralTypeId { get; set; }
        public DateTime ReferralDate { get; set; }
        public int ServicerId { get; set; }
        public string ServicerLoanNumber { get; set; }
        public string PropertyState { get; set; }
        public DateTime FclSaleDate { get; set; }
        public DateTime FnmaReceivedDate { get; set; }
        public int NumberDaysBetween { get; set; }
        public decimal TotalPenalty { get; set; }
        public decimal ForgivenAmount { get; set; }
        public decimal RequestedAmount { get; set; }
        public decimal? ReceivableAmount { get; set; }
        public DateTime? ReceivableDate { get; set; }
        public int? ReceivableAge { get; set; }
        public string ReceivableStatus { get; set; }
        public string ReceivableWaivedIndicator { get; set; }
        public decimal? ReceiptAmount { get; set; }
        public DateTime? ReceiptDate { get; set; }
        public string DispositionStatus { get; set; }
        public DateTime? DispositionStatusDate { get; set; }
        public int? DispositionAge { get; set; }
        public decimal? WaivedAmount { get; set; }
        public DateTime? WaivedAmountDate { get; set; }
        public DateTime? EstimatedReceiptDate { get; set; }
        public int DatagramStatusId { get; set; }
        public bool Imported { get; set; }
        public DateTime ImportDate { get; set; }
        public bool? Invoiced { get; set; }
        public DateTime? InvoiceDate { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public int? TraxWaiveCodeId { get; set; }
        public int? InvoiceStatusId { get; set; }
        public string ResponsiblePartyServicerNumber { get; set; }

        public virtual LkpDatagramStatusTypes DatagramStatus { get; set; }
        public virtual LkpDatagramReferralTypes ReferralType { get; set; }
        public virtual ICollection<TblDatagramComment> TblDatagramComment { get; set; }
    }
}
