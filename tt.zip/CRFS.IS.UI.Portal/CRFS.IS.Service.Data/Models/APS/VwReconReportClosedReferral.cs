﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class VwReconReportClosedReferral
    {
        public int ReferralId { get; set; }
        public string FnmaloanNumber { get; set; }
        public string ReoId { get; set; }
        public string ServicerName { get; set; }
        public string ServicerLoanNumber { get; set; }
        public string Micompany { get; set; }
        public string MicertificateNumber { get; set; }
        public string CategoryCodeOfReceipt { get; set; }
        public string ReconStatus { get; set; }
        public string BillingStatus { get; set; }
        public DateTime? CompletedDate { get; set; }
        public int ReferralTypeId { get; set; }
    }
}
