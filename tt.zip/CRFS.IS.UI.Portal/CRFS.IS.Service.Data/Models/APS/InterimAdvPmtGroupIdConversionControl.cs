﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class InterimAdvPmtGroupIdConversionControl
    {
        public string GroupName { get; set; }
        public int NewGroupId { get; set; }
        public int LegacyGroupId { get; set; }
    }
}
