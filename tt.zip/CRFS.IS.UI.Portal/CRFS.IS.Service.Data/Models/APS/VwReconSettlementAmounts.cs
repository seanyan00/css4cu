﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class VwReconSettlementAmounts
    {
        public int ReferralId { get; set; }
        public decimal? CurtailmentRequested { get; set; }
        public decimal? CurtailmentReceived { get; set; }
        public decimal? CurtailmentDifference { get; set; }
        public decimal? SupplementalRequested { get; set; }
        public decimal? SupplementalReceived { get; set; }
        public decimal? SupplementalDifference { get; set; }
        public decimal? DisallowanceRequested { get; set; }
        public decimal? OtherFundsRequested { get; set; }
    }
}
