﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpAdvPmtGroups
    {
        public LkpAdvPmtGroups()
        {
            XrefAdvPmtLegacyInvoicingJobsGroups = new HashSet<XrefAdvPmtLegacyInvoicingJobsGroups>();
            XrefAdvPmtServicersGroups = new HashSet<XrefAdvPmtServicersGroups>();
        }

        public int GroupId { get; set; }
        public string GroupName { get; set; }
        public DateTime EffectiveFromDate { get; set; }
        public DateTime EffectiveToDate { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual ICollection<XrefAdvPmtLegacyInvoicingJobsGroups> XrefAdvPmtLegacyInvoicingJobsGroups { get; set; }
        public virtual ICollection<XrefAdvPmtServicersGroups> XrefAdvPmtServicersGroups { get; set; }
    }
}
