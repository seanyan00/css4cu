﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class XrefServicerGroupUserAssignment
    {
        public int ServicerGroupUserAssignmentId { get; set; }
        public int GroupId { get; set; }
        public int UserId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }
    }
}
