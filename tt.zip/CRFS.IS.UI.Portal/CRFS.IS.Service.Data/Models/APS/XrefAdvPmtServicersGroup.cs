﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class XrefAdvPmtServicersGroup
    {
        public int ServicerGroupId { get; set; }
        public int ServicerId { get; set; }
        public int GroupId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual LkpAdvPmtGroup Group { get; set; }
        public virtual LkpAdvPmtServicer Servicer { get; set; }
    }
}
