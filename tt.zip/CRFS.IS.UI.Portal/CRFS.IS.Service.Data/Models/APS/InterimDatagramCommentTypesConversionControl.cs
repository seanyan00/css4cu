﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class InterimDatagramCommentTypesConversionControl
    {
        public int DatagramCommentId { get; set; }
        public int OldCommentTypeId { get; set; }
        public int NewCommentTypeId { get; set; }
    }
}
