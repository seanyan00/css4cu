﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class InterimDatagramCommentTypesConversionControl
    {
        public int DatagramCommentId { get; set; }
        public int OldCommentTypeId { get; set; }
        public int NewCommentTypeId { get; set; }
    }
}
