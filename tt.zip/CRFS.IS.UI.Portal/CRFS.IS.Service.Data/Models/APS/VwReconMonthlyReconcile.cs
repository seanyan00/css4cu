﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class VwReconMonthlyReconcile
    {
        public int ReferralId { get; set; }
        public string LoanNo { get; set; }
        public string ReoId { get; set; }
        public string CategoryCodeOfReceipt { get; set; }
        public string ReferralStatus { get; set; }
        public string ReferralType { get; set; }
        public DateTime? ReferralDate { get; set; }
        public DateTime? ClosedDate { get; set; }
        public DateTime? StatusDate { get; set; }
    }
}
