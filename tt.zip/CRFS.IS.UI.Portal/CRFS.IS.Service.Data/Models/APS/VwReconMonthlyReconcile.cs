﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class VwReconMonthlyReconcile
    {
        public int ReferralId { get; set; }
        public string LoanNo { get; set; }
        public string ReoId { get; set; }
        public string CategoryCodeOfReceipt { get; set; }
        public string ReferralStatus { get; set; }
        public string ReferralType { get; set; }
        public DateTime? ReferralDate { get; set; }
        public DateTime? ClosedDate { get; set; }
        public DateTime? StatusDate { get; set; }
    }
}
