﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class VwReconCore
    {
        public int ReferralId { get; set; }
        public string FnmaloanNumber { get; set; }
        public string ReoId { get; set; }
        public string ServicerName { get; set; }
        public int? ServicerId { get; set; }
        public string ServicerLoanNumber { get; set; }
        public string Micompany { get; set; }
        public int? MicompanyId { get; set; }
        public string MicertificateNumber { get; set; }
        public string ReconStatus { get; set; }
        public int ReferralTypeId { get; set; }
        public string ReferralType { get; set; }
    }
}
