﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class VwAdvPmtCheckedOutReferral
    {
        public long ReferralEditId { get; set; }
        public long ReferralId { get; set; }
        public string WorkstationName { get; set; }
        public string FnmaloanNumber { get; set; }
        public int CheckoutUserId { get; set; }
        public string UserName { get; set; }
        public DateTime CheckOutDateTime { get; set; }
        public int? CheckinUserId { get; set; }
    }
}
