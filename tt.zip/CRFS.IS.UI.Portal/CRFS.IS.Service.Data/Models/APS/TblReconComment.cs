﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblReconComment
    {
        public int CommentId { get; set; }
        public int ReferralId { get; set; }
        public int CommentTypeId { get; set; }
        public bool FollowupComplete { get; set; }
        public DateTime? FollowupDate { get; set; }
        public string CommentText { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual LkpReconCommentType CommentType { get; set; }
        public virtual TblReconReferral Referral { get; set; }
    }
}
