﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblAdvPmtReferralEdits
    {
        public long ReferralEditId { get; set; }
        public long ReferralId { get; set; }
        public string WorkstationName { get; set; }
        public DateTime CheckoutDateTime { get; set; }
        public int CheckoutUserId { get; set; }
        public DateTime? CheckinDateTime { get; set; }
        public int? CheckinUserId { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public bool MarkedForDelete { get; set; }

        public virtual TblAdvPmtReferrals Referral { get; set; }
    }
}
