﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class VwEmployee
    {
        public int UserId { get; set; }
        public string Login { get; set; }
        public string UserName { get; set; }
        public bool Active { get; set; }
        public string UserEmailAddress { get; set; }
    }
}
