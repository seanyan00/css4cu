﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class VwAdvPmtUserApplicationRole
    {
        public int RoleId { get; set; }
        public int ApplicationId { get; set; }
        public int UserId { get; set; }
    }
}
