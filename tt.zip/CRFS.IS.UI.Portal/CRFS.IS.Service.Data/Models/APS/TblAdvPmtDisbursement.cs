﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblAdvPmtDisbursement
    {
        public long DisbursementId { get; set; }
        public long ReferralId { get; set; }
        public int? DisbursementTypeId { get; set; }
        public DateTime? TransactionDate { get; set; }
        public string PreparerName { get; set; }
        public decimal TransactionAmount { get; set; }
        public string Claim571Payee { get; set; }
        public bool Claimable { get; set; }
        public bool? Waived { get; set; }
        public bool? MarkedForDelete { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual LkpAdvPmtDisbursementType DisbursementType { get; set; }
        public virtual TblAdvPmtReferral Referral { get; set; }
    }
}
