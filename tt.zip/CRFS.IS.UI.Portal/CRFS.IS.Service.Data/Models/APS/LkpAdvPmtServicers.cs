﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpAdvPmtServicers
    {
        public LkpAdvPmtServicers()
        {
            TblAdvPmtReferrals = new HashSet<TblAdvPmtReferrals>();
            XrefAdvPmtServicersGroups = new HashSet<XrefAdvPmtServicersGroups>();
        }

        public int ServicerId { get; set; }
        public string ServicerName { get; set; }
        public DateTime EffectiveFromDate { get; set; }
        public DateTime EffectiveToDate { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public DateTime LastUpdateUserId { get; set; }

        public virtual ICollection<TblAdvPmtReferrals> TblAdvPmtReferrals { get; set; }
        public virtual ICollection<XrefAdvPmtServicersGroups> XrefAdvPmtServicersGroups { get; set; }
    }
}
