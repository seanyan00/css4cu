﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblReconTransactions
    {
        public int TransactionId { get; set; }
        public int ReferralId { get; set; }
        public int CategoryCodeOfReceiptId { get; set; }
        public decimal TransactionAmount { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public bool MarkAsRemoved { get; set; }
        public DateTime? DateReferral { get; set; }

        public virtual LkpReconCategoryCodes CategoryCodeOfReceipt { get; set; }
        public virtual TblReconReferral Referral { get; set; }
    }
}
