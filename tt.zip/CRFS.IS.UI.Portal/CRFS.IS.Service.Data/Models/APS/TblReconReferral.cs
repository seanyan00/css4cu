﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblReconReferral
    {
        public TblReconReferral()
        {
            TblReconClaimItem = new HashSet<TblReconClaimItem>();
            TblReconComment = new HashSet<TblReconComment>();
            TblReconEobvalues = new HashSet<TblReconEobvalues>();
            TblReconTransactions = new HashSet<TblReconTransactions>();
        }

        public int ReferralId { get; set; }
        public string ReoId { get; set; }
        public string FnmaloanNumber { get; set; }
        public int ReferralTypeId { get; set; }
        public int ReconStatusId { get; set; }
        public int InternalFormId { get; set; }
        public DateTime ReceivedDate { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public bool? IsQcmcfile { get; set; }
        public string ResponsiblePartySvcrNbr { get; set; }
        public DateTime? MiclaimFiledDate { get; set; }

        public virtual LkpReconStatusTypes ReconStatus { get; set; }
        public virtual LkpReconReferralTypes ReferralType { get; set; }
        public virtual ICollection<TblReconClaimItem> TblReconClaimItem { get; set; }
        public virtual ICollection<TblReconComment> TblReconComment { get; set; }
        public virtual ICollection<TblReconEobvalues> TblReconEobvalues { get; set; }
        public virtual ICollection<TblReconTransactions> TblReconTransactions { get; set; }
    }
}
