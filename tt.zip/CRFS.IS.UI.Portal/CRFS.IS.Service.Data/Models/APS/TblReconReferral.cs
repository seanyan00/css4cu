﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblReconReferral
    {
        public TblReconReferral()
        {
            TblReconClaimItems = new HashSet<TblReconClaimItem>();
            TblReconComments = new HashSet<TblReconComment>();
            TblReconEobvalues = new HashSet<TblReconEobvalue>();
            TblReconTransactions = new HashSet<TblReconTransaction>();
        }

        public int ReferralId { get; set; }
        public string ReoId { get; set; }
        public string FnmaloanNumber { get; set; }
        public int ReferralTypeId { get; set; }
        public int ReconStatusId { get; set; }
        public int InternalFormId { get; set; }
        public DateTime ReceivedDate { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public bool? IsQcmcfile { get; set; }
        public string ResponsiblePartySvcrNbr { get; set; }
        public DateTime? MiclaimFiledDate { get; set; }

        public virtual LkpReconStatusType ReconStatus { get; set; }
        public virtual LkpReconReferralType ReferralType { get; set; }
        public virtual ICollection<TblReconClaimItem> TblReconClaimItems { get; set; }
        public virtual ICollection<TblReconComment> TblReconComments { get; set; }
        public virtual ICollection<TblReconEobvalue> TblReconEobvalues { get; set; }
        public virtual ICollection<TblReconTransaction> TblReconTransactions { get; set; }
    }
}
