﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class VwDataGramFindClaims
    {
        public int ReferralId { get; set; }
        public string ReoId { get; set; }
        public string FnmaLoanNumber { get; set; }
        public int ReferralTypeId { get; set; }
        public string ReferralType { get; set; }
        public DateTime ReferralDate { get; set; }
        public int StatusId { get; set; }
        public string StatusType { get; set; }
    }
}
