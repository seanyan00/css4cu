﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblDatagramComment
    {
        public int DatagramCommentId { get; set; }
        public int DatagramReferralId { get; set; }
        public int CommentTypeId { get; set; }
        public bool FollowupComplete { get; set; }
        public DateTime? FollowupDate { get; set; }
        public string CommentText { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual LkpDatagramCommentTypes CommentType { get; set; }
        public virtual TblDatagramReferral DatagramReferral { get; set; }
    }
}
