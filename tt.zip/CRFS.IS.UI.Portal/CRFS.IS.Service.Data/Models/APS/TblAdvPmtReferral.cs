﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblAdvPmtReferral
    {
        public TblAdvPmtReferral()
        {
            TblAdvPmtComments = new HashSet<TblAdvPmtComment>();
            TblAdvPmtDisbursements = new HashSet<TblAdvPmtDisbursement>();
            TblAdvPmtReferralEdits = new HashSet<TblAdvPmtReferralEdit>();
        }

        public long ReferralId { get; set; }
        public int BillingReasonId { get; set; }
        public int ReferralStatusId { get; set; }
        public int InvoiceStatusId { get; set; }
        public DateTime ReferralDate { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public bool MarkedForDelete { get; set; }
        public int ApplicationId { get; set; }
        public string FnmaloanNumber { get; set; }
        public string PropertyStateCode { get; set; }
        public int ServicerId { get; set; }
        public string ServicerNumber { get; set; }
        public string ServicerLoanNumber { get; set; }
        public DateTime? InitialBillingDate { get; set; }
        public bool IsClosed { get; set; }
        public DateTime ClosedDate { get; set; }

        public virtual LkpAdvPmtBillingReason BillingReason { get; set; }
        public virtual LkpAdvPmtInvoiceStatus InvoiceStatus { get; set; }
        public virtual LkpAdvPmtReferralStatus ReferralStatus { get; set; }
        public virtual LkpAdvPmtServicer Servicer { get; set; }
        public virtual ICollection<TblAdvPmtComment> TblAdvPmtComments { get; set; }
        public virtual ICollection<TblAdvPmtDisbursement> TblAdvPmtDisbursements { get; set; }
        public virtual ICollection<TblAdvPmtReferralEdit> TblAdvPmtReferralEdits { get; set; }
    }
}
