﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblAdvPmtLegacyInvoicingJob
    {
        public TblAdvPmtLegacyInvoicingJob()
        {
            TblAdvPmtLegacyInvoicingJobHistories = new HashSet<TblAdvPmtLegacyInvoicingJobHistory>();
            XrefAdvPmtLegacyInvoicingJobsGroups = new HashSet<XrefAdvPmtLegacyInvoicingJobsGroup>();
        }

        public int LegacyInvoicingJobId { get; set; }
        public string JobName { get; set; }
        public string JobDescription { get; set; }
        public bool MarkedForDelete { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }

        public virtual ICollection<TblAdvPmtLegacyInvoicingJobHistory> TblAdvPmtLegacyInvoicingJobHistories { get; set; }
        public virtual ICollection<XrefAdvPmtLegacyInvoicingJobsGroup> XrefAdvPmtLegacyInvoicingJobsGroups { get; set; }
    }
}
