﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblAdvPmtComment
    {
        public long CommentId { get; set; }
        public long ReferralId { get; set; }
        public int CommentTypeId { get; set; }
        public string CommentText { get; set; }
        public DateTime? CommentDate { get; set; }
        public bool FollowupComplete { get; set; }
        public DateTime FollowupDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public bool? MarkedForDelete { get; set; }

        public virtual LkpAdvPmtCommentType CommentType { get; set; }
        public virtual TblAdvPmtReferral Referral { get; set; }
    }
}
