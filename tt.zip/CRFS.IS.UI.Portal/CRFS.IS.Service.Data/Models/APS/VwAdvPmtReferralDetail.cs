﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class VwAdvPmtReferralDetail
    {
        public long ReferralId { get; set; }
        public string FnmaloanNumber { get; set; }
        public int ServicerId { get; set; }
        public string ServicerLoanNumber { get; set; }
        public string ServicerNumber { get; set; }
        public int BillingReasonId { get; set; }
        public DateTime ReferralDate { get; set; }
        public DateTime? InitialBillingDate { get; set; }
        public decimal? TotalNonClaimableAmount { get; set; }
        public decimal? TotalClaimableAmount { get; set; }
        public decimal? TotalWaivedAmount { get; set; }
        public decimal? TotalExpenseBalance { get; set; }
        public int ReferralStatusId { get; set; }
        public int InvoiceStatusId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public bool IsClosed { get; set; }
        public DateTime ClosedDate { get; set; }
        public bool? IsLocked { get; set; }
        public int? LockedBy { get; set; }
    }
}
