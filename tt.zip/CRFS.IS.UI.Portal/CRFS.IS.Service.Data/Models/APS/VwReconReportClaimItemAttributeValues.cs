﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class VwReconReportClaimItemAttributeValues
    {
        public int ReferralId { get; set; }
        public string OtherReceivedFunds { get; set; }
        public string OldServicerLoanNumber { get; set; }
        public string ClosedDate { get; set; }
        public string SupplementalFiledInTraxdate { get; set; }
        public string IsSupplementalFiledInTrax { get; set; }
        public string DiscrepanciesOutsideParamsDate { get; set; }
        public string IsDiscrepanciesOutsideParams { get; set; }
        public string DiscrepanciesWithinParamsDate { get; set; }
        public string IsDiscrepanciesWithinParams { get; set; }
        public string MiCurtailedInErrorDate { get; set; }
        public string IsMiCurtailedInError { get; set; }
        public string ServiceBillingDate { get; set; }
        public string IsServiceBilling { get; set; }
        public string ReconciledProceedsDate { get; set; }
        public string IsReconciledProceeds { get; set; }
        public string DisallowanceRequested { get; set; }
        public string SupplementalDifference { get; set; }
        public string SupplementalReceived { get; set; }
        public string SupplementalRequested { get; set; }
        public string CurtailmentDifference { get; set; }
        public string CurtailmentReceived { get; set; }
        public string CurrtailmentRequested { get; set; }
        public string UpbPctDifference { get; set; }
        public string AdditionalExpensesAmount { get; set; }
        public string PresaleSettlementAmount { get; set; }
        public string NetworkFcl { get; set; }
        public string UpbDifference { get; set; }
        public string IsCompensatoryFee { get; set; }
        public string NoBillReasonId { get; set; }
        public string BillingStatusId { get; set; }
        public string IsPropertyAddressVerified { get; set; }
        public string IsFiledAmountVerified { get; set; }
        public string IsFileDateVerified { get; set; }
        public string TraxUpbAmount { get; set; }
        public string IsMicoverageVerified { get; set; }
        public string SettlementTypeId { get; set; }
        public string ReconciliationDueDate { get; set; }
        public string SettlementReceivedDate { get; set; }
        public string DispositionStatusId { get; set; }
        public string DispositionDate { get; set; }
        public string ZipCode { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string PropertyAddress { get; set; }
        public string MipercentCoverage { get; set; }
        public string MicertificateNumber { get; set; }
        public string MicompanyBusinessEntityId { get; set; }
        public string ServicerLoanNumber { get; set; }
        public string ServicerBusinessEntityId { get; set; }
    }
}
