﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class VwAdvPmtCheckedOutReferrals
    {
        public long ReferralEditId { get; set; }
        public long ReferralId { get; set; }
        public string WorkstationName { get; set; }
        public string FnmaloanNumber { get; set; }
        public int CheckoutUserId { get; set; }
        public string UserName { get; set; }
        public DateTime CheckOutDateTime { get; set; }
        public int? CheckinUserId { get; set; }
    }
}
