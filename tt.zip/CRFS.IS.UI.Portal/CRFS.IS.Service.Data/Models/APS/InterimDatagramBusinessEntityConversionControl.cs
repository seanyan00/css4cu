﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class InterimDatagramBusinessEntityConversionControl
    {
        public int DatagramReferralId { get; set; }
        public int LegacyServicerId { get; set; }
        public int? NewServicerId { get; set; }
    }
}
