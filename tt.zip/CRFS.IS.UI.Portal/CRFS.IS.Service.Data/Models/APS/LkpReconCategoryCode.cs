﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpReconCategoryCode
    {
        public LkpReconCategoryCode()
        {
            TblReconTransactions = new HashSet<TblReconTransaction>();
        }

        public int CategoryCodeOfReceiptId { get; set; }
        public string CategoryCodeOfReceipt { get; set; }
        public string Description { get; set; }
        public bool? Active { get; set; }
        public DateTime? ActiveToDate { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUserId { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUserId { get; set; }
        public bool? MarkedForDelete { get; set; }

        public virtual ICollection<TblReconTransaction> TblReconTransactions { get; set; }
    }
}
