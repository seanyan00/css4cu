﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class XrefAdvPmtServicersGroups
    {
        public int ServicerGroupId { get; set; }
        public int ServicerId { get; set; }
        public int GroupId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual LkpAdvPmtGroups Group { get; set; }
        public virtual LkpAdvPmtServicers Servicer { get; set; }
    }
}
