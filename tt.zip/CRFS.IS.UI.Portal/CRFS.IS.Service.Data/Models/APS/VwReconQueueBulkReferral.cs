﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class VwReconQueueBulkReferral
    {
        public int ReferralId { get; set; }
        public string FnmaloanNumber { get; set; }
        public string ReoId { get; set; }
        public DateTime? FollowupDate { get; set; }
        public string FollowUpType { get; set; }
        public int ReferralTypeId { get; set; }
    }
}
