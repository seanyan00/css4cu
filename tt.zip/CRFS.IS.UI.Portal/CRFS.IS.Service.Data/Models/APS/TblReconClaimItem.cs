﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblReconClaimItem
    {
        public int ClaimItemId { get; set; }
        public int ReferralId { get; set; }
        public int ClaimItemAttributeId { get; set; }
        public string ClaimItemAttributeValue { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual LkpReconClaimItemAttribute ClaimItemAttribute { get; set; }
        public virtual TblReconReferral Referral { get; set; }
    }
}
