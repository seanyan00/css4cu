﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblReconClaimItem
    {
        public int ClaimItemId { get; set; }
        public int ReferralId { get; set; }
        public int ClaimItemAttributeId { get; set; }
        public string ClaimItemAttributeValue { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual LkpReconClaimItemAttribute ClaimItemAttribute { get; set; }
        public virtual TblReconReferral Referral { get; set; }
    }
}
