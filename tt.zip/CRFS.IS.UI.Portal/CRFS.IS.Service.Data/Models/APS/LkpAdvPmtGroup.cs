﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpAdvPmtGroup
    {
        public LkpAdvPmtGroup()
        {
            XrefAdvPmtLegacyInvoicingJobsGroups = new HashSet<XrefAdvPmtLegacyInvoicingJobsGroup>();
            XrefAdvPmtServicersGroups = new HashSet<XrefAdvPmtServicersGroup>();
        }

        public int GroupId { get; set; }
        public string GroupName { get; set; }
        public DateTime EffectiveFromDate { get; set; }
        public DateTime EffectiveToDate { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual ICollection<XrefAdvPmtLegacyInvoicingJobsGroup> XrefAdvPmtLegacyInvoicingJobsGroups { get; set; }
        public virtual ICollection<XrefAdvPmtServicersGroup> XrefAdvPmtServicersGroups { get; set; }
    }
}
