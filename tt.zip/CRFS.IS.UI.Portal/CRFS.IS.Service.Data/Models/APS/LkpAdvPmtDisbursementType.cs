﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpAdvPmtDisbursementType
    {
        public LkpAdvPmtDisbursementType()
        {
            TblAdvPmtDisbursements = new HashSet<TblAdvPmtDisbursement>();
        }

        public int DisbursementTypeId { get; set; }
        public string DisbursementTypeDescription { get; set; }
        public bool? Active { get; set; }
        public DateTime? ActiveToDate { get; set; }
        public int? EnteredByUserId { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? LastUpdateUserId { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public bool? MarkedForDelete { get; set; }
        public bool NegativePolarity { get; set; }

        public virtual ICollection<TblAdvPmtDisbursement> TblAdvPmtDisbursements { get; set; }
    }
}
