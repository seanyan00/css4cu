﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class InterimAdvPmtServicerIdConversionControl
    {
        public string ServicerName { get; set; }
        public int NewServicerId { get; set; }
        public int LegacyServicerId { get; set; }
    }
}
