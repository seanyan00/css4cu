﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class VwAdvPmtAllServicerGroupsUnassigned
    {
        public int? ServicerGroupUserAssignmentId { get; set; }
        public int GroupId { get; set; }
        public int? UserId { get; set; }
    }
}
