﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class XrefAdvPmtLegacyInvoicingJobsGroup
    {
        public XrefAdvPmtLegacyInvoicingJobsGroup()
        {
            TblAdvPmtLegacyInvoicingJobGroupsJobHistories = new HashSet<TblAdvPmtLegacyInvoicingJobGroupsJobHistory>();
        }

        public int LegacyInvoicingJobsGroupsId { get; set; }
        public int LegacyInvoicingJobId { get; set; }
        public int GroupId { get; set; }
        public bool MarkedForDelete { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }

        public virtual LkpAdvPmtGroups Group { get; set; }
        public virtual TblAdvPmtLegacyInvoicingJob LegacyInvoicingJob { get; set; }
        public virtual ICollection<TblAdvPmtLegacyInvoicingJobGroupsJobHistory> TblAdvPmtLegacyInvoicingJobGroupsJobHistories { get; set; }
    }
}
