﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblAdvPmtLegacyInvoicingJobHistory
    {
        public TblAdvPmtLegacyInvoicingJobHistory()
        {
            TblAdvPmtLegacyInvoicingJobGroupsJobHistories = new HashSet<TblAdvPmtLegacyInvoicingJobGroupsJobHistory>();
        }

        public int LegacyInvoicingJobHistoryId { get; set; }
        public int LegacyInvoicingJobId { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public bool WasSuccessful { get; set; }
        public string StatusMessage { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }

        public virtual TblAdvPmtLegacyInvoicingJob LegacyInvoicingJob { get; set; }
        public virtual ICollection<TblAdvPmtLegacyInvoicingJobGroupsJobHistory> TblAdvPmtLegacyInvoicingJobGroupsJobHistories { get; set; }
    }
}
