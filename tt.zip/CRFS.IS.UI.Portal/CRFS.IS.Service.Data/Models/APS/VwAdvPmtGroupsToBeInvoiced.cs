﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class VwAdvPmtGroupsToBeInvoiced
    {
        public string GroupName { get; set; }
        public int GroupId { get; set; }
    }
}
