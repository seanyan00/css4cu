﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class InterimDatagramInvoiceStatusTypesConversionControl
    {
        public int DatagramReferralId { get; set; }
        public int? OldInvoiceStatusId { get; set; }
        public int NewInvoiceStatusId { get; set; }
    }
}
