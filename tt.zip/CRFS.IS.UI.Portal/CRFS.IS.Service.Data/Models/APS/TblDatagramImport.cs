﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblDatagramImport
    {
        public int DatagramImportId { get; set; }
        public int? DatagramReferralId { get; set; }
        public string ReoId { get; set; }
        public string FnmaLoanNumber { get; set; }
        public string ServicerName { get; set; }
        public string ServicerLoanNumber { get; set; }
        public string PropertyState { get; set; }
        public DateTime FclSaleDate { get; set; }
        public DateTime FnmaReceivedDate { get; set; }
        public int NumberDaysBetween { get; set; }
        public decimal TotalPenalty { get; set; }
        public decimal? ForgivenAmount { get; set; }
        public decimal RequestedAmount { get; set; }
        public bool ReReferralAllowed { get; set; }
    }
}
