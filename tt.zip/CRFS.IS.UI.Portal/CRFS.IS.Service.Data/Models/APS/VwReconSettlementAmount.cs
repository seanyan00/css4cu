﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class VwReconSettlementAmount
    {
        public int ReferralId { get; set; }
        public decimal? CurtailmentRequested { get; set; }
        public decimal? CurtailmentReceived { get; set; }
        public decimal? CurtailmentDifference { get; set; }
        public decimal? SupplementalRequested { get; set; }
        public decimal? SupplementalReceived { get; set; }
        public decimal? SupplementalDifference { get; set; }
        public decimal? DisallowanceRequested { get; set; }
        public decimal? OtherFundsRequested { get; set; }
    }
}
