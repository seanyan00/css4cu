﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class LkpDatagramInvoiceStatusType
    {
        public int InvoiceStatusId { get; set; }
        public string InvoiceStatus { get; set; }
        public bool? Active { get; set; }
        public DateTime ActiveToDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public bool MarkedForDelete { get; set; }
    }
}
