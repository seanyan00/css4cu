﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class InterimDatagramStatusTypesConversionControl
    {
        public int DatagramReferralId { get; set; }
        public int OldDatagramStatusId { get; set; }
        public int NewStatusId { get; set; }
    }
}
