﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class InterimDatagramReferralTypesConversionControl
    {
        public int DatagramReferralId { get; set; }
        public int OldReferralTypeId { get; set; }
        public int NewReferralTypeId { get; set; }
    }
}
