﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRFS.IS.Service.Data
{
    public partial class TblReconTransaction
    {
        public int TransactionId { get; set; }
        public int ReferralId { get; set; }
        public int CategoryCodeOfReceiptId { get; set; }
        public decimal TransactionAmount { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public bool MarkAsRemoved { get; set; }
        public DateTime? DateReferral { get; set; }

        public virtual LkpReconCategoryCode CategoryCodeOfReceipt { get; set; }
        public virtual TblReconReferral Referral { get; set; }
    }
}
