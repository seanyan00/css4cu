﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRFS.IS.Service.Common
{
    public static class CommonHelper
    {
        public static DateTime SetKind(this DateTime dt, DateTimeKind kind)
        {
            return DateTime.SpecifyKind(dt, kind);
        }
        public static string GetSafeString(this DateTime? dt)
        {
            return dt == null ? "" : ((DateTime)dt).ToString(Constant.DateTimeString);
        }
        public static string GetSafeString(this DateTime dt)
        {
            return dt == null ? "" : dt.ToString(Constant.DateTimeString);
        }
        public static string GetSafeString(this string s)
        {
            return string.IsNullOrEmpty(s) ? "" : s;
        }
        public static T GetSafeValue<T>(this T v)
        {
            Type t = typeof(T);
            if(t == typeof(string))
                return v == null ? (T)(object)string.Empty : v;
            if (t.IsValueType) {
                var ut = Nullable.GetUnderlyingType(t);
                if (ut == null)
                    return v == null ? default(T) : v;
                else {
                    return v == null ? (T)Activator.CreateInstance(ut) : v;
                }
            } 
            return v;
        }
        public static string GetSafeDateString(this string s)
        {
            if (string.IsNullOrEmpty(s))
                return Constant.EmptyDateTime;
            return s;
        }
    }
}
