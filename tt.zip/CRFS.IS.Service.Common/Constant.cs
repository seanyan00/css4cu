﻿using System;

namespace CRFS.IS.Service.Common
{
    public static class Constant
    {
        public const int MB = 1048576;
        public const string DOMAIN = "crfs.crfservices.com";
        public const string EmptyDateTime = "01/01/1900";
        public const string DateTimeString = "MM/dd/yyyy HH:mm:ss";
        public const string Success = "Success";
        public enum UIPrivilege
        {
            None = 0,
            Read,
            Write,
            Delete,
            Admin
        }       
    }
}
