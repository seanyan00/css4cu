﻿using System;
using System.Reflection;

namespace BitMiracle.Common
{
    static class AssemblyAttributes
    {
        public static string GetCompany(Assembly assembly)
        {
            AssemblyCompanyAttribute companyAttr = getCustomAttribute<AssemblyCompanyAttribute>(assembly);
            if (companyAttr == null)
                return string.Empty;

            return companyAttr.Company;
        }

        public static string GetProduct(Assembly assembly)
        {
            AssemblyProductAttribute productAttr = getCustomAttribute<AssemblyProductAttribute>(assembly);
            if (productAttr == null)
                return string.Empty;

            return productAttr.Product;
        }

        private static T getCustomAttribute<T>(Assembly assembly) where T : Attribute
        {
            if (assembly == null)
                throw new ArgumentNullException("assembly");

            return Attribute.GetCustomAttribute(assembly, typeof(T)) as T;
        }
    }
}
