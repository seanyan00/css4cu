﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace CRFS.IS.Service.Util
{
    public static class FileProvider
    {
        public static Task UploadFile(MemoryStream ms, string appname, string filename, string filetype)
        {
            return Task.CompletedTask;
        }
    }
}
