﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using MIGE.Core.Domain;
using MIG.Utilities;

namespace MIG.WindowsService.Processor {


	public class ProfitSharingPlanDetails : BaseEntity
	{

		public ProfitSharingPlanDetails()
		{
			//base.eventLog = eventLog;
		}


		public List<DWXM00102M> GetAllPlans()
		{
			Logger.Log("DWXM00102M - starting process", Logger.LogLevel.INFO, null, "etl");
			//eventLog.WriteEntry("DWXM00102M - starting process");
			List<DWXM00102M> dWXM00102Ms = new List<DWXM00102M>();

			try {
				using (_session = base.OpenSession()) {
					dWXM00102Ms = (from agentms in _session.Query<DWXM00102M>()
								   select agentms).AsEnumerable().ToList();
					Logger.Log("DWXM00102M - got all the records " + dWXM00102Ms.Count, Logger.LogLevel.INFO, null, "etl");
					//eventLog.WriteEntry("DWXM00102M - got all the records " + dWXM00102Ms.Count);
				}
			} catch (Exception ex) {
				Logger.Log("DWXM00102M - error " + ex.Message, Logger.LogLevel.ERROR, ex, "etl");
				//eventLog.WriteEntry("DWXM00102M - error " + ex.Message + " STACK TRACE" + ex.StackTrace, EventLogEntryType.Error);
			}

			using (_sessionSQL = base.OpenSQLSession()) {
				try {
					using (var transaction = _sessionSQL.BeginTransaction()) {
						Logger.Log("DWXM00102M - deleting previous records", Logger.LogLevel.INFO, null, "etl");
						//eventLog.WriteEntry("DWXM00102M - deleting previous records");
						_sessionSQL.CreateSQLQuery("delete from DWXM00102M").SetTimeout(600).ExecuteUpdate();
						transaction.Commit();
						Logger.Log("DWXM00102M - records deleted", Logger.LogLevel.INFO, null, "etl");
						//eventLog.WriteEntry("DWXM00102M - records deleted");
					}
				} catch (Exception ex) {
					Logger.Log("DWXM00102M - error " + ex.Message, Logger.LogLevel.ERROR, ex, "etl");
					//eventLog.WriteEntry("DWXM00102M - error " + ex.Message + " STACK TRACE" + ex.StackTrace, EventLogEntryType.Error);
				}

				try {
					Logger.Log("DWXM00102M - starting record insertion", Logger.LogLevel.INFO, null, "etl");
					//eventLog.WriteEntry("DWXM00102M - starting  insertion records");
					foreach (DWXM00102M dWXF007 in dWXM00102Ms) {
						using (var transaction = _sessionSQL.BeginTransaction()) {
							_sessionSQL.Insert(dWXF007);
							transaction.Commit();
						}
					}
				} catch (Exception ex) {
					Logger.Log("DWXM00102M - error " + ex.Message, Logger.LogLevel.ERROR, ex, "etl");
					//eventLog.WriteEntry("DWXM00102M - error " + ex.Message + " STACK TRACE" + ex.StackTrace, EventLogEntryType.Error);
				}

				Logger.Log("DWXM00102M - finished insertion", Logger.LogLevel.INFO, null, "etl");
				//eventLog.WriteEntry("DWXM00102M - finished insertion");
			}

			return dWXM00102Ms;
		}
	}
}
