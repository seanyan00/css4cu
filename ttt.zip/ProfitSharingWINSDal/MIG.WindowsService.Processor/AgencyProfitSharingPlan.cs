﻿using MIGE.Core.Domain;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using MIG.Utilities;

namespace MIG.WindowsService.Processor {


	public class AgencyProfitSharingPlan : BaseEntity
	{

		public AgencyProfitSharingPlan()
		{
		}


		public int GetAllPlans()
		{
			Logger.Log("DWXM00101M - starting process", Logger.LogLevel.INFO, null, "etl");
			List<DWXM00101M> dWXM00101Ms = new List<DWXM00101M>();
			int iteration = 0;
			int cnt = 0;
			bool stop = false;

			using (_session = base.OpenSession()) {
				using (_sessionSQL = base.OpenSQLSession()) {
					using (var transaction = _sessionSQL.BeginTransaction()) {
						try {
									//  delete old records
							Logger.Log("DWXM00101M - deleting previous records", Logger.LogLevel.INFO, null, "etl");
							_sessionSQL.CreateSQLQuery("delete from DWXM00101M").SetTimeout(1800).ExecuteUpdate();
							Logger.Log("DWXM00101M - records deleted", Logger.LogLevel.INFO, null, "etl");

							do {
									//  extract data from source DB
								dWXM00101Ms = (from agentms in _session.Query<DWXM00101M>()
											   orderby agentms.AGENT, agentms.ACTDTE, agentms.CO, agentms.PROD
											   select agentms).Skip(iteration * ChuckSize).Take(ChuckSize).AsEnumerable().ToList();
								Logger.Log(string.Format("DWXM00101M - got {0} records, iteration {1}.", dWXM00101Ms.Count, iteration + 1), Logger.LogLevel.INFO, null, "etl");

									//  load data into target DB
								foreach (DWXM00101M rec in dWXM00101Ms) {
									_sessionSQL.Insert(rec);
								}

								cnt += dWXM00101Ms.Count;
								Logger.Log(string.Format("DWXM00101M - inserted {0} records, iteration {1}, total: {2}", dWXM00101Ms.Count, iteration + 1, cnt), Logger.LogLevel.INFO, null, "etl");

										//  if last read didn't get chunkSize records, must be end of data so stop processing
								stop = dWXM00101Ms.Count < ChuckSize;
								iteration++;
							} while (!stop);

							transaction.Commit();
						} catch (Exception ex) {
							Logger.Log("DWXM00101M - error " + ex.Message, Logger.LogLevel.ERROR, ex, "etl");
							transaction.Rollback();
						}
					}
				}
			}

			Logger.Log(string.Format("DWXM00101M - finished load, {0} records", cnt), Logger.LogLevel.INFO, null, "etl");

			return cnt;
		}
	}
}
