﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using MIGE.Core.Domain;
using MIG.Utilities;


namespace MIG.WindowsService.Processor
{


	public class AgencyManagementSystem : BaseEntity
	{

		public AgencyManagementSystem()
		{
			//base.eventLog = eventLog;
		}


		public int GetAllAgencyManagementSystem()
		{
			Logger.Log("DWXM11500M - starting process", Logger.LogLevel.INFO, null, "etl");
			List<DWXM11500M> agencyMS = new List<DWXM11500M>();
			int iteration = 0;
			int cnt = 0;
			bool stop = false;

			using (_session = base.OpenSession()) {
				using (_sessionSQL = base.OpenSQLSession()) {
					using (var transaction = _sessionSQL.BeginTransaction()) {
						try {
									//  delete old records
							Logger.Log("DWXM11500M - deleting previous records", Logger.LogLevel.INFO, null, "etl");
							_sessionSQL.CreateSQLQuery("delete from DWXM11500M").SetTimeout(1800).ExecuteUpdate();
							Logger.Log("DWXM11500M - records deleted", Logger.LogLevel.INFO, null, "etl");

							do {
										//  extract data from source DB
								agencyMS = (from agentms in _session.Query<DWXM11500M>()
										orderby agentms.AGENT, agentms.ACTDTE, agentms.CO, agentms.PROD
										select agentms).Skip(iteration * ChuckSize).Take(ChuckSize).AsEnumerable().ToList();
								Logger.Log(string.Format("DWXM11500M - got {0} records, iteration {1}.", agencyMS.Count, iteration + 1), Logger.LogLevel.INFO, null, "etl");

										//  load data into target DB
								foreach (DWXM11500M rec in agencyMS) {
									_sessionSQL.Insert(rec);
								}

								cnt += agencyMS.Count;
								Logger.Log(string.Format("DWXM11500M - inserted {0} records, iteration {1}, total: {2}", agencyMS.Count, iteration + 1, cnt), Logger.LogLevel.INFO, null, "etl");

										//  if last read didn't get chunkSize records, must be end of data so stop processing
								stop = agencyMS.Count < ChuckSize;
								iteration++;
							} while (!stop);

							transaction.Commit();
						} catch (Exception ex) {
							Logger.Log("DWXM11500M - error " + ex.Message, Logger.LogLevel.ERROR, ex, "etl");
							transaction.Rollback();
						}
					}
				}
			}

			Logger.Log(string.Format("DWXM11500M - finished load, {0} records", cnt), Logger.LogLevel.INFO, null, "etl");

			return cnt;


			//try {
			//	using (_session = base.OpenSession()) {
			//		agencyMS = (from agentms in _session.Query<DWXM11500M>()
			//				select agentms).AsEnumerable().ToList();
			//		Logger.Log("DWXM11500M - got all the records " + agencyMS.Count, Logger.LogLevel.INFO, null, "etl");
			//		//eventLog.WriteEntry("DWXM11500M - got all the records " + agencyMS.Count);
			//	}
			//} catch (Exception ex) {
			//	Logger.Log("DWXM11500M - error " + ex.Message, Logger.LogLevel.ERROR, ex, "etl");
			//	//eventLog.WriteEntry("DWXM11500M - error " + ex.Message + " STACK TRACE" + ex.StackTrace, EventLogEntryType.Error);
			//}

			//using (_sessionSQL = base.OpenSQLSession()) {
			//	try {
			//		using (var transaction = _sessionSQL.BeginTransaction()) {
			//			Logger.Log("DWXM11500M - deleting previous records", Logger.LogLevel.INFO, null, "etl");
			//			//eventLog.WriteEntry("DWXM11500M - deleting previous records");
			//			_sessionSQL.CreateSQLQuery("delete from DWXM11500M").SetTimeout(600).ExecuteUpdate();
			//			transaction.Commit();
			//			Logger.Log("DWXM11500M - records deleted", Logger.LogLevel.INFO, null, "etl");
			//			//eventLog.WriteEntry("DWXM11500M - records deleted");
			//		}
			//	} catch (Exception ex) {
			//		Logger.Log("DWXM11500M - error " + ex.Message, Logger.LogLevel.ERROR, ex, "etl");
			//		//eventLog.WriteEntry("DWXM11500M - error " + ex.Message + " STACK TRACE" + ex.StackTrace, EventLogEntryType.Error);
			//	}

			//	try {
			//		Logger.Log("DWXM11500M - starting record insertion", Logger.LogLevel.INFO, null, "etl");
			//		//eventLog.WriteEntry("DWXM11500M - starting  insertion records");
			//		foreach (DWXM11500M dWXM11500M in agencyMS) {
			//			using (var transaction = _sessionSQL.BeginTransaction()) {
			//				_sessionSQL.Insert(dWXM11500M);
			//				transaction.Commit();
			//			}
			//		}
			//	} catch (Exception ex) {
			//		Logger.Log("DWXM11500M - error " + ex.Message, Logger.LogLevel.ERROR, ex, "etl");
			//		//eventLog.WriteEntry("DWXM11500M - error " + ex.Message + " STACK TRACE" + ex.StackTrace, EventLogEntryType.Error);
			//	}

			//	Logger.Log("DWXM11500M - finished insertion", Logger.LogLevel.INFO, null, "etl");
			//	//eventLog.WriteEntry("DWXM11500M - finished insertion");
			//}

			//return agencyMS;
		}
	}
}
