﻿using System;
using System.Threading.Tasks;
using MIG.Utilities;


namespace MIG.WindowsService.Processor {


	public static class ServiceProcessor
	{
		public static bool isExecuting = false;


		public static bool StartProcessing()
		{
					// set the executing flag to true
			isExecuting = true;
			System.Collections.Generic.List<Task> arrayList = new System.Collections.Generic.List<Task>();

			Logger.Log("MIGE.SQLDumpService starting", Logger.LogLevel.INFO, null, "etl");

					//  DWXM11500M
			AgencyManagementSystem agencyManagementSystem = new AgencyManagementSystem();
			Task taskA = Task.Run(() => {
				Logger.Log("MIGE.SQLDumpService starting AgencyManagementSystem", Logger.LogLevel.INFO, null, "etl");
				agencyManagementSystem.GetAllAgencyManagementSystem();
			});

					//  DWXF007
			AgencyInfo agency = new AgencyInfo();
			Task taskB = Task.Run(() => {
				Logger.Log("MIGE.SQLDumpService starting AgencyInfo", Logger.LogLevel.INFO, null, "etl");
				agency.GetAllAgentInfos();
			});

					//  DWXM00101M
			AgencyProfitSharingPlan agencyProfitSharingPlan = new AgencyProfitSharingPlan();
			Task taskC = Task.Run(() => {
				Logger.Log("MIGE.SQLDumpService starting AgencyProfitSharingPlan", Logger.LogLevel.INFO, null, "etl");
				agencyProfitSharingPlan.GetAllPlans();
			});

					//  DWXF108
			AgentMarketTerritory agentMarketTerritory = new AgentMarketTerritory();
			Task taskD = Task.Run(() => {
				Logger.Log("MIGE.SQLDumpService starting AgentMarketTerritory", Logger.LogLevel.INFO, null, "etl");
				agentMarketTerritory.GetAllMarketingTerritory();
			});

					//  DWXM00102M
			ProfitSharingPlanDetails profitSharingPlanDetails = new ProfitSharingPlanDetails();
			Task taskE = Task.Run(() => {
				Logger.Log("MIGE.SQLDumpService starting ProfitSharingPlanDetails", Logger.LogLevel.INFO, null, "etl");
				profitSharingPlanDetails.GetAllPlans();

			});

			Task.WaitAll(taskA, taskB, taskC, taskD, taskE);

					//  migrations - can only run after all data is loaded
			EtlMigrations migrations = new EtlMigrations();
			migrations.Process();

			isExecuting = false;
			return true;
		}
	}
}
