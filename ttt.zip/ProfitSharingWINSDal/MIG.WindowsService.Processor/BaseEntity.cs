﻿using System;
using System.Configuration;
using System.Diagnostics;
using NHibernate;
using MIGE.Core.Domain;

namespace MIG.WindowsService.Processor {


	public class BaseEntity : IDisposable
	{
		protected const string CONFIG_CHUNK_SIZE = "etlChunkSize";

		private int chunkSize = 0;
		protected IStatelessSession _session = null;
		protected IStatelessSession _sessionSQL = null;


		protected int ChuckSize
		{
			get {
				if (chunkSize == 0) {
					chunkSize = int.Parse(ConfigurationManager.AppSettings[CONFIG_CHUNK_SIZE]);
				}

				return chunkSize;
			}
		}


		public BaseEntity()
		{
			string _connectionStringWINS;

			//try {
			//	_connectionStringWINS = ((NameValueCollection)ConfigurationManager.GetSection("DBConfigSection")).Get("WINS");
			//} catch (Exception ex) {
			//	this.eventLog.WriteEntry("MIGE.SQLDumpService Base exception" + ex.Message, EventLogEntryType.Error);

				_connectionStringWINS = ConfigurationManager.AppSettings["profitSharingSQL"];
			//}

			AppDomain.CurrentDomain.SetData("ConnectionString", _connectionStringWINS);
			AppDomain.CurrentDomain.SetData("NHibernateShowSQL", "true");
		}


		public void Dispose()
		{
			this._session.Close();
			this._sessionSQL.Close();
		}


		/// <summary>
		/// Get nhibernate session for source DB.
		/// </summary>
		/// <returns></returns>
//		public ISession OpenSession()
		public IStatelessSession OpenSession()
		{
			//this._session = MIGE.Core.DAL.NHibernateSession.OpenSession();
			this._session = MIGE.Core.DAL.NHibernateOdsSQLSession.OpenSessionFactory().OpenStatelessSession();
			return _session;
		}


		/// <summary>
		/// Get nhibernate session for target DB.
		/// </summary>
		/// <returns></returns>
		public IStatelessSession OpenSQLSession()
		{
			this._sessionSQL = MIGE.Core.DAL.NHibernateSQLSession.CreateSessionFactory().OpenStatelessSession();
			return this._sessionSQL;
		}
	}
}
