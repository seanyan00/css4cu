﻿using System;
using System.Diagnostics;
using System.Configuration;
using MIG.Utilities;

namespace MIG.WindowsService.Processor {


	public class EtlMigrations : BaseEntity
	{

		public EtlMigrations()
		{
		}


		public void Process()
		{
			Logger.Log("EtlMigrations - starting migrations", Logger.LogLevel.INFO, null, "etl");

			using (_sessionSQL = base.OpenSQLSession()) {
				try {
					string sql = ConfigurationManager.AppSettings["etlMigrations"];

					using (var transaction = _sessionSQL.BeginTransaction()) {
						_sessionSQL.CreateSQLQuery(sql).SetTimeout(1200).ExecuteUpdate();
						transaction.Commit();
					}
				} catch (Exception ex) {
					Logger.Log("EtlMigrations - error " + ex.Message, Logger.LogLevel.ERROR, ex, "etl");
				}

				Logger.Log("EtlMigrations - finished migrations", Logger.LogLevel.INFO, null, "etl");
			}
		}
	}
}
