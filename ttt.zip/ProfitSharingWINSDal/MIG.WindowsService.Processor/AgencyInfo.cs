﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using MIGE.Core.Domain;
using MIG.Utilities;

namespace MIG.WindowsService.Processor {


	public class AgencyInfo : BaseEntity
	{

		public AgencyInfo()
		{
			//base.eventLog = eventLog;
		}


		public List<DWXF007> GetAllAgentInfos()
		{
			Logger.Log("DWXF007 - starting process", Logger.LogLevel.INFO, null, "etl");
			//eventLog.WriteEntry("DWXF007 - starting process");
			List<DWXF007> dWXF007s = new List<DWXF007>();

			try {
				using (_session = base.OpenSession()) {
					dWXF007s = (from agentms in _session.Query<DWXF007>()
							select agentms).AsEnumerable().ToList();
					Logger.Log("DWXF007 - got all the records " + dWXF007s.Count, Logger.LogLevel.INFO, null, "etl");
					//eventLog.WriteEntry("DWXF007 - got all the records " + dWXF007s.Count);
				}
			} catch (Exception ex) {
				Logger.Log("DWXF007 - error " + ex.Message, Logger.LogLevel.ERROR, ex, "etl");
				//eventLog.WriteEntry("DWXF007 - error " + ex.Message + " STACK TRACE" + ex.StackTrace, EventLogEntryType.Error);
			}

			using (_sessionSQL = base.OpenSQLSession()) {
				try {
					using (var transaction = _sessionSQL.BeginTransaction()) {
						Logger.Log("DWXF007 - deleting previous records", Logger.LogLevel.INFO, null, "etl");
						//eventLog.WriteEntry("DWXF007 - deleting previous records");
						_sessionSQL.CreateSQLQuery("delete from DWXF007").SetTimeout(600).ExecuteUpdate();
						transaction.Commit();
						Logger.Log("DWXF007 - records deleted", Logger.LogLevel.INFO, null, "etl");
						//eventLog.WriteEntry("DWXF007 - records deleted");
					}
				} catch (Exception ex) {
					Logger.Log("DWXF007 - error " + ex.Message, Logger.LogLevel.ERROR, ex, "etl");
					//eventLog.WriteEntry("DWXF007 - error " + ex.Message + " STACK TRACE" + ex.StackTrace, EventLogEntryType.Error);
				}

				try {
					Logger.Log("DWXF007 - starting record insertion", Logger.LogLevel.INFO, null, "etl");
					//eventLog.WriteEntry("DWXF007 - starting  insertion records");
					foreach (DWXF007 dWXF007 in dWXF007s) {
						using (var transaction = _sessionSQL.BeginTransaction()) {
							_sessionSQL.Insert(dWXF007);
							transaction.Commit();
						}
					}
				} catch (Exception ex) {
					Logger.Log("DWXF007 - error " + ex.Message, Logger.LogLevel.ERROR, ex, "etl");
					//eventLog.WriteEntry("DWXF007 - error " + ex.Message + " STACK TRACE" + ex.StackTrace, EventLogEntryType.Error);
				}

				Logger.Log("DWXF007 - finished insertion", Logger.LogLevel.INFO, null, "etl");
				//eventLog.WriteEntry("DWXF007 - finished insertion");
			}

			return dWXF007s;
		}
	}
}
