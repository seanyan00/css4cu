﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using MIGE.Core.Domain;
using MIG.Utilities;

namespace MIG.WindowsService.Processor {


	public class AgentMarketTerritory : BaseEntity
	{

		public AgentMarketTerritory()
		{
			//base.eventLog = eventLog;
		}


		public List<DWXF108> GetAllMarketingTerritory()
		{
			Logger.Log("DWXF108 - starting process", Logger.LogLevel.INFO, null, "etl");
			//eventLog.WriteEntry("DWXF108 - starting process");
			List<DWXF108> dWXF108s = new List<DWXF108>();

			try {
				using (_session = base.OpenSession()) {
					dWXF108s = (from agentms in _session.Query<DWXF108>()
							select agentms).AsEnumerable().ToList();
					Logger.Log("DWXF108 - got all the records " + dWXF108s.Count, Logger.LogLevel.INFO, null, "etl");
					//eventLog.WriteEntry("DWXF108 - got all the records " + dWXF108s.Count);
				}
			} catch (Exception ex) {
				Logger.Log("DWXF108 - error " + ex.Message, Logger.LogLevel.ERROR, ex, "etl");
				//eventLog.WriteEntry("DWXF108 - error " + ex.Message + " STACK TRACE" + ex.StackTrace, EventLogEntryType.Error);
			}

			using (_sessionSQL = base.OpenSQLSession()) {
				try {
					using (var transaction = _sessionSQL.BeginTransaction()) {
						Logger.Log("DWXF108 - deleting previous records", Logger.LogLevel.INFO, null, "etl");
						//eventLog.WriteEntry("DWXF108 - deleting previous records");
						_sessionSQL.CreateSQLQuery("delete from DWXF108").SetTimeout(600).ExecuteUpdate();
						transaction.Commit();
						Logger.Log("DWXF108 - records deleted", Logger.LogLevel.INFO, null, "etl");
						//eventLog.WriteEntry("DWXF108 - records deleted");
					}
				} catch (Exception ex) {
					Logger.Log("DWXF108 - error " + ex.Message, Logger.LogLevel.ERROR, ex, "etl");
					//eventLog.WriteEntry("DWXF108 - error " + ex.Message + " STACK TRACE" + ex.StackTrace, EventLogEntryType.Error);
				}

				try {
					Logger.Log("DWXF108 - starting record insertion", Logger.LogLevel.INFO, null, "etl");
					//eventLog.WriteEntry("DWXF108 - starting  insertion records");
					foreach (DWXF108 dWXF007 in dWXF108s) {
						using (var transaction = _sessionSQL.BeginTransaction()) {
							_sessionSQL.Insert(dWXF007);
							transaction.Commit();
						}
					}
				} catch (Exception ex) {
					Logger.Log("DWXF108 - error " + ex.Message, Logger.LogLevel.ERROR, ex, "etl");
					//eventLog.WriteEntry("DWXF108 - error " + ex.Message + " STACK TRACE" + ex.StackTrace, EventLogEntryType.Error);
				}

				Logger.Log("DWXF108 - finished insertion", Logger.LogLevel.INFO, null, "etl");
				//eventLog.WriteEntry("DWXF108 - finished insertion");
			}

			return dWXF108s;
		}
	}
}
