﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentNHibernate;
using FluentNHibernate.Mapping;
using FluentNHibernate.Automapping.Alterations;
using NHibernate.UserTypes;



//namespace MIGE.Core.Domain.AS400
namespace MIGE.Core.Domain
{
     /* ****************************************************************************************************
     * PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS - SEE LIBRARY AND TABLE/FILENAME 
     * AS400 LIBRARY        - DVDTA
     * TABLE/FILENAME       - DWXM00102M
     * DESCRIPTION          - Agency Profit Sharing Plan 
     * DATE CREATED         - 2/13/2019 7:11:37 AM
     * AUTHOR               - RICHARD FUMERELLE
     * VERSION              - 1.0
     * CODE GENERATION      - Automatic code generation using CodeSmith GenerationTool
     * NOTES                - This table can be modified.
     ****************************************************************************************************/

    #region DWXM00102M Class

    public partial class DWXM00102M : DWXM00102MAbstract
    {
    
        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            if(object.ReferenceEquals(this, obj)) return true;
            DWXM00102M dwxm00102m = obj as DWXM00102M;
            if (dwxm00102m == null) return false;
            if( AGENT == dwxm00102m.AGENT && EFFDTE == dwxm00102m.EFFDTE ) return true;
            return false;
           
        }
        
        public override int GetHashCode()
        {
                 return(AGENT + "|"+ EFFDTE).GetHashCode();
            
              
            
        }
        
        #endregion
   
    }
}
