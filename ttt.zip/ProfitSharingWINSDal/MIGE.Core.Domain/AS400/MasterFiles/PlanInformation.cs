﻿using System;
using FluentNHibernate.Mapping;

//namespace MIGE.Core.Domain.SQL.Models
namespace MIGE.Core.Domain
{


  public  class PlanInformation
    {
        public virtual int Id { get; set; }
        public virtual string PlanName { get; set; }
        public virtual int DisablePlan { get; set; }
    }


    public class PlanInformationMap : ClassMap<PlanInformation>
    {
        public PlanInformationMap()
        {
            Id(x => x.Id).Column("Id").GeneratedBy.Identity();
        }
    }
}
