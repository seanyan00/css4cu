﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIGE.Core.Domain.Dto
{
	public class PagingInfo
	{
		public int TotalResults { get; set; } = 0;
		public int CurrentPage { get; set; } = 0;
		public int PageSize { get; set; } = 20;
		public int PageCount { get; set; } = 0;

		public PagingInfo() { }
	}
}
