﻿using FluentNHibernate.Mapping;
using System;

//namespace MIGE.Core.Domain.SQL.Models
namespace MIGE.Core.Domain
{


    public class MarketingTerritoryAssignment
    {
        public virtual int Id { get; set; }
        public virtual PlanInformation PlanInformation{ get; set; }
        public virtual int EffectiveYear { get; set; }
        public virtual string MarketingTerritory { get; set; }
		public virtual bool IncludePersonalLines { get; set; }
	}


	public class MarketingTerritoryAssignmentMap : ClassMap<MarketingTerritoryAssignment>
    {
        public MarketingTerritoryAssignmentMap()
        {
            Id(x => x.Id).Column("Id").GeneratedBy.Identity();
        }
    }
}
