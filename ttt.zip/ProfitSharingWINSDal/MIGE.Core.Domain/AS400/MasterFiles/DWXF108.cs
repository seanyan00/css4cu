﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentNHibernate;
using FluentNHibernate.Mapping;
using FluentNHibernate.Automapping.Alterations;
using NHibernate.UserTypes;



//namespace MIGE.Core.Domain.AS400
namespace MIGE.Core.Domain
{
     /* ****************************************************************************************************
     * PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS - SEE LIBRARY AND TABLE/FILENAME 
     * AS400 LIBRARY        - DVDTA
     * TABLE/FILENAME       - DWXF108
     * DESCRIPTION          - Agent Additional File 
     * DATE CREATED         - 2/13/2019 7:11:36 AM
     * AUTHOR               - RICHARD FUMERELLE
     * VERSION              - 1.0
     * CODE GENERATION      - Automatic code generation using CodeSmith GenerationTool
     * NOTES                - This table can be modified.
     ****************************************************************************************************/

    #region DWXF108 Class

    public partial class DWXF108 : DWXF108Abstract
    {
    
        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            if(object.ReferenceEquals(this, obj)) return true;
            DWXF108 dwxf108 = obj as DWXF108;
            if (dwxf108 == null) return false;
            if( CDKEY1 == dwxf108.CDKEY1 && CDKEY2 == dwxf108.CDKEY2 && CDKEY3 == dwxf108.CDKEY3 && EFFDTE == dwxf108.EFFDTE ) return true;
            return false;
           
        }
        
        public override int GetHashCode()
        {
                 return(CDKEY1 + "|"+ CDKEY2 + "|"+ CDKEY3 + "|"+ EFFDTE).GetHashCode();
            
              
            
        }
        
        #endregion
   
    }
}
