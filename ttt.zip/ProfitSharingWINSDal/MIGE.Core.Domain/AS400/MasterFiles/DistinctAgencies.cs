﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace MIGE.Core.Domain
{
	[DataContract]
	public class DistinctAgencies
	{
		[DataMember]
		public virtual string AgentNumber { get; set; }
		[DataMember]
		public virtual string CDDesc { get; set; }
		[DataMember]
		public virtual string AgencyName { get; set; }
		[DataMember]
		public virtual string Address1 { get; set; }
		[DataMember]
		public virtual string Address2 { get; set; }
		[DataMember]
		public virtual string Address3 { get; set; }
		[DataMember]
		public virtual string City { get; set; }
		[DataMember]
		public virtual string State { get; set; }
		[DataMember]
		public virtual string ZipCode { get; set; }
		[DataMember]
		public virtual string MasterAgency { get; set; }
		[DataMember]
		public virtual string RegionalOffice { get; set; }
		[DataMember]
		public virtual string MarketingCode { get; set; }
		//[DataMember]
		//public virtual decimal EffectiveDate { get; set; }
		//[DataMember]
		//public virtual decimal EndingDate { get; set; }
		//[DataMember]
		public virtual IList<DistinctAgencies> children { get; set; }

		public override bool Equals(object obj)
		{
			if (obj == null)
				return false;
			if (object.ReferenceEquals(this, obj))
				return true;
			DistinctAgencies distinctAgencies = obj as DistinctAgencies;
			if (distinctAgencies == null)
				return false;
			if (AgentNumber == distinctAgencies.AgentNumber)
				return true;
			return false;
		}

		public override int GetHashCode()
		{
			return (AgentNumber).GetHashCode();
		}

	}
}
