﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using FluentNHibernate.Mapping;
using Newtonsoft.Json;




//namespace MIGE.Core.Domain.SQL.Models
namespace MIGE.Core.Domain
{

   public class ProfitGrowthFactors
    {
        public virtual int Id { get; set; }
        public virtual string Name { get; set; }
        [StringLength(100, MinimumLength = 3)]
        [MaxLength]
        public virtual string Data { get; set; }
        public virtual TableNames TableNames { get; set; }
        public virtual TableStatus TableStatus { get; set; }


		public ProfitGrowthFactors()
		{
		}


		public ProfitGrowthFactors(
			PremiumVolumeLossRatioTbl pvlrTbl)
		{
			Id = pvlrTbl.Id;
			Name = pvlrTbl.Name;
			TableNames = TableNames.PremiumVolumeLossRatio;
			TableStatus = pvlrTbl.TableStatus;
			Data = JsonConvert.SerializeObject(pvlrTbl.Rows);
		}
	}


    public class ProfitGrowthFactorsMap : ClassMap<ProfitGrowthFactors>
    {
        public ProfitGrowthFactorsMap()
        {
            Id(x => x.Id).Column("Id").GeneratedBy.Identity();
        }
    }


    public enum TableStatus
    {
        Draft = 0,
        Pending = 1,
        Review =2,
        Approved =3
    }


    public enum TableNames
    {
        ThreeYearProfitability = 1,
        ProfitGrowthFactors = 2,
        PremiumVolumeLossRatio = 3
    }
}

