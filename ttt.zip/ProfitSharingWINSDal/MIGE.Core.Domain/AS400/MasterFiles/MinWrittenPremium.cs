﻿using FluentNHibernate.Mapping;
using MIGE.Core.Domain;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//namespace MIGE.Core.Domain.SQL.Models
namespace MIGE.Core.Domain
{
    public class MinWrittenPremium
    {
        public virtual int Id { get; set; }
        public virtual PlanInformation PlanInformation { get; set; }
        public virtual decimal Premium{ get; set; }
        public virtual int StartYear { get; set; }
        public virtual int EndYear { get; set; }
    }

    public class MinWrittenPremiumMap : ClassMap<MinWrittenPremium>
    {
        public MinWrittenPremiumMap()
        {
            Id(x => x.Id).Column("Id").GeneratedBy.Identity();
            References(x => x.PlanInformation).Not.Nullable().LazyLoad();
        }
    }
}
