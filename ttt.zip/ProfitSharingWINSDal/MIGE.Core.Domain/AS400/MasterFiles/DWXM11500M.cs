﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentNHibernate;
using FluentNHibernate.Mapping;
using FluentNHibernate.Automapping.Alterations;
using NHibernate.UserTypes;



//namespace MIGE.Core.Domain.AS400
namespace MIGE.Core.Domain
{
     /* ****************************************************************************************************
     * PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS - SEE LIBRARY AND TABLE/FILENAME 
     * AS400 LIBRARY        - DVDTA
     * TABLE/FILENAME       - DWXM11500M
     * DESCRIPTION          - Agency Management System Master File 
     * DATE CREATED         - 2/13/2019 7:11:37 AM
     * AUTHOR               - RICHARD FUMERELLE
     * VERSION              - 1.0
     * CODE GENERATION      - Automatic code generation using CodeSmith GenerationTool
     * NOTES                - This table can be modified.
     ****************************************************************************************************/

    #region DWXM11500M Class

    public partial class DWXM11500M : DWXM11500MAbstract
    {
    
        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            if(object.ReferenceEquals(this, obj)) return true;
            DWXM11500M dwxm11500m = obj as DWXM11500M;
            if (dwxm11500m == null) return false;
            if( ACTDTE == dwxm11500m.ACTDTE && CO == dwxm11500m.CO && AGENT == dwxm11500m.AGENT && SUBPRO == dwxm11500m.SUBPRO && PROD == dwxm11500m.PROD ) return true;
            return false;
           
        }
        
        public override int GetHashCode()
        {
                 return(ACTDTE + "|"+ CO + "|"+ AGENT + "|"+ SUBPRO + "|"+ PROD).GetHashCode();
            
              
            
        }
        
        #endregion
   
    }
}
