﻿using FluentNHibernate.Mapping;
using System;


//namespace MIGE.Core.Domain.SQL.Models
namespace MIGE.Core.Domain
{


    public class AgentQualification
	{
        public virtual int Id { get; set; }
        public virtual string AGENT { get; set; }
		public virtual string AGYCDE { get; set; }
		public virtual int YEAR { get; set; }
        public virtual decimal MINPREM { get; set; }     
        public virtual bool STOPLOSS { get; set; }
        public virtual DateTime? LockedAt { get; set; }
	}


    public class AgentQualificationMap : ClassMap<AgentQualification>
    {

        public AgentQualificationMap()
        {
            Id(x => x.Id).Column("Id").GeneratedBy.Identity();
        }
    }
}
