﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//namespace MIGE.Core.Domain.SQL.Models
namespace MIGE.Core.Domain
{
    public class AddendumA
    {
        public virtual int Id { get; set; }
        public virtual string AgentCode { get; set; }
        public virtual int Year { get; set; }
        public virtual decimal MinPremium { get; set; }     
        public virtual bool IsEnabled { get; set; }
        public virtual ProfitGrowthFactors PremiumTable { get; set; }        


    }

    public class AddendumAMap : ClassMap<AddendumA>
    {
        public AddendumAMap()
        {
            Id(x => x.Id).Column("Id").GeneratedBy.Identity();
        }
    }
}
