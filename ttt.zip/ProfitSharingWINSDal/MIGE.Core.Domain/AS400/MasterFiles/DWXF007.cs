﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentNHibernate;
using FluentNHibernate.Mapping;
using FluentNHibernate.Automapping.Alterations;
using NHibernate.UserTypes;



//namespace MIGE.Core.Domain.AS400
namespace MIGE.Core.Domain
{
	/* ****************************************************************************************************
	* PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS - SEE LIBRARY AND TABLE/FILENAME 
	* AS400 LIBRARY        - DVDTA
	* TABLE/FILENAME       - DWXF007
	* DESCRIPTION          - Agent Master File
	* DATE CREATED         - 7/23/2018 11:18:31 AM
	* AUTHOR               - RICHARD FUMERELLE
	* VERSION              - 1.0
	* CODE GENERATION      - Automatic code generation using CodeSmith GenerationTool
	* NOTES                - This table can be modified.
	****************************************************************************************************/


	#region DWXF007 - Properties

	public partial class DWXF007 : BaseEntityAbstract
	{

		public virtual string CDKEY1 { get; set; }
		public virtual string CDKEY2 { get; set; }
		public virtual string CDKEY3 { get; set; }
		public virtual decimal EFFDTE { get; set; }
		public virtual string CDDESC { get; set; }
		public virtual decimal ENDDTE { get; set; }
		public virtual string AGYNAM { get; set; }
		public virtual string AGYAD1 { get; set; }
		public virtual string AGYAD2 { get; set; }
		public virtual string AGYAD3 { get; set; }
		public virtual string AGYCTY { get; set; }
		public virtual string AGYST { get; set; }
		public virtual string AGYZIP { get; set; }
		public virtual string IRSNO { get; set; }
		public virtual string AGYTYP { get; set; }
		public virtual string ATTNAM { get; set; }
		public virtual string AGYTEL { get; set; }
		public virtual decimal APPDTE { get; set; }
		public virtual string TRNSTF { get; set; }
		public virtual decimal TRNSDT { get; set; }
		public virtual string TRNSAG { get; set; }
		public virtual string AGCOM1 { get; set; }
		public virtual string MKTREP { get; set; }
		public virtual string FAXNBR { get; set; }
		public virtual string AGYCDE { get; set; }
		public virtual string COMIND { get; set; }
		public virtual decimal CRTEXT { get; set; }
		public virtual string POLCTL { get; set; }
		public virtual string IDADD { get; set; }
		public virtual string DNLDCD { get; set; }
		public virtual decimal DTEADD { get; set; }
		public virtual string IDCHG { get; set; }
		public virtual decimal DTECHG { get; set; }
		public virtual string ASNRSK { get; set; }
		public virtual string FUTUR1 { get; set; }
		public virtual string FUTUR2 { get; set; }
		public virtual string AGYUWS { get; set; }
		public virtual string REGOFC { get; set; }
		public virtual string REFISS { get; set; }
		public virtual string REFREN { get; set; }
		public virtual string SUPMST { get; set; }
		public virtual string ULTMST { get; set; }
	    //public virtual IList<DWXF007> SubAgents { get; set; }

	}

	#endregion

	#region DWXF007 

	public partial class DWXF007 : BaseEntityAbstract
    {


		public override bool Equals(object obj)
		{
			if (obj == null) return false;
			if (object.ReferenceEquals(this, obj)) return true;
			DWXF007 dwxf007 = obj as DWXF007;
			if (dwxf007 == null) return false;
			if (CDKEY1 == dwxf007.CDKEY1 && CDKEY2 == dwxf007.CDKEY2 && CDKEY3 == dwxf007.CDKEY3 && EFFDTE == dwxf007.EFFDTE) return true;
			return false;

		}

		public override int GetHashCode()
		{
			return (CDKEY1 + "|" + CDKEY2 + "|" + CDKEY3 + "|" + EFFDTE).GetHashCode();



		}

		#endregion


	}
}
