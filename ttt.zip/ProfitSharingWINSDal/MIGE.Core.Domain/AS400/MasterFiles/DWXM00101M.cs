﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentNHibernate;
using FluentNHibernate.Mapping;
using FluentNHibernate.Automapping.Alterations;
using NHibernate.UserTypes;



//namespace MIGE.Core.Domain.AS400
namespace MIGE.Core.Domain
{
     /* ****************************************************************************************************
     * PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS - SEE LIBRARY AND TABLE/FILENAME 
     * AS400 LIBRARY        - DVSRC
     * TABLE/FILENAME       - DWXM00101M
     * DESCRIPTION          - Agency Profit Sharing Plan - Summary File 
     * DATE CREATED         - 2/13/2019 7:11:37 AM
     * AUTHOR               - RICHARD FUMERELLE
     * VERSION              - 1.0
     * CODE GENERATION      - Automatic code generation using CodeSmith GenerationTool
     * NOTES                - This table can be modified.
     ****************************************************************************************************/

    #region DWXM00101M Class

    public partial class DWXM00101M : DWXM00101MAbstract
    {
    
        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            if(object.ReferenceEquals(this, obj)) return true;
            DWXM00101M dwxm00101m = obj as DWXM00101M;
            if (dwxm00101m == null) return false;
            if( ACTDTE == dwxm00101m.ACTDTE && CO == dwxm00101m.CO && AGENT == dwxm00101m.AGENT && PROD == dwxm00101m.PROD ) return true;
            return false;
           
        }
        
        public override int GetHashCode()
        {
                 return(ACTDTE + "|"+ CO + "|"+ AGENT + "|"+ PROD).GetHashCode();
            
              
            
        }
        
        #endregion
   
    }
}
