﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//namespace MIGE.Core.Domain.SQL.Models
namespace MIGE.Core.Domain
{
    public class Addendumc
    {
        public virtual int Id { get; set; }
        public virtual string AgentId { get; set; }
        public virtual bool IsEnabled { get; set; }
        public virtual int Year { get; set; }


		public virtual Addendumc ShallowCopy()
		{
			return (Addendumc)this.MemberwiseClone();
		}
	}


	public class AddendumCMap : ClassMap<Addendumc>
    {
        public AddendumCMap()
        {
            Id(x => x.Id).Column("Id").GeneratedBy.Identity();
        }
    }
}
