﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using FluentNHibernate.Mapping;
using Newtonsoft.Json;

//namespace MIGE.Core.Domain.SQL.Models.Map
namespace MIGE.Core.Domain
{

	public class PremiumVolumeLossRatioTbl
	{
		public virtual int Id { get; set; }
		[StringLength(255)]
		public virtual string Name { get; set; }
		[StringLength(255)]
		public virtual TableStatus TableStatus { get; set; }
		[JsonProperty("Data")]
		public virtual IList<PremiumVolumeLossRatioValue> Rows { get; set; }
	}


	public class PremiumVolumeLossRatioTblMap : ClassMap<PremiumVolumeLossRatioTbl>
	{
		public PremiumVolumeLossRatioTblMap()
		{
			Id(x => x.Id).Column("Id").GeneratedBy.Identity();

			HasMany<PremiumVolumeLossRatioValue>(x => x.Rows)
				//				.KeyColumns.Add("TableId")
				//				.Table("PremiumVolumeLossRatioValue")
				.KeyColumn("Table_id")
				.Cascade.AllDeleteOrphan()
				.Inverse();
		}
	}


	public class PremiumVolumeLossRatioValue
	{
		[JsonIgnore]	
		public virtual int Id { get; set; }
		[JsonIgnore]
		public virtual int Table_id { get; set; }
		[JsonProperty("loss-ratio-low")]
		public virtual decimal LossRatioLow { get; set; }
		[JsonProperty("loss-ratio-high")]
		public virtual decimal LossRatioHigh { get; set; }
		[JsonProperty("written-premium-volume-low")]
		public virtual decimal WrittenPremiumVolumeLow { get; set; }
		[JsonProperty("written-premium-volume-high")]
		public virtual decimal WrittenPremiumVolumeHigh { get; set; }
		[JsonProperty("factor")]
		public virtual decimal Factor { get; set; }
		[JsonIgnore]
		public virtual PremiumVolumeLossRatioTbl Table { get; set; }
	}


	public class PremiumVolumeLossRatioValueMap : ClassMap<PremiumVolumeLossRatioValue>
	{
		public PremiumVolumeLossRatioValueMap()
		{
			Id(x => x.Id).Column("Id").GeneratedBy.Identity();

			References(x => x.Table, "Table_id")
//				.Column("TableId")
				.Not.Nullable();
		}
	}
}

