﻿using FluentNHibernate.Mapping;
using MIGE.Core.Domain;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//namespace MIGE.Core.Domain.SQL.Models
namespace MIGE.Core.Domain
{
    public class AddendumAGrowthPercentage
    {
        public virtual int Id { get; set; }        [Required]
       
        public virtual decimal Value { get; set; }
        public virtual int StartYear { get; set; }
        public virtual int EndYear { get; set; }

    }

    public class AddendumAGrowthPercentageMap : ClassMap<AddendumAGrowthPercentage>
    {
        public AddendumAGrowthPercentageMap()
        {
            Id(x => x.Id).Column("Id").GeneratedBy.Identity();
           // References(x => x.PlanInformation, "Id").Not.Nullable().LazyLoad();
           // HasOne<PlanInformation>(x => x.PlanInformation).LazyLoad();
        }
    }
}
