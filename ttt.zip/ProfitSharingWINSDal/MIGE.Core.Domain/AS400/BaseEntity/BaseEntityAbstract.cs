﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace MIGE.Core.Domain
{
	/* ****************************************************************************************************
	* PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS
	* AS400 LIBRARY        - N/A
	* TABLE/FILENAME       - N/A
	* DESCRIPTION          - Manages Record State for Disconnected Objects
	* DATE CREATED         - 6/18/2018 
	* AUTHOR               - RICHARD FUMERELLE
	* VERSION              - 1.0
	* CODE GENERATION      - N/A
	* NOTES                - N/A
	****************************************************************************************************/


	[DataContract]
	public abstract class BaseEntityAbstract
	{
		[DataMember]
		public virtual string RECORDSTATE { get; set; }
	}
}
