﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentNHibernate;
using FluentNHibernate.Mapping;
using FluentNHibernate.Automapping.Alterations;
using NHibernate.UserTypes;


namespace MIGE.Core.Domain
{
     /* ****************************************************************************************************
     * PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS - SEE LIBRARY AND TABLE/FILENAME 
     * AS400 LIBRARY        - DVDTA
     * TABLE/FILENAME       - DWXM11500M
     * DESCRIPTION          - Agency Management System Master File
     * DATE CREATED         - 2/13/2019 7:11:36 AM
     * AUTHOR               - RICHARD FUMERELLE
     * VERSION              - 1.0
     * CODE GENERATION      - Automatic code generation using CodeSmith GenerationTool
     * NOTES                - This table can be modified.
     ****************************************************************************************************/


    #region DWXM11500MAbstract - Properties
    
    public abstract partial class DWXM11500MAbstract : BaseEntityAbstract
    {
      
                public virtual decimal  ACTDTE {get; set;}
                public virtual string CO {get; set;}
                public virtual string AGENT {get; set;}
                public virtual string SUBPRO {get; set;}
                public virtual string PROD {get; set;}
                public virtual decimal  PIF {get; set;}
                public virtual decimal  PRMIF {get; set;}
                public virtual decimal  NBSCNTYD {get; set;}
                public virtual decimal  NBSCNT {get; set;}
                public virtual decimal  NBSPRMYD {get; set;}
                public virtual decimal  NBSPRM {get; set;}
                public virtual decimal  CHRGOFF {get; set;}
                public virtual decimal  DIVIDENDS {get; set;}
                public virtual decimal  INCLOSSSTP {get; set;}
                public virtual decimal  WRTPRMYD {get; set;}
                public virtual decimal  WRTPRM {get; set;}
                public virtual decimal  ERNPRMYD {get; set;}
                public virtual decimal  ERNPRM {get; set;}
                public virtual decimal  UNERNPRM {get; set;}
                public virtual decimal  INCRLOSYD {get; set;}
                public virtual decimal  INCRLOS {get; set;}
                public virtual decimal  INCRINDMYD {get; set;}
                public virtual decimal  INCRINDM {get; set;}
                public virtual decimal  INCREXPYD {get; set;}
                public virtual decimal  INCREXP {get; set;}
                public virtual decimal  RSVCHGTOT {get; set;}
                public virtual decimal  RSVCHGIND {get; set;}
                public virtual decimal  ACCTPIF {get; set;}
                public virtual decimal  MONOPIF {get; set;}
       
    }
    
    #endregion
    
}
