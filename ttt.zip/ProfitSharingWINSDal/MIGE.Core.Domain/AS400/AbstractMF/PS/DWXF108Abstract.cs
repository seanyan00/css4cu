﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentNHibernate;
using FluentNHibernate.Mapping;
using FluentNHibernate.Automapping.Alterations;
using NHibernate.UserTypes;


namespace MIGE.Core.Domain
{
	/* ****************************************************************************************************
	* PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS - SEE LIBRARY AND TABLE/FILENAME 
	* AS400 LIBRARY        - DVDTA
	* TABLE/FILENAME       - DWXF108
	* DESCRIPTION          - Agent Additional File
	* DATE CREATED         - 2/13/2019 7:11:36 AM
	* AUTHOR               - RICHARD FUMERELLE
	* VERSION              - 1.0
	* CODE GENERATION      - Automatic code generation using CodeSmith GenerationTool
	* NOTES                - This table can be modified.
	****************************************************************************************************/


	#region DWXF108Abstract - Properties

	public abstract partial class DWXF108Abstract : BaseEntityAbstract
	{

		public virtual string CDKEY1 { get; set; }
		public virtual string CDKEY2 { get; set; }
		public virtual string CDKEY3 { get; set; }
		public virtual decimal EFFDTE { get; set; }
		public virtual string CDDESC { get; set; }
		public virtual decimal ENDDTE { get; set; }
		public virtual decimal TERMDT { get; set; }
		public virtual string MKTTER { get; set; }
		public virtual string AGYLA1 { get; set; }
		public virtual string AGYLA2 { get; set; }
		public virtual string AGYLCT { get; set; }
		public virtual string AGYLST { get; set; }
		public virtual string AGYLZP { get; set; }
		public virtual string NIKNAM { get; set; }
		public virtual string PTERR { get; set; }
		public virtual string CTERR { get; set; }
		public virtual string BILMTD { get; set; }
		public virtual string RECINV { get; set; }
		public virtual decimal NBRCPY { get; set; }
		public virtual string IDADD { get; set; }
		public virtual decimal DTEADD { get; set; }
		public virtual string IDCHG { get; set; }
		public virtual decimal DTECHG { get; set; }
		public virtual string BKPNAM { get; set; }
		public virtual string ACCANA { get; set; }
		public virtual decimal MAXDFT { get; set; }
		public virtual string PRGCD1 { get; set; }
		public virtual string PRGCD2 { get; set; }
		public virtual string PRGCD3 { get; set; }
		public virtual string PRGCD4 { get; set; }
		public virtual string PRGCD5 { get; set; }
		public virtual string LCST01 { get; set; }
		public virtual string LCST02 { get; set; }
		public virtual string LCST03 { get; set; }
		public virtual string LCST04 { get; set; }
		public virtual string LCST05 { get; set; }
		public virtual string LCST06 { get; set; }
		public virtual string LCST07 { get; set; }
		public virtual string LCST08 { get; set; }
		public virtual string LCST09 { get; set; }
		public virtual string LCST10 { get; set; }
		public virtual string LCST11 { get; set; }
		public virtual string LCST12 { get; set; }
		public virtual string LCST13 { get; set; }
		public virtual string LCST14 { get; set; }
		public virtual string LCST15 { get; set; }
		public virtual string LCST16 { get; set; }
		public virtual string LCST17 { get; set; }
		public virtual string LCST18 { get; set; }
		public virtual string LCST19 { get; set; }
		public virtual string LCST20 { get; set; }
		public virtual string DIRPAY { get; set; }
		public virtual string AGPAYO { get; set; }
		public virtual string URL { get; set; }
		public virtual string EMAIL { get; set; }
		public virtual string TRMCDE { get; set; }
		public virtual string VDRCDE { get; set; }
		public virtual string EMAIL2 { get; set; }
		public virtual string AGYCNT { get; set; }
		public virtual string AGYNAM2 { get; set; }
		public virtual string CHPTCDE { get; set; }
		public virtual decimal CHPTEFF { get; set; }
		public virtual decimal CHPTEXP { get; set; }
		public virtual decimal APGROUPID { get; set; }
		public virtual string SPRSPRT { get; set; }
		public virtual string AGYTIER { get; set; }
		public virtual decimal ORGDTE { get; set; }
		public virtual decimal EXPDTE { get; set; }
		public virtual string NATACC { get; set; }
		public virtual string SHLAGT { get; set; }
		public virtual string GEN1099 { get; set; }
		public virtual decimal SPRSDTE { get; set; }
		public virtual string YACCOUNT { get; set; }

	}

	#endregion

}
