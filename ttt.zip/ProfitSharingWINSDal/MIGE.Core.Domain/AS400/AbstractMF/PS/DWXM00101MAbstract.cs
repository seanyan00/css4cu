﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentNHibernate;
using FluentNHibernate.Mapping;
using FluentNHibernate.Automapping.Alterations;
using NHibernate.UserTypes;


namespace MIGE.Core.Domain
{
	/* ****************************************************************************************************
	* PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS - SEE LIBRARY AND TABLE/FILENAME 
	* AS400 LIBRARY        - DVSRC
	* TABLE/FILENAME       - DWXM00101M
	* DESCRIPTION          - Agency Profit Sharing Plan - Summary File
	* DATE CREATED         - 2/13/2019 7:11:37 AM
	* AUTHOR               - RICHARD FUMERELLE
	* VERSION              - 1.0
	* CODE GENERATION      - Automatic code generation using CodeSmith GenerationTool
	* NOTES                - This table can be modified.
	****************************************************************************************************/


	#region DWXM00101MAbstract - Properties

	public abstract partial class DWXM00101MAbstract : BaseEntityAbstract
	{

		public virtual decimal ACTDTE { get; set; }
		public virtual string CO { get; set; }
		public virtual string AGENT { get; set; }
		public virtual string PROD { get; set; }
		public virtual decimal ADJWRTPREM { get; set; }
		public virtual decimal CHARGEOFFS { get; set; }
		public virtual decimal DIVIDENDS { get; set; }
		public virtual decimal CHGOFFDIVD { get; set; }
		public virtual decimal WRITEPREM { get; set; }
		public virtual decimal ADJEARPREM { get; set; }
		public virtual decimal EARNEDPREM { get; set; }
		public virtual decimal INCLOSSACT { get; set; }
		public virtual decimal INCLOSSSTP { get; set; }
		public virtual decimal INCCREDLOS { get; set; }
		public virtual decimal INCCREDEXP { get; set; }

	}

	#endregion

}
