﻿using System;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;

using System.IO;
using System.IO.Compression;
using System.Security.Principal;
using System.Net;
using Microsoft.Reporting.WebForms;
using NHibernate;
using NHibernate.Linq;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;
using MIG.Utilities;
using MIG.Utilities.Nhibernate;
using MIG.WEB.API.Models;
using MIGE.Core.Domain;
using System.Dynamic;

namespace MIG.WEB.API.Data
{

	public class DataContext : IDisposable
	{
		private const string CONFIG_REPORT_SERVER_URL = "reportServerUrl";
		private const string CONFIG_REPORT_PATH = "reportServerPath";
		private const int DEFAULT_PAGE = 1;
		private const int DEFAULT_PAGE_SIZE = 15;
		private const int MS_IN_MINUTE = 60000; // conversion factor from minute -> millisecond

		protected ISession _session = null;
		//public EventLog eventLog = new EventLog("MIG DataContext Logs", Environment.MachineName, "MIG DataContext Logs");
		private string _connectionStringWINS;


		public Dictionary<string, string> ReportExtensionMap = new Dictionary<string, string> {
			{"PDF", "pdf" },
			{"EXCEL", "xls" },
			{"CSV", "csv" }
		};


		public class AgentFilter {
			public string[]	Id { get; set; }
			public string Territory { get; set; }
			public string Region { get; set; }
			public bool? AddendumAEnabled { get; set; }
			public bool? AddendumCEnabled { get; set; }
			public bool? IncludeCanceled { get; set; }
			public bool? IncludeZeroPayments { get; set; }
			public int? Year { get; set; }

			public int Page { get; set; }
			public int PageSize { get; set; }

			public bool IncludeSubagents { get; set; }


			public AgentFilter(
				Newtonsoft.Json.Linq.JToken jsonFilter)
			{
				Id = jsonFilter["Id"]?.ToObject<string[]>();
				Territory = jsonFilter["Territory"]?.ToObject<string>();
				Region = jsonFilter["Region"]?.ToObject<string>();
				AddendumAEnabled = jsonFilter["AddendumAEnabled"]?.ToObject<bool?>();
				AddendumCEnabled = jsonFilter["AddendumCEnabled"]?.ToObject<bool?>();
				IncludeCanceled = jsonFilter["IncludeCanceled"]?.ToObject<bool?>();
				IncludeZeroPayments = jsonFilter["IncludeZeroPayments"]?.ToObject<bool?>();
				Year = jsonFilter["Year"]?.ToObject<int?>();
				Page = jsonFilter["Page"]?.ToObject<int>() ?? DEFAULT_PAGE;
				PageSize = jsonFilter["PageSize"]?.ToObject<int>() ?? DEFAULT_PAGE_SIZE;
				IncludeSubagents = jsonFilter["IncludeSubagents"]?.ToObject<bool>() ?? false;
			}
		}


		public DataContext()
		{

			//try {
			//	_connectionStringWINS = ((NameValueCollection)ConfigurationManager.GetSection("DBConfigSection")).Get("WINS");
			//} catch (Exception ex) {
			//	//this.Logger.Log("MIGE.SQLDumpService Base exception" + ex.Message, Logger.LogLevel.ERROR);
			//	Logger.Log("MIGE.SQLDumpService Base exception" + ex.Message, Logger.LogLevel.ERROR);

			//	_connectionStringWINS = ConfigurationManager.AppSettings["WINS"];
			//}

			//AppDomain.CurrentDomain.SetData("ConnectionString", _connectionStringWINS);
			//AppDomain.CurrentDomain.SetData("NHibernateShowSQL", "true");
		}


		public void Dispose()
		{
			this._session.Close();
		}


		public ISession OpenSession()
		{
			this._session = MIGE.Core.DAL.NHibernateSession.OpenSession();
			return _session;
		}


		public ISession OpenSQLSession()
		{
			this._session = MIGE.Core.DAL.NHibernateSQLSession.CreateSessionFactory().OpenSession();
			return this._session;
		}


		public ISession OpenStateSQLSession()
		{
			return MIGE.Core.DAL.NHibernateSQLSession.CreateSessionFactory().OpenSession();
		}


		public SearchResult<AgentMaster> FindAgents(
			AgentFilter filter)
		{
			List<AgentMaster> agents = new List<AgentMaster>();
			int totalMatches = 0;
			int year = filter.Year.HasValue ? filter.Year.Value : DateTime.Now.Year;

			using (_session = this.OpenSQLSession()) {
				using (var sqlSession = this.OpenSQLSession()) {
					try {
						string baseQuery = @"with
	agent_info as (select CDKEY2, min(agent.AGYCDE) as AGYCDE, min(agent.AGYAD1) as AGYAD1
	, min(agent.AGYAD2) as AGYAD2, min(agent.AGYCTY) as AGYCTY
	, min(agent.AGYST) as AGYST, min(agent.AGYZIP) as AGYZIP, min(agent.AGYNAM)as AGYNAM
	, min(agent.REGOFC) as REGOFC
	from DWXF007 agent
	group by CDKEY2
	)
	, mstr_sub as (
		select CDKEY2, IIF(AGYCDE = '', CDKEY2, AGYCDE) as AGYCDE
		from DWXF007 with (nolock) where not exists (select top 1 AGENT from AgentQualification where [YEAR] = {0})
		union
		select AGENT as CDKEY2, AGYCDE from AgentQualification with(nolock)
		where [YEAR] = {0}
	)
select distinct ltrim(rtrim(agent.CDKEY2)) as CDKEY2, ltrim(rtrim(agent.AGYCDE)) as AGYCDE, ltrim(rtrim(agent.AGYAD1)) as AGYAD1
	, ltrim(rtrim(agent.AGYAD2)) as AGYAD2, ltrim(rtrim(agent.AGYCTY)) as AGYCTY
	, ltrim(rtrim(agent.AGYST)) as AGYST, ltrim(rtrim(agent.AGYZIP)) as AGYZIP, ltrim(rtrim(agent.AGYNAM))as AGYNAM
	, ltrim(rtrim(agent.REGOFC)) as REGOFC
	, ltrim(rtrim(info.MKTTER)) as MKTTER
	, coalesce(adda.IsEnabled, 0) as AddAEnabled, coalesce(addc.IsEnabled, 0) as AddCEnabled
	, round(case when adda.MinPremium is null then coalesce(minprem.Premium, 0) else adda.MinPremium end, 0) as minPremium
	, '[' + stuff((select ',' + rtrim(CDKEY2)
		from mstr_sub ms
		where ms.AGYCDE = agent.CDKEY2
		for xml path('')),1,1,'') +']' subAgents
from agent_info agent
	join DWXF108 info on info.cdkey2 = agent.cdkey2
left outer join AddendumA adda on adda.AgentCode = agent.CDKEY2 and adda.Year = {0}
left outer join Addendumc addc on addc.AgentId = agent.CDKEY2 and addc.Year = {0}
left outer join MarketingTerritoryAssignment mkt on mkt.MarketingTerritory = info.MKTTER and mkt.EffectiveYear = {0}
left outer join PlanManagement pmgt on pmgt.PlanInformation_id = mkt.PlanInformation_id
left outer join PlanInformation planinfo on planinfo.Id = pmgt.PlanInformation_id
left outer join MinWrittenPremium minprem on minprem.PlanInformation_id = planinfo.Id and {0} between minprem.StartYear and minprem.EndYear";

								//  {0} is year
								//  {1} is for " (double quote)
								//  {2} is for {1} placeholder for { in final Format
								//  {3} is for {2} placeholder for } in final Format
						string queryStr = string.Format(baseQuery, year, "\"", "{1}", "{2}")
								+ " {0}"  // where clause placeholder
								+ " order by ltrim(rtrim(agent.CDKEY2))";
	//, stuff((select ',' + rtrim(CDKEY2)
	//	from mstr_sub
	//	where AGYCDE = agent.CDKEY2
	//	for xml path('')),1,1,'') subAgents

	//, '[' + stuff((select ',' + '{2}{1}AgentId{1}:{1}' + rtrim(ms.CDKEY2) + '{1}{3}'
	//	from mstr_sub ms
	//	where ms.AGYCDE = agent.CDKEY2
	//	for xml path('')),1,1,'') +']' subAgents

						StringBuilder where = new StringBuilder();

								//  agent ID
						if ((filter.Id != null) && (filter.Id.Length > 0)) {
							where.Append(string.Format("agent.CDKEY2 in ('{0}') and ", string.Join("','", filter.Id)));
						}
								//  territory
						if (!string.IsNullOrEmpty(filter.Territory)) {
							where.Append(string.Format("mkt.MarketingTerritory = '{0}' and ", filter.Territory));
						}
								//  region
						if (!string.IsNullOrEmpty(filter.Region)) {
							where.Append(string.Format("agent.REGOFC = '{0}' and ", filter.Region));
						}
								//  addendum A enabled
						if (filter.AddendumAEnabled.HasValue && filter.Year.HasValue) {
							where.Append("adda.IsEnabled = 1 and ");
						}
								//  addendum C enabled
						if (filter.AddendumCEnabled.HasValue && filter.Year.HasValue) {
							where.Append("addc.IsEnabled = 1 and ");
						}
								//  include canceled
						if (filter.IncludeCanceled.HasValue) {
							// TODO
						}
								//  include zero payments
						if (filter.IncludeZeroPayments.HasValue) {
							// TODO
						}

								//  if we have a where clause, massage it for in the query
						if (where.Length > 4) {
							where.Length -= 5;
							where.Insert(0, " where ");
						}
								//  include the where clause in the query
						queryStr = string.Format(queryStr, where, "{", "}");

						var q1 = sqlSession.CreateSQLQuery(queryStr);
						q1.SetTimeout(300);


								//  execute query
						var q2 = q1.List<object[]>();

								//  get total count
						totalMatches = q2.Count;
						
								//  apply paging and map columns to dynamic object
						var q3 = q2.Skip((filter.Page - 1) * filter.PageSize)
								.Take(filter.PageSize)
								.GroupBy(x => new {
							AgentId = (string)x[0],
							AgentCode = (string)x[1],
							Address1 = (string)x[2],
							Address2 = (string)x[3],
							City = (string)x[4],
							State = (string)x[5],
							Zip = (string)x[6],
							Name = (string)x[7],
							Region = (string)x[8],
							Territory = (string)x[9],
							AdnA = ((int)x[10] == 1),
							AdnC = ((int)x[11] == 1),
							MinPremium = (decimal)x[12],
							SubAgents = (string)x[13]
						});

								//  build AgentMaster instances
						var queryResult = q3.Select(s => new AgentMaster {
							AgentId = s.Key.AgentId,
							MasterAgentId = s.Key.AgentCode,
							Address1 = s.Key.Address1,
							Address2 = s.Key.Address2,
							City = s.Key.City,
							State = s.Key.State,
							Zip = s.Key.Zip,
							Name = s.Key.Name,
							Region = s.Key.Region,
							Territory = s.Key.Territory,
							AdnA = s.Key.AdnA,
							AdnC = s.Key.AdnC,
							MinPremium = s.Key.MinPremium,
							SubAgent = s.Key.SubAgents
						});

						agents.AddRange(queryResult);

					} catch (Exception ex) {
						Logger.Log("FindAgents - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
					}

							//  wrap results in a SearchResult
					var results = new SearchResult<AgentMaster>(agents.ToArray(), filter, filter.Page, filter.PageSize, totalMatches);
					return results;
				}
			}
		}


		public SearchResult<AgentMaster> FindAgents2(
			AgentFilter filter)
		{
			List<AgentMaster> agents = new List<AgentMaster>();
			int totalMatches = 0;
			int year = filter.Year.HasValue ? filter.Year.Value : DateTime.Now.Year;

			using (_session = this.OpenSQLSession()) {
				using (var sqlSession = this.OpenSQLSession()) {
					try {
						StringBuilder baseQuery = new StringBuilder();
//						string baseQuery = @"with
						baseQuery.Append(@"with
	agent_info as (select CDKEY2, min(agent.AGYCDE) as AGYCDE, min(agent.AGYAD1) as AGYAD1
	, min(agent.AGYAD2) as AGYAD2, min(agent.AGYCTY) as AGYCTY
	, min(agent.AGYST) as AGYST, min(agent.AGYZIP) as AGYZIP, min(agent.AGYNAM)as AGYNAM
	, min(agent.REGOFC) as REGOFC
	from DWXF007 agent
	group by CDKEY2
	)
	, mstr_sub as (
		select CDKEY2, IIF(AGYCDE = '', CDKEY2, AGYCDE) as AGYCDE
		from DWXF007 with (nolock) where not exists (select top 1 AGENT from AgentQualification where [YEAR] = {0})
		union
		select AGENT as CDKEY2, AGYCDE from AgentQualification with(nolock)
		where [YEAR] = {0}
	)
select distinct ltrim(rtrim(agent.CDKEY2)) as CDKEY2, ltrim(rtrim(agent.AGYCDE)) as AGYCDE, ltrim(rtrim(agent.AGYAD1)) as AGYAD1
	, ltrim(rtrim(agent.AGYAD2)) as AGYAD2, ltrim(rtrim(agent.AGYCTY)) as AGYCTY
	, ltrim(rtrim(agent.AGYST)) as AGYST, ltrim(rtrim(agent.AGYZIP)) as AGYZIP, ltrim(rtrim(agent.AGYNAM))as AGYNAM
	, ltrim(rtrim(agent.REGOFC)) as REGOFC
	, ltrim(rtrim(info.MKTTER)) as MKTTER
	, coalesce(adda.IsEnabled, 0) as AddAEnabled, coalesce(addc.IsEnabled, 0) as AddCEnabled
	, round(case when adda.MinPremium is null then coalesce(minprem.Premium, 0) else adda.MinPremium end, 0) as minPremium");

								//  only include subagent data if requested
						if (filter.IncludeSubagents) {
							baseQuery.Append(@", '[' + stuff((select ',' + '{2}{1}AgentId{1}:{1}' + rtrim(ms.CDKEY2) + '{1}'
								+ ',{1}Name{1}:{1}' + (select top 1 rtrim(AGYNAM) from DWXF108 where CDKEY2 = ms.CDKEY2) + '{1}'
								+ ',{1}AdnA{1}:{1}' + cast(coalesce(adda.IsEnabled, 0) as varchar(2)) + '{1}'
								+ ',{1}AdnC{1}:{1}' + cast(coalesce(adda.IsEnabled, 0) as varchar(2)) + '{1}'
								+ ',{1}MinPremium{1}:{1}' + cast(coalesce(minprem.Premium, 0) as varchar(20)) + '{1}'
								+ ',{1}Territory{1}:{1}' + rtrim(info.MKTTER) + '{1}'
								+ ',{1}Region{1}:{1}' + (select top 1 rtrim(REGOFC) from DWXF108 where CDKEY2 = ms.CDKEY2) +'{1}'
								+ '{3}'
						from mstr_sub ms
left outer join AddendumA adda on adda.AgentCode = ms.CDKEY2 and adda.Year = 2020
left outer join Addendumc addc on addc.AgentId = ms.CDKEY2 and addc.IsEnabled = 1 and addc.Year = 2020
left outer join MarketingTerritoryAssignment mkt on mkt.MarketingTerritory = info.MKTTER and mkt.EffectiveYear = 2020
left outer join PlanManagement pmgt on pmgt.PlanInformation_id = mkt.PlanInformation_id
left outer join PlanInformation planinfo on planinfo.Id = pmgt.PlanInformation_id
left outer join MinWrittenPremium minprem on minprem.PlanInformation_id = planinfo.Id and 2020 between minprem.StartYear and minprem.EndYear
		where ms.AGYCDE = agent.CDKEY2
		for xml path('')),1,1,'') +']' subAgents");
						} else {
							baseQuery.Append(", null as subAgents");
						}

						baseQuery.Append(@" from agent_info agent
join DWXF108 info on info.cdkey2 = agent.cdkey2
left outer join AddendumA adda on adda.AgentCode = agent.CDKEY2 and adda.Year = {0}
left outer join Addendumc addc on addc.AgentId = agent.CDKEY2 and addc.Year = {0}
left outer join MarketingTerritoryAssignment mkt on mkt.MarketingTerritory = info.MKTTER and mkt.EffectiveYear = {0}
left outer join PlanManagement pmgt on pmgt.PlanInformation_id = mkt.PlanInformation_id
left outer join PlanInformation planinfo on planinfo.Id = pmgt.PlanInformation_id
left outer join MinWrittenPremium minprem on minprem.PlanInformation_id = planinfo.Id and {0} between minprem.StartYear and minprem.EndYear");

								//  {0} is year
								//  {1} is for " (double quote)
								//  {2} is for {1} placeholder for { in final Format
								//  {3} is for {2} placeholder for } in final Format
						string queryStr = string.Format(baseQuery.ToString(), year, "\"", "{1}", "{2}")
								+ " {0}"  // where clause placeholder
								+ " order by ltrim(rtrim(agent.CDKEY2))";
						//, stuff((select ',' + rtrim(CDKEY2)
						//	from mstr_sub
						//	where AGYCDE = agent.CDKEY2
						//	for xml path('')),1,1,'') subAgents

						//, '[' + stuff((select ',' + '{2}{1}AgentId{1}:{1}' + rtrim(ms.CDKEY2) + '{1}{3}'
						//	from mstr_sub ms
						//	where ms.AGYCDE = agent.CDKEY2
						//	for xml path('')),1,1,'') +']' subAgents

						StringBuilder where = new StringBuilder();

								//  agent ID
						if ((filter.Id != null) && (filter.Id.Length > 0)) {
							where.Append(string.Format("agent.CDKEY2 in ('{0}') and ", string.Join("','", filter.Id)));
						}
								//  territory
						if (!string.IsNullOrEmpty(filter.Territory)) {
							where.Append(string.Format("mkt.MarketingTerritory = '{0}' and ", filter.Territory));
						}
								//  region
						if (!string.IsNullOrEmpty(filter.Region)) {
							where.Append(string.Format("agent.REGOFC = '{0}' and ", filter.Region));
						}
								//  addendum A enabled
						if (filter.AddendumAEnabled.HasValue && filter.Year.HasValue) {
							where.Append("adda.IsEnabled = 1 and ");
						}
								//  addendum C enabled
						if (filter.AddendumCEnabled.HasValue && filter.Year.HasValue) {
							where.Append("addc.IsEnabled = 1 and ");
						}
								//  include canceled
						if (filter.IncludeCanceled.HasValue) {
							// TODO
						}
								//  include zero payments
						if (filter.IncludeZeroPayments.HasValue) {
							// TODO
						}

								//  if we have a where clause, massage it for in the query
						if (where.Length > 4) {
							where.Length -= 5;
							where.Insert(0, " where ");
						}
								//  include the where clause in the query
						queryStr = string.Format(queryStr, where, "{", "}");

						var q1 = sqlSession.CreateSQLQuery(queryStr);
						q1.SetTimeout(300);

						//  execute query
						var q2 = q1.List<object[]>();

								//  get total count
						totalMatches = q2.Count;

								//  apply paging and map columns to dynamic object
						var q3 = q2.Skip((filter.Page - 1) * filter.PageSize)
								.Take(filter.PageSize)
								.GroupBy(x => new {
									AgentId = (string)x[0],
									AgentCode = (string)x[1],
									Address1 = (string)x[2],
									Address2 = (string)x[3],
									City = (string)x[4],
									State = (string)x[5],
									Zip = (string)x[6],
									Name = (string)x[7],
									Region = (string)x[8],
									Territory = (string)x[9],
									AdnA = ((int)x[10] == 1),
									AdnC = ((int)x[11] == 1),
									MinPremium = (decimal)x[12],
									SubAgents = (string)x[13]
								});

								//  build AgentMaster instances
						var queryResult = q3.Select(s => new AgentMaster {
							AgentId = s.Key.AgentId,
							MasterAgentId = s.Key.AgentCode,
							Address1 = s.Key.Address1,
							Address2 = s.Key.Address2,
							City = s.Key.City,
							State = s.Key.State,
							Zip = s.Key.Zip,
							Name = s.Key.Name,
							Region = s.Key.Region,
							Territory = s.Key.Territory,
							AdnA = s.Key.AdnA,
							AdnC = s.Key.AdnC,
							MinPremium = s.Key.MinPremium,
							SubAgent = s.Key.SubAgents
						});

						agents.AddRange(queryResult);

					} catch (Exception ex) {
						Logger.Log("FindAgents - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
					}

							//  wrap results in a SearchResult
					var results = new SearchResult<AgentMaster>(agents.ToArray(), filter, filter.Page, filter.PageSize, totalMatches);
					return results;
				}
			}
		}


		public List<AgentMaster> GetAgents(
			int pageNumber = 0,
			int pageSize = 15)
		{
			List<AgentMaster> agentMasters = new List<AgentMaster>();
			using (_session = this.OpenSQLSession()) {
				using (var sqlSession = this.OpenSQLSession()) {
					try {
						var query = (
							from agentms in _session.Query<DWXF007>()
							select new AgentMaster {
								AgentId = agentms.CDKEY2,
								MasterAgentId = agentms.AGYCDE ?? "",
								Address1 = agentms.AGYAD1 ?? "",
								Address2 = agentms.AGYAD2 ?? "",
								City = agentms.AGYCTY ?? "",
								State = agentms.AGYST ?? "",
								Zip = agentms.AGYZIP ?? "",
								Name = agentms.AGYNAM ?? "",
								Region = agentms.REGOFC ?? "",
								Territory = GetMarketingTerritory(agentms.CDKEY2),// agentms2.MKTTER,
								AdnA = false,
								AdnC = false,
								MinPremium = 0

							});

						agentMasters = query
							.Skip(pageNumber * pageSize)
							.Take(pageSize)
							.Distinct()
							.ToList();

					} catch (Exception ex) {
						Logger.Log("DWXF007 - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
					}

					return agentMasters;
				}
			}
		}


		public dynamic AgentStartDate(
			string agentCode,
			int? year)
		{
			//int? startDate = null;

			using (_session = this.OpenSQLSession()) {
				try {
					//decimal? decDate = null;

					if (!year.HasValue) {
						year = DateTime.Now.Year;
					}

					var q1 = _session.CreateSQLQuery(
						"with mstr_sub as ("
							+ " select CDKEY2, IIF(AGYCDE = '', CDKEY2, AGYCDE) as AGYCDE"
							+ " from DWXF007 with (nolock) where not exists(select top 1 AGENT from AgentQualification where [YEAR] = :year)"
							+ " union"
							+ " select AGENT as CDKEY2, AGYCDE from AgentQualification with(nolock)"
							+ " where [YEAR] = :year)"
						+ " select rtrim(agnt.CDKEY2) as AgentId, round(min(agnt.EFFDTE), 0) as ActualStartDate, (select round(min(EFFDTE), 0) from vw_agent_base where CDKEY2 in (select CDKEY2 from mstr_sub where AGYCDE = agnt.CDKEY2)) as CalculatedStartDate"
							+ " from vw_agent_base agnt"
							+ " where agnt.CDKEY2 = :agentCode"
							+ " group by agnt.CDKEY2")
						.SetParameter("agentCode", agentCode)
						.SetDecimal("year", year.Value);

					var result = q1.DynamicList();

					if (result.Count > 0) {
						return result[0];
					} else {
						return "Agent not found";
					}
				} catch (Exception ex) {
					Logger.Log("AgentStartDate " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
					throw;
				}
			}
		}


		public int TotalNumberOfAgents()
		{
			int totalNumber = 0;

			using (_session = this.OpenSQLSession()) {
				using (var sqlSession = this.OpenSQLSession()) {
					try {
						totalNumber = _session.Query<DWXF007>().Select(i => i.CDKEY2).Distinct().Count();
					} catch (Exception ex) {
						Logger.Log("TotalNumberOfAgents - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
					}

					return totalNumber;
				}
			}
		}


		private string GetMarketingTerritory(
			string agentCode)
		{
			string mtkTerr = "";
			using (_session = this.OpenSQLSession()) {
				try {
					mtkTerr = (
							from agentms in _session.Query<DWXF108>()
							where agentms.CDKEY2.Trim().ToLower() == agentCode.Trim().ToLower()
							select agentms.MKTTER).FirstOrDefault();
				} catch (Exception ex) {
					Logger.Log("GetMarketingTerritory " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				}

				return mtkTerr;
			}
		}

		public string[] GetMasterAgentIds()
        {
			string[] masters = new string[0];

			try
			{
				using (var sqlSession = this.OpenSQLSession())
				{

					string sql = string.Format("EXEC SP_StatementGetAllMasterAgents");

					//  generate stored procedure call
					var q = sqlSession.CreateSQLQuery(sql);
					q.SetTimeout(3600); // 60 min

					//  execute stored procedure and get results
					//var result = q.DynamicList();

					//if (result.Count > 0)
					//{
					//                   masters = result.Select(a=>(string)a.CDKEY2).ToArray();

					//}
					var result = q.List();

					if (result.Count > 0)
					{
						masters = result.Cast<string>().ToArray();

					}
					for (int i = 0; i < masters.Length; i++) 
                    {
						masters[i] = masters[i].Trim();
                    }

				}
			}
			catch (Exception ex)
			{
				Logger.Log("GetReportMasterAgentIds- error " + ex.Message, Logger.LogLevel.ERROR, ex);
				throw;
			}

			return masters;
		}

		public string[] GetReportMasterAgentIds(
		int year,
		int month,
		bool includeZeroPayment,
		string orderBy)
		{
			string[] masters = new string[0];

			try {
				using (var sqlSession = this.OpenSQLSession()) {
					
					//string sql = string.Format("EXEC SP_StatementGetReportMasterAgents @year = {0}, @month = {1}", year, month);
					string sql = string.Format("EXEC SP_StatementGetAllMasterAgents_WithRegion");


					//  generate stored procedure call
					var q = sqlSession.CreateSQLQuery(sql);
					q.SetTimeout(3600); // 60 min

					//  execute stored procedure and get results
					//var result = q.DynamicList();
					var result = q.DynamicList();

                    if (result.Count > 0)
                    {
                        if (orderBy.ToLower() == "region")
                        {
                            masters = result.OrderBy(a => a.REGOFC).ThenBy(a=>a.MKTTER).ThenBy(a => a.CDKEY2).Select(a => (string)a.CDKEY2).Distinct().ToArray();
                        }
                        else
                        {
                            masters = result.OrderBy(a => a.CDKEY2).Select(a => (string)a.CDKEY2).ToArray();
                        }
                    }

                    //if (result.Count > 0)
                    //{
                    //	masters = result.Cast<string>().ToArray();
                    //}
                }
			} catch (Exception ex) {
				Logger.Log("GetReportMasterAgentIds- error " + ex.Message, Logger.LogLevel.ERROR, ex);
				throw;
			}

			return masters;
		}

		public SearchResult<AgentMaster> GetSubAgents(
			string agentId,
			int year,
			int pageNumber = 0,
			int numberOfRecords = 0)
		{
			List<AgentMaster> subs = new List<AgentMaster>();
			int totalMatches = 0;

			using (var sqlSession = this.OpenSQLSession()) {
				try {
							//  see if there are "locked" relationships for the year
					int aqCnt = (int)sqlSession.CreateSQLQuery(string.Format("select count(*) from AgentQualification aq where AGYCDE = {0} and Year = {1}", agentId, year)).UniqueResult();

					// TODO: fix AdnA, AdnC, MinPremium
							//  if no relationships in AgentQualification, use DWXF007
					if (aqCnt == 0) {

						
						var query = (
							from agentms in sqlSession.Query<DWXF007>()
							//join agentms2 in sqlSession.Query<DWXF108>() on agentms.CDKEY2 equals agentms2.CDKEY2
							where agentms.AGYCDE.Trim().ToLower() == agentId
							select new AgentMaster {
								AgentId = agentms.CDKEY2.Trim(),
								MasterAgentId = agentms.AGYCDE.Trim() ?? "",
								SubAgent = agentms.CDKEY2.Trim() ?? "",
								Name = agentms.AGYNAM.Trim() ?? "",
								Region = agentms.REGOFC.Trim() ?? "",
								//Territory = agentms2.MKTTER.Trim(),
								AdnA = false,
								AdnC = false,
								MinPremium = 0
							}
							);

								//  get total count
						totalMatches = query.Distinct().ToList().Count;

						subs = query.OrderBy(a => a.AgentId)
							.Distinct()
							.Skip(pageNumber * numberOfRecords)
							.Take(numberOfRecords == 0 ? 10000 : numberOfRecords)
							.ToList();

							//  prior year, get relationships from AgentQualification
					} else {
						var q1 = sqlSession.CreateSQLQuery(
								"select distinct aq.AGENT, aq.AGYCDE as AgentCode, aq.AGENT as SubAgent, agnt.AGYNAM as Name, agnt.REGOFC as Region,"
								+ " coalesce(aq.STOPLOSS, 0) as AdnC, coalesce(aq.MINPREM, 0) as MinPremium"
								+ " from AgentQualification aq"
								+ " join DWXF007 agnt on aq.AGENT = agnt.CDKEY2"
								+ " where aq.AGYCDE = :agycde and aq.YEAR = :year")
							.SetParameter("agycde", agentId)
							.SetDecimal("year", year);

								//  execute query
						var q2 = q1.List<object[]>();

								//  get total count
						totalMatches = q2.Distinct().Count();

								//  build AgentMaster instances
						var query = q2.Select(s => new AgentMaster {
							AgentId = (string)s[0],
							MasterAgentId = (string)s[1],
							SubAgent = (string)s[2],
							Name = (string)s[3],
							Region = (string)s[4],
							AdnC = ((int)s[5] != 0),
							MinPremium = (decimal)s[6]
						});

						subs = query.OrderBy(a => a.AgentId)
							.Distinct()
							.Skip(pageNumber * numberOfRecords)
							.Take(numberOfRecords == 0 ? 10000 : numberOfRecords)
							.ToList();
					}
				} catch (Exception ex) {
					Logger.Log("GetSubAgents - error " + ex.Message + " STACK TRACE: " + ex.StackTrace, Logger.LogLevel.ERROR);
				}

//				return subs.ToList();
						//  wrap results in a SearchResult
				var results = new SearchResult<AgentMaster>(subs.ToArray(), null, pageNumber + 1, numberOfRecords, totalMatches);
				return results;
			}
		}


		public bool HasSubAgents(
			string agentId)
		{
			List<DWXF007> queryList = new List<DWXF007>();
			using (_session = this.OpenSQLSession()) {
				try {
					var query = (
						 from agentms in _session.Query<DWXF007>()
						 where agentms.AGYCDE.Trim().ToLower() == agentId
						 select agentms);
					queryList = query.ToList();
				} catch (Exception ex) {
					Logger.Log("HasSubAgents - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				}

				return (queryList.Count > 0);
			}
		}


		public AgentMaster GetAgentById(
			string agentId)
		{
			AgentMaster agentMaster = new AgentMaster();
			using (_session = this.OpenSQLSession()) {
				using (var sqlSession = this.OpenSQLSession()) {
					try {
						agentMaster = (
							from agentms in _session.Query<DWXF007>()
							where agentms.CDKEY2.Trim() == agentId.Trim()
							select new AgentMaster {
								AgentId = agentms.CDKEY2,
								MasterAgentId = agentms.AGYCDE ?? "",
								Address1 = agentms.AGYAD1 ?? "",
								Address2 = agentms.AGYAD2 ?? "",
								City = agentms.AGYCTY ?? "",
								State = agentms.AGYST ?? "",
								Zip = agentms.AGYZIP ?? "",
								Name = agentms.AGYNAM ?? "",
								Region = agentms.REGOFC ?? "",
								Territory = GetMarketingTerritory(agentms.CDKEY2),// agentms2.MKTTER,
								AdnA = false,
								AdnC = false,
								MinPremium = 0
							}).FirstOrDefault();

					} catch (Exception ex) {
						Logger.Log("DWXF007 - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);

					}

					return agentMaster;
				}
			}
		}


		//public void AddAddendumC(
		//	Addendumc addendumc)
		//{
		//	List<string> addendumcs = new List<string>();

		//	try {
		//				//save the parent
		//		using (var sqlSession = this.OpenSQLSession()) {
		//			if (this.HasSubAgents(addendumc.AgentId.Trim())) {
		//				addendumcs = (
		//						from agentms in sqlSession.Query<DWXF007>()
		//						where agentms.AGYCDE.Trim().ToLower() == addendumc.AgentId.Trim().ToLower()
		//						select agentms.CDKEY2).ToList();
		//			}result = ((ExpandoObject)result).FirstOrDefault(x => x.Key == "children");
		//			sqlSession.SaveOrUpdate(new Addendumc { AgentId = addendumc.AgentId, Year = DateTime.Now.Year, IsEnabled = addendumc.IsEnabled });
		//		}

		//		using (var sqlSession = this.OpenSQLSession()) {
		//					//save sub agents
		//			foreach (string agentId in addendumcs.ToList().Distinct()) {
		//				using (var transaction = sqlSession.BeginTransaction()) {
		//					sqlSession.SaveOrUpdate(new Addendumc { AgentId = agentId, Year = DateTime.Now.Year, IsEnabled = true });
		//					transaction.Commit();
		//				}

		//			}
		//		}
		//	} catch (Exception ex) {
		//		Logger.Log("AddAddendumC - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
		//	}

		//	return;
		//}


		public List<Addendumc> GetAdnCByAgentId(
			string agentId)
		{
			List<Addendumc> addendumcList = new List<Addendumc>();

			try {
						//save the parent
				using (var sqlSession = this.OpenSQLSession()) {
					addendumcList = (
							from agentms in _session.Query<Addendumc>()
							where agentms.AgentId.Trim().ToLower() == agentId.ToLower().Trim()
							select agentms).ToList();
				}
			} catch (Exception ex) {
				Logger.Log("DWXF108 - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
			}

			return addendumcList;
		}


		//public Addendumc UpdateAddC(
		//	Addendumc addendumc)
		//{
		//	List<string> addendumcs = new List<string>();
		//	Addendumc addendumcExisting = new Addendumc();
		//	try {
		//				//save the parent
		//		using (var sqlSession = this.OpenSQLSession()) {
		//			addendumcExisting = (
		//					from agentms in _session.Query<Addendumc>()
		//					where agentms.AgentId.Trim().ToLower() == addendumc.AgentId.ToLower().Trim()
		//					select agentms).FirstOrDefault();
		//			if (addendumcExisting != null) {
		//				addendumcExisting.IsEnabled = addendumc.IsEnabled;
		//				addendumcExisting.Year = addendumc.Year;
		//				using (var transaction = sqlSession.BeginTransaction()) {
		//					sqlSession.Update(addendumcExisting);
		//					transaction.Commit();
		//				}
		//			}
		//		}
		//		if (this.HasSubAgents(addendumc.AgentId.Trim())) {
		//			using (var sqlSession = this.OpenSQLSession()) {
		//				addendumcs = (
		//						from agentms in sqlSession.Query<DWXF007>()
		//						where agentms.AGYCDE.Trim().ToLower() == addendumc.AgentId.Trim().ToLower()
		//						select agentms.CDKEY2).ToList();

		//						//save sub agents
		//				foreach (string agentId in addendumcs) {
		//					addendumcExisting = (
		//							from agentms in _session.Query<Addendumc>()
		//							where agentms.AgentId.Trim().ToLower() == agentId.ToLower().Trim()
		//							select agentms).FirstOrDefault();

		//					if (addendumcExisting != null) {
		//						addendumcExisting.IsEnabled = addendumc.IsEnabled;
		//						addendumcExisting.Year = addendumc.Year;
		//						using (var transaction = sqlSession.BeginTransaction()) {
		//							sqlSession.Update(addendumcExisting);
		//							transaction.Commit();
		//						}
		//					}
		//				}
		//			}
		//		}
		//	} catch (Exception ex) {
		//		Logger.Log("DWXF108 - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);

		//	}

		//	return addendumcExisting;
		//}


		public Addendumc[] AddBulkAddendumC(Addendumc[] addendumcs)
		{
			List<string> addendumcsList = new List<string>();

			try {
				foreach (Addendumc addendumc in addendumcs) {

					if (this.HasSubAgents(addendumc.AgentId.Trim())) {
						using (var sqlSession = this.OpenSQLSession()) {
							addendumcsList = (
								from agentms in _session.Query<DWXF007>()
								where agentms.AGYCDE.Trim().ToLower() == addendumc.AgentId.Trim().ToLower()
								select agentms.CDKEY2).ToList();
								sqlSession.SaveOrUpdate(new Addendumc { AgentId = addendumc.AgentId, Year = addendumc.Year, IsEnabled = addendumc.IsEnabled });
						}
					}

					using (var sqlSession = this.OpenSQLSession()) {
						foreach (string agentId in addendumcsList) {
							sqlSession.SaveOrUpdate(new Addendumc { AgentId = agentId, Year = addendumc.Year, IsEnabled = true });
						}
					}
				}
			} catch (Exception ex) {
				Logger.Log("AddBulkAddendumC - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
			}

			return addendumcs;
		}


		public Addendumc[] BulkFileAddendumC(
			System.Web.HttpFileCollection files)
		{
			List<Addendumc> retList = new List<Addendumc>();
		
			try {
				var csvConfig = new CsvHelper.Configuration.CsvConfiguration(System.Globalization.CultureInfo.InvariantCulture);
				csvConfig.HeaderValidated = null;
				csvConfig.MissingFieldFound = null;

				Addendumc[] addendumCs;

				foreach (string fileName in files) {
					var file = files[fileName];

							//  parse the CSV file
					using (var reader = new StreamReader(file.InputStream)) {
						using (var csv = new CsvHelper.CsvReader(reader, csvConfig)) {
							addendumCs = csv.GetRecords<Addendumc>().ToArray();
						}
					}

					using (var sqlSession = this.OpenSQLSession()) {
						foreach (Addendumc addC in addendumCs) {
									//  if import file doesn't have IDs left padded w/0s, pad now
							if (addC.AgentId.Length < 5) {
								addC.AgentId = addC.AgentId.PadLeft(5, '0');
							}
									//  get the sub-agent IDs
							List<string> agentIds = (from agentms in _session.Query<DWXF007>()
									where agentms.AGYCDE.Trim().ToLower() == addC.AgentId.Trim().ToLower()
									select agentms.CDKEY2.Trim()).Distinct().ToList();

									//  if list not created by sub-agent look up, create it
							if (agentIds == null) {
								agentIds = new List<string>();
							}
									//  add the current agent ID to the list if not already included
							if (!agentIds.Contains(addC.AgentId.Trim())) {
								agentIds.Add(addC.AgentId.Trim());
							}

									//  add or update the Addendumc record(s)
							foreach (string id in agentIds) {
										//  look up indentity value of Addendumc table if agent/year already exists
										//  (needed to update existing record)
								Addendumc rec = (from addCEx in _session.Query<Addendumc>()
										where addCEx.AgentId.Trim() == id && addCEx.Year == addC.Year
										select addCEx).FirstOrDefault();

								if (rec == null) {
											//  if no record exists for agent/year, create one
									rec = new Addendumc {
										Id = 0,
										AgentId = id,
										Year = addC.Year,
										IsEnabled = addC.IsEnabled
									};

										//  if records already exists for agent/year, update enabled flag
								} else {
									rec.IsEnabled = addC.IsEnabled;
								}

										//  add/update Addendumc record
								sqlSession.SaveOrUpdate(rec);

								retList.Add(rec);
							}

							agentIds.Clear();
						}

						sqlSession.Flush();
					}
				}

			} catch (Exception e) {
				Logger.Log("BulkFileAddendumC - error " + e.Message + " STACK TRACE" + e.StackTrace, Logger.LogLevel.ERROR);
			}

			return retList.ToArray();
		}


		#region Premium Volume & Loss Ratio Factors

		//public int AddPremiumVolumeLossRatio(
		//	ProfitGrowthFactors profitGrowthFactor)
		//{

		//	try {
		//		PremiumVolumeLossRatioTbl tbl = new PremiumVolumeLossRatioTbl {
		//			Id = profitGrowthFactor.Id,
		//			Name = profitGrowthFactor.Name,
		//			TableStatus = profitGrowthFactor.TableStatus,
		//			Rows = JsonConvert.DeserializeObject<List<PremiumVolumeLossRatioValue>>(profitGrowthFactor.Data)
		//		};

		//		using (var sqlSession = this.OpenSQLSession()) {
		//			sqlSession.SaveOrUpdate(tbl);
		//			sqlSession.Flush();
		//		}

		//		return tbl.Id;
		//	} catch (Exception ex) {
		//		Logger.Log("Growth Factor Add/Update - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
		//		throw ex;

		//	}
		//}

		#endregion


		#region Profit Growth Factors

		public int AddGrowthFactor(
		ProfitGrowthFactors profitGrowthFactor)
	{

		try {
			//save the parent   
			using (var sqlSession = this.OpenSQLSession()) {
				sqlSession.SaveOrUpdate(profitGrowthFactor);
			}
		} catch (Exception ex) {
			Logger.Log("Growth Factor Add/Update - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
			throw ex;

		}

		return profitGrowthFactor.Id;
	}


	public bool UpdateGrowthFactor(
		ProfitGrowthFactors profitGrowthFactor)
	{

		try {
			//save the parent   
			using (var sqlSession = this.OpenSQLSession()) {
				ProfitGrowthFactors existingGrowthFactor = (from gf in sqlSession.Query<ProfitGrowthFactors>()
															where gf.Id == profitGrowthFactor.Id
															select gf).FirstOrDefault();

				if (existingGrowthFactor != null) {
					existingGrowthFactor.Data = profitGrowthFactor.Data;
					existingGrowthFactor.Name = profitGrowthFactor.Name;
					existingGrowthFactor.TableStatus = profitGrowthFactor.TableStatus;
					sqlSession.Update(existingGrowthFactor);
					sqlSession.Flush();
				}

			}
		} catch (Exception ex) {
			Logger.Log("Growth Factor Update - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
			throw ex;

		}

		return true;
	}

	#endregion


		public ProfitGrowthFactors GetGrowthFactor(
			int growthFactorId)
		{

			try {
				//save the parent   
				using (var sqlSession = this.OpenSQLSession()) {
					ProfitGrowthFactors existingGrowthFactor = (from gf in sqlSession.Query<ProfitGrowthFactors>()
																where gf.Id == growthFactorId
																select gf).FirstOrDefault();

					if (existingGrowthFactor != null) {
						return existingGrowthFactor;
					}
				}
			} catch (Exception ex) {
				Logger.Log("Growth Factor Add/Update - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return new ProfitGrowthFactors();
		}


		public List<ProfitGrowthFactors> GetAllDataByTable(
			TableNames tableType)
		{
			List<ProfitGrowthFactors> tables = new List<ProfitGrowthFactors>();

			try {
				using (var sqlSession = this.OpenSQLSession()) {
					//switch (tableType) {
					//	case TableNames.PremiumVolumeLossRatio:
					//		tables = (from tbl in sqlSession.Query<PremiumVolumeLossRatioTbl>()
					//				select new ProfitGrowthFactors(tbl)).ToList<ProfitGrowthFactors>();
					//		break;

					//	default:
							tables = (from gf in sqlSession.Query<ProfitGrowthFactors>()
									where gf.TableNames == tableType
									select gf).ToList<ProfitGrowthFactors>();
					//		break;
					//}
				}
			} catch (Exception ex) {
				Logger.Log("Growth Factor Add/Update - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return tables;
		}
		//public List<ProfitGrowthFactors> GetAllDataByTable(
		//	TableNames table)
		//{
		//	List<ProfitGrowthFactors> existingGrowthFactor = new List<ProfitGrowthFactors>();

		//	try {
		//		using (var sqlSession = this.OpenSQLSession()) {
		//			existingGrowthFactor = (from gf in sqlSession.Query<ProfitGrowthFactors>()
		//									where gf.TableNames == table
		//									select gf).ToList<ProfitGrowthFactors>();



		//		}
		//	} catch (Exception ex) {
		//		Logger.Log("Growth Factor Add/Update - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
		//		throw ex;
		//	}

		//	return existingGrowthFactor;
		//}


		public PlanInformaionDTO AddPlan(
			PlanInformaionDTO planInformationDTO)
		{
			try {
				//save the parent   
				using (var sqlSession = this.OpenSQLSession()) {
					PlanInformation planInformation = new PlanInformation { 
						PlanName = planInformationDTO.PlanName,
						DisablePlan = 0};

					sqlSession.SaveOrUpdate(planInformation);

					planInformationDTO.Id = planInformation.Id;
					PlanManagement planManagement = new PlanManagement {
						PlanInformation = planInformation,
						StartYear = DateTime.Now.Year,
						EndYear = 9999,
						PremiumVolumeLossRatioReference = sqlSession.Query<ProfitGrowthFactors>().Where(p => p.Id == planInformationDTO.PremiumVolumeLossRatioReferenceId).FirstOrDefault(),
						ProfitGrowthFactorsReference = sqlSession.Query<ProfitGrowthFactors>().Where(p => p.Id == planInformationDTO.ProfitGrowthFactorsReferenceId).FirstOrDefault(),
						ThreeYearProfitabilityReference = sqlSession.Query<ProfitGrowthFactors>().Where(p => p.Id == planInformationDTO.ProfitGrowthFactorsReferenceId).FirstOrDefault()
					};

					sqlSession.SaveOrUpdate(planManagement);
				}
			} catch (Exception ex) {
				Logger.Log("Plan Info - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return planInformationDTO;
		}


		public int EditPlan(
			PlanInformation planInformation)
		{
			PlanInformation planInformationExisting = null;

			try {

				using (var sqlSession = this.OpenSQLSession()) {
							//get the plan
					planInformationExisting = (from pi in sqlSession.Query<PlanInformation>()
											   where pi.Id == planInformation.Id
											   select pi).FirstOrDefault();
					if (planInformationExisting != null) {
						planInformationExisting.PlanName = planInformation.PlanName;

								//update
						sqlSession.SaveOrUpdate(planInformationExisting);
						sqlSession.Flush();
					}
				}
			} catch (Exception ex) {
				Logger.Log("Plan Info - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return planInformation.Id;
		}

		public bool DeletePlan(
			int planInformationId)
		{
			bool planInUse = true;
			List<int> planIds = null;

			try
			{

				using (var sqlSession = this.OpenSQLSession())
				{
					//get the plan ids used by marketing territory					
					planIds = (from mt in sqlSession.Query<MarketingTerritoryAssignment>()
							   select mt.PlanInformation.Id).Distinct().ToList();

					planInUse = planIds.IndexOf(planInformationId) != -1;

					//delete
					if (!planInUse)
					{
						int piCount = sqlSession.Delete(string.Format("from PlanInformation pi where pi.Id = {0}", planInformationId));
						int pmCount = sqlSession.Delete(string.Format("from PlanManagement pm where pm.PlanInformation.Id = {0}", planInformationId));
						int mwpCount = sqlSession.Delete(string.Format("from MinWrittenPremium mwp where mwp.PlanInformation.Id = {0}", planInformationId));

					}
					sqlSession.Flush();

				}			
			}
			catch (Exception ex)
			{
				Logger.Log("Plan Info - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return planInUse;
		}

		public int EnableDisablePlan(
			int planInformationId,
			int disable)
		{
			PlanInformation planInformation;
			int count;

			try
			{

				using (var sqlSession = this.OpenSQLSession())
				{
					planInformation = (from pi in sqlSession.Query<PlanInformation>()
							 where pi.Id == planInformationId
							 select pi).FirstOrDefault();
					if (planInformation != null)
					{
						planInformation.DisablePlan = disable;
						//update
						using (var transaction = sqlSession.BeginTransaction())
						{
							sqlSession.Update(planInformation);
							transaction.Commit();
						}

					}
				}
			}
			catch (Exception ex)
			{
				Logger.Log("Plan Info - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return planInformation.Id;
		}


		public IList<Plan> GetAllPlans()
		{
			IList<Plan> planInformationList = new List<Plan>();
			try {
				using (var sqlSession = this.OpenSQLSession()) {
					var query = sqlSession.CreateSQLQuery("select pi.id as PlanId, planname, StartYear,EndYear,ThreeYearProfitabilityReference_id as ThreeYearProfitabilityReferenceId," +
						"ProfitGrowthFactorsReference_id as ProfitGrowthFactorsReferenceId, PremiumVolumeLossRatioReference_id as PremiumVolumeLossRatioReferenceId, pi.DisablePlan as DisablePlan from planinformation as pi" +
						" inner join planmanagement as pm on pm.PlanInformation_id = pi.id");

					foreach (object[] o in query.List()) {
						planInformationList.Add(new Plan {
							PlanId = (int)o[0],
							PlanName = (string)o[1],
							StartYear = (int)o[2],
							EndYear = (int)o[3],
							MinPremium = 0,
							ThreeYearProfitabilityReferenceId = o[4] == null ? -1 : (int)o[4],
							ProfitGrowthFactorsReferenceId = o[5] == null ? -1 : (int)o[5],
							PremiumVolumeLossRatioReferenceId = o[6] == null ? -1 : (int)o[6],
							DisablePlan = (int)o[7],
						});
					}
				}
			} catch (Exception ex) {
				Logger.Log("GetAllPlans - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return planInformationList;
		}


		public PlanInformation GetPlanInformationById(
			int planinformationId)
		{
			PlanInformation planInformation;
			try {

				using (var sqlSession = this.OpenSQLSession()) {
					//get the plan
					planInformation = (from pi in sqlSession.Query<PlanInformation>()
									   where pi.Id == planinformationId
									   select pi).FirstOrDefault();
				}
			} catch (Exception ex) {
				Logger.Log("GetAllPlans - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return planInformation;
		}


		public int AddNewPlanToManage(
			PlanManagementDTO planManagement)
		{
			PlanManagement planManagementNew = null;
			try {
				//save the parent   
				using (var sqlSession = this.OpenSQLSession()) {
					planManagementNew = new PlanManagement {
						PlanInformation = sqlSession.Query<PlanInformation>().Where(q => q.Id == planManagement.PlanInformationId).FirstOrDefault(),
						StartYear = planManagement.StartYear,
						EndYear = planManagement.EndYear,
						PremiumVolumeLossRatioReference = sqlSession.Query<ProfitGrowthFactors>().Where(q => q.Id == planManagement.PremiumVolumeLossRatioId).FirstOrDefault(),
						ProfitGrowthFactorsReference = sqlSession.Query<ProfitGrowthFactors>().Where(q => q.Id == planManagement.ProfitGrowthFactorsId).FirstOrDefault(),
						ThreeYearProfitabilityReference = sqlSession.Query<ProfitGrowthFactors>().Where(q => q.Id == planManagement.ThreeYearProfitabilityId).FirstOrDefault()

					};
					sqlSession.SaveOrUpdate(planManagementNew);
				}
			} catch (Exception ex) {
				Logger.Log("Plan Info - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return planManagementNew.Id;
		}


		public int EditPlanToManage(
			PlanManagementDTO planManagement)
		{
			PlanManagement planManagementExisting = null;
			try {

				using (var sqlSession = this.OpenSQLSession()) {
					//get the plan
					planManagementExisting = (from pi in sqlSession.Query<PlanManagement>()
											  where pi.Id == planManagement.Id
											  select pi).FirstOrDefault();
					if (planManagementExisting != null) {
						planManagementExisting.StartYear = planManagement.StartYear;
						planManagementExisting.EndYear = planManagement.EndYear;
						planManagementExisting.PremiumVolumeLossRatioReference = sqlSession.Query<ProfitGrowthFactors>().Where(q => q.Id == planManagement.PremiumVolumeLossRatioId).FirstOrDefault();
						planManagementExisting.ProfitGrowthFactorsReference = sqlSession.Query<ProfitGrowthFactors>().Where(q => q.Id == planManagement.ProfitGrowthFactorsId).FirstOrDefault();
						planManagementExisting.ThreeYearProfitabilityReference = sqlSession.Query<ProfitGrowthFactors>().Where(q => q.Id == planManagement.ThreeYearProfitabilityId).FirstOrDefault();
						//update
						using (var transaction = sqlSession.BeginTransaction()) {
							sqlSession.Update(planManagementExisting);
							transaction.Commit();
						}
					}
				}
			} catch (Exception ex) {
				Logger.Log("Plan Info - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return planManagementExisting.Id;
		}


		public PlanManagement GetPlanToManageById(
			int planId)
		{
			PlanManagement planManagement = new PlanManagement();
			try {

				using (var sqlSession = this.OpenSQLSession()) {
					//get the plan
					planManagement = (from pm in sqlSession.Query<PlanManagement>()
									 .Fetch(pm => pm.PlanInformation)
									 .Fetch(pm => pm.PremiumVolumeLossRatioReference)
									 .Fetch(pm => pm.ProfitGrowthFactorsReference)
									 .Fetch(pm => pm.ThreeYearProfitabilityReference)
									  where pm.Id == planId
									  select pm).FirstOrDefault();

				}
			} catch (Exception ex) {
				Logger.Log("Plan Info - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return planManagement;
		}


		public List<PlanManagement> GetAllPlansToManage(
			int planId)
		{
			List<PlanManagement> planManagements = new List<PlanManagement>();
			try {

				using (var sqlSession = this.OpenSQLSession()) {
					//get the plan
					planManagements = (from pi in sqlSession.Query<PlanManagement>()
									   .Fetch(pi => pi.PlanInformation)
									   .Fetch(pi => pi.PremiumVolumeLossRatioReference)
									   .Fetch(pi => pi.ProfitGrowthFactorsReference)
									   .Fetch(pi => pi.ThreeYearProfitabilityReference)
									   where pi.PlanInformation.Id == planId
									   select pi).ToList();

				}
			} catch (Exception ex) {
				Logger.Log("Plan Info - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return planManagements;
		}


		public int AddMinWrittenPremium(
			MinWrittenPremium minWrittenPremium,
			int planId)
		{
			try {
				//save the parent   
				using (var sqlSession = this.OpenSQLSession()) {
					minWrittenPremium.PlanInformation.Id = planId;
					sqlSession.SaveOrUpdate(minWrittenPremium);
				}
			} catch (Exception ex) {
				Logger.Log("Plan Info - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return minWrittenPremium.Id;
		}


		public MinWrittenPremium EditMinWrittenPremium(
			MinWrittenPremiumDTO minWrittenPremium)
		{
			MinWrittenPremium minWrittenPremiumExisting = null;
			try {
				using (var sqlSession = this.OpenSQLSession()) {
					//get the plan
					minWrittenPremiumExisting = (from pi in sqlSession.Query<MinWrittenPremium>()
												 where pi.Id == minWrittenPremium.Id
												 select pi).FirstOrDefault();
					if (minWrittenPremiumExisting != null) {
						minWrittenPremiumExisting.StartYear = minWrittenPremium.StartYear;
						minWrittenPremiumExisting.EndYear = minWrittenPremium.EndYear;
						minWrittenPremiumExisting.Premium = minWrittenPremium.Premium;
						//update
						using (var transaction = sqlSession.BeginTransaction()) {
							sqlSession.SaveOrUpdate(minWrittenPremiumExisting);
							transaction.Commit();
						}
					}
				}
			} catch (Exception ex) {
				Logger.Log("Plan Info - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return minWrittenPremiumExisting;
		}


		public List<MinWrittenPremium> GetAllMinWrittenPremiumByPlanID(
			int planId)
		{
			List<MinWrittenPremium> minWrittenPremiumExistingList = null;
			try {
				using (var sqlSession = this.OpenSQLSession()) {
					//get the plan
					minWrittenPremiumExistingList = (from pi in sqlSession.Query<MinWrittenPremium>()
													  .Fetch(pi => pi.PlanInformation)
													 where pi.PlanInformation.Id == planId
													 select pi).ToList();
				}
			} catch (Exception ex) {
				Logger.Log("Plan Info - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return minWrittenPremiumExistingList;
		}


		public List<string> GetMarketingTerritories()
		{
			List<string> marketingTerritories = null;
			try {
				using (var sqlSession = this.OpenSQLSession()) {
					//get the plan
					marketingTerritories = (from mt in sqlSession.Query<DWXF108>()
											select mt.MKTTER).Distinct().ToList();
				}
			} catch (Exception ex) {
				Logger.Log("GetMarketingTerritories- error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return marketingTerritories;
		}


		public int AddPlanToMarketingTerritory(
			MarketingTerritoryAssignment marketingTerritoryAssignment,
			int planId)
		{
			try {
				//save the parent   
				using (var sqlSession = this.OpenSQLSession()) {
					marketingTerritoryAssignment.PlanInformation.Id = planId;
					sqlSession.SaveOrUpdate(marketingTerritoryAssignment);
				}
			} catch (Exception ex) {
				Logger.Log("PMarketingTerritoryAssignment - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return marketingTerritoryAssignment.Id;
		}


		public MarketingTerritoryAssignment UpdatePlanForMarketingTerritory(
			MarketingTerritoryAssignmentDTO marketingTerritoryAssignment)
		{
			MarketingTerritoryAssignment marketingTerritoryAssignmentExisting = null;
			try {
				using (var sqlSession = this.OpenSQLSession()) {
					//get the plan
					marketingTerritoryAssignmentExisting = (from mktplan in sqlSession.Query<MarketingTerritoryAssignment>()
															where mktplan.Id == marketingTerritoryAssignment.Id
															select mktplan).FirstOrDefault();
					if (marketingTerritoryAssignmentExisting != null) {
						marketingTerritoryAssignmentExisting.EffectiveYear = marketingTerritoryAssignment.EffectiveYear;
						marketingTerritoryAssignmentExisting.MarketingTerritory = marketingTerritoryAssignment.MarketingTerritory;                        //update
						marketingTerritoryAssignmentExisting.IncludePersonalLines = marketingTerritoryAssignment.IncludePersonalLines;
						marketingTerritoryAssignmentExisting.PlanInformation =
							(from p in sqlSession.Query<PlanInformation>()
							 where p.Id == marketingTerritoryAssignment.PlanInformationId
							 select p).FirstOrDefault();
						//insert
						using (var transaction = sqlSession.BeginTransaction()) {
							sqlSession.SaveOrUpdate(marketingTerritoryAssignmentExisting);
							transaction.Commit();
						}
					}
				}
			} catch (Exception ex) {
				Logger.Log("MarketingTerritoryAssignment- error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return marketingTerritoryAssignmentExisting;
		}


		public List<MarketingTerritoryAssignment> GetAllMarketingTerrByPlanId(
			int planId)
		{
			List<MarketingTerritoryAssignment> marketingTerritoryAssignmentExistingList = new List<MarketingTerritoryAssignment>();
			try {
				using (var sqlSession = this.OpenSQLSession()) {
					//get the plan
					marketingTerritoryAssignmentExistingList = (from mktplan in sqlSession.Query<MarketingTerritoryAssignment>()
																 .Fetch(pm => pm.PlanInformation)
																where mktplan.PlanInformation.Id == planId
																select mktplan).ToList();
				}
			} catch (Exception ex) {
				Logger.Log("GetAllMarketingTerrByPlanId- error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return marketingTerritoryAssignmentExistingList;
		}


		public List<MarketingTerritoryAssignment> GetAllMarketingTerrByYear(
			int year)
		{
			List<MarketingTerritoryAssignment> marketingTerritoryAssignmentExistingList = new List<MarketingTerritoryAssignment>();
			try {
				using (var sqlSession = this.OpenSQLSession()) {
					//get the plan
					marketingTerritoryAssignmentExistingList = (from mktplan in sqlSession.Query<MarketingTerritoryAssignment>()
																 .Fetch(pm => pm.PlanInformation)
																where mktplan.EffectiveYear == year
																select mktplan).ToList();
				}
			} catch (Exception ex) {
				Logger.Log("GetAllMarketingTerrByPlanId- error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return marketingTerritoryAssignmentExistingList;
		}


		public List<AddendumAGrowthPercentage> GetAllAddAGrowthPercentagesByPlanId(
			int planId)
		{
			List<AddendumAGrowthPercentage> addendumAGrowthPercentageList = null;
			try {
				using (var sqlSession = this.OpenSQLSession()) {
					//get the plan
					addendumAGrowthPercentageList = (from mt in sqlSession.Query<AddendumAGrowthPercentage>()
														 // where mt.PlanInformation.Id == planId
													 select mt).ToList();

				}
			} catch (Exception ex) {
				Logger.Log("GetAllAddAGrowthPercentagesByPlanId- error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return addendumAGrowthPercentageList;
		}


		public int AddAddAGrowthPerentageToPlan(
			AddendumAGrowthPercentage addendumAGrowthPercentage)
		{
			try {
				//save the parent   
				using (var sqlSession = this.OpenSQLSession()) {
					//  addendumAGrowthPercentage.PlanInformation.Id = planId;
					sqlSession.SaveOrUpdate(addendumAGrowthPercentage);
				}
			} catch (Exception ex) {
				Logger.Log("AddAddAGrowthPerentageToPlan - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return addendumAGrowthPercentage.Id;
		}


		public int UpdateAddAGrowthPercentage(
			AddendumAGrowthPercentage addendumAGrowthPercentage)
		{
			AddendumAGrowthPercentage addendumAGrowthPercentageExisting = null;
			try {
				using (var sqlSession = this.OpenSQLSession()) {
					//get the plan
					addendumAGrowthPercentageExisting = (from addA in sqlSession.Query<AddendumAGrowthPercentage>()
														 where addA.Id == addendumAGrowthPercentage.Id
														 select addA).FirstOrDefault();
					if (addendumAGrowthPercentageExisting != null) {
						addendumAGrowthPercentageExisting.EndYear = addendumAGrowthPercentage.EndYear;
						addendumAGrowthPercentageExisting.StartYear = addendumAGrowthPercentage.StartYear;
						addendumAGrowthPercentageExisting.Value = addendumAGrowthPercentage.Value;
						//insert
						using (var transaction = sqlSession.BeginTransaction()) {
							sqlSession.SaveOrUpdate(addendumAGrowthPercentageExisting);
							transaction.Commit();
						}//update

					}
				}
			} catch (Exception ex) {
				Logger.Log("MarketingTerritoryAssignment- error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return addendumAGrowthPercentageExisting.Id;
		}


		public List<AddendumAGrowthPercentage> GetAllAddendumAGrowthPercentage()
		{
			List<AddendumAGrowthPercentage> addendumAGrowthPercentages = new List<AddendumAGrowthPercentage>();
			try {
				using (var sqlSession = this.OpenSQLSession()) {
					//get the plan
					addendumAGrowthPercentages = (from addA in sqlSession.Query<AddendumAGrowthPercentage>()
													  // .Fetch(addA=>addA.PlanInformation)
												  select addA).ToList();

				}
			} catch (Exception ex) {
				Logger.Log("MarketingTerritoryAssignment- error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return addendumAGrowthPercentages;
		}


		public List<string> GetAllProducts()
		{
			List<string> products = new List<string>();
			try {
				using (var sqlSession = this.OpenSQLSession()) {

					products = (from p in sqlSession.Query<DWXM00101M>()
								select p.PROD).Distinct<string>().ToList();

				}
			} catch (Exception ex) {
				Logger.Log("GetAllProducts- error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return products;
		}


		public List<Product> GetAllProductsForAllYears()
		{
			List<Product> products = new List<Product>();
			try {
				using (var sqlSession = this.OpenSQLSession()) {

					products = (from p in sqlSession.Query<Product>()
								select p).Distinct<Product>().ToList();

				}
			} catch (Exception ex) {
				Logger.Log("GetAllProducts- error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return products;
		}


		public List<Product> GetAllProductsByYear(
			int year)
		{
			List<Product> products = new List<Product>();
			try {
				using (var sqlSession = this.OpenSQLSession()) {

					products = (from p in sqlSession.Query<Product>()
								where p.Year == year
								select p).Distinct<Product>().ToList();

				}
			} catch (Exception ex) {
				Logger.Log("GetAllProducts- error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return products;
		}


		public List<int> GetAllYears()
		{
			List<int> products = new List<int>();
			try {
				using (var sqlSession = this.OpenSQLSession()) {

					products = (from p in sqlSession.Query<Product>()
								select p.Year).Distinct<int>().ToList();

				}
			} catch (Exception ex) {
				Logger.Log("GetAllProducts- error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return products;
		}


		public int AddProduct(
			Product product)
		{
			Product productExisting = null;
			try {
				//save the parent   
				using (var sqlSession = this.OpenSQLSession()) {
					//get the plan
					productExisting = (from p in sqlSession.Query<Product>()
									   where p.ProductName.Trim().ToLower() == product.ProductName.ToLower().Trim()
									   && p.Year == product.Year
									   select p).FirstOrDefault();
					if (productExisting == null) {
						//insert
						using (var transaction = sqlSession.BeginTransaction()) {
							sqlSession.SaveOrUpdate(product);
							transaction.Commit();
						}
					}
				}
			} catch (Exception ex) {
				Logger.Log("AddProduct - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return product.Id;
		}


		public int UpdateProduct(
			Product product)
		{
			Product productExisting = null;
			try {
				using (var sqlSession = this.OpenSQLSession()) {
					//get the plan
					productExisting = (from p in sqlSession.Query<Product>()
									   where p.Id == product.Id
									   select p).FirstOrDefault();
					if (productExisting != null) {
						productExisting.Included = product.Included;
						productExisting.Year = product.Year;
						//update
						//update
						using (var transaction = sqlSession.BeginTransaction()) {
							sqlSession.SaveOrUpdate(productExisting);
							transaction.Commit();
						}

					}
				}
			} catch (Exception ex) {
				Logger.Log("UpdateProduct- error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return productExisting.Id;
		}


		public List<AddendumA> SaveAddendumA(
			AddendumADTO addendumA)
		{
			List<AddendumA> addendumAs = new List<AddendumA>();

			try {
				using (var sqlSession = this.OpenSQLSession()) {
					using (var transaction = sqlSession.BeginTransaction()) {
						try {
									//  save the master agent's addendum A record
							addendumAs.Add(SaveSingleAddendumA(addendumA, sqlSession));

									//  get the agent's subagents
							SearchResult<AgentMaster> subs = GetSubAgents(addendumA.AgentCode, addendumA.Year);
							if ((subs.Items != null) && (subs.Items.Length > 0)) {
										//  make a copy of the given addendum A to use for subagents
								AddendumADTO subAddA = addendumA.ShallowCopy();

								foreach (AgentMaster sub in subs.Items) {
											//  skip if the agent ID has already been processed
									if (!addendumAs.Any(a => a.AgentCode == sub.AgentId)) {
										subAddA.AgentCode = sub.AgentId;
												//  save the subagent addendum A record
										addendumAs.Add(SaveSingleAddendumA(subAddA, sqlSession));
									}
								}
							}
						} catch (Exception e) {
							transaction.Rollback();
							addendumAs.Clear();
							throw;
						}

						transaction.Commit();
					}
				}
			} catch (Exception e) {
				Logger.Log("Error in SaveAddendumA", Logger.LogLevel.ERROR, e);
				throw;
			}

			return addendumAs;
		}


		protected AddendumA SaveSingleAddendumA(
			AddendumADTO addendumA,
			ISession sqlSession)
		{

			try {
				AddendumA addA = new AddendumA {
					AgentCode = addendumA.AgentCode,
					Year = addendumA.Year,
					IsEnabled = addendumA.IsEnabled,
					MinPremium = addendumA.MinPremium,
					PremiumTable = null // GetGrowthFactor(addendumA.PremiumTable)
				};

						//  if enabling, add/update record for agent/year
				if (addendumA.IsEnabled) {
							//  see if there is an entry for the agent/year
					AddendumA existing = (from aa in sqlSession.Query<AddendumA>()
					where aa.AgentCode.ToLower().Trim() == addendumA.AgentCode.ToLower().Trim() && aa.Year == addendumA.Year
					select aa).FirstOrDefault();

							//  if a record already exists for the agent/year update that record's info for SaveOrUpdate
					if (existing != null) {
						addA = existing;
						addA.IsEnabled = addendumA.IsEnabled;
						addA.MinPremium = addendumA.MinPremium;
					}

							//  add/update the record
					sqlSession.SaveOrUpdate(addA);

						//  if disabling, delete record for agent/year
				} else {
					int cnt = sqlSession.Delete(string.Format("from AddendumA a where a.AgentCode = ? and Year = {0}", addendumA.Year), addendumA.AgentCode, NHibernateUtil.String);
				}

				return addA;
			} catch (Exception e) {
				Logger.Log("Error in SaveSingleAddendumA", Logger.LogLevel.ERROR, e);
				throw;
			}
		}


		public List<Addendumc> SaveAddendumC(
			Addendumc addendumC)
		{
			List<Addendumc> addendumCs = new List<Addendumc>();

			try {
				using (var sqlSession = this.OpenSQLSession()) {
					using (var transaction = sqlSession.BeginTransaction()) {
						try {
									//  save the master agent's addendum C record
							addendumCs.Add(SaveSingleAddendumC(addendumC, sqlSession));

									//  get the agent's subagents
							SearchResult<AgentMaster> subs = GetSubAgents(addendumC.AgentId, addendumC.Year);
							if ((subs.Items != null) && (subs.Items.Length > 0)) {
										//  make a copy of the given addendum C to use for subagents
								Addendumc subAddC = addendumC.ShallowCopy();

								foreach (AgentMaster sub in subs.Items) {
											//  skip if the agent ID has already been processed
									if (!addendumCs.Any(a => a.AgentId == sub.AgentId)) {
										subAddC.AgentId = sub.AgentId;
												//  save the subagent addendum C record
										addendumCs.Add(SaveSingleAddendumC(subAddC, sqlSession));
									}
								}
							}
						} catch (Exception e) {
							transaction.Rollback();
							addendumCs.Clear();
							throw;
						}

						transaction.Commit();
					}
				}
			} catch (Exception e) {
				Logger.Log("Error in SaveAddendumC", Logger.LogLevel.ERROR, e);
				throw;
			}

			return addendumCs;
		}


		protected Addendumc SaveSingleAddendumC(
			Addendumc addendumC,
			ISession sqlSession)
		{

			try {
				Addendumc addC = new Addendumc {
					AgentId = addendumC.AgentId,
					Year = addendumC.Year,
					IsEnabled = addendumC.IsEnabled
				};

						//  if enabling, add/update record for agent/year
				if (addendumC.IsEnabled) {
							//  see if there is an entry for the agent/year
					Addendumc existing = (from ac in sqlSession.Query<Addendumc>()
										  where ac.AgentId.ToLower().Trim() == addendumC.AgentId.ToLower().Trim() && ac.Year == addendumC.Year
										  select ac).FirstOrDefault();

							//  if a record already exists for the agent/year update that record's info for SaveOrUpdate
					if (existing != null) {
						addC = existing;
						addC.IsEnabled = addendumC.IsEnabled;
					}

							//  add/update the record
					sqlSession.SaveOrUpdate(addC);

						//  if disabling, delete record for agent/year
				} else {
					int cnt = sqlSession.Delete(string.Format("from Addendumc a where a.AgentId = ? and Year = {0}", addendumC.Year), addendumC.AgentId, NHibernateUtil.String);
				}

				return addC;
			} catch (Exception e) {
				Logger.Log("Error in SaveSingleAddendumC", Logger.LogLevel.ERROR, e);
				throw;
			}
		}


		public int AddAddendumA(
			AddendumADTO addendumA)
		{
			List<string> addendumas = new List<string>();
			AddendumA addendumAToReturn = new AddendumA();

			try {
				//save the parent
				using (var sqlSession = this.OpenSQLSession()) {
					if (this.HasSubAgents(addendumA.AgentCode.Trim())) {
						addendumas = (
								from agentms in sqlSession.Query<DWXF007>()
								where agentms.AGYCDE.Trim().ToLower() == addendumA.AgentCode.Trim().ToLower()
								select agentms.CDKEY2).ToList();
					}

					sqlSession.SaveOrUpdate(new AddendumA {
						AgentCode = addendumA.AgentCode,
						Year = DateTime.Now.Year,
						IsEnabled = addendumA.IsEnabled,
						MinPremium = addendumA.MinPremium,
						PremiumTable = GetGrowthFactor(addendumA.PremiumTable)
					});
				}
				//save sub agents
				foreach (string agentId in addendumas.Distinct()) {
					using (var sqlSession = this.OpenSQLSession()) {
						sqlSession.SaveOrUpdate(new AddendumA {
							AgentCode = agentId,
							Year = DateTime.Now.Year,
							IsEnabled = addendumA.IsEnabled,
							MinPremium = addendumA.MinPremium,
							PremiumTable = GetGrowthFactor(addendumA.PremiumTable)
						});
					}
				}
			} catch (Exception ex) {
				Logger.Log("DWXF108 - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);

			}

			return addendumA.Id;
		}


		public AddendumADTO[] AddBulkAddendumA(
			AddendumADTO[] addendumA)
		{

			try {
				//save the parent   
				using (var sqlSession = this.OpenSQLSession()) {
					foreach (AddendumADTO addendum in addendumA) {
						sqlSession.SaveOrUpdate(new AddendumA {
							AgentCode = addendum.AgentCode,
							Year = DateTime.Now.Year,
							IsEnabled = addendum.IsEnabled,
							MinPremium = addendum.MinPremium,
							PremiumTable = GetGrowthFactor(addendum.PremiumTable)
						});
					}
				}
			} catch (Exception ex) {
				Logger.Log("AddBulkAddendumA - error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return addendumA;
		}


		public AddendumA UpdateAddendumA(
			AddendumADTO addendumA)
		{
			List<string> addendumas = new List<string>();
			AddendumA addendumAExisting = null;
			try {
				using (var sqlSession = this.OpenSQLSession()) {
					//get the plan
					addendumAExisting = (from p in sqlSession.Query<AddendumA>()
										 where p.AgentCode.ToLower().Trim() == addendumA.AgentCode.ToLower().Trim()
										 select p).FirstOrDefault();
					if (addendumAExisting != null) {
						addendumAExisting.IsEnabled = addendumA.IsEnabled;
						addendumAExisting.Year = addendumA.Year;
						addendumAExisting.MinPremium = addendumA.MinPremium;
						addendumAExisting.PremiumTable = sqlSession.Query<ProfitGrowthFactors>().Where(tbl => tbl.Id == addendumA.PremiumTable).FirstOrDefault();
						addendumAExisting.AgentCode = addendumA.AgentCode;
						//update
						//update
						using (var transaction = sqlSession.BeginTransaction()) {
							sqlSession.SaveOrUpdate(addendumAExisting);
							transaction.Commit();
						}

					}
				}
				using (var sqlSession = this.OpenSQLSession()) {
					if (this.HasSubAgents(addendumA.AgentCode.Trim())) {
						addendumas = (
								from agentms in sqlSession.Query<DWXF007>()
								where agentms.AGYCDE.Trim().ToLower() == addendumA.AgentCode.Trim().ToLower()
								select agentms.CDKEY2).ToList();
					}
					//save sub agents
					foreach (string agentId in addendumas.Distinct()) {
						addendumAExisting = (from p in sqlSession.Query<AddendumA>()
											 where p.AgentCode.ToLower().Trim() == agentId.ToLower().Trim()
											 select p).FirstOrDefault();

						addendumAExisting.IsEnabled = addendumA.IsEnabled;
						addendumAExisting.Year = addendumA.Year;
						addendumAExisting.MinPremium = addendumA.MinPremium;
						addendumAExisting.PremiumTable = sqlSession.Query<ProfitGrowthFactors>().Where(tbl => tbl.Id == addendumA.PremiumTable).FirstOrDefault();
						//update
						//update
						using (var transaction = sqlSession.BeginTransaction()) {
							sqlSession.SaveOrUpdate(addendumAExisting);
							transaction.Commit();
						}

					}
				}
			} catch (Exception ex) {
				Logger.Log("UpdateProduct- error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return addendumAExisting;
		}


		public List<AddendumA> GetAll()
		{
			List<AddendumA> addendumAs = new List<AddendumA>();
			try {
				using (var sqlSession = this.OpenSQLSession()) {
					//get the plan
					addendumAs = (from p in sqlSession.Query<AddendumA>()
							.Fetch(p => p.PremiumTable)
							select p).ToList();
				}
			} catch (Exception ex) {
				Logger.Log("GetAll- error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return addendumAs;
		}


		public List<AddendumA> GetAddendumAByAgentCode(
			string agentCode)
		{
			List<AddendumA> addendumAs = new List<AddendumA>();
			try {
				using (var sqlSession = this.OpenSQLSession()) {
					//get the plan
					addendumAs = (from p in sqlSession.Query<AddendumA>()
							.Fetch(p => p.PremiumTable)
							where p.AgentCode.ToLower().Trim() == agentCode.ToLower().Trim()
							select p).ToList();
				}
			} catch (Exception ex) {
				Logger.Log("GetAddendumAByAgentCode- error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return addendumAs;
		}


		public AddendumA UpdateAddendumAByAgentCode(
			AddendumADTO addendumADTO)
		{
			AddendumA addendumA = new AddendumA();
			try {
				using (var sqlSession = this.OpenSQLSession()) {
					//get the plan
					addendumA = (from p in sqlSession.Query<AddendumA>()
								  .Fetch(p => p.PremiumTable)
								 where p.AgentCode.ToLower().Trim() == addendumADTO.AgentCode.ToLower().Trim()
								 && p.Year == addendumADTO.Year
								 select p).FirstOrDefault();
					if (addendumA != null) {
						addendumA.MinPremium = addendumADTO.MinPremium;
						addendumA.IsEnabled = addendumADTO.IsEnabled;
						addendumA.PremiumTable = GetGrowthFactor(addendumADTO.PremiumTable);
						using (var transaction = sqlSession.BeginTransaction()) {
							sqlSession.SaveOrUpdate(addendumA);
							transaction.Commit();
						}
					}
				}
			} catch (Exception ex) {
				Logger.Log("GetAddendumAByAgentCode- error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return addendumA;
		}

		//Redundant code don't need since new controller
		//public byte[] ProfitSharingReportTopAsCsv(
		//	string[] agentIds,
		//	int year,
		//	int month)
		//{
		//	//TODO: RRF - REMOVE HARD CODE FOR INCLUD SUB-AGENTS AND ADD PARAMETER
		//	return GenerateProfitSharingReport(agentIds, year, month, false,0, "Profit Sharing Top", "CSV");
		//}


		//public byte[] ProfitSharingReportAsPdf(
		//	string[] agentIds,
		//	int year,
		//	int month,
		//	bool includeBottom,
		//	int includeSubAgents)
		//{
		//	return GenerateProfitSharingReport(agentIds, year, month, includeBottom, includeSubAgents, "Profit Sharing Master", "PDF");
		//}


		//public byte[] ProfitSharingReportAsExcel(
		//	string[] agentIds,
		//	int year,
		//	int month,
		//	bool includeBottom,
		//	int includeSubAgents)
		//{
		//	return GenerateProfitSharingReport(agentIds, year, month, includeBottom, includeSubAgents, "Profit Sharing Master", "EXCEL");
		//}


		public byte[] GenerateProfitSharingReport(
			string agentIds,
			int year,
			int month,
			bool includeBottom,
			int includeSubAgents,
			string orderBy,
			string reportName,
			string format)
		{

			try {
                ReportViewer rv = new ReportViewer { ProcessingMode = ProcessingMode.Remote };
				rv.AsyncRendering = false;
				rv.ServerReport.ReportServerCredentials = new ReportCredentials();
				ServerReport sr = rv.ServerReport;
				sr.ReportServerUrl = new Uri(ConfigurationManager.AppSettings[CONFIG_REPORT_SERVER_URL]);
				sr.ReportPath = Path.Combine(ConfigurationManager.AppSettings[CONFIG_REPORT_PATH], reportName);
				
				List<ReportParameter> paramList = new List<ReportParameter>();
				paramList.Add(new ReportParameter("year", year.ToString()));
				paramList.Add(new ReportParameter("month", month.ToString()));
				paramList.Add(new ReportParameter("orderBy", orderBy.ToString().ToUpper()));
				if (reportName != "Profit Sharing Batch Report_REVISED")
				{
					paramList.Add(new ReportParameter("agent_id", agentIds.Trim().ToString()));
				}

                //paramList.Add(new ReportParameter("agent_id", "[\"" + string.Join("\",\"", agentIds) + "\"]"));
                //paramList.Add(new ReportParameter("as_sub", includeSubAgents.ToString()));
                paramList.Add(new ReportParameter("include_summary", includeBottom.ToString()));
                rv.ServerReport.SetParameters(paramList);

				Warning[] warnings;
				string[] streamIds;
				string mimeType;
				string encoding;
				string extension;
				byte[] report = rv.ServerReport.Render(format, null, out mimeType, out encoding, out extension,
						out streamIds, out warnings);

				//  for debugging - to write out to local file
				//try
				//{
				//	string filePath = Path.Combine(System.Web.HttpContext.Current.Server.MapPath("~/"),
				//			ConfigurationManager.AppSettings["outputFilePath"],
				//			"report." + ReportExtensionMap[format]);
				//	System.IO.File.Delete(filePath);
				//	var file = System.IO.File.OpenWrite(filePath);
				//	file.Write(report, 0, report.Length);
				//	file.Flush();
				//	file.Close();
				//}
				//catch { }

				return report;
			} catch (Exception e) {
				Logger.Log("Error in GenerateProfitSharingReport", Logger.LogLevel.ERROR, e);
				throw;
			}
		}

		public byte[] GenerateProfitSharingCombinedReport(
			string[] agentIds,
			int year,
			int month,
			bool includeBottom,
			int includeSubAgents,
			string reportName,
			string format)
		{

			try
			{
				ReportViewer rv = new ReportViewer { ProcessingMode = ProcessingMode.Remote };
				rv.AsyncRendering = false;
				rv.ServerReport.ReportServerCredentials = new ReportCredentials();
				ServerReport sr = rv.ServerReport;
				sr.ReportServerUrl = new Uri(ConfigurationManager.AppSettings[CONFIG_REPORT_SERVER_URL]);
				sr.ReportPath = Path.Combine(ConfigurationManager.AppSettings[CONFIG_REPORT_PATH], reportName);

				List<ReportParameter> paramList = new List<ReportParameter>();
				paramList.Add(new ReportParameter("year", year.ToString()));
				paramList.Add(new ReportParameter("month", month.ToString()));
				if (reportName != "Profit Sharing Batch Report_REVISED")
				{
					paramList.Add(new ReportParameter("agent_ids_str", "[\"" + string.Join("\",\"", agentIds) + "\"]"));
				}

				//paramList.Add(new ReportParameter("as_sub", includeSubAgents.ToString()));
				paramList.Add(new ReportParameter("include_summary", includeBottom.ToString()));
				rv.ServerReport.SetParameters(paramList);

				Warning[] warnings;
				string[] streamIds;
				string mimeType;
				string encoding;
				string extension;
				byte[] report = rv.ServerReport.Render(format, null, out mimeType, out encoding, out extension,
						out streamIds, out warnings);

				//  for debugging - to write out to local file
				//try
				//{
				//	string filePath = Path.Combine(System.Web.HttpContext.Current.Server.MapPath("~/"),
				//			ConfigurationManager.AppSettings["outputFilePath"],
				//			"report." + ReportExtensionMap[format]);
				//	System.IO.File.Delete(filePath);
				//	var file = System.IO.File.OpenWrite(filePath);
				//	file.Write(report, 0, report.Length);
				//	file.Flush();
				//	file.Close();
				//}
				//catch { }

				return report;
			}
			catch (Exception e)
			{
				Logger.Log("Error in GenerateProfitSharingReport", Logger.LogLevel.ERROR, e);
				throw;
			}
		}

		public async Task<byte[]> ProfitSharingReportAsPdfBulk(
			int year,
			int month,
			bool includeBottom,
			string orderBy)
		{
			try {
				//  collection for individual reports from SSRS, key is agent ID, value id the PDF from SSRS (as buyte[])
				//byte[] retContent = null;

				//  generate a report for each agent ID given and add to collection

				//TODO: RRF - REMOVE HARD CODE FOR INCLUDING SUB-AGENTS AND ADD PARAMETER
				//int includeSub = 0;
                //byte[] report = GenerateProfitSharingReport(new string[] { id }, year, month, includeBottom, 1, "Profit Sharing Master_REVISED", "PDF");
                //byte[] report = includeSub == 0 ? GenerateProfitSharingReport(null, year, month, includeBottom, includeSub, "Profit Sharing Master Rollup_REVISED", "PDF") :
                //GenerateProfitSharingReport(null, year, month, includeBottom, includeSub, "Profit Sharing Master Agent_REVISED", "PDF");

                byte[] report = GenerateProfitSharingReport(String.Empty, year, month, includeBottom, 0, orderBy, "Profit Sharing Batch Report_REVISED", "PDF");

				//reports.Add("00779", report);



                //  package reports in a zip file
                /*if (asZip) {
					using (var compressedFileStream = new MemoryStream()) {
								//  create an archive and store the stream in memory
						using (var archive = new ZipArchive(compressedFileStream, ZipArchiveMode.Create, false)) {

							foreach (KeyValuePair<string, byte[]> rpt in reports) {
										//  create a zip entry for each attachment
								ZipArchiveEntry zipEntry = archive.CreateEntry(rpt.Key + ".pdf");

										//  get the stream of the attachment
								using (var originalFileStream = new MemoryStream(rpt.Value)) {
									using (var zipEntryStream = zipEntry.Open()) {
												//  copy the attachment stream to the zip entry stream
										originalFileStream.CopyTo(zipEntryStream);
									}
								}
							}
						}

						retContent = compressedFileStream.ToArray();

					}

						//  pacckage reports in a single PDF file
				} else {*/
					/*using (PdfDocument pdf = new PdfDocument())
					{
						foreach (KeyValuePair<string, byte[]> rpt in reports)
						{
							using (MemoryStream memStream = new MemoryStream(rpt.Value))
							{
								using (PdfDocument rptDoc = PdfReader.Open(memStream, PdfDocumentOpenMode.Import))
								{
									//									PdfPage page = rptDoc.Pages[0];
									foreach (PdfPage page in rptDoc.Pages)
									{
										pdf.AddPage(page);
									}
								}
							}
						}
						using (MemoryStream stream = new MemoryStream()) {
							pdf.Save(stream, true);
							retContent = stream.ToArray();
						}
					}*/

							//  for debugging - to write out to local file
					//try {
					//	string filePath = Path.Combine(System.Web.HttpContext.Current.Server.MapPath("~/"),
					//			ConfigurationManager.AppSettings["outputFilePath"],
					//			"bulkReport.pdf");
					//	System.IO.File.Delete(filePath);
					//	var file = System.IO.File.OpenWrite(filePath);
					//	file.Write(retContent, 0, retContent.Length);
					//	file.Flush();
					//	file.Close();
					//} catch { }
				//}

				return report;
			} catch (Exception e) {
				Logger.Log("ProfitSharingReportAsPdfBulk- error ", Logger.LogLevel.ERROR, e);
				throw;
			}
		}

        ////TODO : call a different SP
        public IList<ProfitSharingReportDto> ProfitSharingAgentRollupReport(
            string[] agentIds,
            int year,
            int month)
        {

            List<ProfitSharingReportDto> profitSharingReportDTOs = new List<ProfitSharingReportDto>();
            try
            {
				using (var sqlSession = this.OpenSQLSession())
				{
					//  get the query from config
					//string queryStr = ConfigurationManager.AppSettings["profitSharingAgentRollUpQuery"];
					//queryStr = string.Format(queryStr, "\"" + string.Join("\",\"", agentIds) + "\"", year, month);

					//queryStr = string.Format(queryStr, agentIds[0].ToString(), year, month);
					string queryStr = "";
					var q = sqlSession.CreateSQLQuery("select * from TAB_ANALYSIS where MONTH = :month and YEAR = :year AND CDKEY2 = :agentIds");
					if(agentIds.Length > 1)
                    {
						queryStr = ConfigurationManager.AppSettings["profitSharingCombinedReportQuery"];
						queryStr = string.Format(queryStr, "\"" + string.Join("\",\"", agentIds) + "\"", year, month);
						q = sqlSession.CreateSQLQuery(queryStr);

					}
					else
                    {
						q = sqlSession.CreateSQLQuery("select * from TAB_ANALYSIS where MONTH = :month and YEAR = :year AND CDKEY2 = :agentIds");
						q.SetParameter("month", month);
						q.SetParameter("year", year);
						q.SetParameter("agentIds", agentIds[0].ToString());
					}
					q.SetTimeout(300);

					var result = q.DynamicList();

					if (result.Count > 0)
					{
						ProfitSharingReportDto dto = new ProfitSharingReportDto();
						
						for (int i = 0; i < result.Count; i++)
						{
							dto.EarnedPremiums += result[i].ActualEarnedPremium ?? 0m;
							dto.GrowthRate += result[i].GrowthRate ?? 0m;// question ,should we multiply by 100?
							dto.LossRatio += result[i].LossRatio ?? 0m;
							dto.NineMonthLossLock += result[i].NineMonthLock ?? 0m;
							dto.PremiumGrowthFactor += result[i].PGF_Factor ?? 0m;
							dto.PremiumVolumeAndLossRatioFactor += result[i].PVLR_Factor ?? 0m;
							dto.PreviousYearNetAdjustedWrittenPremiums += result[i].PreviousYearNetAdjustedWrittenPremium ?? 0m;
							dto.ProfitSharingPayment += result[i].PAYMENT ?? 0m;
							dto.ThreeYearProfitability += result[i].SUM_THREE_YR_PROFITABILITY ?? 0m;
							dto.ThreeYearProfitabilityFactor += result[i].TYP_Factor ?? 0m;
							dto.WrittenPremiumVolume += result[i].ProjectedWrittenPremium ?? 0m;
							dto.NetAdjustedPremiums += result[i].NetAdjustedPremiums;
                            ////  build DTO object
                            //ProfitSharingReportDto dto = new ProfitSharingReportDto
                            //{
                            //	EarnedPremiums = result[0].ActualEarnedPremium ?? 0m,
                            //	GrowthRate = result[0].GrowthRate ?? 0m,// question ,should we multiply by 100?
                            //	LossRatio = result[0].LossRatio ?? 0m,
                            //	NineMonthLossLock = result[0].NineMonthLock ?? 0m,
                            //	PremiumGrowthFactor = result[0].PGF_Factor ?? 0m,
                            //	PremiumVolumeAndLossRatioFactor = result[0].PVLR_Factor ?? 0m,
                            //	PreviousYearNetAdjustedWrittenPremiums = result[0].PreviousYearNetAdjustedWrittenPremium ?? 0m,
                            //	ProfitSharingPayment = result[0].PAYMENT ?? 0m,
                            //	ThreeYearProfitability = result[0].SUM_THREE_YR_PROFITABILITY ?? 0m,
                            //	ThreeYearProfitabilityFactor = result[0].TYP_Factor ?? 0m,
                            //	WrittenPremiumVolume = result[0].ProjectedWrittenPremium ?? 0m,
                            //	NetAdjustedPremiums = result[0].NetAdjustedPremiums
                            //};
                        }

						//  add results to return collection
						profitSharingReportDTOs.Add(dto);

					}

				}

            }
            catch (Exception ex)
            {
                Logger.Log("ProfitSharingReportTop- error ", Logger.LogLevel.ERROR, ex);
                throw;
            }

            return profitSharingReportDTOs;
            //return null;
        }

		public IList<SubAgent> ProfitSharingGetSubAgents(
			string[] agentIds
			)
		{

			List<SubAgent> subAgent = new List<SubAgent>();
			try
			{
				using (var sqlSession = this.OpenSQLSession())
				{
					//  get the query from config
					string queryStr = ConfigurationManager.AppSettings["profitSharingSubAgentQuery"];

					//queryStr = string.Format(queryStr, "\"" + string.Join("\",\"", agentIds) + "\"");
					queryStr = string.Format(queryStr, agentIds);

					var q = sqlSession.CreateSQLQuery(queryStr);
					q.SetTimeout(300);

					var result = q.List();

					if (result.Count > 0)
					{
						foreach (object[] o in result)
                        {
							subAgent.Add(new SubAgent
							{

								AgentId = (string)o[0],
								MasterAgentId = (string)o[1],
								Name = (string)o[2]

							});
						}

					}
				}

			}
			catch (Exception ex)
			{
				Logger.Log("ProfitSharingSubAgent- error ", Logger.LogLevel.ERROR, ex);
				throw;
			}

			return subAgent;
		
		}


		private List<ProfitSharingReportTopDto> MasterAgentProfitSharingReportTop(
			string[] agentIds,
			int year,
			int month,
			bool asSub = false
			)
		{
			throw new NotImplementedException();
		}

		public List<ProfitSharingReportDto> ProfitSharingAgentOnlyReport(
			string[] agentIds,
			int year,
			int month)
		{
			List<ProfitSharingReportDto> profitSharingReportDTOs = new List<ProfitSharingReportDto>();

			try {
				using (var sqlSession = this.OpenSQLSession()) {
							//  get the query from config
					//string queryStr = ConfigurationManager.AppSettings["profitSharingAgentOnlyQuery"];
					//queryStr = string.Format(queryStr, "\"" + string.Join("\",\"", agentIds) + "\"", year, month);

					var q = sqlSession.CreateSQLQuery("select * from TAB_ANALYSIS_AGENT_ONLY where MONTH = :month and YEAR = :year AND CDKEY2 = :agentIds");
					q.SetParameter("month", month);
					q.SetParameter("year", year);
					//q.SetParameter("agentIds", "\"" + string.Join("\",\"", agentIds) + "\"");

					q.SetParameter("agentIds", agentIds[0].ToString());
					q.SetTimeout(300);
					
					var result = q.DynamicList();
					ProfitSharingReportDto dto = new ProfitSharingReportDto();

					if (result.Count > 0) {
						for (int i = 0; i < result.Count; i++)
						{
							dto.EarnedPremiums += result[i].ActualEarnedPremium ?? 0m;
							dto.GrowthRate += result[i].GrowthRate ?? 0m;// question ,should we multiply by 100?
							dto.LossRatio += result[i].LossRatio ?? 0m;
							dto.NineMonthLossLock += result[i].NineMonthLock ?? 0m;
							dto.PremiumGrowthFactor += result[i].PGF_Factor ?? 0m;
							dto.PremiumVolumeAndLossRatioFactor += result[i].PVLR_Factor ?? 0m;
							dto.PreviousYearNetAdjustedWrittenPremiums += result[i].PreviousYearNetAdjustedWrittenPremium ?? 0m;
							dto.ProfitSharingPayment += result[i].PAYMENT ?? 0m;
							dto.ThreeYearProfitability += result[i].SUM_THREE_YR_PROFITABILITY ?? 0m;
							dto.ThreeYearProfitabilityFactor += result[i].TYP_Factor ?? 0m;
							dto.WrittenPremiumVolume += result[i].ProjectedWrittenPremium ?? 0m;
							dto.NetAdjustedPremiums += result[i].NetAdjustedPremiums;
							//  build DTO object NetAdjustedPremiums 
							//ProfitSharingReportDto dto = new ProfitSharingReportDto {
							//EarnedPremiums = result[0].ActualEarnedPremium ?? 0m,
							//GrowthRate = result[0].GrowthRate ?? 0m,// question ,should we multiply by 100?
							//LossRatio = result[0].LossRatio ?? 0m,
							//NineMonthLossLock = result[0].NineMonthLock ?? 0m,
							//PremiumGrowthFactor = result[0].PGF_Factor ?? 0m,
							//PremiumVolumeAndLossRatioFactor = result[0].PVLR_Factor ?? 0m,
							//PreviousYearNetAdjustedWrittenPremiums = result[0].PAYMENT ?? 0m,//this is miising
							//ProfitSharingPayment = result[0].PAYMENT ?? 0m,
							//ThreeYearProfitability = result[0].SUM_THREE_YR_PROFITABILITY ?? 0m,
							//ThreeYearProfitabilityFactor = result[0].TYP_Factor ?? 0m,
							//WrittenPremiumVolume = result[0].ProjectedWrittenPremium ?? 0m,
							//NetAdjustedPremiums = result[0].NetAdjustedPremiums
						};

								//  add results to return collection
						profitSharingReportDTOs.Add(dto);
					}
				}
			} catch (Exception ex) {
				Logger.Log("ProfitSharingReportBottom- error " + ex.Message, Logger.LogLevel.ERROR, ex);
				throw;
			}

			return profitSharingReportDTOs;
		}


		public byte[] ProfitSharingCustomReport(
			int year,
			int month,
			MIG.WEB.API.Controllers.CustomReportFields fields,
			MIG.WEB.API.Controllers.CustomReportSort sort,
			bool includeNonPaymentAgents)
		{
			try {
				ReportViewer rv = new ReportViewer { ProcessingMode = ProcessingMode.Remote };
				rv.AsyncRendering = false;

				//IReportServerCredentials irsc = new MyCustomeReportCredentials();
				rv.ServerReport.ReportServerCredentials = new ReportCredentials();
				

				ServerReport sr = rv.ServerReport;
				sr.ReportServerUrl = new Uri(ConfigurationManager.AppSettings[CONFIG_REPORT_SERVER_URL]);
				sr.ReportPath = Path.Combine(ConfigurationManager.AppSettings[CONFIG_REPORT_PATH], "Custom Report");
				
				sr.Timeout = 30 * MS_IN_MINUTE;

						//  get array of field names from bit flags
				string[] fieldAry = Enum.GetValues(typeof(MIG.WEB.API.Controllers.CustomReportFields))
						.Cast<MIG.WEB.API.Controllers.CustomReportFields>()
						.Where(v => (v & fields) > 0)
						.Select(v => v.ToString())
						.ToArray();

				List<ReportParameter> paramList = new List<ReportParameter>();
				paramList.Add(new ReportParameter("year", year.ToString()));
				paramList.Add(new ReportParameter("month", month.ToString()));
				paramList.Add(new ReportParameter("minPayment", includeNonPaymentAgents ? "0" : "1"));
				paramList.Add(new ReportParameter("fields", fieldAry));

				string sortField = "CDKEY2";
				switch (sort) {
					case Controllers.CustomReportSort.Region:
						sortField = "REGOFC";
						break;
					case Controllers.CustomReportSort.Territory:
						sortField = "MKTTER";
						break;
				}
				paramList.Add(new ReportParameter("sortField", sortField));

				rv.ServerReport.SetParameters(paramList);

				Warning[] warnings;
				string[] streamIds;
				string mimeType;
				string encoding;
				string extension;
				byte[] report = rv.ServerReport.Render("EXCEL", null, out mimeType, out encoding, out extension,
						out streamIds, out warnings);

				//try {
				//			// for testing - to save a copy of the file
				//	string filePath = Path.Combine(System.Web.HttpContext.Current.Server.MapPath("~/"),
				//			ConfigurationManager.AppSettings["outputFilePath"],
				//			"custom report." + ReportExtensionMap["EXCEL"]);
				//	System.IO.File.Delete(filePath);
				//	var file = System.IO.File.OpenWrite(filePath);
				//	file.Write(report, 0, report.Length);
				//	file.Flush();
				//	file.Close();
				//} catch { }

				return report;
			} catch (Exception ex) {
				Logger.Log("ProfitSharingCustomReport- error " + ex.Message, Logger.LogLevel.ERROR, ex);
				throw;
			}
		}


        public List<ProfitSharingReportTopDto> ProfitSharingReportByAgentId(
            string agentId,
            decimal period)
        {
            List<ProfitSharingReportTopDto> profitSharingReportDTOs = new List<ProfitSharingReportTopDto>();
            try
            {
                using (var sqlSession = this.OpenSQLSession())
                {
                    //get the plan
            profitSharingReportDTOs = sqlSession.Query<DWXM00101M>()
                    .Where(w => w.ACTDTE.ToString().Trim().Substring(0, 4) == period.ToString() && w.AGENT.ToLower().Trim() == agentId.ToLower().Trim())
                    .GroupBy(g => g.PROD)
                    .Select(s => new ProfitSharingReportTopDto
                    {
                        ProductId = s.Select(x => x.PROD).FirstOrDefault(),
                        AdjustedWrittenPremium = s.Sum(x => x.ADJWRTPREM),
                        ChargeOffsAndWC = s.Sum(x => x.CHGOFFDIVD),
                        NetAdjustedEarnedPremiums = s.Sum(x => x.ADJWRTPREM - x.CHARGEOFFS),
                        AdjustedEarnedPremiums = s.Sum(x => x.ADJEARPREM),
                        NetAdjustedPremiums = s.Sum(x => x.ADJEARPREM - x.CHGOFFDIVD),
                        LossAdjustmentExpense = s.Sum(x => x.INCLOSSSTP - x.INCLOSSACT),
                        IncurredLossesBeforeStopLoss = s.Sum(x => x.INCLOSSSTP),
                        IncurredLossesAfterStopLoss = s.Sum(x => x.INCLOSSACT),
                        LossRatio = GetLossRatio(s.Sum(x => x.ADJEARPREM), s.Sum(x => x.ADJWRTPREM - x.CHARGEOFFS))
                    }).ToList();

                    var query = from p in sqlSession.Query<DWXM00101M>()
                                where p.ACTDTE == period
                                && p.AGENT.ToLower().Trim() == agentId.ToLower().Trim()
                                select p;
                }
            }
            catch (Exception ex)
            {
                Logger.Log("ProfitSharingReportByAgentId- error " + ex.Message, Logger.LogLevel.ERROR, ex);
                throw ex;
            }

            return profitSharingReportDTOs;
        }


        private decimal GetLossRatio(
			decimal adjPrem,
			decimal netAdjPrem)
		{
			if (netAdjPrem == 0) {
				return 0;
			} else {
				return adjPrem / netAdjPrem;
			}
		}


		public List<decimal> GetAllTimePeriods()
		{
			List<decimal> timePeriods = new List<decimal>();
			try {
				using (var sqlSession = this.OpenSQLSession()) {
							//  get the plan
					timePeriods = (from p in sqlSession.Query<DWXM00101M>()
							//where p.MasterAgentId.ToLower().Trim() == addendumADTO.MasterAgentId.ToLower().Trim()                                 
							select p.ACTDTE).Distinct().ToList<Decimal>();
				}
			} catch (Exception ex) {
				Logger.Log("GetAddendumAByAgentCode- error " + ex.Message + " STACK TRACE" + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return timePeriods;
		}


		public Tuple<decimal, decimal> GetWrittenPremiumAndLossRatio(
			int year,
			string agentId)
		{
			decimal netAdjEarned, ratio = 0;
			//  Tuple<decimal, decimal> minPremiumAndRatio = new Tuple<decimal, decimal>(0,0);
			try {
				using (var sqlSession = this.OpenSQLSession()) {
							//get values for  all the years
							//get the plan
					var premium = from d in sqlSession.Query<DWXM00101M>()
							where (d.ACTDTE.ToString().Trim().Substring(0, 4) == year.ToString()
								&& d.AGENT.ToLower().Trim() == agentId.ToLower().Trim()
							)
							select new {
								AdjustedWrittenPremium = d.ADJWRTPREM,
								ChargeOffsAndWC = d.CHGOFFDIVD,
								NetAdjustedEarnedPremiums = d.ADJWRTPREM - d.CHARGEOFFS,
								AdjustedEarnedPremiums = d.ADJEARPREM,
								NetAdjustedPremiums = d.ADJEARPREM - d.CHGOFFDIVD,
								LossAdjustmentExpense = d.INCLOSSSTP - d.INCLOSSACT,
								IncurredLossesBeforeStopLoss = d.INCLOSSSTP,
								IncurredLossesAfterStopLoss = d.INCLOSSACT,
								LossRatio = GetLossRatio((d.ADJEARPREM), (d.ADJWRTPREM - d.CHARGEOFFS))
							};

					netAdjEarned = premium.Select(a => a.NetAdjustedPremiums).Sum();
					try {
						ratio = premium.Select(a => a.LossRatio).Sum();
					} catch (Exception) {
						ratio = 0;
					}
				}
			} catch (Exception ex) {
				Logger.Log("GetAddendumAByAgentCode- error " + ex.Message + " STACK TRACE: " + ex.StackTrace, Logger.LogLevel.ERROR);
				throw ex;
			}

			return new Tuple<decimal, decimal>(netAdjEarned, ratio);
		}


		public void YearEndLock(
			int year)
		{

			try {
				using (var sqlSession = this.OpenSQLSession()) {
							//  check to see if there are any existing records for given year
					int existingCnt = (int)sqlSession.CreateSQLQuery(string.Format("select count(*) from AgentQualification aq where Year = {0}", year)).UniqueResult();

					if (existingCnt > 0) {
						throw new ArgumentException(string.Format("Agent data for {0} already locked.", year));
					}

					var sql = string.Format("insert into AgentQualification (AGENT, AGYCDE, [YEAR], MINPREM, STOPLOSS, LockedAt)"
							+ " select distinct agnt.CDKEY2, agnt.AGYCDE, {0} as 'year', adda.MinPremium, addc.IsEnabled as STOPLOSS, getdate() as 'LockedAt'"
							+ " from DWXF007 agnt"
							+ " left outer join AddendumA adda on adda.AgentCode = agnt.CDKEY2 and adda.Year = {0}"
							+ " left outer join AddendumC addc on addc.AgentId = agnt.CDKEY2 and addc.IsEnabled = 1 and addc.Year = {0}"
							+ " where agnt.AGYCDE != ''", year);

					var insert = sqlSession.CreateSQLQuery(sql);
					insert.ExecuteUpdate();
				}
			} catch (Exception e) {
				Logger.Log("YearEndLock- error " + e.Message + " STACK TRACE: " + e.StackTrace, Logger.LogLevel.ERROR);
				throw;
			}
		}


		private void GetDateRange(
			int month)
		{
			return;
		}
	}

	public class ReportCredentials : IReportServerCredentials
	{
		public WindowsIdentity ImpersonationUser {

				get { return null; }
		}

		public ICredentials NetworkCredentials {
			get {

				#region - comment
				// Read the user information from the Web.config file.  
				// By reading the information on demand instead of 
				// storing it, the credentials will not be stored in 
				// session, reducing the vulnerable surface area to the
				// Web.config file, which can be secured with an ACL.

				// User name
				string userName =
					ConfigurationManager.AppSettings
						["ReportViewerUser"];

				if (string.IsNullOrEmpty(userName))
					throw new Exception(
						"Missing user name from web.config file");

				//// Password
				string password =
					ConfigurationManager.AppSettings
						["ReportViewerPassword"];

				if (string.IsNullOrEmpty(password))
					throw new Exception(
						"Missing password from web.config file");

				//// Domain
				string domain =
					ConfigurationManager.AppSettings
						["ReportViewerDomain"];

				if (string.IsNullOrEmpty(domain))
					throw new Exception(
						"Missing domain from web.config file");

				//string userName = "dykes";
				//string password = "ooY5aXqC";
				//string domain = "MIG";

				//< identity impersonate = "true" userName = "MIG\dykes" password = "ooY5aXqC" /> -->
				#endregion

				//string userName = "PFSDevSvc";
				//string password = "q3qmzYw84mAc";
				//string domain = "MIG";

				return new NetworkCredential(userName, password, domain);
			}
		}

		public bool GetFormsCredentials(out Cookie authCookie, out string userName, out string password, out string authority)
		{
			authCookie = null;
			userName = null;
			password = null;
			authority = null;

			// Not using form credentials
			return false;
		}
	}
}
