﻿using System;

namespace MIG.WEB.API.Models
{
	public class ProfitSharingReporPdfDto
	{
		public byte[] Pdf { get; set; }
	}
}
