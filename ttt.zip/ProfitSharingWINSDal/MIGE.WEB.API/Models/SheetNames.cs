﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MIG.WEB.API.Models
{
    public enum SheetNames
    {
        ThreeYearProfitability = 1,
        PremiumGrowthFactors = 2,
        PremiumVolumeAndLossRatio = 3
    }
}