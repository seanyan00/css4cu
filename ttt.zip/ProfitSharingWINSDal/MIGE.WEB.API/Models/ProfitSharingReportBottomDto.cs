﻿using System;

namespace MIG.WEB.API.Models
{
	public class ProfitSharingReportDto
	{
		public decimal PreviousYearNetAdjustedWrittenPremiums { get; set; }
		public decimal EarnedPremiums { get; set; }
		public decimal LossRatio { get; set; }
		public decimal WrittenPremiumVolume { get; set; }
		public decimal PremiumVolumeAndLossRatioFactor { get; set; }
		public decimal GrowthRate { get; set; }
		public decimal PremiumGrowthFactor { get; set; }
		public decimal NineMonthLossLock { get; set; }
		public decimal ThreeYearProfitability { get; set; }
		public decimal ThreeYearProfitabilityFactor { get; set; }
		public decimal ProfitSharingPayment { get; set; }
		public decimal NetAdjustedPremiums { get; set; }
	}
}
