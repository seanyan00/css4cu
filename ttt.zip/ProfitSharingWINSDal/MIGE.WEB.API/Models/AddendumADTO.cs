﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MIG.WEB.API.Models
{
    public class AddendumADTO
    {
        public virtual int Id { get; set; }
        public virtual string AgentCode { get; set; }
        public virtual int Year { get; set; }
        public virtual decimal MinPremium { get; set; }
        public virtual bool IsEnabled { get; set; }
        public virtual int PremiumTable { get; set; }


		public AddendumADTO ShallowCopy()
		{
			return (AddendumADTO)this.MemberwiseClone();
		}
	}
}
