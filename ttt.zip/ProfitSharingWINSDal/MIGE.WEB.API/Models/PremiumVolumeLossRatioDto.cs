﻿using System;
using MIGE.Core.Domain.SQL.Models;

namespace MIG.WEB.API.Models
{

	public class PremiumVolumeLossRatioDto
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public PremiumVolumeLossRatioValue[] Data { get; set; }
		public int TableNames { get; set; }
		public int TableStatus { get; set; }
	}
}
