﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MIG.WEB.API.Models
{
    public class PlanManagementDTO
    {
        public  int Id { get; set; }
        public int PlanInformationId { get; set; }
        public  int StartYear { get; set; }
        public  int EndYear { get; set; }
        public int ThreeYearProfitabilityId { get; set; }
        public int ProfitGrowthFactorsId { get; set; }
        public int PremiumVolumeLossRatioId { get; set; }
    }
}