﻿namespace MIG.WEB.API.Models
{
    public class SubAgent
    {
        public virtual string AgentId { get; set; }
        public virtual string MasterAgentId { get; set; }
        public virtual string Name { get; set; }

    }
}
