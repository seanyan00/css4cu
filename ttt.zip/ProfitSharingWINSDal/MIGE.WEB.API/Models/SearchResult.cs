﻿using System;

namespace MIG.WEB.API.Models {


	public class SearchResult<T>
	{
		/// <summary>
		/// Gets the total number of items that matched the requested search.
		/// </summary>
		public long TotalMatches { get; protected set; }

		/// <summary>
		/// Gets the number of items returned.
		/// </summary>
		public long NumberReturned { get; protected set; }

		/// <summary>
		/// Gets the record index (zero based), relative to all matches, of the first record returned.
		/// </summary>
		public long FirstItemIndex { get; protected set; }

		/// <summary>
		/// Gets the record index (zero based), relative to all matches, of the last record returned.
		/// </summary>
		public long LastItemIndex { get; protected set; }

		/// <summary>
		/// Gets the number of items remaining from the search beyond the page
		/// of items included here.
		/// </summary>
		public long NumberRemaining { get; protected set; }

		/// <summary>
		/// Gets the filter applied to obtain the results returned.
		/// </summary>
		public object Filter { get; protected set; }

		/// <summary>
		/// Gets the number of the page of paged results.
		/// </summary>
		public int Page { get; protected set; }

		/// <summary>
		/// Gets the size of the current page of results.
		/// </summary>
		public int PageSize { get; protected set; }

		/// <summary>
		/// Gets the total number of pages required for all results.
		/// </summary>
		public int TotalPages { get; protected set; }

		/// <summary>
		/// Gets the items returned in as a result of the search.
		/// </summary>
		public T[] Items {
			get;
			private set;
		}


		public SearchResult(
			T[] items,
			object filter,
			int page,
			int pageSize,
			int totalMatches)
		{
			Items = items;
			Filter = filter;
			Page = page;
			PageSize = pageSize;
			TotalMatches = totalMatches;
			NumberReturned = items.Length;

			CalculatePaging();
		}


		/// <summary>
		/// Calculates the index of the first and last record, the number of records remaining,
		/// and the total number of pages needed to display all records based on the given values
		/// for the data to be paged.
		/// </summary>
		private void CalculatePaging()
		{
					//  calculate the total number of pages required to display all of the records
			if (PageSize > 0) {
				TotalPages = (int)Math.Ceiling(Math.Max((TotalMatches - PageSize) / (double)PageSize, 0) + 1);
			}

					//  calculate the index of the first record on the specified page
			FirstItemIndex = (Page - 1) * PageSize;

					//  calculate the index of the last record on the specified page
			LastItemIndex = Math.Min(TotalMatches, (Page * PageSize)) - 1;

					//  calculate the number of records remaining
			NumberRemaining = Math.Max(0, TotalMatches - LastItemIndex - 1);
		}
	}
}
