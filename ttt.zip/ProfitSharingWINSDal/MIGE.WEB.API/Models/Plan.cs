﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MIG.WEB.API.Models
{
    public class Plan
    {
        public  int PlanId { get; set; }
        public string PlanName { get; set; }
        public int DisablePlan { get; set; }
        public int StartYear { get; set; }
        public  int EndYear { get; set; }  
        public int MinPremium { get; set; }
        public int ThreeYearProfitabilityReferenceId { get; set; }
        public int ProfitGrowthFactorsReferenceId { get; set; }
        public int PremiumVolumeLossRatioReferenceId { get; set; }
    }
}