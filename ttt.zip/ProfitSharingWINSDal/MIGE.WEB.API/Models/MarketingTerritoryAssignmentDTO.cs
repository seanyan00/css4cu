﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MIG.WEB.API.Models
{
    public class MarketingTerritoryAssignmentDTO
    {
        public  int Id { get; set; }
        public  int PlanInformationId { get; set; }
        public  int EffectiveYear { get; set; }
        public  string MarketingTerritory { get; set; }
		public bool IncludePersonalLines { get; set; }
	}
}
