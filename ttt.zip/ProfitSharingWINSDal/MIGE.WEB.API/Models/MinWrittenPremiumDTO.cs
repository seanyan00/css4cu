﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MIG.WEB.API.Models
{
    public class MinWrittenPremiumDTO
    {
        public  int Id { get; set; }
        public  int PlanInformationId { get; set; }
        public  decimal Premium { get; set; }
        public  int StartYear { get; set; }
        public  int EndYear { get; set; }
    }
}