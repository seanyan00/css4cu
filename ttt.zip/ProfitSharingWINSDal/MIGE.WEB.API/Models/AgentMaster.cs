﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MIG.WEB.API.Models
{
    public class AgentMaster
    {
        public virtual string AgentId { get; set; }
        public virtual string MasterAgentId { get; set; }
        public virtual string Address1 { get; set; }
        public virtual string Address2 { get; set; }
        public virtual string City{ get; set; }
        public virtual string State { get; set; }
        public virtual string Zip { get; set; }
        public virtual string SubAgent { get; set; } = string.Empty;
        public virtual string Name { get; set; }
        public virtual string Region { get; set; }
        public virtual string Territory { get; set; }
        public virtual decimal MinPremium { get; set; } = 0;
        public virtual bool AdnA { get; set; } = false;
        public virtual bool AdnC { get; set; } = false;
    }
}
