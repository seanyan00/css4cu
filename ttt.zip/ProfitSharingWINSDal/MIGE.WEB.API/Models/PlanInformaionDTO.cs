﻿using MIGE.Core.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MIG.WEB.API.Models
{
    public class PlanInformaionDTO: PlanInformation
    {
       
        public virtual int StartYear { get; set; }
        public virtual int EndYear { get; set; }
        public virtual decimal MinPremium { get; set; }
        public int ThreeYearProfitabilityReferenceId { get; set; }
        public int ProfitGrowthFactorsReferenceId { get; set; }
        public int PremiumVolumeLossRatioReferenceId { get; set; }
       
    }
}