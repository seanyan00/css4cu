﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace MIG.WEB.API.Models
{
	[DataContract]
	public class ProfitSharingReportTopDto
	{

		//TODO:  ADDED THE FOLLOWING FIELDS

		[DataMember]
		public string AGENT { get; set; }
		[DataMember]
		public string AGYCDE { get; set; }
		[DataMember]
		public string CDDESC { get; set; }
		[DataMember]
		public string AGYNAM { get; set; }
		[DataMember]
		public string AGYAD1 { get; set; }
		[DataMember]
		public string AGYAD2 { get; set; }
		[DataMember]
		public string AGYAD3 { get; set; }
		[DataMember]
		public string AGYCTY	{ get; set; }
		[DataMember]
		public string AGYST { get; set; }
		[DataMember]
		public string AGYZIP { get; set;}
		[DataMember]
		public string MKTTER { get; set; }
		[DataMember]
		public List<string> SUBAGENTS { get; set; }

		[DataMember]
		public string ProductId { get; set; }
		[DataMember]
		public decimal AdjustedWrittenPremium { get; set; }
		[DataMember]
		public decimal ChargeOffsAndWC { get; set; }
		[DataMember]
		public decimal NetAdjustedPremiums { get; set; }
		[DataMember]
		public decimal AdjustedEarnedPremiums { get; set; }
		[DataMember]
		public decimal NetAdjustedEarnedPremiums { get; set; }
		[DataMember]
		public decimal LossAdjustmentExpense { get; set; }
		[DataMember]
		public decimal IncurredLossesBeforeStopLoss { get; set; }
		[DataMember]
		public decimal IncurredLossesAfterStopLoss { get; set; }
		[DataMember]
		public decimal LossRatio { get; set; }
		[DataMember]
		public Int32 subagent_cnt { get; set; }

	    public ProfitSharingReportTopDto()
		{
			this.SUBAGENTS = new List<string>();
		}

	}


}
