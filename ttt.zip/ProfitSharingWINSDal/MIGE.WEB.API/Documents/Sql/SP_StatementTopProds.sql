IF OBJECT_ID ( 'SP_StatementTopProds', 'P' ) IS NOT NULL   
    DROP PROCEDURE SP_StatementTopProds;  
GO
 
CREATE PROCEDURE dbo.SP_StatementTopProds(
	@agent_ids_str nvarchar(max),
	@year int,
	@month int,
	@as_sub int = 0)
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @agent_ids TABLE (Value nvarchar(255))
	insert into @agent_ids select value from openjson(@agent_ids_str);

	with
		year_products as (select * from product where Year = @year
		)
		, sums_cte as (select distinct PROD,
			sum(ADJWRTPREM) as ADJWRTPREM,
			sum(WRITEPREM) as WRITEPREM,
			sum(CHARGEOFFS) as CHARGEOFFS,
			sum(CHGOFFDIVD) as CHGOFFDIVD,
			sum(INCCREDEXP) as INCCREDEXP,
			sum(ADJEARPREM) as ADJEARPREM,
			sum(EARNEDPREM) as EARNEDPREM,
			sum(INCLOSSSTP) as INCLOSSSTP,
			sum(INCLOSSACT) as INCLOSSACT
			from (select
					case when @as_sub = 1 then AGENT else agycde end as AGENT,
					ACTDTE,
					PROD,
					ADJWRTPREM,
					WRITEPREM,
					CHARGEOFFS,
					CHGOFFDIVD,
					case when prod in (select ProductName from year_products) then INCCREDEXP end INCCREDEXP,
					case when prod in (select ProductName from year_products) then ADJEARPREM end ADJEARPREM,
					case when prod in (select ProductName from year_products) then EARNEDPREM end EARNEDPREM,
					case when prod in (select ProductName from year_products) then INCLOSSSTP end INCLOSSSTP,
					case when prod in (select ProductName from year_products) then INCLOSSACT end INCLOSSACT
				from DWXM00101M) data
			where actdte = @year * 100 + @month
				and data.agent in (select * from @agent_ids)
			group by prod
		)
	select PROD
		, ADJWRTPREM
		, CHGOFFDIVD
		, WRITEPREM
		, coalesce(ADJEARPREM, 0) as ADJEARPREM
		, coalesce(EARNEDPREM, 0) as EARNEDPREM
		, INCCREDEXP
		, coalesce(INCLOSSACT, 0) as INCLOSSACT
		, coalesce(INCLOSSSTP, 0) as INCLOSSSTP
		, IIF(EARNEDPREM = 0, 0, coalesce((INCLOSSSTP / EARNEDPREM * 100), 0)) as LOSS_RATIO
		from sums_cte
	order by prod
END
GO

GRANT EXECUTE ON OBJECT::dbo.SP_StatementTopProds  
    TO ProfitSharing_User;  
GO
