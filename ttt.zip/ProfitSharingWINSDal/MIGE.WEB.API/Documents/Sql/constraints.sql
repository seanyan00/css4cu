
ALTER TABLE dbo.AddendumA   
add constraint ADDA_UNIQUE_AGENT_YEAR unique (AgentCode, Year);   
GO  


ALTER TABLE dbo.AddendumC   
add constraint ADDC_UNIQUE_AGENT_YEAR unique (AgentId, Year);   
GO  

