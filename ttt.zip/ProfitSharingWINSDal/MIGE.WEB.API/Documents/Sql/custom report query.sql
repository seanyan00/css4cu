declare @year int;
declare @month int;
declare @minPayment int;
set @year = 2019;
set @month = 12;
set @minPayment = 0;

with
	 mstr_sub as (select CDKEY2, IIF(AGYCDE = '', CDKEY2, AGYCDE) as AGYCDE
		from DWXF007 where not exists (select top 1 AGENT from AgentQualification where [YEAR] = @year)
		union
		select AGENT as CDKEY2, AGYCDE
		from AgentQualification where [YEAR] = @year
	)
	, agent_base as (select rtrim(base.CDKEY2) as CDKEY2, min(rtrim(base.AGYCDE)) as AGYCDE, min(rtrim(base.CDDESC)) as CDDESC, min(base.ENDDTE) as ENDDTE,
		min(rtrim(base.REGOFC)) as REGOFC, min(base.STRTYR) as STRTYR, min(base.MKTTER) as MKTTER, min(round(base.APPDTE / 100, 0)) as APPDTE
		from DWXF007 base
		group by base.CDKEY2
	)
	, agent_data as (select distinct rtrim(base.CDKEY2) as CDKEY2,
		rtrim(base.CDDESC) as CDDESC, base.ENDDTE, rtrim(base.REGOFC) as REGOFC,
		base.MKTTER, coalesce(addc.IsEnabled, 0) as NineMonthLock,
		--@month as report_month,
		case when coalesce(addc.IsEnabled, 0) = 1 and @month > 9 then 9 else @month end as lock_month,
		case when coalesce(addc.IsEnabled, 0) = 1 and @month > 9 then .8 else 1 end as nine_month_lock_factor,
		mgt.PlanInformation_id, mgt.ThreeYearProfitabilityReference_id, mgt.ProfitGrowthFactorsReference_id, mgt.PremiumVolumeLossRatioReference_id,
		base.STRTYR as start_month, round(base.STRTYR / 100, 0) as start_year, base.APPDTE,
		ter.IncludePersonalLines
		from agent_base base
		left outer join Addendumc addc on addc.AgentId = IIF(base.AGYCDE = '', base.CDKEY2, base.AGYCDE) /*base.AGYCDE*/ and addc.Year = @year
		left outer join MarketingTerritoryAssignment ter on ter.MarketingTerritory = base.MKTTER and EffectiveYear = @year
		-- default to NH_NJ_PA_VT_NY if no plan identified for MarketingTerritory
		join (select info.Id, info.PlanName, mgt.StartYear, mgt.EndYear 
			from PlanManagement mgt join PlanInformation info on info.Id = mgt.PlanInformation_id) default_plan
			on default_plan.PlanName = 'NH_NJ_PA_VT_NY' and @year between default_plan.StartYear and default_plan.EndYear
		join PlanManagement mgt on mgt.PlanInformation_id = coalesce(ter.PlanInformation_id, default_plan.Id) and @year between mgt.StartYear and mgt.EndYear
		--join MarketingTerritoryAssignment ter on ter.MarketingTerritory = base.MKTTER and EffectiveYear = @year
		--join PlanManagement mgt on mgt.PlanInformation_id = ter.PlanInformation_id and @year between mgt.StartYear and mgt.EndYear
	)
	, year_products as (select * from product where Year = @year
	)
	, growth_factor_cte as (select pgf.Id, pgf.Name, pgf.TableNames, pgf.TableStatus, gf.*
		from ProfitGrowthFactors pgf
		cross apply OPENJSON(pgf.Data) WITH (
				written_premium_growth_percentage_low   decimal(19,5)   '$."written-premium-growth-percentage-low"',  
				written_premium_growth_percentage_high   decimal(19,5)   '$."written-premium-growth-percentage-high"',  
				growth_factor decimal(19,5)   '$."factor"'
		) AS gf
		where TableNames = 'ProfitGrowthFactors'
	)
	, three_yr_prof_factor_cte as (select pgf.Id, pgf.Name, pgf.TableNames, pgf.TableStatus, three_year_prof.*
		from ProfitGrowthFactors pgf
		cross apply OPENJSON(pgf.Data) WITH (
			loss_ratio_low  decimal(19,5) '$."loss-ratio-low"',
			loss_ratio_high  decimal(19,5) '$."loss-ratio-high"',
			three_yr_prof_factor decimal(19,5)   '$."factor"'
		)  as three_year_prof
		where TableNames = 'ThreeYearProfitability'
	)
	, loss_ratio_factor_cte as (select pgf.Id, pgf.Name, pgf.TableNames, pgf.TableStatus, loss_ratio.*
		from ProfitGrowthFactors pgf
		cross apply OPENJSON(pgf.Data) WITH (
			loss_ratio_low  decimal(19,5) '$."loss-ratio-low"',
			loss_ratio_high  decimal(19,5) '$."loss-ratio-high"',
			written_premium_volume_low   decimal(19,5)   '$."written-premium-volume-low"',  
			written_premium_volume_high   decimal(19,5)   '$."written-premium-volume-high"',  
			loss_ratio_factor decimal(19,5)   '$."factor"'
		)  as loss_ratio
		where TableNames = 'PremiumVolumeLossRatio'
	)
	-- map of DWXM00101M replacing AGYCDE from table (for ACTDTE year) with AGYCDE for report year
	--, rpt_yr_agency_data as (select mstr.AGYCDE, data.ACTDTE, data.AGENT, data.PROD, data.ADJWRTPREM,
	--		data.CHARGEOFFS, data.DIVIDENDS, data.CHGOFFDIVD, data.WRITEPREM, data.ADJEARPREM, data.EARNEDPREM,
	--		data.INCLOSSACT, data.INCLOSSSTP, data.INCCREDLOS, data.INCCREDEXP,
	--		agnt.CDKEY2, ter.IncludePersonalLines
	--	from DWXM00101M data
	--	join mstr_sub mstr on mstr.CDKEY2 = data.AGENT
	--	join DWXF007 agnt on agnt.CDKEY2 = data.AGENT
	--	left outer join MarketingTerritoryAssignment ter on ter.MarketingTerritory = agnt.MKTTER and EffectiveYear = @year
	--)
	, rpt_yr_agency_data as (select agnt.AGYCDE, ACTDTE, AGENT, PROD, ADJWRTPREM, CHARGEOFFS, DIVIDENDS, CHGOFFDIVD, WRITEPREM, ADJEARPREM, EARNEDPREM, INCLOSSACT, INCLOSSSTP, INCCREDLOS, INCCREDEXP
		from DWXM00101M data
		join mstr_sub agnt on agnt.CDKEY2 = data.AGENT
	)
	, prev_yr_sums_cte as (select AGENT,
		coalesce(sum(GR_WRITEPREM), 0) as WRITEPREM,
		coalesce(sum(GR_WRITEPREM), 0) as GR_WRITEPREM
		from (select
				prem.agycde as AGENT,
				WRITEPREM,
				-- special case for value used in growth rate calculation
				case when agnt.IncludePersonalLines = 1 or prod in (select Code from MigProduct where [Type] = 'regular') then WRITEPREM end GR_WRITEPREM
			from rpt_yr_agency_data prem
			join agent_data agnt on agnt.CDKEY2 = prem.AGYCDE
			where actdte = (@year - 1) * 100 + @month) data
		group by AGENT
	)
	, prev_full_yr_sums_cte as (select agycde as AGENT,
		coalesce(sum(WRITEPREM), 0) as WRITEPREM,
		coalesce(sum(ADJWRTPREM), 0) as ADJWRTPREM
		from rpt_yr_agency_data data
		where actdte = (@year - 1) * 100 + 12
		group by agycde
	)
	, cur_year_sums_cte as (select AGENT,
		sum(ADJWRTPREM) AS ADJWRTPREM,
		sum(WRITEPREM) as WRITEPREM,
		sum(GR_WRITEPREM) as GR_WRITEPREM,
		sum(CHARGEOFFS) as CHARGEOFFS,
		sum(CHGOFFDIVD) as CHGOFFDIVD,
		sum(INCCREDEXP) AS INCCREDEXP,
		coalesce(sum(ADJEARPREM), 0) as ADJEARPREM,
		coalesce(sum(EARNEDPREM), 0) as EARNEDPREM,
		coalesce(sum(INCLOSSSTP), 0) as INCLOSSSTP,
		coalesce(sum(INCLOSSACT), 0) AS INCLOSSACT,
		(select min(ACTDTE % 100) from DWXM00101M where agent = data.AGENT and round(actdte / 100, 0) = @year) as start_month
		from (select
				prem.agycde as AGENT,
				ADJWRTPREM,
				WRITEPREM,
				-- special case for value used in growth rate calculation
				case when agnt.IncludePersonalLines = 1 or prod in (select Code from MigProduct where [Type] = 'regular') then WRITEPREM end GR_WRITEPREM,
				CHARGEOFFS,
				CHGOFFDIVD,
				INCCREDEXP,
				case when prod in (select ProductName from year_products) then ADJEARPREM end ADJEARPREM,
				case when prod in (select ProductName from year_products) then EARNEDPREM end EARNEDPREM,
				case when prod in (select ProductName from year_products) then INCLOSSSTP end INCLOSSSTP,
				case when prod in (select ProductName from year_products) then INCLOSSACT end INCLOSSACT
			from rpt_yr_agency_data prem
			join agent_data agnt on agnt.CDKEY2 = prem.AGYCDE
			where actdte = @year * 100 + @month) data
		group by AGENT
	)
	, nine_month_sums_cte as (select AGENT,
		sum(EARNEDPREM) as EARNEDPREM,
		sum(INCLOSSSTP) as INCLOSSSTP
		from (select
				agycde as AGENT,
				case when prod in (select ProductName from year_products) then EARNEDPREM end EARNEDPREM,
				case when prod in (select ProductName from year_products) then INCLOSSSTP end INCLOSSSTP
			from DWXM00101M
			where actdte = @year * 100 + 9) data
		group by AGENT
	)
	, growth_rate_cte as (select cur.AGENT, round(case when agent.start_year < @year then IIF(coalesce(prev.GR_WRITEPREM, 0) = 0 or coalesce(cur.GR_WRITEPREM, 0) = 0, 0, ((cur.GR_WRITEPREM - prev.GR_WRITEPREM) / prev.GR_WRITEPREM) * 100)
		else (select top 1 value from AddendumAGrowthPercentage where StartYear <= @year and EndYear >= @year) end, 2) as growth_rate
		from cur_year_sums_cte cur
		join agent_data agent on agent.CDKEY2 = cur.AGENT
		left join prev_yr_sums_cte prev on prev.AGENT = cur.AGENT
	)
	, nine_month_loss_ratio_cte as (select AGENT, case when nms.EARNEDPREM = 0 then 0 else nms.INCLOSSSTP / nms.EARNEDPREM * 100 end as loss_ratio
		from nine_month_sums_cte nms
	)
	, rprt_month_loss_ratio_cte as (select AGENT, case when cur.EARNEDPREM = 0 then 0 else cur.INCLOSSSTP / cur.EARNEDPREM * 100 end as loss_ratio
		from cur_year_sums_cte cur
	)
	, loss_ratio_cte as (select agent.CDKEY2 as AGENT, case 
		when @month > 9 and agent.NineMonthLock = 1 and nine.loss_ratio is not null then IIF(rprt.loss_ratio < nine.loss_ratio, rprt.loss_ratio, nine.loss_ratio) 
		else rprt.loss_ratio end as loss_ratio
		from agent_data agent
		join rprt_month_loss_ratio_cte rprt on rprt.AGENT = agent.CDKEY2
		left outer join nine_month_loss_ratio_cte nine on nine.AGENT = agent.CDKEY2
	)
	, writ_prem_vol_cte as (select agent.cdkey2 as agent,
		case when coalesce(prev_full.ADJWRTPREM, 0) = 0 and @month < 12 then (cur.ADJEARPREM / (1 + @month - cur.start_month)) * (13 - cur.start_month)
			when prev_full.ADJWRTPREM != 0 and @month < 12 then prev_full.WRITEPREM * (1 + (gr.growth_rate / 100))
			else cur.WRITEPREM end as writ_prem_vol		-- full year = col 3
		from agent_data agent
		join cur_year_sums_cte cur on cur.agent = agent.cdkey2
		left outer join prev_full_yr_sums_cte prev_full on prev_full.agent = agent.cdkey2
		join growth_rate_cte gr on gr.agent = agent.cdkey2
	)
	, earned_prem_cte as (select cur.agent as agent,
		case when coalesce(prev.WRITEPREM, 0) = 0 and @month < 12 then (cur.ADJEARPREM / (1 + @month - cur.start_month)) * (13 - cur.start_month)
			when prev.WRITEPREM != 0 and @month < 12 then (prev.WRITEPREM + (prev.ADJWRTPREM * (1 + (round(gr.growth_rate, 2) / 100)))) / 2
			else cur.EARNEDPREM end as earned_prem		-- full year = col 5
		from cur_year_sums_cte cur
		join growth_rate_cte gr on gr.agent = cur.agent
		left join prev_full_yr_sums_cte prev on prev.agent = cur.agent
	)
	, three_yr_prof_cte AS (select data.AGYCDE as AGENT, 
		case when sum(EARNEDPREM) = 0 then 0 else (sum(INCLOSSACT) / sum(EARNEDPREM)) * 100.0 end as three_yr_perc
		from rpt_yr_agency_data data
		join agent_data agnt on agnt.CDKEY2 = data.AGENT
		where actdte in ((@year - 2) * 100 + 12, (@year - 1) * 100 + 12, @year * 100 + @month)
		and prod in (select ProductName from year_products) 
		group by data.AGYCDE
	)
	, three_yr_factor_cte as (select agnt.CDKEY2,
		iif(agnt.APPDTE >= (@year - 3) * 100 + @month and three_yr_factor.three_yr_prof_factor > 1, 1, three_yr_factor.three_yr_prof_factor) as three_yr_prof_factor
		from agent_data agnt
		join three_yr_prof_cte three_yr_prof on three_yr_prof.AGENT = agnt.CDKEY2
		left outer join three_yr_prof_factor_cte three_yr_factor on three_yr_factor.Id = agnt.ThreeYearProfitabilityReference_id
			and three_yr_factor.loss_ratio_low <= round(three_yr_prof.three_yr_perc, 2) and three_yr_factor.loss_ratio_high >= round(three_yr_prof.three_yr_perc, 2)
	)
--	and three_yr_factor.loss_ratio_low <= round(lr.loss_ratio, 2) and three_yr_factor.loss_ratio_high >= round(lr.loss_ratio, 2)
	--, payment_cte as (select ep.earned_prem * (lrf.loss_ratio_factor / 100.0) * gf.growth_factor
	--	* nine_month_loss_lock_cte.nine_month_loss_lock * three_yr_prof_tbl.three_yr_prof_factor as prof_share_pmt
	--	from earned_prem_cte ep
	--	join agent_data agent on agent.CDKEY2 = ep.agent
	--	join loss_ratio_cte lr on lr.AGENT = ep.agent
	--	join growth_rate_cte gr on gr.AGENT = agent.CDKEY2
	--	join growth_factor_cte gf on gf.Id = agent.ProfitGrowthFactorsReference_id
	--		and gf.written_premium_growth_percentage_low <= gr.growth_rate and gf.written_premium_growth_percentage_high >= gr.growth_rate
	--	left outer join loss_ratio_factor_cte lrf on lrf.Id = agent.PremiumVolumeLossRatioReference_id and lrf.loss_ratio_low <= lr.loss_ratio and lrf.loss_ratio_high >= lr.loss_ratio
	--		and lrf.written_premium_volume_low <= vol.writ_prem_vol and lrf.written_premium_volume_high >= vol.writ_prem_vol

	--	, vol_loss_tbl, growth_factor_tbl, nine_month_loss_lock_cte, three_yr_prof_tbl
	--)

select distinct
	agent.REGOFC, agent.CDKEY2
	--, agent.start_month, agent.APPDTE, agent.PlanInformation_id
	, agent.CDDESC
	, cur.ADJWRTPREM, cur.CHARGEOFFS, cur.WRITEPREM, cur.ADJEARPREM, cur.CHGOFFDIVD
	, cur.EARNEDPREM, cur.INCCREDEXP, cur.INCLOSSACT, cur.INCLOSSSTP
	, agent.MKTTER
	, prev_yr.WRITEPREM as prev_mnth_adj_wp
	, prev_full.WRITEPREM as prev_full_adj_wp
	, ep.earned_prem
	, gr.growth_rate
	, lr.loss_ratio
	, lrf.loss_ratio_factor
	, gf.growth_factor
	, agent.nine_month_lock_factor as NineMonthLock--, agent.lock_month
	, three_yr_prof.three_yr_perc
	, three_yr_factor.three_yr_prof_factor
	, coalesce(ep.earned_prem * (lrf.loss_ratio_factor / 100) * gf.growth_factor * agent.nine_month_lock_factor * three_yr_factor.three_yr_prof_factor, 0) as payment
from agent_data agent
join growth_rate_cte gr on gr.AGENT = agent.CDKEY2
join growth_factor_cte gf on gf.Id = agent.ProfitGrowthFactorsReference_id and gf.written_premium_growth_percentage_low <= round(gr.growth_rate, 2) and gf.written_premium_growth_percentage_high >= round(gr.growth_rate, 2)
join cur_year_sums_cte cur on cur.AGENT = agent.CDKEY2
left outer join three_yr_prof_cte three_yr_prof on three_yr_prof.AGENT = agent.CDKEY2
left outer join prev_yr_sums_cte prev_yr on prev_yr.AGENT = agent.CDKEY2
left outer join prev_full_yr_sums_cte prev_full on prev_full.agent = agent.CDKEY2
join loss_ratio_cte lr on lr.AGENT = agent.CDKEY2
join writ_prem_vol_cte vol on vol.agent = agent.CDKEY2
join earned_prem_cte ep on ep.agent = agent.CDKEY2
left outer join loss_ratio_factor_cte lrf on lrf.Id = agent.PremiumVolumeLossRatioReference_id and lrf.loss_ratio_low <= round(lr.loss_ratio, 2) and lrf.loss_ratio_high >= round(lr.loss_ratio, 2)
	and lrf.written_premium_volume_low <= round(vol.writ_prem_vol, 2) and lrf.written_premium_volume_high >= round(vol.writ_prem_vol, 2)
left outer join three_yr_factor_cte three_yr_factor on three_yr_factor.CDKEY2 = agent.CDKEY2
--left outer join three_yr_prof_factor_cte three_yr_factor on three_yr_factor.Id = agent.ThreeYearProfitabilityReference_id
--	and three_yr_factor.loss_ratio_low <= round(three_yr_prof.three_yr_perc, 2) and three_yr_factor.loss_ratio_high >= round(three_yr_prof.three_yr_perc, 2)
----	and three_yr_factor.loss_ratio_low <= round(lr.loss_ratio, 2) and three_yr_factor.loss_ratio_high >= round(lr.loss_ratio, 2)
where coalesce(ep.earned_prem * (lrf.loss_ratio_factor / 100) * gf.growth_factor * agent.nine_month_lock_factor * three_yr_factor.three_yr_prof_factor, 0) >= @minPayment

order by agent.CDKEY2 --agent.MKTTER agent.REGOFC, 

