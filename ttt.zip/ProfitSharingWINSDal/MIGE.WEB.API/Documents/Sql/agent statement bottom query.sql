
-- profit sharing report bottom
declare @agent_ids_str nvarchar(max);
declare @year int;
declare @month int;
set @agent_ids_str = '["85039"]'; --05240 84644 40478 85023 84948 85088 78839 84764 82870
set @year = 2019;
set @month = 9;

DECLARE @agent_ids TABLE (Value nvarchar(255))
insert into @agent_ids select value from openjson(@agent_ids_str);

WITH 
		mstr_sub as (
			select CDKEY2, IIF(AGYCDE = '', CDKEY2, AGYCDE) as AGYCDE
			from DWXF007 with (nolock) where not exists (select top 1 AGENT from AgentQualification where [YEAR] = @year)
			union
			select AGENT as CDKEY2, AGYCDE from AgentQualification with(nolock)
			where [YEAR] = @year
		)
		, prev_mstr_sub as (
			select CDKEY2, IIF(AGYCDE = '', CDKEY2, AGYCDE) as AGYCDE
			from DWXF007 with (nolock) where not exists (select top 1 AGENT from AgentQualification where [YEAR] = @year - 1)
			union
			select AGENT as CDKEY2, AGYCDE from AgentQualification with(nolock)
			where [YEAR] = @year - 1
		)
		, sub_agents as (select distinct CDKEY2 from mstr_sub where AGYCDE in (select * from @agent_ids)
		)
		, year_products as (select * from product where Year = @year
		)
		-- base agent info
		, agent_data as (select top 1 agnt.CDKEY2 as agent,
			pmgt.ThreeYearProfitabilityReference_id, pmgt.ProfitGrowthFactorsReference_id, pmgt.PremiumVolumeLossRatioReference_id,
			coalesce(minprem.Premium, 100000000) as min_premium,
			coalesce(addc.IsEnabled, 0) as NineMonthLock,
			case when coalesce(addc.IsEnabled, 0) = 1 and @month > 9 then 9 else @month end as lock_month, @month as report_month,
			case when coalesce(addc.IsEnabled, 0) = 1 then .8 else 1 end as nine_month_lock_factor,
			(select top 1 AGYCDE from mstr_sub where CDKEY2 = agnt.CDKEY2) as AGYCDE,
			agnt.STRTYR as start_month, round(agnt.STRTYR / 100, 0) as start_year, agnt.EFFDTE,
			mkt.IncludePersonalLines
			from DWXF007 agnt
			left outer join Addendumc addc on addc.AgentId = agnt.cdkey2
			left outer join MarketingTerritoryAssignment mkt on mkt.MarketingTerritory = agnt.MKTTER and mkt.EffectiveYear = @year
			left outer join PlanManagement pmgt on pmgt.PlanInformation_id = mkt.PlanInformation_id and  @year between pmgt.StartYear and pmgt.EndYear
			left outer join MinWrittenPremium minprem on minprem.PlanInformation_id = mkt.PlanInformation_id and @year between minprem.StartYear and minprem.EndYear
			where agnt.CDKEY2 in (select CDKEY2 from sub_agents)
		)
		-- map of DWXM00101M replacing AGYCDE from table (for ACTDTE year) with AGYCDE for report year
		, rpt_yr_agency_data as (select agnt.AGYCDE, ACTDTE, AGENT, PROD, ADJWRTPREM, CHARGEOFFS, DIVIDENDS, CHGOFFDIVD, WRITEPREM, ADJEARPREM, EARNEDPREM, INCLOSSACT, INCLOSSSTP, INCCREDLOS, INCCREDEXP
			from DWXM00101M data
			join mstr_sub agnt on agnt.CDKEY2 = data.AGENT
		)
		-- top table cols
		, cur_year_sums_cte as (select 
			sum(ADJWRTPREM) AS ADJWRTPREM,
			sum(WRITEPREM) as WRITEPREM,
			sum(GR_WRITEPREM) as GR_WRITEPREM,
			coalesce(sum(ADJEARPREM), 0) as ADJEARPREM,
			coalesce(sum(EARNEDPREM), 0) as EARNEDPREM,
			coalesce(sum(INCLOSSSTP), 0) as INCLOSSSTP,
			(select min(ACTDTE % 100) from DWXM00101M where agent = min(data.SUB) and round(actdte / 100, 0) = @year) as start_month
			from (select
					prem.agycde as AGENT,
					prem.AGENT as SUB,
					ACTDTE,
					PROD,
					ADJWRTPREM,
					WRITEPREM,
					-- special case for value used in growth rate calculation
					case when ter.IncludePersonalLines = 1 or prod in (select Code from MigProduct where [Type] = 'regular') then WRITEPREM end GR_WRITEPREM,
					case when prod in (select ProductName from year_products) then ADJEARPREM end ADJEARPREM,
					case when prod in (select ProductName from year_products) then EARNEDPREM end EARNEDPREM,
					case when prod in (select ProductName from year_products) then INCLOSSSTP end INCLOSSSTP
				from DWXM00101M as prem with (nolock)
				inner join mstr_sub as agnt with (nolock) on agnt.CDKEY2 = prem.AGENT
				inner join (select distinct cdkey2, MKTTER from DWXF007) as d7 on prem.AGENT = d7.CDKEY2
				left outer join MarketingTerritoryAssignment as ter with(nolock) on ter.MarketingTerritory = d7.MKTTER
					and ter.EffectiveYear = @year
				left join Product on prem.prod = Product.ProductName and Product.[Year] = @year
				where prem.actdte = @year * 100 + @month) as data
			where data.agent in (select * from @agent_ids)
			--	from DWXM00101M prem
			--	join agent_data agnt on agnt.agent = prem.AGENT) data
			--where actdte = @year * 100 + @month
			--	and data.agent in (select * from @agent_ids)
		)
		, nine_month_sums AS (select sum(EARNEDPREM) AS EARNEDPREM,
			sum(INCLOSSSTP)AS INCLOSSSTP
			from DWXM00101M data
			where prod in (select ProductName from year_products)
			and data.AGYCDE in (select * from @agent_ids) and actdte = @year * 100 + 9
		)
		-- sums from previous full year
		, prev_full_yr AS (select coalesce(sum(WRITEPREM), 0) as WRITEPREM,	-- col 3
			coalesce(sum(ADJWRTPREM), 0) as ADJWRTPREM
			from rpt_yr_agency_data
			where AGYCDE in (select * from @agent_ids) and actdte = (@year - 1) * 100 + 12
		)
		-- A
		, prev_yr AS (select 
			coalesce(sum(WRITEPREM), 0) as WRITEPREM,
			coalesce(sum(GR_WRITEPREM), 0) as GR_WRITEPREM
			from (select
					agnt.AGYCDE as AGENT,
					WRITEPREM,
					-- special case for value used in growth rate calculation
					case when agnt.IncludePersonalLines = 1 or prod in (select Code from MigProduct where [Type] = 'regular') then WRITEPREM end GR_WRITEPREM
				from rpt_yr_agency_data prem
				join agent_data agnt on agnt.agent = prem.AGENT
				where actdte = (@year - 1) * 100 + @month) data
			where data.AGENT in (select * from @agent_ids) --and actdte = (@year - 1) * 100 + @month
		)
		-- F
		, growth_rate_cte as (select round(case when prev_yr.GR_WRITEPREM > 0 then ((cur_year_sums_cte.GR_WRITEPREM - prev_yr.GR_WRITEPREM) / prev_yr.GR_WRITEPREM) * 100
			else (select top 1 value from AddendumAGrowthPercentage where StartYear <= @year and EndYear >= @year) end, 2) as growth_rate
			from prev_yr, cur_year_sums_cte
		)
		-- D
		, writ_prem_vol_cte as (select top 1 case when prev_full_yr.ADJWRTPREM = 0 and @month < 12 then (cur_year_sums_cte.ADJWRTPREM / (1 + @month - cur_year_sums_cte.start_month)) * (13 - cur_year_sums_cte.start_month)
			when prev_full_yr.ADJWRTPREM != 0 and @month < 12 then prev_full_yr.ADJWRTPREM * (1 + round(growth_rate_cte.growth_rate / 100, 4))
			else cur_year_sums_cte.WRITEPREM end as writ_prem_vol		-- full year = col 3
			from DWXM00101M, cur_year_sums_cte, prev_yr, prev_full_yr, growth_rate_cte
		)
		-- B
		, earned_prem_cte as (select top 1
			case when prev.WRITEPREM = 0 and @month < 12 then (cur.ADJEARPREM / (1 + @month - cur.start_month)) * (13 - cur.start_month)
				when prev.WRITEPREM != 0 and @month < 12 then (prev.WRITEPREM + (prev.ADJWRTPREM * (1 + (round(gr.growth_rate, 2) / 100)))) / 2
				else cur.EARNEDPREM end as earned_prem		-- full year = col 5
			from cur_year_sums_cte cur, growth_rate_cte gr, prev_full_yr prev
		)
		, nine_month_loss_ratio_cte as (select case when nms.EARNEDPREM = 0 then 0 else nms.INCLOSSSTP / nms.EARNEDPREM * 100 end as loss_ratio
			from nine_month_sums nms
		)
		, rprt_month_loss_ratio_cte as (select case when cur.EARNEDPREM = 0 then 0 else cur.INCLOSSSTP / cur.EARNEDPREM * 100 end as loss_ratio
			from cur_year_sums_cte cur
		)
		-- C (top col 9)
		, loss_ratio_cte as (select case 
			when @month > 9 and agent_data.NineMonthLock = 1 and nine_month_loss_ratio_cte.loss_ratio is not null 
				then IIF(rprt_month_loss_ratio_cte.loss_ratio < nine_month_loss_ratio_cte.loss_ratio, rprt_month_loss_ratio_cte.loss_ratio, nine_month_loss_ratio_cte.loss_ratio) 
			else rprt_month_loss_ratio_cte.loss_ratio end as loss_ratio
			from agent_data, nine_month_loss_ratio_cte, rprt_month_loss_ratio_cte
		)
		-- E
		, vol_loss_tbl as (select loss_factor.*, pgf.* 
			from ProfitGrowthFactors pgf
			cross apply OPENJSON (pgf.[data])  
			WITH (
				loss_ratio_low  decimal(19,5) '$."loss-ratio-low"',
				loss_ratio_high  decimal(19,5) '$."loss-ratio-high"',
				written_premium_volume_low   decimal(19,5)   '$."written-premium-volume-low"',  
				written_premium_volume_high   decimal(19,5)   '$."written-premium-volume-high"',  
				factor decimal(19,5)   '$."factor"'
			) as loss_factor
			, loss_ratio_cte, writ_prem_vol_cte, agent_data
			where pgf.Id = agent_data.PremiumVolumeLossRatioReference_id
				and loss_factor.written_premium_volume_low <= writ_prem_vol_cte.writ_prem_vol and written_premium_volume_high >= writ_prem_vol_cte.writ_prem_vol
				and loss_factor.loss_ratio_low <= loss_ratio_cte.loss_ratio and loss_factor.loss_ratio_high >= loss_ratio_cte.loss_ratio
		)
		-- G
		, growth_factor_tbl as (select top 1 growth_factor.*, pgf.* 
			from ProfitGrowthFactors pgf
			cross apply OPENJSON (pgf.[data])  
			WITH (
				written_premium_growth_percentage_low   decimal(19,5)   '$."written-premium-growth-percentage-low"',  
				written_premium_growth_percentage_high   decimal(19,5)   '$."written-premium-growth-percentage-high"',  
				growth_factor decimal(19,5)   '$."factor"'
			) as growth_factor
			, growth_rate_cte, agent_data
			where pgf.Id = agent_data.ProfitGrowthFactorsReference_id
				and growth_factor.written_premium_growth_percentage_low <= growth_rate_cte.growth_rate and growth_factor.written_premium_growth_percentage_high >= growth_rate_cte.growth_rate
		)
		-- I
		, three_yr_prof_cte AS (select case when sum(EARNEDPREM) = 0 then 0 else (sum(INCLOSSACT) / sum(EARNEDPREM)) * 100.0 end as three_yr_prof			-- col 7 / col 5
			from DWXM00101M
			where prod in (select ProductName from Product where year = @year and ProductName not in ('CUP', 'PUP')) 
			and agent in (select * from sub_agents) and actdte in ((@year - 2) * 100 + 12, (@year - 1) * 100 + 12, @year * 100 + @month)
		)
		-- J
		, three_yr_prof_tbl as (select profitability.*, pgf.* 
			from ProfitGrowthFactors pgf
			cross apply OPENJSON (pgf.[data])  
			WITH (
				loss_ratio_low  decimal(19,5) '$."loss-ratio-low"',
				loss_ratio_high  decimal(19,5) '$."loss-ratio-high"',
				three_yr_prof_factor decimal(19,5)   '$."factor"'
			) as profitability
			, loss_ratio_cte, agent_data
			where pgf.Id = agent_data.ThreeYearProfitabilityReference_id
				and profitability.loss_ratio_low <= loss_ratio_cte.loss_ratio and profitability.loss_ratio_high >= loss_ratio_cte.loss_ratio
		)
		, prof_share_pmt_cte as (select earned_prem_cte.earned_prem * (vol_loss_tbl.factor / 100.0) * growth_factor_tbl.growth_factor
			* agent_data.nine_month_lock_factor * three_yr_prof_tbl.three_yr_prof_factor as prof_share_pmt
			from earned_prem_cte, vol_loss_tbl, growth_factor_tbl, agent_data, three_yr_prof_tbl
		)

	select
		round(prev_yr.WRITEPREM, 2) as prev_year_premiums,
		round(earned_prem_cte.earned_prem, 2) as earned_prem,
		loss_ratio_cte.loss_ratio,
		round(writ_prem_vol_cte.writ_prem_vol, 2) as writ_prem_vol,
		vol_loss_tbl.factor as loss_ratio_factor,
		growth_rate_cte.growth_rate,
		growth_factor_tbl.growth_factor,
		agent_data.nine_month_lock_factor as nine_month_loss_lock,
		three_yr_prof_cte.three_yr_prof as three_yr_prof_ratio,
		three_yr_prof_tbl.three_yr_prof_factor,
		round(prof_share_pmt_cte.prof_share_pmt, 2) as prof_share_pmt
	from agent_data, prev_full_yr, prev_yr, growth_rate_cte, three_yr_prof_cte, writ_prem_vol_cte, earned_prem_cte,
		loss_ratio_cte, vol_loss_tbl, growth_factor_tbl, three_yr_prof_tbl, prof_share_pmt_cte
--, cur_year_sums_cte
	

	