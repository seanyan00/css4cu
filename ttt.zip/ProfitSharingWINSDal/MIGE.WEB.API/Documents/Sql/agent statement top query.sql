
-- profit sharing report top
declare @agent_ids_str nvarchar(max);
declare @year int;
declare @month int;
set @agent_ids_str = '["84797"]'; --"84694", 05240, 02167, 18885, 82557, 48676
set @year = 2020;
set @month = 9;

DECLARE @agent_ids TABLE (Value nvarchar(255))
insert into @agent_ids select value from openjson(@agent_ids_str);

-- per product
with
	--mstr_sub as (select CDKEY2, IIF(AGYCDE = '', CDKEY2, AGYCDE) as AGYCDE
	--	from DWXF007 where not exists (select top 1 AGENT from AgentQualification where [YEAR] = @year)
	--	union
	--	select AGENT as CDKEY2, AGYCDE
	--	from AgentQualification where [YEAR] = @year
	--)
	--, sub_agents as (select distinct CDKEY2 from mstr_sub where CDKEY2 in (select * from @agent_ids) or AGYCDE in (select * from @agent_ids)
	--)
	year_products as (select * from product where Year = @year
	)
	, sums_cte as (select distinct PROD,
		sum(ADJWRTPREM) as ADJWRTPREM,
		sum(WRITEPREM) as WRITEPREM,
		sum(CHARGEOFFS) as CHARGEOFFS,
		sum(CHGOFFDIVD) as CHGOFFDIVD,
		sum(INCCREDEXP) as INCCREDEXP,
		sum(ADJEARPREM) as ADJEARPREM,
		sum(EARNEDPREM) as EARNEDPREM,
		sum(INCLOSSSTP) as INCLOSSSTP,
		sum(INCLOSSACT) as INCLOSSACT
		from (select
				agycde as AGENT,
				ACTDTE,
				PROD,
				ADJWRTPREM,
				WRITEPREM,
				CHARGEOFFS,
				CHGOFFDIVD,
				case when prod in (select ProductName from year_products) then INCCREDEXP end INCCREDEXP,
				case when prod in (select ProductName from year_products) then ADJEARPREM end ADJEARPREM,
				case when prod in (select ProductName from year_products) then EARNEDPREM end EARNEDPREM,
				case when prod in (select ProductName from year_products) then INCLOSSSTP end INCLOSSSTP,
				case when prod in (select ProductName from year_products) then INCLOSSACT end INCLOSSACT
			from DWXM00101M) data
		where actdte = @year * 100 + @month
			and data.agent in (select * from @agent_ids)
		group by prod
	)
select PROD
	, ADJWRTPREM
	, CHGOFFDIVD
	, WRITEPREM
	, coalesce(ADJEARPREM, 0) as ADJEARPREM
	, coalesce(EARNEDPREM, 0) as EARNEDPREM
	, INCCREDEXP
	, coalesce(INCLOSSACT, 0) as INCLOSSACT
	, coalesce(INCLOSSSTP, 0) as INCLOSSSTP
	, IIF(EARNEDPREM = 0, 0, coalesce((INCLOSSSTP / EARNEDPREM * 100), 0)) as LOSS_RATIO
	from sums_cte
order by prod

;

--declare @agent_ids_str nvarchar(max);
--declare @year int;
--declare @month int;
--set @agent_ids_str = '["18885"]'; --"84694", 05240, 02167, 18885, 82557, 48676
--set @year = 2019;
--set @month = 9;

--DECLARE @agent_ids TABLE (Value nvarchar(255))
--insert into @agent_ids select value from openjson(@agent_ids_str);

-- totals
with
		mstr_sub as (select CDKEY2, IIF(AGYCDE = '', CDKEY2, AGYCDE) as AGYCDE
			from DWXF007 where not exists (select top 1 AGENT from AgentQualification where [YEAR] = @year)
			union
			select AGENT as CDKEY2, AGYCDE
			from AgentQualification where [YEAR] = @year
		)
		--, agent_info as (select top 1 agnt.CDKEY2 as agent, agnt.AGYCDE,
		--	coalesce(addc.IsEnabled, 0) as NineMonthLock
		--	from mstr_sub agnt
		--	left outer join Addendumc addc on addc.AgentId = agnt.cdkey2
		--	where agnt.CDKEY2 in (select * from @agent_ids)
		--)
		, sub_agents as (select distinct CDKEY2 from mstr_sub where CDKEY2 in (select * from @agent_ids) or AGYCDE in (select * from @agent_ids)
		)
		, year_products as (select * from product where Year = @year
		)
		, sums_cte as (select 
			sum(ADJWRTPREM) as ADJWRTPREM,
			sum(WRITEPREM) as WRITEPREM,
			sum(CHARGEOFFS) as CHARGEOFFS,
			sum(CHGOFFDIVD) as CHGOFFDIVD,
			sum(INCCREDEXP) as INCCREDEXP,
			sum(ADJEARPREM) as ADJEARPREM,
			sum(EARNEDPREM) as EARNEDPREM,
			sum(INCLOSSSTP) as INCLOSSSTP,
			sum(INCLOSSACT) as INCLOSSACT
			from (select
						agnt.AGYCDE as AGENT,
						prem.PROD,
						prem.ACTDTE,
						prem.ADJWRTPREM,
						prem.WRITEPREM,
						 --special case for value used in growth rate calculation
						case when ter.IncludePersonalLines = 1 or prem.prod in (select Code from MigProduct where [Type] = 'regular') then prem.WRITEPREM end GR_WRITEPREM,
						prem.CHARGEOFFS,
						prem.CHGOFFDIVD,
						case when Product.ProductName is not null then INCCREDEXP end INCCREDEXP,
						case when Product.ProductName is not null then ADJEARPREM end ADJEARPREM,
						case when Product.ProductName is not null then EARNEDPREM end EARNEDPREM,
						case when Product.ProductName is not null then INCLOSSSTP end INCLOSSSTP,
						case when Product.ProductName is not null then INCLOSSACT end INCLOSSACT
					from DWXM00101M as prem with (nolock)
					inner join mstr_sub as agnt with (nolock) on agnt.CDKEY2 = prem.AGENT
					inner join (select distinct cdkey2, MKTTER from DWXF007) as d7 on prem.AGENT = d7.CDKEY2
					left outer join MarketingTerritoryAssignment as ter with(nolock) on ter.MarketingTerritory = d7.MKTTER 
						and ter.EffectiveYear = @year
					left join Product on prem.prod = Product.ProductName
						and Product.[Year] = @year) as data
			where data.actdte = @year * 100 + @month
				and data.agent in (select * from @agent_ids)
		)
		, loss_ratio_cte as (select case when cur.EARNEDPREM = 0 then 0 else cur.INCLOSSSTP / cur.EARNEDPREM * 100 end as loss_ratio
			from sums_cte cur
		)

select 'Total' as PROD, 
ADJWRTPREM,
CHGOFFDIVD,
WRITEPREM,	-- coll 3
ADJEARPREM,
EARNEDPREM,	-- coll 5
INCCREDEXP,
INCLOSSACT,
INCLOSSSTP,
loss_ratio_cte.loss_ratio AS LOSS_RATIO,
(select count(*) from sub_agents) as subagent_cnt
from sums_cte, loss_ratio_cte
