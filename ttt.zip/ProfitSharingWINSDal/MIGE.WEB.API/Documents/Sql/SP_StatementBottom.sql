IF OBJECT_ID ( 'SP_StatementBottom', 'P' ) IS NOT NULL   
    DROP PROCEDURE SP_StatementBottom;  
GO
 
CREATE PROCEDURE dbo.SP_StatementBottom(
	@agent_ids_str nvarchar(max),
	@year int,
	@month int,
	@as_sub int = 0)
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @agent_ids TABLE (Value nvarchar(255))
	insert into @agent_ids select value from openjson(@agent_ids_str);

	WITH 
		mstr_sub as (
			select CDKEY2, case when @as_sub = 1 then CDKEY2 else IIF(AGYCDE = '', CDKEY2, AGYCDE) end as AGYCDE
			from DWXF007 with (nolock) where not exists (select top 1 AGENT from AgentQualification where [YEAR] = @year)
			union
			select AGENT as CDKEY2, case when @as_sub = 1 then AGENT else AGYCDE end as AGYCDE 
			from AgentQualification with(nolock)
			where [YEAR] = @year
		)
		, prev_mstr_sub as (
			select CDKEY2, case when @as_sub = 1 then CDKEY2 else IIF(AGYCDE = '', CDKEY2, AGYCDE) end as AGYCDE
			from DWXF007 with (nolock) where not exists (select top 1 AGENT from AgentQualification where [YEAR] = @year - 1)
			union
			select AGENT as CDKEY2, case when @as_sub = 1 then AGENT else AGYCDE end as AGYCDE 
			from AgentQualification with(nolock)
			where [YEAR] = @year - 1
		)
		, agent_base as (
			select base.CDKEY2
				, base.AGYCDE as cur_AGYCDE
				, iif(coalesce(ms.AGYCDE, '') = '', base.CDKEY2, ms.AGYCDE) as year_AGYCDE
				, iif(coalesce(pms.AGYCDE, '') = '', base.CDKEY2, pms.AGYCDE) as prev_AGYCDE
				, base.CDDESC
				, base.ENDDTE
				, base.REGOFC
				, base.STRTYR
				, base.MKTTER
				, base.EFFDTE
				-- get the min EFFDTE for any subagent belonging to the agent's master agent
				, (select min(sub.EFFDTE)
					from vw_agent_base agnt
					--join mstr_sub rel_mstr on rel_mstr.CDKEY2 = agnt.CDKEY2
					join mstr_sub rel_sub on rel_sub.AGYCDE = agnt.CDKEY2 --rel_mstr.AGYCDE
					join vw_agent_base sub on sub.CDKEY2 = rel_sub.CDKEY2
					where agnt.CDKEY2 = base.CDKEY2) as min_EFFDTE
				, coalesce(adda.IsEnabled, 0) as min_prem_enabled
				, case when coalesce(adda.IsEnabled, 0) = 1 then adda.MinPremium
					else minprem.Premium
					end as MinPremium
			from vw_agent_base as base
			left outer join mstr_sub ms on ms.CDKEY2 = base.CDKEY2
			left outer join prev_mstr_sub pms on pms.CDKEY2 = base.CDKEY2
			left outer join AddendumA adda on adda.AgentCode = base.CDKEY2 and adda.Year = @year
			left outer join MarketingTerritoryAssignment as ter with (nolock) on ter.MarketingTerritory = base.MKTTER and EffectiveYear = @year
			left outer join (select info.Id, info.PlanName, mgt.StartYear, mgt.EndYear
						from PlanManagement as mgt with (nolock) 
						inner join PlanInformation as info with (nolock) on 
							info.Id = mgt.PlanInformation_id) as default_plan on 
				default_plan.PlanName = 'NH_NJ_PA_VT_NY' and 
				@year between default_plan.StartYear and default_plan.EndYear
			left outer join PlanManagement as mgt with(nolock) on 
				mgt.PlanInformation_id = coalesce(ter.PlanInformation_id, default_plan.Id) and 
				@year between mgt.StartYear and mgt.EndYear
			left outer join MinWrittenPremium minprem with(nolock) on minprem.PlanInformation_id = mgt.PlanInformation_id
		)
		, prem_base as (select coalesce(agnt.AGYCDE, prem.AGENT) as year_AGYCDE,
			coalesce(prev_agnt.AGYCDE, prem.AGENT) as prev_AGYCDE,
			ACTDTE, AGENT, PROD, ADJWRTPREM, CHARGEOFFS, DIVIDENDS, CHGOFFDIVD, WRITEPREM, ADJEARPREM, EARNEDPREM, INCLOSSACT, INCLOSSSTP, INCCREDLOS, INCCREDEXP
			from DWXM00101M prem with (nolock)
			left outer join mstr_sub agnt on agnt.CDKEY2 = prem.AGENT
			left outer join prev_mstr_sub prev_agnt on prev_agnt.CDKEY2 = prem.AGENT
		)
		, prev_yr_sums_cte as (
			select min(AGENT) as AGENT,
				coalesce(sum(GR_WRITEPREM), 0) as WRITEPREM,
				coalesce(sum(GR_WRITEPREM), 0) as GR_WRITEPREM
			from (select
					prem.year_AGYCDE as AGENT,
					prem.WRITEPREM,
					-- special case for value used in growth rate calculation
					case when ter.IncludePersonalLines = 1 or prod in (select Code from MigProduct where [Type] = 'regular') then prem.WRITEPREM end GR_WRITEPREM
					from prem_base prem
					inner join (select distinct cdkey2, MKTTER from DWXF007) as d7 on d7.CDKEY2	= prem.year_AGYCDE	
					left outer join MarketingTerritoryAssignment as ter with (nolock) on ter.MarketingTerritory = d7.MKTTER 
						and ter.EffectiveYear = @year - 1
					where prem.actdte = (@year - 1) * 100 + @month) as [data]
			where AGENT in (select * from @agent_ids)
		)
		, prev_full_yr_sums_cte as (
			select min(prem.year_AGYCDE) as AGENT, --agnt.agycde as AGENT,
				coalesce(sum(WRITEPREM), 0) as WRITEPREM,
				coalesce(sum(ADJWRTPREM), 0) as ADJWRTPREM
			from prem_base prem
			where actdte = (@year - 1) * 100 + 12
			and prem.year_AGYCDE in (select * from @agent_ids)
		)
		, cur_year_sums_cte as (
			select min(AGENT) as AGENT,
				sum(ADJWRTPREM) AS ADJWRTPREM,
				sum(WRITEPREM) as WRITEPREM,
				sum(GR_WRITEPREM) as GR_WRITEPREM,
				sum(CHARGEOFFS) as CHARGEOFFS,
				sum(CHGOFFDIVD) as CHGOFFDIVD,
				coalesce(sum(INCCREDEXP), 0) as INCCREDEXP,
				coalesce(sum(ADJEARPREM), 0) as ADJEARPREM,
				coalesce(sum(EARNEDPREM), 0) as EARNEDPREM,
				coalesce(sum(INCLOSSSTP), 0) as INCLOSSSTP,
				coalesce(sum(INCLOSSACT), 0) AS INCLOSSACT,
				(select min(ACTDTE % 100)  from DWXM00101M with(nolock) where agent = min(agntdata.AGENT) and round(actdte / 100, 0) = @year) as start_month
				from (select
					agnt.AGYCDE as AGENT,
					prem.ADJWRTPREM,
					prem.WRITEPREM,
						--special case for value used in growth rate calculation
					case when ter.IncludePersonalLines = 1 or prem.prod in (select Code from MigProduct where [Type] = 'regular') then prem.WRITEPREM end GR_WRITEPREM,
					prem.CHARGEOFFS,
					prem.CHGOFFDIVD,
					case when Product.ProductName is not null then INCCREDEXP end INCCREDEXP,
					case when Product.ProductName is not null then ADJEARPREM end ADJEARPREM,
					case when Product.ProductName is not null then EARNEDPREM end EARNEDPREM,
					case when Product.ProductName is not null then INCLOSSSTP end INCLOSSSTP,
					case when Product.ProductName is not null then INCLOSSACT end INCLOSSACT
					from DWXM00101M as prem with (nolock)
					inner join mstr_sub as agnt with (nolock) on agnt.CDKEY2 = prem.AGENT
					inner join (select distinct cdkey2, MKTTER from DWXF007) as d7 on prem.AGENT = d7.CDKEY2
					left outer join MarketingTerritoryAssignment as ter with(nolock) on ter.MarketingTerritory = d7.MKTTER
						and ter.EffectiveYear = @year
					left join Product on prem.prod = Product.ProductName and Product.[Year] = @year
			where prem.actdte = @year * 100 + @month) as agntdata
			where AGENT in (select * from @agent_ids)
		)
		, nine_month_sums_cte as (
			select min(AGENT) as AGENT,
				sum(EARNEDPREM) as EARNEDPREM,
				sum(INCLOSSSTP) as INCLOSSSTP
				from (select
					year_AGYCDE as AGENT,
					case when Product.ProductName is not null then EARNEDPREM end EARNEDPREM,
					case when Product.ProductName is not null then INCLOSSSTP end INCLOSSSTP
					from prem_base AS prem with(nolock)
 					left join Product on prem.prod = Product.ProductName and Product.[Year] = @year
				where actdte = @year * 100 + 9) as agntdata
			where AGENT in (select * from @agent_ids)
		)
		, growth_rate_cte as (
			select distinct cur.AGENT
				, round(case
						when FLOOR(base.EFFDTE/100) < @year then 
							IIF(coalesce(prev.GR_WRITEPREM, 0) = 0 or coalesce(cur.GR_WRITEPREM, 0) = 0, 0, ((cur.GR_WRITEPREM - prev.GR_WRITEPREM) / prev.GR_WRITEPREM) * 100)
						else 
							(select top 1 value from AddendumAGrowthPercentage where StartYear <= @year and EndYear >= @year) 
						end, 2) as growth_rate
			from cur_year_sums_cte as cur
			inner join vw_agent_base as base on base.CDKEY2 = cur.AGENT 
			left join prev_yr_sums_cte as prev on prev.AGENT = cur.AGENT
		)
		, nine_month_loss_ratio_cte as (
			select AGENT, case when nms.EARNEDPREM = 0 then 0 else nms.INCLOSSSTP / nms.EARNEDPREM * 100 end as loss_ratio
			from nine_month_sums_cte as nms
		)
		, rprt_month_loss_ratio_cte as (
			select AGENT, case when cur.EARNEDPREM = 0 then 0 else cur.INCLOSSSTP / cur.EARNEDPREM * 100 end as loss_ratio
			from cur_year_sums_cte cur
		)
		, earned_prem_cte as (
			select cur.agent as agent,
				case when coalesce(prev.WRITEPREM, 0) = 0 and @month < 12 then (cur.ADJEARPREM / (1 + @month - cur.start_month)) * (13 - cur.start_month)
				when prev.WRITEPREM != 0 and @month < 12 then (prev.WRITEPREM + (prev.ADJWRTPREM * (1 + (round(gr.growth_rate, 2) / 100)))) / 2
				else cur.EARNEDPREM end as earned_prem	-- full year = col 5
			from cur_year_sums_cte as cur
			inner join growth_rate_cte as gr on gr.agent = cur.agent
			left join prev_full_yr_sums_cte as prev on prev.agent = cur.agent
		)
		, loss_ratio_cte as (
			select base.CDKEY2 as AGENT
				, case
					when @month > 9 and coalesce(addc.IsEnabled, 0) = 1 and nine.loss_ratio is not null then 
						IIF(rprt.loss_ratio < nine.loss_ratio, rprt.loss_ratio, nine.loss_ratio)
					else rprt.loss_ratio end as loss_ratio
			from agent_base as base
			left outer join Addendumc as addc with (nolock) on addc.AgentId = IIF(base.year_AGYCDE = '', base.CDKEY2, base.year_AGYCDE) /*base.AGYCDE*/ and addc.Year = @year
			inner join rprt_month_loss_ratio_cte as rprt on rprt.AGENT = base.CDKEY2
			left outer join nine_month_loss_ratio_cte as nine on nine.AGENT = base.CDKEY2
			join earned_prem_cte ep on ep.agent = base.CDKEY2
		)
		, writ_prem_vol_cte as (
			select cur.agent as agent
				, case when coalesce(prev_full.ADJWRTPREM, 0) = 0 and @month < 12 then 
						(cur.ADJEARPREM / (1 + @month - cur.start_month)) * (13 - cur.start_month)
				when prev_full.ADJWRTPREM != 0 and @month < 12 then 
						prev_full.ADJWRTPREM * (1 + (gr.growth_rate / 100))
				else cur.WRITEPREM  end as writ_prem_vol   -- full year = col 3
			from cur_year_sums_cte as cur 
			left outer join prev_full_yr_sums_cte as prev_full on prev_full.agent = cur.AGENT
			inner join growth_rate_cte gr on gr.agent = cur.AGENT
		)
		, three_yr_prof_cte AS (
			select agnt.AGYCDE as AGENT,
				case when sum(EARNEDPREM) = 0 then 0 else (sum(INCLOSSACT) / sum(EARNEDPREM)) * 100.0 end as three_yr_perc
			from DWXM00101M as d with(nolock)
			inner join mstr_sub as agnt on agnt.CDKEY2 = d.AGENT
 			INNER join Product on d.prod = Product.ProductName and Product.[Year] = @year
			where actdte in ((@year - 2) * 100 + 12, (@year - 1) * 100 + 12, @year * 100 + @month)
				and prod in (select ProductName from product where [Year] = @year)
			group by agnt.AGYCDE
		)
		, three_yr_factor_cte as (
			select base.CDKEY2,
				iif(base.min_EFFDTE > (@year - 3) * 100 + @month and three_yr_factor.three_yr_prof_factor > 1, 1, 
				three_yr_factor.three_yr_prof_factor) as three_yr_prof_factor
			from agent_base as base
			left outer join MarketingTerritoryAssignment as ter with (nolock) on ter.MarketingTerritory = base.MKTTER and EffectiveYear = @year
			-- default to NH_NJ_PA_VT_NY if no plan identified for MarketingTerritory
			inner join (select info.Id, info.PlanName, mgt.StartYear, mgt.EndYear
						from PlanManagement as mgt with (nolock) 
						inner join PlanInformation as info with (nolock) on 
							info.Id = mgt.PlanInformation_id) as default_plan on 
				default_plan.PlanName = 'NH_NJ_PA_VT_NY' and 
				@year between default_plan.StartYear and default_plan.EndYear
			inner join PlanManagement as mgt with(nolock) on 
				mgt.PlanInformation_id = coalesce(ter.PlanInformation_id, default_plan.Id) and 
				@year between mgt.StartYear and mgt.EndYear
			inner join three_yr_prof_cte as three_yr_prof on 
				three_yr_prof.AGENT = base.CDKEY2
			left outer join vw_three_yr_prof_factor as three_yr_factor on 
				three_yr_factor.Id = mgt.ThreeYearProfitabilityReference_id and 
				three_yr_factor.loss_ratio_low <= round(three_yr_prof.three_yr_perc, 2) and 
				three_yr_factor.loss_ratio_high >= round(three_yr_prof.three_yr_perc, 2)
	 )
	
	select distinct --* --
			round(prev_yr.WRITEPREM, 2) as prev_year_premiums,
			round(ep.earned_prem, 2) as earned_prem,
			lr.loss_ratio,
			round(vol.writ_prem_vol, 2) as writ_prem_vol,
			lrf.loss_ratio_factor as loss_ratio_factor,
			gr.growth_rate,
			gf.growth_factor,
			case when coalesce(addc.IsEnabled, 0) = 1 and @month > 9 then .8 else 1 end as nine_month_loss_lock,
			three_yr_prof.three_yr_perc as three_yr_prof_ratio,
			three_yr_factor.three_yr_prof_factor,
			case when base.MinPremium > vol.writ_prem_vol then 0
					else coalesce(ep.earned_prem * (lrf.loss_ratio_factor / 100) * gf.growth_factor
					* (case when coalesce(addc.IsEnabled, 0) = 1 and @month > 9 then .8 else 1 end) -- Nine month lock factor 
					* three_yr_factor.three_yr_prof_factor, 0)
					end as prof_share_pmt

	from agent_base as base
	left outer join Addendumc as addc with (nolock) on addc.AgentId = IIF(base.year_AGYCDE = '', base.CDKEY2, base.year_AGYCDE) /*base.AGYCDE*/ and addc.Year = @year
	left outer join MarketingTerritoryAssignment as ter with (nolock) on ter.MarketingTerritory = base.MKTTER 
		and EffectiveYear = @year
	-- default to NH_NJ_PA_VT_NY if no plan identified for MarketingTerritory
	inner join (select info.Id, info.PlanName, mgt.StartYear, mgt.EndYear
				from PlanManagement as mgt with(nolock) 
				inner join PlanInformation as info with(nolock) on 
					info.Id = mgt.PlanInformation_id) as default_plan on default_plan.PlanName = 'NH_NJ_PA_VT_NY' and 
						@year between default_plan.StartYear and default_plan.EndYear
	inner join PlanManagement as mgt with(nolock) on mgt.PlanInformation_id = coalesce(ter.PlanInformation_id, default_plan.Id)
		and @year between mgt.StartYear and mgt.EndYear
	inner join growth_rate_cte gr on gr.AGENT = base.CDKEY2
	inner join vw_growth_factor gf on gf.Id = mgt.ProfitGrowthFactorsReference_id
		and gf.written_premium_growth_percentage_low <= round(gr.growth_rate, 2)
		and gf.written_premium_growth_percentage_high >= round(gr.growth_rate, 2)
	inner join cur_year_sums_cte cur on cur.AGENT = base.CDKEY2
	left outer join three_yr_prof_cte as three_yr_prof on three_yr_prof.AGENT = base.CDKEY2
	left outer join prev_yr_sums_cte as prev_yr on prev_yr.AGENT = base.CDKEY2
	left outer join prev_full_yr_sums_cte as prev_full on prev_full.agent = base.CDKEY2
	join loss_ratio_cte as lr on lr.AGENT = base.CDKEY2
	join writ_prem_vol_cte as vol on vol.agent = base.CDKEY2
	join earned_prem_cte ep on ep.agent = base.CDKEY2
	left outer join vw_loss_ratio_factor lrf on lrf.Id = mgt.PremiumVolumeLossRatioReference_id 
		and lrf.loss_ratio_low <= round(lr.loss_ratio, 2) 
		and lrf.loss_ratio_high >= round(lr.loss_ratio, 2) 
		and lrf.written_premium_volume_low <= round(vol.writ_prem_vol, 2) 
		and lrf.written_premium_volume_high >= round(vol.writ_prem_vol, 2)
	left outer join three_yr_factor_cte AS three_yr_factor on three_yr_factor.CDKEY2 = base.CDKEY2

	where base.year_AGYCDE in (select * from @agent_ids)
END
GO

GRANT EXECUTE ON OBJECT::dbo.SP_StatementBottom  
    TO ProfitSharing_User;  
GO
