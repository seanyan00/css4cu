IF OBJECT_ID ( 'SP_StatementAgents', 'P' ) IS NOT NULL   
    DROP PROCEDURE SP_StatementAgents;  
GO
 
CREATE PROCEDURE dbo.SP_StatementAgents(
	@agent_ids_str nvarchar(max),
	@year int = null,
	@month int = null)
AS
BEGIN
	SET NOCOUNT ON;

	if (@year is null) begin
		set @year = YEAR(getdate())
	end
	if (@month is null) begin
		set @month = MONTH(getdate())
	end

	DECLARE @agent_ids TABLE (Value nvarchar(255))
	insert into @agent_ids select value from openjson(@agent_ids_str);

	with
		mstr_sub as (
			select CDKEY2, IIF(AGYCDE = '', CDKEY2, AGYCDE) as AGYCDE
			from DWXF007 with (nolock) where not exists (select top 1 AGENT from AgentQualification where [YEAR] = @year)
			union
			select AGENT as CDKEY2, AGYCDE from AgentQualification with(nolock)
			where [YEAR] = @year
		)
	select distinct CDKEY2 from mstr_sub where AGYCDE in (select * from @agent_ids)
END
GO

GRANT EXECUTE ON OBJECT::dbo.SP_StatementAgents  
    TO ProfitSharing_User;  
GO
