
-- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
-- NOTE: when copying to project or SSRS need to remove the "select * from " from the "select * from @agent_ids" subqueries
-- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

declare @agent_ids_str nvarchar(max);
declare @year int;
declare @month int;
set @agent_ids_str = '["05240"]'; --"84694","83806","83860", "84880"
set @year = 2019;
set @month = 11;

DECLARE @agent_id TABLE (Value nvarchar(255))
insert into @agent_id select value from openjson(@agent_ids_str);

select top 1 agnt.cdkey2, agnt.agynam, agnt.agyad1, agnt.agyad2, agnt.agycty, agnt.agyst, agnt.agyzip, agnt.regofc, info.MKTTER, 
case when coalesce(addc.IsEnabled, 0) = 0 then 'NO' else 'YES' end as lossLock,
round(case when adda.MinPremium is null then coalesce(minprem.Premium, 0) else adda.MinPremium end, 0) as minPremium
from DWXF007 agnt
join DWXF108 info on info.cdkey2 = agnt.cdkey2
left outer join Addendumc addc on addc.AgentId = agnt.cdkey2
left outer join Addenduma adda on adda.AgentCode = agnt.cdkey2 and adda.Year = @year and adda.IsEnabled = 1
left outer join MarketingTerritoryAssignment mkt on mkt.MarketingTerritory = info.MKTTER and mkt.EffectiveYear = @year
left outer join PlanManagement pmgt on pmgt.PlanInformation_id = mkt.PlanInformation_id and  @year between pmgt.StartYear and pmgt.EndYear
left outer join PlanInformation planinfo on planinfo.Id = pmgt.PlanInformation_id
left outer join MinWrittenPremium minprem on minprem.PlanInformation_id = planinfo.Id and @year between minprem.StartYear and minprem.EndYear
where agnt.cdkey2 in (select * from @agent_id)
 
