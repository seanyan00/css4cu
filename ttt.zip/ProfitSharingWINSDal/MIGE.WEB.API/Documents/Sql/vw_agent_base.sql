IF OBJECT_ID ( 'vw_agent_base', 'V' ) IS NOT NULL   
    DROP VIEW vw_agent_base; 
GO

SET QUOTED_IDENTIFIER ON
GO


--CREATE VIEW [dbo].[vw_agent_base] AS
--	select base.CDKEY2 as CDKEY2
--		, min(rtrim(base.AGYCDE)) as AGYCDE
--		, min(rtrim(base.CDDESC)) as CDDESC
--		, min(base.ENDDTE) as ENDDTE
--		, min(rtrim(base.REGOFC)) as REGOFC
--		, min(base.STRTYR) as STRTYR
--		, min(base.MKTTER) as MKTTER
--		, min(round(base.APPDTE / 100, 0)) as APPDTE
--	from dbo.DWXF007 as base
--	group by base.CDKEY2;

CREATE VIEW [dbo].[vw_agent_base] AS
	select base.CDKEY2 as CDKEY2
		, min(rtrim(base.AGYCDE)) as AGYCDE
		, min(rtrim(base.CDDESC)) as CDDESC
		, min(base.ENDDTE) as ENDDTE
		, min(rtrim(base.REGOFC)) as REGOFC
		, min(base.STRTYR) as STRTYR
		, min(base.MKTTER) as MKTTER
		, min(round(base.APPDTE / 100, 0)) as APPDTE
		, coalesce(
			(select top 1 round(EFFDTE / 100, 0) from dbo.DWXF007 where CDKEY2 = base.CDKEY2 and CDKEY1 = 'MMIC'),
			(select top 1 round(EFFDTE / 100, 0) from dbo.DWXF007 where CDKEY2 = base.CDKEY2 and CDKEY1 = 'MNIC'),
			min(round(base.EFFDTE / 100, 0))) as EFFDTE
	from dbo.DWXF007 as base
	group by base.CDKEY2;

GO

