IF OBJECT_ID ( 'SP_StatementTopTotal', 'P' ) IS NOT NULL   
    DROP PROCEDURE SP_StatementTopTotal;  
GO
 
CREATE PROCEDURE dbo.SP_StatementTopTotal(
	@agent_ids_str nvarchar(max),
	@year int,
	@month int,
	@as_sub int = 0)
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @agent_ids TABLE (Value nvarchar(255))
	insert into @agent_ids select value from openjson(@agent_ids_str);

	with
		mstr_sub as (select CDKEY2, case when @as_sub = 1 then CDKEY2 else IIF(AGYCDE = '', CDKEY2, AGYCDE) end as AGYCDE
			from DWXF007 where not exists (select top 1 AGENT from AgentQualification where [YEAR] = @year)
			union
			select AGENT as CDKEY2, case when @as_sub = 1 then AGENT else AGYCDE end as AGYCDE
			from AgentQualification where [YEAR] = @year
		)
		, sub_agents as (select distinct CDKEY2 from mstr_sub where CDKEY2 in (select * from @agent_ids) or AGYCDE in (select * from @agent_ids)
		)
		, year_products as (select * from product where Year = @year
		)
		, sums_cte as (select 
			sum(ADJWRTPREM) as ADJWRTPREM,
			sum(WRITEPREM) as WRITEPREM,
			sum(CHARGEOFFS) as CHARGEOFFS,
			sum(CHGOFFDIVD) as CHGOFFDIVD,
			sum(INCCREDEXP) as INCCREDEXP,
			sum(ADJEARPREM) as ADJEARPREM,
			sum(EARNEDPREM) as EARNEDPREM,
			sum(INCLOSSSTP) as INCLOSSSTP,
			sum(INCLOSSACT) as INCLOSSACT
			from (select
						agnt.AGYCDE as AGENT,
						prem.PROD,
						prem.ACTDTE,
						prem.ADJWRTPREM,
						prem.WRITEPREM,
						 --special case for value used in growth rate calculation
						case when ter.IncludePersonalLines = 1 or prem.prod in (select Code from MigProduct where [Type] = 'regular') then prem.WRITEPREM end GR_WRITEPREM,
						prem.CHARGEOFFS,
						prem.CHGOFFDIVD,
						case when Product.ProductName is not null then INCCREDEXP end INCCREDEXP,
						case when Product.ProductName is not null then ADJEARPREM end ADJEARPREM,
						case when Product.ProductName is not null then EARNEDPREM end EARNEDPREM,
						case when Product.ProductName is not null then INCLOSSSTP end INCLOSSSTP,
						case when Product.ProductName is not null then INCLOSSACT end INCLOSSACT
					from DWXM00101M as prem with (nolock)
					inner join mstr_sub as agnt with (nolock) on 
						agnt.CDKEY2 = prem.AGENT
					inner join (select distinct cdkey2, MKTTER from DWXF007) as d7 on
						prem.AGENT = d7.CDKEY2
					left outer join MarketingTerritoryAssignment as ter with(nolock) on 
						ter.MarketingTerritory = d7.MKTTER and 
						ter.EffectiveYear = @year
					left join Product on
						prem.prod = Product.ProductName and
						Product.[Year] = @year) as data
			where data.actdte = @year * 100 + @month
				and data.agent in (select * from @agent_ids)
		)
		, loss_ratio_cte as (select case when cur.EARNEDPREM = 0 then 0 else cur.INCLOSSSTP / cur.EARNEDPREM * 100 end as loss_ratio
			from sums_cte cur
		)
	select 'Total' as PROD, 
	ADJWRTPREM,
	CHGOFFDIVD,
	WRITEPREM,	-- coll 3
	ADJEARPREM,
	EARNEDPREM,	-- coll 5
	INCCREDEXP,
	INCLOSSACT,
	INCLOSSSTP,
	loss_ratio_cte.loss_ratio AS LOSS_RATIO,
	(select count(*) from sub_agents) as subagent_cnt
	from sums_cte, loss_ratio_cte
END
GO

GRANT EXECUTE ON OBJECT::dbo.SP_StatementTopTotal  
    TO ProfitSharing_User;  
GO
