﻿using MIG.WEB.API.Data;
using MIG.WEB.API.Models;
using MIGE.Core.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Web.Http;
using System.Web.Http.Cors;

namespace MIG.WEB.API.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [Route("api/[controller]")]
    public class PlanManagementController : ApiController
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();


       
        [HttpPost]
        [Route("api/AddNewPlanToManage")]
        public IHttpActionResult AddNewPlanToManage([FromBody] PlanManagementDTO planManagement)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.AddNewPlanToManage(planManagement));
        }
       

        [HttpPost]
        [Route("api/EditPlanToManage")]
        public IHttpActionResult EditPlanToManage([FromBody] PlanManagementDTO planManagement)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.EditPlanToManage(planManagement));
        }

        [HttpGet]
        [Route("api/GetPlanToManageByPlanManageId/{planManagementId}")]
        public IHttpActionResult GetPlanToManageByPlanManageId(int planManagementId)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.GetPlanToManageById(planManagementId));
        }

        [HttpGet]
        [Route("api/GetAllPlansToManageByPlanInfoId/{planInformationId}")]
        public IHttpActionResult GetAllPlansToManageByPlanInfoId(int planInformationId)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.GetAllPlansToManage(planInformationId));
        }


    }
}
