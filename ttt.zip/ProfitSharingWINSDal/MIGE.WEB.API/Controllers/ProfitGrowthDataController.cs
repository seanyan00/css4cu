﻿using MIG.WEB.API.Data;
using MIGE.Core.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Web.Http;
using System.Web.Http.Cors;

namespace MIG.WEB.API.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [Route("api/[controller]")]
    public class ProfitGrowthDataController : ApiController
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();


        /// <summary>
        /// Takes in SheetNames enum as ID and data(json format) as string 
        /// </summary>
        /// <param name="profitGrowthFactor"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/AddTable")]
        public IHttpActionResult AddTable(
			[FromBody] ProfitGrowthFactors profitGrowthFactor)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();

			//switch (profitGrowthFactor.TableNames) {
			//	case TableNames.PremiumVolumeLossRatio:
			//		return Ok(context.AddPremiumVolumeLossRatio(profitGrowthFactor));

			//	default:
					return Ok(context.AddGrowthFactor(profitGrowthFactor));
			//}
        }


        /// <summary>
        /// Gets the JSON file for growth factor
        /// </summary>
        /// <param name="growthFactorId">This is the ID for the growth factor table</param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/GetTable")]
        public IHttpActionResult GetTable(
			[FromBody] int growthFactorId)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.GetGrowthFactor(growthFactorId));
        }


        /// <summary>
        /// Pass in the Profit Growth factor entity
        /// </summary>
        /// <param name="profitGrowthFactor"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/UpdateTable")]
        public IHttpActionResult UpdateTable(
			[FromBody] ProfitGrowthFactors profitGrowthFactor)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.UpdateGrowthFactor(profitGrowthFactor));
        }


        /// <summary>
        /// Pass in the table type to get an array for that table
        /// </summary>
        /// <param name="tableType"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/GetTables")]
        public IHttpActionResult GetTables(
			[FromBody] TableNames tableType)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.GetAllDataByTable(tableType));
        }
    }
}
