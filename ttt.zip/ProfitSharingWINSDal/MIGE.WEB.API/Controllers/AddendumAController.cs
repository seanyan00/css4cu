﻿using System;
using System.Reflection;
using System.Web.Http;
using System.Web.Http.Cors;
using MIG.WEB.API.Data;
using MIG.WEB.API.Models;

namespace MIG.WEB.API.Controllers
{


    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [Route("api/[controller]")]
    public class AddendumAController : ApiController
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();


		[HttpPost]
		[Route("api/SaveAddendumA")]
		public IHttpActionResult SaveAddendumA(
			[FromBody] AddendumADTO addendumA)
		{
			logger.Debug(MethodInfo.GetCurrentMethod());
			DataContext context = new DataContext();
			return Ok(context.SaveAddendumA(addendumA));
		}


		[HttpPost]
        [Route("api/AddAddendumA")]
        public IHttpActionResult AddAddendumA(
			[FromBody] AddendumADTO addendumA)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.AddAddendumA(addendumA));
        }


        [HttpPost]
        [Route("api/UpdateAddendumA")]
        public IHttpActionResult UpdateAddendumA(
			[FromBody] AddendumADTO addendumA)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.UpdateAddendumA(addendumA));
        }


        [HttpPost]
        [Route("api/GetAddendumAByAgentCode/{agentCode}")]
        public IHttpActionResult GetAddendumAByAgentCode(
			string agentCode)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.GetAddendumAByAgentCode(agentCode));
        }


        [HttpPost]
        [Route("api/UpdateAddendumAByAgentCode")]
        public IHttpActionResult UpdateAddendumAByAgentCode(
			[FromBody] AddendumADTO addendumADTO)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.UpdateAddendumAByAgentCode(addendumADTO));
        }


        [HttpPost]
        [Route("api/GetAll")]
        public IHttpActionResult GetAll()
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.GetAll());
        }
    }
}
