﻿using MIG.WEB.API.Data;
using MIG.WEB.API.Models;
using MIGE.Core.Domain;
using System.Reflection;
using System.Web.Http;
using System.Web.Http.Cors;

namespace MIG.WEB.API.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [Route("api/[controller]")]
    public class PlanInformationController : ApiController
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();


        /// <summary>
        /// Takes in SheetNames enum as ID and data(json format) as string 
        /// </summary>
        /// <param name="profitGrowthFactor"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/AddPlan")]
        public IHttpActionResult AddPlan(
			[FromBody] PlanInformaionDTO planInformation)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.AddPlan(planInformation));
        }


        /// <summary>
        /// Takes in SheetNames enum as ID and data(json format) as string 
        /// </summary>
        /// <param name="profitGrowthFactor"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/EditPlan")]
        public IHttpActionResult EditPlan(
			[FromBody] PlanInformation planInformation)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.EditPlan(planInformation));
        }

        /// <summary>
        /// Takes in single planId as ID and checks if it can be deleted 
        /// </summary>
        /// <param name="planId"></param>
        /// <returns></returns>
        [HttpDelete]
        [Route("api/DeletePlan/{id}")]
        public IHttpActionResult DeletePlan(int id)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.DeletePlan(id));
        }

        /// <summary>
        /// Takes in single planId as ID and disable/enable it 
        /// </summary>
        /// <param name="planId"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/EnableDisablePlan/{id}/{disable}")]
        public IHttpActionResult EnableDisablePlan(int id, int disable)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.EnableDisablePlan(id, disable));
        }


        /// <summary>
        /// Get plan information by the plan id
        /// </summary>
        /// <param name="planInformationId"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/GetPlanInformationById")]
        public IHttpActionResult GetPlanInformationById(
			[FromBody] int planInformationId)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.GetPlanInformationById(planInformationId));
        }


        /// <summary>
        /// gets all the plans in the database
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/GetAllPlans")]
        public IHttpActionResult GetAllPlans()
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.GetAllPlans());
        }
    }
}
