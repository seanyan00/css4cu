﻿using MIG.WEB.API.Data;
using MIGE.Core.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Web.Http;
using System.Web.Http.Cors;

namespace MIG.WEB.API.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [Route("api/[controller]")]
    public class AddendumAGrowthPercentageController : ApiController
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        [HttpGet]
        [Route("api/GetAllAddAGrowthPercentages/{planId}")]
        public IHttpActionResult GetAllAddAGrowthPercentagesByPlanId([FromUri] int planId)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.GetAllAddAGrowthPercentagesByPlanId(planId));
        }
        
        [HttpPost]
        [Route("api/AddAddAGrowthPerentage")]
        public IHttpActionResult AddAddAGrowthPerentage([FromBody] AddendumAGrowthPercentage addendumAGrowthPercentage)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.AddAddAGrowthPerentageToPlan(addendumAGrowthPercentage));
        }
        
        [HttpPost]
        [Route("api/UpdateAddAGrowthPercentage")]
        public IHttpActionResult UpdateAddAGrowthPercentage([FromBody] AddendumAGrowthPercentage addendumAGrowthPercentage)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.UpdateAddAGrowthPercentage(addendumAGrowthPercentage));
        }


        [HttpPost]
        [Route("api/GetAllAddendumAGrowthPercentage")]
        public IHttpActionResult GetAllAddendumAGrowthPercentage()
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.GetAllAddendumAGrowthPercentage());
        }

    }
}
