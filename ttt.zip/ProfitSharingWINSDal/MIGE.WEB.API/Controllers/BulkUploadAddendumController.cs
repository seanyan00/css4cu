﻿using MIG.WEB.API.Data;
using System;
using System.Web;
using System.Web.Http;
using System.Reflection;
using System.Web.Http.Cors;
using MIGE.Core.Domain;
using MIG.WEB.API.Models;

namespace MIG.WebAPI.Controllers
{


	[EnableCors(origins: "*", headers: "*", methods: "*")]
	[Route("api/[controller]")]
	public class BulkUploadAddendumController : ApiController
	{
		private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();


		[HttpPost]
		[Route("api/AddBulkAddendumA")]
		public IHttpActionResult AddBulkAddendumA(
			[FromBody] AddendumADTO[] addendumA)
		{
			logger.Debug(MethodInfo.GetCurrentMethod());
			DataContext context = new DataContext();
			return Ok(context.AddBulkAddendumA(addendumA));
		}


		[HttpPost]
		[Route("api/AddBulkAddendumC")]
		public IHttpActionResult AddBulkAddendumC(
			[FromBody] Addendumc[] addendumc)
		{
			logger.Debug(MethodInfo.GetCurrentMethod());
			DataContext context = new DataContext();
			return Ok(context.AddBulkAddendumC(addendumc));
		}


		[HttpPost]
		[Route("api/BulkFileAddendumC")]
		public IHttpActionResult BulkFileAddendumC()
		{
			logger.Debug(MethodInfo.GetCurrentMethod());

			try {
				Addendumc[] addendumCs = null;
				var request = HttpContext.Current.Request;

				if (request.Files.Count > 0) {
					DataContext context = new DataContext();

					addendumCs = context.BulkFileAddendumC(request.Files);
				}

				return Ok(addendumCs);
			} catch (Exception e) {
				throw;
			}
		}
	}
}
