﻿using MIG.WEB.API.Data;
using MIGE.Core.Domain;
using System.Reflection;
using System.Web.Http;
using System.Web.Http.Cors;

namespace MIG.WEB.API.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [Route("api/[controller]")]
    public class ProductController : ApiController
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

       /// <summary>
       /// Gets all products from AS400
       /// </summary>      
       /// <returns></returns>
        [HttpGet]
        [Route("api/GetAllProducts")]
        public IHttpActionResult GetAllProducts()
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.GetAllProducts());
        }

        /// <summary>
        /// Add product
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/AddProduct")]
        public IHttpActionResult AddProduct([FromBody] Product product)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.AddProduct(product));
        }

        /// <summary>
        /// Add product
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/UpdateProduct")]
        public IHttpActionResult UpdateProduct([FromBody] Product product)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.UpdateProduct(product));
        }
        /// <summary>
        /// Get all distinct years
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/GetAllYears")]
        public IHttpActionResult GetAllYears()
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.GetAllYears());
        }

        /// <summary>
        /// Get all products for a year
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("api/GetAllProductsByYear/{year}")]
        public IHttpActionResult GetAllProductsByYear([FromUri] int year)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.GetAllProductsByYear(year));
        }

        [HttpGet]
        [Route("api/GetAllProductsForAllYears")]
        public IHttpActionResult GetAllProductsForAllYears()
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.GetAllProductsForAllYears());
        }
    }
}
