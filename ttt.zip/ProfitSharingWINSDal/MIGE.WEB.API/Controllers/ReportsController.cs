﻿using System;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;
using System.IO;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using MIG.WEB.API.Data;
using MIG.WEB.API.Models;
using MIG.WindowsService.Processor;
using MIG.Utilities;
using Newtonsoft.Json;
using System.Xml.Linq;
using System.Text.RegularExpressions;

namespace MIG.WEB.API.Controllers
{

	[EnableCors(origins: "*", headers: "*", methods: "*")]
	[Route("api/[controller]")]
	public class ReportsController : ApiController
	
	{
		private const string CONFIG_LOG_PATH = "logPath";

		private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        //TODO:
        [HttpPost]
        [Route("api/ProfitSharingAgentRollupReport/{year}/{month}")]
        public IHttpActionResult ProfitSharingAgentRollupReport(

            [FromUri] int year,
            [FromUri] int month,          
            [FromBody] string[] agentIds)
        {

			logger.Debug(MethodInfo.GetCurrentMethod());
			DataContext context = new DataContext();
			return Ok(context.ProfitSharingAgentRollupReport(agentIds, year, month));

		}

		[HttpPost]
		[Route("api/ProfitSharingGetSubAgents/")]
		public IHttpActionResult ProfitSharingGetSubAgents(

			[FromBody] string[] agentIds)
		{

			logger.Debug(MethodInfo.GetCurrentMethod());
			DataContext context = new DataContext();
			return Ok(context.ProfitSharingGetSubAgents(agentIds));
		}

		/// <summary>
		/// Central API to generate the reports based on type of report to be generated
		/// Simply create context class and call generate method with passed in parameters
		/// </summary>
		/// <remarks>
		/// Body of post request will be string array of the requested agentIds as such:
		///			["00779","00696"]
		/// </remarks>
		/// <param name="format">The type of report to generate</param>
		/// <param name="year">Year for report</param>
		/// <param name="month">Month for report</param>
		/// <param name="asSub">Sub agents?</param>
		/// <param name="includeBottom">Include bottom page?</param>
		/// <param name="agentIds">Array of agent ids</param>
		/// <returns>Returns the report in the format that is passed in from the format parameter(ex: pdf,excel,csv)</returns>
		/// 

		[HttpPost]
		[Route("api/ProfitSharingReportGenerator/{format}/{year}/{month}/{asSub?}/{includeBottom?}")]
		public HttpResponseMessage ProfitSharingReportGeneration(
			[FromUri] string format,
			[FromUri] int year,
			[FromUri] int month,
			[FromBody] string[] agentIds,
			[FromUri] bool asSub,
			[FromUri] bool includeBottom = false)
		{
			DataContext context = new DataContext();
			int includeSubAgents = asSub == true ? 0 : 1;
			byte[] report; 
			//byte[] report = context.GenerateProfitSharingReport(agentIds, year, month, includeBottom, includeSubAgents, "Profit Sharing Master_REVISED", format);
			//Needed for Gregs changes
			if(agentIds.Length > 1) // if the agentIds.Length is > 1, we are trying to generate a combined report. 
            {
				//report = includeSubAgents == 1 ? context.GenerateProfitSharingCombinedReport(agentIds, year, month, includeBottom, includeSubAgents, "Profit Sharing Sub-Agent Report_REVISED", format) :
				report = context.GenerateProfitSharingCombinedReport(agentIds, year, month, includeBottom, includeSubAgents, "Profit Sharing Combined Report_REVISED", format);
			}
            else // agentId length is 1, so we just are only creating a report from a single agent. 
            {
				report = includeSubAgents == 1 ? context.GenerateProfitSharingReport(agentIds[0], year, month, includeBottom, includeSubAgents, "AGENT", "Profit Sharing Sub-Agent Report_REVISED", format) :
				context.GenerateProfitSharingReport(agentIds[0], year, month, includeBottom, includeSubAgents, "AGENT", "Profit Sharing Master Rollup Report_REVISED", format);
			}
			


			var result = new HttpResponseMessage(HttpStatusCode.OK) { 
				Content = new ByteArrayContent(report)
			};

			result.Content.Headers.ContentDisposition =
					new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment")
					{
						FileName = "ProfitSharingReport." + format.ToLower()
					};
			result.Content.Headers.ContentType =
					new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");

			return result;
		}

        // Only need one controller to handle different formats to generate the reports

        //[HttpPost]
        //[Route("api/ProfitSharingReportTopAsCsv/{year}/{month}")]
        //public HttpResponseMessage ProfitSharingReportTopAsCsv(
        //	[FromUri] int year,
        //	[FromUri] int month,
        //	[FromBody]  string[] agentIds)
        //{
        //	logger.Debug(MethodInfo.GetCurrentMethod());
        //	DataContext context = new DataContext();
        //	//return Ok(context.ProfitSharingReportTopAsCvs(agentIds, year, month));

        //	byte[] csv = context.ProfitSharingReportTopAsCsv(agentIds, year, month);
        //	var result = new HttpResponseMessage(HttpStatusCode.OK) {
        //		Content = new ByteArrayContent(csv)
        //	};
        //	result.Content.Headers.ContentDisposition =
        //			new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment") {
        //				//					FileName = "CertificationCard.pdf"
        //			};
        //	result.Content.Headers.ContentType =
        //			new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");

        //	return result;
        //}


        //[HttpPost]
        //[Route("api/ProfitSharingReportAsPdf/{year}/{month}/{asSub}/{includeBottom}")]
        //public HttpResponseMessage ProfitSharingReportAsPdf(
        //	[FromUri] int year,
        //	[FromUri] int month,
        //	[FromBody]  string[] agentIds,
        //	[FromUri] bool asSub,
        //	[FromUri] bool includeBottom = false
        //	)
        //{
        //	logger.Debug(MethodInfo.GetCurrentMethod());
        //	DataContext context = new DataContext();

        //	int includeSubAgents = asSub == true ? 0 : 1;

        //	byte[] pdf = context.ProfitSharingReportAsPdf(agentIds, year, month, includeBottom, includeSubAgents);
        //	var result = new HttpResponseMessage(HttpStatusCode.OK) {
        //		Content = new ByteArrayContent(pdf)
        //	};
        //	result.Content.Headers.ContentDisposition =
        //			new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment") {
        //				FileName = "ProfitSharingReport.pdf"
        //			};
        //	result.Content.Headers.ContentType =
        //			new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");

        //	return result;
        //}


        //[HttpPost]
        //[Route("api/ProfitSharingReportAsExcel/{year}/{month}/{asSub}/{includeBottom}")]
        //public HttpResponseMessage ProfitSharingReportAsExcel(
        //	[FromUri] int year,
        //	[FromUri] int month,
        //	[FromBody]  string[] agentIds,
        //	[FromUri] bool asSub,
        //	[FromUri] bool includeBottom = false)
        //{
        //	logger.Debug(MethodInfo.GetCurrentMethod());
        //	DataContext context = new DataContext();

        //	int includeSubAgents = asSub == true ? 0 : 1;

        //	byte[] file = context.ProfitSharingReportAsExcel(agentIds, year, month, includeBottom, includeSubAgents);
        //	var result = new HttpResponseMessage(HttpStatusCode.OK) {
        //		Content = new ByteArrayContent(file)
        //	};
        //	result.Content.Headers.ContentDisposition =
        //			new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment") {
        //				FileName = "ProfitSharingReport.xls"
        //			};
        //	result.Content.Headers.ContentType =
        //			new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");

        //	return result;
        //}


        /// <summary>
        /// Generates bulk PDF Profit Sharing statements.
        /// </summary>
        /// <remarks>
        /// ProfitSharingReportAsPdfBulk can either take a list of agent IDs to generate statements for, or generate statements
        /// for all applicable agents for the given year/month. To generate statements for all applicable agents exclude the 
        /// "agentIds" property from the request body.<br/><br/>
        /// 
        /// Body of request is of the form:
        /// <code>
        ///		{
        ///			"agentIds": ["84694","83806","83860", "84880"],
        ///			"asZip": "false",
        ///			"orderBy": "Agent|Region",
        ///			"includeZeroPayment": "true"
        ///		}
        /// </code>
        ///  
        /// where: <br/>
        /// <strong>agentIds</strong> is the optional list of agent IDs to generate statements for.<br/>
        /// <strong>asZip</strong> is "true" to generate a zip file of the bulk PDF statements, or "false" to generate a single PDF
        /// where each page is a statement for the given agent IDs.<br/>
        /// <strong>orderBy</strong> is only applicable for "all" agents, when no agentIds value is provided. Value of "agent" sorts
        /// the generated statements by agent ID. A value of "region" sorts the statements by region, territory, then agent ID.
        /// Defaults to "agent".<br/>
        /// <strong>includeZeroPayment</strong> is only applicable for "all" agents, when no agentIds value is provided. If "true" all
        /// agents are included, including those with payment of $0. If "false" only agents with payment > $0 will be included.
        /// Defaults to false if not provided.
        /// 
        /// </remarks>
        /// <param name="year">Year of statements.</param>
        /// <param name="month">Month of statements.</param>
        /// <param name="includeBottom">True if the bottom, calculations portion of the report is to be included, false if not.</param>
        /// <param name="data">Additional Report Data</param>
        /// <returns>New Created Todo Item</returns>
        [System.Web.Http.HttpPost]
		[Route("api/ProfitSharingReportAsPdfBulk/{year}/{month}/{includeBottom}")]
		public HttpResponseMessage ProfitSharingReportAsPdfBulk(
			[FromUri] int year,
			[FromUri] int month,
			[FromUri] bool includeBottom,
			[FromBody] JObject data)
		{
            try
            {
                logger.Debug(MethodInfo.GetCurrentMethod());
                DataContext context = new DataContext();
                string orderBy = data["orderBy"].ToObject<string>().ToUpper();

                //  get sort field
                if (orderBy != "REGION")
                {
					orderBy = "AGENT";
                }

                byte[] outFile = context.ProfitSharingReportAsPdfBulk(year, month, includeBottom, orderBy).Result;
                
				var result = new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new ByteArrayContent(outFile)
                };

                string ext = data["asZip"].ToObject<bool>() ? "zip" : "pdf";
                result.Content.Headers.ContentDisposition =
                        new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment")
                        {
                            FileName = "ProfitSharingReport." + ext
                        };
                result.Content.Headers.ContentType =
                        new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");
                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }
		}
		

		//TODO:

		[HttpPost]
		[Route("api/ProfitSharingAgentOnlyReport/{year}/{month}")]
		public IHttpActionResult ProfitSharingAgentOnlyReport(
			[FromUri] int year,
			[FromUri] int month,	
			[FromBody]  string[] agentIds)
		{
			logger.Debug(MethodInfo.GetCurrentMethod());
			DataContext context = new DataContext();
			return Ok(context.ProfitSharingAgentOnlyReport(agentIds, year, month));
		}


		/// <summary>
		/// Generates custom report for agents, Excel format.
		/// </summary>
		/// <remarks>
		/// Body of request is of the form:
		/// <code>
		///		{
		///			"fields": ["AgentId", "Office", "Name", "AdjustedWrittenPremiums", "NetAdjustedWrittenPremiums", "AdjustedEarnedPremiums", "NetAdjustedEarnedPremiums", "ChargeOffs", 
		///					"ChargeOffsWCDividends", "IncurredLossAfterStopLoss", "IncurredLossBeforeStopLoss", "LossAdjustmentExpense", "Territory", "ThreeYearProfitPct", "PrevYrAdjWPDec", 
		///					"PrevYrAdjWPMonth", "ActualEarnedPremium", "GrowthRate", "LossRatio", "LossRatioFactor", "GrowthFactor", "NineMonthLossLock", "ThreeYearProfitFactor",
		///					"AppDate", "AddAEnabled", "MinPremium", "Payment"]
		///			"orderBy": "Default|Region|Territory",
		///			"includeNonPaymentAgents": "true|false"
		///		}
		/// </code>
		///  
		/// where "fields" is an array of any of the acceptible fields to include in the report,
		/// "orderBy" defines how the record in the report are order
		/// 
		/// </remarks>
		[HttpPost]
		[Route("api/ProfitSharingCustomReport/{year}/{month}")]
		public HttpResponseMessage ProfitSharingCustomReport(
			[FromUri] int year,
			[FromUri] int month,
			[FromBody] JObject data)
		{
			CustomReportFields fields = CustomReportFields.None;
			CustomReportSort sort = CustomReportSort.Default;
			bool includeNonPaymentAgents = false;

			logger.Debug(MethodInfo.GetCurrentMethod());

			try {
				string[] fieldAry = data["fields"].ToObject<string[]>();
				if ((fieldAry != null) && (fieldAry.Length > 0)) {
					foreach (string fld in fieldAry) {
						fields |= (CustomReportFields)Enum.Parse(typeof(CustomReportFields), fld);
					}
				}

				sort = (CustomReportSort)Enum.Parse(typeof(CustomReportSort), data["orderBy"].ToObject<string>());

				includeNonPaymentAgents = data["includeNonPaymentAgents"].ToObject<bool>();
			} catch (Exception e) {

			}

			DataContext context = new DataContext();
			byte[] file = context.ProfitSharingCustomReport(year, month, fields, sort, includeNonPaymentAgents);

			var result = new HttpResponseMessage(HttpStatusCode.OK) {
				Content = new ByteArrayContent(file)
			};
			result.Content.Headers.ContentDisposition =
					new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment") {
						FileName = "CustomReport.xls"
					};
			result.Content.Headers.ContentType =
					new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");

			return result;
		}


		[HttpPost]
		[Route("api/ProfitSharingReportByAgentId/{agentId}/{period}")]
		public IHttpActionResult ProfitSharingReportByAgentId(
			string agentId,
			decimal period)
		{
			logger.Debug(MethodInfo.GetCurrentMethod());
			DataContext context = new DataContext();
			return Ok(context.ProfitSharingReportByAgentId(agentId, period));
		}


		[HttpPost]
		[Route("api/GetAllTimePeriods")]
		public IHttpActionResult GetAllTimePeriods()
		{
			logger.Debug(MethodInfo.GetCurrentMethod());
			DataContext context = new DataContext();
			return Ok(context.GetAllTimePeriods());
		}


		[HttpPost]
		[Route("api/GetWrittenPremiumAndLossRatio/{year}/{agentId}")]
		public IHttpActionResult GetWrittenPremiumAndLossRatio(
			int year,
			string agentId)
		{
			logger.Debug(MethodInfo.GetCurrentMethod());
			DataContext context = new DataContext();
			return Ok(context.GetWrittenPremiumAndLossRatio(year, agentId));
		}


		[HttpGet]
		[Route("api/GetLog/{logName?}")]
		public IHttpActionResult GetLog(
			[FromUri] string logName = null)
		{
			string logPath = System.Configuration.ConfigurationManager.AppSettings[CONFIG_LOG_PATH] ?? "log";
			logPath = Path.Combine(HttpRuntime.AppDomainAppPath, logPath);

					//  no log specified, get list of logs
			if (string.IsNullOrEmpty(logName)) {
				try {
					DirectoryInfo di = new DirectoryInfo(logPath);
					var logFiles = di.GetFiles().Select(fi => new { fi.Name, fi.Length });
					return Ok(logFiles);
				} catch (Exception e) {
					return InternalServerError(e);
				}

					//  log specified - fetch log contents
			} else {
				try {
					string logFile = Path.Combine(logPath, logName + ".log");
					string[] contents = File.ReadAllLines(logFile);
					return Ok(contents);
				} catch (Exception e) {
					return InternalServerError(e);
				}
			}
		}


		[HttpGet]
		[Route("api/StartProcessing")]
		public IHttpActionResult StartProcessing()
		{
			string status = "ETL completed";

			if (!System.Diagnostics.EventLog.SourceExists("MIGE.SQLDumpService")) {
				System.Diagnostics.EventLog.CreateEventSource(
					"MIGE.SQLDumpService", "MIGE.SQLDumpService.Log");
			}

			Logger.Log(MethodInfo.GetCurrentMethod().Name, Logger.LogLevel.DEBUG, null, "etl");
			//eventLog1.Source = "MIGE.SQLDumpService";
			//eventLog1.Log = "MIGE.SQLDumpService.Log";
			//logger.Debug(MethodInfo.GetCurrentMethod());

			if (!ServiceProcessor.isExecuting)  {
				try {
					ServiceProcessor.StartProcessing();
				} catch (Exception e) {
					status = string.Format("ETL error: {0}", e.Message);
				}
			} else {
				status = "ETL is already running";
			}

			return Ok(status);
		}
	}


	public enum CustomReportSort
	{
		Default = 0,
		Territory,
		Region
	}


	[Flags]
	public enum CustomReportFields
	{
		None = 0,
		AgentId = 1,													// CDKEY2
		Office = AgentId * 2,											// REGOFC
		Name = Office * 2,												// CDDESC
		AdjustedWrittenPremiums = Name * 2,								// ADJWRTPREM
		NetAdjustedWrittenPremiums = AdjustedWrittenPremiums * 2,		// WRITEPREM
		AdjustedEarnedPremiums = NetAdjustedWrittenPremiums * 2,		// ADJEARPREM
		NetAdjustedEarnedPremiums = AdjustedEarnedPremiums * 2,			// EARNEDPREM
		ChargeOffs = NetAdjustedEarnedPremiums * 2,						// CHARGEOFFS
		ChargeOffsWCDividends = ChargeOffs * 2,							// CHGOFFDIVD
		IncurredLossAfterStopLoss = ChargeOffsWCDividends * 2,			// INCLOSSSTP
		IncurredLossBeforeStopLoss = IncurredLossAfterStopLoss * 2,		// INCLOSSACT
		LossAdjustmentExpense = IncurredLossBeforeStopLoss * 2,			// INCCREDEXP
		Territory = LossAdjustmentExpense * 2,							// MKTTER
		ThreeYearProfitPct = Territory * 2,								// three_yr_prof
		PrevYrAdjWPDec = ThreeYearProfitPct * 2,						// prev_full_adj_wp
		PrevYrAdjWPMonth = PrevYrAdjWPDec * 2,							// prev_mnth_adj_wp
		ActualEarnedPremium = PrevYrAdjWPMonth * 2,						// earned_prem
		GrowthRate = ActualEarnedPremium * 2,							// growth_rate
		LossRatio = GrowthRate * 2,										// loss_ratio
		LossRatioFactor = LossRatio * 2,								// loss_ratio_factor
		GrowthFactor = LossRatioFactor * 2,								// growth_factor
		NineMonthLossLock = GrowthFactor * 2,							// NineMonthLock
		ThreeYearProfitFactor = NineMonthLossLock * 2,					// three_yr_prof_factor
		Payment = ThreeYearProfitFactor * 2,							// payment
		AppDate = Payment * 2,
		AddAEnabled = AppDate * 2,
		MinPremium = AddAEnabled * 2
	}
}
