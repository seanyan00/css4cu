﻿using System;
using System.IO;
using System.Web;
using System.Web.Http;
using System.Reflection;
using System.Web.Http.Cors;
using System.Collections.Generic;
using MIGE.Core.Domain;
using MIGE.Core.Domain.Dto;
using MIG.WEB.API.Data;
using Newtonsoft.Json;
using System.Web.Http.Results;
using Newtonsoft.Json.Linq;
using MIGE.Core.Agent;

namespace MIG.WebAPI.Controllers
{


    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [Route("api/[controller]")]
    //public class AgentInfoController  : ApiController
	public class AgentInfoController  : ApiController
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();
		 

        public AgentInfoController( )
        {            
        }

	    [HttpPost]
		[Route("api/AgentInfo/GetPagedAgents")]
		public JObject GetPagedAgent([FromBody] dynamic postdata)
		{
			try
			{
				JObject jObject = JObject.Parse(postdata.ToString());
				PagingInfo pagingInfo = jObject["PagingInformation"].ToObject<PagingInfo>();
				AgentListPaged alp = new AgentListPaged(pagingInfo);

				return JObject.FromObject(alp);

			}
			catch (Exception ex)
			{

				throw ex;
			}
		}

		[HttpPost]
		[Route("api/AgentInfo/GetAllMasterAgents")]
		public IHttpActionResult GetAllMasterAgents([FromBody] dynamic postdata)
		{
			try
			{
				DataContext context = new DataContext();
				return Ok(context.GetMasterAgentIds());
			}
			catch (Exception ex)
			{

				throw ex;
			}
		}

		[HttpPost]
		[Route("api/AgentInfo/GetAgent")]
		public JObject GetAgent([FromBody] dynamic postdata)
		{
				try
				{
					JObject jObject = JObject.Parse(postdata.ToString());

					string singleAgent = jObject["SingleAgent"].ToString();

					PagingInfo pagingInfo = jObject["PagingInformation"].ToObject<PagingInfo>();
					AgentListPaged alp = new AgentListPaged(pagingInfo, singleAgent);

					return JObject.FromObject(alp);

				}
				catch (Exception ex)
				{

					throw ex;
				}
		}

        [HttpGet]
        [Route("api/AgentInfo/GetAllAgents")]
        public JObject GetAllAgents()
        {

			try
			{
				AgencyInfo agencyInfo = new AgencyInfo();
				agencyInfo.GetAllAgents();
				return JObject.FromObject(agencyInfo);
			}
			catch (Exception ex)
			{

				throw ex;
			}
         //   logger.Debug(MethodInfo.GetCurrentMethod());
         //   DataContext context = new DataContext();
         //// context.GetAgents();

         //   return Ok(context.GetAgents());
		}


		/// <summary>
		/// Searches agents based on the provided criteria.
		/// </summary>
		/// <remarks>
		/// Body of request is of the form:
		/// <code>
		///		{
		///			"filter": {
		///				"Id": ["84694","83806"],
		///				"Territory": "016",
		///				"Region": "ESBC5",
		///				"AddendumAEnabled": "true",
		///				"AddendumCEnabled": "true",
		///				"IncludeCanceled": "true",
		///				"IncludeZeroPayments": "true",
		///				"Year": "2020",
		///				"Page": "1",
		///				"PageSize": "20"
		///			}
		///		}
		///	</code>
		///  
		/// Page defaults to "1" and PageSize to "15" if not provided.
		/// 
		/// </remarks>
		/// <returns>
		/// 
		/// </returns>
		[HttpPost]
		[Route("api/AgentInfo/Search")]
		public IHttpActionResult FindAgents(
			[FromBody] Newtonsoft.Json.Linq.JObject data)
		{
			logger.Debug(MethodInfo.GetCurrentMethod());
			DataContext context = new DataContext();

			var jsonFilter = data["filter"];
			DataContext.AgentFilter filter = new DataContext.AgentFilter(jsonFilter);

			if ((filter.AddendumAEnabled.HasValue || filter.AddendumCEnabled.HasValue || !string.IsNullOrEmpty(filter.Territory)) && !filter.Year.HasValue) {
				return BadRequest("AddendumAEnabled, AddendumCEnabled, and Territory cirteria require Year also be included.");
			}

			return Ok(context.FindAgents(filter));
		}


		/// <summary>
		/// Searches agents based on the provided criteria.
		/// </summary>
		/// <remarks>
		/// Body of request is of the form:
		/// <code>
		///		{
		///			"filter": {
		///				"Id": ["84694","83806"],
		///				"Territory": "016",
		///				"Region": "ESBC5",
		///				"AddendumAEnabled": "true",
		///				"AddendumCEnabled": "true",
		///				"IncludeCanceled": "true",
		///				"IncludeZeroPayments": "true",
		///				"IncludeSubagents": "true",
		///				"Year": "2020",
		///				"Page": "1",
		///				"PageSize": "20"
		///			}
		///		}
		///	</code>
		///  
		/// Page defaults to "1" and PageSize to "15" if not provided.
		/// 
		/// </remarks>
		/// <returns>
		/// 
		/// </returns>
		[HttpPost]
		[Route("api/AgentInfo/Search2")]
		public IHttpActionResult FindAgents2(
			[FromBody] Newtonsoft.Json.Linq.JObject data)
		{
			logger.Debug(MethodInfo.GetCurrentMethod());
			DataContext context = new DataContext();

			var jsonFilter = data["filter"];
			DataContext.AgentFilter filter = new DataContext.AgentFilter(jsonFilter);

			if ((filter.AddendumAEnabled.HasValue || filter.AddendumCEnabled.HasValue || !string.IsNullOrEmpty(filter.Territory)) && !filter.Year.HasValue) {
				return BadRequest("AddendumAEnabled, AddendumCEnabled, and Territory cirteria require Year also be included.");
			}

			return Ok(context.FindAgents2(filter));
		}


		/// <summary>
		/// Get the starting date (YYYYMM) of the given agent.
		/// </summary>
		/// <remarks>
		/// </remarks>
		/// <returns>
		/// ActualStartDate - the APPDTE for the given agent ID.
		/// CalculatedStartDate - the earliest APPDTE of any subagent of the given agent ID.
		/// </returns>
		[HttpGet]
		[Route("api/AgentInfo/StartDate/{agentCode}/{year?}")]
		public IHttpActionResult StartDate(
			[FromUri] string agentCode,
			[FromUri] int? year = null)
		{
			logger.Debug(MethodInfo.GetCurrentMethod());
			DataContext context = new DataContext();

			return Ok(context.AgentStartDate(agentCode, year));
		}


		[HttpGet]
        [Route("api/AgentInfo/TotalNumberOfAgents")]
        public IHttpActionResult TotalNumberOfAgents()
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            // context.GetAgents();

            return Ok(context.TotalNumberOfAgents());
        }


        [HttpGet]
        [Route("api/AgentInfo/GetAllAgentsPaginated/{pageNumber?}/{numberOfRecords?}")]
        public IHttpActionResult GetAllAgentsPaginated(
			[FromUri] int pageNumber = 0,
			[FromUri] int numberOfRecords = 15)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            // context.GetAgents();

            return Ok(context.GetAgents(pageNumber,numberOfRecords));
        }


		//[HttpGet]
		//[Route("~/api/AgentInfo/HasSubAgents/{agentId}/{year}")]
		//public IHttpActionResult GetSubAgents(
		//	[FromUri] string agentId,
		//	[FromUri] int? year)
		//{
		//	logger.Debug(MethodInfo.GetCurrentMethod());
		//	DataContext context = new DataContext();

		//	default to current year if not specified
		//	if (!year.HasValue)
		//	{
		//		year = DateTime.Now.Year;
		//	}

		//	return Ok(context.HasSubAgents(agentId.Trim(), year.Value));
		//}


		[HttpGet]
        [Route("api/AgentInfo/GetSubAgents/{agentId}/{year}/{pageNumber?}/{numberOfRecords?}")]
        public IHttpActionResult GetSubAgents(
			[FromUri] string agentId,
			[FromUri] int? year,
			[FromUri] int pageNumber = 0,
			[FromUri] int numberOfRecords = 15)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();

					//  default to current year if not specified
			if (!year.HasValue) {
				year = DateTime.Now.Year;
			}

			return Ok(context.GetSubAgents(agentId.Trim(), year.Value, pageNumber, numberOfRecords));
        }


        [HttpGet]
        [Route("api/AgentInfo/GetAgentById/{agentId}")]
        public IHttpActionResult GetAgentById(
			[FromUri] string agentId)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();

            return Ok(context.GetAgentById(agentId.Trim()));
        }


		[HttpPost]
		[Route("api/AgentInfo/SaveAddendumC/")]
		public IHttpActionResult SaveAddendumC(
			[FromBody]Addendumc addendumC)
		{
			logger.Debug(MethodInfo.GetCurrentMethod());
			DataContext context = new DataContext();
			return Ok(context.SaveAddendumC(addendumC));
		}


		[HttpPost]
		[Route("api/AgentInfo/AddAddendumC/")]
		public IHttpActionResult AddAddendumC(
			[FromBody]Addendumc addendumC)
		{
			logger.Debug(MethodInfo.GetCurrentMethod());
			DataContext context = new DataContext();
			//context.AddAddendumC(addendumC);
			//return Ok();
			return Ok(context.SaveAddendumC(addendumC));
		}
             

		[HttpPost]
		[Route("api/AgentInfo/UpdateAddC/")]
		public IHttpActionResult UpdateAddC(
			[FromBody] Addendumc addendumC)
		{
			logger.Debug(MethodInfo.GetCurrentMethod());
			DataContext context = new DataContext();
			//return Ok(context.UpdateAddC(addendumc));
			return Ok(context.SaveAddendumC(addendumC));
		}


		[Route("api/AgentInfo/YearEndLock/{year}")]
		public IHttpActionResult YearEndLock(
			[FromUri] int year)
		{
			logger.Debug(MethodInfo.GetCurrentMethod());
			DataContext context = new DataContext();

			try {
				context.YearEndLock(year);
				return Ok();
			} catch (Exception e) {
				return InternalServerError(e);
			}
		}


		//[HttpPost]
		//[Route("~/api/AgentInfo/AddendumCBulk/")]
		//public IHttpActionResult AddendumCBulk()
		//{
		//	logger.Debug(MethodInfo.GetCurrentMethod());

		//	try  {
		//		var request = HttpContext.Current.Request;

		//		if (request.Files.Count > 0) {
		//			var file = request.Files[0];

		//			int x = 1;
		//		}


		//		//var value = fileModel.Data;
		//		//var byteArray = Convert.FromBase64String(value);
		//		//var fileExtension = Path.GetExtension(fileModel.Name);
		//		//var fileName = fileModel.Name;

		//		/// Now save in Database or AWS

		//		DataContext context = new DataContext();

		//		return Ok();
		//	} catch (Exception e) {
		//		throw;
		//	}
		//}


		[HttpPost]
        [Route("api/AgentInfo/GetAdnCByAgentId/{agentId}")]
        public IHttpActionResult GetAdnCByAgentId(
			[FromUri] string agentId)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.GetAdnCByAgentId(agentId));
        }
    }


	///// <summary>
	///// Filter to enable handling file upload in swagger
	///// </summary>
	//public class FormFileSwaggerFilter : IOperationFilter
	//{
	//	private const string formDataMimeType = "multipart/form-data";
	//	private static readonly string[] formFilePropertyNames =
	//		typeof(IFormFile).GetTypeInfo().DeclaredProperties.Select(p => p.Name).ToArray();

	//	public void Apply(Operation operation, OperationFilterContext context)
	//	{
	//		var parameters = operation.Parameters;
	//		if (parameters == null || parameters.Count == 0)
	//			return;

	//		var formFileParameterNames = new List<string>();
	//		var formFileSubParameterNames = new List<string>();

	//		foreach (var actionParameter in context.ApiDescription.ActionDescriptor.Parameters) {
	//			var properties =
	//				actionParameter.ParameterType.GetProperties()
	//					.Where(p => p.PropertyType == typeof(IFormFile))
	//					.Select(p => p.Name)
	//					.ToArray();

	//			if (properties.Length != 0) {
	//				formFileParameterNames.AddRange(properties);
	//				formFileSubParameterNames.AddRange(properties);
	//				continue;
	//			}

	//			if (actionParameter.ParameterType != typeof(IFormFile))
	//				continue;
	//			formFileParameterNames.Add(actionParameter.Name);
	//		}

	//		if (!formFileParameterNames.Any())
	//			return;

	//		var consumes = operation.Consumes;
	//		consumes.Clear();
	//		consumes.Add(formDataMimeType);

	//		foreach (var parameter in parameters.ToArray()) {
	//			if (!(parameter is NonBodyParameter) || parameter.In != "formData")
	//				continue;

	//			if (formFileSubParameterNames.Any(p => parameter.Name.StartsWith(p + "."))
	//				|| formFilePropertyNames.Contains(parameter.Name))
	//				parameters.Remove(parameter);
	//		}

	//		foreach (var formFileParameter in formFileParameterNames) {
	//			parameters.Add(new NonBodyParameter() {
	//				Name = formFileParameter,
	//				Type = "file",
	//				In = "formData"
	//			});
	//		}
	//	}
	//}


	//public class FileModel
	//{
	//	public string Data { get; set; }
	//	public string Name { get; set; }
	//}
}
