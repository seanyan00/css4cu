﻿using MIG.WEB.API.Data;
using MIG.WEB.API.Models;
using MIGE.Core.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Web.Http;
using System.Web.Http.Cors;

namespace MIG.WEB.API.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [Route("api/[controller]")]
    public class MinWrittenPremiumController : ApiController
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        [HttpPost]
        [Route("api/AddMinPremium/{planId}")]
        public IHttpActionResult AddMinPremium([FromBody] MinWrittenPremium minWrittenPremium, int planId)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.AddMinWrittenPremium(minWrittenPremium, planId));
        }

        [HttpPost]
        [Route("api/EditMinWrittenPremium")]
        public IHttpActionResult EditMinWrittenPremium([FromBody] MinWrittenPremiumDTO minWrittenPremium)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.EditMinWrittenPremium(minWrittenPremium));
        }
        /// <summary>
        /// Gets all the min premium by plan id
        /// </summary>
        /// <param name="minWrittenPremium"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/GetAllMinWrittenPremiumByPlanID")]
        public IHttpActionResult GetAllMinWrittenPremiumByPlanID([FromBody] int planId)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.GetAllMinWrittenPremiumByPlanID(planId));
        }
    }

}
