﻿using MIG.WEB.API.Data;
using MIG.WEB.API.Models;
using MIGE.Core.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Web.Http;
using System.Web.Http.Cors;

namespace MIG.WEB.API.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [Route("api/[controller]")]
    public class MarketingPlanAssignmentController : ApiController
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        [HttpGet]
        [Route("api/GetMarketingTerritories")]
        public IHttpActionResult GetMarketingTerritories()
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.GetMarketingTerritories());
        }

        [HttpPost]
        [Route("api/AddPlanToMarketingTerritory/{planId}")]
        public IHttpActionResult AddPlanToMarketingTerritory([FromBody] MarketingTerritoryAssignment  marketingTerritoryAssignment, int planId)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.AddPlanToMarketingTerritory(marketingTerritoryAssignment, planId));
        }

        [HttpPost]
        [Route("api/UpdatePlanForMarketingTerritory")]
        public IHttpActionResult UpdatePlanForMarketingTerritory([FromBody] MarketingTerritoryAssignmentDTO marketingTerritoryAssignment)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.UpdatePlanForMarketingTerritory(marketingTerritoryAssignment));
        }

        [HttpGet]
        [Route("api/GetAllMarketingTerrByPlanId/{planId}")]
        public IHttpActionResult GetAllMarketingTerrByPlanId( int planId)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.GetAllMarketingTerrByPlanId(planId));
        }

        [HttpGet]
        [Route("api/GetAllMarketingTerrByYear/{year}")]
        public IHttpActionResult GetAllMarketingTerrByYear(int year)
        {
            logger.Debug(MethodInfo.GetCurrentMethod());
            DataContext context = new DataContext();
            return Ok(context.GetAllMarketingTerrByYear(year));
        }
    }
}
