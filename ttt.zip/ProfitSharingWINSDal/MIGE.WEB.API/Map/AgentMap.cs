﻿using FluentNHibernate.Mapping;
using MIG.WEB.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MIG.WEB.API.Map
{
    public class AgentMap : ClassMap<AgentMaster>
    {
        public AgentMap()
        {
          //  Id(x => x.AgentId);
          
        }
    }
}