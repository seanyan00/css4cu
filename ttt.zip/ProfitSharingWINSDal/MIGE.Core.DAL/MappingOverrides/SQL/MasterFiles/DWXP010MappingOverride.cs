﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentNHibernate;
using FluentNHibernate.Mapping;
using FluentNHibernate.Automapping.Alterations;
using NHibernate.UserTypes;
using MIGE.Core.Domain.AS400;


namespace MIGE.Core.DAL
{
	/* ****************************************************************************************************
	* PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS - SEE LIBRARY AND TABLE/FILENAME 
	* AS400 LIBRARY        - DVDTA
	* TABLE/FILENAME       - DWXP010
	* DESCRIPTION          - 
	* DATE CREATED         - 7/23/2018 4:43:40 PM
	* AUTHOR               - RICHARD FUMERELLE
	* VERSION              - 1.0
	* CODE GENERATION      - Automatic code generation using CodeSmith GenerationTool
	* NOTES                - This table can be modified.
	****************************************************************************************************/

	#region DWXP010MappingOverride

	public class DWXP010MappingOverride : IAutoMappingOverride<DWXP010>
	{

		#region IAutoMappingOverride<DWXP010> Members

		public void Override(FluentNHibernate.Automapping.AutoMapping<DWXP010> mapping)
		{

			mapping.UseUnionSubclassForInheritanceMapping();
			mapping.Table("DWXP010");
			mapping.CompositeId().KeyProperty(x => x.POLICY, "POLICY").KeyProperty(x => x.EFFDTE, "EFFDTE").KeyProperty(x => x.EDSNO, "EDSNO").KeyProperty(x => x.EDSDTE, "EDSDTE");
			mapping.IgnoreProperty(x => x.RECORDSTATE);

		}

		#endregion
	}

	#endregion

}