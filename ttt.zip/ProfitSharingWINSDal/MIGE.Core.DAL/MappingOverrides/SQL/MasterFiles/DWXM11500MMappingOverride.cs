﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentNHibernate;
using FluentNHibernate.Mapping;
using FluentNHibernate.Automapping.Alterations;
using NHibernate.UserTypes;
using MIGE.Core.Domain;

namespace MIGE.Core.DAL
{
    /* ****************************************************************************************************
    * PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS - SEE LIBRARY AND TABLE/FILENAME 
    * AS400 LIBRARY        - DVDTA
    * TABLE/FILENAME       - DWXM11500M
    * DESCRIPTION          - PS
    * DATE CREATED         - 2/13/2019 7:11:37 AM
    * AUTHOR               - RICHARD FUMERELLE
    * VERSION              - 1.0
    * CODE GENERATION      - Automatic code generation using CodeSmith GenerationTool
    * NOTES                - This table can be modified.
    ****************************************************************************************************/

    #region DWXM11500MMappingOverride

    public class DWXM11500MMappingOverride : IAutoMappingOverride<DWXM11500M>
    {

        #region IAutoMappingOverride<DWXM11500M> Members

        public void Override(FluentNHibernate.Automapping.AutoMapping<DWXM11500M> mapping)
        {

            mapping.UseUnionSubclassForInheritanceMapping();
            mapping.Table("DWXM11500M");
            mapping.CompositeId().KeyProperty(x => x.ACTDTE, "ACTDTE").KeyProperty(x => x.CO, "CO").KeyProperty(x => x.AGENT, "AGENT").KeyProperty(x => x.SUBPRO, "SUBPRO").KeyProperty(x => x.PROD, "PROD");
            mapping.IgnoreProperty(x => x.RECORDSTATE);

        }

        #endregion
    }

    #endregion

}