﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentNHibernate;
using FluentNHibernate.Mapping;
using FluentNHibernate.Automapping.Alterations;
using NHibernate.UserTypes;
using MIGE.Core.Domain;

namespace MIGE.Core.DAL
{
    /* ****************************************************************************************************
    * PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS - SEE LIBRARY AND TABLE/FILENAME 
    * AS400 LIBRARY        - DVDTA
    * TABLE/FILENAME       - DWXF007
    * DESCRIPTION          - PS
    * DATE CREATED         - 2/13/2019 7:11:36 AM
    * AUTHOR               - RICHARD FUMERELLE
    * VERSION              - 1.0
    * CODE GENERATION      - Automatic code generation using CodeSmith GenerationTool
    * NOTES                - This table can be modified.
    ****************************************************************************************************/

    #region DWXF007MappingOverride

    public class DWXF007MappingOverride : IAutoMappingOverride<DWXF007>
    {

        #region IAutoMappingOverride<DWXF007> Members

        public void Override(FluentNHibernate.Automapping.AutoMapping<DWXF007> mapping)
        {

            mapping.UseUnionSubclassForInheritanceMapping();
            mapping.Table("DWXF007");
            mapping.CompositeId().KeyProperty(x => x.CDKEY1, "CDKEY1").KeyProperty(x => x.CDKEY2, "CDKEY2").KeyProperty(x => x.CDKEY3, "CDKEY3").KeyProperty(x => x.EFFDTE, "EFFDTE");
            mapping.IgnoreProperty(x => x.RECORDSTATE);
			//mapping.References(x=>x.CDKEY2).Columns(new[] { "`pk_CDKEY2`" });
			//mapping.Map(x => x.AGYCDE, "FKAGYCDE");
			//mapping.References(x => x.CDKEY2).Column("CDKEY2");
			//mapping.References(x => x.AGYCDE).Column("AGYCDE");
			//mapping.References(x => x.SubAgents).Columns(new[] { "`CDKEY2`", "`AGYCDE`" });
			//mapping.References<DWXF007>(x => x.SubAgents).Column("CDKE2").ForeignKey("AGYCDE").LazyLoad(FluentNHibernate.Mapping.Laziness.False);
			//mapping.References(x => x.SubAgents).Column("CDKEY2").ForeignKey("AGYCDE").LazyLoad(Laziness.False);
			//mapping.HasMany(x => x.SubAgents).LazyLoad().AsList().Inverse().KeyColumn("SubAgents").KeyColumn("CDKEY2").PropertyRef("AGYCDE").Cascade.All();
			//mapping.References<DWXF007>(x => x.SubAgents).Column("CDKEY2").ForeignKey("AGYCDE").Cascade.All();


        }

        #endregion
    }

    #endregion

}
