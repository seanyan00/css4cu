﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentNHibernate;
using FluentNHibernate.Mapping;
using FluentNHibernate.Automapping.Alterations;
using NHibernate.UserTypes;
using MIGE.Core.Domain;

namespace MIGE.Core.DAL
{
    /* ****************************************************************************************************
    * PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS - SEE LIBRARY AND TABLE/FILENAME 
    * AS400 LIBRARY        - DVDTA
    * TABLE/FILENAME       - DWXF108
    * DESCRIPTION          - PS
    * DATE CREATED         - 2/13/2019 7:11:36 AM
    * AUTHOR               - RICHARD FUMERELLE
    * VERSION              - 1.0
    * CODE GENERATION      - Automatic code generation using CodeSmith GenerationTool
    * NOTES                - This table can be modified.
    ****************************************************************************************************/

    #region DWXF108MappingOverride

    public class DWXF108MappingOverride : IAutoMappingOverride<DWXF108>
    {

        #region IAutoMappingOverride<DWXF108> Members

        public void Override(FluentNHibernate.Automapping.AutoMapping<DWXF108> mapping)
        {

            mapping.UseUnionSubclassForInheritanceMapping();
            mapping.Table("DWXF108");
            mapping.CompositeId().KeyProperty(x => x.CDKEY1, "CDKEY1").KeyProperty(x => x.CDKEY2, "CDKEY2").KeyProperty(x => x.CDKEY3, "CDKEY3").KeyProperty(x => x.EFFDTE, "EFFDTE");
            mapping.IgnoreProperty(x => x.RECORDSTATE);

        }

        #endregion
    }

    #endregion

}