﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentNHibernate;
using FluentNHibernate.Mapping;
using FluentNHibernate.Automapping.Alterations;
using NHibernate.UserTypes;
using MIGE.Core.Domain;

namespace MIGE.Core.DAL
{
    /* ****************************************************************************************************
    * PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS - SEE LIBRARY AND TABLE/FILENAME 
    * AS400 LIBRARY        - DVDTA
    * TABLE/FILENAME       - DWXM00102M
    * DESCRIPTION          - PS
    * DATE CREATED         - 2/13/2019 7:11:37 AM
    * AUTHOR               - RICHARD FUMERELLE
    * VERSION              - 1.0
    * CODE GENERATION      - Automatic code generation using CodeSmith GenerationTool
    * NOTES                - This table can be modified.
    ****************************************************************************************************/

    #region DWXM00102MMappingOverride

    public class DWXM00102MMappingOverride : IAutoMappingOverride<DWXM00102M>
    {

        #region IAutoMappingOverride<DWXM00102M> Members

        public void Override(FluentNHibernate.Automapping.AutoMapping<DWXM00102M> mapping)
        {

            mapping.UseUnionSubclassForInheritanceMapping();
            mapping.Table("DWXM00102M");
            mapping.CompositeId().KeyProperty(x => x.AGENT, "AGENT").KeyProperty(x => x.EFFDTE, "EFFDTE");
            mapping.IgnoreProperty(x => x.RECORDSTATE);

        }

        #endregion
    }

    #endregion

}