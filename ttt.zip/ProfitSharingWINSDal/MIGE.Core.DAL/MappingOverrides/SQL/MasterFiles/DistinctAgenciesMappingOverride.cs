﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentNHibernate;
using FluentNHibernate.Mapping;
using FluentNHibernate.Automapping.Alterations;
using NHibernate.UserTypes;
using MIGE.Core.Domain;

namespace MIGE.Core.DAL
{
	public class DistinctAgenciesMappingOverride : IAutoMappingOverride<DistinctAgencies>
	{
		public void Override(FluentNHibernate.Automapping.AutoMapping<DistinctAgencies> mapping)
		{
			//mapping.UseUnionSubclassForInheritanceMapping();
			mapping.Table("vwDistinctAgency");
			mapping.Id(x => x.AgentNumber).CustomSqlType("char(10)").GeneratedBy.Assigned();
			mapping.IgnoreProperty(x => x.children);

			//mapping.HasMany(x => x.children).Inverse().KeyColumn("AgentNumber").PropertyRef("MasterAgency");
			//mapping.HasMany(x => x.children).Inverse().KeyColumn("MasterAgency").PropertyRef("AgentNumber");
			//mapping.Id(x => x.MasterAgency).CustomSqlType("char(10)").GeneratedBy.Assigned();
			//mapping.HasMany(x => x.SubAgencies).Inverse().KeyColumn("MasterAgency").PropertyRef("AgentNumber");
		}
	}
}
