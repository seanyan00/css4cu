﻿using System;
using System.Linq;
using System.Reflection;
using System.Configuration;
using System.Collections.Specialized;

using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using FluentNHibernate.Automapping;
using NHibernate;
using FluentNHibernate.Conventions.Helpers;
using NHibernate.Tool.hbm2ddl;
using FluentNHibernate.Conventions.Inspections;
using FluentNHibernate.Conventions;
using FluentNHibernate.Conventions.Instances;
using FluentNHibernate.Conventions.AcceptanceCriteria;

namespace MIGE.Core.DAL {

	public class NHibernateSQLSession
	{
        public NHibernateSQLSession()
        {

        }
		
        public static ISessionFactory CreateSessionFactory()
        {
            Assembly assembly = AppDomain.CurrentDomain.GetAssemblies().Where(a => a.GetName().Name == "MIGE.Core.Domain").FirstOrDefault();

			var session = Fluently.Configure()
				.Database(
				MsSqlConfiguration.MsSql2012.ShowSql().ConnectionString(c => c.FromAppSetting("targetConn")))
					.Mappings(m => m.AutoMappings.Add(AutoMap.Assemblies(assembly).Where(t => t.Namespace.EndsWith("AS400") || t.Namespace.EndsWith("Domain"))
					.UseOverridesFromAssembly(Assembly.GetExecutingAssembly())
					.Conventions.Add<StringColumnLengthConvention>()
					.Conventions.Add(DynamicUpdate.AlwaysTrue())
					.Conventions.Add(DynamicInsert.AlwaysTrue())))
					.ExposeConfiguration(c => c.SetProperty("generate_statistics", "true"))

			//this is to create db
			// .ExposeConfiguration(cfg => new SchemaExport(cfg).Execute(false,true,false))
			.BuildSessionFactory();

//			var session = Fluently.Configure()
//		.Database(
//		   MsSqlConfiguration.MsSql2012.ShowSql().ConnectionString(c => c.FromAppSetting("profitSharingSQL")))
////						.Mappings(m => m.FluentMappings.Add(Type.GetType("MIGE.Core.Domain.SQL.Models.Map.PremiumVolumeLossRatioTblMap, MIGE.Core.Domain")))
////						.Mappings(m => m.FluentMappings.Add(Type.GetType("MIGE.Core.Domain.SQL.Models.Map.PremiumVolumeLossRatioValueMap, MIGE.Core.Domain")))
//						.Mappings(m => m.AutoMappings.Add(AutoMap.Assemblies(assembly).Where(t => t.Namespace.EndsWith("AS400") || t.Namespace.EndsWith("SQL.Models"))
//							.UseOverridesFromAssembly(Assembly.GetExecutingAssembly())
//							.Conventions.Add<StringColumnLengthConvention>()
//							.Conventions.Add(DynamicUpdate.AlwaysTrue())
//							.Conventions.Add(DynamicInsert.AlwaysTrue())))
//						.ExposeConfiguration(c => c.SetProperty("generate_statistics", "true"))

//				 //this is to create db
//				 // .ExposeConfiguration(cfg => new SchemaExport(cfg).Execute(false,true,false))
//				 .BuildSessionFactory();

			return session;
        }
    }


    public class StringColumnLengthConvention : IPropertyConvention, IPropertyConventionAcceptance
    {
        public void Accept(IAcceptanceCriteria<IPropertyInspector> criteria)
        {
            criteria.Expect(x => x.Type == typeof(string)).Expect(x => x.Length == 0);
        }
        public void Apply(IPropertyInstance instance)
        {
            instance.Length(10000);
        }
    }
}
