﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NHibernate;
using NHibernate.Linq;
using MIGE.Core.Abstractions;

namespace MIGE.Core.DAL
{


   /* ****************************************************************************************************
   * PROGRAM DESCRIPTION  - Generic concrete implementation for Reading or Persisting Entities to DB Repository
   * DATE CREATED         - 05/09/2015
   * AUTHOR               - RICHARD FUMERELLE
   * VERSION              - 1.0
   ****************************************************************************************************/


    public class Repository<TEntity> : IPersistRepository<TEntity>,
    IReadOnlyRepository<TEntity> where TEntity : class//,  T //TEntity//IEntityKey<TKey>
    {
        private readonly ISession _session;
        public Repository(ISession session)
        {
            try
            {
                _session = session;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public bool Add(TEntity entity)
        {
            try
            {
                _session.Save(entity);
                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        //TODO: WOULD LIKE TO RETUNR THE INSERTED OBJ HERE
        // NOT JUST THE ID
        public int SQLAdd(TEntity entity)
        {
            try
            {
                int InsertId = (int)_session.Save(entity);
                return InsertId;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


        public bool Add(IEnumerable<TEntity> entities)
        {
            try
            {
                foreach (TEntity entity in entities)
                {
                    _session.Save(entity);
                }

                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public bool Update(TEntity entity)
        {
            try
            {
                _session.Update(entity);
                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public bool SaveOrUpdate(TEntity entity)
        {
            try
            {
                //_session.Merge(entity);
                _session.SaveOrUpdate(entity);
                //_session.Update(entity);
                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public bool Delete(TEntity entity)
        {
            try
            {
                _session.Delete(entity);
                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public bool Delete(IEnumerable<TEntity> entities)
        {
            try
            {
                foreach (TEntity entity in entities)
                {
                    _session.Delete(entity);
                }
                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public IQueryable<TEntity> GetAll()
        {
            try
            {
                return _session.Query<TEntity>();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public TEntity FindBy(System.Linq.Expressions.Expression<Func<TEntity, bool>> expression)
        {
            try
            {
                return FilterBy(expression).SingleOrDefault();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public IQueryable<TEntity> FilterBy(System.Linq.Expressions.Expression<Func<TEntity, bool>> expression)
        {
            try
            {
                return GetAll().Where(expression).AsQueryable();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public List<TEntity> FilterByList(System.Linq.Expressions.Expression<Func<TEntity, bool>> expression)
        {
            return GetAll().Where(expression).ToList();
        }


        public List<T> ConvertList<T>(IQueryable<object> obj)
        {
            List<T> list = new List<T>();
            foreach (var o in obj)
            {
                list.Add((T)o);
            }
            return list;
        }

        //public T FindBy(TKey id)
        //{
        //    return _session.Get<T>(id);
        //}
    }
}
