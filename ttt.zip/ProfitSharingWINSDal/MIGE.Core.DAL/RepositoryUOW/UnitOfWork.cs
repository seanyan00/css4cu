﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NHibernate;
using MIGE.Core.Abstractions;


namespace MIGE.Core.DAL
{

    /* ****************************************************************************************************
   * PROGRAM DESCRIPTION  - Generic concrete implementation for Commiting or RollingBack Transactions to DB Repository
   * DATE CREATED         - 05/09/2015
   * AUTHOR               - RICHARD FUMERELLE
   * VERSION              - 1.0
   ****************************************************************************************************/

    public class UnitOfWork : IUnitOfWork
    {
        private readonly ISessionFactory _sessionFactory;
        private readonly ITransaction _transaction;
        public ISession Session { get; private set; }


        public UnitOfWork(ISessionFactory sessionFactory)
        {

            try
            {
                _sessionFactory = sessionFactory;
                Session = _sessionFactory.OpenSession();
                Session.FlushMode = FlushMode.Auto;
                _transaction = Session.BeginTransaction(IsolationLevel.ReadCommitted);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public void Commit()
        {
            try
            {
                if (!_transaction.IsActive)
                {
                    throw new InvalidOperationException("Unable to commit transaction - there is no active transaction.");
                }
                _transaction.Commit();
                _transaction.Dispose();
                Session.Flush();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public void Rollback()
        {
            try
            {
                if (_transaction.IsActive)
                {
                    _transaction.Rollback();
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public void Dispose()
        {

            try
            {
                if (Session.IsOpen)
                {
                    Session.Close();
                    Session.Dispose();
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
