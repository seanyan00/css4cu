﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

using FluentNHibernate;
using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using FluentNHibernate.Conventions.Helpers;
using FluentNHibernate.Automapping;
using NHibernate;

namespace MIGE.Core.DAL
{
	public class NHibernateOdsSQLSession
	{
		private static ISessionFactory _sessionFactory;

		private static string s;

		private static ISessionFactory SessionFactory {
			get {
				if (_sessionFactory == null) {
					InitializeSessionFactory();
				}
				return _sessionFactory;
			}
		}


		private static void InitializeSessionFactory()
		{

			try {
				Assembly assembly = AppDomain.CurrentDomain.GetAssemblies().Where(a => a.GetName().Name == "MIGE.Core.Domain").FirstOrDefault();
				Type[] overrideAssembly = AppDomain.CurrentDomain.GetAssemblies().Where(x => x.GetName().Name == "MIGE.Core.DAL").FirstOrDefault().GetTypes();


				if (assembly == null) {
					throw new Exception("SQL Assembly Not Found");
				}

				_sessionFactory = Fluently.Configure()
				.Database(MsSqlConfiguration.MsSql2012
							.ConnectionString(c => c.FromAppSetting("profitSharingSQL"))//.ShowSql()
							.DefaultSchema("MIGPPDDTAM")
				)
				.Mappings(m => m.AutoMappings.Add(AutoMap.Assemblies(assembly).Where(t => t.Namespace.EndsWith("Domain")).UseOverridesFromAssembly(Assembly.GetExecutingAssembly())))
				.BuildSessionFactory();

			} catch (Exception ex) {
				throw ex;
			}
		}

		//
		public static ISession OpenSession()
		{
			try {
				return SessionFactory.OpenSession();
			} catch (Exception ex) {

				throw ex;
			}
		}

		//
		public static ISessionFactory OpenSessionFactory()
		{
			try {
				return SessionFactory;
			} catch (Exception ex) {

				throw ex;
			}
		}
	}
}
