﻿using System;
using System.Linq;
using System.Reflection;
using System.Configuration;
using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using FluentNHibernate.Conventions.Helpers;
using FluentNHibernate.Automapping;
using NHibernate;
using NHibernate.Dialect;
using NHibernate.Driver;
using MIGE.Core.Domain;
using System.IO;

namespace MIGE.Core.DAL
{


	/* ****************************************************************************************************
	* PROGRAM DESCRIPTION  - Initializes and Returns an NHIbernate Session AND
	*                        Initializes the NHibernate ValidationEngine for validating entities.
	* DATE CREATED         - 05/09/2015
	* AUTHOR               - RICHARD FUMERELLE
	* VERSION              - 1.0
	 * 
	 * CHANGE LOG TICKET #
	 * 03-04-2016 - RRF - Updated InitializeSessionFactory() to check for ConfigurationManager.AppSettings["NHibernateShowSQL"] setting in configuration file
	 *                                  If Set to true - NHibernate will output code generated SQL - If Set to False NHibernate not output code generated SQL.
	 *                                  Modified ConnectionString setting to read from configuration file.
	 *                                  Configuration file can be either web.conf or app.config
	 *                                  Added a reference to System.Configuration to support reading from configuration file.
	****************************************************************************************************/


	public class NHibernateSession
	{
		private static string _connectionString = AppDomain.CurrentDomain.GetData("ConnectionString").ToString();
		private static string _nhibernateshowsql = AppDomain.CurrentDomain.GetData("NHibernateShowSQL").ToString();

		public NHibernateSession()
		{

		}

		private static ISessionFactory _sessionFactory;
		private static ISessionFactory SessionFactory {
			get {
				if (_sessionFactory == null) {
					InitializeSessionFactory();

				}

				return _sessionFactory;
			}
		}


		private static void InitializeSessionFactory()
		{

			try {
				/* foreach (Assembly ass in AppDomain.CurrentDomain.GetAssemblies())
				 {
					 LoadReferencedAssembly(ass);
				 }*/

				Assembly assembly = AppDomain.CurrentDomain.GetAssemblies().Where(a => a.GetName().Name == "MIGE.Core.Domain").FirstOrDefault();

				if (assembly == null) {
					throw new Exception("SQL Assembly Not Found");
				}

				if (_nhibernateshowsql == null) {
					throw new Exception("NHibernateShowSQL key missing from App Settings in web.config file - Add the key - values true or false.");
				}

				if (_nhibernateshowsql.ToLower() == "true") {
					_sessionFactory = Fluently.Configure()
				   .Database(DB2Configuration.Standard.ConnectionString(_connectionString).ShowSql()
				   .Driver<DB2400Driver>()
				   .Dialect<DB2400Dialect>()
						  )
					.Mappings(m => m.AutoMappings.Add(AutoMap.Assemblies(assembly).Where(t => t.Namespace.EndsWith("AS400")).UseOverridesFromAssembly(Assembly.GetExecutingAssembly())
					.Conventions.Add(DynamicUpdate.AlwaysTrue())
					.Conventions.Add(DynamicInsert.AlwaysTrue())))
					.ExposeConfiguration(c => c.SetProperty("generate_statistics", "true"))
					.ExposeConfiguration(c => c.SetInterceptor(new ObjectInterceptor()))
				  .BuildSessionFactory();

				} else {
					_sessionFactory = Fluently.Configure()
					.Database(DB2Configuration.Standard.ConnectionString(_connectionString).ShowSql()
					.Driver<DB2400Driver>()
					.Dialect<DB2400Dialect>()
					   )

					.Mappings(m => m.AutoMappings.Add(AutoMap.Assemblies(assembly).Where(t => t.Namespace.EndsWith("AS400")).UseOverridesFromAssembly(Assembly.GetExecutingAssembly())
					.Conventions.Add(DynamicUpdate.AlwaysTrue())
					.Conventions.Add(DynamicInsert.AlwaysTrue())))
				   .ExposeConfiguration(c => c.SetProperty("generate_statistics", "true"))
				   .ExposeConfiguration(c => c.SetInterceptor(new ObjectInterceptor()))
				   .BuildSessionFactory();
				}
			} catch (Exception ex) {
				throw;
			}
		}


		public static ISession OpenSession()
		{
			try {
				return SessionFactory.OpenSession();
			} catch (Exception ex) {
				throw;
			}
		}


		public static ISessionFactory OpenSessionFactory()
		{
			try {
				return SessionFactory;
			} catch (Exception ex) {
				throw;
			}
		}
	}
}
