﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MIGE.Core.Domain;
using MIGE.Core.DAL;
using MIGE.Core.Domain.Dto;
using NHibernate;
using FluentNHibernate;
using System.Runtime.Serialization;

namespace MIGE.Core.Agent
{
	[DataContract]
	public class AgentListPaged
	{
		private ISessionFactory _sessionFactory = null;
		private UnitOfWork _unitOfWork = null;

		[DataMember]
		public PagingInfo PagingInformation { get; set; }

		[DataMember]
		public string SingleAgent { get; set; } = "";

		[DataMember]
		//public List<DistinctAgencies> Agencies { get; set; }
		public List<TableData> data { get; set; }
	

		//public DistinctAgencies[] data2 { get; set; }

		//public AgentListPaged(int pageNumber = 0, int  pageSize = 5)
		public AgentListPaged(PagingInfo pagingInfo, string singleAgent = "" )
		{


			try
			{

				if(singleAgent != "")
				{
					this.SingleAgent = singleAgent;
				}

				PagingInformation = new PagingInfo();
				PagingInformation.CurrentPage = pagingInfo.CurrentPage;
				PagingInformation.PageSize = pagingInfo.PageSize;
				//Agencies = new List<DistinctAgencies>();
				data = new List<TableData>();

				if (PagingInformation.TotalResults == 0)
				{
					GetTotalResults();
				}

				if (PagingInformation.PageCount == 0)
				{
					GetTotalPageCount();
				}

				IsPagingSet();
				
				GetNextAgencies();
				


			}
			catch (Exception ex)
			{

				throw ex;
			}

		}

		private bool IsPagingSet()
		{
			//if(PagingInformation.CurrentPage == 0 || PagingInformation.PageSize == 0) 
			if (PagingInformation.PageSize == 0)
			{
				throw new Exception("One or more paging parameters are set to 0");
			}

			return true;
		}

		private void GetTotalResults()
		{
			try
			{
				_sessionFactory = NHibernateOdsSQLSession.OpenSessionFactory();
				_unitOfWork = new UnitOfWork(_sessionFactory);
				Repository<DistinctAgencies> agenciesRepository = new Repository<DistinctAgencies>(_unitOfWork.Session);
				if (this.SingleAgent == null || this.SingleAgent == "")
				{
					PagingInformation.TotalResults = agenciesRepository.GetAll().Distinct().Count();
				}
				else
				{
					PagingInformation.TotalResults = agenciesRepository.FilterBy(x => x.AgentNumber == this.SingleAgent).Distinct().Count();
				}

				//PagingInformation.TotalResults = agenciesRepository.FilterBy(x => x.MasterAgency == "00779").Count();

				_unitOfWork.Commit();
				_sessionFactory.Close();
			}
			catch (Exception ex)
			{

				throw ex;
			}

		}

		private void GetTotalPageCount()
		{
			PagingInformation.PageCount = System.Convert.ToInt32(System.Math.Ceiling(PagingInformation.TotalResults / System.Convert.ToDouble(PagingInformation.PageSize)));
		}

		//public void GetNextAgencies(int pageNumber, int pageSize)
		private void GetNextAgencies()
		{
			try
			{
				_sessionFactory = NHibernateOdsSQLSession.OpenSessionFactory();
				_unitOfWork = new UnitOfWork(_sessionFactory);
				Repository<DistinctAgencies> agenciesRepository = new Repository<DistinctAgencies>(_unitOfWork.Session);
				List<DistinctAgencies> agencies = new List<DistinctAgencies>();

				if(this.SingleAgent == null || this.SingleAgent == "")
				{
					agencies = agenciesRepository.GetAll().Select(x => x).OrderBy(x => x.AgentNumber).Skip(PagingInformation.CurrentPage * PagingInformation.PageSize).Take(PagingInformation.PageSize).ToList();
				}
				else
				{
					agencies = agenciesRepository.FilterBy(x => x.AgentNumber == this.SingleAgent).Select(x => x).OrderBy(x => x.AgentNumber).Skip(PagingInformation.CurrentPage * PagingInformation.PageSize).Take(PagingInformation.PageSize).ToList();
				}

				agencies.ForEach(agency =>
				{
					TableData td = new TableData();
					td.data = agency;

					List<ChildrenDataObject> childrenDataObjects = new List<ChildrenDataObject>();

					agenciesRepository.FilterBy(x => x.MasterAgency == agency.AgentNumber && x.AgentNumber != agency.AgentNumber).ToList().ForEach(x =>
					{
						ChildrenDataObject cdo = new ChildrenDataObject();
						cdo.data = x;
						childrenDataObjects.Add(cdo);
					});

					td.children = childrenDataObjects;
					this.data.Add(td);

				});

				_unitOfWork.Commit();
				_sessionFactory.Close();

			}
			catch (Exception ex)
			{

				throw ex;
			}
		}


	}



	public class TableData
	{
		public DistinctAgencies data { get; set; }
		public IList<ChildrenDataObject> children { get; set; }

		public TableData() 
		{ 
				children = new List<ChildrenDataObject>();

		}
	}

	public class ChildrenDataObject
	{
		public DistinctAgencies data { get; set; }
	}
}
