﻿using System;
using System.Linq;
               
using NHibernate;

using MIGE.Core.DAL;
using MIGE.Core.Domain;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace MIGE.Core.Agent
{
    /* ****************************************************************************************************
    * PROGRAM DESCRIPTION  - 
    * DESCRIPTION          -    
    * DATE CREATED         - 02/18/2019
    * AUTHOR               - Tauseef Alam
    * NOTES                - N/A
    * CHANGE LOG TICKET #
    *******************************************************************************************************/
	[DataContract]
    public class AgencyInfo
    {
		//      const string APPSOURCE = "MIGE.Core.PSManager:AgencyInfo";

		//      private const string _objectName = "Agency Info - ";

		private ISessionFactory _sessionFactory = null;
		private UnitOfWork _unitOfWork = null;

		//public string AgentCode { get; set; }

		//      public string MarketingTerritory { get; set; }

		//      public DWXF108 AgentMktTerritory { get; set; }

		//      public DWXF007 AgentInfo { get; set; }

		//      public DWXM00101M AgencyProfitSharingPlan { get; set; }

		//      public DWXM00102M ProfitSharingPlanDetails { get; set; }

		//      public DWXM11500M AgencyManagementSystem { get; set; }
		[DataMember]
		public int RecordCount { get; set; } = 0;
        /*THESE FIELD NEEDS TO BE NAMED DATA TO BE CONSUMED BY THE WEB FRONT ENT*/
		[DataMember]
        public List<TableAgentData> data { get; set; }


		public AgencyInfo() 
		{
			data = new List<TableAgentData>();
		}

        public virtual void ValidateObject()
        {

        }

        public void GetAllAgents()
		{
			_sessionFactory = NHibernateOdsSQLSession.OpenSessionFactory();
			_unitOfWork = new UnitOfWork(_sessionFactory);
			Repository<DistinctAgencies> agenciesRepository = new Repository<DistinctAgencies>(_unitOfWork.Session);
			List<DistinctAgencies> agencies = new List<DistinctAgencies>();
			agencies =  agenciesRepository.GetAll().Select(x => new DistinctAgencies { AgentNumber = x.AgentNumber, AgencyName=  x.AgencyName }).OrderBy(x => x.AgentNumber).Distinct().ToList();
			agencies.ForEach(agency =>
			{
				TableAgentData tad = new TableAgentData();
				AgentCodeNameDTO agentCodeNameDTO = new AgentCodeNameDTO();
				agentCodeNameDTO.AgentNumber = agency.AgentNumber;
				agentCodeNameDTO.AgencyName = agency.AgencyName;
				tad.data = agentCodeNameDTO;
				data.Add(tad);

			});

			_unitOfWork.Commit();
			_sessionFactory.Close();
			this.RecordCount = agencies.Count();
			int j = 0;

			//{
			//	AgentCodeNameDTO acnDTO = new AgentCodeNameDTO();
			//	acnDTO.AgentNumber = x.AgentNumber;
			//	acnDTO.AgencyName = x.AgencyName;
			//	data.Add(acnDTO);
			//});
			
		}

		#region Deprecated Code
		//public List<DWXF007> GetAllAgentInfos()
		//{
		//    _session = NHibernateSession.OpenSession();

		//    List<DWXF007> agentInfo = (from agent in _session.Query<DWXF007>()
		//                           select agent).AsEnumerable().ToList();
		//    _session.Close();
		//    return agentInfo;
		//}

		//public AgencyInfo GetAgencyInfomation(string agentCode)
		//{
		//    try
		//    {
		//        _session = NHibernateSession.OpenSession();

		//        string[] companyCodes = { "MMIC", "MPIC", "MINH" };

		//        AgencyInfo agencyInfo = new AgencyInfo();

		//        agencyInfo.AgentInfo = (from agent in _session.Query<DWXF007>()
		//                          where companyCodes.Contains(agent.CDKEY1)
		//                          && agent.CDKEY2 == agentCode
		//                          select agent
		//                         ).FirstOrDefault();


		//        agencyInfo.AgentMktTerritory = (from mktTer in _session.Query<DWXF108>()
		//                                  where companyCodes.Contains(mktTer.CDKEY1)
		//                                  && mktTer.CDKEY2 == agentCode
		//                                  //&& mktTer.CDKEY3 == subProducer
		//                                  select mktTer
		//                         ).FirstOrDefault();


		//        agencyInfo.AgencyProfitSharingPlan = (from psplan in _session.Query<DWXM00101M>()
		//                                     where companyCodes.Contains(psplan.CO)
		//                                     && psplan.AGENT == agentCode
		//                                     select psplan
		//                         ).FirstOrDefault();


		//        agencyInfo.ProfitSharingPlanDetails = (from psplandetails in _session.Query<DWXM00102M>()
		//                                                   where psplandetails.AGENT == agentCode
		//                                                   select psplandetails
		//                         ).FirstOrDefault();


		//        agencyInfo.AgencyManagementSystem = (from agencyManagement in _session.Query<DWXM11500M>()
		//                                                    where companyCodes.Contains(agencyManagement.CO)
		//                                                    && agencyManagement.AGENT == agentCode
		//                                                    select agencyManagement
		//                         ).FirstOrDefault();

		//        if (this.AgentMktTerritory != null)
		//        {
		//            agencyInfo.MarketingTerritory = this.AgentMktTerritory.MKTTER.Trim();
		//        }
		//        else
		//        {
		//            agencyInfo.MarketingTerritory = string.Empty;
		//        }

		//        _session.Close();

		//        return agencyInfo;

		//    }
		//    catch (Exception ex)
		//    {
		//        if (!ex.Source.Contains("Error in MIGE"))
		//        {
		//            ex.Source = "Error in " + APPSOURCE;
		//        }
		//        throw ex;
		//    }
		//}
		#endregion
	}

	public class TableAgentData
	{
		public AgentCodeNameDTO data { get; set; }
		public TableAgentData() { }
	}
}
