﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace MIGE.Core.Agent
{
	[DataContract]
	public class AgentCodeNameDTO
	{
		[DataMember]
		public virtual string AgentNumber { get; set; }
		[DataMember]
		public virtual string AgencyName { get; set; }
	}
}
