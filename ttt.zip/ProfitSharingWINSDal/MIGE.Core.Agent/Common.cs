﻿using System;
using System.Collections.Generic;

using MIGE.Core.Domain;

namespace MIGE.Core.Agent
{
    /* ****************************************************************************************************
    * PROGRAM DESCRIPTION  - 
    * DESCRIPTION          -    
    * DATE CREATED         - 02/18/2019
    * AUTHOR               - Tauseef Alam
    * NOTES                - N/A
    * CHANGE LOG TICKET #
    *******************************************************************************************************/
    public class Common
    {
 //       const string APPSOURCE = "MIGE.Core.PSManager:Common";

 //       public AgencyInfo AgencyInformation { get; set; }

 //       public Common()
 //       {
 //           AgencyInformation = new AgencyInfo();
 //       }


 //       protected virtual void GetAgencyInformation()
	//	{
	//		try
	//		{
	//			if (AgencyInformation == null)
	//			{
 //                   AgencyInformation = new AgencyInfo();
	//			}

 //               AgencyInformation = AgencyInformation.GetAgencyInfomation(AgencyInformation.AgentCode);

 //               if (AgencyInformation == null)
 //               {
 //                   throw new Exception("Agent not found.");
 //               }
 //               else
 //               {
 //                   AgencyInformation.ValidateObject();
 //               }
 //           }
 //           catch (Exception ex)
 //           {
 //               if (!ex.Source.Contains("Error in MIGE"))
 //               {
 //                   ex.Source = "Error in " + APPSOURCE;
 //               }
 //               throw ex;
 //           }
 //       }
	}
}
