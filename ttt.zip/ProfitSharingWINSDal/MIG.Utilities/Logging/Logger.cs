﻿using System;
using System.Linq;
using System.Collections.Generic;
using log4net;

namespace MIG.Utilities
{


	/// <summary>
	/// Adaptor class to wrap logging mechanism.
	/// </summary>
	public class Logger
	{

		public enum LogLevel {
			DEBUG,
			INFO,
			WARN,
			ERROR,
			FATAL
		};


		public static void Log (
			string message,
			LogLevel level,
			Exception exception = null,
			string logger = "general")
		{
			try {
				//log4net.Config.BasicConfigurator.Configure();

				ILog log = LogManager.GetLogger(logger);
				switch (level) {
					case LogLevel.DEBUG:
						log.Debug(message, exception);
						break;
					case LogLevel.INFO:
						log.Info(message, exception);
						break;
					case LogLevel.WARN:
						log.Warn(message, exception);
						break;
					case LogLevel.ERROR:
						log.Error(message, exception);
						break;
					case LogLevel.FATAL:
						log.Fatal(message, exception);
						break;
				}
			} catch (Exception e) { }
		}
	}
}
