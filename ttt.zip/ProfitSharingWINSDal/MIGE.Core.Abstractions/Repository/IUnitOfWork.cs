﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIGE.Core.Abstractions
{
    /* ****************************************************************************************************
    * PROGRAM DESCRIPTION  - Generic Inteface For UOW for Committing or Rolling Back Transactions from DB
    * DATE CREATED         - 05/09/2015
    * AUTHOR               - RICHARD FUMERELLE
    * VERSION              - 1.0
    ****************************************************************************************************/


    public interface IUnitOfWork : IDisposable
    {
        void Commit();
        void Rollback();
    }
}
