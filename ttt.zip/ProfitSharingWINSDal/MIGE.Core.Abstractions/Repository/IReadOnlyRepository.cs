﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq.Expressions;

namespace MIGE.Core.Abstractions
{
    /* ****************************************************************************************************
    * PROGRAM DESCRIPTION  - Generic Inteface For Reading Entities From DB Repository
    * DATE CREATED         - 05/09/2015
    * AUTHOR               - RICHARD FUMERELLE
    * VERSION              - 1.0
    ****************************************************************************************************/


    //public interface IReadOnlyRepository<TKey,TEntity> where TEntity : class, IEntityKey<TKey>
    //{
    //    IQueryable<TEntity> GetAll();
    //    TEntity FindBy(Expression<Func<TEntity,bool>> expression);
    //    IQueryable<TEntity> FilterBy(Expression<Func<TEntity, bool>> expression);
    //    TEntity FindBy(TKey id);
    //}

    public interface IReadOnlyRepository<TEntity>  where TEntity : class
    {
        IQueryable<TEntity> GetAll();
        TEntity FindBy(Expression<Func<TEntity, bool>> expression);
        IQueryable<TEntity> FilterBy(Expression<Func<TEntity, bool>> expression);
        //TEntity FindBy(TKey id);
    }
}
