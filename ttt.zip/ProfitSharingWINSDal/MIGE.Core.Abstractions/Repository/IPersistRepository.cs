﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIGE.Core.Abstractions
{

    /* ****************************************************************************************************
    * PROGRAM DESCRIPTION  - Generic Inteface For Persisting Entities to DB Repository
    * DATE CREATED         - 05/09/2015
    * AUTHOR               - RICHARD FUMERELLE
    * VERSION              - 1.0
    ****************************************************************************************************/


    public interface IPersistRepository<TEntity> where TEntity : class
    {
        bool Add(TEntity entity);
        bool Add(IEnumerable<TEntity> entities);
        bool SaveOrUpdate(TEntity entity);
        bool Update(TEntity entity);
        bool Delete(TEntity entity);
        bool Delete(IEnumerable<TEntity> entities);
    }
}
