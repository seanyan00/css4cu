﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MIGE.Core.Abstractions
{

    /* ****************************************************************************************************
    * PROGRAM DESCRIPTION  - Generic Inteface For An Entities to Id Key
    * DATE CREATED         - 05/09/2015
    * AUTHOR               - RICHARD FUMERELLE
    * VERSION              - 1.0
    ****************************************************************************************************/


    public interface IEntityKey<TKey>
    {
        TKey Id { get; }
    }
}
