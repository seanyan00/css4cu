﻿using System;

using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;


namespace MIGE.Core.Abstractions
{
	//public interface IFileManager<TEntity> where TEntity : class
	public interface IFileManager
	{

		int SaveFile();
		IFileManager GetFile();
		List<IFileManager> GetFiles();

	}

}
