﻿using System;

using Newtonsoft.Json;

using MIGE.Core.Abstractions;
using MIGE.Core.Domain;

namespace MIGE.Core.PSManager
{
    /* ****************************************************************************************************
    * PROGRAM DESCRIPTION  - 
    * DESCRIPTION          - 
    *                        
    * DATE CREATED         - 
    * AUTHOR               - Tauseef Alam
    * NOTES                - N/A
    * CHANGE LOG TICKET #
    * 
    * 
    *******************************************************************************************************/
    //public class ProfitSharing : Common, IAgent
    //{

    //    const string APPSOURCE = "MIGE.Core.PSManager:PS";

    //    private IAgent _agent = null;

    //    public ProfitSharing()
    //    {

    //    }

    //    public IAgent GetAgent()
    //    {
    //        try
    //        {
    //            base.GetAgencyInformation();

    //            _agent = this;

    //            return _agent;

    //        }
    //        catch (Exception ex)
    //        {
    //            if (!ex.Source.Contains("Error in MIGE"))
    //            {
    //                ex.Source = "Error in " + APPSOURCE;
    //            }
    //            throw ex;
    //        }
    //        finally
    //        {

    //        }

    //    }

    //    public IAgent SaveAgent()
    //    {
    //        return null;
    //    }

    //    public void DeleteAgent()
    //    {

    //    }

    //    public IAgent FormatOutput()
    //    {
    //        return this;

    //    }

    //    //object clone
    //    public static T Clone<T>(T source)
    //    {
    //        var serialized = JsonConvert.SerializeObject(source);
    //        return JsonConvert.DeserializeObject<T>(serialized);
    //    }
    //}
}
