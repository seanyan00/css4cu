/**
 * to run: gulp purifyCSS
 *
 * this script searches the result of ng build --prod
 * and strips out any un-used CSS classes
 * take that resulting .css file
 * replace /src/assets/css/mig.css
 * and search and replace and fix the
 * primeicons and font-awesome font paths
 * this doesn't need to be run all the time
 * just when things get out of hand / to many changes
 * / upgrading PrimeNG
 */
const gulp = require('gulp');
const purify = require('gulp-purifycss');

gulp.task('purifyCSS', () => {
  return gulp.src('./wwwroot/styles.*.css')
    .pipe(
      purify(
        ['./src/app/**/*.ts', './src/app/**/*.html'],
        {
          info: true, // Outputs reduction information (like in the screenshot above)
          minify: false, // Minifies the files after reduction
          rejected: true, // Logs the CSS rules that were removed
			whitelist: [
				'*transition*',
				'*dimmer*',
				'*ui-panel*',
				'*panel*',
				'panel-header-darkgrey',
				'splash-screen',
				'splash-loader',
				'*ui-dialog*',
				'*ui-confirmdialog*',
				'*ui-fieldset*'
			] // Ignored css classes
        }
      ),
    )
    .pipe(gulp.dest('./wwwroot/mig.optimized.css'));
});
