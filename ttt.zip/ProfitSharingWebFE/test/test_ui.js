const Nightmare = require('nightmare')
const chai = require('chai')
const expect = chai.expect

const nightmare = new Nightmare({
    show: true,
    alwaysOnTop: false,
    width: 1400,
    height: 800,
    pollInterval: 500
})

const onError = (err) => {
    console.error("Test-runner failed:", err);
}

const base = 'http://localhost:9999'
nightmare.goto(base);


describe('Test Base System', () => {

    it('Top Bar / Quote # should exist', function (done) {
        // give this block enough time to execute
        this.timeout('10s')

        nightmare
            // wait for this selector to exist on the page
            .wait('#report_quotenumber')

            // get the innerHTML
            .evaluate(() => document.querySelector('#report_quotenumber').innerHTML)

            // take that value and check it
            .then(data => {
                expect(data).to.equal('Quote #:')
                done()
            }).catch(err => onError(err));
    })

    it('Top Bar / Agent Name should != ""', function (done) {
        nightmare
            .wait('#report_agentname')
            .evaluate(() => document.querySelector('#report_agentname').innerHTML)
            .then(data => {
                expect(data).to.equal("")
                done()
            }).catch(err => onError(err));
    })

    it('Menu Colapses', function (done) {
        nightmare
            .click('#menu-button')
            .wait('.layout-menu-static-inactive')
            .evaluate(() => document.querySelector('.layout-menu-static-inactive'))
            .then(data => {
                expect(data).to.exist
                done()
            }).catch(err => onError(err));
    })


    it('Menu Expands', function (done) {
        this.timeout('6s')
        nightmare
            .wait(2000)
            .click('#menu-button')
            .wait(2000)
            .exists('.layout-menu-static-inactive')
            .then(exists => {
                expect(exists).to.be.false
                done()
            }).catch(err => onError(err));
    })

    it('Steps Menu Exists', function (done) {
        this.timeout('6s')
        nightmare
            .exists('#steps')
            .then(exists => {
                expect(exists).to.be.true
                done()
            }).catch(err => onError(err));
    })

    it('Has at least 1 menu step', function (done) {
        this.timeout('6s')
        nightmare
            .exists('.ui-steps-item')
            .then(exists => {
                expect(exists).to.be.true
                done()
            }).catch(err => onError(err));
    })

    it('Attachments Button Exists', function (done) {
        nightmare.exists('#btnAttachments').then(exists => {
            expect(exists).to.be.true;
            done()
        }).catch(err => onError(err));
    })

    it('Next Button Exists', function (done) {
        nightmare.exists('#btnNext').then(exists => {
            expect(exists).to.be.true;
            done()
        }).catch(err => onError(err));
    })

})
describe('Test Quote Infomation Step', () => {
    it('Validate INSTEL', function (done) {
        this.timeout('10s')
        nightmare
            .type('#INSTEL input', "7165555555")
            .click("#btnSave").wait(2000)

            .exists('#error.INSTEL').then(exists => {
                expect(exists).to.be.false;
                done()
            }).catch(err => onError(err));
    })

    it('Validate INSTYP', function (done) {
        this.timeout('10s')
        nightmare
            .click("#INSTYP div").wait(2000)

            // choose an option
            .click("#INSTYP div div div ul li")
            .click("#btnSave").wait(2000)

            .exists('#error.INSTYP').then(exists => {
                expect(exists).to.be.false;
                done()
            }).catch(err => onError(err));
    })

    // it('Fill-out Quote Info', function (done) {
    //     this.timeout('10s')
    //     nightmare
    //         .type('#INSTEL input', "7165555555")

    //         // click the dropdown
    //         .click("#INSTYP div").wait(2000)

    //         // choose an option
    //         .click("#INSTYP div div div ul li")
    //         .type("#FEDID input", "111111111")
    //         .type("#INSNAM", "Joe Test")
    //         .type("#INSAD1", "Jane Test")
    //         .click("#btnNext")
    //         .then(stat => {
    //             // console.log(stat)
    //             done()
    //         })
    // })

})