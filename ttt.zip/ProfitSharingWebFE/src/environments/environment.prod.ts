// export const environment = {

//     production: true,
//     //proxyPath: 'http://dev-net-ric.mig.local:9000/api/'
//     proxyPath: 'http://dev-pfs-app.mig.local:9000/'   

// };
