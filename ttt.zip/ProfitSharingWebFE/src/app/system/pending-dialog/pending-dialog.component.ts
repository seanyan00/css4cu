import { Component, OnInit } from '@angular/core';
import { ExportReportService } from '@services/export-report.service';
import { Subscription } from 'rxjs';

@Component({
	selector: 'app-pending-dialog',
	templateUrl: './pending-dialog.component.html',
	styleUrls: ['./pending-dialog.component.css']
})
export class PendingDialogComponent implements OnInit {
	public reportPendingArray: string[] = [];
	public shouldDisplay: boolean = false;
	public exportReportSubscription: Subscription;

	constructor(private exportReport: ExportReportService) { }

	ngOnInit() {
		this.exportReportSubscription = this.exportReport.reportPending.subscribe(reportPendingArray => {
			this.reportPendingArray = reportPendingArray;
			if (reportPendingArray.indexOf('excel') > -1 || reportPendingArray.indexOf('single_pdf') > -1) {
				this.shouldDisplay = true;
			} else {
				this.shouldDisplay = false;
			}
		});
	}

	ngOnDestroy() {
		if (this.exportReportSubscription) this.exportReportSubscription.unsubscribe();
	}
}
