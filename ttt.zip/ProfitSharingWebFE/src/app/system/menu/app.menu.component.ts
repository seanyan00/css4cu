import { Component, OnInit } from '@angular/core';

import { MIGMenuItem } from '@overridden/primeng-menuitem/menuitem';

import { Router, NavigationEnd } from '@angular/router';
import { Paths } from '../../app.routing.enums';
import { Subscription } from 'rxjs';

@Component({
	selector: 'app-menu',
	templateUrl: './app.menu.component.html',
	styleUrls: ['./app.menu.component.scss']
})
export class AppMenu implements OnInit {
	routeSubscription: Subscription;
	menuSet: MIGMenuItem[];
	mobileMenuSet: MIGMenuItem[];
	constructor(
		private router: Router
		) {
	}

	ngOnInit(): void {
		this.menuSet = [
			{
				label: 'Agents',
				icon: 'fas fa-users',
				routerLink: [`/${Paths.agents}`],
				routerLinkActiveOptions: {exact: true},
				styleClass: 'desktop'
			},
			{
				label: 'Tools',
				styleClass: 'desktop',
				icon: 'pi pi-chevron-up',
				command: (data: {event: any, item: MIGMenuItem}) => {
					this.handleToggle(data);
				},
				items: [
					{ label: 'Plans', icon: 'fas fa-balance-scale', routerLink: [`/${Paths.plans}`], routerLinkActiveOptions: {exact: true} },
					{ label: 'Tables', icon: 'fas fa-table', routerLink: [`/${Paths.tables}`], routerLinkActiveOptions: {exact: true} }
				],
				expanded: false
			},
			{
				label: 'Reports',
				icon: 'far fa-folder-open',
				routerLink: [`/${Paths.report_builder}`],
				routerLinkActiveOptions: {exact: true},
				styleClass: 'desktop'
			},
			{
				label: 'System',
				icon: 'fas fa-cog',
				routerLink: [`/${Paths.system}`],
				routerLinkActiveOptions: {exact: true},
				styleClass: 'desktop'
			}
		];

		this.mobileMenuSet = [
			{
				label: 'Agents',
				icon: 'fas fa-users',
				routerLink: [`/${Paths.agents}`],
				routerLinkActiveOptions: {exact: true},
				styleClass: 'mobile'
			},
			{
				label: 'Plans',
				icon: 'fas fa-balance-scale',
				routerLink: [`/${Paths.plans}`],
				routerLinkActiveOptions: {exact: true},
				styleClass: 'mobile'
			},
			{
				label: 'Tables',
				icon: 'fas fa-table',
				routerLink: [`/${Paths.tables}`],
				routerLinkActiveOptions: {exact: true},
				styleClass: 'mobile'
			},
			{
				label: 'Reports',
				icon: 'far fa-folder-open',
				routerLink: [`/${Paths.report_builder}`],
				routerLinkActiveOptions: {exact: true},
				styleClass: 'mobile'
			},
			{
				label: 'System',
				icon: 'fas fa-cog',
				routerLink: [`/${Paths.system}`],
				routerLinkActiveOptions: {exact: true},
				styleClass: 'mobile'
			}
		];
		this.routeSubscription = this.router.events.subscribe(data => {
			if (data instanceof NavigationEnd === false) return;
			let id = data['url'];

			for (let a = 0; a < this.menuSet.length; a++) {
				if (this.menuSet[a].routerLink == id) {
					this.resetMenu();
					this.menuSet[a].active = true;
				} else if (this.menuSet[a].label === 'Tools') {
					for (let item in this.menuSet[a].items) {
						if (this.menuSet[a].items[item]['routerLink'] == id) {
							this.resetMenu();
							this.menuSet[a].items[item]['active'] = true;
						}
					}
				}
			}
		})
	}

	resetMenu = () => {
		for (let a = 0; a < this.menuSet.length; a++) {
			this.menuSet[a].active = false;
			if (this.menuSet[a].label === 'Tools') {
				for (let item in this.menuSet[a].items) {
					this.menuSet[a].items[item]['active'] = false;
				}
			}
		}
	}

	handleToggle = (data: {event: any, item: MIGMenuItem}) => {
		if (data.item.expanded) {
			data.item.icon = 'pi pi-chevron-up';
		} else {
			data.item.icon = 'pi pi-chevron-down';
		}
	}
}