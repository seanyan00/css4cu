import { Component, OnInit } from '@angular/core';
import { ErrorService, ErrorType } from '../../services/error.service';

@Component({
	selector: 'app-error-dialog',
	templateUrl: './error-dialog.component.html',
	styleUrls: ['./error-dialog.component.css']
})
export class ErrorDialogComponent implements OnInit {
	displayErrorDialog: boolean = false;
	error: Pick<ErrorType, 'title' | 'message'>;

	constructor(private errorService: ErrorService) { }

	ngOnInit() {
		this.errorService.errorMessage.subscribe(error => {
			this.error = {
				title: error ? error.title : '',
				message: error ? error.message : ''
			};
			this.displayErrorDialog = error ? error.dialog : false;
		});
	}

	onErrorDialogClosed() {
		this.errorService.setError(null);
	}
}
