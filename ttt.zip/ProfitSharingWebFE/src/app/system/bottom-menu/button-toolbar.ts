export interface ButtonToolbar {
    formId: string,
    label: string;
    type: 'button' | 'download' | 'upload' | 'submit';
    icon: string;
    active: boolean;
    multi: boolean;
    behavior?: (e, formRef?) => void;
}