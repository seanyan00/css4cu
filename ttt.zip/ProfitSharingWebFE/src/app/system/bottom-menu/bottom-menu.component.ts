import { Component, OnInit } from '@angular/core';

import { Router, NavigationEnd } from '@angular/router';
import { Paths } from '../../app.routing.enums'
import { Subscription } from 'rxjs';
import { take } from 'rxjs/operators';

import { ButtonToolbar } from './button-toolbar';
import { ConvertCsvToJsonService } from '@services/convert-csv-to-json.service';
import { TableDataService } from '@services/table-data.service';
import { ApiService, Table, TableNames, TableStatus } from '@services/api.service';
import { ErrorService } from '@services/error.service';
import { ConvertJsonToCsvService } from '@services/convert-json-to-csv.service';
import { ExportReportService } from '@services/export-report.service';
import { AgentDataService } from '@services/agent-data.service';

@Component({
	selector: 'app-bottom-menu',
	templateUrl: './bottom-menu.component.html',
	styleUrls: ['./bottom-menu.component.scss']
})

export class BottomMenuComponent implements OnInit {
	buttonSet: { [title: string]: ButtonToolbar };
	buttonSetIndex: string[];
	displayBottomMenu: boolean;
	routeSubscription: Subscription;
	currentRoute: string;
	agentDetailVisibilitySubscription: Subscription;
	growthTableSubscription: Subscription;
	volumeLossTableSubscription: Subscription;
	profitabilityTableSubscription: Subscription;
	displayErrorDialog: boolean;

	constructor(
		private router: Router,
		public convertCSV: ConvertCsvToJsonService,
		public tableDataService: TableDataService,
		private apiService: ApiService,
		private errorService: ErrorService,
		private convertJsonToCsvService: ConvertJsonToCsvService,
		private exportReport: ExportReportService,
		private agentDataService: AgentDataService
	) { }

	ngOnInit() {
		this.displayBottomMenu = false;

		this.buttonSet = {
			exportPDF: {
				label: 'Export PDF',
				formId: 'exportPDF',
				type: 'button',
				icon: '',
				active: false,
				multi: false,
				behavior: e => {
					// Placeholder TODO: Add behavior for export PDF
					return;
				}
			},
			exportExcel: {
				label: 'Export Excel',
				formId: 'exportExcel',
				type: 'button',
				icon: '',
				active: false,
				multi: false,
				behavior: e => {
					this.exportReport.export('excel', true, false, false, null, null);
					return;
				}
			},
			//exportCustomExcel: {
			//	label: 'Export Excel',
			//	formId: 'exportCustomExcel',
			//	type: 'button',
			//	icon: '',
			//	active: false,
			//	multi: false,
			//	behavior: e => {
			//		this.exportReport.export('custom', true, true, false, null, null);
			//		return;
			//	}
			//},
			printSummary: {
				label: 'Print Summary',
				formId: 'printSummary',
				type: 'button',
				icon: '',
				active: false,
				multi: false,
				behavior: e => {
					this.exportReport.export('single_pdf', false, false, false, null, null);
					return;
				}
			},
			printOptions: {
				label: 'Print Options',
				formId: 'printOptions',
				type: 'button',
				icon: '',
				active: false,
				multi: false,
				behavior: e => {
					this.exportReport.setDisplayPrintOptions(true);
					return;
				}
			},
			printFull: {
				label: 'Print Full',
				formId: 'printFull',
				type: 'button',
				icon: '',
				active: false,
				multi: false,
				behavior: e => {
					this.exportReport.export('single_pdf', true, false, true, null, null);
					return;
				}
			},
			selectFile: {
				label: 'Select File',
				formId: 'selectFile',
				type: 'upload',
				icon: '',
				active: false,
				multi: false,
				behavior: e => {
					return;
				}
			},
			submit: {
				label: 'Submit',
				formId: 'submit',
				type: 'submit',
				icon: '',
				active: false,
				multi: false,
				behavior: e => {
					// Placeholder TODO: Add form submit
					return;
				}
			},
			approve: {
				label: 'Approve',
				formId: 'approve',
				type: 'button',
				icon: '',
				active: false,
				multi: false,
				behavior: e => {
					// Placeholder TODO: Add behavior
					return;
				}
			},
			download: {
				label: 'Download',
				formId: 'download',
				type: 'download',
				icon: '',
				active: false,
				multi: false,
				behavior: e => {
					// Placeholder TODO: Add download behavior
					return;
				}
			}
		};

		this.buttonSetIndex = Object.keys(this.buttonSet);
		this.routeSubscription = this.router.events.subscribe(data => {
			if (data instanceof NavigationEnd === false) return;
			let id = data['url'];
			this.setBottomMenuButtons(id);
		})

		// If the agent detail panel is visible then display custom set of buttons in the toolbar
		this.agentDetailVisibilitySubscription = this.agentDataService.agentDetailVisible.subscribe(bool => {
			if ((this.currentRoute === `/${Paths.agents}` || this.currentRoute === '/') && bool) {
				this.buttonSet.exportExcel.active = true;
				this.buttonSet.printSummary.active = true;
				this.buttonSet.printFull.active = true;
				this.buttonSet.printOptions.active = false;
			} else if ((this.currentRoute === `/${Paths.agents}` || this.currentRoute === '/') && !bool) {
				this.buttonSet.exportExcel.active = false;
				this.buttonSet.printSummary.active = false;
				this.buttonSet.printFull.active = false;
				this.buttonSet.printOptions.active = true;
			}
		});
	}

	ngOnDestroy() {
		if (this.agentDetailVisibilitySubscription) this.agentDetailVisibilitySubscription.unsubscribe();
		if (this.routeSubscription) this.routeSubscription.unsubscribe();
		if (this.growthTableSubscription) this.growthTableSubscription.unsubscribe();
		if (this.profitabilityTableSubscription) this.profitabilityTableSubscription.unsubscribe();
		if (this.volumeLossTableSubscription) this.volumeLossTableSubscription.unsubscribe();
	}

	setBottomMenuButtons = route => {
		this.resetBottomButtons();
		let uploadTableType: ('volume-loss' | 'profitability' | 'growth' | null) = null;

		if (route.match(/\/tables\/view/g)) {
			uploadTableType = route.split('/')[3];
			route = route.match(/\/tables\/view/g)[0];
		}

		this.currentRoute = route;

		switch(route) {
			case '/':
				this.displayBottomMenu = true;
				this.buttonSet.printOptions.active = true;
				break;
			case `/${Paths.agents}`:
				this.displayBottomMenu = true;
				this.buttonSet.printOptions.active = true;
				break;
			case `/${Paths.tables}/${Paths.view}`:
				this.displayBottomMenu = true;
				this.buttonSet.selectFile.active = true;
				this.buttonSet.download.active = true;

				switch (TableNames[uploadTableType]) {
					case TableNames['growth']:
						this.growthTableSubscription = this.tableDataService.growth.subscribe(x => {
							this.detectTableStatus(x.TableStatus, uploadTableType);
						})
						break;
					case TableNames['profitability']:
						this.profitabilityTableSubscription = this.tableDataService.profitability.subscribe(x => {
							this.detectTableStatus(x.TableStatus, uploadTableType);
						})
						break;
					case TableNames['volume-loss']:
						this.volumeLossTableSubscription = this.tableDataService.volumeLoss.subscribe(x => {
							this.detectTableStatus(x.TableStatus, uploadTableType);
						})
						break;
					default:
						break;
				}

				if (uploadTableType) {
					this.buttonSet.selectFile.behavior = this.uploadFunction(uploadTableType);
					this.buttonSet.download.behavior = this.downloadFunction(uploadTableType);
				}

				break;
			//case `/${Paths.report_builder}`:
			//	this.displayBottomMenu = true;
			//	this.buttonSet.exportCustomExcel.active = true;
			//	break;
		}
	}

	resetBottomButtons = () => {
		this.displayBottomMenu = false;
		for (let button in this.buttonSet) {
			this.buttonSet[button].active = false;
		}
	}

	downloadFunction = (uploadTableType: 'volume-loss' | 'profitability' | 'growth' | null) => async () => {
		let currentTableName;
		let currentTableData;
		let convertTable;
		let tableDataMember = uploadTableType === 'volume-loss' ? 'volumeLoss' : uploadTableType;

		try {
			this.tableDataService[tableDataMember].pipe(take(1)).subscribe(data => {
				currentTableName = data.Name;
				currentTableData = data.Data;
			});
			convertTable = await this.convertJsonToCsvService.convertJSONToCSV(currentTableData);
			this.convertJsonToCsvService.downloadCSV(currentTableName, convertTable);
		} catch (e) {

		}
	}

	uploadFunction = (uploadTableType: 'volume-loss' | 'profitability' | 'growth' | null) => async (e, form) => {
		let conversionResult;
		let conversionAPISanitized: string;
		let conversionObservableSanitized: string;
		let sendDataResult;
		let requestBody;
		let currentTableName;
		let currentTableId;
		let tableDataMember = uploadTableType === 'volume-loss' ? 'volumeLoss' : uploadTableType;
		
		if (!e.files.length) return;
		
		try {
			conversionResult = await this.convertCSV.convertExcelToJson(e, uploadTableType);
			this.tableDataService[tableDataMember].pipe(take(1)).subscribe(data => {
				currentTableName = data.Name;
				currentTableId = data.Id;
			});

			// Volume Loss Ratio tables need to be re-formatted before data is sent to the back-end
			if (TableNames[uploadTableType] === TableNames['volume-loss']) {
				conversionObservableSanitized = this.convertCSV.serializeJSON(conversionResult.data);
				conversionAPISanitized = this.convertCSV.serializeJSON(conversionResult.apiFormattedData);
			} else {
				conversionAPISanitized = this.convertCSV.serializeJSON(conversionResult.data);
			}

			// Build request body
			requestBody = {
				"Id": currentTableId,
				"Data": conversionAPISanitized,
				"Name": currentTableName,
				"TableStatus": 0,
				"TableNames": TableNames[uploadTableType]
			}

			if (conversionResult.format_valid === true) {
				switch (TableNames[uploadTableType]) {
					case TableNames['growth']:
						sendDataResult = await this.apiService.updateGrowthTable(requestBody);
						break;
					case TableNames['profitability']:
						sendDataResult = await this.apiService.updateProfitabilityTable(requestBody);
						break;
					case TableNames['volume-loss']:
						sendDataResult = await this.apiService.updateVolumeLossTable(requestBody, conversionObservableSanitized);
						break;
					default:
						break;
				}
			}
		} catch(e) {
			this.errorService.setError({
				message: 'Please upload your spreadsheet in the proper format.',
				title: 'Unable to display your table.',
				error: e,
				dialog: true
			});
		}

		form.clear();
		return sendDataResult;
	}

	incrementTableStatus = (uploadTableType: 'volume-loss' | 'profitability' | 'growth' | null) => async () => {
		let currentTableAPIData;
		let currentTableObservableData;
		let apiSerializedData: string;
		let observableSerializedData: string;
		let sendDataResult;
		let requestBody;
		let currentTableName;
		let currentTableId;
		let currentTableStatus;
		let tableDataMember = uploadTableType === 'volume-loss' ? 'volumeLoss' : uploadTableType;

		this.tableDataService[tableDataMember].pipe(take(1)).subscribe(data => {
			currentTableName = data.Name;
			currentTableId = data.Id;
			currentTableObservableData = data.Data;
			currentTableStatus = data.TableStatus;
			// API formatted data property won't exist if the table is not of type volume-loss
			if (data.DataAPIFormat) {
				currentTableAPIData = data.DataAPIFormat;
			} else {
				currentTableAPIData = data.Data
			}
		});

		
		// Volume Loss Ratio tables need to be re-formatted before data is sent to the back-end
		if (TableNames[uploadTableType] === TableNames['volume-loss']) {
			if (typeof currentTableAPIData !== 'string') {
				observableSerializedData = this.convertCSV.serializeJSON(currentTableObservableData);
				apiSerializedData = this.convertCSV.serializeJSON(currentTableAPIData);
			} else {
				observableSerializedData = currentTableObservableData;
				apiSerializedData = currentTableAPIData;
			}
		} else {
			apiSerializedData = this.convertCSV.serializeJSON(currentTableAPIData);
		}

		// Build request body
		requestBody = {
			"Id": currentTableId,
			"Data": apiSerializedData,
			"Name": currentTableName,
			"TableStatus": currentTableStatus + 1,
			"TableNames": TableNames[uploadTableType]
		}

		switch (TableNames[uploadTableType]) {
			case TableNames['growth']:
				sendDataResult = await this.apiService.updateGrowthTable(requestBody);
				this.router.navigate([`/${Paths.tables}`]);
				break;
			case TableNames['profitability']:
				sendDataResult = await this.apiService.updateProfitabilityTable(requestBody);
				this.router.navigate([`/${Paths.tables}`]);
				break;
			case TableNames['volume-loss']:
				sendDataResult = await this.apiService.updateVolumeLossTable(requestBody, observableSerializedData);
				this.router.navigate([`/${Paths.tables}`]);
				break;
			default:
				break;
		}

		return sendDataResult;
	};

	detectTableStatus = (tableStatus, uploadTableType) => {
		switch (tableStatus) {
			case TableStatus.Draft:
				this.buttonSet.submit.active = true;
				this.buttonSet.approve.active = false;
				this.buttonSet.submit.behavior = this.incrementTableStatus(uploadTableType);
				break;
			case TableStatus.Pending:
				this.buttonSet.approve.active = true;
				this.buttonSet.submit.active = false;
				this.buttonSet.approve.behavior = this.incrementTableStatus(uploadTableType);
				break;
			case TableStatus.Approved:
				this.buttonSet.approve.active = false;
				this.buttonSet.submit.active = false;
				this.buttonSet.approve.behavior = this.incrementTableStatus(uploadTableType);
				break;
			default:
				break;
		}
	}
}
