export interface Message {
    severity: 'warn' | 'info',
    detail: string,
    button: string,
    route: string
}
