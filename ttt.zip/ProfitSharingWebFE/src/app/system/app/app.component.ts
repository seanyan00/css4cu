import {
	AfterViewInit,
	Component,
	ElementRef,
	HostListener,
	OnDestroy,
	Renderer2,
	ViewChild,
	ViewEncapsulation,
	Inject,
	ChangeDetectorRef,
} from '@angular/core';

import { Router, NavigationEnd, ActivatedRoute, ActivationStart, ActivationEnd, ChildActivationEnd } from '@angular/router';
import { Paths } from '../../app.routing.enums';
import { filter } from 'rxjs/operators';

import { MIGSystemService } from '@services/mig.service';
import { Message } from './message';
import { MessageService } from '../../services/message.service';

import { TokenResponse } from '@auth/tokenresponse.class';

enum MenuOrientation {
	STATIC,
	OVERLAY,
	SLIM,
	HORIZONTAL
}

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.css'],
	encapsulation: ViewEncapsulation.None
})

export class AppComponent implements AfterViewInit, OnDestroy {
	e: ElementRef;
	showMobileMenu: boolean = false;
	showRightMenu: boolean = false;
	showAttachments: boolean = false;

	layoutMode: MenuOrientation = MenuOrientation.STATIC;
	staticMenuDesktopInactive: boolean = false;;
	staticMenuMobileActive: boolean;
	layoutMenuScroller: HTMLDivElement;
	resetMenu: boolean;
	menuHoverActive: boolean;
	num: number = 0;
	scl: string = "xl";
	center_wrapper_height: string = "";
	@ViewChild('layoutMenuScroller') layoutMenuScrollerViewChild: ElementRef;

    quote: any;
    LOB: string = '';
	token: TokenResponse;
	messages: Message[] = [];
	routeClass: string = '';

	constructor(public renderer: Renderer2,
		private cd: ChangeDetectorRef,
        public migsystemservice: MIGSystemService,
		@Inject(Document) public document: Document,
		private messageService: MessageService,
		private router: Router,
		private activatedRoute: ActivatedRoute) {}

	ngOnInit(): void {
		this.funcScale();

		this.createRouteClass();

		let toggleMenu = this.migsystemservice.subscribeToggleMenu().subscribe(toggle => {
			this.showMobileMenu = !this.showMobileMenu;
		});

		let toggleRHS = this.migsystemservice.subscribeToggleRHS().subscribe(toggle => {
			this.showRightMenu = !this.showRightMenu;
		});

		this.migsystemservice.subscribeShowAttachmentsDialog().subscribe(data => {
			this.showAttachments = !this.showAttachments;
		});
	}

	ngAfterViewInit() {
		this.funcScale();
		this.cd.detectChanges();
		
		setTimeout(() => {
			this.subscribeToMessages();
		}, 10);
	}

	ngOnDestroy() {}

	@HostListener('window:resize', ['$event']) onResize(event) {
		if (event) {
			this.funcScale();
		}
	}

	funcScale() {
		this.num = window.innerWidth;
		this.center_wrapper_height = (window.innerHeight - 90) + "px";
		
		if (this.num < 641) {
			this.scl = "sm";
		}
		
		if (this.num > 640) {
			this.scl = "md";
		}
		
		if (this.num > 1024) {
			this.scl = "lg";
			this.staticMenuDesktopInactive = false;
		}
		
		if (this.num > 1024) {

		}

		if (this.num > 1440) {
			this.scl = "xl";
			this.staticMenuDesktopInactive = false;
		}
		
		if ((this.scl == "md") || this.scl == "sm") {
			this.staticMenuDesktopInactive = true;
		}
		
		let dummy = this.isMobile();
	}

	isMobile() {
		let isMobile = window.innerWidth <= 1024;
		if (isMobile) {
			this.showMobileMenu = true;
			this.showRightMenu = true;
		}
		this.migsystemservice.notifyIsMobile(isMobile);
		this.showRightMenu = isMobile;
		this.showMobileMenu = isMobile;
		return isMobile;
	}

	isOverlay() { return this.layoutMode === MenuOrientation.OVERLAY; }
	
	isHorizontal() { return this.layoutMode === MenuOrientation.HORIZONTAL; }
	
	isSlim() { return this.layoutMode === MenuOrientation.SLIM; }

	createRouteClass() {
		this.router.events.pipe(
			filter(event => event instanceof ActivationStart)
			).subscribe(event => {
				const suffix = event['snapshot'].data.grid.replace(/\//, '-');
				this.routeClass = <string>`route-${suffix}`;
			});
	}

	addSingleMessage(message) {
		this.messages = [...this.messages, message[0]];
	}

	addMultipleMessages(messages) {
		this.messages = [...this.messages, messages];
	}

	clearMessage() {
		this.messages = [];
	}

	triggerMessage(payload: any): void {
		this.addSingleMessage(payload);
	}

	subscribeToMessages() {
		this.messageService.messagePayload.subscribe(payload => {
			if (!payload.length) return;
			this.addSingleMessage(payload)
		})
	}

	closeMessage() {
		this.messages.pop();
	}
}
