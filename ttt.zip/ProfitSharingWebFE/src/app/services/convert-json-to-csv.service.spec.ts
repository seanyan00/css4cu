import { TestBed } from '@angular/core/testing';

import { ConvertJsonToCsvService } from './convert-json-to-csv.service';

describe('ConvertJsonToCsvService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ConvertJsonToCsvService = TestBed.get(ConvertJsonToCsvService);
    expect(service).toBeTruthy();
  });
});
