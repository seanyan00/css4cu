import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Message } from '../system/app/message'

@Injectable({
	providedIn: 'root'
})
export class MessageService {
	messages = new BehaviorSubject(<Message[]>[]);
	messagePayload = this.messages.asObservable();

	constructor() { }

	setMessages(payload: any): void {
		this.messages.next(payload);
	}
}
