import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { AgentSearch } from '@services/api.service';

@Injectable({
	providedIn: 'root'
})
export class FilterService {
	reportRequest = new BehaviorSubject(false);
	currentReportRequest = this.reportRequest.asObservable();

	filters = new BehaviorSubject(<any>{});
	currentFilters = this.filters.asObservable();

	filtersSerialized = new BehaviorSubject(<AgentSearch>{});
	currentFiltersSerialized = this.filtersSerialized.asObservable();

	filtering = new BehaviorSubject(false);
	currentFiltering = this.filtering.asObservable();

	emptyResult = new BehaviorSubject(false);
	currentEmptyResult = this.emptyResult.asObservable();

	constructor() { }

	setFilters(filterObj: any) {
		let filterValues: AgentSearch = {
			filter: {
				Id: [],
				Territory: null,
				Region: null,
				AddendumAEnabled: null,
				AddendumCEnabled: null,
				IncludeCanceled: null,
				IncludeZeroPayments: null,
				IncludeSubagents: false,
				Page: 1,
				PageSize: 10
			}
		};

		// Store raw filters
		this.filters.next(filterObj);

		// This filter array is mainly used for the main agent list.
		// There are four properties (year, month, sorting, and nonPay)
		const filterKeys = Object.keys(filterObj).filter(filter => {
			switch (filter) {
				case 'page':
					filterValues.filter.Page = filterObj[filter];
					// This is not an actual filter value, so don't add it to the array
					return false;
				case 'code':
					if (!filterObj[filter]) return false;
					const regex = /([0-9]+)/g;
					const agentIds: string[] = filterObj[filter].toString().match(regex);
					filterValues.filter.Id = agentIds;
					return true;
				case 'mktTerritory':
					if (!filterObj[filter]) return false;
					filterValues.filter.Territory = filterObj[filter].value;
					return true;
				case 'region':
					if (!filterObj[filter]) return false;
					filterValues.filter.Region = filterObj[filter];
					return true;
				case 'addendum':
					if (!filterObj[filter].length) return false;
					
					// Check individual members of the checkbox array
					const anyChecked = filterObj[filter].filter((x) => {
						if (!x || (x && !x[0])) return false;
						switch (x[0]) {
							case 'A':
								filterValues.filter.AddendumAEnabled = true;
								break;
							case 'C':
								filterValues.filter.AddendumCEnabled = true;
								break;
							case 'CA':
								filterValues.filter.IncludeCanceled = true;
								break;
							case 'ZP':
								filterValues.filter.IncludeZeroPayments = true;
								break;
							default:
								break;
						}
						return true;
					});

					if (anyChecked.length) return true;
					break;
				case 'year':
					// Not a filter field. Used by report builder.
					// Return false since this field is not for filtering agents.
					return false;
				case 'month':
					// Not a filter field. Used by report builder.
					// Return false since this field is not for filtering agents.
					return false;
				case 'sorting':
					// Not a filter field. Used by report builder.
					// Return false since this field is not for filtering agents.
					return false;
				case 'nonPay':
					// Not a filter field. Used by report builder.
					// Return false since this field is not for filtering agents.
					return false;
				default:
					return false;
			}
		});

		if (filterKeys.length) {
			this.filtersSerialized.next(filterValues);
			this.filtering.next(true);
		} else {
			this.filtering.next(false);
		}
	}

	requestReport(shouldOpenReport): void {
		this.reportRequest.next(shouldOpenReport);
	}

	isFiltered(filtering): void {
		this.filtering.next(filtering);
	}

	isEmpty(empty): void {
		this.emptyResult.next(empty);
	}
}
