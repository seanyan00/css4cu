
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { MIGMenu } from '@shared/menu/menu.class';

@Injectable()
export class MIGSystemService {

	// Menu collapse or expand = true or false
	private subjectToggleMenu = new Subject<any>();
	notifyToggleMenu(toggle: boolean = false) { this.subjectToggleMenu.next(); }
	subscribeToggleMenu(): Observable<any> { return this.subjectToggleMenu.asObservable(); }

	// RHS collapse or expand = true or false
	private subjectToggleRHS = new Subject<any>();
	notifyToggleRHS(toggle: boolean = false) { this.subjectToggleRHS.next(); }
	subscribeToggleRHS(): Observable<any> { return this.subjectToggleRHS.asObservable(); }

	// go to step of process = number of step
	private subjectGoToStep = new Subject<any>();
	notifyGoToStep(step: number) { this.subjectGoToStep.next(step); }
	subscribeGoToStep(): Observable<any> { return this.subjectGoToStep.asObservable(); }

	private subjectGoToSubStep = new Subject<any>();
	notifyGoToSubStep(step: number) { this.subjectGoToSubStep.next(step); }
	subscribeGoToSubStep(): Observable<any> { return this.subjectGoToSubStep.asObservable(); }

	private subjectGoToSubStepLocation = new Subject<any>();
	notifyGoToSubStepLocation(step: number) { this.subjectGoToSubStepLocation.next(step); }
	subscribeGoToSubStepLocation(): Observable<any> { return this.subjectGoToSubStepLocation.asObservable(); }


	// // inject menu object = object
	// // store quote menu structure in quote component
	// // and inject it into our central menu system
	// private subjectInjectMenu = new Subject<any>();
	// notifyInjectMenu(menu: MIGMenu) { this.subjectInjectMenu.next(menu); }
	// subscribeInjectMenu(): Observable<MIGMenu> { return this.subjectInjectMenu.asObservable(); }

	// Save Quote
	private subjectSaveQuote = new Subject<any>();
	notifySaveQuote() { this.subjectSaveQuote.next(); }
	subscribeSaveQuote(): Observable<any> { return this.subjectSaveQuote.asObservable(); }

	// Show Hide Buttons
	private subjectButtons = new Subject<any>();
	notifyButtons(step: number) { this.subjectButtons.next(step); }
	subscribeButtons(): Observable<any> { return this.subjectButtons.asObservable(); }

	// Notify Premium
	private subjectPremium = new Subject<any>();
	notifyPremium(premium: number) { this.subjectPremium.next(premium); }
	subscribePremium(): Observable<any> { return this.subjectPremium.asObservable(); }

	// display block / loading message
	private subjectBlock = new Subject<any>();
	notifyBlock(arr: {}) { this.subjectBlock.next(arr); }
	subscribeBlock(): Observable<any> { return this.subjectBlock.asObservable(); }

	// validate step
	private subjectValidate = new Subject<any>();
	notifyValidate(step: number) { this.subjectValidate.next(step); }
	subscribeValidate(): Observable<any> { return this.subjectValidate.asObservable(); }

	// Update help content
	private subjectInjectHelp = new Subject<any>();
	notifyInjectHelp(info: {}) { this.subjectInjectHelp.next(info); }
	subscribeInjectHelp(): Observable<any> { return this.subjectInjectHelp.asObservable(); }

	// Add New Location
	private subjectAddLocation = new Subject<any>();
	notifyAddLocation() { this.subjectAddLocation.next(); }
	subscribeAddLocation(): Observable<any> { return this.subjectAddLocation.asObservable(); }

	private subjectGoToACTab = new Subject<any>();
	notifyGoToACTab(tab: number) { this.subjectGoToACTab.next(tab); }
	subscribeGoToACTab(): Observable<any> { return this.subjectGoToACTab.asObservable(); }

	private subjectIsMobile = new Subject<any>();
	notifyIsMobile(val: boolean) { this.subjectIsMobile.next(val); }
	subscribeIsMobile(): Observable<any> { return this.subjectIsMobile.asObservable(); }

	private subjectStepChanged = new Subject<any>();
	notifyStepChanged(step: number) { this.subjectStepChanged.next(step); }
	subscribeStepChanged(): Observable<any> { return this.subjectStepChanged.asObservable(); }

	// Add Attachments
	private subjectAttachments = new Subject<any>();
	notifyShowAttachmentsDialog(val) { this.subjectAttachments.next(val); }
	subscribeShowAttachmentsDialog(): Observable<any> { return this.subjectAttachments.asObservable(); }

	// Show Additional Coverages > Property
	private subjectACProperty = new Subject<any>();
	notifyShowACProperty(show: boolean) { this.subjectACProperty.next(show); }
	subscribeShowACProperty(): Observable<any> { return this.subjectACProperty.asObservable(); }

	// notification to validate the form
	private subjectValidateForm = new Subject<any>();
	notifyValidateForm(val: boolean) { this.subjectValidateForm.next(val); }
	subscribeValidateForm(): Observable<any> { return this.subjectValidateForm.asObservable(); }

	// there was a system error be it http request or otherwise
	// tell the user about it
	private subjectSystemError = new Subject<any>();
	notifySystemError(err: any) { this.subjectSystemError.next(err); }
	subscribeSystemError(): Observable<any> { return this.subjectSystemError.asObservable(); }

	// get and set our system version
	private subjectSystemVersion = new Subject<any>();
	notifySystemVersion() { this.subjectSystemVersion.next(); }
	subscribeSystemVersion(): Observable<any> { return this.subjectSystemVersion.asObservable(); }

	// CTRquote changed
	// some components need to know this happened; let them know
	private subjectQuoteChanged = new Subject<any>();
	notifyQuoteChanged(quote: any) { this.subjectQuoteChanged.next(quote); }
	subscribeQuoteChanged(): Observable<any> { return this.subjectQuoteChanged.asObservable(); }

	// next button triggers this
	// used to notify components to update their WINS keys
	private subjectUpdateRecordState = new Subject<any>();
	notifyUpdateRecordState() { this.subjectUpdateRecordState.next(); }
	subscribeUpdateRecordState(): Observable<any> { return this.subjectUpdateRecordState.asObservable(); }

	private subjectGotoSubStepMain = new Subject<any>();
	notifyGotoSubStepMain() { this.subjectGotoSubStepMain.next(); }
	subscribeGotoSubStepMain(): Observable<any> { return this.subjectGotoSubStepMain.asObservable(); }

}
