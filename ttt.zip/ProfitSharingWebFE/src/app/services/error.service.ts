import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export interface ErrorType {
	error: any,
	message: string,
	title: string,
	dialog: boolean
}
@Injectable({
	providedIn: 'root'
})
export class ErrorService {
	errors = new BehaviorSubject(<ErrorType | null>{});
	errorMessage = this.errors.asObservable();
	
	constructor() { }
	
	setError(error: ErrorType | null) {
		this.errors.next(error);
		if (error) console.error(error.error)
	}
}