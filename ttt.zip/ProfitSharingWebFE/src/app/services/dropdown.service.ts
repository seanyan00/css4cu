import { HttpClient, HttpClientModule, HttpRequest, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { pipe } from 'rxjs';
import { environment } from '@environment/environment';
import { Observable } from 'rxjs';

@Injectable()
export class DropDownService {

    private serverAPI = environment.proxyPath;

    constructor(private http: HttpClient) { }

    getDropDowns(): Observable<any>{

        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'RequestPath': 'GetDropDownValues/'
            })
        };

        return this.http.get(this.serverAPI + 'ProxyGet', httpOptions)
            .pipe(map((response: Response) => response))
	}
	
	getDropDownsSample(): Observable<any>{

        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'RequestPath': 'GetDropDownValues/'
            })
        };

        return this.http.get("./assets/dropdowns.json", httpOptions)
            .pipe(map((response: Response) => response))
            //.do(data => (console.log(data)))
    }
}



interface InsuredType {
    label: string;
}