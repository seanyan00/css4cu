import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ApiService, ProfitSharingCustomFields, ProfitSharingOrderOptions } from '@services/api.service';
import { ErrorService } from '@services/error.service';

@Injectable({
	providedIn: 'root'
})
export class ExportReportService {
	private _order = new BehaviorSubject(<ProfitSharingOrderOptions>{});
	private _nonPayment = new BehaviorSubject(false);
	private _customFields = new BehaviorSubject(<ProfitSharingCustomFields[]>{});
	private _agents = new BehaviorSubject(<string[]>{});
	private _year = new BehaviorSubject(<number>{});
	private _month = new BehaviorSubject(<number>{});
	private _displayPrintOptions = new BehaviorSubject(false);
	private _reportPending = new BehaviorSubject(<string[]>[]);
	private _asSub = new BehaviorSubject(<boolean>{});

	public order = this._order.asObservable();
	public nonPayment = this._nonPayment.asObservable();
	public customFields = this._customFields.asObservable();
	public agents = this._agents.asObservable();
	public year = this._year.asObservable();
	public month = this._month.asObservable();
	public displayPrintOptions = this._displayPrintOptions.asObservable();
	public reportPending = this._reportPending.asObservable();
	public asSub = this._asSub.asObservable();


    constructor(
		private apiService: ApiService,
		private errorService: ErrorService
	) { }
	
	// Sets the parameters for a report to be generated,
	// without executing the report.
	setReportParams(year, month, agents, asSub) {
		this._agents.next(agents);
		this._year.next(year);
		this._month.next(month);

		this._asSub.next(asSub)
	}

	setCustomFields(customFields) {
		this._customFields.next(customFields);
	}

	setOrder(order) {
		this._order.next(order);
	}

	setNonPayment(nonPayment) {
		this._nonPayment.next(nonPayment);
	}

	setAgents(agents) {
		if (agents && agents.length) this._agents.next(agents);
	}

	setPeriod(year, month) {
		if (!isNaN(year)) this._year.next(year);
		if (!isNaN(month)) this._month.next(month);
	}

	setReportPending(reportType: string) {
		const currentPendingReports = this._reportPending.value.slice();
		const index = currentPendingReports.indexOf(reportType);
		if (index === -1) {
			currentPendingReports.push(reportType);
		}
		this._reportPending.next(currentPendingReports);
	}

	unsetReportPending(reportType: string) {
		const currentPendingReports = this._reportPending.value.slice();
		const index = currentPendingReports.indexOf(reportType);
		if (index > -1) {
			currentPendingReports.splice(index, 1);
		}
		this._reportPending.next(currentPendingReports);
	}

	unsetLastReportPending() {
		const currentPendingReports = this._reportPending.value.slice();
		if (currentPendingReports.length) {
			currentPendingReports.pop();
		}
		this._reportPending.next(currentPendingReports);
	}

	// Data must be array of objects if all is not selected
	async export(
		type: ('custom' | 'excel' | 'bulk_pdf' | 'single_pdf'),
		includeBottom: boolean,
		all: boolean,
		batch: boolean,
		orderBy: ('Agent' | 'Region'),
		includeZeroPayment: boolean
	) {
		if (isNaN(this._year.value)
		|| isNaN(this._month.value)
		|| (type !== 'custom' && !all && (!this._agents.value || (this._agents.value && !this._agents.value.length)))) {
			this.errorService.setError({
				error: new Error('No report criteria provided'),
				message: 'No report criteria provided',
				title: 'Report Error',
				dialog: true
			});
			return;
		}

		let file;
		let fileURL;
		let result;
		let downloadLink

		try {
			if (type === 'excel') {
				this.setReportPending('excel');
				result = await this.apiService.profitSharingReportGeneration(
					type,
					this._year.value,
					(this._month.value + 1),
					this._agents.value,
					this._asSub.value,
					includeBottom
				);
				this.unsetReportPending('excel');
				// Create blob
				file = new Blob([result.body], {type: 'application/vnd.ms-excel'});
				// Generate URL
				fileURL = URL.createObjectURL(file);
				// Create download link
				downloadLink = document.createElement('a');
				downloadLink.target = '_blank';
				downloadLink.download = 'report.xls';
			} else if (type === 'bulk_pdf' && batch) {
				this.setReportPending('bulk_pdf');
				result = await this.apiService.profitSharingReportAsPDFBulk(
					this._year.value,
					(this._month.value + 1),
					this._agents.value,
					includeBottom,
					all,
					true,
					orderBy,
					includeZeroPayment
				);
				this.unsetReportPending('bulk_pdf');
				// Create blob
				file = new Blob([result.body], {type: 'application/pdf'});
				// Generate URL
				fileURL = URL.createObjectURL(file);
				// Create download link
				downloadLink = document.createElement('a');
				downloadLink.target = '_blank';
				downloadLink.download = 'report.pdf';
			} else if (type === 'bulk_pdf' && !batch) {
				this.setReportPending('bulk_pdf');
				result = await this.apiService.profitSharingReportAsPDFBulk(
					this._year.value,
					(this._month.value + 1),
					this._agents.value,
					includeBottom,
					all,
					false,
					orderBy,
					includeZeroPayment
				);
				this.unsetReportPending('bulk_pdf');
				// Create blob
				file = new Blob([result.body], {type: 'application/zip'});
				// Generate URL
				fileURL = URL.createObjectURL(file);
				// Create download link
				downloadLink = document.createElement('a');
				downloadLink.target = '_blank';
			// 	downloadLink.download = 'report.zip';
			} else if (type === 'single_pdf') {
				this.setReportPending('single_pdf');
				result = await this.apiService.profitSharingReportGeneration(
					"PDF",
					this._year.value,
					(this._month.value + 1),
					this._agents.value,
					this._asSub.value,
					includeBottom,
				);
				this.unsetReportPending('single_pdf');
				// Create blob
				file = new Blob([result.body], {type: 'application/pdf'});
				// Generate URL
				fileURL = URL.createObjectURL(file);
				// Create download link
				downloadLink = document.createElement('a');
				downloadLink.target = '_blank';
				downloadLink.download = 'report.pdf';
			} else if (type === 'custom') {
				this.setReportPending('custom');
				result = await this.apiService.profitSharingReportCustom(
					this._year.value,
					(this._month.value + 1),
					this._customFields.value,
					this._order.value,
					this._nonPayment.value
				);
				this.unsetReportPending('custom');
				// Create blob
				file = new Blob([result.body], {type: 'application/vnd.ms-excel'});
				// Generate URL
				fileURL = URL.createObjectURL(file);
				// Create download link
				downloadLink = document.createElement('a');
				downloadLink.target = '_blank';
				downloadLink.download = 'report.xls';
			}
		} catch(e) {
			this.errorService.setError({
				error: new Error('Could not generate report.'),
				message: 'Could not generate report.',
				title: 'Report Error',
				dialog: true
			});
			this.unsetLastReportPending();
			console.error(e);
			return;
		}

		// Set object URL as the anchor's href
		downloadLink.href = fileURL;

		// Append the anchor to document body
		document.body.append(downloadLink);

		// Fire a click event on the anchor
		downloadLink.click();
	}

	setDisplayPrintOptions(bool) {
		this._displayPrintOptions.next(bool);
	}
}
