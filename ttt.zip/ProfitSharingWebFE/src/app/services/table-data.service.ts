import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Table } from '@services/api.service';

@Injectable({
    providedIn: 'root'
})
export class TableDataService {
	private _profitability = new BehaviorSubject(<Table>{});
	private _profitabilityList = new BehaviorSubject(<Table[]>{});
	private _volumeLoss = new BehaviorSubject(<Table>{});
	private _volumeLossList = new BehaviorSubject(<Table[]>{});
    private _growth = new BehaviorSubject(<Table>{});
	private _growthList = new BehaviorSubject(<Table[]>{});
    

	public profitability = this._profitability.asObservable();
	public profitabilityList = this._profitabilityList.asObservable();
	public volumeLoss = this._volumeLoss.asObservable();
	public volumeLossList = this._volumeLossList.asObservable();
    public growth = this._growth.asObservable();
    public growthList = this._growthList.asObservable();
    
    constructor() { }
    
    setProfitability(data: Table) {
		this._profitability.next(data);
    }
    
    setProfitabilityList(data: Table[]) {
		this._profitabilityList.next(data);
	}

	setVolumeLoss(data: Table) {
		this._volumeLoss.next(data);
	}

    setVolumeLossList(data: Table[]) {
		this._volumeLossList.next(data);
	}

	setGrowth(data: Table) {
		this._growth.next(data);
    }
    
    setGrowthList(data: Table[]) {
		this._growthList.next(data);
	}
}


