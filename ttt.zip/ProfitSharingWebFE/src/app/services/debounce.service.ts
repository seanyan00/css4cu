import { Injectable } from '@angular/core';

@Injectable({
	providedIn: 'root'
})
export class DebounceService {

	constructor() { }

	timeout;

	debounce = function(func, wait, immediate) {
		let that = this;

		(function() {
			let context = this, args = arguments;
			let later = function() {
				clearTimeout(that.timeout);
				if (!immediate) func.apply(context, args);
			};

			let callNow = immediate && !that.timeout;
			clearTimeout(that.timeout);
			that.timeout = setTimeout(later, wait);

			if (callNow) func.apply(context, args);
		})();
	};
}
