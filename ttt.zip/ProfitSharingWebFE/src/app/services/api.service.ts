import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { TreeNode } from 'primeng/api';
import { take } from 'rxjs/operators';

import { TableDataService } from '@services/table-data.service';
import { AgentDataService } from '@services/agent-data.service';
import { ConvertCsvToJsonService } from '@services/convert-csv-to-json.service';
import { FilterService } from '@services/filter.service'

import {environment} from '@environment/environment';
import { isUndefined } from 'node_modules/util-deprecate';
import { Observable } from 'rxjs';

const httpOptions = {
  headers: new HttpHeaders({
	'Content-Type': 'application/json',
	'Accept': 'application/json'
  })
};

export interface SearchResults {
	TotalMatches: number | null,
	NumberReturned?: number | null,
	FirstItemIndex?: number | null,
	LastItemIndex?: number | null,
	NumberRemaining?: number | null,
	Page?: number | null,
	PageSize?: number | null,
	TotalPages?: number | null,
	Items: Agent[]
}

export interface Agent {
	Index?: number,
	AdnA?: boolean,
	AdnC?: boolean,
	AgentCode?: string,
	AgentId?: string,
	MinPremium?: number,
	Name?: string,
	Region?: string,
	SubAgent?: string,
	Territory?: string,
	loadMore?: boolean,
	data?: {
		nextPage: number,
		totalPages: number,
		year: string,
		masterAgentId: string
	}
}

export interface AgentSearch {
	filter: {
        Id: string[] | number[],
        Territory: number,
        Region: string,
        AddendumAEnabled: boolean,
        AddendumCEnabled: boolean,
        IncludeCanceled: boolean,
        IncludeZeroPayments: boolean,
        Page: number,
		PageSize: number,
		IncludeSubagents: boolean
	}
}

export interface AgentSearchResults {
	TotalMatches: number,
	NumberReturned: number,
	FirstItemIndex: number,
	LastItemIndex: number,
	NumberRemaining: number,
	Filter: {
	  Id: string[] | number[],
	  Territory: string,
	  Region: string,
	  AddendumAEnabled: boolean,
	  AddendumCEnabled: boolean,
	  IncludeCanceled: boolean,
	  IncludeZeroPayments: boolean,
	  Page: number,
	  PageSize: number
	},
	Page: number,
	PageSize: number,
	TotalPages: number,
	Items: Agent[]
}

export enum TableStatus {
    Draft = 0,
    Pending,
    Approved
}

export enum TableNames {
	'profitability' = 1,
	'growth',
	'volume-loss'
}

export interface Table {
	Id?: number,
	Data: string,
	DataAPIFormat?: string
	Name: string,
	TableStatus: TableStatus,
	TableNames: TableNames,
}

export interface Plan {
	PlanId?: number,
	PlanName: string,
	StartYear: number,
	EndYear: number,
	MinPremium: number,
	ThreeYearProfitabilityReferenceId: number,
	ThreeYearProfitabilityReferenceName?: string,
	ProfitGrowthFactorsReferenceId: number,
	ProfitGrowthFactorsReferenceName?: string,
	PremiumVolumeLossRatioReferenceId: number,
	PremiumVolumeLossRatioReferenceName?: string,
	DisablePlan: number
}

export interface TableAssignments {
	Id?: number,
	PlanId?: number,
	StartYear: number,
	EndYear: number,
	PlanInformationId: number,
	ThreeYearProfitabilityId?: number,
	ThreeYearProfitabilityReference?: Pick<Table, 'Name' | 'Id'>,
	ProfitGrowthFactorsId?: number,
	ProfitGrowthFactorsReference?: Pick<Table, 'Name' | 'Id'>,
	PremiumVolumeLossRatioId?: number,
	PremiumVolumeLossRatioReference?: Pick<Table, 'Name' | 'Id'>
}

export interface Product {
	Id?: number,
	ProductName: string,
	Year: number,
	Included: boolean
}

export interface Territory {
	Id?: number,
	PlanInformation?: {
		Id: number,
		PlanName: string
	},
	PlanInformationId?: number,
	EffectiveYear: number,
	MarketingTerritory: string,
	IncludePersonalLines: boolean
}

export interface MinPremium {
	Id?: number,
	PlanInformation: {
		Id: number,
		PlanName: string
	},
	Premium: number,
	StartYear: number,
	EndYear: number
}

export interface AdnA {
	Id?: number,
	Value: number,
	StartYear: number,
	EndYear: number
}

export interface AdnAAssignment {
	Id?: number,
	AgentCode: string,
	Year: number,
	MinPremium?: number,
	IsEnabled: boolean
}

export interface AdnC {
	Id?: number,
	AgentId: string,
	IsEnabled: boolean,
	Year: number
}

export interface ProfitSharingReportTop {
	AGENT : string;
	AGYCDE : string;
	CDDESC : string;
	AGYNAM : string;
	AGYAD1 : string;
	AGYAD2 : string;
	AGYAD3 : string;
	AGYCTY : string;
	AGYST : string; 
	AGYZIP : string;
	MKTTER: string;
	SUBAGENTS: string[];
	ProductId: string,
	AdjustedWrittenPremium: number;
	ChargeOffsAndWC: number;
	NetAdjustedPremiums: number;
	AdjustedEarnedPremiums: number;
	NetAdjustedEarnedPremiums: number;
	LossAdjustmentExpense: number;
	IncurredLossesBeforeStopLoss: number;
	IncurredLossesAfterStopLoss: number;
	LossRatio: number;
	Subagent_cnt: number;
}

export interface ProfitSharingReportBottom {
	PreviousYearNetAdjustedWrittenPremiums: number,
    EarnedPremiums: number,
    LossRatio: number,
    WrittenPremiumVolume: number,
    PremiumVolumeAndLossRatioFactor: number,
    GrowthRate: number,
    PremiumGrowthFactor: number,
    NineMonthLossLock: number,
    ThreeYearProfitability: number,
    ThreeYearProfitabilityFactor: number,
	ProfitSharingPayment: number,
	NetAdjustedEarnedPremiums: number
}

export interface SubAgents {

	CDKEY2: string[];
	AGYCDE: string;
	AGYNAM: string;
}

export enum ProfitSharingCustomFields {
	AdjustedEarnedPremiums = 'AdjustedEarnedPremiums',
	ChargeOffsWCDividends = 'ChargeOffsWCDividends',
	IncurredLossAfterStopLoss = 'IncurredLossAfterStopLoss',
	IncurredLossBeforeStopLoss = 'IncurredLossBeforeStopLoss',
	LossAdjustmentExpense = 'LossAdjustmentExpense',
	NetAdjustedEarnedPremiums = 'NetAdjustedEarnedPremiums',
	NetAdjustedWrittenPremiums = 'NetAdjustedWrittenPremiums',
	PriorYearPIF = 'PriorYearPIF',
	ThreeYearProfitPct = 'ThreeYearProfitPct'
}

export enum ProfitSharingOrderOptions {
	Default = 'Default',
	Region = 'Region',
	Territory = 'Territory'
}

@Injectable({
	providedIn: 'root'
})
export class ApiService {
	//RRF - MADE CHANGE HERE
	//apiURL: string = 'http://dev-pfs-app:8080/';
	apiURL: string = environment.proxyPath;

	constructor(
		private http: HttpClient,
		private tableService: TableDataService,
		private agentDataService: AgentDataService,
		public convertCSV: ConvertCsvToJsonService,
		private filterService: FilterService) { 
			//console.log("ENVPATH = " + this.apiURL);
		}

	// Import Process

	startImportProcess() {
		return this.http.get(`${this.apiURL}api/StartProcessing`)
		.toPromise()
		.then((response: number) => {
			return response;
		})
		.catch((err: HttpErrorResponse) => {
			console.error('An error occurred:', err);
			throw new Error(err.error);
		});
	}

	// Agents

	getAgentStartDate(id) {
		return this.http.get(`${this.apiURL}/api/AgentInfo/StartDate/${id}`)
		.toPromise()
		.then((response: {AgentId: string, ActualStartDate: number, CalculatedStartDate: number}) => {
			return response.ActualStartDate;
		})
		.catch((err: HttpErrorResponse) => {
			console.error('An error occurred:', err);
			throw new Error(err.error);
		})
	}

	getAgentTotal() {
		return this.http.get(`${this.apiURL}api/AgentInfo/TotalNumberOfAgents`)
		.toPromise()
		.then((response: number) => {
			this.agentDataService.setAgentListLength(response, false);
			return response;
		})
		.catch((err: HttpErrorResponse) => {
			console.error('An error occurred:', err);
			throw new Error(err.error);
		});
	}

	getAgentsPaginated(year, month, page) {
		// Current class reference
		const self = this;
		// Build empty filter object to conduct a full agent search
		const filters: AgentSearch = {
			filter: {
				Id: [],
				Territory: null,
				Region: null,
				AddendumAEnabled: null,
				AddendumCEnabled: null,
				IncludeCanceled: null,
				IncludeZeroPayments: null,
				IncludeSubagents: false,
				Page: (page + 1),
				PageSize: 10
			}
		};
		// Add year to the filter, and convert to string is needed
		if (typeof year === 'number') {
			filters.filter['Year'] = year.toString();
		} else {
			filters.filter['Year'] = year;
		}
		return this.http.post(`${this.apiURL}api/AgentInfo/Search2/`, filters, httpOptions).toPromise()
		.then(async(res: AgentSearchResults) => {
			// If there are no results, then set agent list to empty array.
			if (!res) {
				this.agentDataService.setAgentListLength(0, true);
				return;
			} else {
				this.agentDataService.setAgentListLength(res.TotalMatches, false);
			}
			// Store the data in an array to prepare for processing subagents
			let dataSet = res.Items;
			// Process subagents
			return await self.processAgents(dataSet, year, month, true, false, true);
		})
		.catch((err: HttpErrorResponse) => {
			console.error('An error occurred:', err);
			throw new Error(err.error);
		});
	}

	getAgentById(id, year, month, shouldUpdateMainList) {
		// Current class reference
		const self = this;
		return this.http.get(`${this.apiURL}api/AgentInfo/GetAgentById/${id}`)
		.toPromise()
		.then(async (res: Agent) => {
			if (!res && shouldUpdateMainList) {
				this.agentDataService.setAgentListLength(0, true);
				return;
			} else if (res && shouldUpdateMainList) { 
				this.agentDataService.setAgentListLength(1, true);
			}
			// Store the data in an array to prepare for processing subagents
			let dataSet = [res];
			// Process subagents
			return await self.processAgents(dataSet, year, month, shouldUpdateMainList, false, false);
		})
		.catch((err: HttpErrorResponse) => {
			console.error('An error occurred:', err.error);
			throw new Error(err.error);
		})
	}

	searchAgents(filters: AgentSearch, year, month, shouldUpdateMainList, shouldProcessSubAgents) {
		// Add year to the filter, and convert to string is needed
		if (typeof year === 'number') {
			filters.filter['Year'] = year.toString();
		} else {
			filters.filter['Year'] = year;
		}
		// Current class reference
		const self = this;
		return this.http.post(`${this.apiURL}api/AgentInfo/Search2/`, filters, httpOptions).toPromise()
			.then(async (res: AgentSearchResults) => {
				// If there are no results, then set agent list to empty array.
				if (!res && shouldUpdateMainList) {
					this.agentDataService.setAgentListLength(0, true);
					return;
				} else if (res && shouldUpdateMainList) {
					this.agentDataService.setAgentListLength(res.TotalMatches, false);
				}
				// Store the data in an array to prepare for processing subagents
				let dataSet = res.Items;
				if (shouldProcessSubAgents) {
					// Process subagents
					return await self.processAgents(dataSet, year, month, shouldUpdateMainList, true, true);
				} else {
					return dataSet;
				}
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			})
	}

	async processAgents(dataSet, year, month, shouldUpdateMainList, isFiltering, separateSubAgentLookup) {
		// Current class reference
		const self = this;
		// Array to hold agent (and subagent) data
		let modifiedAgentList = [];
		// Map over entire dataset
		if (dataSet instanceof Array) {
			try {
				for (let data of dataSet) {
					let hasSubAgents = null;
					let subAgentLookup = null;
					if (!separateSubAgentLookup) {
						// Parse the SubAgent property string to JSON
						subAgentLookup = data.SubAgent ? JSON.parse(data.SubAgent) : null
						hasSubAgents = subAgentLookup ? subAgentLookup.length : null;
					} else {
						// Check each agent for sub agents
						subAgentLookup = await self.getSubAgents(data.AgentId, year, 0, 0);
						hasSubAgents = subAgentLookup.TotalMatches
					}

					// Attach additional properties to indicate sub agents
					if (hasSubAgents) {
						// If sub agents exist hit API to retrieve them
						const subAgentList = await self.getSubAgents(data.AgentId, year, 0, 15)

						// Format object to prepare for display in TreeTable
						let formattedAgents = [];
						if (subAgentList.Items instanceof Array) {
							formattedAgents = subAgentList.Items.map( agent => { return { data: agent } });

							for (let subAgent of formattedAgents) {
								// Check sub agent's Addendum A eligibility
								await self.checkAdnAForGivenYear(subAgent.data, year, month);

								// Check sub agent's Addendum C eligibility
								await self.checkAdnCForGivenYear(subAgent.data, year, month);
							}

							const totalPagesArray = [];
							for (let i = 1; i <= subAgentList.TotalPages; i++) {
								totalPagesArray.push(i);
							}

							// If the current array of sub-agents is not complete, and more pages exist
							if (subAgentList.NumberRemaining != 0) {
								formattedAgents.push({
									loadMore: true,
									data: {
										page: subAgentList.Page - 1,
										nextPage: subAgentList.Page,
										totalPages: subAgentList.TotalPages,
										totalPagesArray,
										totalMatches: subAgentList.TotalMatches,
										year,
										masterAgentId: data.AgentId
									}
								})
							}
						}

						// Add agent and sub agents to the accumulator
						modifiedAgentList = [...modifiedAgentList, { data: data, children: formattedAgents }] as TreeNode[];
					} else {
						// Add agent to the accumulator
						modifiedAgentList = [...modifiedAgentList, { data: data }] as TreeNode[];
					}
				}

				if (shouldUpdateMainList) {
					let globalFilterStatus = false;
					// Set a class property to signal that we are currently filtering the agent list (in the UI)
					this.filterService.currentFiltering.pipe(take(1)).subscribe(isFiltering => globalFilterStatus = isFiltering);
					// If this request was for an unfiltered data set, then do not update the observable agent list
					if (!isFiltering && globalFilterStatus) {
						return;
					}
					this.agentDataService.setAgentList(year, month, modifiedAgentList, isFiltering);
				}

				return dataSet;
			} catch (e) {
				console.error(e);
			}
		}
	}

	hasSubAgents(id) {
		return this.http.get(`${this.apiURL}api/AgentInfo/HasSubAgents/${id}`)
		.toPromise()
		.then((res: boolean) => res)
		.catch((err: HttpErrorResponse) => {
			console.error('An error occurred:', err.error);
			throw new Error(err.error);
		});
	}

	getSubAgents(id, year, page, records) {
		page = page ? page : 0;
		records = records ? records : 0;
		return this.http.get(`${this.apiURL}api/AgentInfo/GetSubAgents/${id.toString().trim()}/${year}/${page}/${records}`)
		.toPromise()
		.then((subAgents: SearchResults ) => subAgents)
		.catch((err: HttpErrorResponse) => {
			console.error('An error occurred:', err.error);
			throw new Error(err.error);
		});
	}

	// Tables

	setProfitabilityTable(body: Table) {
		const missingProperties = Object.keys(body).filter((prop: string) => {
			return body[prop] === null || body[prop] === undefined || body[prop] === '';
		});

		if (missingProperties.length > 0) throw new Error('Data could not be sent: ' + missingProperties);

		return this.http.post(`${this.apiURL}api/AddTable`, body, httpOptions).toPromise()
			.then((response: number) => {
				body.Data = JSON.parse(body.Data);
				body.Id = response;
				this.tableService.setProfitability(body);
				return response;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	setGrowthTable(body: Table) {
		const missingProperties = Object.keys(body).filter((prop: string) => {
			return body[prop] === null || body[prop] === undefined || body[prop] === '';
		});

		if (missingProperties.length > 0) throw new Error('Data could not be sent: ' + missingProperties);

		return this.http.post(`${this.apiURL}api/AddTable`, body, httpOptions).toPromise()
			.then((response: number) => {
				body.Data = JSON.parse(body.Data);
				body.Id = response;
				this.tableService.setGrowth(body);
				return response;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	setVolumeLossTable(requestBody: Table, observableFormat: string) {
		const missingProperties = Object.keys(requestBody).filter((prop: string) => {
			return requestBody[prop] === null || requestBody[prop] === undefined || requestBody[prop] === '';
		});

		if (missingProperties.length > 0) throw new Error('Data could not be sent: ' + missingProperties);

		return this.http.post(`${this.apiURL}api/AddTable`, requestBody, httpOptions).toPromise()
			.then((response: number) => {
				requestBody.DataAPIFormat = requestBody.Data;
				requestBody.Data = observableFormat;
				requestBody.Id = response;
				this.tableService.setVolumeLoss(requestBody);
				return response;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	getTable(id) {
		return this.http.post(`${this.apiURL}api/GetTable`, id).toPromise()
			.then((dataSet: Table) => {
				switch (dataSet.TableNames) {
					case TableNames['growth']:
						this.tableService.setGrowth(dataSet);
						break;
					case TableNames['profitability']:
						this.tableService.setProfitability(dataSet);
						break;
					case TableNames['volume-loss']:
						dataSet.DataAPIFormat = dataSet.Data;
						const reformattedData = this.convertCSV.reformatVolumeLossDataForUI(JSON.parse(dataSet.Data));
						dataSet.Data = this.convertCSV.serializeJSON(reformattedData);
						this.tableService.setVolumeLoss(dataSet);
						break;
					default:
						break;
				}
				return dataSet;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	getProfitabilityTables(): Promise<Table[]> {
		return this.http.post(`${this.apiURL}api/GetTables`, TableNames['profitability']).toPromise()
			.then((dataSet: Table[]) => {
				this.tableService.setProfitabilityList(dataSet);
				return dataSet;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	getGrowthTables(): Promise<Table[]> {
		return this.http.post(`${this.apiURL}api/GetTables`, TableNames['growth']).toPromise()
			.then((dataSet: Table[]) => {
				this.tableService.setGrowthList(dataSet);
				return dataSet;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	getVolumeLossTables(): Promise<Table[]> {
		return this.http.post(`${this.apiURL}api/GetTables`, TableNames['volume-loss']).toPromise()
			.then((dataSet: Table[]) => {
				this.tableService.setVolumeLossList(dataSet);
				return dataSet;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	updateProfitabilityTable(body: Table) {
		const missingProperties = Object.keys(body).filter((prop: string) => {
			return body[prop] === null || body[prop] === undefined || body[prop] === '';
		});

		if (missingProperties.length > 0) throw new Error('Data could not be sent: ' + missingProperties);

		return this.http.post(`${this.apiURL}api/UpdateTable`, body, httpOptions).toPromise()
			.then((response: number) => {
				body.Data = JSON.parse(body.Data);
				this.tableService.setProfitability(body);
				return response;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	updateGrowthTable(body: Table) {
		const missingProperties = Object.keys(body).filter((prop: string) => {
			return body[prop] === null || body[prop] === undefined || body[prop] === '';
		});

		if (missingProperties.length > 0) throw new Error('Data could not be sent: ' + missingProperties);

		return this.http.post(`${this.apiURL}api/UpdateTable`, body, httpOptions).toPromise()
			.then((response: number) => {
				body.Data = JSON.parse(body.Data);
				this.tableService.setGrowth(body);
				return response;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	updateVolumeLossTable(requestBody: Table, observableFormat: string) {
		const missingProperties = Object.keys(requestBody).filter((prop: string) => {
			return requestBody[prop] === null || requestBody[prop] === undefined || requestBody[prop] === '';
		});

		if (missingProperties.length > 0) throw new Error('Data could not be sent: ' + missingProperties);

		return this.http.post(`${this.apiURL}api/UpdateTable`, requestBody, httpOptions).toPromise()
			.then((response: number) => {
				requestBody.DataAPIFormat = JSON.parse(requestBody.Data);
				requestBody.Data = observableFormat;
				this.tableService.setVolumeLoss(requestBody);
				return response;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	// Plans

	setPlan(body: Plan) {
		const missingProperties = Object.keys(body).filter((prop: string) => {
			return (prop !== 'EndYear') && (body[prop] === null || body[prop] === undefined || body[prop] === '');
		});

		if (missingProperties.length > 0) throw new Error('Data could not be sent: ' + missingProperties);

		return this.http.post(`${this.apiURL}api/AddPlan`, body, httpOptions).toPromise()
			.then((response: number) => {
				return response;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	getPlan(id) {
		return this.http.post(`${this.apiURL}api/GetPlanInformationById`, id).toPromise()
			.then((dataSet: Plan) => {
				return dataSet;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	getPlanTableAssignments(id): Promise<TableAssignments[]> {
		return this.http.get(`${this.apiURL}api/GetAllPlansToManageByPlanInfoId/${id}`).toPromise()
			.then((dataSet: TableAssignments[]) => {
				return dataSet;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	getAllPlans(): Promise<Plan[]> {
		return this.http.get(`${this.apiURL}api/GetAllPlans`, {}).toPromise()
			.then((dataSet: Plan[]) => {
				return dataSet;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	updatePlan(body: Plan) {
		const missingProperties = Object.keys(body).filter((prop: string) => {
			return body[prop] === null || body[prop] === undefined || body[prop] === '';
		});

		if (missingProperties.length > 0) throw new Error('Data could not be sent: ' + missingProperties);

		return this.http.post(`${this.apiURL}api/EditPlan`, body, httpOptions).toPromise()
			.then((response: number) => {
				return response;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	deletePlan(id) {
		
		if (id === 0) throw new Error('Please select a valid plan');

		return this.http.delete(`${this.apiURL}api/DeletePlan/${id}`, httpOptions).toPromise()
			.then((response: boolean) => {
				return response;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	enableDisablePlan(id, disable) {

		if (id === 0) throw new Error('Please select a valid plan');

		return this.http.post(`${this.apiURL}api/EnableDisablePlan/${id}/${disable}`, httpOptions).toPromise()
			.then((response: boolean) => {
				return response;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	updateTableAssignment(body: TableAssignments) {
		const missingProperties = Object.keys(body).filter((prop: string) => {
			return body[prop] === null || body[prop] === undefined || body[prop] === '';
		});

		if (missingProperties.length > 0) throw new Error('Data could not be sent: ' + missingProperties);

		return this.http.post(`${this.apiURL}api/EditPlanToManage`, body, httpOptions).toPromise()
			.then((response: number) => {
				return response;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	addTableAssignment(body: TableAssignments) {
		const missingProperties = Object.keys(body).filter((prop: string) => {
			return body[prop] === null || body[prop] === undefined || body[prop] === '';
		});

		if (missingProperties.length > 0) throw new Error('Data could not be sent: ' + missingProperties);

		return this.http.post(`${this.apiURL}api/AddNewPlanToManage`, body, httpOptions).toPromise()
			.then((response: number) => {
				return response;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	// Products

	getAllProducts(): Promise<string[]> {
		return this.http.get(`${this.apiURL}api/GetAllProducts`).toPromise()
			.then((dataSet: string[]) => {
				return dataSet;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	getProductsByYear(year): Promise<Product[]> {
		return this.http.get(`${this.apiURL}api/GetAllProductsByYear/${year}`).toPromise()
			.then((dataSet: Product[]) => {
				return dataSet;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	addProductForYear(body: Product) {
		return this.http.post(`${this.apiURL}api/AddProduct`, body).toPromise()
			.then((response: number) => {
				body.Id = response;
				return body;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	updateProductForYear(body: Product) {
		return this.http.post(`${this.apiURL}api/UpdateProduct`, body).toPromise()
			.then((response: number) => {
				return body;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	// Territories

	getAllTerritories(): Promise<string[]> {
		return this.http.get(`${this.apiURL}api/GetMarketingTerritories`).toPromise()
			.then((dataSet: string[]) => {
				return dataSet;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	getTerritoriesByPlan(id): Promise<Territory[]> {
		return this.http.get(`${this.apiURL}api/GetAllMarketingTerrByPlanId/${id}`).toPromise()
			.then((dataSet: Territory[]) => {
				return dataSet;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	getTerritoriesByYear(year): Promise<Territory[]> {
		return this.http.get(`${this.apiURL}api/GetAllMarketingTerrByYear/${year}`).toPromise()
			.then((dataSet: Territory[]) => {
				return dataSet;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	addPlanToTerritory(body: Territory): Promise<Territory> {
		return this.http.post(`${this.apiURL}api/AddPlanToMarketingTerritory/${body.PlanInformation.Id}`, body).toPromise()
			.then((response: number) => {
				body.Id = response;
				return body;
			})
			.catch((err: HttpErrorResponse) => {
				throw new Error(err.error);
			})
	}

	updateTerritoryForYear(body: Territory): Promise<Territory> {
		return this.http.post(`${this.apiURL}api/UpdatePlanForMarketingTerritory`, body).toPromise()
			.then((response: Territory) => {
				return response;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	// Minimum Premium

	getAllMinPremiumsForPlan(planId: number): Promise<MinPremium[]> {
		return this.http.post(`${this.apiURL}api/GetAllMinWrittenPremiumByPlanID`, planId).toPromise()
			.then((dataSet: MinPremium[]) => {
				return dataSet;
			})
			.catch((err: HttpErrorResponse) => {
				throw new Error(err.error);
			})
	}

	addMinPremiumToPlan(body: MinPremium): Promise<MinPremium> {
		return this.http.post(`${this.apiURL}api/AddMinPremium/${body.PlanInformation.Id}`, body).toPromise()
			.then((response: number) => {
				body.Id = response;
				return body;
			})
			.catch((err: HttpErrorResponse) => {
				throw new Error(err.error);
			})
	}

	updateMinPremiumForPlan(body: MinPremium): Promise<MinPremium> {
		return this.http.post(`${this.apiURL}api/EditMinWrittenPremium`, body).toPromise()
			.then((response: number) => {
				body.Id = response;
				return body;
			})
			.catch((err: HttpErrorResponse) => {
				throw new Error(err.error);
			})
	}

	// Adn A

	getAllAdnA(): Promise<AdnA[]> {
		return this.http.post(`${this.apiURL}api/GetAllAddendumAGrowthPercentage`, null).toPromise()
			.then((dataSet: AdnA[]) => {
				return dataSet;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	getAdnAByAgent(agentCode): Promise<AdnAAssignment[]> {
		return this.http.post(`${this.apiURL}api/GetAddendumAByAgentCode/${agentCode}`, null).toPromise()
			.then((dataSet: AdnAAssignment[]) => {
				return dataSet;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	getAllAdnAForAgents(): Promise<AdnAAssignment[]> {
		return this.http.post(`${this.apiURL}api/GetAll`, null).toPromise()
			.then((dataSet: AdnAAssignment[]) => {
				return dataSet;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	async checkAdnAForGivenYear(data, year, month) {
		// Check for Addendum A eligibility
		const agentData = await this.searchAgents({
			filter: {
				Id: [data.AgentId],
				Territory: null,
				Region: null,
				AddendumAEnabled: null,
				AddendumCEnabled: null,
				IncludeCanceled: null,
				IncludeZeroPayments: null,
				Page: 1,
				PageSize: 1,
				IncludeSubagents: false
			}
		}, year, month, false, false);

		// Set current agent's "AdnA" property
		data.AdnA = agentData[0] && agentData[0].AdnA
			? agentData[0].AdnA
			: false;
		
		// Set current agent's "MinPremium" property
		data.MinPremium = agentData[0] && agentData[0].MinPremium
			? agentData[0].MinPremium
			: 0;

		return data;
	}

	addAdnA(body: AdnA): Promise<AdnA> {
		return this.http.post(`${this.apiURL}api/AddAddAGrowthPerentage`, body).toPromise()
			.then((response: number) => {
				body.Id = response;
				return body;
			})
			.catch((err: HttpErrorResponse) => {
				throw new Error(err.error);
			})
	}

	addAdnAToAgent(body: AdnAAssignment): Promise<AdnAAssignment> {
		return this.http.post(`${this.apiURL}api/AddAddendumA`, body).toPromise()
			.then((response: number) => {
				body.Id = response;
				return body;
			})
			.catch((err: HttpErrorResponse) => {
				throw new Error(err.error);
			})
	}

	updateAdnA(body: AdnA): Promise<AdnA> {
		return this.http.post(`${this.apiURL}api/UpdateAddAGrowthPercentage`, body).toPromise()
			.then((response: number) => {
				return body;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	updateAdnAForAgent(body: AdnAAssignment): Promise<AdnAAssignment> {
		return this.http.post(`${this.apiURL}api/SaveAddendumA`, body).toPromise()
			.then((response: number) => {
				return body;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	bulkAdnAAssignment(body: AdnAAssignment[]): Promise<AdnAAssignment[]> {
		return this.http.post(`${this.apiURL}api/AddBulkAddendumA`, body).toPromise()
			.then((dataSet: AdnAAssignment[]) => {
				return dataSet;
			})
			.catch((err: HttpErrorResponse) => {
				throw new Error(err.error);
			})
	}

	// Adn C

	addAdnCToAgent(body: AdnC): Promise<AdnC> {
		return this.http.post(`${this.apiURL}api/AgentInfo/AddAddendumC`, body).toPromise()
			.then(() => {
				return body;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			})
	}

	getAdnCByAgent(agentCode): Promise<AdnC[]> {
		return this.http.post(`${this.apiURL}api/AgentInfo/GetAdnCByAgentId/${agentCode}`, null).toPromise()
			.then((dataSet: AdnC[]) => {
				return dataSet;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	
	async checkAdnCForGivenYear(data, year, month) {
		// Check for Addendum C eligibility
		const agentData = await this.searchAgents({
			filter: {
				Id: [data.AgentId],
				Territory: null,
				Region: null,
				AddendumAEnabled: null,
				AddendumCEnabled: null,
				IncludeCanceled: null,
				IncludeZeroPayments: null,
				Page: 1,
				PageSize: 1,
				IncludeSubagents: false
			}
		}, year, month, false, false);

		// Set current agent's "AdnC" property
		data.AdnC = agentData[0] && agentData[0].AdnC
			? agentData[0].AdnC
			: false;

		return data;
	}

	updateAdnCForAgent(body: AdnC): Promise<AdnC> {
		return this.http.post(`${this.apiURL}api/AgentInfo/SaveAddendumC`, body).toPromise()
			.then((response: AdnC) => {
				return response;
			})
			.catch((err: HttpErrorResponse) => {
				console.error('An error occurred:', err.error);
				throw new Error(err.error);
			});
	}

	bulkAdnCAssignment(file): Promise<AdnC[]> {
		if (file.type !== 'application/vnd.ms-excel'
		&& file.type !== 'text/csv') {
			throw new Error('Incorrect Format')
		}
		const formData: FormData = new FormData();
		formData.append('file', file, file.name);
		return this.http.post(`${this.apiURL}api/BulkFileAddendumC`, formData).toPromise()
			.then((dataSet: AdnC[]) => {
				return dataSet;
			})
			.catch((err: HttpErrorResponse) => {
				throw new Error(err.error);
			})
	}

	// Reports

	////TODO
	profitSharingAgentRollupReport(year: number, month: number, agents: string[]): Promise<ProfitSharingReportBottom[]> {
		return this.http.post(`${this.apiURL}api/ProfitSharingAgentRollupReport/${year}/${month}`, agents, httpOptions).toPromise()
			.then((dataSet: ProfitSharingReportBottom[]) => {
				return dataSet;
			})
			.catch((err: HttpErrorResponse) => {
				throw new Error(err.error);
			})
	}


	//TODO
	profitSharingAgentOnlyReport(year: number, month: number, agents: string[]): Promise<ProfitSharingReportBottom[]> {
		return this.http.post(`${this.apiURL}api/ProfitSharingAgentOnlyReport/${year}/${month}`, agents, httpOptions).toPromise()
			.then((dataSet: ProfitSharingReportBottom[]) => {
				return dataSet;
			})
			.catch((err: HttpErrorResponse) => {
				throw new Error(err.error);
			})
	}

	//TODO
	profitSharingSubAgents(agents: string[]): Promise<SubAgents[]> {
		return this.http.post(`${this.apiURL}api/ProfitSharingGetSubAgents/`, agents, httpOptions).toPromise()
			.then((dataSet: SubAgents[]) => {
				return dataSet;
			})
			.catch((err: HttpErrorResponse) => {
				throw new Error(err.error);
			})
	}

	profitSharingReportAsPDF(year: number, month: number, agents: string[], asSub: boolean, includeBottom: boolean): Promise<HttpResponse<Blob>> {
		// if (isUndefined(asSub)) {
		// 	asSub = false;
		// }

		// if (isUndefined(includeBottom)) {
		// 	includeBottom = false;
		// }

		return this.http.post(`${this.apiURL}api/ProfitSharingReportAsPdf/${year}/${month}/${asSub}/${includeBottom}`, agents, {observe: 'response', responseType: 'blob'}).toPromise()
			.then((result: HttpResponse<Blob>) => {
				return result;
			})
			.catch((err: HttpErrorResponse) => {
				throw new Error(err.error);
			})
	}

	profitSharingReportGeneration(format: string, year: number, month: number, agents: string[], asSub: boolean, includeBottom: boolean): Promise<HttpResponse<Blob>>{
		
		//Obsoleted potentially
		// if (isUndefined(asSub)) {
		// 	asSub = false;
		// }

		// if (isUndefined(includeBottom)) {
		// 	includeBottom = false;
		// }

		if(asSub == null || asSub == undefined){
			asSub = false; 
		}
		if(includeBottom == null || includeBottom == undefined){
			includeBottom = false; 
		}

		return this.http.post(`${this.apiURL}api/ProfitSharingReportGenerator/${format}/${year}/${month}/${asSub}/${includeBottom}`, agents, {observe: 'response', responseType: 'blob'}).toPromise()
			.then((result: HttpResponse<Blob>) => {
				return result;
			})
			.catch((err: HttpErrorResponse) => {
				throw new Error(err.error);
			})
	}

	profitSharingReportAsPDFBulk(
		year: number, 
		month: number, 
		agents: string[], 
		includeBottom: boolean, 
		all: boolean, 
		batch: boolean,
		orderBy: ('Agent' | 'Region'),
		includeZeroPayment: boolean
	): Promise<HttpResponse<Blob>> {
		let body;
		
		if (all) {
			body = {
				asZip: !batch,
				orderBy,
				includeZeroPayment
			}
		} else {
			const agentIds = agents.filter((id, index) => {
				return agents.indexOf(id) === index;
			})
			body = {
				agentIds,
				asZip: !batch,
				orderBy,
				includeZeroPayment
			}
		}

		return this.http.post(`${this.apiURL}api/ProfitSharingReportAsPdfBulk/${year}/${month}/${includeBottom}`, body, {observe: 'response', responseType: 'blob'}).toPromise()
			.then((result: HttpResponse<Blob>) => {
				return result;
			})
			.catch((err: HttpErrorResponse) => {
				throw new Error(err.error);
			})
	}

	profitSharingReportAsExcel(year: number, month: number, agents: string[], asSub: boolean, includeBottom: boolean): Promise<HttpResponse<Blob>> {
		return this.http.post(`${this.apiURL}api/ProfitSharingReportAsExcel/${year}/${month}/${asSub}/${includeBottom}`, agents, {observe: 'response', responseType: 'blob'}).toPromise()
			.then((result: HttpResponse<Blob>) => {
				return result;
			})
			.catch((err: HttpErrorResponse) => {
				throw new Error(err.error);
			})
	}

	profitSharingReportCustom(year: number, month: number, fields: ProfitSharingCustomFields[], orderBy: ProfitSharingOrderOptions, nonPayment: boolean): Promise<HttpResponse<Blob>> {
		const body = {
			fields: fields,
			orderBy: orderBy,
			includeNonPaymentAgents: nonPayment
		}

		return this.http.post(`${this.apiURL}api/ProfitSharingCustomReport/${year}/${month}`, body, {observe: 'response', responseType: 'blob'}).toPromise()
		.then((result: HttpResponse<Blob>) => {
			return result;
		})
		.catch((err: HttpErrorResponse) => {
			throw new Error(err.error);
		})
	}
}
