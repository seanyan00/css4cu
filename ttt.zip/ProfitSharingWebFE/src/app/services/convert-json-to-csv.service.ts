import { Injectable } from '@angular/core';
import { json2csvAsync } from 'json-2-csv';

@Injectable({
	providedIn: 'root'
})
export class ConvertJsonToCsvService {

	constructor() { }

	async convertJSONToCSV(JSONData): Promise<string | Error> {
		try {
			if (typeof JSONData === 'string') JSONData = JSON.parse(JSONData);
			return await json2csvAsync(JSONData) as string;
		} catch (err) {
			console.error(err)
			return err;
		}
	}

	downloadCSV(name, data) {
		try {
			if (!data || !name) throw new Error('Name and CSV string must be included as arguments.');
			let hiddenElement = document.createElement('a');
			hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(data);
			hiddenElement.target = '_blank';
			hiddenElement.download = `${name}.csv`;
			hiddenElement.click();
		} catch (e) {
			return console.error(e);
		}
	}
}
