import { Injectable } from '@angular/core';
import { TreeNode } from 'primeng/api';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { AgentListPaged } from '@root/mig/A-Models/AgentListPaged';
import { environment } from '@environment/environment';
import { map, catchError } from 'rxjs/operators';
import { throwError as observableThrowError, Observable, BehaviorSubject, pipe  } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class AgentDataService {
	
	private apiURL : string;
	
	
	private _agentListedPaged = new BehaviorSubject(<AgentListPaged>{});

	private _agentList = new BehaviorSubject(<TreeNode[]>{});
	private _agentListLength = new BehaviorSubject(0);
	private _agentListYear = new BehaviorSubject(<number>{});
	private _agentListMonth = new BehaviorSubject(<number>{});
	private _agentListSelections = new BehaviorSubject(<string[]>{});
	private _agentDetailVisible = new BehaviorSubject(<boolean>{});
	private _importPending = new BehaviorSubject(false);
	private _clearSearchInput = new BehaviorSubject(<boolean>{});

	public agentList = this._agentList.asObservable();
	public agentListLength = this._agentListLength.asObservable();
	public agentListYear = this._agentListYear.asObservable();
	public agentListMonth = this._agentListMonth.asObservable();
	public agentListSelections = this._agentListSelections.asObservable();
	public agentDetailVisible = this._agentDetailVisible.asObservable();
	public importPending = this._importPending.asObservable();
	public agentListedPaged = this._agentListedPaged.asObservable();
	public clearSearchInput = this._clearSearchInput.asObservable();


    constructor(
		private _http: HttpClient
	) {

		this.apiURL = environment.proxyPath;

	}
	
	setAgentListPaged(agentListPaged: AgentListPaged){
		this._agentListedPaged.next(agentListPaged);
		this.setAgent(agentListPaged.data);
	}

	setAgent(data: TreeNode[]){
		this._agentList.next(data);
	}

	setClearSearchInput(clear: boolean){
		this._clearSearchInput.next(clear);
	}
	subscribeClearSearchInput() : Observable<boolean>{
		return this._clearSearchInput;
	}

	subscribeAgentList() : Observable<AgentListPaged> {
		return this._agentListedPaged;
	}

	setAgentList(year, month, data: TreeNode[], apiRequestFilterStatus: boolean) {
		this._agentList.next(data);
		if (this._agentListYear.value !== year && typeof year === 'number') {
			this._agentListYear.next(year);
		}
		if (this._agentListMonth.value !== month && typeof month === 'number') {
			this._agentListMonth.next(month);
		}
	}

	setAgentListLength(length: number, apiRequestFilterStatus: boolean) {
		this._agentListLength.next(length);
	}

	setAgentListSelections(agents: string[]) {
		this._agentListSelections.next(agents);
	}

	setAgentDetailVisibility(visible: boolean) {
		this._agentDetailVisible.next(visible);
	}

	setImportPending(pending: boolean) {
		this._importPending.next(pending);
	}

    //getPagedAgents2(agentListPaged: AgentListPaged) : Observable<AgentListPaged> {
	getPagedAgents2(agentListPaged: AgentListPaged)  {
		const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				'Accept': 'application/json'
			})
        };
    
	
		return this._http.post<AgentListPaged>(`${this.apiURL}api/AgentInfo/GetPagedAgents`, agentListPaged, httpOptions)
		.pipe(
				map(response => response),
				  //tap((data :AgentListPaged) => console.log("agent response ")),  //+ JSON.stringify(data))),
			   catchError(this.handleError)
		//);
		);

	}



	getPagedAgents(agentListPaged: AgentListPaged)  {
	//getPagedAgents(agentListPaged: AgentListPaged) : Observable<AgentListPaged> {
		// const httpOptions = {
		// 	headers: new HttpHeaders({
		// 		'Content-Type': 'application/json',
		// 		'Accept': 'application/json'
		// 	})
        // };
    
		// return this._http.post<AgentListPaged>(`${this.apiURL}api/AgentInfo/GetPagedAgents`, agentListPaged, httpOptions)
		//  .pipe(
        //  		map(response => <AgentListPaged>response),
		//    	    //tap((data :IAgentListPaged) => console.log("agent response " + JSON.stringify(data))),
		//     	catchError(this.handleError)
		//  //);
		//  );

//		agents-data-stream.json
		//return this._http.get<any>('./assets/agents.json')
		return this._http.get<any>('./assets/agents-data-stream.json')
		//return this._http.get<any>('./assets/agents.json')
		.toPromise()
		.then(res => <any[]> res.data)
		.then(data => data);


	}



	findAgent(agentCode: string){
		
		console.log("Find agent goes here");
		
		let agentListPaged: AgentListPaged = new AgentListPaged();
		agentListPaged.SingleAgent = agentCode;
		agentListPaged.PagingInformation.PageSize = 10;


		const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				'Accept': 'application/json'
			})
        };

	
		return this._http.post<AgentListPaged>(`${this.apiURL}api/AgentInfo/GetAgent`, agentListPaged, httpOptions)
		.pipe(
				map(response => response),
				// tap(data => { 
				// 	this.setAgent(data.data);
				// 	//this._agentList.next(data.data);
				// 	console.log('agent response ' + JSON.stringify(data.data));
				// }),
			    catchError(this.handleError)
		);

	}

	getFilesystem() {
        return this._http.get<any>('./assets/filesystem.json')
                    .toPromise()
                    .then(res => <any[]> res.data)
                    .then(data => data);
    }

	private handleError(error: Response) {
		//console.error('handle Error: ', JSON.stringify(error.toString()));
		console.error('handle Error: ' + error.toString());
		return observableThrowError(error.toString() || 'Server error');
	}
	getAllMasterAgents() {
		const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				'Accept': 'application/json'
			})
        };
    
	
		return this._http.post<string[]>(`${this.apiURL}api/AgentInfo/GetAllMasterAgents`, httpOptions)
		.pipe(
				map(response => response),
				  //tap((data :AgentListPaged) => console.log("agent response ")),  //+ JSON.stringify(data))),
			   catchError(this.handleError)
		//);
		);
	}

	getAllAgents() {
		const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				'Accept': 'application/json'
			})
        };
    
	
		return this._http.get<TreeNode[]>(`${this.apiURL}api/AgentInfo/GetAllAgents`, httpOptions)
		.pipe(
				map(response => response),
				  //tap((data :AgentListPaged) => console.log("agent response ")),  //+ JSON.stringify(data))),
			   catchError(this.handleError)
		//);
		);
	}

}
