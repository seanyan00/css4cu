import { Injectable } from '@angular/core';
import * as XLSX from 'xlsx';
import { TableDataService } from '@services/table-data.service';

interface Table {
	[key: string]: string
};

@Injectable({
  	providedIn: 'root'
})
export class ConvertCsvToJsonService {

	constructor(public tableDataService: TableDataService) { }

	convertExcelToJson(ev, tableType: ('volume-loss' | 'profitability' | 'growth' | 'bulk-adn-a' | 'bulk-adn-c' | '')) {
		return new Promise((resolve, reject) => {
			let workBook = null;
			let jsonData: Table[] = null;
			const reader = new FileReader();

			// get the uploaded file
			const file = ev.files[0];

			// start reading the content
			reader.onload = (event) => {
				const data = reader.result;
				workBook = XLSX.read(data, { type: 'binary' });
				
				// grab the object key of the first sheet in the workbook
				const sheet = workBook.Sheets[workBook.SheetNames[0]];
				jsonData = XLSX.utils.sheet_to_json(sheet);

				// only convert the first sheet in the workbook
				switch (tableType) {
					case 'profitability':
						// check object keys to validate csv data matches table type
						if (Object.keys(jsonData[0]).indexOf('factor') > -1
						&& Object.keys(jsonData[0]).indexOf('loss-ratio-low') > -1
						&& Object.keys(jsonData[0]).indexOf('loss-ratio-high') > -1
						&& Object.keys(jsonData[0]).length === 3)
						{
							resolve({format_valid: true, data: jsonData});
						} else {
							reject({format_valid: false, data: jsonData});
						}
						break;
					case 'growth':
						// check object keys to validate csv data matches table type
						if (Object.keys(jsonData[0]).indexOf('factor') > -1
						&& Object.keys(jsonData[0]).indexOf('written-premium-growth-percentage-low') > -1
						&& Object.keys(jsonData[0]).indexOf('written-premium-growth-percentage-high') > -1
						&& Object.keys(jsonData[0]).length === 3)
						{
							resolve({format_valid: true, data: jsonData});
						} else {
							reject({format_valid: false, data: jsonData});
						}
						break;
					case 'volume-loss':
						// check object keys to validate csv data matches table type
						if (Object.keys(jsonData[0]).indexOf('factor') === -1
						&& Object.keys(jsonData[0]).indexOf('loss-ratio-low') > -1
						&& Object.keys(jsonData[0]).indexOf('loss-ratio-high') > -1
						&& (Object.keys(jsonData[0])[2].match(/^0-/) || Object.keys(jsonData[0])[3].match(/^0-/))
						&& Object.keys(jsonData[0]).length > 3)
						{
							// Run the data through the reformatter function.
							// This returns a JSON array in the format acceptable for the API
							// to perform calculations on the data. The format is essentially this:
							// 1 row for each premium volume range.
							// The data to be converted will be uploaded in this format:
							// 1 row per loss ratio percentage range,
							// with volume ranges represented by hyphenated strings.
							const reformattedData = this.reformatVolumeLossDataForAPI(jsonData)

							// Store the API format, and the UI-friendly format.
							resolve({format_valid: true, data: jsonData, apiFormattedData: reformattedData});
						} else {
							reject({format_valid: false, data: jsonData});
						}
						break;
					case 'bulk-adn-a':
						// check object keys to validate csv data matches table type
						if (Object.keys(jsonData[0]).indexOf('agent-id') > -1
						&& Object.keys(jsonData[0]).indexOf('enabled') > -1
						&& Object.keys(jsonData[0]).indexOf('min-premium') > -1
						&& Object.keys(jsonData[0]).indexOf('premium-table') > -1
						&& Object.keys(jsonData[0]).length === 4)
						{
							resolve({format_valid: true, data: jsonData});
						} else {
							reject({format_valid: false, data: jsonData});
						}
						break;
					case 'bulk-adn-c':
						// check object keys to validate csv data matches table type
						if (Object.keys(jsonData[0]).indexOf('AgentId') > -1
						&& Object.keys(jsonData[0]).indexOf('IsEnabled') > -1
						&& Object.keys(jsonData[0]).indexOf('Year') > -1
						&& Object.keys(jsonData[0]).length === 3)
						{
							resolve({format_valid: true, data: jsonData});
						} else {
							reject({format_valid: false, data: jsonData});
						}
						break;
					default:
						break;
				}
			}

			// read as binary
			reader.readAsBinaryString(file);
		})
	}

	serializeJSON = data => {
		return JSON.stringify(data).replace(/'/g, '"');
	}

	// This will reformat the volume-loss data to be consumed and processed by the API
	reformatVolumeLossDataForAPI = jsonData => {
		// Initialize empty array for reformatted data
		let reformattedData = [];

		// Count the volume ranges (x-axis)
		const premiumRangeCount = Object.keys(jsonData[0]).length - 2;

		// Count the loss ratio ranges (y-axis)
		const lossRatioRangeCount = jsonData.length;

		// Iterate over y-axis ranges
		for (let lossRatioRange = 0; lossRatioRange <= (lossRatioRangeCount - 1); lossRatioRange++) {
			
			// Iterate over x-axis ranges
			for (let premiumRange = 0; premiumRange <= (premiumRangeCount - 1); premiumRange++) {
				
				// Grab the current volume range
				const currentPremiumRange = Object.keys(jsonData[0])[premiumRange + 2];

				// Split the range and store the low and high ends in separate variables
				const currentPremiumLow = currentPremiumRange.split('-')[0];
				const currentPremiumHigh = currentPremiumRange.split('-')[1];

				// Push a new entry to the array. We will add entries for all volume ranges.
				// The loss ratio range will be the same for each iteration of volume range.
				// After reaching the last volume range, we will begin adding the next loss ratio range.
				// Repeat this untill we run out of loss ratio ranges.
				reformattedData.push({
					'loss-ratio-low': jsonData[lossRatioRange]['loss-ratio-low'],
					'loss-ratio-high': jsonData[lossRatioRange]['loss-ratio-high'],
					'written-premium-volume-low': currentPremiumLow,
					'written-premium-volume-high': currentPremiumHigh,
					'factor': jsonData[lossRatioRange][currentPremiumRange]
				});
			}
		}

		return reformattedData;
	}

	// This will reformat the volume-loss data into an easily consumable format
	reformatVolumeLossDataForUI = jsonData => {
		// Initialize empty array for reformatted data
		let reformattedData = [];

		// Increment this varaible every time a unique low range value is found.
		// This will end up representing the total number of entries (rows) in the array.
		let lossRatioRangeCount = 0;

		// Count the volume ranges (x-axis)
		for (let lossRatioRange = 0; lossRatioRange <= (jsonData.length); lossRatioRange++) {

			let currentPremiumLow;
			let currentPremiumHigh;

			// If object for new row doesn't exist, create it
			if (!reformattedData[lossRatioRangeCount]) {
				reformattedData[lossRatioRangeCount] = {};
			}

			// Check if new row has been populated with values, by checking for a single property
			if (jsonData[lossRatioRange]
			&& jsonData[lossRatioRange]['loss-ratio-low']
			&& !reformattedData[lossRatioRangeCount]['loss-ratio-low']) {
				// Grab the loss-ratio range from the current iteration, since this is the
				// first occurrance of a distinct set of repeating loss-ratio ranges.
				reformattedData[lossRatioRangeCount]['loss-ratio-low'] = jsonData[lossRatioRange]['loss-ratio-low'];
				reformattedData[lossRatioRangeCount]['loss-ratio-high'] = jsonData[lossRatioRange]['loss-ratio-high'];
			}

			// Grab the volume range for current iteration.
			if (jsonData[lossRatioRange]
			&& jsonData[lossRatioRange]['written-premium-volume-low']) {
				currentPremiumLow = jsonData[lossRatioRange]['written-premium-volume-low']
				currentPremiumHigh = jsonData[lossRatioRange]['written-premium-volume-high']
			}

			// Concatenate the premium range and separate each part with a hyphen.
			// Create a new object property for that range and set its value equal to current factor.
			if (jsonData[lossRatioRange]
			&& jsonData[lossRatioRange].factor) {
				reformattedData[lossRatioRangeCount][`${currentPremiumLow}-${currentPremiumHigh}`] = jsonData[lossRatioRange].factor;
			}

			// Check for a new loss-ratio value.
			// This conditional block ensures that the following code
			// only gets executed once for each unique loss-ratio range.
			if (jsonData[lossRatioRange]
			&& jsonData[lossRatioRange + 1]
			&& jsonData[lossRatioRange]['loss-ratio-low'] != jsonData[lossRatioRange + 1]['loss-ratio-low']) {
				// Increment the loss-ratio range count, as this represents the number of rows in the table, AKA
				// objects in the array.
				lossRatioRangeCount++;
			}
		}

		return reformattedData;
	}
}
