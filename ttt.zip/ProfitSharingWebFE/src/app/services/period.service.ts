import { Injectable } from '@angular/core';

@Injectable({
	providedIn: 'root'
})
export class PeriodService {
	public futureYear: number = new Date().getFullYear() + 1;
	public currentYear: number = new Date().getFullYear();
	public currentMonth: number = new Date().getMonth();
	public yearRange: number = 12;

	public years: {label: string, value: number}[] = new Array();
	public months: {label: string, value: number}[] = [
		{label: 'January', value: 0},
		{label: 'February', value: 1},
		{label: 'March', value: 2},
		{label: 'April', value: 3},
		{label: 'May', value: 4},
		{label: 'June', value: 5},
		{label: 'July', value: 6},
		{label: 'August', value: 7},
		{label: 'September', value: 8},
		{label: 'October', value: 9},
		{label: 'November', value: 10},
		{label: 'December', value: 11}
	];
	
	constructor() {
		for (let i = 0; i < this.yearRange; i++) {
			switch (i) {
				case 0:
					this.years.push({ label: (this.currentYear + 1).toString(), value: (this.currentYear + 1) });
					break;
				case 1:
					this.years.push({ label: 'Current', value: this.currentYear })
					break;
				default:
					this.years.push({ label: (this.currentYear - (i - 1)).toString(), value: (this.currentYear - (i - 1)) });
					break;
			}
		}

		this.months = this.months.map((v, i) => {
			if (v.value === this.currentMonth) {
				v.label = 'Current'
				return v;
			}
			return v;
		})
	}
}
