import { TestBed } from '@angular/core/testing';

import { ConvertCsvToJsonService } from './convert-csv-to-json.service';

describe('ConvertCsvToJsonService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ConvertCsvToJsonService = TestBed.get(ConvertCsvToJsonService);
    expect(service).toBeTruthy();
  });
});
