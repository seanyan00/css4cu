import { TestBed } from '@angular/core/testing';

import { AgentDataService } from './agent-data.service';

describe('AgentDataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AgentDataService = TestBed.get(AgentDataService);
    expect(service).toBeTruthy();
  });
});
