import { Component, OnInit } from '@angular/core';
import { ExportReportService } from '@services/export-report.service';
import { Subscription } from 'rxjs';

@Component({
	selector: 'app-report-builder',
	templateUrl: './report-builder.component.html',
	styleUrls: ['./report-builder.component.css']
})
export class ReportBuilderComponent implements OnInit {

	availableRows: { value: string, label: string }[];
	selectedRows: { value: string, label: string }[] = [];
	draggedRow: { value: string, label: string } | undefined;
	draggedFromColumn: 'available' | 'selected' | '' = '';
	reportPendingSubscription: Subscription;
	reportPending: boolean = false;
	
	constructor(private exportReport: ExportReportService) { }

	ngOnInit() {
		this.selectedRows = [];

		this.availableRows = [
			{ value: 'Office', label: 'Regional Office' },
			{ value: 'AgentId', label: 'Agent' },
			{ value: 'Name', label: 'Agency Name' },
			{ value: 'AdjustedWrittenPremiums', label: 'Adjusted Written Premium' },
			{ value: 'ChargeOffs', label: 'Charge Offs' },
			{ value: 'NetAdjustedWrittenPremiums', label: 'Net Adjusted Written Premium' },
			{ value: 'AdjustedEarnedPremiums', label: 'Adjusted Earned Premium' },
			{ value: 'ChargeOffsWCDividends', label: 'Charge Offs WC Dividends' },
			{ value: 'NetAdjustedEarnedPremiums', label: 'Net Adjusted Earned Premium' },
			{ value: 'LossAdjustmentExpense', label: 'Loss Adjustment Expense' },
			{ value: 'IncurredLossBeforeStopLoss', label: 'Incurred Loss Before Stop Loss' },
			{ value: 'IncurredLossAfterStopLoss', label: 'Incurred Loss After Stop Loss' },
			{ value: 'Territory', label: 'Territory' },
			{ value: 'PrevYrAdjWPDec', label: 'Prev Yr Adj WP (Dec)' },
			{ value: 'PrevYrAdjWPMonth', label: 'Prev Yr Adj WP (Rpt mnth)' },
			{ value: 'ActualEarnedPremium', label: 'Actual Earned Premium' },
			{ value: 'GrowthRate', label: 'Growth Rate' },
			{ value: 'LossRatio', label: 'Loss Ratio' },
			{ value: 'GrowthFactor', label: 'Growth Loss Factor' },
			{ value: 'LossRatioFactor', label: 'Volume Factor' },
			{ value: 'NineMonthLossLock', label: 'Nine Month Loss Lock' },
			{ value: 'ThreeYearProfitPct', label: 'Three Year Prof Pct' },
			{ value: 'ThreeYearProfitFactor', label: 'Three Year Prof Factor' },
			{ value: 'AddAEnabled', label: 'Addendum A Enabled'},
			{ value: 'MinPremium', label: 'Minimum Written Premium' },
			{ value: 'Payment', label: 'PAYMENT' }
		];

		this.reportPendingSubscription = this.exportReport.reportPending.subscribe(pendingReportArray => {
			this.reportPending = pendingReportArray.indexOf('custom') === -1 ? false : true;
		});
	}

	ngOnDestroy() {
		if (this.reportPendingSubscription) this.reportPendingSubscription.unsubscribe();
	}

	dragStart(event, row: { value: string, label: string }) {
		this.draggedRow = row;
    }

    drop(event, draggedFromColumn: 'available' | 'selected') {
		if (!this.draggedRow) return;
		
		this.draggedFromColumn = draggedFromColumn;
		let draggedRowIndex: number = undefined;

        switch (draggedFromColumn) {
			case 'available':
				draggedRowIndex = this.findAvailableIndex(this.draggedRow);
				this.selectedRows = [...this.selectedRows, this.draggedRow];
				this.availableRows = this.availableRows.filter((val, i) => i != draggedRowIndex);
				this.draggedRow = undefined;
				break;
			case 'selected':
				draggedRowIndex = this.findSelectedIndex(this.draggedRow);
				this.availableRows = [...this.availableRows, this.draggedRow];
				this.selectedRows = this.selectedRows.filter((val, i) => i != draggedRowIndex);
				this.draggedRow = undefined;
				break;
			default:
				break;
		}
		
		this.exportReport.setCustomFields(this.selectedRows.map(x => x.value));
    }

    dragEnd(event) {
        this.draggedRow = null;
    }

    findAvailableIndex(row: { value: string, label: string }) {
        let index = -1;
        for (let i = 0; i < this.availableRows.length; i++) {
            if (row === this.availableRows[i]) {
                index = i;
                break;
            }
        }
        return index;
	}
	
	findSelectedIndex(row: { value: string, label: string }) {
        let index = -1;
        for (let i = 0; i < this.selectedRows.length; i++) {
            if (row.value === this.selectedRows[i].value) {
                index = i;
                break;
            }
        }
        return index;
	}

	addAllRows(e) {
		this.selectedRows = [...this.selectedRows, ...this.availableRows];
		this.availableRows = [];
		this.exportReport.setCustomFields(this.selectedRows.map(x => x.value));
	}

	removeAllRows(e) {
		this.availableRows = [...this.selectedRows, ...this.availableRows];
		this.selectedRows = [];
		this.exportReport.setCustomFields(this.selectedRows.map(x => x.value));
	}

	exportExcel() {
		this.exportReport.export('excel', true, true, false, 'Region', true);
	}
}
