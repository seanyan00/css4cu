import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { PeriodService } from '@services/period.service';
import { ApiService } from '@services/api.service';

@Component({
	selector: 'app-products',
	templateUrl: './products.component.html',
	styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
	products: {included: boolean, name: string, id?: number}[] = [];
	productForm: FormGroup;
	formEditable: boolean = false;
	periodFilter: FormGroup;
	periodCustomYears: {label: string, value: number}[];
	chosenYear: number = this.periodService.currentYear;
	formReady: boolean = false;
	
	constructor(
		public periodService: PeriodService,
		private apiService: ApiService
	) { }

	async ngOnInit() {
		this.periodCustomYears = this.periodService.years.filter((v, i) => {
			if (i < 9) return true
		})

		this.periodFilter = new FormGroup({
			year: new FormControl(this.periodCustomYears[1]),
			month: new FormControl(this.periodService.months[this.periodService.currentMonth])
		});

		this.periodChanges();
		this.loadProducts(this.periodService.currentYear);
	}

	buildForm() {
		const controlObject = {}
		this.products.map((v, i) => {
			const formControl = new FormControl(v.included)
			controlObject[v.name] = formControl;
		})
		this.productForm = new FormGroup(controlObject);
		this.formReady = true;
	}

	toggleEdit(editable) {
		if (!editable) {
			this.products.filter(product => {
				return this.productForm.controls[product.name].dirty === true
			}).map(async product => {
				if (product.id) {
					await this.apiService.updateProductForYear({
						Id: product.id,
						ProductName: product.name,
						Included: this.productForm.controls[product.name].value,
						Year: this.chosenYear
					})
					await this.loadProducts(this.chosenYear);
				} else {
					await this.apiService.addProductForYear({
						ProductName: product.name,
						Included: this.productForm.controls[product.name].value,
						Year: this.chosenYear
					})
					await this.loadProducts(this.chosenYear);
				}
			})
		}
		this.formEditable = editable;
	}

	async loadProducts(year) {
		if (!year) year = this.periodService.currentYear;

		const productReponse = await this.apiService.getAllProducts();
		const yearInclusion = await this.apiService.getProductsByYear(year);

		this.products = productReponse.map(product => {
			const inclusionExists = yearInclusion.filter(explicitEntry => {
				if (explicitEntry.ProductName === product) return true;
			})
			if (inclusionExists.length) {
				return {
					included: inclusionExists[0].Included,
					name: product,
					id: inclusionExists[0].Id
				};
			} else {
				return {
					included: false,
					name: product
				};
			}
		});

		this.buildForm();
	}

	periodChanges(): void {
		this.periodFilter.valueChanges.subscribe(val => {
			this.chosenYear = val.year.value;
			this.loadProducts(val.year.value);
		});
	}
}
