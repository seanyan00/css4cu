export class DistinctAgencies {

    AgentNumber : string;
    CDDesc : string;
    AgencyName : string;
    Address1 : string;
    Address2 : string;
    Address3 : string;
    City : string;
    State : string;
    ZipCode : string;
    MasterAgency : string;
    RegionalOffice : string;
    MarketingCode : string;
    MasterAgencyDetail : DistinctAgencies[];

    constructor() {
        this.MasterAgencyDetail = [];
    }
}