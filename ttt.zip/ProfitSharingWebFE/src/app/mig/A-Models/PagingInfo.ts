export class PagingInfo{

    TotalResults : number = 0;
    CurrentPage : number = 0;
    PageSize : number = 0;;
    PageCount : number = 0;

    constructor() {}
    
}