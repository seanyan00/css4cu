interface ProfitSharingReportTopDto {
    
		//TODO:  ADDED THE FOLLOWING FIELDS
		AGENT : string;
        AGYCDE : string;
		CDDESC : string;
		AGYNAM : string;
		AGYAD1 : string;
		AGYAD2 : string;
		AGYAD3 : string;
		AGYCTY : string;
		AGYST : string; 
		AGYZIP : string;
		MKTTER : string;
		ProductId : string;
		AdjustedWrittenPremium : number;
		ChargeOffsAndWC : number;
		NetAdjustedPremiums : number;
		AdjustedEarnedPremiums : number;
		NetAdjustedEarnedPremiums : number;
		LossAdjustmentExpense : number;
		IncurredLossesBeforeStopLoss : number;
		IncurredLossesAfterStopLoss : number;
		LossRatio : number;
	
}