import { TreeNode,  } from 'primeng/api';
import { PagingInfo } from "./PagingInfo";

export class AgentListPaged {
    
    PagingInformation : PagingInfo;
    //this field is used only for getting a single agent in the search
    SingleAgent: string;
    //data : DistinctAgencies[];
    //data: TableData[];
    data: TreeNode[];

    constructor() {
        this.PagingInformation = new PagingInfo();
        //this.Agencies = [];
        //this.data = []
        this.data = [];
    }
}