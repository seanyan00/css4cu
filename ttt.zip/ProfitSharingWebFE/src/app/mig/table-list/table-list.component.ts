import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Paths } from '../../app.routing.enums';
import { ConvertCsvToJsonService } from '@services/convert-csv-to-json.service';
import { TableDataService } from '@services/table-data.service';
import { Subscription } from 'rxjs';
import { ApiService, Table, TableNames, TableStatus } from '@services/api.service';
import { ConvertJsonToCsvService } from '@services/convert-json-to-csv.service';

@Component({
  selector: 'app-table-list',
  templateUrl: './table-list.component.html',
  styleUrls: ['./table-list.component.css']
})
export class TableListComponent implements OnInit {
	// Local instances of the path enums
	public tablesPath: string;
	public viewPath: string;
	public profitabilityPath: string;
	public growthPath: string;
	public volumeLossPath: string;

	// Table data
	public volumeLossList: Table[];
	public growthList: Table[];
	public profitabilityList: Table[];

	private volumeLossListSubscription: Subscription;
	private growthListSubscription: Subscription;
	private profitabilityListSubscription: Subscription;

	// Upload dialog properties
	public createTableDialog: boolean = false;
	public createTableDialogHeader: ('Premium Volume and Loss Ratio Factors' | 'Premium Growth Factors' | '3-Year Profitability Factors' | '') = '';
	public createTableDialogType: 'volume-loss' | 'profitability' | 'growth' | '';
	public createTableForm: FormGroup;
	private csvFile: FormData = new FormData();
	public csvFileName: string;
	public csvFileSize: number;
	public formValidity: boolean = true;
	public formInvalidReason: ('empty' | 'format' | '') = '';

	constructor(
		public convertCSV: ConvertCsvToJsonService,
		public tableDataService: TableDataService,
		private apiService: ApiService,
		private router: Router,
		private convertJsonToCsvService: ConvertJsonToCsvService
	) { }

	async ngOnInit() {
		// Initialize the local instances of the path enums
		this.tablesPath = `/${Paths.tables}`;
		this.viewPath = Paths.view;
		this.profitabilityPath = Paths.profitability;
		this.growthPath = Paths.growth;
		this.volumeLossPath = Paths.volume_loss;

		this.volumeLossListSubscription = this.tableDataService.volumeLossList.subscribe(data => {
			if (!data.length) this.volumeLossList = [];
			if (data.length) this.volumeLossList = data;
		});

		this.growthListSubscription = this.tableDataService.growthList.subscribe(data => {
			if (!data.length) this.growthList = [];
			if (data.length) this.growthList = data;
		});

		this.profitabilityListSubscription = this.tableDataService.profitabilityList.subscribe(data => {
			if (!data.length) this.profitabilityList = [];
			if (data.length) this.profitabilityList = data;
		});

		this.buildForm();

		await this.apiService.getVolumeLossTables();
		await this.apiService.getGrowthTables();
		await this.apiService.getProfitabilityTables();
	}

	ngOnDestroy() {
		if (this.volumeLossListSubscription) this.volumeLossListSubscription.unsubscribe();
		if (this.growthListSubscription) this.growthListSubscription.unsubscribe();
		if (this.profitabilityListSubscription) this.profitabilityListSubscription.unsubscribe();
	}

	showCreateTableDialog(tableType) {
		this.createTableDialogType = '';
		switch (tableType) {
			case 'volume-loss':
				this.createTableDialogHeader = 'Premium Volume and Loss Ratio Factors'
				this.createTableDialogType = tableType;
				break;
			case 'growth':
				this.createTableDialogHeader = 'Premium Growth Factors'
				this.createTableDialogType = tableType;
				break;
			case 'profitability':
				this.createTableDialogHeader = '3-Year Profitability Factors'
				this.createTableDialogType = tableType;
				break;
			default:
				break;
		}
        this.createTableDialog = true;
    }

	buildForm() {
		this.createTableForm = new FormGroup({
			tableName: new FormControl('', [Validators.required])
		});
	}

	handleUpload(e, form) {
		this.csvFileName = e.files[0].name;
		this.csvFileSize = e.files[0].size;
		this.csvFile.set('csvFile', e.files[0], this.createTableForm.get('tableName').value);
		form.clear();
	}

	async handleSubmit(e) {
		// TODO: has() is causing issues in IE
		if (!this.createTableForm.invalid && this.csvFile.has('csvFile')) {
			this.formValidity = true;
			this.formInvalidReason = '';
			const conversionParam = {files: [this.csvFile.get('csvFile')]};
			let conversionResult;
			let conversionAPISanitized: string;
			let conversionObservableSanitized: string;
			let sendDataResult;
			let requestBody;

			try {
				conversionResult = await this.convertCSV.convertExcelToJson(conversionParam, this.createTableDialogType);

				// Volume Loss Ratio tablesNeed to be re-formatted before data is sent to the back-end
				if (TableNames[this.createTableDialogType] === TableNames['volume-loss']) {
					conversionObservableSanitized = this.convertCSV.serializeJSON(conversionResult.data);
					conversionAPISanitized =this.convertCSV.serializeJSON(conversionResult.apiFormattedData);
				} else {
					conversionAPISanitized = this.convertCSV.serializeJSON(conversionResult.data);
				}

				// Build request body
				requestBody = {
					"Data": conversionAPISanitized,
					"Name": this.createTableForm.get('tableName').value,
					"TableStatus": 0,
					"TableNames": TableNames[this.createTableDialogType]
				}

				if (conversionResult.format_valid === true) {
					switch (TableNames[this.createTableDialogType]) {
						case TableNames['growth']:
							sendDataResult = await this.apiService.setGrowthTable(requestBody);
							break;
						case TableNames['profitability']:
							sendDataResult = await this.apiService.setProfitabilityTable(requestBody);
							break;
						case TableNames['volume-loss']:
							sendDataResult = await this.apiService.setVolumeLossTable(requestBody, conversionObservableSanitized);
							break;
						default:
							break;
					}
				}

				if (sendDataResult) this.router.navigate([this.tablesPath, this.viewPath, this.createTableDialogType, this.createTableForm.get('tableName').value, sendDataResult]);
			} catch (e) {
				this.formValidity = false;
				this.formInvalidReason = 'format';
			}

		} else if (this.createTableForm.invalid || !this.csvFile.has('csvFile')) {
			this.formValidity = false;
			this.formInvalidReason = 'empty';
		} else {
			this.formValidity = false;
			this.formInvalidReason = '';
		}
	}

	async viewVolumeLossTable(row) {
		const sanitizeTable = row.Data.replace(/'/g, '"');
		let parseTable;
		
		try {
			parseTable = JSON.parse(sanitizeTable);
			row.Data = parseTable;
		} catch (e) {
			row.Data = null;
			console.error(new Error('Table retrieved has invalid formatting.'))
		}

		await this.apiService.getTable(row.Id)
		this.router.navigate([this.tablesPath, this.viewPath, this.volumeLossPath, row.Name, row.Id]);
	}

	async viewProfitabilityTable(row) {
		const sanitizeTable = row.Data.replace(/'/g, '"');
		let parseTable;
		
		try {
			parseTable = JSON.parse(sanitizeTable);
			row.Data = parseTable;
		} catch (e) {
			row.Data = null;
			console.error(new Error('Table retrieved has invalid formatting.'))
		}

		await this.apiService.getTable(row.Id)
		this.router.navigate([this.tablesPath, this.viewPath, this.profitabilityPath, row.Name, row.Id]);
	}

	async viewGrowthTable(row) {
		const sanitizeTable = row.Data.replace(/'/g, '"');
		let parseTable;
		
		try {
			parseTable = JSON.parse(sanitizeTable);
			row.Data = parseTable;
		} catch (e) {
			row.Data = null;
			console.error(new Error('Table retrieved has invalid formatting.'))
		}

		await this.apiService.getTable(row.Id)
		this.router.navigate([this.tablesPath, this.viewPath, this.growthPath, row.Name, row.Id]);
	}

	async downloadVolumeLossTable(row) {
		const freshData = await this.apiService.getTable(row.Id);
		let convertTable;
		convertTable = await this.convertJsonToCsvService.convertJSONToCSV(freshData.Data);
		this.convertJsonToCsvService.downloadCSV(row.Name, convertTable);
	}

	async downloadProfitabilityTable(row) {
		const freshData = await this.apiService.getTable(row.Id);
		let convertTable;
		convertTable = await this.convertJsonToCsvService.convertJSONToCSV(freshData.Data);
		this.convertJsonToCsvService.downloadCSV(row.Name, convertTable);
	}

	async downloadGrowthTable(row) {
		const freshData = await this.apiService.getTable(row.Id);
		let convertTable;
		convertTable = await this.convertJsonToCsvService.convertJSONToCSV(freshData.Data);
		this.convertJsonToCsvService.downloadCSV(row.Name, convertTable);
	}

	handleTableDialogClose() {
		this.createTableForm.reset();
		this.csvFileName = '';
		this.csvFileSize = 0;
		this.csvFile.delete('csvFile');
	}
}
