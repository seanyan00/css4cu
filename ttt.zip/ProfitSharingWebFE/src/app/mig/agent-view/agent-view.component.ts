import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { TreeNode } from 'primeng/api';
import { PeriodService } from '@services/period.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ApiService, Agent, ProfitSharingReportTop, AdnAAssignment, AdnC, TableAssignments } from '@services/api.service';
import { FilterService } from '../../services/filter.service';
import { ErrorService } from '../../services/error.service';
import { ExportReportService } from '@services/export-report.service';
import { Subscription } from 'rxjs';
import { take } from 'rxjs/operators';
import { ReportDataType } from '../calculation-detail/calculation-detail.component';


@Component({
	selector: 'app-agent-view',
	templateUrl: './agent-view.component.html',
	styleUrls: ['./agent-view.component.scss']
})
export class AgentViewComponent implements OnInit {
	// Properties to be set by getters and setters
	private _agent: Agent;
	private _agentList: Agent[];
	private _master: Agent;
	private _children: Agent[];
	private _chosenYear: number = this.periodService.currentYear;
	private _chosenMonth: number = this.periodService.currentMonth;
	private _page: number = 0;

	// Combined Report
	public searchResult: Agent | {} | null = {};
	public searchError: string = null;
	public combinedReportForm: FormGroup;
	public rollUpChecked: boolean = true;

	// Single Agent Detail
	public singleAgentForm: FormGroup;
	public editingMinimum: boolean = false;
	public originalMinimumFormFields: {
		adnA: FormControl,
		minPremium: FormControl
	};
	public editingRate: boolean = false;
	public originalRateFormFields: { adnC: FormControl };
	public profitSharingOptions: { label: string, value: number }[];
	public rollUp: boolean;


	private adnAChangeSubscription: Subscription;
	private adnCChangeSubscription: Subscription;
	private rollUpChangeSubscription: Subscription;

	// Keep track of filter state
	public isFiltering: boolean = false;

	// Date Selector
	public periodCustomYears: { label: string, value: number }[];
	private periodChangeSubscriptionSingle: Subscription;
	private periodChangeSubscriptionCombined: Subscription;
	private monthChangeSubscriptionSingle: Subscription;
	private monthChangeSubscriptionCombined: Subscription;


	// Report Details
	public reportTop: ProfitSharingReportTop[];
	public tabHeading: string = "Sub-Agent List"
	public showSubAgentTab: boolean = true;
	public reportBottom;
	public isInProgress: boolean = false;
	public showCheckBox: boolean = true;
	public subagents: any;

	@Output() requestCalculation = new EventEmitter<{
		detailsFor: string,
		detailData: ReportDataType,
		detailDataMinusOne: ReportDataType,
		detailDataMinusTwo: ReportDataType,
		awaitingDetails: boolean,
		planInfo: TableAssignments[],
		chosenYearAdnA: number,
		year: number,
		month: number,
		agentStartDate: number
	}>();
	@Output() periodChangeFromAgentDetail = new EventEmitter<{ year: number, month: number }>();

	// TODO: find a way around using 'any' for the getter and setter methods

	@Input()
	set agent(agentInfo: any) {

		//console.log("agent info = " + agentInfo);
		this._agent = agentInfo && agentInfo.agent ? agentInfo.agent : null;
		this._master = agentInfo && agentInfo.parent ? agentInfo.parent : null;

		if (agentInfo && agentInfo.agent && agentInfo.agent.children) {
			this._children = agentInfo.agent.children.filter(child => child.data.AgentId).map(child => child.data.AgentId.trim());
		} else {
			this._children = null;
		}

		if (agentInfo != null && agentInfo.agent.AgentNumber == agentInfo.agent.MasterAgency) {
			this.rollUpChecked = true;
		}

		//else {
		//	this.rollUpChecked = false;
		//}
	}

	get agent(): any { return this._agent; }
	get children(): any { return this._children; }
	get master(): any { return this._master; }

	@Input()
	set agentList(agentList: any) {

		try {
			//console.log("set agent list entered: ", agentList);
			/* SET AGENT TO COMBINED ROLLUP */
			if (agentList != null || agentList != undefined) {
				this.rollUpChecked = true;
				let fakeAgency: any = {};
				fakeAgency.AgentNumber = "Null";
				fakeAgency.MasterAgency = "0000000";
				fakeAgency.AgencyName = "Combined Agent Report";
				fakeAgency.Address1 = "Not Applicable"
				fakeAgency.parent = null;
				fakeAgency.SubAgent = [];
				fakeAgency.SelectedAgents = [];
				fakeAgency.SubAgentNumbers = [];
				let m: TreeNode[] = [];
				m = agentList as TreeNode[];
				m.forEach(x => {
					let name = x.data.AgentNumber + ' - ' + x.data.AgencyName;
					let agentNumbers = x.data.AgentNumber;
					fakeAgency.SubAgentNumbers.push(agentNumbers);
					fakeAgency.SubAgent.push(name);
					fakeAgency.SelectedAgents.push(name);
				})
				this.tabHeading = fakeAgency.SubAgentNumbers != null ? "Agents Selected" : "Sub-Agent List"
				this.rollUpChecked = true;
				this._agent = fakeAgency;
			}

			//this._agentList = agentList;
		}
		catch (error) {
			console.log(error);
		}
	}

	get agentList(): any { return this._agentList; }

	@Input()
	set chosenYear(chosenYear: number) {
		this._chosenYear = chosenYear;
	}

	get chosenYear(): number { return this._chosenYear; }

	@Input()
	set chosenMonth(chosenMonth: number) {
		this._chosenMonth = chosenMonth;
	}

	get chosenMonth(): number { return this._chosenMonth; }

	@Input()
	set page(page: number) {
		this._page = page;
	}

	get page(): number { return this._page; }

	@Input()
	set panelVisible(isVisible: boolean) {
		this.resetForm(isVisible);
		if (isVisible === false) {
			// Emit an event to sync period filters
			this.periodChangeFromAgentDetail.emit({ year: this.chosenYear, month: this.chosenMonth });
		}
	}

	constructor(
		public periodService: PeriodService,
		private apiService: ApiService,
		private errorService: ErrorService,
		private filterService: FilterService,
		private exportReport: ExportReportService
	) {
		let x: number = 0;
	}

	async ngOnInit() {
		// Grab all years except future
		this.periodCustomYears = this.periodService.years.filter((v, i) => {
			if (i !== 0) return true;
		})

		//= this.periodService.months[this.periodService.currentMonth === 0 ? 11 : (this.periodService.currentMonth - 1)]

		// Grab all plans and filter to populate only current plans
		const plans = await this.apiService.getAllPlans();

		// Generate options for plan select dropdown
		this.profitSharingOptions = plans
			.filter(x => { return (x.StartYear <= this.periodService.currentYear) && (x.EndYear >= this.periodService.currentYear) })
			.map(x => { return { label: x.PlanName, value: x.PlanId } });

		this.buildForm();
		this.controlSubscriptions();
		// this.toggleRollUp();
		this.toggleAdnA();
		this.toggleAdnC();

		// this.periodChanges();
	}


	ngOnDestroy() {

		if(this.singleAgentForm) {this.singleAgentForm.reset();}
		if(this.combinedReportForm) { this.combinedReportForm.reset();}
		if (this.periodChangeSubscriptionCombined) this.periodChangeSubscriptionCombined.unsubscribe();
		if (this.periodChangeSubscriptionSingle) this.periodChangeSubscriptionSingle.unsubscribe();
		if (this.monthChangeSubscriptionCombined) this.monthChangeSubscriptionCombined.unsubscribe();
		if (this.monthChangeSubscriptionSingle) this.monthChangeSubscriptionSingle.unsubscribe();
		if (this.adnAChangeSubscription) this.adnAChangeSubscription.unsubscribe();
		if (this.adnCChangeSubscription) this.adnCChangeSubscription.unsubscribe();
		if (this.rollUpChangeSubscription) this.rollUpChangeSubscription.unsubscribe();
	}

	controlSubscriptions() {

			this.monthChangeSubscriptionSingle = this.singleAgentForm.get('month').valueChanges.subscribe(async val => {
			//console.log("chosen month subscription changed - value = "  + val.value);
			if(val){
				this.chosenMonth = val.value;
			}
		});

		this.monthChangeSubscriptionCombined = this.combinedReportForm.get('month').valueChanges.subscribe(async val => {
			//console.log("chosen month subscription changed - value = "  + val.value);
			if(val){
				this.chosenMonth = val.value;
			}

		});

		this.rollUpChangeSubscription = this.singleAgentForm.get('rollUp').valueChanges
			.subscribe(async (rollUp: boolean) => {
				this.rollUp = rollUp;
			});


	// Subscribe to changes to the period dropdown
	// periodChanges(): void {
	// 	this.monthChangeSubscriptionSingle = this.singleAgentForm.get('month').valueChanges.subscribe(async val => {
	// 		this.chosenMonth = val.value;

	// 		// Single agent detail
	// 		if (this.agent && this.agent.AgentId) {
	// 			// Don't retrieve reports if data is present or future date
	// 			if (!(this.chosenYear === this.periodService.currentYear && val.value >= this.periodService.currentMonth)) {
	// 				const rollUp = this.singleAgentForm.get('rollUp').value;
	// 				// Rolled Up reports should use Master Agent Id
	// 				const agentForReport = rollUp && this.agent.MasterAgentId ? this.agent.MasterAgentId : this.agent.AgentId;
	// 				// Grab report data
	// 				console.log("LINE 181 - periodChanges - changeSubscriptionSingle");
	// 				console.log(agentForReport);
	// 				this.retrieveReportData(this.chosenYear, val.value, [agentForReport], this.master, this.children, true, rollUp);
	// 			} else {
	// 				this.exportReport.setPeriod(this.chosenYear, val.value);
	// 			}
	// 		}
	// 	});



	// 	// For combined report
	// 	if (this.agentList && this.agentList.length) {
	// 		const agentList = this.agentList.map(x => x.data.AgentId.trim());
	// 		// Don't retrieve reports if data is present or future date
	// 		if (!(this.chosenYear === this.periodService.currentYear && val.value >= this.periodService.currentMonth)) {
	// 			// Grab report data
	// 			console.log("LINE 198 - PERIOD CHANGES changeSubscriptionCombined");
	// 			this.retrieveReportData(this.chosenYear, val.value, agentList, this.master, this.children, true, false);
	// 		} else {
	// 			this.exportReport.setPeriod(this.chosenYear, val.value);
	// 		}
	// 	}
	// });

		this.periodChangeSubscriptionSingle = this.singleAgentForm.get('year').valueChanges.subscribe(async val => {
			if(val != null) {this.chosenYear = val.value; }
		});
	// 		this.editingMinimum = false;
	// 		this.editingRate = false;

	// 		let adnCExists = null;

	// 		// This is a single agent detail, and not combined report
	// 		if (this.agent && this.agent.AgentId) {
	// 			// Grab this agent's Addendum A eligibility
	// 			await this.apiService.checkAdnAForGivenYear(this.agent, this.chosenYear, this.chosenMonth);
	// 			// Grab this agent's Addendum C eligibility
	// 			await this.apiService.checkAdnCForGivenYear(this.agent, this.chosenYear, this.chosenMonth);
	// 			// Don't retrieve reports if data is present/future date
	// 			if (!(this.chosenYear === this.periodService.currentYear && this.chosenMonth >= this.periodService.currentMonth)) {
	// 				const rollUp = this.singleAgentForm.get('rollUp').value;
	// 				// Rolled Up reports should use Master Agent Id
	// 				const agentForReport = rollUp && this.agent.MasterAgentId ? this.agent.MasterAgentId : this.agent.AgentId;
	// 				// Grab report data
	// 				console.log("LINE 226 - PERIOD CHANGES changeSubscriptionSingle");
	// 				console.log(agentForReport);
	// 				this.retrieveReportData(val.value, this.chosenMonth, [agentForReport], this.master, this.children, true, rollUp);
	// 			} else {
	// 				this.exportReport.setPeriod(val.value, this.chosenMonth);
	// 			}
	// 		}

	// 		// Set value for "adnA" form control, if not undefined or null
	// 		this.singleAgentForm.get('adnA').setValue(
	// 			this.agent && this.agent.AdnA
	// 			? this.agent.AdnA
	// 			: false
	// 		);
	// 		// Set value for "minPremium" form control, if not undefined or null
	// 		this.singleAgentForm.get('minPremium').setValue(
	// 			this.agent && this.agent.MinPremium
	// 			? this.agent.MinPremium
	// 			: 0
	// 		);

	// 		// Set value for "adnC" form control, if not undefined or null
	// 		this.singleAgentForm.get('adnC').setValue(
	// 			this.agent && this.agent.AdnC
	// 			? this.agent.AdnC
	// 			: false
	// 		);
	// 	});

		this.periodChangeSubscriptionCombined = this.combinedReportForm.get('year').valueChanges.subscribe(async val => {

			if(val != null) {this.chosenYear = val.value;}
			// For combined report
			if (this.agentList && this.agentList.length) {
				const agentList = this.agentList.map(x => x.data.AgentId.trim());
				// Don't retrieve reports if data is present or future date
				if (!(this.chosenYear === this.periodService.currentYear && val.value >= this.periodService.currentMonth)) {
					// Grab report data
					this.retrieveReportData(val.value, this.chosenMonth, agentList, this.master, this.children, true);
				} else {
					this.exportReport.setPeriod(val.value, this.chosenMonth);
				}
			}
		});
	}
	//END

	async retrieveReportData(year, month, agents, master, children, shouldStoreValues) {


		let reportTop: ProfitSharingReportTop[];
		// let agentArray = agents.split(",");
		(agents.length)

		let reportBottom = null;

		// Make sure year and month are numeric.
		// Make sure at least one agent id exists in the array.
		if (isNaN(year)
			|| isNaN(month)
			|| (!agents || (agents && !agents.length))) {
			return;
		}


		// Trim leading and trailing white space from the agent ids
		agents = agents.map(x => x.trim());

		// The parameters set for report generation should be globally available
		// as an observable so that other components can trigger a report export.
		this.exportReport.setReportParams(year, month, agents, this.rollUp);

		//TODO: This SP
		try {
			let rollUp = this.singleAgentForm.get('rollUp').value;
			if (rollUp) {
				reportBottom = await this.apiService.profitSharingAgentRollupReport(year, (month + 1), agents);
			} else {
				reportBottom = await this.apiService.profitSharingAgentOnlyReport(year, (month + 1), agents);
			}


			//this.agent.Address1 = reportTop[0].AGYAD1.trim();
			//this.agent.Address2 = reportTop[0].AGYAD2.trim();
			//this.agent.City = reportTop[0].AGYCTY.trim();
			//this.agent.State = reportTop[0].AGYST.trim();
			//this.agent.Zip = reportTop[0].AGYZIP.trim();
			//this.agent.SubAgent = reportTop[0].SUBAGENTS;

		} catch (e) {
			console.error(e);
		}

		//TODO: New SP
		//try {
		//	reportTop = await this.apiService.profitSharingAgentOnlyReport(year, (month + 1), agents);
		//} catch (e) {
		//	console.error(e);
		//}

		if (shouldStoreValues) {
			this.reportTop = reportTop;
			this.reportBottom = reportBottom;
		}

		this.isInProgress = false;
		return { reportTop, reportBottom }
	}

	async getSubAgent(e) {
		if (e.index === 1) {
			let masterAgents = [this.agent.AgentNumber];
			if (masterAgents.includes("Null")) {
				masterAgents = [this.agent.SubAgentNumbers]
			} else {
				masterAgents = masterAgents.map(x => x.trim());
			}

			// console.log("MASTER: ", masterAgents);
			// console.log("AGENT : ", this.agent)
			this.subagents = await this.apiService.profitSharingSubAgents(this.agent.SubAgentNumbers ?  masterAgents[0] : masterAgents);
			// this.subagents = await this.apiService.profitSharingSubAgents(masterAgents);

			// console.log("SubagentNumbers: ", this.agent.SubAgentNumbers);
			// console.log("masterAgents: ", masterAgents)
			//this.subagents = await this.apiService.profitSharingSubAgents(masterAgents[0]);

			if (this.subagents && this.subagents.length > 1) {
				this.tabHeading = this.agent.AgencyName  == "Combined Agent Report" ? 'Agents Selected' : 'Sub-Agent List' 
				this.subagents.shift(); // the first element will be the master agent, which we do not want to include in the subagent array.
			}
			else{
				this.tabHeading = 'Agents Selected'
			}
		}
	}

	async noSubAgent(e) {
		//console.log("noSubAgent")
	}
	buildForm() {
		// Form for single-agent fly-out
		this.singleAgentForm = new FormGroup({
			year: new FormControl(this.periodCustomYears[0]),
			month: new FormControl(this.periodService.months[this.periodService.currentMonth === 0 ? 11 : (this.periodService.currentMonth - 1)]),
			minPremium: new FormControl(this.agent ? this.agent.MinPremium : 0),
			adnA: new FormControl(this.agent ? this.agent.AdnA : false),
			adnC: new FormControl(this.agent ? this.agent.AdnC : false),
			rate: new FormControl(this.agent ? this.agent.Rate : 1),
			rollUp: new FormControl(this.rollUpChecked)
		});

		// Form for multiple agent combined report fly-out
		this.combinedReportForm = new FormGroup({
			year: new FormControl(this.periodCustomYears[0]),
			month: new FormControl(this.periodService.months[this.periodService.currentMonth === 0 ? 11 : (this.periodService.currentMonth - 1)]),
			agentSearch: new FormControl(''),
			zeroPayment: new FormControl(''),
			profitSharingPlan: new FormControl('')
		});

	}

	// toggleRollUp() {
	// 	this.rollUpChangeSubscription = this.singleAgentForm.get('rollUp').valueChanges
	// 		.subscribe(async (rollUp: boolean) => {
	// 			// Don't retrieve reports if data is present or future date
	// 			if (this.agent && !(this.chosenYear === this.periodService.currentYear && this.chosenMonth >= this.periodService.currentMonth)) {
	// 				// Rolled Up reports should use Master Agent Id
	// 				const agentForReport = rollUp ? this.agent.MasterAgentId : this.agent.AgentId;
	// 				// Grab report data
	// 				console.log("LINE 344 - toggleRollUp - rollUpChangeSubscription");
	// 				console.log(agentForReport);
	// 				this.retrieveReportData(this.chosenYear, this.chosenMonth, [agentForReport], this.master, this.children, true, rollUp);
	// 			}
	// 		})
	// }

	async updateReportData() {

		this.resetForm(true, false);
		this.isInProgress = true;
		let rollUp = this.singleAgentForm.get('rollUp').value;
		let agentForReport = [this.agent.AgentNumber];

		if (this.agent.AgentNumber !== this.agent.MasterAgency && rollUp)
			rollUp = false;

		if (this.agent.SubAgentNumbers != null || this.agent.SubAgentNumbers != undefined)
			agentForReport = this.agent.SubAgentNumbers;
		this.retrieveReportData(this.chosenYear, this.chosenMonth, agentForReport, this.master, this.children, true);
		//this.retrieveReportData(this.chosenYear, this.chosenMonth, [agentForReport], this.master, this.children, true, rollUp);
	}

	toggleAdnA() {
		this.adnAChangeSubscription = this.singleAgentForm.get('adnA').valueChanges
			.subscribe(async adnA => {
				if (adnA === true) {
					this.singleAgentForm.get('minPremium').setValidators([Validators.required]);
				} else if (adnA === false) {
					this.singleAgentForm.get('minPremium').setValidators([]);
				}
				this.singleAgentForm.get('minPremium').updateValueAndValidity();
			})
	}

	async saveAdnA() {
		const adnA = this.singleAgentForm.get('adnA').value;
		const agentCode = this.agent.AgentId.trim();
		const minPremium = this.singleAgentForm.get('minPremium').value;

		// Display errors if validation fails
		if (adnA === null || adnA === undefined || !agentCode || typeof minPremium !== 'number') {
			this.errorService.setError({
				error: new Error(`There has been a problem updating this agent\'s Addendum A status.\nadnA: ${adnA}\nagentCode: ${agentCode}\nminPremium: ${minPremium}\n`),
				message: 'There has been a problem updating this agent\'s Addendum A status',
				title: 'Update Addendum A Error',
				dialog: true
			});
			this.singleAgentForm.get('minPremium').setValue(this.agent ? this.agent.MinPremium : 0);
			this.singleAgentForm.get('adnA').setValue(this.agent ? this.agent.AdnA : false);
			return;
		}

		try {
			// Build request body
			const requestBody: AdnAAssignment = {
				AgentCode: agentCode,
				Year: this.periodService.currentYear,
				MinPremium: minPremium,
				IsEnabled: adnA
			}

			// Update record in database and refresh  observable
			await this.apiService.updateAdnAForAgent(requestBody);

			// Update agent list after checking if filter state is true.
			this.filterService.currentFiltering.pipe(take(1)).subscribe(isFiltering => this.isFiltering = isFiltering);

			if (this.isFiltering) {
				let rawFilters = null;
				this.filterService.filters.pipe(take(1)).subscribe(x => rawFilters = x);
				rawFilters.page = (this.page + 1);
				this.filterService.setFilters(rawFilters);
			} else {
				await this.apiService.getAgentsPaginated(this.chosenYear, this.chosenMonth, this.page);
			}
		} catch (e) {
			// If error, log it and set the checkbox back to previous state
			console.error(e)
			this.singleAgentForm.controls.adnA.setValue(!adnA);
		}

		if (adnA === true) {
			this.singleAgentForm.get('minPremium').setValidators([Validators.required]);
		} else if (adnA === false) {
			this.singleAgentForm.get('minPremium').setValidators([]);
		}

		this.singleAgentForm.get('minPremium').updateValueAndValidity();

		// Refresh report data now that there has been a change in addendum status.
		// Don't retrieve reports if data is present or future date
		if (!(this.chosenYear === this.periodService.currentYear && this.chosenMonth >= this.periodService.currentMonth)) {
			const rollUp = this.singleAgentForm.get('rollUp').value;
			// Rolled Up reports should use Master Agent Id
			const agentForReport = rollUp && this.agent.MasterAgentId ? this.agent.MasterAgentId : this.agent.AgentId;
			// Grab report data
			this.retrieveReportData(this.chosenYear, this.chosenMonth, [agentForReport], this.master, this.children, true);
		}
	}

	toggleAdnC() {
		this.adnCChangeSubscription = this.singleAgentForm.get('adnC').valueChanges
			.subscribe(adnC => {
				if (adnC === true) {
					this.singleAgentForm.get('rate').setValue('.8');
				} else if (adnC === false) {
					this.singleAgentForm.get('rate').setValue('1');
				}
			})
	}

	// TODO: Refresh report data
	async saveAdnC() {
		const adnC = this.singleAgentForm.get('adnC').value;
		const agentCode = this.agent.AgentId.trim();

		// Display errors if validation fails
		if (adnC === null || adnC === undefined || !agentCode) {
			this.errorService.setError({
				error: new Error(`There has been a problem updating this agent\'s Addendum C status.\nadnC: ${adnC}\nagentCode: ${agentCode}`),
				message: 'There has been a problem updating this agent\'s Addendum C status',
				title: 'Update Addendum C Error',
				dialog: true
			});
			return;
		}

		try {
			// Build request body
			const requestBody: AdnC = {
				AgentId: agentCode,
				Year: this.periodService.currentYear,
				IsEnabled: adnC
			}

			// Update record in database and refresh agent data observable
			await this.apiService.updateAdnCForAgent(requestBody);

			// Update agent list after checking if filter state is true.
			this.filterService.currentFiltering.pipe(take(1)).subscribe(isFiltering => this.isFiltering = isFiltering);

			if (this.isFiltering) {
				let rawFilters = null;
				this.filterService.filters.pipe(take(1)).subscribe(x => rawFilters = x);
				rawFilters.page = (this.page + 1);
				this.filterService.setFilters(rawFilters);
			} else {
				await this.apiService.getAgentsPaginated(this.chosenYear, this.chosenMonth, this.page);
			}
		} catch (e) {
			// If error, log it and set the checkbox back to previous state
			console.error(e)
			this.singleAgentForm.controls.adnC.setValue(!adnC);
		}

		// Refresh report data now that there has been a change in addendum status.
		// Don't retrieve reports if data is present or future date
		if (!(this.chosenYear === this.periodService.currentYear && this.chosenMonth >= this.periodService.currentMonth)) {
			const rollUp = this.singleAgentForm.get('rollUp').value;
			// Rolled Up reports should use Master Agent Id
			const agentForReport = rollUp && this.agent.MasterAgentId ? this.agent.MasterAgentId : this.agent.AgentId;
			// Grab report data
			this.retrieveReportData(this.chosenYear, this.chosenMonth, [agentForReport], this.master, this.children, true);
		}
	}

	checkboxValueChanged(e) {
		this.resetForm(true);
	}

	resetForm(shouldReset, resetCheckbox?: boolean) {
		try {

			if (!shouldReset || !this.singleAgentForm || !this.combinedReportForm)
				return;

			// Set the observable parameters necessary to retrieve reports as null
			this.exportReport.setReportParams(null, null, null, null);

			// Reset period filter "year" to chosen year
			this.singleAgentForm.get('year').setValue(this.periodService.years.filter(x => this.chosenYear === x.value)[0]);
			this.singleAgentForm.get('month').setValue(this.periodService.months.filter(x => this.chosenMonth === x.value)[0]);

			// Reset agent form with selected agent data
			this.singleAgentForm.get('minPremium').setValue(this.agent ? this.agent.MinPremium : 0);
			this.singleAgentForm.get('adnA').setValue(this.agent ? this.agent.AdnA : false);
			this.singleAgentForm.get('adnC').setValue(this.agent ? this.agent.AdnC : false);
			this.singleAgentForm.get('rate').setValue(this.agent ? this.agent.Rate : 1);
			//this.singleAgentForm.get('rollUp').setValue(this.master ? true : false);

			if (resetCheckbox) {
				this.singleAgentForm.get('rollUp').setValue(this.rollUpChecked);
			}

			this.reportTop = [];
			this.reportBottom = [];
			if (this.agent.SubAgent == null || this.agent.SubAgent == undefined) {
				this.agent.SubAgent = [];
			}
			// Reset period filter "year" to chosen year
			this.combinedReportForm.get('year').setValue(this.periodService.years.filter(x => this.chosenYear === x.value)[0]);
			this.combinedReportForm.get('month').setValue(this.periodService.months.filter(x => this.chosenMonth === x.value)[0]);

			// Reset combined report form completely
			this.combinedReportForm.get('agentSearch').setValue('');
			this.combinedReportForm.get('zeroPayment').setValue(false);
			this.combinedReportForm.get('profitSharingPlan').setValue('');
		}

		catch (error) {
			console.log(error);
		}

	}

	toggleEditingMinimum() {
		this.editingMinimum = !this.editingMinimum;
		if (this.editingMinimum === true) {
			this.originalMinimumFormFields = {
				minPremium: this.singleAgentForm.get('minPremium').value,
				adnA: this.singleAgentForm.get('adnA').value
			}
		} else if (this.editingMinimum === false) {
			this.saveAdnA();
		}
	}

	cancelEditingMinimum() {
		this.editingMinimum = false;
		// Reset Addendum A section fields
		this.singleAgentForm.get('minPremium').setValue(this.originalMinimumFormFields.minPremium);
		this.singleAgentForm.get('adnA').setValue(this.originalMinimumFormFields.adnA);
	}

	// TODO: For now this functionality will not include editing the actual rate,
	// only enabling and disabling.
	toggleEditingRate() {
		this.editingRate = !this.editingRate;
		if (this.editingRate === true) {
			this.originalRateFormFields = {
				adnC: this.singleAgentForm.get('adnC').value
			}
		} else if (this.editingRate === false) {
			this.saveAdnC();
		}
	}

	cancelEditingRate() {
		this.editingRate = false;
		// Reset Addendum C checkbox
		this.singleAgentForm.get('adnC').setValue(this.originalRateFormFields.adnC);
	}

	async openCalculationDetail(detailsFor: string) {
		let planInfo: TableAssignments[] = null;
		let chosenYearAdnA: number = null;
		let reportTopMinusOne = null;
		let reportTopMinusTwo = null;
		let reportBottomMinusOne = null;
		let reportBottomMinusTwo = null;
		let detailData: ReportDataType = null;
		let detailDataMinusOne: ReportDataType = null;
		let detailDataMinusTwo: ReportDataType = null;
		let agentStartDate = null;
		if ((!this.reportBottom || (this.reportBottom && !this.reportBottom.length))
			|| (!this.reportTop || (this.reportTop && !this.reportTop.length))) return;
		// Serialize all the reporting data.
		detailData = {
			...this.reportBottom[0],
			...this.reportTop[0]
		}
		// Emit an event to open the calculation detail modal
		this.requestCalculation.emit({
			detailsFor,
			detailData,
			detailDataMinusOne,
			detailDataMinusTwo,
			awaitingDetails: true,
			planInfo,
			chosenYearAdnA,
			year: this.chosenYear,
			month: this.chosenMonth,
			agentStartDate
		});
		const rollUp = this.singleAgentForm.get('rollUp').value;
		// Check for multiple agents.
		// If only a single agent is selected, then check if a rolled up report was requested.
		// If so, then we need to use master agent ID.
		const agentsForReport = this.agentList && this.agentList.length ? this.agentList.map(x => x.data.AgentId.trim()) : rollUp && this.agent.MasterAgentId ? [this.agent.MasterAgentId] : [this.agent.AgentId];
		// Grab the table assignments for this agent's plan
		if (this.agent
			&& (detailsFor === 'loss-factor'
				|| detailsFor === 'profitability-factor'
				|| detailsFor === 'growth-factor')) {
			// TODO: This is not the most performant way to grab a territory's plan.
			// There should be an endpoint for grabbing a selected plan for a given territory and year.
			const allTerritories = await this.apiService.getTerritoriesByYear(this.chosenYear);
			// Filter all territories to grab only the territory which matches this agent.
			// Then map over the filtered result to return just the Id for that territory's plan.
			const planIds = allTerritories
				.filter(x => x.MarketingTerritory === this.agent.Territory)
				.map(x => x.PlanInformation.Id);
			// Retrieve the table assignments for that plan.
			planInfo = await this.apiService.getPlanTableAssignments(planIds[0]);
		}
		// Grab agent start date
		if (this.agent && detailsFor === 'earned-premium-actual-or-projected') {
			agentStartDate = await this.apiService.getAgentStartDate(agentsForReport[0]);
		}
		// Grab previous report data for only one year prior
		if (detailsFor === 'earned-premium-actual-or-projected'
			|| detailsFor === 'written-premium-actual-or-projected') {
			// Grab report data
			const { reportTop: reportTopMinusOne, reportBottom: reportBottomMinusOne } = await this.retrieveReportData((this.chosenYear - 1), 11, agentsForReport, this.master, this.children, false);
			// Reset the report parameters to be chosen year and month
			this.exportReport.setReportParams(this.chosenYear, this.chosenMonth, agentsForReport, rollUp);
			// Serialize all the previous reporting data.
			if ((reportTopMinusOne && reportTopMinusOne.length)
				&& (reportBottomMinusOne && reportBottomMinusOne.length)) {
				detailDataMinusOne = {
					...reportTopMinusOne[0],
					...reportBottomMinusOne[0]
				}
			}
		}
		// Grab previous report data for one and two years prior
		if (detailsFor === 'profitability') {
			// Grab report data
			const { reportTop: reportTopMinusOne, reportBottom: reportBottomMinusOne } = await this.retrieveReportData((this.chosenYear - 1), 11, agentsForReport, this.master, this.children, false);
			const { reportTop: reportTopMinusTwo, reportBottom: reportBottomMinusTwo } = await this.retrieveReportData((this.chosenYear - 2), 11, agentsForReport, this.master, this.children, false);
			// Reset the report parameters to be chosen year and month
			this.exportReport.setReportParams(this.chosenYear, this.chosenMonth, agentsForReport, rollUp);
			// Serialize all the previous reporting data.
			if ((reportTopMinusOne && reportTopMinusOne.length)
				&& (reportBottomMinusOne && reportBottomMinusOne.length)) {
				detailDataMinusOne = {
					...reportTopMinusOne[0],
					...reportBottomMinusOne[0]
				}
			}
			if ((reportTopMinusTwo && reportTopMinusTwo.length)
				&& (reportBottomMinusTwo && reportBottomMinusTwo.length)) {
				detailDataMinusTwo = {
					...reportTopMinusTwo[0],
					...reportBottomMinusTwo[0]
				}
			}
		}
		// Grab current addendum A rate
		if (detailsFor === 'growth') {
			let allAdnA = await this.apiService.getAllAdnA();
			allAdnA = allAdnA.filter(x => { return (x.StartYear <= this.chosenYear) && (x.EndYear >= this.chosenYear) });
			if (allAdnA.length) chosenYearAdnA = allAdnA[0].Value;
		}
		// Emit an event to open the calculation detail modal
		this.requestCalculation.emit({
			detailsFor,
			detailData,
			detailDataMinusOne,
			detailDataMinusTwo,
			awaitingDetails: false,
			planInfo,
			chosenYearAdnA,
			year: this.chosenYear,
			month: this.chosenMonth,
			agentStartDate
		});
	}

	leftBoxXOR() {
		return ((this.agent || this.agentList) && !(this.agent && this.agentList));
	}

	async searchAgentByCode() {
		this.searchError = null;
		const inputValue = this.combinedReportForm.get('agentSearch').value;
		var reg = /^\d+$/;

		if (!reg.test(inputValue)) {
			this.searchError = 'Please enter an agent ID';
			this.searchResult = null;
			return;
		}
		try {
			this.searchResult = await this.apiService.searchAgents({
				filter: {
					Id: [inputValue],
					Territory: null,
					Region: null,
					AddendumAEnabled: null,
					AddendumCEnabled: null,
					IncludeCanceled: null,
					IncludeZeroPayments: null,
					Page: 1,
					PageSize: 1,
					IncludeSubagents: false
				}
			}, this.chosenYear, this.chosenMonth, false, false);
			this.searchResult = this.searchResult[0];

			if (!this.searchResult) {
				this.searchError = 'Agent not found';
			} else {
				Object.keys(this.searchResult)
					.filter(key => typeof this.searchResult[key] === 'string')
					.map(key => this.searchResult[key] = this.searchResult[key].trim());
			}
		} catch (e) {
			this.searchError = 'Network error';
			this.searchResult = null;
		}
	}

	addAgentToReport() {
		// Check if the search result found an agent
		if (!this.searchResult || (this.searchResult && !Object.keys(this.searchResult).length)) return;
		// Check if the agent has already been added to the agentList
		const agentExists = this.agentList.filter(agent => {
			return agent.data.AgentId.trim() === (this.searchResult as Agent).AgentId
		});
		// If already added to the list then return
		if (agentExists.length) return;
		// If not, then add the agent to agentList
		this.agentList.unshift({ data: this.searchResult })
		// Trim the space off either end and generate updated report data
		const agentList = this.agentList.map(x => x.data.AgentId.trim());
		this.retrieveReportData(this.chosenYear, this.chosenMonth, agentList, this.master, this.children, true);
		// Unset the search result
		this.searchResult = null;
	}

	removeAgentFromReport(index) {
		this.agentList.splice(index, 1);
		const agentList = this.agentList.map(x => x.data.AgentId.trim());
		this.retrieveReportData(this.chosenYear, this.chosenMonth, agentList, this.master, this.children, true);
	}
}
