import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { SelectItem } from 'primeng/api';
import { ExportReportService } from '@services/export-report.service';
import { Subscription } from 'rxjs';
import { FormControl, FormGroup } from '@angular/forms';
import { PeriodService } from '@services/period.service';

@Component({
	selector: 'app-report-modal',
	templateUrl: './report-modal.component.html',
	styleUrls: ['./report-modal.component.css']
})
export class ReportModalComponent implements OnInit {

	private _displayDialog: boolean;
	
	public agents: SelectItem[];
	public reportType: SelectItem[];
	public reportLength: SelectItem[];
	public includeZeroPayment: boolean;
	public orderBy: 'Agent' | 'Region';
	periodCustomYears: {label: string, value: number}[];
	public regionChecked: boolean = true;
	// TODO: Hardcoded to generate report for all agents
	// This specific functionality was requested.
	public agentsSelection: 'All' | 'Selection' = 'All';
	public reportTypeSelection: 'Batch' | 'Individual' = 'Batch';
	public reportLengthSelection: 'Summary' | 'Full' = 'Summary';

	public reportPendingSubscription: Subscription;
	public reportPending: boolean = false;
	periodFilter: FormGroup;

	@Input()
	set displayDialog(shouldDisplay: boolean) {
		this._displayDialog = shouldDisplay;
	}
	get displayDialog(): boolean { return this._displayDialog; }

	@Output() reportDialogClosed = new EventEmitter();
	
	constructor(private exportReport: ExportReportService,
		public periodService: PeriodService) {
		this.agents = [{label: 'All', value: 'All'}, {label: 'Selection', value: 'Selection'}];
		this.reportType = [{label: 'Batch', value: 'Batch'}, {label: 'Individual', value: 'Individual'}];
		this.reportLength = [{label: 'Summary', value: 'Summary'}, {label: 'Full', value: 'Full'}];
	}

	ngOnInit() {
		this.reportPendingSubscription = this.exportReport.reportPending.subscribe(pendingReportArray => {
			this.reportPending = pendingReportArray.indexOf('bulk_pdf') === -1 ? false : true;
		});
		this.periodFilter = new FormGroup({
			year: new FormControl(this.periodService.years.filter(x => x.value === this.periodService.currentYear)[0]),
			month: new FormControl(this.periodService.months[this.periodService.currentMonth === 0 ? 11 : (this.periodService.currentMonth - 1)])
		});

		this.periodCustomYears = this.periodService.years.filter((v, i) => {
			if (i !== 0) return true
		});
	}

	ngOnDestroy() {
		if (this.reportPendingSubscription) this.reportPendingSubscription.unsubscribe();
	}

	handlePrint(e) {
		let selectedYear: number = this.periodFilter.get('year').value.value;
		let selectedMonth: number = this.periodFilter.get('month').value.value;
		this.exportReport.setReportParams(selectedYear,selectedMonth,null,false)
		this.exportReport.export(
			'bulk_pdf',
			this.reportLengthSelection === 'Full',
			this.agentsSelection === 'All',
			this.reportTypeSelection === 'Batch',
			this.regionChecked ? 'Region' : 'Agent',
			this.includeZeroPayment === true
		);
	} 

	onHideDialog() {
		this.displayDialog = false
		this.reportDialogClosed.emit();
	}
}
