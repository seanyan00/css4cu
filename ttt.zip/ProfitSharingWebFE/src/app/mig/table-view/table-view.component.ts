import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { TableDataService } from '@services/table-data.service';
import { ApiService, Table, TableNames, TableStatus } from '../../services/api.service';
import { ConvertCsvToJsonService } from '../../services/convert-csv-to-json.service';

@Component({
	selector: 'app-table-view',
	templateUrl: './table-view.component.html',
	styleUrls: ['./table-view.component.css']
})
export class TableViewComponent implements OnInit {

	// Table data
	public volumeLossData;
	public growthData;
	public profitabilityData;

	// Table data subscription
	private _volumeLossSubscription: Subscription;
	private _growthSubscription: Subscription;
	private _profitabilitySubscription: Subscription;

	// Common table properties
	private checkTableType: Subscription;
	public tableType: 'volume-loss' | 'growth' | 'profitability';
	public tableTypeHeader: 'Premium Volume and Loss Ratio Factors' | 'Premium Growth Factors' | '3-Year Profitability Factors';
	public tableName: string;
	public tableId: string;

	// Table specific properties
	public volumeOnlyCols: string[][];
	public volumeLossCols: string[];
	public growthCols: string[];
	public profitabilityCols: string[];

	// Status message
	public showWarning: TableStatus = TableStatus.Approved;
	public tableStatus = TableStatus

	constructor(
		private route: ActivatedRoute,
		private tableDataService: TableDataService,
		private apiService: ApiService,
		private convertCSV: ConvertCsvToJsonService
	) { }

	ngOnInit() {
		this.checkTableType = this.route.params.subscribe(params => {
			this.tableType = params.type;
			this.tableName = params.name;
			this.tableId = params.id;

			switch (params.type) {
				case 'volume-loss':
					this.tableTypeHeader = 'Premium Volume and Loss Ratio Factors';

					// Subscribe to observable changes to Volume Loss Ratio table data. Store the subscription in variable,
					this._volumeLossSubscription = this.tableDataService.volumeLoss.subscribe(async (data: Table) => {
						// Check if data does not exist. If it does exist, check if data is a string.
						if ((!data.Data) || (data.Data && typeof data.Data === 'string')) {
							// If data does not exist, grab data from API.
							if (!data.Data) {
								data = await this.apiService.getTable(parseInt(this.tableId)) as Table;
							}

							// If data is not a string, exit function
							if (typeof data.Data !== 'string') return;

							// Convert data from JSON string to JSON object
							try {
								const parseTable = JSON.parse(data.Data);
								data.Data = parseTable;
							} catch (e) {
								data.Data = null;
								console.error(new Error('Table retrieved has invalid formatting.'))
								return this.volumeLossData = undefined;
							}
						// If data does exist but is not a string, and the object has no entries.
						} else if (Object.entries(data.Data).length === 0) {
							// Empty the component property
							return this.volumeLossData = undefined;
						}

						// Assign the data to the component property
						this.volumeLossData = data.Data;

						// Display the status of the table in the header
						this.showWarning = data.TableStatus;

						// Array of all column headings
						this.volumeLossCols = Object.keys(data.Data[0]);

						// Array of just the volume dollar ranges
						this.volumeOnlyCols = this.volumeLossCols
							.filter(col => {
								return !isNaN(parseInt(col.split('-')[0]))
							})
							.map(col => col.split('-'));
					})
					break;
				case 'growth':
					this.tableTypeHeader = 'Premium Growth Factors';

					this._growthSubscription = this.tableDataService.growth.subscribe(async (data: Table) => {
						if ((!data.Data) || (data.Data && typeof data.Data === 'string')) {
							if (!data.Data) {
								data = await this.apiService.getTable(parseInt(this.tableId)) as Table;
							}

							if (typeof data.Data !== 'string') return;

							try {
								const parseTable = JSON.parse(data.Data);
								data.Data = parseTable;
							} catch (e) {
								data.Data = null;
								console.error(new Error('Table retrieved has invalid formatting.'))
								return this.growthData = undefined;
							}
						} else if (Object.entries(data.Data).length === 0) {
							return this.growthData = undefined;
						}

						this.growthData = data.Data;
						this.showWarning = data.TableStatus;
						this.growthCols = Object.keys(data.Data[0]);
					})
					break;
				case 'profitability':
					this.tableTypeHeader = '3-Year Profitability Factors';

					this._profitabilitySubscription = this.tableDataService.profitability.subscribe(async (data: Table) => {
						if ((!data.Data) || (data.Data && typeof data.Data === 'string')) {
							if (!data.Data) {
								data = await this.apiService.getTable(parseInt(this.tableId)) as Table;
							}

							if (typeof data.Data !== 'string') return;

							try {
								const parseTable = JSON.parse(data.Data);
								data.Data = parseTable;
							} catch (e) {
								data.Data = null;
								console.error(new Error('Table retrieved has invalid formatting.'))
								return this.profitabilityData = undefined;
							}
						} else if (Object.entries(data.Data).length === 0) {
							return this.profitabilityData = undefined;
						}

						this.profitabilityData = data.Data;
						this.showWarning = data.TableStatus;
						this.profitabilityCols = Object.keys(data.Data[0]);
					})
					break;
				default:
					break;
			}
		})
	}

	ngOnDestroy() {
		// TODO: Need to unsubscribe elsewhere
		if (this.checkTableType) this.checkTableType.unsubscribe();
		if (this._volumeLossSubscription) this._volumeLossSubscription.unsubscribe();
		if (this._growthSubscription) this._growthSubscription.unsubscribe();
		if (this._profitabilitySubscription) this._profitabilitySubscription.unsubscribe();
	}
}
