import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { ApiService, Plan, TableAssignments, MinPremium } from '../../services/api.service';
import { PeriodService } from '../../services/period.service';
import { ErrorService } from '../../services/error.service';

@Component({
	selector: 'app-plan-view',
	templateUrl: './plan-view.component.html',
	styleUrls: ['./plan-view.component.css']
})
export class PlanViewComponent implements OnInit {
	public loading: boolean = false;

	// Plan info
	public planId: number;
	public planName: string;

	// Table assignments
	public tableAssignmentForm: FormGroup;
	public editingTableAssignment: boolean = false;
	public editingTableAssignmentRow: number = null;
	private getTableAssignments: Subscription;
	public tableAssignments: TableAssignments[] = [];
	public newAssignment: TableAssignments | null = null;

	// Table options
	public lossOptions: {label: string, value: number}[];
	public growthOptions: {label: string, value: number}[];
	public profitOptions: {label: string, value: number}[];

	// Minimum Premium
	public minPremiumForm: FormGroup;
	public minPremiumFormReady: boolean = false;
	public minPremiumList: MinPremium[] = [];
	public editingMinPremium: boolean = false;
	public editingMinPremiumRow: number = null;
	public newMinPremium: MinPremium | null = null;

	constructor(
		private apiService: ApiService,
		public periodService: PeriodService,
		private route: ActivatedRoute,
		private errorService: ErrorService
	) { }

	async ngOnInit() {
		this.apiService.getVolumeLossTables().then(dataList => {
			return this.lossOptions = dataList.filter(data => data.TableStatus === 2).map(data => {
				return { label: data.Name, value: data.Id };
			})
		});

		this.apiService.getProfitabilityTables().then(dataList => {
			return this.profitOptions = dataList.filter(data => data.TableStatus === 2).map(data => {
				return { label: data.Name, value: data.Id };
			})
		});

		this.apiService.getGrowthTables().then(dataList => {
			return this.growthOptions = dataList.filter(data => data.TableStatus === 2).map(data => {
				return { label: data.Name, value: data.Id };
			})
		});

		this.getTableAssignments = this.route.params.subscribe(async params => {
			// Grab the plan name from the URL params
			this.planName = params.name;

			// Grab the plan id from the URL params
			this.planId = parseInt(params.id);

			try {
				// Grab all table assignments associated with current plan, from the database
				this.tableAssignments = await this.apiService.getPlanTableAssignments(this.planId);
				// Sort the list by start year
				this.tableAssignments = this.tableAssignments.sort((a: TableAssignments, b: TableAssignments) => (a.StartYear < b.StartYear) ? 1 : -1);
			} catch (e) {
				console.error(e)
			}

			// Minimum Premium setup
			this.minPremiumList = await this.apiService.getAllMinPremiumsForPlan(this.planId);
			this.minPremiumList.sort((a: MinPremium, b: MinPremium) => (a.StartYear < b.StartYear) ? 1 : -1);
			this.buildMinPremiumForm();
		})

		// Create reactive form for table assignments
		this.buildTableAssignmentForm();
	}

	ngOnDestroy() {
		if (this.getTableAssignments) this.getTableAssignments.unsubscribe()
	}

	// Blank form to start with. Will be populated with default values elsewhere.
	buildTableAssignmentForm() {
		this.tableAssignmentForm = new FormGroup({
			loss: new FormControl(),
			growth: new FormControl(),
			profit: new FormControl(),
			startDate: new FormControl(),
			endDate: new FormControl()
		})
	}

	// Initialize table assignment form to be editable and to have default values
	initTableAssignment(index: number, newAssignment: boolean) {
		if (newAssignment) {
			this.editingTableAssignment = true;
			this.editingTableAssignmentRow = 0;
			const rowData = this.newAssignment;
			this.populateFields(rowData);
		} else {
			this.editingTableAssignment = true;
			this.editingTableAssignmentRow = index;
			const rowData = this.tableAssignments[index];
			this.populateFields(rowData);
		}
	}

	populateFields(rowData) {
		this.tableAssignmentForm = new FormGroup({
			loss: new FormControl(
				rowData.PremiumVolumeLossRatioReference
				? { value: rowData.PremiumVolumeLossRatioReference.Id }
				: { value: this.lossOptions[0].value },
				Validators.required
			),
			growth: new FormControl(
				rowData.ProfitGrowthFactorsReference
				? { value: rowData.ProfitGrowthFactorsReference.Id }
				: { value: this.growthOptions[0].value },
				Validators.required
			),
			profit: new FormControl(
				rowData.ThreeYearProfitabilityReference
				? { value: rowData.ThreeYearProfitabilityReference.Id }
				: { value: this.profitOptions[0].value },
				Validators.required
			),
			startDate: new FormControl(rowData.StartYear ? rowData.StartYear : this.periodService.currentYear, Validators.required),
			endDate: new FormControl(rowData.EndYear ? rowData.EndYear : 9999, Validators.required)
		})
	}

	// Remove form from UI
	cancelTableAssignment(index: number, newAssignment: boolean) {
		this.editingTableAssignment = false;
		if (newAssignment) {
			this.newAssignment = null;
			this.tableAssignments.shift();
		}
	}

	// Send data to back-end
	async saveTableAssignment(index: number, newAssignment: boolean) {
		this.editingTableAssignment = false;
		let sendDataResult;
		let requestBody: TableAssignments;

		// If user tried to submit blank endDate field, set it to 9999
		if (newAssignment
			&& !this.tableAssignmentForm.get('endDate').value
			&& this.tableAssignmentForm.get('endDate').value !== 9999) {
			this.tableAssignmentForm.get('endDate').setValue(9999);
		}

		try {
			if (this.tableAssignmentForm.invalid) {
				// Blank fields
				throw 'No fields should be left blank';
			} else if (newAssignment
				&& (this.tableAssignmentForm.get('endDate').value !== 9999)
				&& (this.tableAssignmentForm.get('startDate').value > this.tableAssignmentForm.get('endDate').value)) {
				// New assignment has explicit end year, and the start year is greater than the end year.
				// This is legacy from when end years were allow to be set by the FE.
				this.cancelTableAssignment(0, newAssignment)
				throw 'End year must be greater than start year';
			} else if (!newAssignment
				&& (this.tableAssignmentForm.get('endDate').value !== 9999)
				&& (this.tableAssignmentForm.get('startDate').value > this.tableAssignmentForm.get('endDate').value)) {
				// Existing assignment has explicit end year, but the start year is greater than the end year
				this.cancelTableAssignment(index, newAssignment)
				throw 'End year must be greater than start year';
			} else if (newAssignment
				&& this.tableAssignments[1]
				&& (this.tableAssignments[1].EndYear !== 9999)
				&& (this.tableAssignmentForm.get('startDate').value <= this.tableAssignments[1].EndYear)) {
				// Previous row has explicit end year, and start year of new assignment is not greater than previous row's end year
				this.cancelTableAssignment(0, newAssignment)
				throw 'Start year must be greater than previous assignment\'s end year'
			} else if (newAssignment
				&& this.tableAssignments[1]
				&& (this.tableAssignmentForm.get('startDate').value <= this.tableAssignments[1].StartYear)) {
				// Previous row's start year is greater than the start year of the new assignment
				this.cancelTableAssignment(0, newAssignment)
				throw 'Start year must be greater than previous assignment\'s start year'
			} else if (!newAssignment
				&& this.tableAssignments[index + 1]
				&& (this.tableAssignmentForm.get('startDate').value <= this.tableAssignments[index + 1].StartYear)) {
				// Current row start date needs to be greater than previous row's start date
				this.cancelTableAssignment(0, newAssignment)
				throw 'Start year must be greater than previous assignment\'s start year'
			} else if (!newAssignment
				&& this.tableAssignments[index + 1]
				&& (this.tableAssignments[index + 1].EndYear !== 9999)
				&& (this.tableAssignmentForm.get('startDate').value <= this.tableAssignments[index + 1].EndYear)) {
				// Previous row has an explicit end year, and start year of the current row is not greater than previous row's end year
				this.cancelTableAssignment(0, newAssignment)
				throw 'Start year must be greater than previous assignment\'s end year'
			}

			// Build request body
			requestBody = {
				"PlanInformationId": this.planId,
				"StartYear": this.tableAssignmentForm.get('startDate').value,
				"EndYear": this.tableAssignmentForm.get('endDate').value,
				"ThreeYearProfitabilityId": this.tableAssignmentForm.get('profit').value.value,
				"ProfitGrowthFactorsId": this.tableAssignmentForm.get('growth').value.value,
				"PremiumVolumeLossRatioId": this.tableAssignmentForm.get('loss').value.value
			}

			// Grab the actual index of the existing table if not a new table assignment
			if (!newAssignment) requestBody.Id = this.tableAssignments[index].Id;

			sendDataResult = newAssignment
				? await this.apiService.addTableAssignment(requestBody)
				: await this.apiService.updateTableAssignment(requestBody);

			if (sendDataResult) {
				// If previous assignment's end year is greater than start year of row we are updating,
				// set previous end year to (start year - 1)
				if (this.tableAssignments[index + 1] // Previous assignment row exists
				&& this.tableAssignmentForm.get('startDate').value > this.tableAssignments[index + 1].StartYear) { // Editing row's start date is greater than previous rows start date
					this.tableAssignments[index + 1].EndYear = (this.tableAssignmentForm.get('startDate').value - 1); // Set the previous end year to 1 year less than editing row's start year
					this.tableAssignments[index + 1].PlanInformationId = this.planId;
					this.tableAssignments[index + 1].ThreeYearProfitabilityId = this.tableAssignments[index + 1].ThreeYearProfitabilityReference.Id;
					this.tableAssignments[index + 1].ProfitGrowthFactorsId = this.tableAssignments[index + 1].ProfitGrowthFactorsReference.Id;
					this.tableAssignments[index + 1].PremiumVolumeLossRatioId = this.tableAssignments[index + 1].PremiumVolumeLossRatioReference.Id;
					await this.apiService.updateTableAssignment(this.tableAssignments[index + 1]);
				}
			}

			this.tableAssignments = await this.apiService.getPlanTableAssignments(this.planId);
			this.tableAssignments = this.tableAssignments.sort((a: TableAssignments, b: TableAssignments) => (a.StartYear < b.StartYear) ? 1 : -1);
			this.newAssignment = null;
		} catch (e) {
			this.newAssignment = null;
			this.errorService.setError({
				error: new Error(e),
				message: e,
				title: 'Update Plan Error',
				dialog: true
			});
		}
	}

	addTableAssignment() {
		// TODO: If pagination is anything other than 1 new row won't be visible
		if (this.newAssignment) return;
		this.newAssignment = {
			StartYear: this.tableAssignments[0] && this.tableAssignments[0].EndYear && this.tableAssignments[0].EndYear !== 9999 // If previous assignment's end year is not 9999
				? (this.tableAssignments[0].EndYear + 1)
				: this.tableAssignments[0] && this.tableAssignments[0].EndYear === 9999 // If previous assignment's end year is 9999
				? this.tableAssignments[0].StartYear + 1 // Add one year to the previous assignment's start year
				: null,
			EndYear: 9999,
			PlanInformationId: this.planId,
			ThreeYearProfitabilityId: null,
			ThreeYearProfitabilityReference: {
				Name: '',
				Id: this.profitOptions[0].value
			},
			PremiumVolumeLossRatioId: null,
			PremiumVolumeLossRatioReference: {
				Name: '',
				Id: this.lossOptions[0].value
			},
			ProfitGrowthFactorsId: null,
			ProfitGrowthFactorsReference: {
				Name: '',
				Id: this.growthOptions[0].value
			}
		}

		this.tableAssignments.unshift(this.newAssignment)
		this.initTableAssignment(0, true)
	}

	// Blank form to start with. Will be populated with default values elsewhere.
	buildMinPremiumForm() {
		this.minPremiumForm = new FormGroup({
			value: new FormControl(),
			startDate: new FormControl(),
			endDate: new FormControl()
		});
		this.minPremiumFormReady = true;
	}

	// Initialize Minimum Premium form to be editable and to have default values
	initMinPremium(index: number, newMinPremium: boolean) {
		if (newMinPremium) {
			this.editingMinPremium = true;
			this.editingMinPremiumRow = 0;
			const rowData = this.newMinPremium;
			this.populateMinPremiumForm(rowData);
		} else {
			this.editingMinPremium = true;
			this.editingMinPremiumRow = index;
			const rowData = this.minPremiumList[index];
			this.populateMinPremiumForm(rowData);
		}
	}

	// Assign default values for Minimum Premium form
	populateMinPremiumForm(rowData) {
		this.minPremiumForm = new FormGroup({
			value: new FormControl(rowData.Premium ? rowData.Premium : null, Validators.required),
			startDate: new FormControl(rowData.StartYear ? rowData.StartYear : this.periodService.currentYear, Validators.required),
			endDate: new FormControl(rowData.EndYear ? rowData.EndYear : 9999, Validators.required)
		});
	}

	// Remove form from UI
	cancelMinPremium(index: number, newAssignment: boolean) {
		this.editingMinPremium = false;
		if (newAssignment) {
			this.newMinPremium = null;
			this.minPremiumList.shift();
		}
	}

	// Send data to back-end
	async saveMinPremium(index: number, newMinPremium: boolean) {
		this.editingMinPremium = false;
		let sendDataResult;
		let requestBody: MinPremium;
		
		// If user tried to submit blank endDate field, set it to 9999
		if (!this.minPremiumForm.get('endDate').value
			&& this.minPremiumForm.get('endDate').value !== 9999) {
			this.minPremiumForm.get('endDate').setValue(9999);
		}

		try {
			if (this.minPremiumForm.invalid) {
				// Blank fields
				throw 'No fields should be left blank';
			} else if (newMinPremium
				&& (this.minPremiumForm.get('endDate').value !== 9999)
				&& (this.minPremiumForm.get('startDate').value > this.minPremiumForm.get('endDate').value)) {
				// New Min Premium has explicit end year, and the start year is greater than the end year.
				// This is legacy from when end years were allow to be set by the FE.
				this.cancelMinPremium(0, newMinPremium);
				throw 'End year must be greater than start year';
			} else if (!newMinPremium
				&& (this.minPremiumForm.get('endDate').value !== 9999)
				&& (this.minPremiumForm.get('startDate').value > this.minPremiumForm.get('endDate').value)) {
				// Existing Min Premium has explicit end year, but the start year is greater than the end year
				this.cancelMinPremium(index, newMinPremium);
				throw 'End year must be greater than start year';
			} else if (newMinPremium
				&& this.minPremiumList[1]
				&& (this.minPremiumList[1].EndYear !== 9999)
				&& (this.minPremiumForm.get('startDate').value <= this.minPremiumList[1].EndYear)) {
				// Previous row has explicit end year, and start year of new Min Premium is not greater than previous row's end year
				this.cancelMinPremium(0, newMinPremium);
				throw 'Start year must be greater than previous Min Premium\'s end year';
			} else if (newMinPremium
				&& this.minPremiumList[1]
				&& (this.minPremiumForm.get('startDate').value <= this.minPremiumList[1].StartYear)) {
				// Previous row's start year is greater than the start year of the new Min Premium
				this.cancelMinPremium(0, newMinPremium);
				throw 'Start year must be greater than previous Min Premium\'s start year';
			} else if (!newMinPremium
				&& this.minPremiumList[index + 1]
				&& (this.minPremiumForm.get('startDate').value <= this.minPremiumList[index + 1].StartYear)) {
				// Current row start date needs to be greater than previous row's start date
				this.cancelMinPremium(0, newMinPremium);
				throw 'Start year must be greater than previous Min Premium\'s start year';
			} else if (!newMinPremium
				&& this.minPremiumList[index + 1]
				&& (this.minPremiumList[index + 1].EndYear !== 9999)
				&& (this.minPremiumForm.get('startDate').value <= this.minPremiumList[index + 1].EndYear)) {
				// Previous row has an explicit end year, and start year of the current row is not greater than previous row's end year
				this.cancelMinPremium(0, newMinPremium);
				throw 'Start year must be greater than previous Min Premium\'s end year';
			}

			// Build request body
			requestBody = {
				"Premium": this.minPremiumForm.get('value').value,
				"StartYear": this.minPremiumForm.get('startDate').value,
				"EndYear": this.minPremiumForm.get('endDate').value,
				"PlanInformation": {
					"Id": this.planId,
					"PlanName": this.planName
				}
			}

			// Grab the actual index of the existing Min Premium if not a new Min Premium
			if (!newMinPremium) requestBody.Id = this.minPremiumList[index].Id;

			sendDataResult = newMinPremium
				? await this.apiService.addMinPremiumToPlan(requestBody)
				: await this.apiService.updateMinPremiumForPlan(requestBody);

			if (sendDataResult) {
				// If previous Min Premium's end year is greater than start year of row we are updating,
				// set previous end year to (start year - 1)
				if (this.minPremiumList[index + 1] // Previous Min Premium row exists
				&& this.minPremiumForm.get('startDate').value > this.minPremiumList[index + 1].StartYear) { // Editing row's start date is greater than previous rows start date
					this.minPremiumList[index + 1].EndYear = (this.minPremiumForm.get('startDate').value - 1); // Set the previous end year to 1 year less than editing row's start year
					await this.apiService.updateMinPremiumForPlan(this.minPremiumList[index + 1]);
				}
			}

			this.minPremiumList = await this.apiService.getAllMinPremiumsForPlan(this.planId);
			this.minPremiumList = this.minPremiumList.sort((a: MinPremium, b: MinPremium) => (a.StartYear < b.StartYear) ? 1 : -1);
			this.newMinPremium = null;
		} catch (e) {
			this.newMinPremium = null;
			this.errorService.setError({
				error: new Error(e),
				message: e,
				title: 'Update Minimum Premium Error',
				dialog: true
			});
		}
	}

	addMinPremium() {
		// TODO: If pagination is anything other than 1 new row won't be visible
		if (this.newMinPremium) return;
		this.newMinPremium = {
			StartYear: this.minPremiumList[0] && this.minPremiumList[0].EndYear && this.minPremiumList[0].EndYear !== 9999 // If previous min premium's end year is not 9999
				? (this.minPremiumList[0].EndYear + 1)
				: this.minPremiumList[0] && this.minPremiumList[0].EndYear === 9999 // If previous min premium's end year is 9999
				? this.minPremiumList[0].StartYear + 1 // Add one year to the previous min premium's start year
				: null,
			EndYear: 9999,
			Premium: 1,
			PlanInformation: {
				Id: this.planId,
				PlanName: this.planName
			}
		}

		this.minPremiumList.unshift(this.newMinPremium)
		this.initMinPremium(0, true)
	}
}
