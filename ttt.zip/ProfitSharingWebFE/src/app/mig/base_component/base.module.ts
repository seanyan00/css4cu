import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from "@angular/router";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MIGBaseComponent } from './base.component';
//import { AgentListComponent } from '../agent-list/agent-list.component';
import { AgentListComponentV2 } from '../agent-list/agent-list-v2.component';
import { AgentViewComponent } from '../agent-view/agent-view.component';
import { CalendarModule } from 'primeng/calendar';
import { PaginatorModule } from 'primeng/paginator';
import { PanelModule } from 'primeng/panel';
import { TabViewModule } from 'primeng/tabview';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { InputTextModule } from 'primeng/inputtext';
import { MIGMessageModule } from '@overridden/primeng-message/message.module';
import { TreeTableModule } from 'primeng/treetable';
import { TableModule } from 'primeng/table';
import { Table } from 'primeng/table';
import { TooltipModule } from 'primeng/tooltip';
import { ProgressBarModule} from 'primeng/progressbar';
import { ButtonModule } from 'primeng/button';
import { SelectButtonModule } from 'primeng/selectbutton';
import { FieldsetModule } from 'primeng/fieldset';
import { RightPanelComponent } from '../right-panel/right-panel.component';
import { CardModule } from 'primeng/card';
import { CheckboxModule } from 'primeng/checkbox';
import { RadioButtonModule } from 'primeng/radiobutton';
import { SidebarModule } from 'primeng/sidebar';
import { FileUploadModule } from 'primeng/fileupload';
import { PlanListComponent } from '../plan-list/plan-list.component';
import { PlanViewComponent } from '../plan-view/plan-view.component';
import { TableListComponent } from '../table-list/table-list.component';
import { TableViewComponent } from '../table-view/table-view.component';
import { ReportBuilderComponent } from '../report-builder/report-builder.component';
import { ReportModalComponent } from '../report-modal/report-modal.component';
import { ProductsComponent } from '../products/products.component';
import { CalculationDetailComponent } from '../calculation-detail/calculation-detail.component';
import { DialogModule } from 'primeng/dialog';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DragDropModule } from 'primeng/dragdrop';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { DropdownModule } from 'primeng/dropdown';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';

@NgModule({
    imports: [
        BrowserAnimationsModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        CalendarModule,
		PaginatorModule,
		PanelModule,
        TabViewModule,
        ButtonModule,
        MIGInputtextModule,
        MIGDropDownModule,
        MIGCheckboxModule,
        DropdownModule,
        InputTextModule,
		MIGMessageModule,
		TooltipModule,
        FieldsetModule,
        TreeTableModule,
        TableModule,
        ProgressBarModule,
        CardModule,
        CheckboxModule,
        RadioButtonModule,
        SidebarModule,
        FileUploadModule,
        RouterModule,
		DialogModule,
		ConfirmDialogModule,
        DragDropModule,
        ProgressSpinnerModule,
        SelectButtonModule
    ],
    declarations: [
        MIGBaseComponent,
        RightPanelComponent,
        //AgentListComponent,
        AgentListComponentV2,
        AgentViewComponent,
        PlanListComponent,
        TableListComponent,
        TableViewComponent,
        ReportBuilderComponent,
        ReportModalComponent,
        PlanViewComponent,
        ProductsComponent,
        CalculationDetailComponent
    ],
    providers: [
        Table
    ]
})
export class MIGBaseModule { }
