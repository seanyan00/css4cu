import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Paths } from '../../app.routing.enums';
import { TreeNode } from 'primeng/api';
import { Message } from '../../system/app/message';
import { AgentDataService } from '@services/agent-data.service';
import { Subscription } from 'rxjs';
import { take } from 'rxjs/operators';
import { ExportReportService } from '@services/export-report.service';
import { ReportDataType } from '@mig/calculation-detail/calculation-detail.component';
import { TableAssignments } from '@services/api.service';


@Component({
	styleUrls: ['base.component.css'],
	templateUrl: './base.component.html',
	host: {
		class: 'main-section'
	}
})

export class MIGBaseComponent implements OnInit, OnDestroy {
	displayRightPanel: boolean = false;
	singleAgentViewVisible: boolean = false;
	combinedReportViewVisible: boolean = false;
	singleAgent;
	agentList;
	chosenYear;
	chosenMonth;
	periodFromAgentDetail;
	page;
	messages: Message[] = [];
	gridToDisplay: string = '';
	openDetailDialog: boolean = false;
	openReportDialog: boolean = false;
	showDetailsFor: string = '';
	showDetailData: ReportDataType = null;
	showDetailDataMinusOne: ReportDataType = null;
	showDetailDataMinusTwo: ReportDataType = null;
	showAwaitingDetails: boolean = null;
	showDetailPlanInfo: TableAssignments[] = null;
	showChosenYearAdnA: number = null;
	showChosenYear: number = null;
	showChosenMonth: number = null;
	showAgentStartDate: number = null;
	displayPrintOptionsSubscription: Subscription;
  
	constructor(
		private activatedRoute: ActivatedRoute,
		private agentDataService: AgentDataService,
		private exportReport: ExportReportService
	) {
		// TODO: replace this placeholder notification
		this.messages = [
			{severity: 'info', detail: 'A new marketing territory has been added. Choose a plan assignment now.', button: 'Go', route: `/${Paths.plans}`}
		]
	}

	ngOnInit(): void {
		this.triggerMessage();
		this.selectGridView();
		this.displayPrintOptionsSubscription = this.exportReport.displayPrintOptions.subscribe(display => {
			this.openReportDialog = display
		});
	}

	// TODO: Unsubscribe 
	ngOnDestroy() {
		if (this.displayPrintOptionsSubscription) this.displayPrintOptionsSubscription.unsubscribe();
	}
	
	onHideAgentView() {
		this.singleAgentViewVisible = false;
		this.combinedReportViewVisible = false;
	}

	// Static panel with filters and search
	onToggleRightPanel(display: boolean): void {
		this.displayRightPanel = display;
	}

	// Single agent detail fly-out
	onShowAgentDetailPanel(data: { page: number, chosenYear: number, chosenMonth: number, parent: TreeNode, agent: TreeNode }): void {
		this.singleAgentViewVisible = true;
		this.combinedReportViewVisible = false;
		this.singleAgent = {parent: data.parent, agent: data.agent};
		this.agentList = null;
		this.page = data.page;
		this.chosenYear = data.chosenYear;
		this.chosenMonth = data.chosenMonth;
	}

	// Combined report fly-out
	onShowCombinedReportPanel(data: { agentList: TreeNode[], chosenYear: number, chosenMonth: number }): void {
		this.combinedReportViewVisible = false;
		this.singleAgentViewVisible = true;
		this.agentList = data.agentList;
		this.singleAgent = null;
		this.chosenYear = data.chosenYear;
		this.chosenMonth = data.chosenMonth;
	}

	slideOutXOR() {
		const xor = ((this.singleAgentViewVisible || this.combinedReportViewVisible) && !(this.singleAgentViewVisible && this.combinedReportViewVisible));
		if (xor) {
			// Set observable to indicate that the agent detail panel is visible
			this.agentDataService.setAgentDetailVisibility(true);
		} else {
			let detailWasOpen;
			let agentListSelections;
			this.agentDataService.agentDetailVisible.pipe(take(1)).subscribe(x => detailWasOpen = x)
			this.agentDataService.agentListSelections.pipe(take(1)).subscribe(x => agentListSelections = x)
			if (detailWasOpen && (agentListSelections && agentListSelections.length)) {
				this.exportReport.setAgents(agentListSelections);
			}
			// Set observable to indicate that the agent detail panel is visible
			this.agentDataService.setAgentDetailVisibility(false);
		}
		return xor;
	}

	onPeriodChangeFromAgentDetail(data: { year: number, month: number }): void {
		this.periodFromAgentDetail = data;
	}

	onRequestCalculation(data: {
		detailsFor: string,
		detailData: ReportDataType,
		detailDataMinusOne: ReportDataType,
		detailDataMinusTwo: ReportDataType,
		awaitingDetails: boolean,
		planInfo: TableAssignments[],
		chosenYearAdnA: number,
		year: number,
		month: number,
		agentStartDate: number
	}): void {
		this.openDetailDialog = true;
		this.showDetailsFor = data.detailsFor;
		this.showDetailData = data.detailData;
		this.showDetailDataMinusOne = data.detailDataMinusOne;
		this.showDetailDataMinusTwo = data.detailDataMinusTwo;
		this.showAwaitingDetails = data.awaitingDetails;
		this.showDetailPlanInfo = data.planInfo;
		this.showChosenYearAdnA = data.chosenYearAdnA;
		this.showChosenYear = data.year;
		this.showChosenMonth = data.month;
		this.showAgentStartDate = data.agentStartDate;
	}

	onCalculationDialogClosed() {
		this.openDetailDialog = false;
		this.showDetailsFor = '';
	}

	onReportDialogClosed() {
		this.exportReport.setDisplayPrintOptions(false);
	}

	// TODO: Messages can be triggered from anywhere using the service.
	// This is likely going to be called after checking certain parameters,
	// which are yet to be defined. This is currently getting triggered on several routes,
	// for demonstration purposes. In production new messages will be rendered based on the data
	// being pulled from the database.
	triggerMessage() {
		// this.messageService.setMessages(this.messages);
	}

	// This determines the view to display in the center region
	selectGridView() {
		this.activatedRoute.data
			.subscribe((data: { grid: string }) => {
				this.gridToDisplay = data.grid;
			});
	}
}
