import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Paths } from '../../app.routing.enums';
import { PeriodService } from '../../services/period.service';
import { TableDataService } from '@services/table-data.service';
import { Subscription } from 'rxjs';
import { ApiService, Plan, Territory, AdnA, MinPremium } from '../../services/api.service';
import { ErrorService } from '../../services/error.service';
import { ConfirmationService } from 'primeng/api';

@Component({
	selector: 'app-plan-list',
	templateUrl: './plan-list.component.html',
	styleUrls: ['./plan-list.component.css']
})
export class PlanListComponent implements OnInit {
	public periodFilter: FormGroup;
	public periodCustomYears: { label: string, value: number }[];

	// Local instances of the path enums
	public plansPath: string;
	public viewPath: string;

	// Plan data
	public planList: Plan[] = [];
	public volumeLossDropdown: { label: string, value: number }[];
	public growthDropdown: { label: string, value: number }[];
	public profitabilityDropdown: { label: string, value: number }[];

	private volumeLossListSubscription: Subscription;
	private growthListSubscription: Subscription;
	private profitabilityListSubscription: Subscription;

	// Plan form
	public planInfo;
	public planInUse : boolean = false;
	public createPlanDialog: boolean = false;
	public createPlanForm: FormGroup;
	public formValidity: boolean = true;
	public formInvalidReason: ('empty' | 'network' | '') = '';
	public lockPlan: boolean = false;
	public plandIdToDisable: number = 0;

	// Territory form
	public territories: { id?: number, plan?: string, name: string, planId?: number, personalLines?: boolean }[];
	public territoryForm: FormGroup;
	public territoryFormReady: boolean = false;
	public territoryFormEditable: boolean = false;
	public chosenYear: number = this.periodService.currentYear;
	public planListDropdown: { label: string, value: number }[] = [];

	// Adn A form
	public adnAForm: FormGroup;
	public adnAFormReady: boolean = false;
	public adnAList: AdnA[] = [];
	public editingAdnA: boolean = false;
	public editingAdnARow: number = null;
	public newAdnA: AdnA | null = null;

	constructor(
		public periodService: PeriodService,
		public tableDataService: TableDataService,
		private apiService: ApiService,
		private router: Router,
		private errorService: ErrorService,
		private confirmationService: ConfirmationService
	) { }

	async ngOnInit() {
		// Initialize the local instances of the path enums
		this.plansPath = `/${Paths.plans}`;
		this.viewPath = Paths.view;

		// Only grab 10 years
		this.periodCustomYears = this.periodService.years.filter((v, i) => {
			if (i < 9) return true
		})

		// Create the form for the marketing territory year month filter
		this.periodFilter = new FormGroup({
			year: new FormControl(this.periodCustomYears[1]),
			month: new FormControl(this.periodService.months[this.periodService.currentMonth])
		});

		// Subscribe to changes to the volume-loss table data.
		// When we retrieve the data from the API this will listen for data changes.
		this.volumeLossListSubscription = this.tableDataService.volumeLossList.subscribe(data => {
			if (!data.length) this.volumeLossDropdown = [];
			if (data.length) this.volumeLossDropdown = data.filter(x => x.TableStatus === 2).map(x => {return { label: x.Name, value: x.Id }});
		});

		// Subscribe to changes to the growth table data.
		// When we retrieve the data from the API this will listen for data changes.
		this.growthListSubscription = this.tableDataService.growthList.subscribe(data => {
			if (!data.length) this.growthDropdown = [];
			if (data.length) this.growthDropdown = data.filter(x => x.TableStatus === 2).map(x => {return { label: x.Name, value: x.Id }});
		});

		// Subscribe to changes to the profitability table data.
		// When we retrieve the data from the API this will listen for data changes.
		this.profitabilityListSubscription = this.tableDataService.profitabilityList.subscribe(data => {
			if (!data.length) this.profitabilityDropdown = [];
			if (data.length) this.profitabilityDropdown = data.filter(x => x.TableStatus === 2).map(x => {return { label: x.Name, value: x.Id }});
		});

		// Call function to build the form for plan creation
		this.buildPlanForm();

		// Call all API methods to retrieve table data
		await this.apiService.getVolumeLossTables();
		await this.apiService.getGrowthTables();
		await this.apiService.getProfitabilityTables();

		// Grab all plans
		this.planList = await this.apiService.getAllPlans();

		// Only display current plans
		this.planList = this.planList.filter(x => { return (x.StartYear <= this.periodService.currentYear) && (x.EndYear >= this.periodService.currentYear) });


		// Iterate over all plans
		this.planList.map(async plan => {
			// Add all plans to a dropdown for the marketing territory form
			if (plan && !plan.DisablePlan) {
				this.planListDropdown.push({ label: plan.PlanName, value: plan.PlanId });
			}
			// For current plan, add each table type to its corresponding column/field in the UI table
			if (plan.ThreeYearProfitabilityReferenceId) {
				const profitabilityAssignment = await this.apiService.getTable(plan.ThreeYearProfitabilityReferenceId);
				plan.ThreeYearProfitabilityReferenceName = profitabilityAssignment.Name;
			}
			if (plan.PremiumVolumeLossRatioReferenceId) {
				const volumeLossAssignment = await this.apiService.getTable(plan.PremiumVolumeLossRatioReferenceId);
				plan.PremiumVolumeLossRatioReferenceName = volumeLossAssignment.Name;
			}
			if (plan.ProfitGrowthFactorsReferenceId) {
				const growthAssignment = await this.apiService.getTable(plan.ProfitGrowthFactorsReferenceId);
				plan.ProfitGrowthFactorsReferenceName = growthAssignment.Name;
			}
			// Grab the min premium by passing in the plan id to the min premium endpoint
			if (plan.PlanId) {
				const minPremiums = await this.apiService.getAllMinPremiumsForPlan(plan.PlanId);
				// Instantiate some variables to keep track of the most recent min premium (and start year)
				let startYear;
				let currentPremium;
				// Iterate over all min premiums associated with this plan
				minPremiums.map(obj => {
					// If there is no min premium then return
					if (!obj.Premium) return;
					// If currentPremium is null, set currentPremium to the current iteration's Premium property
					// If currentPremium is truthy, and startYear is null, set currentPremium to the current iteration's Premium property
					// If currentPremium is truthy, and startYear less than the current iteration's StartYear, set currentPremium to the current iteration's Premium property
					if (!currentPremium || (currentPremium && (!startYear || (startYear && startYear < obj.StartYear)))) {
						currentPremium = obj.Premium;
					}
				})
				// If a min premium was found then set it to the current plan's min premium property
				if (currentPremium) plan.MinPremium = currentPremium;
			}
		})

		// Marketing Territory setup
		this.periodChanges();
		this.loadTerritories(this.periodService.currentYear);

		// Addendum A setup
		this.adnAList = await this.apiService.getAllAdnA();
		this.adnAList.sort((a: AdnA, b: AdnA) => (a.StartYear < b.StartYear) ? 1 : -1);
		this.buildAdnAForm();
	}

	ngOnDestroy() {
		if (this.volumeLossListSubscription) this.volumeLossListSubscription.unsubscribe();
		if (this.growthListSubscription) this.growthListSubscription.unsubscribe();
		if (this.profitabilityListSubscription) this.profitabilityListSubscription.unsubscribe();
	}

	showCreatePlanDialog() {
        this.createPlanDialog = true;
	}
	
	buildPlanForm() {
		this.createPlanForm = new FormGroup({
			planName: new FormControl('', [Validators.required]),
			volumeLoss: new FormControl('', [Validators.required]),
			growth: new FormControl('', [Validators.required]),
			profitability: new FormControl('', [Validators.required]),
			minPremium: new FormControl('', [Validators.required])
		});
	}

	async confirm(rowData) {
		this.confirmationService.confirm({
			message: "Are you sure you want to delete the plan - " + rowData.PlanName + " ?",
			icon : 'pi pi-info-circle',
			accept: async () => {
				this.plandIdToDisable = rowData.PlanId;
				this.planInUse = await this.apiService.deletePlan(rowData.PlanId);
				if (!this.planInUse)					
					this.reloadComponent();
			},
			reject: () => {
				return;
			}
		});
	}	

	async disablePlan() {
		await this.apiService.enableDisablePlan(this.plandIdToDisable, 1);
		this.reloadComponent();
	}

	async enablePlan(rowData) {
		await this.apiService.enableDisablePlan(rowData.PlanId, 0);
		this.reloadComponent();
	}

	reloadComponent() {
		let currentUrl = this.router.url;
		this.router.routeReuseStrategy.shouldReuseRoute = () => false;
		this.router.onSameUrlNavigation = 'reload';
		this.router.navigate([currentUrl]);
	}

	async handlePlanSubmit(e) {
		if (!this.createPlanForm.invalid) {
			this.formValidity = true;
			this.formInvalidReason = '';
			let sendPlanDataResult;
			let sendMinPremiumDataResult;
			let planRequestBody: Plan;
			let minPremiumRequestBody: MinPremium;

			try {
				// Build request body for new plan
				planRequestBody = {
					"PlanName": this.createPlanForm.get('planName').value,
					"StartYear": this.periodService.currentYear,
					"EndYear": 9999,
					"MinPremium": this.createPlanForm.get('minPremium').value,
					"ThreeYearProfitabilityReferenceId": this.createPlanForm.get('profitability').value.value,
					"ProfitGrowthFactorsReferenceId": this.createPlanForm.get('growth').value.value,
					"PremiumVolumeLossRatioReferenceId": this.createPlanForm.get('volumeLoss').value.value,
					"DisablePlan": 0
				}

				// Send request to create new plan
				sendPlanDataResult = await this.apiService.setPlan(planRequestBody);

				// Build request for new min premium
				minPremiumRequestBody = {
					"PlanInformation": {
						"Id": sendPlanDataResult.Id,
						"PlanName": this.createPlanForm.get('planName').value
					},
					"Premium": this.createPlanForm.get('minPremium').value,
					"StartYear": this.periodService.currentYear,
					"EndYear": 9999
				}

				// Send request to create new min premium
				sendMinPremiumDataResult = await this.apiService.addMinPremiumToPlan(minPremiumRequestBody);

				// If both requests are successful navigate to single plan view
				if (sendPlanDataResult && sendMinPremiumDataResult) this.router.navigate([this.plansPath, this.viewPath, this.createPlanForm.get('planName').value, sendPlanDataResult.Id]);
			} catch (e) {
				this.formValidity = false;
				this.formInvalidReason = 'network';
			}
		} else if (this.createPlanForm.invalid) {
			this.formValidity = false;
			this.formInvalidReason = 'empty';
		}
	}

	handlePlanInUseDialogClose() {		
		this.planInUse = false;
	}

	handlePlanDialogClose() {
		this.createPlanForm.reset();
	}

	viewPlan(data) {
		this.router.navigate([this.plansPath, this.viewPath, data.PlanName, data.PlanId]);
	}

	toggleTerritoryEdit(editable) {
		if (!editable) {
			this.territories.filter(territory => {
				return (
					this.territoryForm.controls[territory.name + '_plan'].touched === true
					|| this.territoryForm.controls[territory.name + '_personalLines'].touched === true
				)
			}).map(async territory => {
				if (territory.id && territory.plan && territory.planId
				|| (territory.id && (!territory.plan || territory.planId))) {
					await this.apiService.updateTerritoryForYear({
						Id: territory.id,
						MarketingTerritory: territory.name,
						PlanInformationId: this.territoryForm.controls[territory.name + '_plan'].value.value,
						EffectiveYear: this.chosenYear,
						IncludePersonalLines: this.territoryForm.controls[territory.name + '_personalLines'].value
					})
				} else {
					await this.apiService.addPlanToTerritory({
						MarketingTerritory: territory.name,
						PlanInformation: {
							Id: this.territoryForm.controls[territory.name + '_plan'].value.value,
							PlanName: this.territoryForm.controls[territory.name + '_plan'].value.label
						},
						EffectiveYear: this.chosenYear,
						IncludePersonalLines: this.territoryForm.controls[territory.name + '_personalLines'].value
					})
				}
			})
		}
		this.loadTerritories(this.chosenYear);
		this.territoryFormEditable = editable;
	}

	// Grab all territories, then check if each territory has been assigned a plan
	async loadTerritories(year) {
		if (!year) year = this.periodService.currentYear;

		const territoryReponse = await this.apiService.getAllTerritories();
		const yearInclusion: Territory[] = await this.apiService.getTerritoriesByYear(year);

		this.territories = territoryReponse.map((territory: string) => {
			const inclusionExists = yearInclusion.filter((explicitEntry: Territory) => {
				if (explicitEntry.MarketingTerritory === territory) return true;
			})
			if (inclusionExists.length) {
				return {
					id: inclusionExists[0].Id,
					plan: inclusionExists[0].PlanInformation
						&& inclusionExists[0].PlanInformation.PlanName
						? inclusionExists[0].PlanInformation.PlanName
						: null,
					name: territory,
					planId: inclusionExists[0].PlanInformation
						&& inclusionExists[0].PlanInformation.Id
						? inclusionExists[0].PlanInformation.Id
						: null,
					personalLines: inclusionExists[0].IncludePersonalLines === true
						? true
						: false
				};
			} else {
				return {
					id: null,
					plan: null,
					name: territory,
					planId: null,
					personalLines: null
				};
			}
		});

		this.buildTerritoryForm();
	}

	// Assign default values to each marketing territory form
	buildTerritoryForm() {
		const controlObject = {}
		this.territories.map((v, i) => {
			const planFormControl = new FormControl(
				{
					label: v.plan
						? v.plan
						: this.planListDropdown.length
						? this.planListDropdown[0].label
						: '',
					value: v.planId
						? v.planId
						: this.planListDropdown.length
						? this.planListDropdown[0].value
						: ''
				})

			const personalLinesFormControl = new FormControl(v.personalLines === true ? v.personalLines : false)

			controlObject[`${v.name}_plan`] = planFormControl;
			controlObject[`${v.name}_personalLines`] = personalLinesFormControl;
		})
		this.territoryForm = new FormGroup(controlObject);
		this.territoryFormReady = true;
	}

	// Subscribe to changes to the period dropdown
	periodChanges(): void {
		this.periodFilter.valueChanges.subscribe(val => {
			this.chosenYear = val.year.value;
			this.loadTerritories(val.year.value);
		});
	}

	// Blank form to start with. Will be populated with default values elsewhere.
	buildAdnAForm() {
		this.adnAForm = new FormGroup({
			value: new FormControl(),
			startDate: new FormControl(),
			endDate: new FormControl()
		});
		this.adnAFormReady = true;
	}

	// Initialize Adn A form to be editable and to have default values
	initAdnA(index: number, newAdnA: boolean) {
		if (newAdnA) {
			this.editingAdnA = true;
			this.editingAdnARow = 0;
			const rowData = this.newAdnA;
			this.populateAdnAForm(rowData);
		} else {
			this.editingAdnA = true;
			this.editingAdnARow = index;
			const rowData = this.adnAList[index];
			this.populateAdnAForm(rowData);
		}
	}

	// Assign default values for Adn A form
	populateAdnAForm(rowData) {
		this.adnAForm = new FormGroup({
			value: new FormControl(rowData.Value ? rowData.Value : null, Validators.required),
			startDate: new FormControl(rowData.StartYear ? rowData.StartYear : this.periodService.currentYear, Validators.required),
			endDate: new FormControl(rowData.EndYear ? rowData.EndYear : 9999, Validators.required)
		});
	}

	// Remove form from UI
	cancelAdnA(index: number, newAdnA: boolean) {
		this.editingAdnA = false;
		if (newAdnA) {
			this.newAdnA = null;
			this.adnAList.shift();
		}
	}

	// Send data to back-end
	async saveAdnA(index: number, newAdnA: boolean) {
		this.editingAdnA = false;
		let sendDataResult;
		let requestBody: AdnA;
		
		// If user tried to submit blank endDate field, set it to 9999
		if (!this.adnAForm.get('endDate').value
			&& this.adnAForm.get('endDate').value !== 9999) {
			this.adnAForm.get('endDate').setValue(9999);
		}

		try {
			if (this.adnAForm.invalid) {
				// Blank fields
				throw 'No fields should be left blank';
			} else if (newAdnA
				&& (this.adnAForm.get('endDate').value !== 9999)
				&& (this.adnAForm.get('startDate').value > this.adnAForm.get('endDate').value)) {
				// New Adn A has explicit end year, and the start year is greater than the end year.
				// This is legacy from when end years were allow to be set by the FE.
				this.cancelAdnA(0, newAdnA)
				throw 'End year must be greater than start year';
			} else if (!newAdnA
				&& (this.adnAForm.get('endDate').value !== 9999)
				&& (this.adnAForm.get('startDate').value > this.adnAForm.get('endDate').value)) {
				// Existing Adn A has explicit end year, but the start year is greater than the end year
				this.cancelAdnA(index, newAdnA)
				throw 'End year must be greater than start year';
			} else if (newAdnA
				&& this.adnAList[1]
				&& (this.adnAList[1].EndYear !== 9999)
				&& (this.adnAForm.get('startDate').value <= this.adnAList[1].EndYear)) {
				// Previous row has explicit end year, and start year of new Adn A is not greater than previous row's end year
				this.cancelAdnA(0, newAdnA)
				throw 'Start year must be greater than previous Addendum A\'s end year'
			} else if (newAdnA
				&& this.adnAList[1]
				&& (this.adnAForm.get('startDate').value <= this.adnAList[1].StartYear)) {
				// Previous row's start year is greater than the start year of the new Adn A
				this.cancelAdnA(0, newAdnA);
				throw 'Start year must be greater than previous Addendum A\'s start year';
			} else if (!newAdnA
				&& this.adnAList[index + 1]
				&& (this.adnAForm.get('startDate').value <= this.adnAList[index + 1].StartYear)) {
				// Current row start date needs to be greater than previous row's start date
				this.cancelAdnA(0, newAdnA);
				throw 'Start year must be greater than previous Addendum A\'s start year';
			} else if (!newAdnA
				&& this.adnAList[index + 1]
				&& (this.adnAList[index + 1].EndYear !== 9999)
				&& (this.adnAForm.get('startDate').value <= this.adnAList[index + 1].EndYear)) {
				// Previous row has an explicit end year, and start year of the current row is not greater than previous row's end year
				this.cancelAdnA(0, newAdnA);
				throw 'Start year must be greater than previous Addendum A\'s end year';
			}

			// Build request body
			requestBody = {
				"Value": this.adnAForm.get('value').value,
				"StartYear": this.adnAForm.get('startDate').value,
				"EndYear": this.adnAForm.get('endDate').value
			}

			// Grab the actual index of the existing Adn A if not a new Adn A
			if (!newAdnA) requestBody.Id = this.adnAList[index].Id;

			sendDataResult = newAdnA
				? await this.apiService.addAdnA(requestBody)
				: await this.apiService.updateAdnA(requestBody);

			if (sendDataResult) {
				// If previous Adn A's end year is greater than start year of row we are updating,
				// set previous end year to (start year - 1)
				if (this.adnAList[index + 1] // Previous Adn A row exists
				&& this.adnAForm.get('startDate').value > this.adnAList[index + 1].StartYear) { // Editing row's start date is greater than previous rows start date
					this.adnAList[index + 1].EndYear = (this.adnAForm.get('startDate').value - 1); // Set the previous end year to 1 year less than editing row's start year
					await this.apiService.updateAdnA(this.adnAList[index + 1]);
				}
			}

			this.adnAList = await this.apiService.getAllAdnA();
			this.adnAList = this.adnAList.sort((a: AdnA, b: AdnA) => (a.StartYear < b.StartYear) ? 1 : -1);
			this.newAdnA = null;
		} catch (e) {
			this.newAdnA = null;
			this.errorService.setError({
				error: new Error(e),
				message: e,
				title: 'Update Addendum A Error',
				dialog: true
			});
		}
	}

	addAdnA() {
		// TODO: If pagination is anything other than 1 new row won't be visible
		if (this.newAdnA) return;
		this.newAdnA = {
			StartYear: this.adnAList[0] && this.adnAList[0].EndYear && this.adnAList[0].EndYear !== 9999 // If previous Adn A's end year is not 9999
				? (this.adnAList[0].EndYear + 1)
				: this.adnAList[0] && this.adnAList[0].EndYear === 9999 // If previous Adn A's end year is 9999
				? this.adnAList[0].StartYear + 1 // Add one year to the previous Adn A's start year
				: null,
			EndYear: 9999,
			Value: 1
		}

		this.adnAList.unshift(this.newAdnA)
		this.initAdnA(0, true)
	}
}
