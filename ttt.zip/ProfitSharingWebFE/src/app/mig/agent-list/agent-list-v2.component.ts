import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { TreeNode } from 'primeng/api';
import { FilterService } from '@services/filter.service';
import { PeriodService } from '@services/period.service';
import { ApiService } from '@services/api.service';
import { AgentDataService } from '@services/agent-data.service';
import { FormControl, FormGroup } from '@angular/forms';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { AgentListPaged } from '@root/mig/A-Models/AgentListPaged';
import { DistinctAgencies } from '../A-Models/DistinctAgencies';
import  * as _ from 'lodash'; 

import { TreeTable } from 'primeng/treetable';

import { Table } from 'primeng/table';
import { PagingInfo } from '../A-Models/PagingInfo';
import {DialogModule} from 'primeng/dialog';
@Component({
	selector: 'app-agent-list-v2',
	templateUrl: './agent-list-v2.component.html',
	styleUrls: ['./agent-list.component.scss']
})

export class AgentListComponentV2 implements OnInit{
	
	public agentListPaged: AgentListPaged;
	
	filterCriteria: FormGroup;
	public singleAgentSearch: string = "";
	
	periodFilter: FormGroup;


	public IsAgentFiltered: boolean = false;
	periodCustomYears: {label: string, value: number}[];

	public display: boolean = true;

	public totalRecordCount = 0;

	//selectedValues: string[] = [];

	selectedRows: TreeNode[] = [];
	masterAgentIds: string[] = [];
	public currentPage: number = 0;

	data: TreeNode[] = [];
	cols: any[];
	territoryOptions: {label: string, value: string}[];

	@Output() showAgentDetailPanel: EventEmitter<{page: number, chosenYear: number, chosenMonth: number, parent: any, agent: any}> = new EventEmitter();
	@Output() showCombinedReportPanel: EventEmitter<{agentList: any, chosenYear: number, chosenMonth: number}> = new EventEmitter();

	
	sales: TreeNode[];
	public first: number = 0;
	showPaginator: boolean;

	constructor(private agentDataService: AgentDataService,
		       public periodService: PeriodService,
			   private filterService: FilterService,
			   public apiService: ApiService,){}
    async ngOnInit() {

		this.agentListPaged = new AgentListPaged();
		this.agentListPaged.PagingInformation.TotalResults = 0;

		this.display = true;

		this.periodCustomYears = this.periodService.years.filter((v, i) => {
			if (i !== 0) return true
		});

		//this.QuoteInformationFormGroup.addControl("BUSDSC", new FormControl(this.quote.POLICYTRANS.BUSDSC));
		this.filterCriteria = new FormGroup({
			agentSearch: new FormControl(this.singleAgentSearch),
			markettingTerritories: new FormControl(''),
			addendumA: new FormControl(false),
			addendumC: new FormControl(false)
		});
		
		this.filterCriteria.get('agentSearch').valueChanges.pipe(debounceTime(500),distinctUntilChanged()).subscribe(value=>{
			this.singleAgentSearch = value as string;
			this.getAgent();
		});

		// Setting up territory dropdown
		const territories =  await this.apiService.getAllTerritories();
		territories.sort();

		this.territoryOptions = territories.map(ter => {
			return { label: ter, value: ter }
		});
		this.territoryOptions.unshift({ label: 'None', value: null });

		this.periodFilter = new FormGroup({
			year: new FormControl(this.periodService.years.filter(x => x.value === this.periodService.currentYear)[0]),
			month: new FormControl(this.periodService.months[this.periodService.currentMonth === 0 ? 11 : (this.periodService.currentMonth - 1)])
		});
		

		this.cols = [
			{ field: 'AgentNumber', header: 'Agent Number' },
			{ field: 'AgencyName', header: 'Agency Name' }
		];

		// this.agentListPaged = new AgentListPaged();
		// this.agentListPaged.PagingInformation.PageSize = 10;
		
		// this.agentDataService.getPagedAgents2(this.agentListPaged).subscribe(agents => {
		 
		// 	this.agentListPaged.PagingInformation = agents.PagingInformation;
		// 	this.agentListPaged.data = agents.data;
		// 	this.IsAgentFiltered = false;
		// 	console.log("agent data");
		// 	console.log(JSON.stringify(this.agentListPaged.data));
		// });

		this.getPagedAgents();
		this.agentDataService.getAllMasterAgents().subscribe(agents =>{
			agents.forEach(x=>{
				//get all our master agent ids and push them to our array, while trimming excess space
				this.masterAgentIds.push(x.trim())
				
			});
			// console.log("this.masterAgentsS: ", this.masterAgentIds)
		});

		if(this.data.length === 0){
			this.agentDataService.getAllAgents().subscribe(agents => {
				let agentData : any = agents;

				// console.log("agents: ", agentData.data);
				// this.data = agentData.data;
				this.data = _.filter(agentData.data, (Entry) => {	// agentData.data has all of our agent ids. We want to filter out all agents that are not Master agents. 
					return _.includes(this.masterAgentIds, Entry.data.AgentNumber);
				});
			
				// console.log('this.data =');
				// console.log(JSON.stringify(this.data));

			});
		}



		this.agentDataService.subscribeAgentList().subscribe((data) =>{
			
			//console.log('This agent list paged data in subscribe: ', data);
			//console.log(JSON.stringify(data));
			if(data.SingleAgent != ''){
				this.IsAgentFiltered = true;
			}
			this.agentListPaged = data;
			
		});
    }

	loadCustomers($event) {
		let k : number = 0;
		console.log('lazy load');
	}

	showDialog() {

		
        if(this.display === false){
			
			this.display = true;
			//this.data = [];
			this.selectedRows = [];
			this.periodFilter.reset();
			this.periodFilter.get('year').setValue(this.periodService.years.filter(x => x.value === this.periodService.currentYear)[0]);
			this.periodFilter.get('month').setValue(this.periodService.months[this.periodService.currentMonth === 0 ? 11 : (this.periodService.currentMonth - 1)]);

		}
		else {
			this.display = false;
			//agents already received
			if(this.data.length === 0){
					this.agentDataService.getAllAgents().subscribe(agents => {
						let agentData : any = agents;
						this.data = agentData.data;
						//console.log('this.data =');
						//console.log(JSON.stringify(this.data));

			});
			
		}
		// console.log("AGENTS: ", this.data);
		// console.log("agentPaged: ", this.agentListPaged)
		let obj = new Object({first: 0, rows: 50 });
		this.paginate(obj);
	}
}

	paginate(event) {
		// console.log("event: ", event);
		this.currentPage = event.first / event.rows
		this.first = event.rows * this.currentPage
		this.agentListPaged.PagingInformation.PageSize = event.rows;
		// console.log("currentPage: ", this.currentPage)
		this.agentListPaged.PagingInformation.CurrentPage = this.currentPage;
			if(this.agentListPaged.data){
				this.agentListPaged.data.forEach(agent=> {
					if(agent.children){
						agent.children.forEach(child=> {
							child.parent = {}; // clear out the parent object from the child, as leaving the parent object there creates a circular structure which cannot be "stringified". 
						})
					}
				})
			}
		this.agentDataService.getPagedAgents2(this.agentListPaged).subscribe(agents => {
			this.agentListPaged.data = agents.data;
			// console.log("DATA: ", this.agentListPaged.data)
		});

    }

	showAgentDetail(agentData: any) {

		//console.log("show agent detail");
		let parent = null;	
		let selectedYear: number = this.periodFilter.get('year').value.value;
		let selectedMonth: number = this.periodFilter.get('month').value.value + 1;
		// Open single agent detail fly-out
		this.showAgentDetailPanel.emit({ page: this.agentListPaged.PagingInformation.CurrentPage, chosenYear: selectedYear, chosenMonth: selectedMonth, parent, agent: agentData });
		//this.showAgentDetailPanel.emit({page: this.page, chosenYear: this.chosenYear, chosenMonth: this.chosenMonth, parent, agent: agentData});
	}

	showCombinedReport() {
		/*if (!this.chosenYear) return;*/
		// Open combined report fly-out to view the multiple
		// agents that have been selected.
		/*console.log("showCombinedReport " + agentList)*/
		//this.showCombinedReportPanel.emit({ agentList: [], chosenYear: 2021, chosenMonth: 4 });

		if (this.selectedRows.length > 0) {

			let selectedAgents: string[] = [];
			let selectedYear: number = this.periodFilter.get('year').value.value;
			let selectedMonth: number = this.periodFilter.get('month').value.value + 1;

			let j: number = 0;

			// this.selectedRows.forEach(agent=>{
			// 	//selectedAgents.push(agent.data.AgentNumber);
			// 	selectedAgents.push(agent.data.AgentNumber + '-' + agent.data.AgencyName);
			// })

			//this.showCombinedReportPanel.emit({agentList: selectedAgents, chosenYear: selectedYear, chosenMonth: selectedMonth})
			this.showCombinedReportPanel.emit({ agentList: this.selectedRows, chosenYear: selectedYear, chosenMonth: selectedMonth })
		}
	}

	removeFilter() {
		//this.agentListPaged.PagingInformation.CurrentPage = 0;
		this.IsAgentFiltered = false;
		this.filterCriteria.get('agentSearch').setValue("");
		this.getPagedAgents();
		this.agentDataService.setClearSearchInput(true);
		
	}

	getPagedAgents() {


			this.agentListPaged = new AgentListPaged();
			
			this.agentListPaged.PagingInformation.PageSize = 10;
			
			this.agentDataService.getPagedAgents2(this.agentListPaged).subscribe(agents => {
				this.agentListPaged.PagingInformation = agents.PagingInformation;
				this.agentListPaged.data = agents.data;
				this.IsAgentFiltered = false;
				this.totalRecordCount = this.agentListPaged.PagingInformation.TotalResults;
			});
			this.agentDataService.setClearSearchInput(true);
	}

	
	getAgent(){
		
		//this.agentDataService.findAgent(this.singleAgentSearch);

		this.agentDataService.findAgent(this.singleAgentSearch).subscribe(agentListedPaged=> {
			//console.log('getAgentLog ' + JSON.stringify(agentListedPaged));
			this.agentDataService.setAgentListPaged(agentListedPaged);
			//console.log('total result count ' + agentListedPaged.PagingInformation.TotalResults);
			this.totalRecordCount = agentListedPaged.PagingInformation.TotalResults;
			
		});
		
		
	}



	onAgentCheck(agent) {

		let i = 0;
		console.log('log');

	}
	nodeSelect(event) {
		let i = 0;
		console.log('log');
    }

    nodeUnselect(event) {
        let i = 0;
		console.log('log');
    }

	clearFilters(): void {
		this.filterCriteria.reset();
	}

	runReport(): void {
		this.filterService.requestReport(true);
	}

	
}
export class TableData {
	
	public data : DistinctAgencies;
	constructor () {
		this.data = new DistinctAgencies();
	}
}


