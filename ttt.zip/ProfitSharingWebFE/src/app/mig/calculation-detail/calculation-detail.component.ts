import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { TableAssignments } from '@services/api.service';
import { PeriodService } from '@services/period.service';
import { Paths } from '../../app.routing.enums';

export interface ReportDataType {
	AdjustedEarnedPremiums: number | null,
	AdjustedWrittenPremium: number | null,
	ChargeOffsAndWC: number | null,
	EarnedPremiums: number | null,
	GrowthRate: number | null,
	IncurredLossesAfterStopLoss: number | null,
	IncurredLossesBeforeStopLoss: number | null,
	LossAdjustmentExpense: number | null,
	LossRatio: number | null,
	NetAdjustedEarnedPremiums: number | null,
	NetAdjustedPremiums: number | null,
	NineMonthLossLock: number | null,
	PremiumGrowthFactor: number | null,
	PremiumVolumeAndLossRatioFactor: number | null,
	PreviousYearNetAdjustedWrittenPremiums: number | null,
	ProductId: string | null,
	ProfitSharingPayment: number | null,
	ThreeYearProfitability: number | null,
	ThreeYearProfitabilityFactor: number | null,
	WrittenPremiumVolume: number | null
}

@Component({
	selector: 'app-calculation-detail',
	templateUrl: './calculation-detail.component.html',
	styleUrls: ['./calculation-detail.component.css']
})
export class CalculationDetailComponent implements OnInit {

	private _displayDialog: boolean;
	private _detailsFor: string;
	private _detailData: ReportDataType;
	private _detailDataMinusOne: ReportDataType;
	private _detailDataMinusTwo: ReportDataType;
	private _detailPlanInfo: TableAssignments[];
	private _currentVolumeLossTableId: number;
	private _currentVolumeLossTableName: string;
	private _currentProfitabilityTableId: number;
	private _currentProfitabilityTableName: string;
	private _currentGrowthTableId: number;
	private _currentGrowthTableName: string;
	private _chosenYearAdnA: number;
	private _detailYear: number;
	private _detailMonth: number;
	private _agentStartYear: number;
	private _agentStartMonth: number;
	private _awaitingDetails: boolean;

	// Local instances of the path enums
	public tablesPath: string;
	public viewPath: string;
	public profitabilityPath: string;
	public growthPath: string;
	public volumeLossPath: string;
	
	@Input()
	set displayDialog(shouldDisplay: boolean) {
		this._displayDialog = shouldDisplay;
	}
	get displayDialog(): boolean { return this._displayDialog; }
	
	@Input()
	set detailsFor(dataType: string) {
		this._detailsFor = dataType;
	}
	get detailsFor(): string { return this._detailsFor; };

	@Input()
	set detailData(data: ReportDataType) {
		this._detailData = data;
	}
	get detailData(): ReportDataType { return this._detailData; };

	@Input()
	set detailDataMinusOne(data: ReportDataType) {
		this._detailDataMinusOne = data;
	}
	get detailDataMinusOne(): ReportDataType { return this._detailDataMinusOne; };

	@Input()
	set detailDataMinusTwo(data: ReportDataType) {
		this._detailDataMinusTwo = data;
	}
	get detailDataMinusTwo(): ReportDataType { return this._detailDataMinusTwo; };

	@Input()
	set detailPlanInfo(planInfo: TableAssignments[]) {
		this._detailPlanInfo = planInfo;
		if (!planInfo || planInfo && !planInfo.length) return;
		// Select the volume loss ratio table id for the current plan's table assignment
		this._currentVolumeLossTableId = planInfo
			.filter(x => { return (x.StartYear <= this.periodService.currentYear) && (x.EndYear >= this.periodService.currentYear) })
			.map(x => x.PremiumVolumeLossRatioReference.Id)[0];
		// Select the volume loss ratio table name for the current plan's table assignment
		this._currentVolumeLossTableName = planInfo
			.filter(x => { return (x.StartYear <= this.periodService.currentYear) && (x.EndYear >= this.periodService.currentYear) })
			.map(x => x.PremiumVolumeLossRatioReference.Name)[0];
		// Select the 3 year profitability table id for the current plan's table assignment
		this._currentProfitabilityTableId = planInfo
			.filter(x => { return (x.StartYear <= this.periodService.currentYear) && (x.EndYear >= this.periodService.currentYear) })
			.map(x => x.ThreeYearProfitabilityReference.Id)[0];
		// Select the 3 year profitability table name for the current plan's table assignment
		this._currentProfitabilityTableName = planInfo
			.filter(x => { return (x.StartYear <= this.periodService.currentYear) && (x.EndYear >= this.periodService.currentYear) })
			.map(x => x.ThreeYearProfitabilityReference.Name)[0];
		// Select the growth factors table id for the current plan's table assignment
		this._currentGrowthTableId = planInfo
			.filter(x => { return (x.StartYear <= this.periodService.currentYear) && (x.EndYear >= this.periodService.currentYear) })
			.map(x => x.ProfitGrowthFactorsReference.Id)[0];
		// Select the growth factors table name for the current plan's table assignment
		this._currentGrowthTableName = planInfo
			.filter(x => { return (x.StartYear <= this.periodService.currentYear) && (x.EndYear >= this.periodService.currentYear) })
			.map(x => x.ProfitGrowthFactorsReference.Name)[0];
	}
	get detailPlanInfo(): TableAssignments[] { return this._detailPlanInfo; };
	
	get currentVolumeLossTableId(): number { return this._currentVolumeLossTableId; };
	get currentVolumeLossTableName(): string { return this._currentVolumeLossTableName; };

	get currentProfitabilityTableId(): number { return this._currentProfitabilityTableId; };
	get currentProfitabilityTableName(): string { return this._currentProfitabilityTableName; };

	get currentGrowthTableId(): number { return this._currentGrowthTableId; };
	get currentGrowthTableName(): string { return this._currentGrowthTableName; };

	@Input()
	set chosenYearAdnA(value: number) {
		this._chosenYearAdnA = value;
	}
	get chosenYearAdnA(): number { return this._chosenYearAdnA; };

	@Input()
	set detailYear(year: number) {
		this._detailYear = year;
	}
	get detailYear(): number { return this._detailYear; };

	@Input()
	set detailMonth(month: number) {
		this._detailMonth = month;
	}
	get detailMonth(): number { return this._detailMonth; };

	@Input()
	set agentStartDate(date: number) {
		if (!date || (date && date.toString().length !== 6)) return;
		this._agentStartYear = parseInt(date.toString().substring(0,4));
		this._agentStartMonth = parseInt(date.toString().substring(4,6));
	}
	get agentStartYear(): number { return this._agentStartYear; };
	get agentStartMonth(): number { return this._agentStartMonth; };

	@Input()
	set awaitingDetails(awaiting: boolean) {
		this._awaitingDetails = awaiting;
	}
	get awaitingDetails(): boolean { return this._awaitingDetails; };

	@Output() calculationDialogClosed = new EventEmitter();
	
	constructor(
		public periodService: PeriodService,
		public router: Router
	) { }

	ngOnInit() {
		// Initialize the local instances of the path enums
		this.tablesPath = `/${Paths.tables}`;
		this.viewPath = Paths.view;
		this.profitabilityPath = Paths.profitability;
		this.growthPath = Paths.growth;
		this.volumeLossPath = Paths.volume_loss;
	}

	onHideDialog() {
		this.displayDialog = false
		this.calculationDialogClosed.emit();
	}

	viewVolumeLossTable() {
		return `
			${this.tablesPath}/
			${this.viewPath}/
			${this.volumeLossPath}/
			${this.currentVolumeLossTableName}/
			${this.currentVolumeLossTableId}
		`;
	}

	viewProfitabilityTable() {
		return `
			${this.tablesPath}/
			${this.viewPath}/
			${this.profitabilityPath}/
			${this.currentProfitabilityTableName}/
			${this.currentProfitabilityTableId}
		`;
	}

	viewGrowthTable() {
		return `
			${this.tablesPath}/
			${this.viewPath}/
			${this.growthPath}/
			${this.currentGrowthTableName}/
			${this.currentGrowthTableId}
		`;
	}
}
