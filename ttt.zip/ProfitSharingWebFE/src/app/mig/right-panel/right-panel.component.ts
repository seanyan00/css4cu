import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { TabView } from 'primeng/tabview';
import { Subscription } from 'rxjs';
import { FormControl, FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { Router, NavigationEnd } from '@angular/router';
import { Paths } from '../../app.routing.enums';
import { PanelSections } from './panel-sections';
import { FilterService } from '../../services/filter.service';
import { ExportReportService } from '../../services/export-report.service';
import { ConvertCsvToJsonService } from '@services/convert-csv-to-json.service';
import { ErrorService } from '@services/error.service';
import { PeriodService } from '../../services/period.service';
import { ApiService } from '@services/api.service';
import { AgentDataService } from '@services/agent-data.service';
import { DebounceService } from '@services/debounce.service';
import { AgentListPaged } from '../A-Models/AgentListPaged';

@Component({
	selector: 'app-right-panel',
	templateUrl: './right-panel.component.html',
	styleUrls: ['./right-panel.component.css']
})
export class RightPanelComponent implements OnInit {
	dataFilter: FormGroup;
	emptyResultSubscription: Subscription;
	noResults: boolean = true;
	importPendingSubscription: Subscription;
	importPending: boolean = false;
	@Output() toggleRightPanel: EventEmitter<boolean> = new EventEmitter<boolean>();
	panelSections: PanelSections[];
	periodCustomYears: {label: string, value: number}[];
	routeSubscription: Subscription;
	currentRoute: string = this.router.url;
	paths = Paths;

	constructor(
		public router: Router,
		private filterService: FilterService,
		private exportReport: ExportReportService,
		public convertCSV: ConvertCsvToJsonService,
		private errorService: ErrorService,
		public periodService: PeriodService,
		public apiService: ApiService,
		public agentDataService: AgentDataService,
		public debounceService: DebounceService
	) {
	}

	async ngOnInit() {
		this.periodCustomYears = this.periodService.years.filter((v, i) => {
			if (i !== 0) return true
		});
		
		this.exportReport.setPeriod(this.periodCustomYears[0].value, this.periodService.months[this.periodService.currentMonth === 0 ? 11 : (this.periodService.currentMonth - 1)].value);

		// Grab all territories
		const territoryResponse = await this.apiService.getAllTerritories();

		// Sort all territories
		territoryResponse.sort();

		// Generate an options list from the territories
		const territoryOptions = territoryResponse.map(ter => {
			return { label: ter, value: ter }
		});

		// Add a 'None' option
		territoryOptions.unshift({ label: 'None', value: null });
		
		// Build out the sections of the right panel
		this.panelSections = [
			{
				heading: '',
				fields: [
					{
						key: 'input',
						formId: 'code',
						label: 'Agent/Master Code'
					},
					{
						key: 'button',
						button: {
							label: 'Go Get Agent',
							behavior: () => {
								this.getAgent();
								return;
							}
						}

					},
					{
						key: 'dropdown',
						formId: 'mktTerritory',
						placeholder: 'Marketing Territory',
						alignment: 'full',
						options: territoryOptions
					},
					{
						key: 'checkbox',
						formId: 'addendum',
						options: [
							{
								label: 'Addendum A',
								value: 'A'
							},
							{
								label: 'Addendum C',
								value: 'C'
							}
						]
					},
					{
						key: 'button',
						button: {
							label: 'Clear Filters',
							behavior: () => {
								this.clearFilters();
								return;
							}
						}
					}
				],
				display: (route) => {
					if (route == `/${Paths.agents}`) return true;
					return false;
				}
			},
			{
				heading: 'Addendum A Bulk Upload',
				fields: [
					{
						key: 'upload',
						description: '<a href="assets/sample_data/SAMPLE_Addendum_A_Bulk.xlsx" download><i>Download spreadsheet format</i></a>',
						upload: {
							label: 'Select File',
							multi: false,
							behavior: this.uploadAdnABulk
						}
					}
				],
				display: (route) => {
					if (route == `/${Paths.plans}`) return true;
					return false;
				}
			},
			{
				heading: 'Addendum C Bulk Upload',
				fields: [
					{
						key: 'upload',
						description: '<a href="assets/sample_data/SAMPLE_Addendum_C_Bulk.xlsx" download><i>Download spreadsheet format</i></a>',
						upload: {
							label: 'Select File',
							multi: false,
							behavior: this.uploadAdnCBulk
						}
					}
				],
				display: (route) => {
					if (route == `/${Paths.plans}`) return true;
					return false;
				}
			},
			{
				heading: 'Agent Qualification Closing',
				fields: [
					{
						key: 'button',
						description: '<p>Used to freeze the calculations for the profit sharing year and reset for the subsequent year.</p>',
						button: {
							label: 'Close',
							behavior: () => {
								// Placeholder TODO: Add action for freezing calculations
								return;
							}
						}
					}
				],
				display: (route) => {
					if (route == `/${Paths.plans}`) return true;
					return false;
				}
			},
			{
				heading: 'View Other Plans',
				fields: [
					{
						key: 'link',
						link: {
							label: 'Michigan and Ohio', // This may need to be dynamic
							icon: 'pi pi-angle-right',
							behavior: () => {
								// Placeholder TODO: Add action for clearing filters
								return;
							}
						}
					},
					{
						key: 'link',
						link: {
							label: 'All Other',
							icon: 'pi pi-angle-right',
							behavior: () => {
								// Placeholder TODO: Add action for clearing filters
								return;
							}
						}
					}
				],
				display: (route) => {
					if (route == `/${Paths.plans}/${Paths.view}`) return true;
					return false;
				}
			},
			{
				fields: [
					{
						key: 'link',
						link: {
							label: 'Return to all Plans', // This may need to be dynamic
							icon: 'pi pi-angle-right',
							behavior: () => {
								// Placeholder TODO: Add action for clearing filters
								return;
							}
						}
					}
				],
				display: (route) => {
					if (route == `/${Paths.plans}/${Paths.view}`) return true;
					return false;
				}
			},
			{
				heading: 'Update Qualifications',
				fields: [
					{
						key: 'button',
						description: '<p>Download the following spreadsheet and fill in the appropriate values to bulk update agent qualifications.</p><p><em>Download spreadsheet format</em></p>',
						button: {
							label: 'Select File',
							behavior: () => {
								// Placeholder TODO: Add action for bulk updating
								return;
							}
						}
					}
				],
				display: (route) => {
					if (route == `/${Paths.presidents}`) return true;
					return false;
				}
			},
			{
				heading: 'Period',
				fields: [
					{
						key: 'dropdown',
						formId: 'month',
						label: 'end',
						alignment: 'right',
						placeholder: 'Select a Month',
						options: this.periodService.months
					},
					{
						key: 'dropdown',
						formId: 'year',
						alignment: 'right',
						placeholder: 'Select a Year',
						options: this.periodCustomYears
					}
				],
				display: (route) => {
					if (route == `/${Paths.report_builder}`) return true;
					return false;
				}
			},
			{
				heading: 'Sorting/Grouping',
				fields: [
					{
						key: 'radio',
						formId: 'sorting',
						defaultValue: 'Default',
						options: [
							{
								label: 'Marketing Territory',
								value: 'Territory'
							},
							{
								label: 'Region',
								value: 'Region'
							},
							{
								label: 'Neither',
								value: 'Default'
							}
						]
					}
				],
				display: (route) => {
					if (route == `/${Paths.report_builder}`) return true;
					return false;
				}
			},
			{
				heading: 'Options',
				fields: [
					{
						key: 'checkbox',
						formId: 'nonPay',
						options: [
							{
								label: 'Include non-payment agents',
								value: 'include-non-payment-agents',
								defaultTrue: true
							}
						]
					}
				],
				display: (route) => {
					if (route == `/${Paths.report_builder}`) return true;
					return false;
				}
			},
			{
				heading: 'Re-Import WINS Data',
				fields: [
					{
						key: 'button',
						description: '<p>Will re-run regular import from WINS for data correction up until the end of the previous month.</p>',
						button:	{
							label: 'Import',
							behavior: async () => {
								this.agentDataService.setImportPending(true);
								await this.apiService.startImportProcess();
								this.agentDataService.setImportPending(false)
								return;
							},
							disabled: () => this.importPending
						}
					}
				],
				display: (route) => {
					// TODO: This is temporarily removed
					return false;
					// if (route == `/${Paths.system}`) return true;
					// return false;
				}
			},
			{
				heading: 'Import WC and C/O',
				fields: [
					{
						key: 'button',
						description: '<p>Import a spreadsheet of Workers Compensation Dividends and Charge Offs from finance.</p><p><em>Download spreadsheet format</em></p>',
						button:	{
							label: 'Select File',
							behavior: () => {
								// Placeholder TODO: Add action for importing WC and CO
								return;
							}
						}
					}
				],
				display: (route) => {
					// Placeholder TODO: add conditions under which this section should display.
					// Must return boolean
					return false;
				}
			},
			{
				heading: 'Combined Report',
				fields: [
					{
						key: 'button',
						button:	{
							label: 'Run Report',
							behavior: () => {
								this.filterService.requestReport(true);
								return;
							}
						}
					}
				],
				display: (route) => {
					if (route == `/${Paths.agents}`) return true;
					return false;
				}
			}
		];

		this.routeSubscription = this.router.events.subscribe(data => {
			if (data instanceof NavigationEnd === false) return;
			let id = data['url'];
			this.currentRoute = id;
		});

		((path) => {
			this.resetRightPanel(path);
		})(this.router.url);

		this.addFormItems();
		this.onChanges();

		this.filterService.setFilters('');

		this.emptyResultSubscription = this.filterService.currentEmptyResult.subscribe(empty => {
			this.noResults = empty;
		});

		this.importPendingSubscription = this.agentDataService.importPending.subscribe(pending => {
			this.importPending = pending;
		})

		this.agentDataService.subscribeClearSearchInput().subscribe(data => {
			if(data == true) {
				this.dataFilter.reset();
			}
		});
	}

	getAgent() {
		
		this.agentDataService.setClearSearchInput(false);

		this.agentDataService.findAgent(this.dataFilter.value.code).subscribe(agentListedPaged=> {
			//console.log('getAgentLog ' + JSON.stringify(agentListedPaged));
			this.agentDataService.setAgentListPaged(agentListedPaged);
			
		});
		
	}
	ngOnDestroy() {
		if (this.emptyResultSubscription) this.emptyResultSubscription.unsubscribe();
		if (this.routeSubscription) this.routeSubscription.unsubscribe();
		if (this.importPendingSubscription) this.importPendingSubscription.unsubscribe();
	}

	addFormItems() {
		let group = {};
		for (let v of this.panelSections) {
			for (let field in v.fields) {
				// Check if no formId is present or if field should not be displayed, then skip iteration
				if (!v.fields[field]['formId'] || !v.display(this.router.url)) continue;
				// Customize the form control or perform side effects
				switch (v.fields[field].key) {
					case 'checkbox':
						const boxArray = v.fields[field]['options'].map(option => {
							// Set options with default values here
							if (option.defaultTrue) {
								return new FormControl(option.value)
							}
							return new FormControl('')
						});
						group[v.fields[field]['formId']] = new FormArray(boxArray);
						break;
					default:
						if (v.fields[field]['formId'] === 'year') {
							group['year'] = new FormControl(this.periodCustomYears[0]);
							this.filterService.setFilters({year: this.periodCustomYears[0]})
						} else if (v.fields[field]['formId'] === 'month') {
							group['month'] = new FormControl(this.periodService.months[this.periodService.currentMonth === 0 ? 11 : (this.periodService.currentMonth - 1)]);
							this.filterService.setFilters({month: this.periodService.months[this.periodService.currentMonth === 0 ? 11 : (this.periodService.currentMonth - 1)]})
						} else {
							// Set options with default values here
							if (v.fields[field]['defaultValue'] !== undefined
							&& v.fields[field]['defaultValue'] !== null) {
								group[v.fields[field]['formId']] = new FormControl(v.fields[field]['defaultValue']);
							} else {
								group[v.fields[field]['formId']] = new FormControl('');
							}
						}
						break;
				}
			}
		}
		this.dataFilter = new FormGroup(group);
		this.filterService.setFilters(this.dataFilter.value);
	}

	resetRightPanel = id => {
		this.addFormItems();
		this.toggleRightPanel.emit(false)
		for (let section of this.panelSections) {
			if (section.display(id)) {
				this.toggleRightPanel.emit(true);
				break;
			}
		}
	}

	onChanges(): void {
		// this.dataFilter.valueChanges.subscribe(val => {
		// 	// Debounce call to filter setter if changes directly trigger API call.
		// 	// Currently only relevent for agent list..
		// 	if (this.currentRoute === `/${Paths.report_builder}`) {
		// 		this.filterService.setFilters(val);
		// 		// Set parameters for the next report export
		// 		if (Object.keys(val).length) {
		// 			Object.keys(val).map(filter => {
		// 				switch(filter) {
		// 					case 'year':
		// 						this.exportReport.setPeriod(val['year'].value, undefined);
		// 					case 'month':
		// 						this.exportReport.setPeriod(undefined, val['month'].value);
		// 					case 'sorting':
		// 						this.exportReport.setOrder(val['sorting']);
		// 					case 'nonPay':
		// 						this.exportReport.setNonPayment(val['nonPay'].length ? true : false);
		// 					default:
		// 						break;
		// 				}
		// 			})
		// 		}
		// 	} else if (this.currentRoute === `/${Paths.agents}`) {
		// 		this.debounceService.debounce(this.setFilters(val), 1500, false);
		// 	}
		// });
	}

	setFilters = (val) => () => {
		this.filterService.setFilters(val);
	}

	clearFilters(): void {
		this.dataFilter.reset();
	}

	uploadAdnABulk = async (e, form) => {
		let conversionResult;
		// TODO: The backend currently does not support upserts for bulk addendum A.
		// In other words, bulkAdnAAssignment() only supports inserting new records.
		let assignmentsToAdd = [];
		
		if (!e.files.length) return;
		
		try {
			// Convert the content of the csv file to JSON
			conversionResult = await this.convertCSV.convertExcelToJson(e, 'bulk-adn-a');

			// Check for the proper columns in the csv data
			if (!conversionResult.format_valid) throw 'Format is invalid.';

			// Iterate over each row in the spreadsheet
			for (let key in conversionResult.data) {
				// Current iteration
				const data = conversionResult.data[key];

				try {
					// Hit addendum A update endpoint
					await this.apiService.updateAdnAForAgent({
						"AgentCode": typeof data['agent-id'] === 'number' ? data['agent-id'].toString() : data['agent-id'],
						"Year": this.periodService.currentYear,
						"MinPremium": typeof data['min-premium'] === 'string' ? parseInt(data['min-premium']) : data['min-premium'],
						"IsEnabled": data['enabled'].toUpperCase() === 'TRUE' ? true : false
					});
				} catch (e) {
					throw 'An error occurred while modifying addendum A assignments.';
				}
			}

			// Nothing more needs to happen if every element of the array corresponds to an existing DB record
			if (!assignmentsToAdd.length) return;

			// Hit the bulk add endpoint to create new database entries for these addendum assignments
			try {
				await this.apiService.bulkAdnAAssignment(assignmentsToAdd)
			} catch (e) {
				throw 'An error occurred while saving your new addendum A assignments to the database.';
			}
		} catch(e) {
			this.errorService.setError({
				message: 'Please upload your spreadsheet in the proper format.',
				title: 'Unable to process your addendum A bulk upload.',
				error: e,
				dialog: true
			});
		}

		// Remove all files from the input
		form.clear();
	}

	uploadAdnCBulk = async (e, form) => {
		let conversionResult;
		let assignmentsToAdd = [];
		
		if (!e.files.length) return;
		
		try {
			// Hit the bulk add endpoint to create new database entries for these addendum assignments
			try {
				await this.apiService.bulkAdnCAssignment(e.files[0])
			} catch (e) {
				throw 'An error occurred while saving your new addendum C assignments to the database.';
			}
		} catch(e) {
			this.errorService.setError({
				message: 'Please upload your spreadsheet in the proper format. (CSV)',
				title: 'Unable to process your addendum C bulk upload.',
				error: e,
				dialog: true
			});
		}

		// Remove all files from the input
		form.clear();
	}
}