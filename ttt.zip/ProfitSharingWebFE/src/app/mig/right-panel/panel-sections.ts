export interface PanelSections {
    heading?: string,
    fields: (dropdown | radio | checkbox | button | upload | input | link)[],
    display: (route: string) => boolean,
}

interface radio {
    key: 'radio',
    formId: string,
    defaultValue?: string,
    options: {
        label?: string,
        value: string
    }[]
}

interface input {
    key: 'input',
    formId: string,
    label: string
}

interface dropdown {
    key: 'dropdown',
    formId: string,
    placeholder: string,
    label?: string,
    alignment: 'full' | 'right',
    options: {
        label?: string,
        value: string | number
    }[]
}

interface checkbox {
    key: 'checkbox',
    formId: string,
    options: {
        label?: string,
        defaultTrue?: boolean,
        value: string
    }[]
}

interface button {
    key: 'button',
    formId?: string,
    description?: string,
    button: {
        label?: string,
        method?: string,
        action?: string,
        behavior?: () => void,
        disabled?: () => boolean
    }
}

interface upload {
    key: 'upload',
    formId?: string,
    description?: string,
    upload: {
        label?: string,
        multi: boolean,
        behavior?: (arg0?: any, arg1?: any) => void | Promise<any>
    }
}

interface link {
    key: 'link',
    link: {
        label: string,
        icon?: string,
        behavior?: () => void
    }
}