/* NG Includes */
import { Component, Input, OnChanges, OnInit, SimpleChange, SimpleChanges, AfterViewInit, ElementRef, Renderer2, DoCheck } from '@angular/core';
// import { ContractorsGlobals } from '@globals';

@Component({
    selector: 'mig-loading',
    templateUrl: './loading.component.html'
})

export class MIGLoading implements OnInit {
    @Input() message: any;
    @Input() title: any;
    constructor(
        // public globals: ContractorsGlobals,
    ) { }

    
    ngOnInit() {
    
    }

}