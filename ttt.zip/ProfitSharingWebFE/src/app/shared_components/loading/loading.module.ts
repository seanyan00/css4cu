/* NG Includes */
import { NgModule } from '@angular/core';
import { MIGLoading } from '@shared/loading/loading.component';
import { PanelModule } from 'primeng/panel';

@NgModule({
    imports: [PanelModule],
    declarations: [MIGLoading],
    exports: [MIGLoading],
    
})
export class LoadingModule { }
