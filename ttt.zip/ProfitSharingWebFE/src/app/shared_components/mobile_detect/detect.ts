import { Directive, ElementRef, HostListener } from '@angular/core';

/**
 * Custom MIG directive to show and hide HTML elements based on screen size
 * By: Mario Giambanco
 * On: 2-22-2018
 * 
 * Usage: 
 * Import into component and module
 * import { SM, MD, LG, XL } from '@shared/mobile_detect/detect';
 * 
 * Add SM, MD, LG, XL to Declatations of @NgModule
 * 
 * <div sm></div>   Only show element on small devices
 * <div md></div>   Show element on Medium size devices and greater
 * <div lg></div>   Show element on Large size devices and greater
 * <div xl></div>   Show element on Big Screen Monitors size devices and greater
 */
@Directive({
    selector: '[responsive]'
})
export class PrimeResponsive {
    num: number = 0;
    e: ElementRef;
    scl: string = "xl";
    constructor(el: ElementRef) {
        this.e = el;
        el.nativeElement.style.display = "none";
    }
}

@Directive({ selector: '[sm]' })
export class SM extends PrimeResponsive {
    num: number = 0;
    e: ElementRef;

    ngAfterViewInit() { this.funcAdjust(); }
    @HostListener('window:resize', ['$event']) onResize(event) {
        if (event) { this.funcAdjust(); }
    }

    funcAdjust() {
        this.num = window.innerWidth;
        if (this.num < 641) {
            this.e.nativeElement.style.display = "inherit";
            this.scl = "sm";
        } else {
            this.e.nativeElement.style.display = "none";
        }
    }
}

@Directive({ selector: '[md]' })
export class MD extends PrimeResponsive {
    num: number;
    e: ElementRef;

    ngAfterViewInit() { this.funcAdjust(); }
    @HostListener('window:resize', ['$event']) onResize(event) {
        if (event) { this.funcAdjust(); }
    }

    funcAdjust() {
        this.num = window.innerWidth;
        if (this.num > 640) {
            this.e.nativeElement.style.display = "inherit";
            this.scl = "md";
        } else {
            this.e.nativeElement.style.display = "none";
        }
    }
}

@Directive({ selector: '[lg]' })
export class LG extends PrimeResponsive {
    num: number;
    e: ElementRef;

    ngAfterViewInit() { this.funcAdjust(); }
    @HostListener('window:resize', ['$event']) onResize(event) {
        if (event) { this.funcAdjust(); }
    }

    funcAdjust() {
        this.num = window.innerWidth;
        if (this.num > 1024) {
            this.e.nativeElement.style.display = "inherit";
            this.scl = "lg";
        } else {
            this.e.nativeElement.style.display = "none";
        }
    }
}

@Directive({ selector: '[xl]' })
export class XL extends PrimeResponsive {
    num: number;
    e: ElementRef;

    ngAfterViewInit() { this.funcAdjust(); }
    @HostListener('window:resize', ['$event']) onResize(event) {
        if (event) { this.funcAdjust(); }
    }

    funcAdjust() {
        this.num = window.innerWidth;
        if (this.num > 1440) {
            this.e.nativeElement.style.display = "inherit";
            this.scl = "xl";
        } else {
            this.e.nativeElement.style.display = "none";
        }
    }
}