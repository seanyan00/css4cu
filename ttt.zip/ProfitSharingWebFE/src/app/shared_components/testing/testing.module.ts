/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SidebarModule } from 'primeng/sidebar';
import { PanelModule } from 'primeng/panel';
import { CheckboxModule } from 'primeng/checkbox';
import { ButtonModule } from 'primeng/button';

import { MIGTesting } from '@shared/testing/testing.component';
import { RouterModule } from '@angular/router';
import { PipesModule } from '@pipes/pipes.module';
@NgModule({
    imports: [
        CheckboxModule,
        FormsModule,
        SidebarModule,
        CommonModule,
        PanelModule,
        ButtonModule,
		RouterModule,
		PipesModule
    ],
    declarations: [MIGTesting],
    exports: [MIGTesting]
})
export class TestingModule { }
