import { Component, Input, Output, EventEmitter, OnInit, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
@Component({
	selector: 'mig-testing',
	templateUrl: './testing.component.html',
	styleUrls: ['testing.component.css'],
	encapsulation: ViewEncapsulation.None
})

export class MIGTesting implements OnInit {
	ShowTestCode: boolean = false;
	showInputData: boolean = false;
	public validate: boolean = true;
    @Input() testing: any;
	sample1: string = "./assets/sample_data/sample1.json";
	sample2: string = "./assets/sample_data/sample2.json";
	@Output() doneLoadData = new EventEmitter<any>();

	constructor(
		public changeDetectionRef: ChangeDetectorRef,
	) { }
	
	ngOnInit(): void {
		
	}
	inputLog() {
		this.showInputData = !this.showInputData;

	}
	
	consoleLog() {
		this.changeDetectionRef.detectChanges();
		this.ShowTestCode = !this.ShowTestCode;

	}
	
	loadSample1() {
		
	}

	loadSample2() {
		
	}

}