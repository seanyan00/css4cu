import { RouterLink } from "@angular/router";

export class MIGMenu extends Array {
    icon?: string;
    label?: string;
    path?: RouterLink;
}