import { AbstractControl, FormControl, Validators } from "@angular/forms";



export class MIGAddressValidator extends Validators {
    constructor() {
        super();
    }

    ValidatePOBOX(controls: FormControl) {
        let dummy: string = controls.value;
        if (dummy && (dummy.length > 0) && (dummy.length < 11)) {
            return null;
        }
        if (dummy && dummy.length == 0) { return null; }
        return {
            severity: "error", summary: "PO Box", detail: "Please enter a value for PO Box or Street Number.", step: 1
        };
    }

    maxValueValidator = (max:number, field: string) => {
        return (control:FormControl) => {
          var num = control.value;
          if( num.length > max){
            return {
                severity: "error", summary: field, detail: "Max lengh of " + field + " is " + max + ".", step: 1
            };
          }
          return null;
        };
    };

    ValidateNotNull = (field: string) => {
        return (control: FormControl) => {
            let dummy: any = control.value;
            if (dummy) { return null; } else { return { severity: "error", summary: field, detail: "Please enter a value for " + field, step: 1 } }
        }
    }

    ValidateRequiredMinMax = (field: string, min: number, max: number) => {
		return (control:FormControl) => {
			var val = control.value;
			var out = { severity: "error", summary: field, detail: field + " is required and should be " + min + "-" + max + " numbers long.", step: 1 };

			if (val.length > max) { return out; }
			if (val.length < min) { return out; }
			if (!val) { return out; }

			return null;
		  };
	}
}
