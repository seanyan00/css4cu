
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ErrorComponent } from '@shared/errors/errors.component';
import { MIGMessages } from '@overridden/primeng-messages/messages';
import { PanelModule } from 'primeng/panel';
@NgModule({
	imports: [
        CommonModule,
        PanelModule
	],
    declarations: [ErrorComponent, MIGMessages],
    exports: [ErrorComponent]
})
export class ErrorModule { }