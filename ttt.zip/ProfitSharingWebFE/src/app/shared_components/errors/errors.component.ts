import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
    selector: 'mig-errors',
    templateUrl: './errors.component.html'
})
    
export class ErrorComponent  {
    @Input() errors;

}
