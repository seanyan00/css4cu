/* NG Includes */
import { NgModule } from '@angular/core';

import { CurrencyFormatPipe, formatDatePipe, PrettyPrintPipe, FilterLocationPipe } from '@pipes/pipes';

@NgModule({
    imports: [ ],
    declarations: [CurrencyFormatPipe, formatDatePipe, PrettyPrintPipe, FilterLocationPipe],
    exports: [CurrencyFormatPipe, formatDatePipe, PrettyPrintPipe, FilterLocationPipe]
})
export class PipesModule { }
