import { Routes, RouterModule } from "@angular/router";
import { MIGBaseComponent } from "./mig/base_component/base.component";
import { NgModule } from "@angular/core";
import { Paths } from './app.routing.enums'

const routes: Routes = [
	{ path: Paths.agents, component: MIGBaseComponent, data: { grid: Paths.agents }},
	{ path: Paths.plans, component: MIGBaseComponent, data: { grid: Paths.plans }},
	{ path: `${Paths.plans}/${Paths.view}/:name/:id`, component: MIGBaseComponent, data: { grid: `${Paths.plans}-${Paths.view}` }},
	{ path: Paths.tables, component: MIGBaseComponent, data: { grid: Paths.tables }},
	{ path: `${Paths.tables}/${Paths.view}/:type/:name/:id`, component: MIGBaseComponent, data: { grid: `${Paths.tables}-${Paths.view}` }},
	{ path: Paths.report_builder, component: MIGBaseComponent, data: { grid: Paths.report_builder } },
	{ path: Paths.system, component: MIGBaseComponent, data: { grid: Paths.system }},
	{ path: '', redirectTo: Paths.agents, pathMatch: 'full' },
    { path: '', redirectTo: Paths.agents, pathMatch: 'full' },
    { path: '**', redirectTo: Paths.agents, pathMatch: 'full' }
];

@NgModule({
	exports: [RouterModule],
	imports: [ RouterModule.forRoot(routes) ],
})
export class AppRoutingModule {}
