import { Component, ElementRef, Input, forwardRef, Renderer2, ChangeDetectorRef } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { Button } from 'primeng/button';
import { state, style, trigger, transition, animate } from '@angular/animations';
import { DomHandler } from 'primeng/dom';
@Component({
  selector: 'mig-button',
  templateUrl: './button.component.html',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: forwardRef(() => MIGButton)
    }
  ]
})

export class MIGButton extends Button {
  @Input() migEditable: boolean = true;

}
