import { MIGButton } from './button.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ButtonModule } from 'primeng/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DomHandler } from 'primeng/dom';

@NgModule({
	imports: [
		CommonModule,
    ButtonModule,
    BrowserAnimationsModule
	],
	declarations: [MIGButton],
  exports: [MIGButton],
  providers: [DomHandler]
	})
export class MIGButtonModule { }
