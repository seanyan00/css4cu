import { MenuItem } from 'primeng/api';
/**
 * Extended 2-1-2018 MG
 */
 type Merge<M, N> = Omit<M, Extract<keyof M, keyof N>> & N;

export type MIGMenuItem = Merge<MenuItem, {
    color?: string; // added 2-1-2018 MG to set color of item in MIGSteps
    command?: (event?: any, item?: MenuItem) => void;
    adjust?: any;
    errors?: any[];
    active?: boolean;
    items?: MIGMenuItem[] | MIGMenuItem[][];
}>;



