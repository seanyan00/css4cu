/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MIGDropdown } from './dropdown.component';
import { ObjectUtils } from 'primeng/utils';

@NgModule({
    imports: [
        FormsModule,
        CommonModule,
        FormsModule
    ],
    declarations: [MIGDropdown],
	exports: [MIGDropdown],
	providers: [ObjectUtils]
})
export class MIGDropDownModule { }
