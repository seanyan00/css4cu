import { Component, Input, forwardRef, ViewEncapsulation, AfterViewInit, AfterViewChecked, AfterContentInit, OnInit, OnDestroy, ElementRef, Renderer2, ChangeDetectorRef, NgZone, } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { Dropdown } from 'primeng/dropdown';
import {state, style, trigger, transition, animate } from '@angular/animations';

@Component({
	selector: 'mig-dropdown',
	templateUrl: './dropdown.component.html',
	styleUrls: ['dropdown.component.css'],
	encapsulation: ViewEncapsulation.None,
	providers: [{
		provide: NG_VALUE_ACCESSOR,
		useExisting: forwardRef(() => MIGDropdown),
		multi: true
	}],
	animations: [
		trigger('overlayAnimation', [
			state('void', style({
				transform: 'translateY(5%)',
				opacity: 0
			})),
			state('visible', style({
				transform: 'translateY(0)',
				opacity: 1
			})),
			transition('void => visible', animate('{{showTransitionParams}}')),
			transition('visible => void', animate('{{hideTransitionParams}}'))
		])
	],
})

export class MIGDropdown extends Dropdown implements OnInit, OnDestroy, AfterViewInit, AfterViewChecked, AfterContentInit {
	@Input() migEditable: boolean = true;
	value: any;

	ngOnInit() {

	}

	ngOnDestroy() {

	}

	ngAfterViewInit() {

	}

	ngAfterViewChecked() {

	}

	ngAfterContentInit() {

	}
}
