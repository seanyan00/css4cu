import { Component, ElementRef, Input, forwardRef, Renderer2, ChangeDetectorRef, NgZone } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { Calendar } from 'primeng/calendar';
import { state, style, trigger, transition, animate } from '@angular/animations';
import { DomHandler } from 'primeng/dom';
import { OverlayService, PrimeNGConfig } from 'primeng/api';
@Component({
  selector: 'mig-calendar',
  templateUrl: './calendar.component.html',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: forwardRef(() => MIGCalendar)
    }
  ],
  animations: [
    trigger('overlayAnimation', [
      state('visible', style({
        transform: 'translateY(0)',
        opacity: 1
      })),
      state('visibleTouchUI', style({
        transform: 'translate(-50%,-50%)',
        opacity: 1
      })),
      transition('void => visible', [
        style({ transform: 'translateY(5%)', opacity: 0 }),
        animate('{{showTransitionParams}}')
      ]),
      transition('visible => void', [
        animate(('{{hideTransitionParams}}'), style({
          opacity: 0,
          transform: 'translateY(5%)'
        }))
      ]),
      transition('void => visibleTouchUI', [
        style({ opacity: 0, transform: 'translate3d(-50%, -40%, 0) scale(0.9)' }),
        animate('{{showTransitionParams}}')
      ]),
      transition('visibleTouchUI => void', [
        animate(('{{hideTransitionParams}}'), style({
          opacity: 0,
          transform: 'translate3d(-50%, -40%, 0) scale(0.9)'
        }))
      ])
    ])
  ]
})

export class MIGCalendar extends Calendar {
  @Input() migEditable: boolean = true;
  constructor
  (
      el: ElementRef,
      renderer2: Renderer2,
      cd: ChangeDetectorRef,
      zone: NgZone,
      config: PrimeNGConfig,
      overlayService: OverlayService
  )
  {
      super(el, renderer2, cd, zone, config,overlayService);
  }
} 
