
import {
	Component,
	ElementRef,
	Input, forwardRef, ChangeDetectorRef, AfterViewInit, ViewChild
} from '@angular/core';

import {
	NG_VALUE_ACCESSOR, FormControl, ControlValueAccessor
} from '@angular/forms';
import { InputSwitch } from 'primeng/inputswitch';
import { DomHandler } from 'primeng/dom';
import { debounceTime } from 'rxjs/operators';

@Component({
	selector: 'mig-inputswitch',
	templateUrl: './switch.component.html',
	styleUrls: ['./switch.component.css'],
	providers: [
		{
			provide: NG_VALUE_ACCESSOR,
			multi: true,
			useExisting: forwardRef(() => MIGInputSwitch)
		}
	]
})

export class MIGInputSwitch extends InputSwitch implements ControlValueAccessor, AfterViewInit {
	@Input() name: any;
	@Input() offLabel: any;
	@Input() onLabel: any;
	@Input() inputId: any;
	@Input() innerValue: boolean = null;
	@Input() ngModel: any;
	@Input() ngClass: any;
	@Input() group: any;
	@Input() style: any;
	@Input() container: any;
	@Input() onContainer: any;
	@Input() offContainer: any;
	@Input() onLabelChild: any;
	@Input() offLabelChild: any;

	@Input() returnOnValue: any = null;
	@Input() returnOffValue: any = null;

	val: string = '';
	switch_container: ElementRef;
	initialized: any;
	@Input() c: FormControl = new FormControl();
	@ViewChild('input') inputRef: ElementRef;

	errors: Array<any> = ['This field is required'];

	propagateChange: any = () => { };
	@Input() migEditable: boolean;
	ccd: ChangeDetectorRef;
	constructor(el: ElementRef,
		domHandler: DomHandler,
		cd: ChangeDetectorRef
	) {

		super(cd);
		this.ccd = cd;
	}

	ngAfterViewInit() {
		this.c.valueChanges.pipe(debounceTime(100)).subscribe(
			() => {
				console.log(this.c);
				// check condition if the form control is RESET
				if (this.c.value == "" || this.c.value == null || this.c.value == undefined) {
					this.innerValue = false;
					// this.inputRef.nativeElement.value = "";
					this.val = "off";
				}
			}
		);
	};

	ngAfterViewChecked() {
		if (this.container && this.container.offsetParent && !this.initialized) {
			this.render();
		}
	};

	render() {
		this.container.style.width = this.onContainer.style.width + this.offContainer.style.width + "px";
		this.initialized = true;
	};

	toggleOn() {
		console.log("ToggleOn");
		this.val = "on";
		this.innerValue = true;
		if (this.returnOnValue) {
			this.propagateChange(this.returnOnValue);
			this.onModelChange(this.returnOnValue);
			this.onChange.emit(this.returnOnValue);
		} else {
			this.propagateChange(this.innerValue);
			this.onModelChange(this.innerValue);
			this.onChange.emit(true);
		}
	}

	toggleOff() {
		console.log("ToggleOff");
		this.val = "off";
		this.innerValue = false;
		if (this.returnOffValue) {
			this.propagateChange(this.returnOffValue);
			this.onModelChange(this.returnOffValue);
			this.onChange.emit(this.returnOffValue);
		} else {
			this.onModelChange(this.innerValue);
			this.onChange.emit(this.innerValue);
			this.propagateChange(this.innerValue);
		}
		console.log(this.val);
		console.log(this.innerValue);
		console.log(this.returnOffValue);

	}

	checkUI() {
	};

	uncheckUI() {
	};



	//get accessor
	get value(): any {
		return this.innerValue;
	};

	//set accessor including call the onchange callback
	@Input('value')
	set value(v: any) {
		if (v !== this.innerValue) {
			this.innerValue = v;
			this.propagateChange();

		}
	}

	//From ControlValueAccessor interface
	writeValue(value: any) {
		this.innerValue = value;
		this.propagateChange();

	}


	//From ControlValueAccessor interface
	registerOnChange(fn: any) {
		this.propagateChange = fn;
	}

	//From ControlValueAccessor interface
	registerOnTouched(fn: any) {

	}
}
