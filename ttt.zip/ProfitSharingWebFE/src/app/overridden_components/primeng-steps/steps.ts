// import { Component, ElementRef, EventEmitter, Input, Output } from '@angular/core';
// import { StepsModule } from 'primeng/primeng';

// @Component({
//     selector: 'mig-steps',
//     templateUrl: './steps.html',
//     styleUrls: ['steps.css']
// })

// /**
//  * extended 1-23-2018 MG
//  * StepsModule extended to allow using a font-awesome icon instead of a #
//  * MIGMenuItem needed for adding dynamic color to step
//  * see steps.css for possible css classes
//  */
// export class MIGSteps extends StepsModule {
//     @Input() model: any;
//     @Input() activeIndex: any;
//     @Input() styleClass: any;
//     @Input() readonly: any;
//     @Input() style: any;

//     @Output() activeIndexChange = new EventEmitter<any>();
//     el: ElementRef;

//     constructor(el: ElementRef) {
//         super();
//         this.el = el;
//     }

//     itemClick = function (event, item, i) {
//         if (this.readonly || item.disabled) {
//             event.preventDefault();
//             return;
//         }
//         this.activeIndexChange.emit(i);
//         if (!item.url) {
//             event.preventDefault();
//         }
//         if (item.command) {
//             item.command({
//                 originalEvent: event,
//                 item: item,
//                 index: i
//             });
//         }
//     };
// }