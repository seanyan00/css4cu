import { MIGProgessbar } from './progress.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DomHandler } from 'primeng/dom';
@NgModule({
	imports: [CommonModule],
	declarations: [MIGProgessbar],
  exports: [MIGProgessbar]
	})
export class MIGProgessbarModule { }
