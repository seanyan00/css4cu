import { MIGSpinner } from './spinner.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DomHandler } from 'primeng/dom';@NgModule({
	imports: [CommonModule, FormsModule],
	declarations: [MIGSpinner],
	exports: [MIGSpinner],
	providers: [DomHandler]
	})
export class MIGSpinnerModule { }
