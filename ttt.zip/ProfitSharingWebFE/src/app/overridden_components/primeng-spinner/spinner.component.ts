import { Component, Input, forwardRef, ElementRef, ChangeDetectorRef } from '@angular/core';
import { NG_VALUE_ACCESSOR, NgModel } from '@angular/forms';
import { Spinner } from 'primeng/spinner';
import { DomHandler } from 'primeng/dom';
@Component({
	selector: 'mig-spinner',
	templateUrl: './spinner.component.html',
	providers: [
		{
			provide: NG_VALUE_ACCESSOR,
			multi: true,
			useExisting: forwardRef(() => MIGSpinner),
		}
	]
})

export class MIGSpinner extends Spinner {
	@Input() migEditable: boolean = true;

	constructor(el: ElementRef<any>, domHandler: DomHandler, cd: ChangeDetectorRef) {
		super(el, cd);
	}

}
