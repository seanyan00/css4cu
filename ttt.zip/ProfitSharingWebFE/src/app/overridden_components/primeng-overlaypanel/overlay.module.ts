/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AutoCompleteModule } from 'primeng/autocomplete';
// import { NgModel } from '@angular/forms';
import { MIGOverlayPanel } from './overlay';
@NgModule({
    imports: [
        AutoCompleteModule,
        FormsModule,
        CommonModule,
    ],
    declarations: [MIGOverlayPanel],
    exports: [MIGOverlayPanel]
})
export class MIGOverlayPanelModule { }
