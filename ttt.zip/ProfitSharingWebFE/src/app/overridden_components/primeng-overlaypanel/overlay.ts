import {
    ChangeDetectorRef,
    Component,
    ElementRef,
    Input,
    Renderer2,
	NgZone} from '@angular/core';

import {
    state,
    style,
    trigger,
} from '@angular/animations';

import { DomHandler } from 'primeng/dom';
import { OverlayPanel } from 'primeng/overlaypanel';
import { OverlayService, PrimeNGConfig } from 'primeng/api';

@Component({
    selector: 'mig-overlaypanel',
    templateUrl: './overlay.html',
    styleUrls: ['overlay.css'],
    animations: [
        trigger('panelState', [
            state('hidden', style({
                opacity: 0
            })),
            state('visible', style({
                opacity: 1
            }))
        ])
    ]
})

export class MIGOverlayPanel extends OverlayPanel {

    @Input() dismissable: any;
    @Input() showCloseIcon: any;

    // can be used as [styleClass]='' if it comes from a variable
    // or just as styleClass='' if it's an actual CSS class
    @Input() styleClass: any;
    @Input() style: any;
    @Input() appendTo: any;

	@Input() willShow: any;
	@Input() onAfterShow: any;
	@Input() onAfterHide: any;


    constructor(el: ElementRef,
        DomHandler: DomHandler,
        Renderer: Renderer2,
		differs: ChangeDetectorRef,
		cd: ChangeDetectorRef,
		zone: NgZone,
        config: PrimeNGConfig, 
        overlayService: OverlayService
	) {
        super(el, Renderer, cd, zone,config,overlayService);
    }

    ngAfterViewChecked() {
        if (this.willShow) {
            // this.bindDocumentClickListener();
            this.onAfterShow.emit(null);
            this.willShow = false;
        }
        if (this.willHide) {
            this.onAfterHide.emit(null);
            this.willHide = false;
        }
    }
}
