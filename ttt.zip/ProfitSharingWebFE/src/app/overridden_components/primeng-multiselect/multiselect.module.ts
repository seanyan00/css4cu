import { MIGMultiselect } from './multiselect.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DomHandler } from 'primeng/dom';import { ScrollingModule } from '@angular/cdk/scrolling';
import { MIGMultiselectItemModule } from './item.module';
@NgModule({
	imports: [CommonModule, FormsModule, ScrollingModule, MIGMultiselectItemModule],
	declarations: [MIGMultiselect],
	exports: [MIGMultiselect],
	providers: [DomHandler]
})
export class MIGMultiselectModule { }
