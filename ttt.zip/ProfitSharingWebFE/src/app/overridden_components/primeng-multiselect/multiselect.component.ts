import { Component, Input, forwardRef, ElementRef } from '@angular/core';
import { NG_VALUE_ACCESSOR, NgModel } from '@angular/forms';
import { MultiSelect } from 'primeng/multiselect';
import { DomHandler } from 'primeng/dom';import { state, style, trigger, transition, animate } from '@angular/animations';
@Component({
  selector: 'mig-multiSelect',
  templateUrl: './multiselect.component.html',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: forwardRef(() => MIGMultiselect),
    }
  ],
  animations: [
    trigger('overlayAnimation', [
      state('void', style({
        transform: 'translateY(5%)',
        opacity: 0
      })),
      state('visible', style({
        transform: 'translateY(0)',
        opacity: 1
      })),
      transition('void => visible', animate('{{showTransitionParams}}')),
      transition('visible => void', animate('{{hideTransitionParams}}'))
    ])
  ]
})

export class MIGMultiselect extends MultiSelect {
  @Input() migEditable: boolean = true;

}
