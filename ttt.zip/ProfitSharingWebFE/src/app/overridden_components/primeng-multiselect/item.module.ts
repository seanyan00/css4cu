import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MIGMultiselectItem } from './item';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { DomHandler } from '../../../../node_modules/primeng/dom'
@NgModule({
	imports: [CommonModule, FormsModule, ScrollingModule],
	declarations: [MIGMultiselectItem],
	exports: [MIGMultiselectItem],
	providers: [DomHandler]
})
export class MIGMultiselectItemModule { }
