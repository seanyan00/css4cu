import { MIGCheckbox } from './checkbox';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

@NgModule({
	imports: [CommonModule],
	declarations: [MIGCheckbox],
	exports: [MIGCheckbox]
	})
export class MIGCheckboxModule { }
