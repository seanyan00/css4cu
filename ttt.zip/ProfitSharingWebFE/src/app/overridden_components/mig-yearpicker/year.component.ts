import { Component, ElementRef, Input, forwardRef, Renderer2, ChangeDetectorRef, OnInit, AfterViewInit, NgZone } from '@angular/core';
import { NG_VALUE_ACCESSOR, FormControl } from '@angular/forms';
import { Calendar } from 'primeng/calendar';
import { state, style, trigger, transition, animate } from '@angular/animations';
import { OverlayService, PrimeNGConfig } from 'primeng/api';

@Component({
	selector: 'mig-year-picker',
	templateUrl: './year.component.html',
	providers: [
		{
			provide: NG_VALUE_ACCESSOR,
			multi: true,
			useExisting: forwardRef(() => MIGYearPicker)
		}
	],
	animations: [
		trigger('overlayAnimation', [
			state('visible', style({
				transform: 'translateY(0)',
				opacity: 1
			})),
			state('visibleTouchUI', style({
				transform: 'translate(-50%,-50%)',
				opacity: 1
			})),
			transition('void => visible', [
				style({ transform: 'translateY(5%)', opacity: 0 }),
				animate('{{showTransitionParams}}')
			]),
			transition('visible => void', [
				animate(('{{hideTransitionParams}}'), style({
					opacity: 0,
					transform: 'translateY(5%)'
				}))
			]),
			transition('void => visibleTouchUI', [
				style({ opacity: 0, transform: 'translate3d(-50%, -40%, 0) scale(0.9)' }),
				animate('{{showTransitionParams}}')
			]),
			transition('visibleTouchUI => void', [
				animate(('{{hideTransitionParams}}'), style({
					opacity: 0,
					transform: 'translate3d(-50%, -40%, 0) scale(0.9)'
				}))
			])
		])
	]
})

export class MIGYearPicker extends Calendar implements OnInit, AfterViewInit {
	@Input() migEditable: boolean = true;
	@Input() migYearStart: number;
	@Input() migYearEnd: number = new Date().getFullYear();
	@Input() c: FormControl = new FormControl();
	@Input() columns: number = 6;

	years: any[] = [];
	propagateChange: any = () => { };

	constructor(
		el: ElementRef,
		renderer2: Renderer2,
		cd: ChangeDetectorRef,
		zone: NgZone,
		config: PrimeNGConfig,
		overlayService: OverlayService
	) {
		super(el, renderer2, cd,zone,config,overlayService);
	}


	ngOnInit() {
		this.columns--;
		let count = 0;
		let row = [];
		for (let i = this.migYearStart; i <= this.migYearEnd; i++) {
			if (count <= this.columns) {
				row.push({ year: i });
				count++;
			} else {
				row.push({ year: i });
				this.years.push(row);
				count = 0;
				row = [];
			}
		}
		if (row.length) { this.years.push(row) };
	}

	ngAfterViewInit(): void {
		if (this.c.value) { this.inputFieldValue = this.c.value; }
	}

	updateInputField() {
		this.inputFieldValue = this.value;
		if (this.inputfieldViewChild && this.inputfieldViewChild.nativeElement) {
			this.inputfieldViewChild.nativeElement.value = this.inputFieldValue;
		}
	}

	onDateSelectYear(event, year) {
		this.value = year;
		this.updateModel(year);
		if (this.inputfieldViewChild && this.inputfieldViewChild.nativeElement) {
			this.inputfieldViewChild.nativeElement.value = this.value;
		}
		this.overlayVisible = false;
		this.cd.detectChanges();
	}

	onUserInput(event) {
		return event;
	}

	formatDate(date, format): string {
		return;
	}

	updateUI() {

		var val = new Date();
		if (Array.isArray(val)) {
			val = val[0];
		}
		this.currentMonth = val.getMonth();
		this.currentYear = val.getFullYear();
		this.createMonths(this.currentMonth, this.currentYear);
		if (this.showTime || this.timeOnly) {
			var hours = val.getHours();
			if (this.hourFormat == '12') {
				this.pm = hours > 11;
				if (hours >= 12) {
					this.currentHour = (hours == 12) ? 12 : hours - 12;
				}
				else {
					this.currentHour = (hours == 0) ? 12 : hours;
				}
			}
			else {
				this.currentHour = val.getHours();
			}
			this.currentMinute = val.getMinutes();
			this.currentSecond = val.getSeconds();
		}
	}

	writeValue(value) {
		this.value = value;
		this.inputFieldValue = value;
		this.updateUI();
	};
}
