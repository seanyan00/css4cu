export enum Paths {
	view = 'view',
	modify = 'modify',
	agents = 'agents',
	plans = 'plans',
	system = 'system',
	presidents = 'presidents',
	tables = 'tables',
	volume_loss = 'volume-loss',
	profitability = 'profitability',
	growth = 'growth',
	report_builder = 'report-builder',
}