// Angular Imports
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent } from '@system/app/app.component';
import { AppMenu } from '@system/menu/app.menu.component';
import { AppRoutingModule } from './app.routing.module';
import { ErrorService } from '@services/error.service';
import { MIGSystemService } from '@services/mig.service';
import { MIGBaseModule } from '@root/mig/base_component/base.module';
import { OnlyNumber } from '@shared/numberOnly/numberOnly.directive';
import { PrimeResponsive, SM, MD, LG, XL } from '@shared/mobile_detect/detect';
import { PanelMenuModule } from 'primeng/panelmenu';
import { InputTextModule } from 'primeng/inputtext';
import { ContextMenuModule } from 'primeng/contextmenu';
import { SearchbarComponent } from './searchbar/searchbar.component';
//import { DropdownModule } from 'primeng/dropdown';
import { CheckboxModule } from 'primeng/checkbox';
import { ButtonModule } from 'primeng/button';
import { HttpClientModule } from '@angular/common/http';
import { PaginatorModule } from 'primeng/paginator';
import { SidebarModule } from 'primeng/sidebar';
import { PanelModule } from 'primeng/panel';
import { BottomMenuComponent } from './system/bottom-menu/bottom-menu.component';
import { ErrorDialogComponent } from '@system/error-dialog/error-dialog.component'; 
import { PendingDialogComponent } from '@system/pending-dialog/pending-dialog.component'; 
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { FileUploadModule } from 'primeng/fileupload';
import { DialogModule } from 'primeng/dialog';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService, SharedModule } from 'primeng/api';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { MIGDropDownModule } from 'src/app/overridden_components/primeng-dropdown/dropdown.module';
import { DropdownModule } from 'primeng/dropdown';
import { TreeTableModule } from 'primeng/treetable';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';

@NgModule({
	imports: [
		BrowserModule,
		BrowserAnimationsModule,
		AppRoutingModule,
		MIGBaseModule,
		PanelMenuModule,
		ProgressSpinnerModule,
		TreeTableModule,
		InputTextModule, ContextMenuModule, MIGDropDownModule,
		MIGCheckboxModule,
		ButtonModule, HttpClientModule, PaginatorModule,
		SidebarModule, PanelModule, MessagesModule, MessageModule, FileUploadModule, ConfirmDialogModule, SharedModule, DialogModule
	],
	declarations: [
		AppComponent,
		OnlyNumber,
		AppMenu,
		PrimeResponsive, SM, MD, LG, XL, AppComponent,
		SearchbarComponent,
		BottomMenuComponent,
		ErrorDialogComponent,
		PendingDialogComponent,
	],
	providers: [
		MIGSystemService,
		ErrorService,
		Document,
		ConfirmationService
	],
	bootstrap: [AppComponent]
})
export class AppModule { }
