import { Injectable } from "@angular/core";

@Injectable()
export class ContractorsDropDowns {
	// Quote Information
	InsuredType: any[] = [];
	States: any[] = [];
	StatesFull: any[] = [];
	
	LineOfBusiness: any[] = [];
	TypeOfOccuranceClaim: any[] = [];

	// Liability Limits
	GLOccuranceAggregate: any[] = [];
	MedicalExpense: any[] = [];
	DamageToPremisesRented: any[] = [];
	
	// Location Summary > Property Coverage
	FIRALM: any[] = [];
	CONSYM: any[] = [];
	BURGAL: any[] = [];
	BLDDED: any[] = [];
	WNDDCT: any[] = [];
	BLDCIN: any[] = [];
	BPPCN1: any[] = [];
	BLDVAL: any[] = [];
	BPPVN1: any[] = [];
}

