import { Injectable } from "@angular/core";

@Injectable()
export class Functions {

	pad(n, width, z = "") {
		z = z || '0';
		n = n + '';
		return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n;
	}

	nopad(s) {
		let trimmed = s.replace(/\b(0(?!\b))+/g, "");
		console.log(trimmed);
		return trimmed;
	}

	funcKillAutoFill(elem, renderer) {
		// Chrome ignores autocomplete='off'
		// so - this is the workaround
		// (MIG can be anything)
		//
		// Put it in AfterViewInit
		let elements = elem.nativeElement.querySelectorAll('input');
		elements.forEach(element => {
			//console.log(element.getAttribute("id"));
			renderer.setElementAttribute(element, "autocomplete", "MIG");

			// turn the rest of them off cause it's just annoying for this project
			renderer.setElementAttribute(element, "autocorrect", "off");
			renderer.setElementAttribute(element, "autocapitalize", "off");
			renderer.setElementAttribute(element, "spellcheck", "false");
		})
		this.funcRemoveTabIndex(elem, renderer);
	}

	funcRemoveTabIndex(elem, renderer) {
		let elements = elem.nativeElement.querySelectorAll('a');
		elements.forEach(element => {
			renderer.setElementAttribute(element, "tabindex", "-1");
		});

		elements = elem.nativeElement.querySelectorAll('button');
		elements.forEach(element => {
			renderer.setElementAttribute(element, "tabindex", "-1");
		});


		let count = 0;
		elements = elem.nativeElement.querySelectorAll('input');
		elements.forEach(element => {
			renderer.setElementAttribute(element, "tabindex", count);
			count++;
		});
	}

	DTEWinsToPrimeNG(dtetme): string {
		if (!dtetme) { return; }
		let out = "";
		let dte: string = dtetme.toString();;
		out = dte.substr(4, 2) + "/" + dte.substr(6, 2) + "/" + dte.substr(0, 4);
		// let dummy = new Date(out);
		// console.log(out);
		return out.toString();
	}

	DTEPrimeNGtoWins(dtetme): number {
		if (!dtetme) { return; }
		return dtetme.toISOString().split('T')[0].replace(/-/g, "");
		// if (dtetme && dtetme.toString().includes("/")) {
		//     let dummy = dtetme.split("/");
		//     let out = dummy[2] + dummy[0] + dummy[1];
		//     return out;
		// } else {
		//     return dtetme;
		// }
	}

	parseWinsState(state: string): string {
		let out = "";
		switch (state) {
			case "MA":
				out = "Massachusetts";
				break;

			case "NY":
				out = "New York";
				break;
		}
		return out;
	}

	validateField(hasError, field) {
		// hasError is a property passdown from contractors.component
		// field is the get field() function from the component
		// to be used on the <label> of the field
		// to simplify setting color: red when a field fails validation
		if (hasError && field && field.errors) { return 'err'; }
	}

	fixDropDownLabel(field) {
		// ui-float-label doesn't work on p-dropdown
		// this fixes it
		if (field.value) { return { "top": "-.75em" }; } else { return { "top": "1.0em" }; }
	}
	detectIE() {
		var ua = window.navigator.userAgent;
		var msie = ua.indexOf('MSIE ');
		if (msie > 0) {
			// IE 10 or older => return version number
			return parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)), 10);
		}

		var trident = ua.indexOf('Trident/');
		if (trident > 0) {
			// IE 11 => return version number
			var rv = ua.indexOf('rv:');
			return parseInt(ua.substring(rv + 3, ua.indexOf('.', rv)), 10);
		}

		var edge = ua.indexOf('Edge/');
		if (edge > 0) {
			// Edge (IE 12+) => return version number
			return parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10);
		}

		// other browser
		return false;
	}
}