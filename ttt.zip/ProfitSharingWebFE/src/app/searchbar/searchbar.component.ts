import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MenuItem } from 'primeng/api';
import {SelectItem} from 'primeng/api';
@Component({
  selector: 'app-searchbar',
  templateUrl: './searchbar.component.html',
  styleUrls: ['./searchbar.component.scss'],
  encapsulation:ViewEncapsulation.None
})
export class SearchbarComponent implements OnInit {
  items: MenuItem[];
  territories: SelectItem[];
  selectedCity1: string;
  constructor() { }

  ngOnInit() {
       //An array of cities
       this.territories = [
        {label: 'Marketing Territory', value: 'NY'},
        {label: 'Marketing Territory', value: 'NY'},
        {label: 'Marketing Territory', value: 'NY'}
        
    ];
  }


}
