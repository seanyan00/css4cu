import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { AuthService } from '@auth/auth.service';
import { AuthGuard } from '@auth/auth.guard';
import { AuthRoutingModule } from '@auth/auth-routing.module';
import { AuthInterceptor } from '@auth/auth-interceptor.service';


@NgModule({
  imports: [
      CommonModule,
      HttpClientModule,
      AuthRoutingModule
  ],
    declarations: [

    ],
    providers: [
        AuthService, {
            provide: HTTP_INTERCEPTORS,
            useClass: AuthInterceptor,
            multi: true,
        },
        AuthGuard
    ]
})
export class AuthModule { }
