import { Injectable, Injector } from "@angular/core";
import { HttpHandler, HttpEvent, HttpInterceptor, HttpRequest } from "@angular/common/http";
import { Observable } from "rxjs";

import { AuthService } from "@auth/auth.service";

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

    constructor(private injector: Injector) { }


    intercept(
        request: HttpRequest<any>,
        next: HttpHandler): Observable<HttpEvent<any>> {

        var auth = this.injector.get(AuthService);

        //console.log('Interceptor: isLoggedIn(): ' + auth.isLoggedIn());

        var token = (auth.isLoggedIn()) ? auth.getAuth()!.Token : null;

        //console.log('Interceptor-token: ' + token);

        if (token) {
            request = request.clone({
                setHeaders: {
                    Authorization: `Bearer ${token}`
                },
                withCredentials: true,
            });
        }
        return next.handle(request);
    }

}
