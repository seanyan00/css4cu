﻿export class TokenResponse {
    
    /** @param string User ID from Post call */
    public UserId: string

    /** @param string User ID from Post call */
    public SessionId: string
    public Email: string
    public UserName: string
    public APSubjectId: string
    public APGroupId: string
    public QuoteId: string
    public TransType: string
    public Token: string
    public Expiration: string
    public DropDownValues: string

}
