﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MIGE.Core.NewWebHost.Models
{
    public class UserData
    {
        public UserData() {
        }

        //
        public string Email { get; set; }
        public string UserName { get; set; }
        public string UserId { get; set; }
        public string SessionId { get; set; }
        public string APSubjectId { get; set; }
        public string APGroupId { get; set; }
        public string QuoteId { get; set; }
        public string TransType { get; set; }


    }
}
