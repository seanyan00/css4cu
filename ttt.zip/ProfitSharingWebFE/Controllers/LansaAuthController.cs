using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using System.IO;
using System.Net;
using System.Text;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Http;
using MIGE.Core.NewWebHost.Models;
using Microsoft.Extensions.Configuration;

//
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;


// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MIGE.Core.NewWebHost.Controllers
{
    public class LansaAuthController : Controller
    {

		private const string URL = "http://dev-net-ric.mig.local:9000/MIG/";
        //protected RoleManager<IdentityRole> RoleManager { get; private set; }
        //protected UserManager<UserData> UserManager { get; private set; }
        protected IConfiguration Configuration { get; private set; }
        protected JsonSerializerSettings JsonSettings { get; private set; }
                
       
        public LansaAuthController(IConfiguration configuration)
        {

            Configuration = configuration; 

            // Instantiate a single JsonSerializerSettings object
            // that can be reused multiple times.
            JsonSettings = new JsonSerializerSettings()
            {
                Formatting = Formatting.Indented
            };
        }

        // GET: /<controller>/
        [HttpPost]
        //[AllowAnonymous]
        [Route("api/LansaAuthenticate")]
        //public IActionResult Index(UserData userData)
        public async Task<IActionResult> Index(UserData userData)
        {

			//test data
			UserData data = new UserData();
			data.UserId = "awarskigc";
			data.SessionId = "L0272A862298502017E6201112019100005";
			data.UserName = "Gregory Awarski";
			data.Email = "gawarski@MerchantsGroup.com";
			data.APSubjectId = "8141";
			data.APGroupId = "100100";

			var identity = User.Identity as ClaimsIdentity;

            // return a generic HTTP Status 500 (Server Error)
            // if the client payload is invalid.
            if (userData == null) return new StatusCodeResult(500);

            // 
            JsonSerializerSettings config = new JsonSerializerSettings { ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore };

            if (!DBNull.Value.Equals(userData.UserId))
            {
                //return GetToken(userData);
                TokenResponseViewModel response = await GetToken(userData);

                if (response == null) {
                    return new RedirectResult("https://secure.merchantsgroup.com:81/cgi-bin/lansaweb?procfun+migcomproc+mlogon+dev+eng+funcparms+z1aplchld(A0010):C");
                }

                var userToken = JsonConvert.SerializeObject(response, Formatting.Indented, config);

                ViewData["data"] = userToken;
                //return View();
                return View("wwwroot/index.cshtml");
            }
            else
            { // not supported - return a HTTP 401 (Unauthorized)
                return new UnauthorizedResult();
            }           

        }

        //private ActionResult GetToken(UserData user)
        private async Task<TokenResponseViewModel> GetToken(UserData user)
        {
            try
            {
                // ** HERE WE GO TO LANSA FOR AUTH 
                // before issuing the token ** // 
                
                // *** PROD ***
                var lansaResponse = await LansaValidate(user);
                
                //testing
                //var lansaResponse = true;

                //if valid create token
                if (Convert.ToBoolean(lansaResponse))
                {                    
                    // add the registered claims for JWT (RFC7519).
                    DateTime now = DateTime.UtcNow;

                    var userClaims = new List<Claim>();

                    userClaims.Add(new Claim(JwtRegisteredClaimNames.Sub, user.UserId));
                    userClaims.Add(new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()));
                    userClaims.Add(new Claim(JwtRegisteredClaimNames.Iat, new DateTimeOffset(now).ToUnixTimeSeconds().ToString()));

                    //add additional claims here ->(loop thorugh lansa roles)
                    //userClaims.Add(new Claim(ClaimTypes.Role, "admin"));
                    userClaims.Add(new Claim(ClaimTypes.Role, "CSR"));
                    //userClaims.Add(new Claim(ClaimTypes.Role, "Colleague"));


                    var tokenExpirationMins = Configuration.GetValue<int>("Auth:Jwt:TokenExpirationInMinutes");
                    var issuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["Auth:Jwt:Key"]));

                    var token = new JwtSecurityToken(
                            issuer: Configuration["Auth:Jwt:Issuer"],
                            audience: Configuration["Auth:Jwt:Audience"],
                            claims: userClaims,
                            //notBefore: now,
                            expires: now.Add(TimeSpan.FromMinutes(tokenExpirationMins)),
                            signingCredentials: new SigningCredentials(issuerSigningKey, SecurityAlgorithms.HmacSha256)
                    );

                    var encodedToken = new JwtSecurityTokenHandler().WriteToken(token);

                    //get dropdown values here
                    //dynamic DropDownValues = GetDropDownValues();
                    
                    // build & return the response
                    var response = new TokenResponseViewModel()
                    {
                        UserId      = user.UserId,
                        UserName    = user.UserName,
                        Email       = user.Email,
                        SessionId   = user.SessionId,
                        APSubjectId = user.APGroupId,
                        APGroupId   = user.APGroupId,
                        QuoteId     = user.QuoteId,
                        TransType   = user.TransType,
                        Token       = encodedToken,
                        Expiration  = tokenExpirationMins,
                        DropDownValues = ""
                    };

                    return response;
                    //return Json(response);
                }
                else {
                    return null;
                }
            }//end if lansa validate
            catch (Exception ex)
            {
                throw ex;
                //return new UnauthorizedResult();
            }
        }

        //private async Task<JsonResult> LansaValidate(UserData user)
        private async Task<string> LansaValidate(UserData user)
        {

            try
            {
                //back-end behind firewall lansa validate call 
                //HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL + "ValidateLansaSession/L00361E003BD8E20165DF05172018090459/8133");
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL + "ValidateLansaSession/" + user.SessionId +"/"+ user.APSubjectId);
                request.Method = "GET";
                request.ContentType = "application/json";

                //
                HttpWebResponse response =  (HttpWebResponse)request.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream());
                string result = reader.ReadToEnd();
                return result;
                //dynamic json = JsonConvert.DeserializeObject(reader.ReadToEnd());
                //return Json(json);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //private dynamic GetDropDownValues() {

        //    try
        //    {
        //        //back-end behind firewall dropdown values call                
        //        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL + "GetDropDownValues");
        //        request.Method = "GET";
        //        request.ContentType = "application/json";

        //        //
        //        HttpWebResponse response = (HttpWebResponse)request.GetResponse();
        //        StreamReader reader = new StreamReader(response.GetResponseStream());
        //        dynamic result = reader.ReadToEnd();
        //        return result;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

    }
}
