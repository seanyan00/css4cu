﻿using System;
using System.Data.Entity;
using System.Reflection;

using BT.Service.TransferObject.ClientSite;
using BT.Service.TransferObject.Main;

namespace BT.Service.Data.Factory
{
    public static class EntityHelperFactory
    {
        public static object CreateInstance(DbContext ctx, ElementDataDTO edd, BTClientUserDTO bud)
        {
            // Type targ = Type.GetType(edd.TableName);
            Type targ = Extensions.TypeHelper.GetDataType(edd.TableName);

            Type gclass = typeof(Extensions.EntityHelper<>);
            Type cclass = gclass.MakeGenericType(targ);

            return Activator.CreateInstance(cclass, new object[] { ctx, edd, bud });
        }
        public static object CreateInstance(DbContext ctx, ElementRequestDTO erd, BTClientUserDTO bud)
        {
            // Type targ = Type.GetType(edd.TableName);
            Type targ = Extensions.TypeHelper.GetDataType(erd.Name);

            Type gclass = typeof(Extensions.EntityHelper<>);
            Type cclass = gclass.MakeGenericType(targ);

            return Activator.CreateInstance(cclass, new object[] { ctx, erd, bud });
        }

        public static ElementDataDTO GetDTO(DbContext ctx, ElementRequestDTO erd, BTClientUserDTO bud)
        {
            object obj = CreateInstance(ctx, erd, bud);
            Type otype = obj.GetType();

            MethodInfo m1 = otype.GetMethod("GetDTO");

            return (ElementDataDTO)m1.Invoke(obj, new object[] { });
        }

        public static int SaveDTO(DbContext ctx, ElementDataDTO edd, BTClientUserDTO bud)
        {
            object obj = CreateInstance(ctx, edd, bud);
            Type otype = obj.GetType();

            MethodInfo m1 = otype.GetMethod("PersistChange");

            return (int)m1.Invoke(obj, new object[] { });
        }
    }
}
