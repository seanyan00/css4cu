﻿using System;
using System.Collections.Generic;

using BT.Service.TransferObject.Main;

namespace BT.Service.Data.Base
{
    public abstract class DbAccess : IDisposable
    {
        protected const int CMDTIMEOUT = 1800;

        protected string _connstr;

        protected bool _disposed = false;

        public DbAccess()
        {
            Init();
        }
        public DbAccess(string connstr) 
        {
            _connstr = connstr;
            Init();
            
        }
        ~DbAccess()
        {
            Dispose(false);
        }
        protected abstract void Init();

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected abstract void Dispose(bool disposing);

        public abstract int SaveDataSet(ElementDataDTO edd);

        public abstract List<string> GetStringList(string sql);

        public abstract List<int> GetIntList(string sql);

        public abstract List<T> GetEntityList<T>(string sql) where T : class, new();

        public abstract object GetDataReader(string sql);

        public abstract int InsertDataReturnId(string sql);

        public abstract void BeginTran();

        public abstract void Commit();

        public abstract void Rollback();

        public abstract int RunSql(string sql);

        public abstract string BuildSql(ElementRequestDTO erd);

        public abstract void TestDBConfig();

        public abstract Models.SiteTable GetSiteTable(string tname);

        public abstract ElementDataDTO GetTargetTableData(string tname);
                
    }
}
