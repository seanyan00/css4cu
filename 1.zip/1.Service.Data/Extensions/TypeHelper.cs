﻿using System;
using System.Linq;
using System.Reflection;

namespace BT.Service.Data.Extensions
{
    public static class TypeHelper
    {
        public static Type GetDataType(string tname)
        {
            //TODO: EF core, using _ctx.Model.GetEntityTypes().First(x => x.ClrType == typeof(T));
            var type = Assembly.GetExecutingAssembly()
                             .GetTypes()
                             .FirstOrDefault(t => t.Name == tname);

            if (type == null)
            {
                if (tname[tname.Length - 1] == 's')
                    type = GetDataType(tname.Substring(0, tname.Length - 1));
                if(type == null)
                    throw new TypeAccessException("Type loading failed on " + tname);
            }
            return type;
        }
    }
}
