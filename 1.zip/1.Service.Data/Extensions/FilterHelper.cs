﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BT.Service.TransferObject.Main;

namespace BT.Service.Data.Extensions
{
    public static class FilterHelper
    {
        public static List<EleRowDTO> ApplyFilter(List<EleRowDTO> lerd, List<Filter> lf)
        {
            var ret = new List<EleRowDTO>();
            
            if(lerd.Count >0 && lf.Count > 0)
            {
                for(int i = 1; i <= lerd.Count; i++)
                {
                    bool inset = true;

                    var row = lerd.Where(x => x.RowId == i.ToString()).ToList();
                    foreach(var f in lf)
                    {
                        switch (f.Oper)
                        {
                            case "eq":
                                if (row.Any(x => x.DBName == f.ColName && (x.DataValue != f.Value)))
                                    inset = false;
                                break;
                            case "eqn":
                                if (row.Any(x => x.DBName == f.ColName && (x.DataValue != null && x.DataValue != f.Value)))
                                    inset = false;
                                break;
                            case "ne":
                                if (row.Any(x => x.DBName == f.ColName && (x.DataValue == f.Value)))
                                    inset = false;
                                break;
                            case "cn":
                                if (!row.Any(x => x.DBName == f.ColName && (x.DataValue.Contains(f.Value))))
                                    inset = false;
                                break;
                            case "gt":
                                if (!row.Any(x => x.DBName == f.ColName && GT(x.DataValue, f.Value, x.DataType)))
                                    inset = false;
                                break;
                            case "lt":
                                if (!row.Any(x => x.DBName == f.ColName && LT(x.DataValue, f.Value, x.DataType)))
                                    inset = false;
                                break;
                            case "gte":
                                if (!row.Any(x => x.DBName == f.ColName && GTE(x.DataValue, f.Value, x.DataType)))
                                    inset = false;
                                break;
                            case "lte":
                                if (!row.Any(x => x.DBName == f.ColName && LTE(x.DataValue, f.Value, x.DataType)))
                                    inset = false;
                                break;
                            case "in":
                                var vs = f.Value.Split(new char[] { '|' });
                                var found = false;
                                
                                foreach(var s in vs)
                                {
                                    if(row.Any(x => x.DBName == f.ColName && x.DataValue == s)){
                                        found = true;
                                        break;
                                    }
                                }
                                inset = found;
                                break;
                            default:
                                break;
                        }
                        if (!inset)
                            break;
                    }
                    if (inset)
                    {
                        ret.AddRange(row);
                    }
                }
            }

            return ret;
        }
        private static bool GT(string cf, string ct, string ts)
        {
            Type t = Type.GetType(ts);

            dynamic v1 = EntityAttrHelper.GetValue(cf, t);
            dynamic v2 = EntityAttrHelper.GetValue(ct, t);

            return v1 > v2;
        }
        private static bool LT(string cf, string ct, string ts)
        {
            Type t = Type.GetType(ts);

            dynamic v1 = EntityAttrHelper.GetValue(cf, t);
            dynamic v2 = EntityAttrHelper.GetValue(ct, t);

            return v1 < v2;
        }
        private static bool GTE(string cf, string ct, string ts)
        {
            Type t = Type.GetType(ts);

            dynamic v1 = EntityAttrHelper.GetValue(cf, t);
            dynamic v2 = EntityAttrHelper.GetValue(ct, t);

            return v1 >= v2;
        }
        private static bool LTE(string cf, string ct, string ts)
        {
            Type t = Type.GetType(ts);

            dynamic v1 = EntityAttrHelper.GetValue(cf, t);
            dynamic v2 = EntityAttrHelper.GetValue(ct, t);

            return v1 <= v2;
        }
    }
}
