﻿using System.Collections.Generic;
using System.Linq;

namespace BVTC.Service.Data
{
    public class SimulatorDAO
    {
        public void ExecuteSql(string cmd)
        {
            using (var cntx = new Models.Simulator.SimulatorEntities())
            {
                cntx.Database.ExecuteSqlCommand(cmd);
            }
        }
        
        public Dictionary<int, string> GetTrace(string sid, int lastid)
        {
            var ret = new Dictionary<int, string>();

            foreach(var tt in new Models.Simulator.SimulatorEntities().EstimateTracings.Where(x => x.Id > lastid && x.SessionId == sid).ToList())
            {
                ret.Add(tt.Id, tt.TracingMsg);
            }
            return ret;
        }
    }
}
