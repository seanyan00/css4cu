﻿using System;

namespace BVTC.Service.Data.Extensions
{
    public class EntityAttrHelper
    {
        public static Type GetEdmType(string typename)
        {
            switch (typename)
            {

                case "Edm.String": return typeof(string);
                case "Edm.Byte": return typeof(byte);
                case "Edm.SByte": return typeof(sbyte);
                case "Edm.Int16": return typeof(short);
                case "Edm.Int32": return typeof(int);
                case "Edm.Int64": return typeof(long);
                case "Edm.Double": return typeof(double);
                case "Edm.Single": return typeof(float);
                case "Edm.Boolean": return typeof(bool);
                case "Edm.Decimal": return typeof(decimal);
                case "Edm.DateTime": return typeof(DateTime);
        
                default: throw new NotSupportedException("Not supported type " + typename);
            }
        }

        public static T GetValue<T>(string v)
        {
            return (T)Convert.ChangeType(v, typeof(T));
        }
        public static dynamic GetValue(dynamic obj, Type t)
        {
            if (obj == null || Convert.ToString(obj) == "")
                return GetDefaultValue(t);

            Type temp = Nullable.GetUnderlyingType(t);

            return temp == null ? Convert.ChangeType(obj, t) : Convert.ChangeType(obj, temp);
        }
        public static int GetIntValue(string v)
        {
            return Convert.ToInt32(v);
        }
        public static Int16 GetInt16Value(string v)
        {
            return Convert.ToInt16(v);
        }
        public static Byte GetByteValue(string v)
        {
            return Convert.ToByte(v);
        }
        public static SByte GetSByteValue(string v)
        {
            return Convert.ToSByte(v);
        }
        public static Int64 GetInt64Value(string v)
        {
            return Convert.ToInt64(v);
        }
        public static Single GetSingleValue(string v)
        {
            return Convert.ToSingle(v);
        }
        public static Double GetDoubleValue(string v)
        {
            return Convert.ToDouble(v);
        }
        public static Boolean GetBooleanValue(string v)
        {
            return Convert.ToBoolean(v);
        }
        public static Decimal GetDecimalValue(string v)
        {
            return Convert.ToDecimal(v);
        }
        public static DateTime GetDateTimeValue(string v)
        {
            if (string.IsNullOrEmpty(v))
                return DateTime.ParseExact("01/01/1900 00:00:01", "MM/dd/yyyy HH:mm:ss", null);

            if(v.Length > 10)
               return DateTime.ParseExact(v, "MM/dd/yyyy HH:mm:ss", null);
            return DateTime.ParseExact(v, "MM/dd/yyyy", null);
        }
        public static string SetDateTimeValue(DateTime v)
        {
            return string.Format("{0:MM/dd/yyyy HH:mm:ss}", v);
        }
        public static string SetValue(object v)
        {
            if (v.GetType() == typeof(DateTime))
                return string.Format("{0:MM/dd/yyyy HH:mm:ss}", v);

            return v.ToString();
        }
        
        public static object GetDefaultValue(Type t)
        {
            if (t.FullName == "System.DateTime") 
                return DateTime.ParseExact("01/01/1900 00:00:01", "MM/dd/yyyy HH:mm:ss", null);

            if (t.IsValueType && Nullable.GetUnderlyingType(t) == null)
                return Activator.CreateInstance(t);

            if (t.FullName == "System.String")
                return String.Empty;
           
            return null;
        }
    }
}
