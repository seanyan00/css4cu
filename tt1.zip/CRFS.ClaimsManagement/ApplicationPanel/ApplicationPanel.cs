﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AdministrativeTools;

namespace CRFS.UI.ClaimsManagement
{
    public partial class ApplicationPanel : Form
    {
        private string _appMode;
        private string _securityUserGroup;
        private string _userID;
        private string _userName;

        private int _securityUserGroupLevel;
        private int _userUniqueID;

        private CRFS.Data.DataFunctions _cdf;
        private DataTable _userAdminRights = new DataTable("AdminRights");
        private int _maxFormID = 11; //When a new form (application) is added, this value should be set to match that ID
        private Form _frmClaimsManagment;

        public ApplicationPanel(string appMode, int securityUserGroupLevel, string securityUserGroup, string userName, string userID, int userUniqueID, Form frmClaimsManagement)
        {
            InitializeComponent();

            _appMode = appMode;
            _securityUserGroup = securityUserGroup;
            _securityUserGroupLevel = securityUserGroupLevel;
            _userID = userID;
            _userName = userName;
            _userUniqueID = userUniqueID;
        
            _cdf = new CRFS.Data.DataFunctions(_appMode);
            _userAdminRights = _cdf.ApplicationAccess_Get(_userUniqueID);

            _frmClaimsManagment = frmClaimsManagement;
        }

        private void frmApplicationPanel_Load(object sender, EventArgs e)
        {
            try
            {
                refreshAppPanel();
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void refreshAppPanel()
        {
            try
            {
                this.Text = this.Text + " - " + _appMode;
                lblAppPanelWelcome.Text = "Welcome " + _userName;

                if (_appMode != "Production")
                {
                    this.Text = this.Text + " - " + _appMode;
                }

                this.ststxtGeneral.Text = "";
                this.stsFiller.Text = "";

                Form frmAppPanel = this;

                switch (_appMode)
                {
                    case "Testing":
                        txtNotProdWarning.Text = "THIS IS THE TEST REGION...";
                        txtNotProdWarning.Visible = true;
                        break;
                    case "Development":
                        txtNotProdWarning.Text = "THIS IS THE DEV REGION...";
                        txtNotProdWarning.Visible = true;
                        break;
                    default:
                        txtNotProdWarning.Visible = false;
                        break;
                }

                //Show/Hide Application Administration menu item based on user's admin rights
                DataView dvUserRights = new DataView(_userAdminRights);
                string UserRightsFilter = "IsAllowedAdmin = true OR IsAllowedUserAdmin = true OR IsAllowedLockAdmin = true OR ";
                UserRightsFilter = UserRightsFilter + "IsAllowedAppAccessAdmin = true OR IsAllowedServicer_MI_Admin = true";

                dvUserRights.RowFilter = (UserRightsFilter);

                if (dvUserRights.Count > 0)
                {
                    //The logged in user has some type of admin rights, they need access to the  admin tools menu item
                    mnuAdmin.Visible = true;
                    mnuAdmin.Enabled = true;
                }
                else
                {
                    //The logged in user has no admin rights, the admin tools menu item needs to be invisible and disabled
                    mnuAdmin.Visible = false;
                    mnuAdmin.Enabled = false;
                }

                //Enable the application modules that the user is granted access to.
                DataView dvUserAccess = new DataView(_userAdminRights);
                if (dvUserAccess.Count > 0)
                {
                    //evaluate access for each form
                    for (int i = 1; i <= _maxFormID; i++)
                    {
                        dvUserAccess.RowFilter = ("UserID = " + _userUniqueID + " AND FormID = " + i + " AND IsAppUser = true");

                        switch (i)
                        {
                            case 6: //Claims 332
                                //NOTE: For the time being, Claims332 and Investor Tracking are
                                //      set available by default because application access has not yet been
                                //      implemented for those modules.
                                //if (dvUserAccess.Count > 0)
                                //{
                                //    //Enable application access
                                    btnClaims332.Enabled = true;
                                //}
                                //else
                                //{
                                //    //Disable application access
                                //    btnClaims332.Enabled = false;
                                //}
                                break;

                            case 8: //Investor Tracking
                                //if (dvUserAccess.Count > 0)
                                //{
                                //    //Enable application access
                                    btnInvestorTracking.Enabled = true;
                                //}
                                //else
                                //{
                                //    //Disable application access
                                //    btnInvestorTracking.Enabled = false;
                                //}
                                break;

                            case 9: //FNMA PFU
                                if (dvUserAccess.Count > 0)
                                {
                                    //Enable application access
                                    btnFNMA_Reconciliation.Enabled = true;
                                }
                                else
                                {
                                    //Disable application access
                                    btnFNMA_Reconciliation.Enabled = false;
                                }
                                break;

                            case 10: //FNMA Recon
                                if (dvUserAccess.Count > 0)
                                {
                                    //Enable application access
                                    btnFNMA_Reconciliation.Enabled = true;
                                }
                                else
                                {
                                    //Disable application access
                                    btnFNMA_Reconciliation.Enabled = false;
                                }
                                break;

                            case 11: //FNMA Asset Collections
                                if (dvUserAccess.Count > 0)
                                {
                                    //Enable application access
                                    btnFNMA_AssetCollections.Enabled = true;
                                }
                                else
                                {
                                    //Disable application access
                                    btnFNMA_AssetCollections.Enabled = false;
                                }
                                break;
                            default:
                                //We get here when contol access has not been defined for an application (formID)
                                //Do nothing
                                break;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        private void btnClaims332_Click(object sender, EventArgs e)
        {
            this.ststxtGeneral.Text = "Loading Claims332...";
            this.Visible = false;
            _frmClaimsManagment.ShowDialog(this);
            this.Visible = true;
        }

        private void btnInvestorTracking_Click(object sender, EventArgs e)
        {
            this.ststxtGeneral.Text = "Loading Investor Traking...";
            this.Visible = false;
            _frmClaimsManagment.ShowDialog(this);
            this.Visible = true;
        }

        private void btnFNMA_PFU_Click(object sender, EventArgs e)
        {
            this.ststxtGeneral.Text = "Loading FNMA Payment Follow Up...";
            this.Visible = false;
            _frmClaimsManagment.ShowDialog(this);
            this.Visible = true;
        }

        private void btnFNMA_Reconciliation_Click(object sender, EventArgs e)
        {
            this.ststxtGeneral.Text = "Loading FNMA Reconciliation...";
            this.Visible = false;

            //Using this same method to get to Recon for now. Eventually, we want to call the separate Recon proect object.
            //The object is there, but needs to be wired up. Code to call the Recon project form is below, commented off.
            //The Recon_Find routine will also need to change to return the referral ID and NOT open the application form.
            _frmClaimsManagment.ShowDialog(this);
            //fmFNMAReconciliation = new FNMAReconciliation(_appMode, claimID, _curUserUniqueID, _curUserID, _curUserSecurityLevel, _curUserName, this, _cmMainForm, _cdf, _events, newForm);
            //fmFNMAReconciliation.ShowDialog(this);
            //fmFNMAReconciliation.Select();
            
            this.Visible = true;
        }

        private void btnFNMA_AssetCollections_Click(object sender, EventArgs e)
        {
            this.ststxtGeneral.Text = "Loading FNMA Asset Collections...";
            this.Visible = false;

            frmFNMA_AssetCollectionsUserPanel frmFNMA_AssetCollections = new frmFNMA_AssetCollectionsUserPanel(_appMode, _securityUserGroupLevel, _securityUserGroup, _userName, _userID, _userUniqueID);
            frmFNMA_AssetCollections.ShowDialog(this);
            //Set the referralID selected in a dialog property
            //After the dialog comes back, pass the referralID, along with other params above into the application form as ShowDialog(this) also
            //When that returns,, make the AppPanel form visible again as below and we're done!
            
            this.Visible = true;
        }

        #region Menus
        private void mnuFile_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void mnuAdmin_Click(object sender, EventArgs e)
        {
            try
            {
                frmAdministrativeTools frmAdmin = new frmAdministrativeTools(_appMode, _userUniqueID, _userID, _securityUserGroupLevel, _userName, _userAdminRights);
                frmAdmin.Show();
                frmAdmin.Select();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        
        /// <summary>
        /// Display the About dialog with the application info
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mnuHelp_About_Click(object sender, EventArgs e)
        {
            try
            {
                MessageBox.Show("Not yet implemented.", "About", MessageBoxButtons.OK);
                //CRFSAbout.AboutApp cms = new CRFSAbout.AboutApp();
                //cms.ShowDialog();
                //cms.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion
    }
}