﻿//namespace CRFS.UI.ApplicationPanel
namespace CRFS.UI.ClaimsManagement
{
    partial class ApplicationPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAppPanelWelcome = new System.Windows.Forms.Label();
            this.menuStripMain = new System.Windows.Forms.MenuStrip();
            this.mnuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFile_Exit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAdmin = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuHelp_About = new System.Windows.Forms.ToolStripMenuItem();
            this.btnClaims332 = new System.Windows.Forms.Button();
            this.btnInvestorTracking = new System.Windows.Forms.Button();
            this.btnFNMA_PFU = new System.Windows.Forms.Button();
            this.btnFNMA_Reconciliation = new System.Windows.Forms.Button();
            this.btnFNMA_AssetCollections = new System.Windows.Forms.Button();
            this.txtNotProdWarning = new System.Windows.Forms.TextBox();
            this.stsMain = new System.Windows.Forms.StatusStrip();
            this.ststxtGeneral = new System.Windows.Forms.ToolStripStatusLabel();
            this.stsFiller = new System.Windows.Forms.ToolStripStatusLabel();
            this.stsProgress = new System.Windows.Forms.ToolStripProgressBar();
            this.pnlMain = new System.Windows.Forms.TableLayoutPanel();
            this.pnlWelcome = new System.Windows.Forms.Panel();
            this.pnlKansas = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.menuStripMain.SuspendLayout();
            this.stsMain.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.pnlWelcome.SuspendLayout();
            this.pnlKansas.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblAppPanelWelcome
            // 
            this.lblAppPanelWelcome.AutoSize = true;
            this.lblAppPanelWelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAppPanelWelcome.Location = new System.Drawing.Point(3, 3);
            this.lblAppPanelWelcome.Name = "lblAppPanelWelcome";
            this.lblAppPanelWelcome.Size = new System.Drawing.Size(87, 20);
            this.lblAppPanelWelcome.TabIndex = 0;
            this.lblAppPanelWelcome.Text = "Welcome ";
            // 
            // menuStripMain
            // 
            this.menuStripMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFile,
            this.mnuAdmin,
            this.mnuHelp});
            this.menuStripMain.Location = new System.Drawing.Point(0, 0);
            this.menuStripMain.Name = "menuStripMain";
            this.menuStripMain.Size = new System.Drawing.Size(369, 24);
            this.menuStripMain.TabIndex = 1;
            // 
            // mnuFile
            // 
            this.mnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFile_Exit});
            this.mnuFile.Name = "mnuFile";
            this.mnuFile.Size = new System.Drawing.Size(35, 20);
            this.mnuFile.Text = "&File";
            // 
            // mnuFile_Exit
            // 
            this.mnuFile_Exit.Name = "mnuFile_Exit";
            this.mnuFile_Exit.Size = new System.Drawing.Size(103, 22);
            this.mnuFile_Exit.Text = "E&xit";
            this.mnuFile_Exit.Click += new System.EventHandler(this.mnuFile_Exit_Click);
            // 
            // mnuAdmin
            // 
            this.mnuAdmin.Name = "mnuAdmin";
            this.mnuAdmin.Size = new System.Drawing.Size(48, 20);
            this.mnuAdmin.Text = "&Admin";
            this.mnuAdmin.Click += new System.EventHandler(this.mnuAdmin_Click);
            // 
            // mnuHelp
            // 
            this.mnuHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuHelp_About});
            this.mnuHelp.Name = "mnuHelp";
            this.mnuHelp.Size = new System.Drawing.Size(40, 20);
            this.mnuHelp.Text = "&Help";
            // 
            // mnuHelp_About
            // 
            this.mnuHelp_About.Name = "mnuHelp_About";
            this.mnuHelp_About.Size = new System.Drawing.Size(114, 22);
            this.mnuHelp_About.Text = "&About";
            this.mnuHelp_About.Click += new System.EventHandler(this.mnuHelp_About_Click);
            // 
            // btnClaims332
            // 
            this.btnClaims332.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClaims332.Location = new System.Drawing.Point(68, 5);
            this.btnClaims332.Name = "btnClaims332";
            this.btnClaims332.Size = new System.Drawing.Size(210, 50);
            this.btnClaims332.TabIndex = 2;
            this.btnClaims332.Text = "Claims 332";
            this.btnClaims332.UseVisualStyleBackColor = true;
            this.btnClaims332.Click += new System.EventHandler(this.btnClaims332_Click);
            // 
            // btnInvestorTracking
            // 
            this.btnInvestorTracking.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInvestorTracking.Location = new System.Drawing.Point(68, 3);
            this.btnInvestorTracking.Name = "btnInvestorTracking";
            this.btnInvestorTracking.Size = new System.Drawing.Size(210, 50);
            this.btnInvestorTracking.TabIndex = 3;
            this.btnInvestorTracking.Text = "Investor Tracking";
            this.btnInvestorTracking.UseVisualStyleBackColor = true;
            this.btnInvestorTracking.Click += new System.EventHandler(this.btnInvestorTracking_Click);
            // 
            // btnFNMA_PFU
            // 
            this.btnFNMA_PFU.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFNMA_PFU.Location = new System.Drawing.Point(68, 5);
            this.btnFNMA_PFU.Name = "btnFNMA_PFU";
            this.btnFNMA_PFU.Size = new System.Drawing.Size(210, 50);
            this.btnFNMA_PFU.TabIndex = 4;
            this.btnFNMA_PFU.Text = "FNMA PFU";
            this.btnFNMA_PFU.UseVisualStyleBackColor = true;
            this.btnFNMA_PFU.Click += new System.EventHandler(this.btnFNMA_PFU_Click);
            // 
            // btnFNMA_Reconciliation
            // 
            this.btnFNMA_Reconciliation.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFNMA_Reconciliation.Location = new System.Drawing.Point(68, 5);
            this.btnFNMA_Reconciliation.Name = "btnFNMA_Reconciliation";
            this.btnFNMA_Reconciliation.Size = new System.Drawing.Size(210, 50);
            this.btnFNMA_Reconciliation.TabIndex = 5;
            this.btnFNMA_Reconciliation.Text = "FNMA Reconciliation";
            this.btnFNMA_Reconciliation.UseVisualStyleBackColor = true;
            this.btnFNMA_Reconciliation.Click += new System.EventHandler(this.btnFNMA_Reconciliation_Click);
            // 
            // btnFNMA_AssetCollections
            // 
            this.btnFNMA_AssetCollections.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFNMA_AssetCollections.Location = new System.Drawing.Point(68, 5);
            this.btnFNMA_AssetCollections.Name = "btnFNMA_AssetCollections";
            this.btnFNMA_AssetCollections.Size = new System.Drawing.Size(210, 50);
            this.btnFNMA_AssetCollections.TabIndex = 6;
            this.btnFNMA_AssetCollections.Text = "FNMA Asset Collections";
            this.btnFNMA_AssetCollections.UseVisualStyleBackColor = true;
            this.btnFNMA_AssetCollections.Click += new System.EventHandler(this.btnFNMA_AssetCollections_Click);
            // 
            // txtNotProdWarning
            // 
            this.txtNotProdWarning.BackColor = System.Drawing.SystemColors.Control;
            this.txtNotProdWarning.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtNotProdWarning.Font = new System.Drawing.Font("Microsoft Sans Serif", 19F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNotProdWarning.ForeColor = System.Drawing.Color.Red;
            this.txtNotProdWarning.Location = new System.Drawing.Point(0, 0);
            this.txtNotProdWarning.Multiline = true;
            this.txtNotProdWarning.Name = "txtNotProdWarning";
            this.txtNotProdWarning.ReadOnly = true;
            this.txtNotProdWarning.Size = new System.Drawing.Size(363, 66);
            this.txtNotProdWarning.TabIndex = 8;
            this.txtNotProdWarning.TabStop = false;
            this.txtNotProdWarning.Text = "THIS IS NOT KANSAS";
            this.txtNotProdWarning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // stsMain
            // 
            this.stsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ststxtGeneral,
            this.stsFiller,
            this.stsProgress});
            this.stsMain.Location = new System.Drawing.Point(0, 479);
            this.stsMain.Name = "stsMain";
            this.stsMain.Padding = new System.Windows.Forms.Padding(1, 0, 10, 0);
            this.stsMain.Size = new System.Drawing.Size(369, 22);
            this.stsMain.TabIndex = 9;
            this.stsMain.Text = "statusStrip1";
            // 
            // ststxtGeneral
            // 
            this.ststxtGeneral.Name = "ststxtGeneral";
            this.ststxtGeneral.Size = new System.Drawing.Size(109, 17);
            this.ststxtGeneral.Text = "toolStripStatusLabel1";
            // 
            // stsFiller
            // 
            this.stsFiller.Name = "stsFiller";
            this.stsFiller.Size = new System.Drawing.Size(172, 17);
            this.stsFiller.Spring = true;
            // 
            // stsProgress
            // 
            this.stsProgress.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.stsProgress.Name = "stsProgress";
            this.stsProgress.Size = new System.Drawing.Size(75, 16);
            this.stsProgress.Step = 1;
            // 
            // pnlMain
            // 
            this.pnlMain.ColumnCount = 1;
            this.pnlMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.pnlMain.Controls.Add(this.pnlWelcome, 0, 0);
            this.pnlMain.Controls.Add(this.pnlKansas, 0, 1);
            this.pnlMain.Controls.Add(this.panel1, 0, 2);
            this.pnlMain.Controls.Add(this.panel2, 0, 3);
            this.pnlMain.Controls.Add(this.panel3, 0, 4);
            this.pnlMain.Controls.Add(this.panel4, 0, 5);
            this.pnlMain.Controls.Add(this.panel5, 0, 6);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Location = new System.Drawing.Point(0, 24);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.RowCount = 7;
            this.pnlMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.pnlMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.pnlMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.pnlMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.pnlMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.pnlMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.pnlMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.pnlMain.Size = new System.Drawing.Size(369, 455);
            this.pnlMain.TabIndex = 10;
            // 
            // pnlWelcome
            // 
            this.pnlWelcome.Controls.Add(this.lblAppPanelWelcome);
            this.pnlWelcome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlWelcome.Location = new System.Drawing.Point(3, 3);
            this.pnlWelcome.Name = "pnlWelcome";
            this.pnlWelcome.Size = new System.Drawing.Size(363, 26);
            this.pnlWelcome.TabIndex = 0;
            // 
            // pnlKansas
            // 
            this.pnlKansas.Controls.Add(this.txtNotProdWarning);
            this.pnlKansas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlKansas.Location = new System.Drawing.Point(3, 35);
            this.pnlKansas.Name = "pnlKansas";
            this.pnlKansas.Size = new System.Drawing.Size(363, 66);
            this.pnlKansas.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnClaims332);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 107);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(363, 64);
            this.panel1.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnInvestorTracking);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 177);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(363, 64);
            this.panel2.TabIndex = 3;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnFNMA_PFU);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 247);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(363, 64);
            this.panel3.TabIndex = 4;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnFNMA_Reconciliation);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(3, 317);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(363, 64);
            this.panel4.TabIndex = 5;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btnFNMA_AssetCollections);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(3, 387);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(363, 65);
            this.panel5.TabIndex = 6;
            // 
            // frmApplicationPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(369, 501);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.stsMain);
            this.Controls.Add(this.menuStripMain);
            this.MainMenuStrip = this.menuStripMain;
            this.Name = "frmApplicationPanel";
            this.Text = "CRFS Claims Management";
            this.Load += new System.EventHandler(this.frmApplicationPanel_Load);
            this.menuStripMain.ResumeLayout(false);
            this.menuStripMain.PerformLayout();
            this.stsMain.ResumeLayout(false);
            this.stsMain.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.pnlWelcome.ResumeLayout(false);
            this.pnlWelcome.PerformLayout();
            this.pnlKansas.ResumeLayout(false);
            this.pnlKansas.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAppPanelWelcome;
        private System.Windows.Forms.MenuStrip menuStripMain;
        private System.Windows.Forms.ToolStripMenuItem mnuFile;
        private System.Windows.Forms.ToolStripMenuItem mnuAdmin;
        private System.Windows.Forms.ToolStripMenuItem mnuHelp;
        private System.Windows.Forms.ToolStripMenuItem mnuHelp_About;
        private System.Windows.Forms.Button btnClaims332;
        private System.Windows.Forms.Button btnInvestorTracking;
        private System.Windows.Forms.Button btnFNMA_PFU;
        private System.Windows.Forms.Button btnFNMA_Reconciliation;
        private System.Windows.Forms.Button btnFNMA_AssetCollections;
        private System.Windows.Forms.ToolStripMenuItem mnuFile_Exit;
        private System.Windows.Forms.TextBox txtNotProdWarning;
        private System.Windows.Forms.StatusStrip stsMain;
        private System.Windows.Forms.ToolStripStatusLabel ststxtGeneral;
        private System.Windows.Forms.ToolStripStatusLabel stsFiller;
        private System.Windows.Forms.ToolStripProgressBar stsProgress;
        private System.Windows.Forms.TableLayoutPanel pnlMain;
        private System.Windows.Forms.Panel pnlWelcome;
        private System.Windows.Forms.Panel pnlKansas;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
    }
}

