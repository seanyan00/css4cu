﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClaimProcessingConstants
{
    public class ClaimsManagementSystem
    {
        public enum FormID
        {
            Claims332 = 6,
            InvestorTracking = 8,
            FNMAPaymentFollowup = 9,
            FNMAReconciliation = 10,
            FNMADataGram = 11
        }

        public enum AppID
        {
            FNMAAdvancedPayment = 1,
            HUDClaims = 2,
            LossAnalysis = 3,
            Docuware1 = 4,
            Docuware2 = 5,
            Docuware4 = 7,
            Wells332Claims = 8,
            InvestorTracking = 9,
            FNMAMIPaymentFollowup = 10,
            FNMAReconciliation = 11,
            FNMAREOGram = 12,
            CRFSBilling = 13,
            WFBI = 14,
            FannieMae571 = 15,
            Title1 = 16,
            ClaimReconcileInfo = 17,
            CMS = 18,
            Imports = 19,
            DataAutomation = 20,
            KQIScoringDistribution = 21,
            FHASupplementalImport = 22,
            LossAnalysisImports = 23
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FormName"></param>
        /// <returns></returns>
        public int FormNameASAppID(string FormName)
        {
            int rtnValue;

            switch (FormName)
            {
                case "Claims332":
                    rtnValue = (int)AppID.Wells332Claims;
                    break;

                case "InvestorTracking":
                    rtnValue = (int)AppID.InvestorTracking;
                    break;

                case "FNMAPaymentFollowup":
                    rtnValue = (int)AppID.FNMAMIPaymentFollowup;
                    break;

                case "FNMAReconciliation":
                    rtnValue = (int)AppID.FNMAReconciliation;
                    break;

                case "FNMADataGram":
                    rtnValue = (int)AppID.FNMAREOGram;
                    break;

                default:
                    throw new Exception("Form name is not configured to return an ApplicationID: " + FormName);
            }

            return rtnValue;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="formID"></param>
        /// <returns></returns>
        public int FormIDASAppID(int formID)
        {
            int rtnValue;

            switch (formID)
            {
                case (int)FormID.Claims332:
                    rtnValue = (int)AppID.Wells332Claims;
                    break;

                case (int)FormID.InvestorTracking:
                    rtnValue = (int)AppID.InvestorTracking;
                    break;

                case (int)FormID.FNMAPaymentFollowup:
                    rtnValue = (int)AppID.FNMAMIPaymentFollowup;
                    break;

                case (int)FormID.FNMAReconciliation:
                    rtnValue = (int)AppID.FNMAReconciliation;
                    break;

                case (int)FormID.FNMADataGram:
                    rtnValue = (int)AppID.FNMAREOGram;
                    break;

                default:
                    throw new Exception("FormID is not configured to return an ApplicationID: " + formID.ToString());
            }

            return rtnValue;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="AppName"></param>
        /// <returns></returns>
        public int AppNameAsFormID(string AppName)
        {
            int rtnValue;

            switch (AppName)
            {
                case "Wells332Claims":
                    rtnValue = (int)FormID.Claims332;
                    break;

                case "InvestorTracking":
                    rtnValue = (int)FormID.InvestorTracking;
                    break;

                case "FNMAMIPaymentFollowup":
                    rtnValue = (int)FormID.FNMAPaymentFollowup;
                    break;

                case "FNMAReconciliation":
                    rtnValue = (int)FormID.FNMAReconciliation;
                    break;

                case "FNMAREOGram":
                    rtnValue = (int)FormID.FNMADataGram;
                    break;

                default:
                    throw new Exception("App name is not configured to return a FormID: " + AppName);
            }

            return rtnValue;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="appID"></param>
        /// <returns></returns>
        public int AppIDAsFormID(int appID)
        {
            int rtnValue;

            switch (appID)
            {
                case (int)AppID.Wells332Claims:
                    rtnValue = (int)FormID.Claims332;
                    break;

                case (int)AppID.InvestorTracking:
                    rtnValue = (int)FormID.InvestorTracking;
                    break;

                case (int)AppID.FNMAMIPaymentFollowup:
                    rtnValue = (int)FormID.FNMAPaymentFollowup;
                    break;

                case (int)AppID.FNMAReconciliation:
                    rtnValue = (int)FormID.FNMAReconciliation;
                    break;

                case (int)AppID.FNMAREOGram:
                    rtnValue = (int)FormID.FNMADataGram;
                    break;

                default:
                    throw new Exception("AppID is not configured to return a FormID: " + appID.ToString());
            }

            return rtnValue;
        }

    }
}
