﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CRFS.ConcurrencyMessage
{
    public partial class frmConcurrencyMessage : Form
    {
        public frmConcurrencyMessage()
        {
            InitializeComponent();
        }

        public static void DisplayMessage(SqlException ex)
        {
            if (ex.Message.Contains("Concurrency Error"))
            {
                MessageBox.Show("Concurrency Error: Changes since your last save have been lost.  \nRe-enter your changes after claim loads", "Concurrency Error");
            }
            else
            {
                throw ex;
            }

        }
    }
}
