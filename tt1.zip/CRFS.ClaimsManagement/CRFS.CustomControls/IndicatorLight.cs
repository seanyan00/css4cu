using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace CRFS.CustomControls
{
    // develop simple control https://msdn.microsoft.com/en-us/library/649xahhe.aspx
    // draw a filled elipse https://msdn.microsoft.com/en-us/library/h34kh0x2%28v=vs.110%29.aspx
    public partial class IndicatorLight : Control
    {
        public IndicatorLight()
        {
            InitializeComponent();
            onColor = System.Drawing.Color.Red;
            offColor = System.Drawing.Color.Transparent;
            textAnchor = DockStyle.Left;
            lit = true;
            phong = false;
        }

        // properties
        System.Drawing.Color _onColor;
        public System.Drawing.Color onColor { get { return _onColor; } set { _onColor = value; Invalidate(); } }

        System.Drawing.Color _offColor;
        public System.Drawing.Color offColor { get { return _offColor; } set { _offColor = value; Invalidate(); } }

        System.Windows.Forms.DockStyle _textAnchor;
        public System.Windows.Forms.DockStyle textAnchor { get { return _textAnchor; } set { _textAnchor = value; Invalidate(); } }

        bool _lit;
        public bool lit { get { return _lit; } set { _lit = value; Invalidate(); } }

        bool _phong;
        public bool phong { get { return _phong; } set { _phong = value; Invalidate(); } }

        protected override void OnPaint(PaintEventArgs pe)
        {
            base.OnPaint(pe);
            System.Drawing.SolidBrush myBrush = new System.Drawing.SolidBrush((lit)?onColor:offColor);
            System.Drawing.Graphics formGraphics = pe.Graphics;
            SizeF s = formGraphics.MeasureString(Text, Font);
            int nh = (int)(Size.Height -(s.Height*1.0));
            int rad = nh / 2;
            Rectangle r = new Rectangle(0, 0, 1, 1);
            switch (textAnchor)
            {
                case DockStyle.Bottom:
                    r= new Rectangle(Size.Width/2-rad, 0, nh, nh);
                    formGraphics.DrawString( Text, Font, new SolidBrush(ForeColor), new Rectangle((int)(Size.Width/2-s.Width/2)+1,nh,Size.Width,Size.Height));
                    break;

                case DockStyle.Top:
                    r= new Rectangle(Size.Width/2-rad, Size.Height-nh, nh, nh);
                    formGraphics.DrawString( Text, Font, new SolidBrush(ForeColor), new Rectangle((int)(Size.Width/2-s.Width/2)+1,0,Size.Width,nh));
                    break;

                case DockStyle.Right:
                    r=new Rectangle(0, 0, Size.Height, Size.Height);
                    formGraphics.DrawString( Text, Font, new SolidBrush(ForeColor), new Rectangle(Size.Height,(int)(Size.Height/2-s.Height/2),Size.Width,Size.Height));
                    break;

                case DockStyle.Left:
                default:
                    r= new Rectangle(Size.Width-Size.Height, 0, Size.Height, Size.Height);
                    formGraphics.DrawString( Text, Font, new SolidBrush(ForeColor), new Rectangle(0,(int)(Size.Height/2-s.Height/2),Size.Width-Size.Height,Size.Height));
                    break;
            }
            if ((!lit)||(!phong))
            {
                formGraphics.FillEllipse(myBrush, r);
            }
            else
            {
                // give a phong effect, maybe looks a little better
                // http://www.codeproject.com/Articles/20018/Gradients-made-easy
                GraphicsPath gp = new GraphicsPath();
                gp.AddEllipse(r);

                PathGradientBrush pgb = new PathGradientBrush(gp);

                pgb.CenterPoint = new PointF(r.X +rad, r.Y +rad);
                pgb.CenterColor = onColor;
                pgb.SurroundColors = new Color[] { Color.Transparent };
                pgb.SetBlendTriangularShape(.5f, 1.0f);
                pgb.FocusScales = new PointF(0f, 0f);

                formGraphics.FillPath(pgb, gp);

                pgb.Dispose();
                gp.Dispose();
            }
            myBrush.Dispose();
            formGraphics.Dispose();
        }
    }
}
