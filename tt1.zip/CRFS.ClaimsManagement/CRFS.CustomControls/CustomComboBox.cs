﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CRFS.CustomControls
{
    public partial class CustomComboBox : ComboBox
    {
        private string _grayFilter = null;             // if set tells which items to gray out
        private string _normalFilter = null;           // if set tells which items to display normally
        private bool overrideEnable = false;           // override checking if an item is enabled for when you set SelectedIndex
        private object initialValue = null;            // initial value to set the checkbox to
        private int normalheight;                      // normal height for opening
        private bool _noOpen = false;                  // if we should suppress opening

        private bool isGray(int rownum)
        {
            if (rownum < 0) return false;
            if (DataSource == null) return false;
            DataView dv;
            if (DataSource.GetType() == typeof(DataView))
            {
                DataView ldv = (DataView)DataSource;
                DataTable dt = ldv.Table.Clone();
                dt.ImportRow(ldv[rownum].Row);
                dv = new DataView(dt);
            }
            else if (DataSource.GetType() == typeof(DataTable))
            {
                DataTable ldt = (DataTable)DataSource;
                DataTable dt = ldt.Clone();
                dt.ImportRow(ldt.Rows[rownum]);
                dv = new DataView(dt);
            }
            else
            {
                return false;
            }
            if (grayFilter != null)
            {
                dv.RowFilter = grayFilter;
                return dv.Count > 0;
            }
            else if (normalFilter != null)
            {
                dv.RowFilter = normalFilter;
                return dv.Count == 0;
            }
            return false;
        }

        /// <summary>
        /// sets a rowfilter to gray out entries in the combo box, all others are normal
        /// </summary>
        public String grayFilter
        {
            get { return _grayFilter; }
            set
            {
                _normalFilter = null;
                _grayFilter = value;
            }
        }

        /// <summary>
        /// sets a row filter for entries in the combo box to be normal, all others are grayed
        /// </summary>
        public String normalFilter
        {
            get { return _normalFilter; }
            set
            {
                _grayFilter = null;
                _normalFilter = value;
            }
        }


        public bool noOpen
        {
            get { return _noOpen; }
            set
            {
                _noOpen = value;
                DropDownHeight = (_noOpen) ? 1 : normalheight;
            }
        }
        /// <summary>
        /// ComboBox that allows for non-selectable items
        /// </summary>
        public CustomComboBox()
        {
            InitializeComponent();
            this.DrawItem += new DrawItemEventHandler(CCBDrawItem);
            this.SelectedIndexChanged += new EventHandler(CCBSelectedIndexChanged);
            this.DrawMode = DrawMode.OwnerDrawFixed;
            this.normalheight = DropDownHeight;
        }

        protected override void OnPaint(PaintEventArgs pe)
        {
            base.OnPaint(pe);
        }


        // gk 15847 20150415 disallow them from clicking on grayed out items
        protected override void OnSelectedValueChanged(EventArgs e)
        {
            if (!isGray(SelectedIndex) || overrideEnable || DataSource == null || SelectedIndex == -1 || SelectedValue==initialValue)
                base.OnSelectedValueChanged(e);
            else
            {
                try
                {
                    overrideEnable = true;
                    if (initialValue != null)
                        SelectedValue = initialValue;
                    else
                        SelectedIndex = -1;

                }
                finally
                {
                    overrideEnable = false;
                }
            }
        }

        protected override void OnSelectedIndexChanged(EventArgs e)
        {
            if (!isGray(SelectedIndex) || overrideEnable || DataSource == null || SelectedIndex == -1 || SelectedValue==initialValue)
                base.OnSelectedIndexChanged(e);
            else
            {
                try
                {
                    overrideEnable = true;
                    if (initialValue != null)
                        SelectedValue = initialValue;
                    else
                        SelectedIndex = -1;
                }
                finally
                {
                    overrideEnable = false;
                }
            }
        }

        public override int SelectedIndex
        {
        
            get
            {
                return base.SelectedIndex;
            }
            set
            {
                if (isGray(value) && !overrideEnable)
                    value = -1;
                if (value != base.SelectedIndex)
                {
                    base.SelectedIndex = value;
                }
            }
        }
        // end gk 15847 20150415 disallow them from clicking on grayed out items



        private void CCBDrawItem(object sender, DrawItemEventArgs e)
        {
            string text = "";
            if (DataSource.GetType() == typeof(DataTable))
                text = ((DataTable)DataSource).Rows[e.Index][DisplayMember].ToString();
            if (DataSource.GetType() == typeof(DataView))
                text = ((DataView)DataSource)[e.Index][DisplayMember].ToString();
            if (!isGray(e.Index))
            {
                e.DrawBackground();
                e.Graphics.DrawString(text, Font, Brushes.Black, e.Bounds);
                e.DrawFocusRectangle();
            } else {
                e.Graphics.DrawString(text, Font, Brushes.LightGray, e.Bounds);
            }
        }

        private void CCBSelectedIndexChanged(object sender, EventArgs e)
        {
            if (!overrideEnable)
            {
                if (isGray(SelectedIndex))
                {
                    if (initialValue != null)
                        setInitialVal(initialValue);
                    else
                        SelectedIndex = -1;
                }
            }
        }

        /// <summary>
        /// set the initial value for the combo box, can set to enabled or disabled values
        /// </summary>
        /// <param name="v">the value to set the selected to</param>
        public void setInitialVal(object v) 
        {
            this.SelectedIndex = -1;
            initialValue = v;
            try
            {
                overrideEnable = true;
                DataView dv=null;
                if (DataSource != null)
                {
                    if (DataSource.GetType() == typeof(DataView))
                    {
                        dv = new DataView(((DataView)DataSource).ToTable());
                    }
                    else if (DataSource.GetType() == typeof(DataTable))
                    {
                        dv = new DataView((DataTable)DataSource);
                    }
                }
                else
                {
                    this.SelectedIndex = -1;
                    this.ResetText();
                    initialValue = null;
                    return;
                }
                if (v.GetType() == typeof(string)) 
                {
                    dv.RowFilter = ValueMember + "='" + v.ToString()+"'";
                }
                else
                {
                   dv.RowFilter = ValueMember + "=" + v.ToString()  ;
                }
                if (dv.Count > 0)
                {
                    this.SelectedValue = v;
                }
                else
                {
                    this.SelectedIndex = -1;
                    this.ResetText();
                    this.SelectedText = "";
                    initialValue = null;
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                overrideEnable = false;
            }
        }

    }
}
