﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace CRFS.Messaging
{
    public class Messaging
    {
        string _messageType;
        string[] _messageOptions;

        CRFS.Messaging.email EmailMsg;
        private string appMode;
        public string AppMode 
        { 
            get 
            { 
                return appMode; 
            } 
            set 
            {
                appMode=value;
                EmailMsg.AppMode = appMode;
            }  
        }

        public Messaging(string MessageType, string[] MessageOptions)
        {
            appMode = "Production";  // default mode to production so that sending of emails still happens if they don't set appmode
            try
            {
                _messageType = MessageType;
                _messageOptions = MessageOptions;

                //_messageOptions[0] = Path to text log file
                //_messageOptions[1] = SMTP Server for email and texting

                switch (_messageType)
                {
                    case "EMAIL":
                        EmailMsg = new email(_messageOptions[1]);
                        
                        break;

                    default:
                        break;

                }

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        public void SendMessage(string[] MessageOptions)
        {
            try
            {
                //MessageOptions[0] = log body
                //MessageOptions[1] = email/text to
                //MessageOptions[2] = email/text from
                //MessageOptions[3] = email/text subject
                //MessageOptions[4] = Path to attachment

                switch (_messageType)
                {
                    case "EMAIL":
                        if (MessageOptions.Length > 4 && MessageOptions[4].Trim().Length > 0)
                        {
                            EmailMsg.SendMessageWithAttachment(MessageOptions[1], MessageOptions[2], MessageOptions[3], MessageOptions[0], MessageOptions[4]);
                        }

                        else
                        {
                            EmailMsg.SendMessage(MessageOptions[1], MessageOptions[2], MessageOptions[3], MessageOptions[0]);
                        }

                        break;

                    default:
                        break;
                
                }

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

    }
}
