﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;

namespace CRFS.Messaging
{
    
    internal class email
    {
        string _smtpServerIP;

        public string AppMode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="smtpServerIP"></param>
        public email(string smtpServerIP)
        {
            AppMode = "Production";  // default app mode to production so we still send emails if AppMode doesn't get set
            _smtpServerIP = smtpServerIP;

        }


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        void sendtofile(MailMessage oMsg)
        {
            // see http://stackoverflow.com/questions/1264672/how-to-save-mailmessage-object-to-disk-as-eml-or-msg-file
            string pudir = @"q:\is\ProgramEmail\"+AppMode+@"\" + DateTime.UtcNow.ToString("yyyyMMdd");
            System.IO.Directory.CreateDirectory(pudir);
            SmtpClient fileclient = new SmtpClient();
            fileclient.DeliveryMethod = SmtpDeliveryMethod.SpecifiedPickupDirectory;
            fileclient.PickupDirectoryLocation = pudir;
            fileclient.Send(oMsg);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="to"></param>
        /// <param name="from"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        internal void SendMessage(string to, string from, string subject, string body)
        {
            try
            {
                MailMessage oMsg = new MailMessage(from, to);
                oMsg.Subject = subject;

                oMsg.Body = body;

                sendtofile(oMsg);

                if (AppMode == "Production")
                {
                    SmtpClient smtp = new SmtpClient();
                    smtp.Host = _smtpServerIP;
                    smtp.Send(oMsg);
                }

                oMsg.Dispose();

            }
            
            catch (Exception ex)
            {
                throw ex;
            
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="to"></param>
        /// <param name="from"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        /// <param name="fileToAttach"></param>
        internal void SendMessageWithAttachment(string to, string from, string subject, string body, string fileToAttach)
        {
            try
            {
                to = to.TrimEnd(',');
                MailMessage oMsg = new MailMessage(from, to);
                oMsg.Subject = subject;

                // 20141211 gk set if it is an html format based on if the body contains a body tag
                oMsg.IsBodyHtml = body.IndexOf("<body",StringComparison.OrdinalIgnoreCase)>=0;
                oMsg.Body = body;

                String sFile = fileToAttach;
                Attachment oAttch = new Attachment(sFile);

                oMsg.Attachments.Add(oAttch);

                sendtofile(oMsg);

                if (AppMode == "Production")
                {
                    SmtpClient smtp = new SmtpClient();
                    smtp.Host = _smtpServerIP;

                    smtp.Send(oMsg);
                }

                oMsg.Dispose();

            }
            
            catch (Exception ex)
            {
                throw ex;
            
            }

        }


    }
}
