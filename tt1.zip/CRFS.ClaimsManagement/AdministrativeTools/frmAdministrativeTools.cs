﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CRFS.AdministrativeTools
{
    public partial class frmAdministrativeTools : Form
    {
        bool _closeForm = true;
        bool _dataLoading = false;
        bool _dataDirty = false;
        bool _modInProgress = false;
        bool _hasAppAccessAdmin = false;
        bool _hasUserAdmin = false;
        bool _hasLockAdmin = false;
        bool _hasServicerMIAdmin = false;
        bool _hasClientSecurityAdmin = false;

        private string _appMode;
        private string _securityUserGroupName = "";
        private string _userName = "";
        private string _CMSLogin = ""; //The string a user types in to identify them seleves at log in

        private int _securityUserGroupLevel = 0;
        private int _CMSLoginID = 0; //The database ID for _userID

        #region "Properties"
        public string AppMode
        {
            get
            {
                return _appMode;
            }
            set
            {
                _appMode = value;
            }
        }

        public string SecurityUserGroupName
        {
            get
            {
                return _securityUserGroupName;
            }
            set
            {
                _securityUserGroupName = value;
            }
        }

        public string UserName
        {
            get
            {
                return _userName;
            }
            set
            {
                _userName = value;
            }
        }

        public string CMSLogin
        {
            get
            {
                return _CMSLogin;
            }
            set
            {
                _CMSLogin = value;
            }
        }

        public int SecurityUserGroupLevel
        {
            get
            {
                return _securityUserGroupLevel;
            }
            set
            {
                _securityUserGroupLevel = value;
            }
        }

        public int CMSLoginID
        {
            get
            {
                return _CMSLoginID;
            }
            set
            {
                _CMSLoginID = value;
            }
        }

        #endregion
        
        string _origTitle = "";
        
        int _appToManage = 0;
        int _userToAdd = 0;
        int _entityTypeToManage = 0;
        int _entityToManage = 0;
        int _groupToManage = 0;
        int _PWLengthDefault = 8;   //This is used when generating a random password string.  If password length requirements change, modify this value.
        int _selectedLock = -1;     //Lock selected from the lock admin datagrid

        //claimFunctions _claimFunctions;
        Moss.Events.Events _events;
        CRFS.Data.DataFunctions _cdf;
        //claimsManagementMain _cmMainForm;

        DataTable _currUserAccessRights = new DataTable("AccessRights");
        DataTable _allUserAccessRights = new DataTable("AccessRights");
        DataTable _activeForms = new DataTable("ActiveForms");
        DataTable _cboValues = new DataTable("cboValues");
        DataTable _cmsUsers = new DataTable("CMSUsers");
        DataTable _EntityTypes = new DataTable("EntityTypes");
        DataTable _EntityGroupsUnassigned = new DataTable("EntityGroups");
        DataTable _EntityGroups = new DataTable("EntityGroups");
        DataTable _UserEmailSignatures = new DataTable("GroupEmailSignatures");
        DataTable _GroupUserAssigned = new DataTable("GroupUserAssigned");
        DataTable _Groups = new DataTable("Groups");
        DataTable _currentLocks;
        DataTable _allUsersClientSpecificSecurity = new DataTable("ClientSpecificSecurity");
        
        DataTable _clientGroups = new DataTable("ClientGroups");
        DataTable _ServicerEmails = new DataTable("ServicerEmails");



        /// <summary>
        /// 
        /// </summary>
        /// <param name="appMode"></param>
        /// <param name="curUserUniqueID"></param>
        /// <param name="curUserID"></param>
        /// <param name="curUserSecurityLevel"></param>
        /// <param name="curUserName"></param>
        /// <param name="cm"></param>
        /// <param name="AdminRights"></param>
        public frmAdministrativeTools(string appMode, int curUserUniqueID, string curUserID, int curUserSecurityLevel, string curUserName, DataTable AdminRights)
        {
            InitializeComponent();

            //Set local variables to values from the call
            AppMode = appMode;
            CMSLoginID = curUserUniqueID;
            CMSLogin = curUserID;
            SecurityUserGroupLevel = curUserSecurityLevel;
            UserName = curUserName;
            //_cmMainForm = cm;
            _currUserAccessRights = AdminRights;

            if (AppMode != "Production")
            {
                _origTitle = "CMS Administration Tools" + " - " + AppMode.ToUpper();
            }
            else
            {
                _origTitle = "CMS Administration Tools";
            }

            this.Text = _origTitle;

        }

        /// <summary>
        /// A constructor used when setting the public properties, rather than passing multiple parameters
        /// </summary>
        /// <param name="AdminRights">A table of the current user's admin rights.</param>
        public frmAdministrativeTools(DataTable AdminRights)
        {
            InitializeComponent();
            _currUserAccessRights = AdminRights;
        
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmApplicationPanel_Load(object sender, EventArgs e)
        {
            if (AppMode != "Production")
            {
                _origTitle = "CMS Administration Tools" + " - " + AppMode.ToUpper();
            }
            else
            {
                _origTitle = "CMS Administration Tools";
            }

            this.Text = _origTitle;

        }

        #region "Common Methods"
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mnuHelp_About_Click(object sender, EventArgs e)
        {
            CRFS.UI.CRFSAbout.AboutApp cms = new CRFS.UI.CRFSAbout.AboutApp();
            cms.ShowDialog();
            cms.Dispose();

        }

        /// <summary>
        /// 
        /// </summary>
        private void DataClean()
        {
            try
            {
                this.stsSaveStatus.Text = "";
                _dataDirty = false;
                _closeForm = true;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private void DataDirty()
        {
            try
            {
                this.stsSaveStatus.Text = "Data has changed...Need to save (Ctrl+S to save)";
                _dataDirty = true;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmAdministrativeTools_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (_dataDirty)
                {
                    DialogResult dr = MessageBox.Show("Data has changed since you last saved.  Do you want to save prior to exiting?", "Save?", MessageBoxButtons.YesNoCancel);

                    if (dr == DialogResult.Cancel)
                    {
                        e.Cancel = true;
                        goto ExitMethod;
                    }

                    else if (dr == DialogResult.Yes)
                    {
                        this.mnuFile_Save_Click(sender, e);
                        if (!_closeForm)
                        {
                            e.Cancel = true;
                            goto ExitMethod;
                        }

                    }

                }

                _closeForm = true;

                //_cmMainForm.Visible = true;
                //_cmMainForm.WindowState = FormWindowState.Normal;
                //_cmMainForm.Select();

            ExitMethod: ;
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

            finally
            {
            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmAdministrativeTools_Load(object sender, EventArgs e)
        {
            try
            {
                _dataLoading = true;

                _cdf = new CRFS.Data.DataFunctions(AppMode);

                InitializeForm();



            }

            catch (Exception ex)
            {
                _dataLoading = false;
                throw ex;

            }

            finally
            {
                _dataLoading = false;
                DataClean();
                // 20130923 gk t-13987 enable/disable all the controls from hideShowMiControls
                hideShowMIControls();
                this.Select();

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        private void InitializeForm()
        {
            try
            {
                _allUserAccessRights = _cdf.ApplicationAccess_GetAllUsers();
                _activeForms = _cdf.Get_ActiveForms();
                _cmsUsers = _cdf.Security_CMSUsers_Get();
                
                //VIP-440 20111024  CRZ
                _allUsersClientSpecificSecurity = _cdf.Security_ClientSpecificSecurity_GetMatrix();
                _clientGroups = _cdf.ClientGroups_Get();
                //Retrieve the Servicer contact info 
                DataTable dtServicerEmails = new DataTable();
                _ServicerEmails = _cdf.AssetColl_ServicerEmails2_Get(dtServicerEmails);
                // 20130920 gk t-13987 get the xref_GroupUserAssinged
                _GroupUserAssigned = _cdf.UserAssignedToGroup_Select();

                LoadFormData();

                //Tab security is set by Layout panel
                DataView dvPanelSets = new DataView(_currUserAccessRights);

                dvPanelSets.RowFilter = ("IsAllowedAdmin = true OR IsAllowedAppAccessAdmin = true OR IsAllowedAppAccessAdmin = true");
                if (dvPanelSets.Count > 0)
                {
                    //The user is allowed access to the App Access Admin tab
                    pnlAppAccess.Enabled = true;
                    _hasAppAccessAdmin = true;

                }

                else
                {
                    pnlAppAccess.Enabled = false;
                    _hasAppAccessAdmin = false;

                }

                dvPanelSets.RowFilter = ("IsAllowedAdmin = true OR IsAllowedUserAdmin = true");
                if (dvPanelSets.Count > 0)
                {
                    //The user is allowed access to the User Admin tab
                    pnlUserAdmin.Enabled = true;
                    _hasUserAdmin = true;

                }

                else
                {
                    pnlUserAdmin.Enabled = false;
                    _hasUserAdmin = false;

                }

                dvPanelSets.RowFilter = ("IsAllowedAdmin = true OR IsAllowedLockAdmin = true");
                if (dvPanelSets.Count > 0)
                {
                    //The user is allowed access to the Locks Admin tab
                    pnlLockAdmin.Enabled = true;
                    _hasLockAdmin = true;

                }

                else
                {
                    pnlLockAdmin.Enabled = false;
                    _hasLockAdmin = false;

                }

                dvPanelSets.RowFilter = ("IsAllowedAdmin = true OR IsAllowedServicer_MI_Admin = true");
                if (dvPanelSets.Count > 0)
                {
                    //The user is allowed access to the Servicer/MI Admin tab
                    pnlServicerMIAdmin.Enabled = true;
                    _hasServicerMIAdmin = true;

                }

                else
                {
                    pnlServicerMIAdmin.Enabled = false;
                    _hasServicerMIAdmin = false;

                }

                dvPanelSets.RowFilter = ("IsAllowedAdmin = true OR IsAllowedCltSpecificSecAdmin = true");
                if (dvPanelSets.Count > 0)
                {
                    //The user is allowed access to the Client Specific Security Admin tab
                    pnlClientSecurityMain.Enabled = true;
                    _hasClientSecurityAdmin = true;

                }

                else
                {
                    pnlClientSecurityMain.Enabled = false;
                    _hasClientSecurityAdmin = false;

                }

                if (_hasClientSecurityAdmin)
                {
                    refresh_ClientSecurityGrid();

                }

                //App Access Admin Tab-----------------------------------------
                btnAddUserToApp.Enabled = false;
                
                //User Admin Tab-----------------------------------------------
                btn_User_Cancel.Enabled = false;
                btn_User_Save.Enabled = false;
                btn_User_ResetPassword.Enabled = false;
                
                //Lock Admin Tab-----------------------------------------------
                btnDeleteLock.Enabled = false;

                //Service/MI Admin Tab-----------------------------------------
                btn_ServicerMI_Cancel.Enabled = false;
                btn_ServicerMI_MoveLeft.Enabled = false;
                btn_ServicerMI_MoveRight.Enabled = false;
                btn_ServicerMI_Save.Enabled = false;
                cbo_ServicerMI_EntityType.Enabled = false;
                cbo_ServicerMI_SelectEntity.Enabled = false;
                chkExcludeFNMAClaimFiledUpdateRpt.Enabled = false;
                chkExcludeFNMAClaimFiledUpdateRpt.Visible = false;
                chkIsBackend.Enabled = false;
                chkIsBackend.Visible = false;

            }

            catch (Exception ex)
            {
                throw ex;
            
            }

        }

        /// <summary>
        /// Load data into all tabs on the administration form.
        /// </summary>
        private void LoadFormData()
        {
            try
            {
                _dataLoading = true;

                //_currUserAccessRights has a set of records that tells what can be accessed
                DataView _dvUserAR = new DataView(_currUserAccessRights);

                //----------Application Access Administration tab----------//
                //Application Selection combo box
                //NOTE: The form filtering here is also used in the Lock Admin tab below, since the
                //      same access should apply in both cases.
                string UserRightsFilter = "IsAllowedAdmin = true OR IsAllowedUserAdmin = true OR IsAllowedLockAdmin = true OR ";
                UserRightsFilter = UserRightsFilter + "IsAllowedAppAccessAdmin = true OR IsAllowedServicer_MI_Admin = true";

                _dvUserAR.RowFilter = (UserRightsFilter);

                string formFilter = "";

                for (int i = 0; i < _dvUserAR.Count; i++)
                {
                    formFilter = formFilter + _dvUserAR[i]["FormID"].ToString() + ",";

                }

                if (formFilter.Length > 0)
                {
                    formFilter = "(" + formFilter + ")";

                    DataView _dvForms = new DataView(_activeForms);
                    _dvForms.RowFilter = ("ID IN " + formFilter);
                    _dvForms.Sort = ("FormName ASC");

                    cboAppSelect.DataSource = _dvForms;
                    cboAppSelect.ValueMember = "id";
                    cboAppSelect.DisplayMember = "FormName";
                    cboAppSelect.SelectedIndex = -1;
                }

                //------End Application Access Administration tab----------//

                //------------Lock Administration tab---------------//
                //Lock Application Selection combo box
                //NOTE: The form filter builds off the list compiled in the App Access tab,
                //      since the same access levels should apply in both places.
                if (formFilter.Length > 0)
                {
                    DataView _dvLockForms = new DataView(_activeForms);
                    _dvLockForms.RowFilter = ("ID IN " + formFilter);
                    _dvLockForms.Sort = ("FormName ASC");

                    cboLockAppSelect.DataSource = _dvLockForms;
                    cboLockAppSelect.ValueMember = "id";
                    cboLockAppSelect.DisplayMember = "FormName";
                    cboLockAppSelect.SelectedIndex = -1;
                }
                //------------END Lock Administration tab-----------//

                //-----------------User Administration tab-----------------//
                DataView _dvUserAdminAR = new DataView(_currUserAccessRights);
                string UserAdminRightsFilter = "IsAllowedAdmin = true OR IsAllowedUserAdmin = true";

                _dvUserAdminAR.RowFilter = (UserAdminRightsFilter);

                string UsersFormFilter = "";

                for (int i = 0; i < _dvUserAdminAR.Count; i++)
                {
                    if (UsersFormFilter.Length == 0)
                    {
                        UsersFormFilter = _dvUserAdminAR[i]["FormID"].ToString();
                    }

                    else
                    {
                        UsersFormFilter = UsersFormFilter + "," + _dvUserAdminAR[i]["FormID"].ToString();
                    }

                }

                if (UsersFormFilter.Length > 0)
                {
                    UsersFormFilter = "(" + UsersFormFilter + ")";

                    DataView _dvUserForms = new DataView(_allUserAccessRights);
                    _dvUserForms.RowFilter = ("FormID IN " + UsersFormFilter + " AND IsAppUser = true");
                    _dvUserForms.Sort = ("UserID ASC");


                    string UsersFilter = "";
                    int LastUserID = 0;

                    for (int i = 0; i < _dvUserForms.Count; i++)
                    {
                        if (LastUserID != int.Parse(_dvUserForms[i]["UserID"].ToString()))
                        {
                            if (UsersFilter.Length == 0)
                            {
                                UsersFilter = _dvUserForms[i]["UserID"].ToString();
                            }

                            else
                            {
                                UsersFilter = UsersFilter + "," + _dvUserForms[i]["UserID"].ToString();
                            }

                            LastUserID = int.Parse(_dvUserForms[i]["UserID"].ToString());
                        }

                    }

                    if (UsersFilter.Length > 0)
                    {
                        UsersFilter = "(" + UsersFilter + ")";
                        
                        DataView _dvUsersToAdmin = new DataView(_cmsUsers);
                        _dvUsersToAdmin.RowFilter = ("id IN " + UsersFilter);
                        _dvUsersToAdmin.Sort = ("UserName ASC");

                        cbo_User_SelectUser.DataSource = _dvUsersToAdmin;
                        cbo_User_SelectUser.ValueMember = "id";
                        cbo_User_SelectUser.DisplayMember = "UserName";
                        cbo_User_SelectUser.SelectedIndex = -1;

                    }

                }

                //---------------END User Administration tab---------------//

                //------------Servicer/MI Administration tab---------------//
                DataView _dvServicerMIAdminAR = new DataView(_currUserAccessRights);
                string ServicerMIAdminRightsFilter = "IsAllowedAdmin = true OR IsAllowedServicer_MI_Admin = true";

                _dvServicerMIAdminAR.RowFilter = (ServicerMIAdminRightsFilter);

                string ServicerMIformFilter = "";

                for (int i = 0; i < _dvServicerMIAdminAR.Count; i++)
                {
                    if (ServicerMIformFilter.Length == 0)
                    {
                        ServicerMIformFilter = _dvServicerMIAdminAR[i]["FormID"].ToString();
                    }

                    else
                    {
                        ServicerMIformFilter = ServicerMIformFilter + "," + _dvServicerMIAdminAR[i]["FormID"].ToString();
                    }

                }

                if (ServicerMIformFilter.Length > 0)
                {
                    ServicerMIformFilter = "(" + ServicerMIformFilter + ")";

                    DataView _dvServicerMIForms = new DataView(_activeForms);
                    _dvServicerMIForms.RowFilter = ("ID IN " + ServicerMIformFilter + "AND FormName LIKE 'FNMA *'");
                    _dvServicerMIForms.Sort = ("FormName ASC");

                    cbo_ServicerMI_AppSelect.DataSource = _dvServicerMIForms;
                    cbo_ServicerMI_AppSelect.ValueMember = "ID";
                    cbo_ServicerMI_AppSelect.DisplayMember = "FormName";
                    cbo_ServicerMI_AppSelect.SelectedIndex = -1;


                }

                //------------END Servicer/MI Administration tab-----------//
                
                //------------Client Specific Security Admin tab-----------//
                //DataView _dvCltSpecificSecurityAdminAR = new DataView(_currUserAccessRights);
                //string ClientSpecificSecurityAdminRightsFilter = "IsAllowedAdmin = true OR IsAllowedCltSpecificSecAdmin = true";
                //_dvCltSpecificSecurityAdminAR.RowFilter = ClientSpecificSecurityAdminRightsFilter;

                //----------END Client Specific Security Admin tab---------//
                
                _dataLoading = false;
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mnuFile_Exit_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }


        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mnuFile_Save_Click(object sender, EventArgs e)
        {
            try
            {
                bool Saved = false;

                TabPage testing = this.tabAppAccessMain.SelectedTab;

                switch (testing.Name)
                {
                    case "tabP_AppAccess":
                        if (_hasAppAccessAdmin)
                        {
                            bool _dataSaved = _cdf.ApplicationAccess_Save(_allUserAccessRights);
                            DataClean();
                            _modInProgress = false;
                        
                        }
                        
                        break;

                    case "tabP_UserAdmin":
                        if (_hasUserAdmin)
                        {
                            Saved = _cdf.Security_CMSUsers_UpdateNonCritical(int.Parse(cbo_User_SelectUser.SelectedValue.ToString()), txtUserPhone.Text, txtUserEmail.Text);
                            DataClean();
                            _modInProgress = false;

                            btn_User_Cancel.Enabled = false;
                            btn_User_Save.Enabled = false;
                            btn_User_ResetPassword.Enabled = false;

                            _dataLoading = true;
                            cbo_User_SelectUser.SelectedIndex = -1;
                            txtUserEmail.Text = "";
                            txtUserPhone.Text = "";
                            _dataLoading = false;
                        
                        }

                        break;
                    
                    case "tabP_LockAdmin":
                        //Placeholder for Lock Admin save method items

                        break;

                    case "tabP_ServicerMIAdmin":
                        //Save the groups
                        switch (_appToManage)
                        { 
                            // PFU
                            case 9:
                                Saved = _cdf.Groups_Save(_Groups);
                                Saved = _cdf.EntityGroupsAssigned_Save(_EntityGroups);
                                // Business_Entities_Update updates bit values that are only used for PFU
                                // No AppConfig version is required as Recon/DataGram don't use these bits
                                Saved = _cdf.Business_Entities_Update(_EntityGroupsUnassigned, _appToManage);
                                break;
                            // Reconciliation
                            case 10:
                            // DataGram
                            case 11:
                                Saved = _cdf.EntityGroups_Save(_Groups);
                                Saved = _cdf.BusinessEntityGroupsAssigned_Save(_EntityGroups);
                                break;
                            default:
                                break;
                        }
 
                        //Save the Contacts
                        Saved = _cdf.AssetColl_ServicerEmail_Save(_ServicerEmails, _CMSLoginID);


                        //Save the users assigned to a group
                        // for reading: internal DataTable UserAssignedToGroup_Select( )
                        //Saved = _cdf.UserAssignedToGroup_Save(_GroupEmailSignatures);
                        Saved = _cdf.UserAssignedToGroup_Save(_GroupUserAssigned);

                        //TODO - this needs to be revised
                        //Save the Email Signature
                        //Saved = _cdf.GroupEmailSignatures_Save(_UserEmailSignatures);
                        Saved = _cdf.UserEmailSignature_Save(_UserEmailSignatures);

                        DataClean();
                        _modInProgress = false;
                        _dataLoading = false;

                        btn_ServicerMI_Cancel.Enabled = false;
                        btn_ServicerMI_Save.Enabled = false;

                        break;

                    case "tabP_ClientSpecificSecurity":
                        //Save the User/Client Security Matrix
                        Saved = _cdf.Security_ClientSpecificSecurity_SaveMatrix(ref _allUsersClientSpecificSecurity, CMSLoginID);

                        DataClean();
                        _modInProgress = false;
                        
                        _dataLoading = true;
                        //_allUsersClientSpecificSecurity = _cdf.Security_ClientSpecificSecurity_GetMatrix();
                        refresh_ClientSecurityGrid();
                        cboCSSecurityAddUser.SelectedIndex = -1;
                        _dataLoading = false;

                        btnCSSecurityAddUser.Enabled = false;
                        btn_CSSCancel.Enabled = false;
                        btn_CSSSave.Enabled = false;

                        break;

                    default:
                        break;

                }
                

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }

        /// <summary>
        /// Controls access to tabs 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tabAppAccessMain_Selecting(object sender, TabControlCancelEventArgs e)
        {
            try
            {
                if (!_modInProgress && !_dataDirty)
                {
                    switch (e.TabPage.Name)
                    {
                        case "tabP_AppAccess":
                            if (!_hasAppAccessAdmin)
                            {
                                e.Cancel = true;

                            }

                            break;

                        case "tabP_UserAdmin":
                            if (!_hasUserAdmin)
                            {
                                e.Cancel = true;

                            }

                            break;

                        case "tabP_LockAdmin":
                            if (!_hasLockAdmin)
                            {
                                e.Cancel = true;

                            }

                            break;

                        case "tabP_ServicerMIAdmin":
                            if (!_hasServicerMIAdmin)
                            {
                                e.Cancel = true;

                            }

                            break;

                        case "tabP_ClientSpecificSecurity":
                            if (!_hasClientSecurityAdmin)
                            {
                                e.Cancel = true;

                            }

                            break;

                        default:
                            break;
                    }

                }

                else
                {
                    if (_dataDirty)
                    {
                        MessageBox.Show("Data has changed and not yet been saved on the current tab.\n\nYou must save or cancel the changes before leaving this tab.", "Data needs to be saved!", MessageBoxButtons.OK);
                        e.Cancel = true;

                    }

                    if (_modInProgress)
                    {
                        MessageBox.Show("Data modifications are in progress on the current tab.\n\nYou must finish and save or cancel the changes before leaving this tab.", "Data modification in progress!", MessageBoxButtons.OK);
                        e.Cancel = true;

                    }
                }

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tabP_AppAccess_Click(object sender, EventArgs e)
        {
            if (!_hasAppAccessAdmin)
            {
                tabP_UserAdmin_Click(sender, e);

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tabP_UserAdmin_Click(object sender, EventArgs e)
        {
            if (!_hasUserAdmin)
            {
                tab_LockAdmin_Click(sender, e);

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tab_LockAdmin_Click(object sender, EventArgs e)
        {
            if (!_hasLockAdmin)
            {
                tabP_ServicerMIAdmin_Click(sender, e);

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tabP_ServicerMIAdmin_Click(object sender, EventArgs e)
        {
            if (!_hasServicerMIAdmin)
            {

            }
        }

        #endregion

        #region "App Access Tab Routines"
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAddUserToApp_Click(object sender, EventArgs e)
        {
            try
            {
                //Generate a new tempoary ID for the new data row.
                int Tempid = (_allUserAccessRights.Rows.Count + 1) * -1;

                DataRow dr = _allUserAccessRights.NewRow();

                dr["AppaccessID"] = Tempid;
                dr["FormID"] = _appToManage;
                dr["UserID"] = int.Parse(cboUserSelect.SelectedValue.ToString());
                dr["UserName"] = cboUserSelect.Text;
                dr["IsAppUser"] = false;
                dr["IsAllowedAdmin"] = false;
                dr["IsAllowedUserAdmin"] = false;
                dr["IsAllowedLockAdmin"] = false;
                dr["IsAllowedAppAccessAdmin"] = false;
                dr["IsAllowedServicer_MI_Admin"] = false;
                dr["IsAllowedCltSpecificSecAdmin"] = false; 
                dr["EnteredDate"] = DateTime.Now;
                dr["EnteredByUserID"] = CMSLoginID;
                dr["LastUpdateDate"] = DateTime.Now;
                dr["LastUpdateUserID"] = CMSLoginID;

                _allUserAccessRights.Rows.Add(dr);

                RefreshPermissionsGrid();

                DataDirty();
                _modInProgress = true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                mnuFile_Save_Click(sender, e);

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cboAppSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (!_dataLoading)
                {
                    if (_modInProgress)
                    {
                        DialogResult dr = MessageBox.Show("A data modification is in progress.\nYou must complete and save this edit or quit and re-enter the form.", "Modification in progress!", MessageBoxButtons.OK);
                        goto ExitMethod;
                    }

                    _appToManage = int.Parse(cboAppSelect.SelectedValue.ToString());

                    //Now that an application has been selected, we can do other things
                    //----------Application Access Administration tab----------//
                    RefreshPermissionsGrid();

                    //--------END Application Access Administration tab--------//

                    //----------User Administration tab----------//
                    //--------END User Administration tab--------//
                    
                ExitMethod: ;
                }

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cboUserSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!_dataLoading)
            {
                _userToAdd = int.Parse(cboUserSelect.SelectedValue.ToString());

                btnAddUserToApp.Enabled = true;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        private void RefreshPermissionsGrid()
        {
            try
            {
                dgvUserAccessRights.AutoGenerateColumns = true;
                dgvUserAccessRights.AllowUserToAddRows = false;
                //dgvUserAccessRights.AllowUserToDeleteRows = false;
                dgvUserAccessRights.MultiSelect = false;
                //dgvUserAccessRights.EditMode = DataGridViewEditMode.EditProgrammatically;
                dgvUserAccessRights.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.DisplayedCells);

                //Update the list of users and permissions data grid
                //Note that a user is not allowed to administer their own privs.
                DataView _dvAllUsers = new DataView(_allUserAccessRights);
                _dvAllUsers.RowFilter = ("FormID = " + _appToManage + " AND UserID NOT IN (" + CMSLoginID + ")");

                dgvUserAccessRights.DataSource = _dvAllUsers;
                dgvUserAccessRights.Columns["AppAccessID"].Visible = false;
                dgvUserAccessRights.Columns["FormID"].Visible = false;
                dgvUserAccessRights.Columns["UserID"].Visible = false;
                dgvUserAccessRights.Columns["EnteredByUserID"].Visible = false;
                dgvUserAccessRights.Columns["LastUpdateUserID"].Visible = false;

                dgvUserAccessRights.Columns["IsAppUser"].HeaderText = "User";
                dgvUserAccessRights.Columns["IsAllowedAdmin"].HeaderText = "Admin";
                dgvUserAccessRights.Columns["IsAllowedUserAdmin"].HeaderText = "PW Reset";
                dgvUserAccessRights.Columns["IsAllowedLockAdmin"].HeaderText = "Lock Reset";
                dgvUserAccessRights.Columns["IsAllowedAppAccessAdmin"].HeaderText = "Access Admin";
                dgvUserAccessRights.Columns["IsAllowedServicer_MI_Admin"].HeaderText = "Servicer/MI Admin";
                dgvUserAccessRights.Columns["IsAllowedCltSpecificSecAdmin"].HeaderText = "Client Security Admin";

                DataView _dvCurrUser = new DataView(_currUserAccessRights);
                _dvCurrUser.RowFilter = ("FormID = " + _appToManage);

                dgvUserAccessRights.Columns["IsAppUser"].ReadOnly = true;
                dgvUserAccessRights.Columns["IsAllowedAdmin"].ReadOnly = true;
                dgvUserAccessRights.Columns["IsAllowedUserAdmin"].ReadOnly = true;
                dgvUserAccessRights.Columns["IsAllowedLockAdmin"].ReadOnly = true;
                dgvUserAccessRights.Columns["IsAllowedAppAccessAdmin"].ReadOnly = true;
                dgvUserAccessRights.Columns["IsAllowedServicer_MI_Admin"].ReadOnly = true;
                dgvUserAccessRights.Columns["IsAllowedCltSpecificSecAdmin"].ReadOnly = true;

                if (bool.Parse(_dvCurrUser[0]["IsAllowedAdmin"].ToString()) == true)
                {
                    //Admins have the privs to set everything
                    dgvUserAccessRights.Columns["IsAppUser"].ReadOnly = false;
                    dgvUserAccessRights.Columns["IsAllowedAdmin"].ReadOnly = false;
                    dgvUserAccessRights.Columns["IsAllowedUserAdmin"].ReadOnly = false;
                    dgvUserAccessRights.Columns["IsAllowedLockAdmin"].ReadOnly = false;
                    dgvUserAccessRights.Columns["IsAllowedAppAccessAdmin"].ReadOnly = false;
                    dgvUserAccessRights.Columns["IsAllowedServicer_MI_Admin"].ReadOnly = false;

                    switch(_appToManage)
                    {
                        case 6:
                        case 8:
                            dgvUserAccessRights.Columns["IsAllowedCltSpecificSecAdmin"].ReadOnly = false;
                            break;

                        default:
                            break;
                    }

                }

                if (bool.Parse(_dvCurrUser[0]["IsAllowedAppAccessAdmin"].ToString()) == true)
                {
                    //Application Access Administrators are allowed to grant 
                    //access for User Application Access, Lock Admin, and Servicer/MI Admin
                    dgvUserAccessRights.Columns["IsAppUser"].ReadOnly = false;
                    dgvUserAccessRights.Columns["IsAllowedLockAdmin"].ReadOnly = false;
                    dgvUserAccessRights.Columns["IsAllowedServicer_MI_Admin"].ReadOnly = false;

                }

                //Filter down the list of CMS users already in the data grid, plus the name of the current user.
                //Users are not allowed to adminster themsleves

                _dataLoading = true;
                string userFilter = CMSLoginID.ToString();

                for (int i = 0; i < _dvAllUsers.Count; i++)
                {
                    userFilter = userFilter + "," + _dvAllUsers[i]["UserID"].ToString();

                }

                //userFilter = "(" + userFilter + ")";

                DataView _dvUserList = new DataView(_cmsUsers);
                _dvUserList.RowFilter = ("ID NOT IN (" + userFilter + ")");
                _dvUserList.Sort = ("UserName ASC");

                cboUserSelect.DataSource = _dvUserList;
                cboUserSelect.ValueMember = "id";
                cboUserSelect.DisplayMember = "UserName";
                cboUserSelect.SelectedIndex = -1;

                _dataLoading = false;

                btnAddUserToApp.Enabled = false;

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvUserAccessRights_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvUserAccessRights.CurrentCell.GetType().ToString() == "System.Windows.Forms.DataGridViewCheckBoxCell")
            {
                //The click happened in a checkbox cell, there was an edit
                DataDirty();

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvUserAccessRights_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            try
            {
                DataDirty();

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        #endregion

        #region "User Admin Tab routines"
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_User_Cancel_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_User_ResetPassword_Click(object sender, EventArgs e)
        {
            try
            {
                string NewUnencryptedPW;
                string NewEncryptedPW;
                string pwResetter;
                string SMTPServerAddress = global::CRFS.AdministrativeTools.Properties.Settings.Default.SMTPServerAddress;
                string mailBody;
                string emailTo;
                string emailFrom;
                string emailSubject = "Your CMS Password has been reset";

                DataView dvCMSUsers = new DataView(_cmsUsers);
                dvCMSUsers.RowFilter = ("id = " + cbo_User_SelectUser.SelectedValue.ToString());
                emailTo = dvCMSUsers[0]["UserEmailAddress"].ToString();

                dvCMSUsers.RowFilter = ("id = " + CMSLoginID.ToString());
                pwResetter = dvCMSUsers[0]["UserName"].ToString(); ;
                emailFrom = dvCMSUsers[0]["UserEmailAddress"].ToString();;
                
                NewUnencryptedPW = GenerateRandomPassword(_PWLengthDefault);

                Moss.Security.Security sec = new Moss.Security.Security();
                NewEncryptedPW = sec.Encrypt(NewUnencryptedPW, true);

                int UserID = int.Parse(cbo_User_SelectUser.SelectedValue.ToString());

                _cdf.Security_CMSUser_PasswordReset(UserID, NewEncryptedPW);

                mailBody = pwResetter + " has reset your CMS password to :\n" + NewUnencryptedPW + "\n\nYou must reset your password the next time you log in to CMS";                

                mail_notification(SMTPServerAddress, mailBody, emailTo, emailFrom, emailSubject);

                _dataLoading = true;
                btn_User_ResetPassword.Enabled = false;
                _cmsUsers = _cdf.Security_CMSUsers_Get();

                cbo_User_SelectUser.SelectedIndex = -1;
                _dataLoading = false;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_User_Save_Click(object sender, EventArgs e)
        {
            this.mnuFile_Save_Click(sender, e);

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbo_User_SelectUser_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                if (!_dataLoading)
                {
                    _dataLoading = true;

                    DataView dvUserData = new DataView(_cmsUsers);
                    dvUserData.RowFilter = ("id = " + int.Parse(cbo_User_SelectUser.SelectedValue.ToString()));
                    txtUserEmail.Text = dvUserData[0]["UserEmailAddress"].ToString();
                    txtUserPhone.Text = dvUserData[0]["PhoneNum"].ToString();

                    btn_User_ResetPassword.Enabled = true;

                    _dataLoading = false;

                }

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// A routine that generates a random password string of a specified length
        /// </summary>
        /// <param name="PWLength">Integer value specifying the lenght of the password string to generate</param>
        /// <returns>string of random characters of the specified length</returns>
        private string GenerateRandomPassword(int PWLength)
        {
            Random rGen = new Random();
            StringBuilder rNewPass = new StringBuilder();

            for (int i = 0; i < PWLength; i++)
            {
                int AsciiCode = 0;

                AsciiCode = Convert.ToInt32(Math.Floor(83 * rGen.NextDouble()) + 43);

                if (AsciiCode == 37 || AsciiCode == 39 || AsciiCode == 42 || AsciiCode == 95)
                {
                    //ASCII codes for % ' * _ detected
                    //Redo the random character generation until we don't get one of these four character codes
                    i = i - 1;

                }

                else
                {
                    char rNewChar = Convert.ToChar(AsciiCode);
                    rNewPass.Append(rNewChar);

                }
            }

            return rNewPass.ToString();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtUserPhone_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (!_dataLoading)
                {
                    DataDirty();
                    btn_User_ResetPassword.Enabled = false;
                    btn_User_Cancel.Enabled = true;
                    btn_User_Save.Enabled = true;
                
                }

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtUserEmail_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (!_dataLoading)
                {
                    DataDirty();
                    btn_User_ResetPassword.Enabled = false;
                    btn_User_Cancel.Enabled = true;
                    btn_User_Save.Enabled = true;

                }

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="SMTPaddress"></param>
        /// <param name="opt1"></param>
        /// <param name="opt2"></param>
        /// <param name="opt3"></param>
        /// <param name="opt4"></param>
        private void mail_notification(string SMTPaddress, string opt1, string opt2, string opt3, string opt4)
        {
            try
            {
                string[] MsgOptions = new string[2] { "", SMTPaddress };

                CRFS.Messaging.Messaging mailer = new CRFS.Messaging.Messaging("EMAIL", MsgOptions);

                MsgOptions = new string[4];
                MsgOptions[0] = opt1;
                MsgOptions[1] = opt2;
                MsgOptions[2] = opt3;
                MsgOptions[3] = opt4;
                //MsgOptions[4] = opt5;

                //MsgOptions[0] = email/Message body
                //MsgOptions[1] = email/text to
                //MsgOptions[2] = email/text from
                //MsgOptions[3] = email/text subject
                //MsgOptions[4] = Path to attachment

                mailer.SendMessage(MsgOptions);



            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        
        #endregion

        #region "Servicer/MI Admin Tab routines"
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_ServicerMI_Cancel_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_ServicerMI_MoveLeft_Click(object sender, EventArgs e)
        {
            try
            {
                if (!_dataLoading)
                {
                    _dataLoading = true;

                    for (int i = 0; i < dgvEntityGroups.Rows.Count; i++)
                    {
                        DataGridViewRow row = dgvEntityGroups.Rows[i];

                        if (dgvEntityGroups.SelectedRows.Contains(row))
                        {
                            string _rowToPrune = row.Cells["Group_BusinessEntityID"].Value.ToString();

                            DataView dvPruneUnassigned = new DataView(_EntityGroupsUnassigned);
                            dvPruneUnassigned.RowFilter = ("Group_BusinessEntityID = " + _rowToPrune);
                            dvPruneUnassigned[0]["Group_BusinessEntityID"] = 0;

                            dvPruneUnassigned.RowFilter = ("EntityTypeID = " + _entityTypeToManage.ToString() + " AND Group_BusinessEntityID = 0");

                            cbo_ServicerMI_SelectEntity.DataSource = dvPruneUnassigned;
                            cbo_ServicerMI_SelectEntity.ValueMember = "BusinessEntityID";
                            cbo_ServicerMI_SelectEntity.DisplayMember = "BusinessEntityName";
                            cbo_ServicerMI_SelectEntity.SelectedIndex = -1;

                            DataView dvPruneAssigned = new DataView(_EntityGroups);
                            dvPruneAssigned.RowFilter = ("Group_BusinessEntityID = " + _rowToPrune);
                            dvPruneAssigned[0].Row.Delete();

                            dvPruneAssigned.RowFilter = ("GroupID = " + _groupToManage);
                            dgvEntityGroups.DataSource = dvPruneAssigned;

                        }

                    }

                    _dataLoading = false;

                    DataDirty();
                    
                    btn_ServicerMI_Cancel.Enabled = true;
                    btn_ServicerMI_Save.Enabled = true;

                    btn_ServicerMI_MoveLeft.Enabled = false;

                }
            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        private void btnAddContact_Click(object sender, EventArgs e)
        {
            _dataLoading = true;
            DataRow dr = _ServicerEmails.NewRow();
            int _newRowID = (_ServicerEmails.Rows.Count + 1) * -1;
            dr["GroupContactID"] = _newRowID;
            dr["GroupID"] = _groupToManage;
            dr["FormID"] = _appToManage;
            dr["ContactName"] = "";
            dr["EmailAddress"] = "";
            dr["Active"] = true;
            _ServicerEmails.Rows.Add(dr);
            btn_ServicerMI_Save.Enabled = true;
            btn_ServicerMI_Cancel.Enabled = true;
            _dataLoading = false;
        }

        private void btnRemoveContact_Click(object sender, EventArgs e)
        {
            if (dgvEntityContacts.SelectedRows.Count <= 0) return;
            
            _dataLoading = true;
            DataView dv = new DataView(_ServicerEmails);
            DataGridViewRow row = dgvEntityContacts.SelectedRows[0];
            dv.RowFilter = (string.Format("GroupContactID = {0}", row.Cells["GroupContactID"].Value));
            dv[0].Row.Delete();
            btn_ServicerMI_Save.Enabled = true;
            btn_ServicerMI_Cancel.Enabled = true;
            _dataLoading = false;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_ServicerMI_MoveRight_Click(object sender, EventArgs e)
        {
            try
            {
                DataRow dr = _EntityGroups.NewRow();
                int _newRowID = (_EntityGroups.Rows.Count + 1) * -1;

                dr["Group_BusinessEntityID"] = _newRowID;
                dr["GroupID"] = _groupToManage;
                dr["BusinessEntityID"] = cbo_ServicerMI_SelectEntity.SelectedValue;
                dr["BusinessEntityName"] = cbo_ServicerMI_SelectEntity.Text;
                dr["DateEntered"] = DateTime.Now;
                dr["FormID"] = _appToManage;

                _EntityGroups.Rows.Add(dr);

                btn_ServicerMI_Save.Enabled = true;
                btn_ServicerMI_Cancel.Enabled = true;

                _dataLoading = true;

                DataView dvRemoveEntity = new DataView(_EntityGroupsUnassigned);
                dvRemoveEntity.RowFilter = ("BusinessEntityID = " + cbo_ServicerMI_SelectEntity.SelectedValue.ToString());
                dvRemoveEntity[0]["Group_BusinessEntityID"] = _newRowID;

                dvRemoveEntity.RowFilter = ("EntityTypeID = " + _entityTypeToManage.ToString() + " AND Group_BusinessEntityID = 0");

                cbo_ServicerMI_SelectEntity.DataSource = dvRemoveEntity;
                cbo_ServicerMI_SelectEntity.ValueMember = "BusinessEntityID";
                cbo_ServicerMI_SelectEntity.DisplayMember = "BusinessEntityName";
                cbo_ServicerMI_SelectEntity.SelectedIndex = -1;

                _dataLoading = false;

                btn_ServicerMI_MoveRight.Enabled = false;

                DataDirty();

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_ServicerMI_Save_Click(object sender, EventArgs e)
        {
            try
            {
                mnuFile_Save_Click(sender, e);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void chkExcludeFNMAClaimFiledUpdateRpt_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (!_dataLoading)
                {
                    DataView dv = new DataView(_EntityGroupsUnassigned);
                    dv.RowFilter = ("BusinessEntityID = " + cbo_ServicerMI_SelectEntity.SelectedValue.ToString());
                    dv[0]["ExcludeFNMAClaimFiledUpdateRpt"] = chkExcludeFNMAClaimFiledUpdateRpt.Checked;

                    DataDirty();

                    btn_ServicerMI_Cancel.Enabled = true;
                    btn_ServicerMI_Save.Enabled = true;

                }

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void chkIsBackend_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (!_dataLoading)
                {
                    DataView dv = new DataView(_EntityGroupsUnassigned);
                    dv.RowFilter = ("BusinessEntityID = " + cbo_ServicerMI_SelectEntity.SelectedValue.ToString());
                    dv[0]["IsBackend"] = chkIsBackend.Checked;

                    DataDirty();

                    btn_ServicerMI_Cancel.Enabled = true;
                    btn_ServicerMI_Save.Enabled = true;

                }

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        // 20130923 gk t-13987 show or hide a list of controls
        private void showControlGroup(List<Control> lControl, bool visible)
        {
            foreach (Control c in lControl)
                c.Visible = visible;
        }

        // 20130923 gk t-13987 do all of the shows and enables from this routine
        private void hideShowMIControls()
        {
            if (_dataLoading)
            {
                return;
            }

            // when application is !=-1 businesstype is active
            List<Control> businesstype = new List<Control>() { cbo_ServicerMI_EntityType, label8 };
            if (cbo_ServicerMI_AppSelect.SelectedIndex != -1)
            {
                showControlGroup(businesstype, true);
            }
            else
            {
                showControlGroup(businesstype, false);
            }

            // when businesstype is set  select group is available
            List<Control> selectGroup = new List<Control>() { cbo_ServicerMI_SelectGroup, label9, lblSlectEntity, cbo_ServicerMI_SelectEntity, 
                                                              btn_ServicerMI_MoveRight, btn_ServicerMI_MoveLeft, label10, dgvEntityGroups };
            if (cbo_ServicerMI_EntityType.SelectedIndex != -1)
            {
                if (!selectGroup[0].Visible)
                {
                    dgvEntityGroups.DataSource = null;
                    btn_ServicerMI_MoveRight.Enabled = false;
                    btn_ServicerMI_MoveLeft.Enabled = false;
                    cbo_ServicerMI_SelectEntity.Text = "";
                    cbo_ServicerMI_SelectGroup.Text = "";
                }
                showControlGroup(selectGroup, true);
            }
            else
            {
                showControlGroup(selectGroup, false);
            }

            // set contacts visible when we are in app 11 EntityType Servicer
            string state = _appToManage+":"+cbo_ServicerMI_EntityType.Text;
            List<Control> contacts = new List<Control>() {label16, btnAddContact, btnRemoveContact,dgvEntityContacts};
            if ((state == "11:Servicer")&&(cbo_ServicerMI_SelectGroup.SelectedIndex!=-1))
            {
                if (!contacts[0].Visible)
                {
                    dgvEntityContacts.DataSource = null;
                }
                showControlGroup(contacts, true);
            }
            else
            {
                showControlGroup(contacts, false);
            }

        }

        private void resetMIControls()
        {
            cbo_ServicerMI_EntityType.SelectedIndex = -1;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbo_ServicerMI_AppSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (!_dataLoading)
                {
                    _dataLoading = true;

                    _appToManage = int.Parse(cbo_ServicerMI_AppSelect.SelectedValue.ToString());

                    cbo_ServicerMI_EntityType.Enabled = true;

                    DataView _dvEntityTypes;

                    switch (_appToManage)
                    {
                        //Controls on this tab are specific to the application selected

                        case 9: //FNMA PFU
                            chkIsBackend.Enabled = false;
                            chkExcludeFNMAClaimFiledUpdateRpt.Enabled = false;

                            chkIsBackend.Visible = true;
                            chkExcludeFNMAClaimFiledUpdateRpt.Visible = true;

                            _Groups = _cdf.Groups_Get(_appToManage);
                            _EntityTypes = _cdf.EntityTypes_Get();

                            _dvEntityTypes = new DataView(_EntityTypes);
                            _dvEntityTypes.Sort = ("EntityType");
                            cbo_ServicerMI_EntityType.DataSource = _dvEntityTypes;
                            cbo_ServicerMI_EntityType.ValueMember = "EntityTypeID";
                            cbo_ServicerMI_EntityType.DisplayMember = "EntityType";
                            cbo_ServicerMI_EntityType.SelectedIndex = -1;

                            break;

                        case 10: //FNMA Reconcilliation
                            chkIsBackend.Enabled = false;
                            chkExcludeFNMAClaimFiledUpdateRpt.Enabled = false; 
                        
                            chkIsBackend.Visible = false;
                            chkExcludeFNMAClaimFiledUpdateRpt.Visible = false;

                            _Groups = _cdf.GetEntityGroups(_appToManage);
                            _EntityTypes= _cdf.GetEntityTypes();

                            _dvEntityTypes = new DataView(_EntityTypes);
                            _dvEntityTypes.Sort = ("EntityTypeName");
                            _dvEntityTypes.RowFilter = "EntityTypeName IN ('Servicer','MI Company')";
                            cbo_ServicerMI_EntityType.DataSource = _dvEntityTypes;
                            cbo_ServicerMI_EntityType.ValueMember = "EntityTypeID";
                            cbo_ServicerMI_EntityType.DisplayMember = "EntityTypeName";
                            cbo_ServicerMI_EntityType.SelectedIndex = -1;

                            break;

                        case 11: //FNMA Asset Collection
                            chkIsBackend.Enabled = false;
                            chkExcludeFNMAClaimFiledUpdateRpt.Enabled = false; 
                        
                            chkIsBackend.Visible = false;
                            chkExcludeFNMAClaimFiledUpdateRpt.Visible = false;

                            // 20130923 gk t-13987 do all of these shows and enables from hideShowMIControls();
                            //cbo_UserAssignToGroup.Visible = true;
                            //txtAssignedUserEmailSignature.Visible = true;
                            //label15.Visible = true;
                            //label17.Visible = true;

                            //Set the list of users in the user assigned combobox
                            DataView dvAssignedUser = new DataView(_allUserAccessRights);
                            dvAssignedUser.RowFilter = "FormID = " + _appToManage;
                            dvAssignedUser.Sort = "UserName ASC";

                            _Groups = _cdf.GetEntityGroups(_appToManage);
                            _EntityTypes = _cdf.GetEntityTypes();

                            _dvEntityTypes = new DataView(_EntityTypes);
                            _dvEntityTypes.Sort = ("EntityTypeName");
                            _dvEntityTypes.RowFilter = "EntityTypeName IN ('Servicer','MI Company')";
                            cbo_ServicerMI_EntityType.DataSource = _dvEntityTypes;
                            cbo_ServicerMI_EntityType.ValueMember = "EntityTypeID";
                            cbo_ServicerMI_EntityType.DisplayMember = "EntityTypeName";
                            cbo_ServicerMI_EntityType.SelectedIndex = -1;

                            break;

                        default:
                            break;

                    }

                    

                    cbo_ServicerMI_SelectGroup.SelectedIndex = -1;

                    _dataLoading = false;

                }

            }

            catch (Exception ex)
            {
                throw ex;

            }
            // 20130923 gk t-13987 do all of these shows and enables from hideShowMIControls();
            hideShowMIControls();

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbo_ServicerMI_SelectEntity_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (!_dataLoading)
                {

                    _dataLoading = true;

                    _entityToManage = int.Parse(cbo_ServicerMI_SelectEntity.SelectedValue.ToString());

                    if (_appToManage == 9 && _entityTypeToManage == 2)
                    {
                        chkIsBackend.Visible = true;
                        chkExcludeFNMAClaimFiledUpdateRpt.Visible = true;

                        chkIsBackend.Enabled = true;
                        chkExcludeFNMAClaimFiledUpdateRpt.Enabled = true;

                        DataView _dvEntity = new DataView(_EntityGroupsUnassigned);
                        _dvEntity.RowFilter = ("BusinessEntityID = " + _entityToManage.ToString());

                        chkIsBackend.Checked = bool.Parse(_dvEntity[0]["IsBackend"].ToString());
                        chkExcludeFNMAClaimFiledUpdateRpt.Checked = bool.Parse(_dvEntity[0]["ExcludeFNMAClaimFiledUpdateRpt"].ToString());

                    }

                    else
                    {
                        chkIsBackend.Visible = false;
                        chkExcludeFNMAClaimFiledUpdateRpt.Visible = false;

                        chkIsBackend.Enabled = false;
                        chkExcludeFNMAClaimFiledUpdateRpt.Enabled = false;

                    }

                    if (cbo_ServicerMI_SelectGroup.SelectedIndex != -1)
                    {
                        //The group is already selected, so we need to enable the move to grid button
                        btn_ServicerMI_MoveRight.Enabled = true;

                    }
                    
                    else
                    {
                        btn_ServicerMI_MoveRight.Enabled = false;

                    }

                    _dataLoading = false;

                }

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbo_ServicerMI_EntityType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (!_dataLoading)
                {
                    _dataLoading = true;

                    _entityTypeToManage = int.Parse(cbo_ServicerMI_EntityType.SelectedValue.ToString());

                    if (_appToManage == 9 && _entityTypeToManage == 2)
                    {
                        chkIsBackend.Visible = true;
                        chkExcludeFNMAClaimFiledUpdateRpt.Visible = true;

                        chkIsBackend.Enabled = false;
                        chkExcludeFNMAClaimFiledUpdateRpt.Enabled = false;

                    }

                    else
                    {
                        chkIsBackend.Visible = false;
                        chkExcludeFNMAClaimFiledUpdateRpt.Visible = false;

                        chkIsBackend.Enabled = false;
                        chkExcludeFNMAClaimFiledUpdateRpt.Enabled = false;

                    }

                    switch(_appToManage)
                    {
                            // PFU
                        case 9:
                            _EntityGroups = _cdf.EntityGroupsAssigned_Get(_appToManage);
                            _EntityGroupsUnassigned = _cdf.EntityGroups_Get(_appToManage);
                            break;
                            // Reocnciliation
                        case 10:
                            // DataGram
                        case 11:
                            _EntityGroups = _cdf.BusinessEntityGroupsAssigned_Get(_appToManage);
                            _EntityGroupsUnassigned = _cdf.BusinessEntityGroups_Get(_appToManage);
                            break;
                        default:
                            break;
                    }

                    

                    DataView _dvEntityUnassigned = new DataView(_EntityGroupsUnassigned);
                    _dvEntityUnassigned.RowFilter = ("EntityTypeID = " + _entityTypeToManage.ToString() + " AND Group_BusinessEntityID = 0");

                    cbo_ServicerMI_SelectEntity.DataSource = _dvEntityUnassigned;
                    cbo_ServicerMI_SelectEntity.ValueMember = "BusinessEntityID";
                    cbo_ServicerMI_SelectEntity.DisplayMember = "BusinessEntityName";
                    cbo_ServicerMI_SelectEntity.SelectedIndex = -1;

                    cbo_ServicerMI_SelectEntity.Enabled = true;


                    DataView _dvGroupFilter = new DataView(_EntityGroupsUnassigned);
                    _dvGroupFilter.RowFilter = ("EntityTypeID NOT IN (" + _entityTypeToManage.ToString() + ")");
                    _dvGroupFilter.Sort = ("GroupID ASC");

                    int currID = 0;
                    int prevID = 0;
                    string groupFilter = "";

                    for (int i = 0; i < _dvGroupFilter.Count; i++)
                    {
                        currID = int.Parse(_dvGroupFilter[i]["GroupID"].ToString());

                        if (currID != 0)
                        {
                            if (groupFilter.Length == 0)
                            {
                                groupFilter = _dvGroupFilter[i]["GroupID"].ToString();

                            }

                            else
                            {
                                groupFilter = groupFilter + "," + _dvGroupFilter[i]["GroupID"].ToString();

                            }

                            prevID = currID;

                        }
                    }

                    DataView _dvGroups = new DataView(_Groups);

                    if (groupFilter.Length > 0)
                    {
                        groupFilter = "(" + groupFilter + ")";
                        _dvGroups.RowFilter = "GroupID NOT IN " + groupFilter;
 

                    }

                    _dvGroups.Sort = ("GroupName ASC");

                    cbo_ServicerMI_SelectGroup.DataSource = _dvGroups;
                    cbo_ServicerMI_SelectGroup.ValueMember = "GroupID";
                    cbo_ServicerMI_SelectGroup.DisplayMember = "GroupName";
                    cbo_ServicerMI_SelectGroup.SelectedIndex = -1;

                    //20130923 gk t-13987 blank out the datasource
                    dgvEntityGroups.DataSource = null;
                    btn_ServicerMI_MoveRight.Enabled = false;
                    btn_ServicerMI_MoveLeft.Enabled = false;

                    _dataLoading = false;

                }

            }

            catch (Exception ex)
            {
                throw ex;

            }

            // 20130923 gk t-13987 do all of these shows and enables from hideShowMIControls();
            hideShowMIControls();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbo_ServicerMI_SelectGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                hideShowMIControls();
                if (!_dataLoading)
                {
                    _dataLoading = true;

                    _groupToManage = int.Parse(cbo_ServicerMI_SelectGroup.SelectedValue.ToString());

                    DataView dvGroups = new DataView(_Groups);
                    dvGroups.RowFilter = "GroupID = " + _groupToManage;

                    string _groupNameToManage = "";

                    if (dvGroups.Count == 1)
                    {
                        _groupNameToManage = dvGroups[0]["GroupName"].ToString();

                    }

                    DataView dvGroupMembersGrid = new DataView(_EntityGroups);
                    dvGroupMembersGrid.RowFilter = ("GroupID = " + _groupToManage);
                    dgvEntityGroups.DataSource = dvGroupMembersGrid;
                    dgvEntityGroups.Columns["Group_BusinessEntityID"].Visible = false;
                    dgvEntityGroups.Columns["GroupID"].Visible = false;
                    dgvEntityGroups.Columns["GroupName"].Visible = false;
                    dgvEntityGroups.Columns["BusinessEntityID"].Visible = false;
                    dgvEntityGroups.Columns["FormID"].Visible = false;

                    dgvEntityGroups.Columns["BusinessEntityName"].HeaderText = cbo_ServicerMI_EntityType.Text;
                    dgvEntityGroups.AutoGenerateColumns = true;
                    dgvEntityGroups.AutoResizeColumns();
                    dgvEntityGroups.AllowUserToAddRows = false;
                    dgvEntityGroups.AllowUserToDeleteRows = false;
                    dgvEntityGroups.MultiSelect = false;
                    dgvEntityGroups.EditMode = DataGridViewEditMode.EditProgrammatically;
                    dgvEntityGroups.SelectionMode = DataGridViewSelectionMode.FullRowSelect;


                    //Filter to just the servicer specified
                    DataView servicerEmails = new DataView(_ServicerEmails)
                                                  {
                                                      RowFilter = string.Format("[GroupID] = '{0}'", _groupToManage),
                                                      AllowEdit = true,
                                                      AllowNew = false,
                                                      AllowDelete = false
                                                  };

                    dgvEntityContacts.DataSource = servicerEmails; 
                    dgvEntityContacts.Columns["GroupContactID"].Visible = false;
                    dgvEntityContacts.Columns["GroupID"].Visible = false;
                    dgvEntityContacts.Columns["FormID"].Visible = false;
                    dgvEntityContacts.AutoGenerateColumns = true;
                    dgvEntityContacts.AutoResizeColumns();
                    dgvEntityContacts.AllowUserToAddRows = false;
                    dgvEntityContacts.AllowUserToDeleteRows = false;
                    dgvEntityContacts.MultiSelect = false;
                    dgvEntityContacts.EditMode = DataGridViewEditMode.EditOnEnter;
                    dgvEntityContacts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    dgvEntityContacts.CellValueChanged += (o, args) =>
                                                              {
                                                                  btn_ServicerMI_Save.Enabled = true;
                                                                  btn_ServicerMI_Cancel.Enabled = true;
                                                                  _dataLoading = true;
                                                              };
                    
                    DataView dvgroupSearch = new DataView(_Groups);
                    dvgroupSearch.RowFilter = ("GroupID =" + cbo_ServicerMI_SelectGroup.SelectedValue.ToString());

                    if (cbo_ServicerMI_SelectEntity.SelectedIndex != -1)
                    {
                        //btn_ServicerMI_MoveLeft.Enabled = true;
                        btn_ServicerMI_MoveRight.Enabled = true;

                    }

                    else
                    {
                        //btn_ServicerMI_MoveLeft.Enabled = false;
                        btn_ServicerMI_MoveRight.Enabled = false;

                    }

                    _dataLoading = false;

                }
            }

            catch (Exception ex)
            {
                throw ex;

            }

        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="dv"></param>
        /// <returns></returns>
        private string build_SignatureBlock(DataView dv)
        {
            try
            {
                string rtnValue = "";

                if (dv.Count > 0)
                {
                    if (dv[0]["Line1"].ToString().Length > 0)
                    {
                        rtnValue = dv[0]["Line1"].ToString();
                    }
    
                    if (dv[0]["Line2"].ToString().Length > 0)
                    {
                        rtnValue = rtnValue + Environment.NewLine + dv[0]["Line2"].ToString();
                    }
    
                    if (dv[0]["Line3"].ToString().Length > 0)
                    {
                        rtnValue = rtnValue + Environment.NewLine + dv[0]["Line3"].ToString();
                    }
    
                    if (dv[0]["Line4"].ToString().Length > 0)
                    {
                        rtnValue = rtnValue + Environment.NewLine + dv[0]["Line4"].ToString();
                    }
    
                    if (dv[0]["Line5"].ToString().Length > 0)
                    {
                        rtnValue = rtnValue + Environment.NewLine + dv[0]["Line5"].ToString();
                    }
    
                    if (dv[0]["Line6"].ToString().Length > 0)
                    {
                        rtnValue = rtnValue + Environment.NewLine + dv[0]["Line6"].ToString();
                    }
    
                    if (dv[0]["Line7"].ToString().Length > 0)
                    {
                        rtnValue = rtnValue + Environment.NewLine + dv[0]["Line7"].ToString();
                    }
    
                    if (dv[0]["Line8"].ToString().Length > 0)
                    {
                        rtnValue = rtnValue + Environment.NewLine + dv[0]["Line8"].ToString();
                    }

                }

                return rtnValue;

            }

            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvEntityGroups_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (!_dataLoading)
                {
                    btn_ServicerMI_MoveLeft.Enabled = true;

                }

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvEntityGroups_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                if (!_dataLoading)
                {
                    btn_ServicerMI_MoveLeft.Enabled = true;

                }

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }


        #endregion

        #region "Lock Admin routines"
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cboLockAppSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (!_dataLoading)
                {
                    if (_modInProgress)
                    {
                        DialogResult dr = MessageBox.Show("A data modification is in progress.\nYou must complete and save this edit or quit and re-enter the form.", "Modification in progress!", MessageBoxButtons.OK);
                        goto ExitMethod;
                    }

                    _appToManage = int.Parse(cboLockAppSelect.SelectedValue.ToString());

                    //Now that an application has been selected, we can do other things
                    RefreshLocksGrid();

                ExitMethod: ;
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Refresh the viewable lock data based onthe current application selection.
        /// </summary>
        private void RefreshLocksGrid()
        {
            try
            {
                dgvLockAdmin.AutoGenerateColumns = true;
                dgvLockAdmin.AllowUserToAddRows = false;
                dgvLockAdmin.AllowUserToDeleteRows = true;
                dgvLockAdmin.MultiSelect = false;
                dgvLockAdmin.EditMode = DataGridViewEditMode.EditProgrammatically;
                dgvLockAdmin.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.DisplayedCells);

                //Update the list of users and permissions data grid
                //The grid data changes depending on the form selected since the
                //  entity changes by form/application (i.e. REO ID, Loan Number, etc.)
                DataView _dvCurrentLocks;
                switch (_appToManage)
                {
                  //For implamentation at a later date...
                  //case: 6     //Claims 332
                  //    break;
                  //case 8:
                  //    break;  //Investore Tracking
                    case 9:     //FNMA PFU
                        //Get the lock data for the selected CMS application
                        _currentLocks = new DataTable("PFU_Locks");
                        _currentLocks = _cdf.PFU_Locks_List_Get();
                        _dvCurrentLocks = new DataView(_currentLocks);
                        _dvCurrentLocks.Sort = "LockDate ASC";
                        dgvLockAdmin.DataSource = _dvCurrentLocks;

                        //Disable columns we don't want to see
                        dgvLockAdmin.Columns["LockID"].Visible = false;
                        dgvLockAdmin.Columns["FormID"].Visible = false;
                        dgvLockAdmin.Columns["Form Name"].Visible = false;
                        dgvLockAdmin.Columns["ReferralID"].Visible = false;
                        dgvLockAdmin.Columns["LockedByUserID"].Visible = false;
                        dgvLockAdmin.Columns["REO ID"].Visible = false;

                        //Set header names appropriately
                        dgvLockAdmin.Columns["Form Name"].HeaderText = "Application";
                        dgvLockAdmin.Columns["FNMA Loan Number"].HeaderText = "Loan Number";
                        dgvLockAdmin.Columns["Workstation Name"].HeaderText = "Workstation";
                        dgvLockAdmin.Columns["Locked By User Name"].HeaderText = "User";

                        //Make sure Delete button is disabled until a row is selected
                        btnDeleteLock.Enabled = false;
                        break;
                  //case 10:    //FNMA Reconciliation
                  //    break;

                  //case 11:    //FNMA AssetCollections
                  //    break;

                    default:
                        break;
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Actions to perform when Locks Admin row is deleted.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvLockAdmin_UserDeletedRow(Object sender, DataGridViewRowEventArgs e)
        {
            try
            {
                SaveLocks();
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// A lock record has been selected, enable the delete button.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvLockAdmin_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                _selectedLock = (int)dgvLockAdmin["LockID", e.RowIndex].Value;
                btnDeleteLock.Enabled = true;
            }
        }

        private void dgvLockAdmin_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                _selectedLock = (int)dgvLockAdmin["LockID", e.RowIndex].Value;
                btnDeleteLock.Enabled = true;
            }
        }

        /// <summary>
        /// Delete the selected lock.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDeleteLock_Click(object sender, EventArgs e)
        {
            //Delete the lock and save the grid results immediately.
            DataView _dvCurrentLocks = new DataView(_currentLocks);
            _dvCurrentLocks.RowFilter = "LockID = " + _selectedLock.ToString();
            _dvCurrentLocks[0].Delete();
            
            SaveLocks();
        }

        /// <summary>
        /// Saves the lock table back to the database.
        /// </summary>
        private void SaveLocks()
        {
            switch (_appToManage)
            {
                //For implamentation at a later date...
                //case: 6     //Claims 332
                //    break;
                //case 8:
                //    break;  //Investore Tracking
                case 9:     //FNMA PFU
                    if (!_cdf.PFU_Lock_Save(_currentLocks))
                    {
                        //This shouldn't occur, but flag an error
                        MessageBox.Show("The edit lock on this referral could not be released. Please submit a ticket with IS and specify the FNMA Loan Number and/or REO ID.", "Lock Administration", MessageBoxButtons.OK);
                    }
                    break;
                case 10:     //FNMARecon
                    if (!_cdf.Recon_Lock_Save(_currentLocks))
                    {
                        //This shouldn't occur, but flag an error
                        MessageBox.Show("The edit lock on this referral could not be released. Please submit a ticket with IS and specify the FNMA Loan Number and/or REO ID.", "Lock Administration", MessageBoxButtons.OK);
                    }
                    break;

                case 11:     //FNMA Asset Collections
                    if (!_cdf.AssetColl_Lock_Save(_currentLocks))
                    {
                        //This shouldn't occur, but flag an error
                        MessageBox.Show("The edit lock on this referral could not be released. Please submit a ticket with IS and specify the FNMA Loan Number and/or REO ID.", "Lock Administration", MessageBoxButtons.OK);
                    }

                    break;

                default:
                    break;
            }

            //Disable the delete button again
            btnDeleteLock.Enabled = false;
        }
        #endregion

        #region "Client Specific Security Tab routines"

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCSSecurityAddUser_Click(object sender, EventArgs e)
        {
            try
            {
                DataRow dr = _allUsersClientSpecificSecurity.NewRow();

                dr["CMSLoginID"] = cboCSSecurityAddUser.SelectedValue;
                dr["UserName"] = cboCSSecurityAddUser.Text;

                //We need to dynamically generate the columns for the client namesbecause we take on new clients regularly.  
                //Don't want to code in client names.  Also, by default, all Client Specific Security selections are to be unchecked (false).

                for (int i = 0; i < _clientGroups.Rows.Count; i++)
                {
                    dr[_clientGroups.Rows[i]["ClientGroupName"].ToString()] = false;

                }

                _allUsersClientSpecificSecurity.Rows.Add(dr);

                //Problems with this - seems like it will blow away the new record?
                refresh_ClientSecurityGrid();

                DataDirty();
                _modInProgress = true;

                btnCSSecurityAddUser.Enabled = false;
                btn_CSSCancel.Enabled = true;
                btn_CSSSave.Enabled = true;

                _dataLoading = true;
                cboCSSecurityAddUser.SelectedIndex = -1;
                _dataLoading = false;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_CSSCancel_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_CSSSave_Click(object sender, EventArgs e)
        {
            try
            {
                mnuFile_Save_Click(sender, e);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cboCSSecurityAddUser_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (!_dataLoading)
                {
                    btnCSSecurityAddUser.Enabled = true;

                }

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvClientSecritySettings_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvClientSecritySettings.CurrentCell.GetType().ToString() == "System.Windows.Forms.DataGridViewCheckBoxCell")
            {
                //The click happened in a checkbox cell, there was an edit
                DataDirty();

                btn_CSSCancel.Enabled = true;
                btn_CSSSave.Enabled = true;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvClientSecritySettings_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            try
            {
                DataDirty();

                btn_CSSCancel.Enabled = true;
                btn_CSSSave.Enabled = true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        private void refresh_ClientSecurityGrid()
        {
            try
            {
                //
                DataView dv = new DataView(_allUsersClientSpecificSecurity);
                dv.RowFilter = "CMSLoginID <> " + CMSLoginID.ToString();

                dgvClientSecritySettings.DataSource = dv;

                dgvClientSecritySettings.AutoGenerateColumns = true;
                dgvClientSecritySettings.AllowUserToAddRows = false;
                dgvClientSecritySettings.MultiSelect = false;
                dgvClientSecritySettings.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.DisplayedCells);
                dgvClientSecritySettings.Columns["CMSLoginID"].Visible = false;

                //Filter down the list of CMS users removing those already in the data grid, plus the name of the current user.
                //Users are not allowed to administer themsleves
                _dataLoading = true;
                string userFilter = CMSLoginID.ToString();

                for (int i = 0; i < dv.Count; i++)
                {
                    userFilter = userFilter + "," + dv[i]["CMSLoginID"].ToString();

                }

                DataView _dvUserList = new DataView(_cmsUsers);
                _dvUserList.RowFilter = "ID NOT IN (" + userFilter + ")";
                _dvUserList.Sort = "UserName ASC";

                cboCSSecurityAddUser.DataSource = _dvUserList;
                cboCSSecurityAddUser.ValueMember = "id";
                cboCSSecurityAddUser.DisplayMember = "UserName";
                cboCSSecurityAddUser.SelectedIndex = -1;

                _dataLoading = false;

                btnCSSecurityAddUser.Enabled = false;
                btn_CSSCancel.Enabled = false;
                btn_CSSSave.Enabled = false;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        #endregion

    }
}
