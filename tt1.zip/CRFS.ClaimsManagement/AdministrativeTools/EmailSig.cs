﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CRFS.AdministrativeTools
{
    public partial class EmailSignature : Form
    {
        DataRow _dr;
        bool _ret = false;
        public EmailSignature(DataRow dr)
        {
            _dr = dr;
            InitializeComponent();

            tbEMSName.Text = _dr["Line1"].ToString();
            tbEMSName.Enabled = false;

            tbEMSTitle.Text = _dr["Line2"].ToString();

            tbEMSCompany.Text = _dr["Line3"].ToString();
            tbEMSCompany.Enabled = false;

            tbEMSAddress1.Text = _dr["Line4"].ToString();
            tbEMSAddress1.Enabled = false;

            tbEMSAddress2.Text = _dr["Line5"].ToString();
            tbEMSAddress2.Enabled = false;

            tbEMSPhone.Text = _dr["Line6"].ToString();

            tbEMSFax.Text = _dr["Line7"].ToString();
            tbEMSFax.Enabled = false;

            tbEMSEmail.Text = _dr["Line8"].ToString();

        }

        public static bool run(DataRow dr)
        {
            using (EmailSignature e = new EmailSignature(dr))
            {
                e.ShowDialog();
                return e._ret;
            }
        }

        private void Save_Click(object sender, EventArgs e)
        {
            _ret = true;
            _dr["Line1"] = tbEMSName.Text;

            _dr["Line2"] = tbEMSTitle.Text;

            _dr["Line3"] = tbEMSCompany.Text;

            _dr["Line4"] = tbEMSAddress1.Text;

            _dr["Line5"] = tbEMSAddress2.Text;

            _dr["Line6"] = tbEMSPhone.Text;

            _dr["Line7"] = tbEMSFax.Text;

            _dr["Line8"] = tbEMSEmail.Text;
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            _ret = false;
            Close();
        }

    }
}
