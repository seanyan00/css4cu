﻿namespace CRFS.AdministrativeTools
{
    partial class frmAdministrativeTools
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.mnuMain = new System.Windows.Forms.MenuStrip();
            this.mnuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFile_Save = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuFile_Exit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuHelp_About = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlAdminTools = new System.Windows.Forms.Panel();
            this.tabAppAccessMain = new System.Windows.Forms.TabControl();
            this.tabP_AppAccess = new System.Windows.Forms.TabPage();
            this.pnlAppAccess = new System.Windows.Forms.Panel();
            this.tblLoPnl_AppAccess = new System.Windows.Forms.TableLayoutPanel();
            this.pnlAppAccessControls = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.tblLOPnlAppAccessValues = new System.Windows.Forms.TableLayoutPanel();
            this.pnlAppAccessSelections = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnAddUserToApp = new System.Windows.Forms.Button();
            this.cboUserSelect = new System.Windows.Forms.ComboBox();
            this.cboAppSelect = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlAppAccessSettings = new System.Windows.Forms.Panel();
            this.dgvUserAccessRights = new System.Windows.Forms.DataGridView();
            this.tabP_UserAdmin = new System.Windows.Forms.TabPage();
            this.pnlUserAdmin = new System.Windows.Forms.Panel();
            this.btn_User_Cancel = new System.Windows.Forms.Button();
            this.btn_User_Save = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtUserEmail = new System.Windows.Forms.TextBox();
            this.txtUserPhone = new System.Windows.Forms.TextBox();
            this.btn_User_ResetPassword = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.cbo_User_SelectUser = new System.Windows.Forms.ComboBox();
            this.tab_LockAdmin = new System.Windows.Forms.TabPage();
            this.pnlLockControls = new System.Windows.Forms.Panel();
            this.btnDeleteLock = new System.Windows.Forms.Button();
            this.pnlLockAdmin = new System.Windows.Forms.Panel();
            this.tblLOPnlLockValues = new System.Windows.Forms.TableLayoutPanel();
            this.pnlLockList = new System.Windows.Forms.Panel();
            this.dgvLockAdmin = new System.Windows.Forms.DataGridView();
            this.pnlLockAppAccessSelection = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.cboLockAppSelect = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tabP_ServicerMIAdmin = new System.Windows.Forms.TabPage();
            this.pnlServicerMIAdmin = new System.Windows.Forms.Panel();
            this.btn_ServicerMI_MoveRight = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.lblSlectEntity = new System.Windows.Forms.Label();
            this.cbo_ServicerMI_SelectEntity = new System.Windows.Forms.ComboBox();
            this.btnRemoveContact = new System.Windows.Forms.Button();
            this.btnAddContact = new System.Windows.Forms.Button();
            this.dgvEntityContacts = new System.Windows.Forms.DataGridView();
            this.btn_ServicerMI_Cancel = new System.Windows.Forms.Button();
            this.cbo_ServicerMI_SelectGroup = new System.Windows.Forms.ComboBox();
            this.chkExcludeFNMAClaimFiledUpdateRpt = new System.Windows.Forms.CheckBox();
            this.cbo_ServicerMI_AppSelect = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.chkIsBackend = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.cbo_ServicerMI_EntityType = new System.Windows.Forms.ComboBox();
            this.btn_ServicerMI_Save = new System.Windows.Forms.Button();
            this.btn_ServicerMI_MoveLeft = new System.Windows.Forms.Button();
            this.dgvEntityGroups = new System.Windows.Forms.DataGridView();
            this.label9 = new System.Windows.Forms.Label();
            this.tabP_ClientSpecificSecurity = new System.Windows.Forms.TabPage();
            this.pnlClientSecurityMain = new System.Windows.Forms.TableLayoutPanel();
            this.pnlCtrlButtons = new System.Windows.Forms.Panel();
            this.btn_CSSCancel = new System.Windows.Forms.Button();
            this.btn_CSSSave = new System.Windows.Forms.Button();
            this.pnlSetupAndDisplay = new System.Windows.Forms.TableLayoutPanel();
            this.pnlUserSetup = new System.Windows.Forms.Panel();
            this.btnCSSecurityAddUser = new System.Windows.Forms.Button();
            this.cboCSSecurityAddUser = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.pnlClientSecuritySettings = new System.Windows.Forms.Panel();
            this.dgvClientSecritySettings = new System.Windows.Forms.DataGridView();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.stsSaveStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.mnuMain.SuspendLayout();
            this.pnlAdminTools.SuspendLayout();
            this.tabAppAccessMain.SuspendLayout();
            this.tabP_AppAccess.SuspendLayout();
            this.pnlAppAccess.SuspendLayout();
            this.tblLoPnl_AppAccess.SuspendLayout();
            this.pnlAppAccessControls.SuspendLayout();
            this.tblLOPnlAppAccessValues.SuspendLayout();
            this.pnlAppAccessSelections.SuspendLayout();
            this.pnlAppAccessSettings.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUserAccessRights)).BeginInit();
            this.tabP_UserAdmin.SuspendLayout();
            this.pnlUserAdmin.SuspendLayout();
            this.tab_LockAdmin.SuspendLayout();
            this.pnlLockControls.SuspendLayout();
            this.pnlLockAdmin.SuspendLayout();
            this.tblLOPnlLockValues.SuspendLayout();
            this.pnlLockList.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLockAdmin)).BeginInit();
            this.pnlLockAppAccessSelection.SuspendLayout();
            this.tabP_ServicerMIAdmin.SuspendLayout();
            this.pnlServicerMIAdmin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEntityContacts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEntityGroups)).BeginInit();
            this.tabP_ClientSpecificSecurity.SuspendLayout();
            this.pnlClientSecurityMain.SuspendLayout();
            this.pnlCtrlButtons.SuspendLayout();
            this.pnlSetupAndDisplay.SuspendLayout();
            this.pnlUserSetup.SuspendLayout();
            this.pnlClientSecuritySettings.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClientSecritySettings)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnuMain
            // 
            this.mnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFile,
            this.mnuHelp});
            this.mnuMain.Location = new System.Drawing.Point(0, 0);
            this.mnuMain.Name = "mnuMain";
            this.mnuMain.Size = new System.Drawing.Size(835, 24);
            this.mnuMain.TabIndex = 1;
            this.mnuMain.Text = "menuStrip1";
            // 
            // mnuFile
            // 
            this.mnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFile_Save,
            this.toolStripSeparator1,
            this.mnuFile_Exit});
            this.mnuFile.Name = "mnuFile";
            this.mnuFile.Size = new System.Drawing.Size(35, 20);
            this.mnuFile.Text = "&File";
            // 
            // mnuFile_Save
            // 
            this.mnuFile_Save.Name = "mnuFile_Save";
            this.mnuFile_Save.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.mnuFile_Save.Size = new System.Drawing.Size(136, 22);
            this.mnuFile_Save.Text = "&Save";
            this.mnuFile_Save.Click += new System.EventHandler(this.mnuFile_Save_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(133, 6);
            // 
            // mnuFile_Exit
            // 
            this.mnuFile_Exit.Name = "mnuFile_Exit";
            this.mnuFile_Exit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F4)));
            this.mnuFile_Exit.Size = new System.Drawing.Size(136, 22);
            this.mnuFile_Exit.Text = "E&xit";
            this.mnuFile_Exit.Click += new System.EventHandler(this.mnuFile_Exit_Click);
            // 
            // mnuHelp
            // 
            this.mnuHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuHelp_About});
            this.mnuHelp.Name = "mnuHelp";
            this.mnuHelp.Size = new System.Drawing.Size(40, 20);
            this.mnuHelp.Text = "&Help";
            // 
            // mnuHelp_About
            // 
            this.mnuHelp_About.Name = "mnuHelp_About";
            this.mnuHelp_About.Size = new System.Drawing.Size(103, 22);
            this.mnuHelp_About.Text = "&About";
            this.mnuHelp_About.Click += new System.EventHandler(this.mnuHelp_About_Click);
            // 
            // pnlAdminTools
            // 
            this.pnlAdminTools.Controls.Add(this.tabAppAccessMain);
            this.pnlAdminTools.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAdminTools.Location = new System.Drawing.Point(0, 24);
            this.pnlAdminTools.Name = "pnlAdminTools";
            this.pnlAdminTools.Size = new System.Drawing.Size(835, 544);
            this.pnlAdminTools.TabIndex = 4;
            // 
            // tabAppAccessMain
            // 
            this.tabAppAccessMain.Controls.Add(this.tabP_AppAccess);
            this.tabAppAccessMain.Controls.Add(this.tabP_UserAdmin);
            this.tabAppAccessMain.Controls.Add(this.tab_LockAdmin);
            this.tabAppAccessMain.Controls.Add(this.tabP_ServicerMIAdmin);
            this.tabAppAccessMain.Controls.Add(this.tabP_ClientSpecificSecurity);
            this.tabAppAccessMain.Dock = System.Windows.Forms.DockStyle.Top;
            this.tabAppAccessMain.Location = new System.Drawing.Point(0, 0);
            this.tabAppAccessMain.Name = "tabAppAccessMain";
            this.tabAppAccessMain.SelectedIndex = 0;
            this.tabAppAccessMain.Size = new System.Drawing.Size(835, 523);
            this.tabAppAccessMain.TabIndex = 0;
            this.tabAppAccessMain.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabAppAccessMain_Selecting);
            // 
            // tabP_AppAccess
            // 
            this.tabP_AppAccess.Controls.Add(this.pnlAppAccess);
            this.tabP_AppAccess.Location = new System.Drawing.Point(4, 22);
            this.tabP_AppAccess.Name = "tabP_AppAccess";
            this.tabP_AppAccess.Padding = new System.Windows.Forms.Padding(3);
            this.tabP_AppAccess.Size = new System.Drawing.Size(827, 497);
            this.tabP_AppAccess.TabIndex = 0;
            this.tabP_AppAccess.Text = "Application Access Administration";
            this.tabP_AppAccess.UseVisualStyleBackColor = true;
            this.tabP_AppAccess.Click += new System.EventHandler(this.tabP_AppAccess_Click);
            // 
            // pnlAppAccess
            // 
            this.pnlAppAccess.Controls.Add(this.tblLoPnl_AppAccess);
            this.pnlAppAccess.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAppAccess.Location = new System.Drawing.Point(3, 3);
            this.pnlAppAccess.Name = "pnlAppAccess";
            this.pnlAppAccess.Size = new System.Drawing.Size(821, 491);
            this.pnlAppAccess.TabIndex = 0;
            // 
            // tblLoPnl_AppAccess
            // 
            this.tblLoPnl_AppAccess.ColumnCount = 1;
            this.tblLoPnl_AppAccess.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblLoPnl_AppAccess.Controls.Add(this.pnlAppAccessControls, 0, 1);
            this.tblLoPnl_AppAccess.Controls.Add(this.tblLOPnlAppAccessValues, 0, 0);
            this.tblLoPnl_AppAccess.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblLoPnl_AppAccess.Location = new System.Drawing.Point(0, 0);
            this.tblLoPnl_AppAccess.Name = "tblLoPnl_AppAccess";
            this.tblLoPnl_AppAccess.RowCount = 2;
            this.tblLoPnl_AppAccess.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 85F));
            this.tblLoPnl_AppAccess.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tblLoPnl_AppAccess.Size = new System.Drawing.Size(821, 491);
            this.tblLoPnl_AppAccess.TabIndex = 0;
            // 
            // pnlAppAccessControls
            // 
            this.pnlAppAccessControls.Controls.Add(this.btnCancel);
            this.pnlAppAccessControls.Controls.Add(this.btnSave);
            this.pnlAppAccessControls.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlAppAccessControls.Location = new System.Drawing.Point(3, 423);
            this.pnlAppAccessControls.Name = "pnlAppAccessControls";
            this.pnlAppAccessControls.Size = new System.Drawing.Size(815, 65);
            this.pnlAppAccessControls.TabIndex = 0;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(427, 29);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(312, 29);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 0;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // tblLOPnlAppAccessValues
            // 
            this.tblLOPnlAppAccessValues.ColumnCount = 2;
            this.tblLOPnlAppAccessValues.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tblLOPnlAppAccessValues.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tblLOPnlAppAccessValues.Controls.Add(this.pnlAppAccessSelections, 0, 0);
            this.tblLOPnlAppAccessValues.Controls.Add(this.pnlAppAccessSettings, 1, 0);
            this.tblLOPnlAppAccessValues.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblLOPnlAppAccessValues.Location = new System.Drawing.Point(3, 3);
            this.tblLOPnlAppAccessValues.Name = "tblLOPnlAppAccessValues";
            this.tblLOPnlAppAccessValues.RowCount = 1;
            this.tblLOPnlAppAccessValues.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblLOPnlAppAccessValues.Size = new System.Drawing.Size(815, 411);
            this.tblLOPnlAppAccessValues.TabIndex = 1;
            // 
            // pnlAppAccessSelections
            // 
            this.pnlAppAccessSelections.Controls.Add(this.label4);
            this.pnlAppAccessSelections.Controls.Add(this.label3);
            this.pnlAppAccessSelections.Controls.Add(this.btnAddUserToApp);
            this.pnlAppAccessSelections.Controls.Add(this.cboUserSelect);
            this.pnlAppAccessSelections.Controls.Add(this.cboAppSelect);
            this.pnlAppAccessSelections.Controls.Add(this.label2);
            this.pnlAppAccessSelections.Controls.Add(this.label1);
            this.pnlAppAccessSelections.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAppAccessSelections.Location = new System.Drawing.Point(3, 3);
            this.pnlAppAccessSelections.Name = "pnlAppAccessSelections";
            this.pnlAppAccessSelections.Size = new System.Drawing.Size(238, 405);
            this.pnlAppAccessSelections.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 164);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(223, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "column is disabled due to your level of access";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 151);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(214, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Note: If you cannot check a checkbox, that";
            // 
            // btnAddUserToApp
            // 
            this.btnAddUserToApp.Location = new System.Drawing.Point(9, 116);
            this.btnAddUserToApp.Name = "btnAddUserToApp";
            this.btnAddUserToApp.Size = new System.Drawing.Size(75, 23);
            this.btnAddUserToApp.TabIndex = 4;
            this.btnAddUserToApp.Text = "Add User";
            this.btnAddUserToApp.UseVisualStyleBackColor = true;
            this.btnAddUserToApp.Click += new System.EventHandler(this.btnAddUserToApp_Click);
            // 
            // cboUserSelect
            // 
            this.cboUserSelect.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cboUserSelect.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboUserSelect.FormattingEnabled = true;
            this.cboUserSelect.Location = new System.Drawing.Point(6, 89);
            this.cboUserSelect.Name = "cboUserSelect";
            this.cboUserSelect.Size = new System.Drawing.Size(213, 21);
            this.cboUserSelect.TabIndex = 3;
            this.cboUserSelect.SelectedIndexChanged += new System.EventHandler(this.cboUserSelect_SelectedIndexChanged);
            // 
            // cboAppSelect
            // 
            this.cboAppSelect.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cboAppSelect.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboAppSelect.FormattingEnabled = true;
            this.cboAppSelect.Location = new System.Drawing.Point(6, 23);
            this.cboAppSelect.Name = "cboAppSelect";
            this.cboAppSelect.Size = new System.Drawing.Size(213, 21);
            this.cboAppSelect.TabIndex = 2;
            this.cboAppSelect.SelectedIndexChanged += new System.EventHandler(this.cboAppSelect_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Additional Users";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Applications";
            // 
            // pnlAppAccessSettings
            // 
            this.pnlAppAccessSettings.Controls.Add(this.dgvUserAccessRights);
            this.pnlAppAccessSettings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAppAccessSettings.Location = new System.Drawing.Point(247, 3);
            this.pnlAppAccessSettings.Name = "pnlAppAccessSettings";
            this.pnlAppAccessSettings.Size = new System.Drawing.Size(565, 405);
            this.pnlAppAccessSettings.TabIndex = 1;
            // 
            // dgvUserAccessRights
            // 
            this.dgvUserAccessRights.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUserAccessRights.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvUserAccessRights.Location = new System.Drawing.Point(0, 0);
            this.dgvUserAccessRights.Name = "dgvUserAccessRights";
            this.dgvUserAccessRights.Size = new System.Drawing.Size(565, 405);
            this.dgvUserAccessRights.TabIndex = 0;
            this.dgvUserAccessRights.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvUserAccessRights_CellContentClick);
            this.dgvUserAccessRights.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.dgvUserAccessRights_UserDeletingRow);
            // 
            // tabP_UserAdmin
            // 
            this.tabP_UserAdmin.Controls.Add(this.pnlUserAdmin);
            this.tabP_UserAdmin.Location = new System.Drawing.Point(4, 22);
            this.tabP_UserAdmin.Name = "tabP_UserAdmin";
            this.tabP_UserAdmin.Padding = new System.Windows.Forms.Padding(3);
            this.tabP_UserAdmin.Size = new System.Drawing.Size(827, 497);
            this.tabP_UserAdmin.TabIndex = 1;
            this.tabP_UserAdmin.Text = "User Administration";
            this.tabP_UserAdmin.UseVisualStyleBackColor = true;
            this.tabP_UserAdmin.Click += new System.EventHandler(this.tabP_UserAdmin_Click);
            // 
            // pnlUserAdmin
            // 
            this.pnlUserAdmin.Controls.Add(this.btn_User_Cancel);
            this.pnlUserAdmin.Controls.Add(this.btn_User_Save);
            this.pnlUserAdmin.Controls.Add(this.label7);
            this.pnlUserAdmin.Controls.Add(this.label6);
            this.pnlUserAdmin.Controls.Add(this.txtUserEmail);
            this.pnlUserAdmin.Controls.Add(this.txtUserPhone);
            this.pnlUserAdmin.Controls.Add(this.btn_User_ResetPassword);
            this.pnlUserAdmin.Controls.Add(this.label5);
            this.pnlUserAdmin.Controls.Add(this.cbo_User_SelectUser);
            this.pnlUserAdmin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlUserAdmin.Location = new System.Drawing.Point(3, 3);
            this.pnlUserAdmin.Name = "pnlUserAdmin";
            this.pnlUserAdmin.Size = new System.Drawing.Size(821, 491);
            this.pnlUserAdmin.TabIndex = 0;
            // 
            // btn_User_Cancel
            // 
            this.btn_User_Cancel.Location = new System.Drawing.Point(152, 161);
            this.btn_User_Cancel.Name = "btn_User_Cancel";
            this.btn_User_Cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_User_Cancel.TabIndex = 12;
            this.btn_User_Cancel.Text = "Cancel";
            this.btn_User_Cancel.UseVisualStyleBackColor = true;
            this.btn_User_Cancel.Click += new System.EventHandler(this.btn_User_Cancel_Click);
            // 
            // btn_User_Save
            // 
            this.btn_User_Save.Location = new System.Drawing.Point(14, 161);
            this.btn_User_Save.Name = "btn_User_Save";
            this.btn_User_Save.Size = new System.Drawing.Size(75, 23);
            this.btn_User_Save.TabIndex = 11;
            this.btn_User_Save.Text = "Save";
            this.btn_User_Save.UseVisualStyleBackColor = true;
            this.btn_User_Save.Click += new System.EventHandler(this.btn_User_Save_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(14, 119);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Email Address";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(14, 73);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Phone Number";
            // 
            // txtUserEmail
            // 
            this.txtUserEmail.Location = new System.Drawing.Point(14, 135);
            this.txtUserEmail.Name = "txtUserEmail";
            this.txtUserEmail.Size = new System.Drawing.Size(213, 20);
            this.txtUserEmail.TabIndex = 8;
            this.txtUserEmail.TextChanged += new System.EventHandler(this.txtUserEmail_TextChanged);
            // 
            // txtUserPhone
            // 
            this.txtUserPhone.Location = new System.Drawing.Point(14, 89);
            this.txtUserPhone.Name = "txtUserPhone";
            this.txtUserPhone.Size = new System.Drawing.Size(213, 20);
            this.txtUserPhone.TabIndex = 7;
            this.txtUserPhone.TextChanged += new System.EventHandler(this.txtUserPhone_TextChanged);
            // 
            // btn_User_ResetPassword
            // 
            this.btn_User_ResetPassword.Location = new System.Drawing.Point(14, 346);
            this.btn_User_ResetPassword.Name = "btn_User_ResetPassword";
            this.btn_User_ResetPassword.Size = new System.Drawing.Size(213, 23);
            this.btn_User_ResetPassword.TabIndex = 6;
            this.btn_User_ResetPassword.Text = "Reset Selected User\'s Password";
            this.btn_User_ResetPassword.UseVisualStyleBackColor = true;
            this.btn_User_ResetPassword.Click += new System.EventHandler(this.btn_User_ResetPassword_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(14, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Select User";
            // 
            // cbo_User_SelectUser
            // 
            this.cbo_User_SelectUser.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cbo_User_SelectUser.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbo_User_SelectUser.FormattingEnabled = true;
            this.cbo_User_SelectUser.Location = new System.Drawing.Point(14, 28);
            this.cbo_User_SelectUser.Name = "cbo_User_SelectUser";
            this.cbo_User_SelectUser.Size = new System.Drawing.Size(213, 21);
            this.cbo_User_SelectUser.TabIndex = 4;
            this.cbo_User_SelectUser.SelectedIndexChanged += new System.EventHandler(this.cbo_User_SelectUser_SelectedIndexChanged);
            // 
            // tab_LockAdmin
            // 
            this.tab_LockAdmin.Controls.Add(this.pnlLockControls);
            this.tab_LockAdmin.Controls.Add(this.pnlLockAdmin);
            this.tab_LockAdmin.Location = new System.Drawing.Point(4, 22);
            this.tab_LockAdmin.Name = "tab_LockAdmin";
            this.tab_LockAdmin.Size = new System.Drawing.Size(827, 497);
            this.tab_LockAdmin.TabIndex = 2;
            this.tab_LockAdmin.Text = "Claim Lock Administration";
            this.tab_LockAdmin.UseVisualStyleBackColor = true;
            this.tab_LockAdmin.Click += new System.EventHandler(this.tab_LockAdmin_Click);
            // 
            // pnlLockControls
            // 
            this.pnlLockControls.Controls.Add(this.btnDeleteLock);
            this.pnlLockControls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlLockControls.Location = new System.Drawing.Point(0, 370);
            this.pnlLockControls.Name = "pnlLockControls";
            this.pnlLockControls.Size = new System.Drawing.Size(827, 127);
            this.pnlLockControls.TabIndex = 1;
            // 
            // btnDeleteLock
            // 
            this.btnDeleteLock.Location = new System.Drawing.Point(498, 37);
            this.btnDeleteLock.Name = "btnDeleteLock";
            this.btnDeleteLock.Size = new System.Drawing.Size(119, 49);
            this.btnDeleteLock.TabIndex = 0;
            this.btnDeleteLock.Text = "Delete Lock";
            this.btnDeleteLock.UseVisualStyleBackColor = true;
            this.btnDeleteLock.Click += new System.EventHandler(this.btnDeleteLock_Click);
            // 
            // pnlLockAdmin
            // 
            this.pnlLockAdmin.Controls.Add(this.tblLOPnlLockValues);
            this.pnlLockAdmin.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlLockAdmin.Location = new System.Drawing.Point(0, 0);
            this.pnlLockAdmin.Name = "pnlLockAdmin";
            this.pnlLockAdmin.Size = new System.Drawing.Size(827, 370);
            this.pnlLockAdmin.TabIndex = 0;
            // 
            // tblLOPnlLockValues
            // 
            this.tblLOPnlLockValues.ColumnCount = 2;
            this.tblLOPnlLockValues.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tblLOPnlLockValues.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tblLOPnlLockValues.Controls.Add(this.pnlLockList, 1, 0);
            this.tblLOPnlLockValues.Controls.Add(this.pnlLockAppAccessSelection, 0, 0);
            this.tblLOPnlLockValues.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblLOPnlLockValues.Location = new System.Drawing.Point(0, 0);
            this.tblLOPnlLockValues.Name = "tblLOPnlLockValues";
            this.tblLOPnlLockValues.RowCount = 1;
            this.tblLOPnlLockValues.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblLOPnlLockValues.Size = new System.Drawing.Size(827, 370);
            this.tblLOPnlLockValues.TabIndex = 0;
            // 
            // pnlLockList
            // 
            this.pnlLockList.Controls.Add(this.dgvLockAdmin);
            this.pnlLockList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlLockList.Location = new System.Drawing.Point(251, 3);
            this.pnlLockList.Name = "pnlLockList";
            this.pnlLockList.Size = new System.Drawing.Size(573, 364);
            this.pnlLockList.TabIndex = 0;
            // 
            // dgvLockAdmin
            // 
            this.dgvLockAdmin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLockAdmin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvLockAdmin.Location = new System.Drawing.Point(0, 0);
            this.dgvLockAdmin.Name = "dgvLockAdmin";
            this.dgvLockAdmin.Size = new System.Drawing.Size(573, 364);
            this.dgvLockAdmin.TabIndex = 1;
            this.dgvLockAdmin.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvLockAdmin_CellContentClick);
            this.dgvLockAdmin.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvLockAdmin_RowHeaderMouseClick);
            this.dgvLockAdmin.UserDeletedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.dgvLockAdmin_UserDeletedRow);
            // 
            // pnlLockAppAccessSelection
            // 
            this.pnlLockAppAccessSelection.Controls.Add(this.textBox1);
            this.pnlLockAppAccessSelection.Controls.Add(this.cboLockAppSelect);
            this.pnlLockAppAccessSelection.Controls.Add(this.label12);
            this.pnlLockAppAccessSelection.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlLockAppAccessSelection.Location = new System.Drawing.Point(3, 3);
            this.pnlLockAppAccessSelection.Name = "pnlLockAppAccessSelection";
            this.pnlLockAppAccessSelection.Size = new System.Drawing.Size(242, 364);
            this.pnlLockAppAccessSelection.TabIndex = 1;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(15, 9);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(213, 76);
            this.textBox1.TabIndex = 5;
            this.textBox1.Text = "Instructions: Select the application from the list above to display the current l" +
    "ocks for. Select the lock to delete and click the \'Delete Lock\' button. The lock" +
    " is deleted immediately.";
            // 
            // cboLockAppSelect
            // 
            this.cboLockAppSelect.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cboLockAppSelect.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboLockAppSelect.FormattingEnabled = true;
            this.cboLockAppSelect.Location = new System.Drawing.Point(15, 118);
            this.cboLockAppSelect.Name = "cboLockAppSelect";
            this.cboLockAppSelect.Size = new System.Drawing.Size(213, 21);
            this.cboLockAppSelect.TabIndex = 4;
            this.cboLockAppSelect.SelectedIndexChanged += new System.EventHandler(this.cboLockAppSelect_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(15, 101);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(76, 13);
            this.label12.TabIndex = 3;
            this.label12.Text = "Applications";
            // 
            // tabP_ServicerMIAdmin
            // 
            this.tabP_ServicerMIAdmin.Controls.Add(this.pnlServicerMIAdmin);
            this.tabP_ServicerMIAdmin.Location = new System.Drawing.Point(4, 22);
            this.tabP_ServicerMIAdmin.Name = "tabP_ServicerMIAdmin";
            this.tabP_ServicerMIAdmin.Size = new System.Drawing.Size(827, 497);
            this.tabP_ServicerMIAdmin.TabIndex = 3;
            this.tabP_ServicerMIAdmin.Text = "Servicer/MI Administration";
            this.tabP_ServicerMIAdmin.UseVisualStyleBackColor = true;
            this.tabP_ServicerMIAdmin.Click += new System.EventHandler(this.tabP_ServicerMIAdmin_Click);
            // 
            // pnlServicerMIAdmin
            // 
            this.pnlServicerMIAdmin.Controls.Add(this.btn_ServicerMI_MoveRight);
            this.pnlServicerMIAdmin.Controls.Add(this.label16);
            this.pnlServicerMIAdmin.Controls.Add(this.lblSlectEntity);
            this.pnlServicerMIAdmin.Controls.Add(this.cbo_ServicerMI_SelectEntity);
            this.pnlServicerMIAdmin.Controls.Add(this.btnRemoveContact);
            this.pnlServicerMIAdmin.Controls.Add(this.btnAddContact);
            this.pnlServicerMIAdmin.Controls.Add(this.dgvEntityContacts);
            this.pnlServicerMIAdmin.Controls.Add(this.btn_ServicerMI_Cancel);
            this.pnlServicerMIAdmin.Controls.Add(this.cbo_ServicerMI_SelectGroup);
            this.pnlServicerMIAdmin.Controls.Add(this.chkExcludeFNMAClaimFiledUpdateRpt);
            this.pnlServicerMIAdmin.Controls.Add(this.cbo_ServicerMI_AppSelect);
            this.pnlServicerMIAdmin.Controls.Add(this.label13);
            this.pnlServicerMIAdmin.Controls.Add(this.chkIsBackend);
            this.pnlServicerMIAdmin.Controls.Add(this.label10);
            this.pnlServicerMIAdmin.Controls.Add(this.label8);
            this.pnlServicerMIAdmin.Controls.Add(this.cbo_ServicerMI_EntityType);
            this.pnlServicerMIAdmin.Controls.Add(this.btn_ServicerMI_Save);
            this.pnlServicerMIAdmin.Controls.Add(this.btn_ServicerMI_MoveLeft);
            this.pnlServicerMIAdmin.Controls.Add(this.dgvEntityGroups);
            this.pnlServicerMIAdmin.Controls.Add(this.label9);
            this.pnlServicerMIAdmin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlServicerMIAdmin.Location = new System.Drawing.Point(0, 0);
            this.pnlServicerMIAdmin.Name = "pnlServicerMIAdmin";
            this.pnlServicerMIAdmin.Size = new System.Drawing.Size(827, 497);
            this.pnlServicerMIAdmin.TabIndex = 0;
            // 
            // btn_ServicerMI_MoveRight
            // 
            this.btn_ServicerMI_MoveRight.Location = new System.Drawing.Point(544, 62);
            this.btn_ServicerMI_MoveRight.Name = "btn_ServicerMI_MoveRight";
            this.btn_ServicerMI_MoveRight.Size = new System.Drawing.Size(110, 23);
            this.btn_ServicerMI_MoveRight.TabIndex = 5;
            this.btn_ServicerMI_MoveRight.Text = "Add to Group";
            this.btn_ServicerMI_MoveRight.UseVisualStyleBackColor = true;
            this.btn_ServicerMI_MoveRight.Click += new System.EventHandler(this.btn_ServicerMI_MoveRight_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(3, 296);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(95, 13);
            this.label16.TabIndex = 35;
            this.label16.Text = "Group Contacts";
            // 
            // lblSlectEntity
            // 
            this.lblSlectEntity.AutoSize = true;
            this.lblSlectEntity.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSlectEntity.Location = new System.Drawing.Point(272, 48);
            this.lblSlectEntity.Name = "lblSlectEntity";
            this.lblSlectEntity.Size = new System.Drawing.Size(133, 13);
            this.lblSlectEntity.TabIndex = 16;
            this.lblSlectEntity.Text = "Select Business Name";
            // 
            // cbo_ServicerMI_SelectEntity
            // 
            this.cbo_ServicerMI_SelectEntity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cbo_ServicerMI_SelectEntity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbo_ServicerMI_SelectEntity.FormattingEnabled = true;
            this.cbo_ServicerMI_SelectEntity.Location = new System.Drawing.Point(275, 64);
            this.cbo_ServicerMI_SelectEntity.Name = "cbo_ServicerMI_SelectEntity";
            this.cbo_ServicerMI_SelectEntity.Size = new System.Drawing.Size(263, 21);
            this.cbo_ServicerMI_SelectEntity.TabIndex = 4;
            this.cbo_ServicerMI_SelectEntity.SelectedIndexChanged += new System.EventHandler(this.cbo_ServicerMI_SelectEntity_SelectedIndexChanged);
            // 
            // btnRemoveContact
            // 
            this.btnRemoveContact.AutoSize = true;
            this.btnRemoveContact.Location = new System.Drawing.Point(194, 286);
            this.btnRemoveContact.Name = "btnRemoveContact";
            this.btnRemoveContact.Size = new System.Drawing.Size(97, 23);
            this.btnRemoveContact.TabIndex = 10;
            this.btnRemoveContact.Text = "Remove Contact";
            this.btnRemoveContact.UseVisualStyleBackColor = true;
            this.btnRemoveContact.Click += new System.EventHandler(this.btnRemoveContact_Click);
            // 
            // btnAddContact
            // 
            this.btnAddContact.AutoSize = true;
            this.btnAddContact.Location = new System.Drawing.Point(110, 286);
            this.btnAddContact.Name = "btnAddContact";
            this.btnAddContact.Size = new System.Drawing.Size(76, 23);
            this.btnAddContact.TabIndex = 9;
            this.btnAddContact.Text = "Add Contact";
            this.btnAddContact.UseVisualStyleBackColor = true;
            this.btnAddContact.Click += new System.EventHandler(this.btnAddContact_Click);
            // 
            // dgvEntityContacts
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvEntityContacts.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvEntityContacts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvEntityContacts.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvEntityContacts.Location = new System.Drawing.Point(8, 312);
            this.dgvEntityContacts.MinimumSize = new System.Drawing.Size(402, 0);
            this.dgvEntityContacts.Name = "dgvEntityContacts";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvEntityContacts.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvEntityContacts.Size = new System.Drawing.Size(538, 152);
            this.dgvEntityContacts.TabIndex = 11;
            // 
            // btn_ServicerMI_Cancel
            // 
            this.btn_ServicerMI_Cancel.Location = new System.Drawing.Point(92, 470);
            this.btn_ServicerMI_Cancel.Name = "btn_ServicerMI_Cancel";
            this.btn_ServicerMI_Cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_ServicerMI_Cancel.TabIndex = 13;
            this.btn_ServicerMI_Cancel.Text = "Cancel";
            this.btn_ServicerMI_Cancel.UseVisualStyleBackColor = true;
            this.btn_ServicerMI_Cancel.Click += new System.EventHandler(this.btn_ServicerMI_Cancel_Click);
            // 
            // cbo_ServicerMI_SelectGroup
            // 
            this.cbo_ServicerMI_SelectGroup.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cbo_ServicerMI_SelectGroup.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbo_ServicerMI_SelectGroup.FormattingEnabled = true;
            this.cbo_ServicerMI_SelectGroup.Location = new System.Drawing.Point(6, 64);
            this.cbo_ServicerMI_SelectGroup.Name = "cbo_ServicerMI_SelectGroup";
            this.cbo_ServicerMI_SelectGroup.Size = new System.Drawing.Size(263, 21);
            this.cbo_ServicerMI_SelectGroup.TabIndex = 3;
            this.cbo_ServicerMI_SelectGroup.SelectedIndexChanged += new System.EventHandler(this.cbo_ServicerMI_SelectGroup_SelectedIndexChanged);
            // 
            // chkExcludeFNMAClaimFiledUpdateRpt
            // 
            this.chkExcludeFNMAClaimFiledUpdateRpt.AutoSize = true;
            this.chkExcludeFNMAClaimFiledUpdateRpt.Location = new System.Drawing.Point(611, 474);
            this.chkExcludeFNMAClaimFiledUpdateRpt.Name = "chkExcludeFNMAClaimFiledUpdateRpt";
            this.chkExcludeFNMAClaimFiledUpdateRpt.Size = new System.Drawing.Size(208, 17);
            this.chkExcludeFNMAClaimFiledUpdateRpt.TabIndex = 15;
            this.chkExcludeFNMAClaimFiledUpdateRpt.Text = "Exclude FNMA Claim Filed Update Rpt";
            this.chkExcludeFNMAClaimFiledUpdateRpt.UseVisualStyleBackColor = true;
            this.chkExcludeFNMAClaimFiledUpdateRpt.CheckedChanged += new System.EventHandler(this.chkExcludeFNMAClaimFiledUpdateRpt_CheckedChanged);
            // 
            // cbo_ServicerMI_AppSelect
            // 
            this.cbo_ServicerMI_AppSelect.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cbo_ServicerMI_AppSelect.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbo_ServicerMI_AppSelect.FormattingEnabled = true;
            this.cbo_ServicerMI_AppSelect.Location = new System.Drawing.Point(6, 24);
            this.cbo_ServicerMI_AppSelect.Name = "cbo_ServicerMI_AppSelect";
            this.cbo_ServicerMI_AppSelect.Size = new System.Drawing.Size(213, 21);
            this.cbo_ServicerMI_AppSelect.TabIndex = 0;
            this.cbo_ServicerMI_AppSelect.SelectedIndexChanged += new System.EventHandler(this.cbo_ServicerMI_AppSelect_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(3, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(76, 13);
            this.label13.TabIndex = 26;
            this.label13.Text = "Applications";
            // 
            // chkIsBackend
            // 
            this.chkIsBackend.AutoSize = true;
            this.chkIsBackend.Location = new System.Drawing.Point(525, 474);
            this.chkIsBackend.Name = "chkIsBackend";
            this.chkIsBackend.Size = new System.Drawing.Size(80, 17);
            this.chkIsBackend.TabIndex = 14;
            this.chkIsBackend.Text = "Is Backend";
            this.chkIsBackend.UseVisualStyleBackColor = true;
            this.chkIsBackend.CheckedChanged += new System.EventHandler(this.chkIsBackend_CheckedChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(5, 101);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(95, 13);
            this.label10.TabIndex = 18;
            this.label10.Text = "Group Members";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(220, 8);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(129, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Select Business Type";
            // 
            // cbo_ServicerMI_EntityType
            // 
            this.cbo_ServicerMI_EntityType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cbo_ServicerMI_EntityType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbo_ServicerMI_EntityType.FormattingEnabled = true;
            this.cbo_ServicerMI_EntityType.Location = new System.Drawing.Point(223, 24);
            this.cbo_ServicerMI_EntityType.Name = "cbo_ServicerMI_EntityType";
            this.cbo_ServicerMI_EntityType.Size = new System.Drawing.Size(167, 21);
            this.cbo_ServicerMI_EntityType.TabIndex = 1;
            this.cbo_ServicerMI_EntityType.SelectedIndexChanged += new System.EventHandler(this.cbo_ServicerMI_EntityType_SelectedIndexChanged);
            // 
            // btn_ServicerMI_Save
            // 
            this.btn_ServicerMI_Save.Location = new System.Drawing.Point(11, 470);
            this.btn_ServicerMI_Save.Name = "btn_ServicerMI_Save";
            this.btn_ServicerMI_Save.Size = new System.Drawing.Size(75, 23);
            this.btn_ServicerMI_Save.TabIndex = 12;
            this.btn_ServicerMI_Save.Text = "Save";
            this.btn_ServicerMI_Save.UseVisualStyleBackColor = true;
            this.btn_ServicerMI_Save.Click += new System.EventHandler(this.btn_ServicerMI_Save_Click);
            // 
            // btn_ServicerMI_MoveLeft
            // 
            this.btn_ServicerMI_MoveLeft.Location = new System.Drawing.Point(552, 117);
            this.btn_ServicerMI_MoveLeft.Name = "btn_ServicerMI_MoveLeft";
            this.btn_ServicerMI_MoveLeft.Size = new System.Drawing.Size(110, 23);
            this.btn_ServicerMI_MoveLeft.TabIndex = 7;
            this.btn_ServicerMI_MoveLeft.Text = "Remove from Group";
            this.btn_ServicerMI_MoveLeft.UseVisualStyleBackColor = true;
            this.btn_ServicerMI_MoveLeft.Click += new System.EventHandler(this.btn_ServicerMI_MoveLeft_Click);
            // 
            // dgvEntityGroups
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvEntityGroups.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvEntityGroups.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvEntityGroups.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgvEntityGroups.Location = new System.Drawing.Point(8, 117);
            this.dgvEntityGroups.MinimumSize = new System.Drawing.Size(402, 0);
            this.dgvEntityGroups.Name = "dgvEntityGroups";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvEntityGroups.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvEntityGroups.Size = new System.Drawing.Size(538, 162);
            this.dgvEntityGroups.TabIndex = 6;
            this.dgvEntityGroups.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvEntityGroups_CellContentClick);
            this.dgvEntityGroups.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvEntityGroups_RowHeaderMouseClick);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(3, 48);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 13);
            this.label9.TabIndex = 15;
            this.label9.Text = "Select Group";
            // 
            // tabP_ClientSpecificSecurity
            // 
            this.tabP_ClientSpecificSecurity.Controls.Add(this.pnlClientSecurityMain);
            this.tabP_ClientSpecificSecurity.Location = new System.Drawing.Point(4, 22);
            this.tabP_ClientSpecificSecurity.Name = "tabP_ClientSpecificSecurity";
            this.tabP_ClientSpecificSecurity.Size = new System.Drawing.Size(827, 497);
            this.tabP_ClientSpecificSecurity.TabIndex = 4;
            this.tabP_ClientSpecificSecurity.Text = "Client Specific Security";
            this.tabP_ClientSpecificSecurity.UseVisualStyleBackColor = true;
            // 
            // pnlClientSecurityMain
            // 
            this.pnlClientSecurityMain.ColumnCount = 1;
            this.pnlClientSecurityMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.pnlClientSecurityMain.Controls.Add(this.pnlCtrlButtons, 0, 1);
            this.pnlClientSecurityMain.Controls.Add(this.pnlSetupAndDisplay, 0, 0);
            this.pnlClientSecurityMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlClientSecurityMain.Location = new System.Drawing.Point(0, 0);
            this.pnlClientSecurityMain.Name = "pnlClientSecurityMain";
            this.pnlClientSecurityMain.RowCount = 2;
            this.pnlClientSecurityMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 85F));
            this.pnlClientSecurityMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.pnlClientSecurityMain.Size = new System.Drawing.Size(827, 497);
            this.pnlClientSecurityMain.TabIndex = 1;
            // 
            // pnlCtrlButtons
            // 
            this.pnlCtrlButtons.Controls.Add(this.btn_CSSCancel);
            this.pnlCtrlButtons.Controls.Add(this.btn_CSSSave);
            this.pnlCtrlButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlCtrlButtons.Location = new System.Drawing.Point(3, 425);
            this.pnlCtrlButtons.Name = "pnlCtrlButtons";
            this.pnlCtrlButtons.Size = new System.Drawing.Size(821, 69);
            this.pnlCtrlButtons.TabIndex = 0;
            // 
            // btn_CSSCancel
            // 
            this.btn_CSSCancel.Location = new System.Drawing.Point(427, 29);
            this.btn_CSSCancel.Name = "btn_CSSCancel";
            this.btn_CSSCancel.Size = new System.Drawing.Size(75, 23);
            this.btn_CSSCancel.TabIndex = 3;
            this.btn_CSSCancel.Text = "Cancel";
            this.btn_CSSCancel.UseVisualStyleBackColor = true;
            this.btn_CSSCancel.Click += new System.EventHandler(this.btn_CSSCancel_Click);
            // 
            // btn_CSSSave
            // 
            this.btn_CSSSave.Location = new System.Drawing.Point(317, 29);
            this.btn_CSSSave.Name = "btn_CSSSave";
            this.btn_CSSSave.Size = new System.Drawing.Size(75, 23);
            this.btn_CSSSave.TabIndex = 2;
            this.btn_CSSSave.Text = "Save";
            this.btn_CSSSave.UseVisualStyleBackColor = true;
            this.btn_CSSSave.Click += new System.EventHandler(this.btn_CSSSave_Click);
            // 
            // pnlSetupAndDisplay
            // 
            this.pnlSetupAndDisplay.ColumnCount = 2;
            this.pnlSetupAndDisplay.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28F));
            this.pnlSetupAndDisplay.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 72F));
            this.pnlSetupAndDisplay.Controls.Add(this.pnlUserSetup, 0, 0);
            this.pnlSetupAndDisplay.Controls.Add(this.pnlClientSecuritySettings, 1, 0);
            this.pnlSetupAndDisplay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlSetupAndDisplay.Location = new System.Drawing.Point(3, 3);
            this.pnlSetupAndDisplay.Name = "pnlSetupAndDisplay";
            this.pnlSetupAndDisplay.RowCount = 1;
            this.pnlSetupAndDisplay.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.pnlSetupAndDisplay.Size = new System.Drawing.Size(821, 416);
            this.pnlSetupAndDisplay.TabIndex = 1;
            // 
            // pnlUserSetup
            // 
            this.pnlUserSetup.Controls.Add(this.btnCSSecurityAddUser);
            this.pnlUserSetup.Controls.Add(this.cboCSSecurityAddUser);
            this.pnlUserSetup.Controls.Add(this.label14);
            this.pnlUserSetup.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlUserSetup.Location = new System.Drawing.Point(3, 3);
            this.pnlUserSetup.Name = "pnlUserSetup";
            this.pnlUserSetup.Size = new System.Drawing.Size(223, 410);
            this.pnlUserSetup.TabIndex = 0;
            // 
            // btnCSSecurityAddUser
            // 
            this.btnCSSecurityAddUser.Location = new System.Drawing.Point(6, 47);
            this.btnCSSecurityAddUser.Name = "btnCSSecurityAddUser";
            this.btnCSSecurityAddUser.Size = new System.Drawing.Size(75, 23);
            this.btnCSSecurityAddUser.TabIndex = 7;
            this.btnCSSecurityAddUser.Text = "Add User";
            this.btnCSSecurityAddUser.UseVisualStyleBackColor = true;
            this.btnCSSecurityAddUser.Click += new System.EventHandler(this.btnCSSecurityAddUser_Click);
            // 
            // cboCSSecurityAddUser
            // 
            this.cboCSSecurityAddUser.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cboCSSecurityAddUser.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboCSSecurityAddUser.FormattingEnabled = true;
            this.cboCSSecurityAddUser.Location = new System.Drawing.Point(3, 20);
            this.cboCSSecurityAddUser.Name = "cboCSSecurityAddUser";
            this.cboCSSecurityAddUser.Size = new System.Drawing.Size(213, 21);
            this.cboCSSecurityAddUser.TabIndex = 6;
            this.cboCSSecurityAddUser.SelectedIndexChanged += new System.EventHandler(this.cboCSSecurityAddUser_SelectedIndexChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(3, 3);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(99, 13);
            this.label14.TabIndex = 5;
            this.label14.Text = "Additional Users";
            // 
            // pnlClientSecuritySettings
            // 
            this.pnlClientSecuritySettings.Controls.Add(this.dgvClientSecritySettings);
            this.pnlClientSecuritySettings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlClientSecuritySettings.Location = new System.Drawing.Point(232, 3);
            this.pnlClientSecuritySettings.Name = "pnlClientSecuritySettings";
            this.pnlClientSecuritySettings.Size = new System.Drawing.Size(586, 410);
            this.pnlClientSecuritySettings.TabIndex = 1;
            // 
            // dgvClientSecritySettings
            // 
            this.dgvClientSecritySettings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvClientSecritySettings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvClientSecritySettings.Location = new System.Drawing.Point(0, 0);
            this.dgvClientSecritySettings.Name = "dgvClientSecritySettings";
            this.dgvClientSecritySettings.Size = new System.Drawing.Size(586, 410);
            this.dgvClientSecritySettings.TabIndex = 0;
            this.dgvClientSecritySettings.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvClientSecritySettings_CellContentClick);
            this.dgvClientSecritySettings.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.dgvClientSecritySettings_UserDeletingRow);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stsSaveStatus});
            this.statusStrip1.Location = new System.Drawing.Point(0, 546);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(835, 22);
            this.statusStrip1.TabIndex = 5;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // stsSaveStatus
            // 
            this.stsSaveStatus.Name = "stsSaveStatus";
            this.stsSaveStatus.Size = new System.Drawing.Size(19, 17);
            this.stsSaveStatus.Text = "---";
            // 
            // frmAdministrativeTools
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(835, 568);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.pnlAdminTools);
            this.Controls.Add(this.mnuMain);
            this.MainMenuStrip = this.mnuMain;
            this.Name = "frmAdministrativeTools";
            this.Text = "CMS Administration Tools";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmAdministrativeTools_FormClosing);
            this.Load += new System.EventHandler(this.frmAdministrativeTools_Load);
            this.mnuMain.ResumeLayout(false);
            this.mnuMain.PerformLayout();
            this.pnlAdminTools.ResumeLayout(false);
            this.tabAppAccessMain.ResumeLayout(false);
            this.tabP_AppAccess.ResumeLayout(false);
            this.pnlAppAccess.ResumeLayout(false);
            this.tblLoPnl_AppAccess.ResumeLayout(false);
            this.pnlAppAccessControls.ResumeLayout(false);
            this.tblLOPnlAppAccessValues.ResumeLayout(false);
            this.pnlAppAccessSelections.ResumeLayout(false);
            this.pnlAppAccessSelections.PerformLayout();
            this.pnlAppAccessSettings.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUserAccessRights)).EndInit();
            this.tabP_UserAdmin.ResumeLayout(false);
            this.pnlUserAdmin.ResumeLayout(false);
            this.pnlUserAdmin.PerformLayout();
            this.tab_LockAdmin.ResumeLayout(false);
            this.pnlLockControls.ResumeLayout(false);
            this.pnlLockAdmin.ResumeLayout(false);
            this.tblLOPnlLockValues.ResumeLayout(false);
            this.pnlLockList.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvLockAdmin)).EndInit();
            this.pnlLockAppAccessSelection.ResumeLayout(false);
            this.pnlLockAppAccessSelection.PerformLayout();
            this.tabP_ServicerMIAdmin.ResumeLayout(false);
            this.pnlServicerMIAdmin.ResumeLayout(false);
            this.pnlServicerMIAdmin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEntityContacts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEntityGroups)).EndInit();
            this.tabP_ClientSpecificSecurity.ResumeLayout(false);
            this.pnlClientSecurityMain.ResumeLayout(false);
            this.pnlCtrlButtons.ResumeLayout(false);
            this.pnlSetupAndDisplay.ResumeLayout(false);
            this.pnlUserSetup.ResumeLayout(false);
            this.pnlUserSetup.PerformLayout();
            this.pnlClientSecuritySettings.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvClientSecritySettings)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnuMain;
        private System.Windows.Forms.ToolStripMenuItem mnuFile;
        private System.Windows.Forms.ToolStripMenuItem mnuFile_Exit;
        private System.Windows.Forms.ToolStripMenuItem mnuHelp;
        private System.Windows.Forms.ToolStripMenuItem mnuHelp_About;
        //private System.Windows.Forms.StatusStrip stsStatus;
        private System.Windows.Forms.Panel pnlAdminTools;
        private System.Windows.Forms.TabControl tabAppAccessMain;
        private System.Windows.Forms.TabPage tabP_AppAccess;
        private System.Windows.Forms.TabPage tabP_UserAdmin;
        private System.Windows.Forms.Panel pnlAppAccess;
        private System.Windows.Forms.TableLayoutPanel tblLoPnl_AppAccess;
        private System.Windows.Forms.Panel pnlAppAccessControls;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TableLayoutPanel tblLOPnlAppAccessValues;
        private System.Windows.Forms.Panel pnlAppAccessSelections;
        private System.Windows.Forms.Panel pnlAppAccessSettings;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cboUserSelect;
        private System.Windows.Forms.ComboBox cboAppSelect;
        private System.Windows.Forms.Button btnAddUserToApp;
        private System.Windows.Forms.DataGridView dgvUserAccessRights;
        private System.Windows.Forms.ToolStripMenuItem mnuFile_Save;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel pnlUserAdmin;
        private System.Windows.Forms.Button btn_User_ResetPassword;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbo_User_SelectUser;
        private System.Windows.Forms.TabPage tab_LockAdmin;
        private System.Windows.Forms.Button btn_User_Cancel;
        private System.Windows.Forms.Button btn_User_Save;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtUserEmail;
        private System.Windows.Forms.TextBox txtUserPhone;
        private System.Windows.Forms.Panel pnlLockAdmin;
        private System.Windows.Forms.TabPage tabP_ServicerMIAdmin;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel stsSaveStatus;
        private System.Windows.Forms.Panel pnlLockControls;
        private System.Windows.Forms.Button btnDeleteLock;
        private System.Windows.Forms.TableLayoutPanel tblLOPnlLockValues;
        private System.Windows.Forms.Panel pnlLockList;
        private System.Windows.Forms.DataGridView dgvLockAdmin;
        private System.Windows.Forms.Panel pnlLockAppAccessSelection;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox cboLockAppSelect;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TabPage tabP_ClientSpecificSecurity;
        private System.Windows.Forms.TableLayoutPanel pnlClientSecurityMain;
        private System.Windows.Forms.Panel pnlCtrlButtons;
        private System.Windows.Forms.TableLayoutPanel pnlSetupAndDisplay;
        private System.Windows.Forms.Panel pnlUserSetup;
        private System.Windows.Forms.Button btnCSSecurityAddUser;
        private System.Windows.Forms.ComboBox cboCSSecurityAddUser;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel pnlClientSecuritySettings;
        private System.Windows.Forms.DataGridView dgvClientSecritySettings;
        private System.Windows.Forms.Button btn_CSSCancel;
        private System.Windows.Forms.Button btn_CSSSave;
        private System.Windows.Forms.Panel pnlServicerMIAdmin;
        private System.Windows.Forms.DataGridView dgvEntityContacts;
        private System.Windows.Forms.Button btn_ServicerMI_Cancel;
        private System.Windows.Forms.ComboBox cbo_ServicerMI_SelectGroup;
        private System.Windows.Forms.CheckBox chkExcludeFNMAClaimFiledUpdateRpt;
        private System.Windows.Forms.ComboBox cbo_ServicerMI_AppSelect;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btn_ServicerMI_MoveRight;
        private System.Windows.Forms.CheckBox chkIsBackend;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblSlectEntity;
        private System.Windows.Forms.ComboBox cbo_ServicerMI_SelectEntity;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cbo_ServicerMI_EntityType;
        private System.Windows.Forms.Button btn_ServicerMI_Save;
        private System.Windows.Forms.Button btn_ServicerMI_MoveLeft;
        private System.Windows.Forms.DataGridView dgvEntityGroups;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnRemoveContact;
        private System.Windows.Forms.Button btnAddContact;
        private System.Windows.Forms.Label label16;
    }
}
