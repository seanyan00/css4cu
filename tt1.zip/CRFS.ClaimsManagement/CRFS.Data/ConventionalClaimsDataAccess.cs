﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace CRFS.Data
{
    class ConventionalClaimsDataAccess
    {
        CRFS.Data.Settings _settings;
        
        enum Actions { Skip = 1, Insert, Update };

        internal ConventionalClaimsDataAccess()
        {
        }

        internal ConventionalClaimsDataAccess(CRFS.Data.Settings settings)
        {
            _settings = settings;

        }

        #region "Common"
        internal DataTable searchClaims_ByLoanNumber(int CMSLoginID, string SearchValue)
        {
            SqlConnection con = new SqlConnection(); 
            
            try
            {
                DataTable dt = new DataTable("Claims");

                dt.Columns.Add("LoanID", typeof(int));
                dt.Columns.Add("LoanNumber", typeof(string));
                dt.Columns.Add("ClaimID", typeof(int));
                dt.Columns.Add("ClientID", typeof(int));
                dt.Columns.Add("ClientName", typeof(string));
                dt.Columns.Add("ClaimTypeID", typeof(int));
                dt.Columns.Add("ClaimType", typeof(string));
                dt.Columns.Add("SubType", typeof(string));
                dt.Columns.Add("ClaimDueDate", typeof(DateTime));
                dt.Columns.Add("ReferralDate", typeof(DateTime));
                dt.Columns.Add("OpenSteps", typeof(int));
                dt.Columns.Add("ClaimFormID", typeof(int)); 
                dt.Columns.Add("FormName", typeof(string));
                dt.Columns.Add("BorrowerFirstName", typeof(string)); 
                dt.Columns.Add("BorrowerLastName", typeof(string));
                dt.Columns.Add("PropertyAddress", typeof(string));
                dt.Columns.Add("PropertyCity", typeof(string));
                dt.Columns.Add("PropertyState", typeof(string));
                dt.Columns.Add("PropertyZip", typeof(string));

                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_CNTL_FindClaim_ByLoanNumberCaseNumber";

                SqlParameter parm = new SqlParameter("@UserID", CMSLoginID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@SearchValue", SearchValue);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["LoanID"] = int.Parse(dr["LoanID"].ToString().Length == 0 ? "0" : dr["LoanID"].ToString());
                    row["LoanNumber"] = dr["LoanNumber"].ToString();
                    row["ClaimID"] = int.Parse(dr["ClaimID"].ToString().Length == 0 ? "0" : dr["ClaimID"].ToString());
                    row["ClientID"] = int.Parse(dr["ClientID"].ToString().Length == 0 ? "0" : dr["ClientID"].ToString());
                    row["ClientName"] = dr["ClientName"].ToString();
                    row["ClaimTypeID"] = int.Parse(dr["ClaimTypeID"].ToString().Length == 0 ? "0" : dr["ClaimTypeID"].ToString());
                    row["ClaimType"] = dr["ClaimType"].ToString();
                    row["SubType"] = dr["SubType"].ToString();
                    row["ClaimDueDate"] = DateTime.Parse(dr["ClaimDueDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClaimDueDate"].ToString());
                    row["ReferralDate"] = DateTime.Parse(dr["ReferralDate"].ToString().Length == 0 ? "1/1/1900" : dr["ReferralDate"].ToString());
                    row["OpenSteps"] = int.Parse(dr["OpenSteps"].ToString().Length == 0 ? "0" : dr["OpenSteps"].ToString());
                    row["ClaimFormID"] = int.Parse(dr["ClaimFormID"].ToString().Length == 0 ? "0" : dr["ClaimFormID"].ToString());
                    row["FormName"] = dr["FormName"].ToString();
                    row["BorrowerFirstName"] = dr["BorrowerFirstName"].ToString();
                    row["BorrowerLastName"] = dr["BorrowerLastName"].ToString();
                    row["PropertyAddress"] = dr["PropertyAddress"].ToString();
                    row["PropertyCity"] = dr["PropertyCity"].ToString();
                    row["PropertyState"] = dr["PropertyState"].ToString();
                    row["PropertyZip"] = dr["PropertyZip"].ToString();

                    dt.Rows.Add(row);

                }

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        #endregion

        #region "Claims 332"

        #endregion

        #region "Investor Tracking"
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        internal DataTable BuildInvestorTrackingPaymentFollowupTable()
        {
            try
            {
                DataTable dt = new DataTable("PmtFollowup");

                dt.Columns.Add("ID", typeof(int));
                dt.Columns.Add("ClaimID", typeof(int));
                dt.Columns.Add("CommentTypeID", typeof(int));
                dt.Columns.Add("CommentType", typeof(string));
                dt.Columns.Add("Comment", typeof(string));
                dt.Columns.Add("PmtCommentEnteredByUser", typeof(int));
                dt.Columns.Add("EnteredByUserName", typeof(string));
                dt.Columns.Add("FollowupDate", typeof(DateTime));
                dt.Columns.Add("FollowupComplete", typeof(bool));
                dt.Columns.Add("FollowupCompleteDate", typeof(DateTime));
                dt.Columns.Add("FollowupCompleteUser", typeof(int));
                dt.Columns.Add("FollowupCompleteUserName", typeof(string));
                dt.Columns.Add("DateEntered", typeof(DateTime));
                dt.Columns.Add("LastUpdateDate", typeof(DateTime));
                dt.Columns.Add("LastUpdateUser", typeof(int));
                dt.Columns.Add("LastUpdateUserName", typeof(string));

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        internal DataTable BuildInvestorTrackingWorkflowStepTable()
        {
            try
            {
                DataTable dt = new DataTable("Workflow");

                DataColumn dc = new DataColumn();
                dc.ColumnName = "rowID";
                dc.AutoIncrement = true;
                dc.AutoIncrementSeed = 1;
                dc.AutoIncrementStep = 1;
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                dt.Columns.Add("id", typeof(int));
                dt.Columns.Add("ClaimID", typeof(int));
                dt.Columns.Add("WorkflowID", typeof(int));
                dt.Columns.Add("WorkflowStepID", typeof(int));
                dt.Columns.Add("OpenDate", typeof(DateTime));
                dt.Columns.Add("OpenUser", typeof(int));
                dt.Columns.Add("OpenUserName", typeof(string));
                dt.Columns.Add("AssignedToUser", typeof(int));
                dt.Columns.Add("AssignedToUserName", typeof(string));
                dt.Columns.Add("CompleteDate", typeof(DateTime));
                dt.Columns.Add("CompletedByUser", typeof(int));
                dt.Columns.Add("CompletedByUserName", typeof(string));
                dt.Columns.Add("DueDate", typeof(DateTime));
                dt.Columns.Add("WorkflowName", typeof(string));
                dt.Columns.Add("WorkflowStepName", typeof(string));
                dt.Columns.Add("Current_ByStep", typeof(bool));
                dt.Columns.Add("WorkflowStepOrder", typeof(int));
                dt.Columns.Add("deltaCheck", typeof(string));

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// Calls a stored procedure to copy (clone) rec sheet records from an identified claim
        /// to the current claim (which should have no existing rec sheet items
        /// </summary>
        /// <param name="sourceClaimID">The claim ID to copy records from</param>
        /// <param name="targetClaimID">the claim ID of the current claim</param>
        /// <param name="userID">the current user ID</param>
        /// <returns></returns>
        internal bool InvTrk_Clone_RecSheet(int sourceClaimID, int targetClaimID, int userID)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                int recordsAffected;

                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_InvTrk_RecSheet_Clone";
                cmd.Connection = con;

                SqlParameter prm = new SqlParameter();

                prm = new SqlParameter("@SourceClaimID", sourceClaimID);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@TargetClaimID", targetClaimID);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@UserID", userID);
                cmd.Parameters.Add(prm);
                
                recordsAffected = cmd.ExecuteNonQuery();

                return true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClaimID"></param>
        /// <returns></returns>
        internal DataTable InvTrk_SelectLoanID_ByClaimID(int ClaimID)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable("Claims");

                dt.Columns.Add("ClaimID", typeof(int)); 
                dt.Columns.Add("LoanID", typeof(int));
                dt.Columns.Add("LoanNumber", typeof(string));
                
                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_InvTrk_Loan_SelectByClaimID";

                SqlParameter parm = new SqlParameter("@ClaimID", ClaimID);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ClaimID"] = int.Parse(dr["ClaimID"].ToString().Length == 0 ? "0" : dr["ClaimID"].ToString()); 
                    row["LoanID"] = int.Parse(dr["LoanID"].ToString().Length == 0 ? "0" : dr["LoanID"].ToString());
                    row["LoanNumber"] = dr["LoanNumber"].ToString();
                    
                    dt.Rows.Add(row);

                }

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }


        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="claimID"></param>
        /// <returns></returns>
        internal DataTable GetInvestorTrackingPmtFollowupComments(int claimID)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dtRtn = BuildInvestorTrackingPaymentFollowupTable();
                
                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_InvTrk_PFUNotes_SelectByClaimID";
                SqlParameter parm = new SqlParameter("@ClaimID", claimID);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dtRtn.NewRow();

                    row["ID"] = int.Parse(dr["ID"].ToString());
                    row["ClaimID"] = int.Parse(dr["ClaimID"].ToString());
                    row["CommentTypeID"] = int.Parse(dr["CommentTypeID"].ToString());
                    row["CommentType"] = dr["CommentType"].ToString();
                    row["Comment"] = dr["Comment"].ToString();
                    row["PmtCommentEnteredByUser"] = int.Parse(dr["PmtCommentEnteredByUser"].ToString());
                    row["EnteredByUserName"] = dr["PmtCommentEnteredByUserName"].ToString();
                    row["FollowupDate"] = DateTime.Parse(dr["FollowupDate"].ToString().Length == 0 ? "1/1/1900" : dr["FollowupDate"].ToString());
                    row["FollowupComplete"] = bool.Parse(dr["FollowupComplete"].ToString());
                    row["FollowupCompleteDate"] = DateTime.Parse(dr["FollowupCompleteDate"].ToString().Length == 0 ? "1/1/1900" : dr["FollowupCompleteDate"].ToString());
                    row["FollowupCompleteUser"] = dr["FollowupCompleteUser"].ToString().Length == 0 ? 0 : int.Parse(dr["FollowupCompleteUser"].ToString());
                    row["FollowupCompleteUserName"] = dr["FollowupCompleteUserName"].ToString();
                    row["DateEntered"] = DateTime.Parse(dr["DateEntered"].ToString());
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString());
                    row["LastUpdateUserName"] = dr["LastUpdateUserName"].ToString();
                    row["LastUpdateUser"] = int.Parse(dr["LastUpdateUser"].ToString());

                    dtRtn.Rows.Add(row);
                }

                dr.Close();
                dr.Dispose();

                dtRtn.AcceptChanges();

                return dtRtn;

            }
            
            catch (Exception e)
            {
                throw e;
            }
            
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="claimID"></param>
        /// <returns></returns>
        internal DataTable GetInvestorTrackingWorkflowSteps(int claimID)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dtRtn = BuildInvestorTrackingWorkflowStepTable();

                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_InvTrk_WorkflowSteps_SelectByClaimID";

                SqlParameter parm = new SqlParameter("@ClaimID", claimID);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dtRtn.NewRow();

                    row["id"] = (int)dr["id"];
                    row["ClaimID"] = (int)dr["ClaimID"];
                    row["WorkflowID"] = (int)dr["WorkflowID"];
                    row["WorkflowStepID"] = (int)dr["WorkflowStepID"];
                    row["OpenDate"] = DateTime.Parse(dr["OpenDate"].ToString());
                    row["OpenUser"] = dr["OpenUser"].ToString();
                    row["OpenUserName"] = dr["OpenUserName"].ToString();
                    row["AssignedToUser"] = int.Parse(dr["AssignedToUser"].ToString().Length == 0 ? "0" : dr["AssignedToUser"].ToString());
                    row["AssignedToUserName"] = dr["AssignedToUserName"].ToString();
                    row["CompleteDate"] = DateTime.Parse(dr["CompleteDate"].ToString().Length == 0 ? "01/01/1900" : dr["CompleteDate"].ToString());
                    row["CompletedByUser"] = int.Parse(dr["CompletedByUser"].ToString().Length == 0 ? "0" : dr["CompletedByUser"].ToString());
                    row["CompletedByUserName"] = dr["CompletedByUserName"].ToString();
                    row["DueDate"] = DateTime.Parse(dr["DueDate"].ToString().Length == 0 ? "01/01/1900" : dr["DueDate"].ToString());
                    row["WorkflowName"] = dr["WorkflowName"].ToString();
                    row["WorkflowStepName"] = dr["WorkflowStepName"].ToString();
                    row["Current_ByStep"] = bool.Parse(dr["Current_ByStep"].ToString());
                    row["WorkflowStepOrder"] = int.Parse(dr["WorkflowStepOrder"].ToString().Length == 0 ? "0" : dr["WorkflowStepOrder"].ToString());
                    row["deltaCheck"] = dr["deltaCheck"];

                    dtRtn.Rows.Add(row);
                }

                dr.Close();
                dr.Dispose();

                dtRtn.AcceptChanges();

                return dtRtn;
            
            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        internal bool SaveInvestorTracking_Claim_LPSImportSpecific(DataTable dt)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    SqlParameter prm = new SqlParameter();

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                    switch (dt.Rows[i].RowState)
                    {
                        case DataRowState.Modified:
                            cmd.CommandText = "usp_InvTrk_Import_LPS_ExistingClaimsRpt_ClaimUpdates";
                            break;

                        default:
                            continue;
                            //break;
                    }
                    
                    cmd.Connection = con;
                    prm = new SqlParameter("@ClaimID", dt.Rows[i]["ClaimID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimPaidAmount", dt.Rows[i]["ClaimPaidAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimPaidDate", dt.Rows[i]["ClaimPaidDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@DenialDate", dt.Rows[i]["DenialDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LastUpdateDate", dt.Rows[i]["LastUpdateDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LastUpdateUser", dt.Rows[i]["LastUpdateUser"]);
                    cmd.Parameters.Add(prm);

                    cmd.ExecuteNonQuery();

                }

                return true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pmtFollowup"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool SaveInvestorTracking_PaymentFollowup(DataTable pmtFollowup)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                int recordsAffected;

                //Get eligible items
                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");

                con.Open();

                for (int i = 0; i < pmtFollowup.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    //SqlCommand cmd1 = new SqlCommand();
                    cmd = new SqlCommand();
                    SqlParameter prm = new SqlParameter();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    switch (pmtFollowup.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            cmd.CommandText = "usp_InvTrk_PFUNotes_Insert";
                            break;
                        case DataRowState.Deleted:
                            break;
                        case DataRowState.Detached:
                            break;
                        case DataRowState.Modified:
                            cmd.CommandText = "usp_InvTrk_PFUNotes_Update";
                            break;
                        case DataRowState.Unchanged:
                            goto NextRecord;
                        //break;
                        default:
                            break;
                    }

                    cmd.Connection = con;
                    prm = new SqlParameter("@id", pmtFollowup.Rows[i]["ID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimID", pmtFollowup.Rows[i]["ClaimID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@CommentTypeID", pmtFollowup.Rows[i]["CommentTypeID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@Comment", pmtFollowup.Rows[i]["Comment"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PmtCommentEnteredByUser", pmtFollowup.Rows[i]["PmtCommentEnteredByUser"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@FollowupDate", pmtFollowup.Rows[i]["FollowupDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@FollowupComplete", pmtFollowup.Rows[i]["FollowupComplete"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@FollowupCompleteDate", pmtFollowup.Rows[i]["FollowupCompleteDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@FollowupCompleteUser", pmtFollowup.Rows[i]["FollowupCompleteUser"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@DateEntered", pmtFollowup.Rows[i]["DateEntered"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LastUpdateDate", pmtFollowup.Rows[i]["LastUpdateDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LastUpdateUser", pmtFollowup.Rows[i]["LastUpdateUser"]);
                    cmd.Parameters.Add(prm);

                    recordsAffected = cmd.ExecuteNonQuery();
                NextRecord: ;
                }

                pmtFollowup.AcceptChanges();

                return true;
            }
            catch (Exception e)
            {
                throw e;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pmtFollowup"></param>
        /// <returns></returns>
        internal bool BulkSave_InvestorTracking_PaymentFollowup(DataTable pmtFollowup)
        {
            SqlConnection con = new SqlConnection();
            bool rtnValue = false;

            try
            {
                DataTable dtUpdates = separate_Modified(pmtFollowup);
                DataTable dtAdditions = separate_Added(pmtFollowup);

                //Updates get stored the sequential way - one at a time via a loop
                SaveInvestorTracking_PaymentFollowup(dtUpdates);

                //New records can be bulk loaded
                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlBulkCopy bulkCopy = new SqlBulkCopy(con);
                bulkCopy.DestinationTableName = "tblInvestorTracking_Claims_PaymentFollowupNotes";
                bulkCopy.BulkCopyTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                //Map columns between memory and database tables
                bulkCopy.ColumnMappings.Add("ClaimID", "ClaimID");
                bulkCopy.ColumnMappings.Add("CommentTypeID", "CommentTypeID");
                bulkCopy.ColumnMappings.Add("Comment", "Comment");
                bulkCopy.ColumnMappings.Add("PmtCommentEnteredByUser", "PmtCommentEnteredByUser");
                bulkCopy.ColumnMappings.Add("FollowupDate", "FollowupDate");
                bulkCopy.ColumnMappings.Add("FollowupComplete", "FollowupComplete");
                bulkCopy.ColumnMappings.Add("FollowupCompleteDate", "FollowupCompleteDate");
                bulkCopy.ColumnMappings.Add("FollowupCompleteUser", "FollowupCompleteUser");
                bulkCopy.ColumnMappings.Add("DateEntered", "DateEntered");
                bulkCopy.ColumnMappings.Add("LastUpdateDate", "LastUpdateDate");
                bulkCopy.ColumnMappings.Add("LastUpdateUser", "LastUpdateUser");

                //This should write the whole table, in bulk to the server
                bulkCopy.WriteToServer(dtAdditions);

                rtnValue = true;
                return rtnValue;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dtWorkflow"></param>
        /// <returns></returns>
        internal bool SaveInvestorTracking_Workflow_Data(DataTable dtWorkflow)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                int loopControl = 0;
                int recordsAffected;

                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();
                
                SqlTransaction sqlTran = con.BeginTransaction();
                
                SqlCommand cmd = new SqlCommand();

                for (int i = 0; i < dtWorkflow.Rows.Count; i++)
                {
                    loopControl = 0; 
                    
                    cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.Transaction = sqlTran;

                    SqlParameter prm = new SqlParameter();

                    switch (dtWorkflow.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            loopControl = (int)Actions.Insert;

                            cmd.CommandText = "usp_InvTrk_Workflow_Insert";

                            prm = new SqlParameter("@ClaimID", dtWorkflow.Rows[i]["ClaimID"]);
                            cmd.Parameters.Add(prm);
                            prm = new SqlParameter("@WorkflowID", dtWorkflow.Rows[i]["WorkflowID"]);
                            cmd.Parameters.Add(prm);
                            prm = new SqlParameter("@WorkflowStepID", dtWorkflow.Rows[i]["WorkflowStepID"]);
                            cmd.Parameters.Add(prm);

                            break;

                        case DataRowState.Modified:
                            loopControl = (int)Actions.Update;

                            cmd.CommandText = "usp_InvTrk_Workflow_Update";

                            prm = new SqlParameter("@ID", dtWorkflow.Rows[i]["ID"]);
                            cmd.Parameters.Add(prm);
                            prm = new SqlParameter("@ClaimID", dtWorkflow.Rows[i]["ClaimID"]);
                            cmd.Parameters.Add(prm);
                            prm = new SqlParameter("@deltaCheck", dtWorkflow.Rows[i]["deltaCheck"]);
                            cmd.Parameters.Add(prm);


                            break;

                        default:
                            loopControl = (int)Actions.Skip;
                            break;
                    }

                    if (loopControl == (int)Actions.Skip)
                    {
                        //Nothing to do. Go to the next table record
                        continue;
                    }

                    else
                    {
                        cmd.Connection = con;

                        prm = new SqlParameter("@OpenDate", dtWorkflow.Rows[i]["OpenDate"]);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@OpenUser", dtWorkflow.Rows[i]["OpenUser"]);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@AssignedToUser", dtWorkflow.Rows[i]["AssignedToUser"]);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@CompleteDate", dtWorkflow.Rows[i]["CompleteDate"]);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@CompletedByUser", dtWorkflow.Rows[i]["CompletedByUser"]);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@DueDate", dtWorkflow.Rows[i]["DueDate"]);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@Current_ByStep", dtWorkflow.Rows[i]["Current_ByStep"]);
                        cmd.Parameters.Add(prm);

                        try
                        {
                            //Ticket 1999 20110318 TRS - this block replaces a single stored procedure execution so that when an insert is performed
                            //the data table is updated with the newly created record ID.  Updates were not occurring on previously inserted rows
                            //even though all of the data was still in memory.  Problem manifested itself with updated information disappearing
                            //after exiting and reentering the claim - typically this was the completed date and completed by user.
                            switch (dtWorkflow.Rows[i].RowState)
                            {
                                case DataRowState.Added:
                                    //If the row was added (inserted) - we need the id of the new record in the current data table
                                    dtWorkflow.Rows[i]["id"] = Convert.ToInt32(cmd.ExecuteScalar());
                                    break;

                                default:
                                    recordsAffected = cmd.ExecuteNonQuery();
                                    break;
                            
                            }

                        }

                        catch (SqlException e)
                        {
                            sqlTran.Rollback();
                            throw e;

                        }

                    }

                }

                sqlTran.Commit();
                dtWorkflow.AcceptChanges();
                return true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dtWorkflow"></param>
        /// <returns></returns>
        internal bool BulkSave_InvestorTracking_Workflow_Data(DataTable dtWorkflow)
        {
            SqlConnection con = new SqlConnection();
            bool rtnValue = false;

            try
            {
                DataTable dtUpdates = separate_Modified(dtWorkflow);
                DataTable dtAdditions = separate_Added(dtWorkflow);

                //Updates get stored the sequential way - one at a time via a loop
                SaveInvestorTracking_Workflow_Data(dtUpdates);

                //New records can be bulk loaded
                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlBulkCopy bulkCopy = new SqlBulkCopy(con);
                bulkCopy.DestinationTableName = "tblInvestorTracking_Workflow";
                bulkCopy.BulkCopyTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                //Map columns between memory and database tables
                bulkCopy.ColumnMappings.Add("ClaimID", "ClaimID");
                bulkCopy.ColumnMappings.Add("WorkflowID", "WorkflowID");
                bulkCopy.ColumnMappings.Add("WorkflowStepID", "WorkflowStepID");
                bulkCopy.ColumnMappings.Add("OpenDate", "OpenDate");
                bulkCopy.ColumnMappings.Add("OpenUser", "OpenUser");
                bulkCopy.ColumnMappings.Add("AssignedToUser", "AssignedToUser");
                bulkCopy.ColumnMappings.Add("CompleteDate", "CompleteDate");
                bulkCopy.ColumnMappings.Add("CompletedByUser", "CompletedByUser");
                bulkCopy.ColumnMappings.Add("DueDate", "DueDate");
                bulkCopy.ColumnMappings.Add("Current_ByStep", "Current_ByStep");

                //This should write the whole table, in bulk to the server
                bulkCopy.WriteToServer(dtAdditions);

                rtnValue = true;
                return rtnValue;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dtIn"></param>
        /// <returns></returns>
        private DataTable separate_Added(DataTable dtIn)
        {
            try
            {
                DataTable dtRtn = new DataTable();
                DataView dv = new DataView(dtIn);

                dv.RowStateFilter = DataViewRowState.Added;
                dtRtn = dv.ToTable();
                dtRtn.AcceptChanges();

                foreach (DataRow row in dtRtn.Rows)
                {
                    row.SetAdded();
                }


                return dtRtn;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dtIn"></param>
        /// <returns></returns>
        private DataTable separate_Modified(DataTable dtIn)
        {
            try
            {
                DataTable dtRtn = new DataTable();
                DataView dv = new DataView(dtIn);

                dv.RowStateFilter = DataViewRowState.ModifiedCurrent;
                dtRtn = dv.ToTable();
                dtRtn.AcceptChanges();

                foreach (DataRow row in dtRtn.Rows)
                {
                    row.SetModified();
                }


                return dtRtn;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        
        #endregion

    }
}
