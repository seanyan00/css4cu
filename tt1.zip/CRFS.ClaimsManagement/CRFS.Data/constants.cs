﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CRFS.Data
{
    // 20130613 gk [t-20709] make some constants so we aren't using magic numbers
    public enum FormConstants 
    {
        Claims332=6,
        InvestorTracking=8,
        FNMAPaymentFollowup=9,
        FNMAReconciliation=10,
        FNMADataGram=11
    }

    //Changed enumeration values to use what is in the standardized Clients table in ApplicationConfiguration
    public enum CRFSClientIds 
    {
        Chase = 19,
        PHH = 28,
        BBT = 5
    }
    // 20130702 gk [t-21185] constant for duplicate workflow
    public enum SqlErrors 
    {
        DuplicateWorkflow=50001
    }
 }
