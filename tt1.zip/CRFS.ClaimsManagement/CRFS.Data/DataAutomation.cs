﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Text.RegularExpressions;
using System.Globalization;


namespace CRFS.Data
{
    #region "Utility"
    public static class helper                                                 // various helper functions add to objects
    {
        public static string defStr(this object t, string def)
        {
            return t.ToString().Length == 0 ? def : t.ToString();
        }
    }

    // stored procedure builder
    //public class spBuilder
    //{
    //    Dictionary<string, object> parms = new Dictionary<string, object>();   // parameters to the stored proc
    //    CRFS.Data.Settings _settings;                                          // settings
    //    string db;                                                             // which database we are connecting to
    //    DataRow wr = null;                                                     // working data row if we took a DataRow as a parameter

    //    spBuilder(CRFS.Data.Settings settings, string db) 
    //    { 
    //        _settings = settings; 
    //        this.db = db; 
    //    }

    //    internal static spBuilder start(CRFS.Data.Settings settings, string db) 
    //    { 
    //        return new spBuilder(settings, db); 
    //    }

    //    public spBuilder P(string n, object o)                                 // add a parameter 
    //    { 
    //        parms[n] = o; 
    //        return this; 
    //    }

    //    public spBuilder P(string n)                                           // add a parameter from working row 
    //    { 
    //        parms[n] = wr[n]; 
    //        return this; 
    //    }

    //    public spBuilder dr(DataRow idr)                                       // set the datarow that we are working with
    //    { 
    //        wr = idr; 
    //        return this; 
    //    }

    //    void addParms(SqlCommand cmd)                                          // add the parameters to the sqlcommand
    //    {
    //        foreach (var v in parms)
    //        {
    //            cmd.Parameters.Add(new SqlParameter("@" + v.Key, v.Value));
    //        }

    //    }

    //    public int scaler(string spn)                                          // call a scaler stored proc
    //    {
    //        SqlConnection con = new SqlConnection();

    //        try
    //        {
    //            con.ConnectionString = _settings.GetConnectionString(db);

    //            con.Open();

    //            SqlCommand cmd = new SqlCommand();
    //            cmd.CommandType = System.Data.CommandType.StoredProcedure;
    //            cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
    //            addParms(cmd);
    //            cmd.CommandText = spn;
    //            cmd.Connection = con;
    //            return int.Parse((cmd.ExecuteScalar() ?? 0).ToString());
    //        }
    //        catch (Exception ex) { throw; }
    //        finally
    //        {
    //            if (con.State != System.Data.ConnectionState.Closed)
    //            {
    //                con.Close();
    //                con.Dispose();
    //            }

    //        }
    //    }

    //    public DataTable fillTable(DataTable dt, string spn)                   // fill a datatable from a stored proc
    //    {
    //        SqlConnection con = new SqlConnection();

    //        try
    //        {
    //            con.ConnectionString = _settings.GetConnectionString(db);

    //            con.Open();

    //            SqlCommand cmd = new SqlCommand();
    //            cmd.CommandType = System.Data.CommandType.StoredProcedure;
    //            cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
    //            addParms(cmd);
    //            cmd.CommandText = spn;
    //            cmd.Connection = con;
    //            SqlDataReader dr = cmd.ExecuteReader();

    //            if (dr.HasRows)
    //            {
    //                while (dr.Read())
    //                {
    //                    DataRow row = dt.NewRow();
    //                    foreach (DataColumn c in dt.Columns)
    //                    {
    //                        // cant swich on c.DataType
    //                        if (c.DataType == typeof(int))
    //                        {
    //                            row[c.ColumnName] = Convert.ToInt32(dr[c.ColumnName].defStr("0"));
    //                        }
    //                        else if (c.DataType == typeof(string))
    //                        {
    //                            row[c.ColumnName] = dr[c.ColumnName].ToString();
    //                        }
    //                        else if (c.DataType == typeof(DateTime))
    //                        {
    //                            row[c.ColumnName] = Convert.ToDateTime(dr[c.ColumnName].defStr("1/1/1900"));
    //                        }
    //                        else
    //                        {
    //                            throw new Exception("spBuilder: unknown datatype" + c.DataType);
    //                        }
    //                    }
    //                    dt.Rows.Add(row);

    //                }
    //            }
    //            return dt;
    //        }
    //        catch (Exception ex) { throw; }
    //        finally
    //        {
    //            if (con.State != System.Data.ConnectionState.Closed)
    //            {
    //                con.Close();
    //                con.Dispose();
    //            }

    //        }
    //    }
    //}
    #endregion

    public class DataAutomation
    {
        internal string _appMode;
 
        internal CRFS.Data.Settings _settings;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="appMode"></param>
        internal DataAutomation(string appMode)
        {
            _appMode = appMode;

            _settings = new CRFS.Data.Settings(appMode);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        internal DataAutomation(Settings settings)
        {
            _settings = settings;

        }

        #region "Common"
        
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        internal Guid GetNewGUID()
        {
            SqlConnection con = new SqlConnection();

            try
            {
                Guid answer;

                con.ConnectionString = _settings.GetConnectionString("DataAutomation");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase;
                cmd.CommandText = "usp_GenerateNewGUID";
                cmd.Connection = con;

                answer = (Guid)cmd.ExecuteScalar();
                return answer;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        internal DataTable ProcessUserEMail_List_withClientPermissions_SELECT()
        {
            SqlConnection con = new SqlConnection(); 
            
            try
            {
                DataTable dt = new DataTable("ProcesUserEmailPermission");

                dt.Columns.Add("ProcessUserEmailID", typeof(int));
                dt.Columns.Add("ProcessID", typeof(int));
                dt.Columns.Add("SecurityUserID", typeof(int));
                dt.Columns.Add("ClientID", typeof(int));
                dt.Columns.Add("ClientName", typeof(string));
                dt.Columns.Add("ClientAbbreviation", typeof(string));
                dt.Columns.Add("ExcludeUntilProduction", typeof(bool));
                dt.Columns.Add("UserEmailAddress", typeof(string));

                con.ConnectionString = _settings.GetConnectionString("ApplicationConfiguration");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_ProcessUserEMail_List_withClientPermissions_SELECT";

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ProcessUserEmailID"] = (int)dr["ProcessUserEmailID"];
                    row["ProcessID"] = (int)dr["ProcessID"];
                    row["SecurityUserID"] = (int)dr["SecurityUserID"];
                    row["ClientID"] = (int)dr["ClientID"];
                    row["ClientName"] = dr["ClientName"].ToString();
                    row["ClientAbbreviation"] = dr["ClientAbbreviation"].ToString();
                    row["ExcludeUntilProduction"] = (bool)dr["ExcludeUntilProduction"];
                    row["UserEmailAddress"] = dr["UserEmailAddress"].ToString();

                    dt.Rows.Add(row);

                }

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }


            finally
            {
                if (con.State != ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }

        }

        #endregion

        #region "Claims 332"
        

        #endregion

        #region "Investor Tracking"
        /*31043
        /// <summary>
        /// Copied from Moss.Data so the LPS and Vendorscape Import routines could be moved here to resolve a circular dependancy preventing
        /// recompile of Moss.Data and CRFS.Data
        /// </summary>
        /// <param name="databaseName"></param>
        /// <param name="loanNumber"></param>
        /// <param name="clientID"></param>
        /// <param name="formID"></param>
        /// <returns></returns>
        internal int CheckExistingLoan_InvestorTracking_byFormID(string databaseName, string loanNumber, int clientID, int formID)
        {

            SqlConnection sqlConn = new SqlConnection();

            try
            {
                int loanID = 0;

                string sConn = _settings.GetConnectionString(databaseName);

                sqlConn.ConnectionString = sConn;

                sqlConn.Open();
                if (sqlConn.State == ConnectionState.Open)
                {
                    SqlCommand sqlCmd = new SqlCommand();
                    sqlCmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandText = "usptblInvestorTracking_Loans_SelectByLoanNumber";

                    SqlParameter prm = new SqlParameter("@LoanNumber", loanNumber.PadLeft(10, '0'));
                    sqlCmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClientID", clientID);
                    sqlCmd.Parameters.Add(prm);
                    prm = new SqlParameter("@FormID", formID);
                    sqlCmd.Parameters.Add(prm);

                    sqlCmd.Connection = sqlConn;

                    SqlDataReader dr = sqlCmd.ExecuteReader();
                    while (dr.Read())
                    {
                        loanID = int.Parse(dr["id"].ToString());
                        break;
                    }

                    dr.Close();
                    dr.Dispose();
                }
                return loanID;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                if (sqlConn.State != ConnectionState.Closed)
                {
                    sqlConn.Close();
                    sqlConn.Dispose();
                }
            }
        }
        */
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        internal bool FHA_PartA_SettlementSupendData_Update(DataTable dt)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                int recordsAffected;

                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();


                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();

                    switch (dt.Rows[i].RowState)
                    {
                        case DataRowState.Modified:

                            cmd.CommandText = "usp_InvTrk_FHA_PartA_SettlementSupendData_Update";

                            break;

                        default:
                            goto NextRecord;
                    }

                    SqlParameter prm = new SqlParameter();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.Connection = con;

                    prm = new SqlParameter("@SubTypeClaimID", dt.Rows[i]["SubTypeClaimID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SettlementDate", dt.Rows[i]["SettlementDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PaidAmount", dt.Rows[i]["PaidAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuspendDate", dt.Rows[i]["SuspendDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LastUpdateDate", DateTime.Now);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LastUpdateUser", dt.Rows[i]["LastUpdateUser"]);
                    cmd.Parameters.Add(prm);

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;
                }

                dt.AcceptChanges();

                //We got here because there were no exceptions raised
                return true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        internal bool FHA_PartB_SettlementSupendData_Update(DataTable dt)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                int recordsAffected;

                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();


                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();

                    switch (dt.Rows[i].RowState)
                    {
                        case DataRowState.Modified:
                            
                            cmd.CommandText = "usp_InvTrk_FHA_PartB_SettlementSupendData_Update";

                            break;

                        default:
                            goto NextRecord;
                    }
                    
                    SqlParameter prm = new SqlParameter();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.Connection = con;

                    prm = new SqlParameter("@SubTypeClaimID", dt.Rows[i]["SubTypeClaimID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SettlementDate", dt.Rows[i]["SettlementDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PaidAmount", dt.Rows[i]["PaidAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuspendDate", dt.Rows[i]["SuspendDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LastUpdateDate", DateTime.Now);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LastUpdateUser", dt.Rows[i]["LastUpdateUser"]);
                    cmd.Parameters.Add(prm);

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;
                }

                dt.AcceptChanges();

                //We got here because there were no exceptions raised
                return true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClientName"></param>
        /// <returns></returns>
        internal DataTable FHA_SettlementSuspendData_Select(string ClientName)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable("SettlementSuspendData");

                dt.Columns.Add("LoanID", typeof(int));
                dt.Columns.Add("LoanNumber", typeof(string));
                dt.Columns.Add("FHACaseNumber", typeof(string));
                dt.Columns.Add("ClaimID", typeof(int));
                dt.Columns.Add("ClaimType", typeof(string));
                dt.Columns.Add("SubTypeClaimID", typeof(int));
                dt.Columns.Add("SettlementDate", typeof(DateTime));
                dt.Columns.Add("PaidAmount", typeof(decimal));
                dt.Columns.Add("SuspendDate", typeof(DateTime));
                dt.Columns.Add("EnteredDate", typeof(DateTime));
                dt.Columns.Add("EnteredByUser", typeof(int));
                dt.Columns.Add("LastUpdateDate", typeof(DateTime));
                dt.Columns.Add("LastUpdateUser", typeof(int));

                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_InvTrk_FHA_SettlementSupendData_Select";

                SqlParameter prm = new SqlParameter("@ClientName", ClientName);
                cmd.Parameters.Add(prm);

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["LoanID"] = (int)dr["LoanID"];
                    row["LoanNumber"] = dr["LoanNumber"].ToString();
                    row["FHACaseNumber"] = dr["FHACaseNumber"].ToString();
                    row["ClaimID"] = (int)dr["ClaimID"];
                    row["ClaimType"] = dr["ClaimType"].ToString();
                    row["SubTypeClaimID"] = (int)dr["SubTypeClaimID"];
                    row["SettlementDate"] = DateTime.Parse(dr["SettlementDate"].ToString().Length == 0 ? "1/1/1900" : dr["SettlementDate"].ToString());
                    row["PaidAmount"] = decimal.Parse(dr["PaidAmount"].ToString().Length == 0 ? "0.00" : dr["PaidAmount"].ToString());
                    row["SuspendDate"] = DateTime.Parse(dr["SuspendDate"].ToString().Length == 0 ? "1/1/1900" : dr["SuspendDate"].ToString());
                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                    row["EnteredByUser"] = (int)dr["EnteredByUser"];
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    row["LastUpdateUser"] = (int)dr["LastUpdateUser"];

                    dt.Rows.Add(row);
                
                }
                
                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dtNotes"></param>
        /// <returns></returns>
        internal bool InvTrk_LoanNotes_Save(DataTable dtNotes)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                int recordsAffected;

                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();


                for (int i = 0; i < dtNotes.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();

                    switch (dtNotes.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            cmd.CommandText = "usptblInvestorTracking_Loans_Notes_Insert";
                            break;

                        default:
                            goto NextRecord;
                    }

                    SqlParameter prm = new SqlParameter();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.Connection = con;

                    prm = new SqlParameter("@LoanID", dtNotes.Rows[i]["LoanID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LoanCommentTypeID", dtNotes.Rows[i]["LoanCommentTypeID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LoanComment", dtNotes.Rows[i]["LoanComment"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@DateEntered", dtNotes.Rows[i]["DateEntered"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@EnteredByUser", dtNotes.Rows[i]["EnteredByUser"]);
                    cmd.Parameters.Add(prm);

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;
                }

                dtNotes.AcceptChanges();

                return true;
            }
            
            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        internal DataTable VendorscapeComparisonData_Select()
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable("VendorscapeBump");

                dt.Columns.Add("Exception", typeof(string));
                dt.Columns.Add("ClientName", typeof(string));
                dt.Columns.Add("ClientID", typeof(int));
                dt.Columns.Add("InvestorLoanNumber", typeof(string));
                dt.Columns.Add("ServicerLoanNumber", typeof(string));
                dt.Columns.Add("ClaimStatus", typeof(string));
                dt.Columns.Add("VendorscapeSubmitDate", typeof(DateTime));
                dt.Columns.Add("CMSSubmitDate", typeof(DateTime));
                dt.Columns.Add("VendorscapeClaimAmount", typeof(decimal));
                dt.Columns.Add("CMSClaimAmount", typeof(decimal));
                dt.Columns.Add("ClaimType", typeof(string));
                dt.Columns.Add("InvestorName", typeof(string));

                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_InvTrk_VendorscapeDataCompare";

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["Exception"] = dr["Exception"].ToString();
                    row["ClientName"] = dr["ClientName"].ToString();
                    row["ClientID"] = (int)dr["ClientID"];
                    row["InvestorLoanNumber"] = dr["InvestorLoanNumber"].ToString();
                    row["ServicerLoanNumber"] = dr["ServicerLoanNumber"].ToString();
                    row["ClaimStatus"] = dr["ClaimStatus"].ToString();
                    row["VendorscapeSubmitDate"] = DateTime.Parse(dr["VendorscapeSubmitDate"].ToString().Length == 0 ? "1/1/1900" : dr["VendorscapeSubmitDate"].ToString());
                    row["CMSSubmitDate"] = DateTime.Parse(dr["CMSSubmitDate"].ToString().Length == 0 ? "1/1/1900" : dr["CMSSubmitDate"].ToString());
                    row["VendorscapeClaimAmount"] = decimal.Parse(dr["VendorscapeClaimAmount"].ToString().Length == 0 ? "0.00" : dr["VendorscapeClaimAmount"].ToString());
                    row["CMSClaimAmount"] = decimal.Parse(dr["CMSClaimAmount"].ToString().Length == 0 ? "0.00" : dr["CMSClaimAmount"].ToString());
                    row["ClaimType"] = dr["ClaimType"].ToString();
                    row["InvestorName"] = dr["InvestorName"].ToString();

                    dt.Rows.Add(row);

                }

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }

        }

        #endregion

        #region "Imports Common"
        
        /*31043
        /// <summary>
        /// 
        /// </summary>
        /// <param name="InvestorCode"></param>
        /// <param name="FormID"></param>
        /// <returns></returns>
        internal int GetInvestorCodeID_ByCodeAndFormID(string InvestorCode, int FormID)
        {
            try
            {
                int retValue = 0;
                ClaimsManagement cm = new ClaimsManagement(_settings);

                DataTable cboValues = cm.GetComboBoxReferenceValues_ByFormID(FormID, _settings);
                DataView dvcboValues = new DataView(cboValues);

                dvcboValues.RowFilter = "ComboBoxTypeTag = 'InvestorCode' AND ComboBoxText = '" + InvestorCode + "'";

                switch (dvcboValues.Count)
                {
                    case 0:
                        //Not found, it needs to be inserted
                        insertClaims332_InvestorCode(InvestorCode);

                        //recursive call to GetInvestorCodeID_ByCodeAndFormID, once an ID is returned, Case 0 will no longer be executed.
                        retValue = GetInvestorCodeID_ByCodeAndFormID(InvestorCode, FormID);

                        break;

                    case 1:
                        retValue = int.Parse(dvcboValues[0]["id"].ToString());

                        break;

                    default:
                        break;

                }

                return retValue;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="InvestorName"></param>
        /// <param name="FormID"></param>
        /// <returns></returns>
        internal int GetInvestorNameID_ByNameAndFormID(string InvestorName, int FormID)
        {
            try
            {
                int retValue = 0;
                ClaimsManagement cm = new ClaimsManagement(_settings);

                DataTable cboValues = cm.GetComboBoxReferenceValues_ByFormID(FormID, _settings);
                DataView dvcboValues = new DataView(cboValues);

                dvcboValues.RowFilter = "ComboBoxTypeTag = 'InvestorName' AND ComboBoxText = '" + InvestorName + "'";

                switch (dvcboValues.Count)
                {
                    case 0:
                        //Not found, it needs to be inserted
                        insertClaims332_InvestorName(InvestorName);

                        //recursive call to GetInvestorNameID_ByNameAndFormID, once an ID is returned, Case 0 will no longer be executed.
                        retValue = GetInvestorNameID_ByNameAndFormID(InvestorName, FormID);

                        break;

                    case 1:
                        retValue = int.Parse(dvcboValues[0]["id"].ToString());

                        break;

                    default:
                        break;

                }

                return retValue;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="LiquidationType"></param>
        /// <param name="FormID"></param>
        /// <returns></returns>
        internal int GetLiqudationTypeID_ByCodeAndFormID(string LiquidationType, int FormID)
        {
            try
            {
                int retValue = 0;
                ClaimsManagement cm = new ClaimsManagement(_settings);

                DataTable cboValues = cm.GetComboBoxReferenceValues_ByFormID(FormID, _settings);
                DataView dvcboValues = new DataView(cboValues);

                dvcboValues.RowFilter = "ComboBoxTypeTag = 'LoanType' AND ComboBoxText = '" + LiquidationType + "'";

                switch (dvcboValues.Count)
                {
                    case 0:
                        //Not found, just return 0 and trap the error in the calling routine
                        break;

                    case 1:
                        retValue = int.Parse(dvcboValues[0]["id"].ToString());

                        break;

                    default:
                        break;

                }

                return retValue;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="_clientID"></param>
        /// <param name="processDate"></param>
        /// <param name="userID"></param>
        /// <param name="settings"></param>
        /// <param name="cm"></param>
        /// <returns></returns>
        internal DataTable Import_Claims332_InvestorTracking_Combined(DataTable dt, int _clientID, string processDate, int userID, Settings settings, ClaimsManagement cm)
        {
            try
            {
                //Adding results columns
                DataColumn dc = new DataColumn();

                //Checkbox to indicated whether or not the row was processed 
                if (!dt.Columns.Contains("Processed"))
                {
                    dc = new DataColumn();
                    dc.ColumnName = "Processed";
                    dc.DataType = typeof(bool);
                    dc.DefaultValue = false;
                    dt.Columns.Add(dc);

                }

                //Highlevel comment to user on process status - detailed results should be logged.
                if (!dt.Columns.Contains("ProcessComments"))
                {
                    dc = new DataColumn();
                    dc.ColumnName = "ProcessComments";
                    dc.DataType = typeof(string);
                    dc.DefaultValue = "Not Processed";
                    dt.Columns.Add(dc);

                }

                DataTable InvTrkData = new DataTable();
                DataTable Claims332Data = new DataTable();
                int FormID = 0;

                //Determine the imports to Claims332 or InvestorTracking
                DataView dv = new DataView(dt);

                //Set the rowfilter to look for InvestorTracking entries
                dv.RowFilter = "INVESTOR_GROUP <> 'Wells Fargo'";

                if (dv.Count > 0)
                {
                    FormID = 8; //Investor Tracking Form ID

                    //Make a table of just the filtered rows
                    InvTrkData = dv.ToTable();

                    //Verify that the supplied data has the required columns
                    if (HasRequiredColumns_InvestorTracking(InvTrkData))
                    {
                        //Performing any preprocessing data gathering ..........



                        //Iterate the data to finalize data gathering/validation and then do the import
                        InvestorTracking_ProcessData(InvTrkData, _clientID, FormID, processDate, userID, settings, cm);

                        //reconcile the import results back to the upload table
                        DataView dvReconcileInvTrk = new DataView(dt);

                        for (int i = 0; i < InvTrkData.Rows.Count; i++)
                        {
                            dvReconcileInvTrk.RowFilter = "Nbr = '" + InvTrkData.Rows[i]["Nbr"] + "'";
                            dvReconcileInvTrk[0]["Processed"] = InvTrkData.Rows[i]["Processed"];
                            dvReconcileInvTrk[0]["ProcessComments"] = InvTrkData.Rows[i]["ProcessComments"];

                        }

                    }

                    else
                    {
                        //Notify/log which columns appear to be missing

                    }
                }

                //Set the rowfilter to look for Claims332 entries
                dv.RowFilter = "INVESTOR_GROUP = 'Wells Fargo'";

                if (dv.Count > 0)
                {
                    FormID = 6; //Claims 332 Form ID

                    //Make a table of just the Claims332 filtered rows
                    Claims332Data = dv.ToTable();

                    //Verify that the supplied data has the required columns
                    if (HasRequiredColumns_Claims332(Claims332Data))
                    {
                        CRFS.Data.ApplicationConfiguration ac = new CRFS.Data.ApplicationConfiguration(settings);

                        //Get the Servicer Address components
                        DataTable dtAddr = ac.Get_Claims332_ServicerAddress_ByClientID(_clientID, settings);


                        //Iterate the data to finalize data gathering/validation and then do the import
                        Claims332_ProcessData(Claims332Data, dtAddr, _clientID, FormID, processDate, userID, settings, cm);

                        //reconcile the import results back to the upload table
                        DataView dvReconcile332 = new DataView(dt);

                        for (int i = 0; i < Claims332Data.Rows.Count; i++)
                        {
                            dvReconcile332.RowFilter = "Nbr = '" + Claims332Data.Rows[i]["Nbr"] + "'";
                            dvReconcile332[0]["Processed"] = Claims332Data.Rows[i]["Processed"];
                            dvReconcile332[0]["ProcessComments"] = Claims332Data.Rows[i]["ProcessComments"];

                        }

                    }

                    else
                    {
                        //Notify/log which columns appear to be missing

                    }

                }

                return dt;
            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
            }

        }
        */

        /// <summary>
        /// 
        /// </summary>
        /// <param name="DateStringToEval"></param>
        /// <returns></returns>
        private bool IsDateStringValid(string DateStringToEval)
        {
            try
            {
                bool Answer = false;

                DateTime tmp = DateTime.Parse("1/1/1900");
                Answer = DateTime.TryParse(DateStringToEval, out tmp);

                return Answer;
            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="SuppliedString"></param>
        /// <returns></returns>
        internal string ReplaceNonPrintableInSuppliedString(string SuppliedString)
        {
            try
            {
                string CleanedString = "";

                //This is a regular expression pattern that is looking for anything that is NOT hex 20 to hex 7E (the set of ACSII printable characters)
                string pattern = "[^\x20-\x7E]+";
                string replacement = " ";

                //Replace non-printable ASCII characters with a space, makes the user entered non-printable characters go away
                CleanedString = Regex.Replace(SuppliedString, pattern, replacement);

                return CleanedString;
            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        
        /// <summary>
        /// Cleans codes such as (70) from the tail end of an imported text string.
        /// This is primarily for the FNMA EOB Reconciliation referral imports, but
        /// may be useful for other processes as well.
        /// </summary>
        /// <param name="SuppliedString">The string to be cleansed of paranthetical codes</param>
        /// <returns>The original string - minus any digit codes enclosed in parenthesis, and the surrounding spaces.</returns>
        internal string ReplaceParantheticalString(string SuppliedString)
        {
            try
            {
                string CleanedString = "";

                //This is a regular expression pattern that is looking for digit codes enclosed in parenthesis
                //example:   Some String Text (01)
                //We need to remove the (01) as well as surrounding space characters
                //string pattern = "/x20+/x28/d{*}/x29/x20*$";
                string pattern = " *\\(*\\d*\\)* *$";
                string replacement = "";

                CleanedString = Regex.Replace(SuppliedString, pattern, replacement);

                return CleanedString;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        /*31043
        /// <summary>
        /// 
        /// </summary>
        /// <param name="BorrowerName"></param>
        /// <returns></returns>
        private string[] split_BorrowerName(string BorrowerName)
        {
            string[] name = BorrowerName.Split(" ".ToCharArray(), 2);

            return name;
        }
        */
        #endregion

        #region "Imports - Investor Tracking"
         #endregion

        #region "Imports - Claims 332"
        /*31043
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        internal DataTable Build_ClaimsDetails_Table()
        {
            try
            {
                DataTable ClaimsDetails = new DataTable("ClaimsDetailsItems");

                ClaimsDetails.Columns.Add("LoanNumber", typeof(string));
                ClaimsDetails.Columns.Add("ClaimType", typeof(string));
                ClaimsDetails.Columns.Add("ClaimDueDate", typeof(DateTime));
                ClaimsDetails.Columns.Add("ClientID", typeof(int));
                ClaimsDetails.Columns.Add("PropertyAddress", typeof(string));
                ClaimsDetails.Columns.Add("PropertyCity", typeof(string));
                ClaimsDetails.Columns.Add("PropertyState", typeof(string));
                ClaimsDetails.Columns.Add("PropertyZip", typeof(string));

                ClaimsDetails.Columns.Add("ServicerName", typeof(string));
                ClaimsDetails.Columns.Add("ServicerAddress", typeof(string));
                ClaimsDetails.Columns.Add("ServicerCity", typeof(string));
                ClaimsDetails.Columns.Add("ServicerState", typeof(string));
                ClaimsDetails.Columns.Add("ServicerZip", typeof(string));
                ClaimsDetails.Columns.Add("ClaimFormID", typeof(int));

                ClaimsDetails.Columns.Add("BorrowerFirstName", typeof(string));
                ClaimsDetails.Columns.Add("BorrowerLastName", typeof(string));

                ClaimsDetails.Columns.Add("InvestorLoanNumber", typeof(string));
                ClaimsDetails.Columns.Add("EnteredByUser", typeof(int));

                ClaimsDetails.Columns.Add("ForeClosureDate", typeof(DateTime));

                ClaimsDetails.Columns.Add("RRCDate", typeof(DateTime));
                ClaimsDetails.Columns.Add("REOSaleDate", typeof(DateTime));

                ClaimsDetails.Columns.Add("InvestorCodeID", typeof(int));
                ClaimsDetails.Columns.Add("InvestorNameID", typeof(int));
                ClaimsDetails.Columns.Add("CMaxClientID", typeof(string));

                return ClaimsDetails;
            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        internal DataTable Build_Claims332Details_Table()
        {
            try
            {
                DataTable Claims332Details = new DataTable("Claims332DetailsItems");

                Claims332Details.Columns.Add("ClaimID", typeof(int));
                Claims332Details.Columns.Add("LiquidationType", typeof(int));
                Claims332Details.Columns.Add("LiquidationDate", typeof(DateTime));
                Claims332Details.Columns.Add("LienNumber", typeof(int));

                return Claims332Details;
            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        internal DataTable Build_WorkFlow_Table_Claims332()
        {
            try
            {
                DataTable WorkFlow = new DataTable("WorkFlowItems");

                WorkFlow.Columns.Add("ClaimID", typeof(int));
                WorkFlow.Columns.Add("FormID", typeof(int));
                WorkFlow.Columns.Add("OpenUser", typeof(int));
                WorkFlow.Columns.Add("AssignedToUser", typeof(int));

                return WorkFlow;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt332Data"></param>
        /// <param name="dtAddrData">Table of address data for the client</param>
        /// <param name="cboData"></param>
        /// <param name="_clientID"></param>
        /// <param name="processDate"></param>
        /// <param name="userID"></param>
        /// <param name="settings"></param>
        /// <param name="cm"></param>
        /// <returns></returns>
        private void Claims332_ProcessData(DataTable dt332Data, DataTable dtAddrData, int _clientID, int FormID, string processDate, int userID, Settings settings, ClaimsManagement cm)
        {
            try
            {
                DataTable dtClaimsDetails = new DataTable();    //Data Table containing all parms required to insert into tblClaims_Details
                DataTable dtClaims332Details = new DataTable(); //Data Table containing all parms required to insert into tblClaims_332_Details
                DataTable dtInitWorkFlow = new DataTable();     //Data Table containing all parms required to insert into tblClaims_Workflow (the initial workflow record)
                string[] name;
                int ExistingLoanCount;
                string LoanNumber;
                string InvestorName;
                int InvestorNameID;
                string InvestorCode;
                int InvestorCodeID;
                int NewClaimID;
                string LiquidationType;
                int LiquidationTypeID;
                bool DetailRecordStored = false;
                bool WorkFlowRecordStored = false;

                ApplicationConfiguration ac = new ApplicationConfiguration(_settings);
                DataTable dtCMax = ac.Get_CMax_Attributes(_settings);
                DataView dvCMax = new DataView(dtCMax);
                dvCMax.RowFilter = "CMSClientID = " + _clientID;

                DataView dv = new DataView(dt332Data);

                //Process each of the incoming records
                for (int i = 0; i < dv.Count; i++)
                {
                    try
                    {
                        ExistingLoanCount = 0;
                        LoanNumber = "";
                        InvestorName = "";
                        InvestorNameID = 0;
                        InvestorCode = "";
                        InvestorCodeID = 0;
                        NewClaimID = 0;
                        LiquidationType = "";
                        LiquidationTypeID = 0;
                        DetailRecordStored = false;
                        WorkFlowRecordStored = false;


                        //Build three datatables (and associated dataviews) for holding parameter values for the SQL Table loads
                        //These tables should only hold 1 record as each import record is process individually
                        dtClaimsDetails = Build_ClaimsDetails_Table();
                        dtClaimsDetails.Rows.Add();
                        DataView dv1 = new DataView(dtClaimsDetails);

                        dtClaims332Details = Build_Claims332Details_Table();
                        dtClaims332Details.Rows.Add();
                        DataView dv2 = new DataView(dtClaims332Details);

                        dtInitWorkFlow = Build_WorkFlow_Table_Claims332();
                        dtInitWorkFlow.Rows.Add();
                        DataView dv3 = new DataView(dtInitWorkFlow);

                        //According to a business rule, LO Type should never be anything other than a 3 or a 6
                        if (dv[i]["LO TYPE"].ToString() != "3" && dv[i]["LO TYPE"].ToString() != "6")
                        {
                            //Action on this exception is to report the error, and do not process (import) the record
                            dv[i]["Processed"] = false;
                            dv[i]["ProcessComments"] = "LO TYPE Value is not valid: " + dv[i]["LO TYPE"].ToString();
                            goto NextRecord;

                        }

                        //Loan number is to be 10 characters in length
                        LoanNumber = dv[i]["Loan Number"].ToString().Trim();

                        if (LoanNumber.Length < 1 || LoanNumber.Length > 10)
                        {
                            dv[i]["Processed"] = false;
                            dv[i]["ProcessComments"] = "Loan Number length is not valid: " + LoanNumber.Length.ToString();
                            goto NextRecord;

                        }

                        LoanNumber = LoanNumber.PadLeft(10, '0');
                        dv1[0]["LoanNumber"] = LoanNumber;

                        //332 initial - and it is hard coded in the legacy import,
                        //Required for the check to see if the Claims332 Loan has already been loaded
                        dv1[0]["ClaimType"] = "332 initial";


                        //Before proceeding, we need to see if this loan has already been loaded
                        ExistingLoanCount = cm.CheckExistingLoan(LoanNumber, _clientID, dv1[0]["ClaimType"].ToString(), FormID, settings);

                        if (ExistingLoanCount != 0)
                        {
                            dv[i]["Processed"] = false;
                            dv[i]["ProcessComments"] = "Loan already exists in Claims 332";
                            goto NextRecord;

                        }

                        dv1[0]["ClaimDueDate"] = dv[i]["DUE_DATE"];
                        dv1[0]["ClientID"] = _clientID;
                        dv1[0]["PropertyAddress"] = dv[i]["PROPERTY STREET ADDRESS"];
                        dv1[0]["PropertyCity"] = dv[i]["CITY NAME"];
                        dv1[0]["PropertyState"] = dv[i]["PROPERTY ALPHA STATE CODE"];
                        dv1[0]["PropertyZip"] = dv[i]["PROPERTY ZIP CODE"];
                        dv1[0]["ServicerName"] = dtAddrData.Rows[0]["ServicerName"];
                        dv1[0]["ServicerAddress"] = dtAddrData.Rows[0]["ServicerAddress"];
                        dv1[0]["ServicerCity"] = dtAddrData.Rows[0]["ServicerCity"];
                        dv1[0]["ServicerState"] = dtAddrData.Rows[0]["ServicerState"];
                        dv1[0]["ServicerZip"] = dtAddrData.Rows[0]["ServicerZip"];
                        dv1[0]["ClaimFormID"] = FormID;

                        //Split the Mortgager name string, as supplied, into a separate first and last name and store for loading
                        name = split_BorrowerName(dv[i]["MORTGAGOR NAME"].ToString());
                        dv1[0]["BorrowerLastName"] = name[0];
                        dv1[0]["BorrowerFirstName"] = name[1];

                        dv1[0]["EnteredByUser"] = userID;

                        //Evaluate the Supplied Investor Name and ID Code values - Inserting them into the lookup if they do not exist
                        InvestorName = ReplaceNonPrintableInSuppliedString(dv[i]["INVESTOR NAME"].ToString().Trim());
                        InvestorNameID = GetInvestorNameID_ByNameAndFormID(InvestorName, FormID);
                        dv1[0]["InvestorNameID"] = InvestorNameID;

                        InvestorCode = ReplaceNonPrintableInSuppliedString(dv[i]["INVESTOR ID"].ToString().Trim());
                        InvestorCodeID = GetInvestorCodeID_ByCodeAndFormID(InvestorCode, FormID);
                        dv1[0]["InvestorCodeID"] = InvestorCodeID;

                        dv1[0]["CMaxClientID"] = dvCMax[0]["CMaxClientID"];

                        //This is all we should need to insert the new Claims 332 claim.
                        //Further steps require the claimID odf the new claim so it is 
                        //time to perform the insert and return the claimID
                        NewClaimID = cm.Claims332_Import_InsertNewClaim(dtClaimsDetails, settings);

                        if (NewClaimID == 0)
                        {
                            dv[i]["Processed"] = false;
                            dv[i]["ProcessComments"] = "Untrapped error occurred inserting the claim";
                            goto NextRecord;

                        }

                        dv[i]["ProcessComments"] = "Loan Imported.";

                        //At this point we have the newly inserted claimID
                        //Time to build and insert the claim 332 details import record
                        dv2[0]["ClaimID"] = NewClaimID;

                        LiquidationType = ReplaceNonPrintableInSuppliedString(dv[i]["CLAIM_TYPE"].ToString().Trim());

                        if (LiquidationType.Length == 0)
                        {
                            dv[i]["Processed"] = false;
                            dv[i]["ProcessComments"] = "CLAIM_TYPE is blank";
                            goto NextRecord;

                        }

                        LiquidationTypeID = GetLiqudationTypeID_ByCodeAndFormID(LiquidationType, FormID);

                        if (LiquidationTypeID == 0)
                        {
                            dv[i]["Processed"] = false;
                            dv[i]["ProcessComments"] = "CLAIM_TYPE value is invalid: " + dv[i]["CLAIM_TYPE"].ToString().Trim();
                            goto NextRecord;


                        }

                        else
                        {
                            dv2[0]["LiquidationType"] = LiquidationTypeID;

                        }

                        if (dv[i]["LIQUIDATION_DATE"].ToString().Length == 0)
                        {
                            dv[i]["Processed"] = false;
                            dv[i]["ProcessComments"] = "LIQUIDATION_DATE is blank";
                            goto NextRecord;

                        }

                        dv2[0]["LiquidationDate"] = dv[i]["LIQUIDATION_DATE"];

                        //From legacy import process, Lien Number is determined from the value of LOType
                        //LOType 3, Lien Number = 1
                        //LOType 6, Lien Number = 2
                        switch (int.Parse(dv[i]["LO TYPE"].ToString()))
                        {
                            case 3:
                                dv2[0]["LienNumber"] = 1;
                                break;

                            case 6:
                                dv2[0]["LienNumber"] = 2;
                                break;

                            default:
                                break;

                        }

                        DetailRecordStored = cm.Claims332_Import_InsertNewClaim332Details(dtClaims332Details, settings);

                        if (!DetailRecordStored)
                        {
                            dv[i]["Processed"] = false;
                            dv[i]["ProcessComments"] = dv[i]["ProcessComments"].ToString() + ", but Loan Details were not";
                            goto NextRecord;

                        }

                        dv[i]["ProcessComments"] = dv[i]["ProcessComments"].ToString() + " Loan Details Imported.";

                        //Now build and insert the initial workflow record
                        dv3[0]["ClaimID"] = NewClaimID;
                        dv3[0]["FormID"] = FormID;
                        dv3[0]["OpenUser"] = userID;
                        dv3[0]["AssignedToUser"] = 0; //Assigning the workflow step to no person - it will be blank when first displayed in the application

                        WorkFlowRecordStored = cm.Claims332_Import_InsertInitialWorkflowRecord(dtInitWorkFlow, settings);

                        if (!WorkFlowRecordStored)
                        {
                            dv[i]["Processed"] = false;
                            dv[i]["ProcessComments"] = dv[i]["ProcessComments"].ToString() + ", but Initail Workflow record was not";
                            goto NextRecord;
                        }

                        //After everything is completed, update the Processed and Process Comments columns showing success
                        dv[i]["Processed"] = true;
                        dv[i]["ProcessComments"] = "Import into Claims 332 Successful - " + dv[i]["ProcessComments"].ToString();

                    }

                    catch (Exception ex)
                    {
                        dv[i]["Processed"] = false;
                        dv[i]["ProcessComments"] = "Unhandled Error trapped.  Message is: " + ex.Message;
                    }

                NextRecord: ;

                }

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        private bool HasRequiredColumns_Claims332(DataTable dt)
        {
            try
            {
                bool answerValue = true;

                //20110512 TRS TODO - this is just a stub that always returns true
                //Eventually, required column logic should be implemented here

                return answerValue;
            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="investorCode"></param>
        /// <returns></returns>
        internal bool insertClaims332_InvestorCode(string investorCode)
        {
            SqlConnection con = new SqlConnection();
            int recordsAffected = 0;
            bool saved = false;

            try
            {
                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                SqlParameter prm = new SqlParameter();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase;
                cmd.CommandText = "usptblClaims332_InvestorCode_Insert";
                cmd.Connection = con;

                prm = new SqlParameter("@InvestorCode", investorCode);
                cmd.Parameters.Add(prm);

                recordsAffected = cmd.ExecuteNonQuery();
                saved = true;
                return saved;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="investorName"></param>
        /// <returns></returns>
        internal bool insertClaims332_InvestorName(string investorName)
        {
            SqlConnection con = new SqlConnection();
            int recordsAffected = 0;
            bool saved = false;

            try
            {
                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                SqlParameter prm = new SqlParameter();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase;
                cmd.CommandText = "usptblClaims332_InvestorName_Insert";
                cmd.Connection = con;

                prm = new SqlParameter("@InvestorName", investorName);
                cmd.Parameters.Add(prm);

                recordsAffected = cmd.ExecuteNonQuery();
                saved = true;
                return saved;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }
        */
        #endregion

        #region "Imports - Data Automation"

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="processID"></param>
        /// <param name="importDate"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        
        //This routine is not used yet
        internal DataTable ImportDataAutomationBatch(DataTable dt, int processID, DateTime importDate, Settings settings)
        {
            try
            {
                //Add the process status columns to the supplied data table
                DataColumn dc = new DataColumn(); 
                
                if (!dt.Columns.Contains("Processed"))
                {
                    dc = new DataColumn();
                    dc.ColumnName = "Processed";
                    dc.DataType = typeof(bool);
                    dc.DefaultValue = false;
                    dt.Columns.Add(dc);
                }

                if (!dt.Columns.Contains("ProcessComments"))
                {
                    dc = new DataColumn();
                    dc.ColumnName = "ProcessComments";
                    dc.DataType = typeof(string);
                    dc.DefaultValue = "Record was not processed";
                    dt.Columns.Add(dc);
                }
               
                //Clients are processed as batches, so we'll need to have a list to filter from
                //Create a table of the distinct Clients
                DataView dvClients = new DataView(dt);
                DataTable _clients = dvClients.ToTable("_clients", true, "Client");

                //With the data table that was passed in, filter it by each client
                for (int i = 0; i < _clients.Rows.Count; i++)
                {
                    
                    string Client = _clients.Rows[i]["Client"].ToString();

                    DataView dvClientFilteredBatch = new DataView(dt);
                    dvClientFilteredBatch.RowFilter = "Client = '" + Client + "'";

                    //Now create a table of the filtered values - this will be a table of just the job entries for a single client
                    DataTable dtClientFilteredBatch = dvClientFilteredBatch.ToTable("dtClientFilteredBatch");

                    //Generate a new GUID for this batch
                    Guid batchGUID = GetNewGUID();

                    switch (processID)
                    {
                        case 27: //FHA Part B Advice
                            //Call a new routine that specifically loads Part B advices job data
                            LoadClientBatch_FHA_PartBAdvices(dt, batchGUID, importDate, settings);
                            break;

                        default:
                            break;

                    }

                    //Now that the job has been loaded, we need to go through each record for the batch and return the load status
                    for (int j = 0; j < dtClientFilteredBatch.Rows.Count; j++)
                    {
                        int RowNumber = 0;
                        RowNumber = int.Parse(dtClientFilteredBatch.Rows[j]["Nbr"].ToString());

                        dvClientFilteredBatch.RowFilter = "Client = '" + Client + "' AND Nbr = " + RowNumber;

                        dvClientFilteredBatch[0]["Processed"] = dtClientFilteredBatch.Rows[j]["Processed"].ToString();
                        dvClientFilteredBatch[0]["ProcessComments"] = dtClientFilteredBatch.Rows[j]["ProcessComments"].ToString();

                    }

                }

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="batchGuid"></param>
        /// <param name="importDate"></param>
        /// <param name="settings"></param>
        
        //This routine is not used yet
        internal void LoadClientBatch_FHA_PartBAdvices(DataTable dt, Guid batchGuid, DateTime importDate, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("DataAutomation");
                con.Open();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (bool.Parse(dt.Rows[i]["Process"].ToString()))
                    {
                        SqlCommand cmd = new SqlCommand();
                        SqlParameter prm = new SqlParameter();
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase;
                        cmd.CommandText = "usp_FHAPartBAdvicesJob_Insert";
                        cmd.Connection = con;
                        
                        //Revise parms according to new storage?
                        prm = new SqlParameter("@LoanNumber", dt.Columns["LoanNumber"].ToString());
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@Client", dt.Columns["Client"].ToString());
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@ClaimType", dt.Columns["ClaimType"].ToString());
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@CaseNumber", dt.Columns["CaseNumber"].ToString());
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@ImportDate", importDate);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@ImportBatchGUID", batchGuid);
                        cmd.Parameters.Add(prm);

                    }
                }
                
            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
 
            }

        }

        /// <summary>
        /// Imports a table of LPS data to DataAutomation to match on (Servicer) Loan Number, Investor Loan Number,
        /// Submit Date, and Claim Amount.
        /// </summary>
        /// <param name="dt">The LPS data imported</param>
        internal void Import_LPS_ExistingClaimInventory_for_CMS_match_and_categorize(DataTable dt)
        {
            SqlConnection con = new SqlConnection(); 
            
            try
            {
                con.ConnectionString = _settings.GetConnectionString("DataAutomation");
                con.Open();

                SqlBulkCopy bulkCopy = new SqlBulkCopy(con);
                bulkCopy.DestinationTableName = "dbo.tbl_DA_LPS_Import_InvoiceMgmtExistingClaim";
                bulkCopy.BulkCopyTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase;

                //Map columns between memory and database tables
                bulkCopy.ColumnMappings.Add("ImportDate", "ImportDate");
                bulkCopy.ColumnMappings.Add("ImportedByUserID", "ImportedByUserID");
                bulkCopy.ColumnMappings.Add("ClaimType", "LPS_ClaimType");
                bulkCopy.ColumnMappings.Add("ClaimNumber", "LPS_ClaimNumber");
                bulkCopy.ColumnMappings.Add("InvestorLoanNumber", "LPS_InvestorLoanNumber");
                bulkCopy.ColumnMappings.Add("ServicerLoanNumber", "LPS_ServicerLoanNumber");
                bulkCopy.ColumnMappings.Add("ClaimStatus", "LPS_ClaimStatus");
                bulkCopy.ColumnMappings.Add("Check/ACHNumber", "LPS_Check_ACHNumber");
                bulkCopy.ColumnMappings.Add("CurrentStatusProcessDays", "LPS_CurrentStatusProcDays");
                bulkCopy.ColumnMappings.Add("SubmittedDate", "LPS_SubmittedDate");
                bulkCopy.ColumnMappings.Add("ClaimAge", "LPS_ClaimAge");
                bulkCopy.ColumnMappings.Add("RequestedAmount", "LPS_RequestedAmount");
                bulkCopy.ColumnMappings.Add("AmountToPay", "LPS_AmountToPay");
                bulkCopy.ColumnMappings.Add("ClaimExportDate", "LPS_ClaimExportDate");
                bulkCopy.ColumnMappings.Add("Processor", "LPS_Processor");
                bulkCopy.ColumnMappings.Add("ClaimID", "CMS_ClaimID");
                bulkCopy.ColumnMappings.Add("UpdateType", "UpdateType");

                //This should write the whole table, in bulk to the server
                bulkCopy.WriteToServer(dt);

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        internal void Run_LPS_ExistingClaimInventory_to_CMS_match_and_categorize(int clientID)
        {
            SqlConnection con = new SqlConnection(); 
            
            try
            {
                con.ConnectionString = _settings.GetConnectionString("DataAutomation");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase;
                cmd.CommandText = "usp_DA_LPS_ExistingClaimsImport_MatchAndCompare";
                cmd.Connection = con;

                SqlParameter prm = new SqlParameter();
                prm = new SqlParameter("@ClientID", clientID);
                cmd.Parameters.Add(prm);

                int rtnValue = cmd.ExecuteNonQuery();

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        internal DataTable Get_LPS_ExistingClaimInventory_CMS_Matched(DataTable dt)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("DataAutomation");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase;
                cmd.CommandText = "usp_DA_LPS_Import_InvoiceMgmtExistingClaim_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        DataRow row = dt.NewRow();

                        row["Servicer"] = dr["LPS_Servicer"];
                        row["ClaimType"] = dr["LPS_ClaimType"];
                        row["ClaimNumber"] = dr["LPS_ClaimNumber"];
                        row["InvestorLoanNumber"] = dr["LPS_InvestorLoanNumber"];
                        row["ServicerLoanNumber"] = dr["LPS_ServicerLoanNumber"];
                        row["ClaimStatus"] = dr["LPS_ClaimStatus"];
                        row["Check/ACHNumber"] = dr["LPS_Check_ACHNumber"];
                        row["CurrentStatusProcessDays"] = dr["LPS_CurrentStatusProcDays"];
                        row["SubmittedDate"] = dr["LPS_SubmittedDate"];
                        row["RequestedAmount"] = dr["LPS_RequestedAmount"];
                        row["AmountToPay"] = dr["LPS_AmountToPay"];
                        row["ClaimExportDate"] = dr["LPS_ClaimExportDate"];
                        row["Processor"] = dr["LPS_Processor"];
                        row["ClaimID"] = dr["CMS_ClaimID"];
                        row["UpdateType"] = dr["UpdateType"];
                        row["ImportDate"] = dr["ImportDate"];
                        row["ImportedByUserID"] = dr["ImportedByUserID"];
                        
                        dt.Rows.Add(row);

                    }
                }

                dt.AcceptChanges();

                return dt;
            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        internal void Run_LPS_ExistingClaimInventory_Cleanup()
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("DataAutomation");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase;
                cmd.CommandText = "usp_DA_LPS_Import_InvoiceMgmtExistingClaim_Reset";
                cmd.Connection = con;

                int rtnValue = cmd.ExecuteNonQuery();

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        #endregion
        
        #region "Imports - FNMA PFU"
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="ReferralTypeID"></param>
        /// <param name="databaseName"></param>
        /// <param name="processDate"></param>
        /// <param name="settings"></param>
        /// <param name="processID"></param>
        /// <param name="events"></param>
        /// <param name="userUniqueID"></param>
        /// <param name="cm"></param>
        /// <returns></returns>
        internal DataTable ImportCMSFNMAPaymentFollowup(DataTable dt, int ReferralTypeID, string databaseName, string processDate, CRFS.Data.Settings settings, int processID, Moss.Events.Events events, int userUniqueID, ClaimsManagement cm)
        {
            double nextTarget = .01;
            SqlConnection sqlConn = new SqlConnection();
            SqlCommand sqlCmd = new SqlCommand();
            SqlParameter prm = new SqlParameter();

            try
            {
                bool overrideReferralDate = false;

                DataColumn dc = new DataColumn();

                if (!dt.Columns.Contains("Processed"))
                {
                    dc = new DataColumn();
                    dc.ColumnName = "Processed";
                    dc.DataType = typeof(bool);
                    dc.DefaultValue = true;
                    dt.Columns.Add(dc);
                }

                if (!dt.Columns.Contains("ProcessComments"))
                {
                    dc = new DataColumn();
                    dc.ColumnName = "ProcessComments";
                    dc.DataType = typeof(string);
                    dc.DefaultValue = "Import Successful";
                    dt.Columns.Add(dc);
                }

                if (dt.Columns.Contains("REFERRAL DATE"))
                {
                    overrideReferralDate = true;
                }

                int rowCount = dt.Rows.Count;

                string sConn = _settings.GetConnectionString(databaseName);

                sqlConn.ConnectionString = sConn;
                SqlTransaction sqlTran;

                sqlConn.Open();
                if (sqlConn.State == ConnectionState.Open)
                {
                    for (int i = 0; i < rowCount; i++)
                    {
                        //Before starting a SQL Transaction, we need to look at the MI Company and Servicer names
                        //Since these are text, we get a lot of variation for them and they must be grouped to send emails
                        //Therefore, we are now flagging on import when we can't find a match.  After being set up for the MI
                        //Company/Servicer name, the records can/shpould be re-imported.

                        //First check to see if the MI Company name exists
                        string MICompanyName = ReplaceNonPrintableInSuppliedString(dt.Rows[i]["MI_INS_NME_ABRV"].ToString());
                        int MICompanyID = 0;
                        bool MIAddedFlag = false;

                        DataTable dtMiCompanies = cm.GetMICompanyNames(settings);
                        DataView dvMICompany = new DataView(dtMiCompanies);
                        dvMICompany.RowFilter = "BusinessEntityName = '" + MICompanyName + "'";

                        switch (dvMICompany.Count)
                        {
                            case 0:
                                //The MI Company needs to be added to the BusinessEntities table.  This can be done automatically,
                                //But it will need manual steps performed to be added to a group as well as designate it as either backend or not
                                //we'll set a message flag for this
                                MICompanyID = cm.InsertMICompany(MICompanyName, settings);
                                MIAddedFlag = true;
                                break;

                            case 1:
                                //We're in good shape.  We have a single match.  Use the BusinessEntityID for loading this record
                                MICompanyID = int.Parse(dvMICompany[0]["BusinessEntityID"].ToString());
                                break;

                            default:
                                //We have more than one record returned
                                dt.Rows[i]["Processed"] = false;
                                dt.Rows[i]["ProcessComments"] = "ERROR: There is more than one MI Company matching the value for this import record.  This record was not saved";

                                goto NextRecord;
                                break;

                        }

                        string ServicerName = ReplaceNonPrintableInSuppliedString(dt.Rows[i]["SRVCR_NME"].ToString());
                        int ServicerID = 0;
                        bool ServicerAddedFlag = false;

                        DataTable dtServicers = cm.GetServicerNames(settings);
                        DataView dvServicer = new DataView(dtServicers);
                        dvServicer.RowFilter = "BusinessEntityName = '" + ServicerName + "'";

                        switch (dvServicer.Count)
                        {
                            case 0:
                                ServicerID = cm.InsertServicer(ServicerName, settings);
                                ServicerAddedFlag = true;
                                break;

                            case 1:
                                //We're in good shape.  We have a single match.  Use the BusinessEntityID for loading this record    
                                ServicerID = int.Parse(dvServicer[0]["BusinessEntityID"].ToString());
                                break;

                            default:
                                //We have more than one record returned
                                dt.Rows[i]["Processed"] = false;
                                dt.Rows[i]["ProcessComments"] = "ERROR: There is more than one Servicer matching the value for this import record.  This record was not saved";

                                goto NextRecord;
                                break;

                        }

                        sqlTran = sqlConn.BeginTransaction();
                        try
                        {
                            //Create a record for the loan
                            sqlCmd = new SqlCommand();
                            sqlCmd.CommandTimeout = Configuration.CommandTimeouts_Extra_ClaimsManagementSQLDatabase;
                            sqlCmd.CommandType = CommandType.StoredProcedure;
                            sqlCmd.CommandText = "usp_PFU_Referral_Insert";
                            sqlCmd.Transaction = sqlTran;

                            //The null after the REO_ID terniary operator is because for Non-REO type referrals this field needs to be null.  
                            //A zero length string causes problems between edits to referrals and  subsequent Non-REO imports.
                            prm = new SqlParameter("@REO_ID", dt.Rows[i]["REO_ID"].ToString().Trim().Length == 0 ? null : dt.Rows[i]["REO_ID"].ToString());
                            sqlCmd.Parameters.Add(prm);
                            prm = new SqlParameter("@FNMALoanNumber", dt.Rows[i]["LOAN_NO"].ToString());
                            sqlCmd.Parameters.Add(prm);
                            prm = new SqlParameter("@ServicerName", dt.Rows[i]["SRVCR_NME"].ToString());
                            sqlCmd.Parameters.Add(prm);
                            prm = new SqlParameter("@ServicerLoanNumber", dt.Rows[i]["SRVCR_LOAN_NO"].ToString());
                            sqlCmd.Parameters.Add(prm);
                            prm = new SqlParameter("@PropertyAddress", dt.Rows[i]["PROP_ADDR"].ToString());
                            sqlCmd.Parameters.Add(prm);
                            prm = new SqlParameter("@City", dt.Rows[i]["PROP_CTY"].ToString());
                            sqlCmd.Parameters.Add(prm);
                            prm = new SqlParameter("@State", dt.Rows[i]["PROP_ST"].ToString());
                            sqlCmd.Parameters.Add(prm);
                            prm = new SqlParameter("@ZipCode", dt.Rows[i]["PROP_ZIP"].ToString());
                            sqlCmd.Parameters.Add(prm);
                            prm = new SqlParameter("@MICompanyName", dt.Rows[i]["MI_INS_NME_ABRV"].ToString());
                            sqlCmd.Parameters.Add(prm);
                            prm = new SqlParameter("@MICertificateNumber", dt.Rows[i]["MI_CERT_NO"].ToString());
                            sqlCmd.Parameters.Add(prm);
                            prm = new SqlParameter("@ForeclosureDate", dt.Rows[i]["fcl_dt"].ToString().Trim().Length == 0 ? DateTime.Parse("1/1/1900") : DateTime.Parse(dt.Rows[i]["fcl_dt"].ToString().Trim()));
                            sqlCmd.Parameters.Add(prm);
                            prm = new SqlParameter("@RRCExpirationDate", dt.Rows[i]["RDMPTN_END_DT"].ToString().Trim().Length == 0 ? DateTime.Parse("1/1/1900") : DateTime.Parse(dt.Rows[i]["RDMPTN_END_DT"].ToString().Trim()));
                            sqlCmd.Parameters.Add(prm);
                            prm = new SqlParameter("@ClaimEligibleDate", dt.Rows[i]["CLM_ELGBL_DT"].ToString().Trim().Length == 0 ? DateTime.Parse("1/1/1900") : DateTime.Parse(dt.Rows[i]["CLM_ELGBL_DT"].ToString().Trim()));
                            sqlCmd.Parameters.Add(prm);
                            prm = new SqlParameter("@EnteredByUser", userUniqueID);
                            sqlCmd.Parameters.Add(prm);
                            prm = new SqlParameter("@ReferralDate", overrideReferralDate == true ? dt.Rows[i]["REFERRAL DATE"] : processDate);
                            sqlCmd.Parameters.Add(prm);
                            prm = new SqlParameter("@ReferralTypeID", ReferralTypeID);
                            sqlCmd.Parameters.Add(prm);
                            prm = new SqlParameter("@BusinessEntityIDServicer",ServicerID);
                            sqlCmd.Parameters.Add(prm);
                            prm = new SqlParameter("@BusinessEntityIDMICompany",MICompanyID);
                            sqlCmd.Parameters.Add(prm);

                            sqlCmd.Connection = sqlConn;
                            int referralID;

                            referralID = int.Parse(sqlCmd.ExecuteScalar().ToString());


                            if (referralID < 0)
                            {
                                dt.Rows[i]["Processed"] = false;

                                switch (referralID)
                                {
                                    case -1:
                                        dt.Rows[i]["ProcessComments"] = "ERROR: There is already an active referral for this REO ID.  This record was not saved";
                                        break;
                                    case -2:
                                        dt.Rows[i]["ProcessComments"] = "ERROR: There is already an active referral for this FNMA Loan Number.  This record was not saved";
                                        break;
                                    case -1000:
                                        dt.Rows[i]["ProcessComments"] = "ERROR: ReferralID Not Initialized - Examine Referral Type.  This record was not saved";
                                        break;
                                    default:
                                        dt.Rows[i]["ProcessComments"] = "ERROR: Return Value " + referralID.ToString() + " is not configured in Data Layer.  This record was not saved";
                                        break;
                                }

                                sqlTran.Rollback();
                                goto NextRecord;

                            }

                            else
                            {
                                //unique referral id was returned
                                dt.Rows[i]["Processed"] = true;
                                dt.Rows[i]["ProcessComments"] = "Record saved with Referral ID: " + referralID.ToString();

                                if (ServicerAddedFlag)
                                {
                                    dt.Rows[i]["ProcessComments"] = "Servicer added and needs to be added to a group. " + dt.Rows[i]["ProcessComments"].ToString();

                                }

                                if (MIAddedFlag)
                                {
                                    dt.Rows[i]["ProcessComments"] = "MI Company added and needs to be added to a group, plus backend determined. " + dt.Rows[i]["ProcessComments"].ToString();

                                }

                                sqlTran.Commit();
                                goto NextRecord;
                            }

                        }

                        catch (Exception e)
                        {
                            dt.Rows[i]["Processed"] = false;
                            dt.Rows[i]["ProcessComments"] = "An error occurred while trying to insert this record.  This record was not saved";
                            sqlTran.Rollback();
                            goto NextRecord;
                        }

                    NextRecord: ;
                        if ((((double)i + 1) / (double)rowCount) >= nextTarget)
                        {
                            nextTarget += .01;
                            events.OnRaiseImportStatusUpdateEvent();
                        }
                    }
                }

                return dt;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                if (sqlConn.State != ConnectionState.Closed)
                {
                    sqlConn.Close();
                    sqlConn.Dispose();
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="ReferralTypeID"></param>
        /// <param name="processDate"></param>
        /// <param name="processID"></param>
        /// <param name="events"></param>
        /// <param name="userUniqueID"></param>
        /// <param name="cm"></param>
        internal DataTable ImportPFU_CloseAndBill(DataTable dt, int ReferralTypeID, string processDate, int userUniqueID, ClaimsManagement cm)
        {
            try
            {
                DataColumn dc = new DataColumn();
                DateTime _processDate = DateTime.Parse(processDate);
                int LockID;
                bool IsLockReleased;

                if (!dt.Columns.Contains("Processed"))
                {
                    dc = new DataColumn();
                    dc.ColumnName = "Processed";
                    dc.DataType = typeof(bool);
                    dc.DefaultValue = false;
                    dt.Columns.Add(dc);
                }

                if (!dt.Columns.Contains("ProcessComments"))
                {
                    dc = new DataColumn();
                    dc.ColumnName = "ProcessComments";
                    dc.DataType = typeof(string);
                    dc.DefaultValue = "Not Yet Processed";
                    dt.Columns.Add(dc);
                }

                DataView dv1 = new DataView(dt);

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    bool result = false;

                    //Check for in-file duplication
                    dv1.RowFilter = "LOAN_NO ='" + dt.Rows[i]["LOAN_NO"].ToString() + "'";

                    switch (dv1.Count)
                    {
                        case 1:
                            //The referral record is not duplicated within the file, we need to evaluate referral data in CMS for exceptions
                            DataTable dtEval = cm.PFU_AutoCloseExceptionEvaluation_SelectByFNMALoanNumber(dt.Rows[i]["LOAN_NO"].ToString());
                            
                            switch (dtEval.Rows.Count)
                            {
                                case 0:
                                    dt.Rows[i]["Processed"] = false;
                                    dt.Rows[i]["ProcessComments"] = "Referral is not in CMS";
                                    
                                    break;
                                    
                                case 1:
                                    //There is only one record of this referral IN CMS.  Make sure the record status is open
                                    switch (dtEval.Rows[0]["Status"].ToString().ToUpper())
                                    {
                                        case "RECEIVED":
                                        case "WORKING":
                                            //The referral is still open.  The referral must have been referred at least 7 days ago
                                            DateTime AgedreferralDate = DateTime.Parse(dtEval.Rows[0]["ReferralDate"].ToString()).AddDays(7);

                                            if (AgedreferralDate < _processDate)
                                            {
                                                //We've had the referral at least 7 days
                                                //Now we evaluate Which type of automation we're going to be performing
                                                switch (dt.Rows[i]["MI_DLY_TYP_CD_DESCPTN"].ToString().Length)
                                                {
                                                    case 0:
                                                        //We should be doing a Claim Paid, since this field is not filled in
                                                        //MI_PROCEEDS_RCVD and MI_PROCEEDS_DT must be filled in (Columns O and P)
                                                        if (dt.Rows[i]["MI_PROCEEDS_RCVD"].ToString().Length == 0 || dt.Rows[i]["MI_PROCEEDS_DT"].ToString().Length == 0)
                                                        {
                                                            dt.Rows[i]["Processed"] = false;
                                                            dt.Rows[i]["ProcessComments"] = "MI_PROCEEDS_RCVD and MI_PROCEEDS_DT (Columns O and P) must both be populated";
                                                            
                                                        }
                                                        
                                                        else
                                                        {
                                                            //Check to make sure neither of the fields for Claim Denied/Terminated/Rescinded are filled in.
                                                            if (dt.Rows[i]["MI_DLY_TYP_CD_DESCPTN"].ToString().Length > 0 || dt.Rows[i]["MI_DLAY_CREATED_DT"].ToString().Length > 0)
                                                            {
                                                                dt.Rows[i]["Processed"] = false;
                                                                dt.Rows[i]["ProcessComments"] = "MI_DLY_TYP_CD_DESCPTN and MI_DLAY_CREATED_DT (Columns M and N) must both be empty";
                                                                
                                                            }
                                                            
                                                            else
                                                            {
                                                                //There is one last check to make on Claim Paid.  The Proceeds Received amount must be at least $2000.  We're to list as an exception if less than 2000.
                                                                if (decimal.Parse(dt.Rows[i]["MI_PROCEEDS_RCVD"].ToString()) < 2000m)
                                                                {
                                                                    dt.Rows[i]["Processed"] = false;
                                                                    dt.Rows[i]["ProcessComments"] = "Proceeds Recieved Amount is less than $2000";

                                                                }

                                                                else
                                                                {
                                                                    //T-6072 20111208 TRS - We need to get a lock on the referral here.  If we don't, note an exception that the referral was being worked when the job was run
                                                                    LockID = cm.PFU_Lock_Request(Environment.MachineName, userUniqueID, ReferralID: int.Parse(dtEval.Rows[0]["ReferralID"].ToString()), FormID: 9);

                                                                    if (LockID > 0)
                                                                    {
                                                                        result = PFU_PerformClaimPaid(dt, dt.Rows[i]["LOAN_NO"].ToString(), int.Parse(dtEval.Rows[0]["ReferralID"].ToString()), _processDate, userUniqueID, cm);

                                                                        if (result)
                                                                        {
                                                                            dt.Rows[i]["Processed"] = true;
                                                                            dt.Rows[i]["ProcessComments"] = "Success. Processed Claim Paid";

                                                                        }

                                                                        else
                                                                        {
                                                                            dt.Rows[i]["Processed"] = false;
                                                                            dt.Rows[i]["ProcessComments"] = "Unable to Process Claim Paid - Please examine CMS Data";

                                                                        }

                                                                        IsLockReleased = cm.PFU_Lock_Release(LockID);

                                                                    }

                                                                    else
                                                                    {
                                                                        dt.Rows[i]["Processed"] = false;
                                                                        
                                                                        switch (LockID)
                                                                        {
                                                                            case -2000:
                                                                                dt.Rows[i]["ProcessComments"] = "Unable to obtain locate referral to obtain lock";
                                                                                break;

                                                                            case -1002:
                                                                                dt.Rows[i]["ProcessComments"] = "This workstation already has a lock that has not been released";
                                                                                break;

                                                                            case -1001:
                                                                                dt.Rows[i]["ProcessComments"] = "Current user already has a lock that has not been released";
                                                                                break;

                                                                            case -1000:
                                                                            default:
                                                                                dt.Rows[i]["ProcessComments"] = "Unable to obtain lock to Process Claim Paid - Referral is already locked";
                                                                                break;

                                                                        }

                                                                    }
                                                                    //T-6072 Ends 20111208 TRS

                                                                }
                                                                
                                                            }
                                                            
                                                        }
                                                        
                                                        break;

                                                    default:
                                                        //We're doing either Claim Denied or Policy Terminated Rescinded
                                                        //MI_DLY_TYP_CD_DESCPTN and MI_DLAY_CREATED_DT (Columns M and N) must both be populated
                                                        if (dt.Rows[i]["MI_DLY_TYP_CD_DESCPTN"].ToString().Length == 0 || dt.Rows[i]["MI_DLAY_CREATED_DT"].ToString().Length == 0)
                                                        {
                                                            dt.Rows[i]["Processed"] = false;
                                                            dt.Rows[i]["ProcessComments"] = "MI_DLY_TYP_CD_DESCPTN and MI_DLAY_CREATED_DT (Columns M and N) must both be populated";

                                                        }

                                                        else
                                                        {
                                                            //Check to make sure neither of the fields for Claim Paid are filled in.
                                                            if (dt.Rows[i]["MI_PROCEEDS_RCVD"].ToString().Length > 0 || dt.Rows[i]["MI_PROCEEDS_DT"].ToString().Length > 0)
                                                            {
                                                                dt.Rows[i]["Processed"] = false;
                                                                dt.Rows[i]["ProcessComments"] = "MI_PROCEEDS_RCVD and MI_PROCEEDS_DT (Columns O and P) must both be empty";

                                                            }

                                                            else
                                                            {
                                                                switch (dt.Rows[i]["MI_DLY_TYP_CD_DESCPTN"].ToString().ToUpper())
                                                                {
                                                                    case "CLAIM DENIED":
                                                                        //T-6072 20111208 TRS - We need to get a lock on the referral here.  If we don't, note an exception that the referral was being worked when the job was run
                                                                        LockID = cm.PFU_Lock_Request(Environment.MachineName, userUniqueID, ReferralID: int.Parse(dtEval.Rows[0]["ReferralID"].ToString()), FormID: 9);

                                                                        if (LockID > 0)
                                                                        {
                                                                            result = PFU_PerformClaimDenied(dt, dt.Rows[i]["LOAN_NO"].ToString(), int.Parse(dtEval.Rows[0]["ReferralID"].ToString()), _processDate, userUniqueID, cm);

                                                                            if (result)
                                                                            {
                                                                                dt.Rows[i]["Processed"] = true;
                                                                                dt.Rows[i]["ProcessComments"] = "Success. Processed Claim Denied";

                                                                            }

                                                                            else
                                                                            {
                                                                                dt.Rows[i]["Processed"] = false;
                                                                                dt.Rows[i]["ProcessComments"] = "Unable to Process Claim Denied - Please examine CMS Data";

                                                                            }
                                                                            
                                                                            IsLockReleased = cm.PFU_Lock_Release(LockID);
                                                                        }

                                                                        else
                                                                        {
                                                                            dt.Rows[i]["Processed"] = false;
                                                                        
                                                                            switch (LockID)
                                                                            {
                                                                                case -2000:
                                                                                    dt.Rows[i]["ProcessComments"] = "Unable to obtain locate referral to obtain lock";
                                                                                    break;

                                                                                case -1002:
                                                                                    dt.Rows[i]["ProcessComments"] = "This workstation already has a lock that has not been released";
                                                                                    break;

                                                                                case -1001:
                                                                                    dt.Rows[i]["ProcessComments"] = "Current user already has a lock that has not been released";
                                                                                    break;

                                                                                case -1000:
                                                                                default:
                                                                                    dt.Rows[i]["ProcessComments"] = "Unable to obtain lock to Process Claim Denied - Referral is already locked";
                                                                                    break;

                                                                            }

                                                                        }
                                                                        //T-6072 Ends 20111208 TRS

                                                                        break;

                                                                    case "MI POLICY TERMINATED/RESCINDED":
                                                                        //T-6072 20111208 TRS - We need to get a lock on the referral here.  If we don't, note an exception that the referral was being worked when the job was run
                                                                        LockID = cm.PFU_Lock_Request(Environment.MachineName, userUniqueID, ReferralID: int.Parse(dtEval.Rows[0]["ReferralID"].ToString()), FormID: 9);

                                                                        if (LockID > 0)
                                                                        { 
                                                                            //T-6072 20111208 TRS - We need to get a lock on the referral here.  If we don't, note an exception that the referral was being worked when the job was run
                                                                            result = PFU_PerformMITerminatedRescinded(dt, dt.Rows[i]["LOAN_NO"].ToString(), int.Parse(dtEval.Rows[0]["ReferralID"].ToString()), _processDate, userUniqueID, cm);

                                                                            if (result)
                                                                            {
                                                                                dt.Rows[i]["Processed"] = true;
                                                                                dt.Rows[i]["ProcessComments"] = "Success. MI Policy Terminated/Rescinded";
                                                                            
                                                                            }

                                                                            else
                                                                            {
                                                                                dt.Rows[i]["Processed"] = false;
                                                                                dt.Rows[i]["ProcessComments"] = "Unable to Process MI Policy Terminated/Rescinded - Please examine CMS Data";

                                                                            }
                                                                            
                                                                            IsLockReleased = cm.PFU_Lock_Release(LockID);
                                                                        }

                                                                        else
                                                                        {
                                                                            dt.Rows[i]["Processed"] = false;
                                                                        
                                                                            switch (LockID)
                                                                            {
                                                                                case -2000:
                                                                                    dt.Rows[i]["ProcessComments"] = "Unable to obtain locate referral to obtain lock";
                                                                                    break;

                                                                                case -1002:
                                                                                    dt.Rows[i]["ProcessComments"] = "This workstation already has a lock that has not been released";
                                                                                    break;

                                                                                case -1001:
                                                                                    dt.Rows[i]["ProcessComments"] = "Current user already has a lock that has not been released";
                                                                                    break;

                                                                                case -1000:
                                                                                default:
                                                                                    dt.Rows[i]["ProcessComments"] = "Unable to obtain lock to Process MI Policy Terminated/Rescinded - Referral is already locked";
                                                                                    break;

                                                                            }

                                                                        }
                                                                        //T-6072 Ends 20111208 TRS

                                                                        break;

                                                                    default:
                                                                        dt.Rows[i]["Processed"] = false;
                                                                        dt.Rows[i]["ProcessComments"] = "MI_DLY_TYP_CD_DESCPTN Invalid entry: " + dt.Rows[i]["MI_DLY_TYP_CD_DESCPTN"].ToString();
                                                                        break;

                                                                }
                                                            }
                                                        }
                                                        
                                                        break;
                                                        
                                                } //End of switch-Import type checking

                                            }

                                            else
                                            {
                                                dt.Rows[i]["Processed"] = false;
                                                dt.Rows[i]["ProcessComments"] = "Referral Date is less than 7 days ago";

                                            } //End of If/else referral date check
 
                                            break;
                                            
                                        default:
                                            dt.Rows[i]["Processed"] = false;
                                            dt.Rows[i]["ProcessComments"] = "Status is " + dtEval.Rows[0]["Status"].ToString().ToUpper();
                                            
                                            break;
                                            
                                    } //End of switch-Status check

                                    break;
                                    
                                default:
                                    dt.Rows[i]["Processed"] = false;
                                    dt.Rows[i]["ProcessComments"] = "This referral has duplicate FNMA Loan Number records in CMS";
                                    
                                    break;
                                    
                            } //End of switch-check for loan in CMS and duplication
                            
                            break;

                        default:
                            dt.Rows[i]["Processed"] = false;
                            dt.Rows[i]["ProcessComments"] = "There are " + dv1.Count.ToString() + " records for LOAN_NO " + dt.Rows[i]["LOAN_NO"].ToString() + " in this file.";
                            
                            break;
                            
                    } //End of switch-check for in-file duplication

                } //End of for loop


                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="ReferralID"></param>
        /// <param name="processDate"></param>
        /// <param name="userUniqueID"></param>
        /// <param name="cm"></param>
        /// <returns></returns>
        internal bool PFU_PerformClaimDenied(DataTable dt, string FNMALoanNumber, int ReferralID, DateTime processDate, int userUniqueID, ClaimsManagement cm)
        {
            bool result = false;
            bool result2 = false;
            bool result3 = false;

            try
            {
                //Gather information needed to set CDRT for Claim Denied                
                DataView dv1 = new DataView(dt);
                dv1.RowFilter = "LOAN_NO = '" + FNMALoanNumber + "'";

                DateTime CDRTNotificationDate = DateTime.Parse(dv1[0]["MI_DLAY_CREATED_DT"].ToString());
                DateTime MIReopenResponseDate = processDate;
                DateTime CDRTResolutionDate = processDate;

                DataTable dtCBOValues = new DataTable("ComboBoxValues");
                dtCBOValues = cm.GetComboBoxReferenceValues_ByFormID(9, _settings);
                DataView dv2 = new DataView(dtCBOValues);
                
                dv2.RowFilter = "ComboBoxTypeTag = 'CDRTStatus' AND ComboBoxText = 'Denied'";
                int CDRTStatus = int.Parse(dv2[0]["id"].ToString());
                
                dv2.RowFilter = "ComboBoxTypeTag = 'MIResponseToReopen' AND ComboBoxText = 'No'";
                int MIResponseToReopen = int.Parse(dv2[0]["id"].ToString());

                result = cm.PFU_CDRT_UpSert(ReferralID, CDRTStatus, MIResponseToReopen, CDRTNotificationDate, MIReopenResponseDate, CDRTResolutionDate, userUniqueID);

                if (result)
                {
                    //CDRT was set, we continue now with setting Comments
                    dv2.RowFilter = "ComboBoxTypeTag = 'CommentType' AND ComboBoxText = 'Other'";
                    int CommentTypeID = int.Parse(dv2[0]["id"].ToString());

                    dv2.RowFilter = "ComboBoxTypeTag = 'CommentCategory' AND ComboBoxText = 'Comment'";
                    int CommentCategoryID = int.Parse(dv2[0]["id"].ToString());
                    
                    string CommentText = "Per investor, MI COVERAGE DENIED, close and bill.";

                    result2 = cm.PFU_ClosingComment_Insert(ReferralID, CommentText, CommentTypeID, CommentCategoryID, userUniqueID);

                    if (result2)
                    {
                        //The closing comment was inserted, time to close the claim
                        dv2.RowFilter = "ComboBoxTypeTag = 'ClaimStatus' AND ComboBoxText = 'Bill - Closed'";
                        int ClaimStatusID = int.Parse(dv2[0]["id"].ToString());

                        result3 = cm.PFU_CloseReferral(ReferralID, ClaimStatusID, userUniqueID, processDate);

                        result = result3;

                    }

                    else result = result2;

                }

                return result;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {


            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="FNMALoanNumber"></param>
        /// <param name="ReferralID"></param>
        /// <param name="processDate"></param>
        /// <param name="userUniqueID"></param>
        /// <param name="cm"></param>
        /// <returns></returns>
        internal bool PFU_PerformClaimPaid(DataTable dt, string FNMALoanNumber, int ReferralID, DateTime processDate, int userUniqueID, ClaimsManagement cm)
        {
            bool result = false;
            bool result2 = false;
            bool result3 = false;

            try
            {
                //Gather information needed to set Claim Paid                
                DataView dv1 = new DataView(dt);
                dv1.RowFilter = "LOAN_NO = '" + FNMALoanNumber + "'";

                decimal SettlementAmount = decimal.Parse(dv1[0]["MI_PROCEEDS_RCVD"].ToString());
                DateTime SettlementReceivedDate = DateTime.Parse(dv1[0]["MI_PROCEEDS_DT"].ToString());

                DataTable dtCBOValues = new DataTable("ComboBoxValues");
                dtCBOValues = cm.GetComboBoxReferenceValues_ByFormID(9, _settings);
                DataView dv2 = new DataView(dtCBOValues);

                dv2.RowFilter = "ComboBoxTypeTag = 'SettlementType' AND ComboBoxText = 'Unknown'";
                int SettlementTypeID = int.Parse(dv2[0]["id"].ToString());

                result = cm.PFU_PaymentReceived_UpSert(ReferralID, SettlementTypeID, SettlementAmount, SettlementReceivedDate, userUniqueID);

                if (result)
                {
                    //Set up the closing comment and enter it
                    //CDRT was set, we continue now with setting Comments
                    dv2.RowFilter = "ComboBoxTypeTag = 'CommentType' AND ComboBoxText = 'Other'";
                    int CommentTypeID = int.Parse(dv2[0]["id"].ToString());

                    dv2.RowFilter = "ComboBoxTypeTag = 'CommentCategory' AND ComboBoxText = 'Comment'";
                    int CommentCategoryID = int.Parse(dv2[0]["id"].ToString());

                    string CommentText = "Per investor, MI CLAIM PAYMENT RECEIVED, close and bill.";

                    result2 = cm.PFU_ClosingComment_Insert(ReferralID, CommentText, CommentTypeID, CommentCategoryID, userUniqueID);

                    if (result2)
                    {
                        //Now Close out the referral
                        dv2.RowFilter = "ComboBoxTypeTag = 'ClaimStatus' AND ComboBoxText = 'Bill - Closed'";
                        int ClaimStatusID = int.Parse(dv2[0]["id"].ToString());

                        result3 = cm.PFU_CloseReferral(ReferralID, ClaimStatusID, userUniqueID, processDate);

                        result = result3;

                    }

                    else
                    {
                        result = result2;

                    }

                }

                return result;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {


            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="FNMALoanNumber"></param>
        /// <param name="ReferralID"></param>
        /// <param name="processDate"></param>
        /// <param name="userUniqueID"></param>
        /// <param name="cm"></param>
        /// <returns></returns>
        internal bool PFU_PerformMITerminatedRescinded(DataTable dt, string FNMALoanNumber, int ReferralID, DateTime processDate, int userUniqueID, ClaimsManagement cm)
        {
            bool result = false;
            bool result2 = false;
            bool result3 = false;

            try
            {
                //Gather information needed to set CDRT for Claim Denied                
                DataView dv1 = new DataView(dt);
                dv1.RowFilter = "LOAN_NO = '" + FNMALoanNumber + "'";

                DateTime CDRTNotificationDate = DateTime.Parse(dv1[0]["MI_DLAY_CREATED_DT"].ToString());
                DateTime MIReopenResponseDate = processDate;
                DateTime CDRTResolutionDate = processDate;

                DataTable dtCBOValues = new DataTable("ComboBoxValues");
                dtCBOValues = cm.GetComboBoxReferenceValues_ByFormID(9, _settings);
                DataView dv2 = new DataView(dtCBOValues);

                dv2.RowFilter = "ComboBoxTypeTag = 'CDRTStatus' AND ComboBoxText = 'Rescinded'";
                int CDRTStatus = int.Parse(dv2[0]["id"].ToString());

                dv2.RowFilter = "ComboBoxTypeTag = 'MIResponseToReopen' AND ComboBoxText = 'No'";
                int MIResponseToReopen = int.Parse(dv2[0]["id"].ToString());

                result = cm.PFU_CDRT_UpSert(ReferralID, CDRTStatus, MIResponseToReopen, CDRTNotificationDate, MIReopenResponseDate, CDRTResolutionDate, userUniqueID);

                if (result)
                {
                    //CDRT was set, we continue now with setting Comments
                    dv2.RowFilter = "ComboBoxTypeTag = 'CommentType' AND ComboBoxText = 'Other'";
                    int CommentTypeID = int.Parse(dv2[0]["id"].ToString());

                    dv2.RowFilter = "ComboBoxTypeTag = 'CommentCategory' AND ComboBoxText = 'Comment'";
                    int CommentCategoryID = int.Parse(dv2[0]["id"].ToString());

                    string CommentText = "Per investor, MI COVERAGE RESCINDED/DENIED, close and bill.";

                    result2 = cm.PFU_ClosingComment_Insert(ReferralID, CommentText, CommentTypeID, CommentCategoryID, userUniqueID);

                    if (result2)
                    {
                        //The closing comment was inserted, time to close the claim
                        dv2.RowFilter = "ComboBoxTypeTag = 'ClaimStatus' AND ComboBoxText = 'Bill - Closed'";
                        int ClaimStatusID = int.Parse(dv2[0]["id"].ToString());

                        result3 = cm.PFU_CloseReferral(ReferralID, ClaimStatusID, userUniqueID, processDate);

                        result = result3;

                    }

                    else result = result2;

                }

                return result;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {


            }

        }

        /// <summary>
        /// Data import update process for FNMA PFU SOX Claim Filed referrals. The SOX Claim Filed flag is set
        /// for the REO ID for REO files and the FNMA Loan Number for Non-REO files.
        /// </summary>
        /// <param name="dt">Data imported from spreadsheet</param>
        /// <param name="ReferralTypeID">REO/Non-REO indicator</param>
        /// <param name="databaseName">Database to import data to</param>
        /// <param name="processDate">Date of import to use for processing</param>
        /// <param name="settings">Application mode setting (Production, Test, Dev, etc.) for connection string settings</param>
        /// <param name="processID">Import process id</param>
        /// <param name="events"></param>
        /// <param name="userUniqueID">User performing the import</param>
        /// <param name="cm"></param>
        /// <returns>Import results for each record imported.</returns>
        //[VIP-410] CRZ 20111028
        internal DataTable ImportFNMA_PFU_SOX_ClaimFiled(DataTable dt, int ReferralTypeID, string databaseName, string processDate, CRFS.Data.Settings settings, int processID, Moss.Events.Events events, int userUniqueID, ClaimsManagement cm)
        {
            double nextTarget = .01;
            SqlConnection sqlConn = new SqlConnection();
            SqlCommand sqlCmd = new SqlCommand();
            SqlParameter param = new SqlParameter();

            try
            {
                DataColumn dc = new DataColumn();

                if (!dt.Columns.Contains("Processed"))
                {
                    dc = new DataColumn();
                    dc.ColumnName = "Processed";
                    dc.DataType = typeof(bool);
                    dc.DefaultValue = true;
                    dt.Columns.Add(dc);
                }

                if (!dt.Columns.Contains("ProcessComments"))
                {
                    dc = new DataColumn();
                    dc.ColumnName = "ProcessComments";
                    dc.DataType = typeof(string);
                    dc.DefaultValue = "Import Successful";
                    dt.Columns.Add(dc);
                }

                //Rename the loan # column, it varies between the REO and Non-REO files
                //  Also check to see if the REO ID column exists
                bool REO_ID_exists = false;
                foreach (DataColumn column in dt.Columns)
                {
                    switch (column.ColumnName.ToUpper())
                    {
                        case "LOAN NUMBER":
                            column.ColumnName = "FNMA LOAN NUMBER";
                            break;

                        case "LOAN_NUMBER":
                            column.ColumnName = "FNMA LOAN NUMBER";
                            break;

                        case "LOAN NO:":
                            column.ColumnName = "FNMA LOAN NUMBER";
                            break;

                        case "LOAN_NO:":
                            column.ColumnName = "FNMA LOAN NUMBER";
                            break;

                        case "FNMA LOAN#":
                            column.ColumnName = "FNMA LOAN NUMBER";
                            break;

                        case "REO ID#":
                            column.ColumnName = "REO ID";
                            break;

                        case "REO_ID#":
                            column.ColumnName = "REO ID";
                            break;

                        case "REO_ID":
                            column.ColumnName = "REO ID";
                            break;

                        default:
                            break;
                    }
                    if (column.ColumnName == "REO ID")
                    {
                        REO_ID_exists = true;
                    }
                }
                
                int rowCount = dt.Rows.Count;

                string sConn = _settings.GetConnectionString(databaseName);

                sqlConn.ConnectionString = sConn;
                SqlTransaction sqlTran;

                DataView dv = new DataView(dt);

                sqlConn.Open();
                if (sqlConn.State == ConnectionState.Open)
                {
                    for (int i = 0; i < rowCount; i++)
                    {
                        //Check for in-file duplication
                        dv.RowFilter = "[FNMA LOAN NUMBER] = '" + dt.Rows[i]["FNMA LOAN NUMBER"].ToString() + "'";

                        switch (dv.Count)
                        {
                            case 1:
                                sqlTran = sqlConn.BeginTransaction();
                                try
                                {
                                    //Create a record for the loan
                                    sqlCmd = new SqlCommand();
                                    sqlCmd.CommandTimeout = Configuration.CommandTimeouts_Extra_ClaimsManagementSQLDatabase;
                                    sqlCmd.CommandType = CommandType.StoredProcedure;
                                    sqlCmd.CommandText = "usp_PFU_SOX_ClaimFiled_Import";
                                    sqlCmd.Transaction = sqlTran;

                                    //The null after the REO_ID terniary operator is because for Non-REO type referrals this field needs to be null.  
                                    //A zero length string causes problems between edits to referrals and  subsequent Non-REO imports.
                                    if (REO_ID_exists)
                                    {
                                        param = new SqlParameter("@REO_ID", dt.Rows[i]["REO ID"].ToString().Trim().Length == 0 ? null : dt.Rows[i]["REO ID"].ToString());
                                        sqlCmd.Parameters.Add(param);
                                    }
                                    param = new SqlParameter("@FNMALoanNumber", dt.Rows[i]["FNMA LOAN NUMBER"].ToString());
                                    sqlCmd.Parameters.Add(param);
                                    param = new SqlParameter("@ReferralTypeID", ReferralTypeID);
                                    sqlCmd.Parameters.Add(param);
                                    param = new SqlParameter("@SOX_ClaimFiled", true);
                                    sqlCmd.Parameters.Add(param);
                                    param = new SqlParameter("@LastUpdateUserID", userUniqueID);
                                    sqlCmd.Parameters.Add(param);

                                    sqlCmd.Connection = sqlConn;
                                    int referralID;

                                    referralID = (int)sqlCmd.ExecuteScalar();

                                    if (referralID < 0)
                                    {
                                        dt.Rows[i]["Processed"] = false;

                                        switch (referralID)
                                        {
                                            case -1000:
                                                //This error should never occur. Indicates error in data record since this value is CMS code generated.
                                                dt.Rows[i]["ProcessComments"] = "ERROR: Referral Type ID was not found. This record was not updated.";
                                                break;
                                            case -1001:
                                                //REO ID not found
                                                dt.Rows[i]["ProcessComments"] = "ERROR: REO ID was not found. This record was not updated.";
                                                break;
                                            case -1002:
                                                //Non-REO: FNMA Loan Number not found
                                                dt.Rows[i]["ProcessComments"] = "ERROR: FNMA Loan Number was not found. This record was not updated.";
                                                break;
                                            case -2000:
                                                //Claim is not open for processing.
                                                dt.Rows[i]["ProcessComments"] = "ERROR: Claim is not open. This record was not updated.";
                                                break;
                                            case -2001:
                                                //Claim is already in Claim Filed state.
                                                dt.Rows[i]["ProcessComments"] = "ERROR: Claim is already Claim Filed. This record was not updated.";
                                                break;
                                            default:
                                                dt.Rows[i]["ProcessComments"] = "ERROR: Return Value " + referralID.ToString() + " is not configured in Data Layer.  This record was not updated.";
                                                break;
                                        }

                                        sqlTran.Rollback();
                                        goto NextRecord;

                                    }
                                    else
                                    {
                                        //unique referral id was returned
                                        dt.Rows[i]["Processed"] = true;
                                        dt.Rows[i]["ProcessComments"] = "Record updated for Referral ID: " + referralID.ToString();

                                        sqlTran.Commit();
                                        goto NextRecord;
                                    }
                                    break;
                                }

                                catch (Exception e)
                                {
                                    dt.Rows[i]["Processed"] = false;
                                    dt.Rows[i]["ProcessComments"] = "An error occurred while trying to update this record.  This record was not saved";
                                    sqlTran.Rollback();
                                    goto NextRecord;
                                }

                            default:
                                dt.Rows[i]["Processed"] = false;
                                dt.Rows[i]["ProcessComments"] = "There are " + dv.Count.ToString() + " records for FNMA LOAN NUMBER " + dt.Rows[i]["FNMA LOAN NUMBER"].ToString() + " in this file.";
                                break;
                        }

                    NextRecord: ;
                        if ((((double)i + 1) / (double)rowCount) >= nextTarget)
                        {
                            nextTarget += .01;
                            events.OnRaiseImportStatusUpdateEvent();
                        }
                    }
                }

                return dt;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                if (sqlConn.State != ConnectionState.Closed)
                {
                    sqlConn.Close();
                    sqlConn.Dispose();
                }
            }
        }

        /// <summary>
        /// Data import update process for FNMA PFU SOX Delayed Proceeds referrals. The SOX Delayed Proceeds flag is set
        /// for the REO ID for REO files and the FNMA Loan Number for Non-REO files.
        /// </summary>
        /// <param name="dt">Data imported from spreadsheet</param>
        /// <param name="ReferralTypeID">REO/Non-REO indicator</param>
        /// <param name="databaseName">Database to import data to</param>
        /// <param name="processDate">Date of import to use for processing</param>
        /// <param name="settings">Application mode setting (Production, Test, Dev, etc.) for connection string settings</param>
        /// <param name="processID">Import process id</param>
        /// <param name="events"></param>
        /// <param name="userUniqueID">User performing the import</param>
        /// <param name="cm"></param>
        /// <returns>Import results for each record imported.</returns>
        //[VIP-410] CRZ 20111028
        internal DataTable ImportFNMA_PFU_SOX_DelayedProceeds(DataTable dt, int ReferralTypeID, string databaseName, string processDate, CRFS.Data.Settings settings, int processID, Moss.Events.Events events, int userUniqueID, ClaimsManagement cm)
        {
            double nextTarget = .01;
            SqlConnection sqlConn = new SqlConnection();
            SqlCommand sqlCmd = new SqlCommand();
            SqlParameter param = new SqlParameter();

            try
            {
                DataColumn dc = new DataColumn();

                if (!dt.Columns.Contains("Processed"))
                {
                    dc = new DataColumn();
                    dc.ColumnName = "Processed";
                    dc.DataType = typeof(bool);
                    dc.DefaultValue = true;
                    dt.Columns.Add(dc);
                }

                if (!dt.Columns.Contains("ProcessComments"))
                {
                    dc = new DataColumn();
                    dc.ColumnName = "ProcessComments";
                    dc.DataType = typeof(string);
                    dc.DefaultValue = "Import Successful";
                    dt.Columns.Add(dc);
                }

                //Rename the loan # column, it varies between the REO and Non-REO files
                //  Also check to see if the REO ID column exists
                bool REO_ID_exists = false;
                foreach (DataColumn column in dt.Columns)
                {
                    switch (column.ColumnName.ToUpper())
                    {
                        case "LOAN NUMBER":
                            column.ColumnName = "FNMA LOAN NUMBER";
                            break;

                        case "LOAN_NUMBER":
                            column.ColumnName = "FNMA LOAN NUMBER";
                            break;

                        case "LOAN NO:":
                            column.ColumnName = "FNMA LOAN NUMBER";
                            break;

                        case "LOAN_NO:":
                            column.ColumnName = "FNMA LOAN NUMBER";
                            break;

                        case "FNMA LOAN#":
                            column.ColumnName = "FNMA LOAN NUMBER";
                            break;

                        case "REO ID#":
                            column.ColumnName = "REO ID";
                            break;

                        case "REO_ID#":
                            column.ColumnName = "REO ID";
                            break;

                        case "REO_ID":
                            column.ColumnName = "REO ID";
                            break;

                        default:
                            break;
                    }
                    if (column.ColumnName == "REO ID")
                    {
                        REO_ID_exists = true;
                    }
                }

                if (REO_ID_exists)
                {
                    //Get rid of this comment column. It contains embedded e-mail text with hard line breaks which
                    //     messes up the import log file formatting. Only exists in REO version of import file.
                    dt.Columns.Remove("MI Comment Text");
                }

                int rowCount = dt.Rows.Count;

                string sConn = _settings.GetConnectionString(databaseName);

                sqlConn.ConnectionString = sConn;
                SqlTransaction sqlTran;

                DataView dv = new DataView(dt);

                sqlConn.Open();
                if (sqlConn.State == ConnectionState.Open)
                {
                    for (int i = 0; i < rowCount; i++)
                    {
                        //Check for in-file duplication
                        dv.RowFilter = "[FNMA LOAN NUMBER] = '" + dt.Rows[i]["FNMA LOAN NUMBER"].ToString() + "'";

                        switch (dv.Count)
                        {
                            case 1:
                                sqlTran = sqlConn.BeginTransaction();
                                try
                                {
                                    //Create a record for the loan
                                    sqlCmd = new SqlCommand();
                                    sqlCmd.CommandTimeout = Configuration.CommandTimeouts_Extra_ClaimsManagementSQLDatabase;
                                    sqlCmd.CommandType = CommandType.StoredProcedure;
                                    sqlCmd.CommandText = "usp_PFU_SOX_DelayedProceeds_Import";
                                    sqlCmd.Transaction = sqlTran;

                                    //The null after the REO_ID terniary operator is because for Non-REO type referrals this field needs to be null.  
                                    //A zero length string causes problems between edits to referrals and  subsequent Non-REO imports.
                                    if (REO_ID_exists)
                                    {
                                        param = new SqlParameter("@REO_ID", dt.Rows[i]["REO ID"].ToString().Trim().Length == 0 ? null : dt.Rows[i]["REO ID"].ToString());
                                        sqlCmd.Parameters.Add(param);
                                    }
                                    param = new SqlParameter("@FNMALoanNumber", dt.Rows[i]["FNMA LOAN NUMBER"].ToString());
                                    sqlCmd.Parameters.Add(param);
                                    param = new SqlParameter("@ReferralTypeID", ReferralTypeID);
                                    sqlCmd.Parameters.Add(param);
                                    param = new SqlParameter("@SOX_DelayedProceeds", true);
                                    sqlCmd.Parameters.Add(param);
                                    param = new SqlParameter("@LastUpdateUserID", userUniqueID);
                                    sqlCmd.Parameters.Add(param);

                                    sqlCmd.Connection = sqlConn;
                                    int referralID;

                                    referralID = (int)sqlCmd.ExecuteScalar();

                                    if (referralID < 0)
                                    {
                                        dt.Rows[i]["Processed"] = false;

                                        switch (referralID)
                                        {
                                            case -1000:
                                                //This error should never occur. Indicates error in data record since this value is CMS code generated.
                                                dt.Rows[i]["ProcessComments"] = "ERROR: Referral Type ID was not found. This record was not updated.";
                                                break;
                                            case -1001:
                                                //REO ID not found
                                                dt.Rows[i]["ProcessComments"] = "ERROR: REO ID was not found. This record was not updated.";
                                                break;
                                            case -1002:
                                                //Non-REO: FNMA Loan Number not found
                                                dt.Rows[i]["ProcessComments"] = "ERROR: FNMA Loan Number was not found. This record was not updated.";
                                                break;
                                            case -2000:
                                                //Claim is not open for processing.
                                                dt.Rows[i]["ProcessComments"] = "ERROR: Claim is not open. This record was not updated.";
                                                break;
                                            default:
                                                dt.Rows[i]["ProcessComments"] = "ERROR: Return Value " + referralID.ToString() + " is not configured in Data Layer.  This record was not updated.";
                                                break;
                                        }

                                        sqlTran.Rollback();
                                        goto NextRecord;

                                    }
                                    else
                                    {
                                        //unique referral id was returned
                                        dt.Rows[i]["Processed"] = true;
                                        dt.Rows[i]["ProcessComments"] = "Record updated for Referral ID: " + referralID.ToString();

                                        sqlTran.Commit();
                                        goto NextRecord;
                                    }
                                    break;
                                }

                                catch (Exception e)
                                {
                                    dt.Rows[i]["Processed"] = false;
                                    dt.Rows[i]["ProcessComments"] = "An error occurred while trying to update this record.  This record was not saved";
                                    sqlTran.Rollback();
                                    goto NextRecord;
                                }

                            default:
                                dt.Rows[i]["Processed"] = false;
                                dt.Rows[i]["ProcessComments"] = "There are " + dv.Count.ToString() + " records for FNMA LOAN NUMBER " + dt.Rows[i]["FNMA LOAN NUMBER"].ToString() + " in this file.";
                                break;
                        }

                    NextRecord: ;
                        if ((((double)i + 1) / (double)rowCount) >= nextTarget)
                        {
                            nextTarget += .01;
                            events.OnRaiseImportStatusUpdateEvent();
                        }
                    }
                }

                return dt;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                if (sqlConn.State != ConnectionState.Closed)
                {
                    sqlConn.Close();
                    sqlConn.Dispose();
                }
            }
        }

        #endregion

        

 

        #region "Screen Scraping Automation"

        /// <summary>
        /// 
        /// </summary>
        /// <param name="MachineName"></param>
        /// <returns></returns>
        internal int AssignMachineToBatch(string MachineName)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("DataAutomation");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                SqlParameter prm = new SqlParameter();

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase;
                cmd.CommandText = "usp_DA_AssignBatchToMachine";
                cmd.Connection = con;

                //Revise parms according to new storage?
                prm = new SqlParameter("@MachineName", MachineName);
                cmd.Parameters.Add(prm);

                int result = cmd.ExecuteNonQuery();

                return result;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="MachineName"></param>
        /// <returns></returns>
        internal int AssignMachineToSpecialBatch(string MachineName)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("DataAutomation");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                SqlParameter prm = new SqlParameter();

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase;
                cmd.CommandText = "usp_DA_AssignSpecialBatchToMachine";
                cmd.Connection = con;

                //Revise parms according to new storage?
                prm = new SqlParameter("@MachineName", MachineName);
                cmd.Parameters.Add(prm);

                int result = cmd.ExecuteNonQuery();

                return result;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="AssignmentID"></param>
        /// <returns></returns>
        internal int CompleteMachineAssignment(int AssignmentID)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("DataAutomation");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                SqlParameter prm = new SqlParameter();

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase;
                cmd.CommandText = "usp_DA_CompleteMachineAssignment";
                cmd.Connection = con;

                //Revise parms according to new storage?
                prm = new SqlParameter("@AssignmentID", AssignmentID);
                cmd.Parameters.Add(prm);

                int result = cmd.ExecuteNonQuery();

                return result;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        internal DataTable GetAutomationClients()
        {
            SqlConnection con = new SqlConnection(); 
            
            try
            {
                DataTable dt = new DataTable("Clients");

                dt.Columns.Add("ClientName", typeof(string));
                dt.Columns.Add("ClientAbbreviation", typeof(string));
                dt.Columns.Add("ImportClientID", typeof(string));
                dt.Columns.Add("AutomationClientID", typeof(int));

                con.ConnectionString = _settings.GetConnectionString("DataAutomation");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase;
                cmd.CommandText = "usp_DA_AutomationClients_Select";

                cmd.Connection = con;
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        DataRow dr = dt.NewRow();

                        dr["ClientName"] = reader["ClientName"].ToString();
                        dr["ClientAbbreviation"] = reader["ClientAbbreviation"].ToString();
                        dr["ImportClientID"] = reader["ImportClientID"].ToString();
                        dr["AutomationClientID"] = reader["AutomationClientID"].ToString();

                        dt.Rows.Add(dr);

                    }

                }

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="DocTypeDescription"></param>
        /// <param name="ClientID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetBostonWorksFileNameComponents(string DocTypeDescription, string ClientID)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable("FileNameComponents");

                dt.Columns.Add("MVUEDocType", typeof(string));
                dt.Columns.Add("MVUEClientAbbrev", typeof(string));

                //Get the Document type first
                con.ConnectionString = _settings.GetConnectionString("DataAutomation");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase; 
                cmd.CommandText = "usp_DA_DocType_Select";

                SqlParameter prm = new SqlParameter("@DocTypeDescription", DocTypeDescription);
                cmd.Parameters.Add(prm);

                cmd.Connection = con;
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    DataRow dr = dt.NewRow();

                    while (reader.Read())
                    {
                        dr["MVUEDocType"] = reader["MVUEDocType"].ToString();

                    }

                    con.Close();
                    con.ConnectionString = _settings.GetConnectionString("DataAutomation");
                    con.Open();

                    cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase;
                    cmd.CommandText = "usp_DA_ClientAbbrev_Select";

                    prm = new SqlParameter("@ClientID", ClientID);
                    cmd.Parameters.Add(prm);

                    cmd.Connection = con;
                    reader = cmd.ExecuteReader();

                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            dr["MVUEClientAbbrev"] = reader["MVUEClientAbbrev"].ToString();

                        }

                        dt.Rows.Add(dr);

                    }

                }


                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        internal DataTable GetDocuware_Automation_Info()
        {
            SqlConnection con = new SqlConnection(); 
            
            try
            {
                DataTable dt = new DataTable("FileNameComponents");

                dt.Columns.Add("AutomationXRefDocuwareID", typeof(int));
                dt.Columns.Add("DocType", typeof(string));
                dt.Columns.Add("DWDocTypeID", typeof(int));
                dt.Columns.Add("Cabinet", typeof(string));
                dt.Columns.Add("DWCabinetID", typeof(int));
                dt.Columns.Add("Process", typeof(string));
                dt.Columns.Add("DWProcessID", typeof(int));
                dt.Columns.Add("AutomationProcessID", typeof(int));

                con.ConnectionString = _settings.GetConnectionString("DataAutomation");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase;
                cmd.CommandText = "usp_DA_Docuware_DataAutomation_Info_Select";

                cmd.Connection = con;
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        DataRow dr = dt.NewRow(); 
                        
                        dr["AutomationXRefDocuwareID"] = int.Parse(reader["AutomationXRefDocuwareID"].ToString());
                        dr["DocType"] = reader["DocType"].ToString();
                        dr["DWDocTypeID"] = int.Parse(reader["DWDocTypeID"].ToString());
                        dr["Cabinet"] = reader["Cabinet"].ToString();
                        dr["DWCabinetID"] = int.Parse(reader["DWCabinetID"].ToString());
                        dr["Process"] = reader["Process"].ToString();
                        dr["DWProcessID"] = int.Parse(reader["DWProcessID"].ToString());
                        dr["AutomationProcessID"] = int.Parse(reader["AutomationProcessID"].ToString());

                        dt.Rows.Add(dr);

                    }

                }

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="machineName"></param>
        /// <returns></returns>
        internal DataTable GetFHAPartB(string machineName)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("DataAutomation");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase; 
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_DA_FHAPartB_Select";
                SqlParameter prm = new SqlParameter("@machineName", machineName);
                cmd.Parameters.Add(prm);

                cmd.Connection = con;
                DataTable dt = new DataTable("PrepTable");
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Columns.Add("CaseNumber", typeof(string));
                    dt.Columns.Add("ClaimType", typeof(string));
                    dt.Columns.Add("Client", typeof(string));
                    dt.Columns.Add("ClientAbbreviation", typeof(string));
                    dt.Columns.Add("DateEntered", typeof(DateTime));
                    dt.Columns.Add("FHA_PartB_CaptureImages", typeof(DateTime));
                    dt.Columns.Add("FHA_PartB_ImageCount", typeof(int));
                    dt.Columns.Add("ImportBatchGUID", typeof(string));
                    dt.Columns.Add("LoanNumber", typeof(string));
                    dt.Columns.Add("ProcessComments", typeof(string));
                    dt.Columns.Add("ProcessCompleteDate", typeof(DateTime));
                    dt.Columns.Add("ProcessDate", typeof(DateTime));
                    dt.Columns.Add("ProcessID", typeof(int));
                    dt.Columns.Add("ProcessLastUpdateDate", typeof(DateTime));
                    dt.Columns.Add("ReadyToArchive", typeof(bool));
                    dt.Columns.Add("id", typeof(int));

                    while (reader.Read())
                    {
                        DataRow dr = dt.NewRow();

                        dr["CaseNumber"] = reader["CaseNumber"];
                        dr["ClaimType"] = reader["ClaimType"];
                        dr["Client"] = reader["Client"];
                        dr["ClientAbbreviation"] = reader["ClientAbbreviation"];
                        dr["DateEntered"] = reader["DateEntered"];
                        dr["FHA_PartB_CaptureImages"] = reader["FHA_PartB_CaptureImages"];
                        dr["FHA_PartB_ImageCount"] = reader["FHA_PartB_ImageCount"];
                        dr["ImportBatchGUID"] = reader["ImportBatchGUID"];
                        dr["LoanNumber"] = reader["LoanNumber"];
                        dr["ProcessComments"] = reader["ProcessComments"];
                        dr["ProcessCompleteDate"] = reader["ProcessCompleteDate"];
                        dr["ProcessDate"] = reader["ProcessDate"];
                        dr["ProcessID"] = reader["ProcessID"];
                        dr["ProcessLastUpdateDate"] = reader["ProcessLastUpdateDate"];
                        dr["ReadyToArchive"] = reader["ReadyToArchive"];
                        dr["id"] = reader["id"];

                        dt.Rows.Add(dr);

                    }

                }

                con.Close();
                con.Dispose();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="importClientID"></param>
        /// <param name="systemType"></param>
        /// <returns></returns>
        internal string[] GetLogin(string importClientID, string systemType)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                string[] loginDetails = new string[7];

                con.ConnectionString = _settings.GetConnectionString("DataAutomation");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                SqlParameter prm = new SqlParameter();

                cmd.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_DA_GetAutomationLogin";

                prm = new SqlParameter("@importClientID", importClientID);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@systemType", systemType);
                cmd.Parameters.Add(prm);

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    //This should only return 1 record
                    loginDetails[0] = dr["SystemURL"].ToString();
                    loginDetails[1] = dr["SystemID"].ToString();
                    loginDetails[2] = dr["SystemPassword"].ToString();
                    loginDetails[3] = dr["SystemOtherCode"].ToString();
                    loginDetails[4] = dr["MainFrameCommand"].ToString();
                    loginDetails[5] = dr["SystemPageCheck"].ToString();
                    loginDetails[6] = dr["AutomationClientID"].ToString();

                    break;
                }

                dr.Close();
                dr.Dispose();



                return loginDetails;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="systemName"></param>
        /// <param name="systemType"></param>
        /// <returns></returns>
        internal DataTable GetLogin_BySystemNameAndType(string systemName, string systemType)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable();

                dt.Columns.Add("AutomationSystemID", typeof(int));
                dt.Columns.Add("SystemName", typeof(string));
                dt.Columns.Add("SystemType", typeof(string));
                dt.Columns.Add("SystemURL", typeof(string));
                dt.Columns.Add("SystemID", typeof(string));
                dt.Columns.Add("SystemPassword", typeof(string));
                dt.Columns.Add("SystemOtherCode", typeof(string));
                dt.Columns.Add("MainFrameCommand", typeof(string));
                dt.Columns.Add("SystemPageCheck", typeof(string));
                dt.Columns.Add("DateEntered", typeof(DateTime));

                con.ConnectionString = _settings.GetConnectionString("DataAutomation");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                SqlParameter prm = new SqlParameter();

                cmd.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_DA_GetAutomationLogon_bySystemTypeAndSystemName";

                prm = new SqlParameter("@systemName", systemName);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@systemType", systemType);
                cmd.Parameters.Add(prm);

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    //This should only return 1 record
                    row["AutomationSystemID"] = int.Parse(dr["AutomationSystemID"].ToString());
                    row["SystemName"] = dr["SystemName"].ToString();
                    row["SystemType"] = dr["SystemType"].ToString();
                    row["SystemURL"] = dr["SystemURL"].ToString();
                    row["SystemID"] = dr["SystemID"].ToString();
                    row["SystemPassword"] = dr["SystemPassword"].ToString();
                    row["SystemOtherCode"] = dr["SystemOtherCode"].ToString();
                    row["MainFrameCommand"] = dr["MainFrameCommand"].ToString();
                    row["SystemPageCheck"] = dr["SystemPageCheck"].ToString();
                    row["DateEntered"] = DateTime.Parse(dr["DateEntered"].ToString());

                    dt.Rows.Add(row);

                    break;
                }

                dr.Close();
                dr.Dispose();

                return dt;

            }

            catch (Exception e)
            {
                throw e;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="systemType"></param>
        /// <returns></returns>
        internal DataTable GetLogins_BySystemType(string systemType)
        {
            SqlConnection con = new SqlConnection(); 
            
            try
            {
                DataTable dt = new DataTable();

                dt.Columns.Add("AutomationSystemID", typeof(int));
                dt.Columns.Add("SystemName", typeof(string));
                dt.Columns.Add("SystemType", typeof(string));
                dt.Columns.Add("SystemURL", typeof(string));
                dt.Columns.Add("SystemID", typeof(string));
                dt.Columns.Add("SystemPassword", typeof(string));
                dt.Columns.Add("SystemOtherCode", typeof(string));
                dt.Columns.Add("MainFrameCommand", typeof(string));
                dt.Columns.Add("SystemPageCheck", typeof(string));
                dt.Columns.Add("DateEntered", typeof(DateTime));
                dt.Columns.Add("DateUpdated", typeof(DateTime));
                dt.Columns.Add("ImportClientID", typeof(string));
                dt.Columns.Add("CredentialsValid", typeof(bool));

                con.ConnectionString = _settings.GetConnectionString("DataAutomation");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                SqlParameter prm = new SqlParameter();

                cmd.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_DA_AutomationLogin_SelectBySystemType";

                prm = new SqlParameter("@systemType", systemType);
                cmd.Parameters.Add(prm);

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["AutomationSystemID"] = int.Parse(dr["AutomationSystemID"].ToString());
                    row["SystemName"] = dr["SystemName"].ToString();
                    row["SystemType"] = dr["SystemType"].ToString();
                    row["SystemURL"] = dr["SystemURL"].ToString();
                    row["SystemID"] = dr["SystemID"].ToString();
                    row["SystemPassword"] = dr["SystemPassword"].ToString();
                    row["SystemOtherCode"] = dr["SystemOtherCode"].ToString();
                    row["MainFrameCommand"] = dr["MainFrameCommand"].ToString();
                    row["SystemPageCheck"] = dr["SystemPageCheck"].ToString();
                    row["DateEntered"] = DateTime.Parse(dr["DateEntered"].ToString().Length == 0 ? "1/1/1900" : dr["DateEntered"].ToString().ToString());
                    row["DateUpdated"] = DateTime.Parse(dr["DateUpdated"].ToString().Length == 0 ? "1/1/1900" : dr["DateUpdated"].ToString().ToString());
                    row["ImportClientID"] = dr["ImportClientID"].ToString();
                    row["CredentialsValid"] = bool.Parse(dr["CredentialsValid"].ToString().Length == 0 ? "false" : dr["CredentialsValid"].ToString());

                    dt.Rows.Add(row);

                }

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

                }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="MachineName"></param>
        /// <returns></returns>
        internal DataTable GetMachineProcessAssignments(string MachineName)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable("MachineProcessAssignments");

                dt.Columns.Add("MachineProcessAssignmentID", typeof(int));
                dt.Columns.Add("ImportBatchGUID", typeof(Guid));
                dt.Columns.Add("ProcessComplete", typeof(bool));
                dt.Columns.Add("ProcessCompleteDate", typeof(DateTime));
                dt.Columns.Add("ProcessNumber", typeof(int));
                dt.Columns.Add("ProcessOrder", typeof(int));
                dt.Columns.Add("ImportClientID", typeof(string));

                con.ConnectionString = _settings.GetConnectionString("DataAutomation");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                SqlParameter prm = new SqlParameter();
                
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase;
                cmd.CommandText = "usp_DA_AssignedBatch_Select";
                cmd.Connection = con;

                //Revise parms according to new storage?
                prm = new SqlParameter("@MachineName", MachineName);
                cmd.Parameters.Add(prm);

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["MachineProcessAssignmentID"] = int.Parse(dr["MachineProcessAssignmentID"].ToString().Length == 0 ? "" : dr["MachineProcessAssignmentID"].ToString());
                    row["ImportBatchGUID"] = Guid.Parse(dr["ImportBatchGUID"].ToString().Length == 0 ? "" : dr["ImportBatchGUID"].ToString());
                    row["ProcessComplete"] = bool.Parse(dr["ProcessComplete"].ToString().Length == 0 ? "false" : dr["ProcessComplete"].ToString()) ;
                    row["ProcessCompleteDate"] = DateTime.Parse(dr["ProcessCompleteDate"].ToString().Length == 0 ? "1/1/1900" : dr["ProcessCompleteDate"].ToString());
                    row["ProcessNumber"] = int.Parse(dr["ProcessNumber"].ToString().Length == 0 ? "0" : dr["ProcessNumber"].ToString());
                    row["ProcessOrder"] = int.Parse(dr["ProcessOrder"].ToString().Length == 0 ? "0" : dr["ProcessOrder"].ToString());
                    row["ImportClientID"] = dr["ImportClientID"].ToString();

                    dt.Rows.Add(row);

                }
                
                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

             }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
 
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="machineName"></param>
        /// <returns></returns>
        internal DataTable GetFHA_SFDMS_MIC(string machineName)
        {
            SqlConnection con = new SqlConnection(); 
            
            try
            {
                con.ConnectionString = _settings.GetConnectionString("DataAutomation");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_DA_FHA_SFDMS_MIC_Select";
                SqlParameter prm = new SqlParameter("@machineName", machineName);
                cmd.Parameters.Add(prm);

                cmd.Connection = con;
                DataTable dt = new DataTable("PrepTable");
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Columns.Add("CaseNumber", typeof(string));
                    dt.Columns.Add("ClaimType", typeof(string));
                    dt.Columns.Add("Client", typeof(string));
                    dt.Columns.Add("ClientAbbreviation", typeof(string));
                    dt.Columns.Add("DateEntered", typeof(DateTime));
                    dt.Columns.Add("FHA_SFDMS_CaptureImages", typeof(DateTime));
                    dt.Columns.Add("FHA_SFDMS_ImageCount", typeof(int));
                    dt.Columns.Add("FHA_MIC_CaptureImages", typeof(DateTime));
                    dt.Columns.Add("FHA_MIC_ImageCount", typeof(int));
                    dt.Columns.Add("ImportBatchGUID", typeof(string));
                    dt.Columns.Add("LoanNumber", typeof(string));
                    dt.Columns.Add("ProcessComments", typeof(string));
                    dt.Columns.Add("ProcessCompleteDate", typeof(DateTime));
                    dt.Columns.Add("ProcessDate", typeof(DateTime));
                    dt.Columns.Add("ProcessID", typeof(int));
                    dt.Columns.Add("ProcessLastUpdateDate", typeof(DateTime));
                    dt.Columns.Add("ReadyToArchive", typeof(bool));
                    dt.Columns.Add("id", typeof(int));

                    while (reader.Read())
                    {
                        DataRow dr = dt.NewRow();

                        dr["CaseNumber"] = reader["CaseNumber"];
                        dr["ClaimType"] = reader["ClaimType"];
                        dr["Client"] = reader["Client"];
                        dr["ClientAbbreviation"] = reader["ClientAbbreviation"];
                        dr["DateEntered"] = reader["DateEntered"];
                        dr["FHA_SFDMS_CaptureImages"] = reader["FHA_SFDMS_CaptureImages"];
                        dr["FHA_SFDMS_ImageCount"] = reader["FHA_SFDMS_ImageCount"];
                        dr["FHA_MIC_CaptureImages"] = reader["FHA_MIC_CaptureImages"];
                        dr["FHA_MIC_ImageCount"] = reader["FHA_MIC_ImageCount"];
                        dr["ImportBatchGUID"] = reader["ImportBatchGUID"];
                        dr["LoanNumber"] = reader["LoanNumber"];
                        dr["ProcessComments"] = reader["ProcessComments"];
                        dr["ProcessCompleteDate"] = reader["ProcessCompleteDate"];
                        dr["ProcessDate"] = reader["ProcessDate"];
                        dr["ProcessID"] = reader["ProcessID"];
                        dr["ProcessLastUpdateDate"] = reader["ProcessLastUpdateDate"];
                        dr["ReadyToArchive"] = reader["ReadyToArchive"];
                        dr["id"] = reader["id"];

                        dt.Rows.Add(dr);

                    }

                }

                con.Close();
                con.Dispose();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="ProcessCompleteDate"></param>
        /// <param name="ProcessLastUpdateDate"></param>
        /// <param name="FHA_PartB_CaptureImages"></param>
        /// <param name="FHA_PartB_ImageCount"></param>
        /// <returns></returns>
        internal int UpdateFHAPartB(int id, DateTime ProcessCompleteDate, DateTime ProcessLastUpdateDate, DateTime FHA_PartB_CaptureImages, int FHA_PartB_ImageCount, string ProcessComments)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                int recordsAffected = 0;

                con.ConnectionString = _settings.GetConnectionString("DataAutomation");

                con.Open();
                if (con.State == ConnectionState.Open)
                {

                    SqlCommand cmd = new SqlCommand();
                    SqlParameter prm = new SqlParameter();
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase;
                    cmd.CommandText = "usp_DA_FHAPartB_Update";

                    prm = new SqlParameter("@id", id);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ProcessCompleteDate", ProcessCompleteDate);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ProcessLastUpdateDate", ProcessLastUpdateDate);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@FHA_PartB_CaptureImages", FHA_PartB_CaptureImages);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@FHA_PartB_ImageCount", FHA_PartB_ImageCount);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ProcessComments", ProcessComments);
                    cmd.Parameters.Add(prm);

                    recordsAffected = cmd.ExecuteNonQuery();

                }
                return recordsAffected;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State != ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="ProcessCompleteDate"></param>
        /// <param name="ProcessLastUpdateDate"></param>
        /// <param name="FHA_SFDMS_CaptureImages"></param>
        /// <param name="FHA_SFDMS_ImageCount"></param>
        /// <param name="?"></param>
        /// <param name="FHA_MIC_CaptureImages"></param>
        /// <param name="FHA_MIC_ImageCount"></param>
        /// <param name="ProcessComments"></param>
        /// <returns></returns>
        internal int UpdateFHASFDMSMIC(int id, DateTime ProcessCompleteDate, DateTime ProcessLastUpdateDate, DateTime FHA_SFDMS_CaptureImages, int FHA_SFDMS_ImageCount, DateTime FHA_MIC_CaptureImages, int FHA_MIC_ImageCount, string ProcessComments)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                int recordsAffected = 0;

                con.ConnectionString = _settings.GetConnectionString("DataAutomation");

                con.Open();
                if (con.State == ConnectionState.Open)
                {

                    SqlCommand cmd = new SqlCommand();
                    SqlParameter prm = new SqlParameter();
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase;
                    cmd.CommandText = "usp_DA_FHA_SFDMS_MIC_Update";

                    prm = new SqlParameter("@id", id);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ProcessCompleteDate", ProcessCompleteDate);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ProcessLastUpdateDate", ProcessLastUpdateDate);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@FHA_SFDMS_CaptureImages", FHA_SFDMS_CaptureImages);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@FHA_SFDMS_ImageCount", FHA_SFDMS_ImageCount);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@FHA_MIC_CaptureImages", FHA_MIC_CaptureImages);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@FHA_MIC_ImageCount", FHA_MIC_ImageCount);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ProcessComments", ProcessComments);
                    cmd.Parameters.Add(prm);

                    recordsAffected = cmd.ExecuteNonQuery();

                }
                return recordsAffected;
            }
            
            catch (SystemException ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        internal bool UpdateLoansToPrep_ClientAbbreviation()
        {

            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("DataAutomation");

                con.Open();

                SqlCommand com = new SqlCommand();
                com.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase;
                com.CommandType = CommandType.StoredProcedure;
                com.CommandText = "usp_DA_LoansToPrep_UpdateClientAbbrev";
                com.Connection = con;

                int recordsAffected = com.ExecuteNonQuery();

                return true;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (con.State != ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        internal int UpdateLogin(ref DataTable dt)
        {
            SqlConnection con = new SqlConnection(); 
            
            try
            {
                int recordsAffected = 0;
                con.ConnectionString = _settings.GetConnectionString("DataAutomation");

                con.Open();
                
                if (con.State == ConnectionState.Open)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        SqlCommand cmd = new SqlCommand();
                        SqlParameter prm = new SqlParameter();
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandTimeout = Configuration.CommandTimeouts_GeneralDataAutomationSQLDatabase;
                        

                        switch (dt.Rows[i].RowState)
                        {
                            case DataRowState.Modified:
                                cmd.CommandText = "usp_DA_AutomationLogin_Update";

                                prm = new SqlParameter("@AutomationSystemID", dt.Rows[i]["AutomationSystemID"]);
                                cmd.Parameters.Add(prm);
                                prm = new SqlParameter("@SystemName", dt.Rows[i]["SystemName"]);
                                cmd.Parameters.Add(prm);
                                prm = new SqlParameter("@SystemType", dt.Rows[i]["SystemType"]);
                                cmd.Parameters.Add(prm);
                                prm = new SqlParameter("@SystemURL", dt.Rows[i]["SystemURL"]);
                                cmd.Parameters.Add(prm);
                                prm = new SqlParameter("@SystemID", dt.Rows[i]["SystemID"]);
                                cmd.Parameters.Add(prm);
                                prm = new SqlParameter("@SystemPassword", dt.Rows[i]["SystemPassword"]);
                                cmd.Parameters.Add(prm);
                                prm = new SqlParameter("@SystemOtherCode", dt.Rows[i]["SystemOtherCode"]);
                                cmd.Parameters.Add(prm);
                                prm = new SqlParameter("@MainFrameCommand", dt.Rows[i]["MainFrameCommand"]);
                                cmd.Parameters.Add(prm);
                                prm = new SqlParameter("@SystemPageCheck", dt.Rows[i]["SystemPageCheck"]);
                                cmd.Parameters.Add(prm);
                                prm = new SqlParameter("@DateEntered", dt.Rows[i]["DateEntered"]);
                                cmd.Parameters.Add(prm);
                                prm = new SqlParameter("@DateUpdated", dt.Rows[i]["DateUpdated"]);
                                cmd.Parameters.Add(prm);
                                prm = new SqlParameter("@CredentialsValid", dt.Rows[i]["CredentialsValid"]);
                                cmd.Parameters.Add(prm);

                                break;

                            default:
                                goto NextRecord;

                        }

                        recordsAffected += cmd.ExecuteNonQuery();

                    NextRecord: ;
                    }

                }

                dt.AcceptChanges();

                return recordsAffected;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        internal void CloseAutomationJobLogID(DataTable dt)
        {
            // 20131021 gk t-24563 
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("DataAutomation");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.Parameters.Add(new SqlParameter("@AutomationJobLogID", dt.Rows[0]["AutomationJobLogID"]));
                cmd.Parameters.Add(new SqlParameter("@machineName", dt.Rows[0]["machineName"]));
                cmd.Parameters.Add(new SqlParameter("@command", dt.Rows[0]["command"]));
                cmd.Parameters.Add(new SqlParameter("@arguments", dt.Rows[0]["arguments"]));
                cmd.Parameters.Add(new SqlParameter("@restartFileName", dt.Rows[0]["restartFileName"]));
                cmd.Parameters.Add(new SqlParameter("@StartTime", dt.Rows[0]["startTime"]));
                cmd.Parameters.Add(new SqlParameter("@EndTime", DateTime.UtcNow));
                cmd.CommandText = "usp_DA_BWorks_tbl_AutomationJobLog_Update";
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex) 
            { 
                throw ex.InnerException; 
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }
        internal long OpenAutomationJobLogID(string machineName, string command, string arguments, string restartFileName, DateTime startTime)
        {
            // 20131021 gk t-24563 
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("DataAutomation");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.Parameters.Add(new SqlParameter("@machineName", machineName));
                cmd.Parameters.Add(new SqlParameter("@command", command));
                cmd.Parameters.Add(new SqlParameter("@arguments", arguments));
                cmd.Parameters.Add(new SqlParameter("@restartFileName", restartFileName));
                cmd.Parameters.Add(new SqlParameter("@StartTime", startTime));
                cmd.CommandText = "usp_DA_BWorks_tbl_AutomationJobLog_Insert";
                cmd.Connection = con;
                var t = cmd.ExecuteScalar();
                if (t == null)
                {
                    t = "0";
                }
                return long.Parse(t.ToString());
            }
            catch (Exception ex) 
            { 
                throw ex.InnerException; 
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }
        }

        internal long OpenJobSystemLog(DataTable dt)
        {
            // 20131021 gk t-24563 
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("DataAutomation");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                // left off here getting an exception
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.Parameters.Add(new SqlParameter("@automationJobLogID", dt.Rows[0]["automationJobLogID"]));
                cmd.Parameters.Add(new SqlParameter("@automationSystemID", dt.Rows[0]["automationSystemID"]));
                cmd.Parameters.Add(new SqlParameter("@startTime", dt.Rows[0]["startTime"]));
                cmd.CommandText = "usp_DA_BWorks_tbl_JobSystemLog_Insert";
                cmd.Connection = con;
                return long.Parse((cmd.ExecuteScalar() ?? 0).ToString());
            }
            catch (Exception ex)
            {
                throw ex.InnerException;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }
        }

        internal void CloseJobSystemLog(DataTable dt)
        {
                    // 20131021 gk t-24563 
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("DataAutomation");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.Parameters.Add(new SqlParameter("@JobSystemLogID", dt.Rows[0]["JobSystemLogID"]));
                cmd.Parameters.Add(new SqlParameter("@AutomationJobLogID", dt.Rows[0]["AutomationJobLogID"]));
                cmd.Parameters.Add(new SqlParameter("@AutomationSystemID", dt.Rows[0]["AutomationSystemID"]));
                cmd.Parameters.Add(new SqlParameter("@StartTime", dt.Rows[0]["StartTime"]));
                cmd.Parameters.Add(new SqlParameter("@EndTime", DateTime.UtcNow));

                cmd.CommandText = "usp_DA_BWorks_tbl_JobSystemLog_Update";
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex) 
            { 
                throw ex.InnerException; 
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }
        }

        // 20131021 gk t-24563 TBD save these and get the id of the new SystemTargetLog when when the stored proc is there, for now just a count
        internal long OpenSystemTargetLog(DataTable dt)
        {
            // 20131021 gk t-24563 
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("DataAutomation");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                // left off here getting an exception
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.Parameters.Add(new SqlParameter("@JobSystemLogID", dt.Rows[0]["JobSystemLogID"]));
                cmd.Parameters.Add(new SqlParameter("@TargetID", dt.Rows[0]["TargetID"]));
                cmd.CommandText = "usp_DA_BWorks_tbl_SystemTargetLog_Insert";
                cmd.Connection = con;
                return long.Parse((cmd.ExecuteScalar() ?? 0).ToString());
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }
        }

        internal bool UpdateTargetActionLog(DataTable dt)
        {
            SqlConnection con = new SqlConnection();

            try
            {

                con.ConnectionString = _settings.GetConnectionString("DataAutomation");
                con.Open();


                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();

                    DataRow dr = dt.Rows[i];
                    if ((dr.RowState == DataRowState.Modified) || (dr.RowState == DataRowState.Added))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                        cmd.Connection = con;
                        cmd.Parameters.Add(new SqlParameter("@SystemTargetLogID", dr["SystemTargetLogID"]));
                        cmd.Parameters.Add(new SqlParameter("@ActionID", dr["ActionID"]));
                        cmd.Parameters.Add(new SqlParameter("@ActionStartDate", dr["ActionStartDate"]));
                        cmd.Parameters.Add(new SqlParameter("@ActionEndDate", dr["ActionEndDate"]));
                        cmd.Parameters.Add(new SqlParameter("@ResultID", dr["ResultID"]));
                        cmd.Parameters.Add(new SqlParameter("@ResultAttribute", dr["ResultAttribute"]));
                        cmd.Parameters.Add(new SqlParameter("@ResultValue", dr["ResultValue"]));
                        if (dr.RowState == DataRowState.Modified)
                        {
                            cmd.Parameters.Add(new SqlParameter("@TargetActionLogID", dr["TargetActionLogID"]));
                            cmd.CommandText = "usp_DA_BWorks_tbl_TargetActionLog_Update";
                            cmd.ExecuteNonQuery();
                        }
                        else
                        {
                            cmd.CommandText = "usp_DA_BWorks_tbl_TargetActionLog_Insert";
                            dr["TargetActionLogID"] = long.Parse(cmd.ExecuteScalar().ToString());
                        }

                    }
                }

                dt.AcceptChanges();

                //We got here because there were no exceptions raised
                return true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        // gk fb 4167 20140808
        // Save the history datatable
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        internal void SaveExistingClaim_History(DataTable dt)
        {
            SqlConnection con = new SqlConnection();

            try
            {

                con.ConnectionString = _settings.GetConnectionString("DataAutomation");
                con.Open();


                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();

                    switch (dt.Rows[i].RowState)
                    {
                        case DataRowState.Modified:

                            cmd.CommandText = "usp_DA_LPS_ExistingClaimsImport_History_Update";

                            break;

                        default:
                            goto NextRecord;
                    }

                    SqlParameter prm = new SqlParameter();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.Connection = con;

                    prm = new SqlParameter("@CMS_ClaimID", dt.Rows[i]["CMS_ClaimID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PFUDate", dt.Rows[i]["PFUDate"]);
                    cmd.Parameters.Add(prm);

                    cmd.ExecuteNonQuery();

                NextRecord: ;
                }

                dt.AcceptChanges();

                //We got here because there were no exceptions raised
                return ;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        // gk fb 4167 20140808
        // read in the history datatable
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        internal DataTable ReadExistingClaim_History()
        {
            
            SqlConnection con = new SqlConnection(); 
            try
            {
                DataTable dt = new DataTable("ExistingClaimHistory");
                dt.Columns.Add("CMS_ClaimID", typeof(int));
                dt.Columns.Add("LastUpdateType",typeof(int));
                dt.Columns.Add("LastUpdateDate", typeof(DateTime));
                dt.Columns.Add("PFUDate", typeof(DateTime));

                con.ConnectionString = _settings.GetConnectionString("DataAutomation");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_DA_LPS_Import_ExistingClaim_History_SelectAll";

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["CMS_ClaimID"] = dr["CMS_ClaimID"];
                    row["LastUpdateType"] = dr["LastUpdateType"];
                    row["LastUpdateDate"] = dr["LastUpdateDate"];
                    row["PFUDate"] = dr["PFUDate"];

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }


            finally
            {
                if (con.State != ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        
        }

        internal DataTable ReadActionLkpTbl() 
        {
            
            SqlConnection con = new SqlConnection(); 
            try
            {
                DataTable dt = new DataTable("ActionLKP");
                dt.Columns.Add("ActionID", typeof(long));
                dt.Columns.Add("ActionCode", typeof(string));
                dt.Columns.Add("ActionDescription", typeof(string));

                con.ConnectionString = _settings.GetConnectionString("DataAutomation");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_DA_BWorks_lkp_Actions_Select_All";

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ActionID"] = (long)dr["ActionID"];
                    row["ActionCode"] = dr["ActionCode"].ToString();
                    row["ActionDescription"] = dr["ActionDescription"].ToString();

                    dt.Rows.Add(row);

                }

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }


            finally
            {
                if (con.State != ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        
        }

        internal DataTable ReadResLkpTbl()
        {
            
            SqlConnection con = new SqlConnection(); 
            try
            {
                DataTable dt = new DataTable("ResultsLKP");
                dt.Columns.Add("ResultID", typeof(long));
                dt.Columns.Add("ResultCode", typeof(string));
                dt.Columns.Add("ResultDescription", typeof(string));

                con.ConnectionString = _settings.GetConnectionString("DataAutomation");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_DA_BWorks_lkp_Results_Select_All";

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ResultID"] = (long)dr["ResultID"];
                    row["ResultCode"] = dr["ResultCode"].ToString();
                    row["ResultDescription"] = dr["ResultDescription"].ToString();

                    dt.Rows.Add(row);

                }

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }


            finally
            {
                if (con.State != ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        
        }


        #endregion

        #region FNMAAdvPmt
        // gk [t-12862] 20130709 get the import batch number
        /// <summary>
        /// 
        /// </summary>
        /// <param name="clientid"></param>
        /// <param name="fname"></param>
        /// <param name="ftypeid"></param>
        /// <param name="reccount"></param>
        /// <param name="userid"></param>
        /// <returns>batch number</returns>
        internal int OpenImportBatch(int clientid, string fname, int ftypeid, int reccount, int userid)
        {
            //return spBuilder.start(_settings, "DataImports")
            //                .P("ClientID", clientid)
            //                .P("OriginalFileName", fname)
            //                .P("BatchRecordCount", reccount)
            //                .P("MarkedForDelete", false)
            //                .P("EnteredByUserID", userid)
            //                .P("LastUpdateUserID", userid)
            //                .P("FileTypeID", ftypeid)
            //                .scaler("usp_Imports_ImportBatch_Insert");
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("DataImports");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.Parameters.Add(new SqlParameter("@ClientID", clientid));
                cmd.Parameters.Add(new SqlParameter("@OriginalFileName", fname));
                cmd.Parameters.Add(new SqlParameter("@BatchRecordCount", reccount));
                cmd.Parameters.Add(new SqlParameter("@MarkedForDelete", false));
                cmd.Parameters.Add(new SqlParameter("@EnteredByUserID", userid));
                cmd.Parameters.Add(new SqlParameter("@LastUpdateUserID", userid));
                cmd.Parameters.Add(new SqlParameter("@FileTypeID", ftypeid));
                cmd.CommandText = "usp_Imports_ImportBatch_Insert";
                cmd.Connection = con;
                return int.Parse((cmd.ExecuteScalar() ?? 0).ToString());
            }
            catch (Exception ex) { throw; }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }
        }
        // gk [t-12862] 20130709 get the record number
        /// <summary>
        /// 
        /// </summary>
        /// <param name="batchid"></param>
        /// <param name="userid"></param>
        /// <returns>import record id</returns>
        internal int OpenImportRecordID(int batchid, int userid)
        {
            //return spBuilder.start(_settings, "DataImports")
            //                .P("IMport_BatchID", batchid) // look at this make sure it works
            //                .P("MarkedForDelete", false)
            //                .P("EnteredByUserID", userid)
            //                .P("LastUpdateUserID", userid)
            //                .scaler("usp_Imports_ImportRecord_Insert");
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("DataImports");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.Parameters.Add(new SqlParameter("@IMport_BatchID", batchid)); 
                cmd.Parameters.Add(new SqlParameter("@MarkedForDelete", false));
                cmd.Parameters.Add(new SqlParameter("@EnteredByUserID", userid));
                cmd.Parameters.Add(new SqlParameter("@LastUpdateUserID", userid));
                cmd.CommandText = "usp_Imports_ImportRecord_Insert";
                cmd.Connection = con;
                return int.Parse((cmd.ExecuteScalar() ?? 0).ToString());
            }
            catch (Exception ex) { throw; }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }
        }
        // gk [t-12862] 20130708 get the business entities
        /// <summary>
        /// 
        /// </summary>
        /// <returns>data table with disposition staus codes</returns>
        internal DataTable GetDispositionStatusCodes()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("DispositionStatusID", typeof(int));
            dt.Columns.Add("DispositionStatusCode", typeof(string));
            dt.Columns.Add("DispositionStatusDescription", typeof(string));
            //return spBuilder.start(_settings, "DataImports")
            //                .fillTable(dt, "usp_Imports_DispositionStatusCodes_Select");
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("DataImports");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.CommandText = "usp_Imports_DispositionStatusCodes_Select";
                cmd.Connection = con;
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        DataRow row = dt.NewRow();
                        row["DispositionStatusID"]=Convert.ToInt32(dr["DispositionStatusID"].defStr("0"));
                        row["DispositionStatusCode"]=dr["DispositionStatusCode"].ToString();
                        row["DispositionStatusDescription"]=dr["DispositionStatusDescription"].ToString();
                        dt.Rows.Add(row);

                    }
                }
                return dt;
            }
            catch (Exception ex) { throw; }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }
        }
        // gk [t-12862] 20130709 get the business entities
        /// <summary>
        /// 
        /// </summary>
        /// <param name="recid"></param>
        /// <param name="statusid"></param>
        /// <param name="attrib"></param>
        /// <param name="val"></param>
        /// <param name="userid"></param>
        /// <returns>id of the inserted record </returns>
        internal int ImportRecordDispositionInsert(int recid, int statusid, string attrib, string val, int userid)
        {
            //return spBuilder.start(_settings, "DataImports")
            //                .P("ImportRecordID", recid)
            //                .P("DispositionStatusID", statusid)
            //                .P("StatusAttribute", attrib)
            //                .P("StatusValue", val)
            //                .P("EnteredByUserID", userid)
            //                .P("LastUpdateUserID", userid)
            //                .scaler("usp_Imports_RecordDispositionHistory_Insert");
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("DataImports");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.Parameters.Add(new SqlParameter("@ImportRecordID", recid));
                cmd.Parameters.Add(new SqlParameter("@DispositionStatusID", statusid));
                cmd.Parameters.Add(new SqlParameter("@StatusAttribute", attrib));
                cmd.Parameters.Add(new SqlParameter("@StatusValue", val));
                cmd.Parameters.Add(new SqlParameter("@EnteredByUserID", userid));
                cmd.Parameters.Add(new SqlParameter("@LastUpdateUserID", userid));
                cmd.CommandText = "usp_Imports_RecordDispositionHistory_Insert";
                cmd.Connection = con;
                return int.Parse((cmd.ExecuteScalar() ?? 0).ToString());
            }
            catch (Exception ex) { throw; }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }
        }
        // gk [t-12862] 20130710 get the business entities
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dr"></param>
        /// <returns>0</returns>
        internal int UpdateAdvPmtReferral(DataRow dr)
        {
            //return spBuilder.start(_settings, "FNMAApps")
            //                .dr(dr)
            //                .P("ReferralID")
            //                .P("BusinessEntityID")
            //                .P("ServicerNumber")
            //                .P("ServicerLoanNumber")
            //                .P("PropertyStateCode")
            //                .P("LoanStatusCode")
            //                .P("ReferralStatusID")
            //                .P("LastUpdateUserID", dr["EnteredByUserID"])
            //                .scaler("usp_FNMA_AdvPmt_Referral_Update");
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("FNMAApps");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.Parameters.Add(new SqlParameter("@ReferralID",dr["ReferralID"]));
                cmd.Parameters.Add(new SqlParameter("@BusinessEntityID",dr["BusinessEntityID"]));
                cmd.Parameters.Add(new SqlParameter("@ServicerNumber",dr["ServicerNumber"]));
                cmd.Parameters.Add(new SqlParameter("@ServicerLoanNumber",dr["ServicerLoanNumber"]));
                cmd.Parameters.Add(new SqlParameter("@PropertyStateCode",dr["PropertyStateCode"]));
                cmd.Parameters.Add(new SqlParameter("@LoanStatusCode",dr["LoanStatusCode"]));
                cmd.Parameters.Add(new SqlParameter("@ReferralStatusID",dr["ReferralStatusID"]));
                cmd.Parameters.Add(new SqlParameter("@LastUpdateUserID", dr["EnteredByUserID"]));
                cmd.CommandText = "usp_FNMA_AdvPmt_Referral_Update";
                cmd.Connection = con;
                return int.Parse((cmd.ExecuteScalar() ?? 0).ToString());
            }
            catch (Exception ex) { throw; }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }
        }

        // gk [t-12862] 20130710 get the business entities
        /// <summary>
        /// 
        /// </summary>
        /// <returns>0</returns>
        internal DataTable GetFileTypes()
        {
            DataTable dt=new DataTable("FileTypes");
            dt.Columns.Add("FileTypeID",typeof(int));
            dt.Columns.Add("FileTypeDescription",typeof(string));
            dt.Columns.Add("FileTypeExtension",typeof(string));
            //return spBuilder.start(_settings,"DataImports")
            //                .fillTable(dt, "usp_Imports_FileTypes_Select");
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("DataImports");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.CommandText = "usp_Imports_FileTypes_Select";
                cmd.Connection = con;
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        DataRow row = dt.NewRow();
                        row["FileTypeID"] = Convert.ToInt32(dr["FileTypeID"].defStr("0"));
                        row["FileTypeDescription"] = dr["FileTypeDescription"].ToString();
                        row["FileTypeExtension"] = dr["FileTypeExtension"].ToString();
                        dt.Rows.Add(row);

                    }
                }
                return dt;
            }
            catch (Exception ex) { throw; }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }
        }
        // gk [t-12862] 20130710 get the business entities
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dr"></param>
        /// <returns>id of inserted record</returns>
        internal int InsertFNMAAdvPmt_ImportData(DataRow dr)
        {
            //return spBuilder.start(_settings, "DataImports")
            //                .dr(dr)
            //                .P("ImportRecordID")
            //                .P("FNMALoanNumber")
            //                .P("BusinessEntityName")
            //                .P("ServicerNumber")
            //                .P("ServicerLoanNumber")
            //                .P("PropertyStateCode")
            //                .P("LoanStatusCode")
            //                .P("PreparerName")
            //                .P("TransactionAmount")
            //                .scaler("usp_Imports_FNMAAdvPmt_ImportData_Insert");
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("DataImports");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.Parameters.Add(new SqlParameter("@ImportRecordID",dr["ImportRecordID"]));
                cmd.Parameters.Add(new SqlParameter("@FNMALoanNumber",dr["FNMALoanNumber"]));
                cmd.Parameters.Add(new SqlParameter("@BusinessEntityName",dr["BusinessEntityName"]));
                cmd.Parameters.Add(new SqlParameter("@ServicerNumber",dr["ServicerNumber"]));
                cmd.Parameters.Add(new SqlParameter("@ServicerLoanNumber",dr["ServicerLoanNumber"]));
                cmd.Parameters.Add(new SqlParameter("@PropertyStateCode",dr["PropertyStateCode"]));
                cmd.Parameters.Add(new SqlParameter("@LoanStatusCode",dr["LoanStatusCode"]));
                cmd.Parameters.Add(new SqlParameter("@PreparerName",dr["PreparerName"]));
                cmd.Parameters.Add(new SqlParameter("@TransactionAmount",dr["TransactionAmount"]));
                cmd.CommandText = "usp_Imports_FNMAAdvPmt_ImportData_Insert";
                cmd.Connection = con;
                return int.Parse((cmd.ExecuteScalar() ?? 0).ToString());
            }
            catch (Exception ex) { throw; }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }
        }
        // gk [t-12862] 20130708 get the business entities
        /// <summary>
        /// 
        /// </summary>
        /// <returns>data table with businessentities</returns>
        internal DataTable GetBusinessEntities()
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("ApplicationConfiguration");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.CommandText = "usp_CNTL_BusinessEntity_Select";
                cmd.Connection = con;

                DataTable dt = new DataTable("BusinessEntities");
                dt.Columns.Add("BusinessEntityID", typeof(int));
                dt.Columns.Add("BusinessEntityName", typeof(string));
                dt.Columns.Add("ApplicationID", typeof(int));
                dt.Columns.Add("CMSFormID", typeof(int));
                dt.Columns.Add("EntityTypeID", typeof(int));
                dt.Columns.Add("EntityTypeName", typeof(string));
                dt.Columns.Add("EffectiveFromDate", typeof(DateTime));
                dt.Columns.Add("EffectiveToDate", typeof(DateTime));
                dt.Columns.Add("EnteredDate", typeof(DateTime));
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        DataRow row = dt.NewRow();
                        row["BusinessEntityID"] = Convert.ToInt32(dr["BusinessEntityID"].defStr("0"));
                        row["BusinessEntityName"] = Convert.ToString(dr["BusinessEntityName"].defStr(""));
                        row["ApplicationID"] = Convert.ToInt32(dr["ApplicationID"].defStr("0"));
                        row["CMSFormID"] = Convert.ToInt32(dr["CMSFormID"].defStr("0"));
                        row["EntityTypeID"] = Convert.ToInt32(dr["EntityTypeID"].defStr("0"));
                        row["EntityTypeName"] = Convert.ToString(dr["EntityTypeName"].defStr(""));
                        row["EffectiveFromDate"] = Convert.ToDateTime(dr["EffectiveFromDate"].defStr("1/1/1900"));
                        row["EffectiveToDate"] = Convert.ToDateTime(dr["EffectiveToDate"].defStr("1/1/1900"));
                        row["EnteredDate"] = Convert.ToDateTime(dr["EnteredDate"].defStr("1/1/1900"));

                        dt.Rows.Add(row);

                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FNMALoanNumber"></param>
        /// <param name="ServicerLoanNumber"></param>
        /// <returns></returns>
        internal bool CheckIfAlreadyImported(string FNMALoanNumber, string ServicerLoanNumber)
        {
            bool bReturnValue = false;

            using (SqlConnection con = new SqlConnection())
            {
                try
                {
                    con.ConnectionString = _settings.GetConnectionString("FNMAApps");

                    con.Open();

                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                    cmd.CommandText = "usp_FNMA_AdvPmt_Referral_GetNonClosedByFNMAServicerLoanNumberCount";
                    cmd.Connection = con;
                    cmd.Parameters.Add(new SqlParameter("@FNMALoanNumber", FNMALoanNumber));
                    cmd.Parameters.Add(new SqlParameter("@ServicerLoanNumber", ServicerLoanNumber));
                    cmd.Parameters.Add(new SqlParameter("@RecordExists",DBNull.Value));
                    cmd.Parameters["@RecordExists"].Direction = ParameterDirection.InputOutput;
                    cmd.Parameters["@RecordExists"].DbType = DbType.Boolean;
                    cmd.ExecuteNonQuery();

                    bReturnValue = Convert.ToBoolean(cmd.Parameters["@RecordExists"].Value.ToString());
                }
                finally
                {
                    if (con.State != System.Data.ConnectionState.Closed)
                        con.Close();
                }
            }

            return bReturnValue;
        }

        /// <summary>
        /// Returns the referral status id value for a given referral status description
        /// </summary>
        /// <param name="StatusDescription"></param>
        /// <returns></returns>
        internal int GetReferralStatusIdByDescription(string StatusDescription)
        {
            int iReferralStatusId = -1;

            using (SqlConnection con = new SqlConnection())
            {
                try
                {
                    con.ConnectionString = _settings.GetConnectionString("FNMAApps");

                    con.Open();

                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                    cmd.CommandText = "usp_FNMA_AdvPmt_ReferralStatus_GetByDescription";
                    cmd.Connection = con;
                    cmd.Parameters.Add(new SqlParameter("@ReferralStatusDescription", StatusDescription));

                    using (System.Data.SqlClient.SqlDataReader drReferralStatus = cmd.ExecuteReader())
                    {
                        if (drReferralStatus.HasRows)
                        {
                            drReferralStatus.Read();
                            iReferralStatusId = Convert.ToInt32(drReferralStatus["ReferralStatusID"].ToString());
                        }
                    }
                }
                finally
                {
                    if (con.State != ConnectionState.Closed)
                        con.Close();
                }
            }

            return iReferralStatusId;
        }

        // gk [t-12862] 20130708 get the business entities
        /// <summary>
        /// 
        /// </summary>
        /// <param name="GetBusinessEntities"></param>
        /// <returns>data table with businessentities</returns>

        internal DataTable GetReferralbyFNMA_Servicer_LN(string lnum, string slnum)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("FNMAApps");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.CommandText = "usp_FNMA_AdvPmt_Referral_GetByFNMAServicerLoanNumber";
                cmd.Connection = con;
                cmd.Parameters.Add(new SqlParameter("@FNMALoanNumber", lnum));
                cmd.Parameters.Add(new SqlParameter("@ServicerLoanNumber", slnum));
                SqlDataReader dr = cmd.ExecuteReader();

                DataTable dt = new DataTable("ReferralRecord");
                dt.Columns.Add("ReferralID", typeof(int));
                dt.Columns.Add("ApplicationID", typeof(int));
                dt.Columns.Add("FNMALoanNumber", typeof(string));
                dt.Columns.Add("BusinessEntityID", typeof(int));
                dt.Columns.Add("ServicerNumber", typeof(string));
                dt.Columns.Add("ServicerLoanNumber", typeof(string));
                dt.Columns.Add("PropertyStateCode", typeof(string));
                dt.Columns.Add("LoanStatusCode", typeof(string));
                dt.Columns.Add("ReferralDate", typeof(DateTime));
                dt.Columns.Add("ReferralStatusID", typeof(int));
                dt.Columns.Add("EnteredDate", typeof(DateTime));
                dt.Columns.Add("EnteredByUserID", typeof(int));
                dt.Columns.Add("LastUpdateDate", typeof(DateTime));
                dt.Columns.Add("LastUpdateUserID", typeof(int));
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        DataRow row = dt.NewRow();
                        row["ReferralID"] = Convert.ToInt32(dr["ReferralID"].defStr("0"));
                        row["ApplicationID"] = Convert.ToInt32(dr["ApplicationID"].defStr("0"));
                        row["FNMALoanNumber"] = Convert.ToString(dr["FNMALoanNumber"].defStr(""));
                        row["BusinessEntityID"] = Convert.ToInt32(dr["BusinessEntityID"].defStr("0"));
                        row["ServicerNumber"] = Convert.ToString(dr["ServicerNumber"].defStr(""));
                        row["ServicerLoanNumber"] = Convert.ToString(dr["ServicerLoanNumber"].defStr(""));
                        row["PropertyStateCode"] = Convert.ToString(dr["PropertyStateCode"].defStr(""));
                        row["LoanStatusCode"] = Convert.ToString(dr["LoanStatusCode"].defStr(""));
                        row["ReferralDate"] = Convert.ToDateTime(dr["ReferralDate"].defStr("1/1/1900"));
                        row["ReferralStatusID"] = Convert.ToInt32(dr["ReferralStatusID"].defStr("0"));
                        row["EnteredDate"] = Convert.ToDateTime(dr["EnteredDate"].defStr("1/1/1900"));
                        row["EnteredByUserID"] = Convert.ToInt32(dr["EnteredByUserID"].defStr("0"));
                        row["LastUpdateDate"] = Convert.ToDateTime(dr["LastUpdateDate"].defStr("1/1/1900"));
                        row["LastUpdateUserID"] = Convert.ToInt32(dr["LastUpdateUserID"].defStr("0"));
                        dt.Rows.Add(row);
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }
        }

        /// <summary>
        /// get all the disbursements associated with referralid
        /// </summary>
        /// <param name="lnum"></param>
        /// <returns></returns>
        public DataTable GetDisbursementByReferral(long referralID)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("FNMAApps");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.CommandText = "usp_FNMA_AdvPmt_Disbursement_GetByReferralID";
                cmd.Connection = con;
                cmd.Parameters.Add(new SqlParameter("@ReferralID", referralID));
                SqlDataReader dr = cmd.ExecuteReader();

                DataTable dt = new DataTable("ReferralRecord");
                dt.Columns.Add("DisbursementID", typeof(long));
                dt.Columns.Add("TransactionAmount", typeof(decimal));
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        DataRow row = dt.NewRow();
                        row["DisbursementID"]=Convert.ToInt64(dr["DisbursementID"].defStr("0"));
                        row["TransactionAmount"]=Convert.ToDecimal(dr["TransactionAmount"].defStr("0"));
                        dt.Rows.Add(row);
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }
        }


        // gk [t-12862] 20130709 get the business entities
        /// <summary>
        /// 
        /// </summary>
        /// <param name="lnum"></param>
        /// <returns>data table with ReferralStatus ids</returns>

        internal DataTable getFNMAAdvPmtReferralStatus()
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("FNMAApps");

                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.CommandText = "usp_FNMA_AdvPmt_ReferralStatus_Select";
                cmd.Connection = con;
                DataTable dt = new DataTable("ReferralStatus");
                dt.Columns.Add("ReferralStatusID", typeof(int));
                dt.Columns.Add("ReferralStatus", typeof(string));
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        DataRow row = dt.NewRow();
                        row["ReferralStatusID"] = Convert.ToInt32(dr["ReferralStatusID"].defStr("0"));
                        row["ReferralStatus"] = Convert.ToString(dr["ReferralStatus"].defStr(""));
                        dt.Rows.Add(row);
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }
        }

        // gk [t-12862] 20130709 insert referrals if there is no referral id
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dr"></param>
        /// <returns>referral number</returns>

        internal int InsertOrUpdateFNMAAdvPmtReferral(DataRow dr)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("FNMAApps");

                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.CommandText = "usp_FNMA_AdvPmt_Referral_Insert";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@intApplicationID", dr["ApplicationID"]);
                cmd.Parameters.AddWithValue("@vcrFNMALoanNumber", dr["FNMALoanNumber"]);
                cmd.Parameters.AddWithValue("@intBusinessEntityID", dr["BusinessEntityID"]);
                cmd.Parameters.AddWithValue("@vcrServicerNumber", dr["ServicerNumber"]);
                cmd.Parameters.AddWithValue("@vcrServicerLoanNumber", dr["ServicerLoanNumber"]);
                cmd.Parameters.AddWithValue("@vcrPropertyStateCode", dr["PropertyStateCode"]);
                cmd.Parameters.AddWithValue("@vcrLoanStatusCode", dr["LoanStatusCode"]);
                cmd.Parameters.AddWithValue("@sdtReferralDate", dr["ReferralDate"]);
                cmd.Parameters.AddWithValue("@intReferralStatusID", dr["ReferralStatusID"]);
                cmd.Parameters.AddWithValue("@sdtEnteredDate", dr["EnteredByUserID"]);
                cmd.Parameters.AddWithValue("@intEnteredByUserID", dr["EnteredByUserID"]);

                cmd.Parameters.AddWithValue("@sdtLastUpdateDate", new DateTime(1900,1,1));
                cmd.Parameters.AddWithValue("@intLastUpdateUserID", 0);
                cmd.Parameters.AddWithValue("@sdtInitialBillingDate", new DateTime(1900, 1, 1));
                cmd.Parameters.AddWithValue("@sdtDateInvoiced", DBNull.Value);

                cmd.Parameters["@sdtDateInvoiced"].DbType = DbType.DateTime;
                cmd.Parameters.AddWithValue("@intReferralID", dr["ReferralID"]);

                return int.Parse(cmd.ExecuteScalar().ToString());
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }
        }
        private const int DISP_CODE_OTHER = 10;

        // gk [t-12862] 20130708 get the business entities
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dr"></param>
        /// <returns>id for the disbursment</returns>

        internal int InsertFNMAAdvPmtDisbursement(DataRow dr)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("FNMAApps");

                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.CommandText = "usp_FNMA_AdvPmt_Disbursement_Insert";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@referralID", dr["ReferralID"]);
                cmd.Parameters.AddWithValue("@transactionDate", DBNull.Value);
                cmd.Parameters.AddWithValue("@disbursementTypeID", DISP_CODE_OTHER);
                cmd.Parameters.AddWithValue("@claim571Payee", DBNull.Value);
                cmd.Parameters.AddWithValue("@transactionAmount", dr["TransactionAmount"]);
                cmd.Parameters.AddWithValue("@claimable", false);
                cmd.Parameters.AddWithValue("@userID", dr["EnteredByUserID"]);
                cmd.Parameters.AddWithValue("@preparerName", dr["PreparerName"]);
                return Convert.ToInt32(cmd.ExecuteScalar().ToString());
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }
        }

        // gk [t-12862] 20130708 get the business entities
        /// <summary>
        /// 
        /// </summary>
        /// <returns>data table with entityid and names</returns>
        internal DataTable GetEntityTypes()
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("ApplicationConfiguration");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.CommandText = "usp_CNTL_EntityTpes_Select";
                cmd.Connection = con;

                DataTable dt = new DataTable("BusinessEntities");
                dt.Columns.Add("EntityTypeID", typeof(int));
                dt.Columns.Add("EntityTypeName", typeof(string));
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        DataRow row = dt.NewRow();
                        row["EntityTypeID"] = Convert.ToInt32(dr["EntityTypeID"].defStr("0"));
                        row["EntityTypeName"] = Convert.ToString(dr["EntityTypeName"].defStr(""));
                        dt.Rows.Add(row);

                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }
        }

        // gk [t-12862] 20130708 get the business entities
        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="appid"></param>
        /// <param name="entitytypeid"></param>
        /// <returns>businessentityid of the newly inserted record</returns>
        internal int InsertBusinessEntities(string name, int appid, int entitiytypeid)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("ApplicationConfiguration");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.CommandText = "usp_Imports_BusinessEntity_Insert";
                cmd.Connection = con;
                cmd.Parameters.Add(new SqlParameter("@BusinessEntityName", name));
                cmd.Parameters.Add(new SqlParameter("@ApplicationID", appid));
                cmd.Parameters.Add(new SqlParameter("@EntityTypeID", entitiytypeid));
                return int.Parse(cmd.ExecuteScalar().ToString());
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }
        }
        // gk [t-12862] 20130708 get the application ids from the table
        /// <summary>
        /// 
        /// </summary>
        /// <returns>data table with ApplicationId and ApplicationName</returns>
        internal DataTable GetApplicationIds()
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("ApplicationConfiguration");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.CommandText = "usp_CNTL_Applications_Select";
                cmd.Connection = con;

                DataTable dt = new DataTable("ApplicationsSelect");
                dt.Columns.Add("ApplicationId", typeof(int));
                dt.Columns.Add("ApplicationName", typeof(string));
                dt.Columns.Add("ApplicationURL", typeof(string));
                dt.Columns.Add("CMSFormID", typeof(int));
                dt.Columns.Add("EffectiveFromDate", typeof(DateTime));
                dt.Columns.Add("EffectiveToDate", typeof(DateTime));
                dt.Columns.Add("EnteredDate", typeof(DateTime));

                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        DataRow row = dt.NewRow();

                        row["ApplicationId"] = Convert.ToInt32(dr["ApplicationId"].defStr("0"));
                        row["ApplicationName"] = dr["ApplicationName"].ToString();
                        row["ApplicationURL"] = dr["ApplicationURL"].ToString();
                        row["CMSFormID"] = Convert.ToInt32(dr["CMSFormID"].defStr("0"));
                        row["EffectiveFromDate"] = Convert.ToDateTime(dr["EffectiveFromDate"].defStr("1/1/1900"));
                        row["EffectiveToDate"] = Convert.ToDateTime(dr["EffectiveToDate"].defStr("1/1/1900"));
                        row["EnteredDate"] = Convert.ToDateTime(dr["EnteredDate"].defStr("1/1/1900"));

                        dt.Rows.Add(row);

                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }
        }


        //public void CancelManualReferral(int ManualDelegatedReferralRequestID,int userID,int cancel,string DeltaChk)
        internal void CancelManualReferral(int ManualDelegatedReferralRequestID,int userID,int cancel,string DeltaChk)
        {
            SqlConnection sql = new SqlConnection();

            try
            {
                sql.ConnectionString = _settings.GetConnectionString("DataAutomation");
                sql.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_DA_HOAManualDelegatedReferralRequest_Cancel";
                SqlParameter parm = new SqlParameter("@ManualDelegatedReferralRequestID", ManualDelegatedReferralRequestID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@LastUpdateUserID", userID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@Canceled", cancel);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@DeltaChk", DeltaChk);
                cmd.Parameters.Add(parm);

                cmd.Connection = sql;
                int recordsAffected = cmd.ExecuteNonQuery();
            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (sql.State != ConnectionState.Closed)
                {
                    sql.Close();
                    sql.Dispose();
                }

            }

        }

        //  return da.ManualHOAInsert(fhaClaimID);
        internal void ManualHOAInsert(int fhaClaimID,int userID)
        {
            SqlConnection sql = new SqlConnection();

            try
            {
                sql.ConnectionString = _settings.GetConnectionString("DataAutomation");
                sql.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_DA_HOAManualDelegatedReferralRequestInsert";
                SqlParameter parm = new SqlParameter("@FHAClaimID", fhaClaimID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@UserID", userID);
                cmd.Parameters.Add(parm);

                cmd.Connection = sql;
                int recordsAffected = cmd.ExecuteNonQuery();
            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (sql.State != ConnectionState.Closed)
                {
                    sql.Close();
                    sql.Dispose();
                }

            }

        }
        //public DataTable GetAutomaticHOARequests(int fhaClaimID)
        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <param name="fhaClaimID"></param>
        /// <returns></returns>
        internal DataTable GetAutomaticHOARequests(int fhaClaimID)
        {
            SqlConnection sql = new SqlConnection();

            try
            {
                sql.ConnectionString = _settings.GetConnectionString("DataAutomation");
                sql.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_DA_HOADelegatedReferrals_SelectByFHAClaimID";
                SqlParameter parm = new SqlParameter("@FHAClaimID", fhaClaimID);
                cmd.Parameters.Add(parm);

                cmd.Connection = sql;
                DataTable dt = new DataTable("HOAAutomaticRequests");
                dt.Columns.Add("LastUpdateDate", typeof(DateTime));
                dt.Columns.Add("LastUpdateUser", typeof(string));
                dt.Columns.Add("OutboundSuccessful", typeof(bool));
                dt.Columns.Add("IDReportReturned", typeof(bool));
                dt.Columns.Add("IDReportDate", typeof(string));
                dt.Columns.Add("IDReportName", typeof(string));
                dt.Columns.Add("HOAReferralComplete", typeof(string));

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    DataRow dr = dt.NewRow();
                    dr["LastUpdateDate"] = reader["LastUpdateDate"];
                    dr["LastUpdateUser"] = reader["LastUpdateUser"];
                    dr["OutboundSuccessful"] = reader["OutboundSuccessful"];
                    dr["IDReportReturned"] = reader["IDReportReturned"];
                    dr["IDReportDate"] = reader["IDReportDate"];
                    dr["IDReportName"] = reader["IDReportName"];
                    dr["HOAReferralComplete"] = reader["HOAReferralComplete"];
                    dt.Rows.Add(dr);
                }
                sql.Close();
                sql.Dispose();

                return dt;
            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (sql.State != ConnectionState.Closed)
                {
                    sql.Close();
                    sql.Dispose();
                }

            }

        }

        internal DataTable GetIncompleteManualHOARequests( int fhaClaimID)
        {
            SqlConnection sql = new SqlConnection();

            try
            {
                sql.ConnectionString = _settings.GetConnectionString("DataAutomation");
                sql.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_DA_HOA_ManualDelegatedReferralRequests_SelectIncompleteByFHAClaimID";
                SqlParameter parm = new SqlParameter("@FHAClaimID", fhaClaimID);
                cmd.Parameters.Add(parm);

                cmd.Connection = sql;
                DataTable dt = new DataTable("HOAIncompleteManual");
                dt.Columns.Add("ManualDelegatedReferralRequestID", typeof(int));
                dt.Columns.Add("EnteredDate", typeof(DateTime));
                dt.Columns.Add("EnteredByUser", typeof(string));
                dt.Columns.Add("LastUpdateDate", typeof(DateTime));
                dt.Columns.Add("LastUpdateUser", typeof(string));
                dt.Columns.Add("Canceled", typeof(bool));
                dt.Columns.Add("Processed", typeof(bool));
                dt.Columns.Add("DeltaChk", typeof(string));

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    DataRow dr = dt.NewRow();
                    dr["ManualDelegatedReferralRequestID"] = reader["ManualDelegatedReferralRequestID"];
                    dr["EnteredDate"] = reader["EnteredDate"];
                    dr["EnteredByUser"] = reader["EnteredByUser"];
                    dr["LastUpdateDate"] = reader["LastUpdateDate"];
                    dr["LastUpdateUser"] = reader["LastUpdateUser"];
                    dr["Canceled"] = reader["Canceled"];
                    dr["Processed"] = reader["Processed"];
                    dr["DeltaChk"] = reader["DeltaChk"];
                    dt.Rows.Add(dr);
                }
                sql.Close();
                sql.Dispose();

                return dt;
            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (sql.State != ConnectionState.Closed)
                {
                    sql.Close();
                    sql.Dispose();
                }

            }

        }

        #endregion
    }
}
