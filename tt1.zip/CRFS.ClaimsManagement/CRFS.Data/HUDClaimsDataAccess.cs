﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace CRFS.Data
{
    class HUDClaimsDataAccess
    {
        CRFS.Data.Settings _settings;

        #region "Constructors"
        internal HUDClaimsDataAccess()
        {
        }

        internal HUDClaimsDataAccess(CRFS.Data.Settings settings)
        {
            _settings = settings;

        }

        #endregion

        #region "Investor Tracking"
        internal bool isFHAClaimTypeClaimSubTypeOnboardedForClient(int ClientID, int ClaimTypeID, int ClaimSubTypeID)
        {
            bool rtnValue = false;
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("HUDClaims");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_HUDClaimsSQLDatabase;
                cmd.CommandText = "usp_HUDClaims_InvtrkImports_IsFHAClaimTypeClaimSubtypeOnboardedForClient";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter("@ClientID", ClientID);
                cmd.Parameters.Add(parm);

                parm = new SqlParameter("@CMSClaimTypeID", ClaimTypeID);
                cmd.Parameters.Add(parm);

                parm = new SqlParameter("@CMSClaimSubTypeID", ClaimSubTypeID);
                cmd.Parameters.Add(parm);

                rtnValue = bool.Parse(cmd.ExecuteScalar().ToString());

                return rtnValue;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        internal DataTable Build_InvestorTracking_EDIAuthMatrixTable()
        {
            try
            {
                DataTable dt = new DataTable("EDIAuthMatrix");

                //Columns in Table
                dt.Columns.Add("FHAClientClaimTypeEDIControlID", typeof(long));
                dt.Columns.Add("FHAClientID", typeof(long));
                dt.Columns.Add("CMSClientID", typeof(int));
                dt.Columns.Add("ClaimTypeID", typeof(long));
                dt.Columns.Add("FHAClaimSubTypeID", typeof(long));
                dt.Columns.Add("ClaimTypeName", typeof(string));
                dt.Columns.Add("ClaimSubtypeName", typeof(string));
                dt.Columns.Add("Enable_HUD_EDI", typeof(bool));

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        internal DataTable Get_InvestorTracking_EDIAuthMatrixTable()
        {
            SqlConnection con = new SqlConnection(); 
            
            try
            {
                DataTable dt = Build_InvestorTracking_EDIAuthMatrixTable();

                con.ConnectionString = _settings.GetConnectionString("HUDClaims");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_HUDClaimsSQLDatabase;
                cmd.CommandText = "usp_HUDClaims_InvTrk_EDIAuth_Matrix_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["FHAClientClaimTypeEDIControlID"] = (long)dr["FHAClientClaimTypeEDIControlID"];
                    row["FHAClientID"] = (long)dr["FHAClientID"];
                    row["CMSClientID"] = (int)dr["CMSClientID"];
                    row["ClaimTypeID"] = (long)dr["ClaimTypeID"];
                    row["ClaimTypeName"] = dr["ClaimTypeName"];
                    row["FHAClaimSubTypeID"] = (long)dr["FHAClaimSubTypeID"];
                    row["ClaimSubtypeName"] = dr["ClaimSubtypeName"];
                    row["Enable_HUD_EDI"] = (bool)dr["Enable_HUD_EDI"];

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="ClaimID"></param>
        /// <returns></returns>
        internal DataTable Get_HUDClaims_ClaimData(DataTable dt, int ClaimID)
        {
            SqlConnection con = new SqlConnection(); 
            
            try
            {
                con.ConnectionString = _settings.GetConnectionString("HUDClaims");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_HUDClaimsSQLDatabase;
                cmd.CommandText = "usp_HUDClaims_Claim_Select_ByInvTrkClaimID";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter("@ClaimID", ClaimID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["FHAClaimID"] = (long)dr["FHAClaimID"];
                    row["FHALoanID"] = (long)dr["FHALoanID"];
                    row["ClaimStatusID"] = (long)dr["ClaimStatusID"];
                    row["ClaimTypeID"] = (long)dr["ClaimTypeID"];
                    row["SectionOfTheActID"] = long.Parse(dr["SectionOfTheActID"].ToString() == "" ? "-1" : dr["SectionOfTheActID"].ToString());
                    row["DefaultDate"] = DateTime.Parse(dr["DefaultDate"].ToString().Length == 0 ? "1/1/1900" : dr["DefaultDate"].ToString());
                    row["LoanDate"] = DateTime.Parse(dr["LoanDate"].ToString().Length == 0 ? "1/1/1900" : dr["LoanDate"].ToString());
                    row["DebentureInterestRate"] = decimal.Parse(dr["DebentureInterestRate"].ToString() == "" ? "0" : dr["DebentureInterestRate"].ToString());
                    row["NoteRate"] = decimal.Parse(dr["NoteRate"].ToString() == "" ? "0" : dr["NoteRate"].ToString());
                    row["InvTrk_ClaimID"] = (int)dr["InvTrk_ClaimID"];
                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                    row["EnteredByUser"] = (int)dr["EnteredByUser"];
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    row["LastUpdateUser"] = (int)dr["LastUpdateUser"];
                    row["CurtailDateForDI"] = DateTime.Parse(dr["CurtailDateForDI"].ToString().Length == 0 ? "1/1/1900" : dr["CurtailDateForDI"].ToString());
                    row["MCDEqualCurtailDateForDI"] = bool.Parse(dr["MCDEqualCurtailDateForDI"].ToString().Length == 0 ? "false" : dr["MCDEqualCurtailDateForDI"].ToString());
                    
                    dt.Rows.Add(row);
                }
                
                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            { 
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        internal DataTable Get_HUDClaims_LoanData(DataTable dt, int LoanID)
        {
            SqlConnection con = new SqlConnection(); 
            
            try
            {
                con.ConnectionString = _settings.GetConnectionString("HUDClaims");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_HUDClaimsSQLDatabase;
                cmd.CommandText = "usp_HUDClaims_Loan_Select_ByInvTrkLoanID";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter("@LoanID", LoanID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["FHALoanID"] = dr["FHALoanID"];
                    row["FHAClientID"] = dr["FHAClientID"];
                    row["FHACaseNumber"] = dr["FHACaseNumber"];
                    row["MortgageeID"] = dr["MortgageeID"];
                    row["MortgageeLoanNumber"] = dr["MortgageeLoanNumber"];
                    row["MortgageeContactName"] = dr["MortgageeContactName"];
                    row["MortgageeContactTelephone"] = dr["MortgageeContactTelephone"];
                    row["ServicerID"] = dr["ServicerID"];
                    row["ServicerContactName"] = dr["ServicerContactName"];
                    row["ServicerContactTelephone"] = dr["ServicerContactTelephone"];
                    row["PropertyAddress1"] = dr["PropertyAddress1"];
                    row["PropertyAddress2"] = dr["PropertyAddress2"];
                    row["PropertyCity"] = dr["PropertyCity"];
                    row["PropertyStateCode"] = dr["PropertyStateCode"];
                    row["PropertyZipCode"] = dr["PropertyZipCode"];
                    row["InvTrk_LoanID"] = dr["InvTrk_LoanID"];
                    row["EnteredDate"] = dr["EnteredDate"];
                    row["EnteredByUser"] = dr["EnteredByUser"];
                    row["LastUpdateDate"] = dr["LastUpdateDate"];
                    row["LastUpdateUser"] = dr["LastUpdateUser"];
                    row["SecondChanceSaleDate"] = DateTime.Parse(dr["SecondChanceSaleDate"].ToString().Length == 0 ? "1/1/1900" : dr["SecondChanceSaleDate"].ToString());
                    row["AuthorizedBidAmount"] = dr["AuthorizedBidAmount"];
                    row["SuccessfulBidAmount"] = dr["SuccessfulBidAmount"];
                    
                    dt.Rows.Add(row);
                }
                
                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            { 
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        #endregion

        #region "CmdLinePdf"

        /// <summary>
        /// 
        /// </summary>
        /// <param name="claimID"></param>
        /// <returns></returns>
        internal DataTable HUDClaims_VW_PartA_Select(long claimID)
        {
            SqlConnection con = new SqlConnection();

            try
            {

                DataTable dt = new DataTable("PartAVW");
                dt.Columns.Add("ClaimTypeID",typeof(long));
                dt.Columns.Add("ClaimType",typeof(string));
                dt.Columns.Add("FHACaseNumber",typeof(string));
                dt.Columns.Add("SectionOfTheActID",typeof(long));
                dt.Columns.Add("SectionOfTheAct",typeof(string));
                dt.Columns.Add("DefaultReasonID",typeof(long));
                dt.Columns.Add("DefaultReason",typeof(string));
                dt.Columns.Add("EndorsementDate",typeof(DateTime));
                dt.Columns.Add("DateFormPrepared",typeof(DateTime));
                dt.Columns.Add("FirstPaymentDueDateOriginal",typeof(DateTime));
                dt.Columns.Add("LastCompleteInstallmentPaidDate",typeof(DateTime));
                dt.Columns.Add("DateOfPossession",typeof(DateTime));
                dt.Columns.Add("DateOfAcquisitionOfTitle",typeof(DateTime));
                dt.Columns.Add("Block9Date",typeof(DateTime));
                dt.Columns.Add("DateDeedFiledForRecord",typeof(DateTime));
                dt.Columns.Add("DateAssignmentFiledForRecord",typeof(DateTime));
                dt.Columns.Add("DateOfClosing",typeof(DateTime));
                dt.Columns.Add("DateOfAppraisal",typeof(DateTime));
                dt.Columns.Add("Block10Date",typeof(DateTime));
                dt.Columns.Add("Block11Instituted",typeof(bool));
                dt.Columns.Add("Block11DateofDIL",typeof(bool));
                dt.Columns.Add("ForeclosureProceedingsDate",typeof(DateTime));
                dt.Columns.Add("DateOfDeedInLieu", typeof(DateTime));
                dt.Columns.Add("MortgageeID",typeof(long));
                dt.Columns.Add("HoldingMortgageeNumber",typeof(string));
                dt.Columns.Add("ServicerID",typeof(long));
                dt.Columns.Add("ServicingMortageeNumber",typeof(string));
                dt.Columns.Add("MortgageeLoanNumber",typeof(string));
                dt.Columns.Add("Block15Original",typeof(decimal));
                dt.Columns.Add("Block15Modified",typeof(decimal));
                dt.Columns.Add("HoldingMortgageeEIN",typeof(string));
                dt.Columns.Add("UnpaidLoanBalance",typeof(decimal));
                dt.Columns.Add("FirmCommitmentDate",typeof(DateTime));
                dt.Columns.Add("ExpDateExtensionToForeclose",typeof(DateTime));
                dt.Columns.Add("ExpDateExtensionToAssign",typeof(DateTime));
                dt.Columns.Add("Block19Date",typeof(DateTime));
                dt.Columns.Add("DateOfNoticeToConvey",typeof(DateTime));
                dt.Columns.Add("DateOfExtensionToConvey",typeof(DateTime));
                dt.Columns.Add("Block20Date",typeof(DateTime));
                dt.Columns.Add("ReleaseOfBankruptcyDate",typeof(DateTime));
                dt.Columns.Add("OccupancyStatusID",typeof(long));
                dt.Columns.Add("OccupancyStatus",typeof(string));
                dt.Columns.Add("DateLocalOfficeApprovalConveyanceOccupied",typeof(DateTime));
                dt.Columns.Add("PropertyConditionID",typeof(long));
                dt.Columns.Add("PropertyCondition",typeof(string));
                dt.Columns.Add("DateLocalOfficeApprovalConveyanceDamaged",typeof(DateTime));
                dt.Columns.Add("DateLocalOfficeCertificationConveyanceDamaged",typeof(DateTime));
                dt.Columns.Add("DamageTypeID",typeof(long));
                dt.Columns.Add("EstimateOfDamage",typeof(decimal));
                dt.Columns.Add("InsuranceRecovery",typeof(decimal));
                dt.Columns.Add("IsMortgageeSuccessfulBidder",typeof(bool));
                dt.Columns.Add("DeficiencyJudgementCodeID",typeof(long));
                dt.Columns.Add("DeficiencyJudgement",typeof(string));
                dt.Columns.Add("AuthorizedBidAmount",typeof(decimal));
                dt.Columns.Add("MortgageeReportedCurtailmentDate",typeof(DateTime));
                dt.Columns.Add("MortgagorFirstName",typeof(string));
                dt.Columns.Add("MortgagorMiddleName",typeof(string));
                dt.Columns.Add("MortgagorLastName",typeof(string));
                dt.Columns.Add("MortgagorSSN",typeof(string));
                dt.Columns.Add("PropertyAddress1",typeof(string));
                dt.Columns.Add("PropertyAddress2",typeof(string));
                dt.Columns.Add("PropertyCity",typeof(string));
                dt.Columns.Add("PropertyStateCode",typeof(string));
                dt.Columns.Add("PropertyZipCode",typeof(string));
                dt.Columns.Add("PropertyDescription",typeof(string));
                dt.Columns.Add("MortgageeName",typeof(string));
                dt.Columns.Add("MortgageeAddress",typeof(string));
                dt.Columns.Add("MortgageeCity",typeof(string));
                dt.Columns.Add("MortgageeStateCode",typeof(string));
                dt.Columns.Add("MortgageeZipCode",typeof(string));
                dt.Columns.Add("ServicerName",typeof(string));
                dt.Columns.Add("ServicerAddress",typeof(string));
                dt.Columns.Add("ServicerCity",typeof(string));
                dt.Columns.Add("ServicerStateCode",typeof(string));
                dt.Columns.Add("ServicerZipCode",typeof(string));
                dt.Columns.Add("MonthlyFHAInsurance",typeof(decimal));
                dt.Columns.Add("MonthlyTaxes",typeof(decimal));
                dt.Columns.Add("MonthlyHazardInsurance",typeof(decimal));
                dt.Columns.Add("MonthlyInterestAndPrincipal",typeof(decimal));
                dt.Columns.Add("BankruptcyDateFiled",typeof(DateTime));
                dt.Columns.Add("DateDamaged",typeof(DateTime));
                dt.Columns.Add("HIPCancelledDate",typeof(DateTime));
                dt.Columns.Add("HIPRefusedDate",typeof(DateTime));
                dt.Columns.Add("NumberOfLivingUnits",typeof(int));
                dt.Columns.Add("MortgageeComments",typeof(string));
                dt.Columns.Add("EnteredDate",typeof(DateTime));
                dt.Columns.Add("EnteredByUser",typeof(int));
                dt.Columns.Add("LastUpdateDate",typeof(DateTime));
                dt.Columns.Add("LastUpdateUser",typeof(int));
                dt.Columns.Add("ClientName",typeof(string));
                dt.Columns.Add("FHAClientID",typeof(long));
                dt.Columns.Add("FHALoanID",typeof(long));
                dt.Columns.Add("OrigMtgAmt",typeof(decimal));
                dt.Columns.Add("DebentureInterestRate",typeof(decimal));
                dt.Columns.Add("PartA27011ID",typeof(long));
                dt.Columns.Add("FHAClaimID",typeof(long));
                dt.Columns.Add("SectionOfTheActCode",typeof(string));
                dt.Columns.Add("DefficiendyJudgementCode",typeof(string));
                dt.Columns.Add("DamageCode",typeof(string));
                // 20181026 gk t4803
                dt.Columns.Add("ModifiedInterestRate", typeof(decimal));
                dt.Columns.Add("NewMaturityDate", typeof(DateTime));
                dt.Columns.Add("LastARMRate", typeof(decimal));
                dt.Columns.Add("FirstPaymentDueDateModified", typeof(DateTime));
                
                con.ConnectionString = _settings.GetConnectionString("HUDClaims");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_HUDClaimsSQLDatabase;
                cmd.CommandText = "pClaimsVw_HUD_PartAGet";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter();
                parm = new SqlParameter("@pk_FHAClaimID", claimID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ClaimTypeID"]=dr["ClaimTypeID"];
                    row["ClaimType"]=dr["ClaimType"];
                    row["FHACaseNumber"]=dr["FHACaseNumber"];
                    row["SectionOfTheActID"]=dr["SectionOfTheActID"];
                    row["SectionOfTheAct"]=dr["SectionOfTheAct"];
                    row["DefaultReasonID"]=dr["DefaultReasonID"];
                    row["DefaultReason"]=dr["DefaultReason"];
                    row["EndorsementDate"]=dr["EndorsementDate"];
                    row["DateFormPrepared"]=dr["DateFormPrepared"];
                    row["FirstPaymentDueDateOriginal"]=dr["FirstPaymentDueDateOriginal"];
                    row["LastCompleteInstallmentPaidDate"]=dr["LastCompleteInstallmentPaidDate"];
                    row["DateOfPossession"]=dr["DateOfPossession"];
                    row["DateOfAcquisitionOfTitle"]=dr["DateOfAcquisitionOfTitle"];
                    row["Block9Date"]=dr["Block9Date"];
                    row["DateDeedFiledForRecord"]=dr["DateDeedFiledForRecord"];
                    row["DateAssignmentFiledForRecord"]=dr["DateAssignmentFiledForRecord"];
                    row["DateOfClosing"]=dr["DateOfClosing"];
                    row["DateOfAppraisal"]=dr["DateOfAppraisal"];
                    row["Block10Date"]=dr["Block10Date"];
                    row["Block11Instituted"]=dr["Block11Instituted"];
                    row["Block11DateofDIL"]=dr["Block11DateofDIL"];
                    row["ForeclosureProceedingsDate"]=dr["ForeclosureProceedingsDate"];
                    row["DateOfDeedInLieu"]=dr["DateOfDeedInLieu"];
                    row["MortgageeID"]=dr["MortgageeID"];
                    row["HoldingMortgageeNumber"]=dr["HoldingMortgageeNumber"];
                    row["ServicerID"]=dr["ServicerID"];
                    row["ServicingMortageeNumber"]=dr["ServicingMortageeNumber"];
                    row["MortgageeLoanNumber"]=dr["MortgageeLoanNumber"];
                    row["Block15Original"]=dr["Block15Original"];
                    row["Block15Modified"]=dr["Block15Modified"];
                    row["HoldingMortgageeEIN"]=dr["HoldingMortgageeEIN"];
                    row["UnpaidLoanBalance"]=dr["UnpaidLoanBalance"];
                    row["FirmCommitmentDate"]=dr["FirmCommitmentDate"];
                    row["ExpDateExtensionToForeclose"]=dr["ExpDateExtensionToForeclose"];
                    row["ExpDateExtensionToAssign"]=dr["ExpDateExtensionToAssign"];
                    row["Block19Date"]=dr["Block19Date"];
                    row["DateOfNoticeToConvey"]=dr["DateOfNoticeToConvey"];
                    row["DateOfExtensionToConvey"]=dr["DateOfExtensionToConvey"];
                    row["Block20Date"]=dr["Block20Date"];
                    row["ReleaseOfBankruptcyDate"]=dr["ReleaseOfBankruptcyDate"];
                    row["OccupancyStatusID"]=dr["OccupancyStatusID"];
                    row["OccupancyStatus"]=dr["OccupancyStatus"];
                    row["DateLocalOfficeApprovalConveyanceOccupied"]=dr["DateLocalOfficeApprovalConveyanceOccupied"];
                    row["PropertyConditionID"]=dr["PropertyConditionID"];
                    row["PropertyCondition"]=dr["PropertyCondition"];
                    row["DateLocalOfficeApprovalConveyanceDamaged"]=dr["DateLocalOfficeApprovalConveyanceDamaged"];
                    row["DateLocalOfficeCertificationConveyanceDamaged"]=dr["DateLocalOfficeCertificationConveyanceDamaged"];
                    row["DamageTypeID"]=dr["DamageTypeID"];
                    row["EstimateOfDamage"]=dr["EstimateOfDamage"];
                    row["InsuranceRecovery"]=dr["InsuranceRecovery"];
                    row["IsMortgageeSuccessfulBidder"]=dr["IsMortgageeSuccessfulBidder"];
                    row["DeficiencyJudgementCodeID"]=dr["DeficiencyJudgementCodeID"];
                    row["DeficiencyJudgement"]=dr["DeficiencyJudgement"];
                    row["AuthorizedBidAmount"]=dr["AuthorizedBidAmount"];
                    row["MortgageeReportedCurtailmentDate"]=dr["MortgageeReportedCurtailmentDate"];
                    row["MortgagorFirstName"]=dr["MortgagorFirstName"];
                    row["MortgagorMiddleName"]=dr["MortgagorMiddleName"];
                    row["MortgagorLastName"]=dr["MortgagorLastName"];
                    row["MortgagorSSN"]=dr["MortgagorSSN"];
                    row["PropertyAddress1"]=dr["PropertyAddress1"];
                    row["PropertyAddress2"]=dr["PropertyAddress2"];
                    row["PropertyCity"]=dr["PropertyCity"];
                    row["PropertyStateCode"]=dr["PropertyStateCode"];
                    row["PropertyZipCode"]=dr["PropertyZipCode"];
                    row["PropertyDescription"]=dr["PropertyDescription"];
                    row["MortgageeName"]=dr["MortgageeName"];
                    row["MortgageeAddress"]=dr["MortgageeAddress"];
                    row["MortgageeCity"]=dr["MortgageeCity"];
                    row["MortgageeStateCode"]=dr["MortgageeStateCode"];
                    row["MortgageeZipCode"]=dr["MortgageeZipCode"];
                    row["ServicerName"]=dr["ServicerName"];
                    row["ServicerAddress"]=dr["ServicerAddress"];
                    row["ServicerCity"]=dr["ServicerCity"];
                    row["ServicerStateCode"]=dr["ServicerStateCode"];
                    row["ServicerZipCode"]=dr["ServicerZipCode"];
                    row["MonthlyFHAInsurance"]=dr["MonthlyFHAInsurance"];
                    row["MonthlyTaxes"]=dr["MonthlyTaxes"];
                    row["MonthlyHazardInsurance"]=dr["MonthlyHazardInsurance"];
                    row["MonthlyInterestAndPrincipal"]=dr["MonthlyInterestAndPrincipal"];
                    row["BankruptcyDateFiled"]=dr["BankruptcyDateFiled"];
                    row["DateDamaged"]=dr["DateDamaged"];
                    row["HIPCancelledDate"]=dr["HIPCancelledDate"];
                    row["HIPRefusedDate"]=dr["HIPRefusedDate"];
                    row["NumberOfLivingUnits"]=dr["NumberOfLivingUnits"];
                    row["MortgageeComments"]=dr["MortgageeComments"];
                    row["EnteredDate"]=dr["EnteredDate"];
                    row["EnteredByUser"]=dr["EnteredByUser"];
                    row["LastUpdateDate"]=dr["LastUpdateDate"];
                    row["LastUpdateUser"]=dr["LastUpdateUser"];
                    row["ClientName"]=dr["ClientName"];
                    row["FHAClientID"]=dr["FHAClientID"];
                    row["FHALoanID"]=dr["FHALoanID"];
                    row["OrigMtgAmt"]=dr["OrigMtgAmt"];
                    row["DebentureInterestRate"]=dr["DebentureInterestRate"];
                    row["PartA27011ID"]=dr["PartA27011ID"];
                    row["FHAClaimID"]=dr["FHAClaimID"];
                    row["SectionOfTheActCode"]=dr["SectionOfTheActCode"];
                    row["DefficiendyJudgementCode"]=dr["DefficiendyJudgementCode"];
                    row["DamageCode"]=dr["DamageCode"];
                    row["ModifiedInterestRate"] = dr["ModifiedInterestRate"];
                    row["NewMaturityDate"] = dr["NewMaturityDate"];
                    row["LastARMRate"] = dr["LastARMRate"];
                    row["FirstPaymentDueDateModified"] = dr["FirstPaymentDueDateModified"];

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        //return dal.HUDClaims_GetFHALookups();
        internal DataTable HUDClaims_GetFHALookups(CRFS.Data.Settings settings)
        {
            SqlConnection sql = new SqlConnection();

            try
            {
                sql.ConnectionString = settings.GetConnectionString("HUDClaims");
                sql.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_HUDClaims_InvTrk_GetFHALookups";

                cmd.Connection = sql;
                DataTable dt = new DataTable("ImportProcesses");
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Columns.Add("FHALookupID", typeof(int));
                    dt.Columns.Add("LUCategory", typeof(string));
                    dt.Columns.Add("DisplayCode1", typeof(string));
                    dt.Columns.Add("DisplayCode2", typeof(string));
                    dt.Columns.Add("LUText", typeof(string));
                    dt.Columns.Add("Active", typeof(bool));

                    while (reader.Read())
                    {
                        DataRow dr = dt.NewRow();

                        dr["FHALookupID"] = reader["FHALookupID"];
                        dr["LUCategory"] = reader["LUCategory"];
                        dr["DisplayCode1"] = reader["DisplayCode1"];
                        dr["DisplayCode2"] = reader["DisplayCode2"];
                        dr["LUText"] = reader["LUText"];
                        dr["Active"] = reader["Active"];

                        dt.Rows.Add(dr);

                    }

                }

                sql.Close();
                sql.Dispose();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (sql.State != ConnectionState.Closed)
                {
                    sql.Close();
                    sql.Dispose();
                }

            }

        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="PartAid"></param>
        /// <returns></returns>
        internal DataTable HUDClaims_vw_FHALivingUnits_SelectBy_PartAid(long PartAid)
        {
            SqlConnection con = new SqlConnection();

            try
            {

                DataTable dt = new DataTable("LivingUnits");

                dt.Columns.Add("LivingUnitID",typeof(long));
                dt.Columns.Add("PartA27011ID",typeof(long));
                dt.Columns.Add("UnitNumber",typeof(int));
                dt.Columns.Add("Vacant",typeof(bool));
                dt.Columns.Add("Occupied",typeof(bool));
                dt.Columns.Add("OccupantName",typeof(string));
                dt.Columns.Add("DateVacated",typeof(DateTime));
                dt.Columns.Add("DateSecured",typeof(DateTime));
                dt.Columns.Add("EnteredDate",typeof(DateTime));
                dt.Columns.Add("EnteredByUser",typeof(int));
                dt.Columns.Add("LastUpdateDate",typeof(DateTime));
                dt.Columns.Add("LastUpdateUser",typeof(int));
                 


                con.ConnectionString = _settings.GetConnectionString("HUDClaims");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_HUDClaimsSQLDatabase;
                cmd.CommandText = "usp_HUDClaims_vw_FHALivingUnits_SelectBy_PartAid";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter();
                parm = new SqlParameter("@PartA27011ID", PartAid);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["LivingUnitID"]=/*(long)*/dr["LivingUnitID"];
                    row["PartA27011ID"]=/*(long)*/dr["PartA27011ID"];
                    row["UnitNumber"]=/*(int)*/dr["UnitNumber"];
                    row["Vacant"]=/*(bool)*/dr["Vacant"];
                    row["Occupied"]=/*(bool)*/dr["Occupied"];
                    row["OccupantName"]=/*(string)*/dr["OccupantName"];
                    row["DateVacated"]=/*(DateTime)*/dr["DateVacated"];
                    row["DateSecured"]=/*(DateTime)*/dr["DateSecured"];
                    row["EnteredDate"]=/*(DateTime)*/dr["EnteredDate"];
                    row["EnteredByUser"]=/*(int)*/dr["EnteredByUser"];
                    row["LastUpdateDate"]=/*(DateTime)*/dr["LastUpdateDate"];
                    row["LastUpdateUser"]=/*(int)*/dr["LastUpdateUser"];

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        internal DataTable HUDClaims_VwTaxScheduleSelect()
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt=new DataTable("TaxSchedule");
                dt.Columns.Add("TaxScheduleID",typeof(long ));
                dt.Columns.Add("PartA27011ID",typeof(long));
                dt.Columns.Add("TaxYear",typeof(int));
                dt.Columns.Add("TaxType",typeof(string));
                dt.Columns.Add("CollectorPropertyIdentification",typeof(string));
                dt.Columns.Add("AmountPaid",typeof(decimal));
                dt.Columns.Add("StartDate",typeof(DateTime));
                dt.Columns.Add("EndDate",typeof(DateTime));
                dt.Columns.Add("DatePaid",typeof(DateTime));
                dt.Columns.Add("EnteredDate",typeof(DateTime));
                dt.Columns.Add("EnteredByUser",typeof(int));
                dt.Columns.Add("LastUpdateDate",typeof(DateTime));
                dt.Columns.Add("LastUpdateUser",typeof(int));

                con.ConnectionString = _settings.GetConnectionString("HUDClaims");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_HUDClaimsSQLDatabase;
                cmd.CommandText = "usp_HUDClaims_vw_FHATaxSchedule_Select";
                cmd.Connection = con;


                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["TaxScheduleID"]=dr["TaxScheduleID"];
                    row["PartA27011ID"]=dr["PartA27011ID"];
                    row["TaxYear"]=dr["TaxYear"];
                    row["TaxType"]=dr["TaxType"];
                    row["CollectorPropertyIdentification"]=dr["CollectorPropertyIdentification"];
                    row["AmountPaid"]=dr["AmountPaid"];
                    row["StartDate"]=dr["StartDate"];
                    row["EndDate"]=dr["EndDate"];
                    row["DatePaid"]=dr["DatePaid"];
                    row["EnteredDate"]=dr["EnteredDate"];
                    row["EnteredByUser"]=dr["EnteredByUser"];
                    row["LastUpdateDate"]=dr["LastUpdateDate"];
                    row["LastUpdateUser"]=dr["LastUpdateUser"];

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="claimID"></param>
        /// <returns></returns>
        internal DataTable HUDClaims_VW_PartB_Select(long claimID)
        {
            SqlConnection con = new SqlConnection();

            try
            {

                DataTable dt = new DataTable("PartBVW");
                dt.Columns.Add("ClaimTypeID",typeof(long));
                dt.Columns.Add("MortgagorFirstName",typeof(string));
                dt.Columns.Add("MortgagorMiddleName",typeof(string));
                dt.Columns.Add("MortgagorLastName",typeof(string));
                dt.Columns.Add("PropertyAddress1",typeof(string));
                dt.Columns.Add("PropertyAddress2",typeof(string));
                dt.Columns.Add("PropertyCity",typeof(string));
                dt.Columns.Add("PropertyStateCode",typeof(string));
                dt.Columns.Add("PropertyZipCode",typeof(string));
                dt.Columns.Add("FHACaseNumber",typeof(string));
                dt.Columns.Add("SectionOfTheActID",typeof(long));
                dt.Columns.Add("SectionOfAct",typeof(string));
                dt.Columns.Add("MortgageeLoanNumber",typeof(string));
                dt.Columns.Add("DateFormPrepared",typeof(DateTime));
                dt.Columns.Add("ExpDateToSubmitTitleEvidence",typeof(DateTime));
                dt.Columns.Add("CurtailmentDateFromAOP",typeof(DateTime));
                dt.Columns.Add("ExpOfExtToSubmitFiscalData",typeof(DateTime));
                dt.Columns.Add("Block105Date",typeof(DateTime));
                dt.Columns.Add("IsSupplemental",typeof(bool));
                dt.Columns.Add("Block107aAmount",typeof(decimal));
                dt.Columns.Add("Block107bAmount",typeof(decimal));
                dt.Columns.Add("Block108aAmount",typeof(decimal));
                dt.Columns.Add("Block109aAmount",typeof(decimal));
                dt.Columns.Add("Block110b",typeof(decimal));
                dt.Columns.Add("Block110c",typeof(decimal));
                dt.Columns.Add("Block111b",typeof(decimal));
                dt.Columns.Add("Block111c",typeof(decimal));
                dt.Columns.Add("Block112b",typeof(decimal));
                dt.Columns.Add("Block112c",typeof(decimal));
                dt.Columns.Add("Block113b",typeof(decimal));
                dt.Columns.Add("Block113c",typeof(decimal));
                dt.Columns.Add("Block114b",typeof(decimal));
                dt.Columns.Add("Block114c",typeof(decimal));
                dt.Columns.Add("Block115aAmount",typeof(decimal));
                dt.Columns.Add("Block116bAmount",typeof(decimal));
                dt.Columns.Add("Block117b",typeof(decimal));
                dt.Columns.Add("Block117c",typeof(decimal));
                dt.Columns.Add("Block118aAmount",typeof(decimal));
                dt.Columns.Add("wksheet119L1Amount",typeof(decimal));
                dt.Columns.Add("wksheet119L2Amount",typeof(decimal));
                dt.Columns.Add("wksheet119L3Amount",typeof(decimal));
                dt.Columns.Add("Block119aAmount",typeof(decimal));
                dt.Columns.Add("Block119bAmount",typeof(decimal));
                dt.Columns.Add("Block120b",typeof(decimal));
                dt.Columns.Add("Block120c",typeof(decimal));
                dt.Columns.Add("wksheet121FromDate",typeof(DateTime));
                dt.Columns.Add("wksheet121ToDate",typeof(DateTime));
                dt.Columns.Add("wksheet121Rate",typeof(decimal));
                dt.Columns.Add("Block121Amount",typeof(decimal));
                dt.Columns.Add("Block122b",typeof(decimal));
                dt.Columns.Add("Block122c",typeof(decimal));
                dt.Columns.Add("Block123aAmount",typeof(decimal));
                dt.Columns.Add("Block123bAmount",typeof(decimal));
                dt.Columns.Add("Block123cAmount",typeof(decimal));
                dt.Columns.Add("Block124aAmount",typeof(decimal));
                dt.Columns.Add("Block124bAmount",typeof(decimal));
                dt.Columns.Add("Block124cAmount",typeof(decimal));
                dt.Columns.Add("Block125b",typeof(decimal));
                dt.Columns.Add("Block125c",typeof(decimal));
                dt.Columns.Add("Block126cAmount",typeof(decimal));
                dt.Columns.Add("Block127a",typeof(decimal));
                dt.Columns.Add("Block128b",typeof(decimal));
                dt.Columns.Add("Block129b",typeof(decimal));
                dt.Columns.Add("130AppraisalFeeAFromPtE",typeof(int));
                dt.Columns.Add("Block130b",typeof(decimal));
                dt.Columns.Add("Block130c",typeof(decimal));
                dt.Columns.Add("131DeficiencyAFromPtE",typeof(int));
                dt.Columns.Add("Block131b",typeof(decimal));
                dt.Columns.Add("Block131c",typeof(decimal));
                dt.Columns.Add("Block132Description",typeof(string));
                dt.Columns.Add("Block132aAmount",typeof(decimal));
                dt.Columns.Add("Block132bAmount",typeof(decimal));
                dt.Columns.Add("Block132cAmount",typeof(decimal));
                dt.Columns.Add("MortgageeID",typeof(long));
                dt.Columns.Add("MortgageeName",typeof(string));
                dt.Columns.Add("ServicerID",typeof(long));
                dt.Columns.Add("ServicerName",typeof(string));
                dt.Columns.Add("134TotalDeductions",typeof(decimal));
                dt.Columns.Add("135TotalAdditions",typeof(decimal));
                dt.Columns.Add("136TotalInterest",typeof(decimal));
                dt.Columns.Add("137NetclaimAmount",typeof(decimal));
                dt.Columns.Add("PartB27011ID",typeof(long));
                dt.Columns.Add("FHAClaimID",typeof(long));
                dt.Columns.Add("EnteredDate",typeof(DateTime));
                dt.Columns.Add("EnteredByUser",typeof(int));
                dt.Columns.Add("LastUpdateDate",typeof(DateTime));
                dt.Columns.Add("LastUpdateUser",typeof(int));
                dt.Columns.Add("FHAClientID",typeof(long));
                dt.Columns.Add("FHALoanID",typeof(long));
                dt.Columns.Add("ClientName",typeof(string));
                dt.Columns.Add("SectionOfActCode",typeof(string));

                con.ConnectionString = _settings.GetConnectionString("HUDClaims");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_HUDClaimsSQLDatabase;
                cmd.CommandText = "pClaimsVw_HUD_PartBGet";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter();
                parm = new SqlParameter("@pk_FHAClaimID", claimID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ClaimTypeID"]=dr["ClaimTypeID"];
                    row["MortgagorFirstName"]=dr["MortgagorFirstName"];
                    row["MortgagorMiddleName"]=dr["MortgagorMiddleName"];
                    row["MortgagorLastName"]=dr["MortgagorLastName"];
                    row["PropertyAddress1"]=dr["PropertyAddress1"];
                    row["PropertyAddress2"]=dr["PropertyAddress2"];
                    row["PropertyCity"]=dr["PropertyCity"];
                    row["PropertyStateCode"]=dr["PropertyStateCode"];
                    row["PropertyZipCode"]=dr["PropertyZipCode"];
                    row["FHACaseNumber"]=dr["FHACaseNumber"];
                    row["SectionOfTheActID"]=dr["SectionOfTheActID"];
                    row["SectionOfAct"]=dr["SectionOfAct"];
                    row["MortgageeLoanNumber"]=dr["MortgageeLoanNumber"];
                    row["DateFormPrepared"]=dr["DateFormPrepared"];
                    row["ExpDateToSubmitTitleEvidence"]=dr["ExpDateToSubmitTitleEvidence"];
                    row["CurtailmentDateFromAOP"]=dr["CurtailmentDateFromAOP"];
                    row["ExpOfExtToSubmitFiscalData"]=dr["ExpOfExtToSubmitFiscalData"];
                    row["Block105Date"]=dr["Block105Date"];
                    row["IsSupplemental"]=dr["IsSupplemental"];
                    row["Block107aAmount"]=dr["Block107aAmount"];
                    row["Block107bAmount"]=dr["Block107bAmount"];
                    row["Block108aAmount"]=dr["Block108aAmount"];
                    row["Block109aAmount"]=dr["Block109aAmount"];
                    row["Block110b"]=dr["Block110b"];
                    row["Block110c"]=dr["Block110c"];
                    row["Block111b"]=dr["Block111b"];
                    row["Block111c"]=dr["Block111c"];
                    row["Block112b"]=dr["Block112b"];
                    row["Block112c"]=dr["Block112c"];
                    row["Block113b"]=dr["Block113b"];
                    row["Block113c"]=dr["Block113c"];
                    row["Block114b"]=dr["Block114b"];
                    row["Block114c"]=dr["Block114c"];
                    row["Block115aAmount"]=dr["Block115aAmount"];
                    row["Block116bAmount"]=dr["Block116bAmount"];
                    row["Block117b"]=dr["Block117b"];
                    row["Block117c"]=dr["Block117c"];
                    row["Block118aAmount"]=dr["Block118aAmount"];
                    row["wksheet119L1Amount"]=dr["wksheet119L1Amount"];
                    row["wksheet119L2Amount"]=dr["wksheet119L2Amount"];
                    row["wksheet119L3Amount"]=dr["wksheet119L3Amount"];
                    row["Block119aAmount"]=dr["Block119aAmount"];
                    row["Block119bAmount"]=dr["Block119bAmount"];
                    row["Block120b"]=dr["Block120b"];
                    row["Block120c"]=dr["Block120c"];
                    row["wksheet121FromDate"]=dr["wksheet121FromDate"];
                    row["wksheet121ToDate"]=dr["wksheet121ToDate"];
                    row["wksheet121Rate"]=dr["wksheet121Rate"];
                    row["Block121Amount"]=dr["Block121Amount"];
                    row["Block122b"]=dr["Block122b"];
                    row["Block122c"]=dr["Block122c"];
                    row["Block123aAmount"]=dr["Block123aAmount"];
                    row["Block123bAmount"]=dr["Block123bAmount"];
                    row["Block123cAmount"]=dr["Block123cAmount"];
                    row["Block124aAmount"]=dr["Block124aAmount"];
                    row["Block124bAmount"]=dr["Block124bAmount"];
                    row["Block124cAmount"]=dr["Block124cAmount"];
                    row["Block125b"]=dr["Block125b"];
                    row["Block125c"]=dr["Block125c"];
                    row["Block126cAmount"]=dr["Block126cAmount"];
                    row["Block127a"]=dr["Block127a"];
                    row["Block128b"]=dr["Block128b"];
                    row["Block129b"]=dr["Block129b"];
                    row["130AppraisalFeeAFromPtE"]=dr["130AppraisalFeeAFromPtE"];
                    row["Block130b"]=dr["Block130b"];
                    row["Block130c"]=dr["Block130c"];
                    row["131DeficiencyAFromPtE"]=dr["131DeficiencyAFromPtE"];
                    row["Block131b"]=dr["Block131b"];
                    row["Block131c"]=dr["Block131c"];
                    row["Block132Description"]=dr["Block132Description"];
                    row["Block132aAmount"]=dr["Block132aAmount"];
                    row["Block132bAmount"]=dr["Block132bAmount"];
                    row["Block132cAmount"]=dr["Block132cAmount"];
                    row["MortgageeID"]=dr["MortgageeID"];
                    row["MortgageeName"]=dr["MortgageeName"];
                    row["ServicerID"]=dr["ServicerID"];
                    row["ServicerName"]=dr["ServicerName"];
                    row["134TotalDeductions"]=dr["134TotalDeductions"];
                    row["135TotalAdditions"]=dr["135TotalAdditions"];
                    row["136TotalInterest"]=dr["136TotalInterest"];
                    row["137NetclaimAmount"]=dr["137NetclaimAmount"];
                    row["PartB27011ID"]=dr["PartB27011ID"];
                    row["FHAClaimID"]=dr["FHAClaimID"];
                    row["EnteredDate"]=dr["EnteredDate"];
                    row["EnteredByUser"]=dr["EnteredByUser"];
                    row["LastUpdateDate"]=dr["LastUpdateDate"];
                    row["LastUpdateUser"]=dr["LastUpdateUser"];
                    row["FHAClientID"]=dr["FHAClientID"];
                    row["FHALoanID"]=dr["FHALoanID"];
                    row["ClientName"]=dr["ClientName"];
                    row["SectionOfActCode"]=dr["SectionOfActCode"];

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FHAClaimID"></param>
        /// <returns></returns>
        internal DataTable HUDClaims_VW_PartC_SelectByClaimID(int FHAClaimID)
        {
            SqlConnection con = new SqlConnection();

            try
            {

                DataTable dt = new DataTable("PartCVW");
                dt.Columns.Add("ClaimTypeID",typeof(long));
                dt.Columns.Add("MortgagorFirstName",typeof(string));
                dt.Columns.Add("MortgagorMiddleName",typeof(string));
                dt.Columns.Add("MortgagorLastName",typeof(string));
                dt.Columns.Add("PropertyAddress1",typeof(string));
                dt.Columns.Add("PropertyAddress2",typeof(string));
                dt.Columns.Add("PropertyCity",typeof(string));
                dt.Columns.Add("PropertyStateCode",typeof(string));
                dt.Columns.Add("PropertyZipCode",typeof(string));
                dt.Columns.Add("FHACaseNumber",typeof(string));
                dt.Columns.Add("MortgageeLoanNumber",typeof(string));
                dt.Columns.Add("PartC27011ID",typeof(long));
                dt.Columns.Add("FHAClaimID",typeof(long));
                dt.Columns.Add("DateFormPrepared",typeof(DateTime));
                dt.Columns.Add("MortgageeComments",typeof(string));
                dt.Columns.Add("ClientName",typeof(string));
                dt.Columns.Add("SectionOfActCode",typeof(string));
                dt.Columns.Add("DebentureInterestRate",typeof(decimal));
                dt.Columns.Add("DefaultDate",typeof(DateTime));
                dt.Columns.Add("MortgageeName",typeof(string));
                dt.Columns.Add("ServicerName",typeof(string));
                dt.Columns.Add("EnteredDate",typeof(DateTime));
                dt.Columns.Add("EnteredByUser",typeof(int));
                dt.Columns.Add("LastUpdateDate",typeof(DateTime));
                dt.Columns.Add("LastUpdateUser",typeof(int));

                con.ConnectionString = _settings.GetConnectionString("HUDClaims");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_HUDClaimsSQLDatabase;
                cmd.CommandText = "usp_HUDCLaims_vw_PartC_SelectBy_ClaimID";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter();
                parm = new SqlParameter("@FHAClaimID", FHAClaimID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ClaimTypeID"]=dr["ClaimTypeID"];
                    row["MortgagorFirstName"]=dr["MortgagorFirstName"];
                    row["MortgagorMiddleName"]=dr["MortgagorMiddleName"];
                    row["MortgagorLastName"]=dr["MortgagorLastName"];
                    row["PropertyAddress1"]=dr["PropertyAddress1"];
                    row["PropertyAddress2"]=dr["PropertyAddress2"];
                    row["PropertyCity"]=dr["PropertyCity"];
                    row["PropertyStateCode"]=dr["PropertyStateCode"];
                    row["PropertyZipCode"]=dr["PropertyZipCode"];
                    row["FHACaseNumber"]=dr["FHACaseNumber"];
                    row["MortgageeLoanNumber"]=dr["MortgageeLoanNumber"];
                    row["PartC27011ID"]=dr["PartC27011ID"];
                    row["FHAClaimID"]=dr["FHAClaimID"];
                    row["DateFormPrepared"]=dr["DateFormPrepared"];
                    row["MortgageeComments"]=dr["MortgageeComments"];
                    row["ClientName"]=dr["ClientName"];
                    row["SectionOfActCode"]=dr["SectionOfActCode"];
                    row["DebentureInterestRate"]=dr["DebentureInterestRate"];
                    row["DefaultDate"]=dr["DefaultDate"];
                    row["MortgageeName"]=dr["MortgageeName"];
                    row["ServicerName"]=dr["ServicerName"];
                    row["EnteredDate"]=dr["EnteredDate"];
                    row["EnteredByUser"]=dr["EnteredByUser"];
                    row["LastUpdateDate"]=dr["LastUpdateDate"];
                    row["LastUpdateUser"]=dr["LastUpdateUser"];

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="FHACaseNo"></param>
        /// <returns></returns>
        internal DataTable HUDClaims_VW_PartC_Select(string FHACaseNo)
        {
            SqlConnection con = new SqlConnection();

            try
            {

                DataTable dt = new DataTable("PartCVW");
                dt.Columns.Add("ClaimTypeID",typeof(long));
                dt.Columns.Add("MortgagorFirstName",typeof(string));
                dt.Columns.Add("MortgagorMiddleName",typeof(string));
                dt.Columns.Add("MortgagorLastName",typeof(string));
                dt.Columns.Add("PropertyAddress1",typeof(string));
                dt.Columns.Add("PropertyAddress2",typeof(string));
                dt.Columns.Add("PropertyCity",typeof(string));
                dt.Columns.Add("PropertyStateCode",typeof(string));
                dt.Columns.Add("PropertyZipCode",typeof(string));
                dt.Columns.Add("FHACaseNumber",typeof(string));
                dt.Columns.Add("MortgageeLoanNumber",typeof(string));
                dt.Columns.Add("PartC27011ID",typeof(long));
                dt.Columns.Add("FHAClaimID",typeof(long));
                dt.Columns.Add("DateFormPrepared",typeof(DateTime));
                dt.Columns.Add("MortgageeComments",typeof(string));
                dt.Columns.Add("ClientName",typeof(string));
                dt.Columns.Add("SectionOfActCode",typeof(string));
                dt.Columns.Add("DebentureInterestRate",typeof(decimal));
                dt.Columns.Add("MortgageeName",typeof(string));
                dt.Columns.Add("ServicerName",typeof(string));
                dt.Columns.Add("EnteredDate",typeof(DateTime));
                dt.Columns.Add("EnteredByUser",typeof(int));
                dt.Columns.Add("LastUpdateDate",typeof(DateTime));
                dt.Columns.Add("LastUpdateUser",typeof(int));

                con.ConnectionString = _settings.GetConnectionString("HUDClaims");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_HUDClaimsSQLDatabase;
                cmd.CommandText = "usp_HUDCLaims_vw_PartC_SelectBy_CaseNo";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter();
                parm = new SqlParameter("@FHACaseNo", FHACaseNo);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ClaimTypeID"]=dr["ClaimTypeID"];
                    row["MortgagorFirstName"]=dr["MortgagorFirstName"];
                    row["MortgagorMiddleName"]=dr["MortgagorMiddleName"];
                    row["MortgagorLastName"]=dr["MortgagorLastName"];
                    row["PropertyAddress1"]=dr["PropertyAddress1"];
                    row["PropertyAddress2"]=dr["PropertyAddress2"];
                    row["PropertyCity"]=dr["PropertyCity"];
                    row["PropertyStateCode"]=dr["PropertyStateCode"];
                    row["PropertyZipCode"]=dr["PropertyZipCode"];
                    row["FHACaseNumber"]=dr["FHACaseNumber"];
                    row["MortgageeLoanNumber"]=dr["MortgageeLoanNumber"];
                    row["PartC27011ID"]=dr["PartC27011ID"];
                    row["FHAClaimID"]=dr["FHAClaimID"];
                    row["DateFormPrepared"]=dr["DateFormPrepared"];
                    row["MortgageeComments"]=dr["MortgageeComments"];
                    row["ClientName"]=dr["ClientName"];
                    row["SectionOfActCode"]=dr["SectionOfActCode"];
                    row["DebentureInterestRate"]=dr["DebentureInterestRate"];
                    row["MortgageeName"]=dr["MortgageeName"];
                    row["ServicerName"]=dr["ServicerName"];
                    row["EnteredDate"]=dr["EnteredDate"];
                    row["EnteredByUser"]=dr["EnteredByUser"];
                    row["LastUpdateDate"]=dr["LastUpdateDate"];
                    row["LastUpdateUser"]=dr["LastUpdateUser"];

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="FHACaseNo"></param>
        /// <returns></returns>
        internal DataTable HUDCLaims_Get_vw_PandP_by_PartcID(long PartC27011ID)
        {
            SqlConnection con = new SqlConnection();

            try
            {

                DataTable dt = new DataTable("PandP");
                dt.Columns.Add("ProtectionPreservationDisbursementID",typeof(long));
                dt.Columns.Add("PartC27011ID",typeof(long));
                dt.Columns.Add("DatePaid",typeof(DateTime));
                dt.Columns.Add("DateWorkCompleted",typeof(DateTime));
                dt.Columns.Add("DescriptionOfServicesPerformed",typeof(string));
                dt.Columns.Add("AmountPaid",typeof(decimal));
                dt.Columns.Add("DebentureInterest",typeof(decimal));
                dt.Columns.Add("DebentureInterestCalc",typeof(decimal));
                dt.Columns.Add("FHAClaimID",typeof(long));
                dt.Columns.Add("DebentureInterestRate",typeof(decimal));
                dt.Columns.Add("ClaimTypeID",typeof(long));
                dt.Columns.Add("HudApproved", typeof(bool)); // 20190403 gk fb65878
                dt.Columns.Add("EnteredDate",typeof(DateTime));
                dt.Columns.Add("EnteredByUser",typeof(int));
                dt.Columns.Add("LastUpdateDate",typeof(DateTime));
                dt.Columns.Add("LastUpdateUser",typeof(int));

                con.ConnectionString = _settings.GetConnectionString("HUDClaims");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_HUDClaimsSQLDatabase;
                cmd.CommandText = "usp_HUDCLaims_Get_vw_PandP_by_PartcID";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter();
                parm = new SqlParameter("@PartC27011ID", PartC27011ID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ProtectionPreservationDisbursementID"]=dr["ProtectionPreservationDisbursementID"];
                    row["PartC27011ID"]=dr["PartC27011ID"];
                    row["DatePaid"]=dr["DatePaid"];
                    row["DateWorkCompleted"]=dr["DateWorkCompleted"];
                    row["DescriptionOfServicesPerformed"]=dr["DescriptionOfServicesPerformed"];
                    row["AmountPaid"]=dr["AmountPaid"];
                    row["DebentureInterest"]=dr["DebentureInterest"];
                    row["DebentureInterestCalc"]=dr["DebentureInterestCalc"];
                    row["FHAClaimID"]=dr["FHAClaimID"];
                    row["DebentureInterestRate"]=dr["DebentureInterestRate"];
                    row["ClaimTypeID"]=dr["ClaimTypeID"];
                    row["HudApproved"] = dr["HudApproved"];  // 20190403 gk fb65878
                    row["EnteredDate"]=dr["EnteredDate"];
                    row["EnteredByUser"]=dr["EnteredByUser"];
                    row["LastUpdateDate"]=dr["LastUpdateDate"];
                    row["LastUpdateUser"]=dr["LastUpdateUser"];

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FHAClaimID"></param>
        /// <returns></returns>
        internal DataTable HUDClaims_VW_PartD_SelectbyClaimid(int FHAClaimID)
        {
            SqlConnection con = new SqlConnection();

            try
            {

                DataTable dt = new DataTable("PartDVW");
                dt.Columns.Add("ClaimTypeID",typeof(long));
                dt.Columns.Add("MortgagorFirstName",typeof(string));
                dt.Columns.Add("MortgagorMiddleName",typeof(string));
                dt.Columns.Add("MortgagorLastName",typeof(string));
                dt.Columns.Add("PropertyAddress1",typeof(string));
                dt.Columns.Add("PropertyAddress2",typeof(string));
                dt.Columns.Add("PropertyCity",typeof(string));
                dt.Columns.Add("PropertyStateCode",typeof(string));
                dt.Columns.Add("PropertyZipCode",typeof(string));
                dt.Columns.Add("FHACaseNumber",typeof(string));
                dt.Columns.Add("MortgageeLoanNumber",typeof(string));
                dt.Columns.Add("PartD27011ID",typeof(long));
                dt.Columns.Add("FHAClaimID",typeof(long));
                dt.Columns.Add("DateFormPrepared",typeof(DateTime));
                dt.Columns.Add("ClientName",typeof(string));
                dt.Columns.Add("SectionOfActCode",typeof(string));
                dt.Columns.Add("DebentureInterestRate",typeof(decimal));
                dt.Columns.Add("DefaultDate",typeof(DateTime));
                dt.Columns.Add("MortgageeName",typeof(string));
                dt.Columns.Add("ServicerName",typeof(string));
                dt.Columns.Add("EnteredDate",typeof(DateTime));
                dt.Columns.Add("EnteredByUser",typeof(int));
                dt.Columns.Add("LastUpdateDate",typeof(DateTime));
                dt.Columns.Add("LastUpdateUser",typeof(int));

                con.ConnectionString = _settings.GetConnectionString("HUDClaims");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_HUDClaimsSQLDatabase;
                cmd.CommandText = "usp_HUDCLaims_vw_PartD_SelectBy_ClaimID";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter();
                parm = new SqlParameter("@FHAClaimID", FHAClaimID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ClaimTypeID"]=dr["ClaimTypeID"];
                    row["MortgagorFirstName"]=dr["MortgagorFirstName"];
                    row["MortgagorMiddleName"]=dr["MortgagorMiddleName"];
                    row["MortgagorLastName"]=dr["MortgagorLastName"];
                    row["PropertyAddress1"]=dr["PropertyAddress1"];
                    row["PropertyAddress2"]=dr["PropertyAddress2"];
                    row["PropertyCity"]=dr["PropertyCity"];
                    row["PropertyStateCode"]=dr["PropertyStateCode"];
                    row["PropertyZipCode"]=dr["PropertyZipCode"];
                    row["FHACaseNumber"]=dr["FHACaseNumber"];
                    row["MortgageeLoanNumber"]=dr["MortgageeLoanNumber"];
                    row["PartD27011ID"]=dr["PartD27011ID"];
                    row["FHAClaimID"]=dr["FHAClaimID"];
                    row["DateFormPrepared"]=dr["DateFormPrepared"];
                    row["ClientName"]=dr["ClientName"];
                    row["SectionOfActCode"]=dr["SectionOfActCode"];
                    row["DebentureInterestRate"]=dr["DebentureInterestRate"];
                    row["DefaultDate"]=dr["DefaultDate"];
                    row["MortgageeName"]=dr["MortgageeName"];
                    row["ServicerName"]=dr["ServicerName"];
                    row["EnteredDate"]=dr["EnteredDate"];
                    row["EnteredByUser"]=dr["EnteredByUser"];
                    row["LastUpdateDate"]=dr["LastUpdateDate"];
                    row["LastUpdateUser"]=dr["LastUpdateUser"];

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="FHACaseNo"></param>
        /// <returns></returns>
        internal DataTable HUDClaims_VW_PartD_Select(string FHACaseNo)
        {
            SqlConnection con = new SqlConnection();

            try
            {

                DataTable dt = new DataTable("PartDVW");
                dt.Columns.Add("ClaimTypeID",typeof(long));
                dt.Columns.Add("MortgagorFirstName",typeof(string));
                dt.Columns.Add("MortgagorMiddleName",typeof(string));
                dt.Columns.Add("MortgagorLastName",typeof(string));
                dt.Columns.Add("PropertyAddress1",typeof(string));
                dt.Columns.Add("PropertyAddress2",typeof(string));
                dt.Columns.Add("PropertyCity",typeof(string));
                dt.Columns.Add("PropertyStateCode",typeof(string));
                dt.Columns.Add("PropertyZipCode",typeof(string));
                dt.Columns.Add("FHACaseNumber",typeof(string));
                dt.Columns.Add("MortgageeLoanNumber",typeof(string));
                dt.Columns.Add("PartD27011ID",typeof(long));
                dt.Columns.Add("FHAClaimID",typeof(long));
                dt.Columns.Add("DateFormPrepared",typeof(DateTime));
                dt.Columns.Add("ClientName",typeof(string));
                dt.Columns.Add("SectionOfActCode",typeof(string));
                dt.Columns.Add("DebentureInterestRate",typeof(decimal));
                dt.Columns.Add("MortgageeName",typeof(string));
                dt.Columns.Add("ServicerName",typeof(string));
                dt.Columns.Add("EnteredDate",typeof(DateTime));
                dt.Columns.Add("EnteredByUser",typeof(int));
                dt.Columns.Add("LastUpdateDate",typeof(DateTime));
                dt.Columns.Add("LastUpdateUser",typeof(int));

                con.ConnectionString = _settings.GetConnectionString("HUDClaims");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_HUDClaimsSQLDatabase;
                cmd.CommandText = "usp_HUDCLaims_vw_PartD_SelectBy_CaseNo";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter();
                parm = new SqlParameter("@FHACaseNo", FHACaseNo);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ClaimTypeID"]=dr["ClaimTypeID"];
                    row["MortgagorFirstName"]=dr["MortgagorFirstName"];
                    row["MortgagorMiddleName"]=dr["MortgagorMiddleName"];
                    row["MortgagorLastName"]=dr["MortgagorLastName"];
                    row["PropertyAddress1"]=dr["PropertyAddress1"];
                    row["PropertyAddress2"]=dr["PropertyAddress2"];
                    row["PropertyCity"]=dr["PropertyCity"];
                    row["PropertyStateCode"]=dr["PropertyStateCode"];
                    row["PropertyZipCode"]=dr["PropertyZipCode"];
                    row["FHACaseNumber"]=dr["FHACaseNumber"];
                    row["MortgageeLoanNumber"]=dr["MortgageeLoanNumber"];
                    row["PartD27011ID"]=dr["PartD27011ID"];
                    row["FHAClaimID"]=dr["FHAClaimID"];
                    row["DateFormPrepared"]=dr["DateFormPrepared"];
                    row["ClientName"]=dr["ClientName"];
                    row["SectionOfActCode"]=dr["SectionOfActCode"];
                    row["DebentureInterestRate"]=dr["DebentureInterestRate"];
                    row["MortgageeName"]=dr["MortgageeName"];
                    row["ServicerName"]=dr["ServicerName"];
                    row["EnteredDate"]=dr["EnteredDate"];
                    row["EnteredByUser"]=dr["EnteredByUser"];
                    row["LastUpdateDate"]=dr["LastUpdateDate"];
                    row["LastUpdateUser"]=dr["LastUpdateUser"];

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="PartD27011ID"></param>
        /// <returns></returns>
        internal DataTable usp_HUDCLaims_Select_PartDBlocks_ByDid(long PartD27011ID)
        {
            SqlConnection con = new SqlConnection();

            try
            {

                DataTable dt = new DataTable("PartDBlock");
                dt.Columns.Add("BlockCode",typeof(string));
                dt.Columns.Add("MultiBlockID",typeof(long));
                dt.Columns.Add("PartD27011ID",typeof(long));
                dt.Columns.Add("Form27011BlockID",typeof(int));
                dt.Columns.Add("DatePaid",typeof(DateTime));
                dt.Columns.Add("Description",typeof(string));
                dt.Columns.Add("AmountPaid",typeof(decimal));
                dt.Columns.Add("DebentureInterest",typeof(decimal));
                dt.Columns.Add("DebentureInterestCalc",typeof(decimal));
                dt.Columns.Add("DebentureInterestRate",typeof(decimal));
                dt.Columns.Add("ClaimTypeID",typeof(long));
                dt.Columns.Add("EnteredDate",typeof(DateTime));
                dt.Columns.Add("EnteredByUser",typeof(int));
                dt.Columns.Add("LastUpdateDate",typeof(DateTime));
                dt.Columns.Add("LastUpdateUser",typeof(int));

                con.ConnectionString = _settings.GetConnectionString("HUDClaims");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_HUDClaimsSQLDatabase;
                cmd.CommandText = "usp_HUDCLaims_Select_PartDBlocks_ByDid";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter();
                parm = new SqlParameter("@PartD27011ID", PartD27011ID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["BlockCode"]=dr["BlockCode"];
                    row["MultiBlockID"]=dr["MultiBlockID"];
                    row["PartD27011ID"]=dr["PartD27011ID"];
                    row["Form27011BlockID"]=dr["Form27011BlockID"];
                    row["DatePaid"]=dr["DatePaid"];
                    row["Description"]=dr["Description"];
                    row["AmountPaid"]=dr["AmountPaid"];
                    row["DebentureInterest"]=dr["DebentureInterest"];
                    row["DebentureInterestCalc"]=dr["DebentureInterestCalc"];
                    row["DebentureInterestRate"]=dr["DebentureInterestRate"];
                    row["ClaimTypeID"]=dr["ClaimTypeID"];
                    row["EnteredDate"]=dr["EnteredDate"];
                    row["EnteredByUser"]=dr["EnteredByUser"];
                    row["LastUpdateDate"]=dr["LastUpdateDate"];
                    row["LastUpdateUser"]=dr["LastUpdateUser"];

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="PartD27011ID"></param>
        /// <returns></returns>
        internal DataTable usp_HUDCLaims_Select_Block308_ByDid(long PartD27011ID)
        {
            SqlConnection con = new SqlConnection();

            try
            {

                DataTable dt = new DataTable("PartDBlock308");
                dt.Columns.Add("TaxOnDeedID", typeof(long));
                dt.Columns.Add("PartD27011ID",typeof(long));
                dt.Columns.Add("DatePaid",typeof(DateTime));
                dt.Columns.Add("TaxType",typeof(String));
                dt.Columns.Add("ToMortgagee",typeof(Decimal));
                dt.Columns.Add("ToHud",typeof(Decimal));
                dt.Columns.Add("AmountPaid",typeof(Decimal));
                dt.Columns.Add("DebentureInterest",typeof(Decimal));
                dt.Columns.Add("DebentureInterestCalc",typeof(Decimal));
                dt.Columns.Add("DebentureInterestRate",typeof(Decimal));
                dt.Columns.Add("ClaimTypeID",typeof(long));

                dt.Columns.Add("EnteredDate",typeof(DateTime));
                dt.Columns.Add("EnteredByUser",typeof(int));
                dt.Columns.Add("LastUpdateDate",typeof(DateTime));
                dt.Columns.Add("LastUpdateUser",typeof(int));

                con.ConnectionString = _settings.GetConnectionString("HUDClaims");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_HUDClaimsSQLDatabase;
                cmd.CommandText = "usp_HUDCLaims_Select_FHA_Block308_ByDid";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter();
                parm = new SqlParameter("@PartD27011ID", PartD27011ID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();
                    row["TaxOnDeedID"]=dr["TaxOnDeedID"];
                    row["PartD27011ID"]=dr["PartD27011ID"];
                    row["DatePaid"]=dr["DatePaid"];
                    row["TaxType"]=dr["TaxType"];
                    row["ToMortgagee"]=dr["ToMortgagee"];
                    row["ToHud"]=dr["ToHud"];
                    row["AmountPaid"]=dr["AmountPaid"];
                    row["DebentureInterest"]=dr["DebentureInterest"];
                    row["DebentureInterestCalc"]=dr["DebentureInterestCalc"];
                    row["DebentureInterestRate"]=dr["DebentureInterestRate"];
                    row["ClaimTypeID"]=dr["ClaimTypeID"];
    
                    row["EnteredDate"]=dr["EnteredDate"];
                    row["EnteredByUser"]=dr["EnteredByUser"];
                    row["LastUpdateDate"]=dr["LastUpdateDate"];
                    row["LastUpdateUser"]=dr["LastUpdateUser"];


                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="PartD27011ID"></param>
        /// <returns></returns>
        internal DataTable usp_HUDCLaims_Select_Block309_ByDid(long PartD27011ID)
        {
            SqlConnection con = new SqlConnection();

            try
            {

                DataTable dt = new DataTable("PartDBlock309");
                dt.Columns.Add("SpecialAssessmentsID", typeof(long));
                dt.Columns.Add("PartD27011ID",typeof(long));
                dt.Columns.Add("DatePaid",typeof(DateTime));
                dt.Columns.Add("DateLienAttached", typeof(DateTime));
                dt.Columns.Add("Description", typeof(string));
                dt.Columns.Add("AmountPaid",typeof(decimal));
                dt.Columns.Add("DebentureInterest",typeof(decimal));
                dt.Columns.Add("DebentureInterestCalc",typeof(decimal));
                dt.Columns.Add("DebentureInterestRate",typeof(decimal));
                dt.Columns.Add("ClaimTypeID",typeof(long));
                dt.Columns.Add("EnteredDate",typeof(DateTime));
                dt.Columns.Add("EnteredByUser",typeof(int));
                dt.Columns.Add("LastUpdateDate",typeof(DateTime));
                dt.Columns.Add("LastUpdateUser",typeof(int));

                con.ConnectionString = _settings.GetConnectionString("HUDClaims");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_HUDClaimsSQLDatabase;
                cmd.CommandText = "usp_HUDCLaims_Select_FHA_Block309_ByDid";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter();
                parm = new SqlParameter("@PartD27011ID", PartD27011ID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["SpecialAssessmentsID"]=dr["SpecialAssessmentsID"];
                    row["PartD27011ID"]=dr["PartD27011ID"];
                    row["DatePaid"]=dr["DatePaid"];
                    row["DateLienAttached"]=dr["DateLienAttached"];
                    row["Description"]=dr["Description"];
                    row["AmountPaid"]=dr["AmountPaid"];
                    row["DebentureInterest"]=dr["DebentureInterest"];
                    row["DebentureInterestCalc"]=dr["DebentureInterestCalc"];
                    row["DebentureInterestRate"]=dr["DebentureInterestRate"];
                    row["ClaimTypeID"]=dr["ClaimTypeID"];
                    row["EnteredDate"]=dr["EnteredDate"];
                    row["EnteredByUser"]=dr["EnteredByUser"];
                    row["LastUpdateDate"]=dr["LastUpdateDate"];
                    row["LastUpdateUser"]=dr["LastUpdateUser"];

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="PartD27011ID"></param>
        /// <returns></returns>
        internal DataTable usp_HUDCLaims_Select_Block311_ByDid(long PartD27011ID)
        {
            SqlConnection con = new SqlConnection();

            try
            {

                DataTable dt = new DataTable("PartDBlock311");
                dt.Columns.Add("MIPremiumID",typeof(long));
                dt.Columns.Add("PartD27011ID",typeof(long));
                dt.Columns.Add("DatePaid",typeof(DateTime));
                dt.Columns.Add("PeriodCoveredFrom",typeof(DateTime));
                dt.Columns.Add("PeriodCoveredTo",typeof(DateTime));
                dt.Columns.Add("AmountPaid",typeof(decimal));
                dt.Columns.Add("DebentureInterest",typeof(decimal));
                dt.Columns.Add("DebentureInterestCalc",typeof(decimal));
                dt.Columns.Add("DebentureInterestRate",typeof(decimal));
                dt.Columns.Add("ClaimTypeID",typeof(long));
                dt.Columns.Add("EnteredDate",typeof(DateTime));
                dt.Columns.Add("EnteredByUser",typeof(int));
                dt.Columns.Add("LastUpdateDate",typeof(DateTime));
                dt.Columns.Add("LastUpdateUser",typeof(int));

                con.ConnectionString = _settings.GetConnectionString("HUDClaims");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_HUDClaimsSQLDatabase;
                cmd.CommandText = "usp_HUDCLaims_Select_FHA_Block311_ByDid";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter();
                parm = new SqlParameter("@PartD27011ID", PartD27011ID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["MIPremiumID"]=dr["MIPremiumID"];
                    row["PartD27011ID"]=dr["PartD27011ID"];
                    row["DatePaid"]=dr["DatePaid"];
                    row["PeriodCoveredFrom"]=dr["PeriodCoveredFrom"];
                    row["PeriodCoveredTo"]=dr["PeriodCoveredTo"];
                    row["AmountPaid"]=dr["AmountPaid"];
                    row["DebentureInterest"]=dr["DebentureInterest"];
                    row["DebentureInterestCalc"]=dr["DebentureInterestCalc"];
                    row["DebentureInterestRate"]=dr["DebentureInterestRate"];
                    row["ClaimTypeID"]=dr["ClaimTypeID"];
                    row["EnteredDate"]=dr["EnteredDate"];
                    row["EnteredByUser"]=dr["EnteredByUser"];
                    row["LastUpdateDate"]=dr["LastUpdateDate"];
                    row["LastUpdateUser"]=dr["LastUpdateUser"];

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FHAClaimID"></param>
        /// <returns></returns>
        internal DataTable HUDClaims_VW_PartE_SelectByClaimID(int FHAClaimID)
        {
            SqlConnection con = new SqlConnection();

            try
            {

                DataTable dt = new DataTable("PartEVW");
                dt.Columns.Add("ClaimTypeID",typeof(long));
                dt.Columns.Add("MortgagorFirstName",typeof(string));
                dt.Columns.Add("MortgagorMiddleName",typeof(string));
                dt.Columns.Add("MortgagorLastName",typeof(string));
                dt.Columns.Add("PropertyAddress1",typeof(string));
                dt.Columns.Add("PropertyAddress2",typeof(string));
                dt.Columns.Add("PropertyCity",typeof(string));
                dt.Columns.Add("PropertyStateCode",typeof(string));
                dt.Columns.Add("PropertyZipCode",typeof(string));
                dt.Columns.Add("FHACaseNumber",typeof(string));
                dt.Columns.Add("MortgageeLoanNumber",typeof(string));
                dt.Columns.Add("PartE27011ID",typeof(long));
                dt.Columns.Add("FHAClaimID",typeof(long));
                dt.Columns.Add("DateFormPrepared",typeof(DateTime));
                dt.Columns.Add("ClientName",typeof(string));
                dt.Columns.Add("SectionOfActCode",typeof(string));
                dt.Columns.Add("DebentureInterestRate",typeof(decimal));
                dt.Columns.Add("MortgageeName",typeof(string));
                dt.Columns.Add("ServicerName",typeof(string));
                dt.Columns.Add("EnteredDate",typeof(DateTime));
                dt.Columns.Add("EnteredByUser",typeof(int));
                dt.Columns.Add("LastUpdateDate",typeof(DateTime));
                dt.Columns.Add("LastUpdateUser",typeof(int));

                con.ConnectionString = _settings.GetConnectionString("HUDClaims");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_HUDClaimsSQLDatabase;
                cmd.CommandText = "usp_HUDCLaims_vw_PartE_SelectBy_ClaimID";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter();
                parm = new SqlParameter("@FHAClaimID", FHAClaimID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ClaimTypeID"]=dr["ClaimTypeID"];
                    row["MortgagorFirstName"]=dr["MortgagorFirstName"];
                    row["MortgagorMiddleName"]=dr["MortgagorMiddleName"];
                    row["MortgagorLastName"]=dr["MortgagorLastName"];
                    row["PropertyAddress1"]=dr["PropertyAddress1"];
                    row["PropertyAddress2"]=dr["PropertyAddress2"];
                    row["PropertyCity"]=dr["PropertyCity"];
                    row["PropertyStateCode"]=dr["PropertyStateCode"];
                    row["PropertyZipCode"]=dr["PropertyZipCode"];
                    row["FHACaseNumber"]=dr["FHACaseNumber"];
                    row["MortgageeLoanNumber"]=dr["MortgageeLoanNumber"];
                    row["PartE27011ID"]=dr["PartE27011ID"];
                    row["FHAClaimID"]=dr["FHAClaimID"];
                    row["DateFormPrepared"]=dr["DateFormPrepared"];
                    row["ClientName"]=dr["ClientName"];
                    row["SectionOfActCode"]=dr["SectionOfActCode"];
                    row["DebentureInterestRate"]=dr["DebentureInterestRate"];
                    row["MortgageeName"]=dr["MortgageeName"];
                    row["ServicerName"]=dr["ServicerName"];
                    row["EnteredDate"]=dr["EnteredDate"];
                    row["EnteredByUser"]=dr["EnteredByUser"];
                    row["LastUpdateDate"]=dr["LastUpdateDate"];
                    row["LastUpdateUser"]=dr["LastUpdateUser"];

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="FHACaseNo"></param>
        /// <returns></returns>
        internal DataTable HUDClaims_VW_PartE_Select(string FHACaseNo)
        {
            SqlConnection con = new SqlConnection();

            try
            {

                DataTable dt = new DataTable("PartEVW");
                dt.Columns.Add("ClaimTypeID",typeof(long));
                dt.Columns.Add("MortgagorFirstName",typeof(string));
                dt.Columns.Add("MortgagorMiddleName",typeof(string));
                dt.Columns.Add("MortgagorLastName",typeof(string));
                dt.Columns.Add("PropertyAddress1",typeof(string));
                dt.Columns.Add("PropertyAddress2",typeof(string));
                dt.Columns.Add("PropertyCity",typeof(string));
                dt.Columns.Add("PropertyStateCode",typeof(string));
                dt.Columns.Add("PropertyZipCode",typeof(string));
                dt.Columns.Add("FHACaseNumber",typeof(string));
                dt.Columns.Add("MortgageeLoanNumber",typeof(string));
                dt.Columns.Add("PartE27011ID",typeof(long));
                dt.Columns.Add("FHAClaimID",typeof(long));
                dt.Columns.Add("DateFormPrepared",typeof(DateTime));
                dt.Columns.Add("ClientName",typeof(string));
                dt.Columns.Add("SectionOfActCode",typeof(string));
                dt.Columns.Add("DebentureInterestRate",typeof(decimal));
                dt.Columns.Add("MortgageeName",typeof(string));
                dt.Columns.Add("ServicerName",typeof(string));
                dt.Columns.Add("EnteredDate",typeof(DateTime));
                dt.Columns.Add("EnteredByUser",typeof(int));
                dt.Columns.Add("LastUpdateDate",typeof(DateTime));
                dt.Columns.Add("LastUpdateUser",typeof(int));

                con.ConnectionString = _settings.GetConnectionString("HUDClaims");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_HUDClaimsSQLDatabase;
                cmd.CommandText = "usp_HUDCLaims_vw_PartE_SelectBy_CaseNo";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter();
                parm = new SqlParameter("@FHACaseNo", FHACaseNo);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ClaimTypeID"]=dr["ClaimTypeID"];
                    row["MortgagorFirstName"]=dr["MortgagorFirstName"];
                    row["MortgagorMiddleName"]=dr["MortgagorMiddleName"];
                    row["MortgagorLastName"]=dr["MortgagorLastName"];
                    row["PropertyAddress1"]=dr["PropertyAddress1"];
                    row["PropertyAddress2"]=dr["PropertyAddress2"];
                    row["PropertyCity"]=dr["PropertyCity"];
                    row["PropertyStateCode"]=dr["PropertyStateCode"];
                    row["PropertyZipCode"]=dr["PropertyZipCode"];
                    row["FHACaseNumber"]=dr["FHACaseNumber"];
                    row["MortgageeLoanNumber"]=dr["MortgageeLoanNumber"];
                    row["PartE27011ID"]=dr["PartE27011ID"];
                    row["FHAClaimID"]=dr["FHAClaimID"];
                    row["DateFormPrepared"]=dr["DateFormPrepared"];
                    row["ClientName"]=dr["ClientName"];
                    row["SectionOfActCode"]=dr["SectionOfActCode"];
                    row["DebentureInterestRate"]=dr["DebentureInterestRate"];
                    row["MortgageeName"]=dr["MortgageeName"];
                    row["ServicerName"]=dr["ServicerName"];
                    row["EnteredDate"]=dr["EnteredDate"];
                    row["EnteredByUser"]=dr["EnteredByUser"];
                    row["LastUpdateDate"]=dr["LastUpdateDate"];
                    row["LastUpdateUser"]=dr["LastUpdateUser"];

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="partEid"></param>
        /// <returns></returns>
        internal DataTable HUDClaims_PartE_Multiblock_SelectBy_PartEid(long partEid)
        {
            SqlConnection con = new SqlConnection();

            try
            {

                DataTable dt = new DataTable("PartEBlocks");
                dt.Columns.Add("BlockCode",typeof(string));
                dt.Columns.Add("Description",typeof(string));
                dt.Columns.Add("AmountPaid",typeof(decimal));

                con.ConnectionString = _settings.GetConnectionString("HUDClaims");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_HUDClaimsSQLDatabase;
                cmd.CommandText = "usp_HUDClaims_PartE_Multiblock_SelectBy_PartEid";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter();
                parm = new SqlParameter("@PartE27011ID", partEid);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["BlockCode"]=dr["BlockCode"];
                    row["Description"]=dr["Description"];
                    row["AmountPaid"]=dr["AmountPaid"];

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }
        #endregion
    }
}
