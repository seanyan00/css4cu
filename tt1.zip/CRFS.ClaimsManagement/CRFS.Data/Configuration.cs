﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CRFS.Data
{
    internal class Configuration
    {
        static public int CommandTimeouts_General_ApplicationConfigurationSQLDatabase = 60;
        static public int CommandTimeouts_GeneralDataAutomationSQLDatabase = 60; 
        static public int CommandTimeouts_General_ClaimsManagementSQLDatabase = 60;
        static public int CommandTimeouts_General_HUDClaimsSQLDatabase = 60;
        static public int CommandTimeouts_Extra_ClaimsManagementSQLDatabase = 120;
        static public int CommandTimeouts_General_AppsDB_FNMASQLDatabase = 60;
        static public int CommandTimeouts_Extra_AppsDB_FNMASQLDatabase = 120;
    }
}
