﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;

namespace CRFS.Data
{
    class FNMAReferralDataAccess
    {
        CRFS.Data.Settings _settings;

        /// <summary>
        /// Default Constructor - should not be used
        /// </summary>
        internal FNMAReferralDataAccess()
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="settings"></param>
        internal FNMAReferralDataAccess(CRFS.Data.Settings settings)
        {
            _settings = settings;

        }

        #region "Common FNMA Application Routines"
        /// <summary>
        /// Returns a table of Group, User, and email signature block info
        /// </summary>
        /// <param name="FormID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GroupEmailSignatures_Get(int FormID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

            }
            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("EntityGroups");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("UserEmailSignatureID", typeof(int));
                dt.Columns.Add("Group_UserAssignedID", typeof(int));
                dt.Columns.Add("GroupID", typeof(int));
                dt.Columns.Add("FormID", typeof(int));
                dt.Columns.Add("GroupName", typeof(string));
                dt.Columns.Add("UserID", typeof(int));
                dt.Columns.Add("UserName", typeof(string));
                dt.Columns.Add("UserEmailAddress", typeof(string));
                dt.Columns.Add("Line1", typeof(string));
                dt.Columns.Add("Line2", typeof(string));
                dt.Columns.Add("Line3", typeof(string));
                dt.Columns.Add("Line4", typeof(string));
                dt.Columns.Add("Line5", typeof(string));
                dt.Columns.Add("Line6", typeof(string));
                dt.Columns.Add("Line7", typeof(string));
                dt.Columns.Add("Line8", typeof(string));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_Group_UserAssigned_Signature_Select";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter("@FormID", FormID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["UserEmailSignatureID"] = int.Parse(dr["UserEmailSignatureID"].ToString().Length == 0 ? "0" : dr["UserEmailSignatureID"].ToString());
                    row["Group_UserAssignedID"] = int.Parse(dr["Group_UserAssignedID"].ToString().Length == 0 ? "0" : dr["Group_UserAssignedID"].ToString());
                    row["GroupID"] = int.Parse(dr["GroupID"].ToString().Length == 0 ? "0" : dr["GroupID"].ToString());
                    row["FormID"] = int.Parse(dr["FormID"].ToString().Length == 0 ? "0" : dr["FormID"].ToString());
                    row["GroupName"] = dr["GroupName"].ToString();
                    row["UserID"] = int.Parse(dr["UserID"].ToString().Length == 0 ? "0" : dr["UserID"].ToString());
                    row["UserName"] = dr["UserName"].ToString();
                    row["UserEmailAddress"] = dr["UserEmailAddress"].ToString();
                    row["Line1"] = dr["Line1"].ToString();
                    row["Line2"] = dr["Line2"].ToString();
                    row["Line3"] = dr["Line3"].ToString();
                    row["Line4"] = dr["Line4"].ToString();
                    row["Line5"] = dr["Line5"].ToString();
                    row["Line6"] = dr["Line6"].ToString();
                    row["Line7"] = dr["Line7"].ToString();
                    row["Line8"] = dr["Line8"].ToString();

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// read in the xref_GroupUserAssigned table
        /// </summary>
        /// <param name="settings"></param>
        /// <returns>the datatable</returns>
        internal DataTable UserAssignedToGroup_Select(Settings settings)
        {
            // gk 20130920 t-13987 
            DataTable ret = new DataTable("xref_GroupUserAssigned");
            ret.Columns.Add("Group_UserAssignedID", typeof(int));
            ret.Columns.Add("GroupID", typeof(int));
            ret.Columns.Add("UserID", typeof(int));
            ret.Columns.Add("FormID", typeof(int));
            SqlConnection con = new SqlConnection();
            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_GroupUserAssigned_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = ret.NewRow();
                    row["Group_UserAssignedID"] = dr["Group_UserAssignedID"];
                    row["GroupID"] = dr["GroupID"];
                    row["UserID"] = dr["UserID"];
                    row["FormID"] = dr["FormID"];
                    ret.Rows.Add(row);
                }
                ret.AcceptChanges();
                return ret;
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }


        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool UserAssignedToGroup_Save(DataTable dt, Settings settings)
        {
            SqlConnection con = new SqlConnection();
            bool rtnValue = false;

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

            }
            catch (Exception e)
            {
                throw e;

            }

            try
            {
                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.Connection = con;

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    switch (dt.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            cmd.CommandText = "usp_GroupUserAssigned_Insert";

                            parm = new SqlParameter("@GroupID", dt.Rows[i]["GroupID"]);
                            cmd.Parameters.Add(parm);

                            parm = new SqlParameter("@UserID", dt.Rows[i]["UserID"]);
                            cmd.Parameters.Add(parm);
                            
                            parm = new SqlParameter("@FormID", dt.Rows[i]["FormID"]);
                            cmd.Parameters.Add(parm);

                            //Now we need to execute a stored procedure that returns the new record ID
                            dt.Rows[i]["Group_UserAssignedID"] = int.Parse(cmd.ExecuteScalar().ToString());
                            
                            goto NextRecord;

                        case DataRowState.Deleted:
                            cmd.CommandText = "usp_GroupUserAssigned_Delete";

                            parm = new SqlParameter("@Group_UserAssignedID", dt.Rows[i]["Group_UserAssignedID", DataRowVersion.Original]);
                            cmd.Parameters.Add(parm);

                            break;

                        case DataRowState.Modified:
                            cmd.CommandText = "usp_GroupUserAssigned_Update";

                            parm = new SqlParameter("@Group_UserAssignedID", dt.Rows[i]["Group_UserAssignedID"]);
                            cmd.Parameters.Add(parm);

                            parm = new SqlParameter("@GroupID", dt.Rows[i]["GroupID"]);
                            cmd.Parameters.Add(parm);

                            parm = new SqlParameter("@UserID", dt.Rows[i]["UserID"]);
                            cmd.Parameters.Add(parm);
                            
                            parm = new SqlParameter("@FormID", dt.Rows[i]["FormID"]);
                            cmd.Parameters.Add(parm);

                            break;

                        default:
                            goto NextRecord;

                    }
                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;

                }

                dt.AcceptChanges();

                rtnValue = true;

                return rtnValue;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        internal bool UserEmailSignature_Save(DataTable dt, Settings settings)
        {
            SqlConnection con = new SqlConnection();
            bool rtnValue = false;

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

            }
            catch (Exception e)
            {
                throw e;

            }

            try
            {
                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.Connection = con;

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    switch (dt.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            cmd.CommandText = "usp_UserEmailSignature_Insert";

                            parm = new SqlParameter("@UserID", dt.Rows[i]["UserID"]);
                            cmd.Parameters.Add(parm);

                            parm = new SqlParameter("@Line1", dt.Rows[i]["Line1"]);
                            cmd.Parameters.Add(parm);

                            parm = new SqlParameter("@Line2", dt.Rows[i]["Line2"]);
                            cmd.Parameters.Add(parm);

                            parm = new SqlParameter("@Line3", dt.Rows[i]["Line3"]);
                            cmd.Parameters.Add(parm);

                            parm = new SqlParameter("@Line4", dt.Rows[i]["Line4"]);
                            cmd.Parameters.Add(parm);

                            parm = new SqlParameter("@Line5", dt.Rows[i]["Line5"]);
                            cmd.Parameters.Add(parm);

                            parm = new SqlParameter("@Line6", dt.Rows[i]["Line6"]);
                            cmd.Parameters.Add(parm);

                            parm = new SqlParameter("@Line7", dt.Rows[i]["Line7"]);
                            cmd.Parameters.Add(parm);

                            parm = new SqlParameter("@Line8", dt.Rows[i]["Line8"]);
                            cmd.Parameters.Add(parm);


                            //Now we need to execute a stored procedure that returns the new record ID
                            dt.Rows[i]["UserEmailSignatureID"] = int.Parse(cmd.ExecuteScalar().ToString());
                            
                            goto NextRecord;

                        // deleted not implimented yet
                        //case DataRowState.Deleted:
                        //    cmd.CommandText = "usp_GroupUserAssigned_Delete";

                        //    parm = new SqlParameter("@Group_UserAssignedID", dt.Rows[i]["Group_UserAssignedID", DataRowVersion.Original]);
                        //    cmd.Parameters.Add(parm);

                        //    break;

                        case DataRowState.Modified:
                            cmd.CommandText = "usp_UserEmailSignature_Update";

                            parm = new SqlParameter("@UserID", dt.Rows[i]["UserID"]);
                            cmd.Parameters.Add(parm);

                            parm = new SqlParameter("@Line1", dt.Rows[i]["Line1"]);
                            cmd.Parameters.Add(parm);

                            parm = new SqlParameter("@Line2", dt.Rows[i]["Line2"]);
                            cmd.Parameters.Add(parm);

                            parm = new SqlParameter("@Line3", dt.Rows[i]["Line3"]);
                            cmd.Parameters.Add(parm);

                            parm = new SqlParameter("@Line4", dt.Rows[i]["Line4"]);
                            cmd.Parameters.Add(parm);

                            parm = new SqlParameter("@Line5", dt.Rows[i]["Line5"]);
                            cmd.Parameters.Add(parm);

                            parm = new SqlParameter("@Line6", dt.Rows[i]["Line6"]);
                            cmd.Parameters.Add(parm);

                            parm = new SqlParameter("@Line7", dt.Rows[i]["Line7"]);
                            cmd.Parameters.Add(parm);

                            parm = new SqlParameter("@Line8", dt.Rows[i]["Line8"]);
                            cmd.Parameters.Add(parm);

                            recordsAffected = cmd.ExecuteNonQuery();


                            break;

                        default:
                            goto NextRecord;

                    }
                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;

                }

                dt.AcceptChanges();

                rtnValue = true;

                return rtnValue;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        #endregion

        #region "FNMA PFU"

        /// <summary>
        /// 
        /// </summary>
        /// <param name="SearchValue"></param>
        /// <returns></returns>
        internal DataTable searchFNMAPFU_ByLoanNumberREOID(string SearchValue)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable("Claims");

                dt.Columns.Add("ReferralID", typeof(int));
                dt.Columns.Add("REO_ID", typeof(string));
                dt.Columns.Add("FNMALoanNumber", typeof(string));
                dt.Columns.Add("ClientName", typeof(string));
                dt.Columns.Add("ReferralTypeID", typeof(int));
                dt.Columns.Add("ReferralType", typeof(string));
                dt.Columns.Add("ClaimEligibleDate", typeof(DateTime));
                dt.Columns.Add("FollowUpDate", typeof(DateTime));
                dt.Columns.Add("OpenSteps", typeof(int));
                dt.Columns.Add("ClaimFormID", typeof(int));
                dt.Columns.Add("FormName", typeof(string));
                dt.Columns.Add("PropertyAddress", typeof(string));
                dt.Columns.Add("PropertyCity", typeof(string));
                dt.Columns.Add("PropertyState", typeof(string));
                dt.Columns.Add("PropertyZip", typeof(string));

                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_CNTL_FNMAPFU_FindReferral_ByLoanNumberREOID";

                SqlParameter parm = new SqlParameter("@SearchValue", SearchValue);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ReferralID"] = int.Parse(dr["ReferralID"].ToString().Length == 0 ? "0" : dr["ReferralID"].ToString());
                    row["REO_ID"] = dr["REO_ID"].ToString();
                    row["FNMALoanNumber"] = dr["FNMALoanNumber"].ToString(); 
                    row["ClientName"] = dr["ClientName"].ToString();
                    row["ReferralTypeID"] = int.Parse(dr["ReferralTypeID"].ToString().Length == 0 ? "0" : dr["ReferralTypeID"].ToString());
                    row["ReferralType"] = dr["ReferralType"].ToString();
                    row["ClaimEligibleDate"] = DateTime.Parse(dr["ClaimEligibleDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClaimEligibleDate"].ToString());
                    row["FollowUpDate"] = DateTime.Parse(dr["FollowUpDate"].ToString().Length == 0 ? "1/1/1900" : dr["FollowUpDate"].ToString());
                    row["OpenSteps"] = int.Parse(dr["OpenSteps"].ToString().Length == 0 ? "0" : dr["OpenSteps"].ToString());
                    row["ClaimFormID"] = int.Parse(dr["ClaimFormID"].ToString().Length == 0 ? "0" : dr["ClaimFormID"].ToString());
                    row["FormName"] = dr["FormName"].ToString();
                    row["PropertyAddress"] = dr["PropertyAddress"].ToString();
                    row["PropertyCity"] = dr["PropertyCity"].ToString();
                    row["PropertyState"] = dr["PropertyState"].ToString();
                    row["PropertyZip"] = dr["PropertyZip"].ToString();

                    dt.Rows.Add(row);

                }

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        #endregion

        #region "FNMA Recon"
        
        #endregion

        
        #region "FNMA AdvPayment"

        internal DataTable AdvPmt_GetGroupSignatures(string groupName, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("FNMAApps");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("Signatures");

                dt.Columns.Add("Name", typeof(string));
                dt.Columns.Add("Title", typeof(string));
                dt.Columns.Add("CRFSName", typeof(string));
                dt.Columns.Add("StreetAddress", typeof(string));
                dt.Columns.Add("CityStateZip", typeof(string));
                dt.Columns.Add("Phone", typeof(string));
                dt.Columns.Add("Fax", typeof(string));
                dt.Columns.Add("Email", typeof(string));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_FNMA_AdvPmt_UserEmailSignature_GetByServicerGroupName";
                cmd.Connection = con;
                cmd.Parameters.Add(new SqlParameter("@strServicerGroupName", groupName));

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["Name"] = dr["Name"].ToString();
                    row["Title"] = dr["Title"].ToString();
                    row["CRFSName"] = dr["CRFSName"].ToString();
                    row["StreetAddress"] = dr["StreetAddress"].ToString();
                    row["CityStateZip"] = dr["CityStateZip"].ToString();
                    row["Phone"] = dr["Phone"].ToString();
                    row["Fax"] = dr["Fax"].ToString();
                    row["Email"] = dr["Email"].ToString();
                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        internal DataTable AdvPmt_ServicerEmails_Get(Settings settings,string group)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("FNMAApps");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("ServicerEmails");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("ContactName", typeof(string));
                dt.Columns.Add("EmailAddress", typeof(string));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_FNMA_AdvPmt_EntityGroupContacts_GetByServicerGroupName";
                cmd.Connection = con;
                cmd.Parameters.Add(new SqlParameter("@strServicerGroupName", group));

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ContactName"] = dr["ContactName"].ToString();
                    row["EmailAddress"] = dr["EmailAddress"].ToString();
                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        internal void AdvPmt_SetReferralInvoiced(DataTable data, int updateUser, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("FNMAApps");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_FNMA_AdvPmt_Referral_CompleteInvoiceStatus";
                cmd.Connection = con;
                cmd.Parameters.Add(new SqlParameter("@referralID", 0));
                cmd.Parameters.Add(new SqlParameter("@ReferralStatusDescription", "Invoiced"));
                cmd.Parameters.Add(new SqlParameter("@UserID", updateUser));
                foreach (DataRow dr in data.Rows)
                {
                    cmd.Parameters.RemoveAt("@referralID");
                    cmd.Parameters.Add(new SqlParameter("@referralID", dr["referralID"]));
                    cmd.ExecuteScalar();
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }

        }
        internal void AdvPmt_JobDone(Settings settings,int ID,bool success,string errMsg,DateTime endDate,string emailAddr,string attachment)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("FNMAApps");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("ServicerEmails");
                DataColumn dc = new DataColumn();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_FNMA_AdvPmt_JobHistory_UpdateJobsThatRan";
                cmd.Connection = con;
                cmd.Parameters.Add(new SqlParameter("@intHistoryID" , ID));
                cmd.Parameters.Add(new SqlParameter("@bitWasSuccessful", success));
                cmd.Parameters.Add(new SqlParameter("@vcrErrorMessage", errMsg));
                cmd.Parameters.Add(new SqlParameter("@dtEndDate", endDate));
                cmd.Parameters.Add(new SqlParameter("@vcrEmailAddress", emailAddr));
                cmd.Parameters.Add(new SqlParameter("@vcrAttachmentPath", attachment));
                cmd.ExecuteScalar();
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        internal DataTable AdvPmt_InvoiceData_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("FNMAApps");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                // columns in table: HistoryID,JobID,ReferralID,DisbursementID,GroupName,Servicer Name,FNMA Loan #,Servicer Loan #,Disbursement Type,Disbursement Date,571 Paid To,Billing Amount,Initial Billing Date,Rebuttal Affirmation Date,Due Date,Number of Days Past Due Date,60 Days Outstanding from Due Date,90 Days Outstanding from Due Date,Billing Reason,FNMA Comments,Date of FNMA Comment,Servicer Comments,Date of Servicer Comment,Status of Invoice);
                
                DataTable dt = new DataTable("DG_InvoiceData");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("HistoryID",typeof(int));
                dt.Columns.Add("JobID",typeof(int));
                dt.Columns.Add("ReferralID",typeof(int));
                dt.Columns.Add("DisbursementID",typeof(int));
                dt.Columns.Add("GroupName",typeof(string));
                dt.Columns.Add("Servicer Name",typeof(string));
                dt.Columns.Add("FNMA Loan #",typeof(string));
                dt.Columns.Add("Servicer Loan #",typeof(string));
                dt.Columns.Add("Disbursement Type",typeof(string));
                dt.Columns.Add("Disbursement Date", typeof(string));         // was datetime, but the formatting is already handled and we don't need to know the date
                dt.Columns.Add("571 Paid To",typeof(string));
                dt.Columns.Add("Billing Amount",typeof(decimal));
                dt.Columns.Add("Initial Billing Date",typeof(string));       // was datetime, but the formatting is already handled and we don't need to know the date
                dt.Columns.Add("Rebuttal Affirmation Date",typeof(string));  // was datetime, but the formatting is already handled and we don't need to know the date
                dt.Columns.Add("Due Date",typeof(DateTime)).AllowDBNull=true;
                dt.Columns.Add("Number of Days Past Due Date",typeof(int));
                dt.Columns.Add("60 Days Outstanding from Due Date",typeof(string));
                dt.Columns.Add("90 Days Outstanding from Due Date",typeof(string));
                dt.Columns.Add("Billing Reason",typeof(string));
                dt.Columns.Add("FNMA Comments",typeof(string));
                dt.Columns.Add("Date of FNMA Comment",typeof(string));
                dt.Columns.Add("Servicer Comments",typeof(string));
                dt.Columns.Add("Date of Servicer Comment",typeof(string));   // was datetime, but the formatting is already handled and we don't need to know the date
                dt.Columns.Add("Status of Invoice",typeof(string));
                // fill above in when we see exactly what is in table

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_FNMA_AdvPmt_InvoiceData_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["HistoryID"]=dr["HistoryID"];
                    row["JobID"]=dr["JobID"];
                    row["ReferralID"]=dr["ReferralID"];
                    row["DisbursementID"]=dr["DisbursementID"];
                    row["GroupName"]=dr["GroupName"];
                    row["Servicer Name"]=dr["Servicer Name"];
                    row["FNMA Loan #"]=dr["FNMA Loan #"];
                    row["Servicer Loan #"]=dr["Servicer Loan #"];
                    row["Disbursement Type"]=dr["Disbursement Type"];
                    row["Disbursement Date"]=dr["Disbursement Date"];
                    row["571 Paid To"]=dr["571 Paid To"];
                    row["Billing Amount"]=dr["Billing Amount"];
                    row["Initial Billing Date"]=dr["Initial Billing Date"];
                    row["Rebuttal Affirmation Date"]=dr["Rebuttal Affirmation Date"];
                    row["Due Date"]=dr["Due Date"];
                    row["Number of Days Past Due Date"]=dr["Number of Days Past Due Date"];
                    row["60 Days Outstanding from Due Date"]=dr["60 Days Outstanding from Due Date"];
                    row["90 Days Outstanding from Due Date"]=dr["90 Days Outstanding from Due Date"];
                    row["Billing Reason"]=dr["Billing Reason"];
                    row["FNMA Comments"]=dr["FNMA Comments"];
                    row["Date of FNMA Comment"]=dr["Date of FNMA Comment"];
                    row["Servicer Comments"]=dr["Servicer Comments"];
                    row["Date of Servicer Comment"]=dr["Date of Servicer Comment"];
                    row["Status of Invoice"]=dr["Status of Invoice"];

                    dt.Rows.Add(row);
                }

               
                // do it as above once we have the complete table
                /*
                DataTable dt = new DataTable("AdvPmtData");
                dt.Load(dr);
                String names = String.Join(",",dt.Columns.Cast<DataColumn>().Select(x => x.ColumnName+"|"+x.DataType.ToString()).ToArray());
                */
                
                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
        #endregion
    }
}
