﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;


namespace CRFS.Data
{
    internal static class ErrorDataDump
    {
        static internal void DumpTableToDefaultLocation(DataTable dt, string fileLocation)
        {
            try
            {
                if (fileLocation.Trim().Length == 0)
                {
                    fileLocation = Environment.CurrentDirectory;
                }
                string fileName = fileLocation;
                string curDateTime = DateTime.Today.Year.ToString() + (DateTime.Today.Month.ToString().Length == 1 ? "0" + DateTime.Today.Month.ToString() : DateTime.Today.Month.ToString());
                curDateTime += (DateTime.Today.Day.ToString().Length == 1 ? "0" + DateTime.Today.Day.ToString() : DateTime.Today.Day.ToString()) + (DateTime.Now.Hour.ToString().Length == 1 ? "0" + DateTime.Now.Hour.ToString() : DateTime.Now.Hour.ToString());
                curDateTime += (DateTime.Now.Minute.ToString().Length == 1 ? "0" + DateTime.Now.Minute.ToString() : DateTime.Now.Minute.ToString()) + (DateTime.Now.Second.ToString().Length == 1 ? "0" + DateTime.Now.Second.ToString() : DateTime.Now.Second.ToString());
                fileName += curDateTime + ".txt";

                FileHandling.FileIO fio = new FileHandling.FileIO();
 
                if(fio.TabFile_SaveDataTable(dt,fileName,true))
                {
                    //Do not do anything
                }
            }
            catch (Exception e)
            {
                //As this is error recovery, we will not throw any errors
            }

        }

    }
    
}
