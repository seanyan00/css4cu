﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CRFS.Data
{
    // This class allows you to handle specific events on the settings class:
    //  The SettingChanging event is raised before a setting's value is changed.
    //  The PropertyChanged event is raised after a setting's value is changed.
    //  The SettingsLoaded event is raised after the setting values are loaded.
    //  The SettingsSaving event is raised before the setting values are saved.
    internal class Settings
    {
        string _appMode;
        int _appID; //using appID instead of FormID.  Sometime, this should swith over to an application ID.
        public DataConnectionFabricator.ConnectionBuilder conn;

        public int FormID
        {
            get { return _appID; }
            set { _appID = value; }

        }

        public Settings(string appMode)
        {
            _appMode = appMode;
            conn = new DataConnectionFabricator.ConnectionBuilder(appMode);
            // // To add event handlers for saving and changing settings, uncomment the lines below:
            //
            // this.SettingChanging += this.SettingChangingEventHandler;
            //
            // this.SettingsSaving += this.SettingsSavingEventHandler;
            //
        }

        internal string AddPWToConnString(string connectionString)
        {
            return connectionString += ";Password=~tempasn0activ3directory";
        }
                
        public string GetConnectionString(string databaseName)
        {
            return conn.GetConnectionString(databaseName);
        }

        public string Get_appmode()
        {
            return _appMode;
        }

        private void SettingChangingEventHandler(object sender, System.Configuration.SettingChangingEventArgs e)
        {
            // Add code to handle the SettingChangingEvent event here.
        }

        private void SettingsSavingEventHandler(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Add code to handle the SettingsSaving event here.
        }

    }
}
