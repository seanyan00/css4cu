﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace CRFS.Data
{
    class MossAutomation
    {
        CRFS.Data.Settings _settings;

        internal MossAutomation(CRFS.Data.Settings settings)
        {
            _settings = settings;

        }

        #region "Data Automation Reporting"
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="StartDate"></param>
        /// <param name="EndDate"></param>
        /// <returns></returns>
        internal DataTable GetSFDMS_MIC_ExecutionData(DateTime StartDate, DateTime EndDate)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable("ReportData");

                dt.Columns.Add("Client", typeof(string));
                dt.Columns.Add("CaseNumber", typeof(string));
                dt.Columns.Add("LoanNumber", typeof(string));
                dt.Columns.Add("ClientID", typeof(string));
                dt.Columns.Add("ClaimType", typeof(string));
                dt.Columns.Add("ProcessStatus", typeof(string));
                dt.Columns.Add("DateEntered", typeof(DateTime));
                dt.Columns.Add("ProcessDate", typeof(DateTime));
                dt.Columns.Add("ProcessLastUpdateDate", typeof(DateTime));
                dt.Columns.Add("ProcessCompleteDate", typeof(DateTime));
                dt.Columns.Add("ProcessID", typeof(int));
                dt.Columns.Add("SFDMS_CaptureDate", typeof(DateTime));
                dt.Columns.Add("SFDMS_ImageSize", typeof(int));
                dt.Columns.Add("MIC_CaptureDate", typeof(DateTime));
                dt.Columns.Add("MIC_ImageSize", typeof(int));

                con.ConnectionString = _settings.GetConnectionString("MossAutomation");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_SFDMS_MIC_Execution_Report";

                SqlParameter prm = new SqlParameter("@StartDate", StartDate);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@EndDate", EndDate);
                cmd.Parameters.Add(prm);

                cmd.Connection = con;

                SqlDataReader rdr = cmd.ExecuteReader();

                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        DataRow dr = dt.NewRow();

                        dr["Client"] = rdr["Client"].ToString();
                        dr["CaseNumber"] = rdr["CaseNumber"].ToString();
                        dr["LoanNumber"] = rdr["LoanNumber"].ToString();
                        dr["ClientID"] = rdr["ClientID"].ToString();
                        dr["ClaimType"] = rdr["ClaimType"].ToString();
                        dr["ProcessStatus"] = rdr["ProcessStatus"].ToString();
                        dr["DateEntered"] = DateTime.Parse(rdr["DateEntered"].ToString());
                        dr["ProcessDate"] = DateTime.Parse(rdr["ProcessDate"].ToString());
                        dr["ProcessLastUpdateDate"] = DateTime.Parse(rdr["ProcessLastUpdateDate"].ToString());
                        dr["ProcessCompleteDate"] = DateTime.Parse(rdr["ProcessCompleteDate"].ToString());
                        dr["ProcessID"] = int.Parse(rdr["ProcessID"].ToString());
                        dr["SFDMS_CaptureDate"] = DateTime.Parse(rdr["SFDMS_CaptureDate"].ToString());
                        dr["SFDMS_ImageSize"] = int.Parse(rdr["SFDMS_ImageSize"].ToString());
                        dr["MIC_CaptureDate"] = DateTime.Parse(rdr["MIC_CaptureDate"].ToString());
                        dr["MIC_ImageSize"] = int.Parse(rdr["MIC_ImageSize"].ToString());

                        dt.Rows.Add(dr);

                    }

                }

                con.Close();
                con.Dispose();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="StartDate"></param>
        /// <param name="EndDate"></param>
        /// <returns></returns>
        internal DataTable Get_PaymentAdvices_ExecutionData(DateTime StartDate, DateTime EndDate)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable("ReportData");

                dt.Columns.Add("Client", typeof(string));
                dt.Columns.Add("CaseNumber", typeof(string));
                dt.Columns.Add("LoanNumber", typeof(string));
                dt.Columns.Add("ClientID", typeof(string));
                dt.Columns.Add("ClaimType", typeof(string));
                dt.Columns.Add("ProcessStatus", typeof(string));
                dt.Columns.Add("DateEntered", typeof(DateTime));
                dt.Columns.Add("ProcessDate", typeof(DateTime));
                dt.Columns.Add("ProcessLastUpdateDate", typeof(DateTime));
                dt.Columns.Add("ProcessCompleteDate", typeof(DateTime));
                dt.Columns.Add("ProcessID", typeof(int));
                dt.Columns.Add("Advice_CaptureDate", typeof(DateTime));
                dt.Columns.Add("Advice_ImageSize", typeof(int));
                dt.Columns.Add("PaidDate", typeof(DateTime));

                con.ConnectionString = _settings.GetConnectionString("MossAutomation");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_PaymentAdvices_Execution_Report";

                SqlParameter prm = new SqlParameter("@StartDate", StartDate);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@EndDate", EndDate);
                cmd.Parameters.Add(prm);

                cmd.Connection = con;

                SqlDataReader rdr = cmd.ExecuteReader();

                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        DataRow dr = dt.NewRow();

                        dr["Client"] = rdr["Client"].ToString();
                        dr["CaseNumber"] = rdr["CaseNumber"].ToString();
                        dr["LoanNumber"] = rdr["LoanNumber"].ToString();
                        dr["ClientID"] = rdr["ClientID"].ToString();
                        dr["ClaimType"] = rdr["ClaimType"].ToString();
                        dr["ProcessStatus"] = rdr["ProcessStatus"].ToString();
                        dr["DateEntered"] = DateTime.Parse(rdr["DateEntered"].ToString());
                        dr["ProcessDate"] = DateTime.Parse(rdr["ProcessDate"].ToString());
                        dr["ProcessLastUpdateDate"] = DateTime.Parse(rdr["ProcessLastUpdateDate"].ToString());
                        dr["ProcessCompleteDate"] = DateTime.Parse(rdr["ProcessCompleteDate"].ToString());
                        dr["ProcessID"] = int.Parse(rdr["ProcessID"].ToString());
                        dr["Advice_CaptureDate"] = DateTime.Parse(rdr["Advice_CaptureDate"].ToString());
                        dr["Advice_ImageSize"] = int.Parse(rdr["Advice_ImageSize"].ToString());
                        dr["PaidDate"] = DateTime.Parse(rdr["PaidDate"].ToString());

                        dt.Rows.Add(dr);

                    }

                }

                con.Close();
                con.Dispose();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        #endregion

    }
}
