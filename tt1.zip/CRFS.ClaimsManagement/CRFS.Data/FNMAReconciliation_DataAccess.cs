﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace CRFS.Data
{
    class FNMAReconciliation_DataAccess
    {
        CRFS.Data.Settings _settings;

        #region Constructors

        /// <summary>
        /// Default Constructor - should not be used
        /// </summary>
        internal FNMAReconciliation_DataAccess()
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="settings"></param>
        internal FNMAReconciliation_DataAccess(CRFS.Data.Settings settings)
        {
            _settings = settings;

        }

        #endregion

        #region Lookup Tables

        internal DataTable Reconciliation_BillingStatusTypes_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("BillingStatusTypes");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("BillingStatusID", typeof(int));
                dt.Columns.Add("BillingStatus", typeof(string));
                dt.Columns.Add("Active", typeof(bool));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                cmd.CommandText = "recon.usp_Recon_BillingStatusTypes_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["BillingStatusID"] = int.Parse(dr["BillingStatusID"].ToString().Length == 0 ? "0" : dr["BillingStatusID"].ToString());
                    row["BillingStatus"] = dr["BillingStatus"].ToString().Length == 0 ? "" : dr["BillingStatus"].ToString();
                    row["Active"] = bool.Parse(dr["Active"].ToString().Length == 0 ? "0" : dr["Active"].ToString());

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        internal DataTable Reconciliation_CommentTypes_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("CommentTypes");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("CommentTypeID", typeof(int));
                dt.Columns.Add("CommentType", typeof(string));
                dt.Columns.Add("Active", typeof(bool));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                cmd.CommandText = "recon.usp_Recon_CommentTypes_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["CommentTypeID"] = int.Parse(dr["CommentTypeID"].ToString().Length == 0 ? "0" : dr["CommentTypeID"].ToString());
                    row["CommentType"] = dr["CommentType"].ToString().Length == 0 ? "" : dr["CommentType"].ToString();
                    row["Active"] = bool.Parse(dr["Active"].ToString().Length == 0 ? "0" : dr["Active"].ToString());

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        internal DataTable Reconciliation_DispositionStatusTypes_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("DispositionStatusTypes");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("DispositionStatusID", typeof(int));
                dt.Columns.Add("DispositionStatus", typeof(string));
                dt.Columns.Add("Active", typeof(bool));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                cmd.CommandText = "recon.usp_Recon_DispositionStatusTypes_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["DispositionStatusID"] = int.Parse(dr["DispositionStatusID"].ToString().Length == 0 ? "0" : dr["DispositionStatusID"].ToString());
                    row["DispositionStatus"] = dr["DispositionStatus"].ToString().Length == 0 ? "" : dr["DispositionStatus"].ToString();
                    row["Active"] = bool.Parse(dr["Active"].ToString().Length == 0 ? "0" : dr["Active"].ToString());

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        internal DataTable Reconciliation_SettlementTypes_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("SettlementTypes");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("SettlementTypeID", typeof(int));
                dt.Columns.Add("SettlementType", typeof(string));
                dt.Columns.Add("Active", typeof(bool));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                cmd.CommandText = "recon.usp_Recon_SettlementTypes_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["SettlementTypeID"] = int.Parse(dr["SettlementTypeID"].ToString().Length == 0 ? "0" : dr["SettlementTypeID"].ToString());
                    row["SettlementType"] = dr["SettlementType"].ToString().Length == 0 ? "" : dr["SettlementType"].ToString();
                    row["Active"] = bool.Parse(dr["Active"].ToString().Length == 0 ? "0" : dr["Active"].ToString());

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        internal DataTable Reconciliation_StatusTypes_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("StatusTypes");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("StatusID", typeof(int));
                dt.Columns.Add("StatusType", typeof(string));
                dt.Columns.Add("Active", typeof(bool));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                cmd.CommandText = "recon.usp_Recon_StatusTypes_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["StatusID"] = int.Parse(dr["StatusID"].ToString().Length == 0 ? "0" : dr["StatusID"].ToString());
                    row["StatusType"] = dr["StatusType"].ToString().Length == 0 ? "" : dr["StatusType"].ToString();
                    row["Active"] = bool.Parse(dr["Active"].ToString().Length == 0 ? "0" : dr["Active"].ToString());

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        internal DataTable Reconciliation_NoBillReasons_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("NoBillReasons");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("NoBillReasonID", typeof(int));
                dt.Columns.Add("NoBillReasonDescription", typeof(string));
                dt.Columns.Add("Active", typeof(bool));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                cmd.CommandText = "recon.usp_Recon_NoBillReasons_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["NoBillReasonID"] = int.Parse(dr["NoBillReasonID"].ToString().Length == 0 ? "0" : dr["NoBillReasonID"].ToString());
                    row["NoBillReasonDescription"] = dr["NoBillReasonDescription"].ToString().Length == 0 ? "" : dr["NoBillReasonDescription"].ToString();
                    row["Active"] = bool.Parse(dr["Active"].ToString().Length == 0 ? "0" : dr["Active"].ToString());

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        internal DataTable Reconciliation_ApplicationReferralEvents_Get(Settings settings, int referralID)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("ApplicationReferralEvents");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("ApplicationReferralEventID", typeof(int));
                dt.Columns.Add("EventStateName", typeof(string));
                dt.Columns.Add("EventFromID", typeof(int));
                dt.Columns.Add("EventToID", typeof(int));
                dt.Columns.Add("IsComplete", typeof(bool));
                dt.Columns.Add("EnteredDate", typeof(DateTime));
                dt.Columns.Add("UserName", typeof(string));
                dt.Columns.Add("IsLocked", typeof(bool));

                SqlCommand cmd = new SqlCommand();
                SqlParameter parm = new SqlParameter();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                cmd.CommandText = "recon.usp_Recon_ApplicationReferralEvents_Select";
                cmd.Connection = con;
                parm = new SqlParameter("@ReferralID", referralID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ApplicationReferralEventID"] = int.Parse(dr["ApplicationReferralEventID"].ToString().Length == 0 ? "0" : dr["ApplicationReferralEventID"].ToString());
                    row["EventStateName"] = dr["EventStateName"].ToString().Length == 0 ? "" : dr["EventStateName"].ToString();
                    row["EventFromID"] = int.Parse(dr["EventFromID"].ToString().Length == 0 ? "0" : dr["EventFromID"].ToString());
                    row["EventToID"] = int.Parse(dr["EventToID"].ToString().Length == 0 ? "0" : dr["EventToID"].ToString());
                    row["IsComplete"] = bool.Parse(dr["IsComplete"].ToString().Length == 0 ? "0" : dr["IsComplete"].ToString());
                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                    row["UserName"] = dr["UserName"].ToString().Length == 0 ? "" : dr["UserName"].ToString();
                    row["IsLocked"] = bool.Parse(dr["IsLocked"].ToString().Length == 0 ? "0" : dr["IsLocked"].ToString());

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Retrieves the valid referral types for FNMA Reconciliation.
        /// </summary>
        /// <param name="settings"></param>
        /// <returns>DataTable with all valid referral types for FNMA Reconciliation.</returns>
        internal DataTable Recon_ReferralTypes_Select(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("ReferralTypes");
                DataColumn dc = new DataColumn();

                dc = new DataColumn();
                dc.ColumnName = "ReferralTypeID";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ReferralType";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                cmd.CommandText = "recon.usp_Recon_ReferralTypes_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ReferralTypeID"] = int.Parse(dr["ReferralTypeID"].ToString().Length == 0 ? "0" : dr["ReferralTypeID"].ToString());
                    row["ReferralType"] = dr["ReferralType"].ToString();

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Retrieves the data table ClaimItemAttributeID and data type for a given ClaimItemAttributeName.
        /// </summary>
        /// <param name="claimItemAttributeName">Name of the Claim Item Attribute to retrieve the ID field for.</param>
        /// <param name="settings"></param>
        /// <returns>DataTable containing the unique identifier for the Claim Item Attribute specified and it's data type.</returns>
        internal DataTable Recon_ClaimItemAttributeID_Get(string claimItemAttributeName, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("ClaimItemAttribute");
                dt.Columns.Add("ClaimItemAttributeID", typeof(int));
                dt.Columns.Add("ClaimItemAttributeDataType", typeof(string));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                SqlParameter parm = new SqlParameter("@ClaimItemAttributeName", claimItemAttributeName);
                cmd.Parameters.Add(parm);

                cmd.CommandText = "recon.usp_Recon_ClaimItemAttributeID_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ClaimItemAttributeID"] = int.Parse(dr["ClaimItemAttributeID"].ToString().Length == 0 ? "0" : dr["ClaimItemAttributeID"].ToString());
                    row["ClaimItemAttributeDataType"] = dr["ClaimItemAttributeDataType"].ToString();

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable Recon_CategoryCodes_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();

            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("CategoryCodes");

                dt.Columns.Add("CategoryCodeOfReceiptID", typeof(int));
                dt.Columns.Add("CategoryCodeOfReceipt", typeof(string));
                dt.Columns.Add("Description", typeof(string));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                cmd.CommandText = "recon.usp_Recon_CategoryCodes_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["CategoryCodeOfReceiptID"] = int.Parse(dr["CategoryCodeOfReceiptID"].ToString().Length == 0 ? "0" : dr["CategoryCodeOfReceiptID"].ToString());
                    row["CategoryCodeOfReceipt"] = dr["CategoryCodeOfReceipt"].ToString();
                    row["Description"] = dr["Description"].ToString();


                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        #endregion

        #region Claim Items

        /// <summary>
        /// 
        /// </summary>
        /// <param name="referralID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable Recon_ClaimItem_Get(int referralID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();

            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("ClaimItem");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("ClaimItemID", typeof(int));
                dt.Columns.Add("ReferralID", typeof(int));
                dt.Columns.Add("ClaimItemAttributeID", typeof(int));
                dt.Columns.Add("ClaimItemAttributeName", typeof(string));
                dt.Columns.Add("ClaimItemAttributeValue", typeof(string));
                dt.Columns.Add("ClaimItemAttributeDataType", typeof(string));
                dt.Columns.Add("EnteredDate", typeof(DateTime));
                dt.Columns.Add("EnteredByUserID", typeof(int));
                dt.Columns.Add("EnteredByUser", typeof(string));
                dt.Columns.Add("LastUpdateDate", typeof(DateTime));
                dt.Columns.Add("LastUpdateUserID", typeof(int));
                dt.Columns.Add("LastUpdateUser", typeof(string));
                dt.Columns.Add("deltaCheck", typeof(string));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                SqlParameter parm = new SqlParameter("@ReferralID", referralID);
                cmd.Parameters.Add(parm);

                cmd.CommandText = "recon.usp_Recon_ClaimItem_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ClaimItemID"] = int.Parse(dr["ClaimItemID"].ToString().Length == 0 ? "0" : dr["ClaimItemID"].ToString());
                    row["ReferralID"] = int.Parse(dr["ReferralID"].ToString().Length == 0 ? "0" : dr["ReferralID"].ToString());
                    row["ClaimItemAttributeID"] = int.Parse(dr["ClaimItemAttributeID"].ToString().Length == 0 ? "0" : dr["ClaimItemAttributeID"].ToString());
                    row["ClaimItemAttributeName"] = dr["ClaimItemAttributeName"].ToString();
                    row["ClaimItemAttributeValue"] = dr["ClaimItemAttributeValue"].ToString();
                    row["ClaimItemAttributeDataType"] = dr["ClaimItemAttributeDataType"].ToString();
                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                    row["EnteredByUserID"] = int.Parse(dr["EnteredByUserID"].ToString().Length == 0 ? "0" : dr["EnteredByUserID"].ToString());
                    row["EnteredByUser"] = dr["EnteredByUser"].ToString();
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    row["LastUpdateUserID"] = int.Parse(dr["LastUpdateUserID"].ToString().Length == 0 ? "0" : dr["LastUpdateUserID"].ToString());
                    row["LastUpdateUser"] = dr["LastUpdateUser"].ToString();
                    row["deltaCheck"] = dr["deltaCheck"].ToString();

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool Recon_ClaimItem_Save(DataTable data, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;

            }

            try
            {
                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                for (int i = 0; i < data.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;
                    cmd.Connection = con;

                    switch (data.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            cmd.CommandText = "recon.usp_Recon_ClaimItem_Insert";

                            parm = new SqlParameter("@ReferralID", data.Rows[i]["ReferralID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ClaimItemAttributeID", data.Rows[i]["ClaimItemAttributeID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ClaimItemAttributeValue", data.Rows[i]["ClaimItemAttributeValue"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@EnteredDate", data.Rows[i]["EnteredDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@EnteredByUserID", data.Rows[i]["EnteredByUserID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateDate", data.Rows[i]["LastUpdateDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateUserID", data.Rows[i]["LastUpdateUserID"]);
                            cmd.Parameters.Add(parm);

                            //Now we need to execute a stored procedure that returns the new record ID
                            data.Rows[i]["ClaimItemID"] = int.Parse(cmd.ExecuteScalar().ToString());

                            goto NextRecord;

                        case DataRowState.Modified:
                            //We need to look at the Attribute value to determine what to do next.
                            //If the attribute value contains nothing, we are going to delete the record,
                            //Otherwise we'll perform an update

                            if (data.Rows[i]["ClaimItemAttributeValue"].ToString().Length == 0)
                            {
                                cmd.CommandText = "recon.usp_Recon_ClaimItem_Delete";

                                parm = new SqlParameter("@ReferralID", data.Rows[i]["ReferralID"]);
                                cmd.Parameters.Add(parm);
                                parm = new SqlParameter("@ClaimItemAttributeID", data.Rows[i]["ClaimItemAttributeID"]);
                                cmd.Parameters.Add(parm);
                                parm = new SqlParameter("@deltaCheck", data.Rows[i]["deltaCheck"]);
                                cmd.Parameters.Add(parm);

                                //We also need to delete this row from the data table
                                data.Rows[i].Delete();
                            }

                            else
                            {
                                cmd.CommandText = "recon.usp_Recon_ClaimItem_Update";

                                parm = new SqlParameter("@ReferralID", data.Rows[i]["ReferralID"]);
                                cmd.Parameters.Add(parm);
                                parm = new SqlParameter("@ClaimItemAttributeID", data.Rows[i]["ClaimItemAttributeID"]);
                                cmd.Parameters.Add(parm);
                                parm = new SqlParameter("@ClaimItemAttributeValue", data.Rows[i]["ClaimItemAttributeValue"]);
                                cmd.Parameters.Add(parm);
                                parm = new SqlParameter("@LastUpdateDate", data.Rows[i]["LastUpdateDate"]);
                                cmd.Parameters.Add(parm);
                                parm = new SqlParameter("@LastUpdateUserID", data.Rows[i]["LastUpdateUserID"]);
                                cmd.Parameters.Add(parm);
                                parm = new SqlParameter("@deltaCheck", data.Rows[i]["deltaCheck"]);
                                cmd.Parameters.Add(parm);
                            }
                            break;

                        case DataRowState.Deleted:
                            //Delete from the database.
                            cmd.CommandText = "recon.usp_Recon_ClaimItem_Delete";

                            parm = new SqlParameter("@ReferralID", data.Rows[i]["ReferralID", DataRowVersion.Original]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ClaimItemAttributeID", data.Rows[i]["ClaimItemAttributeID", DataRowVersion.Original]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@deltaCheck", data.Rows[i]["deltaCheck", DataRowVersion.Original]);
                            cmd.Parameters.Add(parm);
                            break;

                        default:
                            goto NextRecord;
                    }

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;
                }

                data.AcceptChanges();

                return true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        #endregion

        #region Comments

        /// <summary>
        /// 
        /// </summary>
        /// <param name="referralID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable Recon_Comments_Get(int referralID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();

            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("Comments");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("CommentID", typeof(int));
                dt.Columns.Add("ReferralID", typeof(int));
                dt.Columns.Add("CommentTypeID", typeof(int));
                dt.Columns.Add("CommentType", typeof(string));
                dt.Columns.Add("FollowupComplete", typeof(bool));
                dt.Columns.Add("FollowupDate", typeof(DateTime));
                dt.Columns.Add("CommentText", typeof(string));
                dt.Columns.Add("EnteredDate", typeof(DateTime));
                dt.Columns.Add("EnteredByUserID", typeof(int));
                dt.Columns.Add("EnteredByUser", typeof(string));
                dt.Columns.Add("LastUpdateDate", typeof(DateTime));
                dt.Columns.Add("LastUpdateUserID", typeof(int));
                dt.Columns.Add("LastUpdateUser", typeof(string));
                dt.Columns.Add("deltaCheck", typeof(string));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                SqlParameter parm = new SqlParameter("@ReferralID", referralID);
                cmd.Parameters.Add(parm);

                cmd.CommandText = "recon.usp_Recon_Comment_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["CommentID"] = int.Parse(dr["CommentID"].ToString().Length == 0 ? "0" : dr["CommentID"].ToString());
                    row["ReferralID"] = int.Parse(dr["ReferralID"].ToString().Length == 0 ? "0" : dr["ReferralID"].ToString());
                    row["CommentTypeID"] = int.Parse(dr["CommentTypeID"].ToString().Length == 0 ? "0" : dr["CommentTypeID"].ToString());
                    row["CommentType"] = dr["CommentType"].ToString();
                    row["FollowupComplete"] = bool.Parse(dr["FollowupComplete"].ToString().Length == 0 ? "false" : dr["FollowupComplete"].ToString());
                    row["FollowupDate"] = DateTime.Parse(dr["FollowupDate"].ToString().Length == 0 ? "1/1/1900" : dr["FollowupDate"].ToString());
                    row["CommentText"] = dr["CommentText"].ToString();
                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                    row["EnteredByUserID"] = int.Parse(dr["EnteredByUserID"].ToString().Length == 0 ? "0" : dr["EnteredByUserID"].ToString());
                    row["EnteredByUser"] = dr["EnteredByUser"].ToString();
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    row["LastUpdateUserID"] = int.Parse(dr["LastUpdateUserID"].ToString().Length == 0 ? "0" : dr["LastUpdateUserID"].ToString());
                    row["LastUpdateUser"] = dr["LastUpdateUser"].ToString();
                    row["deltaCheck"] = dr["deltaCheck"].ToString();

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }


        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool Recon_Comments_Save(DataTable data, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;

            }

            try
            {
                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                for (int i = 0; i < data.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;
                    cmd.Connection = con;

                    switch (data.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            cmd.CommandText = "recon.usp_Recon_Comment_Insert";

                            parm = new SqlParameter("@ReferralID", data.Rows[i]["ReferralID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@CommentTypeID", data.Rows[i]["CommentTypeID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FollowupComplete", data.Rows[i]["FollowupComplete"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FollowupDate", data.Rows[i]["FollowupDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@CommentText", data.Rows[i]["CommentText"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@EnteredDate", data.Rows[i]["EnteredDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@EnteredByUserID", data.Rows[i]["EnteredByUserID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateDate", data.Rows[i]["LastUpdateDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateUserID", data.Rows[i]["LastUpdateUserID"]);
                            cmd.Parameters.Add(parm);

                            //Now we need to execute a stored procedure that returns the new record ID
                            data.Rows[i]["CommentID"] = int.Parse(cmd.ExecuteScalar().ToString());

                            goto NextRecord;

                        case DataRowState.Modified:
                            cmd.CommandText = "recon.usp_Recon_Comment_Update";

                            parm = new SqlParameter("@ReferralID", data.Rows[i]["ReferralID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@CommentID", data.Rows[i]["CommentID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@CommentTypeID", data.Rows[i]["CommentTypeID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FollowupComplete", data.Rows[i]["FollowupComplete"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FollowupDate", data.Rows[i]["FollowupDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@CommentText", data.Rows[i]["CommentText"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateDate", data.Rows[i]["LastUpdateDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateUserID", data.Rows[i]["LastUpdateUserID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@deltaCheck", data.Rows[i]["deltaCheck"]);
                            cmd.Parameters.Add(parm);

                            break;

                        default:
                            goto NextRecord;

                    }

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;
                }

                data.AcceptChanges();

                return true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        #endregion

        #region EOB Values

        /// <summary>
        /// 
        /// </summary>
        /// <param name="referralID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable Recon_EOBValues_Get(int referralID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();

            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("EOBTable");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("EOBValueID", typeof(int));
                dt.Columns.Add("ReferralID", typeof(int));
                dt.Columns.Add("EOBHeaderID", typeof(int));
                dt.Columns.Add("EOB Category", typeof(string));
                dt.Columns.Add("Submit Amt", typeof(decimal));
                dt.Columns.Add("Paid Amt", typeof(decimal));
                dt.Columns.Add("EOB Diff", typeof(decimal));
                dt.Columns.Add("C", typeof(bool));
                dt.Columns.Add("D", typeof(bool));
                //[T-4942] 20111130 CRZ
                dt.Columns.Add("O", typeof(bool));
                dt.Columns.Add("S", typeof(bool));
                dt.Columns.Add("EnteredDate", typeof(DateTime));
                dt.Columns.Add("EnteredByUserID", typeof(int));
                dt.Columns.Add("EnteredByUser", typeof(string));
                dt.Columns.Add("LastUpdateDate", typeof(DateTime));
                dt.Columns.Add("LastUpdateUserID", typeof(int));
                dt.Columns.Add("LastUpdateUser", typeof(string));
                dt.Columns.Add("SortOrder", typeof(int));
                dt.Columns.Add("deltaCheck", typeof(string));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                SqlParameter parm = new SqlParameter("@ReferralID", referralID);
                cmd.Parameters.Add(parm);

                cmd.CommandText = "recon.usp_Recon_EOBValues_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["EOBValueID"] = int.Parse(dr["EOBValueID"].ToString().Length == 0 ? "0" : dr["EOBValueID"].ToString());
                    row["ReferralID"] = int.Parse(dr["ReferralID"].ToString().Length == 0 ? "0" : dr["ReferralID"].ToString());
                    row["EOBHeaderID"] = int.Parse(dr["EOBHeaderID"].ToString().Length == 0 ? "0" : dr["EOBHeaderID"].ToString());
                    row["EOB Category"] = dr["EOBHeaderName"].ToString();
                    row["Submit Amt"] = decimal.Parse(dr["SubmittedAmount"].ToString().Length == 0 ? "0.0" : dr["SubmittedAmount"].ToString());
                    row["Paid Amt"] = decimal.Parse(dr["PaidAmount"].ToString().Length == 0 ? "0.0" : dr["PaidAmount"].ToString());
                    row["EOB Diff"] = decimal.Parse(dr["EOBDifference"].ToString().Length == 0 ? "0.0" : dr["EOBDifference"].ToString());
                    row["C"] = bool.Parse(dr["IsCurtailment"].ToString().Length == 0 ? "false" : dr["IsCurtailment"].ToString());
                    row["D"] = bool.Parse(dr["IsDisallowance"].ToString().Length == 0 ? "false" : dr["IsDisallowance"].ToString());
                    //[T-4942] 20111130 CRZ
                    row["O"] = bool.Parse(dr["IsOther"].ToString().Length == 0 ? "false" : dr["IsOther"].ToString());
                    row["S"] = bool.Parse(dr["IsSupplemental"].ToString().Length == 0 ? "false" : dr["IsSupplemental"].ToString());
                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                    row["EnteredByUserID"] = int.Parse(dr["EnteredByUserID"].ToString().Length == 0 ? "0" : dr["EnteredByUserID"].ToString());
                    row["EnteredByUser"] = dr["EnteredByUser"].ToString();
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    row["LastUpdateUserID"] = int.Parse(dr["LastUpdateUserID"].ToString().Length == 0 ? "0" : dr["LastUpdateUserID"].ToString());
                    row["LastUpdateUser"] = dr["LastUpdateUser"].ToString();
                    row["SortOrder"] = int.Parse(dr["SortOrder"].ToString().Length == 0 ? "0" : dr["SortOrder"].ToString());
                    row["deltaCheck"] = dr["deltaCheck"].ToString();

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool Recon_EOBValues_Save(DataTable data, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;

            }

            try
            {
                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                for (int i = 0; i < data.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;
                    cmd.Connection = con;

                    switch (data.Rows[i].RowState)
                    {
                        case DataRowState.Modified:
                            cmd.CommandText = "recon.usp_Recon_EOBValues_Update";

                            parm = new SqlParameter("@ReferralID", data.Rows[i]["ReferralID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@EOBHeaderID", data.Rows[i]["EOBHeaderID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@SubmittedAmount", data.Rows[i]["Submit Amt"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@PaidAmount", data.Rows[i]["Paid Amt"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@EOBDifference", data.Rows[i]["EOB Diff"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@IsCurtailment", data.Rows[i]["C"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@IsDisallowance", data.Rows[i]["D"]);
                            cmd.Parameters.Add(parm);
                            //[T-4942] 20111130 CRZ
                            parm = new SqlParameter("@IsOther", data.Rows[i]["O"]);
                            cmd.Parameters.Add(parm);
                            //[T-4942] END
                            parm = new SqlParameter("@IsSupplemental", data.Rows[i]["S"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateDate", data.Rows[i]["LastUpdateDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateUserID", data.Rows[i]["LastUpdateUserID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@deltaCheck", data.Rows[i]["deltaCheck"]);
                            cmd.Parameters.Add(parm);

                            break;

                        default:
                            goto NextRecord;

                    }

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;
                }

                data.AcceptChanges();
                return true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        #endregion

        #region Referrals

        /// <summary>
        /// 
        /// </summary>
        /// <param name="referralID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable Recon_Referral_Get(int referralID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("Referral");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("ReferralID", typeof(int));
                dt.Columns.Add("REO ID", typeof(string));
                dt.Columns.Add("FNMA Loan Number", typeof(string));
                dt.Columns.Add("ReferralTypeID", typeof(int));
                dt.Columns.Add("ReferralType", typeof(string));
                dt.Columns.Add("ReconStatusID", typeof(int));
                dt.Columns.Add("ReconStatus", typeof(string));
                dt.Columns.Add("ReceivedDate", typeof(DateTime));
                dt.Columns.Add("EnteredDate", typeof(DateTime));
                dt.Columns.Add("EnteredByUserID", typeof(int));
                dt.Columns.Add("EnteredByUser", typeof(string));
                dt.Columns.Add("LastUpdateDate", typeof(DateTime));
                dt.Columns.Add("LastUpdateUserID", typeof(int));
                dt.Columns.Add("LastUpdateUser", typeof(string));
                dt.Columns.Add("IsQCMCFile", typeof(bool));
                // FB 45112 ARG 20170411
                dt.Columns.Add("ResponsiblePartySvcrNbr", typeof(string));
                dt.Columns.Add("MIClaimFiledDate", typeof(DateTime));
                //FB 48442 ARG 20170728 Not releasing invoicing Sprint 1, uncomment for later sprint
                //dt.Columns.Add("ReadyForInvoicing", typeof(bool));
                dt.Columns.Add("deltaCheck", typeof(string));


                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                SqlParameter parm = new SqlParameter("@ReferralID", referralID);
                cmd.Parameters.Add(parm);

                cmd.CommandText = "recon.usp_Recon_Referral_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ReferralID"] = int.Parse(dr["ReferralID"].ToString().Length == 0 ? "0" : dr["ReferralID"].ToString());
                    row["REO ID"] = dr["REO_ID"].ToString();
                    row["FNMA Loan Number"] = dr["FNMALoanNumber"].ToString();
                    row["ReferralTypeID"] = int.Parse(dr["ReferralTypeID"].ToString().Length == 0 ? "0" : dr["ReferralTypeID"].ToString());
                    row["ReferralType"] = dr["ReferralType"].ToString();
                    row["ReconStatusID"] = int.Parse(dr["ReconStatusID"].ToString().Length == 0 ? "0" : dr["ReconStatusID"].ToString());
                    row["ReconStatus"] = dr["StatusType"].ToString();
                    row["ReceivedDate"] = DateTime.Parse(dr["ReceivedDate"].ToString().Length == 0 ? "1/1/1900" : dr["ReceivedDate"].ToString());
                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                    row["EnteredByUserID"] = int.Parse(dr["EnteredByUserID"].ToString().Length == 0 ? "0" : dr["EnteredByUserID"].ToString());
                    row["EnteredByUser"] = dr["EnteredByUser"].ToString();
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    row["LastUpdateUserID"] = int.Parse(dr["LastUpdateUserID"].ToString().Length == 0 ? "0" : dr["LastUpdateUserID"].ToString());
                    row["LastUpdateUser"] = dr["LastUpdateUser"].ToString();
                    row["IsQCMCFile"] = Boolean.Parse(dr["IsQCMCFile"].ToString());
                    // FB 45112 ARG 20170411
                    row["ResponsiblePartySvcrNbr"] = dr["ResponsiblePartySvcrNbr"].ToString();
                    row["MIClaimFiledDate"] = DateTime.Parse(dr["MIClaimFiledDate"].ToString().Length == 0 ? "1/1/1900" : dr["MIClaimFiledDate"].ToString());
                    //FB 48442 ARG 20170728 Not releasing invoicing Sprint 1, uncomment for later sprint
                    //row["ReadyForInvoicing"] = Boolean.Parse(dr["ReadyForInvoicing"].ToString());
                    row["deltaCheck"] = dr["deltaCheck"].ToString();


                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool Recon_Referral_Save(DataTable data, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;

            }

            try
            {
                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                for (int i = 0; i < data.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;
                    cmd.Connection = con;

                    switch (data.Rows[i].RowState)
                    {
                        case DataRowState.Modified:
                            cmd.CommandText = "recon.usp_Recon_Referral_Update";

                            parm = new SqlParameter("@ReferralID", data.Rows[i]["ReferralID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@REO_ID", data.Rows[i]["REO ID"].ToString().Trim().Length == 0 ? null : data.Rows[i]["REO ID"].ToString());
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FNMALoanNumber", data.Rows[i]["FNMA Loan Number"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ReferralTypeID", data.Rows[i]["ReferralTypeID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ReconStatusID", data.Rows[i]["ReconStatusID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ReceivedDate", data.Rows[i]["ReceivedDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateDate", data.Rows[i]["LastUpdateDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateUserID", data.Rows[i]["LastUpdateUserID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@IsQCMCFile", data.Rows[i]["IsQCMCFile"]);
                            cmd.Parameters.Add(parm);
                            // FB 45112 ARG 20170411
                            parm = new SqlParameter("@ResponsiblePartySvcrNbr", data.Rows[i]["ResponsiblePartySvcrNbr"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@MIClaimFiledDate", data.Rows[i]["MIClaimFiledDate"]);
                            cmd.Parameters.Add(parm);
                            //FB 48442 ARG 20170728 Not releasing invoicing Sprint 1, uncomment for later sprint
                            //parm = new SqlParameter("@ReadyForInvoicing", data.Rows[i]["ReadyForInvoicing"]);
                            //cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@deltaCheck", data.Rows[i]["deltaCheck"]);
                            cmd.Parameters.Add(parm);

                            break;

                        default:
                            goto NextRecord;

                    }

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;
                }

                data.AcceptChanges();
                return true;

            }

            catch (Exception ex)
            {
                //dump the table into an error file so we have some record of where we were
                try
                {
                    CRFS.Data.ErrorDataDump.DumpTableToDefaultLocation(data, "");
                }

                catch { }

                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ReferralTypeID"></param>
        /// <param name="settings"></param>
        /// <param name="optParms"></param>
        /// <returns></returns>
        internal DataTable Recon_Referral_Select_ByID(int ReferralTypeID, Settings settings, string[] optParms)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("Referral");
                dt.Columns.Add("ReferralID", typeof(int));
                dt.Columns.Add("REO_ID", typeof(string));
                dt.Columns.Add("FNMALoanNumber", typeof(string));
                dt.Columns.Add("ReferralTypeID", typeof(int));
                dt.Columns.Add("ReferralType", typeof(string));
                dt.Columns.Add("ReconStatusID", typeof(int));
                dt.Columns.Add("ReconStatus", typeof(string));
                dt.Columns.Add("CategoryCodeOfReceipt", typeof(string));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                SqlParameter parm = new SqlParameter("@ReferralTypeID", ReferralTypeID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@REO_ID", optParms[0]);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@FNMALoanNumber", optParms[1]);
                cmd.Parameters.Add(parm);

                cmd.CommandText = "recon.usp_Recon_ReferralFind";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ReferralID"] = int.Parse(dr["ReferralID"].ToString().Length == 0 ? "0" : dr["ReferralID"].ToString());
                    row["REO_ID"] = dr["REO_ID"].ToString();
                    row["FNMALoanNumber"] = dr["FNMALoanNumber"].ToString();
                    row["ReferralTypeID"] = int.Parse(dr["ReferralTypeID"].ToString().Length == 0 ? "0" : dr["ReferralTypeID"].ToString());
                    row["ReferralType"] = dr["ReferralType"].ToString();
                    row["ReconStatusID"] = int.Parse(dr["ReconStatusID"].ToString().Length == 0 ? "0" : dr["ReconStatusID"].ToString());
                    row["ReconStatus"] = dr["ReconStatus"].ToString();
                    row["CategoryCodeOfReceipt"] = dr["CategoryCodeOfReceipt"].ToString();

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        #endregion

        #region Transactions

        /// <summary>
        /// 
        /// </summary>
        /// <param name="referralID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable Recon_Transactions_Get(int referralID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();

            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("Transactions");

                dt.Columns.Add("TransactionID", typeof(int));
                dt.Columns.Add("ReferralID", typeof(int));
                dt.Columns.Add("MarkAsRemoved", typeof(bool));
                dt.Columns.Add("CategoryCodeOfReceiptID", typeof(int));
                dt.Columns.Add("CategoryCodeOfReceipt", typeof(string));
                dt.Columns.Add("FundType", typeof(string));
                dt.Columns.Add("TransactionAmount", typeof(decimal));
                dt.Columns.Add("EnteredDate", typeof(DateTime));
                dt.Columns.Add("EnteredByUserID", typeof(int));
                dt.Columns.Add("EnteredByUser", typeof(string));
                dt.Columns.Add("LastUpdateDate", typeof(DateTime));
                dt.Columns.Add("LastUpdateUserID", typeof(int));
                dt.Columns.Add("LastUpdateUser", typeof(string));
                dt.Columns.Add("deltaCheck", typeof(string));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                SqlParameter parm = new SqlParameter("@ReferralID", referralID);
                cmd.Parameters.Add(parm);

                cmd.CommandText = "recon.usp_Recon_Transactions_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["TransactionID"] = int.Parse(dr["TransactionID"].ToString().Length == 0 ? "0" : dr["TransactionID"].ToString());
                    row["ReferralID"] = int.Parse(dr["ReferralID"].ToString().Length == 0 ? "0" : dr["ReferralID"].ToString());
                    //[T-4942] 20111130 CRZ
                    row["MarkAsRemoved"] = bool.Parse(dr["MarkAsRemoved"].ToString().Length == 0 ? "false" : dr["MarkAsRemoved"].ToString());
                    row["CategoryCodeOfReceiptID"] = int.Parse(dr["CategoryCodeOfReceiptID"].ToString().Length == 0 ? "0" : dr["CategoryCodeOfReceiptID"].ToString());
                    row["CategoryCodeOfReceipt"] = dr["CategoryCodeOfReceipt"].ToString();
                    row["FundType"] = dr["FundType"].ToString();
                    row["TransactionAmount"] = decimal.Parse(dr["TransactionAmount"].ToString().Length == 0 ? "0.0" : dr["TransactionAmount"].ToString());
                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                    row["EnteredByUserID"] = int.Parse(dr["EnteredByUserID"].ToString().Length == 0 ? "0" : dr["EnteredByUserID"].ToString());
                    row["EnteredByUser"] = dr["EnteredByUser"].ToString();
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    row["LastUpdateUserID"] = int.Parse(dr["LastUpdateUserID"].ToString().Length == 0 ? "0" : dr["LastUpdateUserID"].ToString());
                    row["LastUpdateUser"] = dr["LastUpdateUser"].ToString();
                    row["deltaCheck"] = dr["deltaCheck"].ToString();

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;


            }

            catch (Exception ex)
            {
                throw ex;


            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool Recon_Transactions_Save(DataTable data, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;

            }

            try
            {
                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                for (int i = 0; i < data.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;
                    cmd.Connection = con;

                    switch (data.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            cmd.CommandText = "recon.usp_Recon_Transactions_Insert";

                            parm = new SqlParameter("@ReferralID", data.Rows[i]["ReferralID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@CategoryCodeOfReceiptID", data.Rows[i]["CategoryCodeOfReceiptID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@TransactionAmount", data.Rows[i]["TransactionAmount"]);
                            cmd.Parameters.Add(parm);
                            //[T-4942] 20111130 CRZ
                            parm = new SqlParameter("@MarkAsRemoved", data.Rows[i]["MarkAsRemoved"]);
                            cmd.Parameters.Add(parm);
                            //[T-4942] END
                            parm = new SqlParameter("@EnteredDate", data.Rows[i]["EnteredDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@EnteredByUserID", data.Rows[i]["EnteredByUserID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateDate", data.Rows[i]["LastUpdateDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateUserID", data.Rows[i]["LastUpdateUserID"]);
                            cmd.Parameters.Add(parm);

                            //Now we need to execute a stored procedure that returns the new record ID
                            data.Rows[i]["TransactionID"] = int.Parse(cmd.ExecuteScalar().ToString());

                            goto NextRecord;

                        case DataRowState.Deleted:
                            cmd.CommandText = "recon.usp_Recon_Transactions_Delete";

                            parm = new SqlParameter("@ReferralID", data.Rows[i]["ReferralID", DataRowVersion.Original]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@TransactionID", data.Rows[i]["TransactionID", DataRowVersion.Original]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@deltaCheck", data.Rows[i]["deltaCheck", DataRowVersion.Original]);
                            cmd.Parameters.Add(parm);

                            break;

                        case DataRowState.Modified:
                            //We have some checking to do before setting the command and parameters
                            //If the transaction value contains nothing or is 0, we are going to delete the record,
                            //Otherwise we'll perform an update
                            //We're also going to throw a message if the last character of CategoryCodeOfReceipt
                            //is not the letter "A".  We're only allowing updates/deletes to adjustments.

                            if (data.Rows[i]["TransactionAmount"].ToString().Length == 0 || data.Rows[i]["TransactionAmount"].ToString() == "0")
                            {
                                //We're looking at a delete operation

                                if (data.Rows[i]["CategoryCodeOfReceipt"].ToString().Substring(data.Rows[i]["CategoryCodeOfReceipt"].ToString().Length, 1) != "A")
                                {
                                    //The application has allowed the user to "delete" an imported transaction
                                    //This should be undeleted in the table as well as sending the user a message 
                                    //that they are not being allowed to delete imported transactions
                                    MessageBox.Show("You are attempting to delete an imported Transaction Amount.\n\n" +
                                                    "The delete operation is being disregarded",
                                                    "Operation not allowed", MessageBoxButtons.OK);

                                    data.Rows[i].RejectChanges();

                                }

                                else
                                {
                                    //The last letter of CategoryCodeOfReceipt is an A
                                    //The delete operation is OK
                                    cmd.CommandText = "recon.usp_Recon_Transactions_Delete";

                                    parm = new SqlParameter("@ReferralID", data.Rows[i]["ReferralID"]);
                                    cmd.Parameters.Add(parm);
                                    parm = new SqlParameter("@TransactionID", data.Rows[i]["TransactionID"]);
                                    cmd.Parameters.Add(parm);
                                    parm = new SqlParameter("@deltaCheck", data.Rows[i]["deltaCheck"]);
                                    cmd.Parameters.Add(parm);

                                }
                            }

                            else
                            {
                                //The operation is an update
                                cmd.CommandText = "recon.usp_Recon_Transactions_Update";

                                parm = new SqlParameter("@ReferralID", data.Rows[i]["ReferralID"]);
                                cmd.Parameters.Add(parm);
                                parm = new SqlParameter("@TransactionID", data.Rows[i]["TransactionID"]);
                                cmd.Parameters.Add(parm);
                                parm = new SqlParameter("@CategoryCodeOfReceiptID", data.Rows[i]["CategoryCodeOfReceiptID"]);
                                cmd.Parameters.Add(parm);
                                parm = new SqlParameter("@TransactionAmount", data.Rows[i]["TransactionAmount"]);
                                cmd.Parameters.Add(parm);
                                //[T-4942] 20111130 CRZ
                                parm = new SqlParameter("@MarkAsRemoved", data.Rows[i]["MarkAsRemoved"]);
                                cmd.Parameters.Add(parm);
                                //[T-4942] END
                                parm = new SqlParameter("@LastUpdateDate", data.Rows[i]["LastUpdateDate"]);
                                cmd.Parameters.Add(parm);
                                parm = new SqlParameter("@LastUpdateUserID", data.Rows[i]["LastUpdateUserID"]);
                                cmd.Parameters.Add(parm);
                                parm = new SqlParameter("@deltaCheck", data.Rows[i]["deltaCheck"]);
                                cmd.Parameters.Add(parm);

                            }

                            break;

                        default:
                            goto NextRecord;

                    }

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;

                }

                data.AcceptChanges();
                return true;

            }
            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        #endregion

        #region Imports FNMA Recon
        static Dictionary<string, string> parmTypes = new Dictionary<string, string>();  // local copy of lkp_Recon_ClaimItemAttribute map parameter name to type
        /// <summary>
        /// type check each parameter in the command that has a type associated with it in the lkp_Recon_ClaimItemAttribute table
        /// </summary>
        /// <param name="cmd">the sql command that contains the parameters to check</param>
        /// <returns>"" if types check, error string if they do not check</returns>
        string ImportReconTypeCheck(SqlCommand cmd)
        {
            // ticket 19991 20130522 GK, do type checking before saving to tbl_Recon_ClaimItem
            SqlParameterCollection parms = cmd.Parameters;
            // for each of the parameters
            for (int i = 0; i < parms.Count; i++)
            {
                String parmName = parms[i].ToString();
                // parmValue can be null if the cell is blank, have to protect against this
                string parmValue = (parms[i].Value ?? "").ToString();


                // look up the parameter type from the database if we haven't already
                if (!parmTypes.ContainsKey(parmName))
                {
                    string lookUpName = parmName.Replace("@", "");
                    CRFS.Data.DataFunctions _df = new CRFS.Data.DataFunctions(_settings.Get_appmode());
                    _settings.FormID = (int)FormConstants.FNMAReconciliation;
                    DataTable claimItemAttribute = new DataTable("ClaimItemAttribute");
                    claimItemAttribute = _df.Recon_ClaimItemAttributeID_Get(lookUpName);

                    // if this parameter is in the database store the type, otherwise set it to "None"
                    if (claimItemAttribute.Rows.Count >= 1)
                    {
                        parmTypes[parmName] = claimItemAttribute.Rows[0]["ClaimItemAttributeDataType"].ToString();
                    }
                    else
                    {
                        parmTypes[parmName] = "None";
                    }
                }

                // try and parse the parameter type, return an error string if we can't
                int sacint;
                DateTime sacTime;
                float sacFloat;
                switch (parmTypes[parmName])
                {
                    case "None": break;
                    case "string": break;
                    case "int":
                        if (!int.TryParse(parmValue, out sacint))
                        {
                            return "Bad Parameter " + parmName + " cannot convert " + parmValue + " to int.";
                        }
                        break;
                    case "datetime":
                        if (!DateTime.TryParse(parmValue, out sacTime))
                        {
                            return "Bad Parameter " + parmName + " cannot convert " + parmValue + " to datetime.";
                        }
                        break;
                    case "decimal":
                        if (!float.TryParse(parmValue, out sacFloat))
                        {
                            return "Bad Parameter " + parmName + " cannot convert " + parmValue + " to decimal.";
                        }
                        break;
                    case "bool":
                        if (parmValue != "0" && parmValue != "1")
                        {
                            return "Bad Parameter " + parmName + " cannot convert " + parmValue + " to bool.";
                        }
                        break;
                }
            }

            // return success
            return "";
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="referralTypeID"></param>
        /// <param name="formID"></param>
        /// <param name="importAsDate"></param>
        /// <param name="userUniqueID"></param>
        /// <param name="events"></param>
        /// <param name="df"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable ImportRecon(DataTable data, int referralTypeID, int formID, string importAsDate, int userUniqueID, Moss.Events.Events events, CRFS.Data.DataFunctions df, Settings settings)
        {
            double nextTarget = .01;
            SqlConnection con = new SqlConnection();
            //DataTable dtComboBoxValues = new DataTable();
            DataTable dtReferralTypes = new DataTable();
            DataTable dtReconStatus = new DataTable();
            DataTable dtDisposition = new DataTable();
            DataTable dtApplicationIDs = new DataTable();

            string referralType = "";
            bool DispositionEliminated = false;

            //dtComboBoxValues = df.ClaimsManagement_GetComboBoxReferenceValues_ByFormID(10);
            dtReferralTypes = df.ReconReferralTypesSelect();
            dtReconStatus = df.Reconciliation_StatusTypes_Get();
            dtDisposition = df.Reconciliation_DispositionStatusTypes_Get();
            dtApplicationIDs = df.GetApplicationIds();


            try
            {
                DataColumn dc = new DataColumn();

                if (!data.Columns.Contains("Processed"))
                {
                    dc = new DataColumn();
                    dc.ColumnName = "Processed";
                    dc.DataType = typeof(bool);
                    dc.DefaultValue = false;
                    data.Columns.Add(dc);

                }

                if (!data.Columns.Contains("ProcessComments"))
                {
                    dc = new DataColumn();
                    dc.ColumnName = "ProcessComments";
                    dc.DataType = typeof(string);
                    dc.DefaultValue = "Not Processed";
                    data.Columns.Add(dc);

                }

                DataView dvRefTypes = new DataView(dtReferralTypes);
                dvRefTypes.RowFilter = "ReferralTypeID = " + referralTypeID.ToString();

                switch (dvRefTypes.Count)
                {
                    case 0:
                        //Throw an error - we don't match a referral type
                        throw new Exception("Error initializing Referral Type - No match.  ID causing error is: " + referralTypeID.ToString());

                    case 1:
                        //This is where we want to be 
                        referralType = dvRefTypes[0]["ReferralType"].ToString();

                        break;

                    default:
                        //Throw an error - we match more than one referral type.
                        throw new Exception("Error initializing Referral Type - More than one match: (" + dvRefTypes.Count.ToString() + ")   ID causing error is: " + referralTypeID.ToString());

                }


                int rowCount = data.Rows.Count;

                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                SqlTransaction tran;

                con.Open();

                if (con.State == ConnectionState.Open)
                {
                    for (int i = 0; i < rowCount; i++)
                    {
                        // gk 30017 20160628 MUST have the last column filled in
                        bool foundDateReferral = false;
                        DateTime DateReferral = DateTime.Now;
                        try
                        {
                            string sDateReferral = data.Rows[i]["Date Referral"].ToString();
                            if (sDateReferral.Length > 0)
                            {
                                foundDateReferral = DateTime.TryParse(sDateReferral, out DateReferral);
                            }
                        }
                        catch
                        {
                            ; // column didn't exist or something else, in any event DateReferral isn't there
                        }
                        if (!foundDateReferral)
                        {
                            data.Rows[i]["Processed"] = false;
                            data.Rows[i]["ProcessComments"] = "ERROR: DateReferral must be populated with a date";
                            goto NextRecord;
                        }

                        // end gk 30017 20160628 MUST have the last column filled in

                        //Before starting a SQL Transaction, we need to look at the MI Company and Servicer names
                        //Since these are text, we get a lot of variation for them and they must be grouped to send emails
                        //Therefore, we are now flagging on import when we import a new value.  The Admin tools can then
                        //be used to set up the groupings by users who are authorized to make those changes.

                        //First clean any suplied codes from the name string and then check to see if the MI Company name exists in CMS
                        string MICompanyName = ReplaceParantheticalString(data.Rows[i]["MI Company"].ToString());

                        int MICompanyBusinessEntityID = 0;
                        bool MIAddedFlag = false;

                        DataTable dtBusinessEntities = df.GetBusinessEntities();

                        DataTable dtBusinessEntityTypes = df.GetEntityTypes();

                        DataView dvBusinessEntityTypes = new DataView(dtBusinessEntityTypes);

                        DataView dvApplicationID = new DataView(dtApplicationIDs);
                        dvApplicationID.RowFilter = "CMSFormID = " + formID.ToString();

                        DataView dvMICompany = new DataView(dtBusinessEntities);
                        dvMICompany.RowFilter = "BusinessEntityName = '" + MICompanyName + "' AND ApplicationID = " + dvApplicationID[0]["ApplicationID"].ToString();

                        switch (dvMICompany.Count)
                        {
                            case 0:
                                //The MI Company needs to be added to the BusinessEntities table.  This can be done automatically,
                                //But it will need manual steps performed to be added to a group as well as designate it as either backend or not
                                //we'll set a message flag for this
                                dvBusinessEntityTypes.RowFilter = ("EntityTypeName = 'MI Company'");

                                MICompanyBusinessEntityID = df.InsertBusinessEntities(MICompanyName, int.Parse(dvApplicationID[0]["ApplicationID"].ToString()), int.Parse(dvBusinessEntityTypes[0]["EntityTypeID"].ToString()));
                                MIAddedFlag = true;

                                break;

                            case 1:
                                //We're in good shape.  We have a single match.  Use the BusinessEntityID for loading this record
                                MICompanyBusinessEntityID = int.Parse(dvMICompany[0]["BusinessEntityID"].ToString());

                                break;

                            default:
                                //We have more than one record returned
                                data.Rows[i]["Processed"] = false;
                                data.Rows[i]["ProcessComments"] = "ERROR: There is more than one MI Company matching the value for this import record.  This record was not saved";

                                goto NextRecord;

                        }

                        //Now do the same operation with the servicer name
                        string ServicerName = ReplaceParantheticalString(data.Rows[i]["Servicer Name"].ToString());

                        int ServicerBusinessEntityID = 0;
                        bool ServicerAddedFlag = false;

                        DataView dvServicer = new DataView(dtBusinessEntities);
                        dvServicer.RowFilter = "BusinessEntityName = '" + ServicerName + "' AND ApplicationID = " + dvApplicationID[0]["ApplicationID"].ToString();

                        switch (dvServicer.Count)
                        {
                            case 0:
                                //The Servicer needs to be added to the BusinessEntities table.  This can be done automatically,
                                //But it will need manual steps performed to be added to a group
                                //we'll set a message flag for this
                                dvBusinessEntityTypes.RowFilter = ("EntityTypeName = 'Servicer'");

                                ServicerBusinessEntityID = df.InsertBusinessEntities(ServicerName, int.Parse(dvApplicationID[0]["ApplicationID"].ToString()), int.Parse(dvBusinessEntityTypes[0]["EntityTypeID"].ToString()));
                                ServicerAddedFlag = true;

                                break;

                            case 1:
                                //We're in good shape.  We have a single match.  Use the BusinessEntityID for loading this record
                                ServicerBusinessEntityID = int.Parse(dvServicer[0]["BusinessEntityID"].ToString());

                                break;

                            default:
                                data.Rows[i]["Processed"] = false;
                                data.Rows[i]["ProcessComments"] = "ERROR: There is more than one Servicer matching the value for this import record.  This record was not saved";

                                goto NextRecord;

                        }

                        //We also need the ID of three attributes, rather than the text supplied in the import file.
                        //It is time to do the lookups.  

                        //The first two have lookups stored in tbllkp_Forms_ComboBoxValues
                        int ReconStatusID = 0; //This should always be Open
                        int DispositionStatusID = 0;   //Have to remove the Codes in parens


                        DataView dvRecon = new DataView(dtReconStatus);
                        dvRecon.RowFilter = ("StatusType = 'Open'");

                        switch (dvRecon.Count)
                        {
                            case 0:
                                data.Rows[i]["Processed"] = false;
                                data.Rows[i]["ProcessComments"] = "ERROR: There is no Recon Status 'Open' found.  This record was not saved";

                                goto NextRecord;

                            case 1:
                                ReconStatusID = int.Parse(dvRecon[0]["StatusID"].ToString());

                                break;

                            default:
                                data.Rows[i]["Processed"] = false;
                                data.Rows[i]["ProcessComments"] = "ERROR: There is more than one Recon Status 'Open' found.  This record was not saved";

                                goto NextRecord;

                        }

                        //Non-REO will not have Disposition Status, so we need to bypass the error checking
                        if (referralType == "REO")
                        {
                            DataView dvDisposition = new DataView(dtDisposition);
                            string DispositionStatus = ReplaceParantheticalString(data.Rows[i]["Disposition Status  Description"].ToString());
                            dvDisposition.RowFilter = ("DispositionStatus = '" + DispositionStatus + "'");

                            switch (dvDisposition.Count)
                            {
                                case 0:
                                    data.Rows[i]["Processed"] = false;
                                    data.Rows[i]["ProcessComments"] = "ERROR: There is no Disposition Status " + DispositionStatus + " found.  This record was not saved";

                                    goto NextRecord;

                                case 1:
                                    DispositionStatusID = int.Parse(dvDisposition[0]["DispositionStatusID"].ToString());

                                    break;

                                default:
                                    data.Rows[i]["Processed"] = false;
                                    data.Rows[i]["ProcessComments"] = "ERROR: There is more than one Disposition Status " + DispositionStatus + " found.  This record was not saved";

                                    goto NextRecord;


                            }

                            if (DispositionStatus == "Eliminated")
                            {
                                DispositionEliminated = true;

                            }

                        }


                        //This one has lookups in lkp_Recon_CategoryCodes
                        int CategoryCodeOfReceiptID = 0; //810, 820, 334 ID lookup
                        DataTable CatCodes = new DataTable();
                        CatCodes = df.Recon_CategoryCodes_Get();

                        DataView dvCatCodes = new DataView(CatCodes);
                        dvCatCodes.RowFilter = ("CategoryCodeOfReceipt = '" + data.Rows[i]["Cat# Code of Receipt"].ToString() + "'");

                        switch (dvCatCodes.Count)
                        {
                            case 0:
                                data.Rows[i]["Processed"] = false;
                                data.Rows[i]["ProcessComments"] = "ERROR: There is no Cat. Code of Receipt " + data.Rows[i]["Cat# Code of Receipt"].ToString() + " found.  This record was not saved";

                                goto NextRecord;

                            case 1:
                                CategoryCodeOfReceiptID = int.Parse(dvCatCodes[0]["CategoryCodeOfReceiptID"].ToString());

                                break;

                            default:
                                data.Rows[i]["Processed"] = false;
                                data.Rows[i]["ProcessComments"] = "ERROR: There is more than one Cat. Code of Receipt " + data.Rows[i]["Cat# Code of Receipt"].ToString() + " found.  This record was not saved";

                                goto NextRecord;

                        }

                        //Now we check to see if the referral has already been loaded
                        string[] optParms = new string[2];
                        if (referralType == "REO")
                        {
                            optParms[0] = data.Rows[i]["REO ID"].ToString().Trim().Length == 0 ? null : data.Rows[i]["REO ID"].ToString();
                        }

                        optParms[1] = data.Rows[i]["Loan Number"].ToString().Trim().Length == 0 ? null : data.Rows[i]["Loan Number"].ToString();

                        DataTable ExistingReferral = new DataTable();
                        ExistingReferral = df.Recon_Referral_Select_ByID(referralTypeID, optParms);

                        //We need to make sure the referral is not closed
                        DataView dvExistingReferral = new DataView(ExistingReferral);
                        dvExistingReferral.RowFilter = ("ReferralType = '" + referralType + "' AND ReconStatus = 'Closed'");

                        //This flag indicates whether or not the fund transaction being inserted should
                        //  be 'active' (the default) or whether it should be loaded but marked as 
                        //  removed from the fund transaction calculations.
                        bool markAsRemoved = false;

                        //[T-4942] 20111130 - CRZ
                        // Check if referral is closed. We still need to load the transaction for reconciliation purposes...referrals
                        //  need to be reconciled at the transaction level...but it will be loaded and marked as removed, since
                        //  processing of the claim is complete.
                        bool referralIsClosed = false;
                        if (dvExistingReferral.Count > 0)
                        {
                            referralIsClosed = true;
                            markAsRemoved = true;
                            ////data.Rows[i]["Processed"] = false;
                            ////data.Rows[i]["ProcessComments"] = "ERROR: The referral is in CMS and is closed. This record was not saved.";
                            ////goto NextRecord;
                        }

                        //This flag indicates whether the current fund transactiom is a duplicate active 810 transaction.
                        bool duplicate810Record = false;

                        //This flag indicates if an 810 fund transaction already exists for this referral. If the 
                        //  current fund transaction is also an 810, we issue a warning as noted above for a duplicate 810.
                        //  If this is a 334/820 fund transaction, and an 810 transaction does not exist, we need to issue
                        //  a warning.
                        bool missing810Transaction = false;

                        dvExistingReferral.RowFilter = ("ReferralType = '" + referralType + "' AND CategoryCodeOfReceipt = '810'");
                        if (dvExistingReferral.Count > 0)
                        {
                            //We need to do an additional check to make sure we are not getting an additional Category Code of Receipt 810 record
                            if (data.Rows[i]["Cat# Code of Receipt"].ToString() == "810")
                            {
                                //Allow the additional 810 record to load because we need to reconcile referrals at the transaction level
                                //  log a warning instead of an error. The supervisor will need to sort out which 810 record is the valid
                                //  record. Also, the SAVE process is modified to not allow changes to be saved if there are 2 active 810
                                //  fund transactions.
                                duplicate810Record = true;
                                ////data.Rows[i]["Processed"] = false;
                                ////data.Rows[i]["ProcessComments"] = "ERROR: The referral is in CMS already has an 810 transaction record. This record was not saved.";
                                ////goto NextRecord;
                            }
                        }
                        else
                        {
                            //No 810 exists for this referral, check if this is NOT an 810 (i.e. 334 or 820)
                            if (data.Rows[i]["Cat# Code of Receipt"].ToString() != "810")
                            {
                                //We have a 334 or 820 fund transaction, and no 810 record. Allow this to load because 
                                //  we need to reconcile referrals at the transaction level, but log a warning instead
                                //  of an error and mark this fund transaction as "removed".
                                missing810Transaction = true;
                                markAsRemoved = true;
                            }
                        }
                        //[T-4942] END

                        SqlCommand cmd = new SqlCommand();
                        SqlParameter prm = new SqlParameter();

                        //Now we set a transaction for the Referral Import
                        tran = con.BeginTransaction();

                        try
                        {
                            cmd.CommandTimeout = Configuration.CommandTimeouts_Extra_AppsDB_FNMASQLDatabase;
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "recon.usp_Recon_Referral_Import";
                            cmd.Transaction = tran;

                            //These parameters are are common to Non-REO and REO imports.
                            prm = new SqlParameter("@FNMALoanNumber", data.Rows[i]["Loan Number"].ToString().Trim().Length == 0 ? null : data.Rows[i]["Loan Number"].ToString());
                            cmd.Parameters.Add(prm);
                            prm = new SqlParameter("@ReferralTypeID", referralTypeID);
                            cmd.Parameters.Add(prm);
                            prm = new SqlParameter("@ReconStatusID", ReconStatusID);
                            cmd.Parameters.Add(prm);
                            prm = new SqlParameter("@ReceivedDate", importAsDate);
                            cmd.Parameters.Add(prm);
                            prm = new SqlParameter("@EnteredDate", DateTime.Now);
                            cmd.Parameters.Add(prm);
                            prm = new SqlParameter("@EnteredByUserID", userUniqueID);
                            cmd.Parameters.Add(prm);
                            prm = new SqlParameter("@LastUpdateDate", DateTime.Now);
                            cmd.Parameters.Add(prm);
                            prm = new SqlParameter("@LastUpdateUserID", userUniqueID);
                            cmd.Parameters.Add(prm);
                            prm = new SqlParameter("@ServicerBusinessEntityID", ServicerBusinessEntityID.ToString());
                            cmd.Parameters.Add(prm);
                            prm = new SqlParameter("@ServicerLoanNumber", data.Rows[i]["Servicer Loan Number"].ToString().Trim().Length == 0 ? null : data.Rows[i]["Servicer Loan Number"].ToString());
                            cmd.Parameters.Add(prm);
                            prm = new SqlParameter("@PropertyAddress", data.Rows[i]["Property Address"].ToString().Trim().Length == 0 ? null : data.Rows[i]["Property Address"].ToString());
                            cmd.Parameters.Add(prm);
                            prm = new SqlParameter("@City", data.Rows[i]["Property City"].ToString().Trim().Length == 0 ? null : data.Rows[i]["Property City"].ToString());
                            cmd.Parameters.Add(prm);
                            prm = new SqlParameter("@State", data.Rows[i]["Property State"].ToString().Trim().Length == 0 ? null : data.Rows[i]["Property State"].ToString());
                            cmd.Parameters.Add(prm);
                            prm = new SqlParameter("@Zipcode", data.Rows[i]["Property Zip"].ToString().Trim().Length == 0 ? null : data.Rows[i]["Property Zip"].ToString());
                            cmd.Parameters.Add(prm);
                            prm = new SqlParameter("@SettlementReceivedDate", data.Rows[i]["Last Updated Date of Receipt"].ToString().Trim().Length == 0 ? null : data.Rows[i]["Last Updated Date of Receipt"].ToString());
                            cmd.Parameters.Add(prm);
                            prm = new SqlParameter("@MICompanyBusinessEntityID", MICompanyBusinessEntityID.ToString());
                            cmd.Parameters.Add(prm);
                            prm = new SqlParameter("@MICertificateNumber", data.Rows[i]["Certificate Number"].ToString().Trim().Length == 0 ? null : data.Rows[i]["Certificate Number"].ToString());
                            cmd.Parameters.Add(prm);
                            prm = new SqlParameter("@CategoryCodeOfReceiptID", CategoryCodeOfReceiptID);
                            cmd.Parameters.Add(prm);
                            prm = new SqlParameter("@TransactionAmount", data.Rows[i]["Transaction Amount"].ToString().Trim().Length == 0 ? null : data.Rows[i]["Transaction Amount"].ToString());
                            cmd.Parameters.Add(prm);
                            //[T-4942] 20111130 CRZ
                            prm = new SqlParameter("@MarkAsRemoved", markAsRemoved);
                            cmd.Parameters.Add(prm);
                            //[T-4942] END
                            // gk 30017 20160629
                            prm = new SqlParameter("@DateReferral", DateReferral);
                            cmd.Parameters.Add(prm);
                            // end gk 30017 20160629

                            if (referralType == "REO")
                            {
                                //These parameters are not supplied for Non-REO imports.  They need to be added for REO
                                prm = new SqlParameter("@REO_ID", data.Rows[i]["REO ID"].ToString().Trim().Length == 0 ? null : data.Rows[i]["REO ID"].ToString());
                                cmd.Parameters.Add(prm);
                                prm = new SqlParameter("@DispositionStatusID", DispositionStatusID.ToString());
                                cmd.Parameters.Add(prm);
                                prm = new SqlParameter("@DispositionDate", data.Rows[i]["Disposition Status Date"].ToString().Trim().Length == 0 ? null : data.Rows[i]["Disposition Status Date"].ToString());
                                cmd.Parameters.Add(prm);

                                //With REO referrals, MI % is an integer value.  The application takes care of converting to a decimal and then displaying as a percentage.
                                //See Non-REO difference below
                                prm = new SqlParameter("@MIPercentCoverage", data.Rows[i]["MI %"].ToString().Trim().Length == 0 ? null : data.Rows[i]["MI %"].ToString());
                                cmd.Parameters.Add(prm);


                            }

                            else
                            {
                                //When Non-REO referrals are sent, we get decimal values formatted as a percent
                                //We can expect that at some pont in time, we'll get a whole number and not a decimal value
                                //This will cause a percentage to be off by a factor of 1000 - C'est la vie, at least until we
                                //pull the ability of the business units to negotiate the data formats into development
                                prm = new SqlParameter("@MIPercentCoverage", data.Rows[i]["MI %"].ToString().Trim().Length == 0 ? null : (decimal.Parse(data.Rows[i]["MI %"].ToString()) * 100).ToString());
                                cmd.Parameters.Add(prm);

                            }
                            // ticket:19991 20130522 GK code to check that all the types match
                            string typeCheck = ImportReconTypeCheck(cmd);
                            if (typeCheck != "")
                            {
                                data.Rows[i]["Processed"] = false;
                                data.Rows[i]["ProcessComments"] = "ERROR: " + typeCheck + " This record was not saved";
                                tran.Rollback();
                                goto NextRecord;
                            }
                            // end ticket:19991 20130522 GK code to check that all the types match

                            cmd.Connection = con;
                            int referralID;

                            referralID = int.Parse(cmd.ExecuteScalar().ToString());

                            if (referralID < 0)
                            {
                                data.Rows[i]["Processed"] = false;

                                switch (referralID)
                                {
                                    case -1000:
                                        data.Rows[i]["ProcessComments"] = "ERROR: ReferralID Not Initialized - Examine Referral Type.  This record was not saved";
                                        break;

                                    case -1001:
                                        data.Rows[i]["ProcessComments"] = "ERROR: Problem storing Referral.  This record was not saved";
                                        break;

                                    case -2000:
                                    case -2001:
                                    case -2002:
                                    case -2003:
                                    case -2004:
                                    case -2005:
                                    case -2006:
                                    case -2007:
                                    case -2008:
                                    case -2009:
                                    case -2010:
                                    case -2011:
                                    case -2012:
                                        data.Rows[i]["ProcessComments"] = "ERROR: Problem storing Attribute # " + (referralID + 2001).ToString() + ".  This record was not saved";
                                        break;

                                    case -3000:
                                        data.Rows[i]["ProcessComments"] = "ERROR: Problem creating EOB Records.  This record was not saved";
                                        break;

                                    case -4000:
                                        data.Rows[i]["ProcessComments"] = "ERROR: Problem storing Transaction Record.  This record was not saved";
                                        break;

                                    case -5000:
                                        data.Rows[i]["ProcessComments"] = "ERROR: Problem storing additional Transaction Record.  This record was not saved";
                                        break;

                                    case -6000:
                                        data.Rows[i]["ProcessComments"] = "ERROR: Problem completing previous followup date records.  This record was not saved";
                                        break;

                                    case -7000:
                                        data.Rows[i]["ProcessComments"] = "ERROR: Problem getting category code for new followup date record.  This record was not saved";
                                        break;

                                    case -7001:
                                        data.Rows[i]["ProcessComments"] = "ERROR: Problem getting Comment TypeID for new followup date record.  This record was not saved";
                                        break;

                                    case -7002:
                                        data.Rows[i]["ProcessComments"] = "ERROR: Problem creating new followup date record.  This record was not saved";
                                        break;

                                    default:
                                        data.Rows[i]["ProcessComments"] = "ERROR: Return Value " + referralID.ToString() + " is not configured in Data Layer.  This record was not saved";
                                        break;
                                }

                                tran.Rollback();
                                goto NextRecord;

                            }

                            else
                            {
                                //unique referral id was returned
                                data.Rows[i]["Processed"] = true;
                                data.Rows[i]["ProcessComments"] = "Record saved with Referral ID: " + referralID.ToString();

                                if (ServicerAddedFlag)
                                {
                                    data.Rows[i]["ProcessComments"] = "Servicer added and needs to be added to a group. " + data.Rows[i]["ProcessComments"].ToString();
                                }

                                if (MIAddedFlag)
                                {
                                    data.Rows[i]["ProcessComments"] = "MI Company added and needs to be added to a group. " + data.Rows[i]["ProcessComments"].ToString();
                                }

                                if (DispositionEliminated)
                                {
                                    data.Rows[i]["ProcessComments"] = "Disposition Status is Eliminated.  " + data.Rows[i]["ProcessComments"].ToString();
                                }

                                if (referralIsClosed)
                                {
                                    data.Rows[i]["ProcessComments"] = "WARNING: The referral is in CMS and is closed. This fund transaction is marked as 'removed'. " + data.Rows[i]["ProcessComments"].ToString();
                                }

                                if (duplicate810Record)
                                {
                                    data.Rows[i]["ProcessComments"] = "WARNING: The referral already has an 810 transaction record. Supervisor edit required to select correct 810 transaction. " + data.Rows[i]["ProcessComments"].ToString();
                                }

                                if (missing810Transaction)
                                {
                                    data.Rows[i]["ProcessComments"] = "WARNING: The referral is missing an 810 transaction record. This fund transaction is marked as 'removed'. " + data.Rows[i]["ProcessComments"].ToString();
                                }
                                tran.Commit();
                                goto NextRecord;
                            }
                        }

                        catch (Exception e)
                        {
                            data.Rows[i]["Processed"] = false;
                            data.Rows[i]["ProcessComments"] = "An error occurred while trying to insert this record.  This record was not saved" + e.StackTrace.ToString() + " ex=" + e.ToString();
                            tran.Rollback();
                            goto NextRecord;
                        }

                    NextRecord: ;
                        if ((((double)i + 1) / (double)rowCount) >= nextTarget)
                        {
                            nextTarget += .01;
                            events.OnRaiseImportStatusUpdateEvent();
                        }
                    }
                }

                data.AcceptChanges();
                return data;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        #endregion

        #region Locking
        
        /// <summary>
        /// Returns referral lock information for the FNMA Reconciliation application.
        /// </summary>
        /// <param name="settings">Database connection settings</param>
        /// <returns>Table of all current locks for the FNMA Reconciliation application</returns>
        internal DataTable Recon_Locks_List_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("ReconLocks");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("LockID", typeof(int));
                dt.Columns.Add("FormID", typeof(int));
                dt.Columns.Add("Form Name", typeof(string));
                dt.Columns.Add("ReferralID", typeof(int));
                dt.Columns.Add("FNMA Loan Number", typeof(string));
                dt.Columns.Add("REO ID", typeof(string));
                dt.Columns.Add("Workstation Name", typeof(string));
                dt.Columns.Add("LockedByUserID", typeof(int));
                dt.Columns.Add("Locked By User Name", typeof(string));
                dt.Columns.Add("LockDate", typeof(DateTime));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                cmd.CommandText = "recon.usp_Recon_Locks_List";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["LockID"] = int.Parse(dr["LockID"].ToString().Length == 0 ? "0" : dr["LockID"].ToString());
                    row["FormID"] = int.Parse(dr["FormID"].ToString().Length == 0 ? "0" : dr["FormID"].ToString());
                    row["Form Name"] = dr["FormName"].ToString();
                    row["ReferralID"] = int.Parse(dr["ReferralID"].ToString().Length == 0 ? "0" : dr["ReferralID"].ToString());
                    row["FNMA Loan Number"] = dr["FNMALoanNumber"].ToString();
                    row["REO ID"] = dr["REO_ID"].ToString();
                    row["Workstation Name"] = dr["WorkstationName"].ToString();
                    row["LockedByUserID"] = int.Parse(dr["LockedByUserID"].ToString().Length == 0 ? "0" : dr["LockedByUserID"].ToString());
                    row["Locked By User Name"] = dr["LockedByUserName"].ToString();
                    row["LockDate"] = DateTime.Parse(dr["LockDate"].ToString().Length == 0 ? "1/1/1900" : dr["LockDate"].ToString());

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Handles INSERT, UPDATE and DELETE for FNMA Reconciliation locks. 
        /// For new lock requests, an INSERT is attempted. An INSERT via this routine
        /// would have been initialed by a 'Find' on a specific FNMA Loan Number and
        /// REO ID, or a selection from the 'Find' dialog as a result of a wildcard search.
        /// If successful, the LockID is returned. If unsuccessful, an error code is returned.
        /// For an UPDATE, the LockedDate will updated to reflect the new lock date/time.
        /// Updates will also only occur when a user is re-opening a referral/claim that
        /// had been previously opened and for which a lock already exists.
        /// For a DELETE, the lock specified by the LockID will be removed.
        /// </summary>
        /// <param name="data">Lock record to process</param>
        /// <param name="settings">Database connection settings</param>
        /// <returns></returns>
        internal bool Recon_Lock_Save(DataTable data, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                for (int i = 0; i < data.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;
                    cmd.Connection = con;

                    switch (data.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            //The usp_Recon_Lock_Request wraps the usp_Lock_Insert to provide
                            //  the application specific primary and secondary referral/claim
                            //  identifiers. For FNMA Reconciliation, these are the FNMA Loan
                            //  Number and REO ID respectively.
                            cmd.CommandText = "recon.usp_Recon_Lock_Request";

                            //For an INSERT to be successful, the ReferralID OR the FNMA Loan
                            //  Number AND the REO ID must be specified.
                            parm = new SqlParameter("@FormID", data.Rows[i]["FormID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ReferralID", data.Rows[i]["ReferralID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FNMALoanNumber", data.Rows[i]["FNMA Loan Number"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@REO_ID", data.Rows[i]["REO ID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@WorkstationName", data.Rows[i]["Workstation Name"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LockedByUserID", data.Rows[i]["LockedByUserID"]);
                            cmd.Parameters.Add(parm);

                            //Now we need to execute a stored procedure that returns the new record ID or error code
                            data.Rows[i]["LockID"] = int.Parse(cmd.ExecuteScalar().ToString());

                            goto NextRecord;

                        case DataRowState.Modified:
                            //
                            cmd.CommandText = "usp_Lock_Update";

                            parm = new SqlParameter("@LockID", data.Rows[i]["LockID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LockDate", data.Rows[i]["LockDate"]);
                            cmd.Parameters.Add(parm);
                            break;

                        case DataRowState.Deleted:
                            //Referral/Claim being closed, delete the associated lock
                            cmd.CommandText = "usp_Lock_Delete";

                            parm = new SqlParameter("@LockID", data.Rows[i]["LockID", DataRowVersion.Original]);
                            cmd.Parameters.Add(parm);
                            break;

                        default:
                            goto NextRecord;
                    }

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;
                }

                data.AcceptChanges();

                return true;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        #endregion

        #region Recon Queue
        
        /// <summary>
        /// Retrieves the list of referrals in the Recon Processor's queue.
        /// </summary>
        /// <param name="settings">Database connection settings</param>
        /// <returns></returns>
        internal DataTable Recon_Queue_Processor_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("ReconQueueProcessor");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("ReferralID", typeof(int));
                dt.Columns.Add("FNMA Loan Number", typeof(string));
                dt.Columns.Add("REO ID", typeof(string));
                dt.Columns.Add("FollowupDate", typeof(string));
                dt.Columns.Add("FollowupType", typeof(string));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                cmd.CommandText = "recon.usp_Recon_Queue_Processor";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ReferralID"] = int.Parse(dr["ReferralID"].ToString().Length == 0 ? "0" : dr["ReferralID"].ToString());
                    row["FNMA Loan Number"] = dr["FNMALoanNumber"].ToString();
                    row["REO ID"] = dr["REO_ID"].ToString();
                    row["Followup Date"] = dr["FollowupDate"].ToString();
                    row["Followup Type"] = dr["FollowUpType"].ToString();

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Retrieves the list of referrals in the Recon Supervisor's queue.
        /// </summary>
        /// <param name="settings">Database connection settings</param>
        /// <returns></returns>
        internal DataTable Recon_Queue_Supervisor_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("ReconQueueSupervisor");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("ReferralID", typeof(int));
                dt.Columns.Add("FNMA Loan Number", typeof(string));
                dt.Columns.Add("REO ID", typeof(string));
                dt.Columns.Add("FollowupDate", typeof(string));
                dt.Columns.Add("FollowupType", typeof(string));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                cmd.CommandText = "recon.usp_Recon_Queue_Supervisor";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ReferralID"] = int.Parse(dr["ReferralID"].ToString().Length == 0 ? "0" : dr["ReferralID"].ToString());
                    row["FNMA Loan Number"] = dr["FNMALoanNumber"].ToString();
                    row["REO ID"] = dr["REO_ID"].ToString();
                    row["Followup Date"] = dr["FollowupDate"].ToString();
                    row["Followup Type"] = dr["FollowUpType"].ToString();

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Retrieves the list of referrals in the Recon Comment Followup queue.
        /// </summary>
        /// <param name="settings">Database connection settings</param>
        /// <returns></returns>
        internal DataTable Recon_Queue_CommentFollowUp_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("ReconQueueCommentFollowUp");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("ReferralID", typeof(int));
                dt.Columns.Add("FNMA Loan Number", typeof(string));
                dt.Columns.Add("REO ID", typeof(string));
                dt.Columns.Add("FollowupDate", typeof(string));
                dt.Columns.Add("FollowupType", typeof(string));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                cmd.CommandText = "recon.usp_Recon_Queue_CommentFollowUp";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ReferralID"] = int.Parse(dr["ReferralID"].ToString().Length == 0 ? "0" : dr["ReferralID"].ToString());
                    row["FNMA Loan Number"] = dr["FNMALoanNumber"].ToString();
                    row["REO ID"] = dr["REO_ID"].ToString();
                    row["Followup Date"] = dr["FollowupDate"].ToString();
                    row["Followup Type"] = dr["FollowUpType"].ToString();

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region Misc.
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="searchValue"></param>
        /// <returns></returns>
        internal DataTable searchFNMARecon_ByLoanNumberREOID(string searchValue)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable("ReconClaimsFound");

                dt.Columns.Add("ReferralID", typeof(int));
                dt.Columns.Add("REO ID", typeof(string));
                dt.Columns.Add("FNMA Loan Number", typeof(string));
                dt.Columns.Add("ReferralType", typeof(string));
                dt.Columns.Add("ReconStatus", typeof(string));
                dt.Columns.Add("ClaimFormID", typeof(int));

                con.ConnectionString = _settings.GetConnectionString("AppsDB_FNMA");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "recon.usp_CNTL_FNMARecon_FindReferral_ByLoanNumberREOID";

                SqlParameter prm = new SqlParameter("@SearchValue", searchValue);
                cmd.Parameters.Add(prm);

                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();
                    row["ReferralID"] = int.Parse(dr["ReferralID"].ToString().Length == 0 ? "0" : dr["ReferralID"].ToString());
                    row["REO ID"] = dr["REO_ID"].ToString();
                    row["FNMA Loan Number"] = dr["FNMALoanNumber"].ToString();
                    row["ReferralType"] = dr["ReferralType"].ToString();
                    row["ReconStatus"] = dr["ReconStatus"].ToString();
                    row["ClaimFormID"] = dr["ClaimFormID"];

                    dt.Rows.Add(row);
                }
                dr.Close();
                dr.Dispose();

                return dt;

            }
            catch (Exception e)
            {
                throw e;
            }

            finally
            {
                if (con.State != ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Retrieves all FNMA Reconciliation claims matching the type and value specified.
        /// Multiple values will match if the searchvalue specified is a prefix to any
        /// existing REO IDs or Loan Numbers.
        /// </summary>
        /// <param name="searchType"></param>
        /// <param name="searchValue"></param>
        /// <param name="settings"></param>
        /// <returns>Dataset of claims matching the search type and value specified.</returns>
        internal DataSet Recon_FindClaims(string searchType, string searchValue, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataSet ds = new DataSet();
                DataTable dt = new DataTable("ReconClaimsFound");

                dt.Columns.Add("ReferralID", typeof(int));
                dt.Columns.Add("REO ID", typeof(string));
                dt.Columns.Add("FNMA Loan Number", typeof(string));
                dt.Columns.Add("ReferralType", typeof(string));
                dt.Columns.Add("ReconStatus", typeof(string));
                dt.Columns.Add("ClaimFormID", typeof(int));

                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "recon.usp_Recon_FindClaims_Select";
                SqlParameter prm = new SqlParameter("@SearchType", searchType);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@SearchValue", searchValue);
                cmd.Parameters.Add(prm);

                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();
                    row["ReferralID"] = int.Parse(dr["ReferralID"].ToString().Length == 0 ? "0" : dr["ReferralID"].ToString());
                    row["REO ID"] = dr["REO_ID"].ToString();
                    row["FNMA Loan Number"] = dr["FNMALoanNumber"].ToString();
                    row["ReferralType"] = dr["ReferralType"].ToString();
                    row["ReconStatus"] = dr["ReconStatus"].ToString();
                    row["ClaimFormID"] = dr["ClaimFormID"];

                    dt.Rows.Add(row);
                }
                dr.Close();
                dr.Dispose();

                ds.Tables.Add(dt);
                return ds;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (con.State != ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Cleans codes such as (70) from the tail end of an imported text string.
        /// This is primarily for the FNMA EOB Reconciliation referral imports, but
        /// may be useful for other processes as well.
        /// </summary>
        /// <param name="SuppliedString">The string to be cleansed of paranthetical codes</param>
        /// <returns>The original string - minus any digit codes enclosed in parenthesis, and the surrounding spaces.</returns>
        internal string ReplaceParantheticalString(string SuppliedString)
        {
            try
            {
                string CleanedString = "";

                //This is a regular expression pattern that is looking for digit codes enclosed in parenthesis
                //example:   Some String Text (01)
                //We need to remove the (01) as well as surrounding space characters
                //string pattern = "/x20+/x28/d{*}/x29/x20*$";
                string pattern = " *\\(*\\d*\\)* *$";
                string replacement = "";

                CleanedString = Regex.Replace(SuppliedString, pattern, replacement);

                return CleanedString;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        #endregion

    }
}
