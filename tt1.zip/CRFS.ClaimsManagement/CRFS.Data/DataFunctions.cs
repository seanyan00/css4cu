﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using System.Data.SqlClient;
using System.Windows.Forms;
using CRFS.ConcurrencyMessage;

namespace CRFS.Data
{
    public class DataFunctions
    {
        internal string _appMode;
        internal CRFS.Data.Settings settings;
        internal int _appID;

        public int FormID
        {
            get { return _appID;  }
            set { _appID = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="appMode"></param>
        public DataFunctions(string appMode)
        {
            _appMode = appMode;

            settings = new CRFS.Data.Settings(appMode);
        }
        public const string ConveyancePartAstring = "A";
        public const string ConveyancePartBstring = "B";
        public const string FHAPartDontCare = "X";

        #region "Private Methods"
        void processSqlException(SqlException ex)
        {
            // normally UI shouldn't be done in the DAL but we need a seperate catch for each call so that the subsequent saves would occour.
            frmConcurrencyMessage.DisplayMessage(ex);
        }
        #endregion
        #region "Common"
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable ClaimGroups_Get()
        {
            try
            {
                CRFS.Data.CommonDataAccess dal = new CommonDataAccess();
                return dal.ClaimGroups_Get(settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="formID"></param>
        /// <returns></returns>
        public DataTable ClaimsManagement_GetComboBoxReferenceValues_ByFormID(int formID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.GetComboBoxReferenceValues_ByFormID(formID, settings);
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="formID"></param>
        /// <returns></returns>
        public DataTable ClaimsManagement_GetComboBoxReferenceValues_ByFormID_NoExpire(int formID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.GetComboBoxReferenceValues_ByFormID_NoExpire(formID, settings);
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="formID"></param>
        /// <returns></returns>
        public DataTable ClaimsManagement_GetDeactivatedComboBoxReferenceValues_ByFormID(int formID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.GetDeactivatedComboBoxReferenceValues_ByFormID(formID, settings);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public DataTable Clients_Get()
        {
            try
            {
                CRFS.Data.CommonDataAccess dal = new CommonDataAccess();
                return dal.Clients_Get(settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="appMode"></param>
        /// <param name="dbName"></param>
        /// <returns></returns>
        public string Get_ConnectionString(string appMode, string dbName)
        {
            try
            {
                string rtnValue = "";

                Settings _settings = new Settings(appMode);
                rtnValue = _settings.GetConnectionString(dbName);

                return rtnValue;
            }

            catch(Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable Get_Import_Processes()
        {
            try
            {
                ApplicationConfiguration ac = new ApplicationConfiguration(settings);
                return ac.Get_Import_Processes(settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable Get_EnabledSuppMenuItems()
        {
            try
            {
                ApplicationConfiguration ac = new ApplicationConfiguration(settings);
                return ac.Get_EnabledSuppMenuItems(settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable Get_Shippers()
        {
            try
            {
                ApplicationConfiguration ac = new ApplicationConfiguration(settings);
                return ac.Get_Shippers(settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="fhaClaimID"></param>
        /// <returns></returns>
        public DataTable HUDClaims_GetFHALookups()
        {
            try
            {
                HUDClaimsDataAccess dal = new HUDClaimsDataAccess(settings);
                return dal.HUDClaims_GetFHALookups(settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /*31043
        
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable Get_Import_Process_Client_Map()
        {
            try
            {
                ApplicationConfiguration ac = new ApplicationConfiguration(settings);
                return ac.Get_Import_Process_Client_Map(settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="_clientID"></param>
        /// <param name="processDate"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        public DataTable Import_Claims332_InvestorTracking_Combined(DataTable dt, int _clientID, string processDate, int userID)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                ClaimsManagement cm = new ClaimsManagement(settings);

                return da.Import_Claims332_InvestorTracking_Combined(dt, _clientID, processDate, userID, settings, cm);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        */

        /// <summary>
        /// Retrieves all data for all active application forms.
        /// </summary>
        /// <param name="referralID"></param>
        /// <returns></returns>
        public DataTable Get_ActiveForms()
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.Get_ActiveForms(settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClaimGroupText"></param>
        /// <param name="formID"></param>
        /// <returns></returns>
        public DataTable GetTabControls(string ClaimGroupText, int formID)
        {
            try
            {
                CRFS.Data.ApplicationConfiguration ac = new ApplicationConfiguration(settings);
                return ac.GetTabControls(ClaimGroupText, formID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }


           //_HOAAutomaticReferrals = _cdf.GetIncompleteManualHOARequests(fhaClaimID);
        public DataTable GetIncompleteManualHOARequests(int fhaClaimID)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.GetIncompleteManualHOARequests(fhaClaimID);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        //_cdf.CancelManualReferral((int)_HOAManualReferrals.Rows[0]["ManualDelegatedReferralRequestID"],_curUserUniqueID,1,(string)_HOAManualReferrals.Rows[0]["DeltaChk"])
        public void CancelManualReferral(int ManualDelegatedReferralRequestID,int userID,int cancel,string DeltaChk)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                da.CancelManualReferral(ManualDelegatedReferralRequestID,userID,cancel,DeltaChk);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
           //_cdf.ManualHOAInsert(fhaClaimID);
        public void ManualHOAInsert(int fhaClaimID,int userID)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                da.ManualHOAInsert(fhaClaimID,userID);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
           //_HOAManualReferrals = _cdf.GetAutomaticHOARequests(fhaClaimID);
        public DataTable GetAutomaticHOARequests(int fhaClaimID)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.GetAutomaticHOARequests(fhaClaimID);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        // gk [t-12862] 20130708 get the application ids from the ApplicationConfiguration
        /// <summary>
        /// 
        /// </summary>
        /// <returns>data table with ApplicationId and ApplicationName</returns>
        public DataTable GetApplicationIds()
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.GetApplicationIds();

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }

        // gk[t-12862]  20130709 get the application ids from the ApplicationConfiguration
        /// <summary>
        /// 
        /// </summary>
        /// <returns>data table with ApplicationId and ApplicationName</returns>
        public int OpenImportBatch(int clientid, string fname, int ftypeid, int reccount, int userid)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.OpenImportBatch(clientid,fname,ftypeid,reccount,userid);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        // gk[t-12862]  20130709 get the application ids from the ApplicationConfiguration
        /// <summary>
        /// 
        /// </summary>
        /// <returns>data table with ApplicationId and ApplicationName</returns>
        public int OpenImportRecordID(int batchid,int userid)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.OpenImportRecordID(batchid,userid);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        // gk[t-12862]  20130708 get the application ids from the ApplicationConfiguration
        /// <summary>
        /// 
        /// </summary>
        /// <returns>data table with ApplicationId and ApplicationName</returns>
        public DataTable GetBusinessEntities()
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.GetBusinessEntities();

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }
        // gk[t-12862]  20130709 get the application ids from the ApplicationConfiguration
        /// <summary>
        /// 
        /// </summary>
        /// <returns>data table with ApplicationId and ApplicationName</returns>
        public DataTable GetDispositionStatusCodes()
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.GetDispositionStatusCodes();

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }
        // gk[t-12862]  20130709 get the application ids from the ApplicationConfiguration
        /// <summary>
        /// 
        /// </summary>
        /// <returns>data table with ApplicationId and ApplicationName</returns>
        public int ImportRecordDispositionInsert(int recid,int stausid,string attrib,string val,int userid)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.ImportRecordDispositionInsert(recid,stausid,attrib,val,userid);

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }
        // gk[t-12862]  20130710 get the application ids from the ApplicationConfiguration
        /// <summary>
        /// 
        /// </summary>
        /// <returns>data table with ApplicationId and ApplicationName</returns>
        public int InsertFNMAAdvPmt_ImportData(DataRow dr)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.InsertFNMAAdvPmt_ImportData(dr);

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }
        // gk[t-12862]  20130710 get the application ids from the ApplicationConfiguration
        /// <summary>
        /// 
        /// </summary>
        /// <returns>data table with ApplicationId and ApplicationName</returns>
        public int UpdateAdvPmtReferral(DataRow dr)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.UpdateAdvPmtReferral(dr);

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }
        // gk[t-12862]  20130710 get the application ids from the ApplicationConfiguration
        /// <summary>
        /// 
        /// </summary>
        /// <returns>data table with ApplicationId and ApplicationName</returns>
        public DataTable GetFileTypes()
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.GetFileTypes();

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }
        // gk [t-12862] 20130708 get the application ids from the ApplicationConfiguration
        /// <summary>
        /// 
        /// </summary>
        /// <returns>data table with ApplicationId and ApplicationName</returns>
        public DataTable GetReferralbyFNMA_Servicer_LN(string lnum, string slnum)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.GetReferralbyFNMA_Servicer_LN(lnum, slnum);

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }

        /// <summary>
        /// Determines if an import record has already been imported 
        /// </summary>
        /// <param name="FNMALoanNumber"></param>
        /// <param name="ServicerLoanNumber"></param>
        /// <returns>True if the record can be ignored</returns>
        public bool CheckIfAlreadyImported(string FNMALoanNumber, string ServicerLoanNumber)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.CheckIfAlreadyImported(FNMALoanNumber, ServicerLoanNumber);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Returns the referral status id value for a given referral status description
        /// </summary>
        /// <param name="StatusDescription"></param>
        /// <returns></returns>
        public int GetReferralStatusIdByDescription(string StatusDescription)
        {
            DataAutomation da = new DataAutomation(settings);
            return da.GetReferralStatusIdByDescription(StatusDescription);
        }

        public DataTable GetDisbursementByReferral(long referralid)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.GetDisbursementByReferral(referralid);

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }
        // gk [t-12862] 20130708 get the EntityTypes from ApplicationConfiguration
        /// <summary>
        /// 
        /// </summary>
        /// <returns>data table with EntityTypes</returns>
        public DataTable GetEntityTypes()
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.GetEntityTypes();

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }
        // gk [t-12862] 20130708 insert into BusinessEntityTable
        /// <summary>
        /// 
        /// </summary>
        /// <returns>data table with ApplicationId and ApplicationName</returns>
        public int InsertBusinessEntities(String name, int appid, int entitytypeid)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.InsertBusinessEntities(name,appid,entitytypeid);

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }
        // gk [t-12862] 20130709 insert into BusinessEntityTable
        /// <summary>
        /// 
        /// </summary>
        /// <returns>data table with ApplicationId and ApplicationName</returns>
        public DataTable getFNMAAdvPmtReferralStatus()
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.getFNMAAdvPmtReferralStatus();

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }

        // gk [t-12862] 20130709 insert into BusinessEntityTable
        /// <summary>
        /// 
        /// </summary>
        /// <returns>data table with ApplicationId and ApplicationName</returns>
        public int InsertOrUpdateFNMAAdvPmtReferral(DataRow dr)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.InsertOrUpdateFNMAAdvPmtReferral(dr);

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }

        // gk [t-12862] 20130709 insert into BusinessEntityTable
        /// <summary>
        /// 
        /// </summary>
        /// <returns>data table with ApplicationId and ApplicationName</returns>
        public int InsertFNMAAdvPmtDisbursement(DataRow dr)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.InsertFNMAAdvPmtDisbursement(dr);

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }

        public DataTable BusinessEntities_Get(int formID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.BusinessEntities_Get(formID, settings);

            }

            catch (Exception ex)
                {
                    throw ex;
                }

        }

        public int InsertBusinessEntity(string BusinessEntityName, int BusinessEntityType, int FormID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.InsertBusinessEntity(BusinessEntityName, BusinessEntityType, FormID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable ProcessUserEMail_List_withClientPermissions_SELECT()
        {
            try
            {
                DataAutomation dal = new DataAutomation(settings);
                return dal.ProcessUserEMail_List_withClientPermissions_SELECT();

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        #endregion

        #region "Admin Tools"
        /// <summary>
        /// 
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public DataTable ApplicationAccess_Get(int UserID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.ApplicationAccess_Get(UserID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        public DataTable ApplicationAccess_GetAllUsers()
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.ApplicationAccess_GetAllUsers(settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool ApplicationAccess_Save(DataTable data)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.ApplicationAccess_Save(data, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable Security_CMSUsers_Get()
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.Security_CMSUsers_Get(settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        public DataTable Security_AllUsers_Get()
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.Security_AllUsers_Get(settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public bool Security_CMSUser_PasswordReset(int UserID, string password)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.Security_CMSUser_PasswordReset(UserID, password, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="PhoneNum"></param>
        /// <param name="UserEmailAddress"></param>
        /// <returns></returns>
        public bool Security_CMSUsers_UpdateNonCritical(int UserID, string PhoneNum, string UserEmailAddress)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.Security_CMSUsers_UpdateNonCritical(UserID, PhoneNum, UserEmailAddress, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable ClientGroups_Get()
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.ClientGroups_Get(settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable EntityTypes_Get()
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.EntityTypes_Get(settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FormID"></param>
        /// <returns></returns>
        public DataTable EntityGroups_Get(int FormID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.EntityGroups_Get(FormID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FormID"></param>
        /// <returns></returns>
        public DataTable EntityGroupsAssigned_Get(int FormID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.EntityGroupsAssigned_Get(FormID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        public bool EntityGroupsAssigned_Save(DataTable data)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.EntityGroupsAssigned_Save(data, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FormID"></param>
        /// <returns></returns>
        public DataTable Groups_Get(int FormID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.Groups_Get(FormID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FormID"></param>
        /// <returns></returns>
        public DataTable GetEntityGroups(int FormID)
        {
            try
            {
                CRFS.Data.ApplicationConfiguration ac = new CRFS.Data.ApplicationConfiguration(settings);
                return ac.GetEntityGroups(FormID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        public bool EntityGroups_Save(DataTable data)
        {
            try
            {
                CRFS.Data.ApplicationConfiguration ac = new CRFS.Data.ApplicationConfiguration(settings);
                return ac.EntityGroups_Save(data, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }

        public bool BusinessEntityGroupsAssigned_Save(DataTable data)
        {
            try
            {
                CRFS.Data.ApplicationConfiguration ac = new CRFS.Data.ApplicationConfiguration(settings);
                return ac.BusinessEntityGroupsAssigned_Save(data, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        public DataTable BusinessEntityGroupsAssigned_Get(int FormID)
        {
            try
            {
                CRFS.Data.ApplicationConfiguration ac = new CRFS.Data.ApplicationConfiguration(settings);
                return ac.BusinessEntityGroupsAssigned_Get(FormID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        public DataTable BusinessEntityGroups_Get(int FormID)
        {
            try
            {
                CRFS.Data.ApplicationConfiguration ac = new CRFS.Data.ApplicationConfiguration(settings);
                return ac.BusinessEntityGroups_Get(FormID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="FormID"></param>
        /// <returns></returns>
        public DataTable GroupEmailSignatures_Get(int FormID)
        {
            try
            {
                CRFS.Data.FNMAReferralDataAccess frda = new FNMAReferralDataAccess();
                return frda.GroupEmailSignatures_Get(FormID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="groupName"></param>
        /// <returns></returns>
        public DataTable AdvPmt_GetGroupSignatures(string groupName)
        {
            try
            {
                CRFS.Data.FNMAReferralDataAccess frda = new FNMAReferralDataAccess();
                return frda.AdvPmt_GetGroupSignatures(groupName, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool Groups_Save(DataTable data)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.Groups_Save(data, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="FormID"></param>
        /// <returns></returns>
        public bool Business_Entities_Update(DataTable data, int FormID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.Business_Entities_Update(data, FormID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable Security_ClientSpecificSecurity_GetMatrix()
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.Security_ClientSpecificSecurity_GetMatrix(settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="CurrentUserID"></param>
        /// <returns></returns>
        public bool Security_ClientSpecificSecurity_SaveMatrix(ref DataTable dt, int CurrentUserID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.Security_ClientSpecificSecurity_SaveMatrix(ref dt, CurrentUserID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        // gk 20130920 t-13987
        public DataTable UserAssignedToGroup_Select()
        {
            try
            {
                CRFS.Data.FNMAReferralDataAccess frda = new FNMAReferralDataAccess();
                return frda.UserAssignedToGroup_Select(settings);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public bool UserAssignedToGroup_Save(DataTable dt)
        {
            try
            {
                CRFS.Data.FNMAReferralDataAccess frda = new FNMAReferralDataAccess();
                return frda.UserAssignedToGroup_Save(dt, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        public bool UserEmailSignature_Save(DataTable dt)
        {
            try
            {
                CRFS.Data.FNMAReferralDataAccess frda = new FNMAReferralDataAccess();
                return frda.UserEmailSignature_Save(dt, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        public int setDataDirty(int UserID, int ClaimID, int LoanID, string MachineName) 
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.setDataDirty(UserID,ClaimID,LoanID,MachineName, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        public void setDataClean(int DataDirtyID) 
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                cm.setDataClean(DataDirtyID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        #endregion

        /*31043
        #region "Claims 332"
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable Build_ClaimsDetails_Table()
        {
            try
            {
                CRFS.Data.DataAutomation dal = new DataAutomation(settings);
                return dal.Build_ClaimsDetails_Table();

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        #endregion
        */
        public DataTable ClaimsManagement_GetFormClients(int formID)
        {
            try
            {
                ClaimsManagement cm = new ClaimsManagement();
                return cm.GetForm_Clients(formID, settings);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        #region "Claims Management access for Docuware"

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="events"></param>
        /// <returns></returns>
        public DataTable Get332ClaimDetailsForWellsUpload(DataTable dt, Moss.Events.Events events)
        {
            try
            {
                ClaimsManagement cm = new ClaimsManagement(settings);
                return cm.Get332ClaimDetailsForWellsUpload(dt, events);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        #endregion

        #region "Data Automation"
        /// <summary>
        /// 
        /// </summary>
        /// <param name="MachineName"></param>
        /// <returns></returns>
        public int AssignMachineToBatch(string MachineName)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.AssignMachineToBatch(MachineName);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="MachineName"></param>
        /// <returns></returns>
        public int AssignMachineToSpecialBatch(string MachineName)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.AssignMachineToSpecialBatch(MachineName);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="AssignmentID"></param>
        /// <returns></returns>
        public int CompleteMachineAssignment(int AssignmentID)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.CompleteMachineAssignment(AssignmentID);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public bool FHA_PartA_SettlementSupendData_Update(DataTable dt)
        {
            try
            {
                DataAutomation dal = new DataAutomation(settings);
                return dal.FHA_PartA_SettlementSupendData_Update(dt);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public bool FHA_PartB_SettlementSupendData_Update(DataTable dt)
        {
            try
            {
                DataAutomation dal = new DataAutomation(settings);
                return dal.FHA_PartB_SettlementSupendData_Update(dt);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClientName"></param>
        /// <returns></returns>
        public DataTable FHA_SettlementSuspendData_Select(string ClientName)
        {
            try
            {
                DataAutomation dal = new DataAutomation(settings);
                return dal.FHA_SettlementSuspendData_Select(ClientName);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable GetAutomationClients()
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.GetAutomationClients();

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="DocTypeDescription"></param>
        /// <param name="ClientID"></param>
        /// <returns></returns>
        public DataTable GetBostonWorksFileNameComponents(string DocTypeDescription, string ClientID)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.GetBostonWorksFileNameComponents(DocTypeDescription, ClientID);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable GetDocuware_Automation_Info()
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.GetDocuware_Automation_Info();

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="machineName"></param>
        /// <returns></returns>
        public DataTable GetFHAPartB(string machineName)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.GetFHAPartB(machineName);

            }

            catch (Exception ex)
            {
                throw ex;
            
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="importClientID"></param>
        /// <param name="systemType"></param>
        /// <returns></returns>
        public string[] GetLogin(string importClientID, string systemType)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.GetLogin(importClientID, systemType);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="systemName"></param>
        /// <param name="systemType"></param>
        /// <returns></returns>
        public DataTable GetLogin_BySystemNameAndType(string systemName, string systemType)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.GetLogin_BySystemNameAndType(systemName, systemType);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="systemType"></param>
        /// <returns></returns>
        public DataTable GetLogins_BySystemType(string systemType)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.GetLogins_BySystemType(systemType);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="MachineName"></param>
        /// <returns></returns>
        public DataTable GetMachineProcessAssignments(string MachineName)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.GetMachineProcessAssignments(MachineName);

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="machineName"></param>
        /// <returns></returns>
        public DataTable GetFHA_SFDMS_MIC(string machineName)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.GetFHA_SFDMS_MIC(machineName);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="processID"></param>
        /// <param name="processDate"></param>
        /// <returns></returns>
        public DataTable ImportDataAutomationBatch(DataTable dt, int processID, DateTime processDate)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.ImportDataAutomationBatch(dt, processID, processDate, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        public void Import_LPS_ExistingClaimInventory_for_CMS_match_and_categorize(DataTable dt)
        {
            try
            {
                DataAutomation dal = new DataAutomation(settings);
                dal.Import_LPS_ExistingClaimInventory_for_CMS_match_and_categorize(dt);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        public void Run_LPS_ExistingClaimInventory_to_CMS_match_and_categorize(int clientID)
        {
            try
            {
                DataAutomation dal = new DataAutomation(settings);
                dal.Run_LPS_ExistingClaimInventory_to_CMS_match_and_categorize(clientID);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public DataTable Get_LPS_ExistingClaimInventory_CMS_Matched(DataTable dt)
        {
            try
            {
                DataAutomation dal = new DataAutomation(settings);
                return dal.Get_LPS_ExistingClaimInventory_CMS_Matched(dt);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        public void Run_LPS_ExistingClaimInventory_Cleanup()
        {
            try
            {
                DataAutomation dal = new DataAutomation(settings);
                dal.Run_LPS_ExistingClaimInventory_Cleanup();

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dtNotes"></param>
        /// <returns></returns>
        public bool InvTrk_LoanNotes_Save(DataTable dtNotes)
        {
            try
            {
                DataAutomation dal = new DataAutomation(settings);
                return dal.InvTrk_LoanNotes_Save(dtNotes);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="ProcessCompleteDate"></param>
        /// <param name="ProcessLastUpdateDate"></param>
        /// <param name="FHA_PartB_CaptureImages"></param>
        /// <param name="FHA_PartB_ImageCount"></param>
        /// <returns></returns>
        public int UpdateFHAPartB(int id, DateTime ProcessCompleteDate, DateTime ProcessLastUpdateDate, DateTime FHA_PartB_CaptureImages, int FHA_PartB_ImageCount, string ProcessComments)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.UpdateFHAPartB(id, ProcessCompleteDate, ProcessLastUpdateDate, FHA_PartB_CaptureImages, FHA_PartB_ImageCount, ProcessComments);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="ProcessCompleteDate"></param>
        /// <param name="ProcessLastUpdateDate"></param>
        /// <param name="FHA_SFDMS_CaptureImages"></param>
        /// <param name="FHA_SFDMS_ImageCount"></param>
        /// <param name="FHA_MIC_CaptureImages"></param>
        /// <param name="FHA_MIC_ImageCount"></param>
        /// <param name="ProcessComments"></param>
        /// <returns></returns>
        public int UpdateFHASFDMSMIC(int id, DateTime ProcessCompleteDate, DateTime ProcessLastUpdateDate, DateTime FHA_SFDMS_CaptureImages, int FHA_SFDMS_ImageCount, DateTime FHA_MIC_CaptureImages, int FHA_MIC_ImageCount, string ProcessComments)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.UpdateFHASFDMSMIC(id, ProcessCompleteDate, ProcessLastUpdateDate, FHA_SFDMS_CaptureImages, FHA_SFDMS_ImageCount, FHA_MIC_CaptureImages, FHA_MIC_ImageCount, ProcessComments);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public bool UpdateLoansToPrep_ClientAbbreviation()
        {
            DataAutomation da = new DataAutomation(settings);
            return da.UpdateLoansToPrep_ClientAbbreviation();

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public int UpdateLogin(ref DataTable dt)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.UpdateLogin(ref dt);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        public void CloseAutomationJobLogID(DataTable dt)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                da.CloseAutomationJobLogID(dt);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        public long OpenAutomationJobLogID(string machineName, string command, string arguments, string restartFileName, DateTime startTime)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.OpenAutomationJobLogID(machineName, command, arguments, restartFileName, startTime);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }


        public long OpenJobSystemLog(DataTable dt)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.OpenJobSystemLog(dt);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        public void CloseJobSystemLog(DataTable dt) 
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                da.CloseJobSystemLog(dt);

            }

            catch (Exception ex)
            {
                throw ex;

            }
        
        }

        public long OpenSystemTargetLog(DataTable dt)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.OpenSystemTargetLog(dt);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        public void UpdateTargetActionLog(DataTable dt)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                da.UpdateTargetActionLog(dt);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        // gk fb 4167 20140808
        // read in the history datatable
        public DataTable ReadExistingClaim_History()
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.ReadExistingClaim_History();

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }

        // gk fb 4167 20140808
        // Save the history datatable
        public void SaveExistingClaim_History(DataTable History)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                da.SaveExistingClaim_History(History);

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }

        public DataTable ReadActionLkpTbl()
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.ReadActionLkpTbl();

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        public DataTable ReadResLkpTbl()
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                return da.ReadResLkpTbl();

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }


        #endregion

        #region "Data Automation Reporting"

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="reportPath"></param>
        public void Invalid_FHA_Logons_Report(DataTable dt, string reportPath)
        {
            try
            {
                int TotalRecords = dt.Rows.Count;

                StreamWriter report = new StreamWriter(reportPath);
                WriteReport("FHA Connection Logon Exception Report - " + DateTime.Now.ToString() + " - " + _appMode, report);
                WriteReport("================================================================================", report);
                WriteReport("================================================================================", report); 
                WriteReport("  Total Exception Records: " + TotalRecords.ToString(), report);
                WriteReport("",report);
                WriteReport("================================================================================", report);
                WriteReport("Exceptions Detail:", report);
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        WriteReport("System Name:\t" + dt.Rows[i]["SystemName"].ToString() + "\tLogon:\t" + dt.Rows[i]["SystemID"].ToString() + "\tDate Updated:\t" + dt.Rows[i]["DateUpdated"].ToString(), report);

                    }

                }

                else
                {
                    WriteReport("There were no exceptions.", report);

                }

                report.Close();

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reportPath"></param>
        /// <param name="StartDate"></param>
        /// <param name="EndDate"></param>
        public void PaymentAdvices_Execution_Report(string reportPath, DateTime StartDate, DateTime EndDate)
        {
            try
            {
                MossAutomation ma = new MossAutomation(settings);
                DataTable dt = ma.Get_PaymentAdvices_ExecutionData(StartDate, EndDate);

                int TotalRecords = dt.Rows.Count;
                string ClaimType = "";

                //Table dt has all data for the Payment Advices report for the specified date range.  
                //It needs to be seperated into exceptions and successful records
                DataView dv = new DataView(dt);
                DataTable dtSuccessful = new DataTable();
                DataTable dtExceptions = new DataTable();

                dv.RowFilter = "ProcessStatus = 'Success'";
                dv.Sort = "Client, ClaimType, PaidDate, CaseNumber";
                dtSuccessful = dv.ToTable("Successful");

                dv.RowFilter = "ProcessStatus <> 'Success'";
                dv.Sort = "Client, ClaimType, PaidDate, CaseNumber";
                dtExceptions = dv.ToTable("Exceptions");

                StreamWriter report = new StreamWriter(reportPath);
                WriteReport("FHA Payment Advices Automation Execution Report - " + StartDate.ToString() + " To " + EndDate.ToString() + " - " + _appMode, report);
                WriteReport("================================================================================", report);
                WriteReport("================================================================================", report);
                WriteReport("  Total Records Processed: " + TotalRecords.ToString(), report);
                WriteReport("Total Exceptions Detected: " + dtExceptions.Rows.Count.ToString(), report);
                WriteReport(" Total Successful Records: " + dtSuccessful.Rows.Count.ToString(), report);
                WriteReport("================================================================================", report);
                WriteReport("Exceptions Detail:", report);

                if (dtExceptions.Rows.Count > 0)
                {
                    WriteReport("Client\tClaim Type\tPaid Date\tFHA Case Number\tLoanNumber\tProcess Status", report);

                    for (int i = 0; i < dtExceptions.Rows.Count; i++)
                    {
                        switch (dtExceptions.Rows[i]["ClaimType"].ToString().Substring(0, 3))
                        {
                            case "01A":
                                ClaimType = "Partial Advice";
                                break;

                            case "01B":
                                ClaimType = "Final Advice";
                                break;

                            case "07 ":
                                ClaimType = "PFS (Final) Advice";
                                break;

                            default:
                                break;

                        }

                        WriteReport(dtExceptions.Rows[i]["Client"].ToString() + "\t" + ClaimType + "\t" + DateTime.Parse(dtExceptions.Rows[i]["PaidDate"].ToString()).ToShortDateString() + "\t" + dtExceptions.Rows[i]["CaseNumber"].ToString() + "\t" + dtExceptions.Rows[i]["LoanNumber"].ToString() + "\t" + dtExceptions.Rows[i]["ProcessStatus"].ToString(), report);

                    }

                }

                else
                {
                    WriteReport("There were no exceptions.", report);

                }

                WriteReport("================================================================================", report);
                WriteReport("Successful Processing Detail:", report);

                if (dtSuccessful.Rows.Count > 0)
                {
                    WriteReport("Client\tClaim Type\tPaid Date\tFHA Case Number\tLoanNumber\tProcess Status", report);

                    for (int i = 0; i < dtSuccessful.Rows.Count; i++)
                    {
                        switch (dtSuccessful.Rows[i]["ClaimType"].ToString().Substring(0, 3))
                        {
                            case "01A":
                                ClaimType = "Partial Advice";
                                break;

                            case "01B":
                                ClaimType = "Final Advice";
                                break;

                            case "07 ":
                                ClaimType = "PFS (Final) Advice";
                                break;

                            default:
                                break;

                        }

                        WriteReport(dtSuccessful.Rows[i]["Client"].ToString() + "\t" + ClaimType + "\t" + DateTime.Parse(dtSuccessful.Rows[i]["PaidDate"].ToString()).ToShortDateString() + "\t" + dtSuccessful.Rows[i]["CaseNumber"].ToString() + "\t" + dtSuccessful.Rows[i]["LoanNumber"].ToString() + "\t" + dtSuccessful.Rows[i]["ProcessStatus"].ToString(), report);

                    }

                }

                else
                {
                    WriteReport("There were no records processed successfully.", report);

                }

                report.Close();


            }

            catch (Exception ex)
            { 
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reportPath"></param>
        /// <param name="StartDate"></param>
        /// <param name="EndDate"></param>
        public void SFDMS_MIC_Execution_Report(string reportPath, DateTime StartDate, DateTime EndDate)
        {
            try
            {
                MossAutomation ma = new MossAutomation(settings);
                DataTable dt = ma.GetSFDMS_MIC_ExecutionData(StartDate, EndDate);

                int TotalRecords = dt.Rows.Count;
                
                //Table dt has all data for the SFDMS_MIC report for the specified date range.  It needs to be seperated into exceptions and successful records
                DataView dv = new DataView(dt);
                DataTable dtSuccessful = new DataTable();
                DataTable dtExceptions = new DataTable();

                dv.RowFilter = "ProcessStatus = 'SFDMS Success | MIC Success'";
                dtSuccessful = dv.ToTable("Successful");

                dv.RowFilter = "ProcessStatus <> 'SFDMS Success | MIC Success'";
                dtExceptions = dv.ToTable("Exceptions");

                StreamWriter report = new StreamWriter(reportPath);
                WriteReport("SFDMS/MIC Automation Execution Report - " + StartDate.ToString() + " To " + EndDate.ToString() + " - " + _appMode , report);
                WriteReport("================================================================================", report);
                WriteReport("================================================================================", report); 
                WriteReport("  Total Records Processed: " + TotalRecords.ToString(), report);
                WriteReport("Total Exceptions Detected: " + dtExceptions.Rows.Count.ToString(), report);
                WriteReport(" Total Successful Records: " + dtSuccessful.Rows.Count.ToString(), report);
                WriteReport("================================================================================", report);
                WriteReport("Exceptions Detail:", report);

                if (dtExceptions.Rows.Count > 0)
                {
                    for (int i = 0; i < dtExceptions.Rows.Count; i++)
                    {
                        WriteReport("Client:\t" + dtExceptions.Rows[i]["Client"].ToString() + "\tFHA Case Number:\t" + dtExceptions.Rows[i]["CaseNumber"].ToString() + "\tLoanNumber:\t" + dtExceptions.Rows[i]["LoanNumber"].ToString() + "\tProcess Status:\t" + dtExceptions.Rows[i]["ProcessStatus"].ToString(), report);

                    }

                }

                else
                {
                    WriteReport("There were no exceptions.", report);

                }

                WriteReport("================================================================================", report);
                WriteReport("Successful Processing Detail:", report);

                if (dtSuccessful.Rows.Count > 0)
                {
                    for (int i = 0; i < dtSuccessful.Rows.Count; i++)
                    {
                        WriteReport("Client:\t" + dtSuccessful.Rows[i]["Client"].ToString() + "\tFHA Case Number:\t" + dtSuccessful.Rows[i]["CaseNumber"].ToString() + "\tLoanNumber:" + dtSuccessful.Rows[i]["LoanNumber"].ToString() + "\tProcess Status:\t" + dtSuccessful.Rows[i]["ProcessStatus"].ToString(), report);

                    }

                }

                else
                {
                    WriteReport("There were no records processed successfully.", report);

                }

                report.Close();

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reportLine"></param>
        /// <param name="sw"></param>
        public void WriteReport(string reportLine, StreamWriter sw)
        {
            try
            {
                sw.WriteLine(reportLine);
                sw.Flush();

            }

            catch (System.IO.IOException ex)
            {
                throw ex;

            }

        }

        #endregion

        #region "Investor Tracking"

        /// <summary>
        /// 
        /// </summary>
        /// <param name="loanData"></param>
        /// <param name="loanID"></param>
        /// <returns>DataTable</returns>
        public DataTable ClaimsManagement_GetInvestorTrackingLoan(DataTable loanData, int loanID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new CRFS.Data.ClaimsManagement();
                return cm.GetInvestorTrackingLoan(loanData, loanID, settings);
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        /*31043
        /// <summary>
        /// 
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable ClaimsManagement_GetCMAXClients()
        {
            try
            {
                ApplicationConfiguration ac = new ApplicationConfiguration(settings);
                DataTable dtCMAXClients = ac.Get_CMax_Attributes(settings);
                DataView dvCMAXClients = new DataView(dtCMAXClients);

                DataTable dtcboCMAXClients = new DataTable();
                dtcboCMAXClients = Build_CMAXClients_Table();

                //Add the 'No Filter' combo box choice
                dtcboCMAXClients.Rows.Add();
                DataView dvcboCMAXClients0 = new DataView(dtcboCMAXClients);
                dvcboCMAXClients0[0]["Filter"] = "%";
                dvcboCMAXClients0[0]["DisplayValue"] = "No Filter";

                //
                //Process each of the incoming records
                for (int i = 0; i < dvCMAXClients.Count; i++)
                {
                    try
                    {
                        //Build combobox table to display concatenated view of CMAX Client # and CMAX Client Name
                        dtcboCMAXClients.Rows.Add();
                        DataView dvcboCMAXClients = new DataView(dtcboCMAXClients);

                        //Since the 'No filter' row was added above, we need to add 1 to index of new row added
                        dvcboCMAXClients[i+1]["Filter"] = dvCMAXClients[i]["CMSClientID"];
                        dvcboCMAXClients[i+1]["DisplayValue"] = dvCMAXClients[i]["CMaxClientID"].ToString()  + '-' + dvCMAXClients[i]["ClientName"].ToString() ;
                    }

                    catch (Exception ex)
                    {
                        throw ex;

                    }

                NextRecord: ;

                }
                //
                return dtcboCMAXClients;
            } 

            catch (Exception ex)
            {
                throw ex;
            }
        }
        */
        /// <summary>
        /// 
        /// </summary>
        /// <returns>DataTable</returns>
        private DataTable Build_CMAXClients_Table()
        {
            try
            {
                DataTable dt = new DataTable("CMAXClients");

                dt.Columns.Add("Filter", typeof(string));
                dt.Columns.Add("DisplayValue", typeof(string));

                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable BuildInvestorTrackingPaymentFollowupTable()
        {
            try
            {
                CRFS.Data.ConventionalClaimsDataAccess ccda = new CRFS.Data.ConventionalClaimsDataAccess(settings);
                return ccda.BuildInvestorTrackingPaymentFollowupTable();

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable BuildInvestorTrackingWorkflowStepTable()
        {
            try
            {
                CRFS.Data.ConventionalClaimsDataAccess ccda = new CRFS.Data.ConventionalClaimsDataAccess(settings);
                return ccda.BuildInvestorTrackingWorkflowStepTable();

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        public DataTable BuildInvestorTrackingWorkflowStepLookupTable()
        {
            try
            {
                CRFS.Data.ClaimsManagement dal = new ClaimsManagement(settings);
                return dal.BuildInvestorTrackingWorkflowStepLookupTable();

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FormID"></param>
        /// <returns></returns>
        public DataTable GetClaimTypes_ByForm(int FormID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new CRFS.Data.ClaimsManagement();
                return cm.Get_ClaimTypes_ByFormID(FormID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable Get_DisplayMasks()
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new CRFS.Data.ClaimsManagement();
                return cm.Get_DisplayMasks(settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable Get_DisplayControls()
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new CRFS.Data.ClaimsManagement();
                return cm.Get_DisplayControls(settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="claimID"></param>
        /// <returns></returns>
        public DataTable GetInvestorTrackingPmtFollowupComments(int claimID)
        {
            try
            {
                ConventionalClaimsDataAccess ccda = new ConventionalClaimsDataAccess(settings);
                return ccda.GetInvestorTrackingPmtFollowupComments(claimID);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        public DataTable Get_InvestorTracking_PFUEOB_Complete_Matrix()
        {
            try
            {
                CRFS.Data.ApplicationConfiguration ac = new CRFS.Data.ApplicationConfiguration(settings);
                return ac.Get_InvestorTracking_PFUEOB_Complete_Matrix();

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="claimID"></param>
        /// <returns></returns>
        public DataTable GetInvestorTracking_Claim(DataTable dt, int claimID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new CRFS.Data.ClaimsManagement();
                return cm.GetInvestorTracking_Claim(dt, claimID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="claimID"></param>
        /// <returns></returns>
        public DataTable GetInvestorTracking_VAClaim(DataTable dt, int claimID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new CRFS.Data.ClaimsManagement();
                return cm.GetInvestorTracking_VAClaim(dt, claimID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        
        public DataTable GetInvestorTrackingReporting_RecSheet(int claimID, string ClaimType)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new CRFS.Data.ClaimsManagement();
                return cm.GetInvestorTrackingReporting_RecSheet(claimID, ClaimType, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }
        
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="InvestorName"></param>
        /// <param name="ClaimType"></param>
        /// <returns></returns>
        public DataTable GetInvestorTrackingPaymentFollowupIntervals(string InvestorName, string ClaimType)
        {
            try
            {
                CRFS.Data.ApplicationConfiguration ac = new CRFS.Data.ApplicationConfiguration(settings);
                return ac.GetInvestorTrackingPaymentFollowupIntervals(InvestorName, ClaimType, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="MICompanyName"></param>
        /// <param name="ClaimType"></param>
        /// <returns></returns>
        public DataTable GetInvestorTrackingMIPaymentFollowupIntervals(string MICompanyName, string ClaimType)
        {
            try
            {
                CRFS.Data.ApplicationConfiguration ac = new CRFS.Data.ApplicationConfiguration(settings);
                return ac.GetInvestorTrackingMIPaymentFollowupIntervals(MICompanyName, ClaimType, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClaimType"></param>
        /// <returns></returns>
        public DataTable GetInvestorTrackingUSDAPaymentFollowupIntervals(string ClaimType)
        {
            try
            {
                CRFS.Data.ApplicationConfiguration ac = new CRFS.Data.ApplicationConfiguration(settings);
                return ac.GetInvestorTrackingUSDAPaymentFollowupIntervals(ClaimType, settings);
            }

            catch (Exception ex)
            {
                throw ex;

            }
        }

        public DataTable GetClaimTypeNameXref()
        {
            try
            {
                CRFS.Data.ApplicationConfiguration ac = new CRFS.Data.ApplicationConfiguration(settings);
                return ac.GetClaimTypeNameXref( settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClientID"></param>
        /// <returns></returns>
        public DataTable Get_InvestorTracking_ClaimsSubmitted_ByClientID(int ClientID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new CRFS.Data.ClaimsManagement(settings);
                return cm.Get_InvestorTracking_ClaimsSubmitted_ByClientID(ClientID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="claimID"></param>
        /// <returns></returns>
        public DataTable GetInvestorTrackingWorkflowSteps(int claimID)
        {
            try
            {
                CRFS.Data.ConventionalClaimsDataAccess dal = new ConventionalClaimsDataAccess(settings);
                return dal.GetInvestorTrackingWorkflowSteps(claimID);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="workflowStepsData"></param>
        /// <returns></returns>
        public DataTable Get_InvestorTracking_WorkflowActiveStepsData(DataTable workflowStepsData)
        {
            try
            {
                CRFS.Data.ClaimsManagement dal = new ClaimsManagement(settings);
                return dal.Get_InvestorTracking_WorkflowActiveStepsData(workflowStepsData, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Organization"></param>
        /// <returns></returns>
        public DataTable GetOrganizationHolidays(string Organization)
        {
            try
            {
                CRFS.Data.ApplicationConfiguration ac = new CRFS.Data.ApplicationConfiguration(settings);
                return ac.GetOrganizationHolidays(Organization, settings);

            }
            
            catch (Exception ex)
            {
                throw ex;

            }

        }
        
        /*31043
         * Removing this block
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable Get_LPS_Vendorscape_ClientNames()
        {
            try
            {
                CRFS.Data.ApplicationConfiguration ac = new CRFS.Data.ApplicationConfiguration(settings);
                return ac.Get_LPS_Vendorscape_ClientNames(settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        */
        /// <summary>
        /// 
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable InvestorTracking_InvestorNames_Get()
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.InvestorTracking_InvestorNames_Get(settings);
            }

            catch (Exception ex)
            {
                throw (ex);

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClaimID"></param>
        /// <returns></returns>
        public DataTable InvTrk_SelectLoanID_ByClaimID(int ClaimID)
        {
            CRFS.Data.ConventionalClaimsDataAccess ccda = new CRFS.Data.ConventionalClaimsDataAccess(settings);
            return ccda.InvTrk_SelectLoanID_ByClaimID(ClaimID);

        }
        /*31043
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="databaseName"></param>
        /// <param name="processDate"></param>
        /// <param name="processID"></param>
        /// <param name="events"></param>
        /// <param name="userUniqueID"></param>
        /// <returns></returns>
        public DataTable ImportLPSPaid2CMSInvestorTracking(DataTable dt, string databaseName, string processDate, int processID, Moss.Events.Events events, int userUniqueID)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                ClaimsManagement cm = new ClaimsManagement();
                CRFS.Data.DataFunctions df2 = new CRFS.Data.DataFunctions(_appMode);

                return da.ImportLPSPaid2CMSInvestorTracking(dt, databaseName, processDate, settings, processID, events, userUniqueID, cm, df2);
            }

            catch (SystemException ex)
            {
                throw ex;
            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="databaseName"></param>
        /// <param name="processDate"></param>
        /// <param name="processID"></param>
        /// <param name="events"></param>
        /// <param name="userUniqueID"></param>
        /// <returns></returns>
        public DataTable Import_VendorscapePaid2CMSInvestorTracking(DataTable dt, string databaseName, string processDate, int processID, Moss.Events.Events events, int userUniqueID)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                ClaimsManagement cm = new ClaimsManagement();
                CRFS.Data.DataFunctions df2 = new CRFS.Data.DataFunctions(_appMode);

                return da.ImportVendorscapePaid2CMSInvestorTracking(dt, databaseName, processDate, settings, processID, events, userUniqueID, cm, df2);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        */
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public bool SaveInvestorTrackingClaim(DataTable dt)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.SaveInvestorTrackingClaim(dt, settings);

            }

            catch (SqlException ex)
            {
                processSqlException(ex);
                return false;
            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        public bool SaveInvestorTracking_Claim_LPSImportSpecific(DataTable dt)
        {
            try
            {
                CRFS.Data.ConventionalClaimsDataAccess ccda = new ConventionalClaimsDataAccess(settings);
                return ccda.SaveInvestorTracking_Claim_LPSImportSpecific(dt);

            }

            catch (Exception ex)
            {
                throw ex;

            }


        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public bool SaveInvestorTrackingVAClaim(DataTable dt)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.SaveInvestorTrackingVAClaim(dt, settings);

            }
            catch (SqlException ex)
            {
                processSqlException(ex);
                return false;
            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool SaveInvestorTrackingLoan(DataTable data)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.SaveInvestorTrackingLoan(data, settings);

            }
            catch (SqlException ex)
            {
                processSqlException(ex);
                return false;
            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="missingDocuments"></param>
        /// <param name="loanID"></param>
        /// <returns></returns>
        public DataTable ClaimsManagement_GetInvestorTrackingMissingDocument(DataTable missingDocuments, int loanID,int claimID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.GetInvestorTrackingLoanMissingDocument(missingDocuments, loanID, claimID,settings);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="missingDocs"></param>
        /// <returns></returns>
        public bool ClaimsManagement_SaveInvestorTrackingMissingDocs(DataTable missingDocs)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.SaveInvestorTrackingLoanMissingDocs(missingDocs, settings);
            }
            catch (SqlException ex)
            {
                processSqlException(ex);
                return false;
            }
            
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pmtFollowup"></param>
        /// <returns></returns>
        public bool SaveInvestorTracking_PaymentFollowup(DataTable pmtFollowup)
        {
            try
            {
                CRFS.Data.ConventionalClaimsDataAccess ccda = new ConventionalClaimsDataAccess(settings);
                return ccda.SaveInvestorTracking_PaymentFollowup(pmtFollowup);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pmtFollowup"></param>
        /// <returns></returns>
        public bool BulkSave_InvestorTracking_PaymentFollowup(DataTable pmtFollowup)
        {
            try
            {
                CRFS.Data.ConventionalClaimsDataAccess ccda = new ConventionalClaimsDataAccess(settings);
                return ccda.BulkSave_InvestorTracking_PaymentFollowup(pmtFollowup);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dtWorkflow"></param>
        /// <returns></returns>
        public bool SaveInvestorTracking_Workflow_Data(DataTable dtWorkflow)
        {
            try
            {
                CRFS.Data.ConventionalClaimsDataAccess dal = new ConventionalClaimsDataAccess(settings);
                return dal.SaveInvestorTracking_Workflow_Data(dtWorkflow);

            }

            catch (SqlException ex)
            {
                // error was already shown
                processSqlException(ex);
                return false;
            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dtWorkflow"></param>
        /// <returns></returns>
        public bool BulkSave_InvestorTracking_Workflow_Data(DataTable dtWorkflow)
        {
            try
            {
                CRFS.Data.ConventionalClaimsDataAccess dal = new ConventionalClaimsDataAccess(settings);
                return dal.BulkSave_InvestorTracking_Workflow_Data(dtWorkflow);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="CMSLoginID"></param>
        /// <param name="SearchValue"></param>
        /// <returns></returns>
        public DataTable searchClaims_ByLoanNumber(int CMSLoginID, string SearchValue)
        {
            try
            {
                ConventionalClaimsDataAccess ccda = new ConventionalClaimsDataAccess(settings);
                return ccda.searchClaims_ByLoanNumber(CMSLoginID, SearchValue);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable VendorscapeComparisonData_Select()
        {
            try
            {
                DataAutomation dal = new DataAutomation(settings);
                return dal.VendorscapeComparisonData_Select();

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        #endregion

        #region "FNMA PFU"
        /// <summary>
        /// Retrieves the FNMA PFU follow up dates that are displayed in the 'Payment Follow Up Actions' tab.
        /// </summary>
        /// <param name="referralID"></param>
        /// <returns>DataTable</returns>
        public DataTable ClaimsManagment_GetPFUDatesByReferralID(int referralID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.ClaimsManagment_GetPFUDatesByReferralID(referralID, settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="referralID"></param>
        /// <returns></returns>
        public DataTable GetPFUReferralData(int referralID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.GetPFUReferralData(referralID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable GetMICompanyNames()
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.GetMICompanyNames(settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable GetPFUReferralTypes()
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.GetPFUReferralTypes(settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable GetServicerNames()
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.GetServicerNames(settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="ReferralTypeID"></param>
        /// <param name="databaseName"></param>
        /// <param name="processDate"></param>
        /// <param name="processID"></param>
        /// <param name="events"></param>
        /// <param name="userUniqueID"></param>
        /// <returns></returns>
        public DataTable ImportCMSFNMAPaymentFollowup(DataTable dt, int ReferralTypeID, string databaseName, string processDate, int processID, Moss.Events.Events events, int userUniqueID)
        {
            try
            {
                DataAutomation pm = new DataAutomation(settings);
                ClaimsManagement cm = new ClaimsManagement();

                return pm.ImportCMSFNMAPaymentFollowup(dt, ReferralTypeID, databaseName, processDate, settings, processID, events, userUniqueID, cm);
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool ClaimsManagement_SavePFUDetails(DataTable data)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.ClaimsManagement_SavePFUDetails(data, settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns>true if SOX cleared</returns>
        public bool ClaimsManagement_ClearSoxClaimedFiled()
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement(settings);
                return cm.ClaimsManagement_ClearSoxClaimedFiled();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="ReferralTypeID"></param>
        /// <param name="processDate"></param>
        /// <param name="userUniqueID"></param>
        /// <returns></returns>
        public DataTable ImportPFU_CloseAndBill(DataTable dt, int ReferralTypeID, string processDate, int userUniqueID)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                ClaimsManagement cm = new ClaimsManagement(settings);

                return da.ImportPFU_CloseAndBill(dt, ReferralTypeID, processDate, userUniqueID, cm);


            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool SavePFUReferral(DataTable data)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.SavePFUReferral(data, settings);
            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="referralID"></param>
        /// <returns></returns>
        public DataTable ClaimsManagment_GetPFUDetailsByReferralID(int referralID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.ClaimsManagment_GetPFUDetailsByReferralID(referralID, settings);
            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ReferralTypeID"></param>
        /// <param name="rptName"></param>
        /// <param name="optParms"></param>
        /// <returns></returns>
        public DataTable GetPFUReporting_ClaimFiledUpdateReport(int ReferralTypeID, string rptName, string[] optParms)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.GetPFUReporting_ClaimFiledUpdateReport(settings, ReferralTypeID, optParms);
            }           

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ReferralTypeID"></param>
        /// <param name="rptName"></param>
        /// <param name="optParms"></param>
        /// <returns></returns>
        public DataTable GetPFUReporting_DelayedProceedsUpdateReport(int ReferralTypeID, string rptName, string[] optParms)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.GetPFUReporting_DelayedProceedsUpdateReport(settings, ReferralTypeID, optParms);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ReferralTypeID"></param>
        /// <param name="rptName"></param>
        /// <param name="optParms"></param>
        /// <returns></returns>
        public DataTable GetPFUReporting_CommentUpdateReport(int ReferralTypeID, string rptName, string[] optParms)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.GetPFUReporting_CommentUpdateReport(settings, ReferralTypeID, optParms);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Returns referral lock information for the FNMA PFU application.
        /// </summary>
        /// <returns>Table of all current locks for the FNMA PFU application</returns>
        public DataTable PFU_Locks_List_Get()
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.PFU_Locks_List_Get(settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// FNMA PFU lock save.
        /// </summary>
        /// <param name="data">Lock record to process</param>
        /// <returns></returns>
        public bool PFU_Lock_Save(DataTable data)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.PFU_Lock_Save(data, settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="ReferralTypeID"></param>
        /// <param name="databaseName"></param>
        /// <param name="processDate"></param>
        /// <param name="processID"></param>
        /// <param name="events"></param>
        /// <param name="userUniqueID"></param>
        /// <returns></returns>
        //[VIP-410] CRZ 20111028
        public DataTable ImportFNMA_PFU_SOX_ClaimFiled(DataTable dt, int ReferralTypeID, string databaseName, string processDate, int processID, Moss.Events.Events events, int userUniqueID)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                ClaimsManagement cm = new ClaimsManagement();

                return da.ImportFNMA_PFU_SOX_ClaimFiled(dt, ReferralTypeID, databaseName, processDate, settings, processID, events, userUniqueID, cm);
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="ReferralTypeID"></param>
        /// <param name="databaseName"></param>
        /// <param name="processDate"></param>
        /// <param name="processID"></param>
        /// <param name="events"></param>
        /// <param name="userUniqueID"></param>
        /// <returns></returns>
        //[VIP-410] CRZ 20111028
        public DataTable ImportFNMA_PFU_SOX_DelayedProceeds(DataTable dt, int ReferralTypeID, string databaseName, string processDate, int processID, Moss.Events.Events events, int userUniqueID)
        {
            try
            {
                DataAutomation da = new DataAutomation(settings);
                ClaimsManagement cm = new ClaimsManagement();

                return da.ImportFNMA_PFU_SOX_DelayedProceeds(dt, ReferralTypeID, databaseName, processDate, settings, processID, events, userUniqueID, cm);
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="SearchValue"></param>
        /// <returns></returns>
        public DataTable searchFNMAPFU_ByLoanNumberREOID(string SearchValue)
        {
            try
            {
                FNMAReferralDataAccess frda = new FNMAReferralDataAccess(settings);
                return frda.searchFNMAPFU_ByLoanNumberREOID(SearchValue);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        
        #endregion

        #region "FNMA Recon"
        internal void set_Settings_FormID_Recon()
        {
            settings.FormID = (int)FormConstants.FNMAReconciliation;
            settings.conn.appID = (int)ClaimProcessingConstants.ClaimsManagementSystem.AppID.FNMAReconciliation;
        }

        
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable Recon_CategoryCodes_Get()
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                set_Settings_FormID_Recon();
                return fr.Recon_CategoryCodes_Get(settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ReferralID"></param>
        /// <returns></returns>
        public DataTable Recon_ClaimItem_Get(int ReferralID)
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                set_Settings_FormID_Recon();
                return fr.Recon_ClaimItem_Get(ReferralID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool Recon_ClaimItem_Save(DataTable data)
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                set_Settings_FormID_Recon();
                return fr.Recon_ClaimItem_Save(data, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="referralID"></param>
        /// <returns></returns>
        public DataTable Recon_Comments_Get(int referralID)
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                set_Settings_FormID_Recon();
                return fr.Recon_Comments_Get(referralID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool Recon_Comments_Save(DataTable data)
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                set_Settings_FormID_Recon();
                return fr.Recon_Comments_Save(data, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="referralID"></param>
        /// <returns></returns>
        public DataTable Recon_EOBValues_Get(int referralID)
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                set_Settings_FormID_Recon();
                return fr.Recon_EOBValues_Get(referralID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool Recon_EOBValues_Save(DataTable data)
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                set_Settings_FormID_Recon();
                return fr.Recon_EOBValues_Save(data, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="referralID"></param>
        /// <returns></returns>
        public DataTable Recon_Referral_Get(int referralID)
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                set_Settings_FormID_Recon();
                return fr.Recon_Referral_Get(referralID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool Recon_Referral_Save(DataTable data)
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                set_Settings_FormID_Recon();
                return fr.Recon_Referral_Save(data, settings);


            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable ReconReferralTypesSelect()
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                set_Settings_FormID_Recon();
                return fr.Recon_ReferralTypes_Select(settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="referralID"></param>
        /// <returns></returns>
        public DataTable Recon_Transactions_Get(int referralID)
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                set_Settings_FormID_Recon();
                return fr.Recon_Transactions_Get(referralID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool Recon_Transactions_Save(DataTable data)
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                set_Settings_FormID_Recon();
                return fr.Recon_Transactions_Save(data, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="searchType"></param>
        /// <param name="searchValue"></param>
        /// <param name="formID"></param>
        /// <returns></returns>
        public DataSet Recon_FindClaims(string searchType, string searchValue)
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                set_Settings_FormID_Recon();
                return fr.Recon_FindClaims(searchType, searchValue, settings);
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="formID"></param>
        /// <param name="importAsDate"></param>
        /// <param name="userUniqueID"></param>
        /// <param name="events"></param>
        /// <returns></returns>
        public DataTable ImportRecon(DataTable data, int referralTypeID, int formID, string importAsDate, int userUniqueID, Moss.Events.Events events)
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess(settings);
                set_Settings_FormID_Recon();
                return fr.ImportRecon(data, referralTypeID, formID, importAsDate, userUniqueID, events, this, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="claimItemAttributeName"></param>
        /// <returns></returns>
        public DataTable Recon_ClaimItemAttributeID_Get(string claimItemAttributeName)
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                set_Settings_FormID_Recon();
                return fr.Recon_ClaimItemAttributeID_Get(claimItemAttributeName, settings);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ReferralTypeID"></param>
        /// <param name="optParms"></param>
        /// <returns></returns>
        public DataTable Recon_Referral_Select_ByID(int ReferralTypeID, string[] optParms)
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                set_Settings_FormID_Recon();
                return fr.Recon_Referral_Select_ByID(ReferralTypeID, settings, optParms);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// Returns referral lock information for the FNMA Reconciliation application.
        /// </summary>
        /// <returns>Table of all current locks for the FNMA PFU application</returns>
        public DataTable Recon_Locks_List_Get()
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                return fr.Recon_Locks_List_Get(settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// FNMA Reconciliation lock save.
        /// </summary>
        /// <param name="data">Lock record to process</param>
        /// <returns></returns>
        public bool Recon_Lock_Save(DataTable data)
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                return fr.Recon_Lock_Save(data, settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        // fb4102 gk 20140710
        /// <summary>
        /// clear all the locks for a given user and workstation
        /// </summary>
        /// <param name="LockedByUserID">userId</param>
        /// <param name="WorkStationName">WorkStationName</param>
        /// <returns></returns>
        public bool ClearLocksForUserAndStation(int LockedByUserID, string WorkStationName)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.ClearLocksForUserAndStation(LockedByUserID, WorkStationName,settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="searchValue"></param>
        /// <returns></returns>
        public DataTable searchFNMARecon_ByLoanNumberREOID(string searchValue)
        {
            CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess(settings);
            set_Settings_FormID_Recon();
            return fr.searchFNMARecon_ByLoanNumberREOID(searchValue);

        }

        public DataTable Reconciliation_BillingStatusTypes_Get()
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                set_Settings_FormID_Recon();
                return fr.Reconciliation_BillingStatusTypes_Get(settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable Reconciliation_CommentTypes_Get()
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                set_Settings_FormID_Recon();
                return fr.Reconciliation_CommentTypes_Get(settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable Reconciliation_DispositionStatusTypes_Get()
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                set_Settings_FormID_Recon();
                return fr.Reconciliation_DispositionStatusTypes_Get(settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable Reconciliation_SettlementTypes_Get()
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                set_Settings_FormID_Recon();
                return fr.Reconciliation_SettlementTypes_Get(settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable Reconciliation_StatusTypes_Get()
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                set_Settings_FormID_Recon();
                return fr.Reconciliation_StatusTypes_Get(settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable Reconciliation_NoBillReasons_Get()
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                set_Settings_FormID_Recon();
                return fr.Reconciliation_NoBillReasons_Get(settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable Reconciliation_ApplicationReferralEvents_Get(int referralID)
        {
            try
            {
                CRFS.Data.FNMAReconciliation_DataAccess fr = new FNMAReconciliation_DataAccess();
                set_Settings_FormID_Recon();
                return fr.Reconciliation_ApplicationReferralEvents_Get(settings, referralID);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region "FNMA DataGram"

        internal void set_Settings_FormID_DataGram()
        {
            settings.FormID = (int)FormConstants.FNMADataGram;
            settings.conn.appID = (int)ClaimProcessingConstants.ClaimsManagementSystem.AppID.FNMAREOGram;
        }

        /// <summary>
        /// Performs the import for FNMA Asset Collections Datagram Penalty referrals.
        /// </summary>
        /// <param name="data">Table of data for the Datagram referral record.</param>
        /// <param name="referralTypeID">Indicates the Asset Collections referral type ID (Datagram, Hazard, Advance Payment)</param>
        /// <param name="formID">Application formID from tbllkp_Forms.</param>
        /// <param name="importAsDate">Date to use for importing the data record.</param>
        /// <param name="userUniqueID">user ID performing the import.</param>
        /// <param name="events">Moss.Events object</param>
        /// <param name="df">CRFS.Data.Datafunctions object.</param>
        /// <param name="settings">Contains the database connection information which determines
        /// whether we're working with Development, Test, Production, etc.</param>
        /// <returns>Data table of data records imported and the process results for each record.</returns>
        public DataTable ImportAssetCollection(DataTable data, int referralTypeID, int formID, string importAsDate, int userUniqueID, Moss.Events.Events events)
        {
            try
            {
                CRFS.Data.FNMADataGram_DataAccess da = new CRFS.Data.FNMADataGram_DataAccess(settings);
                set_Settings_FormID_DataGram();
                return da.ImportAssetCollection(data, referralTypeID, formID, importAsDate, userUniqueID, events, this, settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable Import_AssetColl_Datagram(DataTable data, string importAsDate, int userUniqueID, Moss.Events.Events events)
        {
            try
            {
                CRFS.Data.FNMADataGram_DataAccess da = new CRFS.Data.FNMADataGram_DataAccess(settings);
                set_Settings_FormID_DataGram();
                return da.Import_AssetColl_Datagram(data, importAsDate, userUniqueID, events, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// Retrieves the invoice data to generate the Servicer invoice letters with
        /// for HIP Collections and DataGram Penalty Collections.
        /// </summary>
        /// <param name="data">Referral data from FNMA Asset Collections import to
        /// include on the Servicer invoice.</param>
        /// <returns>Data table containing data import referral records.</returns>
        ////public DataTable AssetCol_InvoiceData_Get(DataTable data)
        ////{
        ////    try
        ////    {
        ////        CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
        ////        return cm.AssetCol_InvoiceData_Get(settings);
        ////    }

        ////    catch (Exception ex)
        ////    {
        ////        throw ex;
        ////    }
        ////}

        /// <summary>
        /// Retrieves the invoice data to generate the Servicer invoice letters with
        /// for HIP Collections and DataGram Penalty Collections.
        /// </summary>
        /// <param name="data">Referral data from FNMA Asset Collections import to
        /// include on the Servicer invoice.</param>
        /// <returns>Data table containing data import referral records.</returns>
        public DataTable AssetColl_Datagram_InvoiceData_Get()
        {
            try
            {
                CRFS.Data.FNMADataGram_DataAccess da = new CRFS.Data.FNMADataGram_DataAccess();
                set_Settings_FormID_DataGram();
                return da.AssetColl_Datagram_InvoiceData_Get(settings);

            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Public access to reoutine that retrieves all group invoice summary data for inclusion 
        /// on the invoice on the summary tab added for the 2/2013 servicer invoicing iteration
        /// </summary>
        /// <returns>Table of summarized invoice data</returns>
        public DataTable AssetColl_Datagram_InvoiceSummary_Get()
        {
            try
            {
                CRFS.Data.FNMADataGram_DataAccess da = new CRFS.Data.FNMADataGram_DataAccess();
                set_Settings_FormID_DataGram();
                return  da.AssetColl_Datagram_InvoiceSummary_Get(settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool AssetColl_Datagram_InvoiceUpdate(DataTable data)
        {
            try
            {
                CRFS.Data.FNMADataGram_DataAccess da = new CRFS.Data.FNMADataGram_DataAccess();
                set_Settings_FormID_DataGram();
                return da.AssetColl_Datagram_InvoiceUpdate(data, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="group"></param>
        /// <returns></returns>
        public DataTable AdvPmt_ServicerEmails_Get(string group)
        {
            try
            {
                CRFS.Data.FNMAReferralDataAccess dal = new FNMAReferralDataAccess();
                return dal.AdvPmt_ServicerEmails_Get(settings,group);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void AdvPmt_JobDone(int ID,bool success,string errMsg,DateTime endDate,string emailAddr,string attachment)
        {
            try
            {
                CRFS.Data.FNMAReferralDataAccess dal = new FNMAReferralDataAccess();
                dal.AdvPmt_JobDone(settings,ID,success,errMsg,endDate,emailAddr,attachment);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// Retrieves the servicer emails for editing in the admin panel
        /// </summary>
        /// <param name="data">Table of Servicer e-mail info to use for invoice e-mailing.</param>
        /// <returns>Table of Servicer e-mail info to use for invoice e-mailing.</returns>
        public DataTable AssetColl_ServicerEmails2_Get(DataTable data)
        {
            try
            {
                CRFS.Data.FNMADataGram_DataAccess da = new CRFS.Data.FNMADataGram_DataAccess();
                set_Settings_FormID_DataGram();
                return da.AssetColl_ServicerEmail2_Get(settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Retrieves all table data for the DatagramReferral table. Some additional columns
        /// are included for the string translation of ID lookup values.
        /// </summary>
        /// <param name="datagramReferralID">The PK referral ID of interest.</param>
        /// <returns>A table with a single row containing the DatagramReferral data.</returns>
        public DataTable AssetColl_DatagramReferral_Get(int datagramReferralID)
        {
            try
            {
                CRFS.Data.FNMADataGram_DataAccess da = new CRFS.Data.FNMADataGram_DataAccess();
                set_Settings_FormID_DataGram();
                return da.AssetColl_DatagramReferral_Get(datagramReferralID, settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Saves data for the DatagramReferral record via the Datagram update 
        /// stored procedure.
        /// </summary>
        /// <param name="data">Table of data for the Datagram referral record.</param>
        /// <returns>Boolean indicator of success for failure.</returns>
        public bool AssetColl_Datagram_Save(DataTable data)
        {
            try
            {
                CRFS.Data.FNMADataGram_DataAccess da = new CRFS.Data.FNMADataGram_DataAccess();
                set_Settings_FormID_DataGram();
                return da.AssetColl_Datagram_Save(data, settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Data wrapper for claim searches for Asset Collections.
        /// </summary>
        /// <param name="searchType">The selection from the combobox list for the type of search being performed.</param>
        /// <param name="searchValue">Search value typed in by user</param>
        /// <returns></returns>
        public DataSet AssetCollections_FindClaims(string searchType, string searchValue)
        {
            try
            {
                CRFS.Data.FNMADataGram_DataAccess da = new CRFS.Data.FNMADataGram_DataAccess();
                set_Settings_FormID_DataGram();
                return da.AssetCollections_FindClaims(searchType, searchValue, settings);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Retrieves the valid referral (collection) types for FNMA Asset Collections.
        /// </summary>
        /// <returns>DataTable with all valid referral types for FNMA Asset Collections.</returns>
        public DataTable AssetCollReferralTypesSelect()
        {
            try
            {
                CRFS.Data.FNMADataGram_DataAccess da = new CRFS.Data.FNMADataGram_DataAccess();
                set_Settings_FormID_DataGram();
                return da.Datagram_lkp_Datagram_ReferralTypes_Get(settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Retrieves all Datagram comments for the specified referral ID.
        /// </summary>
        /// <param name="datagramReferralID">The PK referral ID of interest.</param>
        /// <returns></returns>
        public DataTable AssetColl_DatagramComments_Get(int ReferralID)
        {
            try
            {
                CRFS.Data.FNMADataGram_DataAccess da = new CRFS.Data.FNMADataGram_DataAccess();
                set_Settings_FormID_DataGram();
                return da.AssetColl_DatagramComments_Get(ReferralID, settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Saves the comment records for the current referral
        /// </summary>
        /// <param name="data">Table of comments retrieved for the Datagram referral.</param>
        /// <returns></returns>
        public bool AssetColl_DatagramComments_Save(DataTable data)
        {
            try
            {
                CRFS.Data.FNMADataGram_DataAccess da = new CRFS.Data.FNMADataGram_DataAccess();
                set_Settings_FormID_DataGram();
                return da.AssetColl_DatagramComments_Save(data, settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }


        //MJF 07/13/2017 FB 45210 
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable AssetColl_DatagramInvoiceStatus_Get()
        {
            try
            {
                CRFS.Data.FNMADataGram_DataAccess da = new CRFS.Data.FNMADataGram_DataAccess();
                set_Settings_FormID_DataGram();
                return da.Datagram_lkp_Datagram_InvoiceStatusTypes_Get(settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        //MJF 07/13/2017 FB 45210
        public DataTable AssetColl_DatagramStatus_Get()
        {
            try
            {
                CRFS.Data.FNMADataGram_DataAccess da = new CRFS.Data.FNMADataGram_DataAccess();
                set_Settings_FormID_DataGram();
                return da.Datagram_lkp_Datagram_StatusTypes_Get(settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }


        //MJF 07/13/2017 FB 45210
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable AssetColl_DatagramCommentTypes_Get()
        {
            try
            {
                CRFS.Data.FNMADataGram_DataAccess da = new CRFS.Data.FNMADataGram_DataAccess();
                set_Settings_FormID_DataGram();
                return da.Datagram_lkp_Datagram_CommentTypes_Get(settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable Datagram_ApplicationReferralEvents_Get(int DatagramReferralID)
        {
            try
            {

                CRFS.Data.FNMADataGram_DataAccess da = new CRFS.Data.FNMADataGram_DataAccess();
                set_Settings_FormID_DataGram();
                return da.Datagram_ApplicationReferralEvents_Get(settings, DatagramReferralID);
            }

            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Saves contact info from the Admin panel
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public bool AssetColl_ServicerEmail_Save(DataTable data, int CMSUserID)
        {
            try
            {
                CRFS.Data.FNMADataGram_DataAccess da = new CRFS.Data.FNMADataGram_DataAccess();
                set_Settings_FormID_DataGram();
                return da.AssetColl_ServicerEmail_Save(data, settings, CMSUserID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// Retrieves all table data for the AdvPmtReferral table. Some additional columns
        /// are included for the string translation of ID lookup values.
        /// </summary>
        /// <param name="datagramReferralID">The PK referral ID of interest.</param>
        /// <returns>A table with a single row containing the DatagramReferral data.</returns>
        public DataTable AssetColl_AdvPmtReferral_Get(int advPmtReferralID)
        {
            try
            {
                CRFS.Data.FNMADataGram_DataAccess da = new CRFS.Data.FNMADataGram_DataAccess();
                set_Settings_FormID_DataGram();
                return da.AssetColl_AdvPmtReferral_Get(advPmtReferralID, settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Saves data for the AdvPmtReferral record via the Advance Payment update 
        /// stored procedure.
        /// </summary>
        /// <param name="data">Table of data for the Advance referral record.</param>
        /// <returns>Boolean indicator of success for failure.</returns>
        public bool AssetColl_AdvPmt_Save(DataTable data)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.AssetColl_AdvPmt_Save(data, settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Retrieves all Advance Payment comments for the specified referral ID.
        /// </summary>
        /// <param name="advancePaymentReferralID">The PK referral ID of interest.</param>
        /// <returns></returns>
        public DataTable AssetColl_AdvPmtComments_Get(int advPmtReferralID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.AssetColl_AdvPmtComments_Get(advPmtReferralID, settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Saves the comment records for the current referral
        /// </summary>
        /// <param name="data">Table of comments retrieved for the Advance Payment referral.</param>
        /// <returns></returns>
        public bool AssetColl_AdvPmtComments_Save(DataTable data)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.AssetColl_AdvPmtComments_Save(data, settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Retrieves the edit history for the specified Referral ID. The Referral ID and
        /// ReferralTypeID are required to match the correct record. The audit table will 
        /// store results for all Asset Collections transactions, so the referralID may not 
        /// be unique. The combination of referralID and referralTypeID, however, wil be.
        /// </summary>
        /// <param name="referralID">Record identifier to retrieve data for.</param>
        /// <param name="referralTypeID">ID from tbllkp_Forms_ComboBoxValues indicating which type of Asset Collection this record belongs to.</param>
        /// <returns>DataTable of the edit history records for the specified referral.</returns>
        public DataTable AssetColl_EditHistory_Get(int referralID, int referralTypeID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.AssetColl_EditHistory_Get(referralID,referralTypeID, settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Retrieves a specific FNMA Asset Collections referral by REO ID, FNMA Loan Number
        /// and Referraltype. the same REO ID and FNMA Loan # combination can exist in each of
        /// the AssetCollections databases.
        /// </summary>
        /// <param name="referralTypeID">ID from tbllkp_Forms_ComboBoxValues indicating which type of Asset Collection this record belongs to.</param>
        /// <param name="optParms">Array containing the REO ID [0] and the FNMA Loan # [1].</param>
        /// <returns></returns>
        public DataTable AssetCollections_SelectReferralID(int referralTypeID, string[] optParms)
        {
            try
            {
                CRFS.Data.FNMADataGram_DataAccess da = new CRFS.Data.FNMADataGram_DataAccess();
                set_Settings_FormID_DataGram();
                return da.AssetCollections_SelectReferralID(referralTypeID, settings, optParms);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Returns referral lock information for the FNMA Asset Collections application.
        /// </summary>
        /// <param name="lockFormID">Unique identifier for the Asset Collection referral type</param>
        /// <param name="referralTypeID">ID from tbllkp_Forms_ComboBoxValues indicating which type of Asset Collection this record belongs to.</param>
        /// <returns>Table of all current locks for the FNMA Asset Collections application</returns>
        public DataTable AssetColl_Locks_List_Get(int lockFormID, int referralTypeID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.AssetColl_Locks_List_Get(lockFormID, referralTypeID, settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// FNMA Asset Collections lock save.
        /// </summary>
        /// <param name="data">Lock record to process</param>
        /// <returns></returns>
        public bool AssetColl_Lock_Save(DataTable data)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.AssetColl_Lock_Save(data, settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Retrieves the list of CMS security groups and their security level value.
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public DataTable Get_CMS_SecurityGroups()
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new CRFS.Data.ClaimsManagement(settings);
                return cm.Get_CMS_SecurityGroups();
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion
        
        #region "FNMA AdvPmt"
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable AdvPmt_InvoiceData_Get()
        {
            try
            {
                CRFS.Data.FNMAReferralDataAccess dal = new FNMAReferralDataAccess();
                return dal.AdvPmt_InvoiceData_Get(settings);

            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        //
        public void AdvPmt_SetReferralInvoiced(DataTable data, int updateUser)
        {
            try
            {
                CRFS.Data.FNMAReferralDataAccess dal = new FNMAReferralDataAccess();
                dal.AdvPmt_SetReferralInvoiced(data, updateUser, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        #endregion

        #region "Reporting"

        #region "Common Reporting"
        #endregion

        #region "Claims 332 Reporting"
        #endregion

        #region "Investor Tracking Reporting"
        /// <summary>
        /// 
        /// </summary>
        /// <param name="reportName"></param>
        /// <param name="InvestorName"></param>
        /// <param name="ClientID"></param>
        /// <param name="optParms"></param>
        /// <returns>DataTable</returns>
        public DataTable ClaimsManagement_GetInvestorTrackingReporting_General(string reportName, string InvestorName, string ClientID, string[] optParms)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.GetInvestorTrackingReporting_General(reportName, InvestorName, ClientID, settings, optParms);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reportName"></param>
        /// <param name="InvestorName"></param>
        /// <param name="ClientID"></param>
        /// <returns>DataTable</returns>
        public DataTable ClaimsManagement_GetInvestorTrackingReporting_MissingDocuments(string reportName, string InvestorName, string ClientID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.GetInvestorTrackingReporting_MissingDocuments(reportName, InvestorName, ClientID, settings);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reportName"></param>
        /// <param name="InvestorName"></param>
        /// <param name="ClientID"></param>
        /// <returns>DataTable</returns>
        public DataTable Get_InvestorTracking_PaymentFollowupExceptions_General(string reportName, string InvestorName, string ClientID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.Get_InvestorTracking_PaymentFollowupExceptions_General(reportName, InvestorName, ClientID, settings);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reportName"></param>
        /// <param name="InvestorName"></param>
        /// <param name="ClientID"></param>
        /// <returns>DataTable</returns>
        public DataTable Get_InvestorTracking_EOBNotComplete_General(string reportName, string InvestorName, string ClientID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new ClaimsManagement();
                return cm.Get_InvestorTracking_EOBNotComplete_General(reportName, InvestorName, ClientID, settings);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region "FNMA PFU Reporting"
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable FNMA_PFU_Missing_Document_Escalation_Report()
        {
            try
            {
                ClaimsManagement cm = new ClaimsManagement(settings);
                return cm.FNMA_PFU_Missing_Document_Escalation_Report(settings);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ReferralTypeID"></param>
        /// <returns></returns>
        public DataTable FNMA_PFU_MISettledLoanNotClosed_Report(int ReferralTypeID)
        {
            try
            {
                ClaimsManagement cm = new ClaimsManagement(settings);
                return cm.FNMA_PFU_MISettledLoanNotClosed_Report(settings, ReferralTypeID);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        #endregion
        #endregion

        #region "Security"
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="EncryptedPW"></param>
        /// <returns></returns>
        public DataTable ClaimsManagement_ConfirmLoginUser(string id, string EncryptedPW)
        {
            try
            {
                ClaimsManagement cm = new ClaimsManagement(settings);
                return cm.ClaimsManagement_ConfirmLoginUser(id, EncryptedPW);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="UserName"></param>
        /// <param name="UserID"></param>
        /// <param name="MachineName"></param>
        /// <param name="AppVersion"></param>
        /// <param name="LoginSuccessful"></param>
        /// <returns></returns>
        public bool InsertLoginActivity(string UserName, string UserID, string MachineName, string AppVersion, bool LoginSuccessful)
        {
            try
            {
                ClaimsManagement cm = new ClaimsManagement(settings);
                return cm.InsertLoginActivity(UserName, UserID, MachineName, AppVersion, LoginSuccessful);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public DataTable GetLoginActivity(string UserID)
        {
            try
            {
                ClaimsManagement cm = new ClaimsManagement(settings);
                return cm.GetLoginActivity(UserID);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        #endregion

        #region "FHA"
        //20130429 TRS - Consolidated FHA functions to this area
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="claimID"></param>
        /// <returns></returns>
        public DataTable GetInvestorTracking_FHACWCOT_Claim(DataTable dt, int claimID)
        {
            try
            {
                CRFS.Data.FHAClaimsDataAccess dal = new CRFS.Data.FHAClaimsDataAccess();
                return dal.GetInvestorTracking_FHACWCOT_Claim(dt, claimID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="claimID"></param>
        /// <returns></returns>
        public DataTable GetInvestorTracking_FHAPartA_Claim(DataTable dt, int claimID)
        {
            try
            {
                CRFS.Data.FHAClaimsDataAccess dal = new CRFS.Data.FHAClaimsDataAccess();
                return dal.GetInvestorTracking_FHAPartA_Claim(dt, claimID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="claimID"></param>
        /// <returns></returns>
        public DataTable GetInvestorTracking_FHAPartB_Claim(DataTable dt, int claimID)
        {
            try
            {
                CRFS.Data.FHAClaimsDataAccess dal = new CRFS.Data.FHAClaimsDataAccess();
                return dal.GetInvestorTracking_FHAPartB_Claim(dt, claimID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="claimID"></param>
        /// <returns></returns>
        public DataTable GetInvestorTracking_FHAPFS_Claim(DataTable dt, int claimID)
        {
            try
            {
                CRFS.Data.FHAClaimsDataAccess dal = new CRFS.Data.FHAClaimsDataAccess();
                return dal.GetInvestorTracking_FHAPFS_Claim(dt, claimID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="claimID"></param>
        /// <returns></returns>
        public DataTable GetInvestorTracking_FHASFLS_Claim(DataTable dt, int claimID)
        {
            try
            {
                CRFS.Data.FHAClaimsDataAccess dal = new CRFS.Data.FHAClaimsDataAccess();
                return dal.GetInvestorTracking_FHASFLS_Claim(dt, claimID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="claimID"></param>
        /// <returns></returns>
        public DataTable GetInvestorTracking_FHACombined_Claim(DataTable dt, int claimID)
        {
            try
            {
                CRFS.Data.FHAClaimsDataAccess dal = new CRFS.Data.FHAClaimsDataAccess();
                return dal.GetInvestorTracking_FHACombined_Claim(dt, claimID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        public DataTable GetInvestorTracking_FHACombined_Claim_ByFHAClaimID(DataTable dt, int FHAClaimID)
        {
            try
            {
                CRFS.Data.FHAClaimsDataAccess dal = new CRFS.Data.FHAClaimsDataAccess();
                return dal.GetInvestorTracking_FHACombined_Claim_ByFHAClaimID(dt, FHAClaimID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="claimID"></param>
        /// <returns></returns>
        public DataTable GetInvestorTracking_FHAFollowUp( int claimID)
        {
            try
            {
                CRFS.Data.FHAClaimsDataAccess dal = new CRFS.Data.FHAClaimsDataAccess();
                return dal.GetInvestorTracking_FHAFollowUp(claimID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="claimID"></param>
        /// <returns></returns>
        public DataTable GetInvestorTracking_VAFollowUp(int claimID)
        {
            try
            {
                CRFS.Data.VAClaimsDataAccess dal = new CRFS.Data.VAClaimsDataAccess();
                return dal.GetInvestorTracking_VAFollowUp(claimID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="claimID"></param>
        /// <returns></returns>
        public DataTable GetInvestorTracking_FHACombined_Errors(DataTable dt, int claimID)
        {
            try
            {
                CRFS.Data.FHAClaimsDataAccess dal = new CRFS.Data.FHAClaimsDataAccess();
                return dal.GetInvestorTracking_FHACombined_Errors(dt, claimID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        //_cdf.GetInvestorTracking_FHACombined_SubmitHistory(new DataTable(), _claimID);
        public DataTable GetInvestorTracking_FHACombined_SubmitHistory(DataTable dt, int claimID)
        {
            try
            {
                CRFS.Data.FHAClaimsDataAccess dal = new CRFS.Data.FHAClaimsDataAccess();
                return dal.GetInvestorTracking_FHACombined_SubmitHistory(dt, claimID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClaimID"></param>
        /// <param name="ClaimPart"></param>
        /// <param name="userid"></param>
        /// <returns></returns>
        public int doEDIUncheck(int ClaimID, string ClaimPart,int userid)
        {
            try
            {
                CRFS.Data.FHAClaimsDataAccess dal = new CRFS.Data.FHAClaimsDataAccess(settings);
                return dal.doEDIUncheck(ClaimID, ClaimPart,userid);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="invTrk_ClaimID"></param>
        /// <param name="claimPart"></param>
        /// <returns></returns>
        public string IsEDIAuthChecked_Allowed(int invTrk_ClaimID,string claimPart=FHAPartDontCare)
        {
            try
            {
                CRFS.Data.FHAClaimsDataAccess dal = new CRFS.Data.FHAClaimsDataAccess(settings);
                return dal.IsEDIAuthChecked_Allowed(invTrk_ClaimID,claimPart);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public bool SaveInvestorTrackingFHAPartAClaim(DataTable dt)
        {
            try
            {
                CRFS.Data.FHAClaimsDataAccess dal = new CRFS.Data.FHAClaimsDataAccess();
                return dal.SaveInvestorTrackingFHAPartAClaim(dt, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public bool SaveInvestorTrackingFHAPartBClaim(DataTable dt)
        {
            try
            {
                CRFS.Data.FHAClaimsDataAccess dal = new CRFS.Data.FHAClaimsDataAccess();
                return dal.SaveInvestorTrackingFHAPartBClaim(dt, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public bool SaveInvestorTrackingFHAPFSClaim(DataTable dt)
        {
            try
            {
                CRFS.Data.FHAClaimsDataAccess dal = new CRFS.Data.FHAClaimsDataAccess();
                return dal.SaveInvestorTrackingFHAPFSClaim(dt, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public bool SaveInvestorTrackingFHACWCOTClaim(DataTable dt)
        {
            try
            {
                CRFS.Data.FHAClaimsDataAccess dal = new CRFS.Data.FHAClaimsDataAccess();
                return dal.SaveInvestorTrackingFHACWCOTClaim(dt, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public bool SaveInvestorTrackingFHASFLSClaim(DataTable dt)
        {
            try
            {
                CRFS.Data.FHAClaimsDataAccess dal = new CRFS.Data.FHAClaimsDataAccess();
                return dal.SaveInvestorTrackingFHASFLSClaim(dt, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public bool SaveInvestorTrackingFHACombinedClaim(DataTable dt)
        {
            try
            {
                CRFS.Data.FHAClaimsDataAccess dal = new CRFS.Data.FHAClaimsDataAccess();
                return dal.SaveInvestorTrackingFHACombinedClaim(dt, settings);

            }

            catch (SqlException ex)
            {
                processSqlException(ex);
                return false;
            }
            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public bool SaveEDISubmitComment(DataTable dt)
        {
            try
            {
                CRFS.Data.FHAClaimsDataAccess dal = new CRFS.Data.FHAClaimsDataAccess();
                return dal.SaveEDISubmitComment(dt, settings);

            }

            catch (SqlException ex)
            {
                processSqlException(ex);
                return false;
            }
            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public bool SaveInvestorTrackingFHAFollowUp(DataTable dt)
        {
            try
            {
                CRFS.Data.FHAClaimsDataAccess dal = new CRFS.Data.FHAClaimsDataAccess();
                return dal.SaveInvestorTrackingFHAFollowUp(dt, settings);

            }

            catch (SqlException ex)
            {
                processSqlException(ex);
                return false;
            }
            catch (Exception ex)
            {
                throw ex;

            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public bool SaveInvestorTrackingVAFollowUp(DataTable dt)
        {
            try
            {
                CRFS.Data.VAClaimsDataAccess dal = new CRFS.Data.VAClaimsDataAccess();
                return dal.SaveInvestorTrackingVAFollowUp(dt, settings);

            }

            catch (SqlException ex)
            {
                processSqlException(ex);
                return false;
            }
            catch (Exception ex)
            {
                throw ex;

            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="CMSLoginID"></param>
        /// <param name="SearchValue"></param>
        /// <returns></returns>
        public DataTable searchFHAClaims_ByLoanNumberCaseNumber(int CMSLoginID, string SearchValue)
        {
            try
            {
                FHAClaimsDataAccess fcda = new FHAClaimsDataAccess(settings);
                return fcda.searchFHAClaims_ByLoanNumberCaseNumber(CMSLoginID, SearchValue);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }


        #endregion

        #region "VA"
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="CMSLoginID"></param>
        /// <param name="SearchValue"></param>
        /// <returns></returns>
        public DataTable searchVAClaims_ByLoanNumberCaseNumber(int CMSLoginID, string SearchValue)
        {
            try
            {
                VAClaimsDataAccess vcda = new VAClaimsDataAccess(settings);
                return vcda.searchVAClaims_ByLoanNumberCaseNumber(CMSLoginID, SearchValue);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        #endregion

        #region CmdLinePdf
        /// <summary>
        /// 
        /// </summary>
        /// <param name="fhaClaimID"></param>
        /// <returns></returns>
        public DataTable HUDClaims_VW_PartA_Select(long fhaClaimID)
        {
            try
            {
                HUDClaimsDataAccess dal = new HUDClaimsDataAccess(settings);
                return dal.HUDClaims_VW_PartA_Select(fhaClaimID);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="PartAid"></param>
        /// <returns></returns>
        public DataTable HUDClaims_vw_FHALivingUnits_SelectBy_PartAid(long PartAid)
        {
            try
            {
                HUDClaimsDataAccess dal = new HUDClaimsDataAccess(settings);
                return dal.HUDClaims_vw_FHALivingUnits_SelectBy_PartAid(PartAid);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable HUDClaims_VwTaxScheduleSelect()
        {
            try
            {
                HUDClaimsDataAccess dal = new HUDClaimsDataAccess(settings);
                return dal.HUDClaims_VwTaxScheduleSelect();

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fhaClaimID"></param>
        /// <returns></returns>
        public DataTable HUDClaims_VW_PartB_Select(long fhaClaimID)
        {
            try
            {
                HUDClaimsDataAccess dal = new HUDClaimsDataAccess(settings);
                return dal.HUDClaims_VW_PartB_Select(fhaClaimID);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="FHAClaimID"></param>
        /// <returns></returns>
        public DataTable HUDClaims_VW_PartC_SelectByClaimID(int FHAClaimID)
        {
            try
            {
                HUDClaimsDataAccess dal = new HUDClaimsDataAccess(settings);
                return dal.HUDClaims_VW_PartC_SelectByClaimID(FHAClaimID);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="FHACaseNo"></param>
        /// <returns></returns>
        public DataTable HUDClaims_VW_PartC_Select(string FHACaseNo)
        {
            try
            {
                HUDClaimsDataAccess dal = new HUDClaimsDataAccess(settings);
                return dal.HUDClaims_VW_PartC_Select(FHACaseNo);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="PartC27011ID"></param>
        /// <returns></returns>
        public DataTable HUDCLaims_Get_vw_PandP_by_PartcID(long PartC27011ID)
        {
            try
            {
                HUDClaimsDataAccess dal = new HUDClaimsDataAccess(settings);
                return dal.HUDCLaims_Get_vw_PandP_by_PartcID(PartC27011ID);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FHAClaimID"></param>
        /// <returns></returns>
        public DataTable HUDClaims_VW_PartD_SelectbyClaimid(int FHAClaimID)
        {
            try
            {
                HUDClaimsDataAccess dal = new HUDClaimsDataAccess(settings);
                return dal.HUDClaims_VW_PartD_SelectbyClaimid(FHAClaimID);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="FHACaseNo"></param>
        /// <returns></returns>
        public DataTable HUDClaims_VW_PartD_Select(string FHACaseNo)
        {
            try
            {
                HUDClaimsDataAccess dal = new HUDClaimsDataAccess(settings);
                return dal.HUDClaims_VW_PartD_Select(FHACaseNo);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="PartD27011ID"></param>
        /// <returns></returns>
        public DataTable usp_HUDCLaims_Select_PartDBlocks_ByDid(long PartD27011ID)
        {
            try
            {
                HUDClaimsDataAccess dal = new HUDClaimsDataAccess(settings);
                return dal.usp_HUDCLaims_Select_PartDBlocks_ByDid(PartD27011ID);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="PartD27011ID"></param>
        /// <returns></returns>
        public DataTable usp_HUDCLaims_Select_Block308_ByDid(long PartD27011ID)
        {
            try
            {
                HUDClaimsDataAccess dal = new HUDClaimsDataAccess(settings);
                return dal.usp_HUDCLaims_Select_Block308_ByDid(PartD27011ID);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="PartD27011ID"></param>
        /// <returns></returns>
        public DataTable usp_HUDCLaims_Select_Block309_ByDid(long PartD27011ID)
        {
            try
            {
                HUDClaimsDataAccess dal = new HUDClaimsDataAccess(settings);
                return dal.usp_HUDCLaims_Select_Block309_ByDid(PartD27011ID);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="PartD27011ID"></param>
        /// <returns></returns>
        public DataTable usp_HUDCLaims_Select_Block311_ByDid(long PartD27011ID)
        {
            try
            {
                HUDClaimsDataAccess dal = new HUDClaimsDataAccess(settings);
                return dal.usp_HUDCLaims_Select_Block311_ByDid(PartD27011ID);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="FHAClaimID"></param>
        /// <returns></returns>
        public DataTable HUDClaims_VW_PartE_SelectByClaimID(int FHAClaimID)
        {
            try
            {
                HUDClaimsDataAccess dal = new HUDClaimsDataAccess(settings);
                return dal.HUDClaims_VW_PartE_SelectByClaimID(FHAClaimID);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="FHACaseNo"></param>
        /// <returns></returns>
        public DataTable HUDClaims_VW_PartE_Select(string FHACaseNo)
        {
            try
            {
                HUDClaimsDataAccess dal = new HUDClaimsDataAccess(settings);
                return dal.HUDClaims_VW_PartE_Select(FHACaseNo);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="PartEid"></param>
        /// <returns></returns>
        public DataTable HUDClaims_PartE_Multiblock_SelectBy_PartEid(long PartEid)
        {
            try
            {
                HUDClaimsDataAccess dal = new HUDClaimsDataAccess(settings);
                return dal.HUDClaims_PartE_Multiblock_SelectBy_PartEid(PartEid);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        #endregion

        #region "HUDClaims"
        public bool isFHAClaimTypeClaimSubTypeOnboardedForClient(int ClientID, int ClaimTypeID, int ClaimSubTypeID)
        {
            try
            {
                HUDClaimsDataAccess dal = new HUDClaimsDataAccess(settings);
                return dal.isFHAClaimTypeClaimSubTypeOnboardedForClient(ClientID, ClaimTypeID, ClaimSubTypeID);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        public DataTable Get_InvestorTracking_EDIAuthMatrixTable()
        {
            try
            {
                HUDClaimsDataAccess dal = new HUDClaimsDataAccess(settings);
                return dal.Get_InvestorTracking_EDIAuthMatrixTable();
            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        public DataTable Get_HUDClaims_ClaimData(DataTable dt, int ClaimID)
        {
            try
            {
                HUDClaimsDataAccess dal = new HUDClaimsDataAccess(settings);
                return dal.Get_HUDClaims_ClaimData(dt, ClaimID);
            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        public DataTable Get_HUDClaims_LoanData(DataTable dt, int LoanID)
        {
            try
            {
                HUDClaimsDataAccess dal = new HUDClaimsDataAccess(settings);
                return dal.Get_HUDClaims_LoanData(dt, LoanID);
            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        #endregion
        #region "recsheet clone"
        public int GetRecSheetItemsCount(int ClaimID)
        {
            try
            {
                CRFS.Data.ClaimsManagement cm = new CRFS.Data.ClaimsManagement();
                return cm.RecSheetItemsCount(ClaimID, settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sourceClaimID"></param>
        /// <param name="targetClaimID"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        public bool InvTrk_Clone_RecSheet(int sourceClaimID, int targetClaimID, int userID)
        {
            try
            {
                CRFS.Data.ConventionalClaimsDataAccess dal = new ConventionalClaimsDataAccess(settings);
                return dal.InvTrk_Clone_RecSheet(sourceClaimID, targetClaimID, userID);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        #endregion
        #region DWStorage
        // fb34513 gk 20160820
        /// <summary>
        /// 
        /// </summary>
        /// <param name="claims"></param>
        /// <returns></returns>
        public DataTable GetDWStorageParameters(DataTable claims)
        {
            try
            {
                CRFS.Data.ApplicationConfiguration ac = new ApplicationConfiguration(settings);
                return ac.GetDWStorageParameters(claims,  settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public DataTable DWLocatorGetEndpoint(DataTable dt)
        {
            try
            {
                CRFS.Data.ApplicationConfiguration ac = new ApplicationConfiguration(settings);
                return ac.DWLocatorGetEndpoint(dt,  settings);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        #endregion

    }

}
