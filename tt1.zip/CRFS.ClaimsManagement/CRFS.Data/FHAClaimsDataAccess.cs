﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;


namespace CRFS.Data
{
    class FHAClaimsDataAccess
    {
        CRFS.Data.Settings _settings;

        internal FHAClaimsDataAccess()
        {
        }

        internal FHAClaimsDataAccess(CRFS.Data.Settings settings)
        {
            _settings = settings;
        }

        #region "Common"
        
        internal DataTable searchFHAClaims_ByLoanNumberCaseNumber(int CMSLoginID, string SearchValue)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable("Claims");

                dt.Columns.Add("LoanID", typeof(int));
                dt.Columns.Add("LoanNumber", typeof(string));
                dt.Columns.Add("FHACaseNumber", typeof(string));
                dt.Columns.Add("ClaimID", typeof(int));
                dt.Columns.Add("ClientID", typeof(int));
                dt.Columns.Add("ClientName", typeof(string));
                dt.Columns.Add("ClaimTypeID", typeof(int));
                dt.Columns.Add("ClaimType", typeof(string));
                dt.Columns.Add("ClaimDueDate", typeof(DateTime));
                dt.Columns.Add("ReferralDate", typeof(DateTime));
                dt.Columns.Add("OpenSteps", typeof(int));
                dt.Columns.Add("ClaimFormID", typeof(int));
                dt.Columns.Add("FormName", typeof(string));
                dt.Columns.Add("BorrowerFirstName", typeof(string));
                dt.Columns.Add("BorrowerLastName", typeof(string));
                dt.Columns.Add("PropertyAddress", typeof(string));
                dt.Columns.Add("PropertyCity", typeof(string));
                dt.Columns.Add("PropertyState", typeof(string));
                dt.Columns.Add("PropertyZip", typeof(string));

                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_CNTL_FHA_FindClaim_ByLoanNumberCaseNumber";

                SqlParameter parm = new SqlParameter("@UserID", CMSLoginID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@SearchValue", SearchValue);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["LoanID"] = int.Parse(dr["LoanID"].ToString().Length == 0 ? "0" : dr["LoanID"].ToString());
                    row["LoanNumber"] = dr["LoanNumber"].ToString();
                    row["FHACaseNumber"] = dr["FHACaseNumber"].ToString();
                    row["ClaimID"] = int.Parse(dr["ClaimID"].ToString().Length == 0 ? "0" : dr["ClaimID"].ToString());
                    row["ClientID"] = int.Parse(dr["ClientID"].ToString().Length == 0 ? "0" : dr["ClientID"].ToString());
                    row["ClientName"] = dr["ClientName"].ToString();
                    row["ClaimTypeID"] = int.Parse(dr["ClaimTypeID"].ToString().Length == 0 ? "0" : dr["ClaimTypeID"].ToString());
                    row["ClaimType"] = dr["ClaimType"].ToString();
                    row["ClaimDueDate"] = DateTime.Parse(dr["ClaimDueDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClaimDueDate"].ToString());
                    row["ReferralDate"] = DateTime.Parse(dr["ReferralDate"].ToString().Length == 0 ? "1/1/1900" : dr["ReferralDate"].ToString());
                    row["OpenSteps"] = int.Parse(dr["OpenSteps"].ToString().Length == 0 ? "0" : dr["OpenSteps"].ToString());
                    row["ClaimFormID"] = int.Parse(dr["ClaimFormID"].ToString().Length == 0 ? "0" : dr["ClaimFormID"].ToString());
                    row["FormName"] = dr["FormName"].ToString();
                    row["BorrowerFirstName"] = dr["BorrowerFirstName"].ToString();
                    row["BorrowerLastName"] = dr["BorrowerLastName"].ToString();
                    row["PropertyAddress"] = dr["PropertyAddress"].ToString();
                    row["PropertyCity"] = dr["PropertyCity"].ToString();
                    row["PropertyState"] = dr["PropertyState"].ToString();
                    row["PropertyZip"] = dr["PropertyZip"].ToString();

                    dt.Rows.Add(row);

                }

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        internal int doEDIUncheck(int claimid, string claimpart,int userid)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_ClaimsManagement_UncheckEDI";

                cmd.Parameters.Add(new SqlParameter("@UserID", userid));
                cmd.Parameters.Add(new SqlParameter("@ClaimID", claimid));
                cmd.Parameters.Add(new SqlParameter("@ClaimPart", claimpart));
                return int.Parse(cmd.ExecuteScalar().ToString());
            }

            catch (Exception ex)
            {
                throw ex;

            }


            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="invTrk_ClaimID"></param>
        /// <returns></returns>
        internal string IsEDIAuthChecked_Allowed(int invTrk_ClaimID,string claimPart)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT dbo.ufn_IsEDIAuthAllowed(" + invTrk_ClaimID.ToString() + ",'"+claimPart+"')";

                string rtnValue = cmd.ExecuteScalar().ToString();
                return rtnValue;

            }

            catch (Exception ex)
            {
                throw ex;

            }


            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }

        }


        #endregion

        #region "Part A"
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="claimID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetInvestorTracking_FHAPartA_Claim(DataTable dt, int claimID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_InvTrk_FHAPartA_Select";

                SqlParameter parm = new SqlParameter("@ClaimID", claimID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["FHAPartAClaimID"] = (int)dr["FHAPartAClaimID"];
                    row["ClaimID"] = (int)dr["ClaimID"];
                    row["UnpaidBalance"] = decimal.Parse(dr["UnpaidBalance"].ToString().Length == 0 ? "0" : dr["UnpaidBalance"].ToString());
                    row["MHT"] = bool.Parse(dr["MHT"].ToString().Length == 0 ? "false" : dr["MHT"].ToString());
                    row["MHTReviewedDate"] = DateTime.Parse(dr["MHTReviewedDate"].ToString().Length == 0 ? "1/1/1900" : dr["MHTReviewedDate"].ToString());
                    row["MHTStartDate"] = DateTime.Parse(dr["MHTStartDate"].ToString().Length == 0 ? "1/1/1900" : dr["MHTStartDate"].ToString());
                    row["MHTEndDate"] = DateTime.Parse(dr["MHTEndDate"].ToString().Length == 0 ? "1/1/1900" : dr["MHTEndDate"].ToString());
                    row["FTVDate"] = DateTime.Parse(dr["FTVDate"].ToString().Length == 0 ? "1/1/1900" : dr["FTVDate"].ToString());
                    row["ICCDate"] = DateTime.Parse(dr["ICCDate"].ToString().Length == 0 ? "1/1/1900" : dr["ICCDate"].ToString());
                    row["ICCReportDate"] = DateTime.Parse(dr["ICCReportDate"].ToString().Length == 0 ? "1/1/1900" : dr["ICCReportDate"].ToString());
                    row["FCLDeedRecordedDate"] = DateTime.Parse(dr["FCLDeedRecordedDate"].ToString().Length == 0 ? "1/1/1900" : dr["FCLDeedRecordedDate"].ToString());
                    row["HUDDeedRecordedDate"] = DateTime.Parse(dr["HUDDeedRecordedDate"].ToString().Length == 0 ? "1/1/1900" : dr["HUDDeedRecordedDate"].ToString());
                    row["PrepCompleteDate"] = DateTime.Parse(dr["PrepCompleteDate"].ToString().Length == 0 ? "1/1/1900" : dr["PrepCompleteDate"].ToString());
                    row["PrepAnalystID"] = int.Parse(dr["PrepAnalystID"].ToString().Length == 0 ? "0" : dr["PrepAnalystID"].ToString());
                    row["SubmitQCDate"] = DateTime.Parse(dr["SubmitQCDate"].ToString().Length == 0 ? "1/1/1900" : dr["SubmitQCDate"].ToString());
                    row["SubmitQCAnalystID"] = int.Parse(dr["SubmitQCAnalystID"].ToString().Length == 0 ? "0" : dr["SubmitQCAnalystID"].ToString());
                    row["QCApprovedDate"] = DateTime.Parse(dr["QCApprovedDate"].ToString().Length == 0 ? "1/1/1900" : dr["QCApprovedDate"].ToString());
                    row["QCApprovedAnalystID"] = int.Parse(dr["QCApprovedAnalystID"].ToString().Length == 0 ? "0" : dr["QCApprovedAnalystID"].ToString());
                    row["SubmittedDate"] = DateTime.Parse(dr["SubmittedDate"].ToString().Length == 0 ? "1/1/1900" : dr["SubmittedDate"].ToString());
                    row["SubmittedAnalystID"] = int.Parse(dr["SubmittedAnalystID"].ToString().Length == 0 ? "0" : dr["SubmittedAnalystID"].ToString());
                    row["ClaimAmount"] = decimal.Parse(dr["ClaimAmount"].ToString().Length == 0 ? "0" : dr["ClaimAmount"].ToString());
                    row["SettlementDate"] = DateTime.Parse(dr["SettlementDate"].ToString().Length == 0 ? "1/1/1900" : dr["SettlementDate"].ToString());
                    row["PaidAmount"] = decimal.Parse(dr["PaidAmount"].ToString().Length == 0 ? "0" : dr["PaidAmount"].ToString());
                    row["SuspendDate"] = DateTime.Parse(dr["SuspendDate"].ToString().Length == 0 ? "1/1/1900" : dr["SuspendDate"].ToString());
                    row["ErrorSubmitDate"] = DateTime.Parse(dr["ErrorSubmitDate"].ToString().Length == 0 ? "1/1/1900" : dr["ErrorSubmitDate"].ToString());
                    row["CurtailmentCode"] = int.Parse(dr["CurtailmentCode"].ToString().Length == 0 ? "0" : dr["CurtailmentCode"].ToString());
                    row["CurtailmentDate"] = DateTime.Parse(dr["CurtailmentDate"].ToString().Length == 0 ? "1/1/1900" : dr["CurtailmentDate"].ToString());
                    row["RecordingInstructionsSentDate"] = DateTime.Parse(dr["RecordingInstructionsSentDate"].ToString().Length == 0 ? "1/1/1900" : dr["RecordingInstructionsSentDate"].ToString());
                    row["RecorderLetterReceiveDate"] = DateTime.Parse(dr["RecorderLetterReceiveDate"].ToString().Length == 0 ? "1/1/1900" : dr["RecorderLetterReceiveDate"].ToString());
                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                    row["EnteredByUser"] = int.Parse(dr["EnteredByUser"].ToString().Length == 0 ? "0" : dr["EnteredByUser"].ToString());
                    row["EnteredByUserName"] = dr["EnteredByUserName"].ToString();
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    row["LastUpdateUser"] = int.Parse(dr["LastUpdateUser"].ToString().Length == 0 ? "0" : dr["LastUpdateUser"].ToString());
                    row["LastUpdateUserName"] = dr["LastUpdateUserName"].ToString();
                    row["PrepReferralCompleteDate"] = DateTime.Parse(dr["PrepReferralCompleteDate"].ToString().Length == 0 ? "1/1/1900" : dr["PrepReferralCompleteDate"].ToString());
                    row["PrepReferralAnalyst"] = int.Parse(dr["PrepReferralAnalyst"].ToString().Length == 0 ? "0" : dr["PrepReferralAnalyst"].ToString());
                    row["ClearMarketableTitleDate"] = DateTime.Parse(dr["ClearMarketableTitleDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClearMarketableTitleDate"].ToString());
                    row["ConveyanceExtensionExpirationDate"] = DateTime.Parse(dr["ConveyanceExtensionExpirationDate"].ToString().Length == 0 ? "1/1/1900" : dr["ConveyanceExtensionExpirationDate"].ToString());
                    row["FCLFirstLegalDate"] = DateTime.Parse(dr["FCLFirstLegalDate"].ToString().Length == 0 ? "1/1/1900" : dr["FCLFirstLegalDate"].ToString());
                    row["ReportedFirstTimeVacancyDate"] = DateTime.Parse(dr["ReportedFirstTimeVacancyDate"].ToString().Length == 0 ? "1/1/1900" : dr["ReportedFirstTimeVacancyDate"].ToString());
                    // 20140728 gk fb4366 add new fields
                    row["RecordLetterVerified"] = DateTime.Parse(dr["RecordLetterVerified"].ToString().Length == 0 ? "1/1/1900" : dr["RecordLetterVerified"].ToString());
                    row["RecordLetterVerifiedUser"] = int.Parse(dr["RecordLetterVerifiedUser"].ToString().Length == 0 ? "0" : dr["RecordLetterVerifiedUser"].ToString());
                    row["ClientSystemUpdated"] = DateTime.Parse(dr["ClientSystemUpdated"].ToString().Length == 0 ? "1/1/1900" : dr["ClientSystemUpdated"].ToString());
                    row["ClientSystemUpdatedUser"] = int.Parse(dr["ClientSystemUpdatedUser"].ToString().Length == 0 ? "0" : dr["ClientSystemUpdatedUser"].ToString());
                    
                    dt.Rows.Add(row);

                }

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool SaveInvestorTrackingFHAPartAClaim(DataTable dt, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                int recordsAffected;

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                    SqlParameter prm = new SqlParameter();

                    switch (dt.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            break;
                        case DataRowState.Deleted:
                            break;
                        case DataRowState.Detached:
                            break;
                        case DataRowState.Modified:
                            cmd.CommandText = "usp_InvTrk_FHAPartA_Update";
                            break;
                        case DataRowState.Unchanged:
                            goto NextRecord;
                        //break;
                        default:
                            break;
                    }

                    cmd.Connection = con;
                    prm = new SqlParameter("@FHAPartAClaimID", dt.Rows[i]["FHAPartAClaimID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@UnpaidBalance", dt.Rows[i]["UnpaidBalance"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@MHT", dt.Rows[i]["MHT"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@MHTStartDate", dt.Rows[i]["MHTStartDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@MHTEndDate", dt.Rows[i]["MHTEndDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@MHTReviewedDate", dt.Rows[i]["MHTReviewedDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@FTVDate", dt.Rows[i]["FTVDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ICCDate", dt.Rows[i]["ICCDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ICCReportDate", dt.Rows[i]["ICCReportDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@FCLDeedRecordedDate", dt.Rows[i]["FCLDeedRecordedDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@HUDDeedRecordedDate", dt.Rows[i]["HUDDeedRecordedDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PrepCompleteDate", dt.Rows[i]["PrepCompleteDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PrepAnalystID", dt.Rows[i]["PrepAnalystID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SubmitQCDate", dt.Rows[i]["SubmitQCDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SubmitQCAnalystID", dt.Rows[i]["SubmitQCAnalystID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@QCApprovedDate", dt.Rows[i]["QCApprovedDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@QCApprovedAnalystID", dt.Rows[i]["QCApprovedAnalystID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SubmittedDate", dt.Rows[i]["SubmittedDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SubmittedAnalystID", dt.Rows[i]["SubmittedAnalystID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimAmount", dt.Rows[i]["ClaimAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SettlementDate", dt.Rows[i]["SettlementDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PaidAmount", dt.Rows[i]["PaidAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuspendDate", dt.Rows[i]["SuspendDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ErrorSubmitDate", dt.Rows[i]["ErrorSubmitDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@CurtailmentCode", dt.Rows[i]["CurtailmentCode"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@CurtailmentDate", dt.Rows[i]["CurtailmentDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@RecordingInstructionsSentDate", dt.Rows[i]["RecordingInstructionsSentDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@RecorderLetterReceiveDate", dt.Rows[i]["RecorderLetterReceiveDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LastUpdateUser", dt.Rows[i]["LastUpdateUser"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PrepReferralCompleteDate", dt.Rows[i]["PrepReferralCompleteDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PrepReferralAnalyst", dt.Rows[i]["PrepReferralAnalyst"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClearMarketableTitleDate", dt.Rows[i]["ClearMarketableTitleDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ConveyanceExtensionExpirationDate", dt.Rows[i]["ConveyanceExtensionExpirationDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@FCLFirstLegalDate", dt.Rows[i]["FCLFirstLegalDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ReportedFirstTimeVacancyDate", dt.Rows[i]["ReportedFirstTimeVacancyDate"]);
                    cmd.Parameters.Add(prm);
                    // 20140728 gk fb4366 add new fields
                    prm = new SqlParameter("@RecordLetterVerified", dt.Rows[i]["RecordLetterVerified"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@RecordLetterVerifiedUser", dt.Rows[i]["RecordLetterVerifiedUser"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClientSystemUpdated", dt.Rows[i]["ClientSystemUpdated"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClientSystemUpdatedUser", dt.Rows[i]["ClientSystemUpdatedUser"]);
                    cmd.Parameters.Add(prm);
                    // end 20140728 gk fb4366 add new fields

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;

                }

                dt.AcceptChanges();

                return true;

            }

            catch (Exception ex)
            {
                //dump the table into an error file so we have some record of where we were
                try
                {
                    CRFS.Data.ErrorDataDump.DumpTableToDefaultLocation(dt, "");

                }

                catch { }
                throw ex;

            }

            finally
            {

                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        #endregion

        #region "Part B"
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="claimID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetInvestorTracking_FHAPartB_Claim(DataTable dt, int claimID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_InvTrk_FHAPartB_Select";

                SqlParameter parm = new SqlParameter("@ClaimID", claimID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["FHAPartBClaimID"] = (int)dr["FHAPartBClaimID"];
                    row["ClaimID"] = (int)dr["ClaimID"];
                    row["TitleSubmitDate"] = DateTime.Parse(dr["TitleSubmitDate"].ToString().Length == 0 ? "1/1/1900" : dr["TitleSubmitDate"].ToString());
                    row["TitleSubmitAnalystID"] = int.Parse(dr["TitleSubmitAnalystID"].ToString().Length == 0 ? "0" : dr["TitleSubmitAnalystID"].ToString());
                    row["TitleExtensionDate"] = DateTime.Parse(dr["TitleExtensionDate"].ToString().Length == 0 ? "1/1/1900" : dr["TitleExtensionDate"].ToString());
                    row["TALDate"] = DateTime.Parse(dr["TALDate"].ToString().Length == 0 ? "1/1/1900" : dr["TALDate"].ToString());
                    row["PrepCompleteDate"] = DateTime.Parse(dr["PrepCompleteDate"].ToString().Length == 0 ? "1/1/1900" : dr["PrepCompleteDate"].ToString());
                    row["PrepAnalystID"] = int.Parse(dr["PrepAnalystID"].ToString().Length == 0 ? "0" : dr["PrepAnalystID"].ToString());
                    row["SubmitQCDate"] = DateTime.Parse(dr["SubmitQCDate"].ToString().Length == 0 ? "1/1/1900" : dr["SubmitQCDate"].ToString());
                    row["SubmitQCAnalystID"] = int.Parse(dr["SubmitQCAnalystID"].ToString().Length == 0 ? "0" : dr["SubmitQCAnalystID"].ToString());
                    row["QCApprovedDate"] = DateTime.Parse(dr["QCApprovedDate"].ToString().Length == 0 ? "1/1/1900" : dr["QCApprovedDate"].ToString());
                    row["QCApprovedAnalystID"] = int.Parse(dr["QCApprovedAnalystID"].ToString().Length == 0 ? "0" : dr["QCApprovedAnalystID"].ToString());
                    row["SubmittedDate"] = DateTime.Parse(dr["SubmittedDate"].ToString().Length == 0 ? "1/1/1900" : dr["SubmittedDate"].ToString());
                    row["SubmittedAnalystID"] = int.Parse(dr["SubmittedAnalystID"].ToString().Length == 0 ? "0" : dr["SubmittedAnalystID"].ToString());
                    row["ClaimAmount"] = decimal.Parse(dr["ClaimAmount"].ToString().Length == 0 ? "0" : dr["ClaimAmount"].ToString());
                    row["SettlementDate"] = DateTime.Parse(dr["SettlementDate"].ToString().Length == 0 ? "1/1/1900" : dr["SettlementDate"].ToString());
                    row["PaidAmount"] = decimal.Parse(dr["PaidAmount"].ToString().Length == 0 ? "0" : dr["PaidAmount"].ToString());
                    row["SuspendDate"] = DateTime.Parse(dr["SuspendDate"].ToString().Length == 0 ? "1/1/1900" : dr["SuspendDate"].ToString());
                    row["ErrorSubmitDate"] = DateTime.Parse(dr["ErrorSubmitDate"].ToString().Length == 0 ? "1/1/1900" : dr["ErrorSubmitDate"].ToString());
                    row["ReviewedForInvestorClaim"] = DateTime.Parse(dr["ReviewedForInvestorClaim"].ToString().Length == 0 ? "1/1/1900" : dr["ReviewedForInvestorClaim"].ToString());
                    row["InvestorClaimDue"] = bool.Parse(dr["InvestorClaimDue"].ToString().Length == 0 ? "false" : dr["InvestorClaimDue"].ToString());
                    row["InvestorClaimFiledDate"] = DateTime.Parse(dr["InvestorClaimFiledDate"].ToString().Length == 0 ? "1/1/1900" : dr["InvestorClaimFiledDate"].ToString());
                    row["InvestorClaimAnalystID"] = int.Parse(dr["InvestorClaimAnalystID"].ToString().Length == 0 ? "0" : dr["InvestorClaimAnalystID"].ToString());
                    row["InvestorClaimAmount"] = decimal.Parse(dr["InvestorClaimAmount"].ToString().Length == 0 ? "0" : dr["InvestorClaimAmount"].ToString());
                    row["SuppRefundDueHUD"] = bool.Parse(dr["SuppRefundDueHUD"].ToString().Length == 0 ? "false" : dr["SuppRefundDueHUD"].ToString());
                    row["SuppRefundFiledDate"] = DateTime.Parse(dr["SuppRefundFiledDate"].ToString().Length == 0 ? "1/1/1900" : dr["SuppRefundFiledDate"].ToString());
                    row["SuppRefundFiledAnalystID"] = int.Parse(dr["SuppRefundFiledAnalystID"].ToString().Length == 0 ? "0" : dr["SuppRefundFiledAnalystID"].ToString());
                    row["SuppRefundAmount"] = decimal.Parse(dr["SuppRefundAmount"].ToString().Length == 0 ? "0" : dr["SuppRefundAmount"].ToString());
                    row["SuppRecoveryDue"] = bool.Parse(dr["SuppRecoveryDue"].ToString().Length == 0 ? "false" : dr["SuppRecoveryDue"].ToString());
                    row["SuppRecoveryFiledDate"] = DateTime.Parse(dr["SuppRecoveryFiledDate"].ToString().Length == 0 ? "1/1/1900" : dr["SuppRecoveryFiledDate"].ToString());
                    row["SuppRecoveryAnalystID"] = int.Parse(dr["SuppRecoveryFiledAnalystID"].ToString().Length == 0 ? "0" : dr["SuppRecoveryFiledAnalystID"].ToString());
                    row["SuppRecoveryAmount"] = decimal.Parse(dr["SuppRecoveryAmount"].ToString().Length == 0 ? "0" : dr["SuppRecoveryAmount"].ToString());
                    row["SuppRecoveryPaidDate"] = DateTime.Parse(dr["SuppRecoveryPaidDate"].ToString().Length == 0 ? "1/1/1900" : dr["SuppRecoveryPaidDate"].ToString());
                    row["SuppRecoveryPaidAmount"] = decimal.Parse(dr["SuppRecoveryPaidAmount"].ToString().Length == 0 ? "0" : dr["SuppRecoveryPaidAmount"].ToString());
                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                    row["EnteredByUser"] = int.Parse(dr["EnteredByUser"].ToString().Length == 0 ? "0" : dr["EnteredByUser"].ToString());
                    row["EnteredByUserName"] = dr["EnteredByUserName"].ToString();
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    row["LastUpdateUser"] = int.Parse(dr["LastUpdateUser"].ToString().Length == 0 ? "0" : dr["LastUpdateUser"].ToString());
                    row["LastUpdateUserName"] = dr["LastUpdateUserName"].ToString();
                    row["ExpectedPartBProceeds"] = decimal.Parse(dr["ExpectedPartBProceeds"].ToString().Length == 0 ? "0" : dr["ExpectedPartBProceeds"].ToString());
                    // 20140729 gk fb2287 add SuppReceivedDate
                    row["SuppReceivedDate"] = DateTime.Parse(dr["SuppReceivedDate"].ToString().Length == 0 ? "1/1/1900" : dr["SuppReceivedDate"].ToString());
                    // 20140801 gk 5128 ClientSystemUpdatedDate ClientSystemUpdatedUser
                    row["ClientSystemUpdatedDate"] = DateTime.Parse(dr["ClientSystemUpdatedDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClientSystemUpdatedDate"].ToString());
                    row["ClientSystemUpdatedUser"] = int.Parse(dr["ClientSystemUpdatedUser"].ToString().Length == 0 ? "0" : dr["ClientSystemUpdatedUser"].ToString());

                    dt.Rows.Add(row);

                }

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool SaveInvestorTrackingFHAPartBClaim(DataTable dt, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                int recordsAffected;

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                    SqlParameter prm = new SqlParameter();

                    switch (dt.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            break;
                        case DataRowState.Deleted:
                            break;
                        case DataRowState.Detached:
                            break;
                        case DataRowState.Modified:
                            cmd.CommandText = "usp_InvTrk_FHAPartB_Update";
                            break;
                        case DataRowState.Unchanged:
                            goto NextRecord;
                        //break;
                        default:
                            break;
                    }

                    cmd.Connection = con;
                    prm = new SqlParameter("@FHAPartBClaimID", dt.Rows[i]["FHAPartBClaimID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@TitleSubmitDate", dt.Rows[i]["TitleSubmitDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@TitleSubmitAnalystID", dt.Rows[i]["TitleSubmitAnalystID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@TitleExtensionDate", dt.Rows[i]["TitleExtensionDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@TALDate", dt.Rows[i]["TALDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PrepCompleteDate", dt.Rows[i]["PrepCompleteDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PrepAnalystID", dt.Rows[i]["PrepAnalystID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SubmitQCDate", dt.Rows[i]["SubmitQCDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SubmitQCAnalystID", dt.Rows[i]["SubmitQCAnalystID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@QCApprovedDate", dt.Rows[i]["QCApprovedDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@QCApprovedAnalystID", dt.Rows[i]["QCApprovedAnalystID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SubmittedDate", dt.Rows[i]["SubmittedDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SubmittedAnalystID", dt.Rows[i]["SubmittedAnalystID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimAmount", dt.Rows[i]["ClaimAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SettlementDate", dt.Rows[i]["SettlementDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PaidAmount", dt.Rows[i]["PaidAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuspendDate", dt.Rows[i]["SuspendDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ErrorSubmitDate", dt.Rows[i]["ErrorSubmitDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ReviewedForInvestorClaim", dt.Rows[i]["ReviewedForInvestorClaim"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorClaimDue", dt.Rows[i]["InvestorClaimDue"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorClaimFiledDate", dt.Rows[i]["InvestorClaimFiledDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorClaimAmount", dt.Rows[i]["InvestorClaimAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorClaimAnalystID", dt.Rows[i]["InvestorClaimAnalystID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRefundDueHUD", dt.Rows[i]["SuppRefundDueHUD"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRefundFiledDate", dt.Rows[i]["SuppRefundFiledDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRefundFiledAnalystID", dt.Rows[i]["SuppRefundFiledAnalystID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRefundAmount", dt.Rows[i]["SuppRefundAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryDue", dt.Rows[i]["SuppRecoveryDue"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryFiledDate", dt.Rows[i]["SuppRecoveryFiledDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryFiledAnalystID", dt.Rows[i]["SuppRecoveryAnalystID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryAmount", dt.Rows[i]["SuppRecoveryAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryPaidDate", dt.Rows[i]["SuppRecoveryPaidDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryPaidAmount", dt.Rows[i]["SuppRecoveryPaidAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LastUpdateUser", dt.Rows[i]["LastUpdateUser"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ExpectedPartBProceeds", dt.Rows[i]["ExpectedPartBProceeds"]);
                    cmd.Parameters.Add(prm);
                    // 20140729 gk fb2287 SuppReceivedDate
                    prm = new SqlParameter("@SuppReceivedDate", dt.Rows[i]["SuppReceivedDate"]);
                    cmd.Parameters.Add(prm);
                    // 20140801 gk 5128 ClientSystemUpdatedDate ClientSystemUpdatedUser
                    prm = new SqlParameter("@ClientSystemUpdatedDate", dt.Rows[i]["ClientSystemUpdatedDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClientSystemUpdatedUser", dt.Rows[i]["ClientSystemUpdatedUser"]);
                    cmd.Parameters.Add(prm);

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;

                }

                dt.AcceptChanges();

                return true;

            }

            catch (Exception ex)
            {
                //dump the table into an error file so we have some record of where we were
                try
                {
                    CRFS.Data.ErrorDataDump.DumpTableToDefaultLocation(dt, "");

                }

                catch { }
                throw ex;

            }

            finally
            {

                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        #endregion

        #region "PFS"
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="claimID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetInvestorTracking_FHAPFS_Claim(DataTable dt, int claimID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_InvTrk_FHAPFS_Select";

                SqlParameter parm = new SqlParameter("@ClaimID", claimID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["PFSClaimID"] = (int)dr["PFSClaimID"];
                    row["ClaimID"] = (int)dr["ClaimID"];
                    row["PrepCompleteDate"] = DateTime.Parse(dr["PrepCompleteDate"].ToString().Length == 0 ? "1/1/1900" : dr["PrepCompleteDate"].ToString());
                    row["PrepAnalystID"] = int.Parse(dr["PrepAnalystID"].ToString().Length == 0 ? "0" : dr["PrepAnalystID"].ToString());
                    row["SubmitQCDate"] = DateTime.Parse(dr["SubmitQCDate"].ToString().Length == 0 ? "1/1/1900" : dr["SubmitQCDate"].ToString());
                    row["SubmitQCAnalystID"] = int.Parse(dr["SubmitQCAnalystID"].ToString().Length == 0 ? "0" : dr["SubmitQCAnalystID"].ToString());
                    row["QCApprovedDate"] = DateTime.Parse(dr["QCApprovedDate"].ToString().Length == 0 ? "1/1/1900" : dr["QCApprovedDate"].ToString());
                    row["QCApprovedAnalystID"] = int.Parse(dr["QCApprovedAnalystID"].ToString().Length == 0 ? "0" : dr["QCApprovedAnalystID"].ToString());
                    row["SubmittedDate"] = DateTime.Parse(dr["SubmittedDate"].ToString().Length == 0 ? "1/1/1900" : dr["SubmittedDate"].ToString());
                    row["SubmittedAnalystID"] = int.Parse(dr["SubmittedAnalystID"].ToString().Length == 0 ? "0" : dr["SubmittedAnalystID"].ToString());
                    row["Amount"] = decimal.Parse(dr["Amount"].ToString().Length == 0 ? "0" : dr["Amount"].ToString());
                    row["SettlementDate"] = DateTime.Parse(dr["SettlementDate"].ToString().Length == 0 ? "1/1/1900" : dr["SettlementDate"].ToString());
                    row["PaidAmount"] = decimal.Parse(dr["PaidAmount"].ToString().Length == 0 ? "0" : dr["PaidAmount"].ToString());
                    row["SuspendDate"] = DateTime.Parse(dr["SuspendDate"].ToString().Length == 0 ? "1/1/1900" : dr["SuspendDate"].ToString());
                    row["ErrorSubmitDate"] = DateTime.Parse(dr["ErrorSubmitDate"].ToString().Length == 0 ? "1/1/1900" : dr["ErrorSubmitDate"].ToString());
                    row["ReviewedForInvestorClaim"] = DateTime.Parse(dr["ReviewedForInvestorClaim"].ToString().Length == 0 ? "1/1/1900" : dr["ReviewedForInvestorClaim"].ToString());
                    row["InvestorClaimDue"] = bool.Parse(dr["InvestorClaimDue"].ToString().Length == 0 ? "false" : dr["InvestorClaimDue"].ToString());
                    row["InvestorClaimFiledDate"] = DateTime.Parse(dr["InvestorClaimFiledDate"].ToString().Length == 0 ? "1/1/1900" : dr["InvestorClaimFiledDate"].ToString());
                    row["InvestorClaimAnalystID"] = int.Parse(dr["InvestorClaimAnalystID"].ToString().Length == 0 ? "0" : dr["InvestorClaimAnalystID"].ToString());
                    row["InvestorClaimAmount"] = decimal.Parse(dr["InvestorClaimAmount"].ToString().Length == 0 ? "0" : dr["InvestorClaimAmount"].ToString());
                    row["SuppRefundDueHUD"] = bool.Parse(dr["SuppRefundDueHUD"].ToString().Length == 0 ? "false" : dr["SuppRefundDueHUD"].ToString());
                    row["SuppRefundFiledDate"] = DateTime.Parse(dr["SuppRefundFiledDate"].ToString().Length == 0 ? "1/1/1900" : dr["SuppRefundFiledDate"].ToString());
                    row["SuppRefundFiledAnalystID"] = int.Parse(dr["SuppRefundFiledAnalystID"].ToString().Length == 0 ? "0" : dr["SuppRefundFiledAnalystID"].ToString());
                    row["SuppRefundAmount"] = decimal.Parse(dr["SuppRefundAmount"].ToString().Length == 0 ? "0" : dr["SuppRefundAmount"].ToString());
                    row["SuppRecoveryDue"] = bool.Parse(dr["SuppRecoveryDue"].ToString().Length == 0 ? "false" : dr["SuppRecoveryDue"].ToString());
                    row["SuppRecoveryFiledDate"] = DateTime.Parse(dr["SuppRecoveryFiledDate"].ToString().Length == 0 ? "1/1/1900" : dr["SuppRecoveryFiledDate"].ToString());
                    row["SuppRecoveryAnalystID"] = int.Parse(dr["SuppRecoveryFiledAnalystID"].ToString().Length == 0 ? "0" : dr["SuppRecoveryFiledAnalystID"].ToString());
                    row["SuppRecoveryAmount"] = decimal.Parse(dr["SuppRecoveryAmount"].ToString().Length == 0 ? "0" : dr["SuppRecoveryAmount"].ToString());
                    row["SuppRecoveryPaidDate"] = DateTime.Parse(dr["SuppRecoveryPaidDate"].ToString().Length == 0 ? "1/1/1900" : dr["SuppRecoveryPaidDate"].ToString());
                    row["SuppRecoveryPaidAmount"] = decimal.Parse(dr["SuppRecoveryPaidAmount"].ToString().Length == 0 ? "0" : dr["SuppRecoveryPaidAmount"].ToString());
                    row["CurtailmentCode"] = int.Parse(dr["CurtailmentCode"].ToString().Length == 0 ? "0" : dr["CurtailmentCode"].ToString());
                    row["CurtailmentDate"] = DateTime.Parse(dr["CurtailmentDate"].ToString().Length == 0 ? "1/1/1900" : dr["CurtailmentDate"].ToString());
                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                    row["EnteredByUser"] = int.Parse(dr["EnteredByUser"].ToString().Length == 0 ? "0" : dr["EnteredByUser"].ToString());
                    row["EnteredByUserName"] = dr["EnteredByUserName"].ToString();
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    row["LastUpdateUser"] = int.Parse(dr["LastUpdateUser"].ToString().Length == 0 ? "0" : dr["LastUpdateUser"].ToString());
                    row["LastUpdateUserName"] = dr["LastUpdateUserName"].ToString();
                    // 20140728 gk fb2287 SuppReceivedDate
                    row["SuppReceivedDate"] = DateTime.Parse(dr["SuppReceivedDate"].ToString().Length == 0 ? "1/1/1900" : dr["SuppReceivedDate"].ToString());
                    // 20140801 gk 5128 ClientSystemUpdatedDate ClientSystemUpdatedUser
                    row["ClientSystemUpdatedDate"] = DateTime.Parse(dr["ClientSystemUpdatedDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClientSystemUpdatedDate"].ToString());
                    row["ClientSystemUpdatedUser"] = int.Parse(dr["ClientSystemUpdatedUser"].ToString().Length == 0 ? "0" : dr["ClientSystemUpdatedUser"].ToString());

                    dt.Rows.Add(row);

                }

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool SaveInvestorTrackingFHAPFSClaim(DataTable dt, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                int recordsAffected;

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                    SqlParameter prm = new SqlParameter();

                    switch (dt.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            break;
                        case DataRowState.Deleted:
                            break;
                        case DataRowState.Detached:
                            break;
                        case DataRowState.Modified:
                            cmd.CommandText = "usp_InvTrk_FHAPFS_Update";
                            break;
                        case DataRowState.Unchanged:
                            goto NextRecord;
                        //break;
                        default:
                            break;
                    }

                    cmd.Connection = con;
                    prm = new SqlParameter("@PFSClaimID", dt.Rows[i]["PFSClaimID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PrepCompleteDate", dt.Rows[i]["PrepCompleteDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PrepAnalystID", dt.Rows[i]["PrepAnalystID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SubmitQCDate", dt.Rows[i]["SubmitQCDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SubmitQCAnalystID", dt.Rows[i]["SubmitQCAnalystID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@QCApprovedDate", dt.Rows[i]["QCApprovedDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@QCApprovedAnalystID", dt.Rows[i]["QCApprovedAnalystID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SubmittedDate", dt.Rows[i]["SubmittedDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SubmittedAnalystID", dt.Rows[i]["SubmittedAnalystID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@Amount", dt.Rows[i]["Amount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SettlementDate", dt.Rows[i]["SettlementDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PaidAmount", dt.Rows[i]["PaidAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuspendDate", dt.Rows[i]["SuspendDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ErrorSubmitDate", dt.Rows[i]["ErrorSubmitDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ReviewedForInvestorClaim", dt.Rows[i]["ReviewedForInvestorClaim"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorClaimDue", dt.Rows[i]["InvestorClaimDue"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorClaimFiledDate", dt.Rows[i]["InvestorClaimFiledDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorClaimAnalystID", dt.Rows[i]["InvestorClaimAnalystID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorClaimAmount", dt.Rows[i]["InvestorClaimAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRefundDueHUD", dt.Rows[i]["SuppRefundDueHUD"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRefundFiledDate", dt.Rows[i]["SuppRefundFiledDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRefundFiledAnalystID", dt.Rows[i]["SuppRefundFiledAnalystID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRefundAmount", dt.Rows[i]["SuppRefundAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryDue", dt.Rows[i]["SuppRecoveryDue"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryFiledDate", dt.Rows[i]["SuppRecoveryFiledDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryFiledAnalystID", dt.Rows[i]["SuppRecoveryAnalystID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryAmount", dt.Rows[i]["SuppRecoveryAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryPaidDate", dt.Rows[i]["SuppRecoveryPaidDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryPaidAmount", dt.Rows[i]["SuppRecoveryPaidAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@CurtailmentCode", dt.Rows[i]["CurtailmentCode"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@CurtailmentDate", dt.Rows[i]["CurtailmentDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LastUpdateUser", dt.Rows[i]["LastUpdateUser"]);
                    cmd.Parameters.Add(prm);
                    // 20140729 gk fb2287 SuppReceivedDate
                    prm = new SqlParameter("@SuppReceivedDate", dt.Rows[i]["SuppReceivedDate"]);
                    cmd.Parameters.Add(prm);
                    // 20140801 gk 5128 ClientSystemUpdatedDate ClientSystemUpdatedUser
                    prm = new SqlParameter("@ClientSystemUpdatedDate", dt.Rows[i]["ClientSystemUpdatedDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClientSystemUpdatedUser", dt.Rows[i]["ClientSystemUpdatedUser"]);
                    cmd.Parameters.Add(prm);

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;

                }

                dt.AcceptChanges();

                return true;

            }

            catch (Exception ex)
            {
                //dump the table into an error file so we have some record of where we were
                try
                {
                    CRFS.Data.ErrorDataDump.DumpTableToDefaultLocation(dt, "");

                }

                catch { }
                throw ex;

            }

            finally
            {

                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        #endregion

        #region "CWCOT"
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="claimID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetInvestorTracking_FHACWCOT_Claim(DataTable dt, int claimID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_InvTrk_FHACWCOT_Select";

                SqlParameter parm = new SqlParameter("@ClaimID", claimID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();
                    //TBD from the reader, populate the table columns
                    row["CWCOTClaimID"] = int.Parse(dr["CWCOTClaimID"].ToString().Length == 0 ? "0" : dr["CWCOTClaimID"].ToString());
                    row["ClaimID"] = int.Parse(dr["ClaimID"].ToString().Length == 0 ? "0" : dr["ClaimID"].ToString());
                    row["FCDeedRecordedDate"] = DateTime.Parse(dr["FCDeedRecordedDate"].ToString().Length == 0 ? "1/1/1900" : dr["FCDeedRecordedDate"].ToString());
                    row["PrepCompleteDate"] = DateTime.Parse(dr["PrepCompleteDate"].ToString().Length == 0 ? "1/1/1900" : dr["PrepCompleteDate"].ToString());
                    row["PrepAnalyst"] = int.Parse(dr["PrepAnalyst"].ToString().Length == 0 ? "0" : dr["PrepAnalyst"].ToString());
                    row["PartACompleteDate"] = DateTime.Parse(dr["PartACompleteDate"].ToString().Length == 0 ? "1/1/1900" : dr["PartACompleteDate"].ToString());
                    row["PartAAnalyst"] = int.Parse(dr["PartAAnalyst"].ToString().Length == 0 ? "0" : dr["PartAAnalyst"].ToString());
                    row["CurtailmentCode"] = int.Parse(dr["CurtailmentCode"].ToString().Length == 0 ? "0" : dr["CurtailmentCode"].ToString());
                    row["PartBCompleteDate"] = DateTime.Parse(dr["PartBCompleteDate"].ToString().Length == 0 ? "1/1/1900" : dr["PartBCompleteDate"].ToString());
                    row["PartBAnalyst"] = int.Parse(dr["PartBAnalyst"].ToString().Length == 0 ? "0" : dr["PartBAnalyst"].ToString());
                    row["CurtailmentDate"] = DateTime.Parse(dr["CurtailmentDate"].ToString().Length == 0 ? "1/1/1900" : dr["CurtailmentDate"].ToString());
                    row["PartAQCCompleteDate"] = DateTime.Parse(dr["PartAQCCompleteDate"].ToString().Length == 0 ? "1/1/1900" : dr["PartAQCCompleteDate"].ToString());
                    row["PartAQCAnalyst"] = int.Parse(dr["PartAQCAnalyst"].ToString().Length == 0 ? "0" : dr["PartAQCAnalyst"].ToString());
                    row["PartBQCCompleteDate"] = DateTime.Parse(dr["PartBQCCompleteDate"].ToString().Length == 0 ? "1/1/1900" : dr["PartBQCCompleteDate"].ToString());
                    row["PartBQCAnalyst"] = int.Parse(dr["PartBQCAnalyst"].ToString().Length == 0 ? "0" : dr["PartBQCAnalyst"].ToString());
                    row["ClaimSubmittedDate"] = DateTime.Parse(dr["ClaimSubmittedDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClaimSubmittedDate"].ToString());
                    row["ClaimSubmittedAnalyst"] = int.Parse(dr["ClaimSubmittedAnalyst"].ToString().Length == 0 ? "0" : dr["ClaimSubmittedAnalyst"].ToString());
                    row["ClaimAmount"] = decimal.Parse(dr["ClaimAmount"].ToString().Length == 0 ? "0" : dr["ClaimAmount"].ToString());
                    row["PaidDate"] = DateTime.Parse(dr["PaidDate"].ToString().Length == 0 ? "1/1/1900" : dr["PaidDate"].ToString());
                    row["PaidAmount"] = decimal.Parse(dr["PaidAmount"].ToString().Length == 0 ? "0" : dr["PaidAmount"].ToString());
                    row["SuspendDate"] = DateTime.Parse(dr["SuspendDate"].ToString().Length == 0 ? "1/1/1900" : dr["SuspendDate"].ToString());
                    row["ErrorSubmitDate"] = DateTime.Parse(dr["ErrorSubmitDate"].ToString().Length == 0 ? "1/1/1900" : dr["ErrorSubmitDate"].ToString());
                    row["SuppRefundDue"] = bool.Parse(dr["SuppRefundDue"].ToString().Length == 0 ? "false" : dr["SuppRefundDue"].ToString());
                    row["SuppRefundFiledDate"] = DateTime.Parse(dr["SuppRefundFiledDate"].ToString().Length == 0 ? "1/1/1900" : dr["SuppRefundFiledDate"].ToString());
                    row["SuppRefundAnalyst"] = int.Parse(dr["SuppRefundAnalyst"].ToString().Length == 0 ? "0" : dr["SuppRefundAnalyst"].ToString());
                    row["SuppRefundAmount"] = decimal.Parse(dr["SuppRefundAmount"].ToString().Length == 0 ? "0" : dr["SuppRefundAmount"].ToString());
                    row["SuppRecoveryDue"] = bool.Parse(dr["SuppRecoveryDue"].ToString().Length == 0 ? "false" : dr["SuppRecoveryDue"].ToString());
                    row["SuppRecoveryFiledDate"] = DateTime.Parse(dr["SuppRecoveryFiledDate"].ToString().Length == 0 ? "1/1/1900" : dr["SuppRecoveryFiledDate"].ToString());
                    row["SuppRecoveryAnalyst"] = int.Parse(dr["SuppRecoveryAnalyst"].ToString().Length == 0 ? "0" : dr["SuppRecoveryAnalyst"].ToString());
                    row["SuppRecoveryAmount"] = decimal.Parse(dr["SuppRecoveryAmount"].ToString().Length == 0 ? "0" : dr["SuppRecoveryAmount"].ToString());
                    row["SuppRecoveryPaidDate"] = DateTime.Parse(dr["SuppRecoveryPaidDate"].ToString().Length == 0 ? "1/1/1900" : dr["SuppRecoveryPaidDate"].ToString());
                    row["SuppRecoveryPaidAmount"] = decimal.Parse(dr["SuppRecoveryPaidAmount"].ToString().Length == 0 ? "0" : dr["SuppRecoveryPaidAmount"].ToString());
                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                    row["EnteredByUser"] = int.Parse(dr["EnteredByUser"].ToString().Length == 0 ? "0" : dr["EnteredByUser"].ToString());
                    row["EnteredByUserName"] = dr["EnteredByUserName"].ToString();
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    row["LastUpdateUser"] = int.Parse(dr["LastUpdateUser"].ToString().Length == 0 ? "0" : dr["LastUpdateUser"].ToString());
                    row["LastUpdateUserName"] = dr["LastUpdateUserName"].ToString();
                    // gk edi auth 20130829
                    row["IsEDIAuthorized"] = bool.Parse(dr["IsEDIAuthorized"].ToString().Length==0 ? "false" : dr["IsEDIAuthorized"].ToString());
                    row["EDIAuthorizedUserId"] = int.Parse(dr["EDIAuthorizedUserId"].ToString().Length==0 ? "0" : dr["EDIAuthorizedUserId"].ToString());
                    row["EDIAuthorizedDate"] = DateTime.Parse(dr["EDIAuthorizedDate"].ToString().Length==0 ? "1/1/1900" : dr["EDIAuthorizedDate"].ToString());
                    // 20140729 gk fb2287 SuppReceivedDate
                    row["SuppReceivedDate"] = DateTime.Parse(dr["SuppReceivedDate"].ToString().Length == 0 ? "1/1/1900" : dr["SuppReceivedDate"].ToString());
                    // 20140801 gk 5128 ClientSystemUpdatedDate ClientSystemUpdatedUser
                    row["ClientSystemUpdatedDate"] = DateTime.Parse(dr["ClientSystemUpdatedDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClientSystemUpdatedDate"].ToString());
                    row["ClientSystemUpdatedUser"] = int.Parse(dr["ClientSystemUpdatedUser"].ToString().Length==0 ? "0" : dr["ClientSystemUpdatedUser"].ToString());
                    // 20140929 gk 1429
                    row["InvestorClaimDue"] = bool.Parse(dr["InvestorClaimDue"].ToString().Length == 0 ? "false" : dr["InvestorClaimDue"].ToString());
                    row["InvestorClaimFiledDate"] = DateTime.Parse(dr["InvestorClaimFiledDate"].ToString().Length == 0 ? "1/1/1900" : dr["InvestorClaimFiledDate"].ToString());
                    row["InvestorClaimAmount"]=decimal.Parse(dr["InvestorClaimAmount"].ToString().Length == 0 ? "0" : dr["InvestorClaimAmount"].ToString());
                    row["InvestorClaimAnalystID"]= int.Parse(dr["InvestorClaimAnalystID"].ToString().Length == 0 ? "0" : dr["InvestorClaimAnalystID"].ToString());
                    row["ReviewedForInvestorClaim"]=DateTime.Parse(dr["ReviewedForInvestorClaim"].ToString().Length == 0 ? "1/1/1900" : dr["ReviewedForInvestorClaim"].ToString());

                    dt.Rows.Add(row);
                }

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

            }
            
            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool SaveInvestorTrackingFHACWCOTClaim(DataTable dt, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                int recordsAffected;

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                    SqlParameter prm = new SqlParameter();

                    switch (dt.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            break;
                        case DataRowState.Deleted:
                            break;
                        case DataRowState.Detached:
                            break;
                        case DataRowState.Modified:
                            cmd.CommandText = "usp_InvTrk_FHACWCOT_Update";
                            break;
                        case DataRowState.Unchanged:
                            goto NextRecord;
                        //break;
                        default:
                            break;
                    }

                    cmd.Connection = con;
                    prm = new SqlParameter("@CWCOTClaimID", dt.Rows[i]["CWCOTClaimID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@FCDeedRecordedDate", dt.Rows[i]["FCDeedRecordedDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PrepCompleteDate", dt.Rows[i]["PrepCompleteDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PrepAnalyst", dt.Rows[i]["PrepAnalyst"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PartACompleteDate", dt.Rows[i]["PartACompleteDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PartAAnalyst", dt.Rows[i]["PartAAnalyst"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@CurtailmentCode", dt.Rows[i]["CurtailmentCode"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PartBCompleteDate", dt.Rows[i]["PartBCompleteDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PartBAnalyst", dt.Rows[i]["PartBAnalyst"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@CurtailmentDate", dt.Rows[i]["CurtailmentDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PartAQCCompleteDate", dt.Rows[i]["PartAQCCompleteDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PartAQCAnalyst", dt.Rows[i]["PartAQCAnalyst"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PartBQCCompleteDate", dt.Rows[i]["PartBQCCompleteDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PartBQCAnalyst", dt.Rows[i]["PartBQCAnalyst"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimSubmittedDate", dt.Rows[i]["ClaimSubmittedDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimSubmittedAnalyst", dt.Rows[i]["ClaimSubmittedAnalyst"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimAmount", dt.Rows[i]["ClaimAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PaidDate", dt.Rows[i]["PaidDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PaidAmount", dt.Rows[i]["PaidAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuspendDate", dt.Rows[i]["SuspendDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ErrorSubmitDate", dt.Rows[i]["ErrorSubmitDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRefundDue", dt.Rows[i]["SuppRefundDue"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRefundFiledDate", dt.Rows[i]["SuppRefundFiledDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRefundAnalyst", dt.Rows[i]["SuppRefundAnalyst"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRefundAmount", dt.Rows[i]["SuppRefundAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryDue", dt.Rows[i]["SuppRecoveryDue"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryFiledDate", dt.Rows[i]["SuppRecoveryFiledDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryAnalyst", dt.Rows[i]["SuppRecoveryAnalyst"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryAmount", dt.Rows[i]["SuppRecoveryAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryPaidDate", dt.Rows[i]["SuppRecoveryPaidDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryPaidAmount", dt.Rows[i]["SuppRecoveryPaidAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LastUpdateDate", dt.Rows[i]["LastUpdateDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LastUpdateUser", dt.Rows[i]["LastUpdateUser"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@IsEDIAuthorized", dt.Rows[i]["IsEDIAuthorized"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@EDIAuthorizedUserId", dt.Rows[i]["EDIAuthorizedUserId"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@EDIAuthorizedDate", dt.Rows[i]["EDIAuthorizedDate"]);
                    cmd.Parameters.Add(prm);
                    // 20140728 gk fb2287 SuppREceivedDate
                    prm = new SqlParameter("@SuppReceivedDate", dt.Rows[i]["SuppReceivedDate"]);
                    cmd.Parameters.Add(prm);
                    // 20140801 gk 5128 ClientSystemUpdatedDate ClientSystemUpdatedUser
                    prm = new SqlParameter("@ClientSystemUpdatedDate", dt.Rows[i]["ClientSystemUpdatedDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClientSystemUpdatedUser", dt.Rows[i]["ClientSystemUpdatedUser"]);
                    cmd.Parameters.Add(prm);
                    // 20140929 gk 1429
                    prm = new SqlParameter("@InvestorClaimDue", dt.Rows[i]["InvestorClaimDue"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorClaimFiledDate", dt.Rows[i]["InvestorClaimFiledDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorClaimAmount", dt.Rows[i]["InvestorClaimAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorClaimAnalystID", dt.Rows[i]["InvestorClaimAnalystID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ReviewedForInvestorClaim", dt.Rows[i]["ReviewedForInvestorClaim"]);
                    cmd.Parameters.Add(prm);



                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;

                }

                dt.AcceptChanges();

                return true;

            }

            catch (Exception ex)
            {
                //dump the table into an error file so we have some record of where we were
                try
                {
                    CRFS.Data.ErrorDataDump.DumpTableToDefaultLocation(dt, "");

                }

                catch { }
                throw ex;

            }

            finally
            {

                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        #endregion

        #region "SFLS"
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="claimID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetInvestorTracking_FHASFLS_Claim(DataTable dt, int claimID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_InvTrk_FHASFLS_Select";

                SqlParameter parm = new SqlParameter("@ClaimID", claimID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();
                    //TBD from the reader, populate the table columns
                    row["SFLSClaimID"] = int.Parse(dr["SFLSClaimID"].ToString().Length == 0 ? "0" : dr["SFLSClaimID"].ToString());
                    row["ClaimID"] = int.Parse(dr["ClaimID"].ToString().Length == 0 ? "0" : dr["ClaimID"].ToString());
                    row["HUDIDDate"] = DateTime.Parse(dr["HUDIDDate"].ToString().Length == 0 ? "1/1/1900" : dr["HUDIDDate"].ToString());
                    row["PrepCompleteDate"] = DateTime.Parse(dr["PrepCompleteDate"].ToString().Length == 0 ? "1/1/1900" : dr["PrepCompleteDate"].ToString());
                    row["PrepAnalyst"] = int.Parse(dr["PrepAnalyst"].ToString().Length == 0 ? "0" : dr["PrepAnalyst"].ToString());
                    row["PartACompleteDate"] = DateTime.Parse(dr["PartACompleteDate"].ToString().Length == 0 ? "1/1/1900" : dr["PartACompleteDate"].ToString());
                    row["PartAAnalyst"] = int.Parse(dr["PartAAnalyst"].ToString().Length == 0 ? "0" : dr["PartAAnalyst"].ToString());
                    row["CurtailmentCode"] = int.Parse(dr["CurtailmentCode"].ToString().Length == 0 ? "0" : dr["CurtailmentCode"].ToString());
                    row["PartBCompleteDate"] = DateTime.Parse(dr["PartBCompleteDate"].ToString().Length == 0 ? "1/1/1900" : dr["PartBCompleteDate"].ToString());
                    row["PartBAnalyst"] = int.Parse(dr["PartBAnalyst"].ToString().Length == 0 ? "0" : dr["PartBAnalyst"].ToString());
                    row["CurtailmentDate"] = DateTime.Parse(dr["CurtailmentDate"].ToString().Length == 0 ? "1/1/1900" : dr["CurtailmentDate"].ToString());
                    row["PartAQCCompleteDate"] = DateTime.Parse(dr["PartAQCCompleteDate"].ToString().Length == 0 ? "1/1/1900" : dr["PartAQCCompleteDate"].ToString());
                    row["PartAQCAnalyst"] = int.Parse(dr["PartAQCAnalyst"].ToString().Length == 0 ? "0" : dr["PartAQCAnalyst"].ToString());
                    row["PartBQCCompleteDate"] = DateTime.Parse(dr["PartBQCCompleteDate"].ToString().Length == 0 ? "1/1/1900" : dr["PartBQCCompleteDate"].ToString());
                    row["PartBQCAnalyst"] = int.Parse(dr["PartBQCAnalyst"].ToString().Length == 0 ? "0" : dr["PartBQCAnalyst"].ToString());
                    row["ClaimSubmittedDate"] = DateTime.Parse(dr["ClaimSubmittedDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClaimSubmittedDate"].ToString());
                    row["ClaimSubmittedAnalyst"] = int.Parse(dr["ClaimSubmittedAnalyst"].ToString().Length == 0 ? "0" : dr["ClaimSubmittedAnalyst"].ToString());
                    row["ClaimAmount"] = decimal.Parse(dr["ClaimAmount"].ToString().Length == 0 ? "0" : dr["ClaimAmount"].ToString());
                    row["PaidDate"] = DateTime.Parse(dr["PaidDate"].ToString().Length == 0 ? "1/1/1900" : dr["PaidDate"].ToString());
                    row["PaidAmount"] = decimal.Parse(dr["PaidAmount"].ToString().Length == 0 ? "0" : dr["PaidAmount"].ToString());
                    row["SuspendDate"] = DateTime.Parse(dr["SuspendDate"].ToString().Length == 0 ? "1/1/1900" : dr["SuspendDate"].ToString());
                    row["ErrorSubmitDate"] = DateTime.Parse(dr["ErrorSubmitDate"].ToString().Length == 0 ? "1/1/1900" : dr["ErrorSubmitDate"].ToString());
                    row["ServiceTransferDate"] = DateTime.Parse(dr["ServiceTransferDate"].ToString().Length == 0 ? "1/1/1900" : dr["ServiceTransferDate"].ToString());
                    row["SuppRefundDue"] = bool.Parse(dr["SuppRefundDue"].ToString().Length == 0 ? "false" : dr["SuppRefundDue"].ToString());
                    row["SuppRefundFiledDate"] = DateTime.Parse(dr["SuppRefundFiledDate"].ToString().Length == 0 ? "1/1/1900" : dr["SuppRefundFiledDate"].ToString());
                    row["SuppRefundAnalyst"] = int.Parse(dr["SuppRefundAnalyst"].ToString().Length == 0 ? "0" : dr["SuppRefundAnalyst"].ToString());
                    row["SuppRefundAmount"] = decimal.Parse(dr["SuppRefundAmount"].ToString().Length == 0 ? "0" : dr["SuppRefundAmount"].ToString());
                    row["SuppRecoveryDue"] = bool.Parse(dr["SuppRecoveryDue"].ToString().Length == 0 ? "false" : dr["SuppRecoveryDue"].ToString());
                    row["SuppRecoveryFiledDate"] = DateTime.Parse(dr["SuppRecoveryFiledDate"].ToString().Length == 0 ? "1/1/1900" : dr["SuppRecoveryFiledDate"].ToString());
                    row["SuppRecoveryAnalyst"] = int.Parse(dr["SuppRecoveryAnalyst"].ToString().Length == 0 ? "0" : dr["SuppRecoveryAnalyst"].ToString());
                    row["SuppRecoveryAmount"] = decimal.Parse(dr["SuppRecoveryAmount"].ToString().Length == 0 ? "0" : dr["SuppRecoveryAmount"].ToString());
                    row["SuppRecoveryPaidDate"] = DateTime.Parse(dr["SuppRecoveryPaidDate"].ToString().Length == 0 ? "1/1/1900" : dr["SuppRecoveryPaidDate"].ToString());
                    row["SuppRecoveryPaidAmount"] = decimal.Parse(dr["SuppRecoveryPaidAmount"].ToString().Length == 0 ? "0" : dr["SuppRecoveryPaidAmount"].ToString());
                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                    row["EnteredByUser"] = int.Parse(dr["EnteredByUser"].ToString().Length == 0 ? "0" : dr["EnteredByUser"].ToString());
                    row["EnteredByUserName"] = dr["EnteredByUserName"].ToString();
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    row["LastUpdateUser"] = int.Parse(dr["LastUpdateUser"].ToString().Length == 0 ? "0" : dr["LastUpdateUser"].ToString());
                    row["LastUpdateUserName"] = dr["LastUpdateUserName"].ToString();
                    // gk edi auth 20130829
                    row["IsEDIAuthorized"] = bool.Parse(dr["IsEDIAuthorized"].ToString().Length==0 ? "false" : dr["IsEDIAuthorized"].ToString());
                    row["EDIAuthorizedUserId"] = int.Parse(dr["EDIAuthorizedUserId"].ToString().Length==0 ? "0" : dr["EDIAuthorizedUserId"].ToString());
                    row["EDIAuthorizedDate"] = DateTime.Parse(dr["EDIAuthorizedDate"].ToString().Length==0 ? "1/1/1900" : dr["EDIAuthorizedDate"].ToString());
                    row["IneligibilityReasonID"] = int.Parse(dr["IneligibilityReasonID"].ToString().Length == 0 ? "0" : dr["IneligibilityReasonID"].ToString());
                    // 20140729 gk fb2287 SuppReceivedDate
                    row["SuppReceivedDate"] = DateTime.Parse(dr["SuppReceivedDate"].ToString().Length==0 ? "1/1/1900" : dr["SuppReceivedDate"].ToString());
                    // 20140801 gk 5128 ClientSystemUpdatedDate ClientSystemUpdatedUser
                    row["ClientSystemUpdatedDate"] = DateTime.Parse(dr["ClientSystemUpdatedDate"].ToString().Length==0 ? "1/1/1900" : dr["ClientSystemUpdatedDate"].ToString());
                    row["ClientSystemUpdatedUser"] = int.Parse(dr["ClientSystemUpdatedUser"].ToString().Length==0 ? "0" : dr["ClientSystemUpdatedUser"].ToString());
                    // 20140929 gk 1429
                    row["InvestorClaimDue"] = bool.Parse(dr["InvestorClaimDue"].ToString().Length == 0 ? "false" : dr["InvestorClaimDue"].ToString());
                    row["InvestorClaimFiledDate"] = DateTime.Parse(dr["InvestorClaimFiledDate"].ToString().Length == 0 ? "1/1/1900" : dr["InvestorClaimFiledDate"].ToString());
                    row["InvestorClaimAmount"] = decimal.Parse(dr["InvestorClaimAmount"].ToString().Length == 0 ? "0" : dr["InvestorClaimAmount"].ToString());
                    row["InvestorClaimAnalystID"] = int.Parse(dr["InvestorClaimAnalystID"].ToString().Length == 0 ? "0" : dr["InvestorClaimAnalystID"].ToString());
                    row["ReviewedForInvestorClaim"] = DateTime.Parse(dr["ReviewedForInvestorClaim"].ToString().Length == 0 ? "1/1/1900" : dr["ReviewedForInvestorClaim"].ToString());


                    dt.Rows.Add(row);
                }

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool SaveInvestorTrackingFHASFLSClaim(DataTable dt, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                int recordsAffected;

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                    SqlParameter prm = new SqlParameter();

                    switch (dt.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            break;
                        case DataRowState.Deleted:
                            break;
                        case DataRowState.Detached:
                            break;
                        case DataRowState.Modified:
                            cmd.CommandText = "usp_InvTrk_FHASFLS_Update";
                            break;
                        case DataRowState.Unchanged:
                            goto NextRecord;
                        //break;
                        default:
                            break;
                    }

                    cmd.Connection = con;
                    prm = new SqlParameter("@SFLSClaimID", dt.Rows[i]["SFLSClaimID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@HUDIDDate", dt.Rows[i]["HUDIDDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PrepCompleteDate", dt.Rows[i]["PrepCompleteDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PrepAnalyst", dt.Rows[i]["PrepAnalyst"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PartACompleteDate", dt.Rows[i]["PartACompleteDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PartAAnalyst", dt.Rows[i]["PartAAnalyst"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@CurtailmentCode", dt.Rows[i]["CurtailmentCode"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PartBCompleteDate", dt.Rows[i]["PartBCompleteDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PartBAnalyst", dt.Rows[i]["PartBAnalyst"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@CurtailmentDate", dt.Rows[i]["CurtailmentDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PartAQCCompleteDate", dt.Rows[i]["PartAQCCompleteDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PartAQCAnalyst", dt.Rows[i]["PartAQCAnalyst"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PartBQCCompleteDate", dt.Rows[i]["PartBQCCompleteDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PartBQCAnalyst", dt.Rows[i]["PartBQCAnalyst"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimSubmittedDate", dt.Rows[i]["ClaimSubmittedDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimSubmittedAnalyst", dt.Rows[i]["ClaimSubmittedAnalyst"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimAmount", dt.Rows[i]["ClaimAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PaidDate", dt.Rows[i]["PaidDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PaidAmount", dt.Rows[i]["PaidAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuspendDate", dt.Rows[i]["SuspendDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ErrorSubmitDate", dt.Rows[i]["ErrorSubmitDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ServiceTransferDate", dt.Rows[i]["ServiceTransferDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRefundDue", dt.Rows[i]["SuppRefundDue"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRefundFiledDate", dt.Rows[i]["SuppRefundFiledDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRefundAnalyst", dt.Rows[i]["SuppRefundAnalyst"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRefundAmount", dt.Rows[i]["SuppRefundAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryDue", dt.Rows[i]["SuppRecoveryDue"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryFiledDate", dt.Rows[i]["SuppRecoveryFiledDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryAnalyst", dt.Rows[i]["SuppRecoveryAnalyst"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryAmount", dt.Rows[i]["SuppRecoveryAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryPaidDate", dt.Rows[i]["SuppRecoveryPaidDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppRecoveryPaidAmount", dt.Rows[i]["SuppRecoveryPaidAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LastUpdateDate", dt.Rows[i]["LastUpdateDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LastUpdateUser", dt.Rows[i]["LastUpdateUser"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@IsEDIAuthorized", dt.Rows[i]["IsEDIAuthorized"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@EDIAuthorizedUserId", dt.Rows[i]["EDIAuthorizedUserId"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@EDIAuthorizedDate", dt.Rows[i]["EDIAuthorizedDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@IneligibilityReasonID", dt.Rows[i]["IneligibilityReasonID"]);
                    cmd.Parameters.Add(prm);
                    // 20140729 gk fb2287 SuppReceivedDate
                    prm = new SqlParameter("@SuppReceivedDate", dt.Rows[i]["SuppReceivedDate"]);
                    cmd.Parameters.Add(prm);
                    // 20140801 gk 5128 ClientSystemUpdatedDate ClientSystemUpdatedUser
                    prm = new SqlParameter("@ClientSystemUpdatedDate", dt.Rows[i]["ClientSystemUpdatedDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClientSystemUpdatedUser", dt.Rows[i]["ClientSystemUpdatedUser"]);
                    cmd.Parameters.Add(prm);
                    // 20140929 gk 1429
                    prm = new SqlParameter("@InvestorClaimDue", dt.Rows[i]["InvestorClaimDue"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorClaimFiledDate", dt.Rows[i]["InvestorClaimFiledDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorClaimAmount", dt.Rows[i]["InvestorClaimAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorClaimAnalystID", dt.Rows[i]["InvestorClaimAnalystID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ReviewedForInvestorClaim", dt.Rows[i]["ReviewedForInvestorClaim"]);
                    cmd.Parameters.Add(prm);
                    
                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;

                }

                dt.AcceptChanges();

                return true;

            }

            catch (Exception ex)
            {
                //dump the table into an error file so we have some record of where we were
                try
                {
                    CRFS.Data.ErrorDataDump.DumpTableToDefaultLocation(dt, "");

                }

                catch { }
                throw ex;

            }

            finally
            {

                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        #endregion
        #region "FHA Combined"
        internal DataTable GetInvestorTracking_FHACombined_Claim(DataTable dt, int claimID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_InvTrk_FHAClaim_Select";

                SqlParameter parm = new SqlParameter("@ClaimID", claimID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow nr = dt.NewRow();
                    //Code to fill the table
                    nr["FHAClaimID"] = System.Int32.Parse((dr["FHAClaimID"].ToString() == "") ? "0" : dr["FHAClaimID"].ToString());
                    nr["ClaimID"] = System.Int32.Parse((dr["ClaimID"].ToString() == "") ? "0" : dr["ClaimID"].ToString());
                    //nr["SuppParentFHAClaimID"] = System.Int32.Parse((dr["SuppParentFHAClaimID"].ToString() == "") ? "0" : dr["SuppParentFHAClaimID"].ToString());
                    nr["SuppParentFHAClaimID"] = dr["SuppParentFHAClaimID"];
                    nr["EnteredDate"] = System.DateTime.Parse((dr["EnteredDate"].ToString() == "") ? "1/1/1900" : dr["EnteredDate"].ToString());
                    nr["EnteredByUser"] = System.Int32.Parse((dr["EnteredByUser"].ToString() == "") ? "0" : dr["EnteredByUser"].ToString());
                    nr["LastUpdateDate"] = System.DateTime.Parse((dr["LastUpdateDate"].ToString() == "") ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    nr["LastUpdateUser"] = System.Int32.Parse((dr["LastUpdateUser"].ToString() == "") ? "0" : dr["LastUpdateUser"].ToString());
                    nr["ClaimAmount"] = System.Decimal.Parse((dr["ClaimAmount"].ToString() == "") ? "0.0" : dr["ClaimAmount"].ToString());
                    nr["ConvPartAClaimAmount"] = System.Decimal.Parse((dr["ConvPartAClaimAmount"].ToString() == "") ? "0.0" : dr["ConvPartAClaimAmount"].ToString());
                    nr["ConveyanceExtensionExpirationDate"] = System.DateTime.Parse((dr["ConveyanceExtensionExpirationDate"].ToString() == "") ? "1/1/1900" : dr["ConveyanceExtensionExpirationDate"].ToString());
                    nr["CurtailmentCodeID"] = System.Int32.Parse((dr["CurtailmentCodeID"].ToString() == "") ? "0" : dr["CurtailmentCodeID"].ToString());
                    nr["CurtailmentDate"] = System.DateTime.Parse((dr["CurtailmentDate"].ToString() == "") ? "1/1/1900" : dr["CurtailmentDate"].ToString());
                    nr["FHAModificationDate"] = System.DateTime.Parse((dr["FHAModificationDate"].ToString() == "") ? "1/1/1900" : dr["FHAModificationDate"].ToString());
                    nr["ExpectedPartBProceeds"] = System.Decimal.Parse((dr["ExpectedPartBProceeds"].ToString() == "") ? "0.0" : dr["ExpectedPartBProceeds"].ToString());
                    nr["FCLDeedRecordedDate"] = System.DateTime.Parse((dr["FCLDeedRecordedDate"].ToString() == "") ? "1/1/1900" : dr["FCLDeedRecordedDate"].ToString());
                    nr["FCLFirstLegalDate"] = System.DateTime.Parse((dr["FCLFirstLegalDate"].ToString() == "") ? "1/1/1900" : dr["FCLFirstLegalDate"].ToString());
                    nr["FTVDate"] = System.DateTime.Parse((dr["FTVDate"].ToString() == "") ? "1/1/1900" : dr["FTVDate"].ToString());
                    nr["HUDDeedRecordedDate"] = System.DateTime.Parse((dr["HUDDeedRecordedDate"].ToString() == "") ? "1/1/1900" : dr["HUDDeedRecordedDate"].ToString());
                    nr["HUDIDDate"] = System.DateTime.Parse((dr["HUDIDDate"].ToString() == "") ? "1/1/1900" : dr["HUDIDDate"].ToString());
                    nr["ICCDate"] = System.DateTime.Parse((dr["ICCDate"].ToString() == "") ? "1/1/1900" : dr["ICCDate"].ToString());
                    nr["ICCReportDate"] = System.DateTime.Parse((dr["ICCReportDate"].ToString() == "") ? "1/1/1900" : dr["ICCReportDate"].ToString());
                    nr["IneligibilityDate"] = System.DateTime.Parse((dr["IneligibilityDate"].ToString() == "") ? "1/1/1900" : dr["IneligibilityDate"].ToString());
                    nr["IneligibilityReasonID"] = System.Int32.Parse((dr["IneligibilityReasonID"].ToString() == "") ? "0" : dr["IneligibilityReasonID"].ToString());
                    nr["IsHAMP"] = System.Boolean.Parse((dr["IsHAMP"].ToString() == "") ? "false" : dr["IsHAMP"].ToString());
                    nr["IsInvestorClaimDue"] = System.Boolean.Parse((dr["IsInvestorClaimDue"].ToString() == "") ? "false" : dr["IsInvestorClaimDue"].ToString());
                    nr["IsMobileHomeTrailer"] = System.Boolean.Parse((dr["IsMobileHomeTrailer"].ToString() == "") ? "false" : dr["IsMobileHomeTrailer"].ToString());
                    nr["MHTEndDate"] = System.DateTime.Parse((dr["MHTEndDate"].ToString() == "") ? "1/1/1900" : dr["MHTEndDate"].ToString());
                    nr["MHTReviewedDate"] = System.DateTime.Parse((dr["MHTReviewedDate"].ToString() == "") ? "1/1/1900" : dr["MHTReviewedDate"].ToString());
                    nr["MHTStartDate"] = System.DateTime.Parse((dr["MHTStartDate"].ToString() == "") ? "1/1/1900" : dr["MHTStartDate"].ToString());
                    nr["PaidAmount"] = System.Decimal.Parse((dr["PaidAmount"].ToString() == "") ? "0.0" : dr["PaidAmount"].ToString());
                    nr["ConvPartAPaidAmount"] = System.Decimal.Parse((dr["ConvPartAPaidAmount"].ToString() == "") ? "0.0" : dr["ConvPartAPaidAmount"].ToString());
                    nr["RecorderLetterReceiveDate"] = System.DateTime.Parse((dr["RecorderLetterReceiveDate"].ToString() == "") ? "1/1/1900" : dr["RecorderLetterReceiveDate"].ToString());
                    nr["RecordingInstructionsSentDate"] = System.DateTime.Parse((dr["RecordingInstructionsSentDate"].ToString() == "") ? "1/1/1900" : dr["RecordingInstructionsSentDate"].ToString());
                    nr["RecorderLetterVerified"] = System.DateTime.Parse((dr["RecorderLetterVerified"].ToString() == "") ? "1/1/1900" : dr["RecorderLetterVerified"].ToString());
                    nr["RecorderLetterVerifiedUser"] = System.Int32.Parse((dr["RecorderLetterVerifiedUser"].ToString() == "") ? "0" : dr["RecorderLetterVerifiedUser"].ToString());
                    nr["FTVDateReported"] = System.DateTime.Parse((dr["FTVDateReported"].ToString() == "") ? "1/1/1900" : dr["FTVDateReported"].ToString());
                    nr["ReviewedForInvestorClaim"] = System.DateTime.Parse((dr["ReviewedForInvestorClaim"].ToString() == "") ? "1/1/1900" : dr["ReviewedForInvestorClaim"].ToString());
                    nr["ServiceTransferDate"] = System.DateTime.Parse((dr["ServiceTransferDate"].ToString() == "") ? "1/1/1900" : dr["ServiceTransferDate"].ToString());
                    nr["SettlementDate"] = System.DateTime.Parse((dr["SettlementDate"].ToString() == "") ? "1/1/1900" : dr["SettlementDate"].ToString());
                    nr["ConvPartASettlementDate"] = System.DateTime.Parse((dr["ConvPartASettlementDate"].ToString() == "") ? "1/1/1900" : dr["ConvPartASettlementDate"].ToString());
                    nr["SuppRecoveryDue"] = System.Boolean.Parse((dr["SuppRecoveryDue"].ToString() == "") ? "false" : dr["SuppRecoveryDue"].ToString());
                    nr["SuppRefundDueHUD"] = System.Boolean.Parse((dr["SuppRefundDueHUD"].ToString() == "") ? "false" : dr["SuppRefundDueHUD"].ToString());
                    nr["SuspendDate"] = System.DateTime.Parse((dr["SuspendDate"].ToString() == "") ? "1/1/1900" : dr["SuspendDate"].ToString());
                    nr["ConvPartASuspendDate"] = System.DateTime.Parse((dr["ConvPartASuspendDate"].ToString() == "") ? "1/1/1900" : dr["ConvPartASuspendDate"].ToString());
                    nr["TALDate"] = System.DateTime.Parse((dr["TALDate"].ToString() == "") ? "1/1/1900" : dr["TALDate"].ToString());
                    nr["TitleExtensionDate"] = System.DateTime.Parse((dr["TitleExtensionDate"].ToString() == "") ? "1/1/1900" : dr["TitleExtensionDate"].ToString());
                    nr["TitleSubmitAnalystID"] = System.Int32.Parse((dr["TitleSubmitAnalystID"].ToString() == "") ? "0" : dr["TitleSubmitAnalystID"].ToString());
                    nr["TitleSubmitDate"] = System.DateTime.Parse((dr["TitleSubmitDate"].ToString() == "") ? "1/1/1900" : dr["TitleSubmitDate"].ToString());
                    nr["UnpaidBalance"] = System.Decimal.Parse((dr["UnpaidBalance"].ToString() == "") ? "0.0" : dr["UnpaidBalance"].ToString());
                    nr["ClaimSubmittedAnalystID"] = System.Int32.Parse((dr["ClaimSubmittedAnalystID"].ToString() == "") ? "0" : dr["ClaimSubmittedAnalystID"].ToString());
                    nr["ConvPartASubmittedAnalystID"] = System.Int32.Parse((dr["ConvPartASubmittedAnalystID"].ToString() == "") ? "0" : dr["ConvPartASubmittedAnalystID"].ToString());
                    nr["ClaimSubmittedDate"] = System.DateTime.Parse((dr["ClaimSubmittedDate"].ToString() == "") ? "1/1/1900" : dr["ClaimSubmittedDate"].ToString());
                    nr["ConvPartASubmittedDate"] = System.DateTime.Parse((dr["ConvPartASubmittedDate"].ToString() == "") ? "1/1/1900" : dr["ConvPartASubmittedDate"].ToString());
                    nr["ClientSystemUpdatedDate"] = System.DateTime.Parse((dr["ClientSystemUpdatedDate"].ToString() == "") ? "1/1/1900" : dr["ClientSystemUpdatedDate"].ToString());
                    nr["ConvPartAClientSystemUpdatedDate"] = System.DateTime.Parse((dr["ConvPartAClientSystemUpdatedDate"].ToString() == "") ? "1/1/1900" : dr["ConvPartAClientSystemUpdatedDate"].ToString());
                    nr["ClientSystemUpdatedUser"] = System.Int32.Parse((dr["ClientSystemUpdatedUser"].ToString() == "") ? "0" : dr["ClientSystemUpdatedUser"].ToString());
                    nr["ConvPartAClientSystemUpdatedUser"] = System.Int32.Parse((dr["ConvPartAClientSystemUpdatedUser"].ToString() == "") ? "0" : dr["ConvPartAClientSystemUpdatedUser"].ToString());
                    nr["EDIAuthorizedDate"] = System.DateTime.Parse((dr["EDIAuthorizedDate"].ToString() == "") ? "1/1/1900" : dr["EDIAuthorizedDate"].ToString());
                    nr["ConvEDIAuthorizedDate"] = System.DateTime.Parse((dr["ConvEDIAuthorizedDate"].ToString() == "") ? "1/1/1900" : dr["ConvEDIAuthorizedDate"].ToString());
                    nr["EDIAuthorizedUserID"] = System.Int32.Parse((dr["EDIAuthorizedUserID"].ToString() == "") ? "0" : dr["EDIAuthorizedUserID"].ToString());
                    nr["ConvEDIAuthorizedUserID"] = System.Int32.Parse((dr["ConvEDIAuthorizedUserID"].ToString() == "") ? "0" : dr["ConvEDIAuthorizedUserID"].ToString());
                    nr["ErrorSubmitDate"] = System.DateTime.Parse((dr["ErrorSubmitDate"].ToString() == "") ? "1/1/1900" : dr["ErrorSubmitDate"].ToString());
                    nr["ConvPartAErrorSubmitDate"] = System.DateTime.Parse((dr["ConvPartAErrorSubmitDate"].ToString() == "") ? "1/1/1900" : dr["ConvPartAErrorSubmitDate"].ToString());
                    nr["IsEDIAuthorized"] = System.Boolean.Parse((dr["IsEDIAuthorized"].ToString() == "") ? "false" : dr["IsEDIAuthorized"].ToString());
                    nr["ConvPartAIsEDIAuthorized"] = System.Boolean.Parse((dr["ConvPartAIsEDIAuthorized"].ToString() == "") ? "false" : dr["ConvPartAIsEDIAuthorized"].ToString());
                    nr["PartAAnalyst"] = System.Int32.Parse((dr["PartAAnalyst"].ToString() == "") ? "0" : dr["PartAAnalyst"].ToString());
                    nr["PartACompleteDate"] = System.DateTime.Parse((dr["PartACompleteDate"].ToString() == "") ? "1/1/1900" : dr["PartACompleteDate"].ToString());
                    nr["PartBAnalyst"] = System.Int32.Parse((dr["PartBAnalyst"].ToString() == "") ? "0" : dr["PartBAnalyst"].ToString());
                    nr["PartBCompleteDate"] = System.DateTime.Parse((dr["PartBCompleteDate"].ToString() == "") ? "1/1/1900" : dr["PartBCompleteDate"].ToString());
                    nr["PartAQCAnalyst"] = System.Int32.Parse((dr["PartAQCAnalyst"].ToString() == "") ? "0" : dr["PartAQCAnalyst"].ToString());
                    nr["PartAQCCompleteDate"] = System.DateTime.Parse((dr["PartAQCCompleteDate"].ToString() == "") ? "1/1/1900" : dr["PartAQCCompleteDate"].ToString());
                    nr["PartBQCAnalyst"] = System.Int32.Parse((dr["PartBQCAnalyst"].ToString() == "") ? "0" : dr["PartBQCAnalyst"].ToString());
                    nr["PartBQCCompleteDate"] = System.DateTime.Parse((dr["PartBQCCompleteDate"].ToString() == "") ? "1/1/1900" : dr["PartBQCCompleteDate"].ToString());
                    nr["PrepAnalyst"] = System.Int32.Parse((dr["PrepAnalyst"].ToString() == "") ? "0" : dr["PrepAnalyst"].ToString());
                    nr["PrepCompleteDate"] = System.DateTime.Parse((dr["PrepCompleteDate"].ToString() == "") ? "1/1/1900" : dr["PrepCompleteDate"].ToString());
                    nr["ConvPartAPrepAnalyst"] = System.Int32.Parse((dr["ConvPartAPrepAnalyst"].ToString() == "") ? "0" : dr["ConvPartAPrepAnalyst"].ToString());
                    nr["ConvPartAPrepCompleteDate"] = System.DateTime.Parse((dr["ConvPartAPrepCompleteDate"].ToString() == "") ? "1/1/1900" : dr["ConvPartAPrepCompleteDate"].ToString());
                    nr["PrepReferralAnalyst"] = System.Int32.Parse((dr["PrepReferralAnalyst"].ToString() == "") ? "0" : dr["PrepReferralAnalyst"].ToString());
                    nr["PrepReferralCompleteDate"] = System.DateTime.Parse((dr["PrepReferralCompleteDate"].ToString() == "") ? "1/1/1900" : dr["PrepReferralCompleteDate"].ToString());
                    nr["ConvPartBOnly"] = System.Boolean.Parse((dr["ConvPartBOnly"].ToString() == "") ? "false" : dr["ConvPartBOnly"].ToString());
                    nr["SupplementalClaimTypeID"] = System.Int32.Parse((dr["SupplementalClaimTypeID"].ToString() == "") ? "0" : dr["SupplementalClaimTypeID"].ToString());
                    // 20151001 gk fb 22705
                    nr["ClaimSubTypeID"] = System.Int32.Parse((dr["ClaimSubTypeID"].ToString() == "") ? "0" : dr["ClaimSubTypeID"].ToString());

                    //20160322 TRS FB 29162
                    nr["IsSuppReview"] = System.Boolean.Parse((dr["IsSuppReview"].ToString() == "") ? "false" : dr["IsSuppReview"].ToString());
                    nr["SuppReviewSetDate"] = System.DateTime.Parse((dr["SuppReviewSetDate"].ToString() == "") ? "1/1/1900" : dr["SuppReviewSetDate"].ToString());
                    nr["SuppReviewSetUserID"] = System.Int32.Parse((dr["SuppReviewSetUserID"].ToString() == "") ? "0" : dr["SuppReviewSetUserID"].ToString());
                    nr["ClearTitleDate"] = System.DateTime.Parse((dr["ClearTitleDate"].ToString() == "") ? "1/1/1900" : dr["ClearTitleDate"].ToString());
                    nr["MarketableTitleDate"] = System.DateTime.Parse((dr["MarketableTitleDate"].ToString() == "") ? "1/1/1900" : dr["MarketableTitleDate"].ToString());
                    
                    nr["deltaCheck"] = dr["deltaCheck"].ToString();
                    dt.Rows.Add(nr);
                
                }

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }

        }

        internal DataTable GetInvestorTracking_FHACombined_Claim_ByFHAClaimID(DataTable dt, int FHAClaimID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_InvTrk_FHAClaim_Select_ByFHAClaimID";

                SqlParameter parm = new SqlParameter("@FHAClaimID", FHAClaimID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow nr = dt.NewRow();
                    //Code to fill the table
                    nr["FHAClaimID"] = System.Int32.Parse((dr["FHAClaimID"].ToString() == "") ? "0" : dr["FHAClaimID"].ToString());
                    nr["ClaimID"] = System.Int32.Parse((dr["ClaimID"].ToString() == "") ? "0" : dr["ClaimID"].ToString());
                    //nr["SuppParentFHAClaimID"] = System.Int32.Parse((dr["SuppParentFHAClaimID"].ToString() == "") ? "0" : dr["SuppParentFHAClaimID"].ToString());
                    nr["SuppParentFHAClaimID"] = dr["SuppParentFHAClaimID"];
                    nr["EnteredDate"] = System.DateTime.Parse((dr["EnteredDate"].ToString() == "") ? "1/1/1900" : dr["EnteredDate"].ToString());
                    nr["EnteredByUser"] = System.Int32.Parse((dr["EnteredByUser"].ToString() == "") ? "0" : dr["EnteredByUser"].ToString());
                    nr["LastUpdateDate"] = System.DateTime.Parse((dr["LastUpdateDate"].ToString() == "") ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    nr["LastUpdateUser"] = System.Int32.Parse((dr["LastUpdateUser"].ToString() == "") ? "0" : dr["LastUpdateUser"].ToString());
                    nr["ClaimAmount"] = System.Decimal.Parse((dr["ClaimAmount"].ToString() == "") ? "0.0" : dr["ClaimAmount"].ToString());
                    nr["ConvPartAClaimAmount"] = System.Decimal.Parse((dr["ConvPartAClaimAmount"].ToString() == "") ? "0.0" : dr["ConvPartAClaimAmount"].ToString());
                    nr["ConveyanceExtensionExpirationDate"] = System.DateTime.Parse((dr["ConveyanceExtensionExpirationDate"].ToString() == "") ? "1/1/1900" : dr["ConveyanceExtensionExpirationDate"].ToString());
                    nr["CurtailmentCodeID"] = System.Int32.Parse((dr["CurtailmentCodeID"].ToString() == "") ? "0" : dr["CurtailmentCodeID"].ToString());
                    nr["CurtailmentDate"] = System.DateTime.Parse((dr["CurtailmentDate"].ToString() == "") ? "1/1/1900" : dr["CurtailmentDate"].ToString());
                    nr["FHAModificationDate"] = System.DateTime.Parse((dr["FHAModificationDate"].ToString() == "") ? "1/1/1900" : dr["FHAModificationDate"].ToString());
                    nr["ExpectedPartBProceeds"] = System.Decimal.Parse((dr["ExpectedPartBProceeds"].ToString() == "") ? "0.0" : dr["ExpectedPartBProceeds"].ToString());
                    nr["FCLDeedRecordedDate"] = System.DateTime.Parse((dr["FCLDeedRecordedDate"].ToString() == "") ? "1/1/1900" : dr["FCLDeedRecordedDate"].ToString());
                    nr["FCLFirstLegalDate"] = System.DateTime.Parse((dr["FCLFirstLegalDate"].ToString() == "") ? "1/1/1900" : dr["FCLFirstLegalDate"].ToString());
                    nr["FTVDate"] = System.DateTime.Parse((dr["FTVDate"].ToString() == "") ? "1/1/1900" : dr["FTVDate"].ToString());
                    nr["HUDDeedRecordedDate"] = System.DateTime.Parse((dr["HUDDeedRecordedDate"].ToString() == "") ? "1/1/1900" : dr["HUDDeedRecordedDate"].ToString());
                    nr["HUDIDDate"] = System.DateTime.Parse((dr["HUDIDDate"].ToString() == "") ? "1/1/1900" : dr["HUDIDDate"].ToString());
                    nr["ICCDate"] = System.DateTime.Parse((dr["ICCDate"].ToString() == "") ? "1/1/1900" : dr["ICCDate"].ToString());
                    nr["ICCReportDate"] = System.DateTime.Parse((dr["ICCReportDate"].ToString() == "") ? "1/1/1900" : dr["ICCReportDate"].ToString());
                    nr["IneligibilityDate"] = System.DateTime.Parse((dr["IneligibilityDate"].ToString() == "") ? "1/1/1900" : dr["IneligibilityDate"].ToString());
                    nr["IneligibilityReasonID"] = System.Int32.Parse((dr["IneligibilityReasonID"].ToString() == "") ? "0" : dr["IneligibilityReasonID"].ToString());
                    nr["IsHAMP"] = System.Boolean.Parse((dr["IsHAMP"].ToString() == "") ? "false" : dr["IsHAMP"].ToString());
                    nr["IsInvestorClaimDue"] = System.Boolean.Parse((dr["IsInvestorClaimDue"].ToString() == "") ? "false" : dr["IsInvestorClaimDue"].ToString());
                    nr["IsMobileHomeTrailer"] = System.Boolean.Parse((dr["IsMobileHomeTrailer"].ToString() == "") ? "false" : dr["IsMobileHomeTrailer"].ToString());
                    nr["MHTEndDate"] = System.DateTime.Parse((dr["MHTEndDate"].ToString() == "") ? "1/1/1900" : dr["MHTEndDate"].ToString());
                    nr["MHTReviewedDate"] = System.DateTime.Parse((dr["MHTReviewedDate"].ToString() == "") ? "1/1/1900" : dr["MHTReviewedDate"].ToString());
                    nr["MHTStartDate"] = System.DateTime.Parse((dr["MHTStartDate"].ToString() == "") ? "1/1/1900" : dr["MHTStartDate"].ToString());
                    nr["PaidAmount"] = System.Decimal.Parse((dr["PaidAmount"].ToString() == "") ? "0.0" : dr["PaidAmount"].ToString());
                    nr["ConvPartAPaidAmount"] = System.Decimal.Parse((dr["ConvPartAPaidAmount"].ToString() == "") ? "0.0" : dr["ConvPartAPaidAmount"].ToString());
                    nr["RecorderLetterReceiveDate"] = System.DateTime.Parse((dr["RecorderLetterReceiveDate"].ToString() == "") ? "1/1/1900" : dr["RecorderLetterReceiveDate"].ToString());
                    nr["RecordingInstructionsSentDate"] = System.DateTime.Parse((dr["RecordingInstructionsSentDate"].ToString() == "") ? "1/1/1900" : dr["RecordingInstructionsSentDate"].ToString());
                    nr["RecorderLetterVerified"] = System.DateTime.Parse((dr["RecorderLetterVerified"].ToString() == "") ? "1/1/1900" : dr["RecorderLetterVerified"].ToString());
                    nr["RecorderLetterVerifiedUser"] = System.Int32.Parse((dr["RecorderLetterVerifiedUser"].ToString() == "") ? "0" : dr["RecorderLetterVerifiedUser"].ToString());
                    nr["FTVDateReported"] = System.DateTime.Parse((dr["FTVDateReported"].ToString() == "") ? "1/1/1900" : dr["FTVDateReported"].ToString());
                    nr["ReviewedForInvestorClaim"] = System.DateTime.Parse((dr["ReviewedForInvestorClaim"].ToString() == "") ? "1/1/1900" : dr["ReviewedForInvestorClaim"].ToString());
                    nr["ServiceTransferDate"] = System.DateTime.Parse((dr["ServiceTransferDate"].ToString() == "") ? "1/1/1900" : dr["ServiceTransferDate"].ToString());
                    nr["SettlementDate"] = System.DateTime.Parse((dr["SettlementDate"].ToString() == "") ? "1/1/1900" : dr["SettlementDate"].ToString());
                    nr["ConvPartASettlementDate"] = System.DateTime.Parse((dr["ConvPartASettlementDate"].ToString() == "") ? "1/1/1900" : dr["ConvPartASettlementDate"].ToString());
                    nr["SuppRecoveryDue"] = System.Boolean.Parse((dr["SuppRecoveryDue"].ToString() == "") ? "false" : dr["SuppRecoveryDue"].ToString());
                    nr["SuppRefundDueHUD"] = System.Boolean.Parse((dr["SuppRefundDueHUD"].ToString() == "") ? "false" : dr["SuppRefundDueHUD"].ToString());
                    nr["SuspendDate"] = System.DateTime.Parse((dr["SuspendDate"].ToString() == "") ? "1/1/1900" : dr["SuspendDate"].ToString());
                    nr["ConvPartASuspendDate"] = System.DateTime.Parse((dr["ConvPartASuspendDate"].ToString() == "") ? "1/1/1900" : dr["ConvPartASuspendDate"].ToString());
                    nr["TALDate"] = System.DateTime.Parse((dr["TALDate"].ToString() == "") ? "1/1/1900" : dr["TALDate"].ToString());
                    nr["TitleExtensionDate"] = System.DateTime.Parse((dr["TitleExtensionDate"].ToString() == "") ? "1/1/1900" : dr["TitleExtensionDate"].ToString());
                    nr["TitleSubmitAnalystID"] = System.Int32.Parse((dr["TitleSubmitAnalystID"].ToString() == "") ? "0" : dr["TitleSubmitAnalystID"].ToString());
                    nr["TitleSubmitDate"] = System.DateTime.Parse((dr["TitleSubmitDate"].ToString() == "") ? "1/1/1900" : dr["TitleSubmitDate"].ToString());
                    nr["UnpaidBalance"] = System.Decimal.Parse((dr["UnpaidBalance"].ToString() == "") ? "0.0" : dr["UnpaidBalance"].ToString());
                    nr["ClaimSubmittedAnalystID"] = System.Int32.Parse((dr["ClaimSubmittedAnalystID"].ToString() == "") ? "0" : dr["ClaimSubmittedAnalystID"].ToString());
                    nr["ConvPartASubmittedAnalystID"] = System.Int32.Parse((dr["ConvPartASubmittedAnalystID"].ToString() == "") ? "0" : dr["ConvPartASubmittedAnalystID"].ToString());
                    nr["ClaimSubmittedDate"] = System.DateTime.Parse((dr["ClaimSubmittedDate"].ToString() == "") ? "1/1/1900" : dr["ClaimSubmittedDate"].ToString());
                    nr["ConvPartASubmittedDate"] = System.DateTime.Parse((dr["ConvPartASubmittedDate"].ToString() == "") ? "1/1/1900" : dr["ConvPartASubmittedDate"].ToString());
                    nr["ClientSystemUpdatedDate"] = System.DateTime.Parse((dr["ClientSystemUpdatedDate"].ToString() == "") ? "1/1/1900" : dr["ClientSystemUpdatedDate"].ToString());
                    nr["ConvPartAClientSystemUpdatedDate"] = System.DateTime.Parse((dr["ConvPartAClientSystemUpdatedDate"].ToString() == "") ? "1/1/1900" : dr["ConvPartAClientSystemUpdatedDate"].ToString());
                    nr["ClientSystemUpdatedUser"] = System.Int32.Parse((dr["ClientSystemUpdatedUser"].ToString() == "") ? "0" : dr["ClientSystemUpdatedUser"].ToString());
                    nr["ConvPartAClientSystemUpdatedUser"] = System.Int32.Parse((dr["ConvPartAClientSystemUpdatedUser"].ToString() == "") ? "0" : dr["ConvPartAClientSystemUpdatedUser"].ToString());
                    nr["EDIAuthorizedDate"] = System.DateTime.Parse((dr["EDIAuthorizedDate"].ToString() == "") ? "1/1/1900" : dr["EDIAuthorizedDate"].ToString());
                    nr["ConvEDIAuthorizedDate"] = System.DateTime.Parse((dr["ConvEDIAuthorizedDate"].ToString() == "") ? "1/1/1900" : dr["ConvEDIAuthorizedDate"].ToString());
                    nr["EDIAuthorizedUserID"] = System.Int32.Parse((dr["EDIAuthorizedUserID"].ToString() == "") ? "0" : dr["EDIAuthorizedUserID"].ToString());
                    nr["ConvEDIAuthorizedUserID"] = System.Int32.Parse((dr["ConvEDIAuthorizedUserID"].ToString() == "") ? "0" : dr["ConvEDIAuthorizedUserID"].ToString());
                    nr["ErrorSubmitDate"] = System.DateTime.Parse((dr["ErrorSubmitDate"].ToString() == "") ? "1/1/1900" : dr["ErrorSubmitDate"].ToString());
                    nr["ConvPartAErrorSubmitDate"] = System.DateTime.Parse((dr["ConvPartAErrorSubmitDate"].ToString() == "") ? "1/1/1900" : dr["ConvPartAErrorSubmitDate"].ToString());
                    nr["IsEDIAuthorized"] = System.Boolean.Parse((dr["IsEDIAuthorized"].ToString() == "") ? "false" : dr["IsEDIAuthorized"].ToString());
                    nr["ConvPartAIsEDIAuthorized"] = System.Boolean.Parse((dr["ConvPartAIsEDIAuthorized"].ToString() == "") ? "false" : dr["ConvPartAIsEDIAuthorized"].ToString());
                    nr["PartAAnalyst"] = System.Int32.Parse((dr["PartAAnalyst"].ToString() == "") ? "0" : dr["PartAAnalyst"].ToString());
                    nr["PartACompleteDate"] = System.DateTime.Parse((dr["PartACompleteDate"].ToString() == "") ? "1/1/1900" : dr["PartACompleteDate"].ToString());
                    nr["PartBAnalyst"] = System.Int32.Parse((dr["PartBAnalyst"].ToString() == "") ? "0" : dr["PartBAnalyst"].ToString());
                    nr["PartBCompleteDate"] = System.DateTime.Parse((dr["PartBCompleteDate"].ToString() == "") ? "1/1/1900" : dr["PartBCompleteDate"].ToString());
                    nr["PartAQCAnalyst"] = System.Int32.Parse((dr["PartAQCAnalyst"].ToString() == "") ? "0" : dr["PartAQCAnalyst"].ToString());
                    nr["PartAQCCompleteDate"] = System.DateTime.Parse((dr["PartAQCCompleteDate"].ToString() == "") ? "1/1/1900" : dr["PartAQCCompleteDate"].ToString());
                    nr["PartBQCAnalyst"] = System.Int32.Parse((dr["PartBQCAnalyst"].ToString() == "") ? "0" : dr["PartBQCAnalyst"].ToString());
                    nr["PartBQCCompleteDate"] = System.DateTime.Parse((dr["PartBQCCompleteDate"].ToString() == "") ? "1/1/1900" : dr["PartBQCCompleteDate"].ToString());
                    nr["PrepAnalyst"] = System.Int32.Parse((dr["PrepAnalyst"].ToString() == "") ? "0" : dr["PrepAnalyst"].ToString());
                    nr["PrepCompleteDate"] = System.DateTime.Parse((dr["PrepCompleteDate"].ToString() == "") ? "1/1/1900" : dr["PrepCompleteDate"].ToString());
                    nr["ConvPartAPrepAnalyst"] = System.Int32.Parse((dr["ConvPartAPrepAnalyst"].ToString() == "") ? "0" : dr["ConvPartAPrepAnalyst"].ToString());
                    nr["ConvPartAPrepCompleteDate"] = System.DateTime.Parse((dr["ConvPartAPrepCompleteDate"].ToString() == "") ? "1/1/1900" : dr["ConvPartAPrepCompleteDate"].ToString());
                    nr["PrepReferralAnalyst"] = System.Int32.Parse((dr["PrepReferralAnalyst"].ToString() == "") ? "0" : dr["PrepReferralAnalyst"].ToString());
                    nr["PrepReferralCompleteDate"] = System.DateTime.Parse((dr["PrepReferralCompleteDate"].ToString() == "") ? "1/1/1900" : dr["PrepReferralCompleteDate"].ToString());
                    nr["ConvPartBOnly"] = System.Boolean.Parse((dr["ConvPartBOnly"].ToString() == "") ? "false" : dr["ConvPartBOnly"].ToString());
                    nr["SupplementalClaimTypeID"] = System.Int32.Parse((dr["SupplementalClaimTypeID"].ToString() == "") ? "0" : dr["SupplementalClaimTypeID"].ToString());
                    nr["ClaimSubTypeID"] = System.Int32.Parse((dr["ClaimSubTypeID"].ToString() == "") ? "0" : dr["ClaimSubTypeID"].ToString());
                    nr["IsSuppReview"] = System.Boolean.Parse((dr["IsSuppReview"].ToString() == "") ? "false" : dr["IsSuppReview"].ToString());
                    nr["SuppReviewSetDate"] = System.DateTime.Parse((dr["SuppReviewSetDate"].ToString() == "") ? "1/1/1900" : dr["SuppReviewSetDate"].ToString());
                    nr["SuppReviewSetUserID"] = System.Int32.Parse((dr["SuppReviewSetUserID"].ToString() == "") ? "0" : dr["SuppReviewSetUserID"].ToString());
                    nr["deltaCheck"] = dr["deltaCheck"].ToString();
                    nr["ClearTitleDate"] = System.DateTime.Parse((dr["ClearTitleDate"].ToString() == "") ? "1/1/1900" : dr["ClearTitleDate"].ToString());
                    nr["MarketableTitleDate"] = System.DateTime.Parse((dr["MarketableTitleDate"].ToString() == "") ? "1/1/1900" : dr["MarketableTitleDate"].ToString());

                    dt.Rows.Add(nr);

                }

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }

        }

        internal DataTable GetInvestorTracking_FHAFollowUp(int claimID, Settings settings)
        {
            SqlConnection con = new SqlConnection();
            DataTable dt=new DataTable("FHAFollowUps");
            dt.Columns.Add("FHAClaim_FollowupID", typeof(int));
            dt.Columns.Add("FHAClaimID", typeof(int));
            dt.Columns.Add("FHAFollowupTypeID", typeof(int));
            dt.Columns.Add("FHAFollowupTypeName", typeof(string));
            dt.Columns.Add("EnteredByUser", typeof(int));
            dt.Columns.Add("EnteredByUserName", typeof(string));
            dt.Columns.Add("EnteredDate", typeof(DateTime));
            dt.Columns.Add("LastUpdateUser", typeof(int));
            dt.Columns.Add("LastUpdatedByUserName", typeof(string));
            dt.Columns.Add("LastUpdateDate", typeof(DateTime));
            dt.Columns.Add("FollowupDate", typeof(DateTime));
            dt.Columns.Add("FollowupComplete", typeof(bool));
            dt.Columns.Add("CompleteDate", typeof(DateTime));
            dt.Columns.Add("CompletedByUser", typeof(int));
            dt.Columns.Add("CompletedByUserName", typeof(string));
            dt.Columns.Add("MarkedForDelete", typeof(bool));
            dt.Columns.Add("CommentText", typeof(string));
            dt.Columns.Add("deltaCheck", typeof(string));

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_InvTrk_FHAClaim_Followup_Select";

                SqlParameter parm = new SqlParameter("@FHAClaimID", claimID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                //dt.Load(dr);
                while (dr.Read())
                {
                    DataRow nr = dt.NewRow();
                    nr["FHAClaim_FollowupID"] = dr["FHAClaim_FollowupID"];
                    nr["FHAClaimID"] = dr["FHAClaimID"];
                    nr["FHAFollowupTypeID"] = dr["FHAFollowupTypeID"];
                    nr["FHAFollowupTypeName"] = dr["FHAFollowupTypeName"];
                    nr["EnteredByUser"] = dr["EnteredByUser"];
                    nr["EnteredByUserName"] = dr["EnteredByUserName"];
                    nr["EnteredDate"] = dr["EnteredDate"];
                    nr["LastUpdateUser"] = dr["LastUpdateUser"];
                    nr["LastUpdatedByUserName"] = dr["LastUpdatedByUserName"];
                    nr["LastUpdateDate"] = dr["LastUpdateDate"];
                    nr["CommentText"] = dr["CommentText"];
                    nr["FollowupDate"] = dr["FollowupDate"];
                    nr["FollowupComplete"] = dr["FollowupComplete"];
                    nr["CompleteDate"] = dr["CompleteDate"];
                    nr["CompletedByUser"] = dr["CompletedByUser"];
                    nr["CompletedByUserName"] = dr["CompletedByUserName"];
                    nr["MarkedForDelete"] = dr["MarkedForDelete"];
                    nr["deltaCheck"] = dr["deltaCheck"];
                    dt.Rows.Add(nr);
                }

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="claimID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetInvestorTracking_FHACombined_Errors(DataTable dt, int claimID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_InvTrk_FHASuspenseCodesSelectFromHUDClaims_ByClaimID";

                SqlParameter parm = new SqlParameter("@ClaimID", claimID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                dt.Load(dr);

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="claimID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetInvestorTracking_FHACombined_SubmitHistory(DataTable idt, int claimID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable("SubmitHistory");

                dt.Columns.Add("EnteredDate", typeof(DateTime));
                dt.Columns.Add("EDISubmittedDate", typeof(DateTime));
                dt.Columns.Add("SubmitType", typeof(string));
                dt.Columns.Add("AssembledCommentText", typeof(string));
                dt.Columns.Add("SubmitPart", typeof(string));

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_InvTrk_FHASubmitHistorySelect_ByClaimID";

                SqlParameter parm = new SqlParameter("@ClaimID", claimID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();
                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString()).ToLocalTime();
                    row["EDISubmittedDate"] = DateTime.Parse(dr["EDISubmittedDate"].ToString()).ToLocalTime();
                    row["SubmitType"] = dr["SubmitType"];
                    row["AssembledCommentText"] = dr["AssembledCommentText"];
                    row["SubmitPart"] = dr["SubmitPart"];
                    dt.Rows.Add(row);
                }

                //dt.Load(dr);

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool SaveInvestorTrackingFHACombinedClaim(DataTable dt, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                int recordsAffected;

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                    SqlParameter prm = new SqlParameter();

                    switch (dt.Rows[i].RowState)
                    {
                        case DataRowState.Added :
                            // this won't quite work
                            //cmd.CommandText = "usp_InvTrk_Import_FHA_ClaimCombined_Insert";
                            break;
                        case DataRowState.Deleted:
                            break;
                        case DataRowState.Detached:
                            break;
                        case DataRowState.Modified:
                            cmd.CommandText = "usp_InvTrk_FHAClaim_Update";
                            break;
                        case DataRowState.Unchanged:
                            goto NextRecord;
                        //break;
                        default:
                            break;
                    }

                    cmd.Connection = con;
                    cmd.Parameters.Add(new SqlParameter("@FHAClaimID", dt.Rows[i]["FHAClaimID"]));
                    cmd.Parameters.Add(new SqlParameter("@ClaimID", dt.Rows[i]["ClaimID"]));
                    cmd.Parameters.Add(new SqlParameter("@EnteredDate", dt.Rows[i]["EnteredDate"]));
                    cmd.Parameters.Add(new SqlParameter("@EnteredByUser", dt.Rows[i]["EnteredByUser"]));
                    cmd.Parameters.Add(new SqlParameter("@LastUpdateDate", dt.Rows[i]["LastUpdateDate"]));
                    cmd.Parameters.Add(new SqlParameter("@LastUpdateUser", dt.Rows[i]["LastUpdateUser"]));
                    cmd.Parameters.Add(new SqlParameter("@ClaimAmount", dt.Rows[i]["ClaimAmount"]));
                    cmd.Parameters.Add(new SqlParameter("@ConvPartAClaimAmount", dt.Rows[i]["ConvPartAClaimAmount"]));
                    cmd.Parameters.Add(new SqlParameter("@ConveyanceExtensionExpirationDate", dt.Rows[i]["ConveyanceExtensionExpirationDate"]));
                    cmd.Parameters.Add(new SqlParameter("@CurtailmentCodeID", dt.Rows[i]["CurtailmentCodeID"]));
                    cmd.Parameters.Add(new SqlParameter("@CurtailmentDate", dt.Rows[i]["CurtailmentDate"]));
                    cmd.Parameters.Add(new SqlParameter("@FHAModificationDate", dt.Rows[i]["FHAModificationDate"]));
                    cmd.Parameters.Add(new SqlParameter("@ExpectedPartBProceeds", dt.Rows[i]["ExpectedPartBProceeds"]));
                    //cmd.Parameters.Add(new SqlParameter("@FCDeedRecordedDate", dt.Rows[i]["FCDeedRecordedDate"]));
                    cmd.Parameters.Add(new SqlParameter("@FCLFirstLegalDate", dt.Rows[i]["FCLFirstLegalDate"]));
                    cmd.Parameters.Add(new SqlParameter("@FTVDate", dt.Rows[i]["FTVDate"]));
                    cmd.Parameters.Add(new SqlParameter("@HUDDeedRecordedDate", dt.Rows[i]["HUDDeedRecordedDate"]));
                    cmd.Parameters.Add(new SqlParameter("@HUDIDDate", dt.Rows[i]["HUDIDDate"]));
                    cmd.Parameters.Add(new SqlParameter("@ICCDate", dt.Rows[i]["ICCDate"]));
                    cmd.Parameters.Add(new SqlParameter("@ICCReportDate", dt.Rows[i]["ICCReportDate"]));
                    cmd.Parameters.Add(new SqlParameter("@IneligibilityDate", dt.Rows[i]["IneligibilityDate"]));
                    cmd.Parameters.Add(new SqlParameter("@IneligibilityReasonID", dt.Rows[i]["IneligibilityReasonID"]));
                    cmd.Parameters.Add(new SqlParameter("@IsHAMP", dt.Rows[i]["IsHAMP"]));
                    cmd.Parameters.Add(new SqlParameter("@IsInvestorClaimDue", dt.Rows[i]["IsInvestorClaimDue"]));
                    cmd.Parameters.Add(new SqlParameter("@IsMobileHomeTrailer", dt.Rows[i]["IsMobileHomeTrailer"]));
                    cmd.Parameters.Add(new SqlParameter("@MHTEndDate", dt.Rows[i]["MHTEndDate"]));
                    cmd.Parameters.Add(new SqlParameter("@MHTReviewedDate", dt.Rows[i]["MHTReviewedDate"]));
                    cmd.Parameters.Add(new SqlParameter("@MHTStartDate", dt.Rows[i]["MHTStartDate"]));
                    cmd.Parameters.Add(new SqlParameter("@PaidAmount", dt.Rows[i]["PaidAmount"]));
                    cmd.Parameters.Add(new SqlParameter("@ConvPartAPaidAmount", dt.Rows[i]["ConvPartAPaidAmount"]));
                    cmd.Parameters.Add(new SqlParameter("@RecorderLetterReceiveDate", dt.Rows[i]["RecorderLetterReceiveDate"]));
                    cmd.Parameters.Add(new SqlParameter("@RecordingInstructionsSentDate", dt.Rows[i]["RecordingInstructionsSentDate"]));
                    cmd.Parameters.Add(new SqlParameter("@RecorderLetterVerified", dt.Rows[i]["RecorderLetterVerified"]));
                    cmd.Parameters.Add(new SqlParameter("@RecorderLetterVerifiedUser", dt.Rows[i]["RecorderLetterVerifiedUser"]));
                    cmd.Parameters.Add(new SqlParameter("@FTVDateReported", dt.Rows[i]["FTVDateReported"]));
                    cmd.Parameters.Add(new SqlParameter("@ReviewedForInvestorClaim", dt.Rows[i]["ReviewedForInvestorClaim"]));
                    cmd.Parameters.Add(new SqlParameter("@ServiceTransferDate", dt.Rows[i]["ServiceTransferDate"]));
                    cmd.Parameters.Add(new SqlParameter("@SettlementDate", dt.Rows[i]["SettlementDate"]));
                    cmd.Parameters.Add(new SqlParameter("@ConvPartASettlementDate", dt.Rows[i]["ConvPartASettlementDate"]));
                    cmd.Parameters.Add(new SqlParameter("@SuppRecoveryDue", dt.Rows[i]["SuppRecoveryDue"]));
                    cmd.Parameters.Add(new SqlParameter("@SuppRefundDueHUD", dt.Rows[i]["SuppRefundDueHUD"]));
                    cmd.Parameters.Add(new SqlParameter("@SuspendDate", dt.Rows[i]["SuspendDate"]));
                    cmd.Parameters.Add(new SqlParameter("@ConvPartASuspendDate", dt.Rows[i]["ConvPartASuspendDate"]));
                    cmd.Parameters.Add(new SqlParameter("@TALDate", dt.Rows[i]["TALDate"]));
                    cmd.Parameters.Add(new SqlParameter("@TitleExtensionDate", dt.Rows[i]["TitleExtensionDate"]));
                    cmd.Parameters.Add(new SqlParameter("@TitleSubmitAnalystID", dt.Rows[i]["TitleSubmitAnalystID"]));
                    cmd.Parameters.Add(new SqlParameter("@TitleSubmitDate", dt.Rows[i]["TitleSubmitDate"]));
                    cmd.Parameters.Add(new SqlParameter("@UnpaidBalance", dt.Rows[i]["UnpaidBalance"]));
                    cmd.Parameters.Add(new SqlParameter("@ClaimSubmittedAnalystID", dt.Rows[i]["ClaimSubmittedAnalystID"]));
                    cmd.Parameters.Add(new SqlParameter("@ConvPartASubmittedAnalystID", dt.Rows[i]["ConvPartASubmittedAnalystID"]));
                    cmd.Parameters.Add(new SqlParameter("@ClaimSubmittedDate", dt.Rows[i]["ClaimSubmittedDate"]));
                    cmd.Parameters.Add(new SqlParameter("@ConvPartASubmittedDate", dt.Rows[i]["ConvPartASubmittedDate"]));
                    cmd.Parameters.Add(new SqlParameter("@ClientSystemUpdatedDate", dt.Rows[i]["ClientSystemUpdatedDate"]));
                    cmd.Parameters.Add(new SqlParameter("@ConvPartAClientSystemUpdatedDate", dt.Rows[i]["ConvPartAClientSystemUpdatedDate"]));
                    cmd.Parameters.Add(new SqlParameter("@ClientSystemUpdatedUser", dt.Rows[i]["ClientSystemUpdatedUser"]));
                    cmd.Parameters.Add(new SqlParameter("@ConvPartAClientSystemUpdatedUser", dt.Rows[i]["ConvPartAClientSystemUpdatedUser"]));
                    cmd.Parameters.Add(new SqlParameter("@EDIAuthorizedDate", dt.Rows[i]["EDIAuthorizedDate"]));
                    cmd.Parameters.Add(new SqlParameter("@ConvEDIAuthorizedDate", dt.Rows[i]["ConvEDIAuthorizedDate"]));
                    cmd.Parameters.Add(new SqlParameter("@EDIAuthorizedUserID", dt.Rows[i]["EDIAuthorizedUserID"]));
                    cmd.Parameters.Add(new SqlParameter("@ConvEDIAuthorizedUserID", dt.Rows[i]["ConvEDIAuthorizedUserID"]));
                    cmd.Parameters.Add(new SqlParameter("@ErrorSubmitDate", dt.Rows[i]["ErrorSubmitDate"]));
                    cmd.Parameters.Add(new SqlParameter("@ConvPartAErrorSubmitDate", dt.Rows[i]["ConvPartAErrorSubmitDate"]));
                    cmd.Parameters.Add(new SqlParameter("@IsEDIAuthorized", dt.Rows[i]["IsEDIAuthorized"]));
                    cmd.Parameters.Add(new SqlParameter("@ConvPartAIsEDIAuthorized", dt.Rows[i]["ConvPartAIsEDIAuthorized"]));
                    cmd.Parameters.Add(new SqlParameter("@PartAAnalyst", dt.Rows[i]["PartAAnalyst"]));
                    cmd.Parameters.Add(new SqlParameter("@PartACompleteDate", dt.Rows[i]["PartACompleteDate"]));
                    cmd.Parameters.Add(new SqlParameter("@PartBAnalyst", dt.Rows[i]["PartBAnalyst"]));
                    cmd.Parameters.Add(new SqlParameter("@PartBCompleteDate", dt.Rows[i]["PartBCompleteDate"]));
                    cmd.Parameters.Add(new SqlParameter("@PartAQCAnalyst", dt.Rows[i]["PartAQCAnalyst"]));
                    cmd.Parameters.Add(new SqlParameter("@PartAQCCompleteDate", dt.Rows[i]["PartAQCCompleteDate"]));
                    cmd.Parameters.Add(new SqlParameter("@PartBQCAnalyst", dt.Rows[i]["PartBQCAnalyst"]));
                    cmd.Parameters.Add(new SqlParameter("@PartBQCCompleteDate", dt.Rows[i]["PartBQCCompleteDate"]));
                    cmd.Parameters.Add(new SqlParameter("@PrepAnalyst", dt.Rows[i]["PrepAnalyst"]));
                    cmd.Parameters.Add(new SqlParameter("@PrepCompleteDate", dt.Rows[i]["PrepCompleteDate"]));
                    cmd.Parameters.Add(new SqlParameter("@ConvPartAPrepAnalyst", dt.Rows[i]["ConvPartAPrepAnalyst"]));
                    cmd.Parameters.Add(new SqlParameter("@ConvPartAPrepCompleteDate", dt.Rows[i]["ConvPartAPrepCompleteDate"]));
                    cmd.Parameters.Add(new SqlParameter("@PrepReferralAnalyst", dt.Rows[i]["PrepReferralAnalyst"]));
                    cmd.Parameters.Add(new SqlParameter("@PrepReferralCompleteDate", dt.Rows[i]["PrepReferralCompleteDate"]));
                    cmd.Parameters.Add(new SqlParameter("@ConvPartBOnly", dt.Rows[i]["ConvPartBOnly"]));
                    cmd.Parameters.Add(new SqlParameter("@SupplementalClaimTypeID", dt.Rows[i]["SupplementalClaimTypeID"]));
                    cmd.Parameters.Add(new SqlParameter("@SuppParentFHAClaimID", dt.Rows[i]["SuppParentFHAClaimID"]));
                    cmd.Parameters.Add(new SqlParameter("@FCLDeedRecordedDate", dt.Rows[i]["FCLDeedRecordedDate"]));
                    // 20151001 gk 22705 add claimsubtypeid
                    cmd.Parameters.Add(new SqlParameter("@ClaimSubTypeID", dt.Rows[i]["ClaimSubTypeID"]));

                    //20160321 TRS FB 29162.  Added 3 columns for supp review accumulator attributes
                    cmd.Parameters.Add(new SqlParameter("@IsSuppReview", dt.Rows[i]["IsSuppReview"]));
                    cmd.Parameters.Add(new SqlParameter("@SuppReviewSetDate", dt.Rows[i]["SuppReviewSetDate"]));
                    cmd.Parameters.Add(new SqlParameter("@SuppReviewSetUserID", dt.Rows[i]["SuppReviewSetUserID"]));
                    cmd.Parameters.Add(new SqlParameter("@ClearTitleDate", dt.Rows[i]["ClearTitleDate"]));

                    //20160321 TRS FB 29162 relocated this here to get it back in order.
                    cmd.Parameters.Add(new SqlParameter("@deltaCheck", dt.Rows[i]["deltaCheck"]));


                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;

                }

                dt.AcceptChanges();

                return true;

            }

            catch (Exception ex)
            {
                //dump the table into an error file so we have some record of where we were
                try
                {
                    CRFS.Data.ErrorDataDump.DumpTableToDefaultLocation(dt, "");

                }

                catch { }
                throw ex;

            }

            finally
            {

                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        internal DataTable getEDISubmitComment( int claimID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable();
                con.ConnectionString = settings.GetConnectionString("HUDClaims");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_FHAClaimSubmitLog_SelectByInvTrkClaimid";

                SqlParameter parm = new SqlParameter("@InvTrak_claimid", claimID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                dt.Load(dr);

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }

        }

        /*
        internal DataTable getEDISubmitComment(DataTable dt, Settings settings)
        {
            SqlConnection con = new SqlConnection();
            try
            {

                con.ConnectionString = settings.GetConnectionString("HUDClaims");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                int claimid = (int)dt.Rows[0]["claimid"];
                cmd.Parameters.Add(new SqlParameter("@InvTrak_claimid", claimid));
                cmd.CommandText = "usp_FHAClaimSubmitLog_SelectByInvTrkClaimid";
                SqlDataReader dr = cmd.ExecuteReader();
                DataTable ret = new DataTable();
                ret.Columns.Add("deltaCheck", typeof(string));
                while (dr.Read())
                {
                    DataRow nr = ret.NewRow();
                    nr["deltaCheck"] = dr["deltaCehck"];
                    ret.Rows.Add(nr);
                }
                //ret.Load(dr);
                return ret;
            }
            finally
            {

                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }


        }
        */
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool SaveEDISubmitComment(DataTable dt, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                // get the last version of the record
                DataTable oldRecord= getEDISubmitComment((int)dt.Rows[0]["claimid"], settings);

                con.ConnectionString = settings.GetConnectionString("HUDClaims");
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.Connection = con;
                cmd.Parameters.Add(new SqlParameter("@FHAClaimSubmitLogID", oldRecord.Rows[0]["FHAClaimSubmitLogID"]));
                cmd.Parameters.Add(new SqlParameter("@User", dt.Rows[0]["UserID"]));
                //cmd.Parameters.Add(new SqlParameter("@InvTrak_claimid", dt.Rows[0]["claimid"]));
                cmd.Parameters.Add(new SqlParameter("@TrackingNumber", dt.Rows[0]["TrackingNumber"]));
                cmd.Parameters.Add(new SqlParameter("@ShippingVendor", dt.Rows[0]["shipper"]));
                cmd.Parameters.Add(new SqlParameter("@SubmitType", dt.Rows[0]["commenttype"]));
                string cmt = dt.Rows[0]["comment"].ToString();
                if (cmt.Length > 60)
                {
                   cmd.Parameters.Add(new SqlParameter("@Comment1", cmt.Substring(0,60)));
                   cmd.Parameters.Add(new SqlParameter("@Comment2", cmt.Substring(60)));
                } 
                else 
                {
                   cmd.Parameters.Add(new SqlParameter("@Comment1", cmt));
                   cmd.Parameters.Add(new SqlParameter("@Comment2", ""));
                }
                string assembledcomment = "";
                if (dt.Rows[0]["comment"].ToString() != "") assembledcomment = assembledcomment + "Comment: " + dt.Rows[0]["comment"];
                if (dt.Rows[0]["shipper"].ToString() != "") assembledcomment = assembledcomment + " Shipper: " + dt.Rows[0]["shipper"]+";";
                if (dt.Rows[0]["TrackingNumber"].ToString() != "") assembledcomment = assembledcomment + " TrackingNumber: " + dt.Rows[0]["TrackingNumber"]+";";
                cmd.Parameters.Add(new SqlParameter("@AssembledCommentText", assembledcomment));
                cmd.Parameters.Add(new SqlParameter("@deltaCheck", oldRecord.Rows[0]["deltaCheck"]));
                cmd.CommandText = "usp_FHAClaimSubmitLog_update";
                cmd.ExecuteNonQuery();

                return true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {

                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool SaveInvestorTrackingFHAFollowUp(DataTable dt, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                int recordsAffected;

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                    SqlParameter prm = new SqlParameter();

                    switch (dt.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            cmd.CommandText = "usp_InvTrk_FHAClaim_Followup_Insert";
                            break;
                        case DataRowState.Deleted:
                            break;
                        case DataRowState.Detached:
                            break;
                        case DataRowState.Modified:
                            cmd.CommandText = "usp_InvTrk_FHAClaim_Followup_Update";
                            break;
                        case DataRowState.Unchanged:
                            goto NextRecord;
                        //break;
                        default:
                            break;
                    }

                    cmd.Connection = con;
                    cmd.Parameters.Add(new SqlParameter("@FHAClaim_FollowupID", dt.Rows[i]["FHAClaim_FollowupID"]));
                    cmd.Parameters.Add(new SqlParameter("@FHAClaimID", dt.Rows[i]["FHAClaimID"]));
                    cmd.Parameters.Add(new SqlParameter("@FHAFollowupTypeID", dt.Rows[i]["FHAFollowupTypeID"]));
                    cmd.Parameters.Add(new SqlParameter("@EnteredByUser", dt.Rows[i]["EnteredByUser"]));
                    cmd.Parameters.Add(new SqlParameter("@EnteredDate", dt.Rows[i]["EnteredDate"]));
                    cmd.Parameters.Add(new SqlParameter("@LastUpdateUser", dt.Rows[i]["LastUpdateUser"]));
                    //cmd.Parameters.Add(new SqlParameter("@LastUpdateDate", dt.Rows[i]["LastUpdateDate"]));
                    cmd.Parameters.Add(new SqlParameter("@LastUpdateDate", DateTime.UtcNow));
                    cmd.Parameters.Add(new SqlParameter("@CommentText", dt.Rows[i]["CommentText"]));
                    cmd.Parameters.Add(new SqlParameter("@FollowupDate", dt.Rows[i]["FollowupDate"]));
                    cmd.Parameters.Add(new SqlParameter("@FollowupComplete", dt.Rows[i]["FollowupComplete"]));
                    cmd.Parameters.Add(new SqlParameter("@CompleteDate", dt.Rows[i]["CompleteDate"]));
                    cmd.Parameters.Add(new SqlParameter("@CompletedByUser", dt.Rows[i]["CompletedByUser"]));
                    cmd.Parameters.Add(new SqlParameter("@MarkedForDelete", dt.Rows[i]["MarkedForDelete"]));
                    cmd.Parameters.Add(new SqlParameter("@deltaCheck", dt.Rows[i]["deltaCheck"]));
                    
                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;

                }

                dt.AcceptChanges();

                return true;

            }

            catch (Exception ex)
            {
                //dump the table into an error file so we have some record of where we were
                try
                {
                    CRFS.Data.ErrorDataDump.DumpTableToDefaultLocation(dt, "");

                }

                catch { }
                throw ex;

            }

            finally
            {

                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }


        }

        #endregion
    }
}
