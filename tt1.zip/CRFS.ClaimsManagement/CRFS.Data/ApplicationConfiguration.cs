﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace CRFS.Data
{
    public class ApplicationConfiguration
    {
        //Code in this area should be common to several processes
        CRFS.Data.Settings _settings;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        internal ApplicationConfiguration(CRFS.Data.Settings settings)
        {
            _settings = settings;

        }

        #region "Common"

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClaimGroupText"></param>
        /// <param name="formID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetTabControls(string ClaimGroupText, int formID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ApplicationConfiguration");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.CommandText = "usp_CNTL_TabControl_Select";

                SqlParameter parm = new SqlParameter("@ClaimGroupText", ClaimGroupText);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@formID", formID);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;

                DataTable dt = new DataTable("TabControls");
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dt.Columns.Add("TabControlID", typeof(int));
                    dt.Columns.Add("FormID", typeof(int));
                    dt.Columns.Add("ClaimGroupText", typeof(string));
                    dt.Columns.Add("TabControlName", typeof(string));
                    dt.Columns.Add("AllowedToUse", typeof(bool));

                    while (dr.Read())
                    {
                        DataRow row = dt.NewRow();

                        row["TabControlID"] = (int)dr["TabControlID"];
                        row["FormID"] = (int)dr["FormID"];
                        row["ClaimGroupText"] = dr["ClaimGroupText"].ToString();
                        row["TabControlName"] = dr["TabControlName"].ToString();
                        row["AllowedToUse"] = bool.Parse(dr["AllowedToUse"].ToString().Length == 0 ? "false" : dr["AllowedToUse"].ToString());

                        dt.Rows.Add(row);

                    }

                }

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        #endregion

        #region "Claims 332"
        //Code in this area should be specific to Claims 332


        #endregion

        #region "Investor Tracking"
        //Code in this area should be specific to Investor Tracking

        internal DataTable build_FollowupIntervals_table()
        {
            try
            {
                DataTable dt = new DataTable("FollowUpIntervals");

                dt.Columns.Add("ClaimType", typeof(string));
                dt.Columns.Add("FollowupDaysAfterSubmit", typeof(int));
                dt.Columns.Add("SubsequentFollowupDays", typeof(int));

                return dt;
            }

            catch(Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        internal DataTable Get_InvestorTracking_PFUEOB_Complete_Matrix()
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("ApplicationConfiguration");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.CommandText = "usp_CNTL_PFUEOBCompleteMatrix_Select";

                cmd.Connection = con;

                DataTable dt = new DataTable("PFUEOB_CompleteMatrix");
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dt.Columns.Add("PFUEOB_CompleteMatrixID", typeof(int));
                    dt.Columns.Add("bitvalue", typeof(int));
                    dt.Columns.Add("ClaimPaidAmountSet", typeof(bool));
                    dt.Columns.Add("ClaimPaidDateSet", typeof(bool));
                    dt.Columns.Add("DeniedDateSet", typeof(bool));
                    dt.Columns.Add("RecissionDateSet", typeof(bool));
                    dt.Columns.Add("CancellationDateSet", typeof(bool));
                    dt.Columns.Add("Allow_PFUEOB_Complete", typeof(bool));

                    while (dr.Read())
                    {
                        DataRow row = dt.NewRow();

                        row["PFUEOB_CompleteMatrixID"] = dr["PFUEOB_CompleteMatrixID"];
                        row["bitvalue"] = dr["bitvalue"];
                        row["ClaimPaidAmountSet"] = dr["ClaimPaidAmountSet"];
                        row["ClaimPaidDateSet"] = dr["ClaimPaidDateSet"];
                        row["DeniedDateSet"] = dr["DeniedDateSet"];
                        row["RecissionDateSet"] = dr["RecissionDateSet"];
                        row["CancellationDateSet"] = dr["CancellationDateSet"];
                        row["Allow_PFUEOB_Complete"] = dr["Allow_PFUEOB_Complete"];

                        dt.Rows.Add(row);

                    }

                }

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="InvestorName"></param>
        /// <param name="ClaimType"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetInvestorTrackingPaymentFollowupIntervals(string InvestorName, string ClaimType, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ApplicationConfiguration");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.CommandText = "usp_InvTrk_FollowupIntervals_Get";
                SqlParameter parm = new SqlParameter("@InvestorName", InvestorName);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@ClaimType", ClaimType);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;

                DataTable dt = build_FollowupIntervals_table();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        DataRow row = dt.NewRow();

                        row["ClaimType"] = dr["ClaimType"].ToString();
                        row["FollowupDaysAfterSubmit"] = int.Parse(dr["FollowupDaysAfterSubmit"].ToString().Length == 0 ? "0" : dr["FollowupDaysAfterSubmit"].ToString());
                        row["SubsequentFollowupDays"] = int.Parse(dr["SubsequentFollowupDays"].ToString().Length == 0 ? "0" : dr["SubsequentFollowupDays"].ToString());

                        dt.Rows.Add(row);

                    }

                }

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="MICompanyName"></param>
        /// <param name="ClaimType"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetInvestorTrackingMIPaymentFollowupIntervals(string MICompanyName, string ClaimType, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ApplicationConfiguration");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.CommandText = "usp_InvTrk_MIFollowupIntervals_Get";
                SqlParameter parm = new SqlParameter("@MICompanyName", MICompanyName);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@ClaimType", ClaimType);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;

                DataTable dt = build_FollowupIntervals_table();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        DataRow row = dt.NewRow();

                        row["ClaimType"] = dr["ClaimType"].ToString();
                        row["FollowupDaysAfterSubmit"] = int.Parse(dr["FollowupDaysAfterSubmit"].ToString().Length == 0 ? "0" : dr["FollowupDaysAfterSubmit"].ToString());
                        row["SubsequentFollowupDays"] = int.Parse(dr["SubsequentFollowupDays"].ToString().Length == 0 ? "0" : dr["SubsequentFollowupDays"].ToString());

                        dt.Rows.Add(row);

                    }

                }

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClaimType"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetInvestorTrackingUSDAPaymentFollowupIntervals(string ClaimType, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ApplicationConfiguration");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.CommandText = "usp_InvTrk_USDAFollowupIntervals_Get";
                SqlParameter parm = new SqlParameter("@ClaimType", ClaimType);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;

                DataTable dt = build_FollowupIntervals_table();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        DataRow row = dt.NewRow();

                        row["ClaimType"] = dr["ClaimType"].ToString();
                        row["FollowupDaysAfterSubmit"] = int.Parse(dr["FollowupDaysAfterSubmit"].ToString().Length == 0 ? "0" : dr["FollowupDaysAfterSubmit"].ToString());
                        row["SubsequentFollowupDays"] = int.Parse(dr["SubsequentFollowupDays"].ToString().Length == 0 ? "0" : dr["SubsequentFollowupDays"].ToString());

                        dt.Rows.Add(row);

                    }

                }

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }
            
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetClaimTypeNameXref(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ApplicationConfiguration");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.CommandText = "usp_InvTrk_ClaimTypeNameXref_Get";

                cmd.Connection = con;

                DataTable dt = new DataTable("ClaimTypeNameXRef");
                dt.Columns.Add("HUDName", typeof(string));
                dt.Columns.Add("CMSName", typeof(string));
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        DataRow row = dt.NewRow();

                        row["HUDName"] = dr["HUDName"].ToString();
                        row["CMSName"] = dr["CMSName"].ToString();

                        dt.Rows.Add(row);

                    }

                }

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Organization"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetOrganizationHolidays(string Organization, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ApplicationConfiguration");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.CommandText = "usp_CNTL_OrganizationHolidays_Get";
                SqlParameter parm = new SqlParameter("@OrganizationName", Organization);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;

                DataTable dt = new DataTable("Holidays");
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dt.Columns.Add("Organization", typeof(string));
                    dt.Columns.Add("HolidayDate", typeof(DateTime));
                    dt.Columns.Add("HolidayDescription", typeof(string));

                    while (dr.Read())
                    {
                        DataRow row = dt.NewRow();

                        row["Organization"] = dr["Organization"].ToString();
                        row["HolidayDate"] = DateTime.Parse(dr["HolidayDate"].ToString());
                        row["HolidayDescription"] = dr["HolidayDescription"].ToString();


                        dt.Rows.Add(row);

                    }

                }

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }


        }

        #endregion

        #region "Imports - Common"
        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable Get_Import_Processes(CRFS.Data.Settings settings)
        {
            SqlConnection sql = new SqlConnection();

            try
            {
                sql.ConnectionString = settings.GetConnectionString("ApplicationConfiguration");
                sql.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_Cntl_Processes_Select";

                cmd.Connection = sql;
                DataTable dt = new DataTable("ImportProcesses");
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Columns.Add("CategoryName", typeof(string));
                    dt.Columns.Add("CategoryID", typeof(int));
                    dt.Columns.Add("ProcessName", typeof(string));
                    dt.Columns.Add("ProcessID", typeof(int));
                    dt.Columns.Add("DatabaseID", typeof(int));
                    dt.Columns.Add("DatabaseName", typeof(string));
                    dt.Columns.Add("Active", typeof(bool));
                    dt.Columns.Add("RequiresIntegrationSetup", typeof(bool));

                    while (reader.Read())
                    {
                        DataRow dr = dt.NewRow();

                        dr["CategoryName"] = reader["CategoryName"];
                        dr["CategoryID"] = reader["CategoryID"];
                        dr["ProcessName"] = reader["ProcessName"];
                        dr["ProcessID"] = reader["ProcessID"];
                        dr["DatabaseID"] = reader["DatabaseID"];
                        dr["DatabaseName"] = reader["DatabaseName"];
                        dr["Active"] = reader["Active"];
                        dr["RequiresIntegrationSetup"] = reader["RequiresIntegrationSetup"];

                        dt.Rows.Add(dr);

                    }

                }

                sql.Close();
                sql.Dispose();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (sql.State != ConnectionState.Closed)
                {
                    sql.Close();
                    sql.Dispose();
                }

            }

        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable Get_EnabledSuppMenuItems(CRFS.Data.Settings settings)
        {
            SqlConnection sql = new SqlConnection();

            try
            {
                sql.ConnectionString = settings.GetConnectionString("ApplicationConfiguration");
                sql.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_EnabledSuppMenuItems";

                cmd.Connection = sql;
                DataTable dt = new DataTable("EnabledSuppMenuItems");
                dt.Columns.Add("ClaimTypeID", typeof(int));
                dt.Columns.Add("ClaimType", typeof(string));
                dt.Columns.Add("SuppMenuItemName", typeof(string));
                dt.Columns.Add("enabled", typeof(bool));
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    DataRow dr = dt.NewRow();
                    dr["ClaimTypeID"] = reader["ClaimTypeID"];
                    dr["ClaimType"] = reader["ClaimType"];
                    dr["SuppMenuItemName"] = reader["SuppMenuItemName"];
                    dr["enabled"] = reader["enabled"];
                    dt.Rows.Add(dr);
                }
                sql.Close();
                sql.Dispose();

                return dt;
            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (sql.State != ConnectionState.Closed)
                {
                    sql.Close();
                    sql.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable Get_Shippers(CRFS.Data.Settings settings)
        {
            SqlConnection sql = new SqlConnection();

            try
            {
                sql.ConnectionString = settings.GetConnectionString("ApplicationConfiguration");
                sql.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_InvTrk_ShippingVendors_Get";

                cmd.Connection = sql;
                DataTable dt = new DataTable("ImportProcesses");
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Columns.Add("ShippingVendorID", typeof(int));
                    dt.Columns.Add("ShippingVendorName", typeof(string));
                    dt.Columns.Add("EffectiveFromDate", typeof(DateTime));
                    dt.Columns.Add("EffectiveToDate", typeof(DateTime));

                    while (reader.Read())
                    {
                        DataRow dr = dt.NewRow();

                        dr["ShippingVendorID"] = reader["ShippingVendorID"];
                        dr["ShippingVendorName"] = reader["ShippingVendorName"];
                        dr["EffectiveFromDate"] = reader["EffectiveFromDate"];
                        dr["EffectiveToDate"] = reader["EffectiveToDate"];

                        dt.Rows.Add(dr);

                    }

                }

                sql.Close();
                sql.Dispose();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (sql.State != ConnectionState.Closed)
                {
                    sql.Close();
                    sql.Dispose();
                }

            }

        }

        /*31043
        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable Get_Import_Process_Client_Map(CRFS.Data.Settings settings)
        {
            SqlConnection sql = new SqlConnection();

            try
            {
                sql.ConnectionString = settings.GetConnectionString("ApplicationConfiguration");
                sql.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_CNTL_Clients_Get";

                cmd.Connection = sql;
                DataTable dt = new DataTable("ImportProcessClientMap");
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Columns.Add("ClientID", typeof(int));
                    dt.Columns.Add("ClientName", typeof(string));
                    dt.Columns.Add("ProcessID", typeof(int));

                    while (reader.Read())
                    {
                        DataRow dr = dt.NewRow();

                        //usp_CNTL_Clients_Get is a "generic" procedure that pulls all attributes for all clients.
                        //We're really interested in just three attributes here: clt_int_import, clt_int_import_id, and clt_int_import_processid
                        //We also handle the type conversions here because everything is stored as a string in the ClientMaster table.
                        if (reader["clt_int_import_id"].ToString().Length > 0)
                        {
                            dr["ClientID"] = int.Parse(reader["clt_int_import_id"].ToString());
                            dr["ClientName"] = reader["clt_int_import"].ToString();
                            dr["ProcessID"] = int.Parse(reader["clt_int_import_processid"].ToString());

                            dt.Rows.Add(dr);
                        }

                    }

                }

                sql.Close();
                sql.Dispose();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (sql.State != ConnectionState.Closed)
                {
                    sql.Close();
                    sql.Dispose();
                }

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable Get_CMax_Attributes(CRFS.Data.Settings settings)
        {
            SqlConnection sql = new SqlConnection();

            try
            {
                sql.ConnectionString = settings.GetConnectionString("ApplicationConfiguration");
                sql.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_CNTL_Clients_Get";

                cmd.Connection = sql;
                DataTable dt = new DataTable("ImportProcessClientMap");
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Columns.Add("CMSClientID", typeof(int));
                    dt.Columns.Add("ClientName", typeof(string));
                    dt.Columns.Add("CMaxClientID", typeof(int));

                    while (reader.Read())
                    {
                        DataRow dr = dt.NewRow();

                        //usp_CNTL_Clients_Get is a "generic" procedure that pulls all attributes for all clients.
                        //We're really interested in just three attributes here: clt_int_import, clt_int_import_id, and clt_int_import_processid
                        //We also handle the type conversions here because everything is stored as a string in the ClientMaster table.
                        dr["CMSClientID"] = int.Parse(reader["clt_int_cms_id"].ToString());
                        dr["ClientName"] = reader["clt_int_cmax_name"].ToString();
                        dr["CMaxClientID"] = int.Parse(reader["clt_int_cmax_id"].ToString());

                        dt.Rows.Add(dr);
                    }

                }

                sql.Close();
                sql.Dispose();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (sql.State != ConnectionState.Closed)
                {
                    sql.Close();
                    sql.Dispose();
                }

            }

        }
        */
        #endregion

        #region LocatatorService

        // fb34513 gk 20160820
        /// <summary>
        /// 
        /// </summary>
        /// <param name="claims"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetDWStorageParameters(DataTable claims, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ApplicationConfiguration");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.CommandText = "usp_DWLocatorWS_ReqParm_Standin";

                SqlParameter parm = new SqlParameter("@inp", claims);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@env", settings.Get_appmode());
                cmd.Parameters.Add(parm);

                cmd.Connection = con;

                DataTable dt = new DataTable("StorageParameters");
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dt.Columns.Add("claimid", typeof(int));
                    dt.Columns.Add("field", typeof(string));
                    dt.Columns.Add("value", typeof(string));

                    while (dr.Read())
                    {
                        DataRow row = dt.NewRow();

                        row["claimid"] = (int)dr["FHAclaimid"];
                        row["field"] = dr["attribute"].ToString();
                        row["value"] = dr["value"].ToString();

                        dt.Rows.Add(row);

                    }

                }

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="claims"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable DWLocatorGetEndpoint(DataTable dt, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ApplicationConfiguration");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.CommandText = "usp_DWLocator_EndpointRequest";

                cmd.Parameters.Add(new SqlParameter("@Environment", dt.Select("field='Environment'")[0]["value"]));
                cmd.Parameters.Add(new SqlParameter("@FHAClaimID", dt.Select("field='Environment'")[0]["claimid"]));
                cmd.Parameters.Add(new SqlParameter("@DocType", dt.Select("field='DocType'")[0]["value"]));
                cmd.Parameters.Add(new SqlParameter("@Initiator", dt.Select("field='Initiator'")[0]["value"]));
                cmd.Parameters.Add(new SqlParameter("@OriginationUser", dt.Select("field='OriginationUser'")[0]["value"]));

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {

                    while (dr.Read())
                    {
                        DataRow row = dt.NewRow();

                        row["claimid"] = Int32.Parse(dr["FHAclaimid"].ToString());
                        row["field"] = dr["attribute"].ToString();
                        row["value"] = dr["value"].ToString();

                        dt.Rows.Add(row);

                    }

                }

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }
        #endregion

        #region "FNMA Applications - DataGram and Reconciliation"
        /// <summary>
        /// 
        /// </summary>
        /// <param name="FormID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetEntityGroups(int FormID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ApplicationConfiguration");
                con.Open();

            }

            catch (Exception e)
            {
                throw e;

            }

            try
            {
                DataTable dt = new DataTable("Groups");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("GroupID", typeof(int));
                dt.Columns.Add("GroupName", typeof(string));
                dt.Columns.Add("DateEntered", typeof(DateTime));
                dt.Columns.Add("EffectiveFromDate", typeof(DateTime));
                dt.Columns.Add("EffectiveToDate", typeof(DateTime));
                dt.Columns.Add("FormID", typeof(int));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;

                cmd.CommandText = "usp_EntityGroups_Select";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter("@FormID", FormID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["GroupID"] = int.Parse(dr["GroupID"].ToString().Length == 0 ? "0" : dr["GroupID"].ToString());
                    row["GroupName"] = dr["GroupName"].ToString();
                    row["DateEntered"] = DateTime.Parse(dr["DateEntered"].ToString().Length == 0 ? "1/1/1900" : dr["DateEntered"].ToString());
                    row["EffectiveFromDate"] = DateTime.Parse(dr["EffectiveFromDate"].ToString().Length == 0 ? "1/1/1900" : dr["EffectiveFromDate"].ToString());
                    row["EffectiveToDate"] = DateTime.Parse(dr["EffectiveToDate"].ToString().Length == 0 ? "1/1/1900" : dr["EffectiveToDate"].ToString());
                    row["FormID"] = int.Parse(dr["FormID"].ToString().Length == 0 ? "0" : dr["FormID"].ToString());

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }


            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool EntityGroups_Save(DataTable data, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ApplicationConfiguration");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                cmd.Connection = con;

                for (int i = 0; i < data.Rows.Count; i++)
                {
                    switch (data.Rows[i].RowState)
                    {
                        case DataRowState.Modified:
                            cmd.CommandText = "usp_EntityGroup_Update";

                            parm = new SqlParameter("@GroupID", data.Rows[i]["GroupID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@GroupName", data.Rows[i]["GroupName"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@DateEntered", data.Rows[i]["DateEntered"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@EffectiveFromDate", data.Rows[i]["EffectiveFromDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@EffectiveToDate", data.Rows[i]["EffectiveToDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@GroupEmailAddress", data.Rows[i]["GroupEmailAddress"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FormID", data.Rows[i]["FormID"]);
                            cmd.Parameters.Add(parm);

                            break;

                        default:
                            goto NextRecord;
                    }

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;

                }

                data.AcceptChanges();
                return true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool BusinessEntityGroupsAssigned_Save(DataTable data, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ApplicationConfiguration");
                con.Open();

            }

            catch (Exception e)
            {
                throw e;

            }

            try
            {

                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                for (int i = 0; i < data.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;
                    cmd.Connection = con;

                    switch (data.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            cmd.CommandText = "usp_BusinessEntityGroup_Insert";

                            parm = new SqlParameter("@GroupID", data.Rows[i]["GroupID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@BusinessEntityID", data.Rows[i]["BusinessEntityID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@DateEntered", data.Rows[i]["DateEntered"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FormID", data.Rows[i]["FormID"]);
                            cmd.Parameters.Add(parm);

                            //Now we need to execute a stored procedure that returns the new record ID
                            data.Rows[i]["Group_BusinessEntityID"] = int.Parse(cmd.ExecuteScalar().ToString());

                            goto NextRecord;

                        case DataRowState.Deleted:
                            cmd.CommandText = "dbo.usp_BusinessEntityGroup_Delete";

                            parm = new SqlParameter("@FormID", data.Rows[i]["FormID", DataRowVersion.Original]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@Group_BusinessEntityID", data.Rows[i]["Group_BusinessEntityID", DataRowVersion.Original]);
                            cmd.Parameters.Add(parm);

                            break;

                        default:
                            goto NextRecord;

                    }

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;

                }

                data.AcceptChanges();

                return true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }
        }

        internal DataTable BusinessEntityGroupsAssigned_Get(int FormID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ApplicationConfiguration");
                con.Open();

            }

            catch (Exception e)
            {
                throw e;

            }

            try
            {
                DataTable dt = new DataTable("EntityGroups");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("Group_BusinessEntityID", typeof(int));
                dt.Columns.Add("GroupID", typeof(int));
                dt.Columns.Add("GroupName", typeof(string));
                dt.Columns.Add("BusinessEntityID", typeof(int));
                dt.Columns.Add("BusinessEntityName", typeof(string));
                dt.Columns.Add("DateEntered", typeof(DateTime));
                dt.Columns.Add("FormID", typeof(int));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;

                cmd.CommandText = "usp_BusinessEntityGroup_Select";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter("@FormID", FormID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["Group_BusinessEntityID"] = int.Parse(dr["Group_BusinessEntityID"].ToString().Length == 0 ? "0" : dr["Group_BusinessEntityID"].ToString());
                    row["GroupID"] = int.Parse(dr["GroupID"].ToString().Length == 0 ? "0" : dr["GroupID"].ToString());
                    row["GroupName"] = dr["GroupName"].ToString();
                    row["BusinessEntityID"] = int.Parse(dr["BusinessEntityID"].ToString().Length == 0 ? "0" : dr["BusinessEntityID"].ToString());
                    row["BusinessEntityName"] = dr["BusinessEntityName"].ToString();
                    row["DateEntered"] = DateTime.Parse(dr["DateEntered"].ToString().Length == 0 ? "1/1/1900" : dr["DateEntered"].ToString());
                    row["FormID"] = int.Parse(dr["FormID"].ToString().Length == 0 ? "0" : dr["FormID"].ToString());

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        internal DataTable BusinessEntityGroups_Get(int FormID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ApplicationConfiguration");
                con.Open();

            }

            catch (Exception e)
            {
                throw e;

            }

            try
            {
                DataTable dt = new DataTable("EntityGroups");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("BusinessEntityID", typeof(int));
                dt.Columns.Add("EntityTypeID", typeof(int));
                dt.Columns.Add("EntityTypeName", typeof(string));
                dt.Columns.Add("BusinessEntityName", typeof(string));
                dt.Columns.Add("IsBackend", typeof(bool));
                dt.Columns.Add("ExcludeFNMAClaimFiledUpdateRpt", typeof(bool));
                dt.Columns.Add("Group_BusinessEntityID", typeof(int));
                dt.Columns.Add("GroupID", typeof(int));
                dt.Columns.Add("GroupName", typeof(string));
                dt.Columns.Add("xrefDateEntered", typeof(DateTime));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ApplicationConfigurationSQLDatabase;

                cmd.CommandText = "usp_BusinessEntityGroup_SelectAll";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter("@FormID", FormID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["BusinessEntityID"] = int.Parse(dr["BusinessEntityID"].ToString().Length == 0 ? "0" : dr["BusinessEntityID"].ToString());
                    row["EntityTypeID"] = int.Parse(dr["EntityTypeID"].ToString().Length == 0 ? "0" : dr["EntityTypeID"].ToString());
                    row["EntityTypeName"] = dr["EntityTypeName"].ToString();
                    row["BusinessEntityName"] = dr["BusinessEntityName"].ToString();
                    row["IsBackend"] = bool.Parse(dr["IsBackend"].ToString().Length == 0 ? "false" : dr["IsBackend"].ToString());
                    row["ExcludeFNMAClaimFiledUpdateRpt"] = bool.Parse(dr["ExcludeFNMAClaimFiledUpdateRpt"].ToString().Length == 0 ? "false" : dr["ExcludeFNMAClaimFiledUpdateRpt"].ToString());
                    row["Group_BusinessEntityID"] = int.Parse(dr["Group_BusinessEntityID"].ToString().Length == 0 ? "0" : dr["Group_BusinessEntityID"].ToString());
                    row["GroupID"] = int.Parse(dr["GroupID"].ToString().Length == 0 ? "0" : dr["GroupID"].ToString());
                    row["GroupName"] = dr["GroupName"].ToString();
                    row["xrefDateEntered"] = DateTime.Parse(dr["xrefDateEntered"].ToString().Length == 0 ? "1/1/1900" : dr["xrefDateEntered"].ToString());

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        #endregion
    }
}
