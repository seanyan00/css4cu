﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;

namespace CRFS.Data
{
    class VAClaimsDataAccess
    {
        CRFS.Data.Settings _settings;

        internal VAClaimsDataAccess()
        {
        }

        internal VAClaimsDataAccess(CRFS.Data.Settings settings)
        {
            _settings = settings;
        }

        #region "Common"
        internal DataTable GetInvestorTracking_VAFollowUp(int claimID, Settings settings)
        {
            SqlConnection con = new SqlConnection();
            DataTable dt = new DataTable("VAFollowUps");
            dt.Columns.Add("VAClaim_FollowupID", typeof(int));
            dt.Columns.Add("VAClaimID", typeof(int));
            dt.Columns.Add("VAFollowupTypeID", typeof(int));
            dt.Columns.Add("VAFollowupTypeName", typeof(string));
            dt.Columns.Add("EnteredByUser", typeof(int));
            dt.Columns.Add("EnteredByUserName", typeof(string));
            dt.Columns.Add("EnteredDate", typeof(DateTime));
            dt.Columns.Add("LastUpdateUser", typeof(int));
            dt.Columns.Add("LastUpdatedByUserName", typeof(string));
            dt.Columns.Add("LastUpdateDate", typeof(DateTime));
            dt.Columns.Add("FollowupDate", typeof(DateTime));
            dt.Columns.Add("FollowupComplete", typeof(bool));
            dt.Columns.Add("CompleteDate", typeof(DateTime));
            dt.Columns.Add("CompletedByUser", typeof(int));
            dt.Columns.Add("CompletedByUserName", typeof(string));
            dt.Columns.Add("MarkedForDelete", typeof(bool));
            dt.Columns.Add("CommentText", typeof(string));
            dt.Columns.Add("deltaCheck", typeof(string));

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_InvTrk_VAClaim_Followup_Select";

                SqlParameter parm = new SqlParameter("@VAClaimID", claimID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                //dt.Load(dr);
                while (dr.Read())
                {
                    DataRow nr = dt.NewRow();
                    nr["VAClaim_FollowupID"] = dr["VAClaim_FollowupID"];
                    nr["VAClaimID"] = dr["VAClaimID"];
                    nr["VAFollowupTypeID"] = dr["VAFollowupTypeID"];
                    nr["VAFollowupTypeName"] = dr["VAFollowupTypeName"];
                    nr["EnteredByUser"] = dr["EnteredByUser"];
                    nr["EnteredByUserName"] = dr["EnteredByUserName"];
                    nr["EnteredDate"] = dr["EnteredDate"];
                    nr["LastUpdateUser"] = dr["LastUpdateUser"];
                    nr["LastUpdatedByUserName"] = dr["LastUpdatedByUserName"];
                    nr["LastUpdateDate"] = dr["LastUpdateDate"];
                    nr["CommentText"] = dr["CommentText"];
                    nr["FollowupDate"] = dr["FollowupDate"];
                    nr["FollowupComplete"] = dr["FollowupComplete"];
                    nr["CompleteDate"] = dr["CompleteDate"];
                    nr["CompletedByUser"] = dr["CompletedByUser"];
                    nr["CompletedByUserName"] = dr["CompletedByUserName"];
                    nr["MarkedForDelete"] = dr["MarkedForDelete"];
                    nr["deltaCheck"] = dr["deltaCheck"];
                    dt.Rows.Add(nr);
                }

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool SaveInvestorTrackingVAFollowUp(DataTable dt, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                int recordsAffected;

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                    SqlParameter prm = new SqlParameter();

                    switch (dt.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            cmd.CommandText = "usp_InvTrk_VAClaim_Followup_Insert";
                            break;
                        case DataRowState.Deleted:
                            break;
                        case DataRowState.Detached:
                            break;
                        case DataRowState.Modified:
                            cmd.CommandText = "usp_InvTrk_VAClaim_Followup_Update";
                            break;
                        case DataRowState.Unchanged:
                            goto NextRecord;
                        //break;
                        default:
                            break;
                    }

                    cmd.Connection = con;
                    cmd.Parameters.Add(new SqlParameter("@VAClaim_FollowupID", dt.Rows[i]["VAClaim_FollowupID"]));
                    cmd.Parameters.Add(new SqlParameter("@VAClaimID", dt.Rows[i]["VAClaimID"]));
                    cmd.Parameters.Add(new SqlParameter("@VAFollowupTypeID", dt.Rows[i]["VAFollowupTypeID"]));
                    cmd.Parameters.Add(new SqlParameter("@EnteredByUser", dt.Rows[i]["EnteredByUser"]));
                    cmd.Parameters.Add(new SqlParameter("@EnteredDate", dt.Rows[i]["EnteredDate"]));
                    cmd.Parameters.Add(new SqlParameter("@LastUpdateUser", dt.Rows[i]["LastUpdateUser"]));
                    //cmd.Parameters.Add(new SqlParameter("@LastUpdateDate", dt.Rows[i]["LastUpdateDate"]));
                    cmd.Parameters.Add(new SqlParameter("@LastUpdateDate", DateTime.UtcNow));
                    cmd.Parameters.Add(new SqlParameter("@CommentText", dt.Rows[i]["CommentText"]));
                    cmd.Parameters.Add(new SqlParameter("@FollowupDate", dt.Rows[i]["FollowupDate"]));
                    cmd.Parameters.Add(new SqlParameter("@FollowupComplete", dt.Rows[i]["FollowupComplete"]));
                    cmd.Parameters.Add(new SqlParameter("@CompleteDate", dt.Rows[i]["CompleteDate"]));
                    cmd.Parameters.Add(new SqlParameter("@CompletedByUser", dt.Rows[i]["CompletedByUser"]));
                    cmd.Parameters.Add(new SqlParameter("@MarkedForDelete", dt.Rows[i]["MarkedForDelete"]));
                    cmd.Parameters.Add(new SqlParameter("@deltaCheck", dt.Rows[i]["deltaCheck"]));

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord:;

                }

                dt.AcceptChanges();

                return true;

            }

            catch (Exception ex)
            {
                //dump the table into an error file so we have some record of where we were
                try
                {
                    CRFS.Data.ErrorDataDump.DumpTableToDefaultLocation(dt, "");

                }

                catch { }
                throw ex;

            }

            finally
            {

                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }


        }
        internal DataTable searchVAClaims_ByLoanNumberCaseNumber(int CMSLoginID, string SearchValue)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable("Claims");

                dt.Columns.Add("LoanID", typeof(int));
                dt.Columns.Add("LoanNumber", typeof(string));
                dt.Columns.Add("VACaseNumber", typeof(string));
                dt.Columns.Add("ClaimID", typeof(int));
                dt.Columns.Add("ClientID", typeof(int));
                dt.Columns.Add("ClientName", typeof(string));
                dt.Columns.Add("ClaimTypeID", typeof(int));
                dt.Columns.Add("ClaimType", typeof(string));
                dt.Columns.Add("ClaimDueDate", typeof(DateTime));
                dt.Columns.Add("ReferralDate", typeof(DateTime));
                dt.Columns.Add("OpenSteps", typeof(int));
                dt.Columns.Add("ClaimFormID", typeof(int));
                dt.Columns.Add("FormName", typeof(string));
                dt.Columns.Add("BorrowerFirstName", typeof(string));
                dt.Columns.Add("BorrowerLastName", typeof(string));
                dt.Columns.Add("PropertyAddress", typeof(string));
                dt.Columns.Add("PropertyCity", typeof(string));
                dt.Columns.Add("PropertyState", typeof(string));
                dt.Columns.Add("PropertyZip", typeof(string));

                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_CNTL_VA_FindClaim_ByLoanNumberCaseNumber";

                SqlParameter parm = new SqlParameter("@UserID", CMSLoginID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@SearchValue", SearchValue);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["LoanID"] = int.Parse(dr["LoanID"].ToString().Length == 0 ? "0" : dr["LoanID"].ToString());
                    row["LoanNumber"] = dr["LoanNumber"].ToString();
                    row["VACaseNumber"] = dr["VACaseNumber"].ToString();
                    row["ClaimID"] = int.Parse(dr["ClaimID"].ToString().Length == 0 ? "0" : dr["ClaimID"].ToString());
                    row["ClientID"] = int.Parse(dr["ClientID"].ToString().Length == 0 ? "0" : dr["ClientID"].ToString());
                    row["ClientName"] = dr["ClientName"].ToString();
                    row["ClaimTypeID"] = int.Parse(dr["ClaimTypeID"].ToString().Length == 0 ? "0" : dr["ClaimTypeID"].ToString());
                    row["ClaimType"] = dr["ClaimType"].ToString();
                    row["ClaimDueDate"] = DateTime.Parse(dr["ClaimDueDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClaimDueDate"].ToString());
                    row["ReferralDate"] = DateTime.Parse(dr["ReferralDate"].ToString().Length == 0 ? "1/1/1900" : dr["ReferralDate"].ToString());
                    row["OpenSteps"] = int.Parse(dr["OpenSteps"].ToString().Length == 0 ? "0" : dr["OpenSteps"].ToString());
                    row["ClaimFormID"] = int.Parse(dr["ClaimFormID"].ToString().Length == 0 ? "0" : dr["ClaimFormID"].ToString());
                    row["FormName"] = dr["FormName"].ToString();
                    row["BorrowerFirstName"] = dr["BorrowerFirstName"].ToString();
                    row["BorrowerLastName"] = dr["BorrowerLastName"].ToString();
                    row["PropertyAddress"] = dr["PropertyAddress"].ToString();
                    row["PropertyCity"] = dr["PropertyCity"].ToString();
                    row["PropertyState"] = dr["PropertyState"].ToString();
                    row["PropertyZip"] = dr["PropertyZip"].ToString();

                    dt.Rows.Add(row);

                }

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        #endregion


    }
}
