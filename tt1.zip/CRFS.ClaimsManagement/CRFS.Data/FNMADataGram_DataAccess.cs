﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Globalization;
using System.Text.RegularExpressions;

namespace CRFS.Data
{
    class FNMADataGram_DataAccess
    {
        CRFS.Data.Settings _settings;

        /// <summary>
        /// Default Constructor - should not be used
        /// </summary>
        internal FNMADataGram_DataAccess()
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="settings"></param>
        internal FNMADataGram_DataAccess(CRFS.Data.Settings settings)
        {
            _settings = settings;

        }

        #region "Lookup Tables for Datagram"
        internal DataTable Datagram_lkp_Datagram_StatusTypes_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("DG_StatusTypes");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("StatusID", typeof(int));
                dt.Columns.Add("StatusType", typeof(string));
                dt.Columns.Add("Active", typeof(bool));


                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                cmd.CommandText = "Datagram.usp_Datagram_StatusTypes_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();
                    row["StatusID"] = int.Parse(dr["StatusID"].ToString().Length == 0 ? "0" : dr["StatusID"].ToString());
                    row["StatusType"] = dr["StatusType"].ToString();
                    row["Active"] = dr["Active"].ToString();

                    dt.Rows.Add(row);

                }
                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;

            }


            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }
        }

        //
        internal DataTable Datagram_lkp_Datagram_ReferralTypes_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("DG_ReferralTypes");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("ReferralTypeID", typeof(int));
                dt.Columns.Add("ReferralType", typeof(string));
                dt.Columns.Add("Active", typeof(bool));


                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                cmd.CommandText = "Datagram.usp_Datagram_ReferralTypes_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();
                    row["ReferralTypeID"] = int.Parse(dr["ReferralTypeID"].ToString().Length == 0 ? "0" : dr["ReferralTypeID"].ToString());
                    row["ReferralType"] = dr["ReferralType"].ToString();
                    row["Active"] = dr["Active"].ToString();

                    dt.Rows.Add(row);

                }
                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;

            }


            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }
        }
        //

        internal DataTable Datagram_lkp_Datagram_InvoiceStatusTypes_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("DG_InvoiceStatus");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("InvoiceStatusID", typeof(int));
                dt.Columns.Add("InvoiceStatus", typeof(string));
                dt.Columns.Add("Active", typeof(bool));


                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                cmd.CommandText = "Datagram.usp_Datagram_InvoiceStatusTypes_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();
                    row["InvoiceStatusID"] = int.Parse(dr["InvoiceStatusID"].ToString().Length == 0 ? "0" : dr["InvoiceStatusID"].ToString());
                    row["InvoiceStatus"] = dr["InvoiceStatus"].ToString();
                    row["Active"] = dr["Active"].ToString();

                    dt.Rows.Add(row);

                }
                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;

            }


            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }
        }
        //
        internal DataTable Datagram_lkp_Datagram_CommentTypes_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("DG_CommentTypes");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("CommentTypeID", typeof(int));
                dt.Columns.Add("CommentType", typeof(string));
                dt.Columns.Add("Active", typeof(bool));


                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                cmd.CommandText = "Datagram.usp_Datagram_CommentTypes_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();
                    row["CommentTypeID"] = int.Parse(dr["CommentTypeID"].ToString().Length == 0 ? "0" : dr["CommentTypeID"].ToString());
                    row["CommentType"] = dr["CommentType"].ToString();
                    row["Active"] = dr["Active"].ToString();

                    dt.Rows.Add(row);

                }
                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;

            }


            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }
        }
        #endregion

        #region "data retrival and saves for Datagram"
        /// <summary>
        /// Retrieves all Datagram comments for the specified referral ID.
        /// </summary>
        /// <param name="referralID">The PK referral ID of interest.</param>
        /// <param name="settings">Database connection information</param>
        /// <returns>DataTable with all comments for the FNMA Asset Collections Datagram referral specified.</returns>
        internal DataTable AssetColl_DatagramComments_Get(int datagramReferralID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();

            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("DatagramComments");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("DatagramCommentID", typeof(int));
                dt.Columns.Add("DatagramReferralID", typeof(int));
                dt.Columns.Add("CommentTypeID", typeof(int));
                dt.Columns.Add("CommentType", typeof(string));
                dt.Columns.Add("FollowupDate", typeof(DateTime));
                dt.Columns.Add("FollowupComplete", typeof(bool));
                dt.Columns.Add("CommentText", typeof(string));
                dt.Columns.Add("EnteredDate", typeof(DateTime));
                dt.Columns.Add("EnteredByUserID", typeof(int));
                dt.Columns.Add("EnteredByUser", typeof(string));
                dt.Columns.Add("LastUpdateDate", typeof(DateTime));
                dt.Columns.Add("LastUpdateUserID", typeof(int));
                dt.Columns.Add("LastUpdateUser", typeof(string));
                dt.Columns.Add("deltaCheck", typeof(int));
                

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                SqlParameter parm = new SqlParameter("@DatagramReferralID", datagramReferralID);
                cmd.Parameters.Add(parm);

                cmd.CommandText = "Datagram.usp_DatagramComment_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["DatagramCommentID"] = int.Parse(dr["DatagramCommentID"].ToString().Length == 0 ? "0" : dr["DatagramCommentID"].ToString());
                    row["DatagramReferralID"] = int.Parse(dr["DatagramReferralID"].ToString().Length == 0 ? "0" : dr["DatagramReferralID"].ToString());
                    row["CommentTypeID"] = int.Parse(dr["CommentTypeID"].ToString().Length == 0 ? "0" : dr["CommentTypeID"].ToString());
                    row["CommentType"] = dr["CommentType"].ToString();
                    row["FollowupComplete"] = bool.Parse(dr["FollowupComplete"].ToString().Length == 0 ? "false" : dr["FollowupComplete"].ToString());
                    row["FollowupDate"] = DateTime.Parse(dr["FollowupDate"].ToString().Length == 0 ? "1/1/1900" : dr["FollowupDate"].ToString());
                    row["CommentText"] = dr["CommentText"].ToString();
                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                    row["EnteredByUserID"] = int.Parse(dr["EnteredByUserID"].ToString().Length == 0 ? "0" : dr["EnteredByUserID"].ToString());
                    row["EnteredByUser"] = dr["EnteredByUser"].ToString();
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    row["LastUpdateUserID"] = int.Parse(dr["LastUpdateUserID"].ToString().Length == 0 ? "0" : dr["LastUpdateUserID"].ToString());
                    row["LastUpdateUser"] = dr["LastUpdateUser"].ToString();
                    //FB 48261 mjf
                    row["deltaCheck"] = dr["deltaCheck"].ToString();
                   
                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Saves the comment records for the current referral
        /// </summary>
        /// <param name="data">Table of comment data to store</param>
        /// <param name="settings">Database connection information</param>
        /// <returns>Boolean flag indicating success or failure.</returns>
        internal bool AssetColl_DatagramComments_Save(DataTable data, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                for (int i = 0; i < data.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;
                    cmd.Connection = con;

                    switch (data.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            cmd.CommandText = "Datagram.usp_DatagramComment_Insert";

                            parm = new SqlParameter("@DatagramReferralID", data.Rows[i]["DatagramReferralID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@CommentTypeID", data.Rows[i]["CommentTypeID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FollowupComplete", data.Rows[i]["FollowupComplete"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FollowupDate", data.Rows[i]["FollowupDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@CommentText", data.Rows[i]["CommentText"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@EnteredDate", data.Rows[i]["EnteredDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@EnteredByUserID", data.Rows[i]["EnteredByUserID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateDate", data.Rows[i]["LastUpdateDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateUserID", data.Rows[i]["LastUpdateUserID"]);
                            cmd.Parameters.Add(parm);
                         
                            //Now we need to execute a stored procedure that returns the new record ID
                            data.Rows[i]["DatagramCommentID"] = int.Parse(cmd.ExecuteScalar().ToString());

                            goto NextRecord;

                        case DataRowState.Modified:
                            cmd.CommandText = "Datagram.usp_DatagramComment_Update";

                            parm = new SqlParameter("@DatagramReferralID", data.Rows[i]["DatagramReferralID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@DatagramCommentID", data.Rows[i]["DatagramCommentID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@CommentTypeID", data.Rows[i]["CommentTypeID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FollowupComplete", data.Rows[i]["FollowupComplete"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FollowupDate", data.Rows[i]["FollowupDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@CommentText", data.Rows[i]["CommentText"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateDate", data.Rows[i]["LastUpdateDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateUserID", data.Rows[i]["LastUpdateUserID"]);
                            cmd.Parameters.Add(parm);
                            //FB 48261 mjf
                            parm = new SqlParameter("@deltaCheck", data.Rows[i]["deltaCheck"]);
                            cmd.Parameters.Add(parm);

                            break;

                        default:
                            goto NextRecord;
                    }

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;
                }

                data.AcceptChanges();

                return true;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
        

       internal DataTable Datagram_ApplicationReferralEvents_Get(Settings settings, int DatagramReferralID)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("ApplicationReferralEvents");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("ApplicationReferralEventID", typeof(int));
                dt.Columns.Add("EventStateName", typeof(string));
                dt.Columns.Add("EventFromID", typeof(int));
                dt.Columns.Add("EventToID", typeof(int));
                dt.Columns.Add("IsComplete", typeof(bool));
                dt.Columns.Add("EnteredDate", typeof(DateTime));
                dt.Columns.Add("UserName", typeof(string));
                dt.Columns.Add("IsLocked", typeof(bool));

                SqlCommand cmd = new SqlCommand();
                SqlParameter parm = new SqlParameter();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

                cmd.CommandText = "Datagram.usp_Datagram_ApplicationReferralEvents_Select";
                cmd.Connection = con;
                parm = new SqlParameter("@DatagramReferralID", DatagramReferralID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ApplicationReferralEventID"] = int.Parse(dr["ApplicationReferralEventID"].ToString().Length == 0 ? "0" : dr["ApplicationReferralEventID"].ToString());
                    row["EventStateName"] = dr["EventStateName"].ToString().Length == 0 ? "" : dr["EventStateName"].ToString();
                    row["EventFromID"] = int.Parse(dr["EventFromID"].ToString().Length == 0 ? "0" : dr["EventFromID"].ToString());
                    row["EventToID"] = int.Parse(dr["EventToID"].ToString().Length == 0 ? "0" : dr["EventToID"].ToString());
                    row["IsComplete"] = bool.Parse(dr["IsComplete"].ToString().Length == 0 ? "0" : dr["IsComplete"].ToString());
                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                    row["UserName"] = dr["UserName"].ToString().Length == 0 ? "" : dr["UserName"].ToString();
                    row["IsLocked"] = bool.Parse(dr["IsLocked"].ToString().Length == 0 ? "0" : dr["IsLocked"].ToString());

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
        #endregion

       internal DataTable AssetColl_AdvPmtReferral_Get(int advPmtReferralID, Settings settings)
       {
           SqlConnection con = new SqlConnection();

           try
           {
               con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
               con.Open();
           }

           catch (Exception e)
           {
               throw e;
           }

           try
           {
               DataTable dt = new DataTable("AdvPmtReferral");
               DataColumn dc = new DataColumn();

               dt.Columns.Add("AdvPmtReferralID", typeof(int));
               dt.Columns.Add("REO ID", typeof(string));
               dt.Columns.Add("FNMA Loan Number", typeof(string));
               dt.Columns.Add("Referral Type", typeof(string));
               dt.Columns.Add("ReferralTypeID", typeof(int));
               dt.Columns.Add("Referral Date", typeof(DateTime));
               dt.Columns.Add("ServicerID", typeof(int));
               dt.Columns.Add("Servicer Name", typeof(string));
               dt.Columns.Add("Servicer Loan Number", typeof(string));
               dt.Columns.Add("Servicer Number", typeof(string));
               dt.Columns.Add("Property State", typeof(string));
               dt.Columns.Add("Last Disbursement Date", typeof(DateTime));
               dt.Columns.Add("DaysSinceLastDisbursement", typeof(int));
               dt.Columns.Add("Loan Status", typeof(string));
               dt.Columns.Add("Loan Status Date", typeof(DateTime));
               dt.Columns.Add("Days Since Loan Status", typeof(int));
               dt.Columns.Add("Months Aged", typeof(int));
               dt.Columns.Add("Age Buckets", typeof(string));
               dt.Columns.Add("Current LPI Date", typeof(DateTime));
               dt.Columns.Add("Insurer Type", typeof(string));
               dt.Columns.Add("FCL Loss Risk Code", typeof(string));
               dt.Columns.Add("DARTS Flag", typeof(string));
               dt.Columns.Add("True FNMA GL", typeof(decimal));
               dt.Columns.Add("Preparer Name of Disbursement", typeof(string));
               dt.Columns.Add("Preparer Phone Number", typeof(string));
               dt.Columns.Add("Advance Payment Status", typeof(string));
               dt.Columns.Add("AdvPmtStatusID", typeof(int));
               dt.Columns.Add("Imported", typeof(bool));
               dt.Columns.Add("Import Date", typeof(DateTime));
               dt.Columns.Add("EnteredDate", typeof(DateTime));
               dt.Columns.Add("EnteredByUser", typeof(string));
               dt.Columns.Add("EnteredByUserID", typeof(int));
               dt.Columns.Add("LastUpdateDate", typeof(DateTime));
               dt.Columns.Add("LastUpdateUser", typeof(string));
               dt.Columns.Add("LastUpdateUserID", typeof(int));

               SqlCommand cmd = new SqlCommand();
               cmd.CommandType = System.Data.CommandType.StoredProcedure;
               cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

               SqlParameter parm = new SqlParameter("@AdvPmtReferralID", advPmtReferralID);
               cmd.Parameters.Add(parm);

               cmd.CommandText = "Datagram.usp_Datagram_AdvPmtReferral_Select";
               cmd.Connection = con;

               SqlDataReader dr = cmd.ExecuteReader();
               while (dr.Read())
               {
                   DataRow row = dt.NewRow();

                   row["AdvPmtReferralID"] = int.Parse(dr["AdvPmtReferralID"].ToString().Length == 0 ? "0" : dr["AdvPmtReferralID"].ToString());
                   row["REO ID"] = dr["REO_ID"].ToString();
                   row["FNMA Loan Number"] = dr["FNMA_LoanNumber"].ToString();
                   row["Referral Type"] = dr["ReferralType"].ToString();
                   row["ReferralTypeID"] = int.Parse(dr["ReferralTypeID"].ToString().Length == 0 ? "0" : dr["ReferralTypeID"].ToString());
                   row["Referral Date"] = DateTime.Parse(dr["ReferralDate"].ToString().Length == 0 ? "1/1/1900" : dr["ReferralDate"].ToString());
                   row["Servicer Name"] = dr["ServicerName"].ToString();
                   row["ServicerID"] = int.Parse(dr["ServicerID"].ToString().Length == 0 ? "0" : dr["ServicerID"].ToString());
                   row["Servicer Loan Number"] = dr["ServicerLoanNumber"].ToString();
                   row["Servicer Number"] = dr["ServicerNumber"].ToString();
                   row["Property State"] = dr["PropertyState"].ToString();
                   row["Last Disbursement Date"] = DateTime.Parse(dr["LastDisbursementDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastDisbursementDate"].ToString());
                   row["DaysSinceLastDisbursement"] = int.Parse(dr["DaysSinceLastDisbursement"].ToString().Length == 0 ? "0" : dr["DaysSinceLastDisbursement"].ToString());
                   row["Loan Status"] = dr["LoanStatus"].ToString();
                   row["Loan Status Date"] = DateTime.Parse(dr["LoanStatusDate"].ToString().Length == 0 ? "1/1/1900" : dr["LoanStatusDate"].ToString());
                   row["Days Since Loan Status"] = int.Parse(dr["DaysSinceLoanStatus"].ToString().Length == 0 ? "0" : dr["DaysSinceLoanStatus"].ToString());
                   row["Months Aged"] = int.Parse(dr["MonthsAged"].ToString().Length == 0 ? "0" : dr["MonthsAged"].ToString());
                   row["Age Buckets"] = dr["AgeBuckets"].ToString();
                   row["Current LPI Date"] = DateTime.Parse(dr["CurrentLPI_Date"].ToString().Length == 0 ? "1/1/1900" : dr["CurrentLPI_Date"].ToString());
                   row["Insurer Type"] = dr["InsurerType"].ToString();
                   row["FCL Loss Risk Code"] = dr["FCL_LossRiskCode"].ToString();
                   row["DARTS Flag"] = dr["DARTS_Flag"].ToString();
                   row["True FNMA GL"] = decimal.Parse(dr["TrueFNMA_GL"].ToString().Length == 0 ? "0.0" : dr["TrueFNMA_GL"].ToString());
                   row["Preparer Name of Disbursement"] = dr["PrepNameOfDisbursement"].ToString();
                   row["Preparer Phone Number"] = dr["PrepPhoneDisbursement"].ToString();
                   row["Advance Payment Status"] = dr["AdvPmtStatus"].ToString();
                   row["AdvPmtStatusID"] = int.Parse(dr["AdvPmtStatusID"].ToString().Length == 0 ? "0" : dr["AdvPmtStatusID"].ToString());
                   row["Imported"] = bool.Parse(dr["Imported"].ToString().Length == 0 ? "false" : dr["Imported"].ToString());
                   row["Import Date"] = DateTime.Parse(dr["ImportDate"].ToString().Length == 0 ? "1/1/1900" : dr["ImportDate"].ToString());
                   row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                   row["EnteredByUser"] = dr["EnteredByUser"].ToString();
                   row["EnteredByUserID"] = int.Parse(dr["EnteredByUserID"].ToString().Length == 0 ? "0" : dr["EnteredByUserID"].ToString());
                   row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                   row["LastUpdateUser"] = dr["LastUpdateUser"].ToString();
                   row["LastUpdateUserID"] = int.Parse(dr["LastUpdateUserID"].ToString().Length == 0 ? "0" : dr["LastUpdateUserID"].ToString());

                   dt.Rows.Add(row);
               }

               dt.AcceptChanges();
               return dt;
           }

           catch (Exception ex)
           {
               throw ex;
           }

           finally
           {
               if (con.State != System.Data.ConnectionState.Closed)
               {
                   con.Close();
                   con.Dispose();
               }
           }
       }

       /// <summary>
       /// Retrieves all FNMA Asset Collection claims matching the type and value specified.
       /// Multiple values will match if the searchvalue specified is a prefix to any
       /// existing REO IDs or Loan Numbers.
       /// </summary>
       /// <param name="searchType">The selection from the combobox list for the type of search being performed.</param>
       /// <param name="searchValue">Search value typed in by user</param>
       /// <param name="settings">Contains the database connection information which determines
       /// whether we're working with Development, Test, Production, etc.</param>
       /// <returns>Dataset of claims matching the search type and value specified.</returns>
       internal DataSet AssetCollections_FindClaims(string searchType, string searchValue, Settings settings)
       {
           SqlConnection con = new SqlConnection();

           try
           {
               DataSet ds = new DataSet();
               DataTable dt = new DataTable("AssetCollectionsClaimsFound");

               dt.Columns.Add("ReferralID", typeof(int));
               dt.Columns.Add("REO ID", typeof(string));
               dt.Columns.Add("FNMA Loan Number", typeof(string));
               dt.Columns.Add("ReferralTypeID", typeof(int));
               dt.Columns.Add("Referral Type", typeof(string));
               dt.Columns.Add("StatusID", typeof(int));
               dt.Columns.Add("StatusType", typeof(string));

               con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
               con.Open();

               SqlCommand cmd = new SqlCommand();
               cmd.CommandType = CommandType.StoredProcedure;
               cmd.CommandText = "Datagram.usp_Datagram_FindClaims_Select";
               SqlParameter prm = new SqlParameter("@SearchType", searchType);
               cmd.Parameters.Add(prm);
               prm = new SqlParameter("@SearchValue", searchValue);
               cmd.Parameters.Add(prm);

               cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;
               cmd.Connection = con;

               SqlDataReader dr = cmd.ExecuteReader();
               while (dr.Read())
               {
                   DataRow row = dt.NewRow();
                   row["ReferralID"] = int.Parse(dr["ReferralID"].ToString().Length == 0 ? "0" : dr["ReferralID"].ToString());
                   row["REO ID"] = dr["REO_ID"].ToString();
                   row["FNMA Loan Number"] = dr["FNMA_LoanNumber"].ToString();
                   row["ReferralTypeID"] = int.Parse(dr["ReferralTypeID"].ToString().Length == 0 ? "0" : dr["ReferralTypeID"].ToString());
                   row["Referral Type"] = dr["ReferralType"].ToString();
                   row["StatusID"] = int.Parse(dr["StatusID"].ToString().Length == 0 ? "0" : dr["StatusID"].ToString());
                   row["StatusType"] = dr["StatusType"].ToString();

                   dt.Rows.Add(row);
               }
               dr.Close();
               dr.Dispose();

               ds.Tables.Add(dt);
               return ds;
           }
           catch (Exception e)
           {
               throw e;
           }
           finally
           {
               if (con.State != ConnectionState.Closed)
               {
                   con.Close();
                   con.Dispose();
               }
           }
       }

       /// <summary>
       /// Retrieves the valid referral (collection) types for FNMA Asset Collections.
       /// </summary>
       /// <param name="settings">Database connection information</param>
       /// <returns>DataTable with all valid referral types for FNMA Asset Collections.</returns>
       internal DataTable AssetColl_ReferralTypes_Select(Settings settings)
       {
           SqlConnection con = new SqlConnection();

           try
           {
               con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
               con.Open();
           }

           catch (Exception e)
           {
               throw e;
           }

           try
           {
               DataTable dt = new DataTable("ReferralTypes");
               DataColumn dc = new DataColumn();

               dc = new DataColumn();
               dc.ColumnName = "ReferralTypeID";
               dc.DataType = typeof(int);
               dt.Columns.Add(dc);

               dc = new DataColumn();
               dc.ColumnName = "ReferralType";
               dc.DataType = typeof(string);
               dt.Columns.Add(dc);

               SqlCommand cmd = new SqlCommand();
               cmd.CommandType = System.Data.CommandType.StoredProcedure;
               cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

               cmd.CommandText = "Datagram.usp_Datagram_ReferralTypes_Select";
               cmd.Connection = con;

               SqlDataReader dr = cmd.ExecuteReader();

               while (dr.Read())
               {
                   DataRow row = dt.NewRow();

                   row["ReferralTypeID"] = int.Parse(dr["ReferralTypeID"].ToString().Length == 0 ? "0" : dr["ReferralTypeID"].ToString());
                   row["ReferralType"] = dr["ReferralType"].ToString();

                   dt.Rows.Add(row);
               }

               dt.AcceptChanges();
               return dt;
           }

           catch (Exception ex)
           {
               throw ex;
           }

           finally
           {
               if (con.State != System.Data.ConnectionState.Closed)
               {
                   con.Close();
                   con.Dispose();
               }
           }
       }

       /// <summary>
       /// Retrieves all Servicer Contact information for Asset Collections for editing in the Admin Panel
       /// </summary>
       /// <returns>DataTable of Servicer contacts and the associated Group Name.</returns>
       internal DataTable AssetColl_ServicerEmail2_Get(Settings settings)
       {
           SqlConnection con = new SqlConnection();

           try
           {
               con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
               con.Open();
           }

           catch (Exception e)
           {
               throw e;
           }

           try
           {
               DataTable dt = new DataTable("ServicerEmails");
               DataColumn dc = new DataColumn();

               dt.Columns.Add("GroupContactID", typeof(int));
               dt.Columns.Add("GroupID", typeof(int));
               dt.Columns.Add("ContactName", typeof(string));
               dt.Columns.Add("EmailAddress", typeof(string));
               dt.Columns.Add("FormID", typeof(int));
               dt.Columns.Add("Active", typeof(bool));

               SqlCommand cmd = new SqlCommand();
               cmd.CommandType = System.Data.CommandType.StoredProcedure;
               cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

               cmd.CommandText = "Datagram.usp_Datagram_ServicerEmail_Select2";
               cmd.Connection = con;

               SqlDataReader dr = cmd.ExecuteReader();
               while (dr.Read())
               {
                   DataRow row = dt.NewRow();

                   row["GroupContactID"] = int.Parse(dr["GroupContactID"].ToString().Length == 0 ? "0" : dr["GroupContactID"].ToString());
                   row["GroupID"] = int.Parse(dr["GroupID"].ToString().Length == 0 ? "0" : dr["GroupID"].ToString());
                   row["ContactName"] = dr["ContactName"].ToString();
                   row["EmailAddress"] = dr["EmailAddress"].ToString();
                   row["FormID"] = int.Parse(dr["FormID"].ToString().Length == 0 ? "0" : dr["FormID"].ToString());
                   row["Active"] = bool.Parse(dr["Active"].ToString().Length == 0 ? "0" : dr["Active"].ToString());
                   dt.Rows.Add(row);
               }

               dt.AcceptChanges();
               return dt;
           }

           catch (Exception ex)
           {
               throw ex;
           }

           finally
           {
               if (con.State != System.Data.ConnectionState.Closed)
               {
                   con.Close();
                   con.Dispose();
               }
           }
       }

       /// <summary>
       /// Saves contact records
       /// </summary>
       /// <param name="data">Table of comment data to store</param>
       /// <param name="settings">Database connection information</param>
       /// <returns>Boolean flag indicating success or failure.</returns>
       internal bool AssetColl_ServicerEmail_Save(DataTable data, Settings settings, int CMSUserID)
       {
           SqlConnection con = new SqlConnection();

           try
           {
               con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
               con.Open();
           }

           catch (Exception e)
           {
               throw e;
           }

           try
           {
               SqlParameter parm = new SqlParameter();
               int recordsAffected;

               for (int i = 0; i < data.Rows.Count; i++)
               {
                   SqlCommand cmd = new SqlCommand();
                   cmd.CommandType = System.Data.CommandType.StoredProcedure;
                   cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;
                   cmd.Connection = con;

                   switch (data.Rows[i].RowState)
                   {
                       case DataRowState.Added:
                           cmd.CommandText = "Datagram.usp_Datagram_ServicerEmail_Insert";

                           parm = new SqlParameter("@GroupID", data.Rows[i]["GroupID"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@FormID", data.Rows[i]["FormID"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@ContactName", data.Rows[i]["ContactName"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@EmailAddress", data.Rows[i]["EmailAddress"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@Active", data.Rows[i]["Active"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@EnteredByUserID", CMSUserID);
                           cmd.Parameters.Add(parm);

                           //Now we need to execute a stored procedure that returns the new record ID
                           data.Rows[i]["GroupContactID"] = int.Parse(cmd.ExecuteScalar().ToString());

                           goto NextRecord;

                       case DataRowState.Modified:
                           cmd.CommandText = "Datagram.usp_Datagram_ServicerEmail_Update";

                           parm = new SqlParameter("@GroupContactID", data.Rows[i]["GroupContactID"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@GroupID", data.Rows[i]["GroupID"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@FormID", data.Rows[i]["FormID"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@ContactName", data.Rows[i]["ContactName"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@EmailAddress", data.Rows[i]["EmailAddress"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@Active", data.Rows[i]["Active"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@LastUpdateUserID", CMSUserID);
                           cmd.Parameters.Add(parm);

                           break;
                       case DataRowState.Deleted:
                           cmd.CommandText = "Datagram.usp_Datagram_ServicerEmail_Delete";
                           parm = new SqlParameter("@GroupContactID", data.Rows[i]["GroupContactID", DataRowVersion.Original]);
                           cmd.Parameters.Add(parm);

                           break;
                       default:
                           goto NextRecord;
                   }

                   recordsAffected = cmd.ExecuteNonQuery();

               NextRecord: ;
               }

               data.AcceptChanges();

               return true;
           }

           catch (Exception ex)
           {
               throw ex;
           }

           finally
           {
               if (con.State != System.Data.ConnectionState.Closed)
               {
                   con.Close();
                   con.Dispose();
               }
           }
       }

       /// <summary>
       /// Retrieves a specific FNMA Asset Collections referral by REO ID, FNMA Loan Number
       /// and Referraltype. the same REO ID and FNMA Loan # combination can exist in each of
       /// the AssetCollections databases.
       /// </summary>
       /// <param name="referralTypeID">ID from tbllkp_Forms_ComboBoxValues indicating which type of Asset Collection this record belongs to.</param>
       /// <param name="settings">Database connection information</param>
       /// <param name="optParms">Array containing the REO ID [0] and the FNMA Loan # [1].</param>
       /// <returns>DataTable with the data for the specified FNMA Asset Collections Datagram referral.</returns>
       internal DataTable AssetCollections_SelectReferralID(int referralTypeID, Settings settings, string[] optParms)
       {
           SqlConnection con = new SqlConnection();

           try
           {
               con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
               con.Open();
           }

           catch (Exception e)
           {
               throw e;
           }

           try
           {
               DataTable dt = new DataTable("Referral");
               dt.Columns.Add("ReferralID", typeof(int));
               dt.Columns.Add("REO_ID", typeof(string));
               dt.Columns.Add("FNMA_LoanNumber", typeof(string));
               dt.Columns.Add("ReferralTypeID", typeof(int));
               dt.Columns.Add("ReferralType", typeof(string));
               dt.Columns.Add("ReferralStatusID", typeof(int));
               dt.Columns.Add("ReferralStatus", typeof(string));

               SqlCommand cmd = new SqlCommand();
               cmd.CommandType = System.Data.CommandType.StoredProcedure;
               cmd.CommandTimeout = Configuration.CommandTimeouts_General_AppsDB_FNMASQLDatabase;

               SqlParameter parm = new SqlParameter("@ReferralTypeID", referralTypeID);
               cmd.Parameters.Add(parm);
               parm = new SqlParameter("@REO_ID", optParms[0]);
               cmd.Parameters.Add(parm);
               parm = new SqlParameter("@FNMA_LoanNumber", optParms[1]);
               cmd.Parameters.Add(parm);

               //Choose stored procedure to run based on 
               cmd.CommandText = "Datagram.usp_Datagram_ReferralFind";
               cmd.Connection = con;

               SqlDataReader dr = cmd.ExecuteReader();

               while (dr.Read())
               {
                   DataRow row = dt.NewRow();

                   row["ReferralID"] = int.Parse(dr["ReferralID"].ToString().Length == 0 ? "0" : dr["ReferralID"].ToString());
                   row["REO_ID"] = dr["REO_ID"].ToString();
                   row["FNMA_LoanNumber"] = dr["FNMA_LoanNumber"].ToString();
                   row["ReferralTypeID"] = int.Parse(dr["ReferralTypeID"].ToString().Length == 0 ? "0" : dr["ReferralTypeID"].ToString());
                   row["ReferralType"] = dr["ReferralType"].ToString();
                   row["ReferralStatusID"] = int.Parse(dr["ReferralStatusID"].ToString().Length == 0 ? "0" : dr["ReferralStatusID"].ToString());
                   row["ReferralStatus"] = dr["ReferralStatus"].ToString();

                   dt.Rows.Add(row);
               }

               dt.AcceptChanges();
               return dt;
           }

           catch (Exception ex)
           {
               throw ex;
           }

           finally
           {
               if (con.State != System.Data.ConnectionState.Closed)
               {
                   con.Close();
                   con.Dispose();
               }
           }
       }

       #region "Imports FNMA Asset Collections"
       /// <summary>
       /// Performs the import for FNMA Asset Collections Datagram Penalty referrals.
       /// </summary>
       /// <param name="data">Table of data for the Datagram referral record.</param>
       /// <param name="referralTypeID">Indicates the Asset Collections referral type ID (Datagram, Hazard, Advance Payment)</param>
       /// <param name="formID">Application formID from tbllkp_Forms.</param>
       /// <param name="importAsDate">Date to use for importing the data record.</param>
       /// <param name="userUniqueID">user ID performing the import.</param>
       /// <param name="events">Moss.Events object</param>
       /// <param name="df">CRFS.Data.Datafunctions object.</param>
       /// <param name="settings">Contains the database connection information which determines
       /// whether we're working with Development, Test, Production, etc.</param>
       /// <returns>Data table of data records imported and the process results for each record.</returns>
       internal DataTable ImportAssetCollection(DataTable data, int referralTypeID, int formID, string importAsDate, int userUniqueID, Moss.Events.Events events, CRFS.Data.DataFunctions df, Settings settings)
       {
           double nextTarget = .01;
           SqlConnection con = new SqlConnection();

           try
           {
               DataColumn dc = new DataColumn();

               if (!data.Columns.Contains("Processed"))
               {
                   dc = new DataColumn();
                   dc.ColumnName = "Processed";
                   dc.DataType = typeof(bool);
                   dc.DefaultValue = false;
                   data.Columns.Add(dc);

               }

               if (!data.Columns.Contains("ProcessComments"))
               {
                   dc = new DataColumn();
                   dc.ColumnName = "ProcessComments";
                   dc.DataType = typeof(string);
                   dc.DefaultValue = "Not Processed";
                   data.Columns.Add(dc);

               }

               //Rename the loan # column, it varies between the REO and Non-REO files
               //  Also check to see if the REO ID column exists
               bool REO_ID_exists = false;
               foreach (DataColumn column in data.Columns)
               {
                   column.ColumnName = column.ColumnName.Trim();
                   switch (column.ColumnName.ToUpper())
                   {
                       case "LOAN NUMBER":
                           column.ColumnName = "FNMA LOAN NUMBER";
                           break;

                       case "LOAN_NUMBER":
                           column.ColumnName = "FNMA LOAN NUMBER";
                           break;

                       case "LOAN NO:":
                           column.ColumnName = "FNMA LOAN NUMBER";
                           break;

                       case "LOAN_NO:":
                           column.ColumnName = "FNMA LOAN NUMBER";
                           break;

                       case "FNMA LOAN#":
                           column.ColumnName = "FNMA LOAN NUMBER";
                           break;

                       case "REO#":
                           column.ColumnName = "REO ID";
                           break;

                       case "REO ID#":
                           column.ColumnName = "REO ID";
                           break;

                       case "REO_ID#":
                           column.ColumnName = "REO ID";
                           break;

                       case "REO_ID":
                           column.ColumnName = "REO ID";
                           break;

                       case "SERVICER LOAN#":
                           column.ColumnName = "SERVICER LOAN NUMBER";
                           break;

                       case "SERVICER LOAN #":
                           column.ColumnName = "SERVICER LOAN NUMBER";
                           break;

                       default:
                           break;
                   }
                   if (column.ColumnName == "REO ID")
                   {
                       REO_ID_exists = true;
                   }
               }

               if (!REO_ID_exists)
               {
                   data.Columns.Add("REO ID");
                   REO_ID_exists = true;
               }

               int rowCount = data.Rows.Count;

               con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
               SqlTransaction tran;

               con.Open();

               if (con.State == ConnectionState.Open)
               {
                   for (int i = 0; i < rowCount; i++)
                   {
                       //Before starting a SQL Transaction, we need to look at the Servicer name.
                       //Since these are text, we get a lot of variation for them and they must be grouped to send emails
                       //Therefore, we are now flagging on import when we import a new value.  The Admin tools can then
                       //be used to set up the groupings by users who are authorized to make those changes.

                       DataTable dtBusinessEntities = df.BusinessEntities_Get(formID);

                       DataTable dtBusinessEntityTypes = df.EntityTypes_Get();
                       DataView dvBusinessEntityTypes = new DataView(dtBusinessEntityTypes);

                       //Now do the same operation with the servicer name
                       string ServicerName = ReplaceParantheticalString(data.Rows[i]["Servicer Name"].ToString());

                       int servicerBusinessEntityID = 0;
                       bool ServicerAddedFlag = false;

                       DataView dvServicer = new DataView(dtBusinessEntities);
                       dvServicer.RowFilter = "BusinessEntityName = '" + ServicerName + "'";

                       switch (dvServicer.Count)
                       {
                           case 0:
                               //The Servicer needs to be added to the BusinessEntities table.  This can be done automatically,
                               //But it will need manual steps performed to be added to a group
                               //we'll set a message flag for this
                               dvBusinessEntityTypes.RowFilter = ("EntityTypeName = 'ServicerName'");

                               servicerBusinessEntityID = df.InsertBusinessEntity(ServicerName, int.Parse(dvBusinessEntityTypes[0]["EntityTypeID"].ToString()), formID);
                               ServicerAddedFlag = true;

                               break;

                           case 1:
                               //We're in good shape.  We have a single match.  Use the BusinessEntityID for loading this record
                               servicerBusinessEntityID = int.Parse(dvServicer[0]["BusinessEntityID"].ToString());

                               break;

                           default:
                               data.Rows[i]["Processed"] = false;
                               data.Rows[i]["ProcessComments"] = "ERROR: There is more than one Servicer matching the value for this import record.  This record was not saved";

                               goto NextRecord;

                       }

                       //We also need the ID of three attributes, rather than the text supplied in the import file.
                       //It is time to do the lookups.  

                       //The first two have lookups stored in tbllkp_Forms_ComboBoxValues
                       int StatusTypeID = 0;               //This should always be Open

                       DataTable dtComboBoxValues = new DataTable();
                       dtComboBoxValues = df.ClaimsManagement_GetComboBoxReferenceValues_ByFormID(formID);

                       DataView dvAssetCollections = new DataView(dtComboBoxValues);
                       dvAssetCollections.RowFilter = ("ComboBoxTypeTag = 'StatusType' AND ComboBoxText = 'Open'");

                       switch (dvAssetCollections.Count)
                       {
                           case 0:
                               data.Rows[i]["Processed"] = false;
                               data.Rows[i]["ProcessComments"] = "ERROR: There is no Status 'Open' found.  This record was not saved";

                               goto NextRecord;

                           case 1:
                               StatusTypeID = int.Parse(dvAssetCollections[0]["id"].ToString());

                               break;

                           default:
                               data.Rows[i]["Processed"] = false;
                               data.Rows[i]["ProcessComments"] = "ERROR: There is more than one Status 'Open' found.  This record was not saved";

                               goto NextRecord;
                       }

                       //Now we check to see if the referral has already been loaded
                       string[] optParms = new string[2];
                       optParms[0] = data.Rows[i]["REO ID"].ToString().Trim().Length == 0 ? null : data.Rows[i]["REO ID"].ToString();
                       optParms[1] = data.Rows[i]["FNMA Loan Number"].ToString().Trim().Length == 0 ? null : data.Rows[i]["FNMA Loan Number"].ToString();

                       DataTable ExistingReferral = new DataTable();
                       ExistingReferral = df.AssetCollections_SelectReferralID(referralTypeID, optParms);

                       DataView dvReferralTypes = new DataView(dtComboBoxValues);
                       dvReferralTypes.RowFilter = ("id = " + referralTypeID);

                       string referralType = dvReferralTypes[0]["ComboBoxText"].ToString();

                       //We need to make sure the referral is not closed
                       DataView dvExistingReferral = new DataView(ExistingReferral);
                       dvExistingReferral.RowFilter = ("ReferralTypeID = '" + referralTypeID + "' AND ReferralStatus <> 'Open'");
                       //dvExistingReferral.RowFilter = ("ReferralType = '" + referralType + "' AND ReferralStatus <> 'Open'");

                       SqlCommand cmd = new SqlCommand();
                       SqlParameter prm = new SqlParameter();

                       //Now we set a transaction for the Referral Import
                       tran = con.BeginTransaction();

                       int referralID = 0;

                       try
                       {
                           switch (referralType)
                           {
                               case "Advance Payment":
                                   cmd.CommandTimeout = Configuration.CommandTimeouts_Extra_ClaimsManagementSQLDatabase;
                                   cmd.CommandType = CommandType.StoredProcedure;
                                   cmd.CommandText = "usp_AssetColl_AdvPmtReferral_Import";
                                   cmd.Transaction = tran;

                                   prm = new SqlParameter("@REO_ID", data.Rows[i]["REO ID"].ToString().Trim().Length == 0 ? null : data.Rows[i]["REO ID"].ToString());
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@FNMA_LoanNumber", data.Rows[i]["FNMA Loan Number"].ToString().Trim().Length == 0 ? null : data.Rows[i]["FNMA Loan Number"].ToString());
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@ReferralTypeID", referralTypeID);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@ReferralDate", importAsDate);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@ServicerID", servicerBusinessEntityID);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@ServicerLoanNumber", data.Rows[i]["Servicer Loan Number"].ToString().Trim().Length == 0 ? null : data.Rows[i]["Servicer Loan Number"].ToString());
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@ServicerNumber", data.Rows[i]["Servicer Number"].ToString().Trim().Length == 0 ? null : data.Rows[i]["Servicer Number"].ToString());
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@PropertyState", data.Rows[i]["State"].ToString().Trim().Length == 0 ? null : data.Rows[i]["State"].ToString());
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@LastDisbursementDate", data.Rows[i]["Last Disbursement Date"]);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@DaysSinceLastDisbursement", data.Rows[i]["Days Aged From Last Disbursement"]);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@LoanStatus", data.Rows[i]["Loan Status"]);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@LoanStatusDate", data.Rows[i]["Loan Status Date"]);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@DaysSinceLoanStatus", data.Rows[i]["Days Aged From Loan Status Date"]);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@MonthsAged", data.Rows[i]["Months Aged         (MAX of Last Disb Date & Loan Status Date)"]);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@AgeBuckets", data.Rows[i]["Age Buckets                          (MAX of Last Disb Date & Lo"]);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@CurrentLPI_Date", data.Rows[i]["Current LPI"]);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@InsurerType", data.Rows[i]["Insurer Type"]);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@FCL_LossRiskCode", data.Rows[i]["FCL Loss Risk Code"]);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@DARTS_Flag", data.Rows[i]["DARTS Flag"]);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@TrueFNMA_GL", data.Rows[i]["True FNMA G/L"]);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@PrepNameOfDisbursement", data.Rows[i]["Preparer Name of Disbursement"]);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@PrepPhoneDisbursement", data.Rows[i]["Preparer Phone# of Disbursement"]);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@EnteredDate", DateTime.Now);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@EnteredByUserID", userUniqueID);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@LastUpdateDate", DateTime.Now);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@LastUpdateUserID", userUniqueID);
                                   cmd.Parameters.Add(prm);

                                   cmd.Connection = con;
                                   referralID = int.Parse(cmd.ExecuteScalar().ToString());

                                   if (referralID < 0)
                                   {
                                       data.Rows[i]["Processed"] = false;

                                       switch (referralID)
                                       {
                                           case -1000:
                                               data.Rows[i]["ProcessComments"] = "ERROR: ReferralID Not Initialized - Examine Referral Type.  This record was not saved";
                                               break;

                                           case -1001:
                                               data.Rows[i]["ProcessComments"] = "ERROR: Problem storing Referral record.  This record was not saved";
                                               break;

                                           case -3000:
                                               data.Rows[i]["ProcessComments"] = "ERROR: Unable to update the existing referral record (referral ID=" + referralID.ToString() + ").  This record was not saved";
                                               break;

                                           case -5000:
                                               data.Rows[i]["ProcessComments"] = "ERROR: Error looking up referral import comment ID.  This record was not saved";
                                               break;

                                           case -5001:
                                               data.Rows[i]["ProcessComments"] = "ERROR: Error inserting referral import comment.  This record was not saved";
                                               break;

                                           default:
                                               data.Rows[i]["ProcessComments"] = "ERROR: Return Value " + referralID.ToString() + " is not configured in Data Layer.  This record was not saved";
                                               break;
                                       }

                                       tran.Rollback();
                                       goto NextRecord;
                                   }

                                   else
                                   {
                                       //unique referral id was returned
                                       data.Rows[i]["Processed"] = true;
                                       data.Rows[i]["ProcessComments"] = "Record saved with Referral ID: " + referralID.ToString();

                                       if (ServicerAddedFlag)
                                       {
                                           data.Rows[i]["ProcessComments"] = "Servicer added and needs to be added to a group. " + data.Rows[i]["ProcessComments"].ToString();
                                       }

                                       tran.Commit();
                                       goto NextRecord;
                                   }
                                   break;
                               case "Datagram Penalty":
                                   cmd.CommandTimeout = Configuration.CommandTimeouts_Extra_ClaimsManagementSQLDatabase;
                                   cmd.CommandType = CommandType.StoredProcedure;
                                   cmd.CommandText = "Datagram.usp_DatagramReferral_Import";
                                   cmd.Transaction = tran;

                                   prm = new SqlParameter("@REO_ID", data.Rows[i]["REO ID"].ToString().Trim().Length == 0 ? null : data.Rows[i]["REO ID"].ToString());
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@FNMA_LoanNumber", data.Rows[i]["FNMA Loan Number"].ToString().Trim().Length == 0 ? null : data.Rows[i]["FNMA Loan Number"].ToString());
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@ReferralTypeID", referralTypeID);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@ReferralDate", importAsDate);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@ServicerID", servicerBusinessEntityID);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@ServicerLoanNumber", data.Rows[i]["Servicer Loan Number"].ToString().Trim().Length == 0 ? null : data.Rows[i]["Servicer Loan Number"].ToString());
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@PropertyState", data.Rows[i]["Property State"].ToString().Trim().Length == 0 ? null : data.Rows[i]["Property State"].ToString());
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@FCL_SaleDate", data.Rows[i]["FCL Date"].ToString().Trim().Length == 0 ? null : data.Rows[i]["FCL Date"].ToString());
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@FNMA_ReceivedDate", data.Rows[i]["Datagram Received Date"].ToString().Trim().Length == 0 ? null : data.Rows[i]["Datagram Received Date"].ToString());
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@NumberDaysBetween", data.Rows[i]["Datagram Days"].ToString().Trim().Length == 0 ? 0 : int.Parse(data.Rows[i]["Datagram Days"].ToString()));
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@TotalPenalty", data.Rows[i]["Datagram Penalty Amount"].ToString().Trim().Length == 0 ? 0 : decimal.Parse(data.Rows[i]["Datagram Penalty Amount"].ToString()));
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@ForgivenAmount", data.Rows[i]["Forgiven Amount"].ToString().Trim().Length == 0 ? 0 : decimal.Parse(data.Rows[i]["Forgiven Amount"].ToString()));
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@RequestedAmount", data.Rows[i]["Net Datagram Penalty Amount"].ToString().Trim().Length == 0 ? 0 : decimal.Parse(data.Rows[i]["Net Datagram Penalty Amount"].ToString()));
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@ReceivableAmount", data.Rows[i]["Receivable Amount"].ToString().Trim().Length == 0 ? 0 : decimal.Parse(data.Rows[i]["Receivable Amount"].ToString()));
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@ReceivableDate", data.Rows[i]["Receivable Date"].ToString().Trim().Length == 0 ? null : data.Rows[i]["Receivable Date"].ToString());
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@ReceivableAge", data.Rows[i]["Receivable Age"].ToString().Trim().Length == 0 ? 0 : int.Parse(data.Rows[i]["Receivable Age"].ToString()));
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@ReceivableStatus", data.Rows[i]["Receivable Status"].ToString().Trim().Length == 0 ? null : data.Rows[i]["Receivable Status"].ToString());
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@ReceivableWaivedIndicator", data.Rows[i]["Receivable Waived Indicator"].ToString().Trim().Length == 0 ? null : data.Rows[i]["Receivable Waived Indicator"].ToString());
                                   cmd.Parameters.Add(prm);

                                   // This field needs to have the data type defined explicitly in order for
                                   // the data conversion to occur properly. The majority of the records do not have
                                   // a value for this field. So, the Excel import process assumes the type to be string
                                   // from the first several rows of data (usually blank).
                                   if (data.Rows[i]["Receipt Amount"].ToString().Trim().Length == 0)
                                   {
                                       prm = new SqlParameter();
                                       prm.SqlDbType = System.Data.SqlDbType.Decimal;
                                       prm.ParameterName = "@ReceiptAmount";
                                       prm.SqlValue = DBNull.Value;
                                   }
                                   else
                                   {
                                       prm = new SqlParameter();
                                       prm.SqlDbType = System.Data.SqlDbType.Decimal;
                                       prm.ParameterName = "@ReceiptAmount";
                                       prm.SqlValue = Decimal.Parse(data.Rows[i]["Receipt Amount"].ToString().Replace(" ", ""), NumberStyles.AllowThousands | NumberStyles.AllowDecimalPoint | NumberStyles.AllowCurrencySymbol);
                                   }
                                   cmd.Parameters.Add(prm);

                                   if (data.Rows[i]["Receipt Date"].ToString().Trim().Length == 0)
                                   {
                                       prm = new SqlParameter("@ReceiptDate", DBNull.Value);
                                   }
                                   else
                                   {
                                       prm = new SqlParameter("@ReceiptDate", data.Rows[i]["Receipt Date"].ToString().Trim());
                                   }
                                   cmd.Parameters.Add(prm);

                                   prm = new SqlParameter("@DispositionStatus", data.Rows[i]["Disposition Status"].ToString().Trim().Length == 0 ? null : data.Rows[i]["Disposition Status"].ToString());
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@DispositionStatusDate", data.Rows[i]["Disposition Status Date"].ToString().Trim().Length == 0 ? null : data.Rows[i]["Disposition Status Date"].ToString());
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@DispositionAge", data.Rows[i]["Disposition Age"].ToString().Trim().Length == 0 ? 0 : int.Parse(data.Rows[i]["Disposition Age"].ToString()));
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@EnteredDate", DateTime.Now);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@EnteredByUserID", userUniqueID);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@LastUpdateDate", DateTime.Now);
                                   cmd.Parameters.Add(prm);
                                   prm = new SqlParameter("@LastUpdateUserID", userUniqueID);
                                   cmd.Parameters.Add(prm);

                                   cmd.Connection = con;
                                   referralID = int.Parse(cmd.ExecuteScalar().ToString());

                                   if (referralID < 0)
                                   {
                                       data.Rows[i]["Processed"] = false;

                                       switch (referralID)
                                       {
                                           case -1000:
                                               data.Rows[i]["ProcessComments"] = "ERROR: ReferralID Not Initialized - Examine Referral Type.  This record was not saved";
                                               break;

                                           case -1001:
                                               data.Rows[i]["ProcessComments"] = "ERROR: Problem storing Referral record.  This record was not saved";
                                               break;

                                           case -2000:
                                               data.Rows[i]["ProcessComments"] = "ERROR: Unspecified error updating existing referral record (referral ID=" + referralID.ToString() + ").  This record was not saved";
                                               break;

                                           case -2001:
                                               data.Rows[i]["ProcessComments"] = "ERROR: The 'Servicer Name' field doesn't match the existing Servicer Name (referral ID=" + referralID.ToString() + "). This record was not saved";
                                               break;

                                           case -2002:
                                               data.Rows[i]["ProcessComments"] = "ERROR: The 'Servicer Loan #' field doesn't match the existing Servicer Loan # (referral ID=" + referralID.ToString() + "). This record was not saved";
                                               break;

                                           case -2003:
                                               data.Rows[i]["ProcessComments"] = "ERROR: The 'Property State' field doesn't match the existing Property State (referral ID=" + referralID.ToString() + "). This record was not saved";
                                               break;

                                           case -2004:
                                               data.Rows[i]["ProcessComments"] = "ERROR: The 'FCL Sale Date' field doesn't match the existing FCL Sale Date (referral ID=" + referralID.ToString() + "). This record was not saved";
                                               break;

                                           case -2005:
                                               data.Rows[i]["ProcessComments"] = "ERROR: The 'Datagram Received Date' field doesn't match the existing Datagram Received Date (referral ID=" + referralID.ToString() + "). This record was not saved";
                                               break;

                                           case -2006:
                                               data.Rows[i]["ProcessComments"] = "ERROR: The 'Datagram Days' field doesn't match the existing Datagram Days (referral ID=" + referralID.ToString() + "). This record was not saved";
                                               break;

                                           case -2007:
                                               data.Rows[i]["ProcessComments"] = "ERROR: The 'Datagram Penalty Amount' field doesn't match the existing Datagram Penalty Amount (referral ID=" + referralID.ToString() + "). This record was not saved";
                                               break;

                                           case -2008:
                                               data.Rows[i]["ProcessComments"] = "ERROR: The 'Receivable Date' field doesn't match the existing Receivable Date (referral ID=" + referralID.ToString() + "). This record was not saved";
                                               break;

                                           case -2009:
                                               data.Rows[i]["ProcessComments"] = "ERROR: The 'Receivable Status' field doesn't match the existing Receivable Status (referral ID=" + referralID.ToString() + "). This record was not saved";
                                               break;

                                           case -2010:
                                               data.Rows[i]["ProcessComments"] = "ERROR: The 'Receivable Waived Indicator' field doesn't match the existing Receivable Waived Indicator (referral ID=" + referralID.ToString() + "). This record was not saved";
                                               break;

                                           case -2011:
                                               data.Rows[i]["ProcessComments"] = "ERROR: The 'Receipt Amount' field doesn't match the existing Receipt Amount (referral ID=" + referralID.ToString() + "). This record was not saved";
                                               break;

                                           case -2012:
                                               data.Rows[i]["ProcessComments"] = "ERROR: The 'Receipt Date' field doesn't match the existing Receipt Date (referral ID=" + referralID.ToString() + "). This record was not saved";
                                               break;

                                           case -3000:
                                               data.Rows[i]["ProcessComments"] = "ERROR: Unable to update the existing referral record (referral ID=" + referralID.ToString() + ").  This record was not saved";
                                               break;

                                           case -5000:
                                               data.Rows[i]["ProcessComments"] = "ERROR: Error looking up referral import comment ID.  This record was not saved";
                                               break;

                                           case -5001:
                                               data.Rows[i]["ProcessComments"] = "ERROR: Error inserting referral import comment.  This record was not saved";
                                               break;

                                           default:
                                               data.Rows[i]["ProcessComments"] = "ERROR: Return Value " + referralID.ToString() + " is not configured in Data Layer.  This record was not saved";
                                               break;
                                       }

                                       tran.Rollback();
                                       goto NextRecord;

                                   }

                                   else
                                   {
                                       //unique referral id was returned
                                       data.Rows[i]["Processed"] = true;
                                       data.Rows[i]["ProcessComments"] = "Record saved with Referral ID: " + referralID.ToString();

                                       if (ServicerAddedFlag)
                                       {
                                           data.Rows[i]["ProcessComments"] = "Servicer added and needs to be added to a group. " + data.Rows[i]["ProcessComments"].ToString();
                                       }

                                       tran.Commit();
                                       goto NextRecord;
                                   }
                                   break;
                               case "Hazard Ins. (HIP)":
                                   break;
                               default:
                                   break;
                           }


                       }

                       catch (Exception e)
                       {
                           data.Rows[i]["Processed"] = false;
                           data.Rows[i]["ProcessComments"] = "An error occurred while trying to insert this record.  This record was not saved";
                           tran.Rollback();
                           goto NextRecord;
                       }

                   NextRecord: ;
                       if ((((double)i + 1) / (double)rowCount) >= nextTarget)
                       {
                           nextTarget += .01;
                           events.OnRaiseImportStatusUpdateEvent();
                       }
                   }
               }

               data.AcceptChanges();
               return data;
           }

           catch (Exception ex)
           {
               throw ex;
           }

           finally
           {
               if (con.State != System.Data.ConnectionState.Closed)
               {
                   con.Close();
                   con.Dispose();
               }
           }
       }

       internal DataTable Import_AssetColl_Datagram(DataTable data, string importAsDate, int userUniqueID, Moss.Events.Events events, Settings settings)
       {
           double nextTarget = .01;
           SqlConnection con = new SqlConnection();

           try
           {
               int datagramImportID;

               DateTime? nullDate = null;
               decimal? nullDecimal = null;

               AddProcessColumns(data);

               con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
               con.Open();

               if (con.State == ConnectionState.Open)
               {
                   for (int i = 0; i < data.Rows.Count; i++)
                   {
                       datagramImportID = 0;

                       SqlCommand cmd = new SqlCommand();
                       SqlParameter prm = new SqlParameter();

                       cmd.CommandTimeout = Configuration.CommandTimeouts_Extra_ClaimsManagementSQLDatabase;
                       cmd.CommandType = CommandType.StoredProcedure;
                       cmd.CommandText = "Datagram.usp_Datagram_Referral_Import";

                       prm = new SqlParameter("@REO_ID", data.Rows[i]["REO#"].ToString().Trim().Length == 0 ?
                                               null : data.Rows[i]["REO#"].ToString());
                       cmd.Parameters.Add(prm);

                       prm = new SqlParameter("@FNMA_LoanNumber", data.Rows[i]["FNMA Loan#"].ToString().Trim().Length == 0 ?
                                               null : data.Rows[i]["FNMA Loan#"].ToString());
                       cmd.Parameters.Add(prm);

                       prm = new SqlParameter("@ServicerName", data.Rows[i]["Servicer Name"].ToString().Trim().Length == 0 ?
                                               null : data.Rows[i]["Servicer Name"].ToString());
                       cmd.Parameters.Add(prm);

                       prm = new SqlParameter("@ServicerLoanNumber", data.Rows[i]["Servicer Loan#"].ToString().Trim().Length == 0 ?
                                               null : data.Rows[i]["Servicer Loan#"].ToString());
                       cmd.Parameters.Add(prm);

                       prm = new SqlParameter("@PropertyState", data.Rows[i]["Property State"].ToString().Trim().Length == 0 ?
                                               null : data.Rows[i]["Property State"].ToString());
                       cmd.Parameters.Add(prm);

                       prm = new SqlParameter("@FCL_SaleDate", data.Rows[i]["Fcl Date"].ToString().Trim().Length == 0 ?
                                               nullDate : ExcelSerialToDate(data.Rows[i]["Fcl Date"].ToString()));
                       cmd.Parameters.Add(prm);

                       prm = new SqlParameter("@FNMA_ReceivedDate", data.Rows[i]["Datagram Received Date"].ToString().Trim().Length == 0 ?
                                               nullDate : ExcelSerialToDate(data.Rows[i]["Datagram Received Date"].ToString()));
                       cmd.Parameters.Add(prm);

                       prm = new SqlParameter("@NumberDaysBetween", data.Rows[i]["Datagram Days"].ToString().Trim().Length == 0 ?
                                               0 : int.Parse(data.Rows[i]["Datagram Days"].ToString()));
                       cmd.Parameters.Add(prm);

                       prm = new SqlParameter("@TotalPenalty", data.Rows[i]["Datagram Penalty Amount"].ToString().Trim().Length == 0 ?
                                               0 : decimal.Parse(data.Rows[i]["Datagram Penalty Amount"].ToString()));
                       cmd.Parameters.Add(prm);

                       prm = new SqlParameter("@ForgivenAmount", data.Rows[i]["Forgiven Amount"].ToString().Trim().Length == 0 ?
                                               0 : decimal.Parse(data.Rows[i]["Forgiven Amount"].ToString()));
                       cmd.Parameters.Add(prm);

                       prm = new SqlParameter("@RequestedAmount", data.Rows[i]["Net Datagram Penalty Amount"].ToString().Trim().Length == 0 ?
                                               0 : decimal.Parse(data.Rows[i]["Net Datagram Penalty Amount"].ToString()));
                       cmd.Parameters.Add(prm);

                       prm = new SqlParameter("@ReceivableAmount", data.Rows[i]["Receivable Amount"].ToString().Trim().Length == 0 ?
                                               0 : decimal.Parse(data.Rows[i]["Receivable Amount"].ToString()));
                       cmd.Parameters.Add(prm);

                       prm = new SqlParameter("@ReceivableDate", data.Rows[i]["Receivable Date"].ToString().Trim().Length == 0 ?
                                               nullDate : ExcelSerialToDate(data.Rows[i]["Receivable Date"].ToString()));
                       cmd.Parameters.Add(prm);

                       prm = new SqlParameter("@ReceivableAge", data.Rows[i]["Receivable Age"].ToString().Trim().Length == 0 ?
                                               0 : int.Parse(data.Rows[i]["Receivable Age"].ToString()));
                       cmd.Parameters.Add(prm);

                       prm = new SqlParameter("@ReceivableStatus", data.Rows[i]["Receivable Status"].ToString().Trim().Length == 0 ?
                                               null : data.Rows[i]["Receivable Status"].ToString());
                       cmd.Parameters.Add(prm);

                       prm = new SqlParameter("@ReceivableWaivedIndicator", data.Rows[i][" Receivable Waived Indicator"].ToString().Trim().Length == 0 ?
                                               null : data.Rows[i][" Receivable Waived Indicator"].ToString());
                       cmd.Parameters.Add(prm);

                       prm = new SqlParameter("@ReceiptAmount", data.Rows[i]["Receipt Amount"].ToString().Trim().Length == 0 ?
                                               nullDecimal : decimal.Parse(data.Rows[i]["Receipt Amount"].ToString()));
                       cmd.Parameters.Add(prm);

                       prm = new SqlParameter("@ReceiptDate", data.Rows[i]["Receipt Date"].ToString().Trim().Length == 0 ?
                                               nullDate : ExcelSerialToDate(data.Rows[i]["Receipt Date"].ToString()));
                       cmd.Parameters.Add(prm);

                       prm = new SqlParameter("@DispositionStatus", data.Rows[i]["Disposition Status"].ToString().Trim().Length == 0 ?
                                               null : data.Rows[i]["Disposition Status"].ToString());
                       cmd.Parameters.Add(prm);

                       prm = new SqlParameter("@DispositionStatusDate", data.Rows[i]["Disposition Status Date"].ToString().Trim().Length == 0 ?
                                               nullDate : ExcelSerialToDate(data.Rows[i]["Disposition Status Date"].ToString()));
                       cmd.Parameters.Add(prm);

                       prm = new SqlParameter("@DispositionAge", data.Rows[i]["Disposition Age"].ToString().Trim().Length == 0 ?
                                               0 : int.Parse(data.Rows[i]["Disposition Age"].ToString()));
                       cmd.Parameters.Add(prm);

                       cmd.Connection = con;
                       datagramImportID = int.Parse(cmd.ExecuteScalar().ToString());

                       data.Rows[i]["Processed"] = true;
                       data.Rows[i]["ProcessComments"] = "Record saved with Datagram Import ID: " + datagramImportID.ToString();


                       if ((((double)i + 1) / (double)data.Rows.Count) >= nextTarget)
                       {
                           nextTarget += .01;
                           events.OnRaiseImportStatusUpdateEvent();
                       }

                   }

               }

               data.AcceptChanges();

               return data;

           }

           catch (Exception ex)
           {
               throw ex;

           }

           finally
           {
               if (con.State != System.Data.ConnectionState.Closed)
               {
                   con.Close();
                   con.Dispose();
               }
           }

       }

       /// <summary>
       /// 
       /// </summary>
       /// <param name="dt"></param>
       /// <returns></returns>
       private DataTable AddProcessColumns(DataTable dt)
       {
           try
           {
               DataColumn dc = new DataColumn();

               if (!dt.Columns.Contains("Processed"))
               {
                   dc = new DataColumn();
                   dc.ColumnName = "Processed";
                   dc.DataType = typeof(bool);
                   dc.DefaultValue = false;
                   dt.Columns.Add(dc);

               }

               if (!dt.Columns.Contains("ProcessComments"))
               {
                   dc = new DataColumn();
                   dc.ColumnName = "ProcessComments";
                   dc.DataType = typeof(string);
                   dc.DefaultValue = "Not Processed";
                   dt.Columns.Add(dc);

               }

               dt.AcceptChanges();

               return dt;

           }

           catch (Exception ex)
           {
               throw ex;

           }

       }

       /// <summary>
       /// Performs Excel-like DateTime math and returns the DateTime
       /// </summary>
       /// <param name="valueToConvert">a text string that is to be converted into a DateTime</param>
       /// <returns>The converted DateTime value</returns>
       private DateTime ExcelSerialToDate(string valueToConvert)
       {
           try
           {
               //An Excel date serial value has two components:
               //The whole number portion (to the left of the decimal point) is the number of days past 1/1/1900
               //The decimal portion is a fractional portion of a full day
               //NOTE: There is also a known set of bugs with doing this
               //Lotus had a bug that allowed 2/29/1900 as a valid date, which Excel duplicated for "compatibility" reasons
               //Also, the anchor date has to be 12/31/1899 as long as the 
               //See discussion at: http://stackoverflow.com/questions/727466/how-do-i-convert-an-excel-serial-date-number-to-a-net-datetime
               //A better method is presented there and is much simpler:  DateTime.FromOADate(double)
               //We'll use that instead

               DateTime rtnValue = DateTime.FromOADate(double.Parse(valueToConvert));

               return rtnValue;

           }

           catch (Exception ex)
           {
               throw ex;

           }

       }

       #endregion


       /// <summary>
       /// Cleans codes such as (70) from the tail end of an imported text string.
       /// This is primarily for the FNMA EOB Reconciliation referral imports, but
       /// may be useful for other processes as well.
       /// </summary>
       /// <param name="SuppliedString">The string to be cleansed of paranthetical codes</param>
       /// <returns>The original string - minus any digit codes enclosed in parenthesis, and the surrounding spaces.</returns>
       internal string ReplaceParantheticalString(string SuppliedString)
       {
           try
           {
               string CleanedString = "";

               //This is a regular expression pattern that is looking for digit codes enclosed in parenthesis
               //example:   Some String Text (01)
               //We need to remove the (01) as well as surrounding space characters
               //string pattern = "/x20+/x28/d{*}/x29/x20*$";
               string pattern = " *\\(*\\d*\\)* *$";
               string replacement = "";

               CleanedString = Regex.Replace(SuppliedString, pattern, replacement);

               return CleanedString;

           }

           catch (Exception ex)
           {
               throw ex;

           }

       }

       #region "Asset Collections Datagram"
       /// <summary>
       /// TEMP ROUTINE TO FETCH IMPORTED REFERRALS
       /// This will become the routine to fetch an import batch.
       /// </summary>
       /// <param name="settings">Contains the database connection information which determines
       /// whether we're working with Development, Test, Production, etc.</param>
       /// <returns>Data table containing data import referral records.</returns>
       internal DataTable AssetColl_Datagram_InvoiceData_Get(Settings settings)
       {
           SqlConnection con = new SqlConnection();

           try
           {
               con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
               con.Open();
           }

           catch (Exception e)
           {
               throw e;
           }

           try
           {
               DataTable dt = new DataTable("DG_InvoiceData");
               DataColumn dc = new DataColumn();

               dt.Columns.Add("Referral ID", typeof(int));
               dt.Columns.Add("GroupName", typeof(string));
               dt.Columns.Add("Servicer Name", typeof(string));
               dt.Columns.Add("REO #", typeof(string));
               dt.Columns.Add("FNMA Loan #", typeof(string));
               dt.Columns.Add("Servicer Loan #", typeof(string));
               dt.Columns.Add("FCL Date", typeof(DateTime)).AllowDBNull = true;
               dt.Columns.Add("Datagram Received Date", typeof(DateTime)).AllowDBNull = true;
               dt.Columns.Add("Datagram Days", typeof(string));
               dt.Columns.Add("Net Datagram Fee Amount", typeof(decimal));
               dt.Columns.Add("Initial Billing Date", typeof(DateTime)).AllowDBNull = true;
               dt.Columns.Add("Rebuttal Affirmation Date", typeof(DateTime)).AllowDBNull = true;
               dt.Columns.Add("Due Date", typeof(DateTime)).AllowDBNull = true;
               dt.Columns.Add("Number of Days Past Due Date", typeof(int)).AllowDBNull = true;
               dt.Columns.Add("60 Days Outstanding from Due Date", typeof(string));
               dt.Columns.Add("90 Days Outstanding from Due Date", typeof(string));
               dt.Columns.Add("FNMA Comments", typeof(string));
               dt.Columns.Add("Date of Last FNMA Comment", typeof(DateTime)).AllowDBNull = true;
               dt.Columns.Add("Servicer Comments", typeof(string));
               dt.Columns.Add("Date of Last Servicer Comment", typeof(DateTime)).AllowDBNull = true;
               dt.Columns.Add("Status of Invoice", typeof(string));
               dt.Columns.Add("Processed", typeof(bool));

               SqlCommand cmd = new SqlCommand();
               cmd.CommandType = System.Data.CommandType.StoredProcedure;
               cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

               cmd.CommandText = "Datagram.usp_Datagram_InvoiceData_Select";
               cmd.Connection = con;

               SqlDataReader dr = cmd.ExecuteReader();
               while (dr.Read())
               {
                   DataRow row = dt.NewRow();

                   row["Referral ID"] = int.Parse(dr["DatagramReferralID"].ToString().Length == 0 ? "0" : dr["DatagramReferralID"].ToString());
                   row["GroupName"] = dr["GroupName"].ToString();
                   row["Servicer Name"] = dr["ServicerName"].ToString();
                   row["REO #"] = dr["REO_ID"].ToString();
                   row["FNMA Loan #"] = dr["FNMA_LoanNumber"].ToString();
                   row["Servicer Loan #"] = dr["ServicerLoanNumber"].ToString();
                   row["FCL Date"] = DateTime.Parse(dr["FCL_SaleDate"].ToString().Length == 0 ? "1/1/1900" : dr["FCL_SaleDate"].ToString());
                   row["Datagram Received Date"] = DateTime.Parse(dr["FNMA_ReceivedDate"].ToString().Length == 0 ? "1/1/1900" : dr["FNMA_ReceivedDate"].ToString());
                   row["Datagram Days"] = dr["NumberDaysBetween"].ToString();
                   row["Net Datagram Fee Amount"] = decimal.Parse(dr["Balance"].ToString().Length == 0 ? "0.0" : dr["Balance"].ToString());
                   row["Initial Billing Date"] = DateTime.Parse(dr["InitialBillingDate"].ToString().Length == 0 ? "1/1/1900" : dr["InitialBillingDate"].ToString());
                   row["Rebuttal Affirmation Date"] = DateTime.Parse(dr["RebuttalAffirmationDate"].ToString().Length == 0 ? "1/1/1900" : dr["RebuttalAffirmationDate"].ToString());
                   row["Due Date"] = DateTime.Parse(dr["DueDate"].ToString().Length == 0 ? "1/1/1900" : dr["DueDate"].ToString());
                   row["Number of Days Past Due Date"] = int.Parse(dr["DaysPastDueDate"].ToString().Length == 0 ? "0" : dr["DaysPastDueDate"].ToString());
                   row["60 Days Outstanding from Due Date"] = dr["SixtyDaysOutstanding"].ToString();
                   row["90 Days Outstanding from Due Date"] = dr["NinetyDaysOutstanding"].ToString();
                   row["FNMA Comments"] = dr["FNMAComments"].ToString();
                   row["Date of Last FNMA Comment"] = DateTime.Parse(dr["LastFNMACommentDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastFNMACommentDate"].ToString());
                   row["Servicer Comments"] = dr["ServicerComments"].ToString();
                   row["Date of Last Servicer Comment"] = DateTime.Parse(dr["LastServicerCommentDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastServicerCommentDate"].ToString());
                   row["Status of Invoice"] = string.Empty;
                   row["Processed"] = false;

                   dt.Rows.Add(row);
               }

               dt.AcceptChanges();
               return dt;
           }

           catch (Exception ex)
           {
               throw ex;
           }

           finally
           {
               if (con.State != System.Data.ConnectionState.Closed)
               {
                   con.Close();
                   con.Dispose();
               }
           }
       }

       /// <summary>
       /// A routine to retrieve all group invoice summary data for inclusion on the invoce
       /// on the summary tab added for the 2/2013 servicer invoicing iteration
       /// </summary>
       /// <param name="settings">Environment settings</param>
       /// <returns>Table of summarized invoice data</returns>
       internal DataTable AssetColl_Datagram_InvoiceSummary_Get(Settings settings)
       {
           SqlConnection con = new SqlConnection();

           try
           {
               con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
               con.Open();

           }

           catch (Exception e)
           {
               throw e;

           }

           try
           {

               DataTable dt = new DataTable("DatagramReferral");
               DataColumn dc = new DataColumn();

               dt.Columns.Add("ReferralDate", typeof(DateTime));
               dt.Columns.Add("GroupName", typeof(string));
               dt.Columns.Add("Summary Date", typeof(string));
               dt.Columns.Add("Original Invoiced Amount", typeof(decimal));
               dt.Columns.Add("Paid", typeof(decimal));
               dt.Columns.Add("Rescinded", typeof(decimal));
               dt.Columns.Add("Remaining Amount Due", typeof(decimal));
               dt.Columns.Add("Pending Rescissions/Reductions", typeof(decimal));

               SqlCommand cmd = new SqlCommand();
               cmd.CommandType = System.Data.CommandType.StoredProcedure;
               cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

               cmd.CommandText = "Datagram.usp_Datagram_InvoiceSummary_Select";
               cmd.Connection = con;

               SqlDataReader dr = cmd.ExecuteReader();
               while (dr.Read())
               {
                   DataRow row = dt.NewRow();

                   row["ReferralDate"] = DateTime.Parse(dr["ReferralDate"].ToString().Length == 0 ? "1/1/1900" : dr["ReferralDate"].ToString());
                   row["GroupName"] = dr["GroupName"].ToString();
                   row["Summary Date"] = dr["SummaryDate"].ToString();
                   row["Original Invoiced Amount"] = decimal.Parse(dr["OriginalInvoicedAmount"].ToString().Length == 0 ? "0.00" : dr["OriginalInvoicedAmount"].ToString());
                   row["Paid"] = decimal.Parse(dr["Paid"].ToString().Length == 0 ? "0.00" : dr["Paid"].ToString());
                   row["Rescinded"] = decimal.Parse(dr["Rescinded"].ToString().Length == 0 ? "0.00" : dr["Rescinded"].ToString());
                   row["Remaining Amount Due"] = decimal.Parse(dr["RemainingAmountDue"].ToString().Length == 0 ? "0.00" : dr["RemainingAmountDue"].ToString());
                   row["Pending Rescissions/Reductions"] = decimal.Parse(dr["PendingRecissionsReductions"].ToString().Length == 0 ? "0.00" : dr["PendingRecissionsReductions"].ToString());

                   dt.Rows.Add(row);

               }

               dt.AcceptChanges();
               return dt;

           }

           catch (Exception ex)
           {
               throw ex;

           }


           finally
           {
               if (con.State != System.Data.ConnectionState.Closed)
               {
                   con.Close();
                   con.Dispose();

               }

           }

       }

       /// <summary>
       /// 
       /// </summary>
       /// <param name="data"></param>
       /// <param name="settings"></param>
       /// <returns></returns>
       internal bool AssetColl_Datagram_InvoiceUpdate(DataTable data, Settings settings)
       {
           SqlConnection con = new SqlConnection();

           try
           {
               con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
               con.Open();
           }

           catch (Exception e)
           {
               throw e;
           }

           try
           {
               SqlParameter parm = new SqlParameter();
               int recordsAffected;

               for (int i = 0; i < data.Rows.Count; i++)
               {
                   SqlCommand cmd = new SqlCommand();
                   cmd.CommandType = System.Data.CommandType.StoredProcedure;
                   cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                   cmd.Connection = con;

                   cmd.CommandText = "Datagram.usp_Datagram_UpdateInvoicing";

                   parm = new SqlParameter("@DatagramReferralID", data.Rows[i]["Referral ID"]);
                   cmd.Parameters.Add(parm);
                   parm = new SqlParameter("@Invoiced", data.Rows[i]["Invoiced"]);
                   cmd.Parameters.Add(parm);
                   parm = new SqlParameter("@InvoiceDate", data.Rows[i]["InvoiceDate"]);
                   cmd.Parameters.Add(parm);
                   parm = new SqlParameter("@LastUpdateDate", data.Rows[i]["LastUpdateDate"]);
                   cmd.Parameters.Add(parm);
                   parm = new SqlParameter("@LastUpdateUserID", data.Rows[i]["LastUpdateUserID"]);
                   cmd.Parameters.Add(parm);

                   recordsAffected = cmd.ExecuteNonQuery();

               }

               data.AcceptChanges();
               return true;

           }

           catch (Exception ex)
           {
               throw ex;

           }


           finally
           {
               if (con.State != System.Data.ConnectionState.Closed)
               {
                   con.Close();
                   con.Dispose();

               }

           }

       }

       /// <summary>
       /// Retrieves all table data for the DatagramReferral table. Some additional columns
       /// are included for the string translation of ID lookup values.
       /// </summary>
       /// <param name="referralID">The PK referral ID of interest.</param>
       /// <param name="settings">Database connection information</param>
       /// <returns>A table with a single row containing the DatagramReferral data.</returns>
       internal DataTable AssetColl_DatagramReferral_Get(int datagramReferralID, Settings settings)
       {
           SqlConnection con = new SqlConnection();

           try
           {
               con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
               con.Open();
           }

           catch (Exception e)
           {
               throw e;
           }

           try
           {
               DataTable dt = new DataTable("DatagramReferral");
               DataColumn dc = new DataColumn();

               dt.Columns.Add("DatagramReferralID", typeof(int));
               dt.Columns.Add("REO ID", typeof(string));
               dt.Columns.Add("FNMA Loan Number", typeof(string));
               dt.Columns.Add("Referral Type", typeof(string));
               dt.Columns.Add("ReferralTypeID", typeof(int));
               dt.Columns.Add("Referral Date", typeof(DateTime));
               dt.Columns.Add("Servicer Name", typeof(string));
               dt.Columns.Add("ServicerID", typeof(int));
               dt.Columns.Add("Servicer Loan Number", typeof(string));
               dt.Columns.Add("Property State", typeof(string));
               dt.Columns.Add("FCL Sale Date", typeof(DateTime));
               dt.Columns.Add("FNMA Received Date", typeof(DateTime));
               dt.Columns.Add("Number Days Between", typeof(int));
               dt.Columns.Add("Total Penalty", typeof(decimal));
               dt.Columns.Add("Forgiven Amount", typeof(decimal));
               dt.Columns.Add("Requested Amount", typeof(decimal));
               dt.Columns.Add("Receivable Amount", typeof(decimal));
               dt.Columns.Add("Receivable Date", typeof(DateTime));
               dt.Columns.Add("Receivable Age", typeof(int));
               dt.Columns.Add("Receivable Status", typeof(string));
               dt.Columns.Add("Receivable Waived Indicator", typeof(string));
               dt.Columns.Add("Receipt Amount", typeof(decimal));
               dt.Columns.Add("Receipt Date", typeof(DateTime));
               dt.Columns.Add("Disposition Status", typeof(string));
               dt.Columns.Add("Disposition Status Date", typeof(DateTime));
               dt.Columns.Add("Disposition Age", typeof(int));
               dt.Columns.Add("Waived Amount", typeof(decimal));
               dt.Columns.Add("Waived Amount Date", typeof(DateTime));
               dt.Columns.Add("Estimated Receipt Date", typeof(DateTime));
               //dt.Columns.Add("TRAX Waive Code", typeof(string));
               //dt.Columns.Add("TRAX_WaiveCodeID", typeof(int));
               dt.Columns.Add("DatagramStatus", typeof(string));
               dt.Columns.Add("DatagramStatusID", typeof(int));
               dt.Columns.Add("Imported", typeof(bool));
               dt.Columns.Add("Import Date", typeof(DateTime));
               dt.Columns.Add("Invoiced", typeof(bool));
               dt.Columns.Add("InvoiceDate", typeof(DateTime));
               dt.Columns.Add("EnteredDate", typeof(DateTime));
               dt.Columns.Add("EnteredByUser", typeof(string));
               dt.Columns.Add("EnteredByUserID", typeof(int));
               dt.Columns.Add("LastUpdateDate", typeof(DateTime));
               dt.Columns.Add("LastUpdateUser", typeof(string));
               dt.Columns.Add("LastUpdateUserID", typeof(int));
               // fb9628 20141219 gk
               dt.Columns.Add("InvoiceStatusID", typeof(int));
               //fb45113 20170412 mjf
               dt.Columns.Add("ResponsiblePartyServicerNumber", typeof(string));
               dt.Columns.Add("deltaCheck", typeof(string));

               SqlCommand cmd = new SqlCommand();
               cmd.CommandType = System.Data.CommandType.StoredProcedure;
               cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

               SqlParameter parm = new SqlParameter("@DatagramReferralID", datagramReferralID);
               cmd.Parameters.Add(parm);

               cmd.CommandText = "Datagram.usp_DatagramReferral_Select";
               cmd.Connection = con;

               SqlDataReader dr = cmd.ExecuteReader();
               while (dr.Read())
               {
                   DataRow row = dt.NewRow();

                   row["DatagramReferralID"] = int.Parse(dr["DatagramReferralID"].ToString().Length == 0 ? "0" : dr["DatagramReferralID"].ToString());
                   row["REO ID"] = dr["REO_ID"].ToString();
                   row["FNMA Loan Number"] = dr["FNMA_LoanNumber"].ToString();
                   row["Referral Type"] = dr["ReferralType"].ToString();
                   row["ReferralTypeID"] = int.Parse(dr["ReferralTypeID"].ToString().Length == 0 ? "0" : dr["ReferralTypeID"].ToString());
                   row["Referral Date"] = DateTime.Parse(dr["ReferralDate"].ToString().Length == 0 ? "1/1/1900" : dr["ReferralDate"].ToString());
                   row["Servicer Name"] = dr["ServicerName"].ToString();
                   row["ServicerID"] = int.Parse(dr["ServicerID"].ToString().Length == 0 ? "0" : dr["ServicerID"].ToString());
                   row["Servicer Loan Number"] = dr["ServicerLoanNumber"].ToString();
                   row["Property State"] = dr["PropertyState"].ToString();
                   row["FCL Sale Date"] = DateTime.Parse(dr["FCL_SaleDate"].ToString().Length == 0 ? "1/1/1900" : dr["FCL_SaleDate"].ToString());
                   row["FNMA Received Date"] = DateTime.Parse(dr["FNMA_ReceivedDate"].ToString().Length == 0 ? "1/1/1900" : dr["FNMA_ReceivedDate"].ToString());
                   row["Number Days Between"] = int.Parse(dr["NumberDaysBetween"].ToString().Length == 0 ? "0" : dr["NumberDaysBetween"].ToString());
                   row["Total Penalty"] = decimal.Parse(dr["TotalPenalty"].ToString().Length == 0 ? "0.0" : dr["TotalPenalty"].ToString());
                   row["Forgiven Amount"] = decimal.Parse(dr["ForgivenAmount"].ToString().Length == 0 ? "0.0" : dr["ForgivenAmount"].ToString());
                   row["Requested Amount"] = decimal.Parse(dr["RequestedAmount"].ToString().Length == 0 ? "0.0" : dr["RequestedAmount"].ToString());
                   row["Receivable Amount"] = decimal.Parse(dr["ReceivableAmount"].ToString().Length == 0 ? "0.0" : dr["ReceivableAmount"].ToString());
                   row["Receivable Date"] = DateTime.Parse(dr["ReceivableDate"].ToString().Length == 0 ? "1/1/1900" : dr["ReceivableDate"].ToString());
                   row["Receivable Age"] = int.Parse(dr["ReceivableAge"].ToString().Length == 0 ? "0" : dr["ReceivableAge"].ToString());
                   row["Receivable Status"] = dr["ReceivableStatus"].ToString();
                   row["Receivable Waived Indicator"] = dr["ReceivableWaivedIndicator"].ToString();
                   row["Receipt Amount"] = decimal.Parse(dr["ReceiptAmount"].ToString().Length == 0 ? "0.0" : dr["ReceiptAmount"].ToString());
                   row["Receipt Date"] = DateTime.Parse(dr["ReceiptDate"].ToString().Length == 0 ? "1/1/1900" : dr["ReceiptDate"].ToString());
                   row["Disposition Status"] = dr["DispositionStatus"].ToString();
                   row["Disposition Status Date"] = DateTime.Parse(dr["DispositionStatusDate"].ToString().Length == 0 ? "1/1/1900" : dr["DispositionStatusDate"].ToString());
                   row["Disposition Age"] = int.Parse(dr["DispositionAge"].ToString().Length == 0 ? "0" : dr["DispositionAge"].ToString());
                   row["Waived Amount"] = decimal.Parse(dr["WaivedAmount"].ToString().Length == 0 ? "0.0" : dr["WaivedAmount"].ToString());
                   row["Waived Amount Date"] = DateTime.Parse(dr["WaivedAmountDate"].ToString().Length == 0 ? "1/1/1900" : dr["WaivedAmountDate"].ToString());
                   row["Estimated Receipt Date"] = DateTime.Parse(dr["EstimatedReceiptDate"].ToString().Length == 0 ? "1/1/1900" : dr["EstimatedReceiptDate"].ToString());
                   //MJF FB 45210
                   //row["TRAX Waive Code"] = dr["TRAX_WaiveCode"].ToString();
                   //row["TRAX_WaiveCodeID"] = int.Parse(dr["TRAX_WaiveCodeID"].ToString().Length == 0 ? "0" : dr["TRAX_WaiveCodeID"].ToString());
                   row["DatagramStatus"] = dr["DatagramStatus"].ToString();
                   row["DatagramStatusID"] = int.Parse(dr["DatagramStatusID"].ToString().Length == 0 ? "0" : dr["DatagramStatusID"].ToString());
                   row["Imported"] = bool.Parse(dr["Imported"].ToString().Length == 0 ? "false" : dr["Imported"].ToString());
                   row["Import Date"] = DateTime.Parse(dr["ImportDate"].ToString().Length == 0 ? "1/1/1900" : dr["ImportDate"].ToString());
                   row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                   row["EnteredByUser"] = dr["EnteredByUser"].ToString();
                   row["EnteredByUserID"] = int.Parse(dr["EnteredByUserID"].ToString().Length == 0 ? "0" : dr["EnteredByUserID"].ToString());
                   row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                   row["LastUpdateUser"] = dr["LastUpdateUser"].ToString();
                   row["LastUpdateUserID"] = int.Parse(dr["LastUpdateUserID"].ToString().Length == 0 ? "0" : dr["LastUpdateUserID"].ToString());
                   // fb9628 20141219 gk
                   row["InvoiceStatusID"] = int.Parse(dr["InvoiceStatusID"].ToString().Length == 0 ? "0" : dr["InvoiceStatusID"].ToString());
                   //fb45113 20170412 mjf
                   row["ResponsiblePartyServicerNumber"] = dr["ResponsiblePartyServicerNumber"].ToString();
                   row["deltaCheck"] = dr["deltaCheck"].ToString();

                   dt.Rows.Add(row);
               }

               dt.AcceptChanges();
               return dt;
           }

           catch (Exception ex)
           {
               throw ex;
           }

           finally
           {
               if (con.State != System.Data.ConnectionState.Closed)
               {
                   con.Close();
                   con.Dispose();
               }
           }
       }

       /// <summary>
       /// Saves data for the DatagramReferral record via the Datagram update 
       /// stored procedure.
       /// </summary>
       /// <param name="data">Table of data for the Datagram referral record.</param>
       /// <param name="settings">Database connection information</param>
       /// <returns>Boolean indicator of success for failure.</returns>
       internal bool AssetColl_Datagram_Save(DataTable data, Settings settings)
       {
           SqlConnection con = new SqlConnection();

           try
           {
               con.ConnectionString = settings.GetConnectionString("AppsDB_FNMA");
               con.Open();
           }
           catch (Exception e)
           {
               throw e;
           }

           try
           {
               SqlParameter parm = new SqlParameter();
               int recordsAffected;

               for (int i = 0; i < data.Rows.Count; i++)
               {
                   SqlCommand cmd = new SqlCommand();
                   cmd.CommandType = System.Data.CommandType.StoredProcedure;
                   cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                   cmd.Connection = con;

                   switch (data.Rows[i].RowState)
                   {
                       case DataRowState.Modified:
                           cmd.CommandText = "Datagram.usp_DatagramReferral_Update";

                           parm = new SqlParameter("@DatagramReferralID", data.Rows[i]["DatagramReferralID"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@REO_ID", data.Rows[i]["REO ID"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@FNMA_LoanNumber", data.Rows[i]["FNMA Loan Number"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@ReferralTypeID", data.Rows[i]["ReferralTypeID"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@ReferralDate", data.Rows[i]["Referral Date"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@ServicerID", data.Rows[i]["ServicerID"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@ServicerLoanNumber", data.Rows[i]["Servicer Loan Number"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@PropertyState", data.Rows[i]["Property State"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@FCL_SaleDate", data.Rows[i]["FCL Sale Date"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@FNMA_ReceivedDate", data.Rows[i]["FNMA Received Date"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@NumberDaysBetween", data.Rows[i]["Number Days Between"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@TotalPenalty", data.Rows[i]["Total Penalty"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@ForgivenAmount", data.Rows[i]["Forgiven Amount"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@RequestedAmount", data.Rows[i]["Requested Amount"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@ReceivableAmount", data.Rows[i]["Receivable Amount"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@ReceivableDate", data.Rows[i]["Receivable Date"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@ReceivableAge", data.Rows[i]["Receivable Age"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@ReceivableStatus", data.Rows[i]["Receivable Status"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@ReceivableWaivedIndicator", data.Rows[i]["Receivable Waived Indicator"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@ReceiptAmount", data.Rows[i]["Receipt Amount"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@ReceiptDate", data.Rows[i]["Receipt Date"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@DispositionStatus", data.Rows[i]["Disposition Status"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@DispositionStatusDate", data.Rows[i]["Disposition Status Date"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@DispositionAge", data.Rows[i]["Disposition Age"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@WaivedAmount", data.Rows[i]["Waived Amount"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@WaivedAmountDate", data.Rows[i]["Waived Amount Date"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@EstimatedReceiptDate", data.Rows[i]["Estimated Receipt Date"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@DatagramStatusID", data.Rows[i]["DatagramStatusID"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@Imported", data.Rows[i]["Imported"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@ImportDate", data.Rows[i]["Import Date"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@Invoiced", data.Rows[i]["Invoiced"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@InvoiceDate", data.Rows[i]["InvoiceDate"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@EnteredDate", data.Rows[i]["EnteredDate"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@EnteredByUserID", data.Rows[i]["EnteredByUserID"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@LastUpdateDate", data.Rows[i]["LastUpdateDate"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@LastUpdateUserID", data.Rows[i]["LastUpdateUserID"]);
                           cmd.Parameters.Add(parm);
                           // fb9628 20141219 gk
                           parm = new SqlParameter("@InvoiceStatusID", data.Rows[i]["InvoiceStatusID"]);
                           cmd.Parameters.Add(parm);
                           //fb45113 20170412 mjf
                           parm = new SqlParameter("@ResponsiblePartyServicerNumber", data.Rows[i]["ResponsiblePartyServicerNumber"]);
                           cmd.Parameters.Add(parm);
                           parm = new SqlParameter("@deltaCheck", data.Rows[i]["deltaCheck"]);
                           cmd.Parameters.Add(parm);

                           break;

                       default:
                           goto NextRecord;
                   }
                   recordsAffected = cmd.ExecuteNonQuery();

               NextRecord: ;
               }

               data.AcceptChanges();
               return true;
           }

           catch (Exception ex)
           {

               try
               {
                   if (ex.Message.Contains("Concurrency Error:"))
                   {

                       return false;
                   }

                   else
                   {
                       //dump the table into an error file so we have some record of where we were
                       CRFS.Data.ErrorDataDump.DumpTableToDefaultLocation(data, "");
                       throw ex;
                   }
               }

               catch
               {
                   throw ex;
               }
           }

           finally
           {
               if (con.State != System.Data.ConnectionState.Closed)
               {
                   con.Close();
                   con.Dispose();
               }
           }
       }



       #endregion

    }
}

