﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace CRFS.Data
{
    class ClaimsManagement
    {
        CRFS.Data.Settings _settings;

        internal ClaimsManagement()
        {
        }

        internal ClaimsManagement(CRFS.Data.Settings settings)
        {
            _settings = settings;

        }

        #region "Common"
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="formID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetComboBoxReferenceValues_ByFormID(int formID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable("ComboBoxValues");

                dt.Columns.Add("id", typeof(int));
                dt.Columns.Add("ComboBoxTypeTag", typeof(string));
                dt.Columns.Add("ComboBoxText", typeof(string));
                

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usptbllkp_Forms_ComboBoxValues_Select";
                SqlParameter parm = new SqlParameter("@FormID", formID);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();
                    row["id"] = (int)dr["id"];
                    row["ComboBoxTypeTag"] = dr["ComboBoxTypeTag"].ToString();
                    row["ComboBoxText"] = dr["ComboBoxText"].ToString();

                    dt.Rows.Add(row);
                }

                return dt;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="formID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetComboBoxReferenceValues_ByFormID_NoExpire(int formID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable("ComboBoxValues");

                dt.Columns.Add("id", typeof(int));
                dt.Columns.Add("ComboBoxTypeTag", typeof(string));
                dt.Columns.Add("ComboBoxText", typeof(string));
                dt.Columns.Add("EffectiveToDate", typeof(DateTime));
                

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usptbllkp_Forms_ComboBoxValues_Select_NoExpire";
                SqlParameter parm = new SqlParameter("@FormID", formID);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();
                    row["id"] = (int)dr["id"];
                    row["ComboBoxTypeTag"] = dr["ComboBoxTypeTag"].ToString();
                    row["ComboBoxText"] = dr["ComboBoxText"].ToString();
                    row["EffectiveToDate"] = DateTime.Parse(dr["EffectiveToDate"].ToString());

                    dt.Rows.Add(row);
                }

                return dt;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="formID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetDeactivatedComboBoxReferenceValues_ByFormID(int formID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable("ComboBoxValues");

                dt.Columns.Add("id", typeof(int));
                dt.Columns.Add("ComboBoxTypeTag", typeof(string));
                dt.Columns.Add("ComboBoxText", typeof(string));

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_COMM_DeactivatedComboBoxValues_Select";
                SqlParameter parm = new SqlParameter("@FormID", formID);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();
                    row["id"] = (int)dr["id"];
                    row["ComboBoxTypeTag"] = dr["ComboBoxTypeTag"].ToString();
                    row["ComboBoxText"] = dr["ComboBoxText"].ToString();

                    dt.Rows.Add(row);
                }

                return dt;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
        /*31043
        /// <summary>
        /// 
        /// </summary>
        /// <param name="formID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable MICompanies_SelectByFormID(int formID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable("ComboBoxValues");

                dt.Columns.Add("id", typeof(int));
                dt.Columns.Add("MICompanyName", typeof(string));
                dt.Columns.Add("CMAX_MI_Name", typeof(string));
                dt.Columns.Add("CMAX_MI_Code", typeof(string));

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_COMM_MICompanies_SelectByFormID";
                SqlParameter parm = new SqlParameter("@FormID", formID);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();
                    row["id"] = (int)dr["id"];
                    row["MICompanyName"] = dr["MICompanyName"].ToString();
                    row["CMAX_MI_Name"] = dr["CMAX_MI_Name"].ToString();
                    row["CMAX_MI_Code"] = dr["CMAX_MI_Code"].ToString();

                    dt.Rows.Add(row);
                }

                return dt;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }
        */
        /// <summary>
        /// 
        /// </summary>
        /// <param name="formID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable Get_ClaimTypes_ByFormID(int formID, Settings settings)
        {
            SqlConnection con = new SqlConnection();
            
            try
            {
                DataTable dt = new DataTable("ComboBoxValues");

                dt.Columns.Add("id", typeof(int));
                dt.Columns.Add("ClaimType", typeof(string));

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usptbllkp_ClaimTypesByForm_SelectActive";
                SqlParameter parm = new SqlParameter("@FormID", formID);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();
                    row["id"] = (int)dr["id"];
                    row["ClaimType"] = dr["ClaimType"].ToString();

                    dt.Rows.Add(row);
                }

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable Get_DisplayMasks( Settings settings)
        {
            SqlConnection con = new SqlConnection();
            
            try
            {
                DataTable dt = new DataTable("DisplayMasks");

                dt.Columns.Add("ClaimTypeDisplayBitmaskID", typeof(int));
                dt.Columns.Add("InvTrk_ClaimTypeID", typeof(int));
                dt.Columns.Add("HUDclaims_ClaimTypeID", typeof(int));
                dt.Columns.Add("SubType", typeof(string));
                dt.Columns.Add("BitMask", typeof(int));

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_ClaimTypeDisplayBitmask_Select";

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                //dt.Load(dr);
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();
                    row["ClaimTypeDisplayBitmaskID"] = (int)dr["ClaimTypeDisplayBitmaskID"];
                    row["InvTrk_ClaimTypeID"] = (int)dr["InvTrk_ClaimTypeID"];
                    //row["HUDclaims_ClaimTypeID"] = (int)dr["HUDclaims_ClaimTypeID"];  // for some reason line is giving an exception, don't have time to mess with it now
                    row["HUDclaims_ClaimTypeID"] = dr["HUDclaims_ClaimTypeID"]; 
                    row["SubType"] = (string)dr["SubType"];
                    row["BitMask"] = (int)dr["BitMask"];

                    dt.Rows.Add(row);
                }

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable Get_DisplayControls( Settings settings)
        {
            SqlConnection con = new SqlConnection();
            
            try
            {
                DataTable dt = new DataTable("DisplayControls");

                dt.Columns.Add("ControlNameDisplayID", typeof(int));
                dt.Columns.Add("ApplicationName", typeof(string));
                dt.Columns.Add("TableName", typeof(string));
                dt.Columns.Add("FieldName", typeof(string));
                dt.Columns.Add("TabName", typeof(string));
                dt.Columns.Add("ControlName", typeof(string));
                dt.Columns.Add("LabelName", typeof(string));
                dt.Columns.Add("ClaimTypeDisplayBitArray", typeof(int));

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_ControlNameDisplay_Select";

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();
                    row["ControlNameDisplayID"] = (int)dr["ControlNameDisplayID"];
                    row["ApplicationName"] = (string)dr["ApplicationName"];
                    row["TableName"] = (string)dr["TableName"];
                    row["FieldName"] = (string)dr["FieldName"];
                    row["TabName"] = (string)dr["TabName"];
                    row["ControlName"] = (string)dr["ControlName"];
                    row["LabelName"] = (string)dr["LabelName"];
                    row["ClaimTypeDisplayBitArray"] = (int)dr["ClaimTypeDisplayBitArray"];

                    dt.Rows.Add(row);
                }

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// Constructs data table and retrieves all data for all active application forms.
        /// </summary>
        /// <param name="settings"></param>
        /// <returns>DataTable containing all collumns for all active application forms.</returns>
        internal DataTable Get_ActiveForms(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("ActiveForms");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("id", typeof(int));
                dt.Columns.Add("FormName", typeof(string));
                dt.Columns.Add("DateEntered", typeof(DateTime));
                dt.Columns.Add("EffectiveFromDate", typeof(DateTime));
                dt.Columns.Add("EffectiveToDate", typeof(DateTime));
                dt.Columns.Add("PrimaryFormID", typeof(int));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usptbllkp_Active_Forms";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["id"] = int.Parse(dr["id"].ToString().Length == 0 ? "0" : dr["id"].ToString());
                    row["FormName"] = dr["FormName"].ToString();
                    row["DateEntered"] = DateTime.Parse(dr["DateEntered"].ToString().Length == 0 ? "1/1/1900" : dr["DateEntered"].ToString());
                    row["EffectiveFromDate"] = DateTime.Parse(dr["EffectiveFromDate"].ToString().Length == 0 ? "1/1/1900" : dr["EffectiveFromDate"].ToString());
                    row["EffectiveToDate"] = DateTime.Parse(dr["EffectiveToDate"].ToString().Length == 0 ? "1/1/1900" : dr["EffectiveToDate"].ToString());
                    row["PrimaryFormID"] = int.Parse(dr["PrimaryFormID"].ToString().Length == 0 ? "0" : dr["PrimaryFormID"].ToString());

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="BusinessEntityName"></param>
        /// <param name="BusinessEntityType"></param>
        /// <param name="FormID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal int InsertBusinessEntity(string BusinessEntityName, int BusinessEntityType, int FormID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {

                int BusinessEntityID = 0;

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                if (con.State == ConnectionState.Open)
                {
                    SqlCommand cmd = new SqlCommand();
                    SqlParameter prm = new SqlParameter();

                    cmd.Connection = con;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "usp_BusinessEntity_Insert";

                    prm = new SqlParameter("@BusinessEntityName", BusinessEntityName);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@EntityTypeID", BusinessEntityType);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@FormID", FormID);
                    cmd.Parameters.Add(prm);

                    BusinessEntityID = int.Parse(cmd.ExecuteScalar().ToString());

                }

                return BusinessEntityID;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        #endregion

        #region "Admin Tools"
        /// <summary>
        /// 
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable ApplicationAccess_Get(int UserID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("AccessRights");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("AppAccessID", typeof(int));
                dt.Columns.Add("FormID", typeof(int));
                dt.Columns.Add("UserID", typeof(int));
                dt.Columns.Add("IsAppUser", typeof(bool));
                dt.Columns.Add("IsAllowedAdmin", typeof(bool));
                dt.Columns.Add("IsAllowedUserAdmin", typeof(bool));
                dt.Columns.Add("IsAllowedLockAdmin", typeof(bool));
                dt.Columns.Add("IsAllowedAppAccessAdmin", typeof(bool));
                dt.Columns.Add("IsAllowedServicer_MI_Admin", typeof(bool));
                dt.Columns.Add("IsAllowedCltSpecificSecAdmin", typeof(bool));
                dt.Columns.Add("EnteredDate", typeof(DateTime));
                dt.Columns.Add("EnteredByUserID", typeof(int));
                dt.Columns.Add("LastUpdateDate", typeof(DateTime));
                dt.Columns.Add("LastUpdateUserID", typeof(int));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                SqlParameter parm = new SqlParameter("@UserID", UserID);
                cmd.Parameters.Add(parm);

                cmd.CommandText = "usp_CNTL_AppAccess_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["AppAccessID"] = int.Parse(dr["AppAccessID"].ToString().Length == 0 ? "0" : dr["AppAccessID"].ToString());
                    row["FormID"] = int.Parse(dr["FormID"].ToString().Length == 0 ? "0" : dr["FormID"].ToString());
                    row["UserID"] = int.Parse(dr["UserID"].ToString().Length == 0 ? "0" : dr["UserID"].ToString());
                    row["IsAppUser"] = bool.Parse(dr["IsAppUser"].ToString().Length == 0 ? "false" : dr["IsAppUser"].ToString());
                    row["IsAllowedAdmin"] = bool.Parse(dr["IsAllowedAdmin"].ToString().Length == 0 ? "false" : dr["IsAllowedAdmin"].ToString());
                    row["IsAllowedUserAdmin"] = bool.Parse(dr["IsAllowedUserAdmin"].ToString().Length == 0 ? "false" : dr["IsAllowedUserAdmin"].ToString());
                    row["IsAllowedLockAdmin"] = bool.Parse(dr["IsAllowedLockAdmin"].ToString().Length == 0 ? "false" : dr["IsAllowedLockAdmin"].ToString());
                    row["IsAllowedAppAccessAdmin"] = bool.Parse(dr["IsAllowedAppAccessAdmin"].ToString().Length == 0 ? "false" : dr["IsAllowedAppAccessAdmin"].ToString());
                    row["IsAllowedServicer_MI_Admin"] = bool.Parse(dr["IsAllowedServicer_MI_Admin"].ToString().Length == 0 ? "false" : dr["IsAllowedServicer_MI_Admin"].ToString());
                    row["IsAllowedCltSpecificSecAdmin"] = bool.Parse(dr["IsAllowedCltSpecificSecAdmin"].ToString().Length == 0 ? "false" : dr["IsAllowedCltSpecificSecAdmin"].ToString()); 
                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                    row["EnteredByUserID"] = int.Parse(dr["EnteredByUserID"].ToString().Length == 0 ? "0" : dr["EnteredByUserID"].ToString());
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    row["LastUpdateUserID"] = int.Parse(dr["LastUpdateUserID"].ToString().Length == 0 ? "0" : dr["LastUpdateUserID"].ToString());

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable ApplicationAccess_GetAllUsers(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("AccessRights");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("AppAccessID", typeof(int));
                dt.Columns.Add("FormID", typeof(int));
                dt.Columns.Add("UserID", typeof(int));
                dt.Columns.Add("UserName", typeof(string));
                dt.Columns.Add("IsAppUser", typeof(bool));
                dt.Columns.Add("IsAllowedAdmin", typeof(bool));
                dt.Columns.Add("IsAllowedUserAdmin", typeof(bool));
                dt.Columns.Add("IsAllowedLockAdmin", typeof(bool));
                dt.Columns.Add("IsAllowedAppAccessAdmin", typeof(bool));
                dt.Columns.Add("IsAllowedServicer_MI_Admin", typeof(bool));
                dt.Columns.Add("IsAllowedCltSpecificSecAdmin", typeof(bool)); 
                dt.Columns.Add("EnteredDate", typeof(DateTime));
                dt.Columns.Add("EnteredByUserID", typeof(int));
                dt.Columns.Add("LastUpdateDate", typeof(DateTime));
                dt.Columns.Add("LastUpdateUserID", typeof(int));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_CNTL_AppAccess_SelectAllUsers";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["AppAccessID"] = int.Parse(dr["AppAccessID"].ToString().Length == 0 ? "0" : dr["AppAccessID"].ToString());
                    row["FormID"] = int.Parse(dr["FormID"].ToString().Length == 0 ? "0" : dr["FormID"].ToString());
                    row["UserID"] = int.Parse(dr["UserID"].ToString().Length == 0 ? "0" : dr["UserID"].ToString());
                    row["UserName"] = dr["UserName"].ToString();
                    row["IsAppUser"] = bool.Parse(dr["IsAppUser"].ToString().Length == 0 ? "false" : dr["IsAppUser"].ToString());
                    row["IsAllowedAdmin"] = bool.Parse(dr["IsAllowedAdmin"].ToString().Length == 0 ? "false" : dr["IsAllowedAdmin"].ToString());
                    row["IsAllowedUserAdmin"] = bool.Parse(dr["IsAllowedUserAdmin"].ToString().Length == 0 ? "false" : dr["IsAllowedUserAdmin"].ToString());
                    row["IsAllowedLockAdmin"] = bool.Parse(dr["IsAllowedLockAdmin"].ToString().Length == 0 ? "false" : dr["IsAllowedLockAdmin"].ToString());
                    row["IsAllowedAppAccessAdmin"] = bool.Parse(dr["IsAllowedAppAccessAdmin"].ToString().Length == 0 ? "false" : dr["IsAllowedAppAccessAdmin"].ToString());
                    row["IsAllowedServicer_MI_Admin"] = bool.Parse(dr["IsAllowedServicer_MI_Admin"].ToString().Length == 0 ? "false" : dr["IsAllowedServicer_MI_Admin"].ToString());
                    row["IsAllowedCltSpecificSecAdmin"] = bool.Parse(dr["IsAllowedCltSpecificSecAdmin"].ToString().Length == 0 ? "false" : dr["IsAllowedCltSpecificSecAdmin"].ToString()); 
                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                    row["EnteredByUserID"] = int.Parse(dr["EnteredByUserID"].ToString().Length == 0 ? "0" : dr["EnteredByUserID"].ToString());
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    row["LastUpdateUserID"] = int.Parse(dr["LastUpdateUserID"].ToString().Length == 0 ? "0" : dr["LastUpdateUserID"].ToString());

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool ApplicationAccess_Save(DataTable data, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                for (int i = 0; i < data.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.Connection = con;

                    switch (data.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            cmd.CommandText = "usp_CNTL_AppAccess_Insert";

                            parm = new SqlParameter("@FormID", data.Rows[i]["FormID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@UserID", data.Rows[i]["UserID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@IsAppUser", data.Rows[i]["IsAppUser"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@IsAllowedAdmin", data.Rows[i]["IsAllowedAdmin"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@IsAllowedUserAdmin", data.Rows[i]["IsAllowedUserAdmin"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@IsAllowedLockAdmin", data.Rows[i]["IsAllowedLockAdmin"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@IsAllowedAppAccessAdmin", data.Rows[i]["IsAllowedAppAccessAdmin"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@IsAllowedServicer_MI_Admin", data.Rows[i]["IsAllowedServicer_MI_Admin"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@IsAllowedCltSpecificSecAdmin", data.Rows[i]["IsAllowedCltSpecificSecAdmin"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@EnteredDate", data.Rows[i]["EnteredDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@EnteredByUserID", data.Rows[i]["EnteredByUserID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateDate", data.Rows[i]["LastUpdateDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateUserID", data.Rows[i]["LastUpdateUserID"]);
                            cmd.Parameters.Add(parm);

                            //Now we need to execute a stored procedure that returns the new record ID
                            data.Rows[i]["AppAccessID"] = int.Parse(cmd.ExecuteScalar().ToString());

                            goto NextRecord;

                        case DataRowState.Deleted:
                            cmd.CommandText = "usp_CNTL_AppAccess_Delete";

                            //parm = new SqlParameter("@FormID", data.Rows[i]["FormID"]);
                            parm = new SqlParameter("@FormID", data.Rows[i]["FormID", DataRowVersion.Original]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@UserID", data.Rows[i]["UserID", DataRowVersion.Original]);
                            cmd.Parameters.Add(parm);

                            break;

                        case DataRowState.Modified:
                            cmd.CommandText = "usp_CNTL_AppAccess_Update";

                            parm = new SqlParameter("@FormID", data.Rows[i]["FormID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@UserID", data.Rows[i]["UserID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@IsAppUser", data.Rows[i]["IsAppUser"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@IsAllowedAdmin", data.Rows[i]["IsAllowedAdmin"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@IsAllowedUserAdmin", data.Rows[i]["IsAllowedUserAdmin"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@IsAllowedLockAdmin", data.Rows[i]["IsAllowedLockAdmin"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@IsAllowedAppAccessAdmin", data.Rows[i]["IsAllowedAppAccessAdmin"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@IsAllowedServicer_MI_Admin", data.Rows[i]["IsAllowedServicer_MI_Admin"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@IsAllowedCltSpecificSecAdmin", data.Rows[i]["IsAllowedCltSpecificSecAdmin"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateDate", data.Rows[i]["LastUpdateDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateUserID", data.Rows[i]["LastUpdateUserID"]);
                            cmd.Parameters.Add(parm);

                            break;

                        default:
                            goto NextRecord;
                    }

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;

                }

                data.AcceptChanges();
                return true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="formID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable BusinessEntities_Get(int formID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("BusinessEntities");

                dt.Columns.Add("BusinessEntityID", typeof(int));
                dt.Columns.Add("EntityTypeID", typeof(int));
                dt.Columns.Add("BusinessEntityName", typeof(string));
                dt.Columns.Add("DateEntered", typeof(DateTime));
                dt.Columns.Add("EffectiveFromDate", typeof(DateTime));
                dt.Columns.Add("EffectiveToDate", typeof(DateTime));
                dt.Columns.Add("IsBackend", typeof(bool));
                dt.Columns.Add("ExcludeFNMAClaimFiledUpdateRpt", typeof(bool));
                dt.Columns.Add("FormID", typeof(int));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                SqlParameter parm = new SqlParameter("@FormID", formID);
                cmd.Parameters.Add(parm);


                cmd.CommandText = "usp_BusinessEntities_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["BusinessEntityID"] = int.Parse(dr["BusinessEntityID"].ToString().Length == 0 ? "0" : dr["BusinessEntityID"].ToString());
                    row["EntityTypeID"] = int.Parse(dr["EntityTypeID"].ToString().Length == 0 ? "0" : dr["EntityTypeID"].ToString());
                    row["BusinessEntityName"] = dr["BusinessEntityName"].ToString();
                    row["DateEntered"] = DateTime.Parse(dr["DateEntered"].ToString().Length == 0 ? "1/1/1900" : dr["DateEntered"].ToString());
                    row["EffectiveFromDate"] = DateTime.Parse(dr["EffectiveFromDate"].ToString().Length == 0 ? "1/1/1900" : dr["EffectiveFromDate"].ToString());
                    row["EffectiveToDate"] = DateTime.Parse(dr["EffectiveToDate"].ToString().Length == 0 ? "1/1/1900" : dr["EffectiveToDate"].ToString());
                    row["IsBackend"] = bool.Parse(dr["IsBackend"].ToString().Length == 0 ? "false" : dr["IsBackend"].ToString());
                    row["ExcludeFNMAClaimFiledUpdateRpt"] = bool.Parse(dr["ExcludeFNMAClaimFiledUpdateRpt"].ToString().Length == 0 ? "false" : dr["ExcludeFNMAClaimFiledUpdateRpt"].ToString());
                    row["FormID"] = int.Parse(dr["FormID"].ToString().Length == 0 ? "0" : dr["FormID"].ToString());

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool Business_Entities_Update(DataTable data, int FormID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                int recordsAffected;


                for (int i = 0; i < data.Rows.Count; i++)
                {
                    SqlParameter parm = new SqlParameter();

                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.Connection = con;

                    switch (data.Rows[i].RowState)
                    {
                        case DataRowState.Modified:
                            cmd.CommandText = "usp_BusinessEntity_Update";

                            parm = new SqlParameter("@BusinessEntityID", data.Rows[i]["BusinessEntityID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FormID", FormID);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@IsBackend", data.Rows[i]["IsBackend"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ExcludeFNMAClaimFiledUpdateRpt", data.Rows[i]["ExcludeFNMAClaimFiledUpdateRpt"]);
                            cmd.Parameters.Add(parm);

                            break;

                        default:
                            goto NextRecord;
                    }

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;

                }

                data.AcceptChanges();
                return true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable ClientGroups_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                DataTable dt = new DataTable("ClientGroups");

                dt.Columns.Add("ClientGroupID", typeof(int));
                dt.Columns.Add("ClientGroupName", typeof(string));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_CNTL_ClientGroups_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ClientGroupID"] = int.Parse(dr["ClientGroupID"].ToString().Length == 0 ? "0" : dr["ClientGroupID"].ToString());
                    row["ClientGroupName"] = dr["ClientGroupName"].ToString();

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        private DataTable Dynamically_Build_ClientSpecificSecurityTable(Settings settings)
        {           
            try
            {
                DataTable dtGroups = ClientGroups_Get(settings);
                DataTable dt = new DataTable("ClientSpecificSecurity");

                dt.Columns.Add("CMSLoginID", typeof(int));
                dt.Columns.Add("UserName", typeof(string));

                for (int i = 0; i < dtGroups.Rows.Count; i++)
                {
                    dt.Columns.Add(dtGroups.Rows[i]["ClientGroupName"].ToString(), typeof(bool));

                }

                dt.AcceptChanges();
                return dt;
            
            }

            catch (Exception Exception)
            {
                throw Exception;

            }

        }

        /// <summary>
        /// Used to find/manage Business Entities that are not assigned to a group
        /// </summary>
        /// <param name="FormID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable EntityGroups_Get(int FormID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

            }

            catch (Exception e)
            {
                throw e;

            }

            try
            {
                DataTable dt = new DataTable("EntityGroups");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("BusinessEntityID", typeof(int));
                dt.Columns.Add("EntityTypeID", typeof(int));
                dt.Columns.Add("EntityTypeName", typeof(string));
                dt.Columns.Add("BusinessEntityName", typeof(string));
                dt.Columns.Add("IsBackend", typeof(bool));
                dt.Columns.Add("ExcludeFNMAClaimFiledUpdateRpt", typeof(bool));
                dt.Columns.Add("Group_BusinessEntityID", typeof(int));
                dt.Columns.Add("GroupID", typeof(int));
                dt.Columns.Add("GroupName", typeof(string));
                dt.Columns.Add("GroupEmailAddress", typeof(string));
                dt.Columns.Add("xrefDateEntered", typeof(DateTime));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_Entity_Group_SelectAll";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter("@FormID", FormID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["BusinessEntityID"] = int.Parse(dr["BusinessEntityID"].ToString().Length == 0 ? "0" : dr["BusinessEntityID"].ToString());
                    row["EntityTypeID"] = int.Parse(dr["EntityTypeID"].ToString().Length == 0 ? "0" : dr["EntityTypeID"].ToString());
                    row["EntityTypeName"] = dr["EntityTypeName"].ToString();
                    row["BusinessEntityName"] = dr["BusinessEntityName"].ToString();
                    row["IsBackend"] = bool.Parse(dr["IsBackend"].ToString().Length == 0 ? "false" : dr["IsBackend"].ToString());
                    row["ExcludeFNMAClaimFiledUpdateRpt"] = bool.Parse(dr["ExcludeFNMAClaimFiledUpdateRpt"].ToString().Length == 0 ? "false" : dr["ExcludeFNMAClaimFiledUpdateRpt"].ToString());
                    row["Group_BusinessEntityID"] = int.Parse(dr["Group_BusinessEntityID"].ToString().Length == 0 ? "0" : dr["Group_BusinessEntityID"].ToString());
                    row["GroupID"] = int.Parse(dr["GroupID"].ToString().Length == 0 ? "0" : dr["GroupID"].ToString());
                    row["GroupName"] = dr["GroupName"].ToString();
                    row["GroupEmailAddress"] = dr["GroupEmailAddress"].ToString();
                    row["xrefDateEntered"] = DateTime.Parse(dr["xrefDateEntered"].ToString().Length == 0 ? "1/1/1900" : dr["xrefDateEntered"].ToString());

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable EntityTypes_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("EntityTypes");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("EntityTypeID", typeof(int));
                dt.Columns.Add("EntityTypeName", typeof(string));
                dt.Columns.Add("EntityType", typeof(string));
                dt.Columns.Add("DateEntered", typeof(DateTime));
                dt.Columns.Add("EffectiveFromDate", typeof(DateTime));
                dt.Columns.Add("EffectiveToDate", typeof(DateTime));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_EntityTypes_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["EntityTypeID"] = int.Parse(dr["EntityTypeID"].ToString().Length == 0 ? "0" : dr["EntityTypeID"].ToString());
                    row["EntityTypeName"] = dr["EntityTypeName"].ToString();
                    row["EntityType"] = dr["EntityType"].ToString();
                    row["DateEntered"] = DateTime.Parse(dr["DateEntered"].ToString().Length == 0 ? "1/1/1900" : dr["DateEntered"].ToString());
                    row["EffectiveFromDate"] = DateTime.Parse(dr["EffectiveFromDate"].ToString().Length == 0 ? "1/1/1900" : dr["EffectiveFromDate"].ToString());
                    row["EffectiveToDate"] = DateTime.Parse(dr["EffectiveToDate"].ToString().Length == 0 ? "1/1/1900" : dr["EffectiveToDate"].ToString());

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }


        }

        /// <summary>
        /// Used to manage groups that already have business entities assigned
        /// </summary>
        /// <param name="FormID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable EntityGroupsAssigned_Get(int FormID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

            }

            catch (Exception e)
            {
                throw e;

            }

            try
            {
                DataTable dt = new DataTable("EntityGroups");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("Group_BusinessEntityID", typeof(int));
                dt.Columns.Add("GroupID", typeof(int));
                dt.Columns.Add("GroupName", typeof(string));
                dt.Columns.Add("BusinessEntityID", typeof(int));
                dt.Columns.Add("BusinessEntityName", typeof(string));
                dt.Columns.Add("DateEntered", typeof(DateTime));
                dt.Columns.Add("FormID", typeof(int));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_Entity_Group_Select";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter("@FormID", FormID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["Group_BusinessEntityID"] = int.Parse(dr["Group_BusinessEntityID"].ToString().Length == 0 ? "0" : dr["Group_BusinessEntityID"].ToString());
                    row["GroupID"] = int.Parse(dr["GroupID"].ToString().Length == 0 ? "0" : dr["GroupID"].ToString());
                    row["GroupName"] = dr["GroupName"].ToString();
                    row["BusinessEntityID"] = int.Parse(dr["BusinessEntityID"].ToString().Length == 0 ? "0" : dr["BusinessEntityID"].ToString());
                    row["BusinessEntityName"] = dr["BusinessEntityName"].ToString();
                    row["DateEntered"] = DateTime.Parse(dr["DateEntered"].ToString().Length == 0 ? "1/1/1900" : dr["DateEntered"].ToString());
                    row["FormID"] = int.Parse(dr["FormID"].ToString().Length == 0 ? "0" : dr["FormID"].ToString());

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool EntityGroupsAssigned_Save(DataTable data, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

            }

            catch (Exception e)
            {
                throw e;

            }

            try
            {

                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                for (int i = 0; i < data.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.Connection = con;

                    switch (data.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            cmd.CommandText = "usp_Entity_Group_Insert";

                            parm = new SqlParameter("@GroupID", data.Rows[i]["GroupID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@BusinessEntityID", data.Rows[i]["BusinessEntityID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@DateEntered", data.Rows[i]["DateEntered"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FormID", data.Rows[i]["FormID"]);
                            cmd.Parameters.Add(parm);

                            //Now we need to execute a stored procedure that returns the new record ID
                            data.Rows[i]["Group_BusinessEntityID"] = int.Parse(cmd.ExecuteScalar().ToString());

                            goto NextRecord;

                        case DataRowState.Deleted:
                            cmd.CommandText = "dbo.usp_Entity_Group_Delete";

                            parm = new SqlParameter("@FormID", data.Rows[i]["FormID", DataRowVersion.Original]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@Group_BusinessEntityID", data.Rows[i]["Group_BusinessEntityID", DataRowVersion.Original]);
                            cmd.Parameters.Add(parm);

                            break;

                        default:
                            goto NextRecord;

                    }

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;

                }

                data.AcceptChanges();

                return true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FormID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable Groups_Get(int FormID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

            }

            catch (Exception e)
            {
                throw e;

            }

            try
            {
                DataTable dt = new DataTable("Groups");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("GroupID", typeof(int));
                dt.Columns.Add("GroupName", typeof(string));
                dt.Columns.Add("DateEntered", typeof(DateTime));
                dt.Columns.Add("EffectiveFromDate", typeof(DateTime));
                dt.Columns.Add("EffectiveToDate", typeof(DateTime));
                dt.Columns.Add("GroupEmailAddress", typeof(string));
                dt.Columns.Add("FormID", typeof(int));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_Groups_Select";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter("@FormID", FormID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["GroupID"] = int.Parse(dr["GroupID"].ToString().Length == 0 ? "0" : dr["GroupID"].ToString());
                    row["GroupName"] = dr["GroupName"].ToString();
                    row["DateEntered"] = DateTime.Parse(dr["DateEntered"].ToString().Length == 0 ? "1/1/1900" : dr["DateEntered"].ToString());
                    row["EffectiveFromDate"] = DateTime.Parse(dr["EffectiveFromDate"].ToString().Length == 0 ? "1/1/1900" : dr["EffectiveFromDate"].ToString());
                    row["EffectiveToDate"] = DateTime.Parse(dr["EffectiveToDate"].ToString().Length == 0 ? "1/1/1900" : dr["EffectiveToDate"].ToString());
                    row["GroupEmailAddress"] = dr["GroupEmailAddress"].ToString();
                    row["FormID"] = int.Parse(dr["FormID"].ToString().Length == 0 ? "0" : dr["FormID"].ToString());

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }


            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool Groups_Save(DataTable data, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.Connection = con;
                
                for (int i = 0; i < data.Rows.Count; i++)
                {
                    switch (data.Rows[i].RowState)
                    {
                        case DataRowState.Modified:
                            cmd.CommandText = "usp_Group_Update";

                            parm = new SqlParameter("@GroupID", data.Rows[i]["GroupID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@GroupName", data.Rows[i]["GroupName"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@DateEntered", data.Rows[i]["DateEntered"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@EffectiveFromDate", data.Rows[i]["EffectiveFromDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@EffectiveToDate", data.Rows[i]["EffectiveToDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@GroupEmailAddress", data.Rows[i]["GroupEmailAddress"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FormID", data.Rows[i]["FormID"]);
                            cmd.Parameters.Add(parm);

                            break;

                        default:
                            goto NextRecord;
                    }

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;

                }

                data.AcceptChanges();
                return true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        internal bool GroupEmailSignatures_Save(DataTable data, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.Connection = con;

                for (int i = 0; i < data.Rows.Count; i++)
                {
                    switch (data.Rows[i].RowState)
                    {
                        case DataRowState.Modified:
                            cmd.CommandText = "usp_Entity_GroupEmailSignature_Update";                            
                            break;

                        case DataRowState.Added:
                            cmd.CommandText = "usp_Entity_GroupEmailSignature_Insert";
                            break;
                        
                        default:
                            goto NextRecord;
                    }
                    parm = new SqlParameter("@GroupID", data.Rows[i]["GroupID"]);
                    cmd.Parameters.Add(parm);
                    parm = new SqlParameter("@EmailSignature", data.Rows[i]["EmailSignature"]);
                    cmd.Parameters.Add(parm);
                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;

                }

                data.AcceptChanges();
                return true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable Security_ClientSpecificSecurity_GetMatrix(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dtGroups = ClientGroups_Get(settings);
                DataTable dt = Dynamically_Build_ClientSpecificSecurityTable(settings);

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_CNTL_UserClientSecurityMatrix_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["CMSLoginID"] = int.Parse(dr["CMSLoginID"].ToString().Length == 0 ? "0" : dr["CMSLoginID"].ToString());
                    row["UserName"] = dr["UserName"].ToString();

                    //Dynamically add column maps
                    for (int i = 0; i < dtGroups.Rows.Count; i++)
                    {
                        string colName = dtGroups.Rows[i]["ClientGroupName"].ToString();

                        //T-14719 Try-Catch block added for trapping and handling an index out of range exception
                        //generated when a new client is on-boarded and there are no users pre-added as able to access
                        //that client's data
                        try
                        {
                            row[colName] = bool.Parse(dr[colName].ToString().Length == 0 ? "false" : dr[colName].ToString());

                        }

                        catch (Exception ex2)
                        {
                            //The column name does not exist.  We'll get aroung the index out of range exception that was thrown
                            row[colName] = false;

                        }

                    }

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        internal bool Security_ClientSpecificSecurity_SaveMatrix(ref DataTable dt, int CurrentUserID, Settings settings)
        {
            SqlConnection con = new SqlConnection();
            
            try
            {
                DataTable dtGroups = ClientGroups_Get(settings);

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                SqlCommand cmd = new SqlCommand();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    switch (dt.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            cmd = new SqlCommand();
                            cmd.CommandType = System.Data.CommandType.StoredProcedure;
                            cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                            cmd.Connection = con;

                            cmd.CommandText = "usp_CNTL_UserClientSecurityMatrix_Insert";

                            parm = new SqlParameter("@CMSLoginID", dt.Rows[i]["CMSLoginID"].ToString());
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ClientGroupID", "");
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@EnteredByUserID", CurrentUserID);
                            cmd.Parameters.Add(parm);

                            //For each client group, we need to find the matching column name from the data grid table of the security matrix
                            //If the column value is true, we insert a new record
                            for (int j = 0; j < dtGroups.Rows.Count; j++)
                            {
                                int GroupID = int.Parse(dtGroups.Rows[j]["ClientGroupID"].ToString());
                                string GroupName = dtGroups.Rows[j]["ClientGroupName"].ToString();

                                if (bool.Parse(dt.Rows[i][GroupName].ToString()))
                                {
                                    cmd.Parameters["@ClientGroupID"].Value = GroupID;
                                    
                                    recordsAffected = cmd.ExecuteNonQuery();

                                }
                                
                            }
                            
                            break;

                        case DataRowState.Deleted:
                            cmd = new SqlCommand();
                            cmd.CommandType = System.Data.CommandType.StoredProcedure;
                            cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                            cmd.Connection = con;

                            cmd.CommandText = "usp_CNTL_UserClientSecurityMatrix_Delete";

                            parm = new SqlParameter("@CMSLoginID", dt.Rows[i]["CMSLoginID", DataRowVersion.Original].ToString());
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ClientGroupID", "%");
                            cmd.Parameters.Add(parm);

                            recordsAffected = cmd.ExecuteNonQuery();

                            break;

                        case DataRowState.Modified:

                            for (int j = 0; j < dtGroups.Rows.Count; j++)
                            {
                                int GroupID = int.Parse(dtGroups.Rows[j]["ClientGroupID"].ToString());
                                string GroupName = dtGroups.Rows[j]["ClientGroupName"].ToString();

                                if (dt.Rows[i][GroupName,DataRowVersion.Original].ToString() != dt.Rows[i][GroupName].ToString())
                                {
                                    //This cell has been modified
                                    if (bool.Parse(dt.Rows[i][GroupName].ToString()))
                                    {
                                        //These are inserts
                                        cmd = new SqlCommand();
                                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                                        cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                                        cmd.Connection = con;

                                        cmd.CommandText = "usp_CNTL_UserClientSecurityMatrix_Insert";


                                        parm = new SqlParameter("@CMSLoginID", dt.Rows[i]["CMSLoginID"].ToString());
                                        cmd.Parameters.Add(parm);
                                        parm = new SqlParameter("@ClientGroupID", GroupID);
                                        cmd.Parameters.Add(parm);
                                        parm = new SqlParameter("@EnteredByUserID", CurrentUserID);
                                        cmd.Parameters.Add(parm);

                                        recordsAffected = cmd.ExecuteNonQuery();

                                    }

                                    else
                                    {
                                        //These are deletes
                                        cmd = new SqlCommand();
                                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                                        cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                                        cmd.Connection = con;

                                        cmd.CommandText = "usp_CNTL_UserClientSecurityMatrix_Delete";

                                        parm = new SqlParameter("@CMSLoginID", dt.Rows[i]["CMSLoginID", DataRowVersion.Original].ToString());
                                        cmd.Parameters.Add(parm);
                                        parm = new SqlParameter("@ClientGroupID", GroupID);
                                        cmd.Parameters.Add(parm);

                                        recordsAffected = cmd.ExecuteNonQuery();

                                    }

                                }

                            }

                            break;

                        default:

                            break;

                    }

                }

                dt.AcceptChanges();

                return true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable Security_AllUsers_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {

                DataTable dt = new DataTable();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_CNTL_AllUsers_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                dt.Load(dr);

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }


        }
        internal DataTable Security_CMSUsers_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("CMSUsers");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("id", typeof(int));
                dt.Columns.Add("UserID", typeof(string));
                dt.Columns.Add("UserName", typeof(string));
                dt.Columns.Add("Password", typeof(string));
                dt.Columns.Add("SecurityGroupID", typeof(int));
                dt.Columns.Add("DateEntered", typeof(DateTime));
                dt.Columns.Add("Active", typeof(bool));
                dt.Columns.Add("PhoneNum", typeof(string));
                dt.Columns.Add("LastPWChange", typeof(DateTime));
                dt.Columns.Add("UserEmailAddress", typeof(string));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_CNTL_CMSUsers_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["id"] = int.Parse(dr["id"].ToString().Length == 0 ? "0" : dr["id"].ToString());
                    row["UserID"] = dr["UserID"].ToString();
                    row["UserName"] = dr["UserName"].ToString();
                    row["Password"] = dr["Password"].ToString();
                    row["SecurityGroupID"] = int.Parse(dr["SecurityGroupID"].ToString().Length == 0 ? "0" : dr["SecurityGroupID"].ToString());
                    row["DateEntered"] = DateTime.Parse(dr["DateEntered"].ToString().Length == 0 ? "1/1/1900" : dr["DateEntered"].ToString());
                    row["Active"] = bool.Parse(dr["Active"].ToString().Length == 0 ? "0" : dr["Active"].ToString());
                    row["PhoneNum"] = dr["PhoneNum"].ToString();
                    row["LastPWChange"] = DateTime.Parse(dr["LastPWChange"].ToString().Length == 0 ? "0" : dr["LastPWChange"].ToString());
                    row["UserEmailAddress"] = dr["UserEmailAddress"].ToString();

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="password"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool Security_CMSUser_PasswordReset(int UserID, string password, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                int recordsAffected;

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.Connection = con;
                cmd.CommandText = "usp_CNTL_CMSUsers_ResetPassword";

                SqlParameter parm = new SqlParameter();

                parm = new SqlParameter("@UserID", UserID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@Password", password);
                cmd.Parameters.Add(parm);

                recordsAffected = cmd.ExecuteNonQuery();

                return true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="PhoneNum"></param>
        /// <param name="UserEmailAddress"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool Security_CMSUsers_UpdateNonCritical(int UserID, string PhoneNum, string UserEmailAddress, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                int recordsAffected;

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.Connection = con;
                cmd.CommandText = "usp_CNTL_User_Update";

                SqlParameter parm = new SqlParameter();

                parm = new SqlParameter("@UserID", UserID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@PhoneNum", PhoneNum);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@UserEmailAddress", UserEmailAddress);
                cmd.Parameters.Add(parm);

                recordsAffected = cmd.ExecuteNonQuery();

                return true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="ClaimID"></param>
        /// <param name="LoanID"></param>
        /// <param name="MachineName"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal int setDataDirty(int UserID, int ClaimID, int LoanID, string MachineName,Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.Connection = con;
                cmd.CommandText = "usp_LogDataDirty_SetDirty";

                SqlParameter parm = new SqlParameter();

                parm = new SqlParameter("@UserID", UserID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@ClaimID", ClaimID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@LoanID", LoanID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@MachineName", MachineName);
                cmd.Parameters.Add(parm);
                return int.Parse(cmd.ExecuteScalar().ToString());
            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        internal void setDataClean(int DataDirtyID,Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.Connection = con;
                cmd.CommandText = "usp_LogDataDirty_SetClean";

                SqlParameter parm = new SqlParameter();

                parm = new SqlParameter("@DataDirtyID", DataDirtyID);
                cmd.Parameters.Add(parm);

                cmd.ExecuteNonQuery();
            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        #endregion
        
        #region "Claims 332"
        internal DataTable GetForm_Clients(int formID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable("Clients");
                DataColumn dc = new DataColumn();
                dc.ColumnName = "id";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClientName";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);


                dc = new DataColumn();
                dc.ColumnName = "ServicerNumber";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                con.ConnectionString = settings.GetConnectionString("ApplicationConfiguration");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_CMS_Clients_SelectByForm";
                SqlParameter parm = new SqlParameter("@FormID", formID);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();
                    row["id"] = int.Parse(dr["id"].ToString());
                    row["ClientName"] = dr["ClientName"].ToString();
                    row["ServicerNumber"] = dr["ServicerNumber"].ToString();
                    dt.Rows.Add(row);
                }

                dr.Close();
                dr.Dispose();

                return dt;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
        #endregion

        #region "Claims Management access for Docuware"
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="events"></param>
        /// <returns></returns>
        internal DataTable Get332ClaimDetailsForWellsUpload(DataTable dt, Moss.Events.Events events)
        {
            SqlConnection con = new SqlConnection();
            double nextTarget = .01;

            try
            {
                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");

                con.Open();

                int rowCount = dt.Rows.Count;

                for (int i = 0; i < rowCount; i++)
                {

                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.CommandText = "uspDocuware_GetAdditional332DetailsForWellFargoUpload";

                    SqlParameter parm = new SqlParameter("@Client", dt.Rows[i]["Client"].ToString());
                    cmd.Parameters.Add(parm);
                    parm = new SqlParameter("@LoanNumber", dt.Rows[i]["LoanNumber"].ToString());
                    cmd.Parameters.Add(parm);

                    cmd.Connection = con;

                    SqlDataReader dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        dt.Rows[i]["BorrowerLastName"] = dr["BorrowerLastName"].ToString();
                        dt.Rows[i]["InvestorCode"] = dr["InvestorIDCode"].ToString();
                        dt.Rows[i]["ProcessImage"] = true;
                        break;
                    }

                    dr.Close();
                    dr.Dispose();


                NextRecord: ;
                    if ((((double)i + 1) / (double)rowCount) >= nextTarget)
                    {
                        nextTarget += .01;
                        events.OnRaiseImportStatusUpdateEvent();
                    }
                }


                return dt;

            }
            
            catch (Exception e)
            {
                throw e;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        #endregion

        #region "FNMA PFU"

        /// <summary>
        /// Retrieves the FNMA PFU follow up dates that are displayed in the 'Payment Follow Up Actions' tab.
        /// </summary>
        /// <param name="referralID"></param>
        /// <param name="settings"></param>
        /// <returns>DataTable</returns>
        internal DataTable ClaimsManagment_GetPFUDatesByReferralID(int referralID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("PFUDates");
                DataColumn dc = new DataColumn();

                dc = new DataColumn();
                dc.ColumnName = "DateID";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ReferralID";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "DateTypeID";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "DateCategory";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "DateTypeName";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "DateSequence";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "DateAddValue";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "Anchored";
                dc.DataType = typeof(bool);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "DisplayFormat";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "DateValue";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "Adjustment";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "Completed";
                dc.DataType = typeof(bool);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "MarkedForDelete";
                dc.DataType = typeof(bool);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "EnteredDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "EnteredByUser";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "EnteredByUserName";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "LastUpdateDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "LastUpdateUser";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "LastUpdateUserName";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_PFU_Dates_SelectByReferralID";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter("@ReferralID", referralID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["DateID"] = int.Parse(dr["DateID"].ToString().Length == 0 ? "0" : dr["DateID"].ToString());
                    row["ReferralID"] = int.Parse(dr["ReferralID"].ToString().Length == 0 ? "0" : dr["ReferralID"].ToString());
                    row["DateTypeID"] = int.Parse(dr["DateTypeID"].ToString().Length == 0 ? "0" : dr["DateTypeID"].ToString());
                    row["DateCategory"] = dr["DateCategory"].ToString();
                    row["DateTypeName"] = dr["DateTypeName"].ToString();
                    row["DateSequence"] = int.Parse(dr["DateSequence"].ToString().Length == 0 ? "0" : dr["DateSequence"].ToString());
                    row["DateAddValue"] = int.Parse(dr["DateAddValue"].ToString().Length == 0 ? "0" : dr["DateAddValue"].ToString());
                    row["Anchored"] = bool.Parse(dr["Anchored"].ToString().Length == 0 ? "false" : dr["Anchored"].ToString());
                    row["DisplayFormat"] = dr["DisplayFormat"].ToString();
                    row["DateValue"] = DateTime.Parse(dr["DateValue"].ToString().Length == 0 ? "1/1/1900" : dr["DateValue"].ToString());
                    row["Adjustment"] = int.Parse(dr["Adjustment"].ToString().Length == 0 ? "0" : dr["Adjustment"].ToString());
                    row["Completed"] = bool.Parse(dr["Completed"].ToString().Length == 0 ? "false" : dr["Completed"].ToString());
                    row["MarkedForDelete"] = bool.Parse(dr["MarkedForDelete"].ToString().Length == 0 ? "false" : dr["MarkedForDelete"].ToString());
                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                    row["EnteredByUser"] = int.Parse(dr["EnteredByUser"].ToString().Length == 0 ? "0" : dr["EnteredByUser"].ToString());
                    row["EnteredByUserName"] = dr["EnteredByUserName"].ToString();
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    row["LastUpdateUser"] = int.Parse(dr["LastUpdateUser"].ToString().Length == 0 ? "0" : dr["LastUpdateUser"].ToString());
                    row["LastUpdateUserName"] = dr["LastUpdateUserName"].ToString();

                    dt.Rows.Add(row);
                }
                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="referralID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetPFUReferralData(int referralID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("Referral");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("ReferralID", typeof(int));
                dt.Columns.Add("REO ID", typeof(string));
                dt.Columns.Add("FNMA Loan Number", typeof(string));
                dt.Columns.Add("Servicer Name", typeof(string));
                dt.Columns.Add("Servicer Loan Number", typeof(string));
                dt.Columns.Add("MI Company Name", typeof(string));
                dt.Columns.Add("MI Certificate Number", typeof(string));
                dt.Columns.Add("Property Address", typeof(string));
                dt.Columns.Add("City", typeof(string));
                dt.Columns.Add("State", typeof(string));
                dt.Columns.Add("Zip Code", typeof(string));
                dt.Columns.Add("Foreclosure Date", typeof(DateTime));
                dt.Columns.Add("RRCExpirationDate", typeof(DateTime));
                dt.Columns.Add("ClaimEligibleDate", typeof(DateTime));
                dt.Columns.Add("InternalFormID", typeof(int));
                dt.Columns.Add("MarkedForDelete", typeof(bool));
                dt.Columns.Add("OnHoldDate", typeof(DateTime));
                dt.Columns.Add("EnteredDate", typeof(DateTime));
                dt.Columns.Add("EnteredByUser", typeof(string));
                dt.Columns.Add("LastUpdateDate", typeof(DateTime));
                dt.Columns.Add("LastUpdateUser", typeof(string));
                dt.Columns.Add("ReferralTypeID", typeof(int));
                dt.Columns.Add("BusinessEntityIDServicer", typeof(int));
                dt.Columns.Add("BusinessEntityIDMICompany", typeof(int));
                dt.Columns.Add("OldServicerLoanNumber", typeof(string));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                SqlParameter parm = new SqlParameter("@ReferralID", referralID);
                cmd.Parameters.Add(parm);

                cmd.CommandText = "usp_PFU_Referral_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ReferralID"] = int.Parse(dr["ReferralID"].ToString().Length == 0 ? "0" : dr["ReferralID"].ToString());
                    row["REO ID"] = dr["REO_ID"].ToString();
                    row["FNMA Loan Number"] = dr["FNMALoanNumber"].ToString();
                    row["Servicer Name"] = dr["ServicerName"].ToString();
                    row["Servicer Loan Number"] = dr["ServicerLoanNumber"].ToString();
                    row["MI Company Name"] = dr["MICompanyName"].ToString();
                    row["MI Certificate Number"] = dr["MICertificateNumber"].ToString();
                    row["Property Address"] = dr["PropertyAddress"].ToString();
                    row["City"] = dr["City"].ToString();
                    row["State"] = dr["State"].ToString();
                    row["Zip Code"] = dr["ZipCode"].ToString();
                    row["Foreclosure Date"] = DateTime.Parse(dr["ForeclosureDate"].ToString().Length == 0 ? "1/1/1900" : dr["ForeclosureDate"].ToString());
                    row["RRCExpirationDate"] = DateTime.Parse(dr["RRCExpirationDate"].ToString().Length == 0 ? "1/1/1900" : dr["RRCExpirationDate"].ToString());
                    row["ClaimEligibleDate"] = DateTime.Parse(dr["ClaimEligibleDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClaimEligibleDate"].ToString());
                    row["InternalFormID"] = int.Parse(dr["InternalFormID"].ToString().Length == 0 ? "0" : dr["InternalFormID"].ToString());
                    row["MarkedForDelete"] = bool.Parse(dr["MarkedForDelete"].ToString().Length == 0 ? "false" : dr["MarkedForDelete"].ToString());
                    row["OnHoldDate"] = DateTime.Parse(dr["OnHoldDate"].ToString().Length == 0 ? "1/1/1900" : dr["OnHoldDate"].ToString());
                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                    row["EnteredByUser"] = int.Parse(dr["EnteredByUser"].ToString().Length == 0 ? "0" : dr["EnteredByUser"].ToString());
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    row["LastUpdateUser"] = int.Parse(dr["LastUpdateUser"].ToString().Length == 0 ? "0" : dr["LastUpdateUser"].ToString());
                    row["ReferralTypeID"] = int.Parse(dr["ReferralTypeID"].ToString().Length == 0 ? "0" : dr["ReferralTypeID"].ToString());
                    row["BusinessEntityIDServicer"] = int.Parse(dr["BusinessEntityIDServicer"].ToString().Length == 0 ? "0" : dr["BusinessEntityIDServicer"].ToString());
                    row["BusinessEntityIDMICompany"] = int.Parse(dr["BusinessEntityIDMICompany"].ToString().Length == 0 ? "0" : dr["BusinessEntityIDMICompany"].ToString());
                    row["OldServicerLoanNumber"] = dr["OldServicerLoanNumber"].ToString();

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetPFUReferralTypes(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("ReferralTypes");
                DataColumn dc = new DataColumn();

                dc = new DataColumn();
                dc.ColumnName = "ID";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ComboBoxText";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "uspGetPFU_ReferralTypes";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ID"] = int.Parse(dr["ID"].ToString().Length == 0 ? "0" : dr["ID"].ToString());
                    row["ComboBoxText"] = dr["ComboBoxText"].ToString();

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetMICompanyNames(Settings settings)
        {
            try
            {
                int FormID = 9;
                int EntityTypeID = 2;
                CRFS.Data.DataFunctions df = new CRFS.Data.DataFunctions(settings.Get_appmode());

                DataTable dataRaw = new DataTable();

                dataRaw = df.BusinessEntities_Get(FormID);

                DataView dv = new DataView(dataRaw);
                dv.RowFilter = "EntityTypeID = " + EntityTypeID.ToString();

                DataTable data = new DataTable();
                data = dv.ToTable("data");

                return data;

            }

            catch (Exception ex)
            {
                throw ex;

            }


            /*
            SqlConnection con = new SqlConnection(); 
            
            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("MICompanies");

                if (con.State == ConnectionState.Open)
                {
                    SqlCommand cmd = new SqlCommand();
                    SqlParameter prm = new SqlParameter();

                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "usp_PFU_MICompanyName_Select";
                    cmd.Connection = con;

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        dt.Columns.Add("BusinessEntityID", typeof(int));
                        dt.Columns.Add("EntityTypeID", typeof(int));
                        dt.Columns.Add("EntityTypeName", typeof(string));
                        dt.Columns.Add("BusinessEntityName", typeof(string));
                        dt.Columns.Add("IsBackend", typeof(bool));

                        while (reader.Read())
                        {
                            DataRow dr = dt.NewRow();

                            dr["BusinessEntityID"] = int.Parse(reader["BusinessEntityID"].ToString().Length == 0 ? "" : reader["BusinessEntityID"].ToString());
                            dr["EntityTypeID"] = int.Parse(reader["EntityTypeID"].ToString().Length == 0 ? "" : reader["EntityTypeID"].ToString());
                            dr["EntityTypeName"] = reader["EntityTypeName"].ToString().Length == 0 ? "" : reader["EntityTypeName"].ToString();
                            dr["BusinessEntityName"] = reader["BusinessEntityName"].ToString().Length == 0 ? "" : reader["BusinessEntityName"].ToString();
                            dr["IsBackend"] = reader["IsBackend"].ToString().Length == 0 ? false : bool.Parse(reader["IsBackend"].ToString());

                            dt.Rows.Add(dr);
                        }

                    }

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }
            */
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetServicerNames(Settings settings)
        {
            try
            {
                int FormID = 9;
                int EntityTypeID = 1;
                CRFS.Data.DataFunctions df = new CRFS.Data.DataFunctions(settings.Get_appmode());

                DataTable dataRaw = new DataTable();

                dataRaw = df.BusinessEntities_Get(FormID);

                DataView dv = new DataView(dataRaw);
                dv.RowFilter = "EntityTypeID = " + EntityTypeID.ToString();

                DataTable data = new DataTable();
                data = dv.ToTable("data");

                return data;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            /* Original code below is now abandoned
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("Servicers");

                if (con.State == ConnectionState.Open)
                {
                    SqlCommand cmd = new SqlCommand();
                    SqlParameter prm = new SqlParameter();

                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "usp_PFU_ServicerName_Select";
                    cmd.Connection = con;

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        dt.Columns.Add("BusinessEntityID", typeof(int));
                        dt.Columns.Add("EntityTypeID", typeof(int));
                        dt.Columns.Add("EntityTypeName", typeof(string));
                        dt.Columns.Add("BusinessEntityName", typeof(string));

                        while (reader.Read())
                        {
                            DataRow dr = dt.NewRow();

                            dr["BusinessEntityID"] = int.Parse(reader["BusinessEntityID"].ToString().Length == 0 ? "" : reader["BusinessEntityID"].ToString());
                            dr["EntityTypeID"] = int.Parse(reader["EntityTypeID"].ToString().Length == 0 ? "" : reader["EntityTypeID"].ToString());
                            dr["EntityTypeName"] = reader["EntityTypeName"].ToString().Length == 0 ? "" : reader["EntityTypeName"].ToString();
                            dr["BusinessEntityName"] = reader["BusinessEntityName"].ToString().Length == 0 ? "" : reader["BusinessEntityName"].ToString();

                            dt.Rows.Add(dr);
                        }

                    }

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }
            */
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="MICompanyName"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal int InsertMICompany(string MICompanyName, Settings settings)
        {
            //SqlConnection con = new SqlConnection();

            try
            {
                CRFS.Data.DataFunctions df = new CRFS.Data.DataFunctions(settings.Get_appmode());

                int MICompanyID = 0;
                
                //These are two hard coded values.  We are using them to access a new stored procedure for
                //inserting MICompanies for FNMA PFU.  Eventually, this routine will be removed and 
                //the FNMA PFU code modified to directly access the new InsertBusinessEntity routine in CRFS.Data.DataFunctions
                int FormID = 9;
                int EntityTypeID = 2;

                /*
                 * This code is now abandoned
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                if (con.State == ConnectionState.Open)
                {
                    SqlCommand cmd = new SqlCommand();
                    SqlParameter prm = new SqlParameter();

                    cmd.Connection = con;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "usp_PFU_MICompanyName_Insert";

                    prm = new SqlParameter("@MICompanyName", MICompanyName);
                    cmd.Parameters.Add(prm);

                    MICompanyID = int.Parse(cmd.ExecuteScalar().ToString());

                }
                */

                MICompanyID = df.InsertBusinessEntity(MICompanyName, EntityTypeID, FormID);

                return MICompanyID;

            }

            catch (Exception ex)
            {
                throw ex;

            }
            
            /*
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }
            */

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ServicerName"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal int InsertServicer(string ServicerName, Settings settings)
        {
            //SqlConnection con = new SqlConnection();

            try
            {
                CRFS.Data.DataFunctions df = new CRFS.Data.DataFunctions(settings.Get_appmode());

                int ServicerID = 0;

                //These are two hard coded values.  We are using them to access a new stored procedure for
                //inserting Servicers for FNMA PFU.  Eventually, this routine will be removed and 
                //the FNMA PFU code modified to directly access the new InsertBusinessEntity routine in CRFS.Data.DataFunctions
                int FormID = 9;
                int EntityTypeID = 1;

                /*
                 * This code is now abandoned 
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                if (con.State == ConnectionState.Open)
                {
                    SqlCommand cmd = new SqlCommand();
                    SqlParameter prm = new SqlParameter();

                    cmd.Connection = con;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "usp_PFU_ServicerName_Insert";

                    prm = new SqlParameter("@ServicerName", ServicerName);
                    cmd.Parameters.Add(prm);

                    ServicerID = int.Parse(cmd.ExecuteScalar().ToString());

                }
                */

                ServicerID = df.InsertBusinessEntity(ServicerName, EntityTypeID, FormID);

                return ServicerID;

            }

            catch (Exception ex)
            {
                throw ex;

            }
            /*
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }
            */

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool SavePFUReferral(DataTable data, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;

            }

            try
            {
                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                for (int i = 0; i < data.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.Connection = con;

                    switch (data.Rows[i].RowState)
                    {
                        case DataRowState.Modified:
                            cmd.CommandText = "usp_PFU_Referral_Update";

                            parm = new SqlParameter("@ReferralID", data.Rows[i]["ReferralID"]);
                            cmd.Parameters.Add(parm);
                            //Ticket 1767: TRS 20110127. Modified next line to be similar to the referral import routine in MossAutomation
                            parm = new SqlParameter("@REO_ID", data.Rows[i]["REO ID"].ToString().Trim().Length == 0 ? null : data.Rows[i]["REO ID"].ToString());
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FNMALoanNumber", data.Rows[i]["FNMA Loan Number"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ServicerName", data.Rows[i]["Servicer Name"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ServicerLoanNumber", data.Rows[i]["Servicer Loan Number"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@MICompanyName", data.Rows[i]["MI Company Name"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@MICertificateNumber", data.Rows[i]["MI Certificate Number"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@PropertyAddress", data.Rows[i]["Property Address"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@City", data.Rows[i]["City"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@State", data.Rows[i]["State"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ZipCode", data.Rows[i]["Zip Code"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ForeclosureDate", data.Rows[i]["Foreclosure Date"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@RRCExpirationDate", data.Rows[i]["RRCExpirationDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ClaimEligibleDate", data.Rows[i]["ClaimEligibleDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@InternalFormID", data.Rows[i]["InternalFormID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@MarkedForDelete", data.Rows[i]["MarkedForDelete"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@OnHoldDate", data.Rows[i]["OnHoldDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@EnteredDate", data.Rows[i]["EnteredDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@EnteredByUser", data.Rows[i]["EnteredByUser"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateDate", data.Rows[i]["LastUpdateDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateUser", data.Rows[i]["LastUpdateUser"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ReferralTypeID", data.Rows[i]["ReferralTypeID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@BusinessEntityIDServicer", data.Rows[i]["BusinessEntityIDServicer"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@BusinessEntityIDMICompany", data.Rows[i]["BusinessEntityIDMICompany"]);
                            cmd.Parameters.Add(parm);

                            break;

                        default:
                            goto NextRecord;

                    }

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;
                }

                data.AcceptChanges();
                return true;

            }

            catch (Exception e)
            {
                //dump the table into an error file so we have some record of where we were
                try
                {
                    CRFS.Data.ErrorDataDump.DumpTableToDefaultLocation(data, "");
                }

                catch { }
                throw e;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        //[VIP-410] CRZ 20111031 - Moved from Moss.Data
        /// <summary>
        /// Retrieves the PFU details data by referralID.
        /// </summary>
        /// <param name="referralID">Unique referral identifier</param>
        /// <param name="settings">Database connection strings</param>
        /// <returns>Datatable containing the modified data from the UI form.</returns>
        internal DataTable ClaimsManagment_GetPFUDetailsByReferralID(int referralID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("PFUDetails");
                DataColumn dc = new DataColumn();

                dc = new DataColumn();
                dc.ColumnName = "DetailID";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ReferralID";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimFiled";
                dc.DataType = typeof(bool);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimFiledAmount";
                dc.DataType = typeof(decimal);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "CDRTStatusID";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "CDRTStatus";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "MICoResponseToReopenID";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "MICoResponseToReopen";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "FUDocMissing";
                dc.DataType = typeof(bool);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "AllMissingDocsReceived";
                dc.DataType = typeof(bool);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "MIReviewedAndPerfected";
                dc.DataType = typeof(bool);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "SettlementProceedsReceived";
                dc.DataType = typeof(bool);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "SettlementProceedsReceivedAmount";
                dc.DataType = typeof(decimal);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "SettlementTypeID";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "SettlementType";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "StatusID";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "Status";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "SOX_ClaimFiled";
                dc.DataType = typeof(bool);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "SOX_DelayedProceeds";
                dc.DataType = typeof(bool);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "MarkedForDelete";
                dc.DataType = typeof(bool);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "EnteredDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "EnteredByUser";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "EnteredByUserName";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "LastUpdateDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "LastUpdateUser";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "LastUpdateUserName";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "uspGetPFU_DetailsByReferralID";
                cmd.Connection = con;

                SqlParameter parm = new SqlParameter("@ReferralID", referralID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["DetailID"] = int.Parse(dr["DetailID"].ToString().Length == 0 ? "0" : dr["DetailID"].ToString());
                    row["ReferralID"] = int.Parse(dr["ReferralID"].ToString().Length == 0 ? "0" : dr["ReferralID"].ToString());
                    row["ClaimFiled"] = bool.Parse(dr["ClaimFiled"].ToString().Length == 0 ? "false" : dr["ClaimFiled"].ToString());
                    row["ClaimFiledAmount"] = decimal.Parse(dr["ClaimFiledAmount"].ToString().Length == 0 ? "0" : dr["ClaimFiledAmount"].ToString());
                    row["CDRTStatusID"] = int.Parse(dr["CDRTStatusID"].ToString().Length == 0 ? "0" : dr["CDRTStatusID"].ToString());
                    row["CDRTStatus"] = dr["CDRTStatus"].ToString();
                    row["MICoResponseToReopenID"] = int.Parse(dr["MICoResponseToReopenID"].ToString().Length == 0 ? "0" : dr["MICoResponseToReopenID"].ToString());
                    row["MICoResponseToReopen"] = dr["MICoResponseToReopen"].ToString();
                    row["FUDocMissing"] = bool.Parse(dr["FUDocMissing"].ToString().Length == 0 ? "false" : dr["FUDocMissing"].ToString());
                    row["AllMissingDocsReceived"] = bool.Parse(dr["AllMissingDocsReceived"].ToString().Length == 0 ? "false" : dr["AllMissingDocsReceived"].ToString());
                    row["MiReviewedAndPerfected"] = bool.Parse(dr["MiReviewedAndPerfected"].ToString().Length == 0 ? "false" : dr["MiReviewedAndPerfected"].ToString());
                    row["SettlementProceedsReceived"] = bool.Parse(dr["SettlementProceedsReceived"].ToString().Length == 0 ? "false" : dr["SettlementProceedsReceived"].ToString());
                    row["SettlementProceedsReceivedAmount"] = decimal.Parse(dr["SettlementProceedsReceivedAmount"].ToString().Length == 0 ? "0" : dr["SettlementProceedsReceivedAmount"].ToString());
                    row["SettlementTypeID"] = int.Parse(dr["SettlementTypeID"].ToString().Length == 0 ? "0" : dr["SettlementTypeID"].ToString());
                    row["SettlementType"] = dr["SettlementType"].ToString();
                    row["StatusID"] = int.Parse(dr["StatusID"].ToString().Length == 0 ? "0" : dr["StatusID"].ToString());
                    row["Status"] = dr["Status"].ToString();
                    row["SOX_ClaimFiled"] = bool.Parse(dr["SOX_ClaimFiled"].ToString().Length == 0 ? "false" : dr["SOX_ClaimFiled"].ToString());
                    row["SOX_DelayedProceeds"] = bool.Parse(dr["SOX_DelayedProceeds"].ToString().Length == 0 ? "false" : dr["SOX_DelayedProceeds"].ToString());
                    row["MarkedForDelete"] = bool.Parse(dr["MarkedForDelete"].ToString().Length == 0 ? "false" : dr["MarkedForDelete"].ToString());
                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                    row["EnteredByUser"] = int.Parse(dr["EnteredByUser"].ToString().Length == 0 ? "0" : dr["EnteredByUser"].ToString());
                    row["EnteredByUserName"] = dr["EnteredByUserName"].ToString();
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    row["LastUpdateUser"] = int.Parse(dr["LastUpdateUser"].ToString().Length == 0 ? "0" : dr["LastUpdateUser"].ToString());
                    row["LastUpdateUserName"] = dr["LastUpdateUserName"].ToString();

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        //[VIP-410] CRZ 20111031 - Moved from Moss.Data
        /// <summary>
        /// Stores the PFU referral details data.
        /// </summary>
        /// <param name="data">Datatable containing the modified data from the UI form.</param>
        /// <param name="settings">Database connection strings</param>
        /// <returns></returns>
        internal bool ClaimsManagement_SavePFUDetails(DataTable data, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }
            catch (Exception e)
            {
                throw e;
            }

            try
            {
                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                for (int i = 0; i < data.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.Connection = con;

                    switch (data.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            cmd.CommandText = "usptblPFU_Details_Insert";

                            parm = new SqlParameter("@ReferralID", data.Rows[i]["ReferralID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ClaimFiled", data.Rows[i]["ClaimFiled"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ClaimFiledAmount", data.Rows[i]["ClaimFiledAmount"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@CDRTStatusID", data.Rows[i]["CDRTStatusID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@MICoResponseToReopenID", data.Rows[i]["MICoResponseToReopenID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FUDocMissing", data.Rows[i]["FUDocMissing"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@AllMissingDocsReceived", data.Rows[i]["AllMissingDocsReceived"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@MiReviewedAndPerfected", data.Rows[i]["MiReviewedAndPerfected"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@SettlementProceedsReceived", data.Rows[i]["SettlementProceedsReceived"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@SettlementProceedsReceivedAmount", data.Rows[i]["SettlementProceedsReceivedAmount"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@SettlementTypeID", data.Rows[i]["SettlementTypeID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@StatusID", data.Rows[i]["StatusID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@SOX_ClaimFiled", data.Rows[i]["SOX_ClaimFiled"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@SOX_DelayedProceeds", data.Rows[i]["SOX_DelayedProceeds"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@MarkedForDelete", data.Rows[i]["MarkedForDelete"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@EnteredDate", data.Rows[i]["EnteredDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@EnteredByUser", data.Rows[i]["EnteredByUser"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateDate", data.Rows[i]["LastUpdateDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateUser", data.Rows[i]["LastUpdateUser"]);
                            cmd.Parameters.Add(parm);

                            break;

                        case DataRowState.Modified:
                            cmd.CommandText = "usptblPFU_Details_Update";

                            parm = new SqlParameter("@DetailID", data.Rows[i]["DetailID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ReferralID", data.Rows[i]["ReferralID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ClaimFiled", data.Rows[i]["ClaimFiled"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ClaimFiledAmount", data.Rows[i]["ClaimFiledAmount"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@CDRTStatusID", data.Rows[i]["CDRTStatusID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@MICoResponseToReopenID", data.Rows[i]["MICoResponseToReopenID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FUDocMissing", data.Rows[i]["FUDocMissing"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@AllMissingDocsReceived", data.Rows[i]["AllMissingDocsReceived"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@MiReviewedAndPerfected", data.Rows[i]["MiReviewedAndPerfected"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@SettlementProceedsReceived", data.Rows[i]["SettlementProceedsReceived"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@SettlementProceedsReceivedAmount", data.Rows[i]["SettlementProceedsReceivedAmount"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@SettlementTypeID", data.Rows[i]["SettlementTypeID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@StatusID", data.Rows[i]["StatusID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@SOX_ClaimFiled", data.Rows[i]["SOX_ClaimFiled"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@SOX_DelayedProceeds", data.Rows[i]["SOX_DelayedProceeds"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@MarkedForDelete", data.Rows[i]["MarkedForDelete"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateDate", data.Rows[i]["LastUpdateDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateUser", data.Rows[i]["LastUpdateUser"]);
                            cmd.Parameters.Add(parm);

                            break;

                        case DataRowState.Deleted:
                            cmd.CommandText = "usptblPFU_Details_Delete";

                            parm = new SqlParameter("@DateID", data.Rows[i]["DateID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateDate", data.Rows[i]["LastUpdateDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateUser", data.Rows[i]["LastUpdateUser"]);
                            cmd.Parameters.Add(parm);

                            break;

                        case DataRowState.Detached:
                            goto NextRecord;

                        case DataRowState.Unchanged:
                            goto NextRecord;

                        default:
                            break;
                    }

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;
                }

                data.AcceptChanges();
                return true;
            }

            catch (Exception e)
            {
                //dump the table into an error file so we have some record of where we were
                try
                {
                    CRFS.Data.ErrorDataDump.DumpTableToDefaultLocation(data, "");
                }

                catch { }
                throw e;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        // [VIP 410] 20110726 CRZ Added report-specific routines for reports. Changed to usage of application specific data table for reports.
        internal DataTable GetPFUReporting_ClaimFiledUpdateReport(Settings settings, int ReferralTypeID, string[] optParms)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("PFUClaimFiledUpdateReport");
                DataColumn dc = new DataColumn();

                dc = new DataColumn();
                dc.ColumnName = "ReferralNumber";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimAmount";
                dc.DataType = typeof(decimal);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimFiledDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "DelayType";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "DelayFollowUpDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "Region";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                SqlParameter parm = new SqlParameter();
                cmd.CommandText = "usprpt_PFU_ClaimFiledUpdate";

                parm = new SqlParameter("@ReferralTypeID", ReferralTypeID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@StartDate", optParms[0]);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@EndDate", optParms[1]);
                cmd.Parameters.Add(parm);
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ReferralNumber"] = dr["ReferralNumber"].ToString();
                    row["ClaimAmount"] = decimal.Parse(dr["ClaimAmount"].ToString().Length == 0 ? "0" : dr["ClaimAmount"].ToString());
                    row["ClaimFiledDate"] = DateTime.Parse(dr["ClaimFiledDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClaimFiledDate"].ToString());
                    row["DelayType"] = dr["DelayType"].ToString();
                    row["DelayFollowUpDate"] = DateTime.Parse(dr["DelayFollowUpDate"].ToString().Length == 0 ? "1/1/1900" : dr["DelayFollowUpDate"].ToString());
                    row["Region"] = dr["Region"].ToString();

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        // [VIP 410] 20110726 CRZ Added report-specific routines for reports. Changed to usage of application specific data table for reports.
        internal DataTable GetPFUReporting_DelayedProceedsUpdateReport(Settings settings, int ReferralTypeID, string[] optParms)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("PFUDelayedProceedsUpdateReport");
                DataColumn dc = new DataColumn();

                dc = new DataColumn();
                dc.ColumnName = "ReferralNumber";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "DelayTypeCode";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "Generic_Money_Field";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "Comment";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                SqlParameter parm = new SqlParameter();

                cmd.CommandText = "usprpt_PFU_DelayedProceedsUpdate";

                parm = new SqlParameter("@ReferralTypeID", ReferralTypeID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@StartDate", optParms[0]);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@EndDate", optParms[1]);
                cmd.Parameters.Add(parm);
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ReferralNumber"] = dr["ReferralNumber"].ToString();
                    row["DelayTypeCode"] = dr["DelayTypeCode"].ToString();
                    row["Generic_Money_Field"] = dr["Generic_Money_Field"].ToString();
                    row["Comment"] = dr["Comment"].ToString();

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        internal DataTable GetPFUReporting_CommentUpdateReport(Settings settings, int ReferralTypeID, string[] optParms)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("PFUCommentUpdateReport");
                DataColumn dc = new DataColumn();

                dc = new DataColumn();
                dc.ColumnName = "ReferralNumber";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "Comment";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "CommentType";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                //Ticket 2081 20110228 TRS - Comment update report is taking over a minute and the default timout is 60 seconds
                //Using the extra time timeout value (currently set to 120 seconds) to resolve.
                cmd.CommandTimeout = Configuration.CommandTimeouts_Extra_ClaimsManagementSQLDatabase;

                SqlParameter parm = new SqlParameter();

                cmd.CommandText = "usprpt_PFU_CommentUpdate";

                parm = new SqlParameter("@ReferralTypeID", ReferralTypeID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@StartDate", optParms[0]);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@EndDate", optParms[1]);
                cmd.Parameters.Add(parm);
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ReferralNumber"] = dr["ReferralNumber"].ToString();
                    row["Comment"] = dr["Comments"].ToString();
                    row["CommentType"] = dr["CommentType"].ToString();

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// Returns referral lock information for the FNMA PFU application.
        /// </summary>
        /// <param name="settings">Database connection settings</param>
        /// <returns>Table of all current locks for the FNMA PFU application</returns>
        internal DataTable PFU_Locks_List_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("PFU_Locks");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("LockID", typeof(int));
                dt.Columns.Add("FormID", typeof(int));
                dt.Columns.Add("Form Name", typeof(string));
                dt.Columns.Add("ReferralID", typeof(int));
                dt.Columns.Add("FNMA Loan Number", typeof(string));
                dt.Columns.Add("REO ID", typeof(string));
                dt.Columns.Add("Workstation Name", typeof(string));
                dt.Columns.Add("LockedByUserID", typeof(int));
                dt.Columns.Add("Locked By User Name", typeof(string));
                dt.Columns.Add("LockDate", typeof(DateTime));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_PFU_Locks_List";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["LockID"] = int.Parse(dr["LockID"].ToString().Length == 0 ? "0" : dr["LockID"].ToString());
                    row["FormID"] = int.Parse(dr["FormID"].ToString().Length == 0 ? "0" : dr["FormID"].ToString());
                    row["Form Name"] = dr["FormName"].ToString();
                    row["ReferralID"] = int.Parse(dr["ReferralID"].ToString().Length == 0 ? "0" : dr["ReferralID"].ToString());
                    row["FNMA Loan Number"] = dr["FNMALoanNumber"].ToString();
                    row["REO ID"] = dr["REO_ID"].ToString();
                    row["Workstation Name"] = dr["WorkstationName"].ToString();
                    row["LockedByUserID"] = int.Parse(dr["LockedByUserID"].ToString().Length == 0 ? "0" : dr["LockedByUserID"].ToString());
                    row["Locked By User Name"] = dr["LockedByUserName"].ToString();
                    row["LockDate"] = DateTime.Parse(dr["LockDate"].ToString().Length == 0 ? "1/1/1900" : dr["LockDate"].ToString());

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Handles INSERT, UPDATE and DELETE for FNMA PFU locks. 
        /// For new lock requests, an INSERT is attempted. An INSERT via this routine
        /// would have been initialed by a 'Find' on a specific FNMA Loan Number and
        /// REO ID, or a selection from the 'Find' dialog as a result of a wildcard search.
        /// If successful, the LockID is returned. If unsuccessful, an error code is returned.
        /// For an UPDATE, the LockedDate will updated to reflect the new lock date/time.
        /// Updates will also only occur when a user is re-opening a referral/claim that
        /// had been previously opened and for which a lock already exists.
        /// For a DELETE, the lock specified by the LockID will be removed.
        /// </summary>
        /// <param name="data">Lock record to process</param>
        /// <param name="settings">Database connection settings</param>
        /// <returns></returns>
        internal bool PFU_Lock_Save(DataTable data, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                for (int i = 0; i < data.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.Connection = con;

                    switch (data.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            //The usp_PFU_Lock_Request wraps the usp_Lock_Insert to provide
                            //  the application specific primary and secondary referral/claim
                            //  identifiers. For FNMA PFU, these are the FNMA Loan
                            //  Number and REO ID respectively.
                            cmd.CommandText = "usp_PFU_Lock_Request";

                            //For an INSERT to be successful, the ReferralID OR the FNMA Loan
                            //  Number AND the REO ID must be specified.
                            parm = new SqlParameter("@FormID", data.Rows[i]["FormID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ReferralID", data.Rows[i]["ReferralID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FNMALoanNumber", data.Rows[i]["FNMA Loan Number"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@REO_ID", data.Rows[i]["REO ID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@WorkstationName", data.Rows[i]["Workstation Name"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LockedByUserID", data.Rows[i]["LockedByUserID"]);
                            cmd.Parameters.Add(parm);

                            //Now we need to execute a stored procedure that returns the new record ID or error code
                            data.Rows[i]["LockID"] = int.Parse(cmd.ExecuteScalar().ToString());

                            goto NextRecord;

                        case DataRowState.Modified:
                            //
                            cmd.CommandText = "usp_Lock_Update";

                            parm = new SqlParameter("@LockID", data.Rows[i]["LockID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LockDate", data.Rows[i]["LockDate"]);
                            cmd.Parameters.Add(parm);
                            break;

                        case DataRowState.Deleted:
                            //Referral/Claim being closed, delete the associated lock
                            cmd.CommandText = "usp_Lock_Delete";

                            parm = new SqlParameter("@LockID", data.Rows[i]["LockID", DataRowVersion.Original]);
                            cmd.Parameters.Add(parm);
                            break;

                        default:
                            goto NextRecord;
                    }

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;
                }

                data.AcceptChanges();

                return true;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Handles INSERT for FNMA PFU Locks
        /// Normally, this is not the routine to use to obtain a lock.  It is used
        /// when no table exists to supply the parameters needed to get a lock for a PFU referral record
        /// </summary>
        /// <param name="WorkstationName">REQUIRED - The name of the workstation where the referral lock is being requested</param>
        /// <param name="LockedByUserID">REQUIRED - The userID of the user requesting the lock</param>
        /// <param name="ReferralID">OPTIONAL - The ID of the referral a lock is desired for</param>
        /// <param name="FNMALoanNumber">OPTIONAL - The FNMA Loan Number of the referral a lock is desired for</param>
        /// <param name="REO_ID">OPTIONAL - The REO ID of the referral a lock is desired for</param>
        /// <param name="FormID">OPTIONAL - The FNMA PFU Form ID. should be 9, if supplied</param>
        /// <returns>positive integer if a lock is obtained.  A negative integer if a lock can't be obtained
        /// -2000 =  Could not locate a referralID with the FNMA Loan Number and REO ID provided
        /// -1000 = UK1: Form ID and Entity ID constraint error
        /// -1001 = UK2: LockedByUserID constraint error
        /// -1002 = UK3: WorkstationName constraint error</returns>
        internal int PFU_Lock_Request(string WorkstationName, int LockedByUserID, int ReferralID = 0, string FNMALoanNumber = null, string REO_ID = null, int FormID = 0)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();

            }

            catch (Exception e)
            {
                throw e;

            }

            try
            {
                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.Connection = con;

                //The usp_PFU_Lock_Request wraps the usp_Lock_Insert to provide
                //  the application specific primary and secondary referral/claim
                //  identifiers. For FNMA PFU, these are the FNMA Loan
                //  Number and REO ID respectively.
                cmd.CommandText = "usp_PFU_Lock_Request";

                //For an INSERT to be successful, the ReferralID OR the FNMA Loan
                //  Number AND the REO ID must be specified.
                parm = new SqlParameter("@FormID", FormID == 0 ? SqlInt32.Null : FormID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@ReferralID", ReferralID == 0 ? SqlInt32.Null : ReferralID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@FNMALoanNumber", FNMALoanNumber == null ? "" : FNMALoanNumber);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@REO_ID", REO_ID == null ? "" : REO_ID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@WorkstationName", WorkstationName);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@LockedByUserID", LockedByUserID);
                cmd.Parameters.Add(parm);

                //Now we need to execute a stored procedure that returns the new record ID or error code
                recordsAffected = int.Parse(cmd.ExecuteScalar().ToString());

                return recordsAffected;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// Handles DELETE for FNMA PFU Loacks
        /// Normally, this is not the routine to use to release a lock.  It is used
        /// when no table exists to supply the parameters needed to release a lock for a PFU referral record
        /// </summary>
        /// <param name="LockID">The ID of the lock to be released (deleted)</param>
        /// <returns>True, the lock was released</returns>
        internal bool PFU_Lock_Release(int LockID)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();

            }

            catch (Exception e)
            {
                throw e;

            }

            try
            {
                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.Connection = con;

                cmd.CommandText = "usp_Lock_Delete";

                parm = new SqlParameter("@LockID", LockID);
                cmd.Parameters.Add(parm);

                recordsAffected = cmd.ExecuteNonQuery();

                return true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// Clears the SOX bitfield
        /// </summary>
        /// <param></param>
        /// <returns>True, the lock was released</returns>
        
        internal bool ClaimsManagement_ClearSoxClaimedFiled()
        {
            bool ret = false;
            // using automatically closes the con at the end of the block
            using (SqlConnection con=new SqlConnection(_settings.GetConnectionString("ClaimsManagement"))) 
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    Object returnValue;

                    cmd.CommandText = "usp_PFU_Clear_SOX_Claim_Filed";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = con;


                    returnValue = cmd.ExecuteScalar();
                    // test to make sure return value is 0 else return false
                    ret = Convert.ToInt32(returnValue) == 0;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return ret;
        }

        #endregion

        #region "FNMA Recon"

        // fb4102 gk 20140710
        /// <summary>
        /// clears all the locks for a given user and workstation
        /// </summary>
        /// <param name="LockedByUserID">userid</param>
        /// <param name="WorkStationName">workstation name</param>
        /// <returns></returns>
        internal bool ClearLocksForUserAndStation(int LockedByUserID, string WorkStationName,Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.Connection = con;
                cmd.CommandText = "usp_CNTL_ClearLocksForUserAndStation";

                SqlParameter parm = new SqlParameter();

                parm = new SqlParameter("@WorkStationName",WorkStationName);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@LockedByUserID", LockedByUserID);
                cmd.Parameters.Add(parm);

                cmd.ExecuteNonQuery();

                return true;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        
        #endregion

        #region "FNMA Asset Collections"
        #region "Advance Payment"
        /// <summary>
        /// Retrieves all table data for the AdvPmtReferral table. Some additional columns
        /// are included for the string translation of ID lookup values.
        /// </summary>
        /// <param name="referralID">The PK referral ID of interest.</param>
        /// <param name="settings">Database connection information</param>
        /// <returns>A table with a single row containing the AdvPayment data.</returns>
       

        /// <summary>
        /// Saves data for the AdvPmtReferral record via the AdvPmt update 
        /// stored procedure.
        /// </summary>
        /// <param name="data">Table of data for the AdvPmt referral record.</param>
        /// <param name="settings">Database connection information</param>
        /// <returns>Boolean indicator of success for failure.</returns>
        internal bool AssetColl_AdvPmt_Save(DataTable data, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }
            catch (Exception e)
            {
                throw e;
            }

            try
            {
                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                for (int i = 0; i < data.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.Connection = con;

                    switch (data.Rows[i].RowState)
                    {
                        case DataRowState.Modified:
                            cmd.CommandText = "usp_AssetColl_AdvPmtReferral_Update";

                            parm = new SqlParameter("@AdvPmtReferralID", data.Rows[i]["AdvPmtReferralID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ServicerID", data.Rows[i]["ServicerID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ServicerLoanNumber", data.Rows[i]["Servicer Loan Number"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ServicerNumber", data.Rows[i]["Servicer Number"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@PropertyState", data.Rows[i]["Property State"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastDisbursementDate", data.Rows[i]["Last Disbursement Date"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@DaysSinceLastDisbursement", data.Rows[i]["DaysSinceLastDisbursement"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LoanStatus", data.Rows[i]["Loan Status"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LoanStatusDate", data.Rows[i]["Loan Status Date"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@DaysSinceLoanStatus", data.Rows[i]["Days Since Loan Status"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@MonthsAged", data.Rows[i]["Months Aged"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@AgeBuckets", data.Rows[i]["Age Buckets"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@CurrentLPI_Date", data.Rows[i]["Current LPI Date"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@InsurerType", data.Rows[i]["Insurer Type"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FCL_LossRiskCode", data.Rows[i]["FCL Loss Risk Code"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@DARTS_Flag", data.Rows[i]["DARTS Flag"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@TrueFNMA_GL", data.Rows[i]["True FNMA GL"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@PrepNameOfDisbursement", data.Rows[i]["Preparer Name of Disbursement"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@PrepPhoneDisbursement", data.Rows[i]["Preparer Phone Number"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@AdvPmtStatusID", data.Rows[i]["AdvPmtStatusID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@Imported", data.Rows[i]["Imported"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ImportDate", data.Rows[i]["Import Date"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateDate", data.Rows[i]["LastUpdateDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateUserID", data.Rows[i]["LastUpdateUserID"]);
                            cmd.Parameters.Add(parm);
                            break;

                        default:
                            goto NextRecord;
                    }
                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;
                }

                data.AcceptChanges();
                return true;
            }

            catch (Exception ex)
            {
                //dump the table into an error file so we have some record of where we were
                try
                {
                    CRFS.Data.ErrorDataDump.DumpTableToDefaultLocation(data, "");
                }

                catch { }

                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Retrieves all AdvPmt comments for the specified referral ID.
        /// </summary>
        /// <param name="referralID">The PK referral ID of interest.</param>
        /// <param name="settings">Database connection information</param>
        /// <returns>DataTable with all comments for the FNMA Asset Collections AdvPmt referral specified.</returns>
        internal DataTable AssetColl_AdvPmtComments_Get(int advPmtReferralID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("AdvPmtComments");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("AdvPmtCommentID", typeof(int));
                dt.Columns.Add("AdvPmtReferralID", typeof(int));
                dt.Columns.Add("CommentTypeID", typeof(int));
                dt.Columns.Add("CommentType", typeof(string));
                dt.Columns.Add("FollowupDate", typeof(DateTime));
                dt.Columns.Add("FollowupComplete", typeof(bool));
                dt.Columns.Add("CommentText", typeof(string));
                dt.Columns.Add("EnteredDate", typeof(DateTime));
                dt.Columns.Add("EnteredByUserID", typeof(int));
                dt.Columns.Add("EnteredByUser", typeof(string));
                dt.Columns.Add("LastUpdateDate", typeof(DateTime));
                dt.Columns.Add("LastUpdateUserID", typeof(int));
                dt.Columns.Add("LastUpdateUser", typeof(string));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                SqlParameter parm = new SqlParameter("@AdvPmtReferralID", advPmtReferralID);
                cmd.Parameters.Add(parm);

                cmd.CommandText = "usp_AssetColl_AdvPmtComment_Select";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["AdvPmtCommentID"] = int.Parse(dr["AdvPmtCommentID"].ToString().Length == 0 ? "0" : dr["AdvPmtCommentID"].ToString());
                    row["AdvPmtReferralID"] = int.Parse(dr["AdvPmtReferralID"].ToString().Length == 0 ? "0" : dr["AdvPmtReferralID"].ToString());
                    row["CommentTypeID"] = int.Parse(dr["CommentTypeID"].ToString().Length == 0 ? "0" : dr["CommentTypeID"].ToString());
                    row["CommentType"] = dr["CommentType"].ToString();
                    row["FollowupComplete"] = bool.Parse(dr["FollowupComplete"].ToString().Length == 0 ? "false" : dr["FollowupComplete"].ToString());
                    row["FollowupDate"] = DateTime.Parse(dr["FollowupDate"].ToString().Length == 0 ? "1/1/1900" : dr["FollowupDate"].ToString());
                    row["CommentText"] = dr["CommentText"].ToString();
                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                    row["EnteredByUserID"] = int.Parse(dr["EnteredByUserID"].ToString().Length == 0 ? "0" : dr["EnteredByUserID"].ToString());
                    row["EnteredByUser"] = dr["EnteredByUser"].ToString();
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    row["LastUpdateUserID"] = int.Parse(dr["LastUpdateUserID"].ToString().Length == 0 ? "0" : dr["LastUpdateUserID"].ToString());
                    row["LastUpdateUser"] = dr["LastUpdateUser"].ToString();

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Saves the comment records for the current referral
        /// </summary>
        /// <param name="data">Table of comment data to store</param>
        /// <param name="settings">Database connection information</param>
        /// <returns>Boolean flag indicating success or failure.</returns>
        internal bool AssetColl_AdvPmtComments_Save(DataTable data, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                for (int i = 0; i < data.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.Connection = con;

                    switch (data.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            cmd.CommandText = "usp_AssetColl_AdvPmtComment_Insert";

                            parm = new SqlParameter("@AdvPmtReferralID", data.Rows[i]["AdvPmtReferralID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@CommentTypeID", data.Rows[i]["CommentTypeID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FollowupComplete", data.Rows[i]["FollowupComplete"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FollowupDate", data.Rows[i]["FollowupDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@CommentText", data.Rows[i]["CommentText"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@EnteredDate", data.Rows[i]["EnteredDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@EnteredByUserID", data.Rows[i]["EnteredByUserID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateDate", data.Rows[i]["LastUpdateDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateUserID", data.Rows[i]["LastUpdateUserID"]);
                            cmd.Parameters.Add(parm);

                            //Now we need to execute a stored procedure that returns the new record ID
                            data.Rows[i]["AdvPmtCommentID"] = int.Parse(cmd.ExecuteScalar().ToString());

                            goto NextRecord;

                        case DataRowState.Modified:
                            cmd.CommandText = "usp_AssetColl_AdvPmtComment_Update";

                            parm = new SqlParameter("@AdvPmtReferralID", data.Rows[i]["AdvPmtReferralID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@AdvPmtCommentID", data.Rows[i]["AdvPmtCommentID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@CommentTypeID", data.Rows[i]["CommentTypeID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FollowupComplete", data.Rows[i]["FollowupComplete"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FollowupDate", data.Rows[i]["FollowupDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@CommentText", data.Rows[i]["CommentText"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateDate", data.Rows[i]["LastUpdateDate"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LastUpdateUserID", data.Rows[i]["LastUpdateUserID"]);
                            cmd.Parameters.Add(parm);

                            break;

                        default:
                            goto NextRecord;
                    }

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;
                }

                data.AcceptChanges();

                return true;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
        #endregion

        #region "Common"
        

        


        

        

        /// <summary>
        /// Retrieves the edit history for the specified Referral ID. The Referral ID and
        /// ReferralTypeID are required to match the correct record. The audit table will 
        /// store results for all Asset Collections transactions, so the referralID may not 
        /// be unique. The combination of referralID and referralTypeID, however, wil be.
        /// </summary>
        /// <param name="referralID">Record identifier to retrieve data for.</param>
        /// <param name="referralTypeID">ID from tbllkp_Forms_ComboBoxValues indicating which type of Asset Collection this record belongs to.</param>
        /// <param name="settings">Database connection information</param>
        /// <returns>Datatable of all history records for the specified FNMA Asset Collections referral.</returns>
        internal DataTable AssetColl_EditHistory_Get(int referralID, int referralTypeID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("EditHistory");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("AuditID", typeof(int));
                dt.Columns.Add("Type", typeof(string));
                dt.Columns.Add("ReferralID", typeof(int));
                dt.Columns.Add("ReferralTypeID", typeof(int));
                dt.Columns.Add("TableName", typeof(string));
                dt.Columns.Add("PrimaryKeyField", typeof(string));
                dt.Columns.Add("PrimaryKeyValue", typeof(string));
                dt.Columns.Add("FieldName", typeof(string));
                dt.Columns.Add("OldValue", typeof(string));
                dt.Columns.Add("NewValue", typeof(string));
                dt.Columns.Add("UpdateDate", typeof(DateTime));
                dt.Columns.Add("UserName", typeof(string));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                SqlParameter parm = new SqlParameter("@ReferralID", referralID);
                cmd.Parameters.Add(parm);

                parm = new SqlParameter("@ReferralTypeID", referralTypeID);
                cmd.Parameters.Add(parm);

                cmd.CommandText = "usp_AssetColl_Referral_Edit_History";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["AuditID"] = int.Parse(dr["AuditID"].ToString().Length == 0 ? "0" : dr["AuditID"].ToString());
                    row["Type"] = dr["Type"].ToString();
                    row["ReferralID"] = int.Parse(dr["ReferralID"].ToString().Length == 0 ? "0" : dr["ReferralID"].ToString());
                    row["ReferralTypeID"] = int.Parse(dr["ReferralTypeID"].ToString().Length == 0 ? "0" : dr["ReferralTypeID"].ToString());
                    row["TableName"] = dr["TableName"].ToString();
                    row["PrimaryKeyField"] = dr["PrimaryKeyField"].ToString();
                    row["PrimaryKeyValue"] = dr["PrimaryKeyValue"].ToString();
                    row["FieldName"] = dr["FieldName"].ToString();
                    row["OldValue"] = dr["OldValue"].ToString();
                    row["NewValue"] = dr["NewValue"].ToString();
                    row["UpdateDate"] = DateTime.Parse(dr["UpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["UpdateDate"].ToString());
                    row["UserName"] = dr["UserName"].ToString();

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

       

        /// <summary>
        /// Returns referral lock information for the FNMA Asset Collections application.
        /// </summary>
        /// <param name="lockFormID">Unique identifier for the Asset Collection referral type</param>
        /// <param name="referralTypeID">ID from tbllkp_Forms_ComboBoxValues indicating which type of Asset Collection this record belongs to.</param>
        /// <param name="settings">Database connection settings</param>
        /// <returns>Table of all current locks for the FNMA Asset Collections application</returns>
        internal DataTable AssetColl_Locks_List_Get(int lockFormID, int referralTypeID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("AssetCollLocks");
                DataColumn dc = new DataColumn();

                dt.Columns.Add("LockID", typeof(int));
                dt.Columns.Add("FormID", typeof(int));
                dt.Columns.Add("Form Name", typeof(string));
                dt.Columns.Add("ReferralID", typeof(int));
                dt.Columns.Add("FNMA Loan Number", typeof(string));
                dt.Columns.Add("REO ID", typeof(string));
                dt.Columns.Add("Workstation Name", typeof(string));
                dt.Columns.Add("LockedByUserID", typeof(int));
                dt.Columns.Add("Locked By User Name", typeof(string));
                dt.Columns.Add("LockDate", typeof(DateTime));

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                SqlParameter parm = new SqlParameter("@LockFormID", lockFormID);
                cmd.Parameters.Add(parm);

                parm = new SqlParameter("@ReferralTypeID", referralTypeID);
                cmd.Parameters.Add(parm);

                cmd.CommandText = "usp_AssetColl_Locks_List";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["LockID"] = int.Parse(dr["LockID"].ToString().Length == 0 ? "0" : dr["LockID"].ToString());
                    row["FormID"] = int.Parse(dr["FormID"].ToString().Length == 0 ? "0" : dr["FormID"].ToString());
                    row["Form Name"] = dr["FormName"].ToString();
                    row["ReferralID"] = int.Parse(dr["ReferralID"].ToString().Length == 0 ? "0" : dr["ReferralID"].ToString());
                    row["FNMA Loan Number"] = dr["FNMALoanNumber"].ToString();
                    row["REO ID"] = dr["REO_ID"].ToString();
                    row["Workstation Name"] = dr["WorkstationName"].ToString();
                    row["LockedByUserID"] = int.Parse(dr["LockedByUserID"].ToString().Length == 0 ? "0" : dr["LockedByUserID"].ToString());
                    row["Locked By User Name"] = dr["LockedByUserName"].ToString();
                    row["LockDate"] = DateTime.Parse(dr["LockDate"].ToString().Length == 0 ? "1/1/1900" : dr["LockDate"].ToString());

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Handles INSERT, UPDATE and DELETE for FNMA Asset Collections locks. 
        /// For new lock requests, an INSERT is attempted. An INSERT via this routine
        /// would have been initialed by a 'Find' on a specific FNMA Loan Number and
        /// REO ID, or a selection from the 'Find' dialog as a result of a wildcard search.
        /// If successful, the LockID is returned. If unsuccessful, an error code is returned.
        /// For an UPDATE, the LockedDate will updated to reflect the new lock date/time.
        /// Updates will also only occur when a user is re-opening a referral/claim that
        /// had been previously opened and for which a lock already exists.
        /// For a DELETE, the lock specified by the LockID will be removed.
        /// </summary>
        /// <param name="data">Lock record to process</param>
        /// <param name="settings">Database connection settings</param>
        /// <returns></returns>
        internal bool AssetColl_Lock_Save(DataTable data, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                for (int i = 0; i < data.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.Connection = con;

                    switch (data.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            //The usp_Recon_Lock_Request wraps the usp_Lock_Insert to provide
                            //  the application specific primary and secondary referral/claim
                            //  identifiers. For FNMA Reconciliation, these are the FNMA Loan
                            //  Number and REO ID respectively.
                            cmd.CommandText = "usp_AssetColl_Lock_Request";

                            //For an INSERT to be successful, the ReferralID OR the FNMA Loan
                            //  Number AND the REO ID must be specified.
                            parm = new SqlParameter("@FormID", data.Rows[i]["FormID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@ReferralID", data.Rows[i]["ReferralID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@FNMALoanNumber", data.Rows[i]["FNMA Loan Number"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@REO_ID", data.Rows[i]["REO ID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@WorkstationName", data.Rows[i]["Workstation Name"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LockedByUserID", data.Rows[i]["LockedByUserID"]);
                            cmd.Parameters.Add(parm);

                            //Now we need to execute a stored procedure that returns the new record ID or error code
                            data.Rows[i]["LockID"] = int.Parse(cmd.ExecuteScalar().ToString());

                            goto NextRecord;

                        case DataRowState.Modified:
                            //
                            cmd.CommandText = "usp_Lock_Update";

                            parm = new SqlParameter("@LockID", data.Rows[i]["LockID"]);
                            cmd.Parameters.Add(parm);
                            parm = new SqlParameter("@LockDate", data.Rows[i]["LockDate"]);
                            cmd.Parameters.Add(parm);
                            break;

                        case DataRowState.Deleted:
                            //Referral/Claim being closed, delete the associated lock
                            cmd.CommandText = "usp_Lock_Delete";

                            parm = new SqlParameter("@LockID", data.Rows[i]["LockID", DataRowVersion.Original]);
                            cmd.Parameters.Add(parm);
                            break;

                        default:
                            goto NextRecord;
                    }

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;
                }

                data.AcceptChanges();

                return true;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Retrieves the list of CMS security groups and their security level value.
        /// </summary>
        /// <returns>Datatable of CMS security groups.</returns>
        internal DataTable Get_CMS_SecurityGroups()
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable("SecurityGroups");
                dt.Columns.Add("id", typeof(int));
                dt.Columns.Add("SecurityGroup", typeof(string));
                dt.Columns.Add("SecurityLevel", typeof(int));

                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_SECURITY_CMS_SecurityGroups_Select";

                con.Open();
                cmd.Connection = con;

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    DataRow dr = dt.NewRow();

                    dr["id"] = int.Parse(reader["id"].ToString().Length == 0 ? "0" : reader["id"].ToString());
                    dr["SecurityGroup"] = reader["SecurityGroup"].ToString();
                    dr["SecurityLevel"] = int.Parse(reader["SecurityLevel"].ToString());

                    dt.Rows.Add(dr);
                }

                reader.Close();
                reader.Dispose();

                con.Close();
                con.Dispose();

                return dt;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (con.State != ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        #endregion
        #endregion

        #region "Investor Tracking"
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        internal DataTable BuildInvestorTrackingWorkflowStepLookupTable()
        {
            DataTable _workflowStepsData = new DataTable("WorkflowSteps");
            DataColumn dc = new DataColumn();
            dc.ColumnName = "id";
            dc.DataType = typeof(int);
            _workflowStepsData.Columns.Add(dc);

            dc = new DataColumn();
            dc.ColumnName = "WorkflowStepName";
            dc.DataType = typeof(string);
            _workflowStepsData.Columns.Add(dc);

            dc = new DataColumn();
            dc.ColumnName = "WorkflowStepOrder";
            dc.DataType = typeof(int);
            _workflowStepsData.Columns.Add(dc);

            return _workflowStepsData;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="claimID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetInvestorTracking_Claim(DataTable dt, int claimID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_InvTrk_Claim_Select";

                SqlParameter parm = new SqlParameter("@ClaimID", claimID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["id"] = (int)dr["id"];
                    row["LoanID"] = dr["LoanID"].ToString();
                    row["ClaimType"] = (int)dr["ClaimType"];
                    row["ClaimTypeText"] = dr["ClaimTypeText"].ToString();
                    row["ClaimDueDate"] = DateTime.Parse(dr["ClaimDueDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClaimDueDate"].ToString());
                    row["ClaimAmount"] = double.Parse(dr["ClaimAmount"].ToString().Length == 0 ? "0" : dr["ClaimAmount"].ToString());
                    row["NoBill"] = bool.Parse(dr["NoBill"].ToString());
                    row["NoClaimSubmitted"] = bool.Parse(dr["NoClaimSubmitted"].ToString());
                    row["ClaimPerfectionDate"] = DateTime.Parse(dr["ClaimPerfectionDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClaimPerfectionDate"].ToString());
                    row["ClaimPaidDate"] = DateTime.Parse(dr["ClaimPaidDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClaimPaidDate"].ToString());
                    row["ClaimPaidAmount"] = double.Parse(dr["ClaimPaidAmount"].ToString().Length == 0 ? "0" : dr["ClaimPaidAmount"].ToString());
                    row["RejectedDate"] = DateTime.Parse(dr["RejectedDate"].ToString().Length == 0 ? "1/1/1900" : dr["RejectedDate"].ToString());
                    row["ClaimClosed"] = bool.Parse(dr["ClaimClosed"].ToString());
                    row["ClaimClosedDate"] = DateTime.Parse(dr["ClaimClosedDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClaimClosedDate"].ToString());
                    row["ClaimClosedUser"] = int.Parse(dr["ClaimClosedUser"].ToString().Length == 0 ? "0" : dr["ClaimClosedUser"].ToString());
                    row["ClaimClosedUserName"] = dr["ClaimClosedUserName"].ToString();
                    row["DateEntered"] = DateTime.Parse(dr["DateEntered"].ToString().Length == 0 ? "1/1/1900" : dr["DateEntered"].ToString());
                    row["EnteredByUser"] = int.Parse(dr["EnteredByUser"].ToString().Length == 0 ? "0" : dr["EnteredByUser"].ToString());
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    row["LastUpdateUser"] = int.Parse(dr["LastUpdateUser"].ToString().Length == 0 ? "0" : dr["LastUpdateUser"].ToString());
                    row["ClosingReason"] = int.Parse(dr["ClosingReason"].ToString().Length == 0 ? "0" : dr["ClosingReason"].ToString());
                    row["PFU_EOBReviewOnly"] = bool.Parse(dr["PFU_EOBReviewOnly"].ToString().Length == 0 ? "false" : dr["PFU_EOBReviewOnly"].ToString());
                    row["PreSaleSettlementProceedsAmount"] = double.Parse(dr["PreSaleSettlementProceedsAmount"].ToString().Length == 0 ? "0" : dr["PreSaleSettlementProceedsAmount"].ToString());
                    row["OptionSettlementCoveragePct"] = double.Parse(dr["OptionSettlementCoveragePct"].ToString().Length == 0 ? "0" : dr["OptionSettlementCoveragePct"].ToString());
                    row["RecissionDate"] = DateTime.Parse(dr["RecissionDate"].ToString().Length == 0 ? "1/1/1900" : dr["RecissionDate"].ToString());
                    row["CancellationDate"] = DateTime.Parse(dr["CancellationDate"].ToString().Length == 0 ? "1/1/1900" : dr["CancellationDate"].ToString());
                    row["ClosedWithoutPaymentDate"] = DateTime.Parse(dr["ClosedWithoutPaymentDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClosedWithoutPaymentDate"].ToString());
                    row["CarrierSettlementType"] = int.Parse(dr["CarrierSettlementType"].ToString().Length == 0 ? "0" : dr["CarrierSettlementType"].ToString());
                    row["RevisedClaimAmt"] = double.Parse(dr["RevisedClaimAmt"].ToString().Length == 0 ? "0" : dr["RevisedClaimAmt"].ToString());
                    row["RevisedProceedsAmt"] = double.Parse(dr["RevisedProceedsAmt"].ToString().Length == 0 ? "0" : dr["RevisedProceedsAmt"].ToString());
                    row["RevisedEstSettlementAmt"] = double.Parse(dr["RevisedEstSettlementAmt"].ToString().Length == 0 ? "0" : dr["RevisedEstSettlementAmt"].ToString());
                    row["SecondaryClaimDueDate"]= DateTime.Parse(dr["SecondaryClaimDueDate"].ToString().Length == 0 ? "1/1/1900" : dr["SecondaryClaimDueDate"].ToString());
                    row["DeltaCheck"] = dr["DeltaCheck"].ToString();
                    row["IsClaimCancelled"] = bool.Parse(dr["IsClaimCancelled"].ToString().Length == 0 ? "false" : dr["IsClaimCancelled"].ToString());
                    row["ClaimCancelledDate"] = DateTime.Parse(dr["ClaimCancelledDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClaimCancelledDate"].ToString());
                    row["ClaimCancelledUserID"] = int.Parse(dr["ClaimCancelledUserID"].ToString().Length == 0 ? "0" : dr["ClaimCancelledUserID"].ToString());
                    row["isZeroNeg"] = bool.Parse(dr["isZeroNeg"].ToString().Length == 0 ? "false" : dr["isZeroNeg"].ToString());
                    row["ZeroNegDate"] = DateTime.Parse(dr["ZeroNegDate"].ToString().Length == 0 ? "1/1/1900" : dr["ZeroNegDate"].ToString());
                    row["ZeroNegUserID"] = int.Parse(dr["ZeroNegUserID"].ToString().Length == 0 ? "0" : dr["ZeroNegUserID"].ToString());
                    row["IndustryClaimDueDate"] = DateTime.Parse(dr["IndustryClaimDueDate"].ToString().Length == 0 ? "1/1/1900" : dr["IndustryClaimDueDate"].ToString());
                    //FB39123 ARG 20170302
                    row["ConventionalUSDASupplemental"] = bool.Parse(dr["ConventionalUSDASupplemental"].ToString().Length == 0 ? "false" : dr["ConventionalUSDASupplemental"].ToString());
                    row["ConventionalTaxSupplemental"] = bool.Parse(dr["ConventionalTaxSupplemental"].ToString().Length == 0 ? "false" : dr["ConventionalTaxSupplemental"].ToString());
                    row["SuppParentClaimID"] = int.Parse(dr["SuppParentClaimID"].ToString().Length == 0 ? "0" : dr["SuppParentClaimID"].ToString());
                    row["ParentClaimType"] = dr["ParentClaimType"].ToString();
                    //FB64294 gk 20190218
                    row["OpsModifiableIndustryDueDate"] = DateTime.Parse(dr["OpsModifiableIndustryDueDate"].ToString().Length == 0 ? "1/1/1900" : dr["OpsModifiableIndustryDueDate"].ToString());
                    row["OpsModifiableSLADueDate"] = DateTime.Parse(dr["OpsModifiableSLADueDate"].ToString().Length == 0 ? "1/1/1900" : dr["OpsModifiableSLADueDate"].ToString());
                    row["OpsModifiableNotWorkable"] = bool.Parse(dr["OpsModifiableNotWorkable"].ToString().Length == 0 ? "false" : dr["OpsModifiableNotWorkable"].ToString());
                    dt.Rows.Add(row);

                }

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="claimID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetInvestorTracking_VAClaim(DataTable dt, int claimID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_InvTrk_VAClaim_Select";

                SqlParameter parm = new SqlParameter("@ClaimID", claimID);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["VAClaimID"] = (int)dr["VAClaimID"];
                    row["ClaimID"] = (int)dr["ClaimID"];
                    row["TOCFiledDate"] = DateTime.Parse(dr["TOCFiledDate"].ToString().Length == 0 ? "1/1/1900" : dr["TOCFiledDate"].ToString());
                    row["TOCFiledProcessorID"] = int.Parse(dr["TOCFiledProcessorID"].ToString().Length == 0 ? "0" : dr["TOCFiledProcessorID"].ToString());
                    row["TOCFiledProcessor"] = dr["TOCFiledProcessor"].ToString();
                    row["TOCResubmitDate"] = DateTime.Parse(dr["TOCResubmitDate"].ToString().Length == 0 ? "1/1/1900" : dr["TOCResubmitDate"].ToString());
                    row["TOCResubmitProcessorID"] = int.Parse(dr["TOCResubmitProcessorID"].ToString().Length == 0 ? "0" : dr["TOCResubmitProcessorID"].ToString());
                    row["TOCResubmitProcessor"] = dr["TOCResubmitProcessor"].ToString();
                    row["TOCPaidDate"] = DateTime.Parse(dr["TOCPaidDate"].ToString().Length == 0 ? "1/1/1900" : dr["TOCPaidDate"].ToString());
                    row["TOCPaidAmount"] = double.Parse(dr["TOCPaidAmount"].ToString().Length == 0 ? "0" : dr["TOCPaidAmount"].ToString());
                    row["TitlePkgExtensionDate"] = DateTime.Parse(dr["TitlePkgExtensionDate"].ToString().Length == 0 ? "1/1/1900" : dr["TitlePkgExtensionDate"].ToString());
                    row["TitlePkgExtensionProcessorID"] = int.Parse(dr["TitlePkgExtensionProcessorID"].ToString().Length == 0 ? "0" : dr["TitlePkgExtensionProcessorID"].ToString());
                    row["TitlePkgExtensionProcessor"] = dr["TitlePkgExtensionProcessor"].ToString();
                    row["TitlePkgSubmitDate"] = DateTime.Parse(dr["TitlePkgSubmitDate"].ToString().Length == 0 ? "1/1/1900" : dr["TitlePkgSubmitDate"].ToString());
                    row["TitlePkgSubmitProcessorID"] = int.Parse(dr["TitlePkgSubmitProcessorID"].ToString().Length == 0 ? "0" : dr["TitlePkgSubmitProcessorID"].ToString());
                    row["TitlePkgSubmitProcessor"] = dr["TitlePkgSubmitProcessor"].ToString();
                    row["TitlePkgRefundPkgSubmitDate"] = DateTime.Parse(dr["TitlePkgRefundPkgSubmitDate"].ToString().Length == 0 ? "1/1/1900" : dr["TitlePkgRefundPkgSubmitDate"].ToString());
                    row["ClaimPrepDate"] = DateTime.Parse(dr["ClaimPrepDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClaimPrepDate"].ToString());
                    row["ClaimPrepID"] = int.Parse(dr["ClaimPrepID"].ToString().Length == 0 ? "0" : dr["ClaimPrepID"].ToString());
                    row["ClaimPrep"] = dr["ClaimPrep"].ToString();
                    row["ClaimSubmitDate"] = DateTime.Parse(dr["ClaimSubmitDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClaimSubmitDate"].ToString());
                    row["ClaimSubmitProcessorID"] = int.Parse(dr["ClaimSubmitProcessorID"].ToString().Length == 0 ? "0" : dr["ClaimSubmitProcessorID"].ToString());
                    row["ClaimSubmitProcessor"] = dr["ClaimSubmitProcessor"].ToString();
                    row["ClaimResubmitDate"] = DateTime.Parse(dr["ClaimResubmitDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClaimResubmitDate"].ToString());
                    row["ClaimResubmitProcessorID"] = int.Parse(dr["ClaimResubmitProcessorID"].ToString().Length == 0 ? "0" : dr["ClaimResubmitProcessorID"].ToString());
                    row["ClaimResubmitProcessor"] = dr["ClaimResubmitProcessor"].ToString();
                    row["Claim3rdPartyProceedsRecievedDate"] = DateTime.Parse(dr["Claim3rdPartyProceedsRecievedDate"].ToString().Length == 0 ? "1/1/1900" : dr["Claim3rdPartyProceedsRecievedDate"].ToString());
                    row["ClaimPaidDate"] = DateTime.Parse(dr["ClaimPaidDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClaimPaidDate"].ToString());
                    row["ClaimPaidAmount"] = double.Parse(dr["ClaimPaidAmount"].ToString().Length == 0 ? "0" : dr["ClaimPaidAmount"].ToString());
                    row["SupplementalClaimDue"] = bool.Parse(dr["SupplementalClaimDue"].ToString().Length == 0 ? "false" : dr["SupplementalClaimDue"].ToString());
                    row["SupplementalFiledDate"] = DateTime.Parse(dr["SupplementalFiledDate"].ToString().Length == 0 ? "1/1/1900" : dr["SupplementalFiledDate"].ToString());
                    row["SupplementalFiledProcessorID"] = int.Parse(dr["SupplementalFiledProcessorID"].ToString().Length == 0 ? "0" : dr["SupplementalFiledProcessorID"].ToString());
                    row["SupplementalFiledProcessor"] = dr["SupplementalFiledProcessor"].ToString();
                    row["SupplementalPaidDate"] = DateTime.Parse(dr["SupplementalPaidDate"].ToString().Length == 0 ? "1/1/1900" : dr["SupplementalPaidDate"].ToString());
                    row["SupplementalPaidAmount"] = double.Parse(dr["SupplementalPaidAmount"].ToString().Length == 0 ? "0" : dr["SupplementalPaidAmount"].ToString());
                    row["SupplementalDeniedDate"] = DateTime.Parse(dr["SupplementalDeniedDate"].ToString().Length == 0 ? "1/1/1900" : dr["SupplementalDeniedDate"].ToString());
                    row["InvestorClaimDue"] = bool.Parse(dr["InvestorClaimDue"].ToString().Length == 0 ? "false" : dr["InvestorClaimDue"].ToString()); 
                    row["InvestorClaimFiledDate"] = DateTime.Parse(dr["InvestorClaimFiledDate"].ToString().Length == 0 ? "1/1/1900" : dr["InvestorClaimFiledDate"].ToString());
                    row["InvestorClaimAmount"] = double.Parse(dr["InvestorClaimAmount"].ToString().Length == 0 ? "0" : dr["InvestorClaimAmount"].ToString());

                    row["InvestorClaimType"] = int.Parse(dr["InvestorClaimType"].ToString().Length == 0 ? "0" : dr["InvestorClaimType"].ToString());
                    row["InvestorClaimOutcomeChangeDate"] = DateTime.Parse(dr["InvestorClaimOutcomeChangeDate"].ToString().Length == 0 ? "1/1/1900" : dr["InvestorClaimOutcomeChangeDate"].ToString());
                    row["InvestorClaimOutcome"] = int.Parse(dr["InvestorClaimOutcome"].ToString().Length == 0 ? "0" : dr["InvestorClaimOutcome"].ToString());
                    row["InvestorClaimOutcomeChangedBy"] = int.Parse(dr["InvestorClaimOutcomeChangedBy"].ToString().Length == 0 ? "0" : dr["InvestorClaimOutcomeChangedBy"].ToString());

                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                    row["EnteredByUser"] = int.Parse(dr["EnteredByUser"].ToString().Length == 0 ? "0" : dr["EnteredByUser"].ToString());
                    row["EnteredByUserName"] = dr["EnteredByUserName"].ToString();
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    row["LastUpdateUser"] = int.Parse(dr["LastUpdateUser"].ToString().Length == 0 ? "0" : dr["LastUpdateUser"].ToString());
                    row["LastUpdateUserName"] = dr["LastUpdateUserName"].ToString();
                    row["TOCAmount"] = double.Parse(dr["TOCAmount"].ToString().Length == 0 ? "0" : dr["TOCAmount"].ToString());
                    row["ClaimAmount"] = double.Parse(dr["ClaimAmount"].ToString().Length == 0 ? "0" : dr["ClaimAmount"].ToString());
                    row["SupplementalAmount"] = double.Parse(dr["SupplementalAmount"].ToString().Length == 0 ? "0" : dr["SupplementalAmount"].ToString());
                    row["TerminationDate"] = DateTime.Parse(dr["TerminationDate"].ToString().Length == 0 ? "1/1/1900" : dr["TerminationDate"].ToString());
                    row["PrepDueDate"] = DateTime.Parse(dr["PrepDueDate"].ToString().Length == 0 ? "1/1/1900" : dr["PrepDueDate"].ToString());

                    row["TOCNoBill"] = bool.Parse(dr["TOCNoBill"].ToString().Length == 0 ? "false" : dr["TOCNoBill"].ToString());
                    row["TOCNoBillDate"] = DateTime.Parse(dr["TOCNoBillDate"].ToString().Length == 0 ? "1/1/1900" : dr["TOCNoBillDate"].ToString());
                    row["TOCNoBillBy"] = int.Parse(dr["TOCNoBillBy"].ToString().Length == 0 ? "0" : dr["TOCNoBillBy"].ToString());
                    row["TitlePkgNoBill"] = bool.Parse(dr["TitlePkgNoBill"].ToString().Length == 0 ? "false" : dr["TitlePkgNoBill"].ToString());
                    row["TitlePkgNoBillDate"] = DateTime.Parse(dr["TitlePkgNoBillDate"].ToString().Length == 0 ? "1/1/1900" : dr["TitlePkgNoBillDate"].ToString());
                    row["TitlePkgNoBillBy"] = int.Parse(dr["TitlePkgNoBillBy"].ToString().Length == 0 ? "0" : dr["TitlePkgNoBillBy"].ToString());
                    row["ClaimNoBill"] = bool.Parse(dr["ClaimNoBill"].ToString().Length == 0 ? "false" : dr["ClaimNoBill"].ToString());
                    row["ClaimNoBillDate"] = DateTime.Parse(dr["ClaimNoBillDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClaimNoBillDate"].ToString());
                    row["ClaimNoBillBy"] = int.Parse(dr["ClaimNoBillBy"].ToString().Length == 0 ? "0" : dr["ClaimNoBillBy"].ToString());
                    row["SupplementalNoBill"] = bool.Parse(dr["SupplementalNoBill"].ToString().Length == 0 ? "false" : dr["SupplementalNoBill"].ToString());
                    row["SupplementalNoBillDate"] = DateTime.Parse(dr["SupplementalNoBillDate"].ToString().Length == 0 ? "1/1/1900" : dr["SupplementalNoBillDate"].ToString());
                    row["SupplementalNoBillBy"] = int.Parse(dr["SupplementalNoBillBy"].ToString().Length == 0 ? "0" : dr["SupplementalNoBillBy"].ToString());
                    row["InvestorClaimNoBill"] = bool.Parse(dr["InvestorClaimNoBill"].ToString().Length == 0 ? "false" : dr["InvestorClaimNoBill"].ToString());
                    row["InvestorClaimNoBillDate"] = DateTime.Parse(dr["InvestorClaimNoBillDate"].ToString().Length == 0 ? "1/1/1900" : dr["InvestorClaimNoBillDate"].ToString());
                    row["InvestorClaimNoBillBy"] = int.Parse(dr["InvestorClaimNoBillBy"].ToString().Length == 0 ? "0" : dr["InvestorClaimNoBillBy"].ToString());

                    row["deltaCheck"] = dr["deltaCheck"];
                    
                    dt.Rows.Add(row);

                }

                dr.Close();
                dr.Dispose();

                dt.AcceptChanges();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="loanData"></param>
        /// <param name="loanID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetInvestorTrackingLoan(DataTable loanData, int loanID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_InvTrk_Loans_SelectByLoanID";
                SqlParameter parm = new SqlParameter("@LoanID", loanID);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    //V-592 20111231 TRS - General revisions for new and changed columns
                    DataRow row = loanData.NewRow();

                    row["id"] = (int)dr["id"];
                    row["LoanNumber"] = dr["LoanNumber"].ToString();
                    row["ClientID"] = (int)dr["ClientID"];
                    row["ClientName"] = dr["ClientName"].ToString();
                    row["PropertyAddress"] = dr["PropertyAddress"].ToString();
                    row["PropertyCity"] = dr["PropertyCity"].ToString();
                    row["PropertyState"] = dr["PropertyState"].ToString();
                    row["PropertyZip"] = dr["PropertyZip"].ToString();
                    row["ServicerNumber"] = dr["ServicerNumber"].ToString();
                    row["ServicerName"] = dr["ServicerName"].ToString();
                    row["ServicerAddress"] = dr["ServicerAddress"].ToString();
                    row["ServicerCity"] = dr["ServicerCity"].ToString();
                    row["ServicerState"] = dr["ServicerState"].ToString();
                    row["ServicerZip"] = dr["ServicerZip"].ToString();
                    row["InternalFormID"] = (int)dr["InternalFormID"];
                    row["InvestorID"] = dr["InvestorID"].ToString();
                    row["InvestorName"] = dr["InvestorName"].ToString();
                    row["MICompanyID"] = int.Parse(dr["MICompanyID"].ToString().Length == 0 ? "0" : dr["MICompanyID"].ToString());
                    //row["MICompanyName"] = dr["MICompanyName"].ToString();
                    row["MIGuarantyNumber"] = dr["MIGuarantyNumber"].ToString();
                    row["BorrowerFirstName"] = dr["BorrowerFirstName"].ToString();
                    row["BorrowerLastName"] = dr["BorrowerLastName"].ToString();
                    row["InvestorLoanNumber"] = dr["InvestorLoanNumber"].ToString();
                    row["ReferDateToMI"] = DateTime.Parse(dr["ReferDateToMI"].ToString().Length == 0 ? "1/1/1900" : dr["ReferDateToMI"].ToString());
                    row["PreForeclosureSettlementDate"] = DateTime.Parse(dr["PreForeclosureSettlementDate"].ToString().Length == 0 ? "1/1/1900" : dr["PreForeclosureSettlementDate"].ToString());
                    row["DeedInLeuRecordDate"] = DateTime.Parse(dr["DeedInLeuRecordDate"].ToString().Length == 0 ? "1/1/1900" : dr["DeedInLeuRecordDate"].ToString());
                    row["ForeClosureDate"] = DateTime.Parse(dr["ForeClosureDate"].ToString().Length == 0 ? "1/1/1900" : dr["ForeClosureDate"].ToString());
                    row["ForeClosureSaleDate"] = DateTime.Parse(dr["ForeClosureSaleDate"].ToString().Length == 0 ? "1/1/1900" : dr["ForeClosureSaleDate"].ToString());
                    row["REOSaleDate"] = DateTime.Parse(dr["REOSaleDate"].ToString().Length == 0 ? "1/1/1900" : dr["REOSaleDate"].ToString());
                    row["RRCDate"] = DateTime.Parse(dr["RRCDate"].ToString().Length == 0 ? "1/1/1900" : dr["RRCDate"].ToString());
                    row["FHACaseNumber"] = dr["FHACaseNumber"].ToString();
                    row["MICertNumber"] = dr["MICertNumber"].ToString();
                    row["MIFiledDate"] = DateTime.Parse(dr["MIFiledDate"].ToString().Length == 0 ? "1/1/1900" : dr["MIFiledDate"].ToString());
                    row["PoolCompany"] = dr["PoolCompany"].ToString();
                    row["PoolCertNumber"] = dr["PoolCertNumber"].ToString();
                    row["PoolFiledDate"] = DateTime.Parse(dr["PoolFiledDate"].ToString().Length == 0 ? "1/1/1900" : dr["PoolFiledDate"].ToString());
                    row["ThirdPartySaleDate"] = DateTime.Parse(dr["ThirdPartySaleDate"].ToString().Length == 0 ? "1/1/1900" : dr["ThirdPartySaleDate"].ToString());
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString());
                    row["DateEntered"] = DateTime.Parse(dr["DateEntered"].ToString());
                    row["EnteredByUser"] = int.Parse(dr["EnteredByUser"].ToString().Length == 0 ? "0" : dr["EnteredByUser"].ToString());
                    row["LastUpdateUser"] = int.Parse(dr["LastUpdateUser"].ToString().Length == 0 ? "0" : dr["LastUpdateUser"].ToString());
                    row["EnteredByUserName"] = dr["EnteredByUserName"].ToString();
                    row["LastUpdateUserName"] = dr["LastUpdateUserName"].ToString();
                    row["AttorneyName"] = dr["AttorneyName"].ToString();
                    row["PCCDate"] = DateTime.Parse(dr["PCCDate"].ToString().Length == 0 ? "1/1/1900" : dr["PCCDate"].ToString());
                    row["GADate"] = DateTime.Parse(dr["GADate"].ToString().Length == 0 ? "1/1/1900" : dr["GADate"].ToString());
                    row["CMAXClientID"] = dr["CMAXClientID"].ToString();
                    row["OldLoanNumber"] = dr["OldLoanNumber"].ToString();
                    row["SellerServicerNumber"] = dr["SellerServicerNumber"].ToString();
                    row["VACaseNumber"] = dr["VACaseNumber"].ToString();
                    row["MarketingExpirationDate"] = DateTime.Parse(dr["MarketingExpirationDate"].ToString().Length == 0 ? "1/1/1900" : dr["MarketingExpirationDate"].ToString());
                    row["LiquidationDate"] = DateTime.Parse(dr["LiquidationDate"].ToString().Length == 0 ? "1/1/1900" : dr["LiquidationDate"].ToString());
                    row["RefundingDate"] = DateTime.Parse(dr["RefundingDate"].ToString().Length == 0 ? "1/1/1900" : dr["RefundingDate"].ToString());
                    row["FHACaseNumber"] = dr["FHACaseNumber"].ToString();
                    row["EvictionAttorney"] = dr["EvictionAttorney"].ToString();
                    row["TitleCompany"] = dr["TitleCompany"].ToString();
                    row["PandPCompany"] = dr["PandPCompany"].ToString();
                    row["IsAcquisitionLoan"] = dr["IsAcquisitionLoan"].ToString().Length == 0 ? false : bool.Parse(dr["IsAcquisitionLoan"].ToString());
                    row["AcquisitionLoanSetByUserID"] = int.Parse(dr["AcquisitionLoanSetByUserID"].ToString().Length == 0 ? "0" : dr["AcquisitionLoanSetByUserID"].ToString());
                    row["AquisitionLoanSetDate"] = DateTime.Parse(dr["AquisitionLoanSetDate"].ToString().Length == 0 ? "1/1/1900" : dr["AquisitionLoanSetDate"].ToString());
                    row["AquisitionLoanSetOnClaimID"] = int.Parse(dr["AquisitionLoanSetOnClaimID"].ToString().Length == 0 ? "0" : dr["AquisitionLoanSetOnClaimID"].ToString());
                    row["ForeclosureTypeID"] = int.Parse(dr["ForeclosureTypeID"].ToString().Length == 0 ? "0" : dr["ForeclosureTypeID"].ToString());
                    row["PropertyAcquisitionDate"] = DateTime.Parse(dr["PropertyAcquisitionDate"].ToString().Length == 0 ? "1/1/1900" : dr["PropertyAcquisitionDate"].ToString());
                    row["NPLSaleDate"] = DateTime.Parse(dr["NPLSaleDate"].ToString().Length == 0 ? "1/1/1900" : dr["NPLSaleDate"].ToString());
                    row["PromissoryNoteDate"] = DateTime.Parse(dr["PromissoryNoteDate"].ToString().Length == 0 ? "1/1/1900" : dr["PromissoryNoteDate"].ToString());
                    row["deltaCheck"] = dr["deltaCheck"].ToString();

                    loanData.Rows.Add(row);

                }
                dr.Close();
                dr.Dispose();

                loanData.AcceptChanges();

                return loanData;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reportName"></param>
        /// <param name="InvestorName"></param>
        /// <param name="ClientID"></param>
        /// <param name="settings"></param>
        /// <param name="optParms"></param>
        /// <returns>DataTable</returns>
        internal DataTable GetInvestorTrackingReporting_General(string reportName, string InvestorName, string ClientID, Settings settings, string[] optParms)
        {
            SqlConnection con = new SqlConnection();
            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }
            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("Reports");
                DataColumn dc = new DataColumn();

                dc = new DataColumn();
                dc.ColumnName = "LoanNumber";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "Investor";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "InvestorLoanNumber";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "State";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClientName";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "FCSaleDate";
                dc.DataType = typeof(string);
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "PFSDate";
                dc.DataType = typeof(string);
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "TPSDate";
                dc.DataType = typeof(string);
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "DILDate";
                dc.DataType = typeof(string);
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "REOSaleDate";
                dc.DataType = typeof(string);
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimType";
                dc.DataType = typeof(string);
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "CalculatedClaimDueDate";
                dc.DataType = typeof(string);
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimDueDate";
                dc.DataType = typeof(string);
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimSubmittedDate";
                dc.DataType = typeof(string);
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "QCCompleteDate";
                dc.DataType = typeof(string);
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimAmount";
                dc.DataType = typeof(double);
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimPaidDate";
                dc.DataType = typeof(string);
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "PaymentFollowupDate";
                dc.DataType = typeof(string);
                dc.DefaultValue = "";
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "PaymentFollowupAnalyst";
                dc.DataType = typeof(string);
                dc.DefaultValue = "";
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "PaymentFollowupComments";
                dc.DataType = typeof(string);
                dc.DefaultValue = "";
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "CurtailmentDate";
                dc.DataType = typeof(string);
                dc.DefaultValue = "";
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "CurtailmentAmount";
                dc.DataType = typeof(string);
                dc.DefaultValue = "0.00";
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "CurtailmentComments";
                dc.DataType = typeof(string);
                dc.DefaultValue = "";
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "CurtailmentAnalyst";
                dc.DataType = typeof(string);
                dc.DefaultValue = "";
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "CurtailmentReason";
                dc.DataType = typeof(string);
                dc.DefaultValue = "";
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "CurtailmentResponsible";
                dc.DataType = typeof(string);
                dc.DefaultValue = "";
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "PaymentFollowupCommentType";
                dc.DataType = typeof(string);
                dc.DefaultValue = "";
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimClosedDate";
                dc.DataType = typeof(string);
                dc.DefaultValue = "";
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimClosedByUser";
                dc.DataType = typeof(string);
                dc.DefaultValue = "";
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "NoBill";
                dc.DataType = typeof(bool);
                dc.AllowDBNull = false;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "NoClaim";
                dc.DataType = typeof(bool);
                dc.AllowDBNull = false;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimPaidAmount";
                dc.DataType = typeof(string);
                dc.DefaultValue = "0.00";
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimPaidAging";
                dc.DataType = typeof(string);
                dc.DefaultValue = "";
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "PaymentFollowupCompleteDate";
                dc.DataType = typeof(string);
                dc.DefaultValue = "";
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "PaymentFollowupCompleteAnalyst";
                dc.DataType = typeof(string);
                dc.DefaultValue = "";
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                // 20110407 - CRZ - [VIP-322] Add AssignedProcessorName to 'Investor Tracking' 'Claims Submitted' report.
                dc = new DataColumn();
                dc.ColumnName = "AssignedProcessorName";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);
                // END 20110407 - VIP-322
                
                //VIP Task 368 - 20110531 TRS - Add Loan Notes column to Claims Due report
                dc = new DataColumn();
                dc.ColumnName = "LoanNote";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);
                //VIP Task 368 - 20110531 TRS - END Add Loan Notes column to Claims Due report

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                SqlParameter prm;

                switch (reportName)
                {
                    case "Claims Closed":
                        cmd.CommandText = "usprptInvestorTracking_ClaimsClosed";
                        prm = new SqlParameter("@InvestorName", InvestorName);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@ClientID", ClientID);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@FromDate", optParms[0]);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@ToDate", optParms[1]);
                        cmd.Parameters.Add(prm);
                        break;
                    case "Claims Due":
                        cmd.CommandText = "usprptInvestorTracking_ClaimsDue";
                        prm = new SqlParameter("@InvestorName", InvestorName);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@ClientID", ClientID);
                        cmd.Parameters.Add(prm);
                        break;
                    case "Claims Due Exceptions":
                        cmd.CommandText = "usprptInvestorTracking_ClaimsDueExceptions";
                        prm = new SqlParameter("@InvestorName", InvestorName);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@ClientID", ClientID);
                        cmd.Parameters.Add(prm);
                        break;
                    case "Claims Submitted Not Paid":
                        cmd.CommandText = "usprptInvestorTracking_ClaimsSubmittedNotPaid";
                        prm = new SqlParameter("@InvestorName", InvestorName);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@ClientID", ClientID);
                        cmd.Parameters.Add(prm);
                        break;
                    case "Claims Paid":
                        cmd.CommandText = "usprptInvestorTracking_ClaimsPaid";
                        prm = new SqlParameter("@InvestorName", InvestorName);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@ClientID", ClientID);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@FromDate", optParms[0]);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@ToDate", optParms[1]);
                        cmd.Parameters.Add(prm);
                        break;
                    case "Claims Submitted":
                        cmd.CommandText = "usprptInvestorTracking_ClaimsSubmitted";
                        prm = new SqlParameter("@InvestorName", InvestorName);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@ClientID", ClientID);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@FromDate", optParms[0]);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@ToDate", optParms[1]);
                        cmd.Parameters.Add(prm);
                        break;
                    case "Curtailment Amounts":
                        cmd.CommandText = "usprptInvestorTracking_CurtailmentAmounts";
                        prm = new SqlParameter("@InvestorName", InvestorName);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@ClientID", ClientID);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@FromDate", optParms[0]);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@ToDate", optParms[1]);
                        cmd.Parameters.Add(prm);
                        break;
                    case "Late Claims Submitted":
                        cmd.CommandText = "usprptInvestorTracking_LateClaimsSubmitted";
                        prm = new SqlParameter("@InvestorName", InvestorName);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@ClientID", ClientID);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@FromDate", optParms[0]);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@ToDate", optParms[1]);
                        cmd.Parameters.Add(prm);
                        break;
                    case "Payment Followup Outstanding":
                        cmd.CommandText = "usprptInvestorTracking_Claims_PaymentFollowupOutstanding";
                        prm = new SqlParameter("@InvestorName", InvestorName);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@ClientID", ClientID);
                        cmd.Parameters.Add(prm);
                        break;
                    case "Payment Followup Completed":
                        cmd.CommandText = "usprptInvestorTracking_Claims_PaymentFollowupComplete";
                        prm = new SqlParameter("@InvestorName", InvestorName);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@ClientID", ClientID);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@StartDate", optParms[0]);
                        cmd.Parameters.Add(prm);
                        prm = new SqlParameter("@EndDate", optParms[1]);
                        cmd.Parameters.Add(prm);
                        break;
                    ////NOT YET IMPLEMENTED HERE
                    ////// 20110414 - CRZ - [VIP-257] Add 'Charge Off' report.
                    ////case "InvTrk - Charge Off":
                    ////    cmd.CommandText = "usprptInvestorTracking_ChargeOffCurtailment";
                    ////    prm = new SqlParameter("@StartDate", optParms[0]);
                    ////    cmd.Parameters.Add(prm);
                    ////    prm = new SqlParameter("@EndDate", optParms[1]);
                    ////    cmd.Parameters.Add(prm);
                    ////    break;
                    ////case "QC Complete Not Submitted":
                    ////    cmd.CommandText = "usprptInvestorTracking_QCCompleteNotSubmitted";
                    ////    prm = new SqlParameter("@InvestorName", InvestorName);
                    ////    cmd.Parameters.Add(prm);
                    ////    break;
                    default:
                        break;
                }

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["LoanNumber"] = dr["LoanNumber"].ToString().Length == 0 ? "" : dr["LoanNumber"].ToString();
                    row["Investor"] = dr["InvestorName"].ToString().Length == 0 ? "" : dr["InvestorName"].ToString();
                    row["InvestorLoanNumber"] = dr["InvestorLoanNumber"].ToString().Length == 0 ? "" : dr["InvestorLoanNumber"].ToString();
                    row["State"] = dr["PropertyState"].ToString().Length == 0 ? "" : dr["PropertyState"].ToString();
                    row["ClientName"] = dr["ClientName"].ToString().Length == 0 ? "" : dr["ClientName"].ToString();
                    row["FCSaleDate"] = dr["ForeclosureSaleDate"].ToString().Length == 0 ? "" : dr["ForeclosureSaleDate"].ToString();
                    row["PFSDate"] = dr["PreForeclosureSettlementDate"].ToString().Length == 0 ? "" : dr["PreForeclosureSettlementDate"].ToString();
                    row["TPSDate"] = dr["ThirdPartySaleDate"].ToString().Length == 0 ? "" : dr["ThirdPartySaleDate"].ToString();
                    row["DILDate"] = dr["DeedInLeuRecordDate"].ToString().Length == 0 ? "" : dr["DeedInLeuRecordDate"].ToString();
                    row["REOSaleDate"] = dr["REOSaleDate"].ToString().Length == 0 ? "" : dr["REOSaleDate"].ToString();
                    row["ClaimType"] = dr["ClaimType"].ToString().Length == 0 ? "" : dr["ClaimType"].ToString(); ;
                    row["ClaimDueDate"] = dr["ClaimDueDate"].ToString().Length == 0 ? "" : dr["ClaimDueDate"].ToString();
                    row["CalculatedClaimDueDate"] = dr["CalculatedClaimDueDate"].ToString().Length == 0 ? "" : dr["CalculatedClaimDueDate"].ToString();
                    row["ClaimSubmittedDate"] = dr["SubmitDate"].ToString().Length == 0 ? "" : dr["SubmitDate"].ToString();
                    row["QCCompleteDate"] = dr["QCCompleteDate"].ToString().Length == 0 ? "" : dr["QCCompleteDate"].ToString();
                    row["ClaimAmount"] = dr["ClaimAmount"].ToString().Length == 0 ? 0 : double.Parse(dr["ClaimAmount"].ToString());
                    row["ClaimPaidDate"] = dr["ClaimPaidDate"].ToString().Length == 0 ? "" : dr["ClaimPaidDate"].ToString();
                    row["NoClaim"] = dr["NoClaimSubmitted"].ToString().Length == 0 ? false : bool.Parse(dr["NoClaimSubmitted"].ToString());
                    row["NoBill"] = dr["NoBill"].ToString().Length == 0 ? false : bool.Parse(dr["NoBill"].ToString());

                    switch (reportName)
                    {
                        case "Claims Closed":
                            row["ClaimClosedDate"] = dr[dr.GetOrdinal("ClaimClosedDate")];
                            row["ClaimClosedByUser"] = dr[dr.GetOrdinal("ClaimClosedByUser")];
                            break;
                        case "Claims Submitted Not Paid":
                            row["ClaimPaidAmount"] = dr[dr.GetOrdinal("ClaimPaidAmount")];
                            row["ClaimPaidAging"] = dr[dr.GetOrdinal("ClaimPaidAging")];
                            break;
                        case "Payment Followup Outstanding":
                            row["PaymentFollowupDate"] = dr[dr.GetOrdinal("PaymentFollowupDate")];
                            row["PaymentFollowupAnalyst"] = dr[dr.GetOrdinal("PaymentFollowupAnalyst")];
                            row["PaymentFollowupComments"] = dr[dr.GetOrdinal("PaymentFollowupComments")];
                            row["PaymentFollowupCommentType"] = dr[dr.GetOrdinal("PaymentFollowupCommentType")];
                            break;
                        case "Claims Paid":
                            row["ClaimPaidAmount"] = dr[dr.GetOrdinal("ClaimPaidAmount")];
                            row["ClaimPaidAging"] = dr[dr.GetOrdinal("ClaimPaidAging")];
                            break;
                        // 20110407 - CRZ - [VIP-322] Add AssignedProcessorName to 'Investor Tracking' 'Claims Submitted' report.
                        case "Claims Submitted":
                            row["AssignedProcessorName"] = dr["AssignedProcessorName"].ToString().Length == 0 ? "" : dr["AssignedProcessorName"].ToString();
                            break;
                        case "Curtailment Amounts":
                            row["CurtailmentDate"] = dr[dr.GetOrdinal("CurtailmentDate")];
                            row["CurtailmentAmount"] = dr[dr.GetOrdinal("CurtailmentAmount")];
                            row["CurtailmentComments"] = dr[dr.GetOrdinal("CurtailmentComments")];
                            row["CurtailmentAnalyst"] = dr[dr.GetOrdinal("CurtailmentAnalyst")];
                            row["CurtailmentReason"] = dr[dr.GetOrdinal("CurtailmentReason")];
                            row["CurtailmentResponsible"] = dr[dr.GetOrdinal("CurtailmentResponsible")];
                            break;
                        case "Payment Followup Completed":
                            row["PaymentFollowupDate"] = dr[dr.GetOrdinal("PaymentFollowupDate")];
                            row["PaymentFollowupAnalyst"] = dr[dr.GetOrdinal("PaymentFollowupAnalyst")];
                            row["PaymentFollowupComments"] = dr[dr.GetOrdinal("PaymentFollowupComments")];
                            row["PaymentFollowupCommentType"] = dr[dr.GetOrdinal("PaymentFollowupCommentType")];
                            row["PaymentFollowupCompleteDate"] = dr[dr.GetOrdinal("PaymentFollowupCompleteDate")];
                            row["PaymentFollowupCompleteAnalyst"] = dr[dr.GetOrdinal("PaymentFollowupCompleteAnalyst")];
                            break;
                        
                        //VIP Task 368 - 20110531 TRS - Add Loan Notes column to Claims Due report
                        case "Claims Due":
                            row["LoanNote"] = dr[dr.GetOrdinal("LoanComment")];
                            break;
                        //VIP Task 368 - 20110531 TRS - END Add Loan Notes column to Claims Due report

                        default:
                            break;
                    }
                    dt.Rows.Add(row);
                }
                dt.AcceptChanges();
                return dt;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reportName"></param>
        /// <param name="InvestorName"></param>
        /// <param name="ClientID"></param>
        /// <param name="settings"></param>
        /// <param name="optParms"></param>
        /// <returns>DataTable</returns>
        internal DataTable GetInvestorTrackingReporting_MissingDocuments(string reportName, string InvestorName, string ClientID, Settings settings)
        {
            SqlConnection con = new SqlConnection();
            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }
            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("Reports");
                DataColumn dc = new DataColumn();

                dc = new DataColumn();
                dc.ColumnName = "LoanNumber";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "Client";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "InvestorName";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimType";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "RequestedDate";
                dc.DataType = typeof(string);
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "DocDueDate";
                dc.DataType = typeof(string);
                dc.AllowDBNull = true;
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "DocType";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "Comments";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "Analyst";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "InvestorLoanNumber";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                SqlParameter prm = new SqlParameter("@InvestorName", InvestorName);
                cmd.Parameters.Add(prm);

                SqlParameter prm1 = new SqlParameter("@ClientID", ClientID);
                cmd.Parameters.Add(prm1);

                switch (reportName)
                {
                    case "Missing Documents":
                        cmd.CommandText = "usprptInvestorTracking_MissingDocuments";
                        break;
                    default:
                        break;
                }

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["LoanNumber"] = dr["LoanNumber"].ToString();
                    row["Client"] = dr["ClientName"];
                    row["InvestorName"] = dr["InvestorName"].ToString();
                    row["ClaimType"] = dr["ClaimType"].ToString();
                    row["RequestedDate"] = dr["RequestedDate"].ToString();
                    row["DocDueDate"] = dr["DueDate"].ToString();
                    row["DocType"] = dr["DocumentType"].ToString();
                    row["Comments"] = dr["Comments"];
                    row["Analyst"] = dr["Analyst"];
                    row["InvestorLoanNumber"] = dr["InvestorLoanNumber"];

                    dt.Rows.Add(row);
                }
                dt.AcceptChanges();
                return dt;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="claimID"></param>
        /// <param name="ClaimType"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetInvestorTrackingReporting_RecSheet(int claimID, string ClaimType, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }
            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("Reports");
                DataColumn dc = new DataColumn();

                dc = new DataColumn();
                dc.ColumnName = "Processor";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "Loan Number";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "Investor Name";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "Investor Loan Number";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "Client Name";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "Claim Type";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "Category";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "Sub Category";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "Amount";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);


                dc = new DataColumn();
                dc.ColumnName = "Description";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "GridName";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "SubtotalType";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "SortOrder";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "AddGeneral";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "DeductGeneral";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "DeductNonClaimable";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "GrandTotal";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "FHA Case Number";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);


                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                SqlParameter parm = new SqlParameter("@ClaimID", claimID);
                cmd.Parameters.Add(parm);

                // FB.13253 ALK Changed the ClaimType argument to use uppercase rather than depend on the
                // variablecase in the database. Removed FHA PFS and FHA Part B, combined all FHA that isn't
                // CWCOT or SFLS into one result.

                switch (ClaimType.ToUpper())
                {
                    case "FHA ASSIGNMENT":
                    case "FHA AUTOMATIC ASSIGNMENT":
                    case "FHA COINSURANCE":
                    case "FHA CONVEYANCE":
                    case "FHA CWCOT":
                    case "FHA MODIFICATION":
                    case "FHA PARTIAL CLAIM":
                    case "FHA PFS":
                    case "FHA SPECIAL FORBEARANCE":
                    case "FHA SUPPLEMENTAL":
                        cmd.CommandText = "usp_InvTrk_Report_RecSheetFHAClaims";
                        break;

                    case "VA":
                        cmd.CommandText = "usp_InvTrk_Report_RecSheetVA";
                        break;

                    // 20130903 gk t-23310 calls for rec sheet report on cwcot and sfls

                    default:
                        cmd.CommandText = "usprptInvestorTracking_RecSheet";
                        break;

                }

                
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                decimal decimal2String;

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["Processor"] = dr["Processor"].ToString().Length == 0 ? "" : dr["Processor"].ToString();
                    row["Loan Number"] = dr["Loan Number"].ToString().Length == 0 ? "" : dr["Loan Number"].ToString();
                    row["FHA Case Number"] = dr["FHA Case Number"].ToString().Length == 0 ? "" : dr["FHA Case Number"].ToString();
                    row["Investor Name"] = dr["Investor Name"].ToString().Length == 0 ? "" : dr["Investor Name"].ToString();
                    row["Investor Loan Number"] = dr["Investor Loan Number"].ToString().Length == 0 ? "" : dr["Investor Loan Number"].ToString();
                    row["Client Name"] = dr["Client Name"].ToString().Length == 0 ? "" : dr["Client Name"].ToString();
                    row["Claim Type"] = dr["Claim Type"].ToString().Length == 0 ? "" : dr["Claim Type"].ToString();
                    row["Category"] = dr["Category"].ToString().Length == 0 ? "" : dr["Category"].ToString();
                    row["Sub Category"] = dr["Sub Category"].ToString().Length == 0 ? "" : dr["Sub Category"].ToString();

                    decimal2String = decimal.Parse(dr["Amount"].ToString().Length == 0 ? "0" : dr["Amount"].ToString());
                    row["Amount"] = string.Format("{0:c}", decimal2String);

                    row["Description"] = dr["Description"].ToString().Length == 0 ? "" : dr["Description"].ToString();
                    row["GridName"] = dr["GridName"].ToString().Length == 0 ? "" : dr["GridName"].ToString();
                    row["SubtotalType"] = dr["SubtotalType"].ToString().Length == 0 ? "" : dr["SubtotalType"].ToString();
                    row["SortOrder"] = int.Parse(dr["SortOrder"].ToString().Length == 0 ? "0" : dr["SortOrder"].ToString());

                    decimal2String = decimal.Parse(dr["AddGeneral"].ToString().Length == 0 ? "0" : dr["AddGeneral"].ToString());
                    row["AddGeneral"] = string.Format("{0:c}", decimal2String);

                    decimal2String = decimal.Parse(dr["DeductGeneral"].ToString().Length == 0 ? "0" : dr["DeductGeneral"].ToString());
                    row["DeductGeneral"] = string.Format("{0:c}", decimal2String);

                    decimal2String = decimal.Parse(dr["DeductNonClaimable"].ToString().Length == 0 ? "0" : dr["DeductNonClaimable"].ToString());
                    row["DeductNonClaimable"] = string.Format("{0:c}", decimal2String);

                    decimal2String = decimal.Parse(dr["GrandTotal"].ToString().Length == 0 ? "0" : dr["GrandTotal"].ToString());
                    row["GrandTotal"] = string.Format("{0:c}", decimal2String);

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw (ex);
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reportName"></param>
        /// <param name="InvestorName"></param>
        /// <param name="ClientID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable Get_InvestorTracking_EOBNotComplete_General(string reportName, string InvestorName, string ClientID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }
            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("Reports");
                DataColumn dc = new DataColumn();

                //Common Fields
                dc = new DataColumn();
                dc.ColumnName = "LoanNumber";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "InvestorLoanNumber";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimType";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "InvestorName";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                //VIP #356 and #357 - 20110319 TRS 
                //Add next 5 date columns to both reports - Claim Paid EOB Not Complete and Claim Rejected EOB Not Complete
                dc = new DataColumn();
                dc.ColumnName = "FCSaleDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "PFSDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "TPSDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "DILDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "REOSaleDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ProcessorName";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "SubmitDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "SubmittedAmount";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimPaidAmount";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                //Claim Paid – EOB Not Complete specific fields
                dc = new DataColumn();
                dc.ColumnName = "QCProcessorName";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimPaidDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimPaidAging";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "PaymentFollowupCompleteDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "EOBAging";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                //Claim Rejected – EOB Not Complete specific fields
                dc = new DataColumn();
                dc.ColumnName = "RejectedDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "FollowupType";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "Comment";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "REO/Non-REO";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                switch (reportName)
                {
                    case "Claim Paid EOB Not Complete":
                        cmd.CommandText = "usprptInvestorTracking_ClaimPaid_EOBNotComplete";
                        break;
                    case "Claim Rejected EOB Not Complete":
                        cmd.CommandText = "usprptInvestorTracking_ClaimRejected_EOBNotComplete";
                        break;
                    default:
                        break;
                }

                SqlParameter parm = new SqlParameter("@InvestorName", InvestorName);
                cmd.Parameters.Add(parm);

                SqlParameter parm1 = new SqlParameter("@ClientID", ClientID);
                cmd.Parameters.Add(parm1);

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                decimal decimal2String;

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["LoanNumber"] = dr["LoanNumber"].ToString().Length == 0 ? "" : dr["LoanNumber"].ToString();
                    row["InvestorLoanNumber"] = dr["InvestorLoanNumber"].ToString().Length == 0 ? "" : dr["InvestorLoanNumber"].ToString();
                    row["ClaimType"] = dr["ClaimType"].ToString().Length == 0 ? "" : dr["ClaimType"].ToString();
                    row["InvestorName"] = dr["InvestorName"].ToString().Length == 0 ? "" : dr["InvestorName"].ToString();

                    //VIP #356 and #357 - 20110319 TRS 
                    //Add next 5 date columns to both reports - Claim Paid EOB Not Complete and Claim Rejected EOB Not Complete
                    row["FCSaleDate"] = DateTime.Parse(dr["ForeclosureSaleDate"].ToString().Length == 0 ? "1/1/1900" : dr["ForeclosureSaleDate"].ToString());
                    row["PFSDate"] = DateTime.Parse(dr["PreForeclosureSettlementDate"].ToString().Length == 0 ? "1/1/1900" : dr["PreForeclosureSettlementDate"].ToString());
                    row["TPSDate"] = DateTime.Parse(dr["ThirdPartySaleDate"].ToString().Length == 0 ? "1/1/1900" : dr["ThirdPartySaleDate"].ToString());
                    row["DILDate"] = DateTime.Parse(dr["DeedInLeuRecordDate"].ToString().Length == 0 ? "1/1/1900" : dr["DeedInLeuRecordDate"].ToString());
                    row["REOSaleDate"] = DateTime.Parse(dr["REOSaleDate"].ToString().Length == 0 ? "1/1/1900" : dr["REOSaleDate"].ToString());

                    row["ProcessorName"] = dr["ProcessorName"].ToString().Length == 0 ? "" : dr["ProcessorName"].ToString();
                    row["SubmitDate"] = DateTime.Parse(dr["SubmitDate"].ToString().Length == 0 ? "1/1/1900" : dr["SubmitDate"].ToString());

                    decimal2String = decimal.Parse(dr["SubmittedAmount"].ToString().Length == 0 ? "0" : dr["SubmittedAmount"].ToString());
                    row["SubmittedAmount"] = string.Format("{0:c}", decimal2String);

                    decimal2String = decimal.Parse(dr["ClaimPaidAmount"].ToString().Length == 0 ? "0" : dr["ClaimPaidAmount"].ToString());
                    row["ClaimPaidAmount"] = string.Format("{0:c}", decimal2String);

                    switch (reportName)
                    {
                        case "Claim Paid EOB Not Complete":
                            row["QCProcessorName"] = dr["QCProcessorName"].ToString().Length == 0 ? "" : dr["QCProcessorName"].ToString();
                            row["ClaimPaidDate"] = DateTime.Parse(dr["ClaimPaidDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClaimPaidDate"].ToString());
                            row["ClaimPaidAging"] = dr["ClaimPaidAging"].ToString().Length == 0 ? "" : dr["ClaimPaidAging"].ToString();
                            row["PaymentFollowupCompleteDate"] = DateTime.Parse(dr["PaymentFollowupCompleteDate"].ToString().Length == 0 ? "1/1/1900" : dr["PaymentFollowupCompleteDate"].ToString());
                            row["EOBAging"] = dr["EOBAging"].ToString().Length == 0 ? "" : dr["EOBAging"].ToString();

                            break;
                        case "Claim Rejected EOB Not Complete":
                            row["RejectedDate"] = DateTime.Parse(dr["RejectedDate"].ToString().Length == 0 ? "1/1/1900" : dr["RejectedDate"].ToString());
                            row["FollowupType"] = dr["FollowupType"].ToString().Length == 0 ? "" : dr["FollowupType"].ToString();
                            row["Comment"] = dr["Comment"].ToString().Length == 0 ? "" : dr["Comment"].ToString();
                            row["REO/Non-REO"] = dr["REO/Non-REO"].ToString().Length == 0 ? "" : dr["REO/Non-REO"].ToString();

                            break;
                        default:
                            break;
                    }

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;

            ExitPoint: ;
            }

            catch (Exception ex)
            {
                throw (ex);
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reportName"></param>
        /// <param name="InvestorName"></param>
        /// <param name="ClientID"></param>
        /// <param name="settings"></param>
        /// <param name="optParms"></param>
        /// <returns>DataTable</returns>
        internal DataTable Get_InvestorTracking_PaymentFollowupExceptions_General(string reportName, string InvestorName, string ClientID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }
            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("Reports");
                DataColumn dc = new DataColumn();

                dc = new DataColumn();
                dc.ColumnName = "id";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "Loanid";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "LoanNumber";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClientName";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimType";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "InvestorName";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                //VIP #358 - 20110321 TRS 
                //Add next 5 date columns to both reports - Claim Paid EOB Not Complete and Claim Rejected EOB Not Complete
                dc = new DataColumn();
                dc.ColumnName = "FCSaleDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "PFSDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "TPSDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "DILDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "REOSaleDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "CompleteDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimAmount";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "UserIDText";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "WorkFlowStepName";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimPaidDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimPaidAmount";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "FollowupType";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                switch (reportName)
                {
                    case "Payment FU Complete Exceptions":
                        cmd.CommandText = "usprptInvestorTracking_PaymentFUCompleteExceptions";
                        break;
                    case "Payment FU Not Complete Exceptions":
                        cmd.CommandText = "usprptInvestorTracking_PaymentFUNotCompleteExceptions";
                        break;
                    default:

                        break;
                }

                SqlParameter parm = new SqlParameter("@InvestorName", InvestorName);
                cmd.Parameters.Add(parm);

                SqlParameter parm1 = new SqlParameter("@ClientID", ClientID);
                cmd.Parameters.Add(parm1);

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                decimal decimal2String;

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["id"] = dr["id"].ToString().Length == 0 ? "" : dr["id"].ToString();
                    row["Loanid"] = dr["Loanid"].ToString().Length == 0 ? "" : dr["Loanid"].ToString();
                    row["LoanNumber"] = dr["LoanNumber"].ToString().Length == 0 ? "" : dr["LoanNumber"].ToString();
                    row["ClientName"] = dr["ClientName"].ToString().Length == 0 ? "" : dr["ClientName"].ToString();
                    row["ClaimType"] = dr["ClaimType"].ToString().Length == 0 ? "" : dr["ClaimType"].ToString();
                    row["InvestorName"] = dr["InvestorName"].ToString().Length == 0 ? "" : dr["InvestorName"].ToString();

                    //VIP #358 - 20110321 TRS 
                    //Add next 5 date columns to both reports - Claim Paid EOB Not Complete and Claim Rejected EOB Not Complete
                    row["FCSaleDate"] = DateTime.Parse(dr["ForeclosureSaleDate"].ToString().Length == 0 ? "1/1/1900" : dr["ForeclosureSaleDate"].ToString());
                    row["PFSDate"] = DateTime.Parse(dr["PreForeclosureSettlementDate"].ToString().Length == 0 ? "1/1/1900" : dr["PreForeclosureSettlementDate"].ToString());
                    row["TPSDate"] = DateTime.Parse(dr["ThirdPartySaleDate"].ToString().Length == 0 ? "1/1/1900" : dr["ThirdPartySaleDate"].ToString());
                    row["DILDate"] = DateTime.Parse(dr["DeedInLeuRecordDate"].ToString().Length == 0 ? "1/1/1900" : dr["DeedInLeuRecordDate"].ToString());
                    row["REOSaleDate"] = DateTime.Parse(dr["REOSaleDate"].ToString().Length == 0 ? "1/1/1900" : dr["REOSaleDate"].ToString());

                    row["CompleteDate"] = DateTime.Parse(dr["CompleteDate"].ToString().Length == 0 ? "1/1/1900" : dr["CompleteDate"].ToString());

                    decimal2String = decimal.Parse(dr["ClaimAmount"].ToString().Length == 0 ? "0" : dr["ClaimAmount"].ToString());
                    row["ClaimAmount"] = string.Format("{0:c}", decimal2String);

                    row["UserIDText"] = dr["UserIDText"].ToString().Length == 0 ? "" : dr["UserIDText"].ToString();
                    row["WorkFlowStepName"] = dr["WorkFlowStepName"].ToString().Length == 0 ? "" : dr["WorkFlowStepName"].ToString();
                    row["ClaimPaidDate"] = DateTime.Parse(dr["ClaimPaidDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClaimPaidDate"].ToString());

                    decimal2String = decimal.Parse(dr["ClaimPaidAmount"].ToString().Length == 0 ? "0" : dr["ClaimPaidAmount"].ToString());
                    row["ClaimPaidAmount"] = string.Format("{0:c}", decimal2String);

                    row["FollowupType"] = dr["FollowupType"].ToString().Length == 0 ? "" : dr["FollowupType"].ToString();

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;


            }

            catch (Exception ex)
            {
                throw (ex);
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ClientID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable Get_InvestorTracking_ClaimsSubmitted_ByClientID(int ClientID, Settings settings)
        {
            SqlConnection con = new SqlConnection(); 
            
            try
            {
                DataTable rtnData = new DataTable("CMSData");
                rtnData.Columns.Add("LoanID", typeof(int));
                rtnData.Columns.Add("LoanNumber", typeof(string));
                rtnData.Columns.Add("InvestorLoanNumber", typeof(string));
                rtnData.Columns.Add("InvestorName", typeof(string));
                rtnData.Columns.Add("ClaimID", typeof(int));
                rtnData.Columns.Add("ClaimType", typeof(string)); 
                rtnData.Columns.Add("ClaimAmount", typeof(decimal));
                rtnData.Columns.Add("ClaimPaidAmount", typeof(decimal));
                rtnData.Columns.Add("ClaimPaidDate", typeof(DateTime));
                rtnData.Columns.Add("DenialDate", typeof(DateTime));
                rtnData.Columns.Add("SubmitDate", typeof(DateTime));
                rtnData.Columns.Add("SubmittedByUser", typeof(int));
                rtnData.Columns.Add("LastUpdateDate", typeof(DateTime));
                rtnData.Columns.Add("LastUpdateUser", typeof(int));


                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_InvTrk_Import_LPS_PFU_Claims_Submitted_SelectByClientID";
                
                SqlParameter parm = new SqlParameter("@ClientID", ClientID);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = rtnData.NewRow();

                    row["LoanID"] = (int)dr["LoanID"];
                    row["LoanNumber"] = dr["LoanNumber"].ToString();
                    row["InvestorLoanNumber"] = dr["InvestorLoanNumber"].ToString();
                    row["InvestorName"] = dr["InvestorName"].ToString();
                    row["ClaimID"] = (int)dr["ClaimID"];
                    row["ClaimType"] = dr["ClaimType"].ToString(); 
                    row["ClaimAmount"] = (decimal)dr["ClaimAmount"];
                    row["ClaimPaidAmount"] = (decimal)dr["ClaimPaidAmount"];
                    row["ClaimPaidDate"] = (DateTime)dr["ClaimPaidDate"];
                    row["DenialDate"] = (DateTime)dr["DenialDate"]; 
                    row["SubmitDate"] = (DateTime)dr["SubmitDate"];
                    row["SubmittedByUser"] = (int)dr["SubmittedByUser"];
                    row["LastUpdateDate"] = (DateTime)dr["LastUpdateDate"];
                    row["LastUpdateUser"] = (int)dr["LastUpdateUser"];

                    rtnData.Rows.Add(row);

                }

                dr.Close();
                dr.Dispose();

                rtnData.AcceptChanges();
                return rtnData;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="missingDocs"></param>
        /// <param name="loanID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetInvestorTrackingLoanMissingDocument(DataTable missingDocs, int loanID, int claimID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_InvTrk_MissingDocuments_Select";
                SqlParameter parm = new SqlParameter("@LoanID", loanID);
                // 20190313 gk fb65126 move claim into missingdocuemnts_select
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@ClaimID", claimID);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = missingDocs.NewRow();
                    row["ID"] = int.Parse(dr["ID"].ToString());
                    row["LoanID"] = int.Parse(dr["LoanID"].ToString());
                    row["ClaimID"] = int.Parse(dr["ClaimID"].ToString());
                    row["DocumentTypeID"] = int.Parse(dr["DocumentTypeID"].ToString());
                    row["DocumentType"] = dr["DocumentType"].ToString();
                    row["DueDate"] = DateTime.Parse(dr["DueDate"].ToString().Length == 0 ? "1/1/1900" : dr["DueDate"].ToString());
                    row["Received"] = dr["Received"].ToString();
                    row["Comments"] = dr["Comments"].ToString();
                    row["DateEntered"] = DateTime.Parse(dr["DateEntered"].ToString());
                    row["UserEntered"] = int.Parse(dr["UserEntered"].ToString());
                    row["UserEnteredName"] = dr["UserEnteredName"].ToString();
                    row["DateReceived"] = DateTime.Parse(dr["DateReceived"].ToString().Length == 0 ? "1/1/1900" : dr["DateReceived"].ToString());
                    row["UserReceived"] = dr["UserReceived"].ToString().Length == 0 ? 0 : int.Parse(dr["UserReceived"].ToString());
                    row["UserReceivedName"] = dr["UserReceivedName"].ToString();
                    row["NotRequired"] = dr["NotRequired"].ToString();
                    row["DateNotRequired"] = DateTime.Parse(dr["DateNotRequired"].ToString().Length == 0 ? "1/1/1900" : dr["DateNotRequired"].ToString());
                    row["UserNotRequired"] = dr["UserNotRequired"].ToString().Length == 0 ? 0 : int.Parse(dr["UserNotRequired"].ToString());
                    row["UserNotRequiredName"] = dr["UserNotRequiredName"].ToString();
                    row["ConveyanceClaimPart"] = dr["ConveyanceClaimPart"].ToString();
                    row["ConveyanceClaimPartID"] = dr["ConveyanceClaimPartID"].ToString().Length == 0 ? 0 : int.Parse(dr["ConveyanceClaimPartID"].ToString());
                    row["LastUpdateDate"] = DateTime.Parse(dr["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dr["LastUpdateDate"].ToString());
                    row["LastUpdateUserID"] = dr["LastUpdateUserID"].ToString().Length == 0 ? 0 : int.Parse(dr["LastUpdateUserID"].ToString());
                    //FB 43392 ARG 20170406
                    row["MissingDocAmount"] = dr["MissingDocAmount"].ToString().Length == 0 ? 0 : decimal.Parse(dr["MissingDocAmount"].ToString());
                    row["MissingDocFromDate"] = DateTime.Parse(dr["MissingDocFromDate"].ToString().Length == 0 ? "1/1/1900" : dr["MissingDocFromDate"].ToString());
                    row["MissingDocToDate"] = DateTime.Parse(dr["MissingDocToDate"].ToString().Length == 0 ? "1/1/1900" : dr["MissingDocToDate"].ToString());
                    //End FB 43392
                    // gk 20190820 add parent and stautsid
                    row["ParentID"] = dr["ParentID"];
                    row["StatusID"] = dr["StatusID"];
                    row["StatusUpdateUserID"] = dr["StatusUpdateUserID"];
                    row["StatusUpdateUserName"] = dr["StatusUpdateUserName"];
                    row["StatusUpdateDate"] = dr["StatusUpdateDate"];
                    // gk 20190820 end add parent and stautsid
                    row["deltaCheck"] = dr["deltaCheck"].ToString();

                    missingDocs.Rows.Add(row);
                }

                dr.Close();
                dr.Dispose();

                missingDocs.AcceptChanges();

                return missingDocs;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }

        }

        /// <summary>
        /// Legacy code copied from Moss.Data to this class.  Slight renaming used to differentiate.
        /// </summary>
        /// <param name="workflowStepsData"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable Get_InvestorTracking_WorkflowActiveStepsData(DataTable workflowStepsData, Settings settings)
        {
            SqlConnection con = new SqlConnection();
            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }
            catch (Exception e)
            {
                throw e;
            }

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usptbllkp_Workflows_Steps_InvestorTracking_GetActiveWorkflowSteps";

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = workflowStepsData.NewRow();

                    row["id"] = (int)dr["id"];
                    row["WorkflowStepName"] = dr["WorkflowStepName"].ToString();
                    row["WorkflowStepOrder"] = int.Parse(dr["WorkflowStepOrder"].ToString());

                    workflowStepsData.Rows.Add(row);
                }
                workflowStepsData.AcceptChanges();
                return workflowStepsData;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns>DataTable</returns>
        internal DataTable InvestorTracking_InvestorNames_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ApplicationConfiguration");
                con.Open();
            }
            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("Filters");
                DataColumn dc = new DataColumn();

                dc = new DataColumn();
                dc.ColumnName = "Filter";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "DisplayValue";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usp_InvTrk_InvestorNamesFilter_Get";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["Filter"] = dr["Filter"].ToString();
                    row["DisplayValue"] = dr["DisplayValue"].ToString();

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw (ex);
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool SaveInvestorTrackingClaim(DataTable dt, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                int recordsAffected;

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                    SqlParameter prm = new SqlParameter();

                    switch (dt.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            //cmd.CommandText = "";
                            break;
                        case DataRowState.Deleted:
                            break;
                        case DataRowState.Detached:
                            break;
                        case DataRowState.Modified:
                            cmd.CommandText = "usp_InvTrk_Claim_Update";
                            break;
                        case DataRowState.Unchanged:
                            goto NextRecord;
                        //break;
                        default:
                            break;
                    }

                    cmd.Connection = con;
                    prm = new SqlParameter("@id", dt.Rows[i]["ID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimType", dt.Rows[i]["ClaimType"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimDueDate", dt.Rows[i]["ClaimDueDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimAmount", dt.Rows[i]["ClaimAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@NoBill", dt.Rows[i]["NoBill"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@NoClaimSubmitted", dt.Rows[i]["NoClaimSubmitted"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimPerfectionDate", dt.Rows[i]["ClaimPerfectionDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimPaidDate", dt.Rows[i]["ClaimPaidDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimPaidAmount", dt.Rows[i]["ClaimPaidAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@RejectedDate", dt.Rows[i]["RejectedDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimClosed", dt.Rows[i]["ClaimClosed"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimClosedDate", dt.Rows[i]["ClaimClosedDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimClosedUser", dt.Rows[i]["ClaimClosedUser"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LastUpdateDate", dt.Rows[i]["LastUpdateDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LastUpdateUser", dt.Rows[i]["LastUpdateUser"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClosingReason", dt.Rows[i]["ClosingReason"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PFU_EOBReviewOnly", dt.Rows[i]["PFU_EOBReviewOnly"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PreSaleSettlementProceedsAmount", dt.Rows[i]["PreSaleSettlementProceedsAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@OptionSettlementCoveragePct", dt.Rows[i]["OptionSettlementCoveragePct"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@RecissionDate", dt.Rows[i]["RecissionDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@CancellationDate", dt.Rows[i]["CancellationDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClosedWithoutPaymentDate", dt.Rows[i]["ClosedWithoutPaymentDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@CarrierSettlementType", dt.Rows[i]["CarrierSettlementType"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@RevisedClaimAmt", dt.Rows[i]["RevisedClaimAmt"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@RevisedProceedsAmt", dt.Rows[i]["RevisedProceedsAmt"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@RevisedEstSettlementAmt", dt.Rows[i]["RevisedEstSettlementAmt"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SecondaryClaimDueDate", dt.Rows[i]["SecondaryClaimDueDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@DeltaCheck", dt.Rows[i]["DeltaCheck"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@IsClaimCancelled", dt.Rows[i]["IsClaimCancelled"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimCancelledDate", dt.Rows[i]["ClaimCancelledDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimCancelledUserID", dt.Rows[i]["ClaimCancelledUserID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@IsZeroNeg", dt.Rows[i]["IsZeroNeg"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ZeroNegDate", dt.Rows[i]["ZeroNegDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ZeroNegUserID", dt.Rows[i]["ZeroNegUserID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@IndustryClaimDueDate", dt.Rows[i]["IndustryClaimDueDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SuppParentClaimID", dt.Rows[i]["SuppParentClaimID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ConventionalUSDASupplemental", dt.Rows[i]["ConventionalUSDASupplemental"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ConventionalTaxSupplemental", dt.Rows[i]["ConventionalTaxSupplemental"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@OpsModifiableIndustryDueDate", dt.Rows[i]["OpsModifiableIndustryDueDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@OpsModifiableSLADueDate", dt.Rows[i]["OpsModifiableSLADueDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@OpsModifiableNotWorkable", dt.Rows[i]["OpsModifiableNotWorkable"]);
                    cmd.Parameters.Add(prm);

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;

                }

                dt.AcceptChanges();

                return true;

            }

            catch (SqlException e)
            {
                //dump the table into an error file so we have some record of where we were
                try
                {
                    CRFS.Data.ErrorDataDump.DumpTableToDefaultLocation(dt, "");

                }

                catch { }
                throw e;

            }

            finally
            {

                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool SaveInvestorTrackingVAClaim(DataTable dt, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                int recordsAffected;

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                    SqlParameter prm = new SqlParameter();

                    switch (dt.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            break;
                        case DataRowState.Deleted:
                            break;
                        case DataRowState.Detached:
                            break;
                        case DataRowState.Modified:
                            cmd.CommandText = "usp_InvTrk_VAClaim_Update";
                            break;
                        case DataRowState.Unchanged:
                            goto NextRecord;
                        //break;
                        default:
                            break;
                    }

                    cmd.Connection = con;
                    prm = new SqlParameter("@VAClaimID", dt.Rows[i]["VAClaimID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@TOCFiledDate", dt.Rows[i]["TOCFiledDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@TOCFiledProcessorID", dt.Rows[i]["TOCFiledProcessorID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@TOCResubmitDate", dt.Rows[i]["TOCResubmitDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@TOCResubmitProcessorID", dt.Rows[i]["TOCResubmitProcessorID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@TOCPaidDate", dt.Rows[i]["TOCPaidDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@TOCPaidAmount", dt.Rows[i]["TOCPaidAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@TitlePkgExtensionDate", dt.Rows[i]["TitlePkgExtensionDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@TitlePkgExtensionProcessorID", dt.Rows[i]["TitlePkgExtensionProcessorID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@TitlePkgSubmitDate", dt.Rows[i]["TitlePkgSubmitDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@TitlePkgSubmitProcessorID", dt.Rows[i]["TitlePkgSubmitProcessorID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@TitlePkgRefundPkgSubmitDate", dt.Rows[i]["TitlePkgRefundPkgSubmitDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimPrepDate", dt.Rows[i]["ClaimPrepDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimPrepID", dt.Rows[i]["ClaimPrepID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimSubmitDate", dt.Rows[i]["ClaimSubmitDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimSubmitProcessorID", dt.Rows[i]["ClaimSubmitProcessorID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimResubmitDate", dt.Rows[i]["ClaimResubmitDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimResubmitProcessorID", dt.Rows[i]["ClaimResubmitProcessorID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@Claim3rdPartyProceedsRecievedDate", dt.Rows[i]["Claim3rdPartyProceedsRecievedDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimPaidDate", dt.Rows[i]["ClaimPaidDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimPaidAmount", dt.Rows[i]["ClaimPaidAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SupplementalClaimDue", dt.Rows[i]["SupplementalClaimDue"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SupplementalFiledDate", dt.Rows[i]["SupplementalFiledDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SupplementalFiledProcessorID", dt.Rows[i]["SupplementalFiledProcessorID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SupplementalPaidDate", dt.Rows[i]["SupplementalPaidDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SupplementalPaidAmount", dt.Rows[i]["SupplementalPaidAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SupplementalDeniedDate", dt.Rows[i]["SupplementalDeniedDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorClaimDue", dt.Rows[i]["InvestorClaimDue"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorClaimFiledDate", dt.Rows[i]["InvestorClaimFiledDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorClaimAmount", dt.Rows[i]["InvestorClaimAmount"]);
                    cmd.Parameters.Add(prm);

                    prm = new SqlParameter("@InvestorClaimType", dt.Rows[i]["InvestorClaimType"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorClaimOutcomeChangeDate", DBNull.Value);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorClaimOutcome", dt.Rows[i]["InvestorClaimOutcome"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorClaimOutcomeChangedBy", dt.Rows[i]["InvestorClaimOutcomeChangedBy"]);
                    cmd.Parameters.Add(prm);

                    prm = new SqlParameter("@LastUpdateUser", dt.Rows[i]["LastUpdateUser"]);
                    cmd.Parameters.Add(prm);
                    // 20130613 gk [t-20396] read out the parameters of the datatable to make sure it is getting there
                    string dbg = "TOCAmount=" + dt.Rows[i]["TOCAmount"] + "ClaimAmount " + dt.Rows[i]["ClaimAmount"] + "SupplementalAmount = " + dt.Rows[i]["SupplementalAmount"];
                    prm = new SqlParameter("@TOCAmount", dt.Rows[i]["TOCAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimAmount", dt.Rows[i]["ClaimAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SupplementalAmount", dt.Rows[i]["SupplementalAmount"]);
                    cmd.Parameters.Add(prm);
                    // MessageBox.Show(dbg);
                    // 20140826 gk fb2043
                    prm = new SqlParameter("@TerminationDate", dt.Rows[i]["TerminationDate"]);
                    cmd.Parameters.Add(prm);
                    // 20170127 MF FB42020 Add Prep Due Date column.
                    prm = new SqlParameter("@PrepDueDate", dt.Rows[i]["PrepDueDate"]);
                    cmd.Parameters.Add(prm);

                    prm = new SqlParameter("@TOCNoBill", dt.Rows[i]["TOCNoBill"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@TOCNoBillDate", dt.Rows[i]["TOCNoBillDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@TOCNoBillBy", dt.Rows[i]["TOCNoBillBy"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@TitlePkgNoBill", dt.Rows[i]["TitlePkgNoBill"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@TitlePkgNoBillDate", dt.Rows[i]["TitlePkgNoBillDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@TitlePkgNoBillBy", dt.Rows[i]["TitlePkgNoBillBy"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimNoBill", dt.Rows[i]["ClaimNoBill"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimNoBillDate", dt.Rows[i]["ClaimNoBillDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimNoBillBy", dt.Rows[i]["ClaimNoBillBy"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SupplementalNoBill", dt.Rows[i]["SupplementalNoBill"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SupplementalNoBillDate", dt.Rows[i]["SupplementalNoBillDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@SupplementalNoBillBy", dt.Rows[i]["SupplementalNoBillBy"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorClaimNoBill", dt.Rows[i]["InvestorClaimNoBill"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorClaimNoBillDate", dt.Rows[i]["InvestorClaimNoBillDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorClaimNoBillBy", dt.Rows[i]["InvestorClaimNoBillBy"]);
                    cmd.Parameters.Add(prm);

                    // 20160203 gk deltacheck
                    prm = new SqlParameter("@deltaCheck", dt.Rows[i]["deltaCheck"]);
                    cmd.Parameters.Add(prm);

                    recordsAffected = cmd.ExecuteNonQuery();

                NextRecord: ;

                }

                dt.AcceptChanges();

                return true;

            }

            catch (Exception ex)
            {
                //dump the table into an error file so we have some record of where we were
                try
                {
                    CRFS.Data.ErrorDataDump.DumpTableToDefaultLocation(dt, "");

                }

                catch { }
                throw ex;

            }

            finally
            {

                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="LoanData"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool SaveInvestorTrackingLoan(DataTable LoanData, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                int recordsAffected;
                bool saved = false;

                //Get eligible items
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                //SqlCommand cmd1 = new SqlCommand();
                cmd = new SqlCommand();
                SqlParameter prm = new SqlParameter();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                switch (LoanData.Rows[0].RowState)
                {
                    case DataRowState.Added:
                        break;
                    case DataRowState.Deleted:
                        break;
                    case DataRowState.Detached:
                        break;
                    case DataRowState.Modified:
                        cmd.CommandText = "usp_InvTrk_Loan_Update";
                        break;
                    case DataRowState.Unchanged:
                        saved = true;
                        return saved;
                    //break;
                    default:
                        break;
                }

                cmd.Connection = con;
                prm = new SqlParameter("@ID", LoanData.Rows[0]["ID"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@LoanNumber", LoanData.Rows[0]["LoanNumber"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@ClientID", LoanData.Rows[0]["ClientID"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@PropertyAddress", LoanData.Rows[0]["PropertyAddress"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@PropertyCity", LoanData.Rows[0]["PropertyCity"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@PropertyState", LoanData.Rows[0]["PropertyState"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@PropertyZip", LoanData.Rows[0]["PropertyZip"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@ServicerNumber", LoanData.Rows[0]["ServicerNumber"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@ServicerName", LoanData.Rows[0]["ServicerName"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@ServicerAddress", LoanData.Rows[0]["ServicerAddress"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@ServicerCity", LoanData.Rows[0]["ServicerCity"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@ServicerState", LoanData.Rows[0]["ServicerState"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@ServicerZip", LoanData.Rows[0]["ServicerZip"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@InvestorID", LoanData.Rows[0]["InvestorID"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@InvestorName", LoanData.Rows[0]["InvestorName"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@MICompanyID", LoanData.Rows[0]["MICompanyID"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@MIGuarantyNumber", LoanData.Rows[0]["MIGuarantyNumber"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@BorrowerFirstName", LoanData.Rows[0]["BorrowerFirstName"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@BorrowerLastName", LoanData.Rows[0]["BorrowerLastName"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@InvestorLoanNumber", LoanData.Rows[0]["InvestorLoanNumber"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@ReferDateToMI", LoanData.Rows[0]["ReferDateToMI"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@PreForeclosureSettlementDate", LoanData.Rows[0]["PreForeclosureSettlementDate"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@DeedInLeuRecordDate", LoanData.Rows[0]["DeedInLeuRecordDate"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@ForeClosureDate", LoanData.Rows[0]["ForeClosureDate"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@ForeclosureSaleDate", LoanData.Rows[0]["ForeclosureSaleDate"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@REOSaleDate", LoanData.Rows[0]["REOSaleDate"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@RRCDate", LoanData.Rows[0]["RRCDate"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@FHACaseNumber", LoanData.Rows[0]["FHACaseNumber"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@MICertNumber", LoanData.Rows[0]["MICertNumber"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@MIFiledDate", LoanData.Rows[0]["MIFiledDate"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@PoolCompany", LoanData.Rows[0]["PoolCompany"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@PoolCertNumber", LoanData.Rows[0]["PoolCertNumber"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@PoolFiledDate", LoanData.Rows[0]["PoolFiledDate"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@ThirdPartySaleDate", LoanData.Rows[0]["ThirdPartySaleDate"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@LastUpdateDate", LoanData.Rows[0]["LastUpdateDate"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@LastUpdateUser", LoanData.Rows[0]["LastUpdateUser"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@AttorneyName", LoanData.Rows[0]["AttorneyName"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@PCCDate", LoanData.Rows[0]["PCCDate"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@GADate", LoanData.Rows[0]["GADate"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@MarketingExpirationDate", LoanData.Rows[0]["MarketingExpirationDate"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@LiquidationDate", LoanData.Rows[0]["LiquidationDate"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@NPLSaleDate", LoanData.Rows[0]["NPLSaleDate"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@RefundingDate", LoanData.Rows[0]["RefundingDate"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@EvictionAttorney", LoanData.Rows[0]["EvictionAttorney"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@TitleCompany", LoanData.Rows[0]["TitleCompany"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@PandPCompany", LoanData.Rows[0]["PandPCompany"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@IsAcquisitionLoan", LoanData.Rows[0]["IsAcquisitionLoan"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@AcquisitionLoanSetByUserID", LoanData.Rows[0]["AcquisitionLoanSetByUserID"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@AquisitionLoanSetDate", LoanData.Rows[0]["AquisitionLoanSetDate"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@AquisitionLoanSetOnClaimID", LoanData.Rows[0]["AquisitionLoanSetOnClaimID"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@ForeclosureTypeID", LoanData.Rows[0]["ForeclosureTypeID"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@PropertyAcquisitionDate", LoanData.Rows[0]["PropertyAcquisitionDate"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@PromissoryNoteDate", LoanData.Rows[0]["PromissoryNoteDate"]);
                cmd.Parameters.Add(prm);
                prm = new SqlParameter("@deltaCheck", LoanData.Rows[0]["deltaCheck"]);
                cmd.Parameters.Add(prm);


                recordsAffected = cmd.ExecuteNonQuery();

                LoanData.AcceptChanges();

                return true;
            }
            catch (Exception e)
            {
                //dump the table into an error file so we have some record of where we were
                try
                {
                    CRFS.Data.ErrorDataDump.DumpTableToDefaultLocation(LoanData, "");

                }
                catch { }
                throw e;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="MissingDocs"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool SaveInvestorTrackingLoanMissingDocs(DataTable MissingDocs, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                int recordsAffected;

                //Get eligible items
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");

                con.Open();

                for (int i = 0; i < MissingDocs.Rows.Count; i++)
                {
                    SqlCommand cmd = new SqlCommand();
                    //SqlCommand cmd1 = new SqlCommand();
                    cmd = new SqlCommand();
                    SqlParameter prm = new SqlParameter();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    switch (MissingDocs.Rows[i].RowState)
                    {
                        case DataRowState.Added:
                            cmd.CommandText = "usp_InvTrk_MissingDocuments_Insert";
                            break;
                        case DataRowState.Deleted:
                            break;
                        case DataRowState.Detached:
                            break;
                        case DataRowState.Modified:
                            cmd.CommandText = "usp_InvTrk_MissingDocuments_Update";
                            break;
                        case DataRowState.Unchanged:
                            goto NextRecord;
                        //break;
                        default:
                            break;
                    }

                    cmd.Connection = con;
                    prm = new SqlParameter("@id", MissingDocs.Rows[i]["ID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LoanID", MissingDocs.Rows[i]["LoanID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimID", MissingDocs.Rows[i]["ClaimID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@DocumentTypeID", MissingDocs.Rows[i]["DocumentTypeID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@DueDate", MissingDocs.Rows[i]["DueDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@Received", MissingDocs.Rows[i]["Received"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@Comments", MissingDocs.Rows[i]["Comments"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@DateEntered", MissingDocs.Rows[i]["DateEntered"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@UserEntered", MissingDocs.Rows[i]["UserEntered"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@DateReceived", MissingDocs.Rows[i]["DateReceived"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@UserReceived", MissingDocs.Rows[i]["UserReceived"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@NotRequired", MissingDocs.Rows[i]["NotRequired"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@DateNotRequired", MissingDocs.Rows[i]["DateNotRequired"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@UserNotRequired", MissingDocs.Rows[i]["UserNotRequired"]);
                    cmd.Parameters.Add(prm);
                    // gk 20150223 
                    prm = new SqlParameter("@ConveyanceClaimPartID", MissingDocs.Rows[i]["ConveyanceClaimPartID"]);
                    cmd.Parameters.Add(prm);
                    //TRS 20160630
                    prm = new SqlParameter("@LastUpdateDate", MissingDocs.Rows[i]["LastUpdateDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LastUpdateUserID", MissingDocs.Rows[i]["LastUpdateUserID"]);
                    cmd.Parameters.Add(prm);
                    //FB 43392 ARG 20170406
                    prm = new SqlParameter("@MissingDocAmount", MissingDocs.Rows[i]["MissingDocAmount"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@MissingDocFromDate", MissingDocs.Rows[i]["MissingDocFromDate"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@MissingDocToDate", MissingDocs.Rows[i]["MissingDocToDate"]);
                    cmd.Parameters.Add(prm);

                    if (MissingDocs.Rows[i].RowState == DataRowState.Modified)
                    {
                        prm = new SqlParameter("@deltaCheck", MissingDocs.Rows[i]["deltaCheck"]);
                        cmd.Parameters.Add(prm);
                    }
                    // 20190820 gk new parameters
                    prm = new SqlParameter("@ParentID", MissingDocs.Rows[i]["ParentID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@StatusID", MissingDocs.Rows[i]["StatusID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@StatusUpdateUserID", MissingDocs.Rows[i]["StatusUpdateUserID"]);
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@StatusUpdateDate", MissingDocs.Rows[i]["StatusUpdateDate"]);
                    cmd.Parameters.Add(prm);

                    recordsAffected = cmd.ExecuteNonQuery();
                NextRecord: ;
                }

                MissingDocs.AcceptChanges();

                return true;
            }
            catch (Exception e)
            {
                //dump the table into an error file so we have some record of where we were
                try
                {
                    CRFS.Data.ErrorDataDump.DumpTableToDefaultLocation(MissingDocs, "");
                }
                catch { }
                throw e;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /*31043
        /// <summary>
        /// Moved from Moss.Data to resolve circular dependancy preventing recompile of CRFS.Data and Moss.Data
        /// </summary>
        /// <param name="LoanID"></param>
        /// <param name="ClientID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable SelectOpenClaimsDataByLoanIDClientID(int LoanID, int ClientID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }
            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("Claims");
                DataColumn dc = new DataColumn();

                dc = new DataColumn();
                dc.ColumnName = "ClaimID";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimClosed";
                dc.DataType = typeof(bool);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimType";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimPaidDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "ClaimPaidAmount";
                dc.DataType = typeof(decimal);
                dt.Columns.Add(dc);

                //VIP Task # 323 20110608 TRS added next column for not overwriting claim info when rejected date is filled in.
                dc = new DataColumn();
                dc.ColumnName = "RejectedDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "SubmitDate";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "PFUWorkFlowRecordID";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usptblInvestorTracking_Claims_SelectOpenClaimsDataByLoanIDClientID";

                SqlParameter parm = new SqlParameter("@LoanID", LoanID);
                cmd.Parameters.Add(parm);

                parm = new SqlParameter("@ClientID", ClientID);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ClaimID"] = int.Parse(dr["ClaimID"].ToString().Length == 0 ? "0" : dr["ClaimID"].ToString());
                    row["ClaimClosed"] = bool.Parse(dr["ClaimClosed"].ToString().Length == 0 ? "false" : dr["ClaimClosed"].ToString());
                    row["ClaimType"] = dr["ClaimType"].ToString().Length == 0 ? "" : dr["ClaimType"].ToString();
                    row["ClaimPaidDate"] = DateTime.Parse(dr["ClaimPaidDate"].ToString().Length == 0 ? "1/1/1900" : dr["ClaimPaidDate"].ToString());
                    row["ClaimPaidAmount"] = decimal.Parse(dr["ClaimPaidAmount"].ToString().Length == 0 ? "0" : dr["ClaimPaidAmount"].ToString());

                    //VIP Task # 323 20110608 TRS added next column for not overwriting claim info when rejected date is filled in.
                    row["RejectedDate"] = DateTime.Parse(dr["RejectedDate"].ToString().Length == 0 ? "1/1/1900" : dr["RejectedDate"].ToString());

                    row["SubmitDate"] = DateTime.Parse(dr["SubmitDate"].ToString().Length == 0 ? "1/1/1900" : dr["SubmitDate"].ToString());
                    row["PFUWorkFlowRecordID"] = int.Parse(dr["PFUWorkFlowRecordID"].ToString().Length == 0 ? "0" : dr["PFUWorkFlowRecordID"].ToString());

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;
            }

            catch (Exception ex)
            {
                throw (ex);
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }


        }
        */
               

        #endregion

        /*31043
        #region "Imports - Claims 332"
        /// <summary>
        /// 
        /// </summary>
        /// <param name="loanNumber"></param>
        /// <param name="clientID"></param>
        /// <param name="claimType"></param>
        /// <param name="claimFormID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal int CheckExistingLoan(string loanNumber, int clientID, string claimType, int claimFormID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                int recordsAffected = 0;

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_CLM332_CheckExistingLoan";

                SqlParameter parm = new SqlParameter("@LoanNumber", loanNumber);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@ClientID", clientID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@ClaimType", claimType);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@ClaimFormID", claimFormID);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;
                recordsAffected = (int)cmd.ExecuteScalar();

                return recordsAffected;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dtClaim"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal int Claims332_Import_InsertNewClaim(DataTable dtClaim, Settings settings)
        {
            SqlConnection con = new SqlConnection();
            try
            {
                int NewClaimID = 0;

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                if (con.State == ConnectionState.Open)
                {
                    SqlCommand cmd = new SqlCommand();
                    SqlParameter prm = new SqlParameter();
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.CommandText = "usp_CLM332_tblClaims_Details_Insert_RtnClaimID";

                    prm = new SqlParameter("@LoanNumber", dtClaim.Rows[0]["LoanNumber"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimType", dtClaim.Rows[0]["ClaimType"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimDueDate", DateTime.Parse(dtClaim.Rows[0]["ClaimDueDate"].ToString().Length == 0 ? "1/1/1900" : dtClaim.Rows[0]["ClaimDueDate"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClientID", int.Parse(dtClaim.Rows[0]["ClientID"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PropertyAddress", dtClaim.Rows[0]["PropertyAddress"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PropertyCity", dtClaim.Rows[0]["PropertyCity"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PropertyState", dtClaim.Rows[0]["PropertyState"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PropertyZip", dtClaim.Rows[0]["PropertyZip"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ServicerName", dtClaim.Rows[0]["ServicerName"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ServicerAddress", dtClaim.Rows[0]["ServicerAddress"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ServicerCity", dtClaim.Rows[0]["ServicerCity"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ServicerState", dtClaim.Rows[0]["ServicerState"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ServicerZip", dtClaim.Rows[0]["ServicerZip"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimFormID", int.Parse(dtClaim.Rows[0]["ClaimFormID"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@BorrowerFirstName", dtClaim.Rows[0]["BorrowerFirstName"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@BorrowerLastName", dtClaim.Rows[0]["BorrowerLastName"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorLoanNumber", dtClaim.Rows[0]["InvestorLoanNumber"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@EnteredByUser", int.Parse(dtClaim.Rows[0]["EnteredByUser"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ForeClosureDate", DateTime.Parse(dtClaim.Rows[0]["ForeClosureDate"].ToString().Length == 0 ? "1/1/1900" : dtClaim.Rows[0]["ForeClosureDate"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@RRCDate", DateTime.Parse(dtClaim.Rows[0]["RRCDate"].ToString().Length == 0 ? "1/1/1900" : dtClaim.Rows[0]["RRCDate"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@REOSaleDate", DateTime.Parse(dtClaim.Rows[0]["REOSaleDate"].ToString().Length == 0 ? "1/1/1900" : dtClaim.Rows[0]["REOSaleDate"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorCodeID", int.Parse(dtClaim.Rows[0]["InvestorCodeID"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorNameID", int.Parse(dtClaim.Rows[0]["InvestorNameID"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@CMaxClientID", dtClaim.Rows[0]["CMaxClientID"].ToString());
                    cmd.Parameters.Add(prm);

                    NewClaimID = int.Parse(cmd.ExecuteScalar().ToString());

                }



                return NewClaimID;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt332Details"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool Claims332_Import_InsertNewClaim332Details(DataTable dt332Details, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                bool RecordSaved = false;
                int RecordsAffected = -1000;

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                if (con.State == ConnectionState.Open)
                {
                    SqlCommand cmd = new SqlCommand();
                    SqlParameter prm = new SqlParameter();
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.CommandText = "usp_CLM332_tblClaims_332_Details_Insert";

                    prm = new SqlParameter("@ClaimID", dt332Details.Rows[0]["ClaimID"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LiquidationType", dt332Details.Rows[0]["LiquidationType"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LiquidationDate", dt332Details.Rows[0]["LiquidationDate"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LienNumber", dt332Details.Rows[0]["LienNumber"].ToString());
                    cmd.Parameters.Add(prm);

                    RecordsAffected = cmd.ExecuteNonQuery();

                    if (RecordsAffected == 1)
                    {
                        RecordSaved = true;

                    }

                }

                return RecordSaved;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dtWorkflow"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool Claims332_Import_InsertInitialWorkflowRecord(DataTable dtWorkflow, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                bool RecordSaved = false;
                int RecordsAffected = -1000;

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                if (con.State == ConnectionState.Open)
                {
                    SqlCommand cmd = new SqlCommand();
                    SqlParameter prm = new SqlParameter();
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.CommandText = "usptblClaims_Workflow_InsertInitialWorkflowRecord";

                    prm = new SqlParameter("@ClaimID", dtWorkflow.Rows[0]["ClaimID"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PrimaryFormID", dtWorkflow.Rows[0]["FormID"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@OpenUser", dtWorkflow.Rows[0]["OpenUser"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@AssignedToUser", dtWorkflow.Rows[0]["AssignedToUser"].ToString());
                    cmd.Parameters.Add(prm);

                    RecordsAffected = cmd.ExecuteNonQuery();

                    if (RecordsAffected == 1)
                    {
                        RecordSaved = true;

                    }

                }

                return RecordSaved;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
            }

        }
        #endregion
        */

        #region "Imports FNMA PFU"

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FNMALoanNumber"></param>
        /// <returns></returns>
        internal DataTable PFU_AutoCloseExceptionEvaluation_SelectByFNMALoanNumber(string FNMALoanNumber)
        {
            SqlConnection con = new SqlConnection(); 
            
            try
            {
                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlParameter parm = new SqlParameter();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.Connection = con;

                cmd.CommandText = "usp_PFU_AutoCloseExceptionEvaluation_SelectByFNMALoanNumber";

                parm = new SqlParameter("@FNMALoanNumber", FNMALoanNumber);
                cmd.Parameters.Add(parm);

                SqlDataReader dr = cmd.ExecuteReader();

                DataTable dt = new DataTable("ExceptionEvaluationData");

                dt.Columns.Add("ReferralID", typeof(int));
                dt.Columns.Add("REO_ID", typeof(string));
                dt.Columns.Add("FNMALoanNumber", typeof(string));
                dt.Columns.Add("ReferralTypeID", typeof(int));
                dt.Columns.Add("Status", typeof(string));
                dt.Columns.Add("ReferralDate", typeof(DateTime));

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["ReferralID"] = int.Parse(dr["ReferralID"].ToString().Length == 0 ? "0" : dr["ReferralID"].ToString());
                    row["REO_ID"] = dr["REO_ID"].ToString();
                    row["FNMALoanNumber"] = dr["FNMALoanNumber"].ToString();
                    row["ReferralTypeID"] = int.Parse(dr["ReferralTypeID"].ToString().Length == 0 ? "0" : dr["ReferralTypeID"].ToString());
                    row["Status"] = dr["Status"].ToString();
                    row["ReferralDate"] = DateTime.Parse(dr["ReferralDate"].ToString().Length == 0 ? "1/1/1900" : dr["ReferralDate"].ToString());


                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ReferralID"></param>
        /// <param name="CDRTStatus"></param>
        /// <param name="MIResponseToReopen"></param>
        /// <param name="CDRTNotificationDate"></param>
        /// <param name="MIReopenResponseDate"></param>
        /// <param name="CDRTResolutionDate"></param>
        /// <param name="UserID"></param>
        /// <returns></returns>
        internal bool PFU_CDRT_UpSert(int ReferralID, 
                                      int CDRTStatus, 
                                      int MIResponseToReopen, 
                                      DateTime CDRTNotificationDate, 
                                      DateTime MIReopenResponseDate, 
                                      DateTime CDRTResolutionDate,
                                      int UserID)
        {
            SqlConnection con = new SqlConnection();
            bool results = false;

            try
            {
                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();
                
                SqlParameter parm = new SqlParameter();
                int recordsAffected = 0;

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.Connection = con;

                cmd.CommandText = "usp_PFU_CDRT_UpSert";

                parm = new SqlParameter("@ReferralID", ReferralID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@CDRTStatus", CDRTStatus);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@MIResponseToReopen", MIResponseToReopen);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@CDRTNotificationDate", CDRTNotificationDate);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@MIReopenResponseDate", MIReopenResponseDate);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@CDRTResolutionDate", CDRTResolutionDate);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@UserID", UserID);
                cmd.Parameters.Add(parm);

                recordsAffected = cmd.ExecuteNonQuery();

                if (recordsAffected > 0)
                {
                    results = true;

                }
                
                return results;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ReferralID"></param>
        /// <param name="CommentText"></param>
        /// <param name="CommentTypeID"></param>
        /// <param name="CommentCategoryID"></param>
        /// <param name="UserID"></param>
        /// <returns></returns>
        internal bool PFU_ClosingComment_Insert(int ReferralID, 
                                             string CommentText,
                                                int CommentTypeID,
                                                int CommentCategoryID,
                                                int UserID)
        {
            SqlConnection con = new SqlConnection();
            bool results = false;

            try
            {
                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlParameter parm = new SqlParameter();
                int recordsAffected;

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.Connection = con;
                cmd.CommandText = "usptblPFU_Comment_Insert";

                parm = new SqlParameter("@ReferralID", ReferralID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@CommentText", CommentText);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@CommentCategoryID", CommentCategoryID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@CommentTypeID", CommentTypeID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@CommentFollowUpDate", DateTime.Parse("1/1/1900"));
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@Completed", false);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@MarkedForDelete", false);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@EnteredDate", DateTime.Now);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@EnteredByUser", UserID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@LastUpdateDate", DateTime.Now);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@LastUpdateUser", UserID);
                cmd.Parameters.Add(parm);

                recordsAffected = cmd.ExecuteNonQuery();

                if (recordsAffected > 0)
                {
                    results = true;

                }

                return results;

            }

            catch (Exception ex)
            {
                throw ex;

            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ReferralID"></param>
        /// <param name="ClaimStatusID"></param>
        /// <param name="UserID"></param>
        /// <param name="ClosingDate"></param>
        /// <returns></returns>
        internal bool PFU_CloseReferral(int ReferralID,
                                        int ClaimStatusID,
                                        int UserID,
                                   DateTime ClosingDate)
        {
            SqlConnection con = new SqlConnection();
            bool results = false;

            try
            {
                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlParameter parm = new SqlParameter();
                int recordsAffected = 0;

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.Connection = con;

                cmd.CommandText = "usp_PFU_CloseReferral";

                parm = new SqlParameter("@ReferralID", ReferralID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@ClaimStatusID", ClaimStatusID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@UserID", UserID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@ClosingDate", ClosingDate);
                cmd.Parameters.Add(parm);

                recordsAffected = cmd.ExecuteNonQuery();

                if (recordsAffected > 0)
                {
                    results = true;

                }

                return results;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ReferralID"></param>
        /// <param name="SettlementTypeID"></param>
        /// <param name="SettlementProceedsAmount"></param>
        /// <param name="SettlementReceivedDate"></param>
        /// <param name="UserID"></param>
        /// <returns></returns>
        internal bool PFU_PaymentReceived_UpSert(int ReferralID,
                                                 int SettlementTypeID,
                                             decimal SettlementProceedsAmount,
                                            DateTime SettlementReceivedDate,
                                                 int UserID)
        {
            SqlConnection con = new SqlConnection();
            bool results = false;

            try
            {
                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlParameter parm = new SqlParameter();
                int recordsAffected = 0;

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.Connection = con;

                cmd.CommandText = "usp_PFU_PaymentReceived_UpSert";

                parm = new SqlParameter("@ReferralID", ReferralID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@SettlementTypeID", SettlementTypeID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@SettlementProceedsAmount", SettlementProceedsAmount);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@SettlementReceivedDate", SettlementReceivedDate);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@UserID", UserID);
                cmd.Parameters.Add(parm);

                recordsAffected = cmd.ExecuteNonQuery();

                if (recordsAffected > 0)
                {
                    results = true;

                }

                return results;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        #endregion

        /*31043
        #region "Imports - Investor Tracking"
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="loanNumber"></param>
        /// <param name="clientID"></param>
        /// <param name="claimFormID"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal int GetInvestorTrackingLoanID_ByLoanNumber(string loanNumber, int clientID, int claimFormID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                int LoanID = 0;

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_InvTrk_LoanID_Select";

                SqlParameter parm = new SqlParameter("@LoanNumber", loanNumber);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@ClientID", clientID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@FormID", claimFormID);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;

                LoanID = int.Parse(cmd.ExecuteScalar().ToString());

                return LoanID;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="LoanNumber"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable InvestorTracking_GetExistingOpenClaimTypes(string LoanNumber, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable();

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                if (con.State == ConnectionState.Open)
                {
                    SqlCommand cmd = new SqlCommand();
                    SqlParameter prm = new SqlParameter();

                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "uspInvestorTracking_Import_ClaimsByLoanNumber";
                    cmd.Connection = con;

                    prm = new SqlParameter("@LoanNumber", LoanNumber);
                    cmd.Parameters.Add(prm);

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        dt.Columns.Add("LoanNumber", typeof(string));
                        dt.Columns.Add("ClaimType", typeof(string));

                        while (reader.Read())
                        {
                            DataRow dr = dt.NewRow();

                            dr["LoanNumber"] = reader["LoanNumber"].ToString().Length == 0 ? "" : reader["LoanNumber"].ToString();
                            dr["ClaimType"] = reader["ClaimType"].ToString().Length == 0 ? "" : reader["ClaimType"].ToString();

                            dt.Rows.Add(dr);
                        }

                    }

                }

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable InvestorTracking_GetStates_Data(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }
            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("Reports");
                DataColumn dc = new DataColumn();

                dc = new DataColumn();
                dc.ColumnName = "StateID";
                dc.DataType = typeof(int);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "StateName";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "StateAbbreviation";
                dc.DataType = typeof(string);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "Submit104DC_OnInitial";
                dc.DataType = typeof(bool);
                dt.Columns.Add(dc);

                dc = new DataColumn();
                dc.ColumnName = "DateEntered";
                dc.DataType = typeof(DateTime);
                dt.Columns.Add(dc);

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usptbllkp_States_Get";
                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["StateID"] = int.Parse(dr["StateID"].ToString().Length == 0 ? "0" : dr["StateID"].ToString());
                    row["StateName"] = dr["StateName"].ToString().Length == 0 ? "" : dr["StateName"].ToString();
                    row["StateAbbreviation"] = dr["StateAbbreviation"].ToString().Length == 0 ? "" : dr["StateAbbreviation"].ToString();
                    row["Submit104DC_OnInitial"] = bool.Parse(dr["Submit104DC_OnInitial"].ToString().Length == 0 ? "False" : dr["Submit104DC_OnInitial"].ToString());
                    row["DateEntered"] = DateTime.Parse(dr["DateEntered"].ToString().Length == 0 ? "1/1/1900" : dr["DateEntered"].ToString());

                    dt.Rows.Add(row);

                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw (ex);
            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal int InvestorTracking_Import_Claim_Insert(DataTable dt, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {

                int ClaimID = 0;

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                if (con.State == ConnectionState.Open)
                {
                    SqlCommand cmd = new SqlCommand();
                    SqlParameter prm = new SqlParameter();

                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "usp_InvTrk_Import_Claim_Insert";

                    prm = new SqlParameter("@LoanID", int.Parse(dt.Rows[0]["LoanID"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimType", int.Parse(dt.Rows[0]["ClaimType"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimDueDate", DateTime.Parse(dt.Rows[0]["ClaimDueDate"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimAmount", decimal.Parse(dt.Rows[0]["ClaimAmount"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@NoBill", bool.Parse(dt.Rows[0]["NoBill"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@NoClaimSubmitted", bool.Parse(dt.Rows[0]["NoClaimSubmitted"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimPerfectionDate", DateTime.Parse(dt.Rows[0]["ClaimPerfectionDate"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimPaidDate", DateTime.Parse(dt.Rows[0]["ClaimPaidDate"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimPaidAmount", decimal.Parse(dt.Rows[0]["ClaimPaidAmount"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimClosed", bool.Parse(dt.Rows[0]["ClaimClosed"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimClosedDate", DateTime.Parse(dt.Rows[0]["ClaimClosedDate"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClaimClosedUser", int.Parse(dt.Rows[0]["ClaimClosedUser"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@DateEntered", DateTime.Parse(dt.Rows[0]["DateEntered"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@EnteredByUser", int.Parse(dt.Rows[0]["EnteredByUser"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LastUpdateDate", DateTime.Parse(dt.Rows[0]["LastUpdateDate"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LastUpdateUser", int.Parse(dt.Rows[0]["LastUpdateUser"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ReferralDate", DateTime.Parse(dt.Rows[0]["ReferralDate"].ToString()));
                    cmd.Parameters.Add(prm);

                    cmd.Connection = con;

                    ClaimID = int.Parse(cmd.ExecuteScalar().ToString());

                }

                return ClaimID;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal int InvestorTracking_Import_InitialWorkFlow_Insert(DataTable dt, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {

                int WorkFlowID = 0;

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                if (con.State == ConnectionState.Open)
                {
                    SqlCommand cmd = new SqlCommand();
                    SqlParameter prm = new SqlParameter();

                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "usptblInvestorTracking_Workflow_InsertInitialRecord";

                    prm = new SqlParameter("@ClaimID", int.Parse(dt.Rows[0]["ClaimID"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@OpenUserID", int.Parse(dt.Rows[0]["OpenUser"].ToString()));
                    cmd.Parameters.Add(prm);

                    cmd.Connection = con;

                    WorkFlowID = cmd.ExecuteNonQuery();

                }

                return WorkFlowID;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }


        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal int InvestorTracking_Import_Loan_Insert(DataTable dt, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {

                int LoanID = 0;

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                if (con.State == ConnectionState.Open)
                {
                    SqlCommand cmd = new SqlCommand();
                    SqlParameter prm = new SqlParameter();

                    cmd.Connection = con;
                    cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "usp_InvTrk_Loan_Insert";

                    prm = new SqlParameter("@LoanNumber", dt.Rows[0]["LoanNumber"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ClientID", int.Parse(dt.Rows[0]["ClientID"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PropertyAddress", dt.Rows[0]["PropertyAddress"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PropertyCity", dt.Rows[0]["PropertyCity"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PropertyState", dt.Rows[0]["PropertyState"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PropertyZip", dt.Rows[0]["PropertyZip"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ServicerNumber", dt.Rows[0]["ServicerNumber"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ServicerName", dt.Rows[0]["ServicerName"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ServicerAddress", dt.Rows[0]["ServicerAddress"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ServicerCity", dt.Rows[0]["ServicerCity"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ServicerState", dt.Rows[0]["ServicerState"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ServicerZip", dt.Rows[0]["ServicerZip"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InternalFormID", int.Parse(dt.Rows[0]["InternalFormID"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorID", dt.Rows[0]["InvestorID"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorName", dt.Rows[0]["InvestorName"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@MICompanyID", int.Parse(dt.Rows[0]["MICompanyID"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@MIGuarantyNumber", dt.Rows[0]["MIGuarantyNumber"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@BorrowerFirstName", dt.Rows[0]["BorrowerFirstName"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@BorrowerLastName", dt.Rows[0]["BorrowerLastName"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@InvestorLoanNumber", dt.Rows[0]["InvestorLoanNumber"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ReferDateToMI", DateTime.Parse(dt.Rows[0]["ReferDateToMI"].ToString().Length == 0 ? "1/1/1900" : dt.Rows[0]["ReferDateToMI"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PreForeclosureSettlementDate", DateTime.Parse(dt.Rows[0]["PreForeclosureSettlementDate"].ToString().Length == 0 ? "1/1/1900" : dt.Rows[0]["PreForeclosureSettlementDate"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@DeedInLeuRecordDate", DateTime.Parse(dt.Rows[0]["DeedInLeuRecordDate"].ToString().Length == 0 ? "1/1/1900" : dt.Rows[0]["DeedInLeuRecordDate"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ForeClosureDate", DateTime.Parse(dt.Rows[0]["ForeClosureDate"].ToString().Length == 0 ? "1/1/1900" : dt.Rows[0]["ForeClosureDate"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ForeclosureSaleDate", DateTime.Parse(dt.Rows[0]["ForeclosureSaleDate"].ToString().Length == 0 ? "1/1/1900" : dt.Rows[0]["ForeclosureSaleDate"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@REOSaleDate", DateTime.Parse(dt.Rows[0]["REOSaleDate"].ToString().Length == 0 ? "1/1/1900" : dt.Rows[0]["REOSaleDate"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@RRCDate", DateTime.Parse(dt.Rows[0]["RRCDate"].ToString().Length == 0 ? "1/1/1900" : dt.Rows[0]["RRCDate"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@FHACaseNumber", dt.Rows[0]["FHACaseNumber"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@MICertNumber", dt.Rows[0]["MICertNumber"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@MIFiledDate", DateTime.Parse(dt.Rows[0]["MIFiledDate"].ToString().Length == 0 ? "1/1/1900" : dt.Rows[0]["MIFiledDate"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PoolCompany", dt.Rows[0]["PoolCompany"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PoolCertNumber", dt.Rows[0]["PoolCertNumber"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PoolFiledDate", DateTime.Parse(dt.Rows[0]["PoolFiledDate"].ToString().Length == 0 ? "1/1/1900" : dt.Rows[0]["PoolFiledDate"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@ThirdPartySaleDate", DateTime.Parse(dt.Rows[0]["ThirdPartySaleDate"].ToString().Length == 0 ? "1/1/1900" : dt.Rows[0]["ThirdPartySaleDate"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@AttorneyName", dt.Rows[0]["AttorneyName"].ToString());
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LastUpdateDate", DateTime.Parse(dt.Rows[0]["LastUpdateDate"].ToString().Length == 0 ? "1/1/1900" : dt.Rows[0]["LastUpdateDate"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@DateEntered", DateTime.Parse(dt.Rows[0]["DateEntered"].ToString().Length == 0 ? "1/1/1900" : dt.Rows[0]["DateEntered"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@EnteredByUser", int.Parse(dt.Rows[0]["EnteredByUser"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@LastUpdateUser", int.Parse(dt.Rows[0]["LastUpdateUser"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@PCCDate", DateTime.Parse(dt.Rows[0]["PCCDate"].ToString().Length == 0 ? "1/1/1900" : dt.Rows[0]["PCCDate"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@GADate", DateTime.Parse(dt.Rows[0]["GADate"].ToString().Length == 0 ? "1/1/1900" : dt.Rows[0]["GADate"].ToString()));
                    cmd.Parameters.Add(prm);
                    prm = new SqlParameter("@CMaxClientID", dt.Rows[0]["CMaxClientID"].ToString());
                    cmd.Parameters.Add(prm);

                    LoanID = int.Parse(cmd.ExecuteScalar().ToString());

                }

                return LoanID;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="StateAbbrev"></param>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal bool InvestorTracking_IsState_104DCOnInitial(string StateAbbrev, Settings settings)
        {
            try
            {
                bool response = false;

                DataTable States = InvestorTracking_GetStates_Data(settings);
                DataView dv = new DataView();
                dv.Table = States;
                dv.RowFilter = ("StateAbbreviation = '" + StateAbbrev + "'");

                if (dv.Count == 1)
                {
                    response = bool.Parse(dv[0]["Submit104DC_OnInitial"].ToString());

                }

                return response;
            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        #endregion
        */

        #region "Reporting"

        #region "Common Reporting"
        #endregion

        #region "Claims 332 Reporting"
        #endregion

        #region "Investor Tracking Reporting"
        #endregion

        #region "FNMA PFU Reporting"
        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable FNMA_PFU_Missing_Document_Escalation_Report(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable("MissingDocs");

                dt.Columns.Add("REO_ID", typeof(string));
                dt.Columns.Add("FNMALoanNumber", typeof(string));
                dt.Columns.Add("ReferralType", typeof(string));
                dt.Columns.Add("EnteredByUserName", typeof(string));
                dt.Columns.Add("EnteredDate", typeof(DateTime));
                dt.Columns.Add("ServicerName", typeof(string));
                dt.Columns.Add("MICompany", typeof(string));
                dt.Columns.Add("CertificateNumber", typeof(string));
                dt.Columns.Add("DocumentName", typeof(string));
                dt.Columns.Add("Comment", typeof(string));
                dt.Columns.Add("Aging", typeof(int));

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_PFU_Report_MissingDocumentEscalation";

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["REO_ID"] = dr["REO_ID"].ToString();
                    row["FNMALoanNumber"] = dr["FNMALoanNumber"].ToString();
                    row["ReferralType"] = dr["ReferralType"].ToString();
                    row["EnteredByUserName"] = dr["UserName"].ToString();
                    row["EnteredDate"] = DateTime.Parse(dr["EnteredDate"].ToString().Length == 0 ? "1/1/1900" : dr["EnteredDate"].ToString());
                    row["ServicerName"] = dr["ServicerName"].ToString();
                    row["MICompany"] = dr["MICompanyName"].ToString();
                    row["CertificateNumber"] = dr["MiCertificateNumber"].ToString();
                    row["DocumentName"] = dr["DocumentName"].ToString();
                    row["Comment"] = dr["Comment"].ToString();
                    row["Aging"] = int.Parse(dr["Aging"].ToString().Length == 0 ? "0" : dr["Aging"].ToString());

                    dt.Rows.Add(row);
                }

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <param name="ReferralTypeID"></param>
        /// <returns></returns>
        internal DataTable FNMA_PFU_MISettledLoanNotClosed_Report(Settings settings, int ReferralTypeID)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();
            }

            catch (Exception e)
            {
                throw e;
            }

            try
            {
                DataTable dt = new DataTable("Referrals");
                DataColumn dc = new DataColumn();


                dt.Columns.Add("REO_ID", typeof(string));
                dt.Columns.Add("FNMALoanNumber", typeof(string));
                dt.Columns.Add("SettlementProceedsAmount", typeof(string));
                dt.Columns.Add("MISettlementDate", typeof(DateTime));
                dt.Columns.Add("MISettlementDateAging", typeof(int));
                dt.Columns.Add("ReferralType", typeof(string));


                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;

                cmd.CommandText = "usprpt_PFU_MISettledLoanNotClosed";

                SqlParameter parm = new SqlParameter();
                parm = new SqlParameter("@ReferralTypeID", ReferralTypeID);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;

                decimal decimal2String;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();

                    row["REO_ID"] = dr["REO_ID"].ToString();
                    row["FNMALoanNumber"] = dr["FNMALoanNumber"].ToString();

                    decimal2String = decimal.Parse(dr["SettlementProceedsAmount"].ToString().Length == 0 ? "0" : dr["SettlementProceedsAmount"].ToString());
                    row["SettlementProceedsAmount"] = string.Format("{0:c}", decimal2String);

                    row["MISettlementDate"] = DateTime.Parse(dr["MISettlementDate"].ToString().Length == 0 ? "1/1/1900" : dr["MISettlementDate"].ToString());
                    row["MISettlementDateAging"] = int.Parse(dr["MISettlementDateAging"].ToString().Length == 0 ? "0" : dr["MISettlementDateAging"].ToString());
                    row["ReferralType"] = dr["ReferralType"].ToString();

                    dt.Rows.Add(row);
                }

                dt.AcceptChanges();
                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        #endregion

        #endregion

        #region "Security"
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="EncryptedPW"></param>
        /// <returns></returns>
        internal DataTable ClaimsManagement_ConfirmLoginUser(string id, string EncryptedPW)
        {
            SqlConnection cnn = new SqlConnection();

            try
            {
                cnn.ConnectionString = _settings.GetConnectionString("ClaimsManagement");

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "uspSecurity_ConfirmLogin";
                SqlParameter prm = new SqlParameter("@LoginID", id);
                cmd.Parameters.Add(prm);

                prm = new SqlParameter("@PW", EncryptedPW);
                cmd.Parameters.Add(prm);

                cnn.Open();

                cmd.Connection = cnn;
                DataTable dt = new DataTable("UserDetails");
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Columns.Add("id", typeof(int));
                    dt.Columns.Add("UserID", typeof(string));
                    dt.Columns.Add("UserName", typeof(string));
                    dt.Columns.Add("SecurityGroup", typeof(string));
                    dt.Columns.Add("SecurityLevel", typeof(int));
                    dt.Columns.Add("LastPWChange", typeof(DateTime));

                    while (reader.Read())
                    {
                        DataRow dr = dt.NewRow();
                        dr["id"] = reader["id"];
                        dr["UserID"] = reader["UserID"];
                        dr["UserName"] = reader["UserName"];
                        dr["SecurityGroup"] = reader["SecurityGroup"];
                        dr["SecurityLevel"] = reader["SecurityLevel"];
                        dr["LastPWChange"] = DateTime.Parse(reader["LastPWChange"].ToString().Length == 0 ? "1/1/1900" : reader["LastPWChange"].ToString());

                        dt.Rows.Add(dr);
                    }
                }
                reader.Close();
                reader.Dispose();

                cnn.Close();
                cnn.Dispose();

                return dt;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                if (cnn.State != ConnectionState.Closed)
                {
                    cnn.Close();
                    cnn.Dispose();
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <param name="UserName"></param>
        /// <param name="UserID"></param>
        /// <param name="MachineName"></param>
        /// <param name="AppVersion"></param>
        /// <param name="LoginSuccessful"></param>
        /// <returns></returns>
        internal bool InsertLoginActivity(string UserName, string UserID, string MachineName, string AppVersion, bool LoginSuccessful)
        {
            SqlConnection con = new SqlConnection();
            bool success = false;

            try
            {
                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");
                con.Open();

            }
            
            catch (Exception e)
            {
                throw e;

            }

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_tbllog_LoginActivity";
                SqlParameter parm = new SqlParameter("@UserName", UserName);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@UserID", UserID);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@MachineName", MachineName);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@AppVersion", AppVersion);
                cmd.Parameters.Add(parm);
                parm = new SqlParameter("@LoginSuccessful", LoginSuccessful);
                cmd.Parameters.Add(parm);

                cmd.Connection = con;

                int rowsAffected = cmd.ExecuteNonQuery();
                
                if (rowsAffected >= 1)
                {
                    success = true;
                }

                return success;

            }
            
            catch (Exception e)
            {
                throw e;

            }
            
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();

                }

            }

        }

        internal DataTable GetLoginActivity(string UserID)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable("LogonActivity");
                dt.Columns.Add("id", typeof(int));
                dt.Columns.Add("UserName", typeof(string));
                dt.Columns.Add("UserID", typeof(string));
                dt.Columns.Add("MachineName", typeof(string));
                dt.Columns.Add("AppVersion", typeof(string));
                dt.Columns.Add("LoginDateTime", typeof(DateTime));
                dt.Columns.Add("LoginSuccessful", typeof(bool));
                
                con.ConnectionString = _settings.GetConnectionString("ClaimsManagement");

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_CNTL_CMSUser_GetLoginActivity";
                SqlParameter prm = new SqlParameter("@UserID", UserID);
                cmd.Parameters.Add(prm);

                con.Open();
                cmd.Connection = con;
                
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    DataRow dr = dt.NewRow();

                    dr["id"] = int.Parse(reader["id"].ToString().Length == 0 ? "0" : reader["id"].ToString());
                    dr["UserName"] = reader["UserName"].ToString();
                    dr["UserID"] = reader["UserID"].ToString();
                    dr["MachineName"] = reader["MachineName"].ToString();
                    dr["AppVersion"] = reader["AppVersion"].ToString();
                    dr["LoginDateTime"] = DateTime.Parse(reader["LoginDateTime"].ToString().Length == 0 ? "1/1/1900" : reader["LoginDateTime"].ToString());
                    dr["LoginSuccessful"] = bool.Parse(reader["LoginSuccessful"].ToString().Length == 0 ? "false" : reader["LoginSuccessful"].ToString());
                    
                    dt.Rows.Add(dr);

                }

                reader.Close();
                reader.Dispose();

                con.Close();
                con.Dispose();

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }
            
            finally
            {
                if (con.State != ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }

        }

        #endregion

        #region "FHA"

        #endregion

        #region "RecSheet Clone"
        internal int RecSheetItemsCount(int ClaimID, Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {

                //Get eligible items
                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                //SqlCommand cmd1 = new SqlCommand();
                cmd = new SqlCommand();
                SqlParameter prm = new SqlParameter();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_InvTrk_RecSheetItemCount";
                cmd.Connection = con;
                prm = new SqlParameter("@ClaimID", ClaimID);
                cmd.Parameters.Add(prm);
                return int.Parse(cmd.ExecuteScalar().ToString());
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
        #endregion

    }
}
