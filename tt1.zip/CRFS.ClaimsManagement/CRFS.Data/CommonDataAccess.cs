﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace CRFS.Data
{
    class CommonDataAccess
    {
        CRFS.Data.Settings _settings;

        /// <summary>
        /// 
        /// </summary>
        internal CommonDataAccess()
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        internal CommonDataAccess(CRFS.Data.Settings settings)
        {
            _settings = settings;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable Clients_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable("Clients");

                dt.Columns.Add("id", typeof(int));
                dt.Columns.Add("ClientName", typeof(string));
                dt.Columns.Add("ClientAbbreviation", typeof(string));
                dt.Columns.Add("DisplayName", typeof(string));
                dt.Columns.Add("FormID", typeof(int));

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_COMM_Clients_SelectWithFormID";

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();
                    row["id"] = (int)dr["id"];
                    row["ClientName"] = dr["CLientName"].ToString();
                    row["ClientAbbreviation"] = dr["ClientAbbreviation"].ToString();
                    row["DisplayName"] = dr["DisplayName"].ToString();
                    row["FormID"] = (int)dr["FormID"];

                    dt.Rows.Add(row);

                }

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally 
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable ClaimGroups_Get(Settings settings)
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable("ClaimTypeGroups");

                dt.Columns.Add("ClaimGroupClaimTypeID", typeof(int));
                dt.Columns.Add("ClaimGroupID", typeof(int));
                dt.Columns.Add("ClaimGroupName", typeof(string));
                dt.Columns.Add("ClaimTypeID", typeof(int));
                dt.Columns.Add("ClaimType", typeof(string));

                con.ConnectionString = settings.GetConnectionString("ClaimsManagement");
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandTimeout = Configuration.CommandTimeouts_General_ClaimsManagementSQLDatabase;
                cmd.CommandText = "usp_InvTrk_ClaimGroup_Select";

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();
                    row["ClaimGroupClaimTypeID"] = (int)dr["ClaimGroupClaimTypeID"];
                    row["ClaimGroupID"] = (int)dr["ClaimGroupID"];
                    row["ClaimGroupName"] = dr["ClaimGroupName"];
                    row["ClaimTypeID"] = (int)dr["ClaimTypeID"];
                    row["ClaimType"] = dr["ClaimType"];

                    dt.Rows.Add(row);

                }

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

    }
}
