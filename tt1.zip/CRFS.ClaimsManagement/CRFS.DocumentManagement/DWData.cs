﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using System.Xml;
using System.Text.RegularExpressions;
//using DocuWare;
//using DocuWare.Gapi;
//using DocuWare.Gapi.Client;
//using DocuWare.Gapi.FileCabinet;
//using DocuWare.Gapi.Command;
//using DocuWare.Gapi.Command.FileCabinet;
//using DocuWare.Gapi.Common;
//using DocuWare.Gapi.Document;

namespace CRFS.DocumentManagement
{
    /*
    public class DWData
    {
        internal string _appMode; 
        internal CRFS.DocumentManagement.Settings _settings;
        internal IGapiClient dClient;
        internal IFileCabinet dCabinet;
        internal DataTable _CabinetList;
        internal IGapiList<IFileCabinetField> fieldList;
        internal DataTable _FieldList;
        internal IFileCabinetField dField;
        private Moss.Events.Events events = new Moss.Events.Events();
        internal DataTable _logs;
        private string _path = "";

        public enum DocuwareHeaderType
        {
            TextVar = 1,
            Date = 4

        }

        #region "Constructors"
        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        public DWData(string appMode)
        {
            _appMode = appMode;
            _settings = new CRFS.DocumentManagement.Settings(appMode);

            CRFS.DocumentManagement.dataFunctions df = new CRFS.DocumentManagement.dataFunctions(_appMode);
            _CabinetList = df.GetCabinetList();
            _logs = BuildLogTable();

        }

        #endregion

        #region "Exporter Utilities"

        /// <summary>
        /// 
        /// </summary>
        /// <param name="FileName"></param>
        /// <param name="ErrMsg"></param>
        private void AddLogRecord(string FileName, string ErrMsg)
        {
            try
            {
                DataRow row = _logs.NewRow();

                row["TimeStamp"] = DateTime.Now;
                row["FileName"] = FileName;
                row["ErrorMessage"] = ErrMsg;

                _logs.Rows.Add(row);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private DataTable BuildLogTable()
        {
            try
            {
                DataTable dt = new DataTable("LogRecords");

                dt.Columns.Add("TimeStamp", typeof(DateTime));
                dt.Columns.Add("FileName", typeof(string));
                dt.Columns.Add("ErrorMessage", typeof(string));

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        #endregion

        #region "General Docuware Methods"

        /// <summary>
        /// 
        /// </summary>
        /// <param name="HeaderFileName"></param>
        /// <param name="UploadFileName"></param>
        /// <param name="UploadPath"></param>
        /// <param name="UploadSize"></param>
        /// <param name="dtFields"></param>
        public void CreateNewDocuwareHeaderFile(string HeaderFileName, string UploadFileName, string UploadPath, int UploadSize, DataTable dtFields)
        {
            try
            {
                //Most of this is a skeleton template of an XML Document fragment - the bare bones of what is needed to load a document into docuware.
                //A few values and attributes are set according to document specifics.  These specifics must be passed into this routine as variables

                XmlDocument doc = new XmlDocument();

                XmlElement root = doc.CreateElement("DWDocument");
                //The root node needs the name of the header file
                root.SetAttribute("DW5BasketFileName", HeaderFileName);
                doc.AppendChild(root);

                XmlElement FileInfos = doc.CreateElement("FileInfos");

                XmlElement ImageInfos = doc.CreateElement("ImageInfos");

                XmlElement ImageInfo = doc.CreateElement("ImageInfo");
                ImageInfo.SetAttribute("id", "0,0,0");
                ImageInfo.SetAttribute("nPages", "0");

                XmlElement FileInfo = doc.CreateElement("FileInfo");
                //The file to be uploaded must have the path prepended
                FileInfo.SetAttribute("fileName", UploadPath + UploadFileName);

                //A seperate attribute for the file name is set.  This is just the base filename.  ??This is the docuware displayed name for the document??
                FileInfo.SetAttribute("dwFileName", UploadFileName);
                FileInfo.SetAttribute("type", "normal");

                //Prior to upload, the size of the file, in bytes must be determined.
                FileInfo.SetAttribute("length", UploadSize.ToString());

                ImageInfo.AppendChild(FileInfo);
                ImageInfos.AppendChild(ImageInfo);
                FileInfos.AppendChild(ImageInfos);
                root.AppendChild(FileInfos);

                XmlElement Section = doc.CreateElement("Section");

                //Docuware does nothing without a Guid for the file.  Hopefully we can generate one and it will work.
                Section.SetAttribute("dwguid", Guid.NewGuid().ToString());
                Section.SetAttribute("number", "0");
                Section.SetAttribute("startPage", "0");

                XmlElement MetaData = doc.CreateElement("Metadata");
                MetaData.SetAttribute("version", "0");

                XmlElement SystemProperties = doc.CreateElement("SystemProperties");

                XmlElement Flags = doc.CreateElement("Flags");
                Flags.InnerText = "2";

                SystemProperties.AppendChild(Flags);
                MetaData.AppendChild(SystemProperties);

                XmlElement FieldProperties = doc.CreateElement("FieldProperties");

                if (dtFields.Rows.Count > 0)
                {
                    //Field Property elements created and appended here from the supplied variable table
                    //We can have a varying quantity and type
                    for (int i = 0; i < dtFields.Rows.Count; i++)
                    {
                        if (dtFields.Rows[i]["fieldValue"].ToString().Length != 0)
                        {
                            XmlElement elementType = doc.CreateElement(dtFields.Rows[i]["fieldType"].ToString());

                            if (dtFields.Rows[i]["fieldLength"].ToString().Length > 0)
                            {
                                if (int.Parse(dtFields.Rows[i]["fieldLength"].ToString()) > 0)
                                {
                                    elementType.SetAttribute("length", dtFields.Rows[i]["fieldLength"].ToString());

                                }
                                
                            }

                            elementType.SetAttribute("field", dtFields.Rows[i]["fieldName"].ToString());
                            elementType.SetAttribute("id", dtFields.Rows[i]["fieldIndex"].ToString());
                            elementType.InnerText = dtFields.Rows[i]["fieldValue"].ToString();

                            FieldProperties.AppendChild(elementType);
                        
                        }

                    }
                }

                MetaData.AppendChild(FieldProperties);

                XmlElement Page = doc.CreateElement("Page");
                Page.SetAttribute("number", "0");

                XmlElement Rendition = doc.CreateElement("Rendition");
                Rendition.SetAttribute("type", "original");

                XmlElement Content = doc.CreateElement("Content");
                Content.SetAttribute("id", "0,0,0");
                Content.SetAttribute("pageNumberInFile", "0");

                XmlElement Annotation = doc.CreateElement("Annotation");
                Annotation.SetAttribute("UpdateStatus", "Inserted");

                //Setting a null value here that Docuware should ignore and force the generation of 
                //the Annotation closing tag in this header file
                Annotation.InnerText = "";

                Rendition.AppendChild(Content);
                Rendition.AppendChild(Annotation);
                Page.AppendChild(Rendition);

                Section.AppendChild(MetaData);
                Section.AppendChild(Page);

                root.AppendChild(Section);

                doc.Normalize(); //If we don't normalize, a doc.Save strips out first 3 bytes???

                doc.Save(UploadPath + HeaderFileName);

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="path"></param>
        /// <param name="events"></param>
        public void CleanupDocuwareHeaderFiles(string path, Moss.Events.Events events)
        {
            try
            {
                System.IO.DirectoryInfo di = new System.IO.DirectoryInfo(path);
                System.IO.FileInfo[] files = di.GetFiles("*.001");
                foreach (System.IO.FileInfo file in files)
                {
                    file.Delete();
                }

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="path"></param>
        /// <param name="events"></param>
        public void CleanupPDFDocumentFiles(string path)
        {
            try
            {
                System.IO.DirectoryInfo di = new System.IO.DirectoryInfo(path);
                System.IO.FileInfo[] files = di.GetFiles("*.pdf");
                foreach (System.IO.FileInfo file in files)
                {
                    file.Delete();

                }

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public DataTable GetDocuwareHeaderFiles(string path)
        {
            try
            {
                
                System.IO.DirectoryInfo di = new System.IO.DirectoryInfo(path);
                System.IO.FileInfo[] files = di.GetFiles("*.001");
                DataTable dt = new DataTable();
                dt.Columns.Add("HeaderName",typeof(string));

                int i = 0;

                foreach (System.IO.FileInfo file in files)
                {
                    DataRow dr = dt.NewRow();
                    dr["HeaderName"] = file.FullName;
                    dt.Rows.Add(dr);

                    i += 1;

                }

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="uid"></param>
        /// <param name="pw"></param>
        /// <returns></returns>
        public bool LoginToDocuware(string uid, string pw)
        {

            try
            {
                bool LoginStatus = false;
                dataFunctions df = new dataFunctions(_appMode);
                //df.setDocuwareAuthServer();
          

                //string testing = "Name=""Standard AS"" Server=""VMA21.crfservices.com"" Port=""9000"" Organization=""Claims Recovery Financial Services LLC"" Local=""false"" Active=""true"" System=""Central system"";


                //Override the config file Authorization Server setting based on the mode the program is launched in
                //string[] ConnStringItems = _settings.GetConnectionString("DocuwareData").Split(',');
                //IConnectionSettings DWConnSetting = Gapi.newConnectionSetting(ConnStringItems[0], ConnStringItems[1], int.Parse(ConnStringItems[2]), ConnStringItems[3]);

                dClient = Gapi.newClient();
                // gk 20140224 try setting the connection settings without switching the docuware.gapi.dll.config file
                dClient.Options.ASConnectionSettings.Clear();
                switch (_appMode)
                {
                    case "Production":
                        //dClient.Options.ASConnectionSettings.Add(Gapi.newConnectionSetting("Standard AS", "PA07", 9000, "Claims Recovery Financial Services LLC"));
                        dClient.Options.ASConnectionSettings.Add(
                            Gapi.newConnectionSetting(
                                global::CRFS.DocumentManagement.Properties.Settings.Default.DWProdName, 
                                global::CRFS.DocumentManagement.Properties.Settings.Default.DWProdServer, 
                                global::CRFS.DocumentManagement.Properties.Settings.Default.DWProdPort, 
                                global::CRFS.DocumentManagement.Properties.Settings.Default.DWProdOrg)
                        );
                        break;

                    case "Testing":
                        //dClient.Options.ASConnectionSettings.Add(Gapi.newConnectionSetting("Testing AS", "VMA35.crfsservices.com", 9000, "Claims Recovery Financial Services LLC"));
                        dClient.Options.ASConnectionSettings.Add(
                            Gapi.newConnectionSetting(
                                global::CRFS.DocumentManagement.Properties.Settings.Default.DWTestName, 
                                global::CRFS.DocumentManagement.Properties.Settings.Default.DWTestServer, 
                                global::CRFS.DocumentManagement.Properties.Settings.Default.DWTestPort, 
                                global::CRFS.DocumentManagement.Properties.Settings.Default.DWTestOrg)
                        );
                        break;

                    case "Development":
                        //dClient.Options.ASConnectionSettings.Add(Gapi.newConnectionSetting("Testing AS", "VMA35.crfsservices.com", 9000, "Claims Recovery Financial Services LLC"));
                        dClient.Options.ASConnectionSettings.Add(
                            Gapi.newConnectionSetting(
                                global::CRFS.DocumentManagement.Properties.Settings.Default.DWDevName, 
                                global::CRFS.DocumentManagement.Properties.Settings.Default.DWDevServer, 
                                global::CRFS.DocumentManagement.Properties.Settings.Default.DWDevPort, 
                                global::CRFS.DocumentManagement.Properties.Settings.Default.DWDevOrg)
                        );
                        break;

                    default:
                        //Do nothing.  This should cause a login failure because the default settings file should have both
                        //AS server entries commented out.  We need the correct appmode to be used in order to log in.
                        break;
                }
                // end gk 20140224


                //dClient.Options.ASConnectionSettings.Clear(); //Remove the item(s) loaded from the config file
                //dClient.Options.ASConnectionSettings.Insert(0, DWConnSetting); //Insert the new ASConnection 
                //dClient.Options.ASConnectionSettings.ElementAt(1);

                //System.Threading.Thread.Sleep(60000);

                dClient.LoginDocuWareAuthentication(uid, pw);

                switch (dClient.ClientStatus)
                {
                    case GapiClientStatus.LoggedIn:
                        LoginStatus = true;
                        break;

                    default:
                        LoginStatus = false;
                        break;

                }
                
//                df.restoreDocuwareAuthServerSettings();
                
                return LoginStatus;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        public void LogoutOfDocuware()
        {
            try
            {
                dClient.Logout();

                // fb 2885 gk 20140702 don't dispose of objects if they haven't been created
                //Clean up the objects
                if (dCabinet != null)
                {
                    dCabinet.Dispose();
                }
                if (dClient != null)
                {
                    dClient.Dispose();
                }

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cabinetName"></param>
        public DataTable OpenFileCabinet(string cabinetName)
        {
            try
            {
                DataView dv = new DataView(_CabinetList);
                string CabinetGUID = "";
                _FieldList = new DataTable();

                dv.RowFilter = "name = '" + cabinetName + "'";

                if (dv.Count == 1)
                {
                    //Save a list of all the fileds and field metadata to a table for later use
                    //We may need GUIDs, indexes, database column names, and/or docuware "column" names
                    CabinetGUID = dv[0]["guid"].ToString();
                    dCabinet = dClient.Organization.GetFileCabinet(Guid.Parse(CabinetGUID));

                    _FieldList.Columns.Add("fieldName", typeof(string));  //The name of the field in the cabinet table in the SQL database
                    _FieldList.Columns.Add("DecimalPlaces", typeof(int));    //If this is a numeric type, then this will be the number of digits after the decimal point.  All other this will be 0
                    _FieldList.Columns.Add("DocuWareType", typeof(DocuWareType));  //An enumerated type in Docuware: Text (1), Numeric (2), Date (3), Keyword (4), and Memo (5)
                    _FieldList.Columns.Add("DotNetType", typeof(Type)); //.Net type: string, int, etc.
                    _FieldList.Columns.Add("FileCabinet", typeof(IFileCabinet)); //This is a file cabinet object, not terribly important because we aready have this
                    _FieldList.Columns.Add("Guid", typeof(Guid));  //The field Guid
                    _FieldList.Columns.Add("fieldIndex", typeof(int)); //The filed index value.  This is likely required to buid XML header files to store documents
                    _FieldList.Columns.Add("fieldLength", typeof(int));  //The length of the field
                    _FieldList.Columns.Add("displayName", typeof(string)); //Docuware (display) name of the field
                    _FieldList.Columns.Add("fieldType", typeof(string));
                    _FieldList.Columns.Add("fieldValue", typeof(string));

                    
                    fieldList = dCabinet.Fields;

                    foreach (IFileCabinetField field in fieldList)
                    {
                        DataRow row = _FieldList.NewRow(); 
                        
                        row["fieldName"] = field.DatabaseName;
                        row["DecimalPlaces"] = field.DecimalPlaces;
                        row["DocuWareType"] = field.DocuWareType;
                        row["DotNetType"] = field.DotNetType;
                        row["FileCabinet"] = field.FileCabinet;
                        row["Guid"] = field.Guid;
                        row["fieldIndex"] = field.Index;
                        row["fieldLength"] = field.Length;
                        row["displayName"] = field.Name;

                        switch (field.DocuWareType)
                        {
                            case DocuWareType.Text:
                                row["fieldType"] = "TextVar";
                                break;

                            case DocuWareType.Numeric:
                                break;

                            case DocuWareType.Memo:
                                break;

                            case DocuWareType.Date:
                                row["fieldType"] = "Date";
                                break;

                            case DocuWareType.Keyword:
                                break;

                            default:
                                break;

                        }

                        _FieldList.Rows.Add(row);

                    }


                    if (dCabinet.Name.Length == 0)
                    {
                        throw new Exception("File Cabinet was not opened - " + cabinetName);

                    }

                    else
                    {
                        return _FieldList;

                    }

                }
                else
                {
                    events.OnRaiseGeneralStatusUpdateEvent("File Cabinet not found - " + cabinetName);
                    throw new Exception("File Cabinet not found - " + cabinetName);

                }

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="clientToSearch"></param>
        /// <param name="docTypeToSearch"></param>
        /// <param name="processToSearch"></param>
        /// <param name="loannumberToSearch"></param>
        /// <returns></returns>
        public DataTable SearchFileCabinet(string clientToSearch = "%", string docTypeToSearch = "%", string processToSearch = "%", string loannumberToSearch = "%")
        {
            try
            {
                DataTable dt = new DataTable();
                
                IFileCabinetSimpleSearchCommand search = dCabinet.Commands.newSimpleSearch();
                
                //Evaluate whether optional paramaters were supplied, if so, add them as criteria
                if (clientToSearch != "%")
                {
                    search.AddCriterion(dCabinet.GetField("CLIENT_"), clientToSearch);
                
                }

                if (docTypeToSearch != "%")
                {
                    search.AddCriterion(dCabinet.GetField("DOCUMENT_TYPE"), docTypeToSearch);

                }

                if (processToSearch != "%")
                {
                    search.AddCriterion(dCabinet.GetField("PROCESS"), processToSearch);

                }

                if (loannumberToSearch != "%")
                {
                    search.AddCriterion(dCabinet.GetField("LOAN_NUMBER"), loannumberToSearch);

                }

                //Add all the user defined fields to the result set
                IGapiList<IFileCabinetField> fieldList = dCabinet.Fields;
                
                foreach (IFileCabinetField field in fieldList)
                {
                    search.AddResultField(dCabinet.GetField(field.DatabaseName.ToString()));

                }

                //Execute the document search
                IResultlist resultList = search.ExecuteEx();
                IResultlistBlock block = resultList.GetResults(0, resultList.ResultCount - 1);
                dt = block.ToDataTable();
                

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <param name="clientToSearch"></param>
        /// <param name="docTypeToSearch"></param>
        /// <param name="processToSearch"></param>
        /// <param name="loannumberToSearch"></param>
        /// <returns></returns>
        public DataTable SearchFileCabinetByDateRange(DateTime fromDate, DateTime toDate,string clientToSearch = "%", string docTypeToSearch = "%", string processToSearch = "%", string loannumberToSearch = "%")
        {
            try
            {
                DataTable dt = new DataTable();

                IFileCabinetSimpleSearchCommand search = dCabinet.Commands.newSimpleSearch();

                //search.AddExtendedSystemCriterion(SystemFields., ">= " + fromDate + " AND <= " + toDate);
                search.AddCriterion(dCabinet.GetField("UPLDDATE"), fromDate, toDate);

                //Evaluate whether optional paramaters were supplied, if so, add them as criteria
                if (clientToSearch != "%")
                {
                    search.AddCriterion(dCabinet.GetField("CLIENT_"), clientToSearch);

                }

                if (docTypeToSearch != "%")
                {
                    search.AddCriterion(dCabinet.GetField("DOCUMENT_TYPE"), docTypeToSearch);

                }

                if (processToSearch != "%")
                {
                    search.AddCriterion(dCabinet.GetField("PROCESS"), processToSearch);

                }

                if (loannumberToSearch != "%")
                {
                    search.AddCriterion(dCabinet.GetField("LOAN_NUMBER"), loannumberToSearch);

                }

                //Add all the user defined fields to the result set
                IGapiList<IFileCabinetField> fieldList = dCabinet.Fields;

                foreach (IFileCabinetField field in fieldList)
                {
                    search.AddResultField(dCabinet.GetField(field.DatabaseName.ToString()));

                }

                //Execute the document search
                IResultlist resultList = search.ExecuteEx();
                IResultlistBlock block = resultList.GetResults(0, resultList.ResultCount - 1);
                dt = block.ToDataTable();


                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="documentHeaders"></param>
        public void StoreDocuments(DataTable documentHeaders)
        {
            try
            {
                for (int i = 0; i < documentHeaders.Rows.Count; i++)
                {
                    IFileCabinetStorageCommand storage = dCabinet.Commands.newStorage();
                    storage.UnfiledDocument = dClient.GetDocument(documentHeaders.Rows[i]["HeaderName"].ToString());
                    storage.Execute();

                }

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        #endregion

        #region "Claims 332 specific Docuware Methods"

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="events"></param>
        public void RenameImagesForWellsFargoExport(DataTable dt, Moss.Events.Events events)
        {
            try
            {
                double nextTarget = .01;
                int rowCount = dt.Rows.Count;
                string logpath = "";

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (bool.Parse(dt.Rows[i]["ProcessImage"].ToString()) == true)
                    {
                        string borrowerName = dt.Rows[i]["BorrowerLastName"].ToString().Trim();
                        string loanNumber = dt.Rows[i]["LoanNumber"].ToString().Trim();
                        string investorCode = dt.Rows[i]["InvestorCode"].ToString().Trim();
                        string docType = dt.Rows[i]["DocumentType"].ToString().Trim();
                        string origFileName = dt.Rows[i]["FileName"].ToString().Trim();

                        int lastDot = origFileName.LastIndexOf('.');
                        string origExtn = origFileName.Substring(lastDot, origFileName.Length - lastDot);

                        if (borrowerName.Length > 0 && loanNumber.Length > 0 && investorCode.Length == 3 && origFileName.Length > 0)
                        {
                            //We have values for all items so go ahead with the rename
                            StringBuilder newFileName = new StringBuilder();
                            newFileName.Append("INV");
                            newFileName.Append(investorCode);
                            
                            //20121008 - TRS -  Ticket 12969.  Second issue arising from the move of Chase documents
                            //within docuware.  Metadata was changed so that all upper case values werer used.  Original code
                            //supplied by J.Moyer for block below used A) a case sensitive comparison and B) if, if else type construct
                            //Changed to use switch construct and force upper case comparisons.
                            //We may need to add something in the default case so that we don't just omit putting in a part of the file name. 
                            switch (docType.ToUpper())
                            {
                                case "332 CLAIM":
                                    newFileName.Append("_LOSS_");
                                    break;

                                case "332 SUPPLEMENTAL CLAIM":
                                    newFileName.Append("_TRAILING_LOSS_");
                                    break;

                                default:
                                    break;

                            }

                            newFileName.Append(loanNumber);
                            newFileName.Append("_");
                            newFileName.Append(borrowerName);
                            //newFileName.Append(".pdf");
                            newFileName.Append(origExtn);
                            //TODO:  deal with file conversion if not a PDF?

                            string fileName = newFileName.ToString();

                            System.IO.FileInfo fileToProcess = new System.IO.FileInfo(origFileName);
                            string origFilePath = fileToProcess.DirectoryName;

                            if (logpath.Length == 0)
                            {
                                logpath = origFilePath;

                            }

                            if (!System.IO.Directory.Exists(origFilePath + "\\Processed\\"))
                            {
                                System.IO.Directory.CreateDirectory(origFilePath + "\\Processed\\");
                            }


                            System.IO.FileInfo origfileToProcess = new System.IO.FileInfo(origFileName);

                            if (System.IO.File.Exists(origFilePath + "\\Processed\\" + newFileName))
                            {
                                //System.Windows.Forms.MessageBox.Show("A duplicate file is being generated, replacing " + newFileName + "\n\nThis will reduce the total file count.", "File is being replaced", System.Windows.Forms.MessageBoxButtons.OK);

                                AddLogRecord(origFilePath + "\\Processed\\" + newFileName, "A duplicate file is being generated, replacing " + newFileName + "\n\nThis will reduce the total file count.");

                                System.IO.FileInfo newFile = new System.IO.FileInfo(origFilePath + "\\Processed\\" + newFileName);
                                newFile.Delete();
                            }

                            fileToProcess.MoveTo(origFilePath + "\\Processed\\" + newFileName);

                            if (System.IO.File.Exists(origFilePath + "\\Processed\\" + newFileName))
                            {
                                origfileToProcess.Delete();
                            }
                        }
                        else
                        {
                            //Move the file to the error directory

                            //Rename the file so that we have a way of looking it up
                            //We have values for all items so go ahead with the rename
                            StringBuilder newFileName = new StringBuilder();

                            newFileName.Append("BadIndexValues_");
                            newFileName.Append(docType.Replace(' ', '_'));
                            newFileName.Append("_");
                            newFileName.Append(loanNumber);
                            newFileName.Append(".pdf");

                            string fileName = newFileName.ToString();

                            System.IO.FileInfo fileToProcess = new System.IO.FileInfo(origFileName);
                            string origFilePath = fileToProcess.DirectoryName;
                            if (!System.IO.Directory.Exists(origFilePath + "\\Errors\\"))
                            {
                                System.IO.Directory.CreateDirectory(origFilePath + "\\Errors\\");
                            }

                            System.IO.FileInfo origfileToProcess = new System.IO.FileInfo(origFileName);

                            if (System.IO.File.Exists(origFilePath + "\\Errors\\" + newFileName))
                            {
                                System.IO.FileInfo newFile = new System.IO.FileInfo(origFilePath + "\\Errors\\" + newFileName);
                                newFile.Delete();
                            }

                            fileToProcess.MoveTo(origFilePath + "\\Errors\\" + newFileName);

                            if (System.IO.File.Exists(origFilePath + "\\Errors\\" + newFileName))
                            {
                                origfileToProcess.Delete();
                            }
                        }
                    }
                    else
                    {
                        string loanNumber = dt.Rows[i]["LoanNumber"].ToString().Trim();
                        string docType = dt.Rows[i]["DocumentType"].ToString().Trim();
                        string origFileName = dt.Rows[i]["FileName"].ToString().Trim();

                        //Rename the file so that we have a way of looking it up
                        //We have values for all items so go ahead with the rename
                        StringBuilder newFileName = new StringBuilder();

                        newFileName.Append("NoIndexValues_");
                        newFileName.Append(docType.Replace(' ', '_'));
                        newFileName.Append("_");
                        newFileName.Append(loanNumber);
                        newFileName.Append(".pdf");

                        string fileName = newFileName.ToString();

                        System.IO.FileInfo fileToProcess = new System.IO.FileInfo(origFileName);
                        string origFilePath = fileToProcess.DirectoryName;
                        if (!System.IO.Directory.Exists(origFilePath + "\\Errors\\"))
                        {
                            System.IO.Directory.CreateDirectory(origFilePath + "\\Errors\\");
                        }

                        System.IO.FileInfo origfileToProcess = new System.IO.FileInfo(origFileName);

                        if (System.IO.File.Exists(origFilePath + "\\Errors\\" + newFileName))
                        {
                            System.IO.FileInfo newFile = new System.IO.FileInfo(origFilePath + "\\Errors\\" + newFileName);
                            newFile.Delete();
                        }

                        fileToProcess.MoveTo(origFilePath + "\\Errors\\" + newFileName);

                        if (System.IO.File.Exists(origFilePath + "\\Errors\\" + newFileName))
                        {
                            origfileToProcess.Delete();
                        }
                    }

                    if ((((double)i + 1) / (double)rowCount) >= nextTarget)
                    {
                        nextTarget += .01;
                        events.OnRaiseImportStatusUpdateEvent();
                    }
                }

                if (_logs.Rows.Count > 0)
                {
                    //Write a logfile
                    Moss.FileIOAccess.FileAccess fa = new Moss.FileIOAccess.FileAccess();
                    
                    DateTime FileTimeStamp = DateTime.Now;
                    
                    string logFileName = _path + "\\";
                    logFileName = logFileName + FileTimeStamp.Year.ToString().PadLeft(4);
                    logFileName = logFileName + FileTimeStamp.Month.ToString().PadLeft(2);
                    logFileName = logFileName + FileTimeStamp.Day.ToString().PadLeft(2);
                    logFileName = logFileName + "_" + FileTimeStamp.Hour.ToString().PadLeft(2);
                    logFileName = logFileName + FileTimeStamp.Minute.ToString().PadLeft(2);
                    logFileName = logFileName + FileTimeStamp.Second.ToString().PadLeft(2);
                    logFileName = logFileName + "duplicate_files_log.csv";

                    fa.CSVFile_SaveTableToFile(logFileName, _logs);

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dtFileList"></param>
        /// <param name="storagePath"></param>
        /// <param name="events"></param>
        /// <returns></returns>
        public DataTable RetrieveDocuwareImagesForClaims332DocuwareExporter(DataTable dtFileList, string storagePath, Moss.Events.Events events)
        {
            try
            {
                double nextTarget = .01;
                int rowCount = dtFileList.Rows.Count;
                DataTable dtRtn = new DataTable("StoredDocuments");
                _path = storagePath;


                dtRtn.Columns.Add("Client", typeof(string));
                dtRtn.Columns.Add("LoanNumber", typeof(string));
                dtRtn.Columns.Add("DocumentType", typeof(string));
                dtRtn.Columns.Add("Process", typeof(string));
                dtRtn.Columns.Add("FileName", typeof(string));
                dtRtn.Columns.Add("BorrowerLastName", typeof(string));
                dtRtn.Columns.Add("InvestorCode", typeof(string));
                dtRtn.Columns.Add("ProcessImage", typeof(bool));
                dtRtn.Columns["ProcessImage"].DefaultValue = false;

                for (int i = 0; i < dtFileList.Rows.Count; i++)
                {
                    DataRow dr = dtFileList.Rows[i];
                    IFiledDocument doc = dCabinet.GetDocument(long.Parse(dr[0].ToString()));

                    string loanNumber = doc.MetaData.GetFieldData("LOAN_NUMBER").ToString();//1056704); //Loan number
                    string client = doc.MetaData.GetFieldData("CLIENT_").ToString();//1056705); //Client
                    string docType = doc.MetaData.GetFieldData("DOCUMENT_TYPE").ToString();//1056707); //Document Type
                    string fileName = doc.Name; //unused???

                    //Put these records into a table that we can iterate through later to rename the files
                    DataRow drRtn = dtRtn.NewRow();
                    drRtn["loanNumber"] = loanNumber;
                    drRtn["Client"] = client;
                    drRtn["DocumentType"] = docType;

                    //Now let's export this document
                    string[] files = doc.Commands.newExport().ExecuteEx(storagePath, DocuWare.Gapi.Command.Document.ExportMode.DocuWareName, false);

                    //Check for the length of files, if it is greater than 2 we have an issue within this document and there are too many
                    if (files.Length > 2)
                    {
                        //This is a problem, will need to deal with these and somehow exclude
                        //Will also need to remove those files from the directory
                        System.Windows.Forms.MessageBox.Show("The file with the name: " + files[0] + " has multiple files and cannot be automatically processed.  Please deal with this file manually");
                        drRtn["ProcessImage"] = false;

                    }

                    else
                    {
                        //Position 0 should contain the pdf file
                        drRtn["FileName"] = files[0];
                        drRtn["ProcessImage"] = true;

                    }

                    dtRtn.Rows.Add(drRtn);

                    if ((((double)i + 1) / (double)rowCount) >= nextTarget)
                    {
                        nextTarget += .01;
                        events.OnRaiseImportStatusUpdateEvent();

                    }

                }

                return dtRtn;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        #endregion

    }
    */
}
