﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace CRFS.DocumentManagement
{
    class DWSystem
    {
        CRFS.DocumentManagement.Settings _settings;

        #region "Constructors"
        /// <summary>
        /// 
        /// </summary>
        internal DWSystem()
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        internal DWSystem(CRFS.DocumentManagement.Settings settings)
        {
            _settings = settings;

        }

        #endregion

        #region "Docuware System Database"
        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        /// <returns></returns>
        internal DataTable GetCabinetList()
        {
            SqlConnection con = new SqlConnection();

            try
            {
                DataTable dt = new DataTable("Cabinets");

                dt.Columns.Add("fid", typeof(int));
                dt.Columns.Add("oid", typeof(int));
                dt.Columns.Add("guid", typeof(string));
                dt.Columns.Add("name", typeof(string));
                dt.Columns.Add("settings", typeof(string));
                dt.Columns.Add("checksum", typeof(string));
                dt.Columns.Add("timestamp", typeof(long));
                dt.Columns.Add("type", typeof(string));

                con.ConnectionString = _settings.GetConnectionString("DocuwareSystem");

                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.CommandTimeout = global::CRFS.DocumentManagement.Properties.Settings.Default.CommandTimeouts_General_DWSystemSQLDatabase;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "SELECT fid, oid, guid, name, settings, checksum, timestamp, type FROM dbo.DWFileCabinet";

                cmd.Connection = con;

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DataRow row = dt.NewRow();
                    row["fid"] = (int)dr["fid"];
                    row["oid"] = (int)dr["oid"];
                    row["guid"] = dr["guid"];
                    row["name"] = dr["name"];
                    row["settings"] = dr["settings"];
                    row["checksum"] = dr["checksum"];
                    row["timestamp"] = (long)dr["timestamp"];
                    row["type"] = dr["type"];

                    dt.Rows.Add(row);

                }

                return dt;

            }

            catch (Exception ex)
            {
                throw ex;

            }

            finally
            {
                if (con.State != System.Data.ConnectionState.Closed)
                {
                    con.Close();
                    con.Dispose();
                }

            }

        }

        #endregion


    }
}
