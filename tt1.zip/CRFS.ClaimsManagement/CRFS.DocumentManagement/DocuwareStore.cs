﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;
// using CUTEFORMCOLib;

namespace CRFS.DocumentManagement
{
    /*
    public class DocuwareStore : IDisposable
    {

        #region PrivateData
        CRFS.DocumentManagement.DWData di = null; //new CRFS.DocumentManagement.DWData("Production");
        CRFS.Data.DataFunctions df = null;
        bool loggedin = false;
        string filename = "";
        string doctype = "";
        string process = "";
        string cabinet = "";
        string client = "";
        string loanNo = "";
        string status = "";
        string path = "";
        // fb 1033 20140425
        string originatinguser = "";
        // end fb 1033
        #endregion

        #region PubicInterface
        public DocuwareStore(CRFS.Data.DataFunctions idf)
        {
            df = idf;
        }

        /// <summary>
        /// login to docuware
        /// </summary>
        /// <returns></returns>
        public bool login(string appmode="Production")
        {
            // don't need to log into docuware anymore
            return loggedin = true;
            if (appmode == "UAT")
            {
                appmode = "Testing";
            }
            di = new CRFS.DocumentManagement.DWData(appmode);
            Moss.Security.Security sec = new Moss.Security.Security();
            DataTable dtDocuwareLogin = df.GetLogins_BySystemType("Docuware");
            String DWUser = dtDocuwareLogin.Rows[0]["SystemID"].ToString();
            String DWpasswd = sec.Decrypt(dtDocuwareLogin.Rows[0]["SystemPassword"].ToString(), true);
            if (!di.LoginToDocuware(DWUser, DWpasswd))
            {
                throw new Exception("cannot log into docuware");
            }
            return loggedin=true;
        }

        /// <summary>
        /// set filename
        /// </summary>
        /// <param name="fn"></param>
        /// <returns></returns>
        public DocuwareStore setFileName(string fn)
        {
            filename = fn;
            return this;
        }

        /// <summary>
        /// set documenttype
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public DocuwareStore setDocType(string dt)
        {
            doctype = dt;
            return this;
        }

        /// <summary>
        /// set process
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public DocuwareStore setProcess(string p)
        {
            process = p;
            return this;
        }

        /// <summary>
        /// set the cabinet within docuware
        /// </summary>
        /// <param name="c"></param>
        /// <returns></returns>
        public DocuwareStore setCabinet(string c)
        {
            cabinet = c;
            return this;
        }

        /// <summary>
        /// set the client 
        /// </summary>
        /// <param name="c"></param>
        /// <returns></returns>
        public DocuwareStore setClient(string c)
        {
            client = c;
            return this;
        }

        /// <summary>
        /// set the loan number
        /// </summary>
        /// <param name="l"></param>
        /// <returns></returns>
        public DocuwareStore setLoanNo(string l)
        {
            loanNo = l;
            return this;
        }

        /// <summary>
        /// set the status string
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public DocuwareStore setStatus(string s)
        {
            status = s;
            return this;
        }

        /// <summary>
        /// set the path to the file to store
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public DocuwareStore setPath(string p)
        {
            path = p;
            return this;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public DocuwareStore setOriginatingUser(string p)
        {
        // fb 1033 20140425
            originatinguser = p;
            return this;
        }

        /// <summary>
        /// save the document into docuware and cleanup
        /// </summary>
        /// <returns></returns>
        public bool save()
        {
            if (!loggedin)
                throw new Exception("Cannot save before logged into docuware");
            //login();
            string outFilePath=path+((path[path.Length-1]=='\\')?"":"\\")+filename;
            long ret;
            if (System.IO.File.Exists(outFilePath))
            {
                FileInfo fi = new FileInfo(outFilePath);
                ret = fi.Length;
            }
            else
            {
                throw new Exception(outFilePath + " does not exist");
            }
            DataTable dtCabinetFields = di.OpenFileCabinet(cabinet);

            //Start building data for the docuware header file
            for (int fieldrow = 0; fieldrow < dtCabinetFields.Rows.Count ; fieldrow++)
            {
                switch (dtCabinetFields.Rows[fieldrow]["fieldName"].ToString().ToUpper())
                {
                    case "CLIENT":
                    case "CLIENT_":
                        dtCabinetFields.Rows[fieldrow]["fieldValue"] = client;
                        break;

                    case "DOCUMENT_TYPE":
                        dtCabinetFields.Rows[fieldrow]["fieldValue"] = doctype;
                        break;

                    case "LOAN_NUMBER":
                        dtCabinetFields.Rows[fieldrow]["fieldValue"] = loanNo; 
                        break;

                    case "PROCESS":
                        dtCabinetFields.Rows[fieldrow]["fieldValue"] = process;
                        break;

                    case "STATUS":
                        if (status.Length>=25) 
                        {
                            status = status.Substring(0, 25);
                        }
                        dtCabinetFields.Rows[fieldrow]["fieldValue"] = status;
                        break;

                    case "UPLOAD_DATE":  // gk 20160229, added yet another variation on upload date
                    case "UPLOADDATE":
                    case "UPLDDATE":
                        dtCabinetFields.Rows[fieldrow]["fieldValue"] = DateTime.Today.ToString("s");
                        break;

                    case "ORIGINATIONDATE":
                        dtCabinetFields.Rows[fieldrow]["fieldValue"] = DateTime.Now.ToString("s");
                        break;

                    case "ORIGINATINGUSER":
                        dtCabinetFields.Rows[fieldrow]["fieldValue"] = originatinguser;
                        break;

                }
            }
            //string noext = filename.Replace(".pdf", "");
            string noext = filename.Replace(Path.GetExtension(filename), "");
            // path needs to have a trailing slash on it
            di.CreateNewDocuwareHeaderFile(noext + ".001", filename/*noext + ".pdf", path + ((path[path.Length - 1] == '\\') ? "" : "\\"), (int)ret, dtCabinetFields);
            DataTable headerFileList = di.GetDocuwareHeaderFiles(path);
            di.StoreDocuments(headerFileList);
            di.CleanupDocuwareHeaderFiles(path, null); // 2nd parm is a moss.events object but it isn't used
            di.CleanupPDFDocumentFiles(path);
            return true;
        }


        #endregion
        public void Dispose()
        {
            if (loggedin)
            {
                //di.LogoutOfDocuware();
            }
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (loggedin)
                {
                    di.LogoutOfDocuware();
                }
            }
        }
    }
    */
}
