﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;

namespace CRFS.DocumentManagement
{
    public class dataFunctions
    {
        internal string _appMode;
        internal CRFS.DocumentManagement.Settings settings;
        private DataTable _CabinetList;
        private Moss.Events.Events events = new Moss.Events.Events();

        /// <summary>
        /// 
        /// </summary>
        /// <param name="appMode"></param>
        public dataFunctions(string appMode)
        {
            _appMode = appMode;
            settings = new CRFS.DocumentManagement.Settings(appMode);

            _CabinetList = GetCabinetList();

        }

        #region "Docuware Autehntication Functions"

        /// <summary>
        /// 
        /// </summary>
        public void setDocuwareAuthServer()
        {
            try
            {
                //The Docuware settings file can have multiple connection settings configured, but only the first
                //workable one is used.  This presents a problem when trying to log into the test server if the 
                //production server happens to be entered in the config file first.  What we need to do, before 
                //the Docuware client tries to read the config/settings files, is to:
                //1) make a copy of the config file, then 
                //2) find the line with the text <GapiConfig SettingsStorage="DocuWare.Gapi.dll.settings"
                //3) make an edit to the file appending either .Test or .Production
                //4) save and close
                //5) allow the Docuware client to read the files to get open
                //6) attempt to replace the file witht the backup copy - leaving us ready for a fresh start

                File.Copy("DocuWare.Gapi.dll.config", "DocuWare.Gapi.dll.config.backup");

                StringBuilder newFile = new StringBuilder();
                string[] origFile = File.ReadAllLines("DocuWare.Gapi.dll.config");

                foreach (string line in origFile)
                {
                    if (line.Contains("DocuWare.Gapi.dll.settings"))
                    {
                        string temp = "";

                        switch (_appMode)
                        {
                            case "Production":
                                temp = line.Replace("DocuWare.Gapi.dll.settings", "DocuWare.Gapi.dll.settings.Production");
                                break;

                            case "Testing":
                                temp = line.Replace("DocuWare.Gapi.dll.settings", "DocuWare.Gapi.dll.settings.Test");
                                break;

                            case "Development":
                                temp = line.Replace("DocuWare.Gapi.dll.settings", "DocuWare.Gapi.dll.settings.Test");
                                break;

                            default:
                                //Do nothing.  This should cause a login failure because the default settings file should have both
                                //AS server entries commented out.  We need the correct appmode to be used in order to log in.
                                temp = line;
                                break;

                        }

                        newFile.Append(temp + "\r\n");

                    }

                    else
                    {
                        newFile.Append(line + "\r\n");

                    }


                }

                File.WriteAllText("DocuWare.Gapi.dll.config", newFile.ToString());

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        public void restoreDocuwareAuthServerSettings()
        {
            try
            {
                StringBuilder newFile = new StringBuilder();
                string[] origFile = File.ReadAllLines("DocuWare.Gapi.dll.config.backup");

                foreach (string line in origFile)
                {
                    newFile.Append(line + "\r\n");

                }

                File.WriteAllText("DocuWare.Gapi.dll.config", newFile.ToString());
                File.Delete("DocuWare.Gapi.dll.config.backup");

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        #endregion

        #region "Docuware System Database Functions"
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable GetCabinetList()
        {
            try
            {
                DWSystem dws = new DWSystem(settings);
                return dws.GetCabinetList();

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        #endregion

    }
}
