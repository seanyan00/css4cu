﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CRFS.DocumentManagement
{
    internal class Settings
    {
        string _appMode;

        /// <summary>
        /// 
        /// </summary>
        public String appMode
        {
            get
            {
                return _appMode;
            
            }

            set
            {
                _appMode = value;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="AppMode"></param>
        public Settings(string AppMode)
        {
            try
            {
                appMode = AppMode;
                // // To add event handlers for saving and changing settings, uncomment the lines below:
                //
                // this.SettingChanging += this.SettingChangingEventHandler;
                //
                // this.SettingsSaving += this.SettingsSavingEventHandler;
                //
            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public string Get_appmode()
        {
            return appMode;
        
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="databaseName"></param>
        /// <returns></returns>
        public string GetConnectionString(string databaseName)
        {
            try
            {
                string connString = null;

                switch (databaseName)
                {
                    case "DocuwareSystem":
                        switch (appMode)
                        {
                            case "Production":
                                connString = global::CRFS.DocumentManagement.Properties.Settings.Default.DWSystemConnectionString;
                                break;
                            case "Testing":
                                connString = global::CRFS.DocumentManagement.Properties.Settings.Default.DWSystemUATConnectionString;
                                break;
                            case "Development":
                                connString = global::CRFS.DocumentManagement.Properties.Settings.Default.DWSystemDevelopmentConnectionString;
                                break;
                            default:
                                break;
                        
                        }

                        connString += ";Password=B0d~ZqaxCTwOPNA7$l3V";

                        break;

                    case "DocuwareData":
                        switch (appMode)
                        {
                            case "Production":
                                connString = global::CRFS.DocumentManagement.Properties.Settings.Default.DWDataAuthServer;
                                break;
                            case "Testing":
                                connString = global::CRFS.DocumentManagement.Properties.Settings.Default.DWDataTestAuthServer;
                                break;
                            case "Development":
                                connString = global::CRFS.DocumentManagement.Properties.Settings.Default.DWDataTestAuthServer;
                                break;
                            default:
                                break;
                        
                        }
                        
                        break;

                    default:
                        break;

                }

                return connString;

            }

            catch (Exception ex)
            {
                throw ex;

            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SettingChangingEventHandler(object sender, System.Configuration.SettingChangingEventArgs e)
        {
            // Add code to handle the SettingChangingEvent event here.
        
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SettingsSavingEventHandler(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Add code to handle the SettingsSaving event here.
        
        }


    }
}
