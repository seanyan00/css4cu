import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from "rxjs";
import { CookieService } from 'ngx-cookie-service';
import { TokenResponse } from '../classinterfaces/TokenResponse';
import { Router, ActivatedRoute, ParamMap, UrlTree } from '@angular/router';
import { DbstoreService } from './dbstore.service';

@Injectable({
  providedIn: 'root'
})
export class TokenService {

  constructor(private cookieService: CookieService,
    private route: ActivatedRoute,
    private router: Router,
    private dbaccess: DbstoreService
    ) { }

  async isAuthenticated() : Promise<boolean | UrlTree >{
    let sid: string | any;
    let agent: string | any;

    let tempsid = this.cookieService.get('sid');
    if( tempsid == null){
      sid = this.route.snapshot.queryParamMap.get('SID');
      agent = this.route.snapshot.queryParamMap.get('AGENT');
      if(sid == null || agent == null){
          return this.router.parseUrl('/unauth');
      }
    } else {
      sid = tempsid;
      agent = this.cookieService.get('agent');
    }
  
    let info: boolean = await this.dbaccess.authenticated(sid, agent);

    if(info) { 
      this.cookieService.set('sid', sid);
      this.cookieService.set('agent', agent);
    }else{
       return this.router.parseUrl('/accessdeny');
    }
    return true;
  }
}
