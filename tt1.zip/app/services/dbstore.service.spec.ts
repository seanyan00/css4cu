import { TestBed } from '@angular/core/testing';

import { DbstoreService } from './dbstore.service';

describe('DbstoreService', () => {
  let service: DbstoreService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DbstoreService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
