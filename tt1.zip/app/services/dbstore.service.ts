import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { IAgencySurvey } from '../classinterfaces/IAgencySurvey';
import { environment } from '@environment/environment';
import { map, catchError } from 'rxjs/operators';
import { throwError, Observable, BehaviorSubject, pipe, lastValueFrom  } from 'rxjs';
   
const httpOptions = {
     headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Accept': 'application/json'
     })
   };

@Injectable({
      providedIn: 'root'
})

export class DbstoreService {
  private apiURL: string;
  
  constructor(private http: HttpClient) { 
       this.apiURL = environment.proxyPath;
  }

  async getAgencyInfo()  {
     try {
         let last$ = this.http.get<IAgencySurvey>(`${this.apiURL}api/AgentInfo/5`);
         let ret = await lastValueFrom(last$);
         
         return ret;
     } catch (error) {
       throw error;
     }
  }

  async authenticated(sid: string, agent: string) {
    try {
      let last$ = this.http.get<boolean>(`${this.apiURL}api/AgentInfo/5`);
      let ret = await lastValueFrom(last$);
      
      return ret;
    } catch (error) {
      throw error;
    }
  }
    
      private handleError(error: HttpErrorResponse) {
         if (error.status === 0) {
             console.error('An error occurred:', error.error);
         } else {
             console.error(`Backend returned code ${error.status}, body was: `, error.error);
         }
         return throwError(() => new Error('Please try again later.'));
       }
	
}
