import { TestBed } from '@angular/core/testing';
import { CanActivateFn } from '@angular/router';

import { dbaccessGuard } from './dbaccess.guard';

describe('dbaccessGuard', () => {
  const executeGuard: CanActivateFn = (...guardParameters) => 
      TestBed.runInInjectionContext(() => dbaccessGuard(...guardParameters));

  beforeEach(() => {
    TestBed.configureTestingModule({});
  });

  it('should be created', () => {
    expect(executeGuard).toBeTruthy();
  });
});
