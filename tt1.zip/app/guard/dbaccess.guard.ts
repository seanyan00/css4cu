import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { DbstoreService } from '../services/dbstore.service';

export const dbaccessGuard: CanActivateFn = (route, state) => {
  const dbService: DbstoreService = inject(DbstoreService);
  const router: Router = inject(Router);

  
  return true;
};
