import { Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { authGuard } from './guard/auth.guard';
import { UnauthorizedComponent } from './errors/unauthorized/unauthorized.component';
import { AccessDenyComponent } from './errors/access-deny/access-deny.component';

export const routes: Routes = [
    { 
        path: '',
        component: AppComponent,
        pathMatch : 'full',
        canActivate: [authGuard],
    },
    /*{
        path: 'unauth',
        component: UnauthorizedComponent,
        pathMatch: 'full'
    },
    {
        path: 'accesserror',
        component: AccessDenyComponent,
        pathMatch:'full'
    },*/
]