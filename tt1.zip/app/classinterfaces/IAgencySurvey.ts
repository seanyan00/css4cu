export interface IAgencySurvey {
    isDownload: boolean,
    name: string
}
