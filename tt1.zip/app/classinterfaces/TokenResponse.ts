export class TokenResponse {
    public Sid: string;
    public Agent: string
}