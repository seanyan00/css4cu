import { Component, ViewEncapsulation, OnInit, EventEmitter, 	Inject,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { FormControl, FormGroup, Validators, ReactiveFormsModule, ValidationErrors  } from '@angular/forms';
import { IAgencySurvey } from './classinterfaces/IAgencySurvey';
import { DbstoreService } from './services/dbstore.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, ReactiveFormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
  encapsulation: ViewEncapsulation.None
})
export class AppComponent implements OnInit{
 // title = 'avalon';
  
  public agencySurvey: IAgencySurvey;
  public agencySurveyForm: FormGroup;

  get name() {
    return this.agencySurveyForm.get('name');
  }
  get isDownload() {
    return this.agencySurveyForm.get('isDownload');
  }

  constructor(
    private dbstoreService: DbstoreService
    )
  {
    this.agencySurvey = { isDownload: false, name: ""};
  }
  async ngOnInit() {
     this.buildForm();
     this.setupForm(); 
     await this.getAgentInfo();
  }

  buildForm(){
    this.agencySurveyForm = new FormGroup({
       isDownload: new FormControl(this.agencySurvey.isDownload),
       name: new FormControl(this.agencySurvey.name ? "" : this.agencySurvey.name, Validators.required)
    });
  }
  
  setupForm(){
    this.name.valueChanges.subscribe(
        seleValue => {
           this.agencySurvey.name = seleValue;
        });
  }
 async getAgentInfo()
  {
     try{
        let info = await this.dbstoreService.getAgencyInfo()
      
        this.agencySurvey.isDownload = info.isDownload;
        this.agencySurvey.name = info.name;
        this.updateValues();
     } catch(e){
        console.log(e);
     }
  }

  updateValues()
  {
    this.agencySurveyForm.patchValue({
      name: this.agencySurvey.name,
      isDownload: this.agencySurvey.isDownload
    });
  }
 
  onSubmit(): void {
    this.agencySurvey;
    if (this.agencySurveyForm.invalid) {
      console.log("don't")
    }
    this.agencySurveyForm.reset();
  }

}
