using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;
using System.IdentityModel.Tokens.Jwt;
using MIGE.Core.NewWebHost.Models;
using Newtonsoft.Json;
using System.Net;
using System.IO;
using Microsoft.Extensions.Primitives;
using System.Net.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using System.Configuration;
using Microsoft.Extensions.Configuration;
using System.Security.Cryptography;
using System.Text;

namespace MIGE.Core.NewWebHost
{
	public class LoggingActionFilter : IActionFilter
	{
		private string URL = ConfigurationManager.AppSettings["BACKENDSERVER_LOCAL"];

		public void OnActionExecuted(ActionExecutedContext context)
		{
            StringValues token = string.Empty;
            JsonSerializerSettings settings = new JsonSerializerSettings { Formatting = Formatting.Indented };
            string controllerName = ((Microsoft.AspNetCore.Mvc.Controllers.ControllerActionDescriptor)context.ActionDescriptor).ControllerName;
            string fullRequestPath = controllerName + "/" + (string)context.HttpContext.Request.Headers["RequestPath"];

            try
            {
                // Gather the token from the headers
                token = context.HttpContext.Request.Headers["Authorization"];

                if (!string.IsNullOrEmpty(token)) {
                    // Parse the token
                    JwtSecurityTokenHandler jwt = new JwtSecurityTokenHandler();
                    JwtSecurityToken jwtTokenInstance = jwt.ReadJwtToken(token.ToString().Replace("Bearer ", ""));

                    // Gather the UserData stored on the Token
                    UserData userData = JsonConvert.DeserializeObject<UserData>(jwtTokenInstance.Claims.Where(x => x.Type == "user-info").FirstOrDefault().Value);
                    string serializedUserData = jwtTokenInstance.Claims.Where(x => x.Type == "user-info").FirstOrDefault().Value;

                    SystemLog log = new SystemLog()
                    {
                        MessageTemplate = LogMessageTemplate.GenericAccess,
                        MessageParameters = new object[] { "Outgoing: " + LogEventType.GenericAccess.Value, userData.UserId, fullRequestPath, context.HttpContext.Connection.RemoteIpAddress.ToString(), token.ToString().Replace("Bearer ", ""), serializedUserData, userData.QuoteId },
                        Severity = LogEventSeverity.Information,
                        Type = LogType.Access
                    };

                    LogMessage(JsonConvert.SerializeObject(log, settings));

                    var builder = new ConfigurationBuilder().AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
                    var configuration = builder.Build();
                    var properties = configuration.GetSection($"FrontEndLogger");
                    var LogFlag = configuration.GetSection($"FrontEndLogger:LogFlag");

                    if (fullRequestPath == "ProxyHandler/SaveQuoteGetPremium/" && LogFlag.Value == "True")
                    {
                        //Make a case statment for when the requestpath is SaveQuoteGetPremium
                        //We then want to write a log to a txt file and save locally for now
                        //Do the same for OnActionExecuted

                        //var propertyList = (JObject)JsonConvert.DeserializeObject(properties);
                        //Check to make sure the flag is turned on or we don't want to write to the file

                        //Grab value of filename from app config
                        //DONT NEED SINCE WILL GET HANDLED IN THE ONACTIONEXECUTION
                        var date = DateTime.Today.Month + "_" + DateTime.Today.Day + "_" + DateTime.Today.Year;
                        var filepath = ConfigurationManager.AppSettings["LoggingFilePath"] + date + ".txt";
                        //if (!File.Exists(filepath))
                        //{
                        //    using (StreamWriter streamWriter = File.CreateText(filepath))
                        //    {
                        //        streamWriter.WriteLine(DateTime.Now);
                        //    }
                        //}
                        //else
                        // {
                        using (StreamWriter streamWriter = File.AppendText(filepath))
                        {
                            //Write hased quoteid and response times
                            //streamWriter.WriteLine("QuoteId: " + userData.QuoteId); //Needs to be hashed
                            streamWriter.WriteLine(DateTime.Now);
                        }
                      //  }
                    }
                }

            }
            catch (Exception ex)
            {
                SystemLog log = new SystemLog()
                {
                    MessageTemplate = LogMessageTemplate.Caught,
                    MessageParameters = new object[] { ex.Message, (ex.InnerException == null ? string.Empty : ex.InnerException.Message) },
                    Severity = LogEventSeverity.Error,
                    Type = LogType.Error
                };
                LogMessage(JsonConvert.SerializeObject(log, settings));
                //throw ex;
            }
            finally {

            }


        }

		/// <summary>
		/// Filter which handles Access Logging in the System.
		/// </summary>
		/// <param name="context"></param>
		public void OnActionExecuting(ActionExecutingContext context)
		{
			StringValues token = string.Empty;
			JsonSerializerSettings settings = new JsonSerializerSettings { Formatting = Formatting.Indented };
			string controllerName = ((Microsoft.AspNetCore.Mvc.Controllers.ControllerActionDescriptor)context.ActionDescriptor).ControllerName;
			string fullRequestPath = controllerName + "/" + (string)context.HttpContext.Request.Headers["RequestPath"];

			try
			{
                // Gather the token from the headers
                token = context.HttpContext.Request.Headers["Authorization"];

				if (!string.IsNullOrEmpty(token))
				{
					// Parse the token
					JwtSecurityTokenHandler jwt = new JwtSecurityTokenHandler();
					JwtSecurityToken jwtTokenInstance = jwt.ReadJwtToken(token.ToString().Replace("Bearer ", ""));

					// Gather the UserData stored on the Token
					UserData userData = JsonConvert.DeserializeObject<UserData>(jwtTokenInstance.Claims.Where(x => x.Type == "user-info").FirstOrDefault().Value);
					string serializedUserData = jwtTokenInstance.Claims.Where(x => x.Type == "user-info").FirstOrDefault().Value;

					SystemLog log = new SystemLog()
					{
						MessageTemplate = LogMessageTemplate.GenericAccess,
						MessageParameters = new object[] { "Incoming: " + LogEventType.GenericAccess.Value, userData.UserId, fullRequestPath, context.HttpContext.Connection.RemoteIpAddress.ToString(), token.ToString().Replace("Bearer ", ""), serializedUserData, userData.QuoteId },
						Severity = LogEventSeverity.Information,
						Type = LogType.Access
					};

					LogMessage(JsonConvert.SerializeObject(log, settings));
                    var builder = new ConfigurationBuilder().AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
                    var configuration = builder.Build();
                    var properties = configuration.GetSection($"FrontEndLogger");
                    var LogFlag = configuration.GetSection($"FrontEndLogger:LogFlag");

                    if (fullRequestPath == "ProxyHandler/SaveQuoteGetPremium/" && LogFlag.Value == "True")
                    {
                        //Make a case statment for when the requestpath is SaveQuoteGetPremium
                        //We then want to write a log to a txt file and save locally for now
                        //Do the same for OnActionExecuted

                        //var propertyList = (JObject)JsonConvert.DeserializeObject(properties);
                        //Check to make sure the flag is turned on or we don't want to write to the file

                        //Grab value of filename from app config
                        var date = DateTime.Today.Month + "_" + DateTime.Today.Day + "_" + DateTime.Today.Year;
                        var filepath = ConfigurationManager.AppSettings["LoggingFilePath"] + date + ".txt";
                        if (!File.Exists(filepath))
                        {
                            //We want a pipe delimited file
                            //We want to create a new file each day
                            using (StreamWriter streamWriter = File.CreateText(filepath))
                            {
                                streamWriter.WriteLine("Request path" + "|" + "QuoteId" + "|" + "Request Time" + "|" + "Response Time");
                                streamWriter.Write(fullRequestPath + "|" + GetHashString(userData.QuoteId) + "|" + DateTime.Now + "|" );
                                //streamWriter.WriteLine(GetHashString(userData.QuoteId) + "|"); //Needs to be hashed
                                //streamWriter.WriteLine(DateTime.Now + "|");
                            }
                        }
                        else
                        {
                            using (StreamWriter streamWriter = File.AppendText(filepath))
                            {
                                //Write hased quoteid and response times
                                streamWriter.Write(fullRequestPath + "|" + GetHashString(userData.QuoteId) + "|" + DateTime.Now + "|");
                                //streamWriter.WriteLine(fullRequestPath + "|");
                                //streamWriter.WriteLine(GetHashString(userData.QuoteId) + "|"); //Needs to be hashed
                                //streamWriter.WriteLine(DateTime.Now + "|");
                            }
                        }

                    }
                    /* TODO: Once the IpAddress issues are figured out, uncomment the below if block which
							 will handle checking the IpAddress and logging what happens. Remove the log process
							 directly above this comment as well (place holder for generic logging)

					// Check the IpAddress
					if (userData.IpAddress.Trim() == context.HttpContext.Connection.RemoteIpAddress.ToString())
					{
						SystemLog log = new SystemLog() {
							MessageTemplate = LogMessageTemplate.GenericAccess,
							MessageParameters = new object[] { LogEventType.GenericAccess.Value, userData.UserId, fullRequestPath, context.HttpContext.Connection.RemoteIpAddress.ToString(), token.ToString().Replace("Bearer ", ""), serializedUserData },
							Severity = LogEventSeverity.Information,
							Type = LogType.Access
						};

						LogMessage(JsonConvert.SerializeObject(log, settings));
					}
					else
					{
						// Invalid IP Address
						SystemLog log = new SystemLog()
						{
							MessageTemplate = LogMessageTemplate.InvalidIpAccess,
							MessageParameters = new object[] { LogEventType.InvalidIpAccess.Value, userData.UserId, fullRequestPath, context.HttpContext.Connection.RemoteIpAddress.ToString(), userData.IpAddress.Trim(), token.ToString().Replace("Bearer ", ""), serializedUserData },
							Severity = LogEventSeverity.Warning,
							Type = LogType.Access
						};

						LogMessage(JsonConvert.SerializeObject(log, settings));

						//TODO: Redirect back to Lansa login URL, based on Env
					}
					*/
                }
				else if (controllerName.ToUpper() == "LANSAAUTH")
				{
					// User is attempting to request a Token, log this request.
					Microsoft.AspNetCore.Mvc.ModelBinding.ModelStateEntry userId;
					context.ModelState.TryGetValue("UserId", out userId);

					SystemLog log = new SystemLog()
					{
						MessageTemplate = LogMessageTemplate.RequestingAccess,
						MessageParameters = new object[] { LogEventType.TokenRequest.Value, userId.RawValue.ToString(), fullRequestPath, context.HttpContext.Connection.RemoteIpAddress.ToString() },
						Severity = LogEventSeverity.Information,
						Type = LogType.Access
					};

					LogMessage(JsonConvert.SerializeObject(log, settings));
				}
				else
				{
					// No Token passed and Not Requesting Token
					// Log that the user attempted an unauthorized request
					SystemLog log = null;
					context.ModelState.TryGetValue("UserId", out Microsoft.AspNetCore.Mvc.ModelBinding.ModelStateEntry userId);

					if (!string.IsNullOrEmpty(userId.RawValue.ToString()))
					{
						log = new SystemLog()
						{
							MessageTemplate = LogMessageTemplate.UnauthorizedWithUser,
							MessageParameters = new object[] { userId, fullRequestPath, context.HttpContext.Connection.RemoteIpAddress.ToString() },
							Severity = LogEventSeverity.Warning,
							Type = LogType.Access
						};
					}
					else
					{
						log = new SystemLog()
						{
							MessageTemplate = LogMessageTemplate.Unauthorized,
							MessageParameters = new object[] { fullRequestPath, context.HttpContext.Connection.RemoteIpAddress.ToString() },
							Severity = LogEventSeverity.Warning,
							Type = LogType.Access
						};
					}

					LogMessage(JsonConvert.SerializeObject(log, settings));
				}
			}
			catch (Exception ex)
			{
				SystemLog log = new SystemLog()
				{
					MessageTemplate = LogMessageTemplate.Caught,
					MessageParameters = new object[] { ex.Message, (ex.InnerException == null ? string.Empty : ex.InnerException.Message) },
					Severity = LogEventSeverity.Error,
					Type = LogType.Error
				};

				LogMessage(JsonConvert.SerializeObject(log, settings));
			}
		}

		/// <summary>
		/// LogMessage
		/// Makes an API call to the MIGE.Core.Backend WebAPI to Log to the Database.
		/// </summary>
		/// <param name="json"></param>
		private void LogMessage(string json)
		{
			HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL + "SystemLog");

			request.Method = "POST";
			request.ContentLength = json.Length;
			request.ContentType = "application/json";

			StreamWriter requestWriter = new StreamWriter(request.GetRequestStream(), System.Text.Encoding.ASCII);
			requestWriter.Write(json);
			requestWriter.Close();

			HttpWebResponse response = (HttpWebResponse)request.GetResponse();
			StreamReader reader = new StreamReader(response.GetResponseStream());
		}

        public static byte[] GetHash(string inputString)
        {
            using (HashAlgorithm algorithm = SHA256.Create())
                return algorithm.ComputeHash(Encoding.UTF8.GetBytes(inputString));
        }
        public static string GetHashString(string inputString)
        {
            StringBuilder sb = new StringBuilder();
            foreach (byte b in GetHash(inputString))
                sb.Append(b.ToString("X2"));

            return sb.ToString();
        }
    }

    /// <summary>
    /// LogMessageTemplate
    /// Holds string templates to be used when Logging messages.
    /// </summary>
    public static class LogMessageTemplate
	{
		public const string RequestingAccess = "{EventType} User {UserId} attempting Token Request to {Controller} from {IpAddress}";
		public const string GenericAccess = "{EventType} User {UserId} accessed {Controller} from {IpAddress} with {Token} || {UserData} || {QuoteId}";
		public const string InvalidIpAccess = "{EventType} User {UserId} attempted to access {Controller} from {IpAddress} instead of from {originIpAddress} with {Token} || {UserData}";
		public const string Unauthorized = "{EventType} Access attempted to {Controller} from {IpAddress}";
		public const string UnauthorizedWithUser = "{EventType} User {UserId} attempted access to {Controller} from {IpAddress}";
		public const string Caught = "Exception: {ExceptionMessage} | InnerException: {InnerEx}";
	}

	/// <summary>
	/// LogEventType
	/// A quasi-enum that allows us to store Strings as an Enum to make coding above more readable.
	/// </summary>
	public sealed class LogEventType
	{
		public static readonly LogEventType GenericAccess = new LogEventType("GenericAccess");
		public static readonly LogEventType TokenRequest = new LogEventType("TokenRequest");
		public static readonly LogEventType InvalidIpAccess = new LogEventType("InvalidIpAccess");
		public static readonly LogEventType Unauthorized = new LogEventType("Unauthorized");

		private LogEventType(string value)
		{
			Value = value;
		}

		public string Value { get; private set; }
	}

	/// <summary>
	/// LogEventSeverity
	/// Enum that holds the different logging severities
	/// </summary>
	public enum LogEventSeverity
	{
		Information = 1,
		Warning = 2,
		Error = 3,
		Fatal = 4
	}

	/// <summary>
	/// LogType
	/// Enum that holds the different types of logs
	/// </summary>
	public enum LogType
	{
		Access = 1,
		Error = 2
	}
}
