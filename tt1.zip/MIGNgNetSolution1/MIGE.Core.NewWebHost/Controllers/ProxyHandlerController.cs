using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;

//
using System.IO;
using System.Net;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Runtime.Serialization.Json;

//
using System.Security.Claims;
using System.Diagnostics;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;

//
using System.Text;
using System.Threading;

using MIGE.Core.NewWebHost.Models;
using Newtonsoft.Json.Serialization;
using Microsoft.AspNetCore.Http;
using System.Configuration;
using System.IdentityModel.Tokens.Jwt;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MIGE.Core.NewWebHost.Controllers
{

    
    public class ProxyHandlerController : Controller
    {
		private string URL = ConfigurationManager.AppSettings["BACKENDSERVER_LOCAL"];
		private CustomMessage response = null;

		[HttpGet]
        [EnableCors("MigPolicy")]
        [Produces("application/json")]
        [Route("api/ProxyGet")]
        //[Authorize(Roles = "admin")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        public JsonResult ProxyGet()
        {
            try
            {

                var token = this.HttpContext.Request.Headers["Authorization"];
                string requestPath = (string)this.HttpContext.Request.Headers["RequestPath"];

                //back-end behind firewall api call 
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL + requestPath);
                request.Method = "GET";
                request.ContentType = "application/json";
                request.Headers.Add("Authorization", token);

                //dynamic obj
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream());
                dynamic json = JsonConvert.DeserializeObject(reader.ReadToEnd());
                return Json(json);

            }
            catch (Exception ex)
            {
				string innerexception = (ex.InnerException != null) ? Environment.NewLine + " - InnerEx: " + ex.InnerException.ToString() : "";

				response = new CustomMessage();
				response.Title = "ProxyGet()-Error!";
				response.StatusCode = "500";
				response.Message = "Request: " + (string)this.HttpContext.Request.Headers["RequestPath"].ToString() + " || Error: " + ex.ToString() + (innerexception == "" ? "" : "-- " + innerexception);

				return Json(response);

				throw ex;
			}
        }


        [HttpPost]
        [EnableCors("MigPolicy")]
        [Route("api/ProxyPost")]
        [Produces("application/json")]
        //[Authorize(Roles = "COL1")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        public JsonResult ProxyPost([FromBody] object postdata)
        {
            try
            {
                var token = this.HttpContext.Request.Headers["Authorization"];
                string requestPath = (string)this.HttpContext.Request.Headers["RequestPath"];

				JwtSecurityTokenHandler jwt = new JwtSecurityTokenHandler();
				var obj = jwt.ReadJwtToken(token.ToString().Replace("Bearer ", ""));

                JsonSerializerSettings settings = new JsonSerializerSettings { Formatting = Formatting.Indented };
                string json = JsonConvert.SerializeObject(postdata, settings);

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL + requestPath);
				Debug.WriteLine("proxy-post = " + URL + requestPath);
				
                request.Method = "POST";
                request.ContentLength = json.Length;
                request.ContentType = "application/json";
                request.Headers.Add("Authorization", token);
				
                StreamWriter requestWriter = new StreamWriter(request.GetRequestStream(), System.Text.Encoding.ASCII);
                requestWriter.Write(json);
                requestWriter.Close();

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream());
                object jsonResponse = JsonConvert.DeserializeObject(reader.ReadToEnd());
                return Json(jsonResponse, settings);

            }
            catch (Exception ex)
            {
				string innerexception = (ex.InnerException != null) ? Environment.NewLine + " - InnerEx: " + ex.InnerException.ToString() : "";

				response = new CustomMessage();
				response.Title = "ProxyPost()-Error!";
				response.StatusCode = "500";
				response.Message = "Request: " + (string)this.HttpContext.Request.Headers["RequestPath"].ToString() + " || Error: " + ex.ToString() + (innerexception == "" ? "" : "-- " + innerexception);

				return Json(response);

				throw ex;
			}
        }        

        [HttpPost]
        [EnableCors("MigPolicy")]
        [Route("api/ProxyFileUpload")]
        [Produces("application/json")]
        //[Authorize(Roles = "admin")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        public JsonResult ProxyPostFileUpload(List<IFormFile> files)        
        {
            //params
            byte[] postData = null;
            string stringData = "";

            //grab headers and file size
            long fileSize = files.Sum(f => f.Length);
            var token = this.HttpContext.Request.Headers["Authorization"];
            var fileMetaData = (string)this.HttpContext.Request.Headers["FileMetaData"];
            var requestPath = (string)this.HttpContext.Request.Headers["RequestPath"];
            
            try
            {

				//foreach (var file in files)
				//{
				//	if (file.Length > 0)
				//	{
				//		using (var ms = new MemoryStream())
				//		{
				//			file.CopyTo(ms);
				//			postData = ms.ToArray();
				//			stringData = Convert.ToBase64String(postData);
				//		}
				//	}
				//}
				if (files.Count !=0)
				{
					using (var ms = new MemoryStream())
					{
						files[0].CopyTo(ms);
						postData = ms.ToArray();
						stringData = Convert.ToBase64String(postData);
					}
				}
				//if (files[0].Length > 0)
				//{
				//	using (var ms = new MemoryStream())
				//	{
				//		files[0].CopyTo(ms);
				//		postData = ms.ToArray();
				//		stringData = Convert.ToBase64String(postData);
				//	}
				//}

				JsonSerializerSettings settings = new JsonSerializerSettings { Formatting = Formatting.Indented };

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL+ "/FileUpload");
                request.Method = "POST";
                //request.ContentLength = fileSize;
                request.ContentType = "application/octet-stream";
                request.Headers.Add("Authorization", token);
                request.Headers.Add("FileMetaData", fileMetaData);

                StreamWriter requestWriter = new StreamWriter(request.GetRequestStream(), System.Text.Encoding.ASCII);
                requestWriter.Write(stringData);
                requestWriter.Close();

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream());
                object jsonResponse = JsonConvert.DeserializeObject(reader.ReadToEnd());
                return Json(jsonResponse, settings);

            }
            catch (Exception ex)
            {
				string innerexception = (ex.InnerException != null) ? Environment.NewLine + " - InnerEx: " + ex.InnerException.ToString() : "";

				response = new CustomMessage();
				response.Title = "ProxyPostFileUpload()-Error!";
				response.StatusCode = "500";
				response.Message = "Request: " + (string)this.HttpContext.Request.Headers["RequestPath"].ToString() + " || Error: " + ex.ToString() + (innerexception == "" ? "" : "-- " + innerexception);

				return Json(response);

				throw ex;

			}

            //try
            //{

            //    long size = files.Sum(f => f.Length);
                
            //    // ** TEMP location ** //
            //    //var filePath = Path.GetTempFileName();

            //    var filePath = "";
            //    foreach (var formFile in files)
            //    {
            //        filePath = Path.Combine("/uploads", formFile.FileName);
            //        if (formFile.Length > 0)
            //        {
            //            using (var stream = new FileStream(filePath, FileMode.Create))
            //            {
            //                await formFile.CopyToAsync(stream);
            //            }
            //        }
            //    }
            //    // process uploaded files
            //    // Don't rely on or trust the FileName property without validation.
            //    return Json(new { count = files.Count, size, filePath });
            //    //return Ok(new { count = files.Count, size, filePath });

            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}

        }
		
	}   


    //public interface IFormFile
    //{
    //    string ContentType { get; }
    //    string ContentDisposition { get; }
    //    IHeaderDictionary Headers { get; }
    //    long Length { get; }
    //    string Name { get; }
    //    string FileName { get; }
    //    Stream OpenReadStream();
    //    void CopyTo(Stream target);
    //    Task CopyToAsync(Stream target, CancellationToken cancellationToken = default(CancellationToken));
    //    //Task CopyToAsync(Stream target);
    //}

}
