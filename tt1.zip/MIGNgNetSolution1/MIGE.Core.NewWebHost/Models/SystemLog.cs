namespace MIGE.Core.NewWebHost.Models
{
	public class SystemLog
	{
		public string MessageTemplate { get; set; }
		public object[] MessageParameters { get; set; }
		public LogEventSeverity Severity { get; set; }
		public LogType Type { get; set; }
	}
}
