using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.AspNetCore.Identity;

namespace MIGE.Core.NewWebHost.Models
{
	public class TokenResponseViewModel
	{
		public TokenResponseViewModel() {
		}

		//
		//public string Email { get; set; }
		//public string UserName { get; set; }
		//public string UserId { get; set; }
		//public string SessionId { get; set; }
		//public string APSubjectId { get; set; }
		//public string APGroupId { get; set; }
		//public string QuoteId { get; set; }
		//public string[] Roles { get; set; }
		//public string TransType { get; set; }
        public string Token { get; set; }
		//public decimal EffectiveDate { get; set; }
		//public decimal EndorsementDate { get; set; }
		//public int EndorsementNumber { get; set; }
		//public int Expiration { get; set; }
  //      public dynamic DropDownValues { get; set; }

    }
}
