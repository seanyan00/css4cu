using System.Runtime.Serialization;

namespace MIGE.Core.NewWebHost.Models
{
	public class CustomMessage
	{
		public CustomMessage() {
			NavToRoute = "/error";
		}

		[DataMember]
		public virtual string Title { get; set; }
		[DataMember]
		public virtual string Message { get; set; }
		[DataMember]
		public virtual string StatusCode { get; set; }
		[DataMember]
		public virtual string NavToRoute { get; set; }
	}
}
