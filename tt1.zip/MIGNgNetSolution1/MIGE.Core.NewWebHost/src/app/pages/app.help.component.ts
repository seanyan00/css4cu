import {Component} from '@angular/core';

@Component({
    selector: 'app-help',
    templateUrl: './app.help.component.html',
})
export class AppHelpComponent {

}
