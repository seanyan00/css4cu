import { Injectable } from '@angular/core';
import {  HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
@Injectable()
export class WhatsnewService {

    url: string = "./assets/sample_data/whatsnew.json";
    constructor(private http: HttpClient) { }

    getWhatsNew() {
        return this.http.get(this.url)
            .pipe(map(res => <any[]>res));
    }
}
