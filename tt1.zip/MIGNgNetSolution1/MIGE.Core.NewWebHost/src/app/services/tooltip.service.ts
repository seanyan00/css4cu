import { HttpClient, HttpClientModule, HttpRequest, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { environment } from '@environment/environment';
import { Observable } from 'rxjs';


@Injectable()
export class TooltipService {
    baseUrl:string = "http://localhost:4200";
    private serverAPI = environment.proxyPath;

    constructor(private http: HttpClient) { 
    }

    getTooltips(): Observable<any>{ //currently not used
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'RequestPath': 'GetTooltipValues/'
            })
        };
        return this.http.get(this.serverAPI + 'ProxyGet', httpOptions)
            .pipe(map((response: Response) => response))
	}

	getTooltipsSample(): Observable<any>{
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'RequestPath': 'GetTooltipValues/'
            })
        };
        return this.http.get("./assets/sample_data/tooltips.json", httpOptions)
            .pipe(map((response: Response) => response))
            //.do(data => (console.log(data)))
    }
}

export interface ITooltips { //not used 
    id: string;
    label: string;
}
