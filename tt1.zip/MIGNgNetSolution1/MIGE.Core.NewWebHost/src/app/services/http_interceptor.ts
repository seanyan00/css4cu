import { Injectable } from '@angular/core';
import {
	HttpRequest,
	HttpHandler,
	HttpEvent,
	HttpInterceptor,
	HttpResponse,
	HttpErrorResponse,
} from '@angular/common/http';

import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { MIGSystemService } from '@services/mig.service';


@Injectable()
export class RequestInterceptor implements HttpInterceptor {

	constructor(public migsystemservice: MIGSystemService
    ) { }
  
	intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

		//console.log("Intercepting Request withCredentials=true ");
        request = request.clone({
            withCredentials: true
        });

		return next.handle(request);
		
		// return next.handle(request)
		// 	.pipe(
		// 		tap(
		// 			(event: HttpEvent<any>) => { }, (err: any) => {
		// 				console.log("ERROR!")
		// 				if (err instanceof HttpErrorResponse) {
		// 					console.log("server error");
		// 					this.migsystemservice.notifySystemError(err);
		// 				}
		// 			}
		// 		)
		// 	);
	}
}
