import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { map, tap, catchError, retry, finalize } from 'rxjs/operators';
import { pipe, throwError as observableThrowError, Observable } from 'rxjs';


import { environment } from '@environment/environment';
import { AuthService } from '@auth/auth.service';
import { TokenResponse } from '@auth/tokenresponse.class';


@Injectable({
  providedIn: 'root'
})
export class LansaAcctManagementService {
    
    
  token: TokenResponse;
	//for testing (below)
	sessionid:string = 'L024AF8503FF577012DCF07022019110641';
	//url:string = 'https://secure.merchantsgroup.com:84/cgi-bin/lansaweb?procfun+migactproc+rtn2act+uap+eng+funcparms+mlogsesid(A0350)';
	url:string = environment.lansaAcct;
   
  //sessionid:string = '';
	//url:string = environment.lansaAcct;
  
    constructor(private _http: HttpClient,
                private authService: AuthService) {
      //getAuth Token for sessionid from Lansa
      this.token = authService.getAuth();
      if(this.token !=null){
          this.sessionid = this.token.SessionId;
      }
     }
    
  	public RedirectToAcctManagment(): any {
    
      //console.log('RedirectToAcctManagment service call~');      
      //window.location.href = this.url + this.sessionid;
      
      // **  **  **  **  **  **  **  **  ** 
      //let body = new URLSearchParams();
      //body.set('AMLOGSESID', this.sessionid);
      // //let body = `AMLOGSESID=this.sessionid`;

      // let options = {
      //     headers: new HttpHeaders().set('Content-Type', 'application/x-www-form-urlencoded')
      // };
      
      // this._http
      //     .post(this.url, body,options)
      //     .subscribe(
      //       (res) => {console.log(res)},
      //       (err) => {console.log(err)}
      //     );

      // **  **  **  **  **  **  **  **  ** 
      // let formData = new FormData();
      // formData.append('AMLOGSESID', this.sessionid);
      
      // const httpOptions = {
  		// 	headers: new HttpHeaders({
      //     'Content-Type': 'application/x-www-form-urlencoded',
      //     'responseType': 'text'
      //     //'Access-Control-Allow-Origin': "*"
  		// 	})
      // };
      // this._http.post<any>(this.url,formData).subscribe(
      //   (res) => {console.log(res)},
      //   (err) => {console.log(err)}
      // );     
      
      
      // **  **  **  **  **  **  **  **  ** 
      // const headers = new Headers();
      // headers.append('Accept', 'application/json');
      // headers.append('Content-Type', 'application/x-www-form-urlencoded');
      // //headers.append( 'No-Auth', 'True');
      
      // const body = new URLSearchParams();
      // body.set('AMLOGSESID', this.sessionid);    
      
      // THIS WORKS IN BOTH ie & CHROME USING FIDDLER
      const payload = new HttpParams()
      .set('AMLOGSESID', this.sessionid);

      // return this._http.post(this.url, payload.toString(),{responseType: 'text'}).subscribe(
      //         (res) => {
                
      //           console.log('redirect reposnse? ', res);
      //           //window.location.assign(this.url);
      //         },
      //         (err) => {console.log(err);}
      //     );

      return this._http.post(this.url, payload.toString(),
            {
              withCredentials: true,
              observe: 'response',
              params: payload,
              responseType: 'text',
              reportProgress: true
            }).subscribe(
              (res) => {
                //this.router.navigateByUrl(this.url);
                //console.log('redirect reposnse? ', res);
              },
              (err) => {console.log(err);}
          );

      // **  **  **  **  **  **  **  **  ** 

    }

    private handleError(error: Response) {
  		//console.error('handle Error: ', JSON.stringify(error.toString()));
  		console.error('handle Error: ' + error.toString());
    	return observableThrowError(error.toString() || 'Server error');
    }
}
