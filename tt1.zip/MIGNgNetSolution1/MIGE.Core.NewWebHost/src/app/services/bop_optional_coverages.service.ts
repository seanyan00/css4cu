import { HttpClient, HttpClientModule, HttpRequest, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { environment } from '@environment/environment';
import { Observable } from 'rxjs';

@Injectable()
export class BopOptionalCoveragesService {
    
    constructor(private http: HttpClient) { }

	getScheduledCoverageData(): Observable<any>{
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'RequestPath': 'GetScheduledCoverageData/'
            })
        };
        
        return this.http.get("./assets/sample_data/BOP_ScheduledOptionalCoverages.json", httpOptions)
        .pipe(map((response: Response) => response))
    }
}