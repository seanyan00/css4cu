import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map,tap, catchError, retry, finalize } from 'rxjs/operators';
import { pipe,throwError as observableThrowError, Observable } from 'rxjs';

import { environment } from '@environment/environment';
import { GUIDE } from '@classes/common/BusinessClass/GUIDE';

@Injectable()
export class GuideService {

    //url:string = 'http://dev-net-brn.MIG.local:8083/api/ProductClasses'
    private serverAPI = environment.proxyPath; // <--'http://dev-net-brn.mig.local:8080/api/'

    constructor(private _http: HttpClient) { }
    
    public getGuide(classrequest:GUIDE): Observable<GUIDE[]> {

		const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				'RequestPath': 'ProductClasses/',
				"Access-Control-Allow-Origin": "*"
			})
		};

      return this._http.post(this.serverAPI + 'ProxyPost', classrequest, httpOptions)
			.pipe(
				//retry(3),
				map(res => <GUIDE[]>res),
				// tap(data => {
				// 	console.log('Return All Class => ' + JSON.stringify(data))
				// }),
				catchError(this.handleError));
	}

	//
	private handleError(error: Response) {
		//console.error('handle Error: ', JSON.stringify(error.toString()));
		//console.error('handle Error: ' + error.toString());
		return observableThrowError(error.toString() || 'Server error');
	}
}

