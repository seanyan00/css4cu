
import { throwError as observableThrowError, Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subscription } from 'rxjs';

import { RATING, RATINGRETURN } from '@classes/Common/RATINGRETURN';
import { environment } from '@environment/environment';
import { map, tap, catchError, retry, finalize } from 'rxjs/operators';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { IQuote } from '@interfaces/IQuote';
//import { ObjectMapper } from 'json-object-mapper';

@Injectable()
export class RatingService {

	private serverAPI = environment.proxyPath;
	subscribeStepChanged: Subscription;
    

	constructor(
		private _http: HttpClient
	) { }

	//public GetRating(quote: CTRQuote): Observable<RATING> {
	public GetRating(quote: IQuote): Observable<any> {

		const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				'RequestPath': 'SaveQuoteGetPremium/',
				"Access-Control-Allow-Origin": "*"
			})
		};

		// return this._http.get("./assets/sample_data/ratingreturn.json", httpOptions)
		// .pipe(map((response: Response) => <any>response))
		// //.do(data => (console.log(data)))
		//return this._http.post(this.serverAPI + 'ProxyPost', ObjectMapper.serialize(quote), httpOptions)
		return this._http.post(this.serverAPI + 'ProxyPost', quote, httpOptions)
			.pipe(
				retry(3),
				//map(response => new RATING(response)),
				map(response => <any>response),
				//map((response: Response) => response),
				//tap(data => console.log('Return  Data: ' + JSON.stringify(data))),
				catchError(this.handleError));
	
	}
	
	
	private handleError(error: Response) {
		//console.error('handle Error: ', JSON.stringify(error.toString()));
		console.error('handle Error: ' + error.toString());
		return observableThrowError(error.toString() || 'Server error');
	}

}
