import { HttpClient, HttpClientModule, HttpRequest, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { environment } from '@environment/environment';
import { Observable } from 'rxjs';

@Injectable()
export class DropDownService {
    
    private serverAPI = environment.proxyPath;
    
    constructor(private http: HttpClient) { }

    getDropDowns(): Observable<any>{

        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'RequestPath': 'GetDropDownValues/'
            })
        };

        return this.http.get(this.serverAPI + 'ProxyGet', httpOptions)
            .pipe(map((response: Response) => response))
	}

	getDropDownsSample(lob: string): Observable<any>{
        // 3/4/2021: added lob parameter which indicates which line of business we have, because different LOB's will need different dropdowns/dropdown options. -JTL
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'RequestPath': 'GetDropDownValues/'
            })
        };
        if(lob == "CTR"){
        return this.http.get("./assets/sample_data/dropdowns.json", httpOptions)
            .pipe(map((response: Response) => response))
        }
        if(lob == "WCA"){
            return this.http.get("./assets/sample_data/WCdropdowns.json", httpOptions)
            .pipe(map((response: Response) => response))
        }
        if(lob == "BOP"){
            return this.http.get("./assets/sample_data/BOPdropdowns.json", httpOptions)
            .pipe(map((response: Response) => response))
        }
            //.do(data => (console.log(data)))
    }
}



interface InsuredType {
    label: string;
}
