
import { throwError as observableThrowError, Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { environment } from '@environment/environment';
import { map, tap, catchError, retry } from 'rxjs/operators';

import { IQuote } from '@interfaces/IQuote';

@Injectable()


export class LogService {

	
	private serverAPI = environment.proxyPath;
	constructor(
		private _http: HttpClient,
	) { }

	public sendLogEntry(logentry: LogEntry): Observable<LogEntry> 
	//public sendLogEntry(quote: IQuote, ex:Error, component:string): Observable<string> 
	{
			
			const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				//'RequestPath': 'UISystemLog/',
				'RequestPath': 'UISystemLog/'+ logentry.Error.toString() +'/'+ logentry.UIComponent,
				"Access-Control-Allow-Origin": "*"
			})
		};
		
		//return this._http.post(this.serverAPI + 'ProxyPost', quote, httpOptions)
		return this._http.post(this.serverAPI + 'ProxyPost', logentry.PostData, httpOptions)
			.pipe(
				retry(3),
				map(response => <any>response),
				tap(data => console.log('log response? ', data)),
				catchError(this.handleError)
			);
	}

	private handleError(error: Response) {
		//console.error('handle Error: ' + error.toString());
		return observableThrowError(error.toString() || 'Server error');
	}
	
}

export class LogEntry {
	
	PostData: IQuote;	
	Error: string;
	UIComponent: string;

	constructor (private _postData:IQuote, private _error:string, private _UIComponent:string){
		this.PostData = _postData;
		this.Error = _error;
		this.UIComponent = _UIComponent;
	}
	
}

/* not used but potentially could be

  export class logEntry {
 	MessageTemplate: string;
 	MessageParameters :object [];
 	Severity:number;
	Type:number
 }
export const enum LogEventSeverity
{
	Information = 1,
	Warning = 2,
	Error = 3,
	Fatal = 4
}

export const enum LogType
{
	Access = 1,
	Error = 2
}*/