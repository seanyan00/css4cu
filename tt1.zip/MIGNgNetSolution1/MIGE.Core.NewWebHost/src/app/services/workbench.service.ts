
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
@Injectable()
export class WorkbenchService {

	constructor(private http: HttpClient) { }

	getWorkbench() {
		return this.http.get("http://dev.mig.local:6060/MIGECoreAPI/api/agentquote/get")
			.pipe(map(res => <Workbench[]>res));
	}
}

export interface Workbench {
	POLICY;
	AQACCTID;
	AQASSIGN;
	EFFDTE;
	name;
	AGENT;
	TOTPRM;
	AQDESC;
	WBSTCD;
	LastModifiedBy;
}
