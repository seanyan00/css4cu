import { throwError as observableThrowError, Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { AuthService } from '@auth/auth.service';

import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { environment } from '@environment/environment';
import { map, tap, catchError, retry, finalize } from 'rxjs/operators';
import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';
import { IQuote } from '@interfaces/IQuote';
//import { ObjectMapper } from 'json-object-mapper';

@Injectable()
export class QuoteService {

	private serverAPI = environment.proxyPath;
	//private serverAPI: string = "./assets/sample_data/ctrquote.json";
	//testquote: CTRQuote;
    private serviceQuoteRef: IQuote;

	constructor(
		private _http: HttpClient,
		private authService: AuthService

	) { }
    
    public setServiceReferenceToQuote(incomingQuote: IQuote)
    {
        this.serviceQuoteRef = incomingQuote;
    }

	public GetQuote(quote: IQuote): Observable<IQuote> {
		const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				'RequestPath': 'GetQuote/',
				"Access-Control-Allow-Origin": "*"
			})
        };
        
		//return this._http.post(this.serverAPI + 'ProxyPost', ObjectMapper.serialize(quote), httpOptions)
		return this._http.post(this.serverAPI + 'ProxyPost', quote, httpOptions)
            .pipe
            (
				retry(3),
				map((response: IQuote) => response),
				//tap(data => console.log('getquote? ', JSON.stringify(data))),
                catchError(this.handleError)
            );
    }
    
    public CopyQuote(quote: IQuote): Observable<IQuote> {
		const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				'RequestPath': 'CopyQuote/',
				"Access-Control-Allow-Origin": "*"
			})
        };
        
		//return this._http.post(this.serverAPI + 'ProxyPost', ObjectMapper.serialize(quote), httpOptions)
		return this._http.post(this.serverAPI + 'ProxyPost', quote, httpOptions)
            .pipe
            (
				map((response: IQuote) => response),
                catchError(this.handleError)
            );
	}

	public GetQuoteTestJson(quote: CTRQuote): Observable<CTRQuote> {

		const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				'RequestPath': 'GetQuoteTestJson/',
				"Access-Control-Allow-Origin": "*"
			})
		};

		//return this._http.post(this.serverAPI + 'ProxyPost', ObjectMapper.serialize(quote), httpOptions)
		return this._http.post(this.serverAPI + 'ProxyPost', quote, httpOptions)
			.pipe(
				map(response => <any>response),
				// map((response: Response) => response),
				catchError(this.handleError)
			);
	}

	public SaveQuote(quote: IQuote, lob?: string): Observable<IQuote> {
				
		const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				'RequestPath': 'SaveQuote/',
				"Access-Control-Allow-Origin": "*"
			})
		};
	
		
		//return this._http.post(this.serverAPI + 'ProxyPost', ObjectMapper.serialize(quote), httpOptions)
		return this._http.post(this.serverAPI + 'ProxyPost', quote, httpOptions)
			.pipe(
				finalize(() => {
					//console.log("quote saved ran from quote.service.ts");
				}),
				map(response => <CTRQuote>response),
				// map((response: Response) => response),
				//tap(data => //console.log('Return Quote Data: ' + JSON.stringify(data))),
				catchError(this.handleError));

	}

	public ReferToComapny(quote: IQuote): Observable<string> {
		const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				'RequestPath': 'ReferToComapny/',
				"Access-Control-Allow-Origin": "*"
			})
        };
        
		//return this._http.post(this.serverAPI + 'ProxyPost', ObjectMapper.serialize(quote), httpOptions)
		return this._http.post(this.serverAPI + 'ProxyPost', quote, httpOptions)
            .pipe
            (
				retry(3),
				map(response => <any>response),
                catchError(this.handleError)
            );
	}

	public ReleaseQuote(quote: CTRQuote): Observable<string> {
		const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				'RequestPath': 'ReleaseQuote/',
				"Access-Control-Allow-Origin": "*"
			})
        };
        
		//return this._http.post(this.serverAPI + 'ProxyPost', ObjectMapper.serialize(quote), httpOptions)
		return this._http.post(this.serverAPI + 'ProxyPost', quote, httpOptions)
            .pipe
            (
				retry(3),
				map(response => <any>response),
                catchError(this.handleError)
            );
	}

	public SendAttachmentNoticeToUW(quotePolicyInformation: QUOTEPOLICYINFO): Observable<any[]> {
		const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				'RequestPath': 'SendAttachmentNoticeToUW/',
				"Access-Control-Allow-Origin": "*"
			})
        };
        
		return this._http.post(this.serverAPI + 'ProxyPost', quotePolicyInformation, httpOptions)
            .pipe
            (
				retry(3),
				map(response => <any[]>response),
                catchError(this.handleError)
            );
	}

	public QuoteEFFDTEChange(quote: IQuote): Observable<IQuote> {
				
		const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				'RequestPath': 'QuoteEFFDTEChange/',
				"Access-Control-Allow-Origin": "*"
			})
		};
		//return this._http.post(this.serverAPI + 'ProxyPost', ObjectMapper.serialize(quote), httpOptions)
		return this._http.post(this.serverAPI + 'ProxyPost', quote, httpOptions)
			.pipe(
				finalize(() => {
					//console.log("quote saved QuoteEFFDTEChange");
				}),
				map(response => <CTRQuote>response),
				// map((response: Response) => response),
				//tap(data => console.log('QuoteEFFDTEChange return Data: ' + JSON.stringify(data))),
				catchError(this.handleError));

	}
	//
	private handleError(error: Response) {
		//console.error('handle Error: ', JSON.stringify(error.toString()));
		console.error('handle Error: ' + error.toString());
		return observableThrowError(error.toString() || 'Server error');
	}

}
