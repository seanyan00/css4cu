
import { throwError as observableThrowError, Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { environment } from '@environment/environment';
import { map, tap, catchError, retry, finalize } from 'rxjs/operators';
import { IQuote } from '@interfaces/IQuote';

@Injectable()
export class PolicyService {

	private serverAPI = environment.proxyPath;
	testquote: CTRQuote;

	constructor(
		private _http: HttpClient,
	) { }
	public GetPolicy(quote: IQuote): Observable<IQuote> {
		const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				'RequestPath': 'GetPolicy/',
				"Access-Control-Allow-Origin": "*"
			})
		};
		return this._http.post(this.serverAPI + 'ProxyPost', quote, httpOptions)
			.pipe(
				retry(3),
				map((response: IQuote) => response),
				catchError(this.handleError));
    }
    
	private handleError(error: Response) {
		//console.error('handle Error: ', JSON.stringify(error.toString()));
		console.error('handle Error: ' + error.toString());
		return observableThrowError(error.toString() || 'Server error');
	}

}
