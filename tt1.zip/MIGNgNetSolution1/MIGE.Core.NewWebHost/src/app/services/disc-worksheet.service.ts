import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AuthService } from '@auth/auth.service';
import { environment } from '@environment/environment';
import { Observable,throwError as observableThrowError } from 'rxjs';
import { catchError, finalize, map, tap } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})

export class DiscWorksheetService {

  private serverAPI = environment.proxyPath;
  
  constructor(private http: HttpClient,
		          private authService: AuthService) { 

    }

    getData() { 
      return this.http.get("./assets/sample_data/disc-worksheet.json")
          .pipe(map(res => <any[]>res));
    }


    getDiscWorkSheetSample(): Observable<any>{

      const httpOptions = {
          headers: new HttpHeaders({
              'Content-Type': 'application/json',
              'RequestPath': 'getDiscWorkSheetSample/'
          })
      };

      return this.http.get("./assets/sample_data/disc-worksheet3.json", httpOptions)
      .pipe(
				map(res => <any[]>res),
				tap(data => { 
					//console.log('Return Data => ' + JSON.stringify(data))
				}),
				//catchError((e) => this.handleError(e))
			);
  }


  getDiscWorkSheetData(PolicyInfo:any): Observable<any>{
  //getDiscWorkSheetData(state:string): Observable<any>{

    const httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'RequestPath': 'GetRisksByState/',
            "Access-Control-Allow-Origin": "*"
        })
    };

    return this.http.post(this.serverAPI + 'ProxyPost', PolicyInfo, httpOptions)
    //return this.http.post(this.serverAPI + 'ProxyPost', state, httpOptions)
      .pipe(
        //retry(3),
        map(res => <any[]>res),
        // tap(data => { 
				// 	console.log('Return Data => ' + JSON.stringify(data))
				// }),
        catchError(this.handleError))
  };

  private handleError(error: Response) {
    //console.error('handle Error: ', JSON.stringify(error.toString()));
    console.error('handle Error: ' + error.toString());
    return observableThrowError(error.toString() || 'Server error');
  }


  saveDiscretionaryWorksheet(DiscObjData:any): Observable<any>{
    const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				'RequestPath': 'SaveDiscretionaryWorkSheet/',
				"Access-Control-Allow-Origin": "*"
			})
		};

    return this.http.post(this.serverAPI + 'ProxyPost', DiscObjData, httpOptions)
			.pipe(
				//finalize(() => {}),
				map(response => <any[]>response),			
				// tap(data => { 
				// 	console.log('Return Data => ' + JSON.stringify(data))
				// }),
				catchError(this.handleError));
    
  }

}
