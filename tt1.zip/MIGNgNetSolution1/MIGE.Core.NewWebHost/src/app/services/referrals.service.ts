import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map, tap, catchError, retry, finalize } from 'rxjs/operators';
import { pipe, throwError as observableThrowError, Observable } from 'rxjs';


import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { environment } from '@environment/environment';



@Injectable()
export class ReferralsService {
	private serverAPI = environment.proxyPath;

	constructor(private _http: HttpClient) { }

	public GetReferrals(quote: CTRQuote): Observable<CTRQuote> {
		const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				'RequestPath': 'GetUWReferrals/',
				"Access-Control-Allow-Origin": "*"
			})
		};
		return this._http.post(this.serverAPI + 'ProxyPost', quote, httpOptions)
			.pipe(
				retry(3),
				//tap(data=>{console.log('Return All Refs => ' + JSON.stringify(data))}),
				map(response => <any>response),
								catchError(this.handleError));
	}

	private handleError(error: Response) {
		//console.error('handle Error: ', JSON.stringify(error.toString()));
		//console.error('handle Error: ' + error.toString());
		return observableThrowError(error.toString() || 'Server error');
	}
}
