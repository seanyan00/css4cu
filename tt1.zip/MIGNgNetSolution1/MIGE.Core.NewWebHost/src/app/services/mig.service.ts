
import { Injectable } from '@angular/core';
import { Observable, Subject, BehaviorSubject, ObservableLike, ReplaySubject } from 'rxjs';
//import { MIGMenu } from '@root/system/menu/menu.class';
import { NotifyClass } from '@root/shared_components/notify/notify.class';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { IQuote } from '@interfaces/IQuote';
//import { QUOTEBASECLASS } from '@classes/Common/QUOTEBASECLASS';
//import { isQuote } from '@angular/compiler';
import { CommonQuote } from '@classViewModels/CommonQuote/CommonQuote';
import { WCAQuote } from '@classViewModels/WCA/WCAQuote';
import { WCASTATES } from '@classes/WCA/WCAStates';

@Injectable()
export class MIGSystemService {

	// Menu collapse or expand = true or false
	private subjectToggleMenu = new Subject<any>();
	notifyToggleMenu(toggle: boolean = false) { this.subjectToggleMenu.next(); }
	subscribeToggleMenu(): Observable<any> { return this.subjectToggleMenu.asObservable(); }

	// RHS collapse or expand = true or false
	private subjectToggleRHS = new Subject<any>();
	notifyToggleRHS(toggle: boolean = false) { this.subjectToggleRHS.next(); }
	subscribeToggleRHS(): Observable<any> { return this.subjectToggleRHS.asObservable(); }

	// go to step of process = number of step
	private subjectGoToStep = new Subject<any>();
	notifyGoToStep(step: number) { this.subjectGoToStep.next(step); }
	subscribeGoToStep(): Observable<any> { return this.subjectGoToStep.asObservable(); }

	private subjectGoToSubStep = new Subject<any>();
	notifyGoToSubStep(step: number) { this.subjectGoToSubStep.next(step); }
	subscribeGoToSubStep(): Observable<any> { return this.subjectGoToSubStep.asObservable(); }

	private subjectGoToSubStepLocation = new Subject<any>();
	notifyGoToSubStepLocation(step: number) { this.subjectGoToSubStepLocation.next(step); }
	subscribeGoToSubStepLocation(): Observable<any> { return this.subjectGoToSubStepLocation.asObservable(); }

	// // inject menu object = object
	// // store quote menu structure in quote component
	// // and inject it into our central menu system
	// private subjectInjectMenu = new Subject<any>();
	// notifyInjectMenu(menu: MIGMenu) { this.subjectInjectMenu.next(menu); }
	// subscribeInjectMenu(): Observable<MIGMenu> { return this.subjectInjectMenu.asObservable(); }

	// Save Quote
	private subjectSaveQuote = new Subject<IQuote>();
	notifySaveQuote(redirect:any) { this.subjectSaveQuote.next(redirect); }
	subscribeSaveQuote(): Observable<IQuote> { return this.subjectSaveQuote.asObservable(); }

	// private subjectSaveWCAQuote = new Subject<WCAQuote>();
	// notifySaveWCAQuote(redirect:any) { this.subjectSaveWCAQuote.next(redirect); }
	// subscribeSaveWCAQuote(): Observable<WCAQuote> { return this.subjectSaveWCAQuote.asObservable(); }

	// Notify Quote Saved
	private subjectSystemNotification = new Subject<any>();
	notifySystemNotification(msg: NotifyClass) { this.subjectSystemNotification.next(msg); }
	subscribeSystemNotification(): Observable<any> { return this.subjectSystemNotification.asObservable(); }

	// Show Hide Buttons
	private subjectButtons = new Subject<any>();
	notifyButtons(step: number) { this.subjectButtons.next(step); }
	subscribeButtons(): Observable<any> { return this.subjectButtons.asObservable(); }

	// Notify Premium
	private subjectPremium = new Subject<any>();
	notifyPremium(premium: number) { this.subjectPremium.next(premium); }
	subscribePremium(): Observable<any> { return this.subjectPremium.asObservable(); }

	// display a system message
	private subjectSystemMessage = new Subject<any>();
	notifySystemMessage(arr: {}) { this.subjectSystemMessage.next(arr); }
	subscribeSystemMessage(): Observable<any> { return this.subjectSystemMessage.asObservable(); }


	// display block / loading message
	private subjectBlock = new Subject<any>();
	notifyBlock(arr: {}) { this.subjectBlock.next(arr); }
	subscribeBlock(): Observable<any> { return this.subjectBlock.asObservable(); }

	// validate step
	private subjectValidate = new Subject<any>();
	notifyValidate(step: number) { this.subjectValidate.next(step); }
	subscribeValidate(): Observable<any> { return this.subjectValidate.asObservable(); }

	// Update help content
	private subjectInjectHelp = new Subject<any>();
	notifyInjectHelp(info: {}) { this.subjectInjectHelp.next(info); }
	subscribeInjectHelp(): Observable<any> { return this.subjectInjectHelp.asObservable(); }

	// Add New Location
	private subjectAddLocation = new Subject<any>();
	notifyAddLocation() { this.subjectAddLocation.next(); }
	subscribeAddLocation(): Observable<any> { return this.subjectAddLocation.asObservable(); }

	private subjectGoToACTab = new Subject<any>();
	notifyGoToACTab(tab: number) { this.subjectGoToACTab.next(tab); }
	subscribeGoToACTab(): Observable<any> { return this.subjectGoToACTab.asObservable(); }

	private subjectIsMobile = new Subject<any>();
	notifyIsMobile(val: boolean) { this.subjectIsMobile.next(val); }
	subscribeIsMobile(): Observable<any> { return this.subjectIsMobile.asObservable(); }

	private subjectStepChanged = new Subject<any>();
	notifyStepChanged(step: number) { this.subjectStepChanged.next(step); }
	subscribeStepChanged(): Observable<any> { return this.subjectStepChanged.asObservable(); }

	// Add Attachments
	private subjectAttachments = new Subject<any>();
	notifyShowAttachmentsDialog(val: any) { this.subjectAttachments.next(val); }
	subscribeShowAttachmentsDialog(): Observable<any> { return this.subjectAttachments.asObservable(); }

	// Show Additional Coverages > Property
	private subjectACProperty = new Subject<any>();
	notifyShowACProperty(show: boolean) { this.subjectACProperty.next(show); }
	subscribeShowACProperty(): Observable<any> { return this.subjectACProperty.asObservable(); }

	// notification to validate the form
	private subjectValidateForm = new BehaviorSubject<boolean>(false);
	notifyValidateForm(val: boolean) { this.subjectValidateForm.next(val); }
	subscribeValidateForm(): Observable<any> { return this.subjectValidateForm.asObservable(); }

	// there was a system error be it http request or otherwise
	// tell the user about it
	private subjectSystemError = new Subject<any>();
	notifySystemError(err: any) { this.subjectSystemError.next(err); }
	subscribeSystemError(): Observable<any> { return this.subjectSystemError.asObservable(); }

	// get and set our system version
	private subjectSystemVersion = new Subject<any>();
	notifySystemVersion() { this.subjectSystemVersion.next(); }
	subscribeSystemVersion(): Observable<any> { return this.subjectSystemVersion.asObservable(); }

	// CTRquote changed
	// some components need to know this happened; let them know
	// private subjectQuoteChanged = new Subject<IQuote>();
	// notifyQuoteChanged(quote: IQuote) { this.subjectQuoteChanged.next(quote); }
	// subscribeQuoteChanged(): Observable<IQuote> { return this.subjectQuoteChanged.asObservable(); }
	private subjectQuoteChanged = new BehaviorSubject<CTRQuote>(new CTRQuote());
	notifyQuoteChanged(quote: CTRQuote) { this.subjectQuoteChanged.next(quote); }
	subscribeQuoteChanged(): Observable<CTRQuote> { return this.subjectQuoteChanged.asObservable(); }

	// private subjectWCAQuoteChanged = new BehaviorSubject<WCAQuote>(new WCAQuote());
	// notifyWCAQuoteChanged(quote: WCAQuote) { this.subjectWCAQuoteChanged.next(quote); }
	// subscribeWCAQuoteChanged(): Observable<WCAQuote> { return this.subjectWCAQuoteChanged.asObservable(); }

	private subjectGetWCAQuote = new BehaviorSubject<any>(new WCAQuote); // had to change this function to be WCA specific in order for the state screen to get the State Object. we should probably find another way to get the state info and keep this function quote independent. -JTL
	notifyGetWCAQuote(quote: WCAQuote) { this.subjectGetWCAQuote.next(quote); }
	subscribeGetWCAQuote(): Observable<WCAQuote> { return this.subjectGetWCAQuote.asObservable(); }

	private subjectGetWCAQuoteStates = new BehaviorSubject<WCASTATES[]>([]); // had to change this function to be WCA specific in order for the state screen to get the State Object. we should probably find another way to get the state info and keep this function quote independent. -JTL
	notifyGetWCAQuoteStates(quote: WCASTATES[]) { this.subjectGetWCAQuoteStates.next(quote); }
	subscribeGetWCAQuoteStates(): Observable<WCASTATES[]> { return this.subjectGetWCAQuoteStates.asObservable(); }


	private subjectGetQuote = new BehaviorSubject<any>(new CommonQuote); // currently used for all LOB's to display info on right nav
	notifyGetQuote(quote: IQuote) { this.subjectGetQuote.next(quote); }
	subscribeGetQuote(): Observable<IQuote> { return this.subjectGetQuote.asObservable(); }

	// next button triggers this
	// used to notify components to update their WINS keys
	private subjectUpdateRecordState = new Subject<any>();
	notifyUpdateRecordState() { this.subjectUpdateRecordState.next(); }
	subscribeUpdateRecordState(): Observable<any> { return this.subjectUpdateRecordState.asObservable(); }

	private subjectGotoSubStepMain = new Subject<any>();
	notifyGotoSubStepMain() { this.subjectGotoSubStepMain.next(); }
    subscribeGotoSubStepMain(): Observable<any> { return this.subjectGotoSubStepMain.asObservable(); }
    
    private subjectAutoRecoverFromError = new Subject<any>();
    notifyAutoRecoverFromError() { this.subjectAutoRecoverFromError.next(); }
    subscribeAutoRecoverFromError(): Observable<any> { return this.subjectAutoRecoverFromError.asObservable(); }

    private subjectCopyQuote = new Subject<any>();
    notifyCopyQuote() { this.subjectCopyQuote.next(); }
    subscribeCopyQuote(): Observable<any> { return this.subjectCopyQuote.asObservable(); }

	private subjectToastMessagesAdded = new Subject<any>();
    notifyToastMessagesAdded(shouldDisplay: boolean) { this.subjectToastMessagesAdded.next(shouldDisplay); }
	subscribeToastMessagesAdded(): Observable<any> { return this.subjectToastMessagesAdded.asObservable(); }
	
	private subjectToastMessagesCleared = new Subject<any>();
    notifyToastMessagesCleared() { this.subjectToastMessagesCleared.next(); }
	subscribeToastMessagesCleared(): Observable<any> { return this.subjectToastMessagesCleared.asObservable(); }

	private subjectNextClicked = new Subject<any>();
	//going to pass the error object in and add the business rule errors to it.
    notifyNextClicked(errors: any) { this.subjectNextClicked.next(errors); }
	subscribeNextClicked(): Observable<any> { return this.subjectNextClicked.asObservable(); }

	private subjectXClicked = new Subject<any>();
    notifyXClicked() { this.subjectXClicked.next(); }
	subscribeXClicked(): Observable<any> { return this.subjectXClicked.asObservable(); }
	
	private subjectLessortsRisk = new Subject<any>();
    notifyLessorsRiskAdd(type:any) { this.subjectLessortsRisk.next(type); }
	subscribeLessorsRiskAdd(): Observable<any> { return this.subjectLessortsRisk.asObservable(); }
	
	//notifies of any errors in the Form Validation
	private subjectNotifyError = new Subject<any>();
	notifyError(messages: any) {this.subjectNotifyError.next(messages);}
	subscribeNotifyError(): Observable<any> {return this.subjectNotifyError.asObservable();}

	private subjectNotifyBackClicked = new Subject<any>();
	notifyBackClicked() {this.subjectNotifyBackClicked.next();}
	subscribeBackClicked(): Observable<any>{return this.subjectNotifyBackClicked.asObservable();}

	private subjectDoneClicked = new BehaviorSubject<any>([]);
	//going to pass the error object in and add the business rule errors to it.
	notifyDoneClicked(errors?: any) { this.subjectDoneClicked.next(errors); }
	subscribeDoneClicked(): Observable<any> { return this.subjectDoneClicked.asObservable(); } 

	//notifies of any errors in the Business Rules
	private subjectNotifyBRRError = new ReplaySubject<any>();
	notifyBRRError(messages: any) {this.subjectNotifyBRRError.next(messages);}
	subscribeNotifyBRRError(): Observable<any> {return this.subjectNotifyBRRError.asObservable();}

	private subjectNotifyBRRRules = new Subject<any>();
	notifyBRRRules(needToWait: boolean) {this.subjectNotifyBRRRules.next(needToWait);}
	subscribeNotifyBRRRules(): Observable<any> {return this.subjectNotifyBRRRules.asObservable();}
	
	private subjectNotifyNOLSINDChange = new BehaviorSubject<string>('');
	notifyNOLSINDChange(value: string) {this.subjectNotifyNOLSINDChange.next(value);}
	subscribeNOLSINDChange(): Observable<string> {return this.subjectNotifyNOLSINDChange.asObservable();}

	private subjectNotifyEditClicked = new BehaviorSubject<boolean>(false);
	notifyEditClicked (value: boolean) {this.subjectNotifyEditClicked.next(value);}
    subscribeEditClicked (): Observable<boolean> {return this.subjectNotifyEditClicked.asObservable();}
    
    private subjectGetQuoteNow = new Subject<any>();
	notifyGetQuoteNow() {this.subjectGetQuoteNow.next();}
    subscribeGetQuoteNow(): Observable<any> {return this.subjectGetQuoteNow.asObservable();}
    
    private subjectFirstLocationStateChanged = new Subject<boolean>();
	notifyFirstLocationStateChanged() {this.subjectFirstLocationStateChanged.next();}
	subscribeFirstLocationStateChanged(): Observable<any> {return this.subjectFirstLocationStateChanged.asObservable();}
	
	private subjectAddInsureds = new BehaviorSubject<boolean>(false);
	notifyAddInsureds(value: boolean) {this.subjectAddInsureds.next(value);}
	subscribeAddInsureds(): Observable<any> {return this.subjectAddInsureds.asObservable();}

	private subjectWindZone = new Subject<any>(); 
	//this is used for the Location Summary page and the app.footer and app.menu to communicate the windzone return from the territory call
	notifyWindZone(windZone: number) {this.subjectWindZone.next(windZone);}
    subscribeWindZone(): Observable<any> { return this.subjectWindZone.asObservable(); }

    private subjectUpdateRightNav = new Subject<any>();
    // this is used to send data from the main application to the right nav. This can be used to update data on the right panel.
    notifyUpdateRightNav(data: any) { this.subjectUpdateRightNav.next(data); }
    subscribeUpdateRightNav(): Observable<any> { return this.subjectUpdateRightNav.asObservable(); }

	private subjectDPWorksheet = new Subject<any>(); 
	//this is used for the 
	notifyDPWorksheet(AmountRemaining: number) {this.subjectDPWorksheet.next(AmountRemaining);}
	subscribeDPWorksheet(): Observable<any> {return this.subjectDPWorksheet.asObservable();}

	private subjectEditBusinessClass = new Subject<any>(); // used by the app footer and menu to communicate with the WCA Business Class component. 
	notifyEditBusinessClass() {this.subjectEditBusinessClass.next();}
    subscribeEditBusinessClass(): Observable<any> {return this.subjectEditBusinessClass.asObservable();}

	private subjectShareQuote = new BehaviorSubject<any>(new CommonQuote); // used to share quote data with footer and menu
	notifyShareQuote(quote: IQuote) { this.subjectShareQuote.next(quote); }
	subscribeShareQuote(): Observable<IQuote> { return this.subjectShareQuote.asObservable(); }
	private subjectDPWorksheetSaved = new BehaviorSubject<boolean>(false);
	notifyDPWorksheetSaved(value: boolean) {this.subjectDPWorksheetSaved.next(value);}
	subscribeDPWorksheetSaved(): Observable<any> {return this.subjectDPWorksheetSaved.asObservable();}

	private subjectDisableMenu = new Subject<any>(); 
	notifyDisableMenu(bool: boolean) {this.subjectDisableMenu.next(bool);}
    subscribeDisableMenu(): Observable<any> { return this.subjectDisableMenu.asObservable(); }

	private subjectEditingLoc = new Subject<any>(); // this is used to let the footer know whether or not we are in an "Edit Location" state
	notifyEditingLoc(bool: boolean) {this.subjectEditingLoc.next(bool);}
    subscribeEditingLoc(): Observable<any> { return this.subjectEditingLoc.asObservable(); }

	private subjectGetFireDistricts = new Subject<any[]>();
	notifyGetFireDistricts(districts: any[]) {this.subjectGetFireDistricts.next(districts) } 
	subscribeGetFireDistricts(): Observable<any> { return this.subjectGetFireDistricts.asObservable(); }
	
}
