import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map, tap, catchError, retry, finalize } from 'rxjs/operators';
import { pipe, throwError as observableThrowError, Observable } from 'rxjs';
//import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
//import { UWQUESTIONSCATEGORY } from '@classes/Common/UWQuestionClasses/UWQUESTIONCATEGORY';
import { IQuote } from '@interfaces/IQuote';
import { environment } from '@environment/environment';
import { ISubcontractorClasses } from '@interfaces/ISubcontractorClasses';


@Injectable()
export class UnderwritingService {


	url: string = "./assets/sample_data/UWQuestions3.json";
	//url:string = 'http://dev-net-brn.MIG.local:8083/api/GetSaveUWQuestionsUsingQuote'
	private serverAPI = environment.proxyPath; // <--'http://dev-net-brn.mig.local:8080/api/'
	


	constructor(private _http: HttpClient) { }


	public getUWQuestions(quote: IQuote): Observable<IQuote> {

		const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				'RequestPath': 'GetSaveUWQuestionsUsingQuote/',
				"Access-Control-Allow-Origin": "*"
			})
		};

		return this._http.post(this.serverAPI + 'ProxyPost', quote, httpOptions)
			.pipe(
				retry(3),
				map(res => <IQuote>res),
				//tap(data=>(console.log('SERVICE UWData: ' + JSON.stringify(data)))),
				catchError(this.handleError));
	}

	public getUWQSubcontractorClasses(): Observable<ISubcontractorClasses> {
		const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				'RequestPath': 'UWQSubcontractorClasses/',
				'Access-Control-Allow-Origin': '*'
			})
		};

		return this._http.post(this.serverAPI + 'ProxyPost', null, httpOptions)
			.pipe(
				retry(3),
				map(res => <ISubcontractorClasses> res),
				//tap(data => console.log('Subcontractors: ' + data)),
				catchError(this.handleError)
			);
	}
	// public getUWQuestions(quote: CTRQuote): Observable<UWQUESTIONSCATEGORY[]> {

	// 	const httpOptions = {
	// 		headers: new HttpHeaders({
	// 			'Content-Type': 'application/json',
	// 			'RequestPath': 'GetSaveUWQuestionsUsingQuote/',
	// 			"Access-Control-Allow-Origin": "*"
	// 		})
	// 	};

	// 	return this._http.post(this.serverAPI + 'ProxyPost', quote, httpOptions)
	// 		.pipe(
	// 			retry(3),
	// 			map(res => <UWQUESTIONSCATEGORY[]>res),
	// 			//tap(data=>(console.log('SERVICE UWData: ' + JSON.stringify(data)))),
	// 			catchError(this.handleError));
	// }

	//
	private handleError(error: Response) {
		//console.error('handle Error: ', JSON.stringify(error.toString()));
		console.error('handle Error: ' + error.toString());
		return observableThrowError(error.toString() || 'Server error');
	}
}
