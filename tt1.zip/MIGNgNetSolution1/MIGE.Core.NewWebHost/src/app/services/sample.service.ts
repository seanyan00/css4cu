import { HttpClient, HttpClientModule, HttpRequest, HttpHeaders } from '@angular/common/http';



import { Injectable } from '@angular/core';


import { environment } from '@environment/environment';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
@Injectable()
export class SampleService {

    private serverAPI = environment.proxyPath;

    constructor(private http: HttpClient) { }

    getSample(url): Observable<any>{

        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'RequestPath': 'GetDropDownValues/'
            })
        };

        return this.http.get(url)
            .pipe(map((response: Response) => response))
            //.do(data => (console.log(data)))
    }
}

interface InsuredType {
    label: string;
}
