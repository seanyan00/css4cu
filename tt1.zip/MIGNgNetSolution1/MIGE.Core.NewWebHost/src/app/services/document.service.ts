
import { throwError as observableThrowError, Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subscription } from 'rxjs';

import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';
import { environment } from '@environment/environment';
import { map, tap, catchError, retry, finalize } from 'rxjs/operators';
import { AuthService } from '@auth/auth.service';


@Injectable()
export class DocumentService {

	private serverAPI = environment.proxyPath;
	subscribeStepChanged: Subscription;
    

	constructor(
		private _http: HttpClient,
		private authService: AuthService
	) { }

    public GenerateDocument(quotePolicyInformation: QUOTEPOLICYINFO, documentType: string): Observable<any> {
		const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				'RequestPath': 'Generate' + documentType + '/',
				"Access-Control-Allow-Origin": "*"
			})
		};

		return this._http.post(this.serverAPI + 'ProxyPost', quotePolicyInformation, httpOptions)
			.pipe(
				retry(3),
				map(response => <any>response),
				catchError(this.handleError));	
    }

    public GetDocument(proposalFileName: string, documentType: string): Observable<string> {

		const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
                'RequestPath': 'Get' + documentType + '/',
				"Access-Control-Allow-Origin": "*"
			})
		};

		return this._http.post(this.serverAPI + 'ProxyPost', JSON.stringify(proposalFileName), httpOptions)
			.pipe(
				retry(3),
				map(response => <any>response),
				catchError(this.handleError));
	}
	
	public GetPolicyDocument(quotePolicyInformation: QUOTEPOLICYINFO, documentType: string){
		
		const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				'RequestPath': 'Get' + documentType + '/',
				"Access-Control-Allow-Origin": "*"
			})
		};

		return this._http.post(this.serverAPI + 'ProxyPost', quotePolicyInformation, httpOptions)
			.pipe(
				retry(3),
				map(response => <any>response),
				catchError(this.handleError));
	}
	private handleError(error: Response) {
		//console.error('handle Error: ', JSON.stringify(error.toString()));
		console.error('handle Error: ' + error.toString());
		return observableThrowError(error.toString() || 'Server error');
	}

}
