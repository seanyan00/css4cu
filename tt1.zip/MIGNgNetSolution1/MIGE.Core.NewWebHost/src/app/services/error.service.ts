import { EventEmitter } from "@angular/core";
import { UntypedFormGroup } from '@angular/forms';

export class ErrorService {
	errors: EventEmitter<any> = new EventEmitter();
	dynamicErrors: EventEmitter<any> = new EventEmitter();
	businessRulesErrors: EventEmitter<any> = new EventEmitter();
	constructor() { }
	
	//for universal errors
	emitErrorsEvent(form: UntypedFormGroup) {
		this.errors.emit(form);
	}

	// for underwriting question
	emitErrorsDynamicEvent(formdata: any) {
		this.dynamicErrors.emit(formdata);
	}
	//for property coverage
	emitBusinessRulesErrorsEvent(form: any){
		this.businessRulesErrors.emit(form);
	}
	getErrorsEmitter() {
		return this.errors;
	}

	getErrorsDynamicEmitter(){
		return this.dynamicErrors;
	}

	getBusinessRulesErrorsEmitter(){
		return this.businessRulesErrors;
	}
}
