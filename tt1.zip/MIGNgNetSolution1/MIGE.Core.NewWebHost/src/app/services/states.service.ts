import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { AuthService } from '@auth/auth.service';
@Injectable()

// produces a list of states we work in
export class StatesService {

	urlStatesFull: string = "./assets/sample_data/states_full.json";
    urlStates: string = "./assets/sample_data/states.json";
    urlDiscPricingScheduleStateMinimums: string;// = "./assets/sample_data/disc_pricing_schedule_state_vals.json";
	constructor(private http: HttpClient,
		private authService: AuthService) { }

	getStatesFull() {
		return this.http.get(this.urlStatesFull)
			.pipe(map(res => <States[]>res));
	}

	getStates() {
		return this.http.get(this.urlStates)
			.pipe(map(res => <States[]>res));
    }
    
    getDiscPricingScheduleStateMinimums() {
		if(this.authService.LOB == "CTR"){
			this.urlDiscPricingScheduleStateMinimums = "./assets/sample_data/disc_pricing_schedule_state_vals.json";
		}
		if(this.authService.LOB == "WCA"){
			this.urlDiscPricingScheduleStateMinimums = "./assets/sample_data/WCA_disc_pricing_schedule_state_vals.json";
		}
        return this.http.get(this.urlDiscPricingScheduleStateMinimums)
            .pipe(map(res => <any> res));
    }
}

export interface States {
	label;
	value;
	merchants;
}
