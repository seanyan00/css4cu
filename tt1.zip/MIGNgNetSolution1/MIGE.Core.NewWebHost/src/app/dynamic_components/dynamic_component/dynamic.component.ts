/* NG Includes */
import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectorRef, ViewEncapsulation, OnDestroy } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, UntypedFormControl, Validators } from '@angular/forms';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { environment } from '@environment/environment';
import { InputMasksClass } from '@helpers/masks';
import { MIGSystemService } from '@root/services/mig.service';
import { MenuClass } from '@root/system/menu/menu';
import { Functions } from '@helpers/functions';
import { DynamicValidator } from './dynamic.validator';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { UnderwritingService } from '@root/services/underwriting.service';
import { ISubcontractorClasses } from '@interfaces/ISubcontractorClasses';
import { IQuote } from '@interfaces/IQuote';


/******************************************************************************************************
     * PROGRAM DESCRIPTION  - Dynamic component used for underwriting questions 
     * NOTES                - RRF 2019-07-11 - Updated NgOnInit to check for single space on UWQuestion Answers and set Answer accordingly 
	 * 						- 10/8/21: added disabled property on multistate dropdown so it will be disabled in colleague view (TFS 2413) -JTL
****************************************************************************************************/


@Component({
	selector: 'mig-dynamic-component',
	templateUrl: './dynamic.component.html',
	styleUrls: ['dynamic.component.css'],
	encapsulation: ViewEncapsulation.None
})

export class MIGDynamicComponent implements OnInit, OnDestroy {
	ngOnDestroy(): void {
		this.changeDetectionRef.detach();
	}
	validate: boolean = false;
	@Input() data: any;
	//@Input() data: UWQUESTION;
	@Input() val: any;
	@Input() form: UntypedFormGroup;
	@Input() glClassList: any[];
	@Input() quote: IQuote;
	@Input() subcontractorClasses: ISubcontractorClasses []
	@Output() StopQuote = new EventEmitter<any>();
    dateDisplayAnswer: string = "";
	prod: any;
	migDynamicValidator: DynamicValidator;

	StatesAnswer: any[];
	
	constructor(
		public changeDetectionRef: ChangeDetectorRef,
		public underwritingService: UnderwritingService,
		public formBuilder: UntypedFormBuilder,
		public migRoles: MIGSecurityRoles,
		public masks: InputMasksClass,
		public migsystemservice: MIGSystemService,
		public menuClass: MenuClass,
		public func: Functions
	) {
		this.prod = environment.production;
		this.migDynamicValidator = new DynamicValidator(this.func);

		
		// this.StatesAnswer = [
        //     {
        //       "ID": 137,
        //       "label": "Alaska",
        //       "value": "AK"
        //     },
        //     {
		// 		"ID": 141,
		// 		"label": "California",
		// 		"value": "CA"
		// 	}
        // ]
	}

	ngOnInit() {

		//need to add a form Subscription to re-trigger validation when answers change

		/* RRF 20190711  Added the following line to set question answer to "" when answer is = " "
		When printing a partial application the JSON document will contain UWQuestions with answers = " " if the 
		quesiton was not answered
		TODO: need to look at the value coming back from MIGInputSwitch override for the corect fix */
		if (this.data.ANSWER != "undefined" && this.data.ANSWER != null) {

			if (this.data.ANSWER.trim() == "") { this.data.ANSWER = "" }
		}

		let validation = (this.data.REQUIRED == 'Y' && this.data.ELEMENTTYPE !== 'LABEL' ? this.migDynamicValidator.ValidateRequired(this.data.ID, this.data.QUESTION) : Validators.nullValidator);

		//special case QUESTIONID 56 
		if(this.data.ID == 44){
			this.form.addControl(this.data.ID, new UntypedFormControl(this.data.ANSWER ? this.func.DTEWinsToPrimeNG(this.data.ANSWER) : 0));
			 //Prior Carrier EFFDTE cannot be the same Expraion date
			 //added with separately with 'setValidators because these are 'subquetions' not parent questions
			this.form.get('44').setValidators(this.migDynamicValidator.ValidateEFFDTEEXPDTE(this.data.ID.toString(),this.form))
			//this.form.updateValueAndValidity();
			this.migDynamicValidator.TriggerValidation(this.form);
		}
		//QUESTIONID 110--this is an async validator
		else if(this.data.ID == 92) {			
			this.form.addControl(this.data.ID, new UntypedFormControl(this.data.ANSWER));
			//
			this.form.get('92').setValidators(this.migDynamicValidator.ValidateQ110(this.data.ID, this.data.QUESTION, this.glClassList, this.subcontractorClasses));
			this.form.updateValueAndValidity({emitEvent: false});
			//this.migDynamicValidator.TriggerValidation(this.form);
		}


		//QUESTIONID 111 --this needs to be based on question 110 (above) not being 0, which is a valid entry for qid 110.
		else if(this.data.ID == 93) {			
			this.form.addControl(this.data.ID, new UntypedFormControl(this.data.ANSWER));			
			//			
			this.form.get('93').setValidators(this.migDynamicValidator.ValidateQ111(this.data.ID, this.data.QUESTION, this.form));
			this.form.updateValueAndValidity({emitEvent: false});
			//this.migDynamicValidator.TriggerValidation(this.form);
		}

		//QUESTIONID 113 --this needs to be based on question 110 (above) not being 0, which is a valid entry for qid 110.
		else if(this.data.ID == 94) {			
			this.form.addControl(this.data.ID, new UntypedFormControl(this.data.ANSWER));
			//
			this.form.get('94').setValidators(this.migDynamicValidator.ValidateQ113(this.data.ID, this.data.QUESTION,this.form));
			this.form.updateValueAndValidity({emitEvent: false});
			///this.migDynamicValidator.TriggerValidation(this.form);
		}

		//QUESTIONID 114 --this needs to be based on question 110 (above) not being 0, which is a valid entry for qid 110.
		else if(this.data.ID == 95) {			
			this.form.addControl(this.data.ID, new UntypedFormControl(this.data.ANSWER));
			//
			this.form.get('95').setValidators(this.migDynamicValidator.ValidateQ114(this.data.ID, this.data.QUESTION,this.form));
			this.form.updateValueAndValidity({emitEvent: false});
			//this.migDynamicValidator.TriggerValidation(this.form);
		}

		else if (this.data.ID === 361) {
			this.form.addControl(this.data.ID, new UntypedFormControl(this.data.ANSWER));
			this.form.get('361').setValidators(this.form.get('360').value === 'N' ? 
			this.migDynamicValidator.ValidateRequired(this.data.ID, this.data.QUESTION): Validators.nullValidator);
			this.form.updateValueAndValidity({emitEvent: false});
		}
		//QUESTIONID 395 -- we are validating against the sibling QUESTIONID 394 NOT the PARENTID 392
		else if(this.data.ID === 363) {
			this.form.addControl(this.data.ID, new UntypedFormControl(this.data.ANSWER));
			
			this.form.get('363').setValidators(this.form.get('362').value === 'N' ? 
			this.migDynamicValidator.ValidateRequired(this.data.ID, this.data.QUESTION): Validators.nullValidator);
			this.form.updateValueAndValidity({emitEvent: false});
		}
		else if(this.data.ID === 368) {
			this.form.addControl(this.data.ID, new UntypedFormControl(this.data.ANSWER));
			
			this.form.get('368').setValidators(this.form.get('367').value === 'Y' ? 
			this.migDynamicValidator.ValidateRequired(this.data.ID, this.data.QUESTION): Validators.nullValidator);
			this.form.updateValueAndValidity({emitEvent: false});
		}
		else if(this.data.ID === 371) {
			this.form.addControl(this.data.ID, new UntypedFormControl(this.data.ANSWER));
			
			this.form.get('371').setValidators(this.form.get('370').value === 'N' ? 
			this.migDynamicValidator.ValidateRequired(this.data.ID, this.data.QUESTION): Validators.nullValidator);
			this.form.updateValueAndValidity({emitEvent: false});
		}
		else if(this.data.ID === 359){
			this.form.addControl(this.data.ID, new UntypedFormControl(this.data.ANSWER));			
			this.form.get('359').setValidators(this.form.get('358').value === 'N' ? 
			this.migDynamicValidator.ValidateRequired(this.data.ID, this.data.QUESTION): Validators.nullValidator);
			this.form.updateValueAndValidity({emitEvent: false});
		}
		else if(this.data.ID === 365){
			this.form.addControl(this.data.ID, new UntypedFormControl(this.data.ANSWER));			
			this.form.get('365').setValidators(this.form.get('364').value === 'N' ? 
			this.migDynamicValidator.ValidateRequired(this.data.ID, this.data.QUESTION): Validators.nullValidator);
			this.form.updateValueAndValidity({emitEvent: false});
		}
		//
        else if (this.data.ELEMENTTYPE == "DATE") {

			if (this.data.ANSWER && this.data.ANSWER != "") {
				this.dateDisplayAnswer = this.func.DTEWinsToPrimeNG(this.data.ANSWER);
            }
            this.form.addControl(this.data.ID, new UntypedFormControl(this.dateDisplayAnswer, validation));
		}
		else if (this.data.ID === 779){					
			//this.form.addControl(this.data.ID, new FormControl(this.StatesAnswer));			
			this.form.addControl(this.data.ID, new UntypedFormControl(this.data.MULTIANSWER));	
			//this.form.updateValueAndValidity({emitEvent: false});
			//this.changeDetectionRef.detectChanges();		
		}
        else {
			this.form.addControl(this.data.ID, new UntypedFormControl(this.data.ANSWER, validation));
		}
		//this.changeDetectionRef.detectChanges();
	}

	//check for stop quote output to parent view to show module
	stopQuote(event, data) {

		this.StopQuote.emit({
			event: event,
			question: data
		});

	}

	nextClick() {
		//console.log(this.form.controls)
	}

	getMask(format) {
		
		if(format != null){
			format = format.toUpperCase();
		}
		
		switch (format) {
			case "CURRENCY":
				return this.masks.currencyMask;
				break;
			case "PERCENTAGE":
				return this.masks.percentMask;
				break;
			case "NUMBER":
				return this.masks.numericMask;
				break;
			// case "Currency":
			// 	return this.masks.currencyMask;
			// 	break;
			// case "Number":
			// 	return this.masks.percentMask;
			// 	break;
			// case "Percentage":
			// 	return this.masks.numericMask;
			// 	break;
		}
	}
}
