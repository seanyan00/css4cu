import { Validation } from '@classes/Common/ValidatorClass/Validation';
import { AbstractControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Functions } from '@helpers/functions';
import { GLClasses } from '@classes/CTR/GLCLASSES';
import { ISubcontractorClasses } from '@interfaces/ISubcontractorClasses';
import * as _ from 'lodash';
import { ContractorsTooltips } from '@helpers/tooltips';


export class DynamicValidator extends Validation {
    

    constructor(private func: Functions) {
        super();

    }
    //need to check a list of Subcontractor Class Codes to see if they have selected one and the $amount is  > 1
    ValidateQ110 = (fieldId: string | number, fieldName: string, quoteClassList: GLClasses[], subcontractorClasses: ISubcontractorClasses[]) => {
        return (control: AbstractControl): any =>  {
            
            let found: boolean = false;
            let subcontractorClassCodes;                
            // if(subcontractorClasses !=null){
            //     subcontractorClasses.map(item => item.subcontractorClassCode).join(',');
            // }
                
            //we are going to check to see if any of the quoteClassList class Codes are in the subcontractClassList
            //_.valuesIn(subcontractorClasses).forEach(item => {
            subcontractorClasses.forEach(item => {
                if(!found){
                    found = quoteClassList.some(x => x.CLASX == item.subcontractorClassCode);
                }                    
            });
            //
            if(!found && this.func.justNumbers(control.value) > 1) {
                //return { severity: "error", summary: fieldId, detail: fieldName + " cannot be > $1 unless one of the subcontractor class codes is used. The subcontractor class codes are: " + subcontractorClassCodes, sticky: true, closable: false }
                return { severity: "error", summary: fieldId, detail: fieldName + " is greater than $0.  This quote does not include a Subcontractor class.  Please return to the Location Screen and add the appropriate classification.", sticky: true, closable: false }
            }
            else if(control.value == '' || control.value == ' ' || control.value == 'undefined'){
                return { severity: "error", summary: fieldId, detail: fieldName + " cannot be left blank.", sticky: true, closable: false }
            }
            return null;
            
        };
    }
    
    //these are subquestions so we need to use the form 
    //*** PLEASE LEAVE THE CONSOLE-LOGS in there, for now but COMMENTED OUT -> BDK
    ValidateQ111 = (fieldId: string | number, fieldName: string, form:UntypedFormGroup) => {
        return (control: AbstractControl): any =>  {     
            let answer = this.func.justNumbers(form.get('92').value);
            
            if(answer != 0 && (control.value == '' || control.value == ' ' || control.value == 'undefined' || control.value == null)){
                //console.log('ValidateQ111', form);                 
                return { severity: "error", summary: fieldId, detail: fieldName + " is required.", sticky: true, closable: false }	
            }
            //control.disable({ emitEvent: false });
            //control.patchValue(null, {emitEvent:false});
            return null;
		}            
    };

    //these are subquetions so we need to use the form 
    ValidateQ113 = (fieldId: string | number, fieldName: string, form:UntypedFormGroup) => {
        return (control: AbstractControl): any =>  {     
            let answer = this.func.justNumbers(form.get('92').value);
            if(answer != 0 && (control.value == '' || control.value == ' ' || control.value == 'undefined' || control.value == null)){
                return { severity: "error", summary: fieldId, detail: fieldName + " is required.", sticky: true, closable: false }	
            }
            return null;
		}            
    };
    
    //these are subquetions so we need to use the form 
    ValidateQ114 = (fieldId: string | number, fieldName: string, form:UntypedFormGroup) => {
        return (control: AbstractControl): any =>  {     
            let answer = this.func.justNumbers(form.get('92').value); 
            if(answer != 0 && (control.value == '' || control.value == ' ' || control.value == 'undefined' || control.value == null)){
                return { severity: "error", summary: fieldId, detail: fieldName + " is required.", sticky: true, closable: false }	
            }
            return null;
		}            
    };

    //these are subquetions so we need to use the form 
    ValidateEFFDTEEXPDTE = (fieldId: string | number, form:UntypedFormGroup) => {
        return (control: AbstractControl): any =>  {                 
            let effdte = this.func.funcDateSelected(form.get('43').value);
            let expdte = this.func.funcDateSelected(form.get('44').value);
            if(effdte == expdte){
                return { severity: "error", summary: fieldId, detail: "Prior Carrier Current Year cannot have equal Effective Date and Expiration Date.", sticky: true, closable: false }	
            }
            return null;
		}            
    };


    ValidateSubQ401 = (fieldId: string, fieldName: string, form: UntypedFormGroup) => {
        return (control: AbstractControl): any => {
            let SQ400Answer = form.get('367').value;

            //this needs an answer when 'Y' is selected, not 'N' or unanswered
            if(SQ400Answer !== 'Y') {
                if(form.get('368')) return form.get('368').setValidators(Validators.nullValidator);
            }else {
                if(form.get('368')) {
                    return form.get('368').setValidators(this.ValidateRequired(fieldId, fieldName));
                    //return {severity: "error", summary: fieldId, detail: fieldName + " is required.", sticky: true, closable: false }
                }
            }

            return null;
        }
    }



    
    

}
