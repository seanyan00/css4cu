/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MIGDynamicFieldsetComponent } from './fieldset.component';
import { CheckboxModule } from 'primeng/checkbox';
import { PanelModule } from 'primeng/panel';
import { TabViewModule } from 'primeng/tabview';
import { FieldsetModule } from 'primeng/fieldset';
import { ConfirmDialogModule } from 'primeng/confirmdialog';

import { UnderwritingService } from '@services/underwriting.service';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { MIGInputSwitchModule } from '@overridden/primeng-inputswitch/switch.module';
import { MIGMessageModule } from '@overridden/primeng-message/message.module';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';
import { DynamicComponentModule } from '@dynamic/dynamic_component/dynamic.module';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
@NgModule({
	imports: [
		CheckboxModule,
		FormsModule,
		TabViewModule,
		CommonModule,
		PanelModule,
		FieldsetModule,
		MIGDropDownModule,
		MIGCheckboxModule,
		MIGInputtextModule,
		MIGInputSwitchModule,
		ReactiveFormsModule,
		MIGMessageModule,
		DynamicComponentModule,
		MIGButtonModule,
		ConfirmDialogModule
	],
	declarations: [MIGDynamicFieldsetComponent],
	exports: [MIGDynamicFieldsetComponent],
	providers: [UnderwritingService]
})
export class MIGDynamicFieldsetModule { }
