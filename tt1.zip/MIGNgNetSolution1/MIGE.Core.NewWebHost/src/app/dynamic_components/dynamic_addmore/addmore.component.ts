/* **************************************************************************************************
* COMPONENT DESCRIPTION  - Handle file upload via a modal window
* AS400 LIBRARY          - N/A
* TABLE/FILENAME         - N/A
*
* DATE CREATED           - N/A
* AUTHOR                 - MAG
* VERSION                - 1.0
* CODE GENERATION        - N/A
*
* using UWQUESTIONSCATEGORY structure
* "QUESTION" is our section title
* "ELEMENTTYPE" is to use this addmore component in ngif Underwriting Questions
* "DATALENGTH" is the limit of how many items can be added
* "ANSWER" turns into an array of answers with id: = SUBQUESTION.ID and answer = answer
* ---- could be re-worked to be json.stringify
* ---- but that'll have to be at the global save level
* and "SUBQUESTION" is our list of questions to ask
*
****************************************************************************************************/


import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, UntypedFormControl, Validators } from '@angular/forms';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { ConfirmationService } from 'primeng/api';
import { Panel } from 'primeng/panel';

@Component({
	selector: 'mig-addmore-component',
	templateUrl: './addmore.component.html',
	styleUrls: ['./addmore.component.css'],
	encapsulation: ViewEncapsulation.None
})

export class MIGAddMoreComponent implements OnInit {
	// json of questions
	@Input() data: any;

	// our UW Questions reactive form
	@Input() form: UntypedFormGroup;

	// we need a local form group for our new form
	localForm: UntypedFormGroup;

	// an array of forms for our rows of data
	formList: any[] = [];

	// are we editing an item ?
	editing: boolean = false;

	// store our data from the reactive form subscription
	formData: any;

	constructor(
		public formBuilder: UntypedFormBuilder,
		public migRoles: MIGSecurityRoles,
		public confirmationService: ConfirmationService,

	) {

	}

	ngOnInit() {
		// setup validation
		this.localForm = this.formBuilder.group({});
		let validation = (this.data.REQUIRED == 'Y' ? Validators.required : Validators.nullValidator);
		this.localForm.addControl(this.data.ID, new UntypedFormControl(this.data.ANSWER || '', validation));

		// turn our question ANSWER into an array
		//this.data.ANSWER = [];

		// subscribe to the form changes - we need to store them locally
		// so we can get the data from it
		this.localForm.valueChanges.pipe(debounceTime(100), distinctUntilChanged()).subscribe(formData => {
			this.formData = formData;
		})
	}

	btnAddAnother() {

		// if we already have our max rows - bye!!!
		if (this.data.DATALENGTH > 0) {
			if (this.data.ANSWER && (this.data.ANSWER.length + 1) > this.data.DATALENGTH) { return false; }
		}

		// toggle editing vs new
		this.editing = !this.editing;

		// if this is our second row, clear the form
		if (this.data.ANSWER && this.data.ANSWER.length > 0) {
			for (let i = 0; i < this.data.SUBQUESTION.length; i++) {
				this.localForm.controls[(this.data.SUBQUESTION[i].ID)].setValue("");
			}
		}
	}

	btnSave() {
		// if the form isnt valid - bye!!!
		if (!this.localForm.valid) { return false; }

		let out = [];

		// create an entry for our new data
		for (let i = 0; i < this.data.SUBQUESTION.length; i++) {
			out.push({
				id: this.data.SUBQUESTION[i].ID,
				answer: this.formData[this.data.SUBQUESTION[i].ID]
			})
		}

		// push this new data onto our ANSWER array
		this.data.ANSWER.push({ item: out })

		// needs to be a 1:1 relationship with reactive forms - so
		// push a form onto the formList
		this.formList.push({ form: this.formBuilder.group({}) })

		// toggle our panel and done and done
		this.editing = !this.editing;
	}

	btnUpdate(elem: Panel, i: number) {
		// if the form isnt valid - bye!!!
		if (!this.formList[i].form.valid) { return false; }

		// loop through the form, get the values of the fields and set the values in ANSWER
		for (let a = 0; a < this.data.SUBQUESTION.length; a++) {
			let tmp = this.formList[i].form.controls[(this.data.SUBQUESTION[a].ID)].value;
			this.data.ANSWER[i].item[a].answer = tmp;
		}

		elem.collapsed = true;
	}

	btnDelete(id: number) {

		// let's just make sure we want to actually do this
		this.confirmationService.confirm({
			message: 'Are you sure you want to remove this item?',
			accept: () => {

				// splice our arrays as needed
				this.data.ANSWER.splice(id, 1);
				this.formList.splice(id, 1);
			}
		});
	}

	funcGetSubQuestion(id: number) {

		// Return the text of a question by ID
		for (let i = 0; i < this.data.SUBQUESTION.length; i++) {
			if (this.data.SUBQUESTION[i].ID == id) { return this.data.SUBQUESTION[i].QUESTION; }
		}
	}


	funcGetSubQuestionDynamic(id: number) {
		// return the object of a question by ID
		for (let i = 0; i < this.data.SUBQUESTION.length; i++) {
			if (this.data.SUBQUESTION[i].ID == id) { return this.data.SUBQUESTION[i]; }
		}
	}
}
