import { NgModule } from '@angular/core';
import { Routes, RouterModule, NoPreloading } from '@angular/router';

import { ModuleWithProviders } from '@angular/core';
import { DashboardComponent } from '@root/mig/dashboard/dashboard.component';
import { ContractorsComponent } from '@root/mig/quotes/contractors/contractors.component';
import { RiskAppetiteGuideComponent } from '@shared/risk-appetite-guide/risk-appetite-guide.component';
import { PublicErrorDisplayComponent } from '@shared/public_error_display/public_error_display.component';
//security
import { AuthGuard } from '@auth/auth.guard';
import { WorkersCompComponent } from '@mig/quotes/workers-comp/workers-comp.component';
import { RoutingredirectComponent } from './system/redirect/routingredirect.component';

// const routes: Routes = [
//   //{ path: '', canLoad:[AuthGuard], component: ContractorsComponent}, 
//   //{path: '', component: AppComponent},
//   //{ path: '', loadChildren: '@root/mig/quotes/contractors/contractors.module.ts#ContractorsModule', canLoad:[AuthGuard]},
//   /** */
//   { path: '', canActivate:[AuthGuard], component: ContractorsComponent},
//   { path: 'https://secure.merchantsgroup.com:81/cgi-bin/lansaweb?procfun+migcomproc+mlogon+dev+eng+funcparms+z1aplchld(A0010):C', component: DashboardComponent },
//   { path: 'quotes/contractors', component: ContractorsComponent },
//   { path: 'quotes/contractors/:id', component: ContractorsComponent },
//   { path: 'guide', component: RiskAppetiteGuideComponent },
//   { path: 'error', component: PublicErrorDisplayComponent },
//   { path: '**', redirectTo: 'quotes/contractors', pathMatch: 'full' }
// ];
export const routes: Routes = [
  //{ path: '', canLoad:[AuthGuard], component: ContractorsComponent},
  // { path: '', canActivate:[AuthGuard], component: ContractorsComponent},

  //{path: '', component: AppComponent},
  //{ path: '', loadChildren: '@root/mig/quotes/contractors/contractors.module.ts#ContractorsModule', canLoad:[AuthGuard]},
  { path: 'https://secure.merchantsgroup.com:81/cgi-bin/lansaweb?procfun+migcomproc+mlogon+dev+eng+funcparms+z1aplchld(A0010):C', component: DashboardComponent },
  { path: 'quotes/contractors',  loadChildren: () => import('./mig/quotes/contractors/contractors.module').then(m=>m.ContractorsModule)},
  { path: 'quotes/workerscomp',  loadChildren: () => import('./mig/quotes/workers-comp/workers-comp.module').then(m=>m.WorkersCompModule) },
  { path: 'quotes/business-owners',  loadChildren: () => import('./mig/quotes/business-owners/business-owners.module').then(m=>m.BusinessOwnersModule) },
  { path: 'quotes/contractors/:id', loadChildren: () => import('./mig/quotes/contractors/contractors.module').then(m=>m.ContractorsModule)},
  { path: 'guide', component: RiskAppetiteGuideComponent },
  { path: 'error', component: PublicErrorDisplayComponent },
  // { path: 'employers-liability-limits', component: EmployersLiabilityLimits},
  { path: '', component: RoutingredirectComponent, pathMatch: 'full'},
  { path: '**', redirectTo: 'quotes/', component: RoutingredirectComponent, pathMatch: 'full' } // we may need a different default path redirect. 

  // { path: '**', redirectTo: 'quotes/contractors', pathMatch: 'full' }
];


export const AppRoutes: ModuleWithProviders<any> = RouterModule.forRoot(routes, { 
  preloadingStrategy: NoPreloading,
  useHash: false 

});

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
