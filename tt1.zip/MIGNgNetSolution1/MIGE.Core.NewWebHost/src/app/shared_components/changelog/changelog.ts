import {
	Component,
	EventEmitter,
	OnInit,
	Output,
	ViewEncapsulation,
} from '@angular/core';
import { MIGSystemService } from '@services/mig.service';
import { WhatsnewService } from '@services/whatsnew.service';
import { Subscription } from 'rxjs';
import { environment } from '@environment/environment';

@Component({
	selector: 'mig-changelog',
	templateUrl: './changelog.html',
	encapsulation: ViewEncapsulation.None,
})

export class MIGChangeLog implements OnInit {
	version: any;
	subSystemVersion: Subscription;
	subStep: string = "";
	@Output() setSubStep = new EventEmitter<any>();

	constructor(
		public migsystemservice: MIGSystemService,
		public whatsNewService: WhatsnewService
	) {
		this.subSystemVersion = this.migsystemservice.subscribeSystemVersion().subscribe(err => {
            if (environment.serverType != 'PROD')
            {
                this.subStep = "version";
			    this.setSubStep.emit("version");
            }
			
		});
	}

	ngOnInit() {
        if (environment.serverType != 'PROD')
        {
            this.whatsNewService.getWhatsNew().subscribe(data => {
                this.version = data;
            });
        }
		
	}

	Close() {
		this.subStep = "main";
		this.setSubStep.emit("main");
	}
}
