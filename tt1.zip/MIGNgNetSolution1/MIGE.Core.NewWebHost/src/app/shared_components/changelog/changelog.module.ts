
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MIGChangeLog } from './changelog';

@NgModule({
	imports: [
		CommonModule,
	],
	declarations: [MIGChangeLog],
	exports: [MIGChangeLog]
})
export class ChangeLogModule { }