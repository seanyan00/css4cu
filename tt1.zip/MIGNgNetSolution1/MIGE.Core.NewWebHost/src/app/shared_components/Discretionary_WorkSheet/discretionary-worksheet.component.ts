/* ****************************************************************************************************
* PROGRAM DESCRIPTION  - Discretionary Worksheet 
* NOTES: 
* - This component is the component that holds our discretionary pricing worksheet. 
* - The DP Worksheet is disconnected from the other data from the object graph. Because of this, we need to save, retrieve, update, and validate the data differently.
* - As of 4/11/22: This is now implented in WCA. 

* BUG FIXES: 
* - 1/18/22: Fixed issue where IRPM comments weren't saving properly.(JIRA-MSC-20422) -JTL
* - 1/18/22: Fixed issue where the form controls were not getting reset properly which would cause program to bomb out and prevent saving. (JIRA-MSC-20417) -JTL 
* - 4/29/22: Fixed issue where the Math.trunc() function was causing the IRPM/Scheduled mod to get calculated incorrectly on occasion. (JIRA MSC-)
****************************************************************************************************/
import { Component, OnInit,Input,Inject } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators} from '@angular/forms';
import { debounceTime } from 'rxjs/operators';
import { IQuote } from '@interfaces/IQuote';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { MenuClass } from '@root/system/menu/menu';
import { MIGSystemService } from '@root/services/mig.service';
import { DiscWorksheetService } from '@services/disc-worksheet.service'
import { Subscription } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { ChangeDetectorRef } from '@angular/core';
import * as _ from 'lodash';
import { DOCUMENT } from "@angular/common";
import { ConfirmationService } from 'primeng/api';
import { WCAQuote } from '@classViewModels/WCA/WCAQuote';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';


@Component({
  
  selector: 'mig-discretionary-worksheet',
  templateUrl: './discretionary-worksheet.component.html',
  styleUrls: ['./discretionary-worksheet.component.css']
})

export class DiscretionaryWorksheet implements OnInit {
  
  @Input() public quote: IQuote;
  @Input() public product :string;
  
  loadedData: any;
  display: boolean = false;  
  SavedClicked: boolean = false;
  nextButtonDisplay: boolean;
  getDPDataSubscription: Subscription;

  /**globals */
  form: UntypedFormGroup;
  loaded:boolean;    
  itemEvent:string = '';
  //quote: IQuote;
  errors:any[] = [];
  validate:boolean;
  /**Schedule var's */
  showSheduleOptions:boolean;
  showSchedule:boolean = true;
  showScheDesc:number;  
  scheduleTitle :string= 'Schedule'  
  scheuledComments: any[] = [];  
  scheuledDebitCredit: any[] = [];
  IsSCHEDebitCredit:string = null;
  /**these to vars are in chare of schedule calculations through out the pg */
  scheduleIRPMOD:number;
  scheduleRemaining: number;
  colleagueView: boolean = false;
  /**IRPM var's */
  showIRPMOptions:boolean;
  showIrpm:boolean = false;
  showIrpmDesc:number;    
  irpmTitle :string= 'IRPM'  
  irpmComments:any[] = [];
  irpmDebitCredit:any[] = [];
  IsIRPMDebitCredit:string = null;
  /**these to vars are in chare of irpm calculations through out the pg */
  irpmIRPMOD:number;
  irpmRemaining: number;
 
  //selectedComment:CommentValues [];

  constructor(public formBuilder: UntypedFormBuilder,
    public menuClass: MenuClass,
		private migsystemservice: MIGSystemService,
    private discWSService: DiscWorksheetService,
    private cd: ChangeDetectorRef,
    private confirmationService: ConfirmationService,
    public migroles: MIGSecurityRoles,
    @Inject(DOCUMENT) public document: Document) {
           
      this.form = this.formBuilder.group({});      
      /**initilaize to 0 in the constructor */
      this.scheduleRemaining = 0;
      this.irpmRemaining = 0;
   }

    ngAfterViewInit(): void {
       
    }
   
    ngOnInit() {

      /** */
      this.migsystemservice.subscribeValidateForm().subscribe(val => {
        this.validate = val;
      });

      this.colleagueView = this.migroles.roles.find(x=>x == "COL") == undefined ? false : true
      if(this.quote instanceof CTRQuote)
      {
       
        //this.quote = this.quote as CTRQuote;
        //this.quote = this.quote as CTRQuote;

        /** SCHEDULE < 1 is credit | > 1 is debit */
        if(this.quote.GLPENTITY.GLPSTATEINFO.find(x=>x.IRPMOD > 0 && x.IRPMOD < 1.0 && x.PRMSTE == this.quote.POLICYTRANS.CANSTE)){
          this.showSchedule = true;
          this.IsSCHEDebitCredit = 'credit'
          /** calculate Percentage to display on page */
          //let scheduleDisplay :number = (ctrQuote.GLPENTITY.GLPSTATEINFO.find(x=> x.PRMSTE == this.quote.POLICYTRANS.CANSTE).IRPMOD * 100);
          this.scheduleIRPMOD = (this.quote.GLPENTITY.GLPSTATEINFO.find(x=> x.PRMSTE == this.quote.POLICYTRANS.CANSTE).IRPMOD * 100);
          this.scheduleRemaining = (100 - this.scheduleIRPMOD);
          this.scheduleIRPMOD = (100 - this.scheduleIRPMOD);
        }
        else if (this.quote.GLPENTITY.GLPSTATEINFO.find(x=>x.IRPMOD > 0 && x.IRPMOD > 1.0 && x.PRMSTE == this.quote.POLICYTRANS.CANSTE)){ 
          this.showSchedule = true;
          this.IsSCHEDebitCredit = 'debit'
          /** calculate Percentage to display on page */
          //let scheduleDisplay :number = _.round((ctrQuote.GLPENTITY.GLPSTATEINFO.find(x=> x.PRMSTE == this.quote.POLICYTRANS.CANSTE).IRPMOD) * 100);
          this.scheduleIRPMOD = _.round((this.quote.GLPENTITY.GLPSTATEINFO.find(x=> x.PRMSTE == this.quote.POLICYTRANS.CANSTE).IRPMOD) * 100);
          this.scheduleRemaining = (this.scheduleIRPMOD - 100);
          this.scheduleIRPMOD = (this.scheduleIRPMOD - 100);
        }
        else
        {
          this.showSchedule = false;
          /**use for DEFAULT loading 
           * USE FOR TESTING the math with var above
           * credit is less than 1 debit is greater than 1
          */

        }

        /** IRPM  < 1 is credit | > 1 is debit */
        if(this.quote.CFPENTITY.CFPSTATEINFO.find(x=>x.IRPMOD > 0 && x.IRPMOD < 1.0 && x.PRMSTE == this.quote.POLICYTRANS.CANSTE)){
          this.showIrpm =true;
          this.IsIRPMDebitCredit = 'credit';
            /** calculate Percentage to display on page */
            //let irpmDisplay :number = (ctrQuote.CFPENTITY.CFPSTATEINFO.find(x=> x.PRMSTE == this.quote.POLICYTRANS.CANSTE).IRPMOD * 100);
          this.irpmIRPMOD = (this.quote.CFPENTITY.CFPSTATEINFO.find(x=> x.PRMSTE == this.quote.POLICYTRANS.CANSTE).IRPMOD * 100);
          this.irpmRemaining = (100 - this.irpmIRPMOD);
          this.irpmIRPMOD = (100 - this.irpmIRPMOD);
        }
        else if (this.quote.CFPENTITY.CFPSTATEINFO.find(x=>x.IRPMOD > 0 && x.IRPMOD > 1.0 && x.PRMSTE == this.quote.POLICYTRANS.CANSTE)){ 
          this.showIrpm = true;
          this.IsIRPMDebitCredit = 'debit' 
           /** calculate Percentage to display on page */
           //let irpmDisplay :number = _.round((ctrQuote.CFPENTITY.CFPSTATEINFO.find(x=> x.PRMSTE == this.quote.POLICYTRANS.CANSTE).IRPMOD) * 100);
          //  this.irpmIRPMOD = _.round((this.quote.CFPENTITY.CFPSTATEINFO.find(x=> x.PRMSTE == this.quote.POLICYTRANS.CANSTE).IRPMOD) * 100);
          this.irpmIRPMOD = _.round(this.quote.CFPENTITY.CFPSTATEINFO.find(x=> x.PRMSTE == this.quote.POLICYTRANS.CANSTE).IRPMOD * 100);
           this.irpmRemaining = (100 - this.irpmIRPMOD);
           this.irpmIRPMOD = (this.irpmIRPMOD - 100);
        }
        else{
          this.showIrpm =false;
          /**use for default loading */
          // this.showIrpm = false;
          // this.IsIRPMDebitCredit = 'credit';
        }
      }
      
      if(this.quote instanceof WCAQuote){
        //credit 
        if(this.quote.STATES.find(x=>x.SCHMOD > 0 && x.SCHMOD < 1 && x.PRMSTE == this.quote.POLICYTRANS.CANSTE)){
          this.showSchedule = true;
          this.IsSCHEDebitCredit = 'credit'
          this.scheduleIRPMOD = (this.quote.STATES.find(x=> x.PRMSTE == this.quote.POLICYTRANS.CANSTE).SCHMOD * 100);
          this.scheduleRemaining = (100 - this.scheduleIRPMOD);
          this.scheduleIRPMOD = (100 - this.scheduleIRPMOD);
        }
        //debit
        else if(this.quote.STATES.find(x=>x.SCHMOD > 0 && x.SCHMOD > 1 && x.PRMSTE == this.quote.POLICYTRANS.CANSTE)){
          this.showSchedule = true;
          this.IsSCHEDebitCredit = 'debit'
          this.scheduleIRPMOD = _.round((this.quote.STATES.find(x=> x.PRMSTE == this.quote.POLICYTRANS.CANSTE).SCHMOD) * 100);
          this.scheduleRemaining = (this.scheduleIRPMOD - 100);
          this.scheduleIRPMOD = (this.scheduleIRPMOD - 100);
        }
        else{
          this.showSchedule = false;
        }
      }

      /** for form value changes */
      this.form.valueChanges.pipe(debounceTime(100)).subscribe((formData)=>{
        let rawFormData = this.form.getRawValue(); 
        if(this.form.dirty) {this.migsystemservice.notifyDPWorksheetSaved(false) } // if the user made changes to the form, let the menu know that there are unsaved changes.
        if(this.showSchedule){
          this.loadedData.SCHED.forEach(element => { 
            element.IsChecked = rawFormData['SDESC' + element.PRPRID];
            element.CreditDebitAnswer = rawFormData['SDEBITCREDIT' + element.PRPRID];            
            if(rawFormData['SCOMMENTS' + element.PRPRID] != 'undefined' && rawFormData['SCOMMENTS' + element.PRPRID] != null){
              let commentsAnswer =  rawFormData['SCOMMENTS' + element.PRPRID].split('|');
              element.CommentAnswer = commentsAnswer[0];
              element.AnswerDescription = commentsAnswer[1];
              if(this.product == "WCA" && commentsAnswer[0] == '468'){ // Comment Answer 468 is "Other". For WCA we want to store our answer Description with what the colleague enters in the text box 
                element.AnswerDescription = rawFormData['SCOMMENTSOTHER' + element.PRPRID];
              }
            }  
          });
        }

        if(this.showIrpm){
          this.loadedData.IMPR.forEach(element => { 
            element.IsChecked = rawFormData['IDESC' + element.PRPRID];
            element.CreditDebitAnswer = rawFormData['IDEBITCREDIT' + element.PRPRID];
            if(rawFormData['ICOMMENTS' + element.PRPRID] != 'undefined' && rawFormData['ICOMMENTS' + element.PRPRID] != null){
              let commentsAnswer =  rawFormData['ICOMMENTS' + element.PRPRID].split('|');
              element.CommentAnswer = commentsAnswer[0];
              element.AnswerDescription = commentsAnswer[1];
            }             
          });
        }              
      });//end form valuechange

      /** LOAD DATA */
      this.loadData(() => {
        this.buildForm();
          /**calculate display for amount remaining after the form is done building
          * since we need to check which boxes are checked */
          this.irpmRemaining = this.irpmIRPMOD - this.calculateIRPMAmountRemaining();
          this.scheduleRemaining = this.scheduleIRPMOD - this.calculateScheduleAmountRemaining();
          /** make sure the value doesn't go past zero */
          (this.irpmRemaining <= 0 || isNaN(this.irpmRemaining)) ? this.irpmRemaining = 0 : this.irpmRemaining;
          (this.scheduleRemaining <= 0 || isNaN(this.scheduleRemaining)) ? this.scheduleRemaining = 0 : this.scheduleRemaining;
          if(this.scheduleRemaining + this.irpmRemaining == 0){ this.migsystemservice.notifyDPWorksheetSaved(true)} // if we are reloading a filled out worksheet, let the menu know that the worksheet is valid.
          /** notify menu */
          this.notifyMenuSteps(this.scheduleRemaining, this.irpmRemaining);     
      });
    } /**end ngOnInit */

    /** */
    loadData(callback = () => { }) {     
      this.discWSService.getDiscWorkSheetData(this.quote) // <-- use this
      //this.discWSService.getDiscWorkSheetSample()
        .pipe(
          finalize(() => {  
          })
        )
        .subscribe(data => {         
          this.loadedData = data;
          this.loaded = true;
          /** fill the IRPMOD in the dataLoad object for storing in SQL save 
           * for retrieving the data after it was saved once for a comparison if the value changes */
          if(this.showSchedule){  
            if(this.quote instanceof CTRQuote){
              this.loadedData.SCHEDULED_IRPMOD = this.quote.GLPENTITY.GLPSTATEINFO.find(x=>x.PRMSTE == this.quote.POLICYTRANS.CANSTE).IRPMOD as number;
            }
            if(this.quote instanceof WCAQuote){
              this.loadedData.SCHEDULED_IRPMOD = this.quote.STATES.find(x=> x.PRMSTE == this.quote.POLICYTRANS.CANSTE).SCHMOD as number;

              this.loadedData.SCHED.forEach(item=>{
                item.DebitComments = item.DebitComments.filter(x=>x.label != 'Other'); // filter out the "Other" comment. We will be re-adding it later only if we are in colleague view -JTL
                item.CreditComments = item.CreditComments.filter(x=>x.label != 'Other');
                if(item.RiskCategory == "9"){ // in agent view, we skip over category "8" for PA and NJ. However we want to maintain numerical order so we display 8 instead of 9. 
                  item.RiskCategory = "8";
                }

              });
              if(this.colleagueView){ // if we are in colleague view, push into Reasons dropdown
                this.loadedData.SCHED.forEach(item=>{ 
                  if(!item.CreditComments.some(comment=> comment.value == "468|Other")){ // make sure we aren't pushing a duplicate "Other" option
                    item.CreditComments.push({value:"468|Other", label:"Other"});
                    item.DebitComments.push({value:"468|Other", label:"Other"});
                  }
                  if(item.RiskCharDesc == "Other Risk Characteristics Not Addressed Above"){ // in colleague view, we want to make sure this characteristic has the right category bc we are artificially manipulating the value in agent view.  
                    item.RiskCategory = "9";
                  }
                });
              }

            }// end WCAQuote
          }
          if(this.showIrpm){
            if(this.quote instanceof CTRQuote){
                this.loadedData.IRPM_IRPMOD = this.quote.CFPENTITY.CFPSTATEINFO.find(x=>x.PRMSTE == this.quote.POLICYTRANS.CANSTE).IRPMOD as number;
            }
          } 
          callback(); 
        });       
    }

    //
    buildForm():void {     
      this.buildScheduleForm();
      this.buildIrpmForm(); 
			this.cd.detectChanges();
    }

    /** */
    buildScheduleForm(){
        //scheduled DP       
        this.loadedData.SCHED.forEach((item,index)=>{
          this.form.addControl('SDESC'+ item.PRPRID, new UntypedFormControl(item.IsChecked, Validators.required));          
          this.form.addControl('SDEBITCREDIT' + item.PRPRID, new UntypedFormControl(item.CreditDebitAnswer,Validators.required)); 
          this.form.addControl('SCOMMENTS' + item.PRPRID, new UntypedFormControl(item.CommentAnswer + '|'+ item.AnswerDescription,Validators.required));
          if(item.CommentAnswer == '468'){
            this.form.get('SCOMMENTS' + item.PRPRID).setValue(item.CommentAnswer + '|Other');
          }
          if(this.product == "WCA"){
            if(this.quote.POLICYTRANS.CANSTE == "28"){ // because NH only has 1 category for WCA, we want to default the checkbox to checked and set the Credit/Debit to their total scheduled limit -JTL 
              this.form.get('SDESC' + item.PRPRID).setValue(true, {emitEvent: false});
              this.form.get('SDEBITCREDIT' + item.PRPRID).setValue(this.scheduleRemaining.toString(), {emitEvent: false});
            }
            this.form.addControl('SCOMMENTSOTHER' + item.PRPRID, new UntypedFormControl(item.AnswerDescription != null ? item.AnswerDescription: "",Validators.required));
            if(!this.colleagueView){
              this.form.get('SCOMMENTSOTHER' + item.PRPRID).disable(); // disables the text area in agent view
            }

          }

      });//end foreach buildForm() 
    }

    /** */
    buildIrpmForm(){
        //IRPM DP
        this.loadedData.IMPR.forEach((item,index)=>{
            this.form.addControl('IDESC'+ item.PRPRID, new UntypedFormControl(item.IsChecked, Validators.required));          
            this.form.addControl('IDEBITCREDIT' + item.PRPRID, new UntypedFormControl(item.CreditDebitAnswer,Validators.required)); 
            this.form.addControl('ICOMMENTS' + item.PRPRID, new UntypedFormControl(item.CommentAnswer + '|'+ item.AnswerDescription,Validators.required));        
        });//end foreach buildForm() 
    }

    addSelectionVisibility(item: any, checkBoxEvent: any, idx:number) 
    {  
      if(checkBoxEvent.checked == false){ // instead of looking for !checkboxEvent, we use checkBoxEvent.checked to determined if the user is turning the checkbox on or off.
        this.scheduleRemaining = this.scheduleIRPMOD - this.calculateScheduleAmountRemaining();
        this.form.controls['SDEBITCREDIT'+ item.PRPRID].reset();// .patchValue(null);
        this.form.controls['SCOMMENTS'+ item.PRPRID].reset();// .patchValue('');
        this.form.controls['SDESC'+ item.PRPRID].reset();//.setValue(false);
      }    
      /** make sure the value doesn't go past zero */
       //(this.scheduleRemaining <= 0 ) ? this.scheduleRemaining = 0 : this.scheduleRemaining;  
       if(this.scheduleRemaining <= 0 ){
        this.display =true;         
        this.form.controls['SDESC'+ item.PRPRID].setValue(false);
        this.scheduleRemaining = this.scheduleIRPMOD - this.calculateScheduleAmountRemaining();;
     } 
     else{
       this.scheduleRemaining;
      }     
      
       /** notify menu */
        this.notifyMenuSteps(this.scheduleRemaining, this.irpmRemaining); 
        this.SavedClicked = false;
        this.cd.detectChanges();
    }

    irpmSelectionVisibility(item: any, checkBoxEvent: any, idx:number){   
      /** */
      if(checkBoxEvent.checked == false){
        this.irpmRemaining = this.irpmIRPMOD - this.calculateIRPMAmountRemaining();
        this.form.controls['IDEBITCREDIT'+ item.PRPRID].reset();
        this.form.controls['ICOMMENTS'+ item.PRPRID].reset();
        this.form.controls['IDESC'+ item.PRPRID].reset();

      } 
      /** make sure the value doesn't go past zero */
      // (this.irpmRemaining <= 0 ) ? this.irpmRemaining = 0 : this.irpmRemaining;
      if(this.irpmRemaining <= 0 ){
        this.display =true;        
        this.form.controls['IDESC'+ item.PRPRID].setValue(false);
        this.irpmRemaining = this.irpmIRPMOD - this.calculateIRPMAmountRemaining();
      } 
      else{
        this.irpmRemaining;
      }

       /** notify menu */
       this.notifyMenuSteps(this.scheduleRemaining, this.irpmRemaining);
       this.SavedClicked = false;
       this.cd.detectChanges();
    }

    ScheduleDebitCreditChange(event,prprid){  
      this.scheduleRemaining = this.scheduleIRPMOD - this.calculateScheduleAmountRemaining();
     /** make sure the value doesn't go past zero */
      //(this.scheduleRemaining <= 0 ) ? this.scheduleRemaining = 0 : this.scheduleRemaining;
      if (this.scheduleRemaining < 0 ){
        this.display = true;
        this.form.controls['SDESC'+ prprid].reset(); 
        this.form.controls['SDEBITCREDIT'+ prprid].patchValue('');
        this.form.controls['SCOMMENTS'+ prprid].patchValue('');
        this.scheduleRemaining = this.scheduleIRPMOD - this.calculateScheduleAmountRemaining();
      }
      else{
        this.scheduleRemaining;
      } 
        /** notify menu  subscription */
      this.notifyMenuSteps(this.scheduleRemaining, this.irpmRemaining);
      this.SavedClicked = false;
      this.cd.detectChanges();

      /**notify errors */       
      if(this.scheduleRemaining == 0){
        this.errors = [];
        this.migsystemservice.notifyError(this.errors);
        return null;
      }
    }

    IRPMDebitCreditChange(event,prprid){      
      this.irpmRemaining = this.irpmIRPMOD - this.calculateIRPMAmountRemaining();
      
    /** make sure the value doesn't go past zero */
      //(this.irpmRemaining <= 0 ) ? this.irpmRemaining = 0 : this.irpmRemaining;
      if (this.irpmRemaining < 0 ){
        this.display = true;
        this.form.controls['IDESC'+ prprid].reset()//.setValue(false);
        this.form.controls['IDEBITCREDIT'+ prprid].patchValue('');
        this.form.controls['ICOMMENTS'+ prprid].patchValue('');
        this.irpmRemaining = this.irpmIRPMOD - this.calculateIRPMAmountRemaining();
      }
      else{
        this.irpmRemaining;
      }
      /** notify menu */
      this.notifyMenuSteps(this.scheduleRemaining, this.irpmRemaining); 
      this.SavedClicked = false;
      this.cd.detectChanges();
      
       /**notify errors */        
      if(this.irpmRemaining == 0){
        this.errors = [];
        this.migsystemservice.notifyError(this.errors);
        return null;
      }
    }
    /**to update the validation on commets being selected */
    CommentsChange(event){
        /**notify errors */        
        if(this.ValidateCommentDescription()){
          this.errors = [];
          this.migsystemservice.notifyError(this.errors);
          //return null;
        }
    }
    //
    calculateScheduleAmountRemaining() : number{
      let totalChecked:number = 0;
      for (let control in this.form.controls){  
        
        if(control.startsWith('SDESC') && this.form.controls[control].value)  {
        if(!isNaN(parseInt(this.form.controls['SDEBITCREDIT'+ control.replace('SDESC','')].value)))
         totalChecked +=  parseInt(this.form.controls['SDEBITCREDIT'+ control.replace('SDESC','')].value);
        }
      } 
      return totalChecked;
    }

    //
    calculateIRPMAmountRemaining() : number{
      let totalChecked:number = 0;
      for (let control in this.form.controls){  
        if(control.startsWith('IDESC') && this.form.controls[control].value)  {           
          totalChecked +=  parseInt(this.form.controls['IDEBITCREDIT'+ control.replace('IDESC','')].value);
        }
      } 
      return totalChecked;
    }

    nextClick(event){
      if(this.ValidateRemmaining() != null){
        //this.save('next')
        this.menuClass.GotoMenuItem('name', 'UnderwritingQuestions');
      }      
    }

    /** */
    save(event?){
      if(this.ValidateRemmaining() != null){
        /** save the data */     
        this.discWSService.saveDiscretionaryWorksheet(this.loadedData)
        .pipe(debounceTime(100)
        
          // finalize(() => {  
           
          // })
        )
        .subscribe(data => {
          this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Contractors', detail: "Worksheet Saved!", event: "end" });
          /** notify menu */
          this.notifyMenuSteps(this.scheduleRemaining, this.irpmRemaining);
          this.SavedClicked = true;
          this.migsystemservice.notifyDPWorksheetSaved(true);
          this.cd.detectChanges();
        });
      }            
    }

    previous(event){ // gets called when the user clicks the "Back" button.
      // if the user hasn't saved the DP Worksheet we want to remind them that if they leave the page w/o saving, they will lose their changes. 
      if(!this.SavedClicked){
        this.confirmationService.confirm({
          message: 'You have unsaved changes. Do you want to save before continuing?',
          acceptLabel: "Save and Continue",
          header: 'Discretionary Worksheet',
          icon: 'pi pi-exclamation-triangle',
          accept: () => { // When we select "Save and Continue", we perform the function below.
            this.save(); // We attempt to save. If the DP worksheet is not complete, the validation will trigger. 
          },
          rejectLabel: "Close and Lose Changes",
          reject: () => { 
            this.migsystemservice.notifyError([]); // clear error panel
            this.menuClass.GotoMenuItem('name', 'PremiumSummary');
          }
        });
      }
      else{ // if our Worksheet is already saved, we simply go to Premium Summary.
        this.menuClass.GotoMenuItem('name', 'PremiumSummary');
      }
    }

    //
    notifyMenuSteps(ScheRemaining:number, ImprRemaining:number){
      // notify the menu and app footer of the combined value of the values need to add up to 0.
      this.migsystemservice.notifyDPWorksheet(ScheRemaining + ImprRemaining); 
      if((ScheRemaining + ImprRemaining) == 0){
        this.nextButtonDisplay = false;
        this.SavedClicked = true;
      }
      else{
        this.nextButtonDisplay = true;
      }
      this.cd.detectChanges();
    }

    ValidateRemmaining(){      
      this.errors = [];
      /** WE NEED THIS FOR VALIDATION */
      if(this.validate){
        if(this.scheduleRemaining != 0 && this.showSchedule){    
          this.errors.push({severity: "error",
          summary: "DiscretionaryWorksheet",
          detail: "Schedule Amount Remaining must be 0",
          sticky: true,
          closable: false});
          this.migsystemservice.notifyDoneClicked(this.errors);
          return null;
        }
        else if(this.irpmRemaining != 0 && this.showIrpm){  
            this.errors.push({severity: "error",
            summary: "DiscretionaryWorksheet",
            detail: "IRPM Amount Remaining must be 0",
            sticky: true,
            closable: false});
            this.migsystemservice.notifyDoneClicked(this.errors);
            return null;
          }
        else if(!this.ValidateCommentDescription()){
            this.errors.push({severity: "error",
            summary: "DiscretionaryWorksheet",
            detail: "Comment Description must be selected",
            sticky: true,
            closable: false});
            this.migsystemservice.notifyDoneClicked(this.errors);
            return null;
        }
        else{      
            this.errors = [];
            this.migsystemservice.notifyDoneClicked(this.errors);
            return 0;
        }  
      }
      else{
          return 0;
      } 
      
    }
    
    ValidateCommentDescription():boolean {
      let ret = true;
      if(this.validate){
        for (let control in this.form.controls)
        {  
          if(this.loadedData.SCHED.RiskCategory != '8'){
            if(control.startsWith('SDESC') && this.form.controls[control].value){ 
                if(this.form.controls['SCOMMENTS'+ control.replace('SDESC','')].value == null 
                  || this.form.controls['SCOMMENTS'+ control.replace('SDESC','')].value === ''
                  || this.form.controls['SCOMMENTS'+ control.replace('SDESC','')].value === '|undefined'
                  || this.form.controls['SCOMMENTS'+ control.replace('SDESC','')].value === 'null|null'){                
                    ret= false;
                    break;
                }
            }
          }
          if(control.startsWith('IDESC') && this.form.controls[control].value){           
            if(this.form.controls['ICOMMENTS'+ control.replace('IDESC','')].value == null 
                || this.form.controls['ICOMMENTS'+ control.replace('IDESC','')].value === ''
                || this.form.controls['ICOMMENTS'+ control.replace('IDESC','')].value === '|undefined' // this was not replacing the proper control earlier which was causing the console to bomb out and prevent worksheet from being saved. 
                || this.form.controls['ICOMMENTS'+ control.replace('IDESC','')].value === 'null|null'){
                  ret= false;
                  break;
              }
          }   
        }
        return ret;
      }
      else{
        return ret;
      }       
    }
    
    CloseModal(){
      this.display = false;
    }
    /** */
    ngOndestroy(){
      //this.getDPDataSubscription.unsubscribe();
    }
}

//
// export class CommentValues {
//   id:number;
//   name:string;  
//   // name:string;
//   // value:number;
// }