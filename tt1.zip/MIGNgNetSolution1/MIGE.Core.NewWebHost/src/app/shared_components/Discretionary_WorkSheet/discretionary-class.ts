import { Injectable } from "@angular/core";
import { CTRQuote } from "@classViewModels/CTR/CTRQuote";
import { IQuote } from "@interfaces/IQuote";
import { Functions }from '@helpers/functions';
import { WCAQuote } from "@classViewModels/WCA/WCAQuote";
import { BOPQuote } from "@classViewModels/BOP/BOPQuote";


@Injectable()
export class DiscretionaryClass {

    constructor(public func: Functions){}

    ShowDiscretioanryMenuItem(quote: IQuote) : boolean
    {    
        let today = new Date();		
        if (quote instanceof CTRQuote)
        {
            let ctrQuote = Object.assign(new CTRQuote(), quote);
            
            /**FIRST WE NEED TO CHECK THE CONFIGURBLE EFFDTE FLAG COMING FROM THE BACKEND TO TOGGLE THE MENU ITEM
             * THIS IS IN QOTEPOLICY INFO AND CHEKED WITH CURRENT DATE */
            if(this.func.funcDateSelected(today) >= quote.QUOTEPOLICYINFORMATION.DPWORKSHEETEFFDTE){
                if (ctrQuote.GLPENTITY.GLPSTATEINFO.length && ctrQuote.GLPENTITY.GLPSTATEINFO.find(x=> x.PRMSTE == ctrQuote.POLICYTRANS.CANSTE != null)) {
                    if(ctrQuote.GLPENTITY.GLPSTATEINFO.find(x=> x.PRMSTE == ctrQuote.POLICYTRANS.CANSTE).IRPMOD > 0){
                        return true;
                    }                    
                }
                if (ctrQuote.CFPENTITY.CFPSTATEINFO.length && ctrQuote.CFPENTITY.CFPSTATEINFO.find(x=> x.PRMSTE == ctrQuote.POLICYTRANS.CANSTE) != null) {
                    
                    if(ctrQuote.CFPENTITY.CFPSTATEINFO.find(x=> x.PRMSTE == ctrQuote.POLICYTRANS.CANSTE).IRPMOD > 0){
                        return true;
                    }                    
                    // if(ctrQuote.CFPENTITY.CFPSTATEINFO.find(x=> x.PRMSTE == ctrQuote.POLICYTRANS.CANSTE).IRPMOD > 0){
                    //     return true;
                    // }
                }    
            }               
            return false;
        }
        if (quote instanceof WCAQuote){
            if(quote.STATES.find(x=>x.SCHMOD > 0 && x.RECORDSTATE != "D" && x.PRMSTE == quote.POLICYTRANS.CANSTE) ){
                return true; 
            }
            return false;
        }
        if(quote instanceof BOPQuote){
            return false; // add logic when we implement Discretionary Pricing for BOP
        }
    }
}
