import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
//import { FieldsetModule, InputTextModule, PanelModule } from 'primeng/primeng';
import { FieldsetModule } from 'primeng/fieldset';
import { InputTextModule } from 'primeng/inputtext';
import { PanelModule } from 'primeng/panel';
import { TextMaskModule } from 'angular2-text-mask';
import { MIGMessageModule } from '@overridden/primeng-message/message.module';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { MIGProgessbarModule } from '@overridden/primeng-progressbar/progress.module';
//
import { MenuClass } from '@root/system/menu/menu';
import { DiscretionaryWorksheet } from './discretionary-worksheet.component';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { DialogModule } from 'primeng/dialog';
import { ConfirmDialogModule } from 'primeng/confirmdialog';


@NgModule({
    imports: [
        FormsModule,
        CommonModule,
        ReactiveFormsModule,
        MIGMessageModule,
        MIGInputtextModule,
        FieldsetModule,
        InputTextModule,
        PanelModule,
        TextMaskModule,
        MIGButtonModule,
        MIGProgessbarModule,
        MIGCheckboxModule,
        MIGDropDownModule,
        ConfirmDialogModule,
        DialogModule
    ],
    declarations: [DiscretionaryWorksheet],
    exports: [DiscretionaryWorksheet]
})
export class DiscretionaryWorkSheetModule {
    
    formGroup: UntypedFormGroup;
	

    constructor(public menuClass: MenuClass,
		private formBuilder: UntypedFormBuilder){

            this.formGroup = this.formBuilder.group({});

            menuClass.addMenuItem({
                name: 'DiscretionaryWorksheet',
                label: 'Discretionary Worksheet',
                color: "ui-steps-number-default",
                navSkip: false,
                active: false,
                hasError: false,
                errors: [],
                buttons: [],
                form: this.formGroup,
                forms: [],
                icon: "fa fa-clipboard-list",
                block: [],
                visible: true,
                quote: "premium"
            });
            // menuClass.addMenuItem({
            //     name: 'DiscretionaryWorksheet',
            //     label: 'Discretionary Worksheet',
            //     color: "ui-steps-number-default",
            //     navSkip: false,
            //     active: false,
            //     hasError: false,
            //     errors: [],
            //     buttons: [{ button: "Next" }, { button: "Save" }],
            //     form: this.formGroup,
            //     forms: [],
            //     icon: "fa fa-clipboard-list",
            //     block: [],
            //     visible: true,
            //     quote: "premium"
            // });

        }
 }
