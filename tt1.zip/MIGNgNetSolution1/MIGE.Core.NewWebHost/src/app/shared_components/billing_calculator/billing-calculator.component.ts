/* ****************************************************************************************************
* PROGRAM DESCRIPTION  - Billing Calculator Component
* NOTES: 
* - This component is a shared component across all product lines and serves a subclass of premium summary. 
* 
* 10/18/21: Removed CTR specific text on WCA Quotes (TFS 2492) -JTL 
****************************************************************************************************/
/* NG Includes */
import { Component, Input, Output, OnInit, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { AuthService } from '@auth/auth.service';

@Component({
  selector: 'mig-calculator',
  templateUrl: './billing-calculator.component.html'
})


export class MIGBillingCalculator implements OnInit {

  @Input() premium: number;
  @Input() policy: string;
  @Input() relpol: string;
  @Output() cancelCallback = new EventEmitter<any>();

  private _payPlansURL = '../assets/sample_data/paymentPlans.json';

  feeForEFT: Number = 0;
  feeForNonEFT: Number = 0;
  lineOfBusiness: string;
  rows: Object[] = [];

  constructor(private http: HttpClient,
    public authService: AuthService) { }

  ngOnInit() {
    this.calculatePayments();
  }


  calculatePayments() {
    var ctrPaymentPlans = [];
    var description = '';
    var deposit = 0;
    var installment = 0;

    this.getPaymentPlans().subscribe((data) => {

      //get payment plans  
      if (this.premium > data.LOWPREMIUM[this.policy.substring(0, 3)] || this.relpol == "ACCTCREDIT") {
        data.ALLPAYMENTPLANS.filter(item => item.PROD == this.policy.substring(0, 3)).map(item => ctrPaymentPlans = item.PAYMENTPLANS);
      } else {
        data.LOWPREMIUMPAYMENTS.filter(item => item.PROD == this.policy.substring(0, 3)).map(item => ctrPaymentPlans = item.PAYMENTPLANS);
     }

      //calculate payments
      ctrPaymentPlans.forEach(paymentPlan => {
        data.DEPOSITS.filter(item => item.PAYMENTPLAN == paymentPlan).map(item => {
          description = item.DESCRIPTION;
          deposit = item.PERCENTAGE * this.premium;
        });
        this.rows.push(new Object({
          "DESCRIPTION": description,
          "DEPOSIT": deposit.toFixed(2),
          "INSTALLMENT": null
        }));
        for (var i = 1; i < parseInt(paymentPlan); i++) {
          installment = (this.premium - deposit) / (parseInt(paymentPlan) - 1);
          this.rows.push(new Object({
            "DESCRIPTION": '',
            "DEPOSIT": null,
            "INSTALLMENT": installment.toFixed(2)
          }));
        }
      });

      //get fees
      this.feeForEFT = data.FEES.EFT;
      if (data.BUSINESS.PERSONAL.includes(this.policy.substring(0, 3))) {
        this.lineOfBusiness = "personal";
        this.feeForNonEFT = data.FEES.NONEFTPERSONAL;
      }
      else {
        this.lineOfBusiness = "commercial";
        this.feeForNonEFT = data.FEES.NONEFTCOMMERCIAL;
      }

    });
  }

  getPaymentPlans(): Observable<any> {

    return this.http.get(this._payPlansURL).pipe(map((response: Response) => response));
  }

	// Cancel the component to exit its view
	cancel() {
		this.cancelCallback.emit();
	}
}
