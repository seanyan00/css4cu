/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, FormGroup, FormBuilder } from '@angular/forms';
import { MIGOverlayPanelModule } from '@overridden/primeng-overlaypanel/overlay.module';
import { PipesModule } from '@pipes/pipes.module';
import { FieldsetModule } from 'primeng/fieldset';
import { PanelModule } from 'primeng/panel';
import { TooltipModule } from 'primeng/tooltip';
import { TabViewModule } from 'primeng/tabview';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { TextMaskModule } from 'angular2-text-mask';
import { MenuClass } from '@root/system/menu/menu';
import { MIGProgessbarModule } from '@overridden/primeng-progressbar/progress.module';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import { DialogModule } from 'primeng/dialog';
import { DiscretionaryPricingModule } from '@shared/discretionary_pricing/discretionary_pricing.module';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { MIGMessageModule } from '@overridden/primeng-message/message.module';
import { MIGDocumentButtonModule} from '@shared/document_button/document_button.module';
import { MIGBillingCalculator } from '@shared/billing_calculator/billing-calculator.component';
import {NgxPrintModule} from 'ngx-print';
import { AuthService } from '@auth/auth.service';

@NgModule({
    imports: [
        MIGButtonModule,
		FormsModule,
		CommonModule,
		MIGDropDownModule,
		PanelModule,
		FieldsetModule,
		PipesModule,
		MIGOverlayPanelModule,
		MIGInputtextModule,
		TabViewModule,
		TooltipModule,
		TextMaskModule,
		MIGCheckboxModule,
		MIGProgessbarModule,
		DialogModule,
		DynamicDialogModule,
		DiscretionaryPricingModule,
        ProgressSpinnerModule,
        MIGMessageModule,
		MIGDocumentButtonModule,
		NgxPrintModule
    ],
    declarations: [MIGBillingCalculator],
	exports: [MIGBillingCalculator]
})
export class BillingCalculatorModule {
	
 }
