/* **************************************************************************************************
* COMPONENT DESCRIPTION  - Handle errors at a global level
* AS400 LIBRARY          - N/A
* TABLE/FILENAME         - N/A
*
* DATE CREATED           - 6/25/2018
* AUTHOR                 - MAG
* VERSION                - 1.0
* CODE GENERATION        - N/A
*
* ************ PROGRAM MODIFICATIONS SHOULD BE DOCUMENTED IN THE FOLLOWING FORMAT ******************
* DATE OF CHANGE - DEVELOPERS INITIALS - BUG # - DESCRIPTION OF CHANGE
* ***************************************************************************************************
* 6/25/2018 - MAG - N/A - First pass - right now, just logs errors to the browser screen to help
* determine a bug from a crash
*
****************************************************************************************************/
import { ErrorHandler, Injectable } from '@angular/core';
// import { ContractorsGlobals } from '@globals';
@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
    constructor(
        // private globals: ContractorsGlobals
    ) { }

    handleError(error) {
        const message = error.message ? error.message : error.toString();
        // log on the server
        // this.globals.systemError += "<br>" + message;
		// this.globals.systemErrorShow = true;
		//console.log("ERROR!");
        //console.log({ message });
        return false;
        // throw error;
    }

}
