/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MIGDocumentButton } from './document_button.component';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { TooltipModule } from 'primeng/tooltip';
import { ProgressSpinnerModule } from 'primeng/progressspinner';

@NgModule({
    imports: [
        MIGButtonModule,
        FormsModule,
        CommonModule,
        TooltipModule,
        ProgressSpinnerModule
    ],
    declarations: [MIGDocumentButton],
    exports: [MIGDocumentButton]
})
export class MIGDocumentButtonModule { }
