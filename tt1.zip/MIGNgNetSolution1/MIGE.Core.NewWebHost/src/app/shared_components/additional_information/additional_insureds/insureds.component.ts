/******************************************************************************************************
     * PROGRAM DESCRIPTION  - Insureds component for additional insured
	 * 						- JTL 8/14/19 - Implemented Error Panel
	 * 
	 * NOTES
	 * - Currently there is an issue when there is originally an Additional insured, 
	 * and the user goes back to remove it, when the user goes back to this screen 
	 * the field will be gone but the errors will still be here. 
	 * - Instead of using Validators.Required, I had to use ValidateRequired(field: string)
	 * (ex: ValidateRequired(this.getLabel(this.localInsuredsList[i].label) + ' (' + (a + 1) + '): Street Number')  )
	 * This gives the name of the CG, followed by the specific Additional insured, followed by the field.
	 * I needed to make it like this because a user could have forgotten the street number for different CG's or AI's, 
	 * and otherwise the error message navigation feature would only navigate to the first instance.  
****************************************************************************************************/
/* NG Includes */
import { Component, ViewEncapsulation, OnInit, EventEmitter, Output, Input, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { MenuClass } from '@system/menu/menu';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { HttpClient } from '@angular/common/http';
import { map, debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { UntypedFormGroup, UntypedFormControl, Validators } from '@angular/forms';
import { MIGAddressValidator } from '../../address_info/address.validators';

import { ADDITIONALINSURED } from '@classes/Common/ADDITIONALINSUREDS';
import { Subscription } from 'rxjs';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { MIGSystemService } from '@services/mig.service';
import { ErrorService } from '@root/services/error.service';

@Component({
	selector: 'mig-underwriting-additional-insureds',
	templateUrl: './insureds.component.html',
	styleUrls: ['insureds.component.css'],
	encapsulation: ViewEncapsulation.None
})

//TODO: remove cpFormGroup since it is not being used
export class MIGUnderwritingAdditionalInsureds implements OnInit, OnDestroy {
	@Output() GoBackToSectionEmitter = new EventEmitter<any>();
	@Input() ctrQuote: CTRQuote;
	stepName: string = "AdditionalInformationAdditionalInsureds";
	localInsuredsList: any[] = [];
	formGroup: UntypedFormGroup;
	cpFormGroup: UntypedFormGroup;
	records: boolean = false;
	updateRecordState: Subscription;
	FormGroupSubscription: Subscription;
	data: any;
	migAddressValidator: MIGAddressValidator;
	additionalInsured: ADDITIONALINSURED;
	nextClicked: boolean;
	DESLabel: any = [];
	LOCLabel: any = [];
	messages: any = [];
	blanketArr: string[] = ['EA', 'OS', 'LS', 'GL', 'CA', 'IB'];
	//
	//cfp1219Properties:CFPLOCATION[] =[];

	constructor(
		public changeDetectionRef: ChangeDetectorRef,
		public menuClass: MenuClass,
		public contractorsDropDowns: ContractorsDropDowns,
		private http: HttpClient,
		public migRoles: MIGSecurityRoles,
		public migsystemservice: MIGSystemService,
		public errorService: ErrorService
	) {
		this.migAddressValidator = new MIGAddressValidator();

		this.migsystemservice.subscribeNextClicked().subscribe(() => {
			this.nextClicked = true;
		});

		this.migsystemservice.subscribeXClicked().subscribe(() => {
			this.nextClicked = false;
		});
	}


	ngOnInit() {

		//check to see if there are only Blanket AI's, if so then move to next screen
		if(this.ctrQuote.ADDITIONALINSUREDS.every(x => this.blanketArr.includes(x.ADDTYP))) this.menuClass.nextStep();
		if (this.ctrQuote.ADDITIONALINSUREDS != null && this.ctrQuote.ADDITIONALINSUREDS.length > 0) {
			this.additionalInsured = this.ctrQuote.ADDITIONALINSUREDS.find(element => element.ADDCDE == "A")
			if (this.additionalInsured == null) {
				this.ctrQuote.ADDITIONALINSUREDS[0].ADDCDE = "A";
				this.additionalInsured = this.ctrQuote.ADDITIONALINSUREDS[0];
			}

			this.additionalInsured.RECORDSTATE = "U";
		}

		if (this.additionalInsured == null) {
			this.additionalInsured = new ADDITIONALINSURED(this.ctrQuote.QUOTEPOLICYINFORMATION);
			this.additionalInsured.ADDCDE = "A";
			this.additionalInsured.RECORDSTATE = "N";
		}

		//CONSTPROJECTLIAB form group
		// this.cpFormGroup = new FormGroup({});
		// if (this.ctrQuote.GLPENTITY.CONSTPROJECTLIAB.length > 0) { this.records = true; }

		// this.ctrQuote.GLPENTITY.CONSTPROJECTLIAB.forEach(elem => {
		// 	this.cpFormGroup.addControl(elem.SPCSEQ, new FormControl((elem.SPCDSC) ? elem.SPCDSC : ''));
		// });

		//
		this.formGroup = new UntypedFormGroup({});
		this.getInsuredsList().subscribe(data => {

			let policyLiabLim = this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS;
			//
			this.localInsuredsList = data;

			for (let i = 0; i < this.localInsuredsList.length; i++) {

				let elem = data[i];
				let fieldCnt = policyLiabLim[elem.field];
				
				if (elem.altfield != null) {
					let altfieldCnt = policyLiabLim[elem.altfield];
                    
                    if (altfieldCnt > 0) {
                        fieldCnt = altfieldCnt;
                    }
				}

				if (fieldCnt > 0) {
					//if any field has a count and is NOT a blanket coverage, show the form
					//--still need to create the element because this is how the AdditionalInsureds array is rebuilt
					this.records = true;
					this.localInsuredsList[i].visible = this.localInsuredsList[i].isBlanket ? false : true;
					
					//for as many of additional insureds that were set in additonal coverages for this type
					for (let a = 0; a < fieldCnt; a++) {
						let found: boolean = false;
						//search the array instead of looping through each time
						let id: string = "ID" + "-" + i + "-" + a + "-";
						var grp = this.ctrQuote.ADDITIONALINSUREDS.filter(f => f.ADDTYP == elem.value || f.ADDTYP == elem.altvalue) ;
						if (grp != null && grp.length > 0) {
							grp.forEach((existing, index) => {
								if (index == a) {
									//function written below to set form control values
									
									this.SetFormData(id, existing, elem, i, a);
									found = true;
								}
							});
						}
						if (!found) {
							var adi = new ADDITIONALINSURED(this.ctrQuote.QUOTEPOLICYINFORMATION);
							//if not found create the form controls and set the addtyp to the current value
							adi.ADDTYP = elem.value;
							this.SetFormData(id, adi, elem, i, a);
						}
					}


				}
			}
			this.menuClass.menuObject(this.stepName).form = this.formGroup;
			this.changeDetectionRef.detectChanges();
		});

		this.FormGroupSubscription = this.formGroup.valueChanges.pipe(debounceTime(100), distinctUntilChanged()).subscribe(data => {
			this.data = data;
			this.ctrQuote.updateScheduledAIData(this.data);
			this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive);
		});


		//commented this out because this is not currently being used -JTL 
		// this.FormGroupSubscription = this.cpFormGroup.valueChanges.pipe(debounceTime(100), distinctUntilChanged()).subscribe(data => {
		// 	for (let key in data) {
		// 		this.ctrQuote.GLPENTITY.CONSTPROJECTLIAB.find(x => x.SPCSEQ == key).SPCDSC = data[key];
		// 	}
		// 	this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive);
		// });
	}

    ngAfterViewInit(): void {
        if (!this.migRoles.editable) {			
			this.formGroup.disable();
        }
	}
	
    SetFormData(id: string, existing: ADDITIONALINSURED, elem: any, i, a) {

        let validationLabel:string = this.getLabel(this.localInsuredsList[i].label) + ' (' + (a + 1) + '):  ';
		
		//we are adding the AINNUM value to the form control so we can pull the data when needed properly
        this.formGroup.addControl(id + "ADDTYP-" + existing.AINNUM, new UntypedFormControl(existing.ADDTYP));
        
        this.formGroup.addControl(id + "AINNAM-" + existing.AINNUM, new UntypedFormControl({value: existing.AINNAM, disabled: !this.migRoles.editable}
            , this.localInsuredsList[i].isBlanket ? 
            [Validators.nullValidator] : [this.migAddressValidator.ValidateRequired(id + 'AINNAM-' + existing.AINNAM, validationLabel +  this.localInsuredsList[i].name_label)]));

        this.formGroup.addControl(id + "AINAD1-" + existing.AINNUM, new UntypedFormControl(existing.AINAD1
            , this.localInsuredsList[i].isBlanket ? 
            [Validators.nullValidator] :  [this.migAddressValidator.ValidateRequired(id + "AINAD1-" + existing.AINAD1, validationLabel + 'Street Number')]));

        this.formGroup.addControl(id + "AINAD2-" + existing.AINNUM, new UntypedFormControl(existing.AINAD2
            , this.localInsuredsList[i].isBlanket ? 
            [Validators.nullValidator] :  [this.migAddressValidator.ValidateRequired(id + "AINAD2-" + existing.AINAD2, validationLabel + 'Street Name')]));

        this.formGroup.addControl(id + "AINCTY-" + existing.AINNUM, new UntypedFormControl(existing.AINCTY
            , this.localInsuredsList[i].isBlanket ? 
            [Validators.nullValidator] :  [this.migAddressValidator.ValidateRequired(id + "AINCTY-" + existing.AINCTY, validationLabel + 'City')]));

        this.formGroup.addControl(id + "AINST-" + existing.AINNUM, new UntypedFormControl(existing.AINST
            , this.localInsuredsList[i].isBlanket ? 
            [Validators.nullValidator] :  [this.migAddressValidator.ValidateRequired(id + "AINST-" + existing.AINST, validationLabel + 'State/Province', true)]));

        this.formGroup.addControl(id + "AINZIP-" + existing.AINNUM, new UntypedFormControl(existing.AINZIP
            , this.localInsuredsList[i].isBlanket ? 
            [Validators.nullValidator] :  [this.migAddressValidator.ValidateZipCode(id + "AINZIP-" + existing.AINZIP, validationLabel + 'Zip Code')]));

		this.formGroup.addControl(id + "AINRCN-" + existing.AINNUM, new UntypedFormControl(existing.AINRCN, 
			this.localInsuredsList[i].isBlanket ? 
			Validators.nullValidator : this.migAddressValidator.ValidateRequired(id + "AINRCN-" + existing.AINNUM, validationLabel + 'Send Cancellation Notice', false, true)));
		
		//we add the AINNUM Control so we know which AINNUM this is associated with which will allow us to easily update without having
		//to use the localInsureds list as an intermediate
		//this.formGroup.addControl(id + "AINNUM", new FormControl(existing.AINNUM));
        
        let addcd = new UntypedFormControl(existing.ADDCDE);
        if (addcd.value == null || addcd.value.length == 0) {
            addcd.setValue("A");
        }
        this.formGroup.addControl(id + "ADDCDE-" + existing.AINNUM, addcd);

        let LOCOPS = false;
        let DESPAD = false;
        let YORPRD = false;

        for (let x = 0; x < elem.additional_questions.length; x++) {

            if (elem.additional_questions[x].field == "LOCOPS") { 
                LOCOPS = true;
                this.LOCLabel = elem.additional_questions[x].label;
            }
            
            if (elem.additional_questions[x].field == "DESPAD") { 
                DESPAD = true;
                this.DESLabel = elem.additional_questions[x].label;
            }
            
            if (elem.additional_questions[x].field == "YORPRD") {
                    YORPRD = true;
            }

        }
        this.formGroup.addControl(id + "LOCOPS-" + existing.AINNUM, new UntypedFormControl(existing.LOCOPS, LOCOPS ?
            [this.migAddressValidator.ValidateRequired(id + "LOCOPS-" + existing.AINNUM, validationLabel + ' ' + this.LOCLabel)] : Validators.nullValidator));
        this.formGroup.addControl(id + "DESPAD-"+ existing.AINNUM, new UntypedFormControl(existing.DESPAD, DESPAD ?
            [this.migAddressValidator.ValidateRequired(id + "DESPAD-" + existing.AINNUM, validationLabel + ' ' + this.DESLabel)] : Validators.nullValidator));
        this.formGroup.addControl(id + "YORPRD-" + existing.AINNUM, new UntypedFormControl(existing.YORPRD, YORPRD ?
            [this.migAddressValidator.ValidateRequired(id + "YORPRD-" + existing.AINNUM, (validationLabel + 'Your Products'))] : Validators.nullValidator));

        this.localInsuredsList[i].data.push(existing);
    }
    
	ngOnDestroy() {
		this.nextClicked = false;
		this.ctrQuote.ADDITIONALINSUREDSVALIDATED = true;
		if (this.FormGroupSubscription) this.FormGroupSubscription.unsubscribe();
		this.migsystemservice.notifyToastMessagesCleared();
		this.changeDetectionRef.detach();
	}

	url: string = "./assets/sample_data/insureds.json";

	getInsuredsList() {
		return this.http.get(this.url)
			.pipe(map(res => <any[]>res));
	}

	getFieldError(fld) {
		return this.formGroup.get(fld).errors ? true : false
	}

	doesCtrQuoteContainData(fld: string) {
		for (let a = 0; a < this.ctrQuote.ADDITIONALINSUREDS.length; a++) {
			if (this.ctrQuote.ADDITIONALINSUREDS[a].ADDTYP == fld) { return true; }
		}
		return false;
	}


	getLabel(val: string): string {
		let arr = val.split(":");
		return arr[0];
	}


	funcAddAnother(fld: string) {
		this.menuClass.GotoMenuItemAndScroll("name", "AdditionalCoveragesLiability", fld);
		this.GoBackToSectionEmitter.emit(4);
	}
}
