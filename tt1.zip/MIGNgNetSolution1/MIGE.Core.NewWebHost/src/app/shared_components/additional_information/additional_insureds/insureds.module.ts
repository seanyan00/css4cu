/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule, UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { MIGUnderwritingAdditionalInsureds } from './insureds.component';
import { CheckboxModule } from 'primeng/checkbox';
import { PanelModule } from 'primeng/panel';
import { TabViewModule } from 'primeng/tabview';
import { FieldsetModule } from 'primeng/fieldset';
import { MIGMessageModule } from '@overridden/primeng-message/message.module';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { MIGInputSwitchModule } from '@overridden/primeng-inputswitch/switch.module';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';
import { DynamicComponentModule } from '@dynamic/dynamic_component/dynamic.module';
import { MenuClass } from '@root/system/menu/menu';
import { MIGSystemService } from '@services/mig.service';

@NgModule({
	imports: [
		CheckboxModule,
		FormsModule,
		TabViewModule,
		CommonModule,
		PanelModule,
		FieldsetModule,
		MIGDropDownModule,
		MIGCheckboxModule,
		MIGInputtextModule,
		MIGInputSwitchModule,
		ReactiveFormsModule,
		DynamicComponentModule,
		MIGButtonModule,
		MIGMessageModule
	],
	declarations: [MIGUnderwritingAdditionalInsureds],
	exports: [MIGUnderwritingAdditionalInsureds]
})
export class MIGAdditionalInformationAdditionalInsuredsModule {
	formGroup: UntypedFormGroup;


	constructor(
		public menuClass: MenuClass,
		private formBuilder: UntypedFormBuilder,
		public migsystemservice: MIGSystemService,
		

	) {
		this.formGroup = this.formBuilder.group({});


		menuClass.addMenuItem({
			name: 'AdditionalInformationAdditionalInsureds',
			label: 'Additional Insureds',
			color: "ui-steps-number-default",
			navSkip: false,
			active: false,
			hasError: false,
			form: this.formGroup,
			errors: [],
			buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }],
			icon: "fa fa-pen-alt",
			block: [],
			visible: false,
			level: 2,
			quote: "application"
		});

		
	}


}
