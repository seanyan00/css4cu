/* NG Includes */
import { Component, Input } from '@angular/core';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';

@Component({
	selector: 'mig-additional-information-stub',
	template: ``,

})

export class MIGAdditionalInformationStub {
	@Input() ctrQuote: CTRQuote;

	// this is just a placeholder component
	// so we can have a menu item parent
	constructor() {

	}
}
