/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule, UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { MIGAdditionalInformationStub } from './additionalinformation.component';
import { CheckboxModule } from 'primeng/checkbox';
import { PanelModule } from 'primeng/panel';
import { TabViewModule } from 'primeng/tabview';
import { FieldsetModule } from 'primeng/fieldset';
import { DropdownModule } from 'primeng/dropdown';
import { InputTextModule } from 'primeng/inputtext';
import { MIGInputSwitchModule } from '@overridden/primeng-inputswitch/switch.module';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';
import { DynamicComponentModule } from '@dynamic/dynamic_component/dynamic.module';
import { MenuClass } from '@root/system/menu/menu';
import { TextMaskModule } from 'angular2-text-mask';

// import { NgModel } from '@angular/forms';
@NgModule({
	imports: [
		CheckboxModule,
		FormsModule,
		TabViewModule,
		CommonModule,
		PanelModule,
		FieldsetModule,
		DropdownModule,
		MIGCheckboxModule,
		InputTextModule,
		MIGInputSwitchModule,
		ReactiveFormsModule,
		DynamicComponentModule,
		TextMaskModule
	],
	declarations: [MIGAdditionalInformationStub],
	exports: [MIGAdditionalInformationStub]
})
export class MIGAdditionalInformationStubModule {
	formGroup: UntypedFormGroup;
	constructor(
		public menuClass: MenuClass,
		private formBuilder: UntypedFormBuilder,
	) {
		this.formGroup = this.formBuilder.group({});

		menuClass.addMenuItem({
			name: 'AdditionalInformationStub',
			label: 'Additional Information',
			color: "ui-steps-number-default",
			navSkip: true,
			active: false,
			hasError: false,
			errors: [],
			buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }],
			icon: "fa fa-pen-alt",
			block: [],
			visible: true
		});
	}
}
