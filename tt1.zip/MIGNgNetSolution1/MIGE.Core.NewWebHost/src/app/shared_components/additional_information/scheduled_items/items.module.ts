/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule, UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { MIGUnderwritingScheduledItems } from './items.component';
import { PanelModule } from 'primeng/panel';
import { TabViewModule } from 'primeng/tabview';
import { FieldsetModule } from 'primeng/fieldset';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { MIGInputSwitchModule } from '@overridden/primeng-inputswitch/switch.module';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { DynamicComponentModule } from '@dynamic/dynamic_component/dynamic.module';
import { MenuClass } from '@root/system/menu/menu';
import { TextMaskModule } from 'angular2-text-mask';
import { MIGSystemService } from '@services/mig.service';
import { MIGMessageModule } from '@overridden/primeng-message/message.module';
import { PipesModule } from '@pipes/pipes.module';
import { MIGYearPickerModule } from '@overridden/mig-yearpicker/year.module';
import { TooltipModule } from 'primeng/tooltip';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
@NgModule({
	imports: [
		FormsModule,
		TabViewModule,
		CommonModule,
		PanelModule,
		FieldsetModule,
		MIGDropDownModule,
		MIGCheckboxModule,
		MIGInputtextModule,
		MIGInputSwitchModule,
		MIGButtonModule,
		ReactiveFormsModule,
		DynamicComponentModule,
		TextMaskModule,
		MIGMessageModule,
		MIGYearPickerModule,
		TooltipModule,
		PipesModule
	],
	declarations: [MIGUnderwritingScheduledItems],
	exports: [MIGUnderwritingScheduledItems]
})
export class MIGAdditionalInformationScheduledItemsModule {
	formGroup: UntypedFormGroup;

	constructor(
		public menuClass: MenuClass,
		private formBuilder: UntypedFormBuilder,
		public migsystemservice: MIGSystemService
	) {
		this.formGroup = this.formBuilder.group({});
		let found: boolean = false;

		menuClass.addMenuItem({
			name: 'AdditionalInformationScheduledItems',
			label: 'Scheduled Items',
			color: "ui-steps-number-default",
			navSkip: !found,
			active: false,
			hasError: false,
			errors: [],
			form: this.formGroup,
			buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }],
			icon: "fa fa-pen-alt",
			block: [],
			visible: found,
			level: 2,
			quote: "application"
		});
		this.migsystemservice.subscribeQuoteChanged().subscribe((quoteInfo: CTRQuote) => {
			found = false;
			let impProducts = quoteInfo.IMPENTITY.IMPPRODUCTS;
			let tot = impProducts ? Number(impProducts.CTRSCL): 0;
			if(this.menuClass.menuObject("AdditionalInformationScheduledItems")){ // added nullcheck here because this menuobject will not be added for policy inquiries -JTL
				if (tot > 0) {
					found = true;
					if (!(this.menuClass.menuObject("AdditionalInformationScheduledItems").visible)) {
						this.migsystemservice.notifySystemMessage({ msg: "New step added to complete: Underwriting Schedule > Scheduled Items", severity: "info" })
					}
				}
				if (found) {
					this.menuClass.ShowHideMenuItemAt(found, "AdditionalInformationScheduledItems");
					//this.menuClass.ShowHideMenuItemAt(found, "AdditionalInformationStub");
					//this.menuClass.menuObject("AdditionalInformationStub").navSkip = true;
					this.menuClass.menuObject("AdditionalInformationScheduledItems").navSkip = false;
				} else {
					this.menuClass.ShowHideMenuItemAt(found, "AdditionalInformationScheduledItems");
					this.menuClass.menuObject("AdditionalInformationScheduledItems").navSkip = true;
				}
			}
			// let calcScheduledLimit = function(quoteInfo): string {
			// 	let tmp = 0;
			// 	for (let i = 0; i < quoteInfo.IMPENTITY.IMPSCHEDULEDITEMS.length; i++) {
			// 		let dummy = quoteInfo.IMPENTITY.IMPSCHEDULEDITEMS[i].ITMVAL.toString();
			// 		dummy = dummy.replace(/\D/g, '');
			// 		tmp = tmp + parseInt(dummy);
			// 	}

			// 	let dummy2 = (quoteInfo.IMPENTITY.IMPPRODUCTS.CTRSCL ? quoteInfo.IMPENTITY.IMPPRODUCTS.CTRSCL : 100000) - tmp;
			// 	let scheduledLimit = dummy2.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
			// 	return "Limit: " + quoteInfo.IMPENTITY.IMPPRODUCTS.CTRSCL + " Remainder: " + scheduledLimit;
			// }

		});

	}


}
