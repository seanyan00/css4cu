/******************************************************************************************************
     * PROGRAM DESCRIPTION  - Items component used for Scheduled Items
	 * 						- JTL 8/14/19: "this field is required" only appears when user clicks next and 
	 * 									 there are still errors
	 * 
	 * NOTES: 
	 * - If we were to implement the error panel, you would need to use ValidateRequired 
	 * rather than Validators.Required because the field string you pass in is important for 
	 * the error message navigation feature. 
	 * - Because there could be multiple items where the same control could be invalid,
	 * we would need to specify in the field string what item we're talking about. (see insureds.component.ts)
	 * 
	 * 
****************************************************************************************************/

/* NG Includes */
import { Component, ViewEncapsulation, OnInit, ChangeDetectorRef, Input, OnDestroy } from '@angular/core';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { UntypedFormGroup, UntypedFormControl, Validators, UntypedFormArray, UntypedFormBuilder } from '@angular/forms';
import { MenuClass } from '@root/system/menu/menu';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';

import { MIGSystemService } from '@services/mig.service';
import { Subscription } from 'rxjs/internal/Subscription';
//import { IMPEntity } from '@classes/CustomEntity/IMPEntity';
import { Panel, PanelModule } from 'primeng/panel';
import { InputMasksClass } from '@helpers/masks';
import { IMPSCHEDULEDITEM } from '@classes/CTR/IMPSCHEDULEDITEMS';
import { MIGItemsValidator } from './items.validators';
import { AppErrors } from '@root/shared_components/errors/app-errors';
import * as _ from 'lodash';

@Component({
	selector: 'mig-underwriting-scheduled-items',
	templateUrl: './items.component.html',
	styleUrls: ['./items.component.css'],
	encapsulation: ViewEncapsulation.None

})

export class MIGUnderwritingScheduledItems implements OnInit, OnDestroy {
	@Input() ctrQuote: CTRQuote;

	stepName: string = "AdditionalInformationScheduledItems";
	formGroup: UntypedFormGroup;
	formGroupList: UntypedFormGroup;
	errors: AppErrors [];
	formList: UntypedFormArray;
	migItemsValidator: MIGItemsValidator;
	data: any;
	collapsed: true;
	scheduledLimit: string;
	adding: boolean = true;
	FormGroupSubscription: any;
	FormGroupListSubscription: Subscription;

	updateRecordState: Subscription;

	saveClicked: boolean;
	constructor(
		private cd: ChangeDetectorRef,
		public menuClass: MenuClass,
		public migRoles: MIGSecurityRoles,
		public migsystemservice: MIGSystemService,
		private formBuilder: UntypedFormBuilder,
		public masks: InputMasksClass
	) {
		this.migItemsValidator = new MIGItemsValidator();
	}

	get ITEMNO() { return this.formGroup.get("ITEMNO"); }
	get ITEMDC() { return this.formGroup.get("ITEMDC"); }
	get ITMMFG() { return this.formGroup.get("ITMMFG"); }
	get ITMMDL() { return this.formGroup.get("ITMMDL"); }
	get ITMMYR() { return this.formGroup.get("ITMMYR"); }
	get SERIAL() { return this.formGroup.get("SERIAL"); }
    get ITMVAL() { return this.formGroup.get("ITMVAL"); }
    get ITEMLIMIT() { return this.formGroup.get("ITEMLIMIT"); }


	ngOnInit() {
		//6-9-2020: changed validation rules so that fields are only required when there are no items -JTL
		this.formGroup = this.menuClass.menuObject(this.stepName).form;

		// Item #
		this.formGroup.addControl("ITEMNO", new UntypedFormControl(1));

		// Item Description

		this.formGroup.addControl("ITEMDC", new UntypedFormControl('', this.ctrQuote.IMPENTITY.IMPSCHEDULEDITEMS.length==0 ? this.migItemsValidator.ValidateRequired('ITEMDC', 'Item Description') : null));

		// Manufactuerer
		this.formGroup.addControl("ITMMFG", new UntypedFormControl("", this.ctrQuote.IMPENTITY.IMPSCHEDULEDITEMS.length==0 ? this.migItemsValidator.ValidateRequired('ITMMFG', 'Manufacturer') : null));

		// Item Model
		this.formGroup.addControl("ITMMDL", new UntypedFormControl(""));

		// Item Model Year
		this.formGroup.addControl("ITMMYR", new UntypedFormControl(null, this.ctrQuote.IMPENTITY.IMPSCHEDULEDITEMS.length==0 ? this.migItemsValidator.ValidateRequired('ITMMYR', 'Year'): null));

		// Serial Number
		this.formGroup.addControl("SERIAL", new UntypedFormControl(""));

		// $ Amount
		this.formGroup.addControl("ITMVAL", new UntypedFormControl(null, this.ctrQuote.IMPENTITY.IMPSCHEDULEDITEMS.length==0 ? this.migItemsValidator.ValidateRequired('ITMVAL', 'Amount of Insurance'): null ));
		this.formGroup.addControl("ITEMLIMIT", new UntypedFormControl(null));
        this.enableTotalScheduledLimitRemaningValidation();

		this.formGroupList = this.formBuilder.group({
			items: this.formBuilder.array([])
        });
        
        this.ctrQuote.IMPENTITY.IMPSCHEDULEDITEMS.forEach(element => {
            this.formList = this.formGroupList.get("items") as UntypedFormArray;
            this.formList.push(this.createItem(element));
        });
        
        this.adding = false;
        
        this.calcScheduledLimit();

		this.formGroup.valueChanges.pipe(debounceTime(300)).subscribe(() => {
            this.calcScheduledLimit();
            
            if (this.adding)
                this.disableTotalScheduledLimitRemaningValidation();
            
            this.errors = this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive);

            if (this.adding)
                this.enableTotalScheduledLimitRemaningValidation();
		});
	}

    enableTotalScheduledLimitRemaningValidation()
    {
        this.ITEMLIMIT.setValidators(this.migItemsValidator.ValidateSpecificNumericValue("ITEMLIMIT", "Total Scheduled Limit Remaining", 0));
        this.ITEMLIMIT.updateValueAndValidity({emitEvent: false});
    }

    disableTotalScheduledLimitRemaningValidation()
    {
        this.ITEMLIMIT.setValidators(Validators.nullValidator);
        this.ITEMLIMIT.updateValueAndValidity({emitEvent: false});
    }

	ngOnDestroy() {
		this.ctrQuote.SCHEDITEMSVALIDATED = true;
        this.cancelAdd(); //6-9-2020 : case where a user clicks add item, goes to a previous page, and comes back, we don't want there to be validation when there is no "add item" fields displayed. -JTL 
        if (this.FormGroupListSubscription)
            this.FormGroupListSubscription.unsubscribe();
        
        this.cd.detach();
	}
    
	createItem(data): UntypedFormGroup {
			let fbg = this.formBuilder.group({
			ITEMNO: [data.ITEMNO, Validators.required],
			ITEMDC: [data.ITEMDC],
			ITMMFG: data.ITMMFG,
			ITMMDL: data.ITMMDL,
			ITMMYR: [data.ITMMYR],
			SERIAL: data.SERIAL,
			ITMVAL: [data.ITMVAL],
			collapsed: true
		});
		this.addValidation(fbg);
		return fbg;
		
	}

	clearAddItem() {
		this.formGroup.reset();
		this.collapsed = true;
	}
	addValidation(fg? : UntypedFormGroup) {
		if(fg) {
			fg.get('ITEMDC').setValidators(this.migItemsValidator.ValidateRequired('ITEMDC', 'Item Description'));
			fg.get('ITMMFG').setValidators(this.migItemsValidator.ValidateRequired('ITMMFG', 'Item Manufacturer'));
			fg.get('ITMMYR').setValidators(this.migItemsValidator.ValidateRequired('ITMMYR', 'Item Model Year'));
			fg.get('ITMVAL').setValidators(this.migItemsValidator.ValidateRequired('ITMVAL', 'Item Value'));
			this.migItemsValidator.TriggerValidation(fg);
		} else {
			this.ITEMDC.setValidators(this.migItemsValidator.ValidateRequired('ITEMDC', 'Item Description'));
			this.ITMMFG.setValidators(this.migItemsValidator.ValidateRequired('ITMMFG', 'Item Manufacturer'));
			this.ITMMYR.setValidators(this.migItemsValidator.ValidateRequired('ITMMYR', 'Item Model Year'));
			this.ITMVAL.setValidators(this.migItemsValidator.ValidateRequired('ITMVAL', 'Item Value'));
			this.migItemsValidator.TriggerValidation(this.formGroup);
		}
	}
	removeValidation() {
		this.ITEMDC.setValidators(Validators.nullValidator);
		this.ITMMFG.setValidators(Validators.nullValidator);
		this.ITMMYR.setValidators(Validators.nullValidator);
		this.ITMVAL.setValidators(Validators.nullValidator);
		this.migItemsValidator.TriggerValidation(this.formGroup);
	}
	cancelAdd() {
        this.removeValidation();
        this.enableTotalScheduledLimitRemaningValidation();
		this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive);
        
        if (!this.ctrQuote.IMPENTITY.IMPSCHEDULEDITEMS.length)
        { 
            return false;
        }

		this.errors = [];
		this.migsystemservice.notifyToastMessagesCleared();
		this.migsystemservice.subscribeXClicked();
		this.clearAddItem();
		this.cd.markForCheck();
		this.adding = false;
		
	}

	checkValidity(index, desc, year, val, pan: Panel){
		//method is called when "+ Save" button is clicked. the index parameter is the form group name, 
		// which signals which item to look at. the desc, year, and val are the 3 controls that we need to validate
		// the last parameter just holds the panel so it can pass it into the saveEdit method if neccessary.

		//need to check validation when editing also.
		this.calcScheduledLimit();
		let tmpFG = this.formList.controls[index] as UntypedFormGroup
		//This is a little tricky because we are using a seperate formGroup list, NOT the formGroup used when creating an item
		//need to pass in the formGroup index in the formList to Calculate Errors due to the way it handles single forms once the proper validation is on it
		this.errors = this.menuClass.CalculateErrorsFormGroup(tmpFG);
		
        this.migsystemservice.notifyDoneClicked(this.errors);
        
        if (this.errors && this.errors.length)
            return;

		if (desc=="" || year==0 || val==0) {
			this.saveClicked = true;
		}
		else {
            this.saveClicked = false;
			this.saveEdit(index, val, pan)
		}
	}

	saveEdit(index, elem, pan: Panel) {	
		let ogITMVAL = elem;
		this.ctrQuote.IMPENTITY.IMPSCHEDULEDITEMS[index].ITMVAL = ogITMVAL.toString().replace(/[^0-9.-]+/g,"");
		this.ctrQuote.IMPENTITY.IMPSCHEDULEDITEMS[index].POLICY = this.ctrQuote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
		this.ctrQuote.IMPENTITY.IMPSCHEDULEDITEMS[index].EFFDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
		this.ctrQuote.IMPENTITY.IMPSCHEDULEDITEMS[index].TRANS  = this.ctrQuote.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;
		this.ctrQuote.IMPENTITY.IMPSCHEDULEDITEMS[index].RCDTYP = this.ctrQuote.QUOTEPOLICYINFORMATION.RECORDTYPE;
		this.ctrQuote.IMPENTITY.IMPSCHEDULEDITEMS[index].EDSDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;
		this.ctrQuote.IMPENTITY.IMPSCHEDULEDITEMS[index].RECORDSTATE = "U";
        pan.collapse(null);
        this.enableTotalScheduledLimitRemaningValidation();
		this.calcScheduledLimit();
	}

	createNewItem() {
        this.adding = true;
        this.clearAddItem();
		this.addValidation();
	}

	funcAddItem() {
        
        this.disableTotalScheduledLimitRemaningValidation();
		this.errors = this.menuClass.CalculateErrorsFormGroup(this.formGroup);
        this.migsystemservice.notifyDoneClicked(this.errors);
        this.enableTotalScheduledLimitRemaningValidation();
        
        if (this.errors && this.errors.length)
            return;
		
		if(this.formGroup.get('ITMVAL') && this.ITMVAL.value != null) this.formGroup.get('ITMVAL').setValue(this.ITMVAL.value.toString().replace(/[^0-9.-]+/g,""));
		this.ctrQuote.IMPENTITY.saveScheduledItem(this.formGroup.value as IMPSCHEDULEDITEM);
		this.formList = this.formGroupList.get("items") as UntypedFormArray;
		this.formList.push(this.createItem(this.formGroup.value as IMPSCHEDULEDITEM));
		this.calcScheduledLimit();
		this.adding = false;
		this.saveClicked=false;
		
	}

	deleteItem(scheduledItem: IMPSCHEDULEDITEM, formGroupIndex: number) {
		this.ctrQuote.IMPENTITY.deleteScheduledItem(this.ctrQuote.IMPENTITY.IMPSCHEDULEDITEMS[formGroupIndex]);
		this.formList = this.formGroupList.get("items") as UntypedFormArray;
		this.formList.removeAt(formGroupIndex);
		this.calcScheduledLimit();

	}

	calcScheduledLimit() {
		let tmp = 0;
		for (let i = 0; i < this.ctrQuote.IMPENTITY.IMPSCHEDULEDITEMS.length; i++) {
			let dummy = this.ctrQuote.IMPENTITY.IMPSCHEDULEDITEMS[i].ITMVAL ? this.ctrQuote.IMPENTITY.IMPSCHEDULEDITEMS[i].ITMVAL.toString(): '';
			dummy = dummy.replace(/\D/g, '');
			tmp = tmp + parseInt(dummy);
		}

        let scheduledLimit = (this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL ? this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL : 100000) - tmp;
        this.ITEMLIMIT.patchValue(scheduledLimit, {emitEvent:false});
		this.scheduledLimit = scheduledLimit.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,")
	}

	trackBy(index, item) {
		if (!item) return null;
		return index;
	}
}
