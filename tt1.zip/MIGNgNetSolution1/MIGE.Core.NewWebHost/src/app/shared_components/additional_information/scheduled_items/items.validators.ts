import { AbstractControl, FormControl, Validators, FormGroup, ValidatorFn} from "@angular/forms";
import { Validation } from '@classes/Common/ValidatorClass/Validation';


export class MIGItemsValidator extends Validation {
    constructor() {
        super();
    }

}