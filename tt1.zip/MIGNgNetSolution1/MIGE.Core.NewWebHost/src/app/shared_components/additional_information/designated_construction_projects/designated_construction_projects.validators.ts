import { Validation } from '@classes/Common/ValidatorClass/Validation';


export class MIGDesignatedConstValidator extends Validation {
    constructor() {
        super();
    }
}