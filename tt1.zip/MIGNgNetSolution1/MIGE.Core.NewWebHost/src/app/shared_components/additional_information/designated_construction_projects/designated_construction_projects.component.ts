/* NG Includes */
import { Component, ViewEncapsulation, OnInit, EventEmitter, Output, Input, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { MenuClass } from '@system/menu/menu';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { UntypedFormGroup, UntypedFormControl } from '@angular/forms';
import { Subscription } from 'rxjs';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { MIGSystemService } from '@services/mig.service';
import { MIGDesignatedConstValidator } from './designated_construction_projects.validators';


@Component({
	selector: 'mig-underwriting-designated-construction-projects',
	templateUrl: './designated_construction_projects.component.html',
	styleUrls: ['designated_construction_projects.component.css'],
	encapsulation: ViewEncapsulation.None
})

export class MIGUnderwritingDesignatedConstructionProjects implements OnInit, OnDestroy {
	@Output() GoBackToSectionEmitter = new EventEmitter<any>();
	@Input() ctrQuote: CTRQuote;
	stepName: string = "AdditionalInformationDesignatedConstructionProjects";
	cpFormGroup:UntypedFormGroup;
	records: boolean = false;
	FormGroupSubscription: Subscription;
	migDesignatedConstValidator: MIGDesignatedConstValidator;

    constructor
    (
		public changeDetectionRef: ChangeDetectorRef,
		public menuClass: MenuClass,
		public contractorsDropDowns: ContractorsDropDowns,
		public migRoles: MIGSecurityRoles,
		public migsystemservice: MIGSystemService
    )
    {
		this.migDesignatedConstValidator = new MIGDesignatedConstValidator();
	}

	ngOnInit() {

		//CONSTPROJECTLIAB form group
		this.cpFormGroup = this.menuClass.menuObject(this.stepName).form;
		if (this.ctrQuote.GLPENTITY.CONSTPROJECTLIAB.length > 0) { this.records = true; }
		
		this.ctrQuote.GLPENTITY.CONSTPROJECTLIAB.forEach(elem => {
			this.cpFormGroup.addControl(elem.SPCSEQ, new UntypedFormControl( (elem.SPCDSC) ? elem.SPCDSC : '', this.migDesignatedConstValidator.ValidateRequired('Description', 'Description for Designated Construction Project: ' + elem.SPCSEQ)));
		});

		this.FormGroupSubscription = this.cpFormGroup.valueChanges.pipe(debounceTime(100), distinctUntilChanged()).subscribe(data => {
			for (let key in data) {				
				this.ctrQuote.GLPENTITY.CONSTPROJECTLIAB.find(x => x.SPCSEQ == key).SPCDSC = data[key];
			}
		})
	}

	ngOnDestroy() {
		this.ctrQuote.CONSTPROJVALIDATED = true;
		if(this.FormGroupSubscription) this.FormGroupSubscription.unsubscribe();
		this.changeDetectionRef.detach();
	}
}
