/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule, UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { MIGUnderwritingDesignatedConstructionProjects } from './designated_construction_projects.component';
import { CheckboxModule } from 'primeng/checkbox';
import { PanelModule } from 'primeng/panel';
import { TabViewModule } from 'primeng/tabview';
import { FieldsetModule } from 'primeng/fieldset';
import { MIGMessageModule } from '@overridden/primeng-message/message.module';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { MIGInputSwitchModule } from '@overridden/primeng-inputswitch/switch.module';
import { MIGTextareaModule } from '@overridden/primeng-textarea/area.module';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';
import { DynamicComponentModule } from '@dynamic/dynamic_component/dynamic.module';
import { MenuClass } from '@root/system/menu/menu';
import { MIGSystemService } from '@services/mig.service';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';

@NgModule({
	imports: [
		CheckboxModule,
		FormsModule,
		TabViewModule,
		CommonModule,
		PanelModule,
		FieldsetModule,
		MIGDropDownModule,
		MIGCheckboxModule,
		MIGInputtextModule,
		MIGInputSwitchModule,
		ReactiveFormsModule,
        DynamicComponentModule,
        MIGTextareaModule,
		MIGButtonModule,
		MIGMessageModule
	],
	declarations: [MIGUnderwritingDesignatedConstructionProjects],
	exports: [MIGUnderwritingDesignatedConstructionProjects]
})
export class MIGAdditionalInformationDesignatedConstructionProjectsModule {
	formGroup: UntypedFormGroup;

    constructor
    (
		public menuClass: MenuClass,
		private formBuilder: UntypedFormBuilder,
		public migsystemservice: MIGSystemService,
    )
    {
		this.formGroup = this.formBuilder.group({});

		let found = false;

		menuClass.addMenuItem({
			name: 'AdditionalInformationDesignatedConstructionProjects',
			label: 'Designated Const. Projects',
			color: "ui-steps-number-default",
			navSkip: !found,
			active: false,
			hasError: false,
			form: this.formGroup,
			errors: [],
			buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }],
			icon: "fa fa-pen-alt",
			block: [],
			visible: found,
			level: 2,
			quote: "application"
		});

		this.migsystemservice.subscribeQuoteChanged().subscribe((quoteInfo:CTRQuote) => {
			
			found = false;
	
			
			quoteInfo.GLPENTITY.CONSTPROJECTLIAB.length ? found = true : found;
				if(this.menuClass.menuObject("AdditionalInformationDesignatedConstructionProjects")){ //12/23/20 added null check here because this will not be included in policy inquiries. -JTL
					if (!(this.menuClass.menuObject("AdditionalInformationDesignatedConstructionProjects").visible)) {
						this.migsystemservice.notifySystemMessage({ msg: "New step added to complete: Underwriting Schedule > Designated Construction Projects", severity: "info" })
					}
							
					this.menuClass.ShowHideMenuItemAt(found, "AdditionalInformationDesignatedConstructionProjects");
					//this.menuClass.ShowHideMenuItemAt(found, "AdditionalInformationStub");

					//this.menuClass.menuObject("AdditionalInformationStub").navSkip = true;
					this.menuClass.menuObject("AdditionalInformationDesignatedConstructionProjects").navSkip = false;	
				}
		});
	}
}
