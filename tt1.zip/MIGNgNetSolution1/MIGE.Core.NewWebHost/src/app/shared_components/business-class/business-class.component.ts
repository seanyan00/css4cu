/* ****************************************************************************************************
* PROGRAM DESCRIPTION  - Business Class 
* NOTES: 
* - This component is currently specific to CTR business classes
* BUG FIXES: 
* 	- 2/3/22: Changed form from NGModel to form controls in order for checkbox & validation to function properly (JIRA-MSC-20777) -JTL
* 	- 2/16/22: Fixed Angular V13-specific issue where checked ifAny checkbox wasn't persisting (Azure Bug 57) -JTL
****************************************************************************************************/
import {ChangeDetectorRef,Component,Input,OnInit,ViewChild,ViewEncapsulation,Inject,OnDestroy} from '@angular/core';
import { InputMasksClass } from '@helpers/masks';
import { DOCUMENT } from "@angular/common";
import { MessageService } from 'primeng/api';
import {ConfirmationService} from 'primeng/api'
import { RiskAppetiteGuideComponent } from '@shared/risk-appetite-guide/risk-appetite-guide.component';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { ContractorsTooltips } from '@helpers/tooltips';
import { Functions } from '@helpers/functions';
import { MIGSystemService } from '@services/mig.service';
import { MenuClass } from '@root/system/menu/menu';
import { trigger,state,style,transition,animate } from '@angular/animations';
import { MIGBusinessClassValidators } from './business-class.validators';
import * as _ from 'lodash';
import { UntypedFormGroup, UntypedFormControl, Validators, AbstractControl } from '@angular/forms';
import { Subscription } from 'rxjs';
import { distinctUntilChanged } from 'rxjs/operators';

@Component({
	selector: 'mig-business-class',
	templateUrl: './business-class.component.html',
	animations: [
        trigger('rowExpansionTrigger', [
            state('void', style({
                transform: 'translateX(-10%)',
                opacity: 0
            })),
            state('active', style({
                transform: 'translateX(0)',
                opacity: 1
            })),
            transition('* <=> *', animate('400ms cubic-bezier(0.86, 0, 0.07, 1)'))
        ])
	],
	styleUrls: ['../quote_information/quote_information.component.css'],
	encapsulation: ViewEncapsulation.None,
})

export class MIGBusinessClass implements OnInit, OnDestroy {
	@Input() ctrQuote: any;
    @Input() LOCNUM: string;
    @Input() businessClassFormGroup: UntypedFormGroup;
	// remove me
	@Input() localGLCLASSLIST: any[] = [];
	@ViewChild(RiskAppetiteGuideComponent, { static: false }) RAGComponent: RiskAppetiteGuideComponent;

	//data & keys - needed for Eligibility(guidelines) expander row in table
	data:any  = [];
	keys: any = [1];

	INJPAY: number;
	INJPAYdisplay: number;
	INJPAYIfAny: boolean = false;
	exposure: number;
	currentClasx:string = null;
	locationindex:string;;
	showAddGLClass: boolean = false;
	businessClassValidators: MIGBusinessClassValidators;
    errors: any = [];
	businessClassCopy;
	editClicked: boolean;
	visExposure: boolean = false;
	vis: boolean = false;
	defaultClass: boolean = false;
	FormGroupSubscription: Subscription;
	constructor(
		public masks: InputMasksClass,
		public confirmationService: ConfirmationService,
		public changeDetectionRef: ChangeDetectorRef,
		public contractorsTooltips:ContractorsTooltips,
		public migRoles: MIGSecurityRoles,
		public migsystemservice: MIGSystemService,
		public messageService: MessageService,
		public menuClass: MenuClass,
		public func:Functions,
		@Inject(DOCUMENT) public document: Document
	) {
		this.businessClassValidators = new MIGBusinessClassValidators();
	}

	ngOnInit() {

        this.businessClassFormGroup.addControl("HASPRIMARYCLASS", new UntypedFormControl(false, this.businessClassValidators.ValidateControlIsTrue("A primary class code must be selected")));
        //this.businessClassFormGroup.addControl("PAYROLLSMEETMINIMUMS", new FormControl(false, this.businessClassValidators.ValidateControlIsTrue("Payroll GL Classes do not meet required minimums")));

		this.funcGatherData();
		//convert to number and send in for glclass lookup
		if (this.LOCNUM && this.LOCNUM.length == 3) {
			this.locationindex = this.LOCNUM;
		}
		this.setUpFormGroupSubscription();
		this.businessClassFormGroup.updateValueAndValidity();
    }

    ngOnDestroy(): void {
		this.close();
		this.FormGroupSubscription.unsubscribe();
        this.changeDetectionRef.detach();
    }
	
	ngAfterViewInit(): void {
		//Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
		//Add 'implements AfterViewInit' to the class.

		//this ensures validation is done on load in case there is already a value in there
		//otherwise it would only fire when a user changes the value in the input
        let index = _.findIndex(this.ctrQuote.GLPENTITY.GLCLASSLIST, {'LOCNUM': this.LOCNUM, 'RECORDSTATE': 'U'});
								
        if (index == -1)
            return;

		//this.onChange(this.ctrQuote.GLPENTITY.GLCLASSLIST[index].EXPOSE, this.ctrQuote.GLPENTITY.GLCLASSLIST[index]);
		//we need to set values for all items in the list or else they will fail validation
		this.setValues();

		//check after view to see if there is an INJPAY and display the PAYROLl textbox
		//checking the EXPOSE from CLASX to show or hide INJPAY textbox
		if(this.ctrQuote.GLPENTITY.GLCLASSLIST.find((x: any)=>x.LOCNUM === this.LOCNUM && x.CLASX === '013590' && x.RECORDSTATE !== 'D'))
			this.INJPAYdisplay = this.ctrQuote.GLPENTITY.GLCLASSLIST.find((x: any)=>x.LOCNUM === this.LOCNUM && x.CLASX === '013590' && x.RECORDSTATE !== 'D').EXPOSE;
			//this.INJPAYdisplay = this.ctrQuote.GLPENTITY.GLCLASSLIST.find((x: any)=>x.LOCNUM === this.LOCNUM && x.CLASX === '013590' && x.RECORDSTATE !== 'D').INJPAY;

		if(!this.migRoles.editable) {
			//the id starting with "exposure"
			this.document.querySelector('[id^="exposure"]').setAttribute("disabled", "");
			if (this.document.getElementById('INJPAY') != null) {
				this.document.getElementById('INJPAY').setAttribute("disabled", "");
			}
		}
	}

	//we need to loop through each item and set the values
	setValues() {		
		this.ctrQuote.GLPENTITY.GLCLASSLIST.forEach(item => {			
			if(item.LOCNUM == this.LOCNUM && item.RECORDSTATE !='D') {
				this.businessClassFormGroup.get(item.CLASX + "Exposure").setValue(item.EXPOSE == 0 ? '' : item.EXPOSE,{emitEvent:false}); // 2/7/22: if exposure is 0, set form control to blank instead of 0 so the text box shows blank instead of "$0" -JTL
				this.businessClassFormGroup.get(item.CLASX + "IfAny").setValue(item.IFANY == "Y" ? true : false, {emitEvent: false});
				if(item.CLASX === '013590') this.businessClassFormGroup.get(`${item.CLASX}PAYROLL`).setValue(item.INJPAY,{emitEvent:false});
			}			
		});
	}
	// //change event for the EXPOSURE number
	// onChange(event, row, setDirty?){
	// 	//setting EXPOSE to 0 is necessary to show blank textbox but needs to be a decimal value saving to BE

	// 	this.ctrQuote.GLPENTITY.GLCLASSLIST.find((x: any)=>x.LOCNUM === this.LOCNUM && x.CLASX === row.CLASX && x.RECORDSTATE !== 'D').EXPOSE = this.func.justNumbers(event);
	// 	//checking the EXPOSE to show or hide INJPAY textbox
	// 	if(this.businessClassFormGroup.get(row.CLASX + "Exposure")) this.businessClassFormGroup.get(row.CLASX + "Exposure").setValue(this.func.justNumbers(event),{emitEvent:false});
	// 	console.log("fg: ", this.businessClassFormGroup.value)
	// 	//we need to ensure if Class 013590 is chosen and Gross Sales is > 0 then INJPAYdisplay is shown
	// 	this.INJPAYdisplay = this.ctrQuote.GLPENTITY.GLCLASSLIST.some((x: any)=> x.CLASX === '013590') ? this.func.justNumbers(event) : 0;
	// 	if(this.INJPAYdisplay == 0 || row.CLASX !== '013590')
	// 	{
	// 		this.ctrQuote.GLPENTITY.GLCLASSLIST.find((x: any)=>x.LOCNUM === this.LOCNUM && x.CLASX === row.CLASX && x.RECORDSTATE !== 'D').INJPAY = 0;
    //     }
	// 	if (setDirty) {
	// 		this.businessClassFormGroup.markAsDirty();
	// 	}

	// 	if(row.CLASX === '013590') {
	// 		if(this.INJPAYdisplay > 0 && this.businessClassFormGroup.get('013590PAYROLL')) {

	// 		this.businessClassFormGroup.get('013590PAYROLL').setValidators(
	// 			this.businessClassValidators.ValidateMinValue(`${row.CLASX}PAYROLL`, `${row.CLASX} PAYROLL`, 1, 'must be at least', true));
	// 		this.businessClassFormGroup.get('013590PAYROLL').updateValueAndValidity({emitEvent:false});
	// 		} else {
	// 			if(row.CLASX === '013590' && !this.businessClassFormGroup.get(`${row.CLASX}PAYROLL`))  this.addPayrollControlForGlazier(row.INJPAY);
	// 			this.businessClassFormGroup.get('013590PAYROLL').setValidators(Validators.nullValidator);
	// 			this.businessClassFormGroup.get('013590PAYROLL').updateValueAndValidity({emitEvent:false});
	// 		}
	// 	}

    //     this.checkForValidPrimaryClass();

	// }
	// //updates to the PAYROLL input if it is 013590
	// onINJPAYChange(event,row){
	// 	event = (event.checked == false ? 0 : event);
	// 	this.ctrQuote.GLPENTITY.GLCLASSLIST.find((x: any)=>x.LOCNUM === this.LOCNUM && x.CLASX === row.CLASX && x.RECORDSTATE !== 'D').INJPAY = this.func.justNumbers(event);
	// 	if(this.businessClassFormGroup.get('013590PAYROLL')) this.businessClassFormGroup.get('013590PAYROLL').setValue(this.func.justNumbers(event), {emitEvent:false});
	// 	this.checkForValidPrimaryClass();
	// }

	// //updates to IFANY box being checked
	// onIFANYChange(event, row){
	// 	//

	// 	// this.ctrQuote.GLPENTITY.GLCLASSLIST.find(x=>x.LOCNUM === this.LOCNUM && x.CLASX === row.CLASX && x.RECORDSTATE !== 'D').EXPOSE = (event == true ? '0': '0');
	// 	// this.ctrQuote.GLPENTITY.GLCLASSLIST.find(x=>x.LOCNUM === this.LOCNUM && x.CLASX === row.CLASX && x.RECORDSTATE !== 'D').IFANY  = (event == true ? 'Y': '');

	// 	this.ctrQuote.GLPENTITY.GLCLASSLIST.find(x=>x.LOCNUM === this.LOCNUM && x.CLASX === row.CLASX && x.RECORDSTATE !== 'D').EXPOSE = (event.checked == true ? '0': '0');
	// 	this.ctrQuote.GLPENTITY.GLCLASSLIST.find(x=>x.LOCNUM === this.LOCNUM && x.CLASX === row.CLASX && x.RECORDSTATE !== 'D').IFANY  = (event.checked == true ? 'Y': '');


	// 	//
	// 	this.INJPAYIfAny  = (row.CLASX === '013590' && row.IFANY === 'Y' ? true : false);
	// 	this.businessClassFormGroup.get(row.CLASX + "IfAny").setValue(event.checked == true ? true : false)
	// 	//need to update the validation for matching form control
	// 	this.businessClassFormGroup.get(row.CLASX + "IfAny").setValidators(row.IFANY !== 'Y' ?
	// 		this.businessClassValidators.ValidateRequired(row.CLASX + "IfAny", `${row.CLASX + "IfAny"} ${row.CLSDSC} ${row.PRMDSC}`, true) : Validators.nullValidator);
	// 		this.businessClassFormGroup.get(row.CLASX + "IfAny").updateValueAndValidity({emitEvent:false});

	// 	if(row.CLASX === '013590' && this.businessClassFormGroup.get('013590PAYROLL')) {
	// 		this.businessClassFormGroup.get('013590PAYROLL').setValidators(row.IFANY !== 'Y' && this.businessClassFormGroup.get(row.CLASX).valid ?
	// 			this.businessClassValidators.ValidateMinValue(`${row.CLASX}PAYROLL`, `${row.CLASX} PAYROLL`, 1, 'must be at least', true) : Validators.nullValidator);
	// 		this.businessClassFormGroup.get('013590PAYROLL').updateValueAndValidity({emitEvent:false});
	// 	}
	// 	this.checkForValidPrimaryClass();
	// }

	funcGatherData() {
        this.localGLCLASSLIST = [];

		this.ctrQuote.GLPENTITY.GLCLASSLIST.forEach(_class => {
			if(_class.LOCNUM == this.LOCNUM && _class.RECORDSTATE !='D') {
				this.localGLCLASSLIST.push(_class);
				//for expander - needed for Eligibility(guidelines) expander row in table
				let classkey = _class.CLASX;
				//example: this.keys[data[i]] = 1;
				this.keys[this.data[classkey]] = 1;		
				if(!this.businessClassFormGroup.get(_class.CLASX + "Exposure")) this.addFormControl(_class);
			}
		});
    }


    checkForValidPrimaryClass()
    {
		let BRErrors = this.businessClassValidators.checkForValidPrimaryClass(this.businessClassFormGroup, this.ctrQuote);
		this.menuClass.stepActiveObject.errors.push(BRErrors);
		this.errors = this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive, BRErrors);
    }
	//for some reason the right nav will not hide using css, need to force it by setting the visible property. Display none does not work because it is still on top
	//of the additional coverages panel and you will not be able to click the close button otherwise
	resetPanel() {
		//this.visExposure = false;
		this.vis = true;
		$("#right").css("visibility","hidden");
	}
	//closes the panel and makes the right-nav visible again
	close() {
		this.vis = false;
		$("#right").css("visibility","visible");
	}
	scrollBottom() {
		let track = document.getElementById("center_wrapper");
		//track.scrollTo(0, track.scrollHeight);
		track.scrollTop = track.scrollHeight;
	}

	funcShowBusinessClass() {
		this.showAddGLClass = true;
		//this.scrollBottom();
	}

	callbackCancel() {
		//need to set this back to null if cancelling and 'edit'
		this.currentClasx = null;
		this.editClicked = false;
		this.showAddGLClass = false;
		this.defaultClass = false; // need to set to false so if the user cancels editing the first class, and then adds a new class, the new class will be added to the end of the list and not the beginning -JTL
	}

	addClass(quotes: any) { 
		let newClass = {
			TRANS:  this.ctrQuote.POLICYTRANS.TRANS,
			POLICY: this.ctrQuote.POLICYTRANS.POLICY,
			EFFDTE: this.ctrQuote.POLICYTRANS.EFFDTE,
			EDSDTE: this.ctrQuote.POLICYTRANS.EDSDTE,
			RCDTYP: this.ctrQuote.QUOTEPOLICYINFORMATION.RECORDTYPE,
			EDSNO: 0,
			COVERG: "",
			PRMSTE: quotes.quote[0].STATECODE,
			LOCNUM: this.LOCNUM,
			BLDNUM: "001",
			CLASX: quotes.quote[0].CLASSCODE,
			SEQNO: "",
			//EXPOSE: (quotes.quote[0].EXPOSE != '' ? quotes.quote[0].EXPOSE : '0'),
			EXPOSE: quotes.quote[0].EXPOSE,
			IFANY:  quotes.quote[0].IFANY,
			CLSDSC: quotes.quote[0].DESCRIPTION.trim(),
			EXPDSC: quotes.quote[0].PRMDSC,
			PRMDSC: quotes.quote[0].PRMDSC,
			PRDINC: quotes.quote[0].PRDINC,
			SICCDE: quotes.quote[0].SICCDE,
			ELIGIBILITY: quotes.quote[0].ELIGIBILITY,
			PKGMOD: 'CO',
			INJPAY:0,
			RECORDSTATE: (quotes.quote[0].mode == "new" ? "N" : "U")
		}		

		let duplicate = this.ctrQuote.GLPENTITY.GLCLASSLIST.find(x => x.CLASX === newClass.CLASX && x.LOCNUM === this.LOCNUM && x.RECORDSTATE !='D');
		//this is emitting from the edit click
		if(this.editClicked && !duplicate){ // only remove the old form controls if the user clicked edit and the class code the user is attempting to change to isn't a duplicate.
			this.removeFormControlIfExists(this.businessClassCopy.CLASX);
		}

		if(quotes.clasx != null && !duplicate){
            this.ctrQuote.GLPENTITY.GLCLASSLIST.find(x => x.CLASX === quotes.clasx && x.LOCNUM === this.LOCNUM).RECORDSTATE = 'D';
		}

		//
		if(newClass.CLASX == '061217'){
			this.ctrQuote.GLPENTITY.GLPLOCATIONS.find(x => x.LOCNUM == this.LOCNUM).ANARLS = 'Y';
			//need this to check the lessors risk checkbox on property cvg
			this.migsystemservice.notifyLessorsRiskAdd('add');
		}

		if(!duplicate && !this.defaultClass){
			this.ctrQuote.GLPENTITY.GLCLASSLIST.push(newClass);
		}
		else if(!duplicate && this.defaultClass){
			this.ctrQuote.GLPENTITY.GLCLASSLIST.unshift(newClass);
		}
        if (this.ctrQuote.HasSubcontractedWorkClass()) { //9/9/21: if the class we are adding is a subcontracted class, add the Risk Transfer Guidelines pdf to the resources panel on right nav -JTL
            this.migsystemservice.notifyUpdateRightNav('AddRiskTransferGuidelines');
        }

        this.funcGatherData();
        //this.onChange(newClass.EXPOSE, newClass, 1);
		this.showAddGLClass = false;
		this.defaultClass = false;
		this.addFormControl(newClass);
	}

	//this adds a new formControl when an a new class item is selected
	addFormControl(newClass: any) {
		//unless IfAny is checked, exposure field must have a value greater than 0 in it
		if(!this.businessClassFormGroup.get(newClass.CLASX + "Exposure")) {
			this.businessClassFormGroup.addControl(newClass.CLASX + "Exposure", new UntypedFormControl(newClass.EXPOSE ? newClass.EXPOSE : "0", newClass.IFANY != 'Y' ?
                    this.businessClassValidators.ValidateRequired(`${newClass.CLASX + "Exposure"} ${newClass.PRMDSC}`, `${newClass.CLASX + "Exposure"} ${newClass.CLSDSC} ${newClass.PRMDSC}`, true)
                    : Validators.nullValidator
                    ));
		}
		if(!this.businessClassFormGroup.get(newClass.CLASX + "IfAny")){
			this.businessClassFormGroup.addControl(newClass.CLASX + "IfAny", new UntypedFormControl(newClass.IFANY));
		}

		//add the secondary formcontrol for the Payroll class if its '013590'
		if(newClass.CLASX === '013590' && !this.businessClassFormGroup.get(`${newClass.CLASX}PAYROLL`))  this.addPayrollControlForGlazier(newClass.INJPAY);
	}

	addPayrollControlForGlazier(injPay: number) {
		this.businessClassFormGroup.addControl(`013590PAYROLL`, new UntypedFormControl(injPay));
	}

	editClass(row) {	
		this.currentClasx = row.CLASX;
		this.businessClassCopy = _.cloneDeep(row); // holds a shell of our business class in its unedited state.
		this.editClicked = true;
		this.defaultClass = true;
        //this.removeFormControlIfExists(this.currentClasx);
		this.showAddGLClass = true;
		if(row.CLASX === '013590' && !this.businessClassFormGroup.get(`${row.CLASX}PAYROLL`))  this.addPayrollControlForGlazier(row.INJPAY);
	}

    removeFormControlIfExists(clasx: string) {
        if (this.businessClassFormGroup.contains(clasx + "Exposure"))
        {
			this.businessClassFormGroup.removeControl(clasx + "Exposure");			
        }
		if(clasx === '013590') this.businessClassFormGroup.removeControl(`${clasx}PAYROLL`);
		if (this.businessClassFormGroup.contains(clasx + "IfAny"))
        {
			this.businessClassFormGroup.removeControl(clasx + "IfAny");			
        }
		//this.businessClassFormGroup.updateValueAndValidity({emitEvent:false});
		//this.migsystemservice.notifyDoneClicked(this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive));

    }

	removeClass(row) {
		this.confirmationService.confirm({
			message: 'Are you sure that you want to remove this business class?',
			accept: () => {

				this.ctrQuote.GLPENTITY.GLCLASSLIST.forEach(_classx=>{
					if(_classx.CLASX === row.CLASX && _classx.LOCNUM === this.LOCNUM){

                        this.removeFormControlIfExists(row.CLASX);

						_classx.RECORDSTATE = 'D';
					}
					if(row.CLASX === '061217'){
						this.ctrQuote.GLPENTITY.GLPLOCATIONS.find(x => x.LOCNUM == this.LOCNUM).ANARLS = 'N';
						this.migsystemservice.notifyLessorsRiskAdd('remove');
					}
				});				
                this.funcGatherData();
                if (!this.ctrQuote.HasSubcontractedWorkClass()) { // 9/9/21: if the class we removed was a subcontracted class, and there are no more subcontracted classes remaining on the quote, remove the Risk Transfer guidelines pdf from the right nav -JTL
                    this.migsystemservice.notifyUpdateRightNav('RemoveRiskTransferGuidelines');
                }
			}
		})
	}

	// ** PRMDSC field updated in DWF1033
	// the mask needs to be updated or
	// exposure does not get read in
	getMask(format) {
		switch (format) {
			case "PAYROLL":
				return this.masks.currencyMask;
			case "SALES":
				return this.masks.currencyMask;
			case "GROSS SALES":
				return this.masks.currencyMask;
			// case "ACRE":
			// 	return this.masks.numericMask;
			// 	break;
			case "# OF ACRES":
					return this.masks.numericMask;
					break
			// case "PLOW":
			// 	return this.masks.numericMask;
			// 	break;
			case "# OF PLOWS":
					return this.masks.numericMask;
			case "AREA":
				return this.masks.numericMask;
			case "TOTAL COST":
				return this.masks.currencyMask;
		}
	}
	setUpFormGroupSubscription(){
		// subscribe to form group changes
		this.FormGroupSubscription = this.businessClassFormGroup.valueChanges.pipe(distinctUntilChanged()).subscribe((data:UntypedFormGroup) => {
			let classcode;
			let exposure: AbstractControl;
			let ifany: AbstractControl;
			for(let control in this.businessClassFormGroup.controls){ // first we need to extract the classcode from the form control name.
               if(control != "HASPRIMARYCLASS"){ // we are not concerned with this form control
				classcode = control.substring(0,6); // the form control will be in the format {ClassCode}{Type of Control} (ex: 092215Exposure). Here we grab the 1st half which we will use to manipulate the two controls. 
				exposure = this.businessClassFormGroup.get(classcode + "Exposure"); 
				ifany = this.businessClassFormGroup.get(classcode + "IfAny")
				if(this.ctrQuote.GLPENTITY.GLCLASSLIST.find(x=>x.LOCNUM === this.LOCNUM && x.CLASX === classcode && x.RECORDSTATE !== 'D')){ // this check is here so we are not trying to update a deleted class code.
					if(control == classcode + "Exposure"){ // Exposure null check 
						if(exposure.value == "$0" || exposure.value == 0 || exposure.value == "")
						{
							if(ifany) ifany.enable({emitEvent:false}); // enable the IfAny checkbox if there is no exposure/exposure is 0
						}
						else {
							ifany.disable({emitEvent:false}); // if there is an exposure entered, disable the checkbox.
						}
						this.ctrQuote.GLPENTITY.GLCLASSLIST.find((x: any)=>x.LOCNUM === this.LOCNUM && x.CLASX === classcode && x.RECORDSTATE !== 'D').EXPOSE = this.func.justNumbers(data[classcode + "Exposure"]); // update our GLCLASS object with our updated form data
					}
					if(control == classcode + "IfAny"){ // If Any null check
						if(ifany.value == true || ifany.value == "Y"){ // If its value is true or Y, the checkbox should be checked.
							exposure.setValue('', {emitEvent: false}); // the exposure should be 0 if the checkbox is checked.
							if(exposure.enabled) exposure.disable({emitEvent:false}); // the exposure should be disabled if the checkbox is checked.
							this.ctrQuote.GLPENTITY.GLCLASSLIST.find(x=>x.LOCNUM === this.LOCNUM && x.CLASX === classcode && x.RECORDSTATE !== 'D').EXPOSE = 0; // set exposure on object graph to 0
							this.ctrQuote.GLPENTITY.GLCLASSLIST.find(x=>x.LOCNUM === this.LOCNUM && x.CLASX === classcode && x.RECORDSTATE !== 'D').IFANY = 'Y'; // set IFANY on object graph to Y so that it persists.
						}
						else if (ifany.value == false || ifany.value == "" ){ // if the user turns off the checkbox, re-enable the exposure field.
							if(exposure){
							if(exposure.disabled) exposure.enable({emitEvent:false});
							this.ctrQuote.GLPENTITY.GLCLASSLIST.find(x=>x.LOCNUM === this.LOCNUM && x.CLASX === classcode && x.RECORDSTATE !== 'D').IFANY  = '';
							}
						}
					}
					if(control == classcode + "PAYROLL"){ //used for classcode 013590
						this.ctrQuote.GLPENTITY.GLCLASSLIST.find((x: any)=>x.LOCNUM === this.LOCNUM && x.CLASX === classcode && x.RECORDSTATE !== 'D').INJPAY = this.func.justNumbers(data[classcode + "PAYROLL"]);
						if(this.businessClassFormGroup.get('013590PAYROLL')) this.businessClassFormGroup.get('013590PAYROLL').setValue(this.func.justNumbers(data[classcode + "PAYROLL"]), {emitEvent:false});				
					}
					if(this.INJPAYdisplay == 0 || classcode !== '013590')
					{
						this.ctrQuote.GLPENTITY.GLCLASSLIST.find((x: any)=>x.LOCNUM === this.LOCNUM && x.CLASX === classcode && x.RECORDSTATE !== 'D').INJPAY = 0;
					}
					this.INJPAYdisplay = this.ctrQuote.GLPENTITY.GLCLASSLIST.some((x: any)=> x.CLASX === '013590') ? this.func.justNumbers(data[classcode + "PAYROLL"]) : 0;
				this.setValidation(classcode); // set our validators for the controls.
				}
			}
		}
		this.businessClassFormGroup.updateValueAndValidity({emitEvent:false});
		});
	}

	setValidation(classCode:string){
		// set our validation rules in this function.
		let row = this.ctrQuote.GLPENTITY.GLCLASSLIST.find((x=>x.LOCNUM === this.LOCNUM && x.CLASX === classCode && x.RECORDSTATE !== 'D'))
		this.INJPAYIfAny  = (classCode === '013590' && row.IFANY === 'Y' ? true : false);
		//need to update the validation for matching form control
		if(this.businessClassFormGroup.get(classCode + "IfAny") && this.businessClassFormGroup.get(classCode + "Exposure")){
			if( (this.func.justNumbers(this.businessClassFormGroup.get(classCode + "Exposure").value) == 0) && this.businessClassFormGroup.get(classCode + "IfAny").value == false){
			this.businessClassFormGroup.get(classCode + "IfAny").setValidators(
				this.businessClassValidators.ValidateRequired(row.CLASX + "IfAny", `${row.CLASX} ${row.CLSDSC} ${row.PRMDSC}`, true));
				this.businessClassFormGroup.get(row.CLASX + "IfAny").updateValueAndValidity({emitEvent:false});
				this.checkForValidPrimaryClass();
			}
			else{
				this.businessClassFormGroup.get(classCode + "IfAny").setValidators(Validators.nullValidator);
			}
			this.checkForValidPrimaryClass();

		}

		if(row.CLASX === '013590' && this.businessClassFormGroup.get('013590PAYROLL')) {
			this.INJPAYdisplay = this.ctrQuote.GLPENTITY.GLCLASSLIST.find((x: any)=>x.LOCNUM === this.LOCNUM && x.CLASX === '013590' && x.RECORDSTATE !== 'D').EXPOSE;

			this.businessClassFormGroup.get('013590PAYROLL').setValidators(row.IFANY !== 'Y' && this.businessClassFormGroup.get(row.CLASX + "Exposure") ?
				this.businessClassValidators.ValidateMinValue(`${row.CLASX}PAYROLL`, `${row.CLASX} PAYROLL`, 1, 'must be at least', true) : Validators.nullValidator);
			this.businessClassFormGroup.get('013590PAYROLL').updateValueAndValidity({emitEvent:false});
		}
	}

}
