/* ****************************************************************************************************
* PROGRAM DESCRIPTION  - BOP Business Class component
* NOTES: 
* - This component is a BOP specific component. Unlike other product lines where we can have a 1-M relationship, only one business class can be associated with a single building. 
* - This component is a child component of BOP Building. 
* - The form group that drives this form is shared with it's parent (building) and sibling (additional coverages) component. As such, the form group subscription only needs to be handled in the BOP building component.
*
* BUG FIXES: 
* 8/9/22: Fixed issue where Computer Description wasn't getting set on LOC 001 BLD 001 (Bug 394) -JTL
****************************************************************************************************/
import { ChangeDetectorRef, Component, Input, OnInit, Inject, OnDestroy } from '@angular/core';
import { PrimeNGConfig,FilterMatchMode,LazyLoadEvent } from 'primeng/api';
import { InputMasksClass } from '@helpers/masks';
import { DOCUMENT } from "@angular/common";
import { MessageService } from 'primeng/api';
import { ConfirmationService } from 'primeng/api'
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { ContractorsTooltips } from '@helpers/tooltips';
import { Functions } from '@helpers/functions';
import { MIGSystemService } from '@services/mig.service';
import { MenuClass } from '@root/system/menu/menu';
import * as _ from 'lodash';
import { BOPQuote } from '@classViewModels/BOP/BOPQuote';
import { Subscription } from 'rxjs';
import { GUIDE } from '@classes/common/BusinessClass/GUIDE';
import { UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { BOPBUILDING } from '@mig/quotes/business-owners/classes/BOPBUILDING';
import { BopBuildingComponent } from '@mig/quotes/business-owners/components/bop-building/bop-building.component';
import { BopLocationSummaryComponent } from '@mig/quotes/business-owners/components/bop-location-summary/bop-location-summary.component';
import { Table } from 'primeng/table';

@Component({
  selector: 'mig-bop-business-class',
  templateUrl: './bop-business-class.component.html',
  styleUrls: ['./bop-business-class.component.css']
})
export class BopBusinessClass implements OnInit,OnDestroy {

    @Input() guide: GUIDE[];
    @Input() quote: BOPQuote;
    buildingObject: BOPBUILDING;
    buildingFormGroup: UntypedFormGroup

    //@Output() BusinessClassFormGroupEmitter = new EventEmitter<any>();     
    //clonedBusinessClasses: { [s: string]: WCAClassExtended; } = {};
    //businessClassCopy: WCAClassExtended;
    buildingArray: BOPBUILDING[] = [];
    fb: UntypedFormBuilder;
    rows:number = 20;
    first:number = 0;
    errors: any[] = [];        
    currentClasx: string;
    filteredGuide: GUIDE[] = [];
    classListFormGroup: UntypedFormGroup;  
    defaultClass: boolean = false;
    addingNewBusinessClass:boolean = false;       
    //businessClassValidators: MIGBusinessClassValidators;  
    selectedSICCDE:string;
    selectDescription:string;
    selectedClassCode:string;
    selectedMktSegment:string;
    fullClassDescription: string;
    defaultClassDescription: string;
    FormGroupSubscription: Subscription;   
    guideServiceSubscription: Subscription;
  constructor(public masks: InputMasksClass,
          public confirmationService: ConfirmationService,
          public changeDetectionRef: ChangeDetectorRef,
          public contractorsTooltips:ContractorsTooltips,
          public migRoles: MIGSecurityRoles,
          public migsystemservice: MIGSystemService,
          public messageService: MessageService,
          public menuClass: MenuClass,
          public func:Functions,
          public buildingComponent: BopBuildingComponent,
          public locationComponent: BopLocationSummaryComponent,
          @Inject(DOCUMENT) public document: Document)
        {
          this.fb = new UntypedFormBuilder();
        }

  // get BLDLMT() { return this.classListFormGroup.get('BLDLMT'); }
  // get BPPLMT() { return this.classListFormGroup.get('BPPLMT'); }

  ngOnInit(): void {
    this.defaultClassDescription = this.quote.QUOTEPOLICYINFORMATION.CLASSCODEINFO.DESCRIPTION;
    this.buildingObject = this.buildingComponent.buildingObject;
    this.buildingFormGroup = this.buildingComponent.buildingFormGroup;
    this.buildingArray.push(this.buildingObject);
    this.buildingComponent.computerDescription = this.setComputerDescription(this.buildingObject.BLDSEG != "" ? this.buildingObject.BLDSEG : this.buildingObject.BPPSEG);

    // console.log("fg: ", this.classListFormGroup)
    //this.menuClass.menu.forms.push(this.classListFormGroup);
    //for loc's and bld's after the first one
    if ((this.buildingObject.BLDCLS == '' || this.buildingObject.BLDCLS == 'NULL') && (this.buildingObject.BPPCLS == '' || this.buildingObject.BPPCLS == 'NULL'))
    {
      this.showClassList();
    }


  }

  selectedBusinessClass (event):void { // called when we select a business class from our guide
    
    this.buildingObject.BLDCLS = event.CLASSCODE
    this.buildingObject.BLDDSC = event.DESCRIPTION.substring(0,30);   
    this.buildingObject.BLDSIC = event.SICCDE;
    this.buildingObject.BLDSEG = event.PRODUCT;
    this.buildingObject.BPPCLS = event.CLASSCODE
    this.buildingObject.BPPDSC = event.DESCRIPTION.substring(0,30);   
    this.buildingObject.BPPSIC = event.SICCDE;
    this.buildingObject.BPPSEG = event.PRODUCT;
    this.buildingObject.FULLBLDGDESCRIPTION = this.guide.find(x=>(x.CLASSCODE == this.buildingObject.BLDCLS)).DESCRIPTION;
    // building.BPPDSC = this.guide.find(x=>(x.CLASSCODE == building.BPPCLS)).DESCRIPTION;
    this.buildingComponent.computerDescription = this.setComputerDescription(this.buildingObject.BLDSEG);
    this.addingNewBusinessClass = false;

    // if(event.PRODUCT == "RETL"){
    //   this.buildingObject.BUSINESSLIABILITY = new BUSINESSLIABILITY(); // BUSINESSLIABILITY should only be added if the building's class segment is Retail
    // }
    //reset the array we're using for the business retail section
    this.buildingComponent.retailClassDisplay = [];
    this.buildingFormGroup.updateValueAndValidity();
    // this.buildingComponent.checkBusinessLogic();
    // this.buildingComponent.updateValidation(); // update the validation rules based on the new selected class.

  }
  setComputerDescription(segment: string) : string{// set text to be displayed under Computer Coverage, the text is different based on Class Segment
    switch(segment){
      case "OFFC": 
        return "Computer Equipment - Automatically included in the Business Personal Property Limit Plus $40,000";
      case "LSRO": 
        return "Computer Equipment - Automatically included in the Business Personal Property Limit";
      case "FOOD":
      case "RETL":
      case "SERV":
      case "WHLS":
        return "Computer Equipment - Automatically included in the Business Personal Property Limit Plus $25,000";
      default: 
        return "Computer Equipment - Automatically included in the Business Personal Property Limit";
    }
  }

  editClass() : void{
    this.addingNewBusinessClass = true;
   
  }
  btnCancel() : void{
    this.addingNewBusinessClass = false;
  }

  //on change building limit
  onChangeBuildingLimit() :void{
    // console.log('BLDLMT', this.BLDLMT.value);
    // this.changeDetectionRef.detectChanges();
  }

  //onchange building property limit 
  onChangeBPPLimit():void{}

  showClassList(){
    this.addingNewBusinessClass = true;
  }

  //
  createAZlinks(): String[] {
    var letters: String[] = [];

    for (var i = 65; i <= 90; i++) {
        letters.push(String.fromCharCode(i));
    }
    return letters;
  }

  //
  AZclicked(letter: string, table :Table){  
    table.filterGlobal(letter, FilterMatchMode.STARTS_WITH);
  }
  next() {
    this.first = this.first + this.rows;
  }

  prev() {
      this.first = this.first - this.rows;
  }

  reset() {
      this.first = 0;
  }

  isLastPage(): boolean {    
    return this.guide ? this.first === (this.guide.length - this.rows): true;
  }

  isFirstPage(): boolean {
    return this.guide ? this.first === 0 : true;
  }
  //visual code test git push
  ngOnDestroy(): void { 
    if(this.FormGroupSubscription){ this.FormGroupSubscription.unsubscribe()}
  }
}
