import { Injectable } from "@angular/core";
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { AppErrors } from '../errors/app-errors';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';

import * as _ from 'lodash';
import { Validation } from '@classes/Common/ValidatorClass/Validation';


@Injectable()
export class MIGBusinessClassValidators extends Validation {
     
    //TODO:  Data Drive this list of secondary class codes using the DW1F033 table.
     secondaryClassCodes: string[] = ['091580', '091581', '091582', '091583', '091585', '091590', '091591', '0M0001', '0M0002', '0M0003', '049451', '047051', '061217'];
     //ENDTODO
    
     constructor() {
        super();
    }
    //should this be 
    ValidatedPayrollMeetsMinimumLimits = (row: any, territory: string, value: number): any[] => {
            let errors = [] ;
            let min: number = 0;
            switch(row.PRMSTE) {
                case '21': min = 19800; break; //MI
                case '28': min = 15600; break; //NH
                case '29': min = 19800; break; //NJ
                case '31': //NY
                    switch(territory) {
                        case '001':
                        case '003':
                        case '007':
                        case '009':
                        case '010':
                        case '016':
                            min = 24800; break;
                        default: min= 19800; break;
                    }
                    break;
                case '34': min = 19800; break; //OH
                case '20': min = 28600; break; //MA
                case '37': min = 5200; break; //PA
                case '44': min = 10400; break; //VT
                default: min = 0;
            }
            //checking to see if the state specific minimum has been met
            if(value < min) {
                errors.push({ severity: "error", summary: 'exposure', detail: `Exposure entered for ${row.CLSDSC} ${row.EXPDSC} is below state/territory minimum of $${min.toLocaleString()}`, step: 1, sticky: true, closable: false});
            }
            return errors;
    }



    AddINJPayError = (summaryMsg: string, detailMsg: string) => {
        return {severity: "error", summary: summaryMsg, detail: detailMsg, sticky: true, closable: false };
    } 

    ValidateControlIsTrue = (messageDetail: string, hasError?: boolean) => {
        return (control: UntypedFormControl): AppErrors | null  => {
            return  !control.value || hasError ? { severity: "error", summary: "General Liability Classes", detail: messageDetail, sticky: true, closable: false }: null; 
        }
    }

    checkForValidPrimaryClass(businessClassFormGroup: UntypedFormGroup, ctrQuote: CTRQuote) {
        let hasPrimaryClass: boolean;
        let primaryClassArray: any[];
        primaryClassArray = _.filter(ctrQuote.GLPENTITY.GLCLASSLIST, (glClass) => ((!(this.secondaryClassCodes.includes(glClass.CLASX))) && glClass.LOCNUM == "001" && glClass.IFANY != 'Y' && glClass.RECORDSTATE != 'D')); 
        hasPrimaryClass = primaryClassArray.length > 0;
        businessClassFormGroup.get("HASPRIMARYCLASS").setValue(hasPrimaryClass,{emitEvent:false});
        if (!(hasPrimaryClass))
        {
            return;
        }
        let primaryClass;
        let BRErrors = [];
        let terr =  ctrQuote.GLPENTITY.GLPLOCATIONS.find((x: any)=> x.LOCNUM === '001' && x.RECORDSTATE !="D").TERR; // 2/9/22: Added recordstate check -JTL
        //validate the exposure amount if its a payroll
        let hasValidPrimaryClass = false;
        for (let i:number = 0; i < primaryClassArray.length; i++)
        {
            primaryClass = primaryClassArray[0]; // 2/9/22: we only want to check the first class in the array because only the first class needs to be validated for payroll -JTL 
            if ((primaryClass.EXPDSC === 'PAYROLL' || primaryClass.CLASX === '013590') && ((primaryClass.PRMSTE != '') && (primaryClass.PRMSTE != '0'))) {
                BRErrors = this.ValidatedPayrollMeetsMinimumLimits(primaryClass, terr, primaryClass.EXPOSE);
                
                if ((businessClassFormGroup.contains(primaryClass.CLASX))) {
                    businessClassFormGroup.get(primaryClass.CLASX).setValidators(Validators.nullValidator);
                }

                if (BRErrors.length == 0) {
                    hasValidPrimaryClass = true;
                }
               
            }
        }
        hasValidPrimaryClass = BRErrors.length == 0 ? true : false;

        // if(hasValidPrimaryClass) {
        //     // return [];
        //     BRErrors = [];
        // }
        if (BRErrors.length > 0)
        {
            if(businessClassFormGroup.get(primaryClass.CLASX + "Exposure")){
                businessClassFormGroup.get(primaryClass.CLASX + "Exposure").setValidators(this.ValidateControlIsTrue(BRErrors[0].detail, true));
                businessClassFormGroup.get(primaryClass.CLASX + "Exposure").updateValueAndValidity({emitEvent:false});
            }
            // businessClassFormGroup.get(primaryClass.CLASX + "Exposure").setValidators(this.ValidateControlIsTrue(BRErrors[0].detail, true));
            // businessClassFormGroup.get(primaryClass.CLASX + "Exposure").updateValueAndValidity({emitEvent:false});
            return BRErrors;
        } 
        else {
            if(businessClassFormGroup.get(primaryClass.CLASX + "Exposure")){
                businessClassFormGroup.get(primaryClass.CLASX + "Exposure").setValidators(Validators.nullValidator);
                businessClassFormGroup.get(primaryClass.CLASX + "Exposure").updateValueAndValidity({emitEvent:false});
            }
        }   
        return BRErrors;
        // commented out code below because the validation for these controls have moved into business-class-component. -JTL
        //need to check specifically for class code 013590 as it contains 2 items, one being payroll under INJPAY

        // if (!(businessClassFormGroup.contains(primaryClass.CLASX + "Exposure")))
        // {
        //     console.log("inside if")
        //     businessClassFormGroup.addControl(primaryClass.CLASX + "Exposure", new FormControl(0));
        // }
        //return BRErrors;
        //console.log("BRERRORS: ", BRErrors)
        // if (BRErrors.length > 0)
        // {
        //     console.log("BRERRORS: ",BRErrors)
        //     businessClassFormGroup.get(primaryClass.CLASX + "Exposure").setValidators(this.ValidateControlIsTrue(BRErrors[0].detail, true));
        //     businessClassFormGroup.get(primaryClass.CLASX + "Exposure").updateValueAndValidity({emitEvent:false});
        //     return BRErrors;
        // } 
        // else {
        //     businessClassFormGroup.get(primaryClass.CLASX + "Exposure").setValidators(Validators.nullValidator);
        //     businessClassFormGroup.get(primaryClass.CLASX + "Exposure").updateValueAndValidity({emitEvent:false});
        // }     
        //businessClassFormGroup.get(primaryClass.CLASX + "IfAny").setValue((BRErrors.length == 0)); //this is causing issues with the checkboxes
    }
    

}