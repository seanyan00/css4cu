/* ****************************************************************************************************
* PROGRAM DESCRIPTION  - WCA Business Class 
* NOTES: 
* - This component is the child component of wca-locations. One location can have many business classes.
* BUG FIXES: 
* 6/23/21: Fixed issue where "IfAny" checkbox validation wasn't firing after user keyed in exposure (TFS 2310) -JTL
* 7/22/21: Fixed issue where full time and part time employees were unable to be overwritten and were reappearing after save (TFS 2240) -JTL 
* 10/19/21: Set DWETYP to blank instead of N when not checked (TFS 2450)
* 10/21/21: Removed onExposureChange function, moved functionality inside Formgroup subscription (TFS 2498) -JTL
* 10/27/21: Added padding for NEMPL field and called onChangeEmployee in the formgroup subscription(TFS 2450) -ZJG
* 11/23/21: Set default for Full time & Part employees so they display blank instead of 0. (TFS 2534) -JTL
* 12/16/21: included seqno (BLDNUM) as part of form controls to differentiate different descriptions of the same class code (JIRA MSC 19717) -JTL
* 3/23/22: IfAny checkbox didn't retain with V13 upgrade and now does properly -ZJG
****************************************************************************************************/
import { ChangeDetectorRef, Component, Input, OnInit, ViewEncapsulation, Inject, OnDestroy, Output, EventEmitter, OnChanges } from '@angular/core';
import { InputMasksClass } from '@helpers/masks';
import { DOCUMENT } from "@angular/common";
import { MessageService } from 'primeng/api';
import {ConfirmationService} from 'primeng/api'
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { ContractorsTooltips } from '@helpers/tooltips';
import { Functions } from '@helpers/functions';
import { MIGSystemService } from '@services/mig.service';
import { MenuClass } from '@root/system/menu/menu';
import { trigger,state,style,transition,animate } from '@angular/animations';
import { MIGBusinessClassValidators } from './business-class.validators';
import * as _ from 'lodash';
import { UntypedFormGroup, UntypedFormControl, Validators, UntypedFormBuilder, AbstractControl } from '@angular/forms';
import { WCAClassExtended } from '@classes/WCA/WCCLASSEXTENDEDABSTRACT';
import { WCALOCATIONS } from '@classes/WCA/WCALocations';
import { GuideService } from '@root/services/risk-appetite-guide.service';
import { GUIDE } from '@classes/common/BusinessClass/GUIDE';
import { Subscription } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { STATISTICS } from '@classes/Common/STATISTICS';
import { WCAQuote } from '@classViewModels/WCA/WCAQuote';

@Component({
	selector: 'mig-wca-business-class',
	templateUrl: './wca-business-class.component.html',
	animations: [
        trigger('rowExpansionTrigger', [
            state('void', style({
                transform: 'translateX(-10%)',
                opacity: 0
            })),
            state('active', style({
                transform: 'translateX(0)',
                opacity: 1
            })),
            transition('* <=> *', animate('400ms cubic-bezier(0.86, 0, 0.07, 1)'))
        ])
	],
	styleUrls: ['../quote_information/quote_information.component.css'],
	encapsulation: ViewEncapsulation.None,
})

//TODO We need to redo this as a reactive form  instead of a template driven form
export class MIGWCABusinessClass implements OnInit, OnDestroy, OnChanges {

    addingNewBusinessClass:boolean = false;
    classListFormGroup: UntypedFormGroup;
    businessClassFormGroup: UntypedFormGroup[]; // array of formgroups, for each business Class
    @Input() locationObject: WCALOCATIONS;
    @Input() guide: GUIDE[];
    @Input() quote: WCAQuote;
    @Output() WCABusinessClassFormGroupEmitter = new EventEmitter<any>(); // USed to communicate our business class formgroup data with our state (parent) component
    currentClasx: string;
    errors: any[] = [];
    defaultClass: boolean = false;
	businessClassValidators: MIGBusinessClassValidators;
    businessClassList: WCAClassExtended[] = [];
    businessClassList2: WCAClassExtended[] = [];
    clonedBusinessClasses: { [s: string]: WCAClassExtended; } = {};
    businessClassCopy: WCAClassExtended;
    FormGroupSubscription: Subscription;
    fb: UntypedFormBuilder;
	guideServiceSubscription: Subscription;
	filteredGuide: GUIDE[];

	constructor(
		public masks: InputMasksClass,
		public confirmationService: ConfirmationService,
		public changeDetectionRef: ChangeDetectorRef,
		public contractorsTooltips:ContractorsTooltips,
		public migRoles: MIGSecurityRoles,
		public migsystemservice: MIGSystemService,
		public messageService: MessageService,
		public menuClass: MenuClass,
		public func:Functions,
        private guideService: GuideService,
		@Inject(DOCUMENT) public document: Document
	) {
		this.businessClassValidators = new MIGBusinessClassValidators();
        this.fb = new UntypedFormBuilder();
        this.locationObject = Object.assign(new WCALOCATIONS(), this.locationObject);
	}

	ngOnInit() {
        this.classListFormGroup = this.fb.group(
        {
            RECORDSTATE: this.locationObject.RECORDSTATE,
            LOCNUM: this.locationObject.LOCNUM,
            TYPE: "Business Class"    
        }
        );
        this.locationObject.BUSINESSCLASSES.filter(x=>x.RECORDSTATE != "D").forEach((x: WCAClassExtended) => { // 12/9/21: added filter by record state != "D" because otherwise a deleted state with no business classes would bomb out form subscription -JTL 
            if(x.BUSINESSCLASSSTATS.CLASX == ""){ // if the stat record gets corrupted for whatever reason (Error during rating, for example), this should set the object back to a point where the business class object won't bomb out. -JTL
                x.BUSINESSCLASSSTATS.CLASX = x.CLASX;
                x.BUSINESSCLASSSTATS.ASLOB = this.quote.QUOTEPOLICYINFORMATION.CLASSCODEINFO.ASLOB;
                x.BUSINESSCLASSSTATS.PRMSTE = this.locationObject.COVERG;
                x.BUSINESSCLASSSTATS.LOCNUM = this.locationObject.LOCNUM;
                x.BUSINESSCLASSSTATS.BLDNUM = x.BLDNUM;
                x.BUSINESSCLASSSTATS.COVERG = this.locationObject.COVERG;
                x.RCDTYP = 3;
                x.COVRG = "11";
            }
            // this.classListFormGroup.addControl('FullTime' + x.CLASX + x.BLDNUM, new FormControl(x.BUSINESSCLASSSTATS.COMCOV != "0" ? x.BUSINESSCLASSSTATS.COMCOV : "")); // if # of FT employees is 0, set the form control to blank
            // this.classListFormGroup.addControl('PartTime' + x.CLASX + x.BLDNUM, new FormControl(x.BUSINESSCLASSSTATS.COLCOV != "0" ? x.BUSINESSCLASSSTATS.COLCOV : "")); // if # of PT employees is 0, set the form control to blank
            this.classListFormGroup.addControl('FullTime' + x.CLASX + x.BLDNUM, new UntypedFormControl(x.BUSINESSCLASSSTATS.COMCOV)); // if # of FT employees is 0, set the form control to blank
            this.classListFormGroup.addControl('PartTime' + x.CLASX + x.BLDNUM, new UntypedFormControl(x.BUSINESSCLASSSTATS.COLCOV)); // if # of PT employees is 0, set the form control to blank
            this.classListFormGroup.addControl('Exposure' + x.CLASX + x.BLDNUM, new UntypedFormControl(x.BUSINESSCLASSSTATS.EXPOSE));
            this.classListFormGroup.addControl('ifAny' + x.CLASX + x.BLDNUM, new UntypedFormControl((x.BUSINESSCLASSSTATS.DWETYP == "Y") ? true : false));
            // if(this.classListFormGroup.get("Exposure" + x.CLASX + x.BLDNUM).value != ""){
            this.classListFormGroup.get("ifAny" + x.CLASX + x.BLDNUM).setValidators(x.BUSINESSCLASSSTATS.EXPOSE == 0 ? this.businessClassValidators.ValidateControlIsTrue("Exposure / If Any is required") : Validators.nullValidator);
            this.classListFormGroup.get("Exposure" + x.CLASX + x.BLDNUM).setValidators(x.BUSINESSCLASSSTATS.DWETYP != "Y" ? this.businessClassValidators.ValidateMinValue("EXPOSE" + x.CLASX + x.BLDNUM,"Exposure", 1, " must be at least",false): Validators.nullValidator);
            if(this.classListFormGroup.get("FullTime" + x.CLASX + x.BLDNUM).value === "" || this.classListFormGroup.get("PartTime" + x.CLASX + x.BLDNUM).value === ""){ // 12/1/21: in NY/MI, FT/PT employees are not required, but we still want an error to occur if the leave the field blank. So 0 is ok, just not blank. 
                this.classListFormGroup.get("FullTime" + x.CLASX + x.BLDNUM).setValidators(this.businessClassValidators.ValidateEmptyField("FullTime","Full Time and Part Time"))
            }
            if(this.locationObject.COVERG != "21" && this.locationObject.COVERG != "31") { // if our state isn't New York or Michigan
                if((x.BUSINESSCLASSSTATS.COLCOV == "0" || x.BUSINESSCLASSSTATS.COLCOV == "") && (x.BUSINESSCLASSSTATS.COMCOV == "0" || x.BUSINESSCLASSSTATS.COMCOV == "")){ // if neither full time nor part time employees are filled out, we set our validator.
                    this.classListFormGroup.get("FullTime" + x.CLASX + x.BLDNUM).setValidators([this.businessClassValidators.ValidateRequired("FullTime","Full Time or Part Time",true, true), this.businessClassValidators.ValidateEmptyField("FullTime","Full Time and Part Time")])
                    // this.classListFormGroup.get("PartTime" + x.CLASX + x.BLDNUM).setValidators([this.businessClassValidators.ValidateRequired("PartTime","Full Time or Part Time",true, true), this.businessClassValidators.ValidateEmptyField("PartTime","Part Time")])
                }
            }
            // if((x.BUSINESSCLASSSTATS.COLCOV == "0" || x.BUSINESSCLASSSTATS.COLCOV == "") && (x.BUSINESSCLASSSTATS.COMCOV == "0" || x.BUSINESSCLASSSTATS.COMCOV == "") && (this.locationObject.COVERG != "21" && this.locationObject.COVERG != "31")){ // if both full time and part time are blank (or zero), and our state isn't New York or Michigan, we must set our validator.
            //     this.classListFormGroup.get("FullTime" + x.CLASX + x.BLDNUM).setValidators(this.businessClassValidators.ValidateRequired("FullTime","Full Time or Part Time",true))
            // }
            if(x.BUSINESSCLASSSTATS.DWETYP == "Y"){
                this.classListFormGroup.get("Exposure" + x.CLASX + x.BLDNUM).disable();
                this.classListFormGroup.get("Exposure" + x.CLASX + x.BLDNUM).setValue(""); // if there is no exposure, set the value of the exposure form control to blank.   
            }
            
            if(x.BUSINESSCLASSSTATS.EXPOSE != 0 && x.BUSINESSCLASSSTATS.EXPOSE != undefined){
                this.classListFormGroup.get("ifAny" + x.CLASX + x.BLDNUM).disable(); // disables the checkbox OnInit if there is an exposure on the business class.
                this.classListFormGroup.get("ifAny" + x.CLASX + x.BLDNUM).setValidators(Validators.nullValidator)
            }
            else{
                this.classListFormGroup.get("Exposure" + x.CLASX + x.BLDNUM).setValue(""); // if there is no exposure, set the value of the exposure form control to blank.   
            }
        })

        if (this.locationObject.BUSINESSCLASSES.length == 0)
        {
            this.showClassList();
        }

        this.setUpFormGroupSubscription();
        this.menuClass.menu.forms.push(this.classListFormGroup);
        this.WCABusinessClassFormGroupEmitter.emit(this.classListFormGroup) // send the persisted BC formgroup to the locations and eventually states.
        this.changeDetectionRef.detectChanges();

        this.migsystemservice.subscribeEditBusinessClass().subscribe(x=> {
            this.editClass(this.quote.STATES[0].LOCATIONS[0].BUSINESSCLASSES[0])
        } )
    }

    ngOnChanges(): void{
    }

    ngOnDestroy(): void {
        if(this.FormGroupSubscription) this.FormGroupSubscription.unsubscribe();
    }

    ifAnyCBChange(row:WCAClassExtended, e?){ // set the Object graph's DWETYP based on the status of the checkbox
        if(this.classListFormGroup.get("ifAny" + row.CLASX + row.BLDNUM).value == true){ // when you turn on the checkbox, the form control values set to true. We want to set the exposure to 0, the exposure form control to blank, and disable the exposure field.
            row.BUSINESSCLASSSTATS.EXPOSE = 0;
            this.classListFormGroup.get("Exposure" + row.CLASX + row.BLDNUM).setValue(""); // 
            this.classListFormGroup.get("Exposure" + row.CLASX + row.BLDNUM).disable();
            this.classListFormGroup.get("ifAny" + row.CLASX + row.BLDNUM).enable();
            row.BUSINESSCLASSSTATS.DWETYP = "Y";
        }
        else{ // when the checkbox is turned off, we want to re-enable the exposure field, and set the DWETWP to N.
            this.classListFormGroup.get("Exposure" + row.CLASX + row.BLDNUM).enable();
            this.classListFormGroup.get("ifAny" + row.CLASX + row.BLDNUM).setValue(false);
            row.BUSINESSCLASSSTATS.DWETYP = ""; //defaulting to blank 10/18/21
        }
        this.classListFormGroup.get("ifAny" + row.CLASX + row.BLDNUM).setValidators(row.BUSINESSCLASSSTATS.EXPOSE == 0 ? this.businessClassValidators.ValidateControlIsTrue("Exposure / If Any is required") : Validators.nullValidator);
        this.classListFormGroup.get("Exposure" + row.CLASX + row.BLDNUM).setValidators(row.BUSINESSCLASSSTATS.DWETYP != "Y" ? this.businessClassValidators.ValidateMinValue("EXPOSE" + row.CLASX + row.BLDNUM,"Exposure", 1, " must be at least",false): Validators.nullValidator)
        this.changeDetectionRef.detectChanges();
    }


    onChangeEmployee(){ // called when a value gets added/changed in the part time or full time input text.
        let totalNumberOfEmployees: number = 0;
        let partTime: number = 0;
        let fullTime: number = 0;
        this.locationObject.BUSINESSCLASSES.forEach(x=> { // for each business class for the location, add up each COLCOV and COMCOV field to get the total number of part time and fill time employees.
            if(x.BUSINESSCLASSSTATS.COLCOV != "" && x.BUSINESSCLASSSTATS.COLCOV != null && x.BUSINESSCLASSSTATS.COLCOV !=undefined){
                partTime +=  parseInt(x.BUSINESSCLASSSTATS.COLCOV); // add this business class's COLCOV to the running total of part time employees.
            }
            if(x.BUSINESSCLASSSTATS.COMCOV != "" && x.BUSINESSCLASSSTATS.COMCOV != null && x.BUSINESSCLASSSTATS.COMCOV !=undefined){
                fullTime +=  parseInt(x.BUSINESSCLASSSTATS.COMCOV); // add this business class's COMCOV to the running total of full time employees.
            }
        });
        totalNumberOfEmployees = fullTime + partTime; // add our total full time and part time employees to get the total number of employees.
        this.locationObject.NEMPL = totalNumberOfEmployees.toString().padStart(4,'0');
        this.changeDetectionRef.detectChanges();
    }

    showClassList() {
        this.addingNewBusinessClass = true;
    }

    selectedBusinessClass(data) {
        // this function is called when you select a classcode from the risk appetite guide.
        var newBusinessClass:WCAClassExtended;

        newBusinessClass = this.locationObject.addNewBusinessClass(data.CLASSCODE, data.SICCDE, data.DESCRIPTION, data.ASLOB, this.businessClassCopy);
        if (this.businessClassCopy != null) { // if we are editing a business class, we want to replace the old formcontrol name with the new one.
            this.classListFormGroup.removeControl("FullTime" + this.businessClassCopy.CLASX + this.businessClassCopy.BLDNUM);
            this.classListFormGroup.removeControl("PartTime" + this.businessClassCopy.CLASX + this.businessClassCopy.BLDNUM);
            this.classListFormGroup.removeControl("Exposure" + this.businessClassCopy.CLASX + this.businessClassCopy.BLDNUM);
            this.classListFormGroup.removeControl("ifAny" + this.businessClassCopy.CLASX + this.businessClassCopy.BLDNUM);
            this.classListFormGroup.addControl("FullTime" + data.CLASSCODE + data.SICCDE, new UntypedFormControl("",this.businessClassValidators.ValidateRequired("FullTime","Full Time or Part Time",true))); // we only need to add the validation to full time, because the validation will be reapplied when they update the formgroup.
            this.classListFormGroup.addControl("PartTime" + data.CLASSCODE + data.SICCDE, new UntypedFormControl(""));
            this.classListFormGroup.addControl("Exposure" + data.CLASSCODE + data.SICCDE, new UntypedFormControl("", this.businessClassValidators.ValidateMinValue("EXPOSE" + data.CLASSCODE + data.SICCDE,"Exposure", 1, " must be at least",false)));
            this.classListFormGroup.addControl("ifAny" + data.CLASSCODE + data.SICCDE, new UntypedFormControl(false, this.businessClassValidators.ValidateControlIsTrue("Exposure / If Any is required")));
            this.classListFormGroup.updateValueAndValidity({ emitEvent: false });
        }
        else { // if we are adding our first business class, we just want to add the controls.
            this.classListFormGroup.addControl("FullTime" + data.CLASSCODE + data.SICCDE, new UntypedFormControl("",this.businessClassValidators.ValidateRequired("FullTime","Full Time or Part Time",true)));
            this.classListFormGroup.addControl("PartTime" + data.CLASSCODE + data.SICCDE, new UntypedFormControl(""));
            this.classListFormGroup.addControl("Exposure" + data.CLASSCODE + data.SICCDE, new UntypedFormControl("",this.businessClassValidators.ValidateMinValue("EXPOSE" + data.CLASSCODE + data.SICCDE,"Exposure", 1, " must be at least",false)));
            this.classListFormGroup.addControl("ifAny" + data.CLASSCODE + data.SICCDE, new UntypedFormControl(false, this.businessClassValidators.ValidateControlIsTrue("Exposure / If Any is required")));
            this.classListFormGroup.updateValueAndValidity({ emitEvent: false });
        }
        //this.migsystemservice.notifyGetQuote(this.quote); //This is not working; the business classes are not getting properly validated. 

        this.migsystemservice.notifyShareQuote(this.quote);
        this.businessClassCopy = null; // we are done with our copy, so set it back to null
        this.changeDetectionRef.detectChanges();
        this.addingNewBusinessClass = false;
    }

    getMask(format) {
		switch (format) {
			case "PAYROLL":
				return this.masks.currencyMask;

			case "SALES":
				return this.masks.currencyMask;

			case "GROSS SALES":
				return this.masks.currencyMask;

			// case "ACRE":
			// 	return this.masks.numericMask;
			// 	break;
			case "# OF ACRES":
					return this.masks.numericMask;
					break
			// case "PLOW":
			// 	return this.masks.numericMask;
			// 	break;
			case "# OF PLOWS":
					return this.masks.numericMask;

			case "AREA":
				return this.masks.numericMask;

			case "TOTAL COST":
				return this.masks.currencyMask;

		}
	}

    editClass(row:WCAClassExtended){ // called when we click "Edit". We should only be able to edit the first business class on the location. 
        this.businessClassCopy = _.cloneDeep(row); // holds a shell of our business class in its unedited state.
        this.currentClasx = row.CLASX;
		this.defaultClass = true;
		this.addingNewBusinessClass = true;
        //TODO: fix the indexes of the class codes so that the edit and delete buttons display properly.
    }

    btnCancel(){
        this.addingNewBusinessClass = false;
    }

    setUpFormGroupSubscription(){
        this.FormGroupSubscription = this.classListFormGroup.valueChanges.pipe(debounceTime(500)).subscribe( (data:UntypedFormGroup) => {
            let classcode; 
            let exposure;
            let seqno: string; 
            let ifAny;
            let fulltime: string;
            let parttime;
            let row: STATISTICS;
            // we need to perform validation as the user enters in values. We cannot use the (change) event because that only fires after the input value loses focus. 
            for(let control in this.classListFormGroup.controls){ // first we need to extract the classcode from the form control name.
                if(control.startsWith("FullTime")){ // the exposure control will have the classcode that we want. 
                    seqno = control.substring(12); // the seqno will start at index 12 and consist of the final three characters.
                    classcode = control.substr(8,4) // the 4 characters of this control starting at index 8 will have our classcode that we want. 
                    exposure = "Exposure" + classcode + seqno; // now that we have our string, we can access our incoming formgroup data using this string as a key.
                    ifAny = "ifAny" + classcode + seqno; 
                    fulltime = "FullTime" + classcode + seqno;
                    parttime = "PartTime" + classcode + seqno;
                    row = this.locationObject.BUSINESSCLASSES.find(x=> x.CLASX == classcode && x.BLDNUM == seqno && x.RECORDSTATE != "D").BUSINESSCLASSSTATS;
                    row.EXPOSE = this.func.justNumbers(data[exposure]); // get the number from the form control value and set the EXPOSE (ex: $50,000 is stored as 50000) 
                    if(this.classListFormGroup.get(ifAny)){ // 6/24/21: added null check -JTL
                        if(data[exposure] != 0 && data[exposure] != undefined){ // if the exposure for this particular business class is not 0, we turn of the validation for the "IfAny" checkbox
                            this.classListFormGroup.get(ifAny).setValidators(Validators.nullValidator)
                            this.classListFormGroup.get(ifAny).updateValueAndValidity({emitEvent:false})
                            if(this.classListFormGroup.get(ifAny).enabled) { this.classListFormGroup.get("ifAny" + row.CLASX + row.BLDNUM).disable() } // check if the If Any checkbox is enabled. If it is, we want to disable it because we have an exposure 
                        }     
                        else{ // if the exposure for this particular business class is 0, the ifAny Checkbox must be checked. so we turn on the validation
                            this.classListFormGroup.get(ifAny).setValidators(this.businessClassValidators.ValidateControlIsTrue("Exposure / If Any is required"))
                            this.classListFormGroup.get(ifAny).updateValueAndValidity({emitEvent:false})
                            if(this.classListFormGroup.get(ifAny).disabled) { this.classListFormGroup.get("ifAny" + row.CLASX + row.BLDNUM).enable() }
                        }  
                    }
                    if(this.classListFormGroup.get(fulltime) && this.classListFormGroup.get(parttime)){
                        row.COMCOV = data[fulltime]; // update our full time and part time employee count on the object graph.
                        row.COLCOV = data[parttime];
                        this.onChangeEmployee(); // Was not updating NEMPL field correctly without function call here 10/27/21

                        if((data[fulltime] == ""  || data[parttime] == "" )){ // if the value is blank
                            this.classListFormGroup.get(fulltime).setValidators(this.businessClassValidators.ValidateEmptyField("FullTime","Full Time and Part Time"));
                            this.classListFormGroup.get(parttime).setValidators(this.businessClassValidators.ValidateEmptyField("PartTime","Part Time"));
                            this.classListFormGroup.get(fulltime).updateValueAndValidity({emitEvent:false});
                            this.classListFormGroup.get(parttime).updateValueAndValidity({emitEvent:false});
                        } 

                        if (this.locationObject.COVERG != "21" && this.locationObject.COVERG != "31") { // if our state isn't MI or NY
                            if ((data[fulltime] == "" || data[fulltime] == "0") && (data[parttime] == "" || data[parttime] == "0")) { // if there are no value in both full time and part time, we want to validate that at least one of them has a value.
                                this.classListFormGroup.get(fulltime).setValidators([this.businessClassValidators.ValidateRequired("FullTime", "Full Time or Part Time", true), this.businessClassValidators.ValidateEmptyField("FullTime", "Full Time and Part Time")]);
                                // this.classListFormGroup.get(parttime).setValidators(this.businessClassValidators.ValidateEmptyField("PartTime","Part Time"));
                                this.classListFormGroup.get(fulltime).updateValueAndValidity({ emitEvent: false });
                                this.classListFormGroup.get(parttime).updateValueAndValidity({emitEvent:false});

                            }
                            else {
                                this.classListFormGroup.get(fulltime).setValidators(Validators.nullValidator);
                                this.classListFormGroup.get(parttime).setValidators(Validators.nullValidator);
                                this.classListFormGroup.get(fulltime).updateValueAndValidity({ emitEvent: false });
                                this.classListFormGroup.get(parttime).updateValueAndValidity({ emitEvent: false });
                            }

                        }

                    }
                } 
            }
            let errors = this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive);
            this.migsystemservice.notifyError(errors);
            this.changeDetectionRef.detectChanges();
            this.classListFormGroup.updateValueAndValidity({ emitEvent: false });
        })

    }
    removeClass(row){
        this.confirmationService.confirm({
            message: 'Are you sure that you want to remove this business class?',
            accept: () => {
                this.locationObject.BUSINESSCLASSES.find(_classx=>{
                    if(_classx.CLASX === row.CLASX && _classx.LOCNUM === row.LOCNUM && _classx.BLDNUM == row.BLDNUM){
                        _classx.RECORDSTATE = 'D';
                        _classx.BUSINESSCLASSSTATS.RECORDSTATE = 'D';
                    }
                });
            }})
    }

    resetPanel(){

    }
}
