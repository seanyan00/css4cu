/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MIGOverlayPanelModule } from '@overridden/primeng-overlaypanel/overlay.module';
import { MIGBusinessClass } from '@shared/business-class/business-class.component';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { RiskAppetiteGuideModule } from '@shared/risk-appetite-guide/risk-appetite-guide.module';
// import { CheckboxModule } from 'primeng/checkbox';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';

import { TableModule } from 'primeng/table';
import { PanelModule } from 'primeng/panel';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { TooltipModule } from 'primeng/tooltip';
import { TextMaskModule } from 'angular2-text-mask';
import { MIGWCABusinessClass } from './wca-business-class.component.';
import { BopBusinessClass } from './bop-business-class.component';

@NgModule({
    imports: [
        MIGButtonModule,
        MIGCheckboxModule,
        FormsModule,
        CommonModule,
        TableModule,
        MIGInputtextModule,
        MIGDropDownModule,
		MIGOverlayPanelModule,
        PanelModule,
        TooltipModule,
        RiskAppetiteGuideModule,
        TextMaskModule,
        ReactiveFormsModule
    ],
    declarations: [MIGBusinessClass, MIGWCABusinessClass, BopBusinessClass],
    exports: [MIGBusinessClass, MIGWCABusinessClass,BopBusinessClass]
})
export class BusinessClassModule { }
