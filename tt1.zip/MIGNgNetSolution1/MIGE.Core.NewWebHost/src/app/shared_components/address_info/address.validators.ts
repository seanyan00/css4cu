import { UntypedFormControl, UntypedFormGroup, ValidatorFn, AbstractControl} from "@angular/forms";
import { Validation } from '@classes/Common/ValidatorClass/Validation';
import { GLPLOCATION } from '@classes/CTR/GLLOCATION';
import { WCALOCATIONS } from "@classes/WCA/WCALocations";

import { CTRQuote } from '@classViewModels/CTR/CTRQuote';


export class MIGAddressValidator extends Validation {
    constructor() {
        super();
    }

 

    //Updated function to perform cross validation with street number, street name and address2.
    //need to pass in the form group itself and make this a ValidatorFn
    //Error now appears if Street Name or Street Number are not entered and no PO BOX is entered
    //or if both a PO Box is entered along with a Street Number or Street Name or Address2 Name
    ValidatePOBOX:  ValidatorFn = (fg: UntypedFormGroup) => {

        const POBox: string = fg.parent.controls['POBOX'].value;
        const StreetName: string = fg.parent.controls['STREETNAME'].value;
        const StreetNum: string = fg.parent.controls['STREETNUMBER'].value;
        const Address2: string = fg.parent.controls['ADDRESSLINE2'].value;

        //we only need to validate the errors, NOT where there are NO errors...just return null for that
        
        //cannot have both a PO Box Specified and address information
        if((POBox.length > 0 && (StreetName.length > 0 || StreetNum.length > 0 || Address2.length > 0))) {
            return {
                severity: "error", summary: "PO Box", detail: "Please either enter a PO Box or Address Information, not both.", step: 1, sticky: true, closable: false
            }       
        } 
        //all values cannot be blank
        if(POBox.length === 0 && StreetName.length === 0 && StreetNum.length === 0) {
            return {
                severity: "error", summary: "PO Box", detail: "Please enter a value for PO Box or Street Number and Street Name.", step: 1, sticky: true, closable: false
            };
        }

        //otherwise there are no errors return null
        return null;
    }

    ValidateTerritoryCode:  ValidatorFn = (addressFormGroup: UntypedFormGroup) => {
        let TerritoryCode: string = addressFormGroup.controls['TERRITORYCODE'].value;

        if ((TerritoryCode == null) || (TerritoryCode == ""))
        {
            return {severity: "error", summary: "TERRITORYCODE", detail: "In order to proceed, a successful territory code search is required.  Please enter a valid location address and save to perform territory code search.", step: 1, sticky: true, closable: false};
        }
        return null;
    }


       //this is not validating anything really. Can enter 00000 and it works fine.
       ValidateZipCode = (fieldId: string, fieldName: string) => {
        return (control:UntypedFormControl) => {
            var out = { severity: "error", summary: fieldId, detail: fieldName + " must be five or nine digits.", step: 1, sticky: true, closable: false };
            let zip: string = control.value;
            
            if (zip.endsWith("-")) zip = zip.replace("-", "");

            if (/^\d{5}([- /]?\d{4})?$/.test(zip)) return null;
            
            return out;
        }
    }

    //If Vermont is selected in Location 1, then the only state that can be selected in the other locations is Vermont
    //If any other state other than Vermont is selected in the first location, then Vermont cannot be selected in other locations 
    ValidateState = (fieldId: string, firstLocation: GLPLOCATION) => {
        return(ac: AbstractControl) => {
            if(firstLocation) {
         
                // Vermont selected in First location with other state selected in other location
                if(firstLocation.LOCST === '44' && ac.value !== '44')  {
                    return { severity: "error", 
                    summary: fieldId, 
                    detail: 'You have selected Vermont in Location 1. All other locations MUST be in Vermont as well.',
                    sticky: true, 
                    closable: false };
                }
                //State other than Vermont selected in first location with Vermont in other location
                if(firstLocation.LOCST !== '44' && ac.value === '44' && firstLocation.LOCST !== '') {
                    return { severity: "error", 
                    summary: fieldId, 
                    detail: 'You have selected a state other than Vermont in Location 1. You may NOT select Vermont in this location.',
                    sticky: true, 
                    closable: false };

                }
            }
            return null;
        }
    }

    ValidateNumberOfFullTimeEmployees = (fieldId: string, fieldName: string, location: WCALOCATIONS) =>  {
        return(control: AbstractControl) => {
            if(location.LOCST == "31" || location.LOCST == "21"){            
            }
        }
    }

      


    /*maxValueValidator = (max:number, field: string) => {
        return (control:FormControl) => {
          var num = control.value;
          if( num.length > max){
            return {
                severity: "error", summary: field, detail: "Max length of " + field + " is " + max + ".", step: 1, sticky: true, closable: false
            };
          }
          return null;
        };
    };

    ValidateNotNull = (fieldId: string, fieldName: string) => {
        return (control: FormControl) => {
            let dummy: any = control.value;
            if (dummy) { return null; } else { return { severity: "error", summary: fieldId, detail: "Please enter a value for " + fieldName, step: 1, sticky: true, closable: false } }
        }
    }

    ValidateRequiredMinMax = (field: string, min: number, max: number) => {
		return (control:FormControl) => {
			var val = control.value;
			var out = { severity: "error", summary: field, detail: field + " is required and should be a length of " + min + " to " + max + ".", step: 1, sticky: true, closable: false };

			if (val.length > max) { return out; }
			if (val.length < min) { return out; }
			if (!val) { return out; }

			return null;
		  };
    }*/
    
 
}
