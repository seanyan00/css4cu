import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ElementRef } from '@angular/core';
import { Renderer2 } from '@angular/core';
import { UntypedFormBuilder } from '@angular/forms';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { Functions } from '@helpers/functions';
import { MIGAddressInformation } from '@shared/address_info/address.component';

describe('MIGAddressInformation', () => {
	let comp: MIGAddressInformation;
	let fixture: ComponentFixture<MIGAddressInformation>;

	beforeEach(() => {
		const elementRefStub = {};
		const rendererStub = {};
		const formBuilderStub = {};
		const contractorsDropDownsStub = {};
		const functionsStub = {
			funcKillAutoFill: () => ({})
		};
		TestBed.configureTestingModule({
			declarations: [ MIGAddressInformation ],
			schemas: [ NO_ERRORS_SCHEMA ],
			providers: [
				{ provide: ElementRef, useValue: elementRefStub },
				{ provide: Renderer2, useValue: rendererStub },
				{ provide: UntypedFormBuilder, useValue: formBuilderStub },
				{ provide: ContractorsDropDowns, useValue: contractorsDropDownsStub },
				{ provide: Functions, useValue: functionsStub }
			]
		});
		fixture = TestBed.createComponent(MIGAddressInformation);
		comp = fixture.componentInstance;
	});

	it('can load instance', () => {
		expect(comp).toBeTruthy();
	});

	it('FullView defaults to: false', () => {
		expect(comp.FullView).toEqual(false);
	});

	it('getTerritoryCode defaults to: false', () => {
		expect(comp.getTerritoryCode).toEqual(false);
	});

	it('hasError defaults to: false', () => {
		expect(comp.hasError).toEqual(false);
	});

	describe('ngAfterViewChecked', () => {
		it('makes expected calls', () => {
			const functionsStub: Functions = fixture.debugElement.injector.get(Functions);
			spyOn(functionsStub, 'funcKillAutoFill');
			comp.ngAfterViewChecked();
			expect(functionsStub.funcKillAutoFill).toHaveBeenCalled();
		});
	});

});
