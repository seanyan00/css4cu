/* ****************************************************************************************************
* PROGRAM DESCRIPTION  - Address Component
* NOTES: This is a shared component that should be able to be used for all product lines. 
* - Consists of a form with fields Street Number, Street Name, Address Line 2, PO BOX, Suite Number, City, State, ZIP code, and Territory Code
* -
* TODO: There is a lot of CTR specific functionality in this component, we should try to make this component more abstract to add flexibility. 
* BUG FIXES:
* - 7/19/22: Only allow alpha-numeric characters in City field (Bug 346) -JTL
* - 8/9/22: Fixed issue where BOP quotes were calling territory code when it already has necessary territory info (Bug 385) -JTL 
* - 8/16/22: Fixed BOP issue where Vermont was only able to be selected on subsequent locations (Bug 403) -JTL 
****************************************************************************************************/
import { Component, ElementRef, Input, OnInit, Renderer2, OnDestroy, ChangeDetectorRef, Output, EventEmitter, AfterViewInit, Inject } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators, UntypedFormBuilder } from '@angular/forms';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { Functions } from '@helpers/functions';
import { ADDRESS } from '@shared/address_info/address.class';
import { MIGAddressValidator } from './address.validators';
import { AddressTerritoryService } from './address-territory.service';
import { debounceTime, distinctUntilChanged} from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { InputMasksClass } from '@helpers/masks';
import { MIGSystemService } from '@root/services/mig.service';
import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';
import { CFPLOCATION } from '@classes/CTR/CFPLOCATION';
import { MenuClass } from '@root/system/menu/menu';
import { GLPLOCATION } from '@classes/CTR/GLLOCATION';
import { ConfirmationService } from 'primeng/api';
import * as _ from 'lodash';
import { DOCUMENT } from '@angular/common';
import { AuthService } from '@auth/auth.service';
import { IQuote } from '@interfaces/IQuote';
import { BOPQuote } from '@classViewModels/BOP/BOPQuote';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { WCAQuote } from '@classViewModels/WCA/WCAQuote';
//import { Panel } from 'primeng/panel';

@Component({
	selector: 'mig-address-information',
    templateUrl: './address.component.html',
    styleUrls: ['address.component.css'],
    providers: [AddressTerritoryService, ConfirmationService]
})

export class MIGAddressInformation implements OnInit, OnDestroy, AfterViewInit {
    ngAfterViewInit(): void {
        if(!this.migRoles.editable || (this.migRoles.ratingOverride.override && !this.showButtons)) {
            this.addressFormGroup.disable();
        }
    }
    // TODO: REFACTOR INPUTS AND OUTPUTS SO THAT THEY CAN APPLY FOR ALL PRODUCT LINES
	@Input('FullView') FullView: boolean = false;
    @Input('getTerritoryCode') getTerritoryCode: boolean = false;
    @Input() public currentLocationNumber: number = 0;
	@Input() public addressFormGroup: UntypedFormGroup;
    @Input() showPOBox:string;
	@Input() addressObject: ADDRESS;
    @Input() public hasError: boolean = false;
    @Input() public mailingAddress: ADDRESS;
    @Input() public quotePolicyInfo: QUOTEPOLICYINFO;
    @Input() quote: IQuote;
    @Input() associatedCfpLocations: CFPLOCATION[] = [];
    @Input() firstLocation: GLPLOCATION;
    @Input() showButtons: boolean = false;
    @Input() saveLocationClicked: boolean = false;
    @Input() currentGLPLocation: GLPLOCATION;
    @Output() addressChanged = new EventEmitter<any>();
    @Output() acquiredTerritoryInfo = new EventEmitter<any>();
    @Output() showSaveBtn = new EventEmitter<any>();
    @Output() userIsChangingTheAddress = new EventEmitter<any>();
    
    
    migAddressValidator: MIGAddressValidator;

    FormGroupSubscription: Subscription;
    StateChangeSubscription: Subscription;

    formColorValid: string = "white";
    formColorInvalid: string = "gainsboro";
    poBoxColor: string;
    streetColor: string;

	stateList: any[];
	selectedState: any = {};

	addressPOBOX: boolean = false;
    showTerritoryCode: boolean = false;
    performedTerritoryCodeLookup: boolean = false;
	readonlyStreet: boolean;
	readonlyPOBox: boolean;
    displayDialog: boolean = false;
    stateChanged: boolean = false;
    initialState: string = '';
    pendingAddressTerritoryLookup: boolean = false;
    readOnlyAddress: boolean = true;
    editMode: boolean;
    needToClearAddress: boolean;
    territoryArray: any[] = [];
    stateSelectionOptions: any[]; 
    cityAndState:string;
    streetNumAndStreetName: string; 
    
	get POBOX() { return this.addressFormGroup.get('POBOX'); }
	get SUITENUMBER() { return this.addressFormGroup.get('SUITENUMBER'); }
	get STREETNUMBER() { return this.addressFormGroup.get('STREETNUMBER'); }
	get STREETNAME() { return this.addressFormGroup.get('STREETNAME'); }
	get ADDRESSLINE2() { return this.addressFormGroup.get('ADDRESSLINE2'); }
	get CITY() { return this.addressFormGroup.get('CITY'); }
    get STATE() { return this.addressFormGroup.get('STATE'); }
    get STATEFORMAT() { return this.addressFormGroup.get('STATEFORMAT'); }
	get ZIPCODE() { return this.addressFormGroup.get('ZIPCODE'); }
	get TERRITORYCODE() { return this.addressFormGroup.get('TERRITORYCODE'); }
    //get SameAsMailing() { return this.addressFormGroup.get('SameAsMailing'); }


    constructor
    (
		public contractorsDropDowns: ContractorsDropDowns,
		private renderer: Renderer2,
		private elem: ElementRef,
		public func: Functions,
		private changeDetectorRef: ChangeDetectorRef,
		public migRoles: MIGSecurityRoles,
        public masks: InputMasksClass,
        public addressTerritoryService: AddressTerritoryService,
        public migsystemservice: MIGSystemService,
        public authService: AuthService,
        private confirmationService: ConfirmationService,
        public menuClass: MenuClass,
        private fb: UntypedFormBuilder,
        @Inject(DOCUMENT) public document: Document
    )
    {
        //addressTerritoryService.logToConsole("Address Component constructor");
        this.migAddressValidator = new MIGAddressValidator();
	}

	ngAfterViewChecked() {
		this.func.funcKillAutoFill(this.elem, this.renderer);
		//this.changeDetectorRef.markForCheck();
	}

	ngOnDestroy() {     
        if(this.quote instanceof CTRQuote || this.quote instanceof WCAQuote){ // not sure why we are doing this in other product lines, but this is causing an issue with BOP Location addresses (Bug 399) so we exclude BOP in this. -JTL.
            this.addressObject = new ADDRESS(this.addressFormGroup.getRawValue());
            if(this.quotePolicyInfo.TRANSACTIONTYPE !="PI"){
                this.addressChanged.emit(this.addressObject); 
            }
        }
        
        //This mig-dropdown can throw an error in certain situations if we dont explicitly remove it during the destroy...
        //This is the root cause:  https://github.com/primefaces/primeng/issues/7970
        //As of 11/7/2019, we have yet to update to the version that contains the fix.
        // - SMB
        //this.addressFormGroup.removeControl('STATE');

        if(this.StateChangeSubscription)this.StateChangeSubscription.unsubscribe();
        if(this.FormGroupSubscription) this.FormGroupSubscription.unsubscribe();
	}

	ngOnInit() {
        this.addressObject.POLICY = this.quotePolicyInfo.QUOTEPOLICYNUMBER;
        this.addressObject.AGENTNUMBER = this.quotePolicyInfo.AGENTNUMBER;
        this.addressObject = new ADDRESS(this.addressObject);

        this.initialState = this.addressObject.STATE;

        if (this.addressFormGroup.pristine) {
            //need to check if the addressObject should be set to the mailingAddress object before initialization otherwise
            //it does not update properly for some reason.
            this.setInitialValues();
            this.addControlsToFormGroup();    
            this.cityAndState = this.addressFormGroup.get("CITY").value  + " " + this.addressFormGroup.get("STATEFORMAT").value;
            this.streetNumAndStreetName = this.addressFormGroup.get("STREETNUMBER").value + this.addressFormGroup.get("STREETNAME").value;
        }
        else {
            //The difference between "getRawValue()" and "value" is "getRawValue()" includes values for disabled controls.
            this.addressObject = new ADDRESS(this.addressFormGroup.getRawValue());
        }

		this.performedTerritoryCodeLookup = this.showTerritoryCode = (this.addressObject.TERRITORYCODE !== "");
         
        
		this.applyPOStreetSuiteName();				
        this.setStreetAndPOColorAndValidation();
         if(this.quotePolicyInfo.TRANSACTIONTYPE != "PI"){
            this.FormGroupSubscription = this.addressFormGroup.valueChanges
            .pipe(debounceTime(500), distinctUntilChanged())
            .subscribe(() => {
                this.addressObject = new ADDRESS(this.addressFormGroup.getRawValue()); 
                this.addressChanged.emit(this.addressObject);
                this.applyPOStreetSuiteName();
                this.setStreetAndPOColorAndValidation();
                this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive);
                if(this.saveLocationClicked) {
                    this.saveLocation();
                    this.saveLocationClicked = false;
                }
            });
        }
        if((!this.pendingAddressTerritoryLookup && this.currentLocationNumber > 0 && !this.needToClearAddress) && this.addressObject.TERRITORYCODE == "") {
            if(this.quote instanceof BOPQuote){
                if(this.quote.getTotalLocations()[this.currentLocationNumber - 1].getTotalBuildings()[0].TERR == ""){
                    this.getTerritoryCode = true;
                    this.addressTerritoryInitialization();
                }
                else{ // if the DW5P130.TERR is already filled, set our address's Territory code to that value.
                    this.showTerritoryCode = true;
                    this.TERRITORYCODE.patchValue(this.quote.getTotalLocations()[this.currentLocationNumber - 1].getTotalBuildings()[0].TERR, {emitEvent: false})
                }
            }
            else{
                this.getTerritoryCode = true;
                this.addressTerritoryInitialization();
            }

        }

        //checks to see if the state changed from the initial value
        this.StateChangeSubscription = this.STATE.valueChanges.subscribe(() => {
                if(this.initialState !== this.STATE.value) this.stateChanged = true;
        });
        this.stateSelectionOptions = this.determineStateSelectionOptions();

        if (this.addressObject.isBlankAddress() && (this.currentLocationNumber > 0) && !this.authService.isPolicyInquiry()){
            this.editAddress();
        }
        if (this.needToClearAddress){
            this.clearAddress();
        }

        if (this.mailingAddress.isMerchantState(this.quotePolicyInfo) && this.addressObject.isBlankAddress() && this.mailingAddress.isPoBoxAddress())
        {
            this.initialState = this.mailingAddress.STATE;
            this.addressObject.STATE = this.mailingAddress.STATE;
            this.addressObject.STATEFORMAT = this.mailingAddress.STATEFORMAT;
            this.STATE.setValue(this.addressObject.STATE, {emitEvent: false});
            this.STATEFORMAT.setValue(this.addressObject.STATEFORMAT, {emitEvent: false});
        }
	}

    initializeEditMode()
    {
        this.userIsChangingTheAddress.emit();

        this.performedTerritoryCodeLookup = false;
        this.pendingAddressTerritoryLookup = false;
        this.showTerritoryCode = false;
        this.applyPOStreetSuiteName();
        this.setStreetAndPOColorAndValidation();

        //this.SameAsMailing.setValue(false, {emitEvent: false});

        this.clearAddress();
        this.toggleEditableControls(true);
    }

    //edit address functionality
     
    editAddress() { // TODO: REFACTOR FOR ALL PRODUCT LINES
        //if there are property coverages, let the user know they will be deleted
        //we need to locate it by locNum on each CFPLocation using paddedLocationID and checking to see if it is marked for deletion or not.
        let hasPropCoverage = _.some(this.associatedCfpLocations, location =>
            location.LOCNUM === this.func.lpad(this.currentLocationNumber.toString(),0,3) && location.RECORDSTATE !== 'D'
        );

        if (!(hasPropCoverage))
        {
            return this.initializeEditMode();
        }

        this.confirmationService.confirm({
            header: 'Edit this location?',
            message: 'Editing this location will remove all property coverage associated with this location.  Are you sure?',
            accept: () => this.initializeEditMode(),
            reject: () => {
            }
        });
    }

    addressTerritoryInitialization() // TODO: REFACTOR FOR ALL PRODUCT LINES
    {
        if ((!(this.getTerritoryCode)) || (this.currentGLPLocation.PROPERTYCOVERAGEINFO != null)) {
            return;
        }

        let callAddressTerritoryOnInit: boolean = true;

        let everyLocationHasAddrTerrInfo: boolean = this.associatedCfpLocations.every((cfpLocation) => {
            /*
            *    We are checking every cfpLocation that is associated to the current address loaded in the address component.
            *
            *   If not every assocated cfpLocation has the fields (TERR, FTSHOR, MLSHOR, PRTCLS, RATCTY) populated,
            *   then we need to call the AddressTerritory api to go get that information.
            */
           let realCfpLocationInstance:CFPLOCATION = Object.assign(new CFPLOCATION(this.quotePolicyInfo), cfpLocation);
           return (realCfpLocationInstance.hasTerritoryInfoPopulated());
        });

        callAddressTerritoryOnInit = ((!everyLocationHasAddrTerrInfo) || (this.addressObject.TERRITORYCODE == "") || (this.associatedCfpLocations.length == 0));

        if (callAddressTerritoryOnInit && this.migRoles.editable)
            this.onAddressFormGroupValueChanges();
    }

    determineStateSelectionOptions()
    {
        if (this.FullView)
        {
            return this.contractorsDropDowns.StatesFull;
        }

        let agentLicensedStateCodes: any[] = _.map(this.quotePolicyInfo.AGENTLICENSEDSTATES, "STATEVALUE");
        let availableStateDropdownSelections:any[] = [];
        //Cannot use AGENTLICENSEDSTATES directly because state names are uppercased in AGENTLICENSEDSTATES.
        //Filtering the proper cased state data from states.json using an array of state codes derived from AGENTLICENSEDSTATES.
        availableStateDropdownSelections = _.filter(this.contractorsDropDowns.States, (stateEntry) => {
            return _.includes(agentLicensedStateCodes, stateEntry.value);
        });
        if (this.currentLocationNumber == 1 || this.quote instanceof BOPQuote) // For BOP Quotes, and for location 1 on CTR Quotes, we simply return all available licensed State Dropdown Selections. 
        {
            return availableStateDropdownSelections;
        }
        if(this.quote instanceof CTRQuote){ // for CTR Quotes, we only show Vermont on subsequent locations if the first location is Vermont, otherwise we display all licensed states except for Vermont.
            return _.filter(availableStateDropdownSelections, stateOption => this.firstLocation.ADDRESS.STATE == "44" ? stateOption.value == "44" : stateOption.value != "44");
        }
    }

    addControlsToFormGroup() {

        this.addressFormGroup.addControl('POBOX', new UntypedFormControl({disabled: this.getTerritoryCode, value: this.addressObject.POBOX}));
        this.addressFormGroup.addControl('SUITENUMBER', new UntypedFormControl({disabled: this.getTerritoryCode, value: this.addressObject.SUITENUMBER}));
        this.addressFormGroup.addControl('STREETNUMBER', new UntypedFormControl({disabled: this.getTerritoryCode, value: this.addressObject.STREETNUMBER}));
        this.addressFormGroup.addControl('STREETNAME', new UntypedFormControl({disabled: this.getTerritoryCode, value: this.addressObject.STREETNAME}));
        this.addressFormGroup.addControl('ADDRESSLINE2', new UntypedFormControl({disabled: this.getTerritoryCode, value: this.addressObject.ADDRESSLINE2},
            this.migAddressValidator.ValidateMaxLength(30, 'ADDRESSLINE2', 'Address Line 2')));
        this.addressFormGroup.addControl('CITY', new UntypedFormControl({disabled: this.getTerritoryCode, value: this.addressObject.CITY},
            [this.migAddressValidator.ValidateMaxLength(20, 'CITY', 'City'),
            this.migAddressValidator.ValidateRequired('CITY', 'City')]));
        this.addressFormGroup.addControl('STATE', new UntypedFormControl({disabled: this.getTerritoryCode, value: this.addressObject.STATE}, [this.migAddressValidator.ValidateRequired('STATE', "State")]));
            //this.migAddressValidator.ValidateState('STATE', this.firstLocation)]));
        this.addressFormGroup.addControl('STATEFORMAT', new UntypedFormControl({disabled: this.getTerritoryCode, value: this.addressObject.STATEFORMAT}));
        this.addressFormGroup.addControl('ZIPCODE', new UntypedFormControl({disabled: this.getTerritoryCode, value: this.addressObject.ZIPCODE}, this.migAddressValidator.ValidateZipCode('ZIPCODE', "Zip Code")));
        this.addressFormGroup.addControl('TERRITORYCODE', new UntypedFormControl({disabled: this.getTerritoryCode, value: this.addressObject.TERRITORYCODE}));
        this.addressFormGroup.addControl('EFFECTIVEDATE', new UntypedFormControl({disabled: this.getTerritoryCode, value: this.addressObject.EFFECTIVEDATE}));
        this.addressFormGroup.addControl('POLICY', new UntypedFormControl({disabled: this.getTerritoryCode, value: this.addressObject.POLICY}));
        this.addressFormGroup.addControl('AGENTNUMBER', new UntypedFormControl({disabled: this.getTerritoryCode, value: this.addressObject.AGENTNUMBER}));
        //this.addressFormGroup.addControl('SameAsMailing', new FormControl({disabled: false, value: false}));

        if (this.getTerritoryCode)
        {
            this.addressFormGroup.setValidators(this.migAddressValidator.ValidateTerritoryCode);
        }

        this.addressFormGroup.updateValueAndValidity();
    }


    clearAddress() {
        try {
        this.SUITENUMBER.setValue('');
        this.STREETNUMBER.setValue('');
        this.STREETNAME.setValue('');
        this.ADDRESSLINE2.setValue('');
        this.POBOX.setValue('');
        this.CITY.setValue('');

        //We do not clear the STATE value on the first location because a change in state on the first location
        //requires all additional coverages to be reset to default upon user confirmation.
        //if(this.currentLocationNumber !== 1)
        this.STATE.setValue('');
        this.STATEFORMAT.setValue('');

        this.ZIPCODE.setValue('');
        this.TERRITORYCODE.setValue('');
        this.toggleEditableControls(true);
        } catch(e) {
            console.log(e);
        }
    }

    setInitialValues() {

        if(this.currentLocationNumber !== 1)
            return;

        let state: string = this.mailingAddress.STATE;
        let tmpTerrCode: string = this.addressObject.TERRITORYCODE || '';
        //if it is a state we write insurance for
        if (this.mailingAddress.isMerchantState(this.quotePolicyInfo) && this.addressObject.isBlankAddress() && !this.mailingAddress.isPoBoxAddress())
        {
            this.addressObject = this.mailingAddress;
            this.addressObject.TERRITORYCODE = tmpTerrCode;
        }

        if(!this.mailingAddress.isMerchantState(this.quotePolicyInfo) &&
        this.currentLocationNumber === 1 &&
        this.addressObject.STREETNUMBER === this.mailingAddress.STREETNUMBER &&
        this.addressObject.STREETNAME === this.mailingAddress.STREETNAME &&
        this.addressObject.ADDRESSLINE2 === this.mailingAddress.ADDRESSLINE2 &&
        this.addressObject.SUITENUMBER === this.mailingAddress.SUITENUMBER &&
        this.addressObject.CITY === this.mailingAddress.CITY &&
        this.addressObject.STATE === this.mailingAddress.STATE &&
        this.addressObject.ZIPCODE === this.mailingAddress.ZIPCODE){ // if any of the address properties are different from the mailing address, we need to clear the address.
            this.needToClearAddress = true;
        } 


    }
    onAddressFormGroupValueChanges() {
        //The difference between "getRawValue()" and "value" is "getRawValue()" includes values for disabled controls.
        this.TERRITORYCODE.setValue("", {emitEvent: false});
        this.showTerritoryCode = false;
        this.performedTerritoryCodeLookup = false;
		this.getAddressTerritory();

		this.setStreetAndPOColorAndValidation()
    }

    isAnyNonPOAddressFilled(): boolean {
        return this.addressObject.STREETNAME != "" || this.addressObject.STREETNUMBER != "" || this.addressObject.ADDRESSLINE2 != "" || this.addressObject.SUITENUMBER != "";
    }

    /**
     * Colors and sets form validation variables in the HTML. Per Bug Ticket 334 on 7/19/22
     * */
    setStreetAndPOColorAndValidation() {

        this.readonlyPOBox = this.isAnyNonPOAddressFilled(); // Validation promoted to function for readability
        this.readonlyStreet = this.addressObject.POBOX != "";

        // If none are filled, don't change form color. (Neither are readonly)
        if (this.addressObject.POBOX.trim() == "" && !this.isAnyNonPOAddressFilled()) {
            this.poBoxColor = this.formColorValid;
            this.streetColor = this.formColorValid;
        }
        else {
            this.poBoxColor = this.isAnyNonPOAddressFilled() ? this.formColorInvalid : this.formColorValid;

            // Just the opposite of whatever poBoxColor is
            this.streetColor = this.poBoxColor == this.formColorInvalid ? this.formColorValid : this.formColorInvalid;
        }

	}


    //if anything has been changed or edited and it has property coverage, we need to display a notifcation letting them know editing the location
    //will remove all property coverage if this on the first location
    saveLocation() {
        this.confirmSaveLocation();
    }

    StopQuoteSaveExit() {
		this.migsystemservice.notifyUpdateRecordState();
		this.migsystemservice.notifySaveQuote(true);
    }

    handleFirstLocationStateChange(event)
    {
        if (this.currentLocationNumber != 1)
        {
            return;
        }

        if(this.authService.LOB == "BOP"){ // we don't pass in the quote so check the LOB this way instead of checking if our quote is an instanceof a BOPQuote.
            return; // we don't want to show the confirmation message in BOP.
        }

        let newState: string = event.value;
        if (this.initialState == newState)
        {
            return;
        }

        let confirmationMessage: string = 'Changing the state will reset all additional coverages to default.\r\n\r\n';

        if (newState == '44')
        {
            confirmationMessage+= 'Changing to a Vermont address will remove any subsequent locations that are not located in Vermont.\r\n\r\n';
            confirmationMessage+= 'A save quote will be triggered if any locations are removed.\r\n\r\n';
        }

        if (this.initialState == '44')
        {
            confirmationMessage+= 'Switching from a Vermont address will remove subsequent locations with a Vermont address.\r\n\r\n';
            confirmationMessage+= 'A save quote will be triggered if any locations are removed.\r\n\r\n';
        }

        confirmationMessage+= 'Do you wish to continue?';

        this.confirmationService.confirm({
            header: 'Change State?',
            message: confirmationMessage,
            acceptLabel: "Yes",
            accept: () => {
                //need to reset all additional coverages to default.
                this.migsystemservice.notifyFirstLocationStateChanged();
            },
            rejectLabel: "No",
            reject: () => {
                this.STATE.setValue(this.initialState);
            }
        });
    }

    confirmSaveLocation()
	{
		this.menuClass.isQuoteDirty = true;
        this.proceedTerritoryCodeLookup();
        this.showSaveBtn.emit(false);
        this.toggleEditableControls(false);
    }

    proceedTerritoryCodeLookup() {
        //this.migRoles.editable = false;
        this.performedTerritoryCodeLookup = false;
        this.showTerritoryCode = false;
        this.acquiredTerritoryInfo.emit(null);
        this.onAddressFormGroupValueChanges();
    }
    toggleEditableControls(editable: boolean)
    {
        if (editable)
        {
            this.POBOX.enable({emitEvent: false});
            this.SUITENUMBER.enable({emitEvent: false});
            this.STREETNUMBER.enable({emitEvent: false});
            this.STREETNAME.enable({emitEvent: false});
            this.ADDRESSLINE2.enable({emitEvent: false});
            this.CITY.enable({emitEvent: false});
            this.STATE.enable({emitEvent: false});

            this.STATEFORMAT.enable({emitEvent: false});
            this.ZIPCODE.enable({emitEvent: false});
            this.editMode = true;
        }

        if (!(editable))
        {
            this.POBOX.disable({emitEvent: false});
            this.SUITENUMBER.disable({emitEvent: false});
            this.STREETNUMBER.disable({emitEvent: false});
            this.STREETNAME.disable({emitEvent: false});
            this.ADDRESSLINE2.disable({emitEvent: false});
            this.CITY.disable({emitEvent: false});

            this.STATE.disable({emitEvent: false});

            this.STATEFORMAT.disable({emitEvent: false});
            this.ZIPCODE.disable({emitEvent: false});
            this.editMode = false;
        }

        //this.changeDetectorRef.detectChanges();
    }

	applyPOStreetSuiteName() {
        if ((this.addressObject.POBOX) && (this.addressObject.POBOX.trim().length > 0)) {
            this.addressPOBOX = true;
			this.POBOX.setValidators([this.migAddressValidator.ValidatePOBOX]);
            this.STREETNAME.setValidators([Validators.nullValidator]);
            this.STREETNUMBER.setValidators([Validators.nullValidator]);
            this.ADDRESSLINE2.setValidators([Validators.nullValidator]);
            this.STREETNUMBER.setValue("", {emitEvent: false});
			this.STREETNAME.setValue("", {emitEvent: false});
            this.SUITENUMBER.setValue("", { emitEvent: false });
            this.ADDRESSLINE2.setValue("", { emitEvent: false });

        }
        else {
            this.addressPOBOX = false;
			this.STREETNAME.setValidators(this.migAddressValidator.ValidateRequired('STREETNAME', "Street Name"));
            this.STREETNUMBER.setValidators([this.migAddressValidator.ValidateRequired('STREETNUMBER', "Street #"),
            this.migAddressValidator.ValidateRequiredMinMax('STREETNUMBER', "Street #", 1, 10)]);
            this.POBOX.setValidators(Validators.nullValidator);
			this.POBOX.setValue("", {emitEvent: false});
        }
        //per Angular must call this function when you add or update validators at runtime
        // this.POBOX.updateValueAndValidity();
        // this.STREETNAME.updateValueAndValidity();
        // this.STREETNUMBER.updateValueAndValidity();
	}

	funcSameAsMailingAddress() {
		if (this.addressObject.isMerchantState(this.quotePolicyInfo)) {
			this.STREETNUMBER.setValue(this.mailingAddress.STREETNUMBER);
			this.STREETNAME.setValue(this.mailingAddress.STREETNAME);
			this.ADDRESSLINE2.setValue(this.mailingAddress.ADDRESSLINE2);
            this.CITY.setValue(this.mailingAddress.CITY);
            this.SUITENUMBER.setValue(this.mailingAddress.SUITENUMBER);
            this.POBOX.setValue(this.mailingAddress.POBOX);
			this.STATE.setValue(this.mailingAddress.STATE);
            this.ZIPCODE.setValue(this.mailingAddress.ZIPCODE);
            this.addressFormGroup.updateValueAndValidity();

		} else {
            this.editAddress();
        }
    }

    checkState() {

    }

    getAddressTerritory() {

        if (((this.addressFormGroup.invalid) && (this.TERRITORYCODE.value != "")) || (this.addressObject.isBlankAddress())) {
            return;
        }

        if (!(this.getTerritoryCode)) {
            return;
        }
        this.pendingAddressTerritoryLookup = true;
        this.TERRITORYCODE.enable();
        this.addressTerritoryService.GetAddressTerritory(this.addressObject).subscribe({
            next: addressTerritory => {
                if ((addressTerritory == null) || (addressTerritory.RETURNEDSTRUCTURECODE == null))
                {
                    this.showTerritoryCode = false;
                    this.pendingAddressTerritoryLookup = false;
                    this.performedTerritoryCodeLookup = true;
                    this.addressFormGroup.updateValueAndValidity();
                    this.TERRITORYCODE.disable();
                    this.toggleEditableControls(true);
                    return;
                }
                switch (addressTerritory.RETURNEDSTRUCTURECODE) {
                    case "PPC":
                        this.STREETNUMBER.patchValue(addressTerritory.RETPPCSTREETNUMBER, {emitEvent: false});
                        if((addressTerritory.RETPPCSTREETNAME + " " + addressTerritory.RETPPCSTREETTYPE).length <= 30){
                            this.STREETNAME.patchValue(addressTerritory.RETPPCSTREETNAME + " " + addressTerritory.RETPPCSTREETTYPE, {emitEvent: false});
                        }
                        else if(addressTerritory.RETPPCSTREETNAME.length <= 30){
                            this.STREETNAME.patchValue(addressTerritory.RETPPCSTREETNAME, {emitEvent: false});
                        }
                        else{
                            this.STREETNAME.patchValue(addressTerritory.RETPPCSTREETNAME.substring(0,30));
                        }
                        //this.STREETNAME.patchValue((addressTerritory.RETPPCSTREETNAME + " " + addressTerritory.RETPPCSTREETTYPE).length <= 30 ? addressTerritory.RETPPCSTREETNAME + " " + addressTerritory.RETPPCSTREETTYPE : addressTerritory.RETPPCSTREETNAME, {emitEvent: false});
                        this.CITY.patchValue(addressTerritory.RETPPCCITY.substr(0, 20), {emitEvent: false});
						this.ZIPCODE.patchValue(addressTerritory.RETPPCZIPCODE + "-" + addressTerritory.RETPPCZIPFOUR, { emitEvent: false });
						this.TERRITORYCODE.patchValue(addressTerritory.RETPPCTERRITORYCODE, { emitEvent: false });
                        this.TERRITORYCODE.disable();
                        this.migsystemservice.notifyWindZone(addressTerritory.WNDZNE); // notify the menu and app footer of the wind zone
                        if(addressTerritory.WNDZNE == 3){ // if the wind zone is 3, it will display the Stop Quote as soon as the territory code is returned.
                            this.displayStopQuote();
                        }
                        break;
                    case "ZPP":
                        this.migsystemservice.notifyWindZone(addressTerritory.WNDZNE); // notify the menu and app footer of the wind zone
                        if(addressTerritory.WNDZNE == 3){ // if the wind zone is 3, it will display the Stop Quote as soon as the territory code is returned.
                            this.displayStopQuote();
                        }
						if (parseInt(addressTerritory.RETZPPTERRITORYCOUNT) == 1) {
							this.TERRITORYCODE.patchValue(addressTerritory.RETZPPTERRITORYZIP, { emitEvent: false });
                            this.TERRITORYCODE.disable();
                        } else {
                            var territories = addressTerritory.RETZPPTERRITORYZIP.match(/.{1,6}/g);
                            this.territoryArray = [];
                            territories.forEach(element => {
                                this.territoryArray.push({"value": element, "label": element});
                            });
                        }
                        break;
                    default:
                }
                this.addressObject = new ADDRESS(this.addressFormGroup.getRawValue());
                this.addressChanged.emit(this.addressObject);
                this.acquiredTerritoryInfo.emit(this.addressTerritoryService.GetCFP_AddressTerritory());
                this.showTerritoryCode = (this.addressObject.TERRITORYCODE != "");
                this.pendingAddressTerritoryLookup = false;
                this.performedTerritoryCodeLookup = true;
            },
            error: err => {
                this.migsystemservice.notifyAutoRecoverFromError();
                this.pendingAddressTerritoryLookup = false;
                this.performedTerritoryCodeLookup = true;
            }
        });
    }
    displayStopQuote(){
		//This function displays the stop quote modal. It is called when the user clicks Add Location or Add Property Coverage, when the windzone for that location is 3. 
		this.confirmationService.confirm({
			message: 'Risk ineligible due to Coastal Restrictions.',
			header: 'Stop Quote',
			icon: 'pi pi-exclamation-triangle',
			acceptLabel: "Save and Exit",
			accept: (() => this.StopQuoteSaveExit()),
			rejectLabel: "Close",
		});
	}


}
