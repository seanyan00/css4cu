/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MIGAddressInformation } from './address.component';
import { OnlyNumber } from '@shared/numberOnly/numberOnly.directive';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { InputMaskModule } from 'primeng/inputmask';
import { MIGInputtextModule} from '@overridden/primeng-inputtext/input.module';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';
import { MIGMessageModule } from '@overridden/primeng-message/message.module';
import { TextMaskModule } from 'angular2-text-mask';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { PipesModule } from '@pipes/pipes.module';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { PanelModule } from 'primeng/panel';

@NgModule({
    imports: [
        PanelModule,
		MIGCheckboxModule,
        FormsModule,
        CommonModule,
		InputMaskModule,
		MIGInputtextModule,
		MIGDropDownModule,
		ReactiveFormsModule,
		MIGMessageModule,
        TextMaskModule,
        MIGButtonModule,
        ConfirmDialogModule,
        PipesModule,
        ProgressSpinnerModule
    ],
    declarations: [MIGAddressInformation, OnlyNumber],
    exports: [MIGAddressInformation]
})
export class AddressInformationModule { }
