import { Injectable } from '@angular/core';
import { throwError as observableThrowError, Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from '@auth/auth.service';
import { environment } from '@environment/environment';
import { ADDRESS, ADDRESSTERRITORY } from '@shared/address_info/address.class';
import { map, tap, catchError, retry, finalize } from 'rxjs/operators';

@Injectable()
export class AddressTerritoryService {
    
    private serverAPI = environment.proxyPath;
    private _addressTerritoryInfo: any = null;
	constructor(private _http: HttpClient, private authService: AuthService) {
	}

	public GetAddressTerritory(address: ADDRESS): Observable<ADDRESSTERRITORY> {
		const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				'RequestPath': 'AddressTerritory/GetAddressTerritory/P/A',
				"Access-Control-Allow-Origin": "*"
			})
        };
        
        if (address.EFFECTIVEDATE <= 0) {
            //Need to set an effective date, otherwise API call will not work.
            address.EFFECTIVEDATE = 20190816;
        }

		return this._http.post(this.serverAPI + 'ProxyPost', address, httpOptions)
            .pipe
            (
				map(response => {
                    this._addressTerritoryInfo = response;
                    return this.GetGLP_AddressTerritory();
                }),
                catchError(this.handleError)
            );
    }

    public GetGLP_AddressTerritory(): ADDRESSTERRITORY {
        if ((this._addressTerritoryInfo == null) || (this._addressTerritoryInfo.GLP == null))
            return null;

        let addressTerritoryResponseObject: ADDRESSTERRITORY = new ADDRESSTERRITORY(this._addressTerritoryInfo.GLP);
        return addressTerritoryResponseObject;
    }

    public GetCFP_AddressTerritory(): ADDRESSTERRITORY {
        if ((this._addressTerritoryInfo == null) || (this._addressTerritoryInfo.CFP == null))
            return null;
            
        let addressTerritoryResponseObject: ADDRESSTERRITORY = new ADDRESSTERRITORY(this._addressTerritoryInfo.CFP);
        return addressTerritoryResponseObject;
    }

    public logToConsole(infoToLog: any) {
        //if (!environment.production)
            //console.log(infoToLog);
    }

	private handleError(error: Response) {
		console.error('handle Error: ' + error.toString());
		return observableThrowError(error.toString() || 'Server error');
	}
}