import * as _ from 'lodash';
import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';

export class ADDRESS {
	EFFECTIVEDATE: number = 0;
    POBOX: string = "";
    SUITENUMBER: string = "";
    STREETNUMBER: string = "";
    STREETNAME: string = "";
    ADDRESSLINE2: string = "";
    CITY: string = "";
    STATE: string = "";
    STATEFORMAT: string = "";
    ZIPCODE: string = "";
    TERRITORYCODE: string = "";
    POLICY: string = "";
    AGENTNUMBER: string = "";
    RECORDSTATE: string = "U";
    GEOLOCATION: GeoLocation = null; 
    DESPRM: string = ""; 
    LOCATN: string = ""; 
    constructor(addressInformation?) {
        if (addressInformation != null) {
            Object.assign(this, addressInformation);

            if (addressInformation.GEOLOCATION != null)
            {
                this.GEOLOCATION = new GeoLocation(addressInformation.GEOLOCATION);
            }
        }
        
        this.ZIPCODE = this.ZIPCODE.replace("-", "");
        this.STREETNAME = this.STREETNAME.toUpperCase();
        this.STATEFORMAT = this.getStateFormat();
        
    }

    isBlankAddress(): boolean {
        
        if ((this.CITY === "") || (this.STATE === "") || (this.ZIPCODE === ""))
            return true;
        
        else if ((this.STREETNAME === "") || (this.STREETNUMBER === ""))
            return true;
        
        return false;
    }

    isPoBoxAddress(): boolean {
        return (this.POBOX !== "");
    }

    isMerchantState(quotePolicyInfo:QUOTEPOLICYINFO): boolean {
        return _.includes(_.map(quotePolicyInfo.AGENTLICENSEDSTATES, "STATEVALUE"), this.STATE);
    }

    getStateFormat(state?: string)
    {
        switch (state != null ? state : this.STATE)
                {
                    case "99": return "OT";
                    case "61": return "AB"; //Alberta
                    case "54": return "AK"; //Alaska
                    case "1": return "AL"; //Alabama
                    case "3": return "AR"; //Arkansas
                    case "2": return "AZ"; //Arizona
                    case "62": return "BC"; //British Columbia
                    case "4": return "CA"; //California
                    case "5": return "CO"; //Colorado
                    case "6": return "CT"; //Connecticut
                    case "8": return "DC"; //District of Columbia
                    case "7": return "DE"; //Delaware
                    case "9": return "FL"; //Florida
                    case "10": return "GA"; //georgia
                    case "52": return "HI"; //Hawaii
                    case "14": return "IA"; //iowa
                    case "11": return "ID"; //Idaho
                    case "12": return "IL"; //Illinois
                    case "13": return "IN"; //Indiana
                    case "88": return "IR"; //??
                    case "15": return "KS"; //Kansas
                    case "16": return "KY"; //Kentucky
                    case "17": return "LA"; //Louisiana
                    case "63": return "MB"; //Manitoba
                    case "19": return "MD"; //Maryland
                    case "18": return "ME"; //Maine
                    case "22": return "MN"; //Minnesota
                    case "24": return "MO"; //Missouri
                    case "23": return "MS"; //Mississippi
                    case "25": return "MT"; //Montana
                    case "98": return "MX"; //??
                    case "71": return "NB"; //New Brunswick
                    case "32": return "NC"; //North Carolina
                    case "33": return "ND"; //North Dakota
                    case "26": return "NE"; //Nebraska
                    case "65": return "NF"; //Newfoundland and Labrador
                    case "30": return "NM"; //New Mexico
                    case "72": return "NS"; //Nova Scotia
                    case "73": return "NU"; //Nunavut ---> This is NOT in the DWXF016 table and needs to be added!
                    case "69": return "NT"; //Northwest Territories
                    //case null: return "NU"; //Nunavut
                    case "27": return "NV"; //Nevada
                    case "35": return "OK"; //Oklahoma
                    case "64": return "ON"; //Ontario
                    case "36": return "OR"; //Oregon
                    case "60": return "PE"; //Prince Edward Island
                    case "58": return "PR"; //Puerto Rico
                    case "66": return "QC"; //Quebec
                    case "38": return "RI"; //Rhode Island (Little Rhody!)
                    case "67": return "SA"; //Saskatchewan
                    case "39": return "SC"; //South Carolina
                    case "40": return "SD"; //South Dakota
                    case "41": return "TN"; //Tennessee
                    case "42": return "TX"; //Texas
                    case "43": return "UT"; //Utah
                    case "45": return "VA"; //Virginia
                    case "46": return "WA"; //Washington
                    case "48": return "WI"; //Wisconsin
                    case "47": return "WV"; //West Virginia
                    case "49": return "WY"; //Wyoming
                    case "68": return "YU"; //Yukon
                    case "20": return "MA";
                    case "21": return "MI";
                    case "28": return "NH";
                    case "29": return "NJ";
                    case "31": return "NY";
                    case "34": return "OH";
                    case "37": return "PA";
                    case "44": return "VT";
                    default: return "";
                }
    }
}

export class ADDRESSTERRITORY extends ADDRESS {
    
    RETPPCCITY: string = "";
    RETPPCDSTFD: string = "";
    RETPPCFIPSCOUNTYCODE: string = "";
    RETPPCFIREDISTRICT: string = "";
    RETPPCMIGCITY: string = "";
    RETPPCPUBLICPROTECTIONCLASS: string = "";
    RETPPCSTATECODE: string = "";
    RETPPCSTREETNAME: string = "";
    RETPPCSTREETNUMBER: string = "";
    RETPPCSTREETPOSTFIX: string = "";
    RETPPCSTREETPREFIX: string = "";
    RETPPCSTREETTYPE: string = "";
    RETPPCTAXCODE: string = "";
    RETPPCTERRITORYCODE: string = "";
    RETPPCZIPCODE: string = "";
    RETPPCZIPFOUR: string = "";
    RETURNEDSTRUCTURECODE: string = "";
    RETZPPFIREDISTRICTCODE1: string = "";
    RETZPPFIREDISTRICTCODE2: string = "";
    RETZPPFIREDISTRICTCOUNT: string = "";
    RETZPPTERRITORYCODE: string = "";
    RETZPPTERRITORYCOUNT: string = "";
    RETZPPTERRITORYZIP: string = "";
    RETCOUNTYNAME: string = "";
    WNDZNE: number = 0; 
    constructor(addressTerritory?) {
        super(addressTerritory);
        
        if (addressTerritory != null)
        {
            Object.assign(this, addressTerritory);
            this.remapProperties();
        }
    }

    private remapProperties() {
        switch (this.RETURNEDSTRUCTURECODE) {
            case "PPC":
                this.STREETNUMBER = this.RETPPCSTREETNUMBER;
                if((this.RETPPCSTREETNAME + " " + this.RETPPCSTREETTYPE).length <= 30){
                    this.STREETNAME = this.RETPPCSTREETNAME + " " + this.RETPPCSTREETTYPE;
                }
                else if(this.RETPPCSTREETNAME.length <= 30){
                    this.STREETNAME = this.RETPPCSTREETNAME;
                }
                else{
                    this.STREETNAME = this.RETPPCSTREETNAME.substring(0,30);
                }
                //this.STREETNAME = this.RETPPCSTREETNAME + " " + this.RETPPCSTREETTYPE;
                this.CITY = this.RETPPCCITY;
                this.ZIPCODE = this.RETPPCZIPCODE + this.RETPPCZIPFOUR;
                this.TERRITORYCODE = this.RETPPCTERRITORYCODE;
                break;
            case "ZPP":
            this.TERRITORYCODE = this.RETZPPTERRITORYZIP;            
                break;
            default:
        }
    }
}

export class GeoLocation {
    MILESTOSHORE: number = 0;
    FEETTOSHORE: number = 0;
    FLOODZONE: string = "";
    LATITUDE: number = 0;
    LONGITUDE: number = 0;
    SHORE: string = "";
    constructor(geoLocationInfo?) {
        if (geoLocationInfo != null)
        {
            Object.assign(this, geoLocationInfo);
        }
    }
}
