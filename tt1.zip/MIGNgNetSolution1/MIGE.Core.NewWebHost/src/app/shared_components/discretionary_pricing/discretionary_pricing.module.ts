
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DiscretionaryPricing } from './discretionary_pricing.component';
import { FormsModule, ReactiveFormsModule, FormGroup, FormBuilder } from '@angular/forms';
import { FieldsetModule  } from 'primeng/fieldset';
import { InputTextModule } from 'primeng/inputtext';
import { PanelModule } from 'primeng/panel';
import { TextMaskModule } from 'angular2-text-mask';
import { MIGMessageModule } from '@overridden/primeng-message/message.module';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';

@NgModule({
    imports: [
        FormsModule,
        CommonModule,
        ReactiveFormsModule,
        MIGMessageModule,
        MIGInputtextModule,
        FieldsetModule,
        InputTextModule,
        PanelModule,
        TextMaskModule,
        MIGButtonModule
    ],
    declarations: [DiscretionaryPricing],
    exports: [DiscretionaryPricing]
})
export class DiscretionaryPricingModule { }
