/* ****************************************************************************************************
* PROGRAM DESCRIPTION  - Discretionary Pricing 
* NOTES: 
* - This component is a child component of Premium Summary (all LOBs) and contains the modal that appears after clicking "Apply/View Discretionary Pricing". 
* 
* BUG FIXES: 
* 4/21/22: Fixed issue where re-rated quote that dips below state threshhold keeps mod. -JTL 
****************************************************************************************************/
import { Component, Input, Output, OnInit, OnDestroy, ViewEncapsulation, EventEmitter } from '@angular/core';
import { UntypedFormGroup, Validators, UntypedFormBuilder } from '@angular/forms';
import { Subscription } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import createNumberMask from 'text-mask-addons/dist/createNumberMask'
import { IQuote } from '@interfaces/IQuote';
import { DISCPRICING } from '@classes/Common/DISCPRICING';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { MIGSystemService } from '@root/services/mig.service';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { StatesService } from '@services/states.service';
import * as _ from 'lodash';
import { RATINGRETURN } from '@classes/Common/RATINGRETURN';
import { WCAQuote } from '@classViewModels/WCA/WCAQuote';
import { AuthService } from '@auth/auth.service';

@Component({
	selector: 'discretionary-pricing',
	templateUrl: './discretionary_pricing.component.html',
	styleUrls: ['discretionary_pricing.component.css'],
	encapsulation: ViewEncapsulation.None
})
export class DiscretionaryPricing implements OnInit, OnDestroy {
	@Input() public quote: IQuote;
	@Input() public discretionaryRatingResult: RATINGRETURN;

	@Output() cancelCallback = new EventEmitter<any>();
	@Output() applyCallback = new EventEmitter<any>();
	@Output() ClearForm = new EventEmitter<any>();

	premium: number;
	stateCode: string;
	formGroup: UntypedFormGroup;
	formGroupSubscription: Subscription;
	discPricing: DISCPRICING[];
	applyAttempted: boolean = false;
	product: string;
	fieldMask = createNumberMask({ prefix: '', suffix: '', allowDecimal: true, requireDecimal: true, integerLimit: 1, allowNegative: false, allowLeadingZeros: true })

	// Constants for use in field disabling/hiding
	njScheduleVals: number[] = [.75, 1.25];
	njDeregMin = .50;
	njDeregMax = 1.50;

	paScheduleVals: number[] = [.60, 1.40];
	paDeregMin = .50;
	paDeregMax = 1.50;
	
    discPricingMin: number;
    discPricingMax: number;
    scheduleStateMinimum: any = null;
	

	constructor(
		private formBuilder: UntypedFormBuilder,
        public migsystemservice: MIGSystemService,
        public migRoles: MIGSecurityRoles,
        public statesService: StatesService,
		public authService: AuthService
	) {
		// Build the initial reactive form
		this.formGroup = this.formBuilder.group({
			schedule: [undefined],
			irpm: [undefined],
			njDereg: [undefined],
			paDereg: [undefined]
		});

	}

	// Getters for specific form controls
	get scheduleControl() { return this.formGroup.get("schedule"); }
	get irpmControl() { return this.formGroup.get("irpm"); }
	get njDeregControl() { return this.formGroup.get("njDereg"); }
	get paDeregControl() { return this.formGroup.get("paDereg"); }

	// Called when the component is initialized
	ngOnInit() {
		this.product = this.authService.LOB;
        // TEMP: Populate the discPricing array manually. This will eventually be hooked up to be populated from the API.
		if(this.quote instanceof(CTRQuote)){this.discPricing = [
			new DISCPRICING(20, .60, 1.25),
			new DISCPRICING(21, .60, 1.40),
			new DISCPRICING(28, .60, 1.00),
			new DISCPRICING(29, .75, 1.25),
			new DISCPRICING(31, .85, 1.15),
			new DISCPRICING(34, .75, 1.25),
			new DISCPRICING(37, .60, 1.40),
			new DISCPRICING(44, .60, 1.40)
        ];}
		if(this.quote instanceof(WCAQuote)){this.discPricing = [
			new DISCPRICING(20, .60, 1.25), //Don't need MA for WCA
			new DISCPRICING(21, .75, 1.25),
			new DISCPRICING(28, .75, 1.25),
			new DISCPRICING(29, .75, 1.25),
			new DISCPRICING(31, .95, 1.05),
			//new DISCPRICING(34, .75, 1.25), //Don't need OH for WCA
			new DISCPRICING(37, .75, 1.25),
			new DISCPRICING(44, .75, 1.25)
        ];}
		


		this.premium = this.quote["POLICYTRANS"]["APRP"];
		this.stateCode = this.quote["POLICYTRANS"]["CANSTE"];
        
        this.statesService.getDiscPricingScheduleStateMinimums().subscribe(responseData => {
            
            this.scheduleStateMinimum = _.find(responseData.ScheduleStateMinimums, scheduleStateMinimum => scheduleStateMinimum.state == this.stateCode);
			if(this.scheduleStateMinimum != null && this.authService.LOB == "WCA"){
				if((this.premium < this.scheduleStateMinimum.policyPremiumMin) && this.premium != 0){ // in scenario where the user applies a mod, fills out a DP worksheet, then modify the Exposure and re-rate such that the new premium dips below our state threshhold, we want to remove the mod and worksheet, per Sherri -JTL 
					this.clearForm();
				}
			}	
            this.checkFieldsDisabled();
            //if ((this.migRoles.editable) && (this.scheduleControl.disabled)) {
			if (this.scheduleControl.disabled) {
                this.quote.SetDPScheduleValue(0);
            }
            //if ((this.migRoles.editable) && (this.irpmControl.disabled)) {
			if (this.irpmControl.disabled) {
                this.quote.SetDPIrpmValue(0);
            }
            //if ((this.migRoles.editable) && (this.irpmControl.disabled && this.scheduleControl.disabled)) {
			if (this.irpmControl.disabled && this.scheduleControl.disabled) {
                this.quote.SetDPNjPaDeregValue(0);
            }
        });

        var dpValue = this.discPricing.find(d => d.STATE == Number(this.stateCode));
        this.discPricingMin = dpValue.MIN;
        this.discPricingMax = dpValue.MAX;

        // Set form validators
        this.scheduleControl.setValidators([Validators.min(this.discPricingMin), Validators.max(this.discPricingMax)]);
        this.irpmControl.setValidators([Validators.min(this.discPricingMin), Validators.max(this.discPricingMax)]);
        this.njDeregControl.setValidators([Validators.min(this.njDeregMin), Validators.max(this.njDeregMax)]);
		this.paDeregControl.setValidators([Validators.min(this.paDeregMin), Validators.max(this.paDeregMax)]);

        /*
        SMB 1/21/2020 - Bug 1615 CTR NJ Dereg Logic
            Per Chris/Sara:
            Here is the response from Sara giving the okay to implement this functionality post Go-Live. 

            @Ken, please add “NJ Dereg Functionality” to RAID.  I’ll put in a new feature task to remove NJ Dereg.
        */

		let currentDVal = this.quote.GetDPNjPaDeregValue();
		//NJ
		if (this.stateCode == '29'){
			this.paDeregControl.setValue(null);
			this.njDeregControl.setValue((currentDVal > 0) ? currentDVal : null);
		}
		else{
			this.njDeregControl.setValue(null);
			this.paDeregControl.setValue((currentDVal > 0) ? currentDVal : null);
		}
		// this.njDeregControl.setValue(null);
		// this.paDeregControl.setValue(null);				
       
        let currentSchedVal = this.quote.GetDPScheduleValue();
        if (currentSchedVal > 0 && currentSchedVal != 1)
            this.scheduleControl.setValue(currentSchedVal);

        let currentIRPMVal = this.quote.GetDPIrpmValue();
        if (currentIRPMVal > 0 && currentIRPMVal != 1){
            this.irpmControl.setValue(currentIRPMVal);
        }

		this.formGroupSubscription = this.formGroup.valueChanges.pipe(debounceTime(100), distinctUntilChanged()).subscribe(data => {
			this.checkFieldsDisabled();
		});
	}

	// Called when the component is destroyed
	ngOnDestroy() {
		if(this.formGroupSubscription) this.formGroupSubscription.unsubscribe();
	}

	
	
	// Checks if fields in the form should be disabled or enabled based on business rules
	checkFieldsDisabled() {

        // if (!this.migRoles.editable)        // {
        //     this.scheduleControl.disable({ emitEvent: false });
        //     this.irpmControl.disable({ emitEvent: false });
        //     this.njDeregControl.disable({ emitEvent: false });
        //     this.paDeregControl.disable({ emitEvent: false });
        //     return;
		// }
		
		if (this.disableSchedule()) {				
			this.scheduleControl.disable({ emitEvent: false });			
			// if(this.quote instanceof(WCAQuote)){ // when clearing the form, set the mods in the object graph to 0 so the mod's save as 0.
			// 	this.clearForm();

			// }		
		} else {
			this.scheduleControl.enable({ emitEvent: false });			
		}
		if (this.disableIrpm()) {
			this.irpmControl.disable({ emitEvent: false });			
		} else {
			this.irpmControl.enable({ emitEvent: false });		
		}
	}
	
	// Returns whether the schedule field should be disabled
	disableSchedule(): boolean {
		//console.log('this.quote.disableSchedule()? ', this.quote.DisableScheduleField(this.scheduleStateMinimum));
		//console.log("scheduleStateMinimum: ", this.scheduleStateMinimum);
		return this.quote.DisableScheduleField(this.scheduleStateMinimum);
	}

	// Returns whether the IRPM field should be disabled
	disableIrpm(): boolean {
		//console.log('this.quote.DisableIrpmField()? ', this.quote.DisableIrpmField());
		return this.quote.DisableIrpmField();
	}

	// Determine if the NJ Dereg field should be shown or not based on business rules
	showNjDereg(): boolean {
        
        let irpmcheck = false;
		let schedulecheck = false;
		let showNjDeregRetVal: boolean = (this.quote.POLICYTRANS.CANSTE == '29');
        let deregFlag  = (this.quote.POLICYTRANS.CANSTE == '29') ? 'Y' : 'N';

        if (this.discretionaryRatingResult)
        {
            deregFlag = this.discretionaryRatingResult.RETURNDEREGFLAG;
        }
	
		if(this.quote.POLICYTRANS.CANSTE == '29')
		{
			//console.log('this.irpmControl.disabled? ',  this.irpmControl.disabled);
			// Hide if the schedule field value does NOT equal any of the specified values in the njScheduleVals array (.75 or 1.25 at the moment)
			//if (!this.irpmControl.disabled) {
			if (!this.disableIrpm()) {
				if ((this.njScheduleVals.some((v) => {
					return (this.irpmControl.value == null) ? false : v == Number(this.irpmControl.value.toString().replace(/\%+/g, ""));
				}))) {
					irpmcheck = true;
				}
				if ((this.njScheduleVals.some((v) => {
					return (this.scheduleControl.value == null) ? false : v == Number(this.scheduleControl.value.toString().replace(/\%+/g, ""));
				}))) {
					schedulecheck = true;
				}
				//but here we need to check if both hav he required value			
				showNjDeregRetVal = (schedulecheck && irpmcheck);
			}
			else if (!this.scheduleControl.disabled) {
				if ((this.njScheduleVals.some((v) => {
					return (this.scheduleControl.value == null) ? false : v == Number(this.scheduleControl.value.toString().replace(/\%+/g, ""));
				}))) {				
					schedulecheck = true;
				}				
				showNjDeregRetVal = schedulecheck;
			} 
							
			showNjDeregRetVal = (showNjDeregRetVal && this.quote.ShowNjDeregField(deregFlag));	

			//if ((this.migRoles.editable) && (!showNjDeregRetVal))
			if (!showNjDeregRetVal)
			{				
				this.quote.SetDPNjPaDeregValue(0);            
				this.njDeregControl.setValue(null, {emitEvent:false});
			}
		}
		//
		return showNjDeregRetVal;
	}

	//
	showPADereg() :boolean {
				
		let irpmcheck = false;
		let schedulecheck = false;			
		let showPaDeregRetVal: boolean = (this.quote.POLICYTRANS.CANSTE == '37');		
        let deregFlag = (this.quote.POLICYTRANS.CANSTE == '37') ? 'Y' : 'N';
        
        if (this.discretionaryRatingResult)
        {
            deregFlag = this.discretionaryRatingResult.RETURNDEREGFLAG;
        }

		if(this.quote.POLICYTRANS.CANSTE == '37')
		{
			//this disabled fucntion checks for property cvg among other things so we
			//will use this, same for below
			//if (!this.irpmControl.disabled) {
			if (!this.disableIrpm()) {	
				if ((this.paScheduleVals.some((v) => {
					return (this.irpmControl.value == null) ? false : v == Number(this.irpmControl.value.toString().replace(/\%+/g, ""));
				}))) {
					irpmcheck = true;
				}
				if ((this.paScheduleVals.some((v) => {
					return (this.scheduleControl.value == null) ? false : v == Number(this.scheduleControl.value.toString().replace(/\%+/g, ""));
				}))) {
					schedulecheck = true;
				}
				//but here we need to check if both hav he required value				
				showPaDeregRetVal = (schedulecheck && irpmcheck);
			}
			else if (!this.scheduleControl.disabled) {	
					
				if ((this.paScheduleVals.some((v) => {
					return (this.scheduleControl.value == null) ? false : v == Number(this.scheduleControl.value.toString().replace(/\%+/g, ""));
				}))) {				
					schedulecheck = true;
				}
				showPaDeregRetVal = schedulecheck;
			}
			
			showPaDeregRetVal = (showPaDeregRetVal && this.quote.ShowPaDeregField(deregFlag));
		
			//console.log('showPaDeregRetVal? ', showPaDeregRetVal);

			//default this to 1 since the math does multipication in the ApplyDiscretionaryPricing() function if its false
			//if ((this.migRoles.editable) && (!showPaDeregRetVal))
			if (!showPaDeregRetVal)
			{						
				this.quote.SetDPNjPaDeregValue(0);            
				this.paDeregControl.setValue(null, {emitEvent:false});
			}
		}
		return showPaDeregRetVal;
	}

	// Cancel the component to exit its view
	cancel() {
		this.cancelCallback.emit();
	}

	// CLear all values in the form
	clearForm() {
		this.formGroup.reset();
		this.applyAttempted = false;
		if(this.quote instanceof(WCAQuote)){ // when clearing the form, set the mods in the object graph to 0 so the mod's save as 0.
			this.quote.STATES.filter(x=>x.RECORDSTATE != "D").forEach(state=>{
				state.SCHMOD = 0;
			});
		}
	}

	// Apply discretionary pricing
	apply() {
		this.applyAttempted = true;

		if (this.formGroup.valid) {
			var scheduleValue = (this.scheduleControl.value == null || this.scheduleControl.value == "") ? 0 : Number(this.scheduleControl.value.toString().replace(/\%+/g, ""));
			var irpmValue = (this.irpmControl.value == null || this.irpmControl.value == "") ? 0 : Number(this.irpmControl.value.toString().replace(/\%+/g, ""));
			var njDeregValue = (this.njDeregControl.value == null || this.njDeregControl.value == "") ? 0 : Number(this.njDeregControl.value.toString().replace(/\%+/g, ""));
			var paDeregValue = (this.paDeregControl.value == null || this.paDeregControl.value == "") ? 0 : Number(this.paDeregControl.value.toString().replace(/\%+/g, ""));

			this.quote.SetDPScheduleValue(scheduleValue);
			this.quote.SetDPIrpmValue(irpmValue);
			//this.quote.SetDPNjDeregValue(njDeregValue);
			//this.quote.SetDPNjPaDeregValue((njDeregValue != 0) ? njDeregValue : paDeregValue);
			this.quote.SetDPNjPaDeregValue((this.stateCode == '29') ? njDeregValue : paDeregValue);

			this.applyCallback.emit(this.quote);
		}
	}
}
