/*****************************************************************************************************
 *
 * UPDATES:
 * 12/3/21: Save quote on init to save new data before viewing application
 * BUG FIXES:
 * TFS 2535: Saved quote on init to make sure data appears on XDOC -ZJG
 ********************************************************************************************************/
/* NG Includes */
import { Component, ViewChild, OnInit, Input } from '@angular/core';
import { OverlayPanel } from 'primeng/overlaypanel';
import { MIGSystemService } from '@root/services/mig.service';
import { IQuote } from '@interfaces/IQuote';
import { MenuClass } from '@root/system/menu/menu';
import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';
import { AuthService } from '@auth/auth.service';

/* Prime Includes */
@Component({
    selector: 'mig-application-complete',
    templateUrl: './application_complete.component.html'
})

export class MIGApplicationComplete implements OnInit{
	@Input() quote: IQuote;
	showQuestionError: boolean = false;
	showReferralError: boolean = false;
    
    @ViewChild(OverlayPanel, { static: false }) DisplayApplicationPanel: OverlayPanel;

    constructor(private migsystemservice: MIGSystemService,
		private menuClass: MenuClass,
        private authService: AuthService) { 

    }

    ngOnInit(){
        if (this.authService.getLOB() == "CTR") {

            let uwqcnt = (this.quote).UWQUESTIONSCATEGORY.length;
            let refcnt = (this.quote).UWREFERRALS.length;
            if(uwqcnt==0){
                this.menuClass.GotoMenuItem('name', 'UnderwritingQuestions');
                this.showQuestionError = true;
                return;
            }
            if ((refcnt == 0) && (!(this.menuClass.menuObject("Referrals").navSkip))) {
                this.menuClass.GotoMenuItem('name', 'Referrals');
                this.showReferralError = true;
                return;
            }

        }
        //We want to save quote before clicking view application button so new data shows
        if(this.authService.getLOB() == "WCA"){
            this.migsystemservice.notifySaveQuote(false);
        }

     }   
    
    redirectToLansa(){
        
        this.migsystemservice.notifyUpdateRecordState();		
		//boolean added for quote redirect
        this.migsystemservice.notifySaveQuote(true);
    }
   

    funcShowDisplayApplicationPanel(overlayPanel: OverlayPanel) {
        this.DisplayApplicationPanel = overlayPanel;
        this.DisplayApplicationPanel.show(event);
    }    
}
