/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { MIGOverlayPanelModule } from '@overridden/primeng-overlaypanel/overlay.module';
import { PanelModule } from 'primeng/panel';
import { InputTextModule } from 'primeng/inputtext';
import { MIGApplicationComplete } from '@shared/application_complete/application_complete.component';
import { MenuClass } from '@root/system/menu/menu';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { LansaAcctManagementService } from '@services/lansa-acct-management.service';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { MIGDocumentButtonModule} from '@shared/document_button/document_button.module';

@NgModule({
    imports: [
        PanelModule,
        MIGButtonModule,
        FormsModule,
        CommonModule,
        InputTextModule,
        MIGOverlayPanelModule,
        MIGDocumentButtonModule,
        ProgressSpinnerModule
    ],
    declarations: [MIGApplicationComplete],
	exports: [MIGApplicationComplete],
	providers: [LansaAcctManagementService]
})
export class ApplicationCompleteModule {
	formGroup: UntypedFormGroup;
	constructor(
		public menuClass: MenuClass,
		private formBuilder: UntypedFormBuilder,
	) {
		this.formGroup = this.formBuilder.group({});

		menuClass.addMenuItem({
			name: 'ApplicationComplete',
			label: 'Application Complete',
			color: "ui-steps-number-default",
			navSkip: false,
			active: false,
			hasError: false,
			errors: [],
			buttons: [],
			icon: 'fa fa-vote-yea',
			block: [],
			visible: true,
			quote: "application"
		});
	}
 }
