/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, FormGroup, FormBuilder } from '@angular/forms';
import { MIGFinishApplicationErisa } from './erisa.component';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { PanelModule } from 'primeng/panel';
import { FieldsetModule } from 'primeng/fieldset';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { MIGMessageModule } from '@overridden/primeng-message/message.module';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { ReactiveFormsModule } from '@angular/forms';
import { TextMaskModule } from 'angular2-text-mask';

// import { NgModel } from '@angular/forms';
@NgModule({
	imports: [
		MIGButtonModule,
		FormsModule,
		ReactiveFormsModule,
		CommonModule,
		PanelModule,
		FieldsetModule,
		MIGInputtextModule,
		MIGMessageModule,
		MIGDropDownModule,
		TextMaskModule
	],
	declarations: [MIGFinishApplicationErisa],
	exports: [MIGFinishApplicationErisa]
})
export class FinishApplicationErisaModule {

}
