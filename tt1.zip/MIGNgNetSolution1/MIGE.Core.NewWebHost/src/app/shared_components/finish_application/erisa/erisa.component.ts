import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { UntypedFormGroup, UntypedFormControl, UntypedFormBuilder,Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { MenuClass } from '@root/system/menu/menu';
import { debounceTime } from 'rxjs/internal/operators/debounceTime';
import { InputMasksClass } from '@helpers/masks';
import { distinctUntilChanged } from 'rxjs/operators';
import { MIGSystemService } from '@root/services/mig.service';
import { IQuote } from '@interfaces/IQuote';
import { ADDITIONALINSURED } from '@classes/Common/ADDITIONALINSUREDS';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { FinishApplicationValidators } from '../finish_application.validators';
import * as _ from 'lodash';
/* Prime Includes */
@Component({
	selector: 'mig-finish-application-erisa',
	templateUrl: './erisa.component.html'
})

export class MIGFinishApplicationErisa implements OnInit, OnDestroy {
	
	formGroup: UntypedFormGroup;
	// formGroupSubscription: Subscription;
	// updateRecordState: Subscription;

	@Input() quote: IQuote;	
	@Input() ctrQuote: CTRQuote;

	additionalInsured: ADDITIONALINSURED;
	additionalInsuredIndex: number = -1;

	stepName: string = "FinishApplication";

	formChanged: boolean = false;
	FormGroupSubscription: Subscription;
	updateRecordState: Subscription;
	data: any;
	finishAppValidation: FinishApplicationValidators
	// recordState: string = "N";

	constructor(
		public migRoles: MIGSecurityRoles,
		public contractorsDropDowns: ContractorsDropDowns,
		public menuClass: MenuClass,
		public masks: InputMasksClass,
		public formBuilder: UntypedFormBuilder,
		private migsystemservice: MIGSystemService
		
	) { 
		if(this.formBuilder == null){
            this.formBuilder = new UntypedFormBuilder();
		}
		this.finishAppValidation = new FinishApplicationValidators();
	}	

	ngOnInit(): void {	

		let mnu = this.menuClass.stepActiveObject;
		this.formGroup = mnu.forms[3];

		if(this.quote.ADDITIONALINSUREDS != undefined && this.quote.ADDITIONALINSUREDS.length > 0){
			this.additionalInsuredIndex = this.quote.ADDITIONALINSUREDS.findIndex(element=>element.ADDCDE === "E" && element.RECORDSTATE != 'D');
		}
		this.processERISA();		
		this.FormGroupSubscription = this.formGroup.valueChanges.pipe(debounceTime(100), distinctUntilChanged()).subscribe(data => {
			this.data = data;
			this.writeDataToCTRQuote()
			this.menuClass.stepActiveObject.errors = [];
			let errors = this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive);
			this.migsystemservice.notifyError(errors);
			this.formChanged = true;			
		});		
	}

	processERISA(): void {

		if (this.additionalInsuredIndex>-1) {			
			this.additionalInsured = this.quote.ADDITIONALINSUREDS[this.additionalInsuredIndex];
			this.additionalInsured.RECORDSTATE = "U";
		}
		else {
			this.additionalInsured = new ADDITIONALINSURED(this.quote.QUOTEPOLICYINFORMATION, this.quote.ADDITIONALINSUREDS);
			this.additionalInsured.ADDCDE = "E";
			this.additionalInsured.RECORDSTATE = "U";
		}

		this.formGroup.addControl("AINNAM", new UntypedFormControl(this.additionalInsured.AINNAM));
		this.formGroup.addControl("AINNUM", new UntypedFormControl(this.additionalInsured.AINNUM));
		this.formGroup.addControl("AINAD1", new UntypedFormControl(this.additionalInsured.AINAD1));
		this.formGroup.addControl("AINAD2", new UntypedFormControl(this.additionalInsured.AINAD2));
		this.formGroup.addControl("AINCTY", new UntypedFormControl(this.additionalInsured.AINCTY));
		this.formGroup.addControl("AINST",  new UntypedFormControl(this.additionalInsured.AINST));
		//this.formGroup.addControl("AINZIP", new FormControl(this.additionalInsured.AINZIP, this.finishAppValidation.ValidateMaxLength(9, 'AINZIP', 'Zipcode')));
		this.formGroup.addControl("AINZIP", new UntypedFormControl(this.additionalInsured.AINZIP));
	}

	writeDataToCTRQuote(): void {
		
		if(this.additionalInsured.ADDCDE === 'E' && (!_.isEmpty(this.data.AINNAM) || !_.isEmpty(this.data.AINNM2) || !_.isEmpty(this.data.AINAD1) || 
		!_.isEmpty(this.data.AINAD2) || !_.isEmpty(this.data.AINAD3) || !_.isEmpty(this.data.AINCTY) || !_.isEmpty(this.data.AINST) || 
		!_.isEmpty(this.data.AINZIP))){ 
			this.quote.updateERISA(this.data)
			//
			this.formGroup.controls['AINNAM'].setValidators(this.finishAppValidation.ValidateRequired('AINNAM', 'ERISA > Name of Plan'));
			this.formGroup.controls['AINNAM'].updateValueAndValidity({emitEvent:false})

			this.formGroup.controls['AINAD1'].setValidators(this.finishAppValidation.ValidateRequired('AINAD1', 'ERISA > Street Number'));
			this.formGroup.controls['AINAD1'].updateValueAndValidity({emitEvent:false})

			this.formGroup.controls['AINAD2'].setValidators(this.finishAppValidation.ValidateRequired('AINAD2', 'ERISA > Street Name'));
			this.formGroup.controls['AINAD2'].updateValueAndValidity({emitEvent:false})

			this.formGroup.controls['AINCTY'].setValidators(this.finishAppValidation.ValidateRequired('AINCTY', 'ERISA > City'));
			this.formGroup.controls['AINCTY'].updateValueAndValidity({emitEvent:false})

			this.formGroup.controls['AINST'].setValidators(this.finishAppValidation.ValidateRequired('AINST', 'ERISA > State'));
			this.formGroup.controls['AINST'].updateValueAndValidity({emitEvent:false})

			this.formGroup.controls['AINZIP'].setValidators(this.finishAppValidation.ValidateRequired('AINZIP', 'ERISA > Zipcode'));
			this.formGroup.controls['AINZIP'].updateValueAndValidity({emitEvent:false});
		};
		//check to see if there is data, otherwise mark it with mark for DELETION
		if(_.isEmpty(this.data.AINNAM) && _.isEmpty(this.data.AINNM2) && _.isEmpty(this.data.AINAD1) && 
		_.isEmpty(this.data.AINAD2) && _.isEmpty(this.data.AINAD3) && _.isEmpty(this.data.AINCTY) && _.isEmpty(this.data.AINST) && 
		_.isEmpty(this.data.AINZIP)){
			 this.quote.deleteERISA();

			this.formGroup.controls['AINNAM'].setValidators(Validators.nullValidator);
			this.formGroup.controls['AINNAM'].updateValueAndValidity({emitEvent:false})

			this.formGroup.controls['AINAD1'].setValidators(Validators.nullValidator);
			this.formGroup.controls['AINAD1'].updateValueAndValidity({emitEvent:false})

			this.formGroup.controls['AINAD2'].setValidators(Validators.nullValidator);
			this.formGroup.controls['AINAD2'].updateValueAndValidity({emitEvent:false})

			this.formGroup.controls['AINCTY'].setValidators(Validators.nullValidator);
			this.formGroup.controls['AINCTY'].updateValueAndValidity({emitEvent:false})

			this.formGroup.controls['AINST'].setValidators(Validators.nullValidator);
			this.formGroup.controls['AINST'].updateValueAndValidity({emitEvent:false})

			this.formGroup.controls['AINZIP'].setValidators(Validators.nullValidator);
			this.formGroup.controls['AINZIP'].updateValueAndValidity({emitEvent:false});
		}
	}

	resetForm() :void{
		this.formGroup.reset();
	}
	ngOnDestroy(): void {
		 if(this.FormGroupSubscription) this.FormGroupSubscription.unsubscribe();
	}
}
