import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { UntypedFormBuilder, UntypedFormGroup, UntypedFormControl, UntypedFormArray} from '@angular/forms';
import { MenuClass } from '@root/system/menu/menu';
import { FinishApplicationValidators } from '../finish_application.validators';
import { distinctUntilChanged, debounceTime} from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { MIGSystemService } from '@root/services/mig.service';
import { Functions } from '@helpers/functions';
import { IQuote } from '@interfaces/IQuote';
import { GLPFORMDATA } from '@classes/Common/GLPFORMDATA';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';

/* Prime Includes */
@Component({
	selector: 'mig-finish-application-2404',
	templateUrl: './2404.component.html'
})

export class MIGFinishApplication2404 implements OnInit, OnDestroy {
	formGroup: UntypedFormGroup;

	waiverFormGroup: UntypedFormGroup;

	@Input() Quote: IQuote;
	finishApplicationValidators: FinishApplicationValidators;
	formGroupSubscription: Subscription;
	updateRecordState: Subscription;

	formChanged: boolean = false;
	recordState: string = "";
	onlyVisibleRecords: any[] = [];
	CG2404: number = 0;
	ngForList: any[] = [];
	//listOfBusinessNames: FormGroup

	get NMEORG() { return this.formGroup.get("NMEORG"); }

	constructor(
		public migRoles: MIGSecurityRoles,
		public menuClass: MenuClass,
		public formBuilder: UntypedFormBuilder,
		private migsystemservice: MIGSystemService,
		public func: Functions
	) {
		this.formGroup = new UntypedFormGroup({});
		this.finishApplicationValidators = new FinishApplicationValidators();
	}

	funcAddAnother() {
		this.menuClass.GotoMenuItem("name", "AdditionalCoveragesLiability");
	}

	ngOnInit(): void {		

		//not sure what's going on here.
		let mnu = this.menuClass.stepActiveObject;
		//this.formGroup = mnu.forms[2];

		if (this.formGroup == null || this.Quote.GLPFORMDATA.every(x => x.RECORDSTATE === 'D') || this.Quote.GLPFORMDATA === []){
			this.formGroup = new UntypedFormGroup({});
		}
		
		this.formBuilder.group({});				
		
		this.CG2404 = this.func.justNumbers((<CTRQuote>this.Quote).GLPENTITY.QUOTEPOLICYLIABLIMITS.WTCNT);

		if (this.Quote.GLPFORMDATA == null) {
			this.Quote.GLPFORMDATA = [];
		}
		//we only are showing the records that are not deleted
		this.onlyVisibleRecords = this.Quote.GLPFORMDATA.filter(x => x.RECORDSTATE !== 'D');

		let addNew = this.CG2404 - this.onlyVisibleRecords.length;

	    if (addNew > 0){
			for(let i=0; i<addNew; i++) {
				this.Quote.GLPFORMDATA.push(new GLPFORMDATA(this.Quote.QUOTEPOLICYINFORMATION));
			}
			//need to update the visible records since we just added some
			this.onlyVisibleRecords = this.Quote.GLPFORMDATA.filter(x => x.RECORDSTATE !== 'D');
		}

		//build out the form
		this.buildForm();
	   	
		//this will check for changes in any of the FormArray formgroup controls
		(this.formGroup.get("DATA") as UntypedFormArray).valueChanges.pipe(distinctUntilChanged(),debounceTime(100)).subscribe(data => {
			this.formGroup.value.DATA.forEach((element, index: number) => {
				this.onlyVisibleRecords[index].NMEORG = element.NMEORG;			
			});
			this.migsystemservice.notifyDoneClicked(this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive));
			this.formChanged = true;
		});
		

	 	this.updateRecordState = this.migsystemservice.subscribeUpdateRecordState().subscribe(() => {			
			for (let c = 0; c < this.CG2404; c++) {					
				this.onlyVisibleRecords[c].POLICY = this.Quote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
				this.onlyVisibleRecords[c].EFFDTE = this.Quote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
				this.onlyVisibleRecords[c].TRANS = this.Quote.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;
				this.onlyVisibleRecords[c].RCDTYP = this.Quote.QUOTEPOLICYINFORMATION.RECORDTYPE;
				this.onlyVisibleRecords[c].EDSDTE = this.Quote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;
				this.onlyVisibleRecords[c].EDSNO = 0;
				this.onlyVisibleRecords[c].RECORDSTATE = "N";		
				this.onlyVisibleRecords[c].NMEORG = this.formGroup.value.DATA[c].NMEORG;				
			}										 		
		});		
		
		//this is needed to set the reference to the menu form
		mnu.forms[2] = this.formGroup;
	}

	//build out the form---we are rebuilding the form each time we hit the page
	buildForm() {
		this.formGroup = new UntypedFormGroup({});
		//if(numToAdd >= 0) this.addControls(numToAdd);
		//if(numToAdd < 0) this.removeControls(Math.abs(numToAdd));
		this.formGroup.addControl("DATA", new UntypedFormArray([])) 
		const control = <UntypedFormArray>this.formGroup.controls["DATA"];
		this.onlyVisibleRecords.forEach((element, index) => {
			let newFormGroup: UntypedFormGroup;
			newFormGroup = this.formBuilder.group({});
			newFormGroup.addControl('NMEORG', new UntypedFormControl(element.NMEORG.trim() || '',
				this.finishApplicationValidators.ValidateRequired('NMEORG' + index ,"Name of Person or Organization #" + (index + 1))));
			control.push(newFormGroup);
		});
	}

	ngOnDestroy(): void {
		if (this.formGroupSubscription) { this.formGroupSubscription.unsubscribe(); }
		if (this.updateRecordState) { this.updateRecordState.unsubscribe(); }
	}

}
