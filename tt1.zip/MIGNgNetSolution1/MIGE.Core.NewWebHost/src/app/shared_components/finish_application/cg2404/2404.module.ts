/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormGroup, FormBuilder } from '@angular/forms';
import { MIGFinishApplication2404 } from './2404.component';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { PanelModule } from 'primeng/panel';
import { FieldsetModule } from 'primeng/fieldset';
import { MenuClass } from '@root/system/menu/menu';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';
import { MIGMessageModule } from '@overridden/primeng-message/message.module';

@NgModule({
	imports: [
		FormsModule,
		ReactiveFormsModule,
		CommonModule,
		PanelModule,
		FieldsetModule,
		MIGInputtextModule,
		MIGButtonModule,
		MIGCheckboxModule,
		MIGMessageModule
	],
	declarations: [MIGFinishApplication2404],
	exports: [MIGFinishApplication2404]
})
export class FinishApplication2404Module {

}
