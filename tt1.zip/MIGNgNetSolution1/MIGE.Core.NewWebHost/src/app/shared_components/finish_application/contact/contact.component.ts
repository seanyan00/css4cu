import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { UntypedFormControl, UntypedFormGroup, Validators, UntypedFormBuilder } from '@angular/forms';
import { Subscription } from 'rxjs';
import { distinctUntilChanged, debounceTime } from 'rxjs/operators';
import { FinishApplicationValidators } from '../finish_application.validators';
import { MenuClass } from '@root/system/menu/menu';
import { InputMasksClass } from '@helpers/masks';
import { Functions } from '@helpers/functions';
import { MIGSystemService } from '@root/services/mig.service';
import { IQuote } from '@interfaces/IQuote';
import { AuthService } from '@auth/auth.service';
import { WCAQuote } from '@classViewModels/WCA/WCAQuote';
/************************************************
Bug fixes
7/23/21: TFS 2355, checking the "same as inspection contact" will now fill the dropdown
9/17/21: TFS 2432, removed "same as named insured checkbox" in inspection contact since we don't need it
9/22/21: TFS 2432, added "same as named insured" checkbox back in with same functionality as ctr

*************************************************/
@Component({
	selector: 'mig-finish-application-contact',
	templateUrl: './contact.component.html'
})

export class MIGFinishApplicationContact implements OnInit, OnDestroy {
	formGroup: UntypedFormGroup;
	@Input() quote: IQuote;

	formGroupSubscription: Subscription;
	updateRecordState: Subscription;

	finishApplicationValidators: FinishApplicationValidators;
	stepName: string = "FinishApplication";
	showContact: boolean = false;
	contactInfoIndex: number = null;

	formChanged: boolean = false;
	recordState: string = "N";



    lineOfBusiness: string;
	constructor(
		public migRoles: MIGSecurityRoles,
		public contractorsDropDowns: ContractorsDropDowns,
		private formBuilder: UntypedFormBuilder,
		public menuClass: MenuClass,
		public masks: InputMasksClass,
		private func: Functions,
		private migsystemservice: MIGSystemService,
		private authService: AuthService
	) {
		this.finishApplicationValidators = new FinishApplicationValidators();
	}
	//CTR Contact controls
	get CNTNAM() { return this.formGroup.get("CNTNAM"); }
	get CNTPHO() { return this.formGroup.get("CNTPHO"); }
	get CNPHTY() { return this.formGroup.get("CNPHTY"); }

	get CNTNAM2() { return this.formGroup.get("CNTNAM2"); }
	get CNTPHO2() { return this.formGroup.get("CNTPHO2"); }
	get CNPHTY2() { return this.formGroup.get("CNPHTY2"); }

	//WCA Contact controls
	get APINCN() { return this.formGroup.get("APINCN"); }
	get APINTL() { return this.formGroup.get("APINTL"); }
	get APINPT() { return this.formGroup.get("APINPT"); }

	get APACCN() { return this.formGroup.get("APACCN"); }
	get APACTL() { return this.formGroup.get("APACTL"); }
	get APACPT() { return this.formGroup.get("APACPT"); }

	get Checkbox() {return this.formGroup.get("GetCheckbox");}

	ngOnInit(): void {
				
		let mnu = this.menuClass.stepActiveObject;
		this.formGroup = mnu.forms[0];

		// the same as named insured checkbox
		// only show it if Insured Type = Individual (IN)
		let INSTYP = this.quote.POLICYTRANS.INSTYP;
		if (INSTYP == "IN") {
			this.showContact = true;
		}
        this.lineOfBusiness = this.authService.LOB;

		

		this.setUpFormGroupSubscription();
		
		this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive);
		
	}

	ngOnDestroy(): void {
		if (this.updateRecordState) { this.updateRecordState.unsubscribe(); }
		if (this.formGroupSubscription) { this.formGroupSubscription.unsubscribe(); }		
	}

	funcSameAsNamedInsured(event) { // Keeping consistant with product lines 
		if(this.authService.LOB == "CTR"){
			if (event) {
				this.CNTNAM.setValue(this.quote.POLICYTRANS.INSNAM);
				this.CNTPHO.setValue(this.quote.POLICYTRANS.INSTEL);
			}
			else{
				this.CNTNAM.setValue(null);
				this.CNTPHO.setValue(null);
			}
		}

		if(this.authService.LOB == "WCA"){ // fill with named insured on the quote
			if(event){
				this.APINCN.setValue(this.quote.POLICYTRANS.INSNAM);
				this.APINTL.setValue(this.quote.POLICYTRANS.INSTEL);
			}
			else{
				this.APINCN.setValue(null);
				this.APINTL.setValue(null);
			}
		}
	}

	funcSameAsInspectionContact(event) {
		if(this.authService.LOB == "CTR"){
			if (event) {
				this.CNTNAM2.setValue(this.CNTNAM.value);
				this.CNTPHO2.setValue(this.CNTPHO.value);
				this.CNPHTY2.setValue(this.CNPHTY.value);
				this.finishApplicationValidators.TriggerValidation(this.formGroup);
				let errors =this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive);
				this.migsystemservice.notifyError(errors);
			}
			else {
				this.CNTNAM2.setValue(null);
				this.CNTPHO2.setValue(null);
				this.CNPHTY2.setValue(null);
			}
		}
		if(this.authService.LOB == "WCA"){
			if (event) {
				this.APACCN.setValue(this.APINCN.value);
				this.APACTL.setValue(this.APINTL.value);
				this.APACPT.setValue(this.APINPT.value);
				this.finishApplicationValidators.TriggerValidation(this.formGroup);
				let errors =this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive);
				this.migsystemservice.notifyError(errors);
			}
			else {
				this.APACCN.setValue(null);
				this.APACTL.setValue(null);
				this.APACPT.setValue(null);
			}
		}
	}
	setUpFormGroupSubscription(){
		if(this.authService.LOB == "CTR"){
			// Contact Name
			this.formGroup.addControl('CNTNAM', new UntypedFormControl(this.quote.CONTACTINFOLOSSES.CNTNAM,
				this.finishApplicationValidators.ValidateRequired('CNTNAM', "Inspection Contact > Contact Name")));
			
			// Phone Number
			this.formGroup.addControl('CNTPHO', new UntypedFormControl(this.quote.CONTACTINFOLOSSES.CNTPHO, 
				this.finishApplicationValidators.ValidateRequired('CNTPHO', "Inspection Contact > Phone Number")));

			// Phone Number Type
			this.formGroup.addControl('CNPHTY', new UntypedFormControl(this.quote.CONTACTINFOLOSSES.CNPHTY, 
				this.finishApplicationValidators.ValidateRequired('CNPHTY', "Inspection Contact > Phone Number Type")));

			this.formGroup.addControl('CNTNAM2', new UntypedFormControl(this.quote.CONTACTINFOLOSSES.CNTNAM2, 
				this.finishApplicationValidators.ValidateRequired('CNTNAM2', "Accounting Contact > Contact Name")));
			this.formGroup.addControl('CNTPHO2', new UntypedFormControl(this.quote.CONTACTINFOLOSSES.CNTPHO2, 
				this.finishApplicationValidators.ValidateRequired('CNTPHO2', "Accounting Contact > Phone Number")));
			this.formGroup.addControl('CNPHTY2', new UntypedFormControl(this.quote.CONTACTINFOLOSSES.CNPHTY2, 
				this.finishApplicationValidators.ValidateRequired('CNPHTY2', "Accounting Contact > Phone Number Type")));
			
				// We needed to retain the value of the checkbox so created a form control to store -3/23/2023 ZJG
			this.formGroup.addControl('GetCheckbox',new UntypedFormControl(
				(this.quote.CONTACTINFOLOSSES.CNTNAM == this.quote.CONTACTINFOLOSSES.CNTNAM2 && 
					this.quote.CONTACTINFOLOSSES.CNTNAM != "" &&
					this.quote.CONTACTINFOLOSSES.CNTPHO == this.quote.CONTACTINFOLOSSES.CNTPHO2 && 
					this.quote.CONTACTINFOLOSSES.CNTPHO != "" &&
					this.quote.CONTACTINFOLOSSES.CNPHTY == this.quote.CONTACTINFOLOSSES.CNPHTY2 &&
					this.quote.CONTACTINFOLOSSES.CNPHTY != "") == true ? true : false
			));	

			this.formGroupSubscription = this.formGroup.valueChanges.pipe(debounceTime(500)).subscribe(data => {
					this.quote.CONTACTINFOLOSSES = data;
					if(this.quote.CONTACTINFOLOSSES.CNTPHO != null) this.quote.CONTACTINFOLOSSES.CNTPHO = this.quote.CONTACTINFOLOSSES.CNTPHO.replace(/[^A-Z0-9]+/ig, "");
					if(this.quote.CONTACTINFOLOSSES.CNTPHO2 != null) this.quote.CONTACTINFOLOSSES.CNTPHO2 = this.quote.CONTACTINFOLOSSES.CNTPHO2.replace(/[^A-Z0-9]+/ig, ""); //10/20/2020: CNTPHO2 now maps to CNTPHO2, not CNTPHO -JTL 
					this.quote.CONTACTINFOLOSSES.TRANS = this.quote.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;
					this.quote.CONTACTINFOLOSSES.POLICY = this.quote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
					this.quote.CONTACTINFOLOSSES.EFFDTE = this.quote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
					this.quote.CONTACTINFOLOSSES.EDSDTE = this.quote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;
					this.quote.CONTACTINFOLOSSES.RCDTYP = this.quote.QUOTEPOLICYINFORMATION.RECORDTYPE;

					this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive);
					//this.migsystemservice.notifyError(errors);
			}); 
		} // End CTR
		if(this.authService.LOB == "WCA"){ //Start WCA
			let wcaquote = this.quote as WCAQuote;
			this.formGroup.addControl('APINCN', new UntypedFormControl(wcaquote.ACCOUNTINGCONTACT.APINCN,
				this.finishApplicationValidators.ValidateRequired('APINCN', "Inspection Contact > Contact Name")));
			
			// Phone Number
			this.formGroup.addControl('APINTL', new UntypedFormControl(wcaquote.ACCOUNTINGCONTACT.APINTL, 
				this.finishApplicationValidators.ValidateRequired('APINTL', "Inspection Contact > Phone Number")));

			// Phone Number Type
			this.formGroup.addControl('APINPT', new UntypedFormControl(wcaquote.ACCOUNTINGCONTACT.APINPT, 
				this.finishApplicationValidators.ValidateRequired('APINPT', "Inspection Contact > Phone Number Type")));

			this.formGroup.addControl('APACCN', new UntypedFormControl(wcaquote.ACCOUNTINGCONTACT.APACCN, 
				this.finishApplicationValidators.ValidateRequired('APACCN', "Accounting Contact > Contact Name")));
			this.formGroup.addControl('APACTL', new UntypedFormControl(wcaquote.ACCOUNTINGCONTACT.APACTL, 
				this.finishApplicationValidators.ValidateRequired('APACTL', "Accounting Contact > Phone Number")));
			this.formGroup.addControl('APACPT', new UntypedFormControl(wcaquote.ACCOUNTINGCONTACT.APACPT, 
				this.finishApplicationValidators.ValidateRequired('APACPT', "Accounting Contact > Phone Number Type")));

				// We needed to retain the value of the checkbox so created a form control to store -3/23/2023 ZJG
			this.formGroup.addControl('GetCheckbox',new UntypedFormControl(
				(wcaquote.ACCOUNTINGCONTACT.APACCN == wcaquote.ACCOUNTINGCONTACT.APINCN && 
					wcaquote.ACCOUNTINGCONTACT.APACCN != "" &&
					wcaquote.ACCOUNTINGCONTACT.APACPT == wcaquote.ACCOUNTINGCONTACT.APINPT && 
					wcaquote.ACCOUNTINGCONTACT.APACPT != "" &&
					wcaquote.ACCOUNTINGCONTACT.APACTL == wcaquote.ACCOUNTINGCONTACT.APINTL &&
					wcaquote.ACCOUNTINGCONTACT.APACTL != "") == true ? true : false
			));

			this.formGroupSubscription = this.formGroup.valueChanges.pipe(debounceTime(500)).subscribe(data => {
				wcaquote.ACCOUNTINGCONTACT = data;
				if(wcaquote.ACCOUNTINGCONTACT.APINTL != null) wcaquote.ACCOUNTINGCONTACT.APINTL = wcaquote.ACCOUNTINGCONTACT.APINTL.replace(/[^A-Z0-9]+/ig, "");
				if(wcaquote.ACCOUNTINGCONTACT.APACTL != null || wcaquote.ACCOUNTINGCONTACT.APACTL != "0") wcaquote.ACCOUNTINGCONTACT.APACTL = wcaquote.ACCOUNTINGCONTACT.APACTL.replace(/[^A-Z0-9]+/ig, "");
				wcaquote.ACCOUNTINGCONTACT.TRANS = wcaquote.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;
				wcaquote.ACCOUNTINGCONTACT.POLICY = wcaquote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
				wcaquote.ACCOUNTINGCONTACT.EFFDTE = wcaquote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
				wcaquote.ACCOUNTINGCONTACT.EDSDTE = wcaquote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;
				wcaquote.ACCOUNTINGCONTACT.RCDTYP = wcaquote.QUOTEPOLICYINFORMATION.RECORDTYPE;

				this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive);
			});
		}// End WCA
	}
}
