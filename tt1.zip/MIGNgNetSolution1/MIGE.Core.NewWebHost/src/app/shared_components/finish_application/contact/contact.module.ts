/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MIGFinishApplicationContact } from './contact.component';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { PanelModule } from 'primeng/panel';
import { FieldsetModule } from 'primeng/fieldset';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';
import { MIGMessageModule } from '@overridden/primeng-message/message.module';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { TextMaskModule } from 'angular2-text-mask';

@NgModule({
	imports: [
		FormsModule,
		ReactiveFormsModule,
		CommonModule,
		PanelModule,
		FieldsetModule,
		MIGInputtextModule,
		MIGButtonModule,
		MIGCheckboxModule,
		MIGMessageModule,
		MIGDropDownModule,
		TextMaskModule
	],
	declarations: [MIGFinishApplicationContact],
	exports: [MIGFinishApplicationContact]
})
export class FinishApplicationContactModule {

}
