/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddressInformationModule } from '@shared/address_info/address.module';
import { PanelModule } from 'primeng/panel';
import {ListboxModule} from 'primeng/listbox';
import {CheckboxModule} from 'primeng/checkbox';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { MIGCheckboxModule} from '@overridden/primeng-checkbox/checkbox.module';
import { InputMaskModule } from 'primeng/inputmask';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { MIGMessageModule } from '@overridden/primeng-message/message.module';
import {AccordionModule} from 'primeng/accordion';
import { MIGCalendarModule } from '@overridden/primeng-calendar/calendar.module';
import { TextMaskModule } from 'angular2-text-mask';
import { MIGAdditionalInterestMortgagee} from './additional_interest_mortgagee.component';
import { TooltipModule } from 'primeng/tooltip';
//import { MIGCheckbox } from '@overridden/primeng-checkbox/checkbox';
//import { MIGInsuredInformation } from './insured.component';
// import { CalendarModule } from 'primeng/calendar';
// import { DropdownModule } from 'primeng/dropdown';
//import { FieldsetModule } from 'primeng/primeng';
// import { MessageModule } from 'primeng/message';
// import { InputTextModule } from 'primeng/inputtext';
// import { NgModel } from '@angular/forms';

@NgModule({
	imports: [
		
		MIGCalendarModule,
		MIGCheckboxModule,
        FormsModule,
		PanelModule,
		ListboxModule,
		CheckboxModule,
		CommonModule,
		InputMaskModule,
		TextMaskModule,		
		MIGInputtextModule,		
        MIGDropDownModule,
        MIGButtonModule,		
		MIGMessageModule,
		ReactiveFormsModule,
		AddressInformationModule,		
		AccordionModule,
		TooltipModule
		// CalendarModule,
		// InputTextModule,
		//FieldsetModule,
		// DropdownModule,
		// MessageModule
	],
	declarations: [MIGAdditionalInterestMortgagee],
	exports: [MIGAdditionalInterestMortgagee],
	//providers: [MIGNamedInsuredValidator]
})
export class MIGAdditionalInterestMortgageeModule { }