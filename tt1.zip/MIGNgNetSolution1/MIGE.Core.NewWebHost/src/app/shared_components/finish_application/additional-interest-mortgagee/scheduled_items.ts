import { IQuote } from '@interfaces/IQuote';
import {IScheduledItem} from '@interfaces/IScheduledItems';

export class ScheduledItemsFunctions{
    
    private quote: IQuote;
    private coverage: string;
    
    constructor(coverage: string, quote: IQuote){
        
        this.quote = quote;
        this.coverage = coverage;

        //console.log("this.coverage" + this.coverage);

    }

    getScheduledItemsCount(coverage: string) : number {
        //return 5;
        return this.quote.GetScheduledItems(coverage).length;
    }

    getScheduledItems(coverage: string) : IScheduledItem[] {
        return this.quote.GetScheduledItems(coverage);
    }

    //we need to remove the mortgage number of associated scheduled items
    remScheduledItems(coverage:string, mortgageNum: string, schItemsArray: any[]): void {
        schItemsArray.forEach(item => {
            if(item.MRTGNO === mortgageNum) item.RECORDSTATE = 'D';
        });
    }

    logTest() {
        //console.log("LOG TEST");
    }
}