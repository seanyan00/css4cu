import { Component, Input, OnInit, OnDestroy, ViewEncapsulation, ChangeDetectorRef} from '@angular/core';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { UntypedFormGroup, UntypedFormControl, UntypedFormBuilder, UntypedFormArray, AbstractControl, Validators } from '@angular/forms';
import { MIGNamedInsuredValidator } from '@shared/insured_info/insured.validators';
import { Functions } from '@helpers/functions';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { Subscription } from 'rxjs';
import { distinctUntilChanged } from 'rxjs/operators';
import { debounceTime } from 'rxjs/operators';
import { IQuote } from '@interfaces/IQuote';
import { MIGSystemService } from '@services/mig.service';
import { MenuClass } from '@root/system/menu/menu';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { InputMasksClass } from '@helpers/masks';
import { IMortgagee } from '@interfaces/IMortgagee';
import { ILocation } from '@interfaces/ILocation';
import { ScheduledItemsFunctions } from './scheduled_items';
import { ErrorService } from '@root/services/error.service';
import * as _ from 'lodash';
import { IMPSCHEDULEDITEM } from '@classes/CTR/IMPSCHEDULEDITEMS';


@Component({
    selector: 'mig-additional-interest-mortgagee',
	templateUrl: './additional_interest_mortgagee.component.html',
	styleUrls: ['additional_interest_mortgage.component.css'],
	encapsulation: ViewEncapsulation.None,
})

export class MIGAdditionalInterestMortgagee implements OnInit, OnDestroy {
    
    migNamedInsuredValidator: MIGNamedInsuredValidator;
    //The following fields are need for Type and Coverage Types dropdowns
    //to be filtered out based on specific conditions

    //Type dropdown list
    ddListMRTGTP : any[] = [];
    //Coverage type dropdown list
    ddListMRTGTPCOVERG : any[] = [];
    //TODO:  make this an IQuote
    //@Input() quote: CTRQuote;
    @Input() quote: IQuote;
    
    private coverage: string;
    messages: any = [];
    private ScheduledItems : ScheduledItemsFunctions;
    private typeOfControl: string;
    //@Input() mortgagee: IMortgagee;

    //formBuilder: FormBuilder;
    addInterestMrtgeeFormGroup: UntypedFormGroup;
    FormGroupSubscription : Subscription;

    //Array to determine the location of records to be edited on the object graph
    editMortgageeAdditionalInterestIndex: number[];
    
    mortgageeAdditionalInterest: IMortgagee;
    
    //Array to hold the completed from groups for additional interest
    completedAdditionalInterestMortgagees: UntypedFormGroup[] = [];
    //completedAdditionalInterestMortgagees: FormArray[] = [];
    formArray: UntypedFormArray[] = [];

    //Toggle displaying the Additional Interest Form
    showAddInterestMrtgeeFormGroup: boolean = true;
    saveClicked: boolean; 
    showDesc: boolean;
    initialBPP: boolean;
    addedSchItems: any[] = [];
    //Type
    get MRTGTP() { return this.addInterestMrtgeeFormGroup.get("MRTGTP"); }
    // Coverage Type
	get MRTGTPCOVERG() { return this.addInterestMrtgeeFormGroup.get("MRTGTPCOVERG"); }
    //Mortgage - Additional Interest Name
    get MRTGNM() { return this.addInterestMrtgeeFormGroup.get('MRTGNM') };
    // Street Number
	get MRTGA1() { return this.addInterestMrtgeeFormGroup.get("MRTGA1"); }
	// Street Name
	get MRTGA2() { return this.addInterestMrtgeeFormGroup.get("MRTGA2"); }
	// City
	get MRTGCT() { return this.addInterestMrtgeeFormGroup.get("MRTGCT"); }
	// State
	get MRTGST() { return this.addInterestMrtgeeFormGroup.get("MRTGST"); }
	// Zipcode
	get MRTGZP() { return this.addInterestMrtgeeFormGroup.get("MRTGZP"); }
	//Description
    get MRTITD() { return this.addInterestMrtgeeFormGroup.get("MRTITD"); }

    constructor(
        public contractorsDropDowns: ContractorsDropDowns,
        public formBuilder: UntypedFormBuilder,
		public func: Functions,
		public migsystemservice: MIGSystemService,
		public menuClass: MenuClass,
		public migRoles: MIGSecurityRoles,
        public masks: InputMasksClass,
        public errorService: ErrorService,
        public cd: ChangeDetectorRef
    ) {
        if(this.formBuilder == null){
            this.formBuilder = new UntypedFormBuilder();
        }

        //this.mortgageeAdditionalInterest = new CFPMORTGAGEE(this.quote.QUOTEPOLICYINFORMATION);
        this.migNamedInsuredValidator = new MIGNamedInsuredValidator();
        this.ddListMRTGTPCOVERG= this.contractorsDropDowns.MRTGTPCOVERG;
        this.ddListMRTGTP = this.contractorsDropDowns.MRTGTP;
        this.migsystemservice.subscribeXClicked().subscribe(() => {
			this.saveClicked=false;	
		});
    }

    ngOnDestroy(){
        this.migsystemservice.notifyToastMessagesCleared();
    }

    ngOnInit(){
        try {      
            let mnu = this.menuClass.stepActiveObject;
            this.addInterestMrtgeeFormGroup = mnu.forms[1];
            this.addInterestMrtgeeFormGroup = this.buildAddIntMortgageeFormGroup(this.mortgageeAdditionalInterest);
            this.addInterestMrtgeeFormGroup.get("MRTGTP").valueChanges.subscribe((value) => this.onMRTGTPValueChanges(value));
            this.addInterestMrtgeeFormGroup.get("MRTGTPCOVERG").valueChanges.subscribe((value) => 
                this.onMRTGTPCOVERGValueChange(value)
            );
            this.secondInit();
        }
        catch (error) {
            //console.log(error);
        }
    }

    secondInit() {
        //this.filterMortgageeAdditionalInterest(this.addInterestMrtgeeFormGroup.value as CFPMORTGAGEE);
        if(this.coverage != null) return;

        let additionalInterest : string[] = ["CFP", "IMP"];
        
        additionalInterest.forEach(value=> { 

            this.coverage = value;
            let property: any[] = this.quote.GetLocations(this.coverage);
            this.filterMortgageeAdditionalInterest(this.addInterestMrtgeeFormGroup.value as IMortgagee);
            
            //Determine if property coverage is on the quote.
            //if(this.quote.CFPENTITY.CFPLOCATIONS.length == 0){
            if(property != null && (property.length === 0 || property[0].RECORDSTATE === 'D')){
                //If there is NO property coverage on the quote remove the ability select Mortgage
                //in the Type
                this.ddListMRTGTP = this.contractorsDropDowns.MRTGTP.filter(x => x.value !== "M");
                //If there is no property coverage on the quote remove the ability to select
                //Business Personal Property from the Coverage Type Listing
                this.ddListMRTGTPCOVERG = this.ddListMRTGTPCOVERG.filter(x => x.value !== "BPP");
            }
            
           //need to make this a ctrQuote to have the necessary items on it.
           let ctrQuote = <CTRQuote> this.quote; 
           //remove scheduled items from the dropdown if there are no scheduled items listed
           if(!ctrQuote.IMPENTITY.IMPSCHEDULEDITEMS.length) this.ddListMRTGTPCOVERG = this.ddListMRTGTPCOVERG.filter(x => x.value !== 'SI');

            //this.addInterestMrtgeeFormGroup.get("MRTGTP").valueChanges.subscribe((value) => this.onMRTGTPValueChanges(value));

            //if(this.quote.CFPENTITY.CFPMORTGAGEE.length > 0) {
            if(this.quote.GetMortgagees(this.coverage).length > 0) {
                //let list : CFPMORTGAGEE[] = [];
                let list : IMortgagee[] = [];
                //this.quote.CFPENTITY.CFPMORTGAGEE.forEach(element => { 
                this.quote.GetMortgagees(this.coverage).forEach((element, index) => { 
                    if(list.filter(x=> 
                        x.MRTGNM == element.MRTGNM &&
                        x.MRTGA1 == element.MRTGA1 &&
                        x.MRTGCT == element.MRTGCT &&
                        x.MRTGST == element.MRTGST &&
                        x.MRTGZP == element.MRTGZP
                    ).length == 0) {
                
                        //list.push(element);
                        //need to add in the controls for any completedAdditionalInterestMortgagees
                        this.completedAdditionalInterestMortgagees.push(this.formBuilder.group(element));
                        this.completedAdditionalInterestMortgagees[index].removeControl('INSTALLATIONCOVERAGE');
                        //need to check if the INSTALLATIONCOVERAGE Control actually exists or it will silently error out.
                        if(element['INSTALLATIONCOVERAGE']) this.completedAdditionalInterestMortgagees[index].addControl('installationCoverage', this.formBuilder.array(element['INSTALLATIONCOVERAGE']));
                    }
                })
                this.ScheduledItems = new ScheduledItemsFunctions(this.coverage, this.quote);
                //we need to add in the controls for scheduled items now if there are any
                let quote = this.quote as CTRQuote;
                

                //we need to add in controls for Scheduled Items and BPP BEFORE it tries to look for them otherwise we will get
                //a "Can't find Control with name xxxx" error

                //scheduled items - IMP Scheduled Items
                quote.IMPENTITY.IMPSCHEDULEDITEMS.forEach(item => {
                    this.completedAdditionalInterestMortgagees.forEach(mort => {
                        mort.addControl('ITEM_D' + item.ITEMNO, new UntypedFormControl(false));
                    });
                });

                //BPP items - CFP Scheduled Items
                quote.CFPENTITY.CFPSCHEDULEDITEMS.forEach(item => {
                    this.completedAdditionalInterestMortgagees.forEach(mort => {
                        mort.addControl('LOCBLDG' + item.LOCNUM + item.BLDNUM, new UntypedFormControl(false));
                    });
                });

                this.showAddInterestMrtgeeFormGroup = false;
                //scheduledItems addcontrol
                if(this.ScheduledItems.getScheduledItemsCount(this.coverage) > 0) this.setTypeOfControl(null, "SI");
                //this.cd.detectChanges();
            }
        });
    }

    UpdateForm(){
		this.FormGroupSubscription = this.addInterestMrtgeeFormGroup.valueChanges.pipe(distinctUntilChanged(), debounceTime(1000)).subscribe(data => {
			if(this.saveClicked){
			this.checkForErrors();	
			}	
		});
    }
    
	buildAddIntMortgageeFormGroup(additionalInterestData: IMortgagee): UntypedFormGroup {
      


        if(additionalInterestData != null){

                return this.formBuilder.group({
                    //Type
                    MRTGTP: [additionalInterestData.MRTGTP, this.migNamedInsuredValidator.ValidateRequired('MRTGTP',"Type")],
                    //Coverage Type
                    MRTGTPCOVERG: [""],
                    //Mortgagee / Loss Payee Name
                    MRTGNM: [additionalInterestData.MRTGNM, this.migNamedInsuredValidator.ValidateMaxLength(30, 'MRTGNM', 'Additional Interest Name')],
                    // Street Number
                    MRTGA1: [additionalInterestData.MRTGA1],
                    // Street Name
                    MRTGA2: [additionalInterestData.MRTGA2],
                    // City
                    MRTGCT: [additionalInterestData.MRTGCT],
                    // State
                    MRTGST: [additionalInterestData.MRTGST],
                    // Zipcode
                    MRTGZP: [additionalInterestData.MRTGZP],
                    //ITEM DESCRIPTION
                    MRTITD: [additionalInterestData.MRTITD]
                    // itemDescription: this.formBuilder.array([
                    //     this.formBuilder.group({
                    //         desc: ["description"]
                    //     })
                    // ])
            });
        }
        else {
                return this.formBuilder.group({
                    //Type
                    MRTGTP: ["", this.migNamedInsuredValidator.ValidateRequired('MRTGTP', "Type")],
                    //Coverage Type
                    MRTGTPCOVERG: [""],
                    //Mortgagee / Loss Payee Name
                    MRTGNM: ["", this.migNamedInsuredValidator.ValidateMaxLength(30, 'MRTGNM', 'Additional Interest Name')],
                    // Street Number
                    MRTGA1: [""],
                    // Street Name
                    MRTGA2: [""],
                    // City
                    MRTGCT: [""],
                    // State
                    MRTGST: [""],
                    // Zipcode
                    MRTGZP: [""],
                    //ITEM DESCRIPTION
                    MRTITD: [""]
                    
                    // itemDescription: this.formBuilder.array([
                    //     this.formBuilder.group({
                    //         desc: ["description"]
                    //     })
                    // ])
            });
        }
    }
    

    onMRTGTPValueChanges(value: string): void {

        //set the validation based on if we have a type selected
       if(value) {
           //this.MRTGTPCOVERG.setValidators(this.migNamedInsuredValidator.ValidateRequired('MRTGTPCOVERG',"Coverage Type"));
           this.MRTGNM.setValidators([this.migNamedInsuredValidator.ValidateRequired('MRTGNM',"Name"), this.migNamedInsuredValidator.ValidateMaxLength(30, 'MRTGNM', 'Mortgagee Name')]);
           this.MRTGA1.setValidators(this.migNamedInsuredValidator.ValidateRequired('MRTGA1', "Street Number"));
           this.MRTGA2.setValidators(this.migNamedInsuredValidator.ValidateRequired('MRTGA2', "Street Name"));
           this.MRTGCT.setValidators(this.migNamedInsuredValidator.ValidateRequired('MRTGCT', "City"));
           this.MRTGST.setValidators(this.migNamedInsuredValidator.ValidateRequired('MRTGST', "State"));
           this.MRTGZP.setValidators(this.migNamedInsuredValidator.ValidateRequired('MRTGZP', "Zip Code"));
       } else {
       // this.MRTGTPCOVERG.setValidators(Validators.nullValidator);
            this.MRTGNM.setValidators(Validators.nullValidator);
            this.MRTGA1.setValidators(Validators.nullValidator);
            this.MRTGA2.setValidators(Validators.nullValidator);
            this.MRTGCT.setValidators(Validators.nullValidator);
            this.MRTGST.setValidators(Validators.nullValidator);
            this.MRTGZP.setValidators(Validators.nullValidator);
       }

       //if the type is mortgagee
        if (value === "M" && this.quote instanceof CTRQuote) {
            this.coverage = "CFP";
            this.MRTGTPCOVERG.setValue("");
            this.MRTGTPCOVERG.setValidators(Validators.nullValidator);
            this.MRTGTPCOVERG.updateValueAndValidity();
            this.setTypeOfControl("LOC");
            this.secondInit();
            this.addControls(this.typeOfControl);
        }
         else {
            this.MRTGTPCOVERG.setValidators(this.migNamedInsuredValidator.ValidateRequired('MRTGTPCOVERG',"Coverage Type"));
            //this.MRTGTPCOVERG.updateValueAndValidity();
         }    

         //update the validation
         this.MRTGTPCOVERG.updateValueAndValidity();
         this.MRTGNM.updateValueAndValidity();
         this.MRTGA1.updateValueAndValidity();
         this.MRTGA2.updateValueAndValidity();
         this.MRTGCT.updateValueAndValidity();
         this.MRTGST.updateValueAndValidity();
         this.MRTGZP.updateValueAndValidity();

         //we need to add in controls to ensure they are available PRIOR to the arrays starting to look for them, otherwise they are going to throw an error
         this.addInterestMrtgeeFormGroup.get("MRTGTPCOVERG").valueChanges.subscribe((value) => 
            this.onMRTGTPCOVERGValueChange(value)
        );
         this.cd.detectChanges();
    }

    onMRTGTPCOVERGValueChange(value: string) : void{
        
        if(value === "SI"){
            this.coverage = "IMP";            
            this.ScheduledItems = new ScheduledItemsFunctions(this.coverage,this.quote);            
            this.secondInit();
            this.setTypeOfControl();
            this.addControls(this.typeOfControl);
        }
        if(value === "UI"){
            this.coverage = "IMP";
            this.setTypeOfControl();
            //this.setTypeOfControl("UI");
            //this.addInterestMrtgeeFormGroup.addControl("MRTID", new FormControl(this.additionalInterestData.MRTGZP != NULL, this.migNamedInsuredValidator.ValidateRequired("Description")));
            this.secondInit();
        }
        if(value === "BPP"){
            this.coverage = "CFP";
            //this.typeOfControl = "CFP";
            //this.setTypeOfControl("LOC");
            this.setTypeOfControl();
            //commented out the following lines
            // this.ScheduledItems = new ScheduledItemsFunctions(this.coverage, this.quote)
            // this.secondInit();
            // this.addDescriptionControls(value);
            // this.addControls(this.typeOfControl);
        }

        if(value === "IC"){            
            this.coverage = "IMP";
            this.setTypeOfControl();
        }
        this.cd.detectChanges();
    }

    //this is for scheduled items...need to add the mortgage number to the checkbox
    //we actually need to create a NEW Scheduled Item with recordState 'N' and set the old scheduled item
    //to RECORDSTATE 'D'
    addMortgageNumber(item: any, e: Event) {

        let ind = _.findIndex(this.addedSchItems, x => x.ITEMNO === item.ITEMNO);
        let temp = new IMPSCHEDULEDITEM(this.quote.QUOTEPOLICYINFORMATION);
        let ctrQuote = this.quote as CTRQuote;

        temp = _.cloneDeep(item as IMPSCHEDULEDITEM);
        if(e && ind === -1) {
            //check the current index for the completed mortgages    
            this.addedSchItems.push(temp);
        } else {
            //remove the mortgage number from this item
            this.addedSchItems = this.addedSchItems.filter(x=> x.ITEMNO !== item.ITEMNO);
        }
        temp.RECORDSTATE = 'N';
        item.RECORDSTATE = 'D';
        ctrQuote.IMPENTITY.IMPSCHEDULEDITEMS.push(temp);
    }
    setTypeOfControl(typeOfControl?: string, mgCov?: string) : void {

        if(typeOfControl != null) {
            this.typeOfControl = typeOfControl;
            return;
        }

        if(this.MRTGTPCOVERG.value !== "UI") {
            this.MRTITD.setValidators(Validators.nullValidator);
            this.MRTITD.updateValueAndValidity();
        }
        if(this.MRTGTP.value === "M") {
            this.coverage = "CFP";
            this.typeOfControl = "LOC";
            return;
        }

        if(mgCov === 'BPP' || this.MRTGTPCOVERG.value === "BPP") {
            this.coverage = "CFP";
            this.typeOfControl = "LOC";
            this.ScheduledItems = new ScheduledItemsFunctions(this.coverage, this.quote)
            this.secondInit();
            //this.addDescriptionControls("BPP");
            this.addControls(this.typeOfControl);
            this.addDescriptionControls(_.isEmpty(this.MRTGTPCOVERG.value) ? mgCov : this.MRTGTPCOVERG.value);
            //this.getLocations(this.coverage).forEach(location=>this.addDescriptionLabelControl(location));
            return;
        }

        if( mgCov === 'IC' || this.MRTGTPCOVERG.value === "IC"){
            this.coverage = "IMP";
            this.secondInit();
            this.addDescriptionControls("IC");
        }

        if(mgCov === 'SI' || this.MRTGTPCOVERG.value === "SI"){
            this.coverage = "IMP";
            this.typeOfControl = "IMP";
            this.addControls(this.typeOfControl);
            this.MRTITD.setValidators(Validators.nullValidator);
            //this.MRTITD.updateValueAndValidity();
            return;
        }

        if(mgCov === 'UI'|| this.MRTGTPCOVERG.value === "UI"){
            this.coverage = "IMP";
            this.typeOfControl = "UI";
            this.MRTITD.setValidators(this.migNamedInsuredValidator.ValidateRequired('MRTITD', 'Item Description'));
            this.MRTITD.updateValueAndValidity();
            return;
        }

        //this.typeOfControl = this.MRTGTPCOVERG.value;
    }

    //addLocationsAndBuildingsControls(): void {
    addControls(typeControls: string): void {
        switch(typeControls) {
            case "LOC": {
                this.quote.GetLocations(this.coverage).forEach((element)=> {
                    this.addInterestMrtgeeFormGroup.addControl("LOCBLDG" + element.LOCNUM + element.BLDNUM, new UntypedFormControl(false));
                    //we also need to check to see if this should be checked or not based on if it has a building and location number associated with it

                });

                break;
            }
            case "IMP": {
                this.quote.GetScheduledItems(this.coverage).forEach((element)=> {
                    this.addInterestMrtgeeFormGroup.addControl("ITEM_D" + element.ITEMNO, new UntypedFormControl(false));
                });
                break;
            }
            default: {break;}
        }
    }
    
    addDescriptionControls(coverageType: string) {
        if(coverageType === "BPP") {
            this.quote.GetLocations(this.coverage).forEach((element) => {
                this.addInterestMrtgeeFormGroup.addControl("itemDescription"+ element.LOCNUM + element.BLDNUM, new UntypedFormArray([]));    
            })
        }
        if(coverageType === "IC"){
            this.addInterestMrtgeeFormGroup.addControl("installationCoverage", new UntypedFormArray([]));
            //document.getElementById("addICDescription").style.visibility = "visible";
            let test : UntypedFormArray;
            this.MRTGTPCOVERG.setValue("IC",{emitEvent: false});
            test = this.addInterestMrtgeeFormGroup.controls["installationCoverage"] as UntypedFormArray;            
            //if(test.length === 0){
                this.addDescriptionLabelControl(null,null,null);
            //}
        }
    }

    addDescriptionLabelControl(location: ILocation, locbldg? :string, value? :string){
        
        let itemDescription: UntypedFormArray;
        let descName: string;        
        let description: UntypedFormGroup;        
        let addDesc: boolean = false;
        description = this.formBuilder.group({});
        descName = "desc";


        if((location != null) && this.MRTGTPCOVERG.value === "BPP"){
            itemDescription = this.addInterestMrtgeeFormGroup.get("itemDescription" + location.LOCNUM + location.BLDNUM) as UntypedFormArray;
            //if itemDescription is null, need to add it
        }
        
        else if(locbldg != null){
            itemDescription = this.addInterestMrtgeeFormGroup.get("itemDescription" + locbldg.substr(0,3) + locbldg.substr(3,3)) as UntypedFormArray;
        }        

        if(location == null && locbldg == null && value == null && this.MRTGTPCOVERG.value === "IC"){
            itemDescription = this.addInterestMrtgeeFormGroup.get("installationCoverage")  as UntypedFormArray;
            
            descName = "icDescription";
            //we need to add installation coverage to the formGroup
            if(itemDescription == null) {
                this.addDescriptionControls("IC");
            }
            if(itemDescription.controls.length > 1) itemDescription.controls.splice(0,1);
        }       

        if(value == null) {
           if((this.MRTGTPCOVERG.value === 'BPP' && !this.initialBPP) || (!itemDescription.controls || !itemDescription.controls.length))  {
               description.addControl(descName, new UntypedFormControl());
               addDesc = true;
           }
        }
        else{
            description.addControl(descName, new UntypedFormControl(value, this.migNamedInsuredValidator.ValidateRequired(descName, 'Item Description')));
            addDesc = true;
        }

        if(itemDescription) {
            if(this.MRTGTPCOVERG.value === 'BPP' && this.initialBPP && itemDescription.controls.length) {
                //we need to make sure this is only a single item
                if(itemDescription.controls.length > 1) itemDescription.controls.splice(0,1);
                return;
            } 
            if(addDesc) itemDescription.push(description);
            
        }
    }

    deleteDescriptionLabelControl(location: ILocation, idx: number) {
        
        let itemDescription: UntypedFormArray;

        if(location != null){
            itemDescription = this.addInterestMrtgeeFormGroup.get("itemDescription" + location.LOCNUM + location.LOCNUM) as UntypedFormArray;
        }
        else if(this.MRTGTPCOVERG.value === "IC"){
            itemDescription = this.addInterestMrtgeeFormGroup.get("installationCoverage") as UntypedFormArray;
        }

        if(idx === -1){
            itemDescription.controls.splice(0, itemDescription.length);
        }
        else {
            itemDescription.removeAt(idx);
        }
    }

    addDescriptionButtonVisibility(location: ILocation, checkBoxValue: any) {
       
        if(document.getElementById("BTN" + location.LOCNUM + location.BLDNUM).style.visibility === "hidden") {
            document.getElementById("BTN" + location.LOCNUM + location.BLDNUM).style.visibility = "visible";
            if(checkBoxValue){
                this.addDescriptionLabelControl(location);
                this.showDesc = true;
                this.initialBPP = false;
            }
        } 
        else {
            document.getElementById("BTN" + location.LOCNUM + location.BLDNUM).style.visibility = "hidden";
            if(!checkBoxValue) {
                this.deleteDescriptionLabelControl(location, -1)
                this.showDesc = false;
            }
        }     
    }

    removeControls(typeControls: string): void {
        switch(typeControls) {
           case "LOC": {
                this.quote.GetLocations(this.coverage).forEach((element) => {
                    this.addInterestMrtgeeFormGroup.removeControl("LOCBLDG" + element.LOCNUM + element.BLDNUM);
                });
                break;
            }
            case "IMP": {
                this.quote.GetScheduledItems(this.coverage).forEach((element)=> {
                    this.addInterestMrtgeeFormGroup.removeControl("ITEM" + element.ITEMNO);
                });
                break;
            }
            default: {break;}
        }

        //always remove installation coverage control after saving
        //this.addInterestMrtgeeFormGroup.removeControl("installationCoverage");
    }

    getLocationCount(coverage: string): number {
        // let locationList: ILocation[];
        // locationList = this.quote.GetLocations(coverage);
        // return locationList.length;
        return this.quote.GetLocations(coverage).length;
    }

    getLocations(coverage: string) : ILocation[] {
        // let locationList: ILocation[];
        // locationList = this.quote.GetLocations(coverage);
        // return locationList;
        return this.quote.GetLocations(coverage);
    }

    filterLocations(coverage: string, loc: ILocation): ILocation[]{
        let locationList: ILocation[];
        locationList = this.quote.GetLocations(coverage);
        return locationList.filter(element=> element.LOCNUM === loc.LOCNUM);
    }

    //rrf
    filterMortgageeAdditionalInterest(mortgagee: IMortgagee): void {
        
        let list: string[];
        let cfpmtg: IMortgagee;

        list =  Array.from(new Set(this.quote.GetMortgagees(this.coverage).map((item: IMortgagee)=> {
        
            //This should not be set to element 0. If the same item gets saved, one will have a Record State 'D' and the other Record State 'N' 
            //and the record State D will be selected, which will cause it to not show up.
            if(cfpmtg == null) {
                cfpmtg = this.quote.GetMortgagees(this.coverage).filter ((element) => 
                    element.MRTGNM === mortgagee.MRTGNM &&
                    element.MRTGA1 === mortgagee.MRTGA1 &&
                    element.MRTGCT === mortgagee.MRTGCT &&
                    element.MRTGST === mortgagee.MRTGST &&
                    element.RECORDSTATE !== 'D'
                )[0];

                if(cfpmtg != null) {
                
                    let fgroup : UntypedFormGroup;
                    fgroup = this.formBuilder.group(cfpmtg);
                    
                    if(this.MRTGTPCOVERG.value === "BPP" || this.MRTGTPCOVERG.value === "IC") {

                        let formArrayName: string;
                        let controlName: string;

                        if(this.MRTGTPCOVERG.value === "BPP") {
                            formArrayName = "itemDescription";
                            controlName = "desc";
                        }

                        if(this.MRTGTPCOVERG.value === "IC") {
                            formArrayName = "installationCoverage";
                            controlName = "icDescription";
                        }
                    
                        Object.keys(this.addInterestMrtgeeFormGroup.controls).filter(key=>key.startsWith(formArrayName))
                        .forEach(key => {                                
                            let control : AbstractControl;
                            control = this.addInterestMrtgeeFormGroup.controls[key] as UntypedFormArray;
                            fgroup.removeControl(key);
                            fgroup.addControl(key, new UntypedFormArray([]));
                            for(let i=0; i < (<UntypedFormArray>control).length; i++) {                                    
                                let description: UntypedFormGroup;
                                description = this.formBuilder.group({});
                                description.addControl(controlName, new UntypedFormControl(control.value[i][controlName]));
                                (<UntypedFormArray>fgroup.get(key)).push(description);
                                
                            }
                        });
                    }
                    this.completedAdditionalInterestMortgagees.push(fgroup);
                }
            }
            this.cd.detectChanges();
            return item.MRTGNM + " " + item.MRTGA1 + " " + item.MRTGCT + " " + item.MRTGST;
        })));        
    }

    getMortgageeCount(coverage: string) : number {
        if(coverage === 'CFP' || coverage === 'IMP') {
            return this.quote.GetMortgagees(coverage).length;
        }
    }
    
    checkForErrors(){
        let form = this.addInterestMrtgeeFormGroup.controls;
        if(!(form.MRTGTP.valid && form.MRTGTPCOVERG.valid && form.MRTGNM.valid && form.MRTGA1.valid && form.MRTGA2.valid && form.MRTGCT.valid && form.MRTGST.valid && form.MRTGZP.valid ) ){
            //this.errorService.emitErrorsEvent(this.addInterestMrtgeeFormGroup)
            
            let errors = this.menuClass.CalculateErrorsFormGroup(this.addInterestMrtgeeFormGroup);
            this.migsystemservice.notifyDoneClicked(errors);
        }
        else{
            this.migsystemservice.notifyToastMessagesCleared();
            this.saveClicked=false; 
        }
    }

    saveMortgageeAdditionalInterest(coverageType: string) {
        this.saveClicked=true;
        this.checkForErrors();
        //let form = this.addInterestMrtgeeFormGroup.controls;
        //if(this.addInterestMrtgeeFormGroup.invalid){
            //this.migsystemservice.notifyDoneClicked();
            //this.menuClass.CalculateErrorsFormGroup(this.addInterestMrtgeeFormGroup);
            //this.errorService.emitErrorsEvent(this.addInterestMrtgeeFormGroup)
            //return false; 
        //}      
        //this.saveClicked=false; 

        if((this.MRTGTP.value === "M" && !(this.MRTGTP.valid && this.MRTGNM.valid && this.MRTGA1.valid && this.MRTGA2.valid && this.MRTGCT.valid && this.MRTGST.valid && this.MRTGZP.valid))
            || (this.MRTGTP.value !== "M" && !(this.MRTGTP.valid && this.MRTGTPCOVERG.valid && this.MRTGNM.valid && this.MRTGA1.valid && this.MRTGA2.valid && this.MRTGCT.valid && this.MRTGST.valid && this.MRTGZP.valid)))            
        {            
            return false;
        }

        //get the IMortgagee instance
        let cfpMortgagee = this.calcMortgageNumber();
        //need to check to see if any scheduled items are list
        this.addedSchItems.forEach(item => {
            if(item.RECORDSTATE !== 'D')item.MRTGNO = cfpMortgagee.MRTGNO;
        });
        //reset the array to empty
        this.addedSchItems = [];

        //this.saveClicked=false; 
        //let mortgageeAdditionalInterestList : IMortgagee[] = [];
        //let mortNumber: string;
       
        //this.setTypeOfControl();
        //this.quote.SaveMortgagee(this.coverage, mortgageeAdditionalInterestList as IMortgagee[], coverageType); 
     
        this.quote.SaveMortgagee(this.coverage,  Object.assign({}, cfpMortgagee), coverageType);
               
        //this.deleteDuplicates(cfpMortgagees, mortgagee.MRTGNO)    

        this.filterMortgageeAdditionalInterest(this.addInterestMrtgeeFormGroup.value as IMortgagee);
        this.showAddInterestMrtgeeFormGroup = false;
        this.removeControls(this.typeOfControl);
        this.addInterestMrtgeeFormGroup.reset();
        this.showDesc = false;
        //this.saveClicked=true;
        this.cd.detectChanges();
    }
    deleteDuplicates(cfpMortgagees: any[], mortgNo: string) {
        //need to delete a duplicate mortgagee or we run into issues
        let deleteDup = cfpMortgagees.filter(key => key.MRTGNO === mortgNo)
        if(deleteDup.length > 1) {
            deleteDup.forEach(item => {
                if(item.RECORDSTATE === 'D') {
                    let index = cfpMortgagees.indexOf(item);
                    cfpMortgagees.splice(index,1);
                }
            })
        }
    }

    calcMortgageNumber() : IMortgagee {

        let mortgageeAdditionalInterestList : IMortgagee[] = [];
        let mortNumber: string;

        let mortlist: IMortgagee[] = this.quote.GetMortgagees(this.coverage).filter(element=>
            element.MRTGNM === this.MRTGNM.value &&
            element.MRTGA1 === this.MRTGA1.value &&
            element.MRTGCT === this.MRTGCT.value &&
            element.MRTGST === this.MRTGST.value &&
            element.MRTGZP === this.MRTGZP.value
        );

        if(this.quote.GetMortgagees(this.coverage).length === 0) {
            mortNumber = "001";
        }
        if(mortlist.length > 0) {
            mortNumber = mortlist[0].MRTGNO;
        }

        if(this.quote.GetMortgagees(this.coverage).length > 0 && mortlist.length === 0) {
            
            let unique = Array.from(new Set(this.quote.GetMortgagees(this.coverage).map((item:any)=> item.MRTGNO))).sort().reverse();

            let mtgNumber = Number(unique[0]) + 1;
        
            if(mtgNumber == 999){
                throw Error("Error in adding mortgagee.");
            }
            if(mtgNumber.toString().length === 1) {
                mortNumber = "00" + mtgNumber.toString();
            }
            if(mtgNumber.toString().length === 2) {
                mortNumber = "0" + mtgNumber.toString();
            }
            if(mtgNumber.toString().length === 3) {
                mortNumber = mtgNumber.toString();
            }                
        }

        Object.keys(this.addInterestMrtgeeFormGroup.controls).filter(key=>key.startsWith("LOCBLDG") || key.startsWith("ITEM_D"))
            .forEach(key => {
            let current = Object.assign({},this.addInterestMrtgeeFormGroup.value);
            current.MRTGNO = mortNumber.toString();
            if (this.addInterestMrtgeeFormGroup.get(key).value) {
                
                if(key.startsWith("LOCBLDG")) {
                    current.LOCNUM = key.substr(7,3);
                    current.BLDNUM = key.substr(10,3);
                    mortgageeAdditionalInterestList.push(current);
                }
            }
            
        });

        if (mortgageeAdditionalInterestList.length === 0) {

            //this.addInterestMrtgeeFormGroup.addControl("MRTGNO", new FormControl(mortNumber));
            let current = Object.assign({}, this.addInterestMrtgeeFormGroup.value);
            current.MRTGNO = mortNumber.toString();
            //mortgageeAdditionalInterestList.push(this.addInterestMrtgeeFormGroup.value);
            mortgageeAdditionalInterestList.push(current);
        }
        this.cd.detectChanges();
        return mortgageeAdditionalInterestList[0];
    }

    editMortgageeAdditionalInterestByIndex(mortgagee: IMortgagee, formGroupIndex: number, coverageType: string) {
        this.setTypeOfControl(null, coverageType);
        //this.addInterestMrtgeeFormGroup = this.formBuilder.group(mortgagee);
        //if(this.addInterestMrtgeeFormGroup.)
        for (let control in this.addInterestMrtgeeFormGroup.controls){
           
            //BPP
            if(control.startsWith('itemDescription')) {
                
                //we need to load the Scheduled Items into the Array
                if(coverageType === 'BPP') {
                    let ctrQuote: CTRQuote = this.quote as CTRQuote;
                    let tempFA: UntypedFormArray;
                    let descName: string = ''
                    ctrQuote.CFPENTITY.CFPSCHEDULEDITEMS.forEach((item, index) => {
                        if(item.MRTGNO === mortgagee.MRTGNO && item.LOCNUM === mortgagee.LOCNUM && item.BLDNUM === mortgagee.BLDNUM) {
                            //we need to push this item into the control array
                            tempFA = this.addInterestMrtgeeFormGroup.get('itemDescription' + item.LOCNUM + item.BLDNUM) as UntypedFormArray;
                            descName = 'itemDescription' + item.LOCNUM + item.BLDNUM;
                            tempFA.push(this.formBuilder.group({desc: item.SCHITM }));
                        }
                    });
                    //this.addInterestMrtgeeFormGroup.removeControl(control);
                    if(tempFA && tempFA.length)  {
                        //this.addInterestMrtgeeFormGroup.addControl(control, tempFA);
                        this.completedAdditionalInterestMortgagees[formGroupIndex].addControl(control, this.addInterestMrtgeeFormGroup.controls[control]);
                    }
                }
            }
            //installation coverage
            if(control.startsWith('installationCoverage')) {
               
                if(coverageType === 'IC') {
                //we need to clone the installation coverage object and rename the controls to lower case for use in addInterestMrtgeeFormGroup
                    this.addInterestMrtgeeFormGroup = _.cloneDeep(this.completedAdditionalInterestMortgagees[formGroupIndex]);
                    
                    let tempFA: UntypedFormArray = this.formBuilder.array([]);
                    //loop through the items in the installationCoverage array and add them to the FormArray
                    this.completedAdditionalInterestMortgagees[formGroupIndex].controls[control]['controls'].forEach(item => {
                        //check to see if there is an INSTALLATIONCOVERAGE control on here and if there is, we need to get the value from it
                        if(this.completedAdditionalInterestMortgagees[formGroupIndex].controls['INSTALLATIONCOVERAGE']) {
                            this.completedAdditionalInterestMortgagees[formGroupIndex].controls[control]['controls'].forEach(item2 => {
                                tempFA.push(this.formBuilder.group({icDescription: item2.value.icDescription}))
                            })
                        } else {
                            tempFA.push(this.formBuilder.group({icDescription: item.value.ICDESCRIPTION}));
                        }
                    });

                    this.completedAdditionalInterestMortgagees[formGroupIndex].removeControl('installationCoverage');
                    //add the formArray to the FormGroup
                    this.completedAdditionalInterestMortgagees[formGroupIndex].addControl(control, tempFA);
                }
            }
            //this is a scheduled item -- we need to check the IMPSCHEDULEDTRANS
            if(control.startsWith('ITEM_D')) {
                
                if(coverageType === 'SI') {
                    //this.addInterestMrtgeeFormGroup = _.cloneDeep(this.completedAdditionalInterestMortgagees[formGroupIndex]);
                    let ctrQuote: CTRQuote = this.quote as CTRQuote
                    ctrQuote.IMPENTITY.IMPSCHEDULEDITEMS.forEach(item => {
                        if(item.ITEMNO === control.substr(6,4)) {
                            //add the control if it doesn't exist
                            if(!this.completedAdditionalInterestMortgagees[formGroupIndex].controls[control]) {
                                this.completedAdditionalInterestMortgagees[formGroupIndex].addControl(control, this.addInterestMrtgeeFormGroup.controls[control]);
                            }
                            if(mortgagee.MRTGNO === item.MRTGNO) {                                
                                this.completedAdditionalInterestMortgagees[formGroupIndex].controls[control].setValue(true);                                
                            }else {
                                this.completedAdditionalInterestMortgagees[formGroupIndex].controls[control].setValue(false);                            
                            }
                        }
                    });
                    //this.completedAdditionalInterestMortgagees[formGroupIndex] = _.cloneDeep(this.addInterestMrtgeeFormGroup);
                }
            }
        }
        this.addInterestMrtgeeFormGroup = _.cloneDeep(this.completedAdditionalInterestMortgagees[formGroupIndex]);
        this.showDesc = true;
        this.showAddInterestMrtgeeFormGroup = true;
        // this.setTypeOfControl();
        // if(coverageType == "BPP"){
        //     Object.keys(mortgagee).filter(key=>key.startsWith("itemDescription"))
        //     .forEach(key => {
        //         let location : string;
        //         location = key.substr(15,6);
        //         for(let i=0; i<mortgagee[key].length; i++){
        //             this.addDescriptionLabelControl(null,location,mortgagee[key][i]["desc"])
        //         }
        //     });
        // }
       
        //rrf to delete
        this.deleteMortgageeAdditionalInterestByIndex(mortgagee,formGroupIndex, coverageType);        
    }

    getLocationValue(item, e) {
        let control = 'LOCBLDG' + item.LOCNUM + item.BLDNUM
        if(!this.addInterestMrtgeeFormGroup.get('LOCBLDG' + item.LOCNUM + item.BLDNUM)) {
            this.addInterestMrtgeeFormGroup.addControl('LOCBLDG' + item.LOCNUM + item.BLDNUM, new UntypedFormControl(e));
        }
        this.checkOnlyOne(item, e);
        if(e && this.addInterestMrtgeeFormGroup.get('LOCBLDG' + item.LOCNUM + item.BLDNUM)) this.addInterestMrtgeeFormGroup.controls[control].setValue(e);
    }

    //we are going to make sure there is only one item able to be checked on Mortgagees
    checkOnlyOne(item, e) {
        if(e) {
            Object.keys(this.addInterestMrtgeeFormGroup.controls).filter(key => key.startsWith('LOCBLDG')).forEach(control => {
                //if it not the current control then uncheck it.
                if(control !== 'LOCBLDG' + item.LOCNUM + item.BLDNUM) this.addInterestMrtgeeFormGroup.controls[control].setValue(false);
            })
        }
    }
    onTabOpen(e: any) {
        if (e.index >= 0) {
            this.editMortgageeAdditionalInterestByIndex(this.completedAdditionalInterestMortgagees[e.index].value,
                e.index, this.completedAdditionalInterestMortgagees[e.index].value['MRTGTPCOVERG'] || '');
        }
    }

    deleteMortgageeAdditionalInterestByIndex(mortgagee: IMortgagee, formGroupIndex: number, coverageType: string) {
        
       
        this.completedAdditionalInterestMortgagees.splice(formGroupIndex,1);

        this.editMortgageeAdditionalInterestIndex = [];

        //cannot just use the coverage value blindly here - it remains set to whatever the last item is in the array it loops through, 
        //need to determine what coverage to use based on the mortgage type
        //if the coverageType is blank, it needs to be set to CFP because it is a mortgagee
        //but why is the coverageType blank for Mortgagee??

        if(coverageType === '' || coverageType === 'BPP') this.coverage = 'CFP';

        //Is this really needed since we are passing in the mortgagee already and it is a reference?
        //Shouldn't we just be able to set the RECORDSTATE to 'D'??

        //this.quote.GetMortgagees(this.coverage).filter(x=>x.RECORDSTATE != 'D').forEach((element, index) => {
        this.quote.GetMortgagees(this.coverage).forEach((element, index) => {
        
            if(
                element.MRTGNM === mortgagee.MRTGNM &&
                element.MRTGA1 === mortgagee.MRTGA1 &&
                element.MRTGCT === mortgagee.MRTGCT &&
                element.MRTGST === mortgagee.MRTGST && 
                element.MRTGZP === mortgagee.MRTGZP &&
                element.MRTGTP === mortgagee.MRTGTP 
            ) {
                this.editMortgageeAdditionalInterestIndex.push(index);
            }
        });

        if(this.editMortgageeAdditionalInterestIndex != null) {
            this.editMortgageeAdditionalInterestIndex.reverse().forEach(value => {
                this.quote.DeleteMortgagee(this.coverage, value, coverageType);
                //remove the mortgage number from the scheduled items if it is this one
                //this.ScheduledItems.remScheduledItems(this.coverage, this.addInterestMrtgeeFormGroup[value].get('MRTGNO'), this.ScheduledItems.getScheduledItems(this.coverage));

                //remove the Installation coverage Items

                //remove the BPP Descriptions
            });
            this.editMortgageeAdditionalInterestIndex = undefined;
        }
        this.cd.detectChanges();
    }

	btnShowAdd() {
        this.mortgageeAdditionalInterest = null;
        this.showAddInterestMrtgeeFormGroup = true;
        this.initialBPP =true;
        this.addInterestMrtgeeFormGroup.reset();
    }

    //need to close the panel and switch back to accordion mode
    btnCancelAdd() {
        this.showAddInterestMrtgeeFormGroup = false;
    }
    
    filterHeaderType(type: string) :string {
        return this.ddListMRTGTP.filter( value=> value == type)[0];
    } 

    addAnother(itemLocitemBldg: string){   
        const control = <UntypedFormArray>this.addInterestMrtgeeFormGroup.controls['itemDescription' + itemLocitemBldg];
        let newDesc : UntypedFormGroup;
        newDesc = this.formBuilder.group({});    
        newDesc.addControl((control.length + 1).toString(),new UntypedFormControl('desc'));
        control.push(newDesc);
        alert(event);
    }
}
