export class AppErrors {
	severity: string;
	summary: string;
	detail: string;
	sticky: boolean;
	closable: false; 
}
