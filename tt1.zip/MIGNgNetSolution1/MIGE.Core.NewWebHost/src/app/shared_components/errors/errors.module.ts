import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ErrorComponent } from './errors.component';
import { MIGMessages } from '@overridden/primeng-messages/messages';
import { PanelModule } from 'primeng/panel';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';

@NgModule({
	imports: [
        CommonModule,
        PanelModule,
        ToastModule
	],
    declarations: [ErrorComponent, MIGMessages],
    exports: [ErrorComponent],
    providers: [MessageService],
})
export class ErrorModule { }
