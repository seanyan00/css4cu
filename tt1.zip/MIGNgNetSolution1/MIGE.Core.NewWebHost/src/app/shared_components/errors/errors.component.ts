import { Component, Input, OnDestroy, OnInit, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { MessageService } from 'primeng/api';
import { MIGSystemService } from '@root/services/mig.service';
import { Subscription} from 'rxjs';
import * as _ from 'lodash';
import * as $ from 'jquery';

@Component({
    selector: 'mig-errors',
    templateUrl: './errors.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})
    
export class ErrorComponent implements OnDestroy, OnInit {
    @Input() errors;

    displayToastMessages: boolean;
    messages: any = [];
    nextBtnClicked: boolean = false;
    doneBtnClicked: boolean = false;
    validateForm: boolean = false;
    //added Subscriptions so we can unsubscribe to prevent memory leaks +
    //TODO: should change these to async pipes so subscribing and unsubscribing is not needed
    toastAddSub: Subscription;
    toastClearSub: Subscription;
    notifyErrorSub: Subscription;
    notifyBRRErrorSub: Subscription;
    validateFormSub : Subscription;
    XClickSub: Subscription;
    nextClickSub: Subscription;
    backClickSub: Subscription;
    doneClickSub: Subscription;
    combineErrorSub: Subscription;
    
    notifyError: boolean;
    brErrors: any[];
    constructor(
        public messageService: MessageService,
        public migsystemservice: MIGSystemService,
        public cd: ChangeDetectorRef,
    ){

}

ngOnInit() {

      //get any error messages coming from the menu component
   this.notifyErrorSub = this.migsystemservice.subscribeNotifyError().subscribe(errors => {
        let cleanedErrors 
        //we only show validation if the Validation checkbox is selected
        if(this.validateForm) {
            //clear out any old messages:
            this.messageService.clear();
            if(errors != null){ //9/22/21: added nullcheck -JTL
                //we are only displaying the error panel when the next/done button has been clicked and there are actually errors  
                if((errors.length || this.brErrors) && (this.nextBtnClicked || this.doneBtnClicked)){
                    //add the errors in next
                    cleanedErrors = this.cleanErrors(this.brErrors ? errors.concat(this.brErrors): errors);
                    
                    _.valuesIn(cleanedErrors).forEach((error) => {
                        this.messageService.add(error);
                    });
                
                    
                    this.migsystemservice.notifyToastMessagesAdded(this.nextBtnClicked || this.doneBtnClicked);
                    this.displayToastMessages = true;
                    this.cd.detectChanges();
                    //used to determine what service it came from to display proper messages
                    this.notifyError = true;
                    

                }

                //There are either no errors or we are not wanting to display the errors
                else {
                        this.migsystemservice.notifyToastMessagesCleared();
                        this.displayToastMessages = false;
                        this.cd.detectChanges();
                        this.notifyError = false;
                        this.closeErrors();
                    }
            }
        }
    
    });


    this.nextClickSub = this.migsystemservice.subscribeNextClicked().subscribe(errors => {
        this.nextBtnClicked = true;
        this.migsystemservice.notifyError(errors);
    });

    this.backClickSub = this.migsystemservice.subscribeBackClicked().subscribe(() => {
        this.nextBtnClicked = false;
    });

    this.doneClickSub = this.migsystemservice.subscribeDoneClicked().subscribe(errors => {
        if(errors && errors.length)
        {
            this.doneBtnClicked = true;
        }
        this.migsystemservice.notifyError(errors);
    });

    this.XClickSub = this.migsystemservice.subscribeXClicked().subscribe(() => {
        this.nextBtnClicked = false;
        this.doneBtnClicked = false;
    });

    //controls whether we do validation or not on the form
    this.validateFormSub = this.migsystemservice.subscribeValidateForm().subscribe(validateForm => {
        this.validateForm = validateForm;
    });

    this.notifyBRRErrorSub = this.migsystemservice.subscribeNotifyBRRError().subscribe(BRErrors => {
        this.brErrors = BRErrors;
        this.migsystemservice.notifyError(this.brErrors);
    });    
    
    this.toastAddSub = this.migsystemservice.subscribeToastMessagesAdded().subscribe(shouldDisplay => {
        if(shouldDisplay) {
            //turns on the error panel	
            if(!this.displayToastMessages){
                this.displayToastMessages = true;
                this.cd.detectChanges();
            }	         
        }else {
            //we don't want to display the errors
            this.migsystemservice.notifyToastMessagesCleared();
        }
    });

    this.toastClearSub = this.migsystemservice.subscribeToastMessagesCleared().subscribe(() => {
        if(this.displayToastMessages){
            if(this.messages.length){
                if($('label[for="' + this.messages.slice(-2)[0] + '"]').length) {
                    $('label[for="' + this.messages.slice(-2)[0]+'"]')[0].style.backgroundColor="white";
                    $('label[for="' + this.messages.slice(-2)[0]+'"]')[0].style.fontWeight="normal";
                }else {
                    document.getElementById(this.messages.slice(-2)[0]).style.fontWeight="normal";
                    document.getElementById(this.messages.slice(-2)[0]).style.backgroundColor="white";
                }
            }
            this.displayToastMessages = false;
            
        }
        this.messages=[];
        this.messageService.clear();
        this.cd.detectChanges();
        this.closeErrors();
    });
    

}

  
    cleanErrors(errors: []): any [] {
        //we need to clean up the errors and put them all in the same format, as they are in different formats at times.
        let newErrors = [];
        _.valuesIn(errors).forEach((error: any, index: number) => {
            //check to see if this is a nested object
            if(error.severity) {
                newErrors.push(error);
                
            }else {
                //gives us the object object, need to pull out the values from the nested object
                _.valuesIn(error).forEach((unzipped, index2)=> {
                    
                    unzipped.summary = Object.keys(error)[index2]; //update the summary message so it displays properly
                    unzipped.sticky = true; //ensure it stays and doesn't disappear
                    unzipped.closable = false;
                    newErrors.push(unzipped);
                
                });
            }
        }); 
        newErrors = _.sortedUniqBy(newErrors, 'summary')
        return _.uniqBy(newErrors, 'detail');
    } 
    //Unsubscribe from the subscriptions to prevent memory leaks
    ngOnDestroy() {
        if(this.toastClearSub) this.toastClearSub.unsubscribe();
        if(this.toastAddSub) this.toastAddSub.unsubscribe();
        if(this.notifyErrorSub) this.notifyErrorSub.unsubscribe();
        if(this.notifyBRRErrorSub) this.notifyBRRErrorSub.unsubscribe();
        if(this.XClickSub) this.XClickSub.unsubscribe();
        if(this.doneClickSub) this.doneClickSub.unsubscribe();
        if(this.nextClickSub) this.nextClickSub.unsubscribe();
        if(this.backClickSub) this.backClickSub.unsubscribe();
        this.cd.detach();
    }

    //method is called when user clicks on an error message
    goToError(fieldName:string){ 
        this.notifyError = true;
        if(this.displayToastMessages){   
            if(document.getElementById(fieldName) || $('label[for="' + fieldName + '"]').length){ //if the id exists on the form
                this.messages.push(fieldName);
                if(this.messages.length > 1){
                    // this is necessary to "unhighlight" the old error after navigating to a new one

                    if(this.notifyError) { // if there are still errors
                        if($('label[for="' + fieldName + '"]').length) {
                            $('label[for="' + this.messages.slice(-2)[0]+'"]')[0].style.backgroundColor="white";
                            $('label[for="' + this.messages.slice(-2)[0]+'"]')[0].style.fontWeight="normal";
                        }else {
                            document.getElementById(this.messages.slice(-2)[0]).style.fontWeight="normal";
                            document.getElementById(this.messages.slice(-2)[0]).style.backgroundColor="white";
                        }
                    }else {                
                        document.getElementById(this.messages.slice(-2)[0]).style.fontWeight="normal";
                        document.getElementById(this.messages.slice(-2)[0]).style.backgroundColor="white";
                }
                }
                //only checks for unique messages not duoplicates
                if(_.uniq(this.messages).length>2){ 
                    //Causes the messages array to only contain the message just clicked and the previous message
                    this.messages.shift()
                }
                if(this.notifyError) {
                    //console.log($('label[for="'+ fieldName+'"]')[0])
                    if($('label[for="' + fieldName + '"]').length) {
                        $('label[for="' + fieldName + '"]')[0].scrollIntoView({behavior: 'smooth', block: 'center'});
                        $('label[for="' + fieldName + '"]')[0].style.backgroundColor="lightcoral";
                        $('label[for="' + fieldName + '"]')[0].style.fontWeight="bold";

                    }else {
                        document.getElementById(fieldName).scrollIntoView({behavior:"smooth",block:"center"});
                        document.getElementById(fieldName).style.backgroundColor="lightcoral";
                        document.getElementById(fieldName).style.fontWeight="bold";
                    }
                }
                else {
                    document.getElementById(fieldName).scrollIntoView({behavior:"smooth",block:"center"});
                    document.getElementById(fieldName).style.backgroundColor="lightcoral";
                    document.getElementById(fieldName).style.fontWeight="bold";
                }
                return fieldName;
            }
        }
        else{
        //console.log(this.messages)
        document.getElementById(fieldName).style.fontWeight="normal";
        document.getElementById(fieldName).style.backgroundColor="white";
        }
	}

    closeErrors(){ //method is called when user clicks on the "x" to close the error panel. 
        if(this.messages.length > 0){
            if(this.notifyError) {
            $('label[for="' + this.messages.slice(-1)[0] + '"]')[0].style.backgroundColor="white";
            $('label[for="' + this.messages.slice(-1)[0] + '"]')[0].style.fontWeight="normal";
            }else {
                document.getElementById(this.messages.slice(-1)[0]).style.fontWeight="normal";
                document.getElementById(this.messages.slice(-1)[0]).style.backgroundColor="white";
            }

        }
        this.messageService.clear();
        this.migsystemservice.notifyXClicked(); //this is necessary otherwise when the user closes the error panel, it will reappear when user updates form
    }

}
