import {
	AfterViewInit,
  	Component,  
	ElementRef,
	HostListener,
	OnDestroy,
	ViewChild,
	ViewEncapsulation,
	Inject,
	ChangeDetectorRef,
	ChangeDetectionStrategy,
} from '@angular/core';

import { PrimeNGConfig } from 'primeng/api';

import { DOCUMENT } from "@angular/common";
import { MIGSystemService } from '@services/mig.service';
import { TooltipService } from '@services/tooltip.service';
import { AuthService } from '@auth/auth.service';
import { QuoteService } from '@services/quote.service';
import { TokenResponse } from '@auth/tokenresponse.class';
import { MenuClass } from '@system/menu/menu';
import { CookieService } from 'ngx-cookie-service';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
import { finalize } from 'rxjs/operators';
//import { HttpRequest } from '@angular/common/http';

enum MenuOrientation {
	STATIC,
	OVERLAY,
	SLIM,
	HORIZONTAL
}


@Component({
	selector: 'mig-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.css'],
	encapsulation: ViewEncapsulation.None,
	changeDetection: ChangeDetectionStrategy.OnPush
})

export class AppComponent {
	title = 'MIG-Angular11';
	firstName :string;
	lastName :string;
	//router: Router;
  	e: ElementRef;
	showMobileMenu: boolean = false;
	showRightMenu: boolean = true;
	showAttachments: boolean = false;

	layoutMode: MenuOrientation = MenuOrientation.STATIC;
	staticMenuDesktopInactive: boolean = false;;
	staticMenuMobileActive: boolean;
	layoutMenuScroller: HTMLDivElement;
	resetMenu: boolean;
	menuHoverActive: boolean;
	num: number = 0;
	scl: string = "xl";
	center_wrapper_height: string = "";
	subStep: string = "";
	toggleMenuSubscription : Subscription;
	toggleRHSSubscription: Subscription;
	scrollSubscription: Subscription;
	disabledMenu: boolean = false;
	@ViewChild('layoutMenuScroller', { static: false }) layoutMenuScrollerViewChild: ElementRef;

	quote: any;
	LOBTitle: string = '';
	token: TokenResponse;
  
	constructor(private primengConfig: PrimeNGConfig,
			private cd: ChangeDetectorRef,
			public migsystemservice: MIGSystemService,
			private authService: AuthService,
			private quoteService: QuoteService,
			public menuClass: MenuClass,
			private cookieService: CookieService,
			private tooltipService: TooltipService,
			public router: Router,
			@Inject(DOCUMENT) public document: Document)
	{
		
		// this.LOB = this.authService.getAuth().QuoteId.substring(0,3);
	}

		
	ngOnInit() :void
	{
		//specify the LOB in order to test with different routes. 
		this.authService.getLOB(); // returns the LOB we will use to route. 
		//this.authService.LOB = "WCA" // use for testing to switch to a LOB. Comment out for deployments.
		if(this.authService.LOB == "CTR"){
			this.router.navigate(['./quotes/contractors']);
			this.document.title = "MIG Contractors";
			this.LOBTitle = "Contractors"
		}
		else if(this.authService.LOB == "WCA"){
			this.router.navigate(['./quotes/workerscomp']);
			this.document.title = "MIG Workers Comp";
			this.LOBTitle = "Worker's Comp"
		}
		else if(this.authService.LOB == "BOP"){
			this.router.navigate(['./quotes/business-owners'])
			this.document.title = "MIG Businessowners";
			this.LOBTitle = "Businessowners"
		} 
		this.primengConfig.ripple = true;
		//
		
		this.migsystemservice.notifySystemNotification({ severity: 'info', summary: this.LOBTitle, detail: this.authService.getAuth().TransType=="PI" ? "Loading Policy Information" : "Loading Quote Information", event: "start" })
		this.funcScale();
		this.toggleMenuSubscription= this.migsystemservice.subscribeToggleMenu().subscribe(toggle => {
			this.showMobileMenu = !this.showMobileMenu;
			this.showMobileMenu ? this.cookieService.set("mobile", "true") : this.cookieService.set("mobile", "false");
			if(this.authService.retryPremium > 0){ // When retrying premium we need to call funcScale again so that the menu comes back instead of resizing the page -ZJG
				this.funcScale();
				this.cd.detectChanges();
			}
		});

		this.toggleRHSSubscription = this.migsystemservice.subscribeToggleRHS().subscribe(toggle => {
			this.showRightMenu = !this.showRightMenu;
		});		

		this.scrollSubscription = this.menuClass.subscribeScrollTo().subscribe(data => {
			this.scrollTo(data);
		});
		this.migsystemservice.subscribeDisableMenu().pipe(finalize(()=> this.funcScale())).subscribe(disable=> {
			this.disabledMenu = disable;
			this.showMobileMenu = disable;
			this.funcScale();
			this.cd.detectChanges()
		})
	} 

	ngAfterViewInit() {
		this.funcScale();
		if (this.cookieService.get("rhs")) {
			this.showMobileMenu = (this.cookieService.get("mobile") == "true" ? true: false);
		}
		this.cd.detectChanges();
	}



	@HostListener('window:resize', ['$event']) onResize(event) {
		if (event) {
			this.funcScale();
		}
	}



	scrollTo(fld) {
		setTimeout(() => {
			let elem = document.getElementById(fld);
			if (elem) {
				elem.scrollIntoView(false);
			}
		}, 500);


	}
	funcScale() {
		this.num = window.innerWidth;
		let bars = 90;

		this.center_wrapper_height = (window.innerHeight - bars) + "px";
		if (this.num < 641) {
			this.scl = "sm";
		}
		if (this.num > 640) {
			this.scl = "md";
			// this.migsystemservice.notifyToggleMenu();
			// this.migsystemservice.notifyToggleRHS();
		}
		if (this.num > 1024) {
			this.scl = "lg";
			this.staticMenuDesktopInactive = false;
			// this.migsystemservice.notifyToggleMenu();
			// this.migsystemservice.notifyToggleRHS();
		}
		if (this.num > 1024) {

		}

		if (this.num > 1440) {
			this.scl = "xl";
			this.staticMenuDesktopInactive = false;
		}
		if ((this.scl == "md") || this.scl == "sm") {
			this.staticMenuDesktopInactive = true;
		}
		let dummy = this.isMobile();
	}

	isMobile() {
		let isMobile = window.innerWidth <= 1024;
		if (isMobile) {
			this.showMobileMenu = true;
			this.showRightMenu = true;
		}
		this.migsystemservice.notifyIsMobile(isMobile);
		this.showRightMenu = isMobile;
		this.showMobileMenu = isMobile;
		return isMobile;
	}

	isOverlay() { return this.layoutMode === MenuOrientation.OVERLAY; }
	isHorizontal() { return this.layoutMode === MenuOrientation.HORIZONTAL; }
	isSlim() { return this.layoutMode === MenuOrientation.SLIM; }
	ngOnDestroy() {
		// jQuery(this.layoutMenuScroller).nanoScroller({ flash: true });
		if(this.toggleMenuSubscription) this.toggleMenuSubscription.unsubscribe();
		if(this.toggleRHSSubscription) this.toggleRHSSubscription.unsubscribe();
		if(this.scrollSubscription) this.scrollSubscription.unsubscribe();
		this.cd.detach();
	}

	toUpper() :void
	{
	  (this.firstName) ?  this.firstName= this.firstName.toUpperCase() : this.firstName;
	  (this.lastName) ?  this.lastName= this.lastName.toUpperCase() : this.lastName;   
	}
}
