// import { Routes, RouterModule, NoPreloading } from '@angular/router';
// import { ModuleWithProviders } from '@angular/core';

// import { ContractorsComponent } from '@root/mig/quotes/contractors/contractors.component';

// import { DashboardComponent } from '@root/mig/dashboard/dashboard.component';
// import { RiskAppetiteGuideComponent } from '@shared/risk-appetite-guide/risk-appetite-guide.component';
// import { PublicErrorDisplayComponent } from '@shared/public_error_display/public_error_display.component';

// //security
// import { AuthGuard } from '@auth/auth.guard';
// import { AppComponent } from './system/app/app.component';
// import { WorkersCompComponent } from '@mig/quotes/workers-comp/workers-comp.component';
// import { EmployersLiabilityLimits } from '@mig/quotes/workers-comp/components/employers-liability-limits/employers-liability-limits.component';

// //will have to manipulate the paths in order to implement WCA quotes
// export const routes: Routes = [
//     //{ path: '', canLoad:[AuthGuard], component: ContractorsComponent},
//     // { path: '', canActivate:[AuthGuard], component: ContractorsComponent},
//     { path: '', canActivate:[AuthGuard], component: WorkersCompComponent},

//     //{path: '', component: AppComponent},
//     //{ path: '', loadChildren: '@root/mig/quotes/contractors/contractors.module.ts#ContractorsModule', canLoad:[AuthGuard]},
//     { path: 'https://secure.merchantsgroup.com:81/cgi-bin/lansaweb?procfun+migcomproc+mlogon+dev+eng+funcparms+z1aplchld(A0010):C', component: DashboardComponent },
//     { path: 'contractors', component: ContractorsComponent },
//     { path: 'workerscomp', component: WorkersCompComponent },
//     { path: 'quotes/contractors/:id', component: WorkersCompComponent },
//     { path: 'guide', component: RiskAppetiteGuideComponent },
//     { path: 'error', component: PublicErrorDisplayComponent },
//     // { path: 'employers-liability-limits', component: EmployersLiabilityLimits},
//     { path: '**', redirectTo: 'workerscomp', pathMatch: 'full' }

//     // { path: '**', redirectTo: 'quotes/contractors', pathMatch: 'full' }
// ];

// export const AppRoutes: ModuleWithProviders<any> = RouterModule.forRoot(routes, { 

//     preloadingStrategy: NoPreloading,
//     useHash: false 

// });
