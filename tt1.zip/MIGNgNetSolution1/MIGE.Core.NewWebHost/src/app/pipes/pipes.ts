import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';
import { DomSanitizer } from '@angular/platform-browser';

/**
 * pipes to be used universally throughout app
 */

// format yyyymmdd as mm/dd/yyyy
@Pipe({ name: 'formatDate' })
export class formatDatePipe implements PipeTransform {
	transform(value: string): string {
		let tmp: string = value.toString();
		let yy = tmp.substr(0, 4);
		let mm = tmp.substr(4, 2);
		let dd = tmp.substr(6, 2);
		let dte = "";
		if (value) {
			dte = mm + "/" + dd + "/" + yy;
		} else {
			dte = "Please select an effective date";
		}
		return dte;
	}
}
@Pipe({ name: 'filterDropDown' })
export class filterDropDownPipe implements PipeTransform {
	transform(data: string, arr: any[]): string {
		for (let i = 0; i < arr.length; i++) {
			if (arr[i].value == data) { return arr[i].label; }
		}
		return data;
	}
}
@Pipe({name: 'formatZipCode' })
export class formatZipCodePipe implements PipeTransform {
    transform(zipCodeValue: string): string {
        if (zipCodeValue == null)
            return zipCodeValue;

        zipCodeValue = zipCodeValue.replace("-", "");
        if (zipCodeValue.length > 5) {
            zipCodeValue = zipCodeValue.slice(0,5) + "-" + zipCodeValue.slice(5);
        }
        return zipCodeValue;
    }
}
@Pipe({name: 'formatTelephone' })
export class formatTelephonePipe implements PipeTransform {
    transform(phoneNoValue: string): string {
        phoneNoValue = phoneNoValue.replace(/-/g, "");
        if (phoneNoValue.length > 6) {
            phoneNoValue = phoneNoValue.slice(0,3) + "-" + phoneNoValue.slice(3,6) + "-" + phoneNoValue.slice(6);
        }
        else if (phoneNoValue.length > 3) {
            phoneNoValue = phoneNoValue.slice(0,3) + "-" + phoneNoValue.slice(3);
        }
        return phoneNoValue;
    }
}
@Pipe({ name: 'formatYN' })
export class formatYesNoPipe implements PipeTransform {
	transform(value: string): string {
		if (value == "Y") { return "Yes"; } else { return "No"; }
	}
}

@Pipe({ name: 'safeHtml' })
export class Safe {
	constructor(private sanitizer: DomSanitizer) { }

	transform(style) {
		return this.sanitizer.bypassSecurityTrustHtml(style);
		//return this.sanitizer.bypassSecurityTrustStyle(style);
		// return this.sanitizer.bypassSecurityTrustXxx(style); - see docs
	}
}
@Pipe({ name: 'CurrencyFormat' })
export class CurrencyFormatPipe implements PipeTransform {
	transform(value: any,
		currencySign: string = '$',
		decimalLength: number = 2,
		chunkDelimiter: string = ',',
		decimalDelimiter: string = '.',
		chunkLength: number = 3): string {

		if (value.toString().includes("$")) { return value; }
		value /= 1;

		let result = '\\d(?=(\\d{' + chunkLength + '})+' + (decimalLength > 0 ? '\\D' : '$') + ')'
		let num = value.toFixed(Math.max(0, ~~decimalLength));

		return currencySign + (decimalDelimiter ? num.replace('.', decimalDelimiter) : num).replace(new RegExp(result, 'g'), '$&' + chunkDelimiter);
	}
}

@Pipe({ name: 'prettyprint' })
export class PrettyPrintPipe implements PipeTransform {
	constructor(public sanitizer: DomSanitizer) { }
	transform(val) {
		if (val) {
			let out = JSON.stringify(val, null, 2)
				.replace(' ', '&nbsp;')
				.replace('\n', '<br/>')
				.replace(new RegExp('LOCNUM', 'g'), "<mark>LOCNUM</mark>")
				.replace(new RegExp('BLDNUM', 'g'), "<mark>BLDNUM</mark>")
				.replace(new RegExp('RECORDSTATE', 'g'), "<mark>RECORDSTATE</mark>")
				.replace(new RegExp('"TRANS"', 'g'), "<mark>TRANS</mark>")
				.replace(new RegExp('RCDTYP', 'g'), "<mark>RCDTYP</mark>")
				.replace(new RegExp('EFFDTE', 'g'), "<mark>EFFDTE</mark>")
				.replace(new RegExp('EDSDTE', 'g'), "<mark>EDSDTE</mark>")
				.replace(new RegExp('"POLICY"', 'g'), "\"<mark>POLICY</mark>\"");
			// return this.sanitizer.bypassSecurityTrustHtml(out);
			return JSON.stringify(val, null, 2);

		} else {
			return val;
		}
	}
}

@Pipe({ name: 'filterRecordState', pure: false })
export class FilterLocationPipe implements PipeTransform {
	transform(items: any[], filter: string): any {
		// console.log(items);
		// console.log(filter);
		if (!items || !filter) {
			return items;
		}
		return items.filter(item => item.RECORDSTATE !== filter);
	}
}

@Pipe({ name: 'sortObjectPipe', pure: false })
export class SortObjectPipe implements PipeTransform {
	// sort array by object
	transform(array: any[], field: string): any[] {
		if (!Array.isArray(array)) {
			return array;
		}
		return array.sort((x, y) => x[field] > y[field] ? 1 : x[field] < y[field] ? -1 : 0);
	}
}

@Pipe({ name: 'dateFormat' })
export class DateFormatPipe extends DatePipe implements PipeTransform {
	transform(value: any): any {
		return super.transform(value, "yyyymmdd");
	}
}

@Pipe({ name: 'extension' })
export class RemoveExtension  extends DatePipe implements PipeTransform {
	transform(value: any): any {
		//return super.transform(value, "yyyymmdd");
		let fileLengthToExt = value.indexOf('.');		
		if(fileLengthToExt >= 25){
			return value.substring(0, 24);	
		}
		else{
			return value.substring(0, value.indexOf('.'));
		}
	}
}

