/* NG Includes */
import { NgModule } from '@angular/core';

import {
	CurrencyFormatPipe, 
	formatDatePipe, 
	PrettyPrintPipe, 
	FilterLocationPipe, 
	SortObjectPipe, 
	formatYesNoPipe, 
	filterDropDownPipe, 
	DateFormatPipe,
	Safe,
    formatZipCodePipe,
    formatTelephonePipe,
	RemoveExtension} from '@pipes/pipes';

@NgModule({
	imports: [],
	declarations: [
		CurrencyFormatPipe,
		formatDatePipe,
		PrettyPrintPipe,
		FilterLocationPipe,
		SortObjectPipe,
		formatYesNoPipe,
		filterDropDownPipe,
        RemoveExtension,
        DateFormatPipe,
        formatZipCodePipe,
        formatTelephonePipe,
		Safe
	],
	exports: [
		CurrencyFormatPipe,
		formatDatePipe,
		PrettyPrintPipe,
		FilterLocationPipe,
		SortObjectPipe,
		formatYesNoPipe,
		filterDropDownPipe,
		RemoveExtension,
        DateFormatPipe,
        formatZipCodePipe,
        formatTelephonePipe,
		Safe
	]
})
export class PipesModule { }
