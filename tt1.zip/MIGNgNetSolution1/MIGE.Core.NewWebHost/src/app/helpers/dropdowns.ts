/* ****************************************************************************************************
* PROGRAM DESCRIPTION  - Provides a spot to store Dropdown values from WINS
* AS400 LIBRARY        -
* TABLE/FILENAME       -
* DESCRIPTION          - Additionally, look at /assets/sample_data/dropdowns.json
* DATE CREATED         - 1-5-2019
* AUTHOR               - Mario Giambanco
* Data Dictionary VER: - 214
* CODE GENERATION      -
* NOTES
*       -
* Mario Giambanco 2-5-2019
* added FTHYDT
* added FDMILE
* added defaultBPPVN1
* Updated values from JSON FIRALM1
* Updated values from JSON BURGAL1
* Removed $10,000 from JSON BLDDED
* Updated values from JSON CONSYM
*
* Mario Giambanco 2-19-2019
* Added Additional Coverages > Liability > EPIDED & defaultEPIDED
contractorsEOClasses
****************************************************************************************************/

import { Injectable } from "@angular/core";
import { AuthService } from "@auth/auth.service";
import { TokenResponse } from "@auth/tokenresponse.class";
import { DropDownService } from '@services/dropdown.service';
import { Subscription } from "rxjs";

@Injectable()
export class ContractorsDropDowns {
	token: TokenResponse;

	constructor(
		public dropdownService: DropDownService,
		public authService: AuthService
	) {
		this.token = this.authService.getAuth();
		if (!this.InsuredType.length) {
			this.getData(this.authService.LOB); //pass in the LOB by substringing the Quote number
		}
	}

	getDropDownsSubscription: Subscription;

	InsuredType: any[] = [];
	States: any[] = [];
	StatesFull: any[] = [];

	LineOfBusiness: any[] = [];
	GLP: any[] = [];
	CFP: any[] = [];
	IMP: any[] = [];

	//BOP Losses
	TypeOfOccurrenceClaim: any[] = [];

	// Liability Limits
	defaultEOLMT: string = "";
	GLOccurrenceAggregate: any[] = [];
	defaultMEDLMT: string = "";
	MedicalExpense: any[] = [];
	defaultFDLMT: string = "";
	DamageToPremisesRented: any[] = [];

	//WCA
	//Liability
	EachAccident: any[] = [];
	defaultEMPLIA: string = "";

	//States
	MeritRateFactor: any[] = [];
	MeritRateFactorNY: any[] = [];

	// Location Summary > Property Coverage	
	RATCTY: any[] = [];	
	FTHYDT: any[] = [];
	FDMILE: any[] = [];
	defaultFIRALM1: string = "";
	FIRALM1: any[] = [];
	CONSYM: any[] = [];
	BURGAL1: any[] = [];
	BLDCLS: any[] = [];	
	defaultBLDGDD: string = "";
	BLDGDD: any[] = [];
	WNDDCT: any[] = [];
	defaultBLDCN1: string = "";
	BLDCN1: any[] = [];
	defaultBPPCN1:string= ""
	BPPCN1: any[] = [];
	defaultBLDVAL: string = "";
	BLDVAL: any[] = [];
	defaultBPPVN1: string = "";
	BPPVN1: any[] = [];
	UTLSVC: any[] = [];
	BLDTP1: any[] = [];
	SNGOFG: any[] = [];

	//BOP Specific Building Coverages:
	Valuation: any[] = [];
	TPDED: any[] = [];
	Garagekeepers: any[] = [];
	LiquorLegalLiability: any[] = [];
	PetPlus: any[] = [];
	USDDLM: any[] = [];
	USTELM: any[] = [];
	// Additional Coverages > Liability

	defaultEPILIM: any[] = [];
	EPILIM: any[] = [];
	defaultEPIDED: any[] = [];
	EPIDED: any[] = [];
	vermontEPIDED: any[] = [];
	STAGLM: any[] = [];
    defaultC01PCA: string = "0";
    defaultC01PCA_NH: string = "0";
	contractorsEOClasses: any[] = [];
	C01PCA: any[] = [];
	defaultC01DED: string = "";
	C01DED: any[] = [];
	defaultCYBAGG: string = "";
	CYBAGG: any[] = [];
	CYBSALLimit: string = "";
	EOACTLClasses: any[] = [];
	EOACTLStates: any[] = [];
	EOACTL: any[] = [];
	defaultEBPCLM: string = "";
	EBPCLM: any[] = [];
	defaultEDLLMT: string = "";
	EDLLMT: any[] = [];
	defaultEDPELM: string = "";
	EDPELM: any[] = [];
	DCPBLK: any[] = [];
	SHTPOL: any[] = [];
	defaultHIREOC: string;
	HIREOC: any[] = [];

	// Additional Coverages > Inland
	defaultCTRDED: number;
	CTRDED: any[] = [];
	CTRCNS: any[] = [];
	defaultCTRCNS: string = "";
	CTRUPL: any[] = [];
	DBRRMV: any[] = [];
	TCPPEL: any[] = [];
	TCPOLL: any[] = [];
	FUELAC: any[] = [];
	RNOOLL: any[] = [];
	TRLCON: any[] = [];
	EQPBOR: any[] = [];
	EQPRNT: any[] = [];
	CEQVAL: any[] = [];
	CINDED: any[] = [];
	CINCNS: any[] = [];
	CINSLM: any[] = [];
	CINLLM: any[] = [];
	CINTLM: any[] = [];
	defaultCTRUPL: number;
	defaultDBRRMV: string = "";
	defaultTCPPEL: string = "";
	defaultTCPOLL: number;
	defaultFUELAC: number;
	defaultRNOOLL: number;
	defaultTRLCON: number;
	defaultEQPRNT: number;
	defaultCINDED: string = "";
	defaultCINCNS: string = "";
	defaultCINSLM: string = "";
	defaultCINLLM: string = "";
	defaultCINTLM: string = "";

	// Additional Coverages > Property
	defaultACRON: string = "";
	ACRON: any[] = [];
	BPPTMP: any[] = [];
	COMEQP: any[] = [];
	ACPDBRRMV: any[] = [];
	ACPEDLLMT: any[] = [];
	ETFTLM: any[] = [];
	FALTLM: any[] = [];
	defaultMNSILM: string = "";
	MNSILM: any[] = [];
	OUTPRP: any[] = [];
	OUTSNL: any[] = [];
	VLPONL: any[] = [];
	BINTIM: any[] = [];

	defaultACPDBRRMV: string = "";
	defaultACPEDLLMT: string = "";
	defaultBPPTMP: string = "";
	defaultCOMEQP: string = "";
	defaultETFTLM: string = "";
	defaultFALTLM: string = "";
	defaultOUTPRP: string = "";
	defaultOUTSNL: string = "";
	defaultVLPONL: string = "";
	defaultBINTIM: string = "";
	// Individuals Included / Excluded 
	MSCTTL: any[] = [];
	//
	MRTGTP: any[] = [];
	MRTGTPCOVERG: any[] = [];
    CONTACTINFORMATION: any[] = [];
    //
    preApril2021CTRUPL: any[] = [];
    preApril2021TCPOLL: any[] = [];
    preApril2021FUELAC: any[] = [];
    preApril2021RNOOLL: any[] = [];
    preApril2021TRLCON: any[] = [];
    preApril2021EQPBOR: any[] = [];
    preApril2021EQPRNT: any[] = [];
    preApril2021CINSLM: any[] = [];
    preApril2021CINLLM: any[] = [];
    preApril2021CINTLM: any[] = [];

	setData(data) {
		this.States = data.States;
		this.StatesFull = data.StatesFull;

		this.InsuredType = data.InsuredType;
		this.LineOfBusiness = data.LineOfBusiness;
		this.CFP = data.CFP;
		this.GLP = data.GLP;
		this.IMP = data.IMP;

		// Liability Limits
		this.defaultEOLMT = data.defaultEOLMT;
		this.GLOccurrenceAggregate = data.GLOccurrenceAggregate;
		this.defaultMEDLMT = data.defaultMEDLMT;
		this.MedicalExpense = data.MedicalExpense;
		this.defaultFDLMT = data.defaultFDLMT;
		this.DamageToPremisesRented = data.DamageToPremisesRented;

		// Property Coverages (some of these are shared between CTR & BOP to avoid creating more globals)
		this.FTHYDT = data.FTHYDT;		
		this.FDMILE = data.FDMILE;
		this.defaultFIRALM1 = data.defaultFIRALM1;
		this.FIRALM1 = data.FIRALM1;
		this.CONSYM = data.CONSYM;
		this.BURGAL1 = data.BURGAL1;
		this.BLDCLS = data.BLDCLS;		
		this.defaultBLDGDD = data.defaultBLDGDD;
		this.BLDGDD = data.BLDGDD;
		this.WNDDCT = data.WNDDCT;
		this.defaultBLDCN1 = data.defaultBLDCN1;
		this.BLDCN1 = data.BLDCN1;
		this.defaultBPPCN1 = data.defaultBLDCN1
		this.BPPCN1 = data.BPPCN1;
		this.defaultBLDVAL = data.defaultBLDVAL;
		this.BLDVAL = data.BLDVAL;
		this.defaultBPPVN1 = data.defaultBPPVN1;
		this.BPPVN1 = data.BPPVN1;
		this.UTLSVC = data.UTLSVC;
		this.BLDTP1 = data.BLDTP1;
		this.SNGOFG = data.SNGOFG;

		//BOP specific Coverages: 
		this.Valuation = data.Valuation;
		this.TPDED = data.TPDED;
		this.Garagekeepers = data.Garagekeepers;
		this.LiquorLegalLiability = data.LiquorLegalLiability;
		this.PetPlus = data.PetPlus;
		this.USDDLM = data.USDDLM;
		this.USTELM = data.USTELM;
		// Additional Coverages > Liability
		this.defaultEPILIM = data.defaultEPILIM;
		this.EPILIM = data.EPILIM;

		this.defaultEPIDED = data.defaultEPIDED;
		this.EPIDED = data.EPIDED;
		this.vermontEPIDED = data.vermontEPIDED;
		this.STAGLM = data.STAGLM;

		this.contractorsEOClasses = data.contractorsEOClasses;

		this.defaultC01PCA = data.defaultC01PCA;
        this.C01PCA = data.C01PCA;
        this.defaultC01PCA_NH = data.defaultC01PCA_NH;
		this.defaultC01DED = data.defaultC01DED;
		this.C01DED = data.C01DED;
		this.defaultCYBAGG = data.defaultCYBAGG;
		this.CYBAGG = data.CYBAGG;
		this.CYBSALLimit = data.CYBSALLimit;
		this.EOACTLClasses = data.EOACTLClasses;
		this.EOACTLStates = data.EOACTLStates;

		this.EOACTL = data.EOACTL;
		this.defaultEBPCLM = data.defaultEBPCLM;
		this.EBPCLM = data.EBPCLM;
		this.defaultEDLLMT = data.defaultEDLLMT;
		this.EDLLMT = data.EDLLMT;
		this.defaultEDPELM = data.defaultEDPELM;
		this.EDPELM = data.EDPELM;
		this.DCPBLK = data.DCPBLK;
		this.SHTPOL = data.SHTPOL;
		this.defaultHIREOC = data.defaultHIREOC;
		this.HIREOC = data.HIREOC;

		// Additional Coverages > Inland
		this.defaultCTRDED = data.defaultCTRDED;
		this.CTRDED = data.CTRDED;
		this.CTRCNS = data.CTRCNS;
		this.defaultCTRCNS = data.defaultCTRCNS;

		this.CTRUPL = data.CTRUPL;
		this.DBRRMV = data.DBRRMV;
		this.TCPPEL = data.TCPPEL;
		this.TCPOLL = data.TCPOLL;
		this.FUELAC = data.FUELAC;
		this.RNOOLL = data.RNOOLL;
		this.TRLCON = data.TRLCON;
		this.EQPBOR = data.EQPBOR;
		this.EQPRNT = data.EQPRNT;
		this.CEQVAL = data.CEQVAL;
		this.CINDED = data.CINDED;
		this.CINCNS = data.CINCNS;
		this.CINSLM = data.CINSLM;
		this.CINLLM = data.CINLLM;
		this.CINTLM = data.CINTLM;

		this.defaultCTRUPL = data.defaultCTRUPL;
		this.defaultDBRRMV = data.defaultDBRRMV;
		this.defaultTCPPEL = data.defaultTCPPEL;
		this.defaultTCPOLL = data.defaultTCPOLL;
		this.defaultFUELAC = data.defaultFUELAC;
		this.defaultRNOOLL = data.defaultRNOOLL;
		this.defaultTRLCON = data.defaultTRLCON;
		this.defaultEQPRNT = data.defaultEQPRNT;

		this.defaultCINDED = data.defaultCINDED;
		this.defaultCINCNS = data.defaultCINCNS;
		this.defaultCINSLM = data.defaultCINSLM;
		this.defaultCINLLM = data.defaultCINLLM;
		this.defaultCINTLM = data.defaultCINTLM;


		// Additional Coverages > Property
		this.defaultACRON = data.defaultACRON;
		this.ACRON = data.ACRON;
		this.BPPTMP = data.BPPTMP;
		this.COMEQP = data.COMEQP;
		this.ACPDBRRMV = data.ACPDBRRMV;
		this.ACPEDLLMT = data.ACPEDLLMT;
		this.ETFTLM = data.ETFTLM;
		this.FALTLM = data.FALTLM;
		this.defaultMNSILM = data.defaultMNSILM;
		this.MNSILM = data.MNSILM;
		this.OUTPRP = data.OUTPRP;
		this.OUTSNL = data.OUTSNL;
		// this.VPRLM1 = data.VPRLM1;
		this.VLPONL = data.VLPONL;
		this.BINTIM = data.BINTIM;

		this.defaultACPDBRRMV = data.defaultACPDBRRMV;
		this.defaultACPEDLLMT = data.defaultACPEDLLMT;
		this.defaultBPPTMP = data.defaultBPPTMP;
		this.defaultCOMEQP = data.defaultCOMEQP;
		this.defaultETFTLM = data.defaultETFTLM;
		this.defaultFALTLM = data.defaultFALTLM;
		this.defaultOUTPRP = data.defaultOUTPRP;
		this.defaultOUTSNL = data.defaultOUTSNL;
		// this.defaultVPRLM1 = data.defaultVPRLM1;
		this.defaultVLPONL = data.defaultVLPONL;
		this.defaultBINTIM = data.defaultBINTIM;

		// Indiviudals Included / Excluded
		this.MSCTTL = data.MSCTTL;


		// finish application
		this.MRTGTP = data.MRTGTP;
		this.MRTGTPCOVERG = data.MRTGTPCOVERG;
        this.CONTACTINFORMATION = data.CONTACTINFORMATION;
        
        //
        this.preApril2021CTRUPL = data.preApril2021CTRUPL;
        this.preApril2021TCPOLL = data.preApril2021TCPOLL;
        this.preApril2021FUELAC = data.preApril2021FUELAC;
        this.preApril2021RNOOLL = data.preApril2021RNOOLL;
        this.preApril2021TRLCON = data.preApril2021TRLCON;
        this.preApril2021EQPBOR = data.preApril2021EQPBOR;
        this.preApril2021EQPRNT = data.preApril2021EQPRNT;
        this.preApril2021CINSLM = data.preApril2021CINSLM;
        this.preApril2021CINLLM = data.preApril2021CINLLM;
		this.preApril2021CINTLM = data.preApril2021CINTLM;
		
		//WCA
		//Liability
		this.EachAccident = data.EachAccident;
		this.defaultEMPLIA = data.defaultEMPLIA;

		//States
		this.MeritRateFactor = data.MeritRateFactor;
		this.MeritRateFactorNY = data.MeritRateFactorNY;

		//BOP Losses
		this.TypeOfOccurrenceClaim = data.TypeOfOccurrenceClaim;
	}

	getData(lob: string) { 
		// 3/4/2021: added lob parameter to send to the service so that the dropdown service knows which JSON file to get. -JTL 
		
		this.getDropDownsSubscription = this.dropdownService.getDropDownsSample(lob).subscribe((data) => {
			this.setData(data);
		});
		}	
}

