import { Injectable } from "@angular/core";

import { FormGroup } from '@angular/forms';

@Injectable()
export class Functions {

	// exists(str: string): boolean {
	// 	let result = false;
	// 	let tmp = str.split(".");
	// 	let cmd;
	// 	tmp.forEach(function (elem) {
	// 		if (elem == "this") { cmd = elem; return; } else {
	// 			cmd += "." + elem;
	// 			if(eval(cmd)) {result = true; }
	// 		}
	// 	})
	// 	return result;
	// };

	lpad(str, padString, length) {
		// add left padding (0's)
		while (str.length < length)
			str = padString + str;
		return str;
	}

	rpad(str) {
		// remove WINS padding
		return str.replace(/^0+/, '')
	}

	pad(n, width, z = "") {
		z = z || '0';
		n = n + '';
		return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n;
	}

	nopad(s) {
		let trimmed = s.replace(/\b(0(?!\b))+/g, "");
		return trimmed;
	}

	justNumbers(val): number {
		if (val) {
			val = Number(val.toString().replace(/\D/g, ''));
		}	
		val = (val === '' ? 0 : val);	
		return val;
	}
	getValueFromPercentage(percentData){ // send in a form control string in the form of a percentage. Returns the numeric value of that percentage.
		if(isNaN(percentData)){ // Make a substring since the formcontrol value has a percentage in it
			var percentStr: string = percentData;
			var newPercentStr: string = percentStr.substring(0,percentStr.length-1);
			var percent: number = +newPercentStr;

		}
		else{
			var percent: number = Number(percentData);
		}
		if (isNaN(percent)) {
			percent = 0;
		}
		return percent;
	}
	funcKillAutoFill(elem, renderer) {
		// Chrome ignores autocomplete='off'
		// so - this is the workaround
		// (MIG can be anything)
		//
		// Put it in AfterViewInit
		let elements = elem.nativeElement.querySelectorAll('input');
		elements.forEach(element => {
			
			renderer.setAttribute(element, "autocomplete", "MIG");
			// turn the rest of them off cause it's just annoying for this project
			renderer.setAttribute(element, "autocorrect", "off");
			renderer.setAttribute(element, "autocapitalize", "off");
			renderer.setAttribute(element, "spellcheck", "false");
		})
		this.funcRemoveTabIndex(elem, renderer);
	}

	funcRemoveTabIndex(elem, renderer) {
		let elements = elem.nativeElement.querySelectorAll('a');
		elements.forEach(element => {
			renderer.setAttribute(element, "tabindex", "-1");
		});

		elements = elem.nativeElement.querySelectorAll('button');
		elements.forEach(element => {
			renderer.setAttribute(element, "tabindex", "-1");
		});
	}

	DTEWinsToPrimeNG(dtetme,format?): any  // added optional param due to saving to DWCP141 MSCDOB field is in format mmddyyyy
	{		
		
		let out = "";
		if (!dtetme) {
			//THE FIX FOR IE
			return new Date();
			
			//BELOW DOES NOT WORK IN IE()
			//let today:any = new Date().toLocaleDateString();
			//return today;
			//let datearray = today.split("/");
			//out = datearray[0] + "/" + datearray[1] + "/" + datearray[2];
			//return out.toString().trim();			
		}
		//else fill whats coming from Lansa
		let dte: string = dtetme.toString();
		dte = this.pad(dte,8); // if date is in format mmddyyyy and mm is less than 10 we need to pad a 0
		if(format == 'mmddyyyy'){
			out = dte.substr(0,2) + "/" + dte.substr(2,2) + "/" + dte.substr(4,4); // formating for mmddyyy
		}
		else{
			out = dte.substr(4, 2) + "/" + dte.substr(6, 2) + "/" + dte.substr(0, 4); // formatting for yyyymmdd
		}
		return new Date(out.toString());//<-- IE needs this to be of type DATE
    }
    
    DTEWinsToDisplayFormat(dtetme): any 
	{	
		let out = "";
		if (!dtetme) {
			//THE FIX FOR IE
			return new Date();
			
			//BELOW DOES NOT WORK IN IE()
			//let today:any = new Date().toLocaleDateString();
			//return today;
			//let datearray = today.split("/");
			//out = datearray[0] + "/" + datearray[1] + "/" + datearray[2];
			//return out.toString().trim();			
		}
		//else fill whats coming from Lansa
		let dte: string = dtetme.toString();
		out = dte.substr(4, 2) + "/" + dte.substr(6, 2) + "/" + dte.substr(0, 4);		
		return out;
	}

	DTEPrimeNGtoWins(dtetme): number {
		if (!dtetme) { return; }
				
		// date formatted properly
		// just return it
		if (dtetme.length < 11) { return dtetme; }

		let dummy = dtetme.toString();
		
		let dummy2 = dummy.split('T')[0];
		
		let dummy3 = dummy2.replace(/-/g, "");
		

		return parseInt(dummy3);
	}

	WinsToDateObject(dte): Date {
		dte = dte.toString();
		let month: number = Number(dte.substr(4, 2)) - 1;
		let day: number = Number(dte.substr(6, 2));
		let year: number = Number(dte.substr(0, 4));

		let dteOut = new Date(year, month, day, 0, 0, 0);
		return dteOut;
	}

	parseWinsState(state: string): string {
		let out = "";
		switch (state) {
			case "MA":
				out = "Massachusetts";
				break;

			case "NY":
				out = "New York";
				break;
		}
		return out;
	}

	validateField(hasError, field) {
		// hasError is a property passdown from contractors.component
		// field is the get field() function from the component
		// to be used on the <label> of the field
		// to simplify setting color: red when a field fails validation
		if (hasError && field && field.errors) { return 'err'; }
	}

	fixDropDownLabel(field) {
		// ui-float-label doesn't work on p-dropdown
		// this fixes it
		if (field.value) { return { "top": "-.75em" }; } else { return { "top": "1.0em" }; }
	}

	detectIE() {
		var ua = window.navigator.userAgent;
		var msie = ua.indexOf('MSIE ');
		if (msie > 0) {
			// IE 10 or older => return version number
			return parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)), 10);
		}

		var trident = ua.indexOf('Trident/');
		if (trident > 0) {
			// IE 11 => return version number
			var rv = ua.indexOf('rv:');
			return parseInt(ua.substring(rv + 3, ua.indexOf('.', rv)), 10);
		}

		var edge = ua.indexOf('Edge/');
		if (edge > 0) {
			// Edge (IE 12+) => return version number
			return parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10);
		}

		// other browser
		return false;
	}

	funcDateSelected(date,output?) { // added optional param due to saving to DWCP141 MSCDOB field is in format mmddyyyy
		
		if (date === undefined) { return 0; }
		//bdk - bug fix
		var d = new Date(date);
		var out;
		let mm = (d.getMonth() + 1).toString();
		let pad = "00";
		mm = pad.substring(mm.length) + mm;
		let dd = (d.getDate()).toString();
		dd = pad.substring(dd.length) + dd;
		let yy = d.getFullYear();

		if(output == 'mmddyyyy'){
			 out = mm.toString() + dd.toString() + yy.toString();
		}
		else {
			 out = yy.toString() + mm.toString() + dd.toString();
		}
		return parseInt(out);
		
	}

	getMaxDate(additionalDays?) : Date { // returns the max (latest) date that can be selected from a calendar. any date past this date will be disabled on the calendar.
		let maxDte = new Date();
		let day = maxDte.getDate();
		if(additionalDays != null){ // if we want to set the max date to a date past today's date, we can pass and set the new value here.
			day = day + additionalDays;
		}
		maxDte.setDate(day); // if we don't pass in additonalDays, our Max date will be set to today's date. 
		return maxDte;
	}
    keyPressAlphaNumeric(event) { // this function can be used for elements where we want to prevent users from entering non alpha-numeric (%,$,&, etc.) values into a field. This is called each time a key is entered in the field

        var inp = String.fromCharCode(event.keyCode); // each key has a unique code associated with it. Grab the key from its code.

        if (/[a-zA-Z0-9 ]/.test(inp)) { //  test to see if the key pressed is alpha-numeric (A-Z, 0-9) or space
          return true;
        } else {
          event.preventDefault();
          return false;
        }
      }

	  keyPressNumeric(event) {

        var inp = String.fromCharCode(event.keyCode); // each key has a unique code associated with it. Grab the key from its code.

        if (/[0-9]/.test(inp)) { //  test to see if the key pressed is numeric (0-9)
          return true;
        } else {
          event.preventDefault();
          return false;
        }
      }

	  setInputSwitchValue(controlValue): string{ // used for input switches (Yes/No Toggles)
		if(controlValue === true || controlValue === "Y"){
		  return "Y";
		}
		if(controlValue === false || controlValue === "N"){ // need === instead of == because otherwise when an input switch is unanswered, its value will be "" which TypeScripts evaluates as false.
		  return "N";
		}
		else {
		  return "";
		}
	  }

	  scrollIntoView(HTMLId: string){
		// 7/18/22: there is a bug with Google Chrome such that the smooth scrolling functionality won't work by default. 
		//You need to type in chrome://flags in the URL and manually enable smooth scrolling in order for the smooth scrolling to actually work. 
		// Otherwise this will just jump to the top of the building tab -JTL
		document.getElementById(HTMLId).scrollIntoView({behavior:"smooth"});
	  }

}
