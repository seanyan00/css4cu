import { Injectable } from "@angular/core";
import { BopOptionalCoveragesService } from "@root/services/bop_optional_coverages.service";
import { Subscription } from "rxjs";

@Injectable()
export class BopOptionalCoveragesData {
    scheduledOptionalCoverageData: any[];

    constructor(
        public bopOptionalCoveragesService: BopOptionalCoveragesService,
    ) {
            this.getData();
    }

    getScheduledCoverageDataSubscription: Subscription;


    setData(data) {
        this.scheduledOptionalCoverageData = data;
    }

	getData() { 
        this.getScheduledCoverageDataSubscription = this.bopOptionalCoveragesService.getScheduledCoverageData().subscribe((data) => {
            this.setData(data);
        });
    }	
}

