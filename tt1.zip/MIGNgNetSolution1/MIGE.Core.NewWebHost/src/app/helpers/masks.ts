/* ****************************************************************************************************
* FILE DESCRIPTION 	   - Input Masks
* DESCRIPTION          - Central place to store the various input masks needed
* DATE CREATED         - 2-19-2019
* AUTHOR               - Mario Giambanco
* Data Dictionary VER: - none
*
* Mario Giambanco 2-19-2019
* Moved all masks to here and refactored code as needed
****************************************************************************************************/

import { Injectable } from "@angular/core";
import createNumberMask from 'text-mask-addons/dist/createNumberMask'

@Injectable()
export class InputMasksClass {
    zipMask = { mask: [/\d/, /\d/, /\d/, /\d/, /\d/], placeholderChar: ' ' };
	phoneMask 	 = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
	//
	percentMask  = createNumberMask({ prefix: '', suffix: '%' });
	currencyMask = createNumberMask({ prefix: '$', suffix: '' });
	numericMask  = createNumberMask({ prefix: '', suffix: ''});
	twoDigit 	 = createNumberMask({ prefix: '', suffix: '', integerLimit: 2 });
	decimalMask  = createNumberMask({ prefix: '', suffix: '', requireDecimal: true, integerLimit: 1,  allowNegative: true, allowLeadingZeros: true });
	yearMask = createNumberMask({ prefix: '', suffix: '', includeThousandsSeparator: false, integerLimit: 4});	
	numericIDMask = createNumberMask({ prefix: '', suffix: '', includeThousandsSeparator: false, allowLeadingZeros:true}); // used for FEIN Number. Can be used for other instances (like an ID number) where we do not want to include a thousands separator. -JTL
	experienceModMask  = createNumberMask({ prefix: '', suffix: '', requireDecimal: true, decimalLimit: 3, integerLimit: 1,  allowNegative: true, allowLeadingZeros: true }); //mask for WCA Experience Mod that has 3 digit precision
    numberOnlyMask = createNumberMask({ prefix: '', suffix: '', includeThousandsSeparator: false });
}
