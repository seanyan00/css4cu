/* ****************************************************************************************************
* PROGRAM DESCRIPTION  - Provides a spot to store tooltip values.
* DESCRIPTION          - tooltips.ts holds the information for both tooltip information and 
*                        also the information used for the extra information panel.
*                      - it subscribes the data retrieved by the service to set each element 
*                        from the file (the tooltips) to its corresponding string. 
* DATE CREATED         - 6-6-2019
* AUTHOR               - John Lammers
* NOTES
* - Used dropdowns.ts by Mario Giambanco as a reference
* - tooltips.json holds the data
* - tooltip.service.ts is the service that retrieves the data from tooltips.json, 
*   using dropdowns.service.ts as a reference
****************************************************************************************************/
import { Injectable } from "@angular/core";
import { TooltipService } from '@services/tooltip.service';
import { Subscription } from "rxjs";

@Injectable()
export class ContractorsTooltips {
    
  constructor(private tooltipService: TooltipService) {
    this.getData();
  }

  getTooltipsSubscription: Subscription;  

  //Quote Information
  BUSDSC: any="";
  ACTCRE: any="";
  LOSDEL: any="";
  LOSCNL: any="";
  LOSDNE: any="";
  //Liability Limits
  PAOFRE: any="";
   //Business Class
  EXPPAY: string="";
  //Property Coverage
  PROPEDIT: any ="";
  // Location Summary (General Liability): 
  CLSADD: any="";
  EDTCLS: any="";
 
  // Property Coverages
  FIRALM1: any="";
  FIRALM2: any="";
  SPRINK: any="";
  BURGAL1: any="";
  BURGAL2: any="";
  BURGAL3: any="";
  CONFRA: any="";
  JOIMAS: any=""; 
  NNCMBT: any="";
  MSNCBT: any="";
  MDFRST: any="";
  FRSIST: any=""; 
  WINDEV: any="";
  SCBPTP: any="";
  UNBPTP: any="";
  //Liabilty Coverages
  WHTINC: any="";
  WHTINC_VT: any="";
  EPILIM: any="";
  EPIOID: any="";
  EPITPC: any="";
  C01RTR: any="";
  EBRETR: any="";
  C01PCA: any="";
  CYBAGG: any="";
  EBPCLM: any="";
  SHTPOL: any="";
  HIRNOA: any="";
  TransRights: any="";
  //Inland Coverages
  SUPMAR: any="";
  DWNHLE: any="";
  //Property Coverages
  SUPPTY: any="";
  //Premium Summary
  PREEAO: any="";
  PRECYB: any="";
  PRESTP: any="";
  PREEQK: any="";
  PRESAI: any="";
  //App footer buttons
  SXTBTN: any="";
  SVLBTN: any="";
  PRVBTN: any="";
  NXTBTN: any="";
  btnPropertyDone: any = "";
  btnPropertyCancel: any = "";
  AdditionalInsuredDescriptions: any[] = [];
  

  getData() {
    this.getTooltipsSubscription = this.tooltipService.getTooltipsSample().subscribe((data) => {
      this.setToolTips(data);
    });
  }

  setToolTips(data){
  
    //Quote Information
    this.BUSDSC=data.BUSDSC;
    this.ACTCRE=data.ACTCRE;
    this.LOSDEL=data.LOSDEL;
    this.LOSCNL=data.LOSCNL;
    this.LOSDNE=data.LOSDNE;
    //Liability Limits
    this.PAOFRE = data.PAOFRE;
    //Business Class
    this.EXPPAY = data.EXPPAY;
    //Proprerty Coverage
    this.PROPEDIT=data.PROPEDIT;
    // Location Summary (General Liability): 
    this.CLSADD=data.CLSADD;
    this.EDTCLS=data.EDTCLS;
    //Property Coverages
    this.FIRALM1=data.FIRALM1;
    this.FIRALM2=data.FIRALM2;
    this.SPRINK=data.SPRINK;
    this.BURGAL1=data.BURGAL1;
    this.BURGAL2=data.BURGAL2;
    this.BURGAL3=data.BURGAL3;
    this.CONFRA=data.CONFRA;
    this.JOIMAS=data.JOIMAS;
    this.NNCMBT=data.NNCMBT;
    this.MSNCBT=data.MSNCBT;
    this.MDFRST=data.MDFRST;
    this.FRSIST=data.FRSIST;
    this.WINDEV=data.WINDEV;
    this.SCBPTP=data.SCBPTP;
    this.UNBPTP=data.UNBPTP;
    //Liability Coverages
    this.WHTINC=data.WHTINC;
    this.WHTINC_VT=data.WHTINC_VT;
    this.EPILIM=data.EPILIM;
    this.EPIOID=data.EPIOID;
    this.EPITPC=data.EPITPC;
    this.C01PCA=data.C01PCA;
    this.C01RTR=data.C01RTR;
    this.CYBAGG=data.CYBAGG;
    this.EBPCLM=data.EBPCLM;
    this.SHTPOL=data.SHTPOL;
    this.HIRNOA=data.HIRNOA;
    this.TransRights=data.TransRights;
    //Inland Coverages
    this.SUPMAR=data.SUPMAR;
    this.DWNHLE=data.DWNHLE;
    //Property Coverages
    this.SUPPTY=data.SUPPTY;
    //Premium Summary
    this.PREEAO=data.PREEAO;
    this.PRECYB=data.PRECYB;
    this.PRESTP=data.PRESTP;
    this.PREEQK=data.PREEQK;
    this.PRESAI=data.PRESAI;
    //App Footer Buttons
    this.SXTBTN=data.SXTBTN;
    this.SVLBTN=data.SVLBTN;
    this.PRVBTN=data.PRVBTN;
    this.NXTBTN=data.NXTBTN;
    //
    this.btnPropertyDone=data.btnPropertyDone;
    this.btnPropertyCancel=data.btnPropertyCancel;
    //
    this.AdditionalInsuredDescriptions = data.AdditionalInsuredDescriptions;
  } 

}