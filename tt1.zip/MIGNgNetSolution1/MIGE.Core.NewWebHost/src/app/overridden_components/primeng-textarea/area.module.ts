import { MIGTextarea } from './area.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgModel } from '@angular/forms';
@NgModule({
	imports: [CommonModule, FormsModule],
	declarations: [MIGTextarea],
	exports: [MIGTextarea],
	providers: [NgModel]
	})
export class MIGTextareaModule { }
