import { Component, ElementRef, Input, forwardRef, Inject, AfterContentChecked, Renderer2, ChangeDetectorRef } from '@angular/core';

import { NG_VALUE_ACCESSOR, NgModel, NgControl } from '@angular/forms';
import { InputTextarea } from 'primeng/inputtextarea';

@Component({
  selector: '[migInputTextarea]',
  templateUrl: './area.component.html',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: forwardRef(() => MIGTextarea),
    }
  ]
})

export class MIGTextarea extends InputTextarea implements AfterContentChecked {
  @Input() migEditable?: boolean = true; // are we editable or no?
  @Input() noValue?: string = ""; // string to display if no value found
  el: any;
  div: any;

  @Input('value')
	set _value(v: any) {
		if (v !== this.el.nativeElement.value) {
			this.el.nativeElement.value = v;
			this.propagateChange();

		}
  }
  
  constructor(
    @Inject(ElementRef) el: ElementRef, ngModel: NgModel, c:NgControl, cd: ChangeDetectorRef, public renderer2: Renderer2  ) 
    {
    super(el, ngModel,c, cd)
    this.el = el;

    this.renderer2.listen(this.el.nativeElement, "keyup", (evt) => {
      this.propagateChange(evt.target.value);
    })
  }

  ngAfterContentChecked() {
      if(this.div) { this.el.nativeElement.parentNode.removeChild(this.div);}
      let hash = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
      let found: boolean = false;

      let tmp = this.el.nativeElement.value.trim();
      if (!tmp) { tmp = (this.noValue ? this.noValue : "No value provided"); } else { found = false; }
      this.div = this.renderer2.createElement('div');
      this.div.setAttribute("id", hash);
      this.div.style.display = "none";
      const small = this.renderer2.createElement('small');
      const text = this.renderer2.createText(tmp);
      this.div.appendChild(small, text);

      if (this.el.nativeElement.value.length > 0) {
        this.div.appendChild( text);
      } else {
        this.div.appendChild( small);
      }
      this.el.nativeElement.parentNode.appendChild(this.div);

      if (!this.migEditable) {
      this.div.style.display = "inherit";
        this.renderer2.setStyle(this.el.nativeElement, 'display', 'none');
      } else {
      this.div.style.display = "none";

        this.renderer2.setStyle(this.el.nativeElement, 'display', 'inherit');

      }
  }

  // _value = '';
  propagateChange: any = () => { };
  writeValue(value: any) { if (value) { this._value = value; } }
  registerOnChange(fn) { this.propagateChange = fn; }
  registerOnTouched(fn: () => void): void { }
  // onChange(event) { this.propagateChange(event.target.value); }

}
