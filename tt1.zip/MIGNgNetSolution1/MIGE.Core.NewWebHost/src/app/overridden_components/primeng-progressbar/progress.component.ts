import {
	Component,
	ElementRef,
	Input, forwardRef, ChangeDetectorRef, AfterViewInit, ViewChild
} from '@angular/core';

import {
	NG_VALUE_ACCESSOR, FormControl, ControlValueAccessor
} from '@angular/forms';

import { ProgressBar } from 'primeng/progressbar';

@Component({
	selector: 'mig-progressBar',
	templateUrl: './progress.component.html'
})

export class MIGProgessbar extends ProgressBar {
	constructor() {
		super()
	}
}
