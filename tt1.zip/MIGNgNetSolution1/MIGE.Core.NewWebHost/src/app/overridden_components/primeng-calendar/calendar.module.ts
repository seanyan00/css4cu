import { MIGCalendar } from './calendar.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ButtonModule } from 'primeng/button';
//import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DomHandler } from 'primeng/dom';

@NgModule({
	imports: [
	CommonModule,
    ButtonModule,
    //BrowserAnimationsModule
	],
	declarations: [MIGCalendar],
  	exports: [MIGCalendar],
  	providers: [DomHandler]
	})
export class MIGCalendarModule { }
