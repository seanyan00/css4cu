import { Component, ElementRef, Input, forwardRef, Renderer2, ChangeDetectorRef, NgZone, OnDestroy, HostListener } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { Calendar } from 'primeng/calendar';
import { state, style, trigger, transition, animate } from '@angular/animations';
import { OverlayService, PrimeNGConfig } from 'primeng/api'


@Component({
  selector: 'mig-calendar',
  templateUrl: './calendar.component.html',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: forwardRef(() => MIGCalendar)
    }
  ],
  animations: [
    trigger('overlayAnimation', [
      state('visible', style({
        transform: 'translateY(33px)',
        opacity: 1
      })),
      state('visibleTouchUI', style({
        transform: 'translate(-50%,-50%)',
        opacity: 1
      })),
      transition('void => visible', [
        style({ transform: 'translateY(5%)', opacity: 0 }),
        animate('{{showTransitionParams}}')
      ]),
      transition('visible => void', [
        animate(('{{hideTransitionParams}}'), style({
          opacity: 0,
          transform: 'translateY(5%)'
        }))
      ]),
      transition('void => visibleTouchUI', [
        style({ opacity: 0, transform: 'translate3d(-50%, -40%, 0) scale(0.9)' }),
        animate('{{showTransitionParams}}')
      ]),
      transition('visibleTouchUI => void', [
        animate(('{{hideTransitionParams}}'), style({
          opacity: 0,
          transform: 'translate3d(-50%, -40%, 0) scale(0.9)'
        }))
      ])
    ])
  ]
})


export class MIGCalendar extends Calendar implements OnDestroy {
  @Input() migEditable: boolean = true;
	private previousTypedInput: string;
  private inCal = false;
  /**for override on primeng calendar */
  _today:string = 'Today';
  _clear:string = 'Clear'
  _months: string[]  = ["January","February","March","April","May","June","July","August","September","October","November","December"]

	@HostListener('click')
	clickInside() {
		this.inCal = true;
	}

	@HostListener('document:click')
	clickOutside() {
		if (!this.inCal) {
			super.hideOverlay();
		}
			this.inCal = false;
	}
    constructor
    (
        el: ElementRef,
        renderer2: Renderer2,
        cd: ChangeDetectorRef,
        zone: NgZone,
        config: PrimeNGConfig,
        overlayService: OverlayService
    )
    {
        super(el, renderer2, cd, zone, config,overlayService);
        this.selectOtherMonths = true;
      //   this.locale = {
      //     firstDayOfWeek: 1,
      //     dayNames: [ "domingo","lunes","martes","miércoles","jueves","viernes","sábado" ],
      //     dayNamesShort: [ "dom","lun","mar","mié","jue","vie","sáb" ],
      //     dayNamesMin: [ "D","L","M","X","J","V","S" ],
      //     monthNames: [ "enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre" ],
      //     monthNamesShort: [ "ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic" ],
      //     today: 'Hoy',
      //     clear: 'Borrar'
      // }
    }
    
    ngOnInit():void  {     
        //console.log('this._today',  formatDate(Date.now(), 'MM/dd/yyyy', 'en'));      
    }
    onInputKeydown(event) {
        super.onInputKeydown(event);
        this.previousTypedInput = event.target.value;
    }
    onUserInput(event)
    {
      
        if (this.dateFormat != 'mm/dd/yy')
        {
            //All bets are off for any other format.
            return super.onUserInput(event);
        }
        
        let newValue: string = event.target.value
        if (this.previousTypedInput.length > newValue.length)
        {
            return super.onUserInput(event);
        }

        let inputData: string = newValue.substring(newValue.length - 1);
        
        if (inputData == "/")
        {
            if (newValue.endsWith("//"))
            {
                newValue = newValue.replace(/\/\//g, "/");
            }
            if (newValue.length == 2)
            {
                newValue = "0" + newValue;
            }
            if (newValue.length == 5)
            {
                newValue = newValue.substring(0,3) + "0" + newValue.substr(3);
            }
            event.target.value = newValue;
        }

        var input = event.target.value;
        if (/\D\/$/.test(input))
        {
            input = input.substr(0, input.length - 3);
        }
        
        var values = input.split('/').map(function(v) {
            return v.replace(/\D/g, '')
        });
        
        if (values[0])
        {
            values[0] = this.checkValue(values[0], 12);
        }

        if (values[1])
        {
            values[1] = this.checkValue(values[1], 31);
        }

        var output = values.map(function(v, i) {
            return v.length == 2 && i < 2 ? v + '/' : v;
        });
        event.target.value = output.join('').substr(0, 14);
        super.onUserInput(event);
    }

    checkValue(str, max) {
        if (str.charAt(0) !== '0' || str == '00')
        {
            var num = parseInt(str);
            if (isNaN(num) || num <= 0 || num > max)
            {
                num = 1;
            }

            str = num > parseInt(max.toString().charAt(0)) 
                    && num.toString().length == 1 ? '0' + num : num.toString();
        }
        return str;
    }

    ngOnDestroy() {
      this.cd.detach();
    }
}
