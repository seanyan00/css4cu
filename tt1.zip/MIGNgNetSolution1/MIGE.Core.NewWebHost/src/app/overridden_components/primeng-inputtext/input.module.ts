import { MIGInputtext } from './input.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgModel } from '@angular/forms';
@NgModule({
	imports: [CommonModule, FormsModule],
	declarations: [MIGInputtext],
	exports: [MIGInputtext],
	providers: [NgModel]
	})
export class MIGInputtextModule { }
