import { Component, ElementRef, Input, forwardRef, Inject, AfterContentChecked, Renderer2, AfterContentInit, ɵConsole, ChangeDetectorRef, AfterViewInit, OnDestroy, AfterViewChecked } from '@angular/core';
import { NG_VALUE_ACCESSOR, NgModel, ControlValueAccessor, NG_VALIDATORS, UntypedFormControl } from '@angular/forms';
import { InputText } from 'primeng/inputtext';
import { debounceTime } from 'rxjs/operators';
import { MIGSystemService } from '@services/mig.service';

@Component({
	selector: '[migInputText]',
	templateUrl: './input.component.html'
	//   providers: [
	//     {
	//       provide: NgModel,
	//       multi: true,
	//       useExisting: forwardRef(() => MIGInputtext)
	//     }
	//   ]
})

export class MIGInputtext extends InputText implements AfterViewInit, AfterViewChecked, ControlValueAccessor {
	ngAfterViewChecked(): void {
		if (!this.migEditable) {
			this.div.style.display = "inherit";
			this.renderer2.setStyle(this.el.nativeElement, 'display', 'none');
		} else {
			this.div.style.display = "none";

			this.renderer2.setStyle(this.el.nativeElement, 'display', 'inherit');
		}
	}

	@Input() migEditable?: boolean = true; // are we editable or no?
	@Input() noValue?: string = ""; // string to display if no value found
	@Input() c: UntypedFormControl = new UntypedFormControl();

	@Input('value')
	set _value(v: any) {
		if (v !== this.el.nativeElement.value) {
			this.el.nativeElement.value = v;
			this.propagateChange();
		}
	}

	el: ElementRef;
	div: any;
	constructor(
		@Inject(ElementRef) el: ElementRef,
		ngModel: NgModel,
		public renderer2: Renderer2,
		cd: ChangeDetectorRef
	) {
		super(el, ngModel,cd)
		this.el = el;
		this.onChange = (_: any) => { };

		// let nme = this.el.nativeElement.value('formControlName');
		
		this.renderer2.listen(this.el.nativeElement, "keyup", (evt) => {
			this.propagateChange(evt.target.value);
		});
		if (this.el.nativeElement.classList.contains('number')) {
			this.el.nativeElement.setAttribute('type', 'tel');
			this.renderer2.listen(this.el.nativeElement, "focus", (evt) => {
				if (evt.target.value == "0") {
					evt.target.value = '';
				}
			});
			this.renderer2.listen(this.el.nativeElement, "blur", (evt) => {
				if (evt.target.value.trim() == "") {
					evt.target.value = '0';
				}
			});
		}
	}

	ngAfterViewInit() {


		this.c.valueChanges.pipe(debounceTime(100)).subscribe(
			() => {
				// check condition if the form control is RESET
				if (this.c.value == "" || this.c.value == null || this.c.value == undefined) {
					// this.innerValue = "";
					this.el.nativeElement.value = "";
				}
				//console.log(this.c);
			}
		);

		if (this.div) this.el.nativeElement.parentNode.removeChild(this.div); 
		// let hash = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
		let found: boolean = false;

		let tmp = this.el.nativeElement.value.trim();
		if (!tmp) { tmp = (this.noValue ? this.noValue : "No value provided"); } else { found = false; }
		this.div = this.renderer2.createElement('div');
		// this.div.setAttribute("id", hash);
		this.div.style.display = "none";
		const small = this.renderer2.createElement('small');
		const text = this.renderer2.createText(tmp);
		this.div.appendChild(small, text);

		if (this.el.nativeElement.value.length > 0) {
			this.div.appendChild(text);
		} else {
			this.div.appendChild(small);
		}
		this.el.nativeElement.parentNode.appendChild(this.div);

		
	};

	ngAfterContentChecked() {

	}


	get _value(): any {
		return this.el.nativeElement.value;
	};

	// set value(v: any) {
	//   console.log(v);
	//   if (v !== this.el.nativeElement.value) {
	//     this.el.nativeElement.value = v;
	//     this.propagateChange();

	//   }
	// }

	propagateChange: any = () => { };
	writeValue(value: any) { if (value) { this._value = value; this.propagateChange(); } }
	registerOnChange(fn) { this.propagateChange = fn; }
	registerOnTouched(fn: () => void): void { }
	onChange(event) { this.propagateChange(event.target.value); }
}
