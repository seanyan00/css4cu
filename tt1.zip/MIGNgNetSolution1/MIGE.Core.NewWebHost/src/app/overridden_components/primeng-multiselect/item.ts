import { Component, Input, forwardRef, ElementRef } from '@angular/core';
import { NG_VALUE_ACCESSOR, NgModel } from '@angular/forms';
import { MultiSelectItem } from 'primeng/multiselect';
import { DomHandler } from 'primeng/dom';
import { state, style, trigger, transition, animate } from '@angular/animations';
@Component({
  selector: 'mig-multiSelectItem',
  templateUrl: './item.html',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi: true,
      useExisting: forwardRef(() => MIGMultiselectItem),
    }
  ],
  animations: [
    trigger('overlayAnimation', [
      state('void', style({
        transform: 'translateY(5%)',
        opacity: 0
      })),
      state('visible', style({
        transform: 'translateY(0)',
        opacity: 1
      })),
      transition('void => visible', animate('{{showTransitionParams}}')),
      transition('visible => void', animate('{{hideTransitionParams}}'))
    ])
  ]
})

export class MIGMultiselectItem extends MultiSelectItem {
//   @Input() migEditable: boolean = true;
  visible:boolean;
  maxSelectionLimitReached: boolean; 
}
