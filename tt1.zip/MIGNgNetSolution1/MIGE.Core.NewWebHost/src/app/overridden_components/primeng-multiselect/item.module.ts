import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DomHandler } from 'primeng/dom';
import { MIGMultiselectItem } from './item';
import { ScrollingModule } from '@angular/cdk/scrolling';
@NgModule({
	imports: [CommonModule, FormsModule, ScrollingModule],
	declarations: [MIGMultiselectItem],
	exports: [MIGMultiselectItem],
	providers: [DomHandler]
})			//MIGMultiselectModule
export class MIGMultiselectItemModule { }
