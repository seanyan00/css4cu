import { MIGInput } from './mig-input.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgModel } from '@angular/forms';
@NgModule({
	imports: [CommonModule, FormsModule],
	declarations: [MIGInput],
	exports: [MIGInput],
	providers: [NgModel]
	})
export class MIGInputModule { }