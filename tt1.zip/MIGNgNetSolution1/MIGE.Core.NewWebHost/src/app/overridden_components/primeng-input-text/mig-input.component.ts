import { Component, ElementRef, Input, forwardRef, Inject, AfterContentChecked, Renderer2, AfterContentInit, ɵConsole, ChangeDetectorRef, AfterViewInit, OnDestroy, AfterViewChecked } from '@angular/core';
import { NG_VALUE_ACCESSOR, NgModel, ControlValueAccessor, NG_VALIDATORS, UntypedFormControl } from '@angular/forms';
import { InputText } from 'primeng/inputtext';
import { debounceTime } from 'rxjs/operators';
import { MIGSystemService } from '@services/mig.service';
import { CdkDrag } from '@angular/cdk/drag-drop';

@Component({
	selector: 'mig-input-text',
	templateUrl: './mig-input.component.html'

})
export class MIGInput extends InputText implements ControlValueAccessor  { 

    @Input() migEditable: boolean;
    @Input() noValue: string;
    @Input() c: UntypedFormControl = new UntypedFormControl();

    @Input('value')
	set _value(v: any) {
		if (v !== this.el.nativeElement.value) {
			this.el.nativeElement.value = v;
			this.propagateChange();
		}
    }
    
    get _value(): any {
		return this.el.nativeElement.value;
	};


    constructor(@Inject(ElementRef) el: ElementRef,
                ngModel: NgModel,
                public renderer2: Renderer2,
                cd: ChangeDetectorRef) 
    {
        super(el,ngModel,cd);
        this.el = el;
        this.onChange = (_: any) => { };

        //console.log("mig editable " + this.migEditable);
    }


    propagateChange: any = () => { };
	writeValue(value: any) { if (value) { this._value = value; this.propagateChange(); } }
	registerOnChange(fn) { this.propagateChange = fn; }
	registerOnTouched(fn: () => void): void { }
	onChange(event) { this.propagateChange(event.target.value); }

}