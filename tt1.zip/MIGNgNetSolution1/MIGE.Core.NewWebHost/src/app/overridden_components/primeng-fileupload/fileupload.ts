/* **************************************************************************************************
* COMPONENT DESCRIPTION  - Handle file upload via a modal window
* AS400 LIBRARY          - N/A
* TABLE/FILENAME         - N/A
*
* DATE CREATED           - 6/25/2018
* AUTHOR                 - MAG
* VERSION                - 1.0
* CODE GENERATION        - N/A
*
* ************ PROGRAM MODIFICATIONS SHOULD BE DOCUMENTED IN THE FOLLOWING FORMAT ******************
* DATE OF CHANGE - DEVELOPERS INITIALS - BUG # - DESCRIPTION OF CHANGE
* ***************************************************************************************************
* 6/25/2018 - MAG - N/A - Merged an Overlay Panel, custom File Upload code and PrimeNG File Upload
* Component into this component for portability
*
****************************************************************************************************/
import { Component, 
    ElementRef, 
    EventEmitter,
    Input, 
    Output, 
    NgZone, 
    NgModule,
    ViewChild, 
    Renderer2, 
    OnInit, 
    AfterViewInit, 
    OnDestroy, 
    ChangeDetectorRef, 
    OnChanges } from '@angular/core';
// import { FileUploadModule,
//         FileUpload,
//         DomHandler,
//         SharedModule,
//         ButtonModule,
//         Messages,
//         MessagesModule,
//         InputTextareaModule,
//         OverlayPanel,
//         DialogService,
//         DynamicDialogRef,
//         DynamicDialogConfig } from 'primeng/primeng';

import { FileUpload } from 'primeng/fileupload';
import {FileUploadModule} from 'primeng/fileupload'
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';

import { DomHandler } from 'primeng/dom';
import { DomSanitizer } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TooltipModule } from 'primeng/tooltip';
import { FileMetaData } from '@classes/FileUpload/FileMetaData';
import { FileuploadService } from './fileupload.service';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { MIGSystemService } from '@services/mig.service';
import { PanelModule } from 'primeng/panel';
import { tap, finalize } from 'rxjs/operators';
import { MIGProgessbarModule } from '@overridden/primeng-progressbar/progress.module'
import { HttpClient } from '@angular/common/http';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { QuoteService } from '@services/quote.service';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { Observable, forkJoin } from 'rxjs';
import * as _ from 'lodash';
import { PrimeNGConfig } from 'primeng/api';

// declare global {
//     interface Navigator {
//         msSaveBlob?: (blob: any, defaultName?: string) => boolean
//     }
// }

@Component({
    selector: 'mig-upload',
    templateUrl: './fileupload.html',
    styleUrls: ['./fileupload.css'],
	providers: [ConfirmationService]
})

export class MIGFileUpload extends FileUpload implements OnInit, OnChanges, AfterViewInit{

    @Input() mode: any = 'advanced';
    @Input() name: any;
    //@Input() files: any;
    @Input()
    public  _files: any;
    public get files(): any {
        return this._files;
    }
    public set files(value: any) {
        this._files = value;
    }
    @Input() customUpload: boolean = true;
    @Input() multiple: any;
    @Input() accept: any;
    @Input() maxFileSize: any = 10000000; //10mb
    @Input() value: any;
    @Input() uploadLabel: any = ""
    @Input() chooseLabel: any = "Add Attachment(s)";
    @Input() dragLabel: any = "Drop Attachment(s), or click here to upload";
    @Input() disabled: boolean = false;
    @Input() visible: boolean = false;
    @Input() Quote: CTRQuote;

    fileMeta: FileMetaData;
    fileMetaArray: FileMetaData[];

    dupCheckNotSent:any;
    dupCheckSentToIR:any;

    fileToRemove:File;
    removeID:any;
    msgs = [];
    allFilesSent:boolean = false; 
    deleteFileCount: number = 0; 
	@Output() uploadComplete = new EventEmitter<any>();
	subStep: string = "";
    @ViewChild('content', { static: false }) public content: ElementRef;
    
    constructor(el: ElementRef,
        domhandler: DomHandler,
        sanitizer: DomSanitizer,
        zone: NgZone,
		renderer2: Renderer2,
		httpClient: HttpClient,
        private uploadService: FileuploadService,
		public confirmationService: ConfirmationService,
        public migsystemservice: MIGSystemService,
        private quoteService: QuoteService,
        public cd: ChangeDetectorRef,
        public config: PrimeNGConfig


	) {
		super(el, sanitizer, zone, httpClient, cd,config);
    }

	ngOnInit() {
        //this creates an EventListener for dragover and drop events on the global window to prevent files from being opened 
        //in the browser tab if they are dragged and dropped outside the dropzone area.
        window.addEventListener("dragover", e => {
            e && e.preventDefault();
          }, false);

          window.addEventListener("drop", e => {
            e && e.preventDefault();
          }, false);
        //   console.log(this.files);
        //   console.log("hasNewFiles: ", this.hasNewFiles());
        //   console.log("allFilesSent: ", this.allFilesSent);
        //   console.log("hasFiles: ", this.hasFiles());
          this.checkIRstatus();
    }
    
    ngAfterViewInit(){}

    ngOnChanges(){
        this.checkIRstatus();
    }

    onDrop(event) {        
        event.preventDefault(); 
        this.processSelectedFiles(event.dataTransfer.files);
    }

    onFileSelect(event) {
        this.processSelectedFiles(event.target.files);
    }

    continueToQuote()
    {
        //if there are files to upload 
        if(this.hasUnsavedFiles()){
            this.UploadFiles(() => {
                this.visible = false;
                this.uploadComplete.emit(false);
            });
        }
        else
        {
            this.visible = false;
            this.uploadComplete.emit(false);
        }
    }

    processSelectedFiles(selectedFiles: FileList) {

        for (let i = 0; i < selectedFiles.length; i++) {
            if(selectedFiles[i].size > this.maxFileSize) {
                this.msgs.push({
                    severity: 'error',
                    summary: this.invalidFileSizeMessageSummary.replace('{0}', selectedFiles[i].name),
                    detail: this.invalidFileSizeMessageDetail.replace('{0}', this.formatSize(this.maxFileSize))
                });
                this.fileSizeConfirmation(selectedFiles[i].name);
            }
             else {
                this.checkDuplicateFileNames(selectedFiles[i]);    
            }
        }
    }

    fileSizeConfirmation(fileName: string) {
        //this is called when a user attempts to upload a file that exceeds the maximum file size. 
        this.confirmationService.confirm({
            header: 'File Exceeded Maximum File Size!',
            message: fileName + ' exceeds maximum file size of ' + this.formatSize(this.maxFileSize) + '. File will NOT be added!',
            key: 'fileUpload',
            rejectVisible: false,
            acceptLabel: 'OK'
        });
    }

    //this is now only checking an individual file NOT an array of files
    checkDuplicateFileNames(fileToUpload: File) {
    //Checks to see if there are duplicate files. Currently gets called in the onFileSelect and onDrop functions.
            this.dupCheckNotSent  = this.files.find(f => f.name.substring(0, f.name.lastIndexOf(".")) == fileToUpload.name.substring(0, fileToUpload.name.lastIndexOf(".")) && ((f.irstatus == 0) || (!f.irstatus)));
            this.dupCheckSentToIR = this.files.find(f => f.name.substring(0, f.name.lastIndexOf(".")) == fileToUpload.name.substring(0, fileToUpload.name.lastIndexOf(".")) && f.irstatus == 1);
            // dupCheckNotSent will return true if the user submits a duplicate file but hasn't sent either to UW yet. 
            // dupCheckSentToIR will return true if a user tries to upload a duplicate file that has already been sent to UW. 
            if (this.dupCheckSentToIR) {
                this.msgs.push(
                    {severity:'error'
                    , summary:'Error Message'
                    , detail:this.dupCheckSentToIR.name.toUpperCase() + ' already exists and sent to underwriting. Please update attachment name.'
                });
                return false;
            }
            else if(this.dupCheckNotSent) {
                this.confirmationService.confirm({
                    header: "Are you sure?",
                    message: this.dupCheckNotSent.name.toUpperCase() + ' already exists. Do you want to replace it?',
                    key:'fileUpload',
                    accept: () => {
                        this.replaceFile(this.dupCheckNotSent.id);
                        this.addNewFile(fileToUpload, null);
                    }
                });
            }
            else {
                this.addNewFile(fileToUpload, null);
                //this.UploadFiles();
            }
    }

    formatSize(bytes) {
        //used to display the size of the data for each file, as well as calculating the max file size.
        if (bytes == 0) {
            return '0 B';
        }
        var k = 1000,
            dm = 0,
            sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
            i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    };

    //
    hasFiles() {
        return this.files && this.files.length > 0;
    };

    // this function can be used to determine whether or not "Send Attachments to Underwriting Now" button should be greyed out. 
    hasNewFiles(){   
        // this function is used to check if there are new files added to the array, regardless of "sent to underwriting" status or uploaded status.
        if(this.files.find(f => !f.irstatus || f.irstatus === undefined )){
            //this.allFilesSent = false; 
            return true;
        }  
        return false;
    }

    hasUnsavedFiles(){
        //this function is used to check if there are any new files that haven't been uploaded yet. Used for "close()" function.
        for( let fl of this.files){
            if(fl.irstatus === undefined){
                return true; 
            }
        }
        return false; 
    }

    
    addNewFile(event, index){    
    //used when the user needs to confirm whether or not they want the file added. This occurs when there is a duplicate file.        
        //console.log("addNewFile event: ", event);    
        this.files.push(event);
        //console.log("addNewFile files: ", this.files);
    }

    //
    replaceFile(id:number){
        // this function is used when the user wants to replace a file that was already sent to UW. 
        let index = this.files.findIndex(f => f.id === this.dupCheckNotSent.id);
        this.files.splice(index, 1);
    }

    //
    getAllFiles(qid: string) {
    //this function calls the upload Service's getAllFiles function, which is an API call that gets the metadata of all the files.
    // seems to just be used for testing. 
        this.uploadService.getAllFiles(qid)
            .subscribe(data => {
                this.fileMetaArray = data
                 var test = this.fileMetaArray.map(function(i) {
                    return { id:i.ID, name: i.FILENAME, size: i.FILESIZE, description: i.DESCRIPTION, status: i.STATUS, irstatus: i.SENT_TO_IMGRIGHT}
                });
                this.files = test;                
            }, error => {
                //console.log(error);
        });
    }

    funcFileClicked(id) {
        // called when the user clicks on the file name after they have uploaded a file. 
        this.uploadService.getSavedFile(id)
            .pipe(finalize(() => this.GetFileCheck()))
            .subscribe(data => {
                this.fileMeta = data
            }, error => {
                //console.log(error);
            });
    }


    UploadFiles(performUponCompletion) {
        let postFileObservables:Observable<any>[] = [];
        this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Uploading Files', detail: "Uploading Files...", event: "start" });
        for (let fl of this.files) {

            if (!fl.status && (fl.size < this.maxFileSize)) {
                postFileObservables.push(this.uploadService.postFile(fl, fl.description, this.Quote.QUOTEPOLICYINFORMATION, fl.irstatus, fl.id))
            }
        }

        forkJoin(postFileObservables).pipe(finalize(() => this.complete(true)))
        .subscribe(data => {
            if (data[0].toString().substring(0, 5).toUpperCase() == "ERROR")
            {
                this.migsystemservice.notifySystemNotification({ severity: 'error', summary: 'Files Failed To Upload', detail: data[0].toString(), event: "end" });
                return;
            }
            this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Files Uploaded', detail: "Files Uploaded!", event: "end" });
            performUponCompletion();
        }, error => {
            //this.msgs = [];
            //this.msgs.push({ severity: 'error', summary: "Error", detail: error });
            
            return false;
        });
    }

    SendAttachmentNoticeToUW() {
        if (this.hasUnsavedFiles())
        {
            this.UploadFiles(() => { this.callSendAttachmentNoticeToUwApi(); });
            return;
        }

        this.callSendAttachmentNoticeToUwApi();
    }
    
    callSendAttachmentNoticeToUwApi(){
        this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Notice to UW', detail: "Sending Attachments to Underwriting...", event: "start" });
        this.quoteService.SendAttachmentNoticeToUW(this.Quote.QUOTEPOLICYINFORMATION)
        .subscribe(	updatedFilesArray => {

            var mappedFilesArray = updatedFilesArray.map(function(i) {
                return { id:i.ID, name: i.FILENAME, size: i.FILESIZE, description: i.DESCRIPTION, status: i.STATUS, irstatus: i.SENT_TO_IMGRIGHT}
            });
            
            this.files = mappedFilesArray;
            this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Notice to UW', detail: "Complete! - Attachments sent to Underwriting!", event: "end" });
            this.cd.detectChanges();
        });
    }

    //
    remove(event, index?: number){
        //called when user clicks the Delete button.
        if(this.files[index].id == null || this.files[index].id == undefined){
            this.files.splice(index, 1);
        }
        else{
            this.confirmationService.confirm({
                header: "Are you sure?",
                message: 'Are you sure you want to delete' + this.files[index].name + '?',
                key:'fileUpload',
                accept: () => {
                    this.removeID = this.files[index].id;
                    this.fileToRemove = this.files[index];
                    
                    this.uploadService.deleteFile(this.fileToRemove,this.removeID,this.Quote.QUOTEPOLICYINFORMATION)
                        .pipe(finalize(() => this.complete(true)))
                        .subscribe(data => {
                            this.files.splice(index, 1);
                            return data;

                        }, error => {
                            this.msgs = [];
                            this.msgs.push({ severity: 'error', summary: "Error", detail: error });                    
                            //console.log(error);
                            return false;
                        });
                }
            });
            
            
        }
        //this.checkIRstatus();
    }

    deleteAllFiles(event){
        //Get this to delete files only if they haven't been sent to underwriting yet. Must delete from the "Files" list, as well as the graph for the SQL table.
        let filesToDelete: any[] = _.filter(this.files, fileInfo => { return (fileInfo.irstatus==0 || fileInfo.irstatus==undefined); });
        this.deleteFileCount = filesToDelete.length;
        
        if (this.deleteFileCount == 0)
            return;

        this.confirmationService.confirm({
            header: "Are you sure?",
            message: "You are about to delete " + this.deleteFileCount + " files. Are you sure?",
            key:'fileUpload',
            accept: () => {
                let deleteFileObservables:Observable<any>[] = [];
                this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Deleting ' + this.deleteFileCount + ' Files', detail: 'Deleting ' + this.deleteFileCount + ' Files', event: "start" });
                
                for (let i = 0; i < filesToDelete.length; i++) {

                    if (filesToDelete[i].id == null || filesToDelete[i].id == undefined) {
                        this.files = _.difference(this.files, [filesToDelete[i]]);
                        continue;
                    }
                    this.removeID = filesToDelete[i].id;
                    this.fileToRemove = filesToDelete[i];

                    deleteFileObservables.push(this.uploadService.deleteFile(this.fileToRemove, this.removeID, this.Quote.QUOTEPOLICYINFORMATION));
                }

                if (deleteFileObservables.length == 0) {
                    this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Deleted ' + this.deleteFileCount + ' Files!', detail: 'Deleted ' + this.deleteFileCount + ' Files!', event: "end" });
                    this.cd.detectChanges();
                    return;
                }

                forkJoin(deleteFileObservables).pipe(finalize(() => this.complete(true)))
                .subscribe(data => {
                    this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Deleted ' + this.deleteFileCount + ' Files!', detail: 'Deleted ' + this.deleteFileCount + ' Files!', event: "end" });
                    this.files = _.difference(this.files, filesToDelete);
                    this.cd.detectChanges();
                    return data;

                }, error => {
                    this.msgs = [];
                    this.msgs.push({ severity: 'error', summary: "Error", detail: error });                    
                    return false;
                });
            }
        });
        
    }

    checkIRstatus(){
        if(this.files){
            for(let fl of this.files){
                if(fl.irstatus == 0 || fl.irstatus == undefined){
                    this.allFilesSent = false; 
                    return;
                }
                else{
                    this.allFilesSent = true;
                }
            }
            
        }
    }


    // setUWValue(event:Event, index: number){
    //     if(event){
    //         this.files[index].irstatus=1;
    //     }
    //     else{
    //         this.files[index].irstatus=0;
    //     }
    //     console.log("irstatus?: ", this.files[index].irstatus);
    // }

    complete(type){

        if(type){
            this.uploadComplete.emit(true);
        }
        else{
            this.uploadComplete.emit(false);
        }
        
        return false;
    }

    close() {
    // called when the user clicks the Close Button. When there are files that haven't been saved yet, a confirmation dialog will prompt the user if they are sure. 
    // We will need to change this implementation, because we will no longer require the files to be saved before closing. 
        if (this.hasUnsavedFiles()) {
            this.confirmationService.confirm({
                header: "Are you sure?",
                message: 'Recently added attachments will not be saved, do you wish to continue?',
                key:'fileUpload',
                accept: () => {
                    this.visible = false;
                    this.uploadComplete.emit(false);
                }
            });
        } else {
            this.visible = false;
            this.uploadComplete.emit(false);
        }
        this.msgs = [];
    }

    GetFileCheck() {

        try {

            var contentType;
            var filetype = this.fileMeta.FILENAME.substring(this.fileMeta.FILENAME.lastIndexOf(".") + 1);

            switch (filetype) {
                case 'pdf':
                    contentType = 'application/pdf'
                    break;
                case 'jpg':
                    contentType = 'image/jpeg'
                    break;
            }

            var byteCharacters = atob(this.fileMeta.FILEBINARY);
            //
            var byteNumbers = new Array(byteCharacters.length);
            for (var i = 0; i < byteCharacters.length; i++) {
                byteNumbers[i] = byteCharacters.charCodeAt(i);
            }
            var byteArray = new Uint8Array(byteNumbers);

            //var blob = new Blob([byteArray], { type: 'application/octet-stream' }); <-- to download to browser
            var blob = new Blob([byteArray], { type: contentType }); // <-- opens in browser window

            let newWin;
            if (navigator.appVersion.toString().indexOf('.NET') > 0) {
                newWin = (window.navigator as any).msSaveBlob(blob, this.fileMeta.FILENAME);
                // const nav = (window.navigator as any);
                // if (nav.msSaveOrOpenBlob) {
                //     nav.msSaveOrOpenBlob(data, filename);
                // }
                //newWin = window.navigator.msSaveBlob(blob, this.fileMeta.FILENAME);
            }
            else {
                let url = window.URL.createObjectURL(blob);
                newWin = window.open(url);
            }         
        }
        catch (error) {
            return 0;
        }

    }
}


@NgModule({
    imports: [
        FormsModule,
        CommonModule,
        MIGProgessbarModule,
        //SharedModule,
        //ButtonModule,
        MessageModule,
        MessagesModule,
        //InputTextareaModule,
        TooltipModule,
        ConfirmDialogModule,
        PanelModule,
        MIGCheckboxModule,
        MIGButtonModule
    ],
    declarations: [
        MIGFileUpload,
    ],
    exports: [
        MIGFileUpload,
        CommonModule,
        MIGProgessbarModule,
        //SharedModule,
        //ButtonModule,
        MessageModule,
        MessagesModule,
        //InputTextareaModule,
        TooltipModule,
        ConfirmDialogModule,
        PanelModule
    ],
    providers: [
        FileuploadService,
        //DialogService,
        //DynamicDialogRef,
        //DynamicDialogConfig
    ]
})
export class MIGFileUploadModule extends FileUploadModule {

}
