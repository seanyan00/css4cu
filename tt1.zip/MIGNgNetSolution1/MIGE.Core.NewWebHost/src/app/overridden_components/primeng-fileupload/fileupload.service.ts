
import { throwError as observableThrowError, Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule, HttpRequest, HttpHeaders, HttpParams } from '@angular/common/http';

import 'rxjs';

import { AuthService } from '@auth/auth.service';
import { TokenResponse } from '@auth/tokenresponse.class';

import { FileMetaData } from '@classes/FileUpload/FileMetaData';
import { environment } from '@environment/environment';

import { map, tap, catchError, retry, finalize } from 'rxjs/operators';
import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';


@Injectable()
export class FileuploadService {

	tokenResponse: TokenResponse;
	private serverAPI = environment.proxyPath;

	constructor(
		private httpClient: HttpClient,
		private authService: AuthService,
	) { }

	//
	getSavedFile(id: number): Observable<any> {

		let fileRequest: FileMetaData = {

			ID: id,
			FILENAME: '',
			FILESIZE: 0,
			FILEBINARY: null,
			QUOTEID: (this.tokenResponse == null) ? '' : this.tokenResponse.QuoteId,
			DESCRIPTION: '',
			AGENTNUMBER: '',
			STATUS: '',
			SENT_TO_IMGRIGHT: 0,
			CREATEDBY: '',
			CREATEDATE: '',
			MODIFIEDBY: '',
			MODIFIEDDATE: ''
		}

		//
		const httpOptions = {
			headers: new HttpHeaders()				
				.set('RequestPath', 'FileDownload')				
		};

		return this.httpClient.post(this.serverAPI + 'ProxyPost', fileRequest, httpOptions)
			.pipe(
				map(res => <FileMetaData>res),
				catchError((e) => this.handleError(e))
			);
	}

	//
	getAllFiles(qid: string): Observable<any[]> {

		let fileRequest: FileMetaData = {

			ID: 0,
			FILENAME: '',
			FILESIZE: 0,
			FILEBINARY: null,
			//QUOTEID: (this.tokenResponse == null) ? '' : this.tokenResponse.QuoteId,
			QUOTEID: qid,
			DESCRIPTION: '',
			AGENTNUMBER: '',
			STATUS: '',
			SENT_TO_IMGRIGHT: 0,
			CREATEDBY: '',
			CREATEDATE: '',
			MODIFIEDBY: '',
			MODIFIEDDATE: ''
		}

		//
		const httpOptions = {
			headers: new HttpHeaders()
				.set('RequestPath', 'GetAllFiles')
		};

		return this.httpClient.post(this.serverAPI + 'ProxyPost', fileRequest, httpOptions)
			.pipe(
				map(res => <FileMetaData[]>res),
				tap(data => {
					//console.log('Return All Files => ' + JSON.stringify(data))
				}),
				catchError((e) => this.handleError(e))
			);
	}

	//FOR TESTING
	getUploadedFilesSample(qid: string): Observable<any>{
		let fileRequest: FileMetaData = {

			ID: 0,
			FILENAME: '',
			FILESIZE: 0,
			FILEBINARY: null,
			//QUOTEID: (this.tokenResponse == null) ? '' : this.tokenResponse.QuoteId,
			QUOTEID: qid,
			DESCRIPTION: '',
			AGENTNUMBER: '',
			STATUS: '',
			SENT_TO_IMGRIGHT: 0,
			CREATEDBY: '',
			CREATEDATE: '',
			MODIFIEDBY: '',
			MODIFIEDDATE: ''
		}
        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'RequestPath': 'GetDropDownValues/'
            })
        };

        return this.httpClient.get("./assets/sample_data/uploadedfiles.json", httpOptions)
		.pipe(
			map(res => <FileMetaData[]>res),
			tap(data => {				
			}),
			catchError((e) => this.handleError(e))
		);
    }

	//
	postFile(fileToUpload: File, desc: string, qpi: QUOTEPOLICYINFO, irstatus:boolean, fileid:any): Observable<any> {

		this.tokenResponse = this.authService.getAuth();
		
		const formData: FormData = new FormData();
		formData.append('files', fileToUpload, fileToUpload.name);
				
		//to add in header
		let fileMeta: FileMetaData = {

			ID: (fileid != 'undefined' && fileid != null) ? fileid : 0,
			FILENAME: fileToUpload.name,
			FILESIZE: fileToUpload.size,
			FILEBINARY: null,
			//QUOTEID: (this.tokenResponse == null) ? '' : this.tokenResponse.QuoteId,
			QUOTEID: qpi.QUOTEPOLICYNUMBER,
			DESCRIPTION: desc,
			AGENTNUMBER: qpi.AGENTNUMBER,
			STATUS: (irstatus) ? 'true' : 'false',
			SENT_TO_IMGRIGHT: (irstatus) ? 1 : 0,
			CREATEDBY: (this.tokenResponse == null) ? '' : this.tokenResponse.UserName,
			CREATEDATE: new Date().toLocaleDateString(),
			MODIFIEDBY: (this.tokenResponse == null) ? '' : this.tokenResponse.UserName,
			MODIFIEDDATE: new Date().toLocaleDateString()
		};
			
		//NEEDED IE FIX FOR SENDING
		let params = new HttpParams();
		Object.keys(fileMeta).forEach(function (key) {
			params = params.append(key, fileMeta[key]);
		});

		const httpOptions = {
			headers: new HttpHeaders()
				//.set('Content-Type', 'multipart/form-data') // <-- do not use
				.set('enctype', 'multipart/form-data')
				.set('RequestPath', 'FileUpload')
				//.set('FileMetaData', JSON.stringify(fileMeta))<-- DOES not work in IE!
				.set('FileMetaData', params.toString()) //<-- see fix above
		};
		
		return this.httpClient.post(this.serverAPI + 'ProxyFileUpload', formData, httpOptions)
			.pipe(
				map(res => <FileMetaData>res),
				tap(data => {
					//return fileToUpload.name;					
				}),
				catchError((e) => this.handleError(e))
			);
		//return null;
	}

	//
	deleteFile(fileToDelete: File,fileid:any,qpi: QUOTEPOLICYINFO): Observable<any>{
		
		this.tokenResponse = this.authService.getAuth();
		
		//to add in header
		let fileMeta: FileMetaData = {

			ID: (fileid != 'undefined') ? fileid : 0,
			FILENAME: fileToDelete.name,
			FILESIZE: fileToDelete.size,
			FILEBINARY: null,
			//QUOTEID: (this.tokenResponse == null) ? '' : this.tokenResponse.QuoteId,
			QUOTEID: qpi.QUOTEPOLICYNUMBER,
			DESCRIPTION: '',
			AGENTNUMBER: qpi.AGENTNUMBER,
			STATUS: '',
			SENT_TO_IMGRIGHT: 0,
			CREATEDBY: (this.tokenResponse == null) ? '' : this.tokenResponse.UserName,
			CREATEDATE: new Date().toLocaleDateString(),
			MODIFIEDBY: (this.tokenResponse == null) ? '' : this.tokenResponse.UserName,
			MODIFIEDDATE: new Date().toLocaleDateString()
		};

		const httpOptions = {
			headers: new HttpHeaders({
				'Content-Type': 'application/json',
				'RequestPath': 'FileDelete/',
				"Access-Control-Allow-Origin": "*"
			})
		};
		return this.httpClient.post(this.serverAPI + 'ProxyPost', fileMeta, httpOptions)
			.pipe(
				retry(3),
				map(response => <any>response),
				catchError(this.handleError));
	}

	//
	private handleError(error: any) {	
		return observableThrowError(error.message || 'Server error');
	}

}

