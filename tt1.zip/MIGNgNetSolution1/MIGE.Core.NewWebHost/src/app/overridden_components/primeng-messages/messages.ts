import { Component, ElementRef, EventEmitter, Input, Output, OnInit } from '@angular/core';
import { MessagesModule } from 'primeng/messages';
@Component({
    selector: 'mig-messages',
    templateUrl: './messages.html',
    styleUrls: ['./messages.css']
})

/*
* extended 5-22-2018 by MG
* Adds onclick event to msg.description to navigate to section mssage occured at
* Adds ability to style each message individually
* Adds ability to close each message individually
*/
export class MIGMessages extends MessagesModule {
	@Input() set value(value: any[]) {
		let count: number = 0;
		let tmp: any[] = [];
		this.row = [];
		for (let a = 0; a < value.length; a++) {
			if (count < 2) {
				tmp.push({ cell: value[a] });
				count++;
			} else {
				tmp.push({ cell: value[a] });
				this.row.push(tmp);
				tmp = [];
				count = 0;
			}
		}
		if (tmp.length) { this.row.push(tmp); }

		//console.log(this.row);
	}

valueChange: any;
    messageService: any;
    @Input() closable: boolean = true;
    enableService: any;
    subscription: any;

	row: any[] = [];

    constructor() {
        super();
	}

    hasMessages() {
        return (this.value && this.value.length > 0 ? true: false);
    };

    getSeverityClass() {
        return this.value[0].severity;
    };

    clear(event, idx) {
        this.value.splice(idx, 1);
        event.preventDefault();
    };

    icon(msg) {
        var icon = null;
        if (this.hasMessages()) {
            switch (msg.severity) {
                case 'success':
                    icon = 'fa-check';
                    break;
                case 'info':
                    icon = 'fa-info-circle';
                    break;
                case 'error':
                    icon = 'fa-close';
                    break;
                case 'warn':
                    icon = 'fa-warning';
                    break;
                default:
                    icon = 'fa-info-circle';
                    break;
            }
        }
        return icon;
    }

    Messages(messageService) {
        this.closable = true;
        this.enableService = true;
    }
}
