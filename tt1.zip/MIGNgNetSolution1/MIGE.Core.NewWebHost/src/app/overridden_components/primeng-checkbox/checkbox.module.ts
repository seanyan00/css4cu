import { MIGCheckbox } from './checkbox';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TooltipModule } from 'primeng/tooltip';

@NgModule({
	imports: [CommonModule, TooltipModule],
	declarations: [MIGCheckbox],
	exports: [MIGCheckbox]
	})
export class MIGCheckboxModule { }
