import { Component, ElementRef, Input, forwardRef, ChangeDetectorRef } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { Checkbox } from 'primeng/checkbox';

@Component({
	selector: 'mig-checkbox',
	templateUrl: './checkbox.html',
	styleUrls: ['./checkbox.css'],
	providers: [
		{
			provide: NG_VALUE_ACCESSOR,
			multi: true,
			useExisting: forwardRef(() => MIGCheckbox),
		}
	]
})

export class MIGCheckbox extends Checkbox  {

	@Input() migEditable?: boolean = true;
	
	// propagateChange: any = () => { };
	// writeValue(value: any) { if (value) { this._value = value; } }
	// registerOnChange(fn) { this.propagateChange = fn; }
	// registerOnTouched(fn: () => void): void { }
	//onChange(event) { this.propagateChange(event.target.value); }
	

}
