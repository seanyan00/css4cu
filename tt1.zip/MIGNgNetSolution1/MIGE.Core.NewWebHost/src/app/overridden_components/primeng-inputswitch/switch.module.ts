import { MIGInputSwitch } from './switch.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DomHandler } from 'primeng/dom';

@NgModule({
	imports: [CommonModule],
	declarations: [MIGInputSwitch],
  exports: [MIGInputSwitch],
  providers: [DomHandler]
	})
export class MIGInputSwitchModule { }
