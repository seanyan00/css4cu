import { MenuItem } from 'primeng/api';
/**
 * Extended 2-1-2018 MG
 */
export interface MIGMenuItem extends MenuItem {
    label?: string;
    icon?: string;
    color?: string; // added 2-1-2018 MG to set color of item in MIGSteps
    command?: (event?: any) => void;
    adjust?: any;
    errors?: any[];
    // model?: any;
    // url?: string;
    // routerLink?: any;
    // queryParams?: {
    //     [k: string]: any;
    // };
    // items?: MIGMenuItem[] | MIGMenuItem[][];
    // expanded?: boolean;
    // disabled?: boolean;
    // visible?: boolean;
    // target?: string;
    // routerLinkActiveOptions?: any;
    // separator?: boolean;
    // badge?: string;
    // badgeStyleClass?: string;
    // style?: any;
    // styleClass?: string;
    // title?: string;
    // id?: string;
}
