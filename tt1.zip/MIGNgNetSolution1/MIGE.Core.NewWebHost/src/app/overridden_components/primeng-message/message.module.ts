import { MIGMessage } from './message.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

@NgModule({
	imports: [CommonModule],
	declarations: [MIGMessage],
	exports: [MIGMessage]
	})
export class MIGMessageModule { }
