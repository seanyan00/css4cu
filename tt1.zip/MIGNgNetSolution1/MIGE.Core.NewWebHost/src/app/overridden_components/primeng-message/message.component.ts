import { Component, ElementRef, Input, forwardRef } from '@angular/core';

import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { UIMessage } from 'primeng/message';

@Component({
	selector: 'mig-message',
	templateUrl: './message.component.html',
	providers: [
		{
			provide: NG_VALUE_ACCESSOR,
			multi: true,
			useExisting: forwardRef(() => UIMessage),
		}
	]
})

export class MIGMessage extends UIMessage {
	constructor() {
		super();
	}
	@Input() severity: any;
	@Input() text: any;
	@Input() migEditable?: boolean = true;

	_value = '';
	propagateChange: any = () => { };
	writeValue(value: any) { if (value) { this._value = value; } }
	registerOnChange(fn) { this.propagateChange = fn; }
	registerOnTouched(fn: () => void): void { }
	onChange(event) { this.propagateChange(event.target.value); }

}
