export interface ILocation { 
    
    LOCNUM: string;
    BLDNUM: string;
	
}