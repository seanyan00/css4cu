import { ADDITIONALINSURED } from '@classes/Common/ADDITIONALINSUREDS';

export interface IAdditionalInsureds {
		//delete additional insureds for scheduled items --- need to see how many are in there and then delete any others
		deleteAdditionalInsureds(additionalInsureds: ADDITIONALINSURED [], addType: string, count: number, secondAddType?: string, secondCount?: number);
		changeAddType(fromAddType: string, toAddType: string);
		//update for Blanket Additional Insureds.
		updateAdditionalInsured(addType: string, updateRecord: boolean);

		
}