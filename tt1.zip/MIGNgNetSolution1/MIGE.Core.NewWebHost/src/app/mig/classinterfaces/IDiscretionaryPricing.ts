export interface IDiscretionaryPricing {

    

}