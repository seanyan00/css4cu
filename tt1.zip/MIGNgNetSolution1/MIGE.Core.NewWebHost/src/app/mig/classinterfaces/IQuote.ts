import { POLICYTRANS } from '@classes/Common/POLICYTRANS';
import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';
import { UWQUESTIONROOT } from '@classes/Common/UWQuestionClasses/UWQUESTIONROOT';
import { CONTACTINFOLOSSES } from '@classes/Common/CONTACTINFOLOSSES';
import { ADDITIONALINSURED } from '@classes/Common/ADDITIONALINSUREDS';
import { UWREFERRALS } from '@classes/Common/UWREFERRALS';
import { GLPFORMDATA } from '@classes/Common/GLPFORMDATA';
import { ILocation } from '@interfaces/ILocation';
import { IMortgagee } from '@interfaces/IMortgagee';
import { IScheduledItem } from '@interfaces/IScheduledItems';
import { from } from 'rxjs';
import { QUOTEPERSONALINFO } from '@classes/CTR/QUOTEPERSONALINFO';
import { UWQUESTIONSCATEGORY } from '@classes/Common/UWQuestionClasses/UWQUESTIONCATEGORY';
import { LOSSCLAIM } from '@classes/Common/LOSSCLAIM';
import { MenuClass } from '@root/system/menu/menu';
import { CFPMORTGAGEE } from '@classes/CTR/CFPMORTGAGEE';

/******************************************************************************************************
     * PROGRAM DESCRIPTION  - IQuote interface for all product lines
     * NOTES                - RRF 2019-07-11 - Added UWQUESTIONSCATEGORY property since UWQUESTIONS will apply to all product lines.
****************************************************************************************************/


export interface IQuote {

    POLICYTRANS: POLICYTRANS;
    QUOTEPOLICYINFORMATION: QUOTEPOLICYINFO;

    CONTACTINFOLOSSES: CONTACTINFOLOSSES;
    LOSSCLAIMS: LOSSCLAIM[];
    QUOTEPERSONALINFO: QUOTEPERSONALINFO;
    
	UWREFERRALS: UWREFERRALS[];
	ADDITIONALINSUREDS: ADDITIONALINSURED[];
    GLPFORMDATA: GLPFORMDATA[];
    UWQUESTIONSCATEGORY: UWQUESTIONSCATEGORY[];

    SaveQuote(): boolean;
    GetQuote(): boolean;
    InitializeLoss(): boolean;

    GetLocations(coverage: string) : ILocation[];

    GetMortgagees(coverage: string) : IMortgagee[];
    DeleteMortgagee(coverage: string, index: number, coverageType: string) : void

    //SaveMortgagee(coverage: string, mortgageList: IMortgagee[], coverageType: string) : void

    SaveMortgagee(coverage: string, mortgage: CFPMORTGAGEE, coverageType: string) : void
    
    GetScheduledItems(coverage: string) : IScheduledItem[]

    AddAdditionalCoverage(coverage: string): void
    RemoveAdditionalCoverage(coverage: string): void
    
    DisableScheduleField(scheduleStateMinimums:any): boolean;
    DisableIrpmField(): boolean;
    ShowNjDeregField(deregFlag:string): boolean;
    ShowPaDeregField(deregFlag:string): boolean;
    
    GetDPScheduleValue(): number;
    GetDPIrpmValue(): number;
    //GetDPNjDeregValue(): number;
    GetDPNjPaDeregValue(): number;

    SetDPScheduleValue(value: number);
    SetDPIrpmValue(value: number);
    //SetDPNjDeregValue(value: number);
    SetDPNjPaDeregValue(value:number);

    ApplyDiscretionaryPricing(originlPremium: number): number;

    UpdateQuoteStatus(menuClass: MenuClass, quoteChangesDetected: boolean): void;

    HasAdditionalInsureds(): boolean;
    HasPropertyCoverage(): boolean;

    changeAddType(fromAddType: string): void
    updateERISA(data: any): void
    deleteERISA(): void
}
