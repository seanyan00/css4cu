import { IBRR } from './IBRR';

export interface IProcessBRR {
    ProcessBRR(): IBRR;
}