export interface IMortgagee {
	/* THIS IS A DTO CLASS THIS WILL BE USED FOR BOTH
       CFP MORTGAGEE AND IMP MORTGAGEE*/
	
	   // KEYS
	TRANS: string;
	POLICY: string;
	EFFDTE: number;
	COVERG: string;
	RCDTYP: number;
	EDSDTE: number;
	EDSNO: number;
	
	//Building Number
	BLDNUM: string;
	//Location Number
	LOCNUM: string;
	//Mortgage Number
	MRTGNO: string;
	// END KEYS
	MRTGTP: string;

	// Mortgage Coverage
	MRTGTPCOVERG: string;
	// Mortgagee Name
	MRTGNM: string;
	// Second Mortgagee Name
	MRTNM2: string;
	// Mortgagee Address Line 1
	MRTGA1: string;
	// Mortgagee Address Line 2
	MRTGA2: string;
	// Mortgagee Address Line 3
	MRTGA3: string;
	// Mortgagee City
	MRTGCT: string;
	// Mortgagee State
	MRTGST: string;
	// Mortgagee Zipcode
	MRTGZP: string;
	// Mortgagee Description
	MRTITD: string;
	
	RECORDSTATE: string;
}