export interface IBRR {
    // Business Rules Result
	success: boolean;
	errors: any[];
}