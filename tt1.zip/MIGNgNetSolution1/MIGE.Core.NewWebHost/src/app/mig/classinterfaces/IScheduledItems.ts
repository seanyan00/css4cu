export interface IScheduledItem{
    ITEMNO: string;
    ITEMDC: string;
    ITMMYR: number;
}