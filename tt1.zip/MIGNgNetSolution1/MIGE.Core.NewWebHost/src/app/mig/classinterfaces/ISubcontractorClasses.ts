export interface ISubcontractorClasses {
    ID: number,
    subcontractorClassCode: string,
    subcontractorClassDesc: string
}