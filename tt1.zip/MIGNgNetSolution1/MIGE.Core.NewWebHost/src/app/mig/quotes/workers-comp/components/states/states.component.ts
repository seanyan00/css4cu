/* ****************************************************************************************************
* PROGRAM DESCRIPTION  - States 
* NOTES: 
* - This component is the component for a specific State on the menu step; After the module builds the menu steps, the state component builds, along with it's associated locations and business classes.
* 
* BUG FIXES: 
* 6/1/21: Fixed issue where Experience Mod form control was defaulting to 0, not blank (TFS 2233) -JTL
* 6/1/21: ARAP now defaults to blank, not 0. Also applied validation (TFS 2258) - JTL
* 6/7/21: Now able to delete a State and its associated locations, business classes, and individuals (TFS 2241) -JTL 
* 6/15/21: Fixed issue where first location on a new quote wasn't prefilling from LANSA. (TFS 2290) -JTL 
* 6/16/21: Fixed issue where business class selected from LANSA wasn't prefilling on first location (TFS 2291) - JTL
* 6/22/21: Fixed issue where Experience mod was clearing out when typing in a number that started with 0. (TFS 2296) -JTL
* 7/13/21: Fixed issue where Suite Number wasn't getting mapped properly on location prefilled from LANSA (TFS 2326) -JTL
* 8/3/21: Fixed issue where multiple class code requests was causing backend to bomb out. (TFS 2372) -JTL
* 8/24/21: Fixed issue where both the experience mod and merit rate factor were disabled (TFS 2383) -JTL 
* 9/3/21: Fixed issue where experience mod wasn't disabling when a merit rate was entered (TFS 2237) -JTL
* 9/20/21: Fixed issue where the class code was prefilling from an incompatible state (TFS 2426) -JTL
* 9/21/21: First location is now opened by default when loading States screen (TFS 2439) -JTL
* 9/23/21: Fixed issue with ARAP Factor not zeroing out when no Experience mod (TFS 2443) -ZJG
* 10/8/21: Added statement onInit to ensure our DWCP130.APPDIS is set properly (TFS 2476) - JTL
* 10/28/21: Instead of defaulting prefilled classcode's BLDNUM to "001", now use QUOTEPOLICYINFORMATION.CLASSCODEINFO.SICCDE (TFS 2504) -JTL
* 11/10/21: Fixed ARAP logic so that the validation will trigger properly if there is an error (TFS 2523) -JTL 
* 11/16/21: Set POLICYTRANS.CO to MPIC if the user switches state to Michigan (TFS 2526) -JTL
* 12/14/21: Removed setting of EXPMD1 in form group subscription, instead using (change) function in HTML (JIRA MSC-19672) -JTL 
* 12/17/21: Set the BoardFileNumber (INTRAR) in the expmod validation function using (change) function in HTML and make it optional field (JIRA MSC-19672) -ZJG
* 12/21/21: Created mask for experience mod that can hold 3 digits after the decimal (JIRA MSC-19861) -JTL
* 12/21/21: Set minimum boundary for experience mod from 0.7 to 0.07 (JIRA MSC-19866) -JTL 
* 12/29/21: Moved setting the DWCP130.DIAFCT to the init function to ensure that it is set when state is MA (JIRA MSC-19964) -ZJG
* 2/8/22: Fixed business class validation error after changing state (JIRA MSC-20938) -JTL
* 5/4/22: In MA quotes when blanking the ARAFCT field it was writing null to object graph. Used null check instead of blank string (JIRA MSC-23284) -ZJG
****************************************************************************************************/
import { ChangeDetectorRef, Component, Input, OnDestroy, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { GUIDE } from '@classes/common/BusinessClass/GUIDE';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { WCAIndividual } from '@classes/WCA/WCAIndividual';
import { WCALOCATIONS } from '@classes/WCA/WCALocations';
import { WCASTATES } from '@classes/WCA/WCAStates';
import { WCAClassExtended } from '@classes/WCA/WCCLASSEXTENDEDABSTRACT';
import { WCAQuote } from '@classViewModels/WCA/WCAQuote';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { Functions } from '@helpers/functions';
import { InputMasksClass } from '@helpers/masks';
import { MIGSystemService } from '@root/services/mig.service';
import { GuideService } from '@root/services/risk-appetite-guide.service';
import { MenuClass } from '@root/system/menu/menu';
import * as _ from 'lodash';
import { ConfirmationService } from 'primeng/api';
import { Subscription } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { MIGWCAStatesValidators } from './states.validators';


@Component({
  selector: 'mig-states',
  templateUrl: './states.component.html',
  styleUrls: ['./states.component.css']
})
//TODO: need to disable Experince Mod field when there is a merit rate factor.
export class StatesComponent implements OnInit, OnDestroy {
  @Input() quote: WCAQuote;
  stateSelectionOptions: any[]; // holds our dropdown options that determines which States we can select. 
  stateFormGroup: UntypedFormGroup;
  locationsFormGroup: UntypedFormGroup[] = []; //This array of formgroups contain the formGroup info for each location associated with our State. 
  businessClassFormGroup: UntypedFormGroup[] = [];
  FormGroupSubscription: Subscription;
  guideServiceSubscription: Subscription;
  nextClickSubscription: Subscription;
  doneClickSubscription: Subscription;
  stateObject: WCASTATES;
  menu: any;
  errors: any[] = [];
  guide: GUIDE[] = [];
  initialState: string; // used to store the initial State. If the user changes the state, and selects "No" in the confirmation dialog, we want the state to revert back to the initialState; 
  isEditingLocation: boolean = false; // flag that we set when the user clicks "Edit Location Address"
  migValidator: MIGWCAStatesValidators;
  nextClicked: boolean; 
  hasFactor: boolean;
  locations: WCALOCATIONS[] = [];

  constructor(
  public dropdowns: ContractorsDropDowns,
    public migRoles: MIGSecurityRoles,
    public migsystemservice: MIGSystemService,
    public guideService: GuideService,
    public menuClass: MenuClass,
    public formBuilder: UntypedFormBuilder,
    public masks: InputMasksClass,
    public confirmationService: ConfirmationService,
    public changeDetectorRef: ChangeDetectorRef,
    private func: Functions
  ) { }

  ngOnInit(): void {
    this.menu = this.menuClass.stepActiveObject;
      this.menu = this.menuClass.stepActiveObject;
      this.menu.forms = []; // on init, set the menu forms array to blank, we will be recreating these forms when we load the screen. 
      if (this.quote.STATES.length == 0)
      {
          this.menu.stateDataObject = this.quote.AddNewStateObject();
          this.stateObject = this.menu.stateDataObject;
          this.setupStateSelectionOptions(); // Determine the States that we can choose from
          if(this.stateObject.PRMSTE == ""){ // if entering a new quote, we need to prefill the PRMSTE with the insured's mailing address, but only if the agent is licensed in it.           
            this.stateObject.PRMSTE = this.stateSelectionOptions.filter(x=> x == this.quote.POLICYTRANS.ADDRESS.STATE) != null && this.quote.POLICYTRANS.ADDRESS.STATE != "34" ? this.quote.POLICYTRANS.ADDRESS.STATE : ""; 
            this.stateObject.COVERG = this.quote.POLICYTRANS.ADDRESS.STATE;
            this.menu.label = _.find(this.dropdowns.StatesFull, s => s["value"] == this.stateObject.COVERG).label; // When we change the State, we update the label on the left nav to the new state.
          }

          if(this.stateSelectionOptions.filter(x=> x == this.quote.POLICYTRANS.ADDRESS.STATE) != null && this.quote.POLICYTRANS.ADDRESS.STATE != "34"){ // if the state on their mailing address is a state that the agent is licensed in, we want to prefill the first location with their mailing address 
            this.stateObject.AddnewLocation();
            this.migsystemservice.notifyEditingLoc(true);
            let firstLocation = this.stateObject.LOCATIONS[0];
            firstLocation.LOCNUM = "001";
            firstLocation.COVERG = this.quote.POLICYTRANS.ADDRESS.STATE;
            firstLocation.LOCAD1 = this.quote.POLICYTRANS.ADDRESS.STREETNUMBER + " " + this.quote.POLICYTRANS.ADDRESS.STREETNAME;
            if(this.quote.POLICYTRANS.ADDRESS.ADDRESSLINE2 != ""){
              firstLocation.LOCAD2 = this.quote.POLICYTRANS.ADDRESS.ADDRESSLINE2; //+ " " + this.quote.POLICYTRANS.ADDRESS.SUITENUMBER; // waiting on Monica to determine whether or not we want to include the Suite number here.
            }     
            firstLocation.LOCST = this.quote.POLICYTRANS.ADDRESS.STATEFORMAT; // LOCST should be set to the 2 letter abbreviation for the state, not the number format -JTL
            firstLocation.LOCCTY = this.quote.POLICYTRANS.ADDRESS.CITY;
            firstLocation.LOCZIP = this.quote.POLICYTRANS.ADDRESS.ZIPCODE;
            if(firstLocation.COVERG == this.quote.POLICYTRANS.CANSTE){ // 9/20/21: if the state on the mailing address does not match the state on the account, we do not want to prefill the business class because it will be from the wrong state -JTL 
              if(this.quote.QUOTEPOLICYINFORMATION.CLASSCODEINFO.CLASSCODE != "NULL") // if the class code from our query returns null for whatever reason, do not add our business class.
              firstLocation.addNewBusinessClass(this.quote.QUOTEPOLICYINFORMATION.CLASSCODEINFO.CLASSCODE, this.quote.QUOTEPOLICYINFORMATION.CLASSCODEINFO.SICCDE, this.quote.QUOTEPOLICYINFORMATION.CLASSCODEINFO.DESCRIPTION, this.quote.QUOTEPOLICYINFORMATION.CLASSCODEINFO.ASLOB); // Adds the business class that was selected from LANSA. 10/28/21: added CLASSCODEINFO.SICCDE in seqno instead of default -JTL
            }
          }
          this.migsystemservice.notifyGetQuote(this.quote);
      }
      this.stateObject = this.menu.stateDataObject;
      this.setupStateSelectionOptions(); // Determine the States that we can choose from
      this.locations = this.stateObject.LOCATIONS.filter(x=> x.RECORDSTATE != "D");
      this.hasFactor = this.stateObject.MERFCT != 0 ? true : false; // set the hasFactor boolean flag to true or false, based on if there is a value selected in the Merit Rate Factor
      if(this.stateObject.EXPMD1 != 0 && this.hasFactor) { // fringe case/fail safe where there is an experience mod and merit rate factor. This shouldn't be possible, but if there is both, we remove the merit rate factor so the text elements aren't disabled
        this.hasFactor = false;
      }
      if(!this.displayConstructionDiscount()){ //if our state is not MA, NJ, NY, or PA, we want to make sure APPDIS is set to "N". Otherwise, APPDIS is determined on whether or not there is a value stored in Construction Discount. 
        this.stateObject.APPDIS = "N";
      }
      if(this.displayDIAAssesment()){ // Need to Write a 2 to the DWCP130 whenever PRMSTE is 20(MA) -3/12/2021 ZJG
        this.stateObject.DIAFCT = "2"; //Moved to init from form group subscription since users won't always edit the formgroup if state is MA 12/29/21
      }
      else{
        this.stateObject.DIAFCT = "";
      }
      if(this.stateObject.LOCATIONS.some(loc=> loc.LOCAD1 == "" && loc.LOCAD2 == "")){ // On init, if there is a location that doesn't have an address line 1 (or 2 to account for a PO BOX), turn on our Editing flag. 
        this.migsystemservice.notifyEditingLoc(true);
      } 
      this.migValidator = new MIGWCAStatesValidators();
      this.initialState = this.stateObject.PRMSTE; // gets the persisted state
      this.stateFormGroup = this.formBuilder.group({
          PremiumState: [this.stateObject.PRMSTE, this.migValidator.ValidateRequired("State", "State")],
          // ExperienceMod: [this.stateObject.EXPMD1 != 0 ? this.stateObject.EXPMD1 : ""],
          ExperienceMod: [this.stateObject.EXPMD1],
          //Intrastate Risk ID
          BoardFileNumber: [this.stateObject.INTRAR],
          //Construction Credit Percentage
          CreditPercentage: [this.stateObject.AVHRWG == 0 ? '' : this.stateObject.AVHRWG],
          //Merit Rate Factor
          RateFactor: [this.stateObject.MERFCT],
          //ARAP Factor
          ARAPFactor: [this.stateObject.ARAFCT == 0 ? '' : this.stateObject.ARAFCT],
          RECORDSTATE: [this.stateObject.RECORDSTATE],
          LOCNUM: [""],
          TYPE: "State"
      });

      this.menu.forms[0] = this.stateFormGroup; // set our menu's first form group to our stateFormGroup's data.
      this.setExpModValueAndValidators(this.stateObject.EXPMD1.toString()); // Establish Experience Modification validation.

      this.setCreditValueAndValidators(this.stateObject.AVHRWG); // Establish Credit Percentage validation
      this.setARAPValueAndValidators(this.stateObject.ARAFCT);
      this.setupStateSelectionOptions(); // Determine the States that we can choose from

      this.setupFormGroupValueChangesSubscription(); // Begin FormGroup Subscription
      this.nextClickSubscription = this.migsystemservice.subscribeNextClicked().subscribe(x=> { // 8/24/21: Added Subscriptions and unsubscribes because this was firing on the Individuals screen and causing issues -JTL
        this.nextClicked = true;
        // this.migsystemservice.notifyError(this.errors);
        this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive);
      });
      this.doneClickSubscription = this.migsystemservice.subscribeDoneClicked().subscribe(x=> { // 8/24/21: Added Subscriptions and unsubscribes because this was firing on the Individuals screen and causing issues -JTL
        this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive);
        //this.nextClicked = true;
      });

      var classrequest:any = {
        PRODUCT:		'WCA',
        STATE:			this.stateObject.COVERG,
        STATECODE: 		this.stateObject.COVERG,
        EFFDTE:	 		this.stateObject.EFFDTE,
        ENDDTE:		 	this.stateObject.EDSDTE,
        CDKEY1: 		'',
        CDKEY2:			'',
        CLASSCODE:		'',
        DESCRIPTION: 	'',
        FSTTRK: 		""
    }
    this.guideServiceSubscription = this.guideService.getGuide(classrequest) // gets our list of class codes for a given state.
    .subscribe(data => {
        this.guide = data;
        this.changeDetectorRef.detectChanges();
    },
    error => {
        console.log(error.Message);
    });
    this.migsystemservice.notifyShareQuote(this.quote);
  }

  ngOnDestroy() {
    if(this.FormGroupSubscription) this.FormGroupSubscription.unsubscribe();
    this.guideServiceSubscription.unsubscribe();
    this.doneClickSubscription.unsubscribe(); 
    this.nextClickSubscription.unsubscribe();
    this.migsystemservice.notifyEditingLoc(false); //if we leave this menu step, make sure the footer and menu know we are not in an "Edit Location" state.
    this.migsystemservice.notifyToastMessagesCleared();
  }

  canAddAnotherState(): boolean { // We should only be able to add another State if we currently only have one state, and our initial state is NOT Michigan -JTL 
    if(this.quote.STATES.filter(x=>x.RECORDSTATE != "D").length != 0){
      if(this.quote.STATES.filter(x=>x.RECORDSTATE != "D")[0].PRMSTE == "21" || this.quote.STATES.filter(x=>x.RECORDSTATE != "D").length == 2){
        return false; 
      }
    }
    return true; 
  }

  canAddAnotherLocation(): boolean { // We should only be able to add another location if all the current locations are valid
    return _.filter(this.menu.forms, locFormGroup => locFormGroup.invalid).length == 0;
  }
  
  displayDIAAssesment(): boolean{
    //returns true if state selected is Massachusetts
    return _.includes(["Massachusetts"], this.menu.label);
  }

  displayConstructionDiscount(): boolean {
    // returns true if the state selected is one of the following, false otherwise
    return _.includes(["Massachusetts","New Jersey","New York","Pennsylvania"], this.menu.label);
  }

  hasExperienceMod(): boolean { // The EFFDTE and EXPDTE don't show on screen and only get saved to WINS if there is an Experience Mod
      var expModValue: number = Number(this.stateObject.EXPMD1);
      //var expDte: number = this.stateObject.EM1EXP;
      if(expModValue != 0 && expModValue != null){
        this.stateObject.EM1EFF = this.quote.POLICYTRANS.EFFDTE;
        this.stateObject.EM1EXP = this.quote.POLICYTRANS.EXPDTE; // needs to be POLICYTRANS.EXPDTE but don't have access for some reason
        this.quote.QUOTEPOLICYINFORMATION.NEWEFFECTIVEDATE;
        this.stateObject.MERFCT = 0;
        this.stateFormGroup.get("RateFactor").setValue("0");
      }
      else{
        this.stateObject.EM1EFF = 0; // These don't get set when there isn't an experience mod
        this.stateObject.EM1EXP = 0;
        this.stateObject.INTRAR = "";
      }
      return this.isValidExperienceModValue(expModValue);
  }

  displayStateFactors(): boolean {
     //* this was updated 20220825 - Project A-02393; removing NY - BDK
    let currentday = this.func.funcDateSelected(new Date());
    // returns true if the state selected is one of the following, false otherwise
    if(this.quote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE < this.quote.QUOTEPOLICYINFORMATION.WCNYMERITFACTORDTE){
      return _.includes(["Massachusetts","Michigan","New York","Pennsylvania"], this.menu.label);
    }
    else{
      return _.includes(["Massachusetts","Michigan","Pennsylvania"], this.menu.label);
    }   
  }

  isValidExperienceModValue(expModValue:number): boolean {
    //console.log('value: ',expModValue)
      return ((expModValue >= 0.07) && (expModValue <= 2));
  }

  setExpModValueAndValidators(expModData: string)
  { // Used for the Experience Modification field. This is an optional field, however if it is selected, there are some validation rules we need to apply. 
    // The Experience Modification must be between 0.7 <= x <= 2.0 
    // Adding a value to the Experience Modification will display the Board File Number Field. This field must be exactly 9 digits in length -JTL
    
    if(expModData != null){
      expModData = expModData.toString(); //12/17/21: ensure this is always a string so the replace doesn't bomb out on some cases
      expModData = expModData.replace("_",""); // 12/14/21: we don't want to worry about the underscore, so we remove it here -JTL 
      var expModValue:number = _.toNumber(expModData);
      if(expModData.toString().endsWith(".")){ // if the data ends with a decimal, we add on a trailing 0.
        this.stateFormGroup.get("ExperienceMod").setValue(expModValue + ".0")
      }
    }

    if(expModData == null){ 
      expModValue = 0;
      expModData = "0.";
      this.stateFormGroup.get("ExperienceMod").setValue("");
    }
    
    else if (isNaN(expModValue) ) { // if we somehow get a non-number in the EXPMD1 field.
        expModValue = 0;
        this.stateFormGroup.get("ExperienceMod").setValue("");
    }

    else if (expModValue == 0 ) { // if expModValue is 0, remove the validation rules, and set the value of the 2 form controls to "", so they show as blank, rather than 0. 
      this.stateFormGroup.get("ExperienceMod").setValidators(Validators.nullValidator);
      this.stateFormGroup.get("BoardFileNumber").setValidators(Validators.nullValidator);
      this.stateObject.INTRAR = '';
      this.stateFormGroup.get("BoardFileNumber").setValue("");
      this.stateFormGroup.get("ExperienceMod").setValue("");
    }

    else if (!(this.isValidExperienceModValue(expModValue))) { // if there is an experience mod value, but it it not a valid value (0.7 <= x <= 2.0)
        this.stateFormGroup.get("BoardFileNumber").setValidators(Validators.nullValidator);
        this.stateFormGroup.get("ExperienceMod").setValidators
        ([
            this.migValidator.ValidateMinValue("ExperienceMod", "Experience Modification", 0.07, "must be at least ", false),
            this.migValidator.ValidateMaxValue(2, "ExperienceMod", "Experience Modification", "cannot be greater than  ", false)
        ]);
    }
    else if(this.hasFactor){ // if we have a merit rate factor.
      expModValue = 0;
    }
    else if(this.stateFormGroup.get("BoardFileNumber").value != ''){ // we have a valid ExpMod value
        this.stateFormGroup.get("BoardFileNumber").setValidators    // 12/17/21: BoardFileNumber changed to optional so only validate when something was entered
        ([
            this.migValidator.ValidateMinLength(9,'BoardFileNumber','Board File Number / Risk ID / Rating Bureau')
        ]);   
    }
    else{
      this.stateFormGroup.get("BoardFileNumber").setValidators(Validators.nullValidator);
    }

    this.stateObject.EXPMD1 = _.toNumber(this.stateFormGroup.get("ExperienceMod").value); // set the value of the experience mod on the object graph. //6/21/21: we now ensure we storing this as a number and not a string -JTL
    //**20220407 for Task 21 Touch less policies if the field has avlaue then map a 3 to EXPIND esle map a 5*/
    if(this.stateObject.EXPMD1 != 0 && this.stateObject.EXPMD1 != null){
      this.quote.EMPLOYERSLIABLIMITS.EXPIND = '3'
    }
    else{
      this.quote.EMPLOYERSLIABLIMITS.EXPIND = '5'
    }
    this.stateObject.INTRAR = this.stateFormGroup.get("BoardFileNumber").value; //Set this value here since its optional 
    this.stateFormGroup.get("ExperienceMod").updateValueAndValidity({emitEvent: false});
    this.stateFormGroup.get("BoardFileNumber").updateValueAndValidity({emitEvent: false});
  }

  setCreditValueAndValidators(creditData){
    if(isNaN(creditData)){ // Make a substring since the formcontrol value has a percentage in it
      var creditStr: string = creditData;
      var newCreditStr: string = creditStr.substring(0,creditStr.length-1);
      var credit: number = +newCreditStr;
    }
    else{
      var credit: number = Number(creditData);
    }
    if (isNaN(credit)) {
      credit = 0;
    }

    if (credit == 0) {
        this.stateFormGroup.get("CreditPercentage").setValidators(Validators.nullValidator);
        this.stateFormGroup.get("CreditPercentage").setValue("");
    }
    else{
      this.stateFormGroup.get("CreditPercentage").setValidators
      ([
        this.migValidator.ValidateMaxValue(100,'CreditPercentage', 'If Construction Discount Applies Enter Credit Percentage', "Discount must be less than ", false)
      ])
    }
    this.stateFormGroup.get("CreditPercentage").updateValueAndValidity({emitEvent: false});
    this.stateObject.AVHRWG = credit;
  }

  setARAPValueAndValidators(arap: number){  // 
    if(arap == 0 && (!this.displayDIAAssesment() || this.stateObject.EXPMD1 == 0)){ // if the arap is 0, then either it doesn't qualify for our ARAP Factor (so apply null Validator), or it does qualify, (so apply our validation rules) 
      this.stateFormGroup.get("ARAPFactor").setValidators(Validators.nullValidator);
      this.stateFormGroup.get("ARAPFactor").setValue("");
    }
    else if(this.displayDIAAssesment() && this.stateObject.EXPMD1 != 0){ // 11/10/21: replaced hasExperienceMod with "this.stateObject.EXPMD1 != 0" in logic because hasExperienceMod wasn't functioning properly -JTL
      this.stateFormGroup.get("ARAPFactor").setValidators([
        this.migValidator.ValidateMinValue("ARAPFactor", "ARAP Factor", 1.01, "must be at least ", false),
        this.migValidator.ValidateMaxValue(1.25, "ARAPFactor", "ARAP Factor", "cannot be greater than  ", false)
      ]);
      this.stateFormGroup.get("ARAPFactor").setValue(arap);
    }
    else if(this.displayDIAAssesment() && this.stateObject.EXPMD1 == 0){
      this.stateFormGroup.get("ARAPFactor").setValue(0);
    }
    this.stateFormGroup.get("ARAPFactor").updateValueAndValidity({emitEvent: false});

  }

  setupStateSelectionOptions()
  { /*
    ** 1. Only include states that the agent is licensed in.
    ** 2. Only include states that haven't been selected yet. (Ex. If the first state selected is NY, on the 2nd State screen, do not include NY)
    ** 3. Never include Ohio
    ** 4. We can only include Michigan for our first state. If Michigan is selected, we cannot add another state.
    */
    let agentLicensedStateCodes: any[] = _.map(this.quote.QUOTEPOLICYINFORMATION.AGENTLICENSEDSTATES, "STATEVALUE");
    let currentStates: any[] = [];
    this.quote.STATES.filter(x=>x.RECORDSTATE != "D").forEach(x => {  // make sure you are not able to select the same state for both state screens.

    if(x.PRMSTE != this.stateObject.PRMSTE)
        currentStates.push(x.PRMSTE)
    if (this.quote.STATES.length == 2) {
        currentStates.push("21"); // 5/17/21: we do not want Michigan to be an option on our second state 
    }
    })
    this.stateSelectionOptions = _.filter(this.dropdowns.States, (stateEntry) => {
        return _.includes(_.difference(agentLicensedStateCodes, currentStates), stateEntry.value) && stateEntry.value != "34"; // filter the difference between our agentLicensed state codes, and our currentStates array. 
    });
  }

  setupFormGroupValueChangesSubscription() { // update our stateObject as we fill out the form.
    this.FormGroupSubscription = this.stateFormGroup.valueChanges.pipe(debounceTime(700)).subscribe( data => {
      this.stateObject.PRMSTE = data.PremiumState;
        this.stateObject.COVERG = data.PremiumState;
        this.stateObject.MERFCT = data.RateFactor;
        this.hasFactor = this.stateObject.MERFCT.toString() != "0" ? true : false; // set the hasFactor boolean flag to true or false, based on if there is a value selected in the Merit Rate Factor
        //this.stateObject.INTRAR = data.BoardFileNumber; //12/17/21: removed this from the subscription, instead we are now setting this value from a change event in the HTML -ZJG
        this.stateObject.APPDIS = data.CreditPercentage == 0 ? "N" : "Y"; // When entered save Y otherwise N -5/12/21 ZJG
        //this.stateObject.EXPMD1 = data.ExperienceMod; // 12/14/21: removed this from the subscription, instead we are now setting this value from a change event in the HTML -JTL
        this.stateObject.ARAFCT = data.ARAPFactor != null ? data.ARAPFactor : 0; // if state is Massachusetts and has an experience mod then we will have ARAP Factor
        //this.stateObject.ARAFCT = (this.displayDIAAssesment() && this.hasExperienceMod()) ? data.ARAPFactor : 0; // if state is Massachusetts and has an experience mod then we will have ARAP Factor
        // if(this.displayDIAAssesment()){ // Need to Write a 2 to the DWCP130 whenever PRMSTE is 20(MA) -3/12/2021 ZJG
        //   this.stateObject.DIAFCT = "2";
        // }
        // else{
        //   this.stateObject.DIAFCT = "";
        // }
        if(data.ExperienceMod == "") { this.stateFormGroup.get("ExperienceMod").reset() } // if the experience mod is 0, reset the form control in order to display blank rather than 0.
        //this.setExpModValueAndValidators(data.ExperienceMod); // 12/14/21: commented out because we are using an on change event in the HTML
        this.setCreditValueAndValidators(data.CreditPercentage);
        this.setARAPValueAndValidators(data.ARAPFactor);
        if(data.ARAPFactor == 0){ this.stateFormGroup.get("ARAPFactor").reset() } // Want to reset the control if value is 0 to blank out and not validate -ZJG
        this.stateFormGroup.updateValueAndValidity({emitEvent: false});
        if (this.nextClicked){
          this.errors = this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive); // Only start displaying the errors when the Next button is clicked
          if(this.errors.length == 0){ // when there are no errors, set nextClicked to false so we break out of this if statement
            this.nextClicked = false; 
          }
          this.migsystemservice.notifyError(this.errors);
        }
        if(this.stateFormGroup.errors != null) { this.menuClass.stepActiveObject.errors.push(this.stateFormGroup.errors) }; // add our formgroup errors to our menu step's errors
        this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive); // Only start displaying the errors when the Next button is clicked
        this.menu.label = _.find(this.dropdowns.StatesFull, s => s["value"] == data.PremiumState).label; // When we change the State, we update the label on the left nav to the new state.
  
    });
  }

  btnAddState() { //Pasted from locationsummary component
  //Still need to create a blank form and dataObject after the new state menu item is added-ZJG
    let currentStepValidationErrors:any[] = this.menuClass.CalculateErrors(this.menuClass.stepActiveObject);
    this.migsystemservice.notifyNextClicked(currentStepValidationErrors);
    if (currentStepValidationErrors.length > 0)
    {
        return;
    }

    var menustateLabel = "";
    let data= {
      name: 'States',
        label: menustateLabel != "" ? menustateLabel : 'New State', 
        sublabel: '<small>' + '1' + ' Location' + '</small>',
        color: "ui-steps-number-default",
        navSkip: false,
        active: false,
        hasError: false,
        errors: [],
        buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }, { button: "GetQuoteNow" }],
        forms:  [this.formBuilder.group({})],
        icon: 'fa fa-map-pin',
        block: [],//[{ text: "Loading Data", success: false, icon: 'fa-spinner' }],
        visible: true,
        stateDataObject: this.quote.AddNewStateObject(),// needs to be a new state
        level: 2,
        fromWins: false,
        quote: "premium"
      }
      this.menuClass.addMenuItemAt(data, "States"); //add's our new menu item to our menu.
      //data.stateDataObject.AddnewLocation(); // commented this out because this was causing an extra invalid location form group to be added to the menu forms that would prevent the user from advancing.
      this.migsystemservice.notifyBlock({ block: true, block_message: data.block });
      this.menu.sublabel = '<small>' + this.stateObject.LOCATIONS.filter(x=>x.RECORDSTATE != "D").length + ' Location' + (this.stateObject.LOCATIONS.length == 1 ? '' : 's') + '</small>';
      this.menuClass.nextStep(this.menu.sublabel); // after we add the new state, we call nextStep so we move to the next state screen. We pass in the sublabel because for some reason the first state's sublabel will be lost if we don't otherwise.

  }

  handleStateChange(event){
    let newState: string = event.value;
      if (this.initialState == newState || this.initialState == "") // we only want the confirmation dialog when we change one state to another.
      { 
        if(this.initialState == ""){ // 6/24/21: if initial state is blank, set the state objects COVERG to the new state code. This is necessary so the first location added will have the proper State code.
          this.stateObject.COVERG = newState;
          this.acceptStateChange();
        }
        var classrequest:any = { // when we set a state for the first time, we need to get the available class codes for that state.
          PRODUCT:		'WCA',
          STATE:			newState,
          STATECODE: 		newState,
          EFFDTE:	 		this.stateObject.EFFDTE,
          ENDDTE:		 	this.stateObject.EDSDTE,
          CDKEY1: 		'',
          CDKEY2:			'',
          CLASSCODE:		'',
          DESCRIPTION: 	'',
          FSTTRK: 		""
      }
      this.guideServiceSubscription = this.guideService.getGuide(classrequest) // gets our list of class codes for a given state.
      .subscribe(data => {
          this.guide = data;
          this.changeDetectorRef.detectChanges();
      },
      error => {
          console.log(error.Message);
      });
      this.initialState = newState;
        return;
      }
      this.confirmationService.confirm({ // else if we currently have a state selected, and we select a different state in the dropdown, we want this confirmation dialog to appear.
        header: 'Change State?',
        message: "Changing the state will remove its associated locations. Do you wish to continue?",
        acceptLabel: "Yes",
        accept: () => { // When we select "Yes", we perform the function below.
          this.initialState = newState; // when we change the state, we want to reset our initial State. 
          this.menu.label = _.find(this.dropdowns.StatesFull, s => s["value"] == newState).label; // When we change the State, we update the label on the left nav to the new state.
          this.acceptStateChange(); 
        },

        reject: () => { // When we select "No", we set the form group's PremiumState control back to our initial State, and revert our stateObject's PRMSTE.
          this.stateFormGroup.get("PremiumState").setValue(this.initialState);
          this.menu.label = _.find(this.dropdowns.StatesFull, s => s["value"] == this.initialState).label; // When we change the State, we update the label on the left nav to the new state.
          this.stateObject.PRMSTE = this.initialState;
        }
      });
  }

  acceptStateChange(){ // When you change the state, and select "Yes" on the dialog message, we need to clear out existing locations, add a blank location, and reset the formgroup except for the State control
      this.stateObject.LOCATIONS = []; // clear existing locations for that state.
      this.locationsFormGroup = [];
      this.menuClass.menu.forms = []; //2/8/22: Remove all the form groups from this menu step. We will be re-adding them later -JTL 
      this.quote.POLICYTRANS.CO = this.stateObject.COVERG == "21" ? "MPIC" : "MMIC"
      this.btnAddLocation(); // adds a new location
      this.stateFormGroup.get("BoardFileNumber").setValue("", {emitEvent:false});
      this.stateFormGroup.get("ExperienceMod").setValue(0, {emitEvent: false});
      this.stateFormGroup.get("CreditPercentage").setValue(0, {emitEvent: false});
      this.stateFormGroup.get("ARAPFactor").setValue(0,{emitEvent: false});
      this.stateFormGroup.get("RateFactor").setValue(0, { emitEvent: false });
      this.stateFormGroup.updateValueAndValidity();
      var classrequest:any = { // when we change a state, we need to retrieve the available class codes for our new state.
        PRODUCT:		'WCA',
        STATE:			this.stateObject.COVERG,
        STATECODE: 		this.stateObject.COVERG,
        EFFDTE:	 		this.stateObject.EFFDTE,
        ENDDTE:		 	this.stateObject.EDSDTE,
        CDKEY1: 		'',
        CDKEY2:			'',
        CLASSCODE:		'',
        DESCRIPTION: 	'',
        FSTTRK: 		""
      }
      this.guideServiceSubscription = this.guideService.getGuide(classrequest) // gets our list of class codes for a given state.
      .subscribe(data => {
          this.guide = data;
          this.changeDetectorRef.detectChanges();
      },
      error => {
          console.log(error.Message);
      });
        if(this.displayDIAAssesment()){ // Need to Write a 2 to the DWCP130 whenever PRMSTE is 20(MA) -3/12/2021 ZJG
          this.stateObject.DIAFCT = "2";
        }
        else{
          this.stateObject.DIAFCT = "";
        }
  }

  onTabOpen(e) { // this fires when we open the tab on one of our locations. 4/29/21: currently not performing any function.
      
  }

  onTabClose(e){ // fires when we close the tab of one of our locations. We turn off the editing flag. 
    // Ideally, we do not want the user to be able to close the tab if they are in "edit mode" and didn't save. At the very least, at least prompt the user that their changes wouldn't be saved if they closed at that time. 
    this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive);
    this.isEditingLocation = false;
  }

  btnAddLocation() {
    //this.menuClass.stopNavigation = true;
    this.stateObject.AddnewLocation();
    this.migsystemservice.notifyEditingLoc(true);
    this.menu.sublabel = '<small>' + this.stateObject.LOCATIONS.filter(x=>x.RECORDSTATE != "D").length + ' Location' + (this.stateObject.LOCATIONS.length == 1 ? '' : 's') + '</small>';
  }
  
  SetBusinessClassFormGroup(formGroup: UntypedFormGroup){
    this.businessClassFormGroup.push(formGroup); // in case we need to view every selected business class for the given state
    formGroup.updateValueAndValidity({emitEvent:false}) 
    this.menu.forms.push(formGroup); // push our business class form group onto the menu form for validation purposes. 
    this.changeDetectorRef.detectChanges();
  }

  deleteState(){
    // first we need to set the record state for the stateObject to "D".
    this.stateObject.RECORDSTATE = "D";
    // next we need to set the record state for all locations, business classes, and individuals that are tied to this state.
    this.stateObject.LOCATIONS.forEach((location: WCALOCATIONS) => {
      location.RECORDSTATE = "D";
      location.BUSINESSCLASSES.forEach((businessClass: WCAClassExtended) => {
        businessClass.RECORDSTATE = "D"; 
        businessClass.BUSINESSCLASSSTATS.RECORDSTATE = "D";
      });
    })
    this.stateObject.INDIVIDUALS.forEach((individual: WCAIndividual) => { 
      individual.RECORDSTATE = "D";
    });
    // now we need to clear out the menu item of the state we are deleting.
    this.menuClass.ClearMenuItem("stateDataObject", this.stateObject);
    this.stateObject = this.quote.STATES.find(x=> x.RECORDSTATE != "D"); 
    // we want to go to the state menu step of the state not deleted
    this.menuClass.GotoMenuItem("label", _.find(this.dropdowns.StatesFull, s => s["value"] == this.stateObject.PRMSTE) != undefined ? _.find(this.dropdowns.StatesFull, s => s["value"] == this.stateObject.PRMSTE).label : 'New State')

    // if we are deleting a state that hasn't been entered, we want to remove the state from the object graph completely
    let index = 0;
    this.quote.STATES.forEach((state, i)=> {  
      if(state.COVERG == ""){
        this.quote.STATES.splice(i, 1); // this needed to be within this if statement. We want to splice ONLY when 
      }
    });

    
  }

}
