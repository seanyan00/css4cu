import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WcaLocationsComponent } from '../wca-locations/wca-locations.component';
import { AddressInformationModule } from '@root/shared_components/address_info/address.module';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { PanelModule } from 'primeng/panel';
import { FieldsetModule } from 'primeng/fieldset';
import { MIGOverlayPanelModule } from '@overridden/primeng-overlaypanel/overlay.module';
import { MIGInputSwitchModule } from '@overridden/primeng-inputswitch/switch.module';
import { ErrorModule } from '@root/shared_components/errors/errors.module';
import { PipesModule } from '@pipes/pipes.module';
import { TooltipModule } from 'primeng/tooltip';
import { ReportItemModule } from '@root/shared_components/report_item/report_item.module';
import { MIGMessageModule } from '@overridden/primeng-message/message.module';
import { DialogModule } from 'primeng/dialog';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { BusinessClassModule } from '@root/shared_components/business-class/business-class.module';



@NgModule({
  declarations: [WcaLocationsComponent],
  imports: [
    PanelModule,
	FieldsetModule,
	MIGButtonModule,
	MIGInputtextModule,
	FormsModule,
	ConfirmDialogModule,
	CommonModule,
	ErrorModule,
	PipesModule,
	MIGOverlayPanelModule,
	TooltipModule,
	MIGDropDownModule,
	ReportItemModule,
	BusinessClassModule,
	AddressInformationModule,
	ReactiveFormsModule,
	MIGInputSwitchModule,
	MIGMessageModule,
	DialogModule

  ],
	exports: [WcaLocationsComponent]
})
export class WcaLocationsModule { }
