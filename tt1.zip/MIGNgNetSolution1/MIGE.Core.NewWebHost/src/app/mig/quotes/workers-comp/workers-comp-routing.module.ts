import { WorkersCompComponent } from "./workers-comp.component";
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployersLiabilityLimits } from "./components/employers-liability-limits/employers-liability-limits.component";


const routes: Routes = [
    {
      path: '',
      component: WorkersCompComponent
    },
    //do we want to route further, one path for each screen? If so, we would need a path for each screen to route to. 
    {
        path: 'employers-liability-limits',
          loadChildren: () => import('./components/employers-liability-limits/employers-liability-limits.module').then(m=>m.EmployersLiabilityLimitsModule) ,

    }
  ];
  
  @NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })
  export class WorkersCompRoutingModule { }
