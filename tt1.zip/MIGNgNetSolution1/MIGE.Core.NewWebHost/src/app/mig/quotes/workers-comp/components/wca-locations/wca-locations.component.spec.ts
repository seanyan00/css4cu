import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WcaLocationsComponent } from './wca-locations.component';

describe('WcaLocationsComponent', () => {
  let component: WcaLocationsComponent;
  let fixture: ComponentFixture<WcaLocationsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WcaLocationsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WcaLocationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
