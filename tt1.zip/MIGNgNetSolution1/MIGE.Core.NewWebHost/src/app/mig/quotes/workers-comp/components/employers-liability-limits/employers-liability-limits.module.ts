/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { InputTextModule } from 'primeng/inputtext';
import { PanelModule } from 'primeng/panel';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { CheckboxModule } from 'primeng/checkbox';
import { FormsModule, ReactiveFormsModule, UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { PipesModule } from '@pipes/pipes.module';
import { MenuClass } from '@root/system/menu/menu';
import { EmployersLiabilityLimits } from './employers-liability-limits.component';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';

@NgModule({
    imports: [
        MIGButtonModule,
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        PanelModule,
        // CheckboxModule,
		MIGDropDownModule,
        // InputTextModule,
        PanelModule,
		MIGInputtextModule
    ],
    declarations: [EmployersLiabilityLimits],
    exports: [EmployersLiabilityLimits],
    providers: [EmployersLiabilityLimits, PipesModule]
})
export class EmployersLiabilityLimitsModule {
	formGroup: UntypedFormGroup;

	constructor(
		public menuClass: MenuClass,
		private formBuilder: UntypedFormBuilder,

	) {
		this.formGroup = this.formBuilder.group({});

		menuClass.addMenuItem({
			name: 'EmployersLiabilityLimits',
			label: 'Employers Liability Limits',
			color: "ui-steps-number-default",
			navSkip: false,
			active: false,
			hasError: false,
			errors: [],
			buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }],
			form: this.formGroup,
			icon: 'fa fa-layer-group',
			block: [],
			visible: true,
			quote: "premium"
		});
	}
}
