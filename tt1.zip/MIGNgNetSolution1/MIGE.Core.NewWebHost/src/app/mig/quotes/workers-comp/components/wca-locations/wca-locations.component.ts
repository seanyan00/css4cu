/* ****************************************************************************************************
* PROGRAM DESCRIPTION  - Locations 
* NOTES: 
* - This component is the child component of states.component.ts and is the parent component of wca-business-class.component.
* - This component is initialized when "Add Another Location" is selected.
* - One State can have many locations. One Location can have many business classes
* - 
* BUG FIXES: 
* 6/8/21: Fixed issue where deleting a location would still check for validation and prevent user from advancing (TFS 2241) -JTL 
* 6/29/21: Fixed issue where the LOCNUM's were not numbering properly. LOCNUM's no longer start back at "001" on the second state. (TFS 2311) -JTL
* 7/13/21: Fixed issue where you be unable to delete a location after adding a new location (TFS 2325) -JTL 
* 7/13/21: Fixed issue where Suite Number wasn't getting mapped properly on location prefilled from LANSA (TFS 2326) -JTL
* 10/22/21: Send updated quote data to footer and menu when we add or delete a location -JTL
****************************************************************************************************/
import { Component, OnInit, ChangeDetectorRef, Input, Output, EventEmitter} from '@angular/core';
import { MenuClass } from '@root/system/menu/menu';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { MIGSystemService } from '@root/services/mig.service';
import { ConfirmationService } from 'primeng/api';
import { WCAQuote } from '@classViewModels/WCA/WCAQuote';
import { UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { WCALOCATIONS } from '@classes/WCA/WCALocations';
import { MIGAddressValidator } from '@root/shared_components/address_info/address.validators';
import * as _ from 'lodash';
import { AccordionTab } from 'primeng/accordion';
import { ADDRESS } from '@root/shared_components/address_info/address.class';
import { GUIDE } from '@classes/common/BusinessClass/GUIDE';
import { MIGMenu } from '@root/system/menu/menu.class';
import { WCASTATES } from '@classes/WCA/WCAStates';
import { WCAClassExtended } from '@classes/WCA/WCCLASSEXTENDEDABSTRACT';

@Component({
  selector: 'mig-wca-locations',
  templateUrl: './wca-locations.component.html',
  styleUrls: ['./wca-locations.component.css']
})
export class WcaLocationsComponent implements OnInit { 
  // WcaLocationsComponet is a child component of States Component. One State can have multiple locations. One location can only be associated with one State.
  @Input() accordionTab: AccordionTab; // Used to access the accordion tab from our state component, for our specific location.
  @Input() quote: WCAQuote;
  @Input() stateObject: WCASTATES; 
  @Input() locationObject: WCALOCATIONS; // Holds our Location object on the object graph, coming from our states component.
  @Input() stateName : string; // Gets the full name of our state, from our state's component, So we can prefill our state control with this value. 
  @Input() guide: GUIDE[];
  businessClassFormGroup: UntypedFormGroup[] = []; 
  menu: MIGMenu;
  @Output() WCALocationFormGroupEmitter = new EventEmitter<any>(); // USed to communicate our location formgroup data with our state (parent) component 
  @Output() WCABusinessClassFormGroupEmitter = new EventEmitter<any>();
  @Output() editingLocation = new EventEmitter<any>(); // Used to let the State Component know we are editing the location.
  formBuilder: UntypedFormBuilder;
  isEditingLocation: boolean = false; 
  locationAddressFormGroup: UntypedFormGroup;
  locationFormGroupCopy: UntypedFormGroup;
  migwcalocationValidator: MIGAddressValidator;
  businessClassFormsCopy = [];
  locations: WCALOCATIONS[] = []; // this array will hold all our locations on our STATE
  totalLocations: WCALOCATIONS[] = []; // this array will hold all our locations on our QUOTE
  constructor(
    public menuClass: MenuClass,
		public migRoles: MIGSecurityRoles,
		public migsystemservice: MIGSystemService,
		public changeDetectionRef: ChangeDetectorRef,
    public confirmationService: ConfirmationService,
  ) { 
    this.formBuilder = new UntypedFormBuilder();
  }

  ngOnInit(): void {
      this.migwcalocationValidator = new MIGAddressValidator();
      this.menu = this.menuClass.stepActiveObject;
      var parsedStreetNumber:string = this.locationObject.LOCAD1.split(" ")[0];
      var parsedStreetName:string = this.locationObject.LOCAD1.replace(parsedStreetNumber, "").trim();
      var LOCAD2StringArray:string[] = this.locationObject.LOCAD2.split("|");
      var addressLine2Parsed:string = LOCAD2StringArray[0];
      var suiteNumberParsed:string = "";
      var address: ADDRESS = new ADDRESS;
      this.locations = this.stateObject.LOCATIONS;
      this.quote.STATES.filter(x=>x.RECORDSTATE !="D").forEach((state: WCASTATES) => { // we need to loop through each location on the quote and add 
        state.LOCATIONS.filter(x=>x.RECORDSTATE != "D").forEach((location:WCALOCATIONS) => {
          this.totalLocations.push(location)
        });
      });

      for(let i = 0; i < this.totalLocations.length; i ++){ // we want to set the LOCNUM relative to other locations on the quote. For example, if there are 3 locations on state 1, the first location on state 2 should start at "004".
        this.totalLocations[i].LOCNUM =  _.padStart((i + 1).toString(),3,'0');
      }

      if (LOCAD2StringArray.length == 2)
      {
        suiteNumberParsed = LOCAD2StringArray[1].replace("SUITE ", "");
      }
      if(this.locationObject.LOCNUM == "001"){ // If we are looking at the location pulled from LANSA, we can simply use the POLICYTRANS.ADDRESS' Suite Number. -JTL
        suiteNumberParsed = this.quote.POLICYTRANS.ADDRESS.SUITENUMBER;
      }
      address.STATE = address.getStateFormat(this.locationObject.COVERG);

      this.locationObject.LOCST = address.STATE;

      this.locationAddressFormGroup = this.formBuilder.group({
        LOCNUM: [this.locationObject.LOCNUM],
        RECORDSTATE: [this.locationObject.RECORDSTATE],
        STREETNUMBER: [parsedStreetNumber, this.migwcalocationValidator.ValidateRequired("STREETNUMBER", "Street Number")],
        STREETNAME: [parsedStreetName, this.migwcalocationValidator.ValidateRequired("STREETNAME", "Street Name")],
        AddressLine2: [addressLine2Parsed],
        SuiteNumber: [suiteNumberParsed],
        City: [this.locationObject.LOCCTY, this.migwcalocationValidator.ValidateRequired("City", "City")],
        State: [address.STATE],
        Zip: [this.locationObject.LOCZIP, this.migwcalocationValidator.ValidateZipCode("Zip","Zip Code")],
        TYPE: "Location"
      });

      if (this.locationAddressFormGroup.valid) { // 5/17/21: we only want to disable the formgroup if it is valid.  
          this.locationAddressFormGroup.disable(); // makes the form control values read-only
      }
      else{
        this.migsystemservice.notifyEditingLoc(true) // when the location isn't valid, we want to let the footer and menu know we are in an editing state. 
      }
    
      this.locationAddressFormGroup.valueChanges.pipe().subscribe( data => {
        this.changeDetectionRef.detectChanges();
      });

      this.locationFormGroupCopy = _.cloneDeep(this.locationAddressFormGroup); // creates a copy of our formgroup Oninit
      this.menu.forms.push(this.locationAddressFormGroup);
  }

  btnSave() {

  }
  ValidateLocation(){ // gets called when the user clicks "Save Location Address". We need to make sure that the location formgroup they are trying to save is valid.
    if(this.locationAddressFormGroup.valid){
        var LOCAD1CONCAT:string = this.locationAddressFormGroup.get("STREETNUMBER").value + ' ' + this.locationAddressFormGroup.get("STREETNAME").value;
        this.locationObject.LOCAD1 = LOCAD1CONCAT;
        //Problem trying to blank out field value that already exists in database
        var LOCAD2CONCAT:string = this.locationAddressFormGroup.get("AddressLine2").value;
        if (this.locationAddressFormGroup.get("SuiteNumber").value != "")//null?
        {
            LOCAD2CONCAT+= "|SUITE " + this.locationAddressFormGroup.get("SuiteNumber").value;
        }
        this.locationObject.LOCAD2 = LOCAD2CONCAT;
        this.locationObject.LOCCTY = this.locationAddressFormGroup.get("City").value;
        this.locationObject.LOCST = this.locationAddressFormGroup.get("State").value;
        this.locationObject.LOCZIP = this.locationAddressFormGroup.get("Zip").value;
        this.locationAddressFormGroup.disable();
        this.accordionTab.disabled = false;
        //this.editingLocation.emit(this.locationAddressFormGroup.enabled); // let the state component know that we are finished editing, and we want to leave our "Editing state"
        //this.accordionTab.toggle(new Event("")); // When we save the location, close the accordion tab.
        this.migsystemservice.notifyToastMessagesCleared();
          //this.menuClass.stopNavigation = false;
        this.migsystemservice.notifyEditingLoc(false); // let menu and footer know we are done editing location.
        this.isEditingLocation = false;
        this.businessClassFormsCopy.forEach((form: UntypedFormGroup)=>{
          this.menu.forms.push(form); // add the filtered out formgroups back onto the menu step. 
        });
    }
    else{
      let errors = this.menuClass.CalculateErrorsFormGroup(this.locationAddressFormGroup);
      this.migsystemservice.notifyDoneClicked(errors);
      //TODO: when the formgroup is not valid, we want to prevent the user from leaving/closing the tab.
    }
}

  EditLocation(){
    this.isEditingLocation = true;
    this.migsystemservice.notifyEditingLoc(true); // let footer and menu know we are editing the location. 
    // this.menuClass.stopNavigation = true;
    this.locationAddressFormGroup.enable(); // When we click Edit Location, we want to enable our form controls, and let the state component know that we want to enter an "Editing state"
    this.locationFormGroupCopy = _.cloneDeep(this.locationAddressFormGroup);
    this.locationAddressFormGroup.get("STREETNUMBER").setValue(""); // clear out all values except for state 
    this.locationAddressFormGroup.get("STREETNAME").setValue("");
    this.locationAddressFormGroup.get("AddressLine2").setValue("");
    this.locationAddressFormGroup.get("SuiteNumber").setValue("");
    this.locationAddressFormGroup.get("City").setValue("");
    this.locationAddressFormGroup.get("Zip").setValue("");

    this.menu.forms.forEach((form: UntypedFormGroup) =>{
        if(form.get("LOCNUM").value == this.locationObject.LOCNUM && form.get("TYPE").value == "Business Class"){
          this.businessClassFormsCopy.push(form); // push the business class form groups associated with this location onto this array. We will be adding these FG's back when they save or cancel editing the location. 
        }
     });

   this.menu.forms = this.menu.forms.filter((x:UntypedFormGroup)=> x.get("TYPE").value != "Location" && x.get("LOCNUM").value != this.locationAddressFormGroup.get("LOCNUM").value ); //IMPORTANT: when we edit a location, we filter out the formgroups associated out with this menu step. We will re-add them when they are finished editing.

    this.editingLocation.emit(this.locationAddressFormGroup.enabled);
    this.accordionTab.disabled = true;
  }

  CancelLocation(){ // Will need to save copy of FG 
    this.locationAddressFormGroup = this.locationFormGroupCopy;
     // will disable fg and close the tab for now
    this.locationAddressFormGroup.disable();
    this.editingLocation.emit(this.locationAddressFormGroup.enabled);
    this.accordionTab.disabled = false;
    this.accordionTab.toggle(new Event(""));
    this.menuClass.stopNavigation = false;
    this.migsystemservice.notifyEditingLoc(false); // let footer and menu know we are not editing location anymore
    this.businessClassFormsCopy.forEach((form: UntypedFormGroup)=>{
      this.menu.forms.push(form); // push the business class form groups associated with this location onto this array. We will be adding these FG's back when they save or cancel editing the location. 
    });
    this.menu.forms.push(this.locationFormGroupCopy); // push our old location form group back onto the menu when they cancel editing. 
    this.isEditingLocation = false;
  }

  SetBusinessClassFormGroup(formGroup){ 
    this.businessClassFormGroup.push(formGroup);
    this.menu.forms.push(formGroup);
    this.WCABusinessClassFormGroupEmitter.emit(formGroup); // propogate the business class FG to the state and menu formgroup. 
    this.changeDetectionRef.detectChanges();
  }

  deleteLocation(){ //called when we click the "delete location button".
    this.locationObject.RECORDSTATE = "D";
    this.locationAddressFormGroup.get("RECORDSTATE").setValue("D");
    this.businessClassFormGroup.forEach((fg: UntypedFormGroup)=> {
      fg.get("RECORDSTATE").setValue("D");
    })
    this.locationObject.BUSINESSCLASSES.forEach((businessClass: WCAClassExtended) => {
      businessClass.RECORDSTATE = "D";
      businessClass.BUSINESSCLASSSTATS.RECORDSTATE = "D";
    })
    this.locations = this.stateObject.LOCATIONS.filter(x => x.RECORDSTATE != "D");
    this.totalLocations = []; // clear and readd our locations, excluding the location we just deleted.
     this.quote.STATES.filter(x=> x.RECORDSTATE != "D").forEach((state: WCASTATES) => {
      state.LOCATIONS.filter(x=>x.RECORDSTATE !="D").forEach((location: WCALOCATIONS) => {
        this.totalLocations.push(location); // 
      });
    });
    this.resetLocationNumbers();
    this.menu.sublabel = '<small>' + this.locations.length + ' Location' + (this.locations.length == 1 ? '' : 's') + '</small>';
    this.menu.forms = this.menu.forms.filter((x:UntypedFormGroup)=> x.get("TYPE").value != "Location" && x.get("LOCNUM").value != this.locationAddressFormGroup.get("LOCNUM").value); // filter out the form group that has the LOCNUM of the location we just deleted.
    this.migsystemservice.notifyGetQuote(this.quote); // gives the menu and footer the updated quote information 
    this.migsystemservice.notifyDoneClicked({}); // if there were errors on the deleted locations, we don't need to worry about them anymore, so this is used to clear out the error panel.
  }
 
  resetLocationNumbers(){ // when we delete a delete a location, we want to readjust the locnums for the locations and business classes. 
    for(let i = 0; i < this.totalLocations.length; i ++ ){
        this.totalLocations[i].LOCNUM = _.padStart((i+ 1).toString(),3,'0');
        this.totalLocations[i].BUSINESSCLASSES.forEach((businessClass: WCAClassExtended) => {
          businessClass.LOCNUM = _.padStart((i + 1).toString(),3,'0');
          businessClass.BUSINESSCLASSSTATS.LOCNUM = _.padStart((i + 1).toString(),3,'0');
        });
      }    
  }

  canDeleteLocation() : boolean { // we can't delete the location if it's the last one on the state.
    return this.stateObject.LOCATIONS.filter(x=>x.RECORDSTATE != "D").length == 1 ? false : true;
  }
}
