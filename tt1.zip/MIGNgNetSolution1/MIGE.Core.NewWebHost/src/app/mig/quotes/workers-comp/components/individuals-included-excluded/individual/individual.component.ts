/* ****************************************************************************************************
* PROGRAM DESCRIPTION  - Individuals Included / Excluded 
* NOTES: 
* This is the child component of individuals-included.component. This component holds our Individuals form. 
* BUG FIXES: 
* 9/17/21: Removed "Has the insured completed and signed the Exclusion/Inclusion Affidavit?" question from form. (TFS 2423) -JTL
****************************************************************************************************/
import { ChangeDetectorRef, Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { WCAIndividual } from '@classes/WCA/WCAIndividual';
import { WCALOCATIONS } from '@classes/WCA/WCALocations';
import { WCASTATES } from '@classes/WCA/WCAStates';
import { WCAClassExtended } from '@classes/WCA/WCCLASSEXTENDEDABSTRACT';
import { WCAQuote } from '@classViewModels/WCA/WCAQuote';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { InputMasksClass } from '@helpers/masks';
import { MIGSystemService } from '@root/services/mig.service';
import { MenuClass } from '@root/system/menu/menu';
import { Functions } from '@helpers/functions';
import  * as _ from 'lodash'; 
import { distinctUntilChanged } from 'rxjs/operators';
import { AppErrors } from '@root/shared_components/errors/app-errors';
import { MIGIndividualValidators } from './individual.validators';
import { AccordionTab } from 'primeng/accordion';
import { Subscription } from 'rxjs';
import { ConfirmationService } from 'primeng/api';
@Component({
  selector: 'mig-individual',
  templateUrl: './individual.component.html',
  styleUrls: ['./individual.component.css']
})
export class IndividualComponent implements OnInit, OnDestroy {
  @Input() quote: WCAQuote;
  @Input() individualObject: WCAIndividual;
  @Input() statesObject: WCASTATES[];
  @Input() individualIndex: number;
  @Input() accordionTab : AccordionTab;
  @Input() isEditingIndividual: boolean;
  @Output() panelEmitter = new EventEmitter<any>();
  @Output() individualFormGroupEmitter = new EventEmitter<any>();
  @Output() updateHeader = new EventEmitter<any>();
  stateObject: WCASTATES;
  stateDropdownOptions: any[];
  titleDropdownOptions: any[]; 
  classCodeOptions: any[] = []; // holds our options for the Class Codes dropdown. This is determined by the Classcodes currently bound to the quote.
  initialState: String;
  individualFormGroup: UntypedFormGroup;
  FormGroupSubscription: Subscription;
  errors: AppErrors[];
  maxDte: Date;
  individualValidators: MIGIndividualValidators;
  constructor(
      private cd: ChangeDetectorRef,
      public menuClass: MenuClass,
      public migRoles: MIGSecurityRoles,
      public confirmationService: ConfirmationService,
      public migsystemservice: MIGSystemService,
      private formBuilder: UntypedFormBuilder,
      public dropdowns: ContractorsDropDowns,
      public func: Functions,
      public masks: InputMasksClass) {
      this.individualValidators = new MIGIndividualValidators();
  }

  ngOnInit() {
    this.stateObject = this.statesObject.find(x => x.PRMSTE == this.individualObject.STCODE); // determine which stateObject we should be referring to, based on our individual's STCODE
    this.initialState = this.stateObject.COVERG;
    this.individualObject.STCODE = this.stateObject.PRMSTE;
    this.individualObject.MSCSEQ = _.padStart((this.individualIndex + 1).toString(),2,'0');
    this.filterStateDropdown(); 
    this.filterTitleDropdown();
    this.determineClassCodeDropdown();
    this.showIncludedExcluded();
    this.showOtherEmployees();
    this.individualFormGroup = this.buildFormGroup(); // build our form group and set validation rules.    
    this.formGroupValueChangesSubscription();
    this.individualFormGroupEmitter.emit(this.individualFormGroup);
    this.updateHeader.emit(this.individualFormGroup);
  }

  ngOnDestroy() {
    if(this.FormGroupSubscription) this.FormGroupSubscription.unsubscribe();
  }

  buildFormGroup(): UntypedFormGroup{
    return this.formBuilder.group({
      SequenceNumber: [this.individualObject.MSCSEQ], // we can use this to uniquely identify an individual.
      State: [this.individualObject.STCODE, this.individualValidators.ValidateRequired("State", "State")],
      OtherEmployees: [this.individualObject.OTHEMPS, this.showOtherEmployees() ? this.individualValidators.ValidateOptionSelected("OtherEmployees", "Other Employees"): Validators.nullValidator],
      MiscName: [this.individualObject.MSCNAM, this.individualValidators.ValidateRequired("MiscName", "Name")],
      DateOfBirth: [this.individualObject.MSCDOB == 0 ? 0 : this.func.DTEWinsToPrimeNG(this.individualObject.MSCDOB, 'mmddyyyy'), this.individualValidators.ValidateRequired("DateOfBirth", "Date of Birth")],
      Title: [this.individualObject.MSCTTL, this.individualValidators.ValidateRequired("Title", "Title")],
      OwnershipPercentage: [this.individualObject.MSCPER != 0 ? this.individualObject.MSCPER : "", [this.individualValidators.ValidateMinValue("OwnershipPercentage", "Ownership Percentage", 1, " must be at least ",false),this.individualValidators.ValidateMaxValue(100, "OwnershipPercentage","Ownership Percentage", " must be less than ", false)]],
      Duties: [this.individualObject.MSCDUT, this.individualValidators.ValidateRequired("Duties", "Duties")],
      IncludedExcluded: [this.individualObject.MSCINC == 'I'? "Y" : this.individualObject.MSCINC == "E" ? "N" : "", this.showIncludedExcluded() ? this.individualValidators.ValidateOptionSelected("IncludedExcluded", "Included / Excluded") : Validators.nullValidator],
      ClassCode: [this.individualObject.MSCCLS, this.individualObject.MSCINC == "I" && this.showIncludedExcluded() ?  this.individualValidators.ValidateRequired("ClassCode", "Class Code") : Validators.nullValidator],
      Remuneration: [this.individualObject.MSCREM, this.individualObject.MSCINC == "I" && this.showIncludedExcluded() ?  this.individualValidators.ValidateRequired("Remuneration", "Remuneration") : Validators.nullValidator ]
    });
  }

  handleStateChange(event){
    let newState: string = event.value;
    this.quote.STATES.forEach(state => {
      if(state.COVERG == newState && newState != this.initialState){
        state.INDIVIDUALS.push(this.individualObject);
      }
      if(state.COVERG == this.initialState){ // this is the state that we need to remove the individual from. filter out the individual with the matching sequence number.
        state.INDIVIDUALS = state.INDIVIDUALS.filter(x => x.MSCSEQ != this.individualObject.MSCSEQ);
      }
    });
    this.individualObject.STCODE = newState; //update object graph. 
    this.stateObject = this.statesObject.find(x => x.PRMSTE == this.individualObject.STCODE); // determine the new state object we are working with
    //Resetting formGroup won't work here so manually reseting controls
    this.individualFormGroup.get("State").setValue(newState);
    this.individualFormGroup.get("OtherEmployees").setValue(""); 
    this.individualFormGroup.get("MiscName").setValue("");
    this.individualFormGroup.get("DateOfBirth").setValue(0);
    this.individualFormGroup.get("Title").setValue("");
    this.individualFormGroup.get("OwnershipPercentage").setValue("");
    this.individualFormGroup.get("Duties").setValue("");
    this.individualFormGroup.get("IncludedExcluded").reset(); // for an input switch, we can't just set the value to "", because that means it will be set to the "Off Switch".
    this.individualFormGroup.get("ClassCode").setValue("");
    this.individualFormGroup.get("Remuneration").setValue(0);
    this.determineClassCodeDropdown(); // update the classcode dropdown info.
  }

  saveIndividual(){ // called when we click "Save" 
    this.errors = this.menuClass.CalculateErrorsFormGroup(this.individualFormGroup); // we only want to save the individual if it is valid, so we check for errors here.
    this.migsystemservice.notifyDoneClicked(this.errors); // if we have any errors, they will be sent to the error panel. 
    if(this.errors.length == 0) {
      this.updateHeader.emit(this.individualFormGroup); // updates our header
      this.accordionTab.toggle(new Event('')); // closes our accordion tab
      this.isEditingIndividual = false;
    }
  }


  determineClassCodeDropdown(){ // We only want the classcodes that are bound to the quote. If they change the state, we want to adjust the dropdown options accordingly.
    let classcodes = []
    this.stateObject.LOCATIONS.forEach((location: WCALOCATIONS) => {
        location.BUSINESSCLASSES.forEach((bc: WCAClassExtended) => {
          classcodes.push({label : bc.CLASX + " - " + bc.EXTDSC, value: bc.CLASX});
        })
    })
    this.classCodeOptions = classcodes;

  }

  filterTitleDropdown(){ // gets called on NgOninit: the values for the Title / Relationship dropdown is determined by the quote's insured type, so we use the INSTYP to filter and return the values we need. 
    let insuredType = this.quote.POLICYTRANS.INSTYP;
    this.titleDropdownOptions = _.filter(this.dropdowns.MSCTTL, (entry)=> {
        return _.includes(entry.INSTYP, insuredType);
    })
  }

  filterStateDropdown(){
    let currentStates = [];
    this.quote.STATES.forEach(x => {  // make sure you are not able to select the same state for both state screens.
      currentStates.push(x.PRMSTE);
      })
    this.stateDropdownOptions = _.filter(this.dropdowns.States, (stateEntry) => {
      return _.includes(currentStates, stateEntry.value);
    });
  }

  formGroupValueChangesSubscription(){
    this.FormGroupSubscription = this.individualFormGroup.valueChanges.pipe(distinctUntilChanged()).subscribe(data =>{

      this.individualObject.MSCNAM = data.MiscName;
      this.individualObject.MSCDOB = data.DateOfBirth == 0 ? 0 : this.func.funcDateSelected(data.DateOfBirth,'mmddyyyy'); 
      this.individualObject.MSCTTL = data.Title;
      this.individualObject.MSCPER = this.func.justNumbers(data.OwnershipPercentage);
      this.individualObject.MSCDUT = data.Duties;
      //this.individualObject.MSCCLS = data.ClassCode;
      //**20220407 if excluded is re-selected after class code was filled if they 'change they're mind' then clear out the class code field here */
      this.individualObject.MSCCLS = data.IncludedExcluded === true ? data.ClassCode : data.ClassCode = "";      
      this.individualObject.MSCREM = data.Remuneration;
      this.individualObject.MSCINC = data.IncludedExcluded === true ? "I" : data.IncludedExcluded === false ? "E" : "";
      this.individualObject.OTHEMPS = data.OtherEmployees === true ? "Y" : data.OtherEmployees === false ? "N" : "";

      this.individualFormGroup.get("OtherEmployees").setValidators( this.showOtherEmployees() ? this.individualValidators.ValidateOptionSelected("OtherEmployees", "Other Employees") : Validators.nullValidator);
      this.individualFormGroup.get("IncludedExcluded").setValidators( this.showIncludedExcluded() ? this.individualValidators.ValidateOptionSelected("IncludedExcluded", "Included / Excluded") : Validators.nullValidator);
      this.individualFormGroup.get("ClassCode").setValidators(this.individualObject.MSCINC == "I" && this.showIncludedExcluded() ? this.individualValidators.ValidateRequired("ClassCode", "Class Code") : Validators.nullValidator);
      this.individualFormGroup.get("Remuneration").setValidators(this.individualObject.MSCINC == "I" && this.showIncludedExcluded() ? this.individualValidators.ValidateRequired("Remuneration", "Remuneration") : Validators.nullValidator);
      this.individualFormGroup.get("OtherEmployees").updateValueAndValidity({emitEvent: false});
      this.individualFormGroup.get("IncludedExcluded").updateValueAndValidity({emitEvent: false});
      this.individualFormGroup.get("ClassCode").updateValueAndValidity({emitEvent: false});
      this.individualFormGroup.get("Remuneration").updateValueAndValidity({emitEvent: false});
      
      this.errors = this.menuClass.CalculateErrorsFormGroup(this.individualFormGroup);
    })
  }

  showIncludedExcluded(): boolean { // if the State is New Jersey, and the insured type is Corporation or Subchapter S Corp, then we do not want to display the included / excluded input switch
    return this.individualObject.STCODE == "29" && (this.quote.POLICYTRANS.INSTYP == "CP" || this.quote.POLICYTRANS.INSTYP == "SS" ) ? false : true;
  }

  showOtherEmployees() : boolean { // we only want to display the "Other Employees" input switch if the state selected is New York or Michigan.
    return this.individualObject.STCODE == "31" || this.individualObject.STCODE == "21" ?  true : false; 
  }

  addNewClassCode(){ // called when they click "Add New Class"
    let menustateLabel = _.find(this.dropdowns.StatesFull, s => s["value"] == this.stateObject.PRMSTE).label; // Determine which state step we want to navigate to if they were to click "Yes"
    this.confirmationService.confirm({ 
			message: 'Adding a new class code will redirect you to the States screen. If you add a new class code, you will have to re-rate. Continue?',
			header: 'Add Class Code?',
			icon: 'pi pi-exclamation-triangle',
			accept: () => {
        this.menuClass.GotoMenuItem("label", menustateLabel); // 
      }
      });
    }
}
