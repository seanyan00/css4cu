import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IndividualsIncludedExcludedComponent } from './individuals-included-excluded.component';

describe('IndividualsIncludedExcludedComponent', () => {
  let component: IndividualsIncludedExcludedComponent;
  let fixture: ComponentFixture<IndividualsIncludedExcludedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IndividualsIncludedExcludedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IndividualsIncludedExcludedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
