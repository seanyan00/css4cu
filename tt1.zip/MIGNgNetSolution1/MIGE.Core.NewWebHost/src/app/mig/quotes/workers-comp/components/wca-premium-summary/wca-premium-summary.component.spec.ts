import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WcaPremiumSummaryComponent } from './wca-premium-summary.component';

describe('WcaPremiumSummaryComponent', () => {
  let component: WcaPremiumSummaryComponent;
  let fixture: ComponentFixture<WcaPremiumSummaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WcaPremiumSummaryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WcaPremiumSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
