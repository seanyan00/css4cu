import { Component, OnInit, ChangeDetectorRef, Inject } from '@angular/core';
import { Subscription } from 'rxjs';
import * as _ from "lodash";
import diff from 'deep-diff';
import { finalize } from 'rxjs/operators';
import { ConfirmationService } from 'primeng/api';
import { MessageService } from 'primeng/api';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { MIGSystemService } from '@services/mig.service';
import { QuoteService } from '@services/quote.service';
import { AuthService } from '@auth/auth.service';
import { TokenResponse } from '@auth/tokenresponse.class';
import { MenuClass } from '@root/system/menu/menu';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { CTRQuoteClass } from '@classViewModels/CTR/quote.class';
import { environment } from '@environment/environment';
import { IQuote } from '@interfaces/IQuote';
import { PolicyService } from '@root/services/policy.service';
import { DOCUMENT } from "@angular/common";
import { UnderwritingService } from '@root/services/underwriting.service';
import { MIGLiabilityResources } from '@CTRcomponents/additional_coverages/liability/extension/extension.resources';
import { WCAQuote } from '@classViewModels/WCA/WCAQuote';
import { DiscretionaryClass } from '@root/shared_components/Discretionary_WorkSheet/discretionary-class';

@Component({
  selector: 'mig-workers-comp',
  templateUrl: './workers-comp.component.html',
  styleUrls: ['./workers-comp.component.css']
})
export class WorkersCompComponent implements OnInit {


    // quote: IQuote;
    quote: WCAQuote;

    activeMenuItemIndex: number;
    activeMenuItem: any = {name: 'default'};
    roles: any[] = [];
    isInRole: boolean = false;
    //this controls whether we see the testing controls or not
    showTestingControls: boolean = true;
    token: TokenResponse;
    product: string;
    sessionid:string = '';
    //for testing redirect to Acct Management
    //sessionid:string = 'L024C0F6480706101DC0F07032019075802';
    lansaUrl:string = environment.lansaAcct;
    quote_id: string = '';
    effective_date: number = 20210208;
    endorsement_date: number = 20210208;
    endorsement_number: number = 0;
    transaction_type: string = 'N';
    // contractors html is made up of multiple sub blocks
    // set our initial value to "block" while we load data
    subStep: string = "block";
    showDiscretionaryWorksheet:boolean = false;

    // our quote class
    // quote: CTRQuote;
    private quoteMemento: WCAQuote;

    quoteInfoOut: any;
    messages:any[]= [];
    // our subscriptions to various notifications
    quoteServiceSubscription: Subscription;
    displayToastMessages: boolean = false;
    private stepChangeSubscription: Subscription = null;

constructor(
  public authService: AuthService,
  public confirmationService: ConfirmationService,
  public quoteService: QuoteService,
  public policyService: PolicyService,
  public contractorsDropDowns: ContractorsDropDowns,
  public migsystemservice: MIGSystemService,
  public menuClass: MenuClass,
  public messageService: MessageService,
  public migRoles: MIGSecurityRoles,
  public quoteClass: CTRQuoteClass,
  private discClass: DiscretionaryClass,
      public cd: ChangeDetectorRef,
      public underwritingService: UnderwritingService,
      @Inject(DOCUMENT) public document: Document
) {
  //getAuth Token for getQuote from Lansa
  this.token = authService.getAuth();
  if(this.token != null){
          this.sessionid = this.token.SessionId;
          this.transaction_type = this.token.TransType;
      }
      this.product = this.authService.LOB;
      this.quote = new WCAQuote();
  // ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **
  if (environment.production) {
          this.quote.POLICYTRANS.POLICY = this.token.QuoteId;
          this.quote.POLICYTRANS.EFFDTE = this.token.EffectiveDate;
          this.quote.POLICYTRANS.EDSDTE = this.token.EndorsementDate;
          this.quote.POLICYTRANS.EDSNO = this.token.EndorsementNo;
          this.quote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER = this.token.QuoteId;
          this.quote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE = this.token.EffectiveDate;
          this.quote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE = this.token.EndorsementDate;
          this.quote.QUOTEPOLICYINFORMATION.ENDORSEMENTNUMBER = this.token.EndorsementNo;
          this.quote.QUOTEPOLICYINFORMATION.TRANSACTIONTYPE = this.token.TransType;
  } else {

          //TODO: uncomment this section out and remove token code
        //   this.quote.EMPLOYERSLIABLIMITS.EMPLIA = "100/100/500";
        //   this.quote.EMPLOYERSLIABLIMITS.EMPLIAFORMAT = "100,000";
          this.quote.POLICYTRANS.POLICY = this.quote_id;
          this.quote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER = this.quote_id;
          this.quote.QUOTEPOLICYINFORMATION.TRANSACTIONTYPE = this.transaction_type;

          if (this.transaction_type == "PI")
          {
              this.quote.POLICYTRANS.EFFDTE = this.effective_date;
              this.quote.POLICYTRANS.EDSDTE = this.endorsement_date;
              this.quote.POLICYTRANS.EDSNO = this.endorsement_number;
              this.quote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE = this.effective_date;
              this.quote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE = this.endorsement_date;
              this.quote.QUOTEPOLICYINFORMATION.ENDORSEMENTNUMBER = this.endorsement_number;
          }
  }
  // ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **
      //console.log(this.quote);

      if (this.quote.QUOTEPOLICYINFORMATION.TRANSACTIONTYPE.toUpperCase() == "PI")
      {
    // this.policyService.GetPolicy(this.quote)
    //   .pipe(finalize(()=>{}))
    //   .subscribe(response => {
    //               this.quote = new CTRQuote(<CTRQuote>response);
    //     //UPDATE set menu to 3 to skip the first 3 menu steps and display quote info
    //     this.migsystemservice.notifyBlock(this.menuClass.menu[3].block);
    //               this.beginQuoteChangeDetection();
    //               // migsystemservice.notifyQuoteChanged(this.quote);
    //               this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Worker's Comp', detail: "Loaded!", event: "end" });
    //   });
      }
      else
      {

    this.quoteService.GetQuote(this.quote)
      .pipe(finalize(()=>{
      }))
      .subscribe(response => {
        this.quote = new WCAQuote(<WCAQuote>response);
        //UPDATE set menu to 1 to skip Accountmanagment module and display quote info
        this.migsystemservice.notifyBlock(this.menuClass.menu[1].block);
                  this.beginQuoteChangeDetection();
                   migsystemservice.notifyGetQuote(this.quote);                  
                   migsystemservice.notifyGetWCAQuoteStates(this.quote.STATES);
                   if( this.authService.retryPremium == 0){ //When we we retry premium we are doing a seperate notify block so don't want this to show -ZJG
                    this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Workers Comp', detail: "Loaded!", event: "end" });
                    }
                  /** new 2021001 */
                  this.showDiscretionaryWorksheetMenu(this.quote);           
                
      });
          
    //       else{
    // // this.quoteService.GetQuote(this.quote)
    // // 	.pipe(finalize(()=>{
    // // 	}))
    // // 	.subscribe(response => {
    //       //         this.quote = new CTRQuote(<CTRQuote>response);
    // // 		//UPDATE set menu to 1 to skip Accountmanagment module and display quote info
    // // 		this.migsystemservice.notifyBlock(this.menuClass.menu[1].block);
    //       //         this.beginQuoteChangeDetection();
    //       //         migsystemservice.notifyQuoteChanged(this.quote);
    //       //         this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Worker's Comp', detail: "Loaded!", event: "end" });
    //       //     });
    //       }
      }

  //Subscribe to Save Quote notify here;moved out of quote.class.ts
  //because UWQ was not being sent to backend and subscribeQuoteChanged is in this constructor
  this.migsystemservice.subscribeSaveQuote().subscribe(redirect => {

          if (!this.migRoles.editable) {
              if(redirect){
                  this.migsystemservice.notifySystemNotification({ severity: 'info', summary: "Worker's Comp", detail: 'Exiting......', event: "start" })
        let btn = this.document.getElementById('btnAcctManagement');
        btn.click();
      }
              return;
          }

          if (this.quote.QUOTEPOLICYINFORMATION.NEWEFFECTIVEDATE > 0)
          {
              //if new effective date is April 1st, 2021 or later, and old effective date is before April 1st, 2021
              //we need to reset inland marine rates and limits.
              if ((this.quote.QUOTEPOLICYINFORMATION.NEWEFFECTIVEDATE >= 20210401) && (this.quote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE < 20210401))
              {

              }
              //if new effective date before April 1st, 2021, and old effective date is on or after April 1st, 2021
              //we need to reset inland marine rates and limits.
              if ((this.quote.QUOTEPOLICYINFORMATION.NEWEFFECTIVEDATE < 20210401) && (this.quote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE >= 20210401))
              {

              }
          }

          this.quoteChangesDetected();

          this.migsystemservice.notifyUpdateRecordState();

          let saveQuoteDetailMessage: string = 'Saving quote. Please wait.'
    this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Workers Comp', detail: saveQuoteDetailMessage, event: "start" })
          /** */
          //this.messageService.add({ severity: 'info', summary: 'Contractors', detail: saveQuoteDetailMessage });

    this.quoteService.SaveQuote(this.quote as WCAQuote, "WCA").subscribe((quoteInfo: WCAQuote)=> {
              this.quote = new WCAQuote(quoteInfo);
              this.beginQuoteChangeDetection();
              this.migsystemservice.notifyGetWCAQuoteStates(this.quote.STATES);
      this.migsystemservice.notifySystemNotification({ severity: 'success', summary: 'Workers Comp', detail: 'Quote Saved. ', event: "end" });
              //this.messageService.add({ severity: 'success', summary: 'Contractors', detail: 'Quote Saved. ' });


      if(redirect){
        let btn = this.document.getElementById('btnAcctManagement');
        btn.click();
      }

    }, (error) => {
      this.migsystemservice.notifySystemNotification({ severity: 'error', summary: 'Workers Comp', detail: 'Quote Save Failed. ', event: "end" })

    }, () => {

    })
  });

  this.migsystemservice.subscribeCopyQuote().subscribe(() => {
          this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Workers Comp', detail: 'Copying quote. Please wait.', event: "start" });
          this.underwritingService.getUWQuestions(this.quote)
    .pipe(
      finalize(() => {
      })
    )
    .subscribe(data => {
      this.quote.UWQUESTIONSCATEGORY = data.UWQUESTIONSCATEGORY;
      this.quoteService.CopyQuote(this.quote)
              .pipe(finalize(()=>{
              }))
              .subscribe(response => {
                  this.migsystemservice.notifySystemNotification({ severity: 'success', summary: 'Workers Comp', detail: 'Quote Copied!  New Quote Number: ' + response.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER, event: "end" });
                  this.quote = new WCAQuote(<WCAQuote>response);
                  this.beginQuoteChangeDetection();
                  this.migsystemservice.notifyGetQuote(this.quote);
                  this.migsystemservice.notifyGetWCAQuoteStates(this.quote.STATES);
                  // this.migsystemservice.notifyQuoteChanged(<WCAQuote>this.quote);
                  //enable insured and address for the new copied quote
                  if (this.menuClass.stepActiveObject.name == "QuoteInformation")
                  {
                      this.menuClass.stepActiveObject.forms.forEach(element => {
                          if (element.get('INSTEL') != null)
                              element.get('INSTEL').enable();
                          if (element.get('INSNAM') != null)
                              element.get('INSNAM').enable();
                          if (element.get('INSAD1') != null)
                              element.get('INSAD1').enable();
                          if (element.get('POBOX') != null)
                              element.get('POBOX').enable();
                          if (element.get('SUITENUMBER') != null)
                              element.get('SUITENUMBER').enable();
                          if (element.get('STREETNUMBER') != null)
                              element.get('STREETNUMBER').enable();
                          if (element.get('STREETNAME') != null)
                              element.get('STREETNAME').enable();
                          if (element.get('ADDRESSLINE2') != null)
                              element.get('ADDRESSLINE2').enable();
                          if (element.get('CITY') != null)
                              element.get('CITY').enable();
                          if (element.get('STATE') != null)
                              element.get('STATE').enable();
                          if (element.get('ZIPCODE') != null)
                              element.get('ZIPCODE').enable();
                      });
                  }
                  //take them back to the quote information screen
                  this.menuClass.GotoMenuItem('name', 'QuoteInformation');
                  this.cd.detectChanges();
              },
              error => {
                  this.migsystemservice.notifySystemNotification({ severity: 'error', summary: 'Workers Comp', detail: 'Copy Quote Failed...', event: "end" });
              });
              },
          error => {
              this.migsystemservice.notifySystemNotification({ severity: 'error', summary: 'Workers Comp', detail: 'Copy Quote Failed...', event: "end" });
    });

  });


      this.migsystemservice.subscribeSystemNotification().subscribe((systemNotification) => {
          if ((systemNotification.severity == "success") && (systemNotification.detail == "Quote Saved. ")
              && ((this.activeMenuItem.name == "PremiumSummary") || (this.activeMenuItem.name == "LocationSummary")))
          {
              //Whenever we save, the quote changes (notifyQuoteChanged), and we rebuild the menu steps for Location Summary (see location_summary.module.ts).
              //We need to make sure a Location Summary current active step remains active after we rebuild the menu steps.

              //This code is also necessary if a user is navigating to Premium Summary.
              this.menuClass.gotoStep(this.activeMenuItemIndex);
              this.cd.detectChanges();
          }
      });

      this.migsystemservice.subscribePremium().subscribe((premium) => {
          this.quote.POLICYTRANS.APRP = premium; // Set the quotes premium to the rating returned premium 5/13/21 ZJG
          this.showDiscretionaryWorksheetMenu(this.quote);
          this.beginQuoteChangeDetection();
      });

      this.migsystemservice.subscribeGetQuoteNow().subscribe(() => {
          this.getQuoteNow();
          this.menuClass.gotoStep(this.menuClass.menuObjectIndex("PremiumSummary"));
      });

      this.migsystemservice.subscribeGetQuote().subscribe(quoteInfo=> {
        this.migsystemservice.notifyGetWCAQuoteStates(this.quote.STATES); // fix for TFS 2498, this effectively refreshes our state objects so they can be updated after rating -JTL 
        this.handleUserRoleRestrictions(this.quote);
        this.quote = quoteInfo as WCAQuote;
        if (this.quote.POLICYTRANS != null && this.quote.POLICYTRANS.POLICY != "") {

            this.quoteChangesDetected();

            if ((this.quote.POLICYTRANS.APRP == 0) || (this.quote.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'N') || (this.quote.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'I'))
            {
                this.menuClass.isQuoteDirty = true;
            }

            this.menuClass.NeedNewPremSummary();

        }
      });

}

  beginQuoteChangeDetection() {
      this.quoteMemento = _.cloneDeep(this.quote);

      if (this.stepChangeSubscription != null)
      {
          this.stepChangeSubscription.unsubscribe();
      }

      this.stepChangeSubscription = this.migsystemservice.subscribeStepChanged().subscribe(() => {

          this.quoteChangesDetected();
          this.activeMenuItem = this.menuClass.stepActiveObject;
          if (this.activeMenuItem.name == "PremiumSummary")
          {
              // if (this.quote.GLPENTITY.GLPLOCATIONS.some(s=>s.LOCNUM=="001" && s.TERR ==''))
              // {
              //     this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Contractors', detail: "In order to rate the quote, please enter a location address that results in a successful territory code lookup.", event: "start" });
              //     this.menuClass.GotoMenuItem('locationId', '001');
              //     setTimeout(() => {
              //         this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Contractors', detail: "In order to rate the quote, please enter a location address that results in a successful territory code lookup.", event: "end" });
              //     }, 3000);
              //     return;
              // }
              this.getQuoteNow();
          }

          if (this.menuClass.menuObjectIndex("Referrals") > this.menuClass.stepActive)
          {
              this.menuClass.menuObject("Referrals").navSkip = false;
          }
      });
  }

  quoteChangesDetected() {

      this.activeMenuItemIndex = this.menuClass.stepActive;
      let currentWCAQuote = new WCAQuote(this.quote as WCAQuote);
      let mementoWCAQuote = new WCAQuote(this.quoteMemento);
      if (!(_.isEqual(currentWCAQuote, mementoWCAQuote)) && this.migRoles.editable)
      {
          this.quote.UpdateQuoteStatus(this.menuClass, true);

          var differences = diff(mementoWCAQuote, currentWCAQuote);
          // if (!(environment.production))
          //console.log(differences);
      }
  }

  updateQuoteStatus() {
      this.quote.UpdateQuoteStatus(this.menuClass, false);

      if (!(environment.production))
      {
          //console.log("WEBSTATUSCODE", this.quote.QUOTEPOLICYINFORMATION.WEBSTATUSCODE);
          //console.log("PREMIUM", this.quote.POLICYTRANS.APRP);
      }
  }

ngOnInit(): void {
      if (environment.serverType == 'PROD')
      {
          this.showTestingControls = false;
      }
}

  getQuoteNow(): void {
      // Don't need to do this for WCA???
      // Would most likely still want to call this function though
    //    let migLiabilityResources:MIGLiabilityResources = new MIGLiabilityResources();
    //    migLiabilityResources.setCTRQuote(this.quote);
    //    migLiabilityResources.ensureDefaultGlpLiabilityCoverage();
  }



  private handleUserRoleRestrictions(quote: IQuote): void{
      let roleSecurity = this.authService.isEditiable(quote);
      this.migRoles.editable = roleSecurity.editable;
      this.migRoles.roles = roleSecurity.roles;
      this.migRoles.ratingOverride = roleSecurity.ratingOverride;
      this.migRoles.transactionTypeOverride = roleSecurity.transactionTypeOverride;
      if (environment.serverType == 'PROD')
      {
          this.migsystemservice.notifyValidateForm(this.migRoles.editable);
      }
  }

  private showDiscretionaryWorksheetMenu(quote:WCAQuote) : void{
    this.menuClass.ShowHideMenuItemAt(false,'DiscretionaryWorksheet');
    // /** COMMENTED OUT for testing */
    if(this.discClass.ShowDiscretioanryMenuItem(quote)){
        this.showDiscretionaryWorksheet = true;
       this.menuClass.ShowHideMenuItemAt(true,'DiscretionaryWorksheet');
    }
    else{
        this.menuClass.ShowHideMenuItemAt(false,'DiscretionaryWorksheet');
    }
}
}

