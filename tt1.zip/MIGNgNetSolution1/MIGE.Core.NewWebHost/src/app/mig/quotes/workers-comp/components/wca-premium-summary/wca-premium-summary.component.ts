/* ****************************************************************************************************
* PROGRAM DESCRIPTION  - Premium Summary (WCA) 
* NOTES: 
* This component is tied to the Premium Summary menu step, specifically for WCA. 
* BUG FIXES: 
* 6/29/21: Fixed an issue where Michigan quotes were rating in MMIC. Michigan now rates in MPIC. (TFS 2313) -JTL
* 7/22/21: Fixed issue where "Quote needs to be rated"  message was preventing user from advancing, even after rating. (TFS 2346) -JTL
* 8/11/21: Removed "Preferred Pricing Eligibility" message for WCA (TFS 2375) -JTL 
* 8/24/21: Removed Preferred Pricing Eligibility Flag for rating, Now "Rate in MPIC" and "Rate in MMIC" buttons will always appear for their respective States (TFS 2395) -JTL
* 10/7/21: Company name stays the same when re entering a quote(TFS 2479) ZJG
* 10/15/21: Write to DWCP130 DEVCDE field when CO is MPIC and State is MA (TFS 2473) -ZJG
* 11/16/21: Remove setting of POLICYTRANS.CO on init, as the Company is set on quote creation.
* 11/19/21: Remove "Quote in MPIC/MMIC" button in colleague view (TFS 2533) -JTL 
* 1/14/22: Re-added "Quote in MPIC/MMIC" button in colleague view (JIRA MSC-20375) - JTL 
****************************************************************************************************/
import { Component, Input, ViewChild, ViewEncapsulation, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { MIGOverlayPanel } from '@overridden/primeng-overlaypanel/overlay';
import { OverlayPanel } from 'primeng/overlaypanel';
import { Subscription } from 'rxjs';
import { timer } from 'rxjs';
import { MIGSystemService } from '@services/mig.service';
import { IQuote } from '@interfaces/IQuote';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { InputMasksClass } from '@helpers/masks';
import { RatingService } from '@root/services/rating.service';
import { finalize } from "rxjs/operators";
import { DocumentService } from '@root/services/document.service';
import { RATINGRETURN } from '@classes/Common/RATINGRETURN';
import { ContractorsTooltips } from '@helpers/tooltips';
import * as moment from 'moment';
import {Functions} from '@helpers/functions';
import { MenuClass } from '@root/system/menu/menu';
import { WCAQuote } from '@classViewModels/WCA/WCAQuote';
import * as _ from 'lodash';

@Component({
  selector: 'mig-wca-premium-summary',
  templateUrl: './wca-premium-summary.component.html',
  styleUrls: ['./wca-premium-summary.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class WcaPremiumSummaryComponent implements OnDestroy {
    preferredPricingEligibilityFlag: string = "N";

  ngOnDestroy() : void{
    if(this.subscription) this.subscription.unsubscribe();
        if(this.timerSubscription) this.timerSubscription.unsubscribe();
        this.changeDetectionRef.detach();
  }

  @Input() formData: any;
  @Input() quote: WCAQuote;
  @ViewChild(OverlayPanel, { static: false }) ProposalPanel: OverlayPanel;
	@ViewChild(OverlayPanel, { static: false }) PrintPanel: OverlayPanel;
	@ViewChild(OverlayPanel, { static: false }) preferred: OverlayPanel;
	@ViewChild("summaryPricing", { static: false }) summaryPricing: MIGOverlayPanel;
    
    subscription: Subscription;
    timerSubscription: Subscription;

    quote_valid: Date;
    premium: any = 0;
    discretionaryRatingResult: RATINGRETURN;

    tmp_pricing: number;
    og_premium: number = this.premium;
    tmp_discretionary_pricing: number;

    company: string = "Merchants Mutual Insurance Company";
    collapsed: boolean = true;
    preferred_pricing: boolean = false;
    calculating: boolean = false;
    showDiscretionaryPricing: boolean = false;
    discPricingApplied: boolean = false;
    showBillingCalculator: boolean = false;
    generateRating: boolean = false;
    showDiscretionaryButton: boolean = true;
    coverage1: any;
    coverage2: any;
    coverage3: any;
    coverage4: any;
    coverage5: any;
    discretionary_pricing: boolean;
    effective_date: "20181117";
      // decimalMask = [/[0-1]/, '?', /\./, /[0-9]/, /[0-9]/];
    ratingServiceSubscription: any;
    before: string = "";
    loaded: boolean = true;
    invalid: boolean = false;
    showUpdatePremiumBtn: boolean = false;
    TimeToComplete: string = "";
	block_message: any[] = [{ success: false, text: "Calculating Premium...", visible: true },
                        	{ success: false, icon: "fa-info-circle",text: "Quote Information", visible: true },
                        	{ success: false, icon: "fa-thermometer-half",text: " Employers Liability Limits",visible: true },
                        	{ success: false, icon: "fa-globe-americas",text: "State Summary",visible: true },
                        	{ success: false, icon: "fa-list-alt",text: "Preparing Premium Summary",visible: true }];

    ratingError: boolean = false;
    ratingErrorMessage: string = "";
    LocationSummaryIndex: number = 4;
    hasSubcontractedWorkClass: boolean = true;
  constructor(
    public func: Functions,
		public migsystemservice: MIGSystemService,
		public migRoles: MIGSecurityRoles,
        public masks: InputMasksClass,
        public changeDetectionRef: ChangeDetectorRef,
        public contractorsTooltips: ContractorsTooltips,
        public ratingService: RatingService,
        public documentService: DocumentService,
        private menuClass: MenuClass
  ) { }

  
  ngOnInit(): void {
    this.calculating = true;
    if(this.quote.STATES.filter(x=>x.RECORDSTATE !="D").length > 0 ){
        if(this.quote.STATES.filter(x=>x.RECORDSTATE !="D")[0].COVERG == "20"){ // do not show the "Apply Discretionary Pricing" button if State is MA
            this.showDiscretionaryButton = false;
        }
    }
    //Set the company field to what it was stored as not just set it to MMIC if state is not michigan -ZJG
    //this.quote.POLICYTRANS.CO = this.quote.STATES.filter(x => x.RECORDSTATE != "D")[0].COVERG == "21" ? "MPIC" : this.quote.POLICYTRANS.CO; 
    if(this.migRoles.editable){ // if in agent view, we want to generate the rating. 
        this.generateRating = true;
    }
    this.setCompanyName();

    //this sets the quote valid until date to 30 days from the effetive date
    this.quote_valid = this.quote.QUOTEPOLICYINFORMATION.NEWEFFECTIVEDATE === 0 ?  
    moment(this.func.DTEWinsToPrimeNG(this.quote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE)).add(30, 'd').toDate() : 
    moment(this.func.DTEWinsToPrimeNG(this.quote.QUOTEPOLICYINFORMATION.NEWEFFECTIVEDATE)).add(30, 'd').toDate();
    
    var date = new Date();
    this.before = date.toLocaleTimeString();
    this.funcGetPremium(this.quote);
    
}

  unmask(val) {
    return val.replace(/\D+/g, '');
  }

removePricingModifer(val: string, event): void {
    switch (val) {
        case "discretionary":
            this.discretionary_pricing = false;
            this.premium -= 25;
            this.summaryPricing.toggle(event);
            this.summaryPricing.toggle(event);
            break;
        case "c1":
            this.coverage1 = false;
            break;
        case "c2":
            this.coverage2 = false;
            break;
        case "c3":
            this.coverage3 = false;
            break;
        case "c4":
            this.coverage4 = false;
            break;

        case "c5":
            this.coverage5 = false;
            break;
    }
}

funcIsPricingModifed() {
    let out = false;
    if (this.discretionary_pricing) { out = true; }
    if (this.coverage1) { out = true; }
    if (this.coverage2) { out = true; }
    if (this.coverage3) { out = true; }
    if (this.coverage4) { out = true; }
    if (this.coverage5) { out = true; }
    return out;
}


funcExpandAll() {
    this.collapsed = false;
}

funcCollapseAll() {
    this.collapsed = true;
}

funcRemovePreferredPricing() {

    this.quote.POLICYTRANS.CO = "MMIC";
    this.setCompanyName();
    this.generateRating = true;
    this.calculating = true;
    this.funcGetPremium(this.quote);
}

funcCalculatePreferredPricing() {
    this.quote.POLICYTRANS.CO = "MPIC";
    this.setCompanyName();
    this.calculating = true;
    this.generateRating = true;
    this.funcGetPremium(this.quote);
}

setCompanyName() {
    if (this.quote.POLICYTRANS.CO == "MPIC"){
        this.company = "Merchants Preferred Insurance Company";
        this.quote.STATES.filter(x=> x.RECORDSTATE != "D").forEach(state =>{
            if(state.COVERG == "20"){
                state.DEVCDE = "01";
            }
        });
    }
    

    if (this.quote.POLICYTRANS.CO == "MMIC"){
        this.company = "Merchants Mutual Insurance Company";
        this.quote.STATES.filter(x=> x.RECORDSTATE != "D").forEach(state =>{
                state.DEVCDE = "";
        });
    }
}

funcGetPremium(quote: WCAQuote): any {
    if (this.generateRating) {
    //Reset Premium;
    this.quote.POLICYTRANS.APRP = 0;
    //GET PREMIUM RATING SERVICE CALL
    
    this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Workers Comp', detail: "Initiating Premium Summary...", event: "start" });
    return this.ratingServiceSubscription = this.ratingService.GetRating(quote)
        .pipe(finalize(() => {
            //need to notify the quote here in case EFFDTE changed
            //this.migsystemservice.notifyQuoteChanged(this.quote);
            this.migsystemservice.notifyGetQuote(this.quote);
            //
            this.calculating = false;
            this.changeDetectionRef.detectChanges();
        }))
            .subscribe(ratingResponse => {
            if(ratingResponse.RATING == undefined)
            {
                //this.ratingError = true;
                // this.ratingErrorMessage = ratingResponse.RATING.RATINGRETURN.RETURNMESSAGE;
                // this.premium = ratingResponse.RATING.RATINGRETURN.RETURNPREMIUM;
                //this.migsystemservice.notifyPremium(0);
                //this.preferredPricingEligibilityFlag = ratingResponse.RATING.RATINGRETURN.PREFERREDPRICINGELIGIBLE; // commenting this out because per Sara the system should no longer determine eligibility, the eligibility is now determined by the Underwriter's referral -JTL
                this.funcWait();
                //this.migsystemservice.notifySystemNotification
                this.migsystemservice.notifySystemNotification({ severity: 'error', summary: 'Workers Comp', detail: "Failed to initiate Premium Summary", event: "end" });
                this.quote.HTTPREQUESTRESPONSE.HTTPREQUEST = this.before;
                var date = new Date();
                this.quote.HTTPREQUESTRESPONSE.HTTPRESPONSE = date.toLocaleTimeString();
                this.changeDetectionRef.detectChanges();
                return;
            }
            if (ratingResponse.RATING.RATINGRETURN.RETURNCODE == "N")
            {  
                /* need to assign the saved quote back to screen in case of effdte change happens during save quote */
                //this.quote = new quote(<quote>ratingResponse.QUOTE);                  
                this.ratingError = true;
                this.ratingErrorMessage = ratingResponse.RATING.RATINGRETURN.RETURNMESSAGE;
                this.premium = ratingResponse.RATING.RATINGRETURN.RETURNPREMIUM;
                this.migsystemservice.notifyPremium(0);
                //this.preferredPricingEligibilityFlag = ratingResponse.RATING.RATINGRETURN.PREFERREDPRICINGELIGIBLE; // commenting this out because per Sara the system should no longer determine eligibility, the eligibility is now determined by the Underwriter's referral -JTL
                this.funcWait();
                this.migsystemservice.notifySystemNotification({ severity: 'error', summary: 'Workers Comp', detail: "Failed to initiate Premium Summary", event: "end" });
                this.quote.HTTPREQUESTRESPONSE.HTTPREQUEST = this.before;
                var date = new Date();
                this.quote.HTTPREQUESTRESPONSE.HTTPRESPONSE = date.toLocaleTimeString();
                this.changeDetectionRef.detectChanges();
                return;
            }
            /* need to assign the saved quote back to screen in case of effdte change happens during save quote */
            this.quote = new WCAQuote(<WCAQuote>ratingResponse.QUOTE);
            this.setCompanyName();
            //discretionaryRatingResult - added for NJ and PA dereg since Haoling is now sending flags for unmodified premium
            this.discretionaryRatingResult = ratingResponse.RATING.RATINGRETURN;
            this.premium = ratingResponse.RATING.RATINGRETURN.RETURNPREMIUM;
            this.preferredPricingEligibilityFlag = ratingResponse.RATING.RATINGRETURN.PREFERREDPRICINGELIGIBLE;
            this.quote.POLICYTRANS.APRP = ratingResponse.RATING.RATINGRETURN.RETURNPREMIUM;
            this.migsystemservice.notifyPremium(this.premium); // 7/22/21: we need to first notify the premium so that the POLICYTRANS.APRP will be updated.
            //this.coveragesToConsider = ratingResponse.RATING.RATINGRETURN.COVERAGESTOCONSIDER;
           // this.filterVermontCoverage();
            //this.coveragesToConsiderExists = this.CoveragesToConsiderExists();
            this.funcWait();
            this.migsystemservice.notifySystemNotification({ severity: 'success', summary: 'Workers Comp', detail: 'Ready to process Premium Summary!', event: "end" });
            this.og_premium = this.premium;
            this.migsystemservice.notifyGetQuote(this.quote);
            this.menuClass.isQuoteDirty = false;
            this.quote.HTTPREQUESTRESPONSE.HTTPREQUEST = this.before;
            var date = new Date();
            this.quote.HTTPREQUESTRESPONSE.HTTPRESPONSE = date.toLocaleTimeString();  
            this.changeDetectionRef.detectChanges();  
        });
       
    }
    else {
        this.premium = this.quote.POLICYTRANS.APRP;
        this.calculating = false;
        this.loaded = true;
        this.menuClass.isQuoteDirty = false;
    }
}

funcWait() {
    for (let i = 0; i < this.block_message.length; i++) {
      this.block_message[i].success = false;
    }
        
    let len = this.block_message.filter(x => x.visible == true).length;

    this.loaded = false;

    let steplength = 500;
    let ticktock = len;
    let tick = timer(0, steplength);

    this.timerSubscription = tick.subscribe(t => {
      if (t == (ticktock - 1 ? ticktock - 1 : 1)) {
        this.loaded = true;
        this.timerSubscription.unsubscribe();
        this.changeDetectionRef.detectChanges();

      } else {
        if (this.block_message && this.block_message[t] && this.block_message[t].text && this.block_message[t].visible) {

          this.block_message[t].success = true;
          this.changeDetectionRef.detectChanges();
        }
      }
    });
}


openDiscretionaryPricing() {
    this.showDiscretionaryPricing = true;
}

cancelDiscPricing() {
    this.showDiscretionaryPricing = false;
}

applyDiscPricing(quote: IQuote) {
    if (this.calculating)
        return;

    this.generateRating = true;
    var newQuote = Object.assign(new WCAQuote(), quote);
    this.quote = newQuote;        
    this.cancelDiscPricing();
    this.block_message.forEach(msg => {
        msg.success = false;
    });
    this.ngOnInit();
}
// filterVermontCoverage() {
// if (this.quote.POLICYTRANS.CANSTE == "44") {
//   this.coveragesToConsider=this.coveragesToConsider.filter(f => f.COVERG != "CEO" && f.COVERG != "CYB");
// }
// }

// showAdditionalCoverageDescription(COVERG: string) {
//     this.coveragesToConsider.forEach(cov => {
//         cov.TOOLTIPDISPLAY = (cov.COVERG == COVERG);
// })
// this.coveragesToConsiderExists = this.CoveragesToConsiderExists();
// }

// private CoveragesToConsiderExists() {
//     return (
//                 (this.coveragesToConsider != null && this.coveragesToConsider.length > 0)
//                 || 
//                 (!(this.quote.HasPropertyCoverage()))
//                 ||
//                 (!(this.quote.HasAdditionalInsureds()))
//             );
// }

openBillingCalculator() {
    this.showBillingCalculator = true;
}

cancelBillingCalculator() {
    this.showBillingCalculator = false;
}

}
