/* ****************************************************************************************************
* PROGRAM DESCRIPTION  - Employers Liability Limits 
* NOTES: 
* - This component is specific to Worker's Comp and is the second menu step. 
* 
* - 8/5/21: Removed EMPLIAFORMAT from the EMPLOYERSLIABLIMITS object and replaced it with a global. -JTL
* - 9/15/21: Fixed Typo in "Year Business Started" field. (TFS 2424) -JTL 
* - 9/17/21: Removed tooltip for "Each Accident" field. (TFS 2434) - JTL
* - 11/30/21: Set cap for YRSBUS field at 99 -JTL
****************************************************************************************************/
import { Component, Input, OnInit, ChangeDetectorRef } from '@angular/core';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { UntypedFormBuilder, UntypedFormGroup, UntypedFormControl } from '@angular/forms';
import { MIGValidatorLiability } from '@CTRcomponents/liability_limits/liability_limits.validators';
import { Functions } from '@helpers/functions';
import { Subscription } from 'rxjs/internal/Subscription';
import { distinctUntilChanged } from 'rxjs/operators';
import { MIGSystemService } from '@services/mig.service';
import { MenuClass } from '@root/system/menu/menu';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { ContractorsTooltips } from '@helpers/tooltips';
import { WCAQuote } from '@classViewModels/WCA/WCAQuote';


@Component({
  selector: 'mig-employers-liability-limits',
  templateUrl: './employers-liability-limits.component.html',
  styleUrls: ['./employers-liability-limits.component.css']
})
export class EmployersLiabilityLimits implements OnInit {


  formBuilder: UntypedFormBuilder;
	formChanged: boolean = false;
	formGroup: UntypedFormGroup;
	vis: boolean = false;
	@Input() public quote: WCAQuote;
	@Input() public hasError: boolean = false;
	@Input() menuSteps: any[] = [];
	@Input() step: number = 1;
	migLiabilityValidator: MIGValidatorLiability;
	FormGroupSubscription: Subscription;
	EOLMTSubscription: Subscription;
	PAEXCSubscription: Subscription;
	updateRecordState: Subscription;
	nextButtonClickedSub: Subscription;
	businessRules: true;
	errors: any[] = [];
	stepName = "EmployersLiabilityLimits";
	lob: string = "";
	EMPLIAFORMAT: string;
	YEARFORMAT: string = '';
	
	constructor(
		public contractorsDropDowns: ContractorsDropDowns,
		public func: Functions,
		public migsystemservice: MIGSystemService,
		public menuClass: MenuClass,
		public migRoles: MIGSecurityRoles,
		public contractorsTooltips: ContractorsTooltips,
        private changeDetectorRef: ChangeDetectorRef
	) {
		
		if (this.formBuilder == null) {
			this.formBuilder = new UntypedFormBuilder();
		}
		this.migLiabilityValidator = new MIGValidatorLiability(this.func);
		//this.lob = ; // Hardcode this to WCA for testing 
		
	}

	//WCA
	get EMPLIA() { return this.formGroup.get("EMPLIA");} // New form group
	get YRSBUSSTARTED() { return this.formGroup.get("YRSBUSSTARTED");} // New form group

	ngOnDestroy() {		
		if (this.FormGroupSubscription) { this.FormGroupSubscription.unsubscribe(); }
		if(this.updateRecordState) this.updateRecordState.unsubscribe();
	}

	ngAfterViewInit(): void{
		if(!this.migRoles.editable) {
			this.formGroup.disable();
		}
	}


	ngOnInit() {
		
		//for year business started box fill
		var d = new Date();
		if(this.quote.EMPLOYERSLIABLIMITS.YRSBUS != -1){
			this.YEARFORMAT = (d.getFullYear() - this.quote.EMPLOYERSLIABLIMITS.YRSBUS).toString();
		}

		// document.getElementById('liabilityLimitsForm').scrollTop;		
		//let processBR = new LiabilityLimitsBR();

		// get our form group for error checking
		this.formGroup = this.menuClass.menuObject(this.stepName).form; 
		
		this.quote.EMPLOYERSLIABLIMITS.EMPFLG = "N";

		//WCA
		this.formGroup.addControl('EMPLIAFORMAT', new UntypedFormControl(this.quote.EMPLOYERSLIABLIMITS.EMPLIA)); //Set the dropdown from EMPLIA value from backend
		this.formGroup.addControl('YRSBUSSTARTED', new UntypedFormControl(this.YEARFORMAT))
		this.YRSBUSSTARTED.setValidators([this.migLiabilityValidator.ValidateRequired('YRSBUSSTARTED','Year Business Started'),
			this.migLiabilityValidator.ValidateMinLength(4, 'YRSBUSSTARTED','Year Business Started')]);
		this.YRSBUSSTARTED.updateValueAndValidity({emitEvent: false});
 
		// Set Form Group based on value of EMLIA
		if(this.quote.EMPLOYERSLIABLIMITS.EMPLIA == "500/500/500"){
			this.formGroup.get("EMPLIAFORMAT").setValue("500,000");
			//this.quote.EMPLOYERSLIABLIMITS.EMPLIAFORMAT = "500,000";
			this.EMPLIAFORMAT = "500,000"
		}
		else if(this.quote.EMPLOYERSLIABLIMITS.EMPLIA == "1000/1000/1000"){
			this.formGroup.get("EMPLIAFORMAT").setValue("1,000,000");
			//this.quote.EMPLOYERSLIABLIMITS.EMPLIAFORMAT = "1,000,000";
			this.EMPLIAFORMAT = "1,000,000";
		}
		else {
			this.formGroup.get("EMPLIAFORMAT").setValue("100,000");

			//this.quote.EMPLOYERSLIABLIMITS.EMPLIAFORMAT = "100,000";
			this.EMPLIAFORMAT = "100,000"
			this.quote.EMPLOYERSLIABLIMITS.EMPLIA = "100/100/500" // 5/12/21: if the EMPLIA is not 1000/1000/1000, 500/500/500, or "", then we default it to 100/100/500
		}
    
		this.FormGroupSubscription = this.formGroup.valueChanges.pipe(distinctUntilChanged()).subscribe(data => {
			//this.setValues();
			//this.applyEOLMTPAEXCRules(data);<--removed; put in setValues()
			
			//Set the both the form group and the EMPLIA value whenever the dropdown is changed
			if(data.EMPLIAFORMAT == "500,000"){
				this.EMPLIAFORMAT = "500,000";
				//this.quote.EMPLOYERSLIABLIMITS.EMPLIAFORMAT = "500,000";
				this.quote.EMPLOYERSLIABLIMITS.EMPLIA = "500/500/500";
			}
			else if(data.EMPLIAFORMAT == "1,000,000"){
				this.EMPLIAFORMAT = "1,000,000";
				//this.quote.EMPLOYERSLIABLIMITS.EMPLIAFORMAT = "1,000,000";
				this.quote.EMPLOYERSLIABLIMITS.EMPLIA = "1000/1000/1000";
			}
			else{
				this.EMPLIAFORMAT = "100,000";
				//this.quote.EMPLOYERSLIABLIMITS.EMPLIAFORMAT = "100,000";
				this.quote.EMPLOYERSLIABLIMITS.EMPLIA = "100/100/500";
			}
			//calculate years in business to number for WINS as a number
			if(data.YRSBUSSTARTED.length >= 4 && data.YRSBUSSTARTED <= d.getFullYear()){
				this.quote.EMPLOYERSLIABLIMITS.YRSBUS = (d.getFullYear() - data.YRSBUSSTARTED);
				if(this.quote.EMPLOYERSLIABLIMITS.YRSBUS >= 100){ // as of 11/30/21, the YRSBUS field can only hold up to 2 digits. Because of this, if the user enters a year more than 100 years ago, we cap the value at 99 -JTL
					this.quote.EMPLOYERSLIABLIMITS.YRSBUS = 99;
				}
			}
			//allows for form auto error updating on the panels
			this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive);

		});

		this.updateRecordState = this.migsystemservice.subscribeUpdateRecordState().subscribe(() => {
			
			this.quote.EMPLOYERSLIABLIMITS.POLICY = this.quote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
			this.quote.EMPLOYERSLIABLIMITS.EFFDTE = this.quote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
			this.quote.EMPLOYERSLIABLIMITS.TRANS = this.quote.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;
			this.quote.EMPLOYERSLIABLIMITS.RCDTYP = this.quote.QUOTEPOLICYINFORMATION.RECORDTYPE;
			this.quote.EMPLOYERSLIABLIMITS.EDSDTE = this.quote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;
			this.quote.EMPLOYERSLIABLIMITS.RECORDSTATE = "U";

		});
		this.changeDetectorRef.detectChanges();
		//this.setValues();
	}

	// setValues() {
		
	// 	// moving the set quote values code from the form group subscription
	// 	// to here because, you may not touch this form
	// 	// (default values provided may be acceptable)
	// 	// and therefor never trigger the form update
	// 	let data = this.formGroup.getRawValue();
    //     this.formChanged = true;
    //     this.changeDetectorRef.detectChanges();
		
	// }
	
}


