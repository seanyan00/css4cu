/* ****************************************************************************************************
* PROGRAM DESCRIPTION  - Individuals Included / Excluded 
* NOTES: 
* This component is tied to the Individuals Included / Excluded menu step. This is a menu step specific to WCA. 
* This is the parent component of individual.component. This component is a container that holds all individuals. 
* BUG FIXES: 
* 6/30/21: Fixed an issue where the validation was not firing on the "Next" click. (TFS 2314) -JTL
* 8/24/21: Fixed issue where the validation was still not firing on the "Next" or "Save" Click by adding unsubscribes in States component (TFS 2402) -JTL
****************************************************************************************************/
import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { WCAIndividual } from '@classes/WCA/WCAIndividual';
import { WCASTATES } from '@classes/WCA/WCAStates';
import { WCAQuote } from '@classViewModels/WCA/WCAQuote';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { MIGSystemService } from '@root/services/mig.service';
import { AppErrors } from '@root/shared_components/errors/app-errors';
import { MenuClass } from '@root/system/menu/menu';
import * as _ from 'lodash';
import { Subscription } from 'rxjs';
@Component({
  selector: 'mig-individuals-included-excluded',
  templateUrl: './individuals-included-excluded.component.html',
  styleUrls: ['./individuals-included-excluded.component.css']
})
export class IndividualsIncludedExcludedComponent implements OnInit, OnDestroy{

  @Input() quote: WCAQuote;
  stateObject: WCASTATES;
  panelHeaders: string[] = [];
  allIndividuals: WCAIndividual[] = [];
  isEditingIndividual: boolean = false; 
  disableDelete: boolean = false; 
  nextClickSubscription: Subscription
  constructor( 
     public migRoles: MIGSecurityRoles,
     public dropdowns: ContractorsDropDowns,
     public menuClass: MenuClass,
     public migsystemservice: MIGSystemService) {}
  
  ngOnInit(): void {
  this.quote.STATES.filter(x=>x.RECORDSTATE != "D").forEach((state:WCASTATES) =>{
  if(state.INDIVIDUALS.filter(x=> x.RECORDSTATE != "D").length == 0){ // if we cannot find an individual that hasn't been deleted in the State object, we want to add a new individual, because each State needs at least one individual 
    state.AddNewIndividual();
  }
  state.INDIVIDUALS.forEach((individual: WCAIndividual) =>{
      if(individual.RECORDSTATE != "D"){
        this.allIndividuals.push(individual);
      }
    });
  });
  this.menuClass.menu.forms = []; // Need to clear out the forms when we come back to page
  let stateIndividuals = [];
  this.nextClickSubscription = this.migsystemservice.subscribeNextClicked().subscribe(x=>{
    let miscErrors: any[] = []; // used to hold non-formgroup validation rules. For example, validating that there is at least one individual per state is not dependent on the formgroup.
    let formGroupErrors: any[] = []; // used to hold the errors from our formGroups.
    let totalErrors: any[] = []; // used to hold all of our errors.
    this.quote.STATES.filter(x => x.RECORDSTATE != "D").forEach((state: WCASTATES) => {
      stateIndividuals = []; // this array will hold all the individuals for a particular state. it will reset when we evaluate the next state.
      state.INDIVIDUALS.filter(x=>x.RECORDSTATE != "D").forEach((individual: WCAIndividual) => {
          stateIndividuals.push(individual); // as long as the record state isn't D, we want to push the individual onto the stateIndividuals array.
      });
      if(stateIndividuals.length == 0){  // we do not want to be able to advance if each state doesn't have at least one individual.
          miscErrors.push({severity: "error",
          summary: "Individuals",
          detail: "There must be at least one individual for each state",
          sticky: true,
          closable: false});
      }
      });
      totalErrors = [];
      for(let i = 0; i < this.menuClass.menu.forms.length; i++){
        formGroupErrors = this.menuClass.CalculateErrorsFormGroup(this.menuClass.menu.forms[i]);
        if(formGroupErrors.length > 0){ totalErrors.push(formGroupErrors); }
      }

      if(miscErrors.length > 0){
        totalErrors = totalErrors.concat(miscErrors); // add the miscErrors into the total.
      }
      this.migsystemservice.notifyDoneClicked(totalErrors); // now that we have all our errors together, send the error messages to the error panel.
    });
  }
  
  ngOnDestroy(){
    this.nextClickSubscription.unsubscribe();
  }
  updateHeader(){ // 
    this.panelHeaders = [];
    this.menuClass.menu.forms.forEach((form: UntypedFormGroup) => { // for each formGroup in menu.forms (will be ordered by sequence number)
    let header = form.get("MiscName").value + " " +  _.find(this.dropdowns.MSCTTL, x=>x["value"] == form.get("Title").value).label; 
    this.panelHeaders.push(header != " " ? header : "New Individual");
    })
  }

  addFormGroup(formGroup: UntypedFormGroup){ // each individual will send their formgroup to this component using an output emitter. We then push the form group onto the menu in order to validate. 
    this.menuClass.menu.forms.push(formGroup);
  }

  addAnotherIndividual(){ // called when you click "Add Another". Because our individual is bound to the states object on the quote, we have to add our individual somewhere, so we add it to the first state by default. 
    this.quote.STATES[0].AddNewIndividual(); // add new individual to the first state on the quote
    this.allIndividuals.push(this.quote.STATES[0].INDIVIDUALS[this.quote.STATES[0].INDIVIDUALS.length - 1]) 
    this.updateHeader();
  }

  deleteIndividual(seqno: string){ // called when we click "Delete"
    let stop = false;
    this.allIndividuals.forEach((individual: WCAIndividual) => { // loop through our individuals
      if(individual.MSCSEQ == seqno && !stop){ // if we find our individual with our selected sequence number
        individual.RECORDSTATE = "D"; 
        this.allIndividuals = this.allIndividuals.filter(x=> x.MSCSEQ != seqno && x.RECORDSTATE != 'D'); // filter out our individuals array. The end result should be every individual except the one we just deleted.
        this.resetSequenceNumbers(); // reset our sequence numbers for the individuals that remain.
        this.menuClass.menu.forms = this.menuClass.menu.forms.filter((form:UntypedFormGroup) => form.get("SequenceNumber").value != seqno); // filter out our deleted form group from the menu forms. 
        stop = true; // set stop to true, so we only execute this if statement once. Because resetSequenceNumbers() changes the sequence number of our individuals, we don't want to execute this if statement more than once because we will continuously find and filter out a matching sequence number.
      }
    });
    this.updateHeader(); // now that we have filtered our arrays, we can update the header labels.
  }

  resetSequenceNumbers(){ // When we delete an individual, we want to reset the sequence numbers
    for(let i = 0; i < this.allIndividuals.length; i++){
      this.allIndividuals[i].MSCSEQ = _.padStart((i + 1).toString(),2,'0'); // sets the sequence number of each individual's sequence number in the object graph. Note that we only set the sequence number of those where RECORDSTATE != D
      this.menuClass.menu.forms[i].get("SequenceNumber").setValue(this.allIndividuals[i].MSCSEQ); // update the SequenceNumber form control for the form groups and individual objects are properly aligned
    }
  }

  canAddAnotherIndividual(): boolean { // We should only be able to add another individual if all the current individuals are valid
    if(this.allIndividuals.length == 0){
      return true;
    }
    return _.filter(this.menuClass.menu.forms, indFormGroup => indFormGroup.invalid).length == 0;
  }

}
