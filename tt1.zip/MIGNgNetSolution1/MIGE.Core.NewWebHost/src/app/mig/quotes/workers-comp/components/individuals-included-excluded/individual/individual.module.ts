import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PanelModule } from 'primeng/panel';
import { TabViewModule } from 'primeng/tabview';
import { FieldsetModule } from 'primeng/fieldset';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { MIGInputSwitchModule } from '@overridden/primeng-inputswitch/switch.module';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { DynamicComponentModule } from '@dynamic/dynamic_component/dynamic.module';
import { TextMaskModule } from 'angular2-text-mask';
import { MIGMessageModule } from '@overridden/primeng-message/message.module';
import { PipesModule } from '@pipes/pipes.module';
import { MIGYearPickerModule } from '@overridden/mig-yearpicker/year.module';
import { TooltipModule } from 'primeng/tooltip';
import { MIGCalendarModule } from '@overridden/primeng-calendar/calendar.module';
import { IndividualComponent } from './individual.component';
import { AccordionModule } from 'primeng/accordion';

@NgModule({
  declarations: [IndividualComponent],
  imports: [
    CommonModule,
    FormsModule,
	TabViewModule,
	PanelModule,
	FieldsetModule,
	MIGDropDownModule,
	MIGCheckboxModule,
	MIGInputtextModule,
	MIGInputSwitchModule,
	MIGButtonModule,
	ReactiveFormsModule,
	DynamicComponentModule,
	TextMaskModule,
	MIGMessageModule,
	AccordionModule,
	MIGYearPickerModule,
	TooltipModule,
	PipesModule,
    MIGCalendarModule
  ],
  exports: [IndividualComponent]  

})
export class IndividualModule { }
