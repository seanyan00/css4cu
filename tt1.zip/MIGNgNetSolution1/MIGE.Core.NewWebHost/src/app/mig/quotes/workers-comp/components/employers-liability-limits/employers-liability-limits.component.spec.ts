import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployersLiabilityLimits } from './employers-liability-limits.component';

describe('EmployersLiabilityLimitsComponent', () => {
  let component: EmployersLiabilityLimits;
  let fixture: ComponentFixture<EmployersLiabilityLimits>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmployersLiabilityLimits ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployersLiabilityLimits);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
