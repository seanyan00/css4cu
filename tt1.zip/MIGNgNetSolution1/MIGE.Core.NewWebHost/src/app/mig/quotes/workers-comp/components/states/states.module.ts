import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StatesComponent } from './states.component';
import { FormsModule, ReactiveFormsModule, UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
//import { GrowlModule } from 'primeng/growl';
import { PanelModule } from 'primeng/panel';
import { PipesModule } from '@pipes/pipes.module';
import { MenuClass } from '@root/system/menu/menu';
import { MIGSystemService } from '@services/mig.service';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import * as _ from 'lodash';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { MIGCalendarModule } from '@overridden/primeng-calendar/calendar.module';
import { TextMaskModule } from 'angular2-text-mask';
import { WCASTATES } from '@classes/WCA/WCAStates';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { WcaLocationsModule } from '../wca-locations/wca-locations.module';
import { AccordionModule } from 'primeng/accordion';
import { WCALOCATIONS } from '@classes/WCA/WCALocations';


@NgModule({
  declarations: [StatesComponent],
  imports: [
    CommonModule,
    WcaLocationsModule,
    MIGButtonModule,
    AccordionModule,
    FormsModule,
    ReactiveFormsModule,
    ConfirmDialogModule,
    CommonModule,
    PanelModule,
    MIGDropDownModule,
    PanelModule,
    MIGCalendarModule,
    MIGInputtextModule,
    TextMaskModule
    
  ],
  exports: [StatesComponent],
  providers: [StatesComponent, PipesModule]
})
export class StatesModule {
  stateFormGroup: UntypedFormGroup;
  stateLabel: string  = "";
  statesFull: any = {}
    constructor(
      public menuClass: MenuClass,
      private formBuilder: UntypedFormBuilder,
      public migsystemservice: MIGSystemService,
      public dropdowns: ContractorsDropDowns
    ) {	
      this.stateFormGroup = this.formBuilder.group({});
    menuClass.addMenuItem({
      name: 'States',
      label: 'States',
      color: "ui-steps-number-default",
      navSkip: true,
      active: false,
      hasError: false,
      errors: [],
      buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }, { button: "GetQuoteNow" }],
      forms: [this.stateFormGroup],
      icon: 'fa fa-globe-americas',
      stateDataObject: new WCASTATES(),
      block: [],
      visible: true,
      quote: "premium"
    });

    let loading = { // we want this menu step to display when the quote first loads. After we have finished loading, this step should be removed and replaced with the states associated with the quote. 
			name: 'States',
			label: "Loading Data",
			sublabel: 'Please wait...',
			color: "ui-steps-number-danger",
			navSkip: false, // needed to set this to false otherwise it would attempt to go to a menu step out of bounds. Perhaps set this back to true when we add the premium summary screen? 
			active: false,
			hasError: false,
			errors: [],
			buttons: [],
			forms: [],
			icon: 'fa fa-map-pin',
			block: [],
			visible: true,
			//stateDataObject: new WCASTATES(),
			level: 2
		};
    
    menuClass.addMenuItemAt(loading, "States");
    
    // if(this.menuClass.stepActiveObject.name != "States"){ // 5/13/21: If we are on the states screen when we save, we do not want to clear the menu step and re-add it, because the "stepActiveObject" will not set properly, causing the component to get NgOnDestroyed. -JTL 

      this.migsystemservice.subscribeGetWCAQuoteStates().subscribe((wcaStates: WCASTATES[])=> { // had to make the subscription WCA specific in order to retreive the state info, we should properly find another way to keep the subscription quote independent.
        this.respondToQuoteChanges(wcaStates);
      });
    //}


 }
  //respondToQuoteChanges(quoteInfo: IQuote) {
  respondToQuoteChanges(wcaStates: WCASTATES[]) {
    //this.menuClass.ClearMenuItemAt("States"); // clear the "Loading Data" menu step after we're done loading
    var currentStep = this.menuClass.stepActiveObject;
    var currentStepIndex = this.menuClass.stepActive;
    var menustateLabel:string = "";
    var menuStepsToAdd:any[] = [];
    if(wcaStates.length == 0){
      let stateMenuStep = {
        name: 'States',
        label: 'New State', 
        sublabel: '<small> 1 Location </small>',
        color: "ui-steps-number-default",
        navSkip: false,
        active: false,
        hasError: false,
        errors: [],
        buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }, { button: "GetQuoteNow" }],
        forms:  [this.stateFormGroup],
        icon: 'fa fa-map-pin',
        block: [],//[{ text: "Loading Data", success: false, icon: 'fa-spinner' }],
        visible: true,
        stateDataObject: new WCASTATES(),
        level: 2,
        fromWins: true,
        quote: "premium"
      };
      menuStepsToAdd.push(stateMenuStep);
    }
    let stateIndex = 0;
    wcaStates.filter(x=>x.RECORDSTATE != "D").forEach(currentState => {
      
      menustateLabel = _.find(this.dropdowns.StatesFull, s => s["value"] == currentState.COVERG).label;
      
      let stateMenuStep = {
        name: 'States',
        label: menustateLabel != "" ? menustateLabel : 'New State', // this isn't working properly, it seems that this menu step is being added before the state label is getting set in the above subscripton. 
        sublabel: '<small>' + currentState.LOCATIONS.filter((loc:WCALOCATIONS) => loc.RECORDSTATE != "D").length + ' Location' + (currentState.LOCATIONS.filter((loc:WCALOCATIONS) => loc.RECORDSTATE != "D").length == 1 ? '' : 's') + '</small>',
        color: "ui-steps-number-default",
        navSkip: false,
        active: false,
        hasError: false,
        errors: [],
        buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }, { button: "GetQuoteNow" }],
        forms:  [this.stateFormGroup],
        icon: 'fa fa-map-pin',
        block: [],//[{ text: "Loading Data", success: false, icon: 'fa-spinner' }],
        visible: true,
        stateDataObject: currentState,
        level: 2,
        fromWins: true,
        id: stateIndex,
        quote: "premium"
      };
      menuStepsToAdd.push(stateMenuStep);
      //this.menuClass.addMenuItemAt(stateMenuStep, "States");  
      stateIndex +=1;
    });
      this.menuClass.ClearMenuItemAt("States"); // clear the "Loading Data" menu step after we're done loading
      menuStepsToAdd.forEach(menuStepToAdd => {
        this.menuClass.addMenuItemAt(menuStepToAdd, "States");
      })
      if(currentStep.name == "States"){ // 5/20/21: If we are on the state screen when we save, we want to go to the menu step of the state we were currently on -JTL
        this.menuClass.gotoStep(currentStepIndex);
      }
    

    this.menuClass.UpdateMenu();
    
    //this.stateFormGroup = this.formBuilder.group({});
  }
}
