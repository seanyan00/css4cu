import { UntypedFormControl } from '@angular/forms';
import { Validation } from '@classes/Common/ValidatorClass/Validation';
import { AppErrors } from '@root/shared_components/errors/app-errors';

export class MIGIndividualValidators extends Validation {
    constructor(
    ) {
        super();
    }


    ValidateOptionSelected(fieldId: string, fieldName: string){
        return (control: UntypedFormControl): AppErrors  => {
            //need a special case for toggle switches since we don't get the values passed in, only a true/false value. Need to check to see if it is undefined or and empty string
           
            if(control.value === '' || control.value == null) return { severity: "error", summary: fieldId, detail: fieldName + " is required", sticky: true, closable: false }
            //this prevents items from validating true when they are loaded with a 0 or '0' for whatever reason instead of remaining blank
            
            return null; 
        }    
    }
}