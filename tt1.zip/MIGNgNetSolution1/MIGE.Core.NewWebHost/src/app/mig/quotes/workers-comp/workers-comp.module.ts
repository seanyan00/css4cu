import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MIGOverlayPanelModule } from '@overridden/primeng-overlaypanel/overlay.module';
import { MIGFileUploadModule } from '@overridden/primeng-fileupload/fileupload';
import { PipesModule } from '@pipes/pipes.module';
import { ContractorsComponent } from '@root/mig/quotes/contractors/contractors.component';
import { ApplicationCompleteModule } from '@shared/application_complete/application_complete.module';
import { FinishApplicationModule } from '@shared/finish_application/finish_application.module';
import { ReferralsModule } from '@shared/referrals/referrals.module';
import { ReportItemModule } from '@shared/report_item/report_item.module';
import { RiskAppetiteGuideModule } from '@shared/risk-appetite-guide/risk-appetite-guide.module';
import { TestingModule } from '@shared/testing/testing.module';

import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ToastModule } from 'primeng/toast';
import { PanelModule } from 'primeng/panel';
import { DomHandler } from 'primeng/dom';
import { ErrorModule } from '@shared/errors/errors.module';
import { ChangeLogModule } from '@shared/changelog/changelog.module';
import { ProgressModule } from '@shared/progress/progress.module';
import { MessageService } from 'primeng/api';

import { QuoteInformationModule } from '@shared/quote_information/quote_information.module';
import { LiabilityLimitsModule } from '@CTRcomponents/liability_limits/liability_limits.module';
import { LocationSummaryModule } from '@CTRcomponents/location_summary/location_summary.module';
import { AdditionalCoveragesModule } from '@CTRcomponents/additional_coverages/additional_coverages.module';
import { AdditionalCoveragesLiabilityModule } from '@CTRcomponents/additional_coverages/liability/coverage.liability.component.module';
import { AdditionalCoveragesInlandModule } from '@CTRcomponents/additional_coverages/inland/coverage.inland.component.module';
import { AdditionalCoveragesPropertyModule } from '@CTRcomponents/additional_coverages/property/coverage.property.component.module';
import { PremiumSummaryModule } from '@CTRcomponents/premium_summary/premium_summary.module';
import { UnderwritingModule } from '@shared/underwriting/underwriting.module';
import { MIGAdditionalInformationStubModule } from '@shared/additional_information/additional_information_stub/additionalinformation.module';
import { MIGAdditionalInformationAdditionalInsuredsModule } from '@shared/additional_information/additional_insureds/insureds.module';
import { MIGAdditionalInformationScheduledItemsModule } from '@shared/additional_information/scheduled_items/items.module';
import { MIGAdditionalInformationDesignatedConstructionProjectsModule } from '@shared/additional_information/designated_construction_projects/designated_construction_projects.module';

import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { LansaAcctManagementModule } from '@shared/lansa_account_manage/lansa-acct-management.module';
import { EmployersLiabilityLimitsModule } from './components/employers-liability-limits/employers-liability-limits.module';
import { WorkersCompComponent } from './workers-comp.component';
import { BrowserModule } from '@angular/platform-browser';
import { WorkersCompRoutingModule } from './workers-comp-routing.module';
import { StatesModule } from './components/states/states.module';
import { WcaPremiumSummaryModule } from './components/wca-premium-summary/wca-premium-summary.module';
import { IndividualsIncludedExcludedModule } from './components/individuals-included-excluded/individuals-included-excluded.module';
import { IndividualsIncludedExcludedComponent } from './components/individuals-included-excluded/individuals-included-excluded.component';
import { DiscretionaryWorkSheetModule } from '@root/shared_components/Discretionary_WorkSheet/discretionary-worksheet.module';

//import { GrowlModule } from 'primeng/growl';
//import { LoadingModule } from '@shared/loading/loading.module';
//import { UnderwritingTriggerModule } from '@shared/underwriting_trigger/trigger.module';

@NgModule({
	imports: [
		// BrowserAnimationsModule,
		WorkersCompRoutingModule,
		// MIGButtonModule,
		CommonModule,
		// ConfirmDialogModule,
		// FormsModule,
		// //GrowlModule,
		// PanelModule,
		// RiskAppetiteGuideModule,
		// MIGOverlayPanelModule,
		// PipesModule,
		// ReportItemModule,
		// ReactiveFormsModule,
		// MIGFileUploadModule,
		TestingModule,
		ErrorModule,
		ChangeLogModule,
		ProgressModule,
		// ToastModule,
		// SystemErrorModule,
		LansaAcctManagementModule, // added 20190627 for a link menu step to return to acct management
		QuoteInformationModule, // these steps modules need to be in order of
		EmployersLiabilityLimitsModule, // how they need to appear in the menu
		StatesModule,
		WcaPremiumSummaryModule,
		DiscretionaryWorkSheetModule,
		UnderwritingModule, // this one too				
		IndividualsIncludedExcludedModule,
		ReferralsModule, // this one too
		
		// LocationSummaryModule, // as the menu is controlled by each sub component's module
		// PremiumSummaryModule, // no subcomponents need to be in order
		
		
		FinishApplicationModule, // this one too
		ApplicationCompleteModule // this one too
	],
	declarations: [
		WorkersCompComponent,
	],
	providers: [DomHandler, MessageService],
})
export class WorkersCompModule {

	constructor() {}
 }
