import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule, UntypedFormGroup } from '@angular/forms';
import { PanelModule } from 'primeng/panel';
import { TabViewModule } from 'primeng/tabview';
import { FieldsetModule } from 'primeng/fieldset';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { MIGInputSwitchModule } from '@overridden/primeng-inputswitch/switch.module';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { DynamicComponentModule } from '@dynamic/dynamic_component/dynamic.module';
import { MenuClass } from '@root/system/menu/menu';
import { TextMaskModule } from 'angular2-text-mask';
import { MIGSystemService } from '@services/mig.service';
import { MIGMessageModule } from '@overridden/primeng-message/message.module';
import { PipesModule } from '@pipes/pipes.module';
import { MIGYearPickerModule } from '@overridden/mig-yearpicker/year.module';
import { TooltipModule } from 'primeng/tooltip';
import { MIGCalendarModule } from '@overridden/primeng-calendar/calendar.module';
import { IndividualsIncludedExcludedComponent } from './individuals-included-excluded.component';
import { IndividualModule } from './individual/individual.module';
import { AccordionModule } from 'primeng/accordion';
import { ConfirmDialogModule } from 'primeng/confirmdialog';



@NgModule({
  declarations: [IndividualsIncludedExcludedComponent],
  imports: [
    CommonModule,
    IndividualModule,
    FormsModule,
		TabViewModule,
		PanelModule,
		FieldsetModule,
		MIGDropDownModule,
		MIGCheckboxModule,
		MIGInputtextModule,
		MIGInputSwitchModule,
		MIGButtonModule,
		ReactiveFormsModule,
    AccordionModule,
		DynamicComponentModule,
		TextMaskModule,
		MIGMessageModule,
		MIGYearPickerModule,
		TooltipModule,
		PipesModule,
    MIGCalendarModule,
    ConfirmDialogModule
  ],
  exports: [IndividualsIncludedExcludedComponent],
  providers: [IndividualsIncludedExcludedComponent, PipesModule]

})
export class IndividualsIncludedExcludedModule { 
  formGroup: UntypedFormGroup;
	constructor(
		public menuClass: MenuClass,
		public migsystemservice: MIGSystemService) {
    menuClass.addMenuItem({
        name: 'Individuals Included / Excluded',
        label: 'Individuals Included / Excluded',
        color: "ui-steps-number-default",
        navSkip: false,
        active: false,
        hasError: false,
        errors: [],
        forms: [this.formGroup], // this resolved TFS 2314, but further testing is required to ensure this doesn't break anything else; -JTL 
        buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }],
        icon: "fa fa-pen-alt",
        block: [],
        visible: true,
        quote: "application"
      });
  }
}

