import { BOPBASECLASS } from "./BOPBASECLASS";
import { BUSINESSLIABILITY, CONTRACTORSLIABILITY, FINEART, LIQUORLIABILITY } from "./BOPClasses";
import { BOPSEGMENTINFO } from "./BOPSEGMENTINFO";

export class BOPBUILDING extends BOPBASECLASS { // DW5P130
    FINEART: FINEART[];
    LIQUORLIABILITY: LIQUORLIABILITY;
    CONTRACTORSLIABILITY: CONTRACTORSLIABILITY[];
    BOPSEGMENTINFO: BOPSEGMENTINFO;
    BUSINESSLIABILITY: BUSINESSLIABILITY;
    /** @param string Location # */
    LOCNUM: string = "0";
    /** @param string Building Number */
	BLDNUM: string = "0";
    PRMSTE: string = "";
    STATS1: string = "";
    STRNO: string = "";
    STRNME: string = "";
    SUITE: string = "";
    LOCAD2: string = "";
    LOCCTY: string = "";
    LOCST: string = "";
    LOCZIP: string = "";
    RATCTY: string = "";
    TERR: string = "";
    TAXCTY: string = "";
    TAXDSC: string = "";
    OWNOCP: string = "";
    BLDCLS: string = "";
    BLDDSC: string = "";
    BLDSEG: string = "";
    BLDSIC: string = "";
    BLDLMT: number = 0;
    BPPCLS: string = "";
    BPPDSC: string = "";
    BPPSEG: string = "";
    BPPSIC: string = "";
    BPPLMT: number = 0;
    CONSTR: string = "";
    PROCLS: string = "";
    BLDVAL: string = "";
    SPRINK: string = "";
    ELVINSP: string = "";
    ASCCRD: string = "";
    WINHDED: number = 0;
    FRNCRD: string = "";
    WINDPRT: string = "";
    FIRALM: string = "";
    BURGAL: string = "";
    OCONYR: number = 0;
    YGELEC: number = 0;
    YGHEAT: number = 0;
    YGROOF: number = 0;
    YGPLMB: number = 0;
    FTHYDT: string = "";
    FDMILE: string = "";
    TRUNT: number = 0;
    CNVDWL: string = "";
    COOKFC: string = "";
    CONDUO: string = "";
    ACRON: number = 0;
    ACROF: number = 0;
    BIEEVAL: string = "";
    FARTLM: number = 0;
    FALTLM: number = 0;
    OUTSNL: number = 0;
    SPLOLM: number = 0;
    USDDLM: number = 0;
    USTELM: number = 0;
    VLPONL: number = 0;
    VLPOFL: number = 0;
    SNGOFG: string = "";
    APTOCC: string = "";
    APTPCT: number = 0;
    NOUNIT: number = 0;
    DTRSTL: number = 0;
    BIEEIC: number = 0;
    BAILMT: number = 0;
    EQDFLG: string = "";
    FCLBIE: number = 0;
    FCLAAE: number = 0;
    LASLPU: number = 0;
    MRPLPU: number = 0;
    ACCSYS: string = "";
    TPDED: string = "";
    WNDZNE: number = 0;
    FULLBLDGDESCRIPTION: string = "";
    RECORDSTATE: string = "N";

    constructor(data?) {
        super(data);        
        if (data != undefined) {
            Object.assign(this, data);
            this.BOPSEGMENTINFO = new BOPSEGMENTINFO(data.BOPSEGMENTINFO);
            this.BOPSEGMENTINFO.TRANS = this.TRANS;
            this.BOPSEGMENTINFO.POLICY = this.POLICY;
            this.BOPSEGMENTINFO.EFFDTE = this.EFFDTE;
            this.BOPSEGMENTINFO.EDSDTE = this.EDSDTE;
            this.BOPSEGMENTINFO.LOCNUM = this.LOCNUM;
            this.BOPSEGMENTINFO.BLDNUM = this.BLDNUM;
            
            this.BUSINESSLIABILITY = new BUSINESSLIABILITY(data.BUSINESSLIABILITY);
            this.BUSINESSLIABILITY.TRANS = this.TRANS;
            this.BUSINESSLIABILITY.POLICY = this.POLICY;
            this.BUSINESSLIABILITY.EFFDTE = this.EFFDTE;
            this.BUSINESSLIABILITY.EDSDTE = this.EDSDTE;
            this.BUSINESSLIABILITY.LOCNUM = this.LOCNUM;
            this.BUSINESSLIABILITY.BLDNUM = this.BLDNUM;

            this.LIQUORLIABILITY = new LIQUORLIABILITY(data.LIQUORLIABILITY);
            this.LIQUORLIABILITY.TRANS = this.TRANS;
            this.LIQUORLIABILITY.POLICY = this.POLICY;
            this.LIQUORLIABILITY.EFFDTE = this.EFFDTE;
            this.LIQUORLIABILITY.EDSDTE = this.EDSDTE;
            this.LIQUORLIABILITY.LOCNUM = this.LOCNUM;
            this.LIQUORLIABILITY.BLDNUM = this.BLDNUM;
        }
    } 
    
    checkBusinessLogic(){


          if(this.LOCST != "37"){ // clear Pennslvania specific fields
            this.ELVINSP = "";
          }
          if(this.LOCST != "31"){ // clear New York specific fields
            this.WINDPRT = "";
          }
          /* Building Limit and BPP Limit
            When both limits are entered, store data in all 8 fields. 
          */
          if(this.hasBuildingLimit() && !this.hasBPPLimit()){
            //When ONLY Building Limit is entered, write class data to BLDCLS, BLDDSC, BLDSEG, and BLDSIC. Set data for BPPCLS, BPPDSC, BPPSEG, and BPPSIC to their default (blank) values.
            this.BPPCLS = "";
            this.BPPDSC = "";
            this.BPPSEG = "";
            this.BPPSIC = "";
          }
          if(!this.hasBuildingLimit() && this.hasBPPLimit()){
            //When ONLY Business Personal Property Limit is entered, write class data to BPPCLS, BPPDSC, BPPSEG, and BPPSIC. Set data for BLDCLS, BLDDSC, BLDSEG, and BLDSIC to their default (blank) values.
      
            this.BLDCLS = "";
            this.BLDDSC = "";
            this.BLDSEG = "";
            this.BLDSIC = "";
          }
          if(!this.hasBuildingLimit()){
            // If the building limit is cleared out, any value that is dependent on having a building limit should be cleared out.
            this.COOKFC = "N";
            this.BLDVAL = "R";
            this.OWNOCP = this.hasSegment("LSRO") ? "0" : "100";
          }
          if(!this.hasBPPLimit()){
            // if the BPP limit is cleared out, any value that is dependent on having a BPP limit should be cleared out.
            this.ACROF = 0;
            this.ACRON = 0;
          }
          if((this.hasBuildingLimit() && this.hasBPPLimit()) || (!this.hasBuildingLimit() && !this.hasBPPLimit())){ // if both building limit and BPP limit are entered, or if neither are entered.
            this.BLDCLS = this.BPPCLS != "" ? this.BPPCLS : this.BLDCLS;
            this.BLDDSC = this.BPPDSC != "" ? this.BPPDSC : this.BLDDSC;
            this.BLDSEG = this.BPPSEG != "" ? this.BPPSEG : this.BLDSEG;
            this.BLDSIC = this.BPPSIC != "" ? this.BPPSIC : this.BLDSIC;
      
            this.BPPCLS = this.BLDCLS != "" ? this.BLDCLS : this.BPPCLS;
            this.BPPDSC = this.BLDDSC != "" ? this.BLDDSC : this.BPPDSC;
            this.BPPSEG = this.BLDSEG != "" ? this.BLDSEG : this.BPPSEG;
            this.BPPSIC = this.BLDSIC != "" ? this.BLDSIC : this.BPPSIC;
          }
      
          if(!this.hasSegment("RETL")){ // if they have a retail class, and change to a non-retail class, we want to clear out the retail specific properties.
            this.BOPSEGMENTINFO.PCTRCT = 0;
            this.BOPSEGMENTINFO.RTIFLT1 = 0;
            this.BOPSEGMENTINFO.RTIPRT1 = 0;
            this.BOPSEGMENTINFO.RTICLS1 = "";
            this.BUSINESSLIABILITY.FULTIM = 0;
            this.BUSINESSLIABILITY.PRTTIM = 0;
            this.BUSINESSLIABILITY.CLASX = "";
          }
          if(!this.hasSegment("FOOD")){
            this.ACCSYS = "";
          }
          if(this.firstLocationFirstBuilding()){ // these properties are determined based on if this building is LOC 001 BLD 001
            this.OWNOCP = this.hasSegment("LSRO") ? "0" : "100";
          }
    }

    hasSegment(segment: string){
        return this.BLDSEG == segment || this.BPPSEG == segment;
    }

    hasBuildingLimit(): boolean{ // returns true if a BUILDING limit is entered
        return this.BLDLMT > 0;
    }

    hasBPPLimit(): boolean { // returns true is a BPP limit is entered
        return this.BPPLMT > 0;
    }

    firstLocationFirstBuilding(): boolean{ // return true if we are viewing the LOC 001 BLD 001 
      return  this.LOCNUM == "001" && this.BLDNUM == "001";
    }
}
