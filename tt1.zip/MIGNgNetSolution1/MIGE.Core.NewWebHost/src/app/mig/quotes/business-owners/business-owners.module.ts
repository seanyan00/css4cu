import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BusinessOwnersComponent } from './business-owners.component';
import { DomHandler } from 'primeng/dom';
import { MessageService } from 'primeng/api';
import { BusinessOwnersRoutingModule } from './business-owners-routing.module';
import { LansaAcctManagementModule } from '@root/shared_components/lansa_account_manage/lansa-acct-management.module';
import { QuoteInformationModule } from '@root/shared_components/quote_information/quote_information.module';
import { ErrorModule } from '@root/shared_components/errors/errors.module';
import { TestingModule } from '@root/shared_components/testing/testing.module';
import { ChangeLogModule } from '@root/shared_components/changelog/changelog.module';
import { ProgressModule } from '@root/shared_components/progress/progress.module';
import { BopLocationSummaryModule } from './components/bop-location-summary/bop-location-summary.module';
import { BopLiabilityLimitsModule } from './components/bop-liability-limits/bop-liability-limits.module';
import { BopOptionalCoveragesModule } from './components/bop-optional-coverages/bop-optional-coverages.module';



@NgModule({
  imports: [
    BusinessOwnersRoutingModule,
    CommonModule,
    TestingModule,
		ErrorModule,
		ChangeLogModule,
		ProgressModule,
    LansaAcctManagementModule, // added 20190627 for a link menu step to return to acct management
		QuoteInformationModule, // these steps modules need to be in order of
    BopLocationSummaryModule,
    BopLiabilityLimitsModule,
    BopOptionalCoveragesModule
  ],
  declarations: [BusinessOwnersComponent],
	providers: [DomHandler, MessageService],

})
export class BusinessOwnersModule { }
