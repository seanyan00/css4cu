import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UntypedFormBuilder, UntypedFormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MenuClass } from '@root/system/menu/menu';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { AccordionModule } from 'primeng/accordion';
import { PanelModule } from 'primeng/panel';
import { FieldsetModule } from 'primeng/fieldset';
import { InputNumberModule } from 'primeng/inputnumber';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { TableModule } from 'primeng/table';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { TextMaskModule } from 'angular2-text-mask';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';
import { BopOptionalCoveragesComponent } from './bop-optional-coverages.component';
import { MIGCalendarModule } from '@overridden/primeng-calendar/calendar.module';
import { ConfirmDialogModule } from 'primeng/confirmdialog';



@NgModule({
  declarations: [BopOptionalCoveragesComponent],
  imports: [
    CommonModule,
    MIGDropDownModule,
    AccordionModule,
    PanelModule,
		FieldsetModule,
		MIGButtonModule,
    TableModule,
		FormsModule,
    MIGInputtextModule,
    TextMaskModule,
    MIGCheckboxModule,
	ReactiveFormsModule,
    InputNumberModule,
    MIGCalendarModule,
    ConfirmDialogModule
  ],
  exports: [BopOptionalCoveragesComponent]
})
export class BopOptionalCoveragesModule { 
	formGroup: UntypedFormGroup;

	constructor(
		public menuClass: MenuClass,
		private formBuilder: UntypedFormBuilder,

	) {
		this.formGroup = this.formBuilder.group({});

		menuClass.addMenuItem({
			name: 'OptionalCoverages',
			label: 'Optional Coverages',
			color: "ui-steps-number-default",
			navSkip: false,
			active: false,
			hasError: false,
			errors: [],
			buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }],
			form: this.formGroup,
			icon: 'fa fa-layer-group',
			block: [],
			visible: true,
			quote: "premium"
		});

        menuClass.addMenuItem({
			name: 'OptionalCoverages2',
			label: 'Validation Test Screen',
			color: "ui-steps-number-default",
			navSkip: false,
			active: false,
			hasError: false,
			errors: [],
			buttons: [{ button: "Back" }, { button: "Save" }],
			form: this.formGroup,
			icon: 'fa fa-layer-group',
			block: [],
			visible: true,
			quote: "premium"
		});
	}
  
}
