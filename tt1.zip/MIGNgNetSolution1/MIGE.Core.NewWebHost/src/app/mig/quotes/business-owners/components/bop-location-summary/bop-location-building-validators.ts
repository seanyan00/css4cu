import { AbstractControl,ValidatorFn, UntypedFormGroup, UntypedFormControl} from "@angular/forms";
import { Functions } from '@helpers/functions';
import { Validation } from '@classes/Common/ValidatorClass/Validation';
import { IQuote } from "@interfaces/IQuote";
import { BOPQuote } from "@classViewModels/BOP/BOPQuote";
import { BOPLOCATION } from "@mig/quotes/business-owners/classes/BOPLOCATION";
import { BOPBUILDING } from "@mig/quotes/business-owners/classes/BOPBUILDING";
import { AppErrors } from "@root/shared_components/errors/app-errors";
import * as _ from 'lodash';
export class MIGBOPLocationBuildingValidators extends Validation {
	constructor(public func: Functions) {
        super();
    }

    hasSegment(segment: string, quote: IQuote) : boolean { // pass in a particular segment (ex: "RETL"), will return true if a building on the quote has that segment.
        let segmentFlag = false;
        if(quote instanceof BOPQuote){
            quote.getTotalLocations().forEach((location: BOPLOCATION) => {
            location.getTotalBuildings().forEach(building => {
                if(building.BLDSEG == segment || building.BPPSEG == segment){
                segmentFlag = true;
                }
            });
            });
        }
        return segmentFlag;
      }

    validateValueIsDivisible = (fieldId: string, fieldName: string, divisor: number, isCurrency?: boolean) => { // validator to determine if a form control is evenly divisable by a particular number
        return (control: UntypedFormControl): AppErrors | null => {
            let value;
            value = isCurrency ? _.isNumber(control.value) ? control.value : parseInt(control.value.toString().replace(/\D+/g, '')) : _.toNumber(control.value);
            
            return value % divisor == 0 ? null : { severity: "error", summary: fieldId, detail: fieldName + " must be divisible by " + divisor, sticky: true, closable: false }
        }
    }


    validateOneOfTwoFieldsRequired = (fieldId1: string, fieldName1: string, fieldId2: string, fieldName2: string, noZero?: boolean) => {
		// this validation rule is applied to the entire form group, rather than an individual control.
		// This validator can be used in a situation when we need to ensure that between control A and control B, at least one of them has a value.
		return (group: UntypedFormGroup): AppErrors | null  => {
            const control1 = group.get(fieldId1);
            const control2 = group.get(fieldId2);
            
            if(!control1 || !control2){
                return null;
            }

            if(control1.value || control2.value){
                return null; 
            }
            if(noZero){ 
                if((control1.value == 0 && control2.value == 0) || (control1.value === "0" && control2.value === "0") ){
                    return { severity: "error", summary: fieldId1, detail: fieldName1 + " or " + fieldName2 + " is required", sticky: true, closable: false }
                }
            }
            if(!control1.value && !control2.value){
                return { severity: "error", summary: fieldId1, detail: fieldName1 + " or " + fieldName2 + " is required", sticky: true, closable: false }
            }
        }    
    }
}