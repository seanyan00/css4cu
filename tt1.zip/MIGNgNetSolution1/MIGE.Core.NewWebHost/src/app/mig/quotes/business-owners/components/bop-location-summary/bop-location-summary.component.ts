/* ****************************************************************************************************
* PROGRAM DESCRIPTION  - BOP Location Summary 
* NOTES: 
* - This component is the component for a specific location on the menu. Within each location it will have a location address, and 1 or many buildings associated with it. 
* - Each building will have its own Business Class, Building Coverages, and Additional Coverages associated with it. 
* - The form groups that need to be attached to the menu step in order the validation to function properly (on next click or menu click) is: 
*   1 Location Address form group that holds our Location address information. 
*   For each (un-deleted) building attached to this location, there will be a form group added to our menu step 
*   So a location with 10 buildings will have 11 form groups attached to the menu step. 
* BUG FIXES:
* 8/9/22: Fixed issue where screen was bringing user to the building coverage screen first instead of Location address (Bug 387) -JTL 
* 8/16/22: Fixed issue where locations weren't deleting / resequencing properly (Bug 399) -JTL 
****************************************************************************************************/
import { Component, Input, OnInit,ChangeDetectorRef, OnDestroy } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { GUIDE } from '@classes/common/BusinessClass/GUIDE';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { BOPQuote } from '@classViewModels/BOP/BOPQuote';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { GuideService } from '@root/services/risk-appetite-guide.service';
import { ADDRESS, ADDRESSTERRITORY } from '@root/shared_components/address_info/address.class';
import { MenuClass } from '@root/system/menu/menu';
import { MIGBOPLocationBuildingValidators } from './bop-location-building-validators';
import { Subscription } from 'rxjs/internal/Subscription';
import { MIGSystemService } from '@root/services/mig.service';
import * as _ from 'lodash';
import { Functions } from '@helpers/functions';
import { BOPLOCATION } from '../../classes/BOPLOCATION';
import { BOPBUILDING } from '../../classes/BOPBUILDING';
import { ConfirmationService } from 'primeng/api';

@Component({
  selector: 'mig-bop-location-summary',
  templateUrl: './bop-location-summary.component.html',
  styleUrls: ['./bop-location-summary.component.css']
})
export class BopLocationSummaryComponent implements OnInit, OnDestroy{
  locationID: string = "001";
  @Input() quote: BOPQuote;

  locationFormGroup: UntypedFormGroup; 
  guide: GUIDE[] = [];
  filteredGuide: GUIDE[] = [];
  locations: BOPLOCATION[] = [];
  buildings: BOPBUILDING[] = [];
  // building coverage variables:
	fireDistrictsArray: any[] = [];
  menu: any;
  locationObject: BOPLOCATION;
  index: number;
  addButtonLabel: string = "";
  migValidator: MIGBOPLocationBuildingValidators;
  territoryInfo: ADDRESSTERRITORY = null;
  territoryArray: any[] =[];
  protectionClassesAandB: string = "";

  guideServiceSubscription: Subscription;
  
  constructor(public menuClass: MenuClass,
              public migRoles: MIGSecurityRoles,
              public dropDowns: ContractorsDropDowns,
              public formBuilder: UntypedFormBuilder,
              public changeDetectorRef: ChangeDetectorRef,
              public guideService: GuideService,
              public migsystemservice: MIGSystemService,
              public confirmationService: ConfirmationService,
              public func: Functions
              ) {

  }

  // functionality that we could consider separating out into different classes: 
  // Adding a new building to the location. 
  // Deleting a building and resequencing the BLDNUM's
  // Adding a new location ? 
  // Deleting a location ? 
  // CRUD Business Classes 
  
  ngOnInit(): void {
    this.menu = this.menuClass.stepActiveObject;
    this.menu.forms = [];
    this.formBuilder = new UntypedFormBuilder();
    this.func.scrollIntoView("locationAddress"); // 8/9/22: fix for Bug 387, this ensures that when we load the page, we start at the top of the screen (where the location address is) -JTL
    if(this.quote instanceof BOPQuote) {
      this.locationObject = this.menu.locationDataObject;

      // if (this.getTotalLocations().length == 0) { // if there are no locations on the quote
      //   this.menu.locationDataObject = this.quote.AddNewLocationObject();
      //   this.locationObject = this.menu.locationDataObject;
      //   this.locationObject.ADDRESS = this.quote.POLICYTRANS.ADDRESS; // prefill the first location address with the mailing address

      //   if(this.getTotalBuildings().length == 0){ // if there are no
      //       this.locationObject.addNewBuilding(this.quote.QUOTEPOLICYINFORMATION, this.quote.QUOTEPOLICYINFORMATION.CLASSCODEINFO.CLASSCODE, this.quote.QUOTEPOLICYINFORMATION.CLASSCODEINFO.DESCRIPTION); // adds our initial building
      //   }
      // }
      if (this.getTotalBuildings().length == 0) {
          this.locationObject.addNewBuilding(this.quote);
        }
      // RDB 337 - Fix Suite not populating through
      if (this.quote.BOPLOCATIONS.length == 1) { // Only for the first location. In this particular case, we do not want to account for Record state = "D" because if we have 2 locations and delete this first location, we do not want the second location to get prefilled with the mailing address. -JTL
            this.locationObject.ADDRESS = this.quote.POLICYTRANS.ADDRESS; 
        }

      this.locationID = this.locationObject.LOCNUM;
      this.locations = this.quote.BOPLOCATIONS; // used if we need to resequence LOCNUM
      this.buildings = this.locationObject.BOPBUILDINGS; // used if we need to resequence LOCNUM/BLDNUM
      this.locationFormGroup = this.formBuilder.group({});
      this.menu.forms.push(this.locationFormGroup)
    }// end instanceOf BOPQuote

    var classrequest:any = {
      PRODUCT:		'BOP',
      STATE:			this.locationObject.ADDRESS.STATE,
      STATECODE: 	this.locationObject.ADDRESS.STATE,
      EFFDTE:	 		20220101,
      ENDDTE:		 	20220101,
      CDKEY1: 		'',
      CDKEY2:			'',
      CLASSCODE:		'',
      DESCRIPTION: 	'',
      FSTTRK: 		""
      };
      this.getGuide(classrequest);
  }

  ngOnDestroy(): void {
    if(this.guideServiceSubscription) {this.guideServiceSubscription.unsubscribe()}
  }


  addressChanged(updatedAddressObject:ADDRESS){ // function called as the address gets changed via an event emitter.
    let initialState = this.locationObject.ADDRESS.STATE;
    this.locationObject.setLocationAddress(updatedAddressObject);
    if(this.locationObject.getTotalBuildings()[0].TERR != "" && this.locationID == "001"){
      this.quote.POLICYTRANS.ADDRESS.TERRITORYCODE = this.locationObject.getTotalBuildings()[0].TERR;
    }
    if(initialState != updatedAddressObject.STATE){
      this.menu.forms.forEach((form:UntypedFormGroup)=>{
        form.updateValueAndValidity(); // when we change the Address State, updateValueAndValidity will update our validation/business logic for each building on the location, as some of the logic is dependent on the address state.
      });
      var classrequest:any = {
        PRODUCT:		'BOP',
        STATE:			this.locationObject.ADDRESS.STATE,
        STATECODE: 	this.locationObject.ADDRESS.STATE,
        EFFDTE:	 		20220101,
        ENDDTE:		 	20220101,
        CDKEY1: 		'',
        CDKEY2:			'',
        CLASSCODE:		'',
        DESCRIPTION: 	'',
        FSTTRK: 		""
        };
        this.getGuide(classrequest);
    }
    if(this.quote.QUOTEPOLICYINFORMATION.TRANSACTIONTYPE !="PI"){
      let label: string = "";
      label = (updatedAddressObject.STREETNUMBER ? updatedAddressObject.STREETNUMBER + " " + updatedAddressObject.STREETNAME : updatedAddressObject.POBOX ? "POBOX " + updatedAddressObject.POBOX : "New Location");
      this.menuClass.updateMenuItemAt(label, "locationId", this.locationObject.LOCNUM, "LocationSummary");
    }
  }

  getGuide(classRequest:any){
    this.guideServiceSubscription = this.guideService.getGuide(classRequest)
        
    // gets our list of class codes for a given state.
   .subscribe(data => {
       this.guide = data;
       this.filteredGuide = this.guide.filter(bclass=> bclass.PRODUCT != "RTIN"); // we do not want the user to be able to select a Retail Installation class from the guide. 
       this.changeDetectorRef.detectChanges();
   },
   error => {
       console.log(error.Message);
   });
  }

  btnAddLocation() { //Pasted from states component
      let currentStepValidationErrors:any[] = this.menuClass.CalculateErrors(this.menuClass.stepActiveObject);
      this.migsystemservice.notifyNextClicked(currentStepValidationErrors);
      if (currentStepValidationErrors.length > 0)
      {
          return;
      }
  
      var menustateLabel = "";
      let data= {
        name: 'LocationSummary',
          label: menustateLabel != "" ? menustateLabel : 'New Location', 
          sublabel: '<small>' + '1' + ' Building' + '</small>',
          color: "ui-steps-number-default",
          navSkip: false,
          active: false,
          hasError: false,
          errors: [],
          buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }, { button: "GetQuoteNow" }],
          forms:  [this.formBuilder.group({})],
          icon: 'fa fa-map-pin',
          block: [],
          visible: true,
          locationDataObject: this.quote.AddNewLocationObject(),// needs to be a new location
          locationId: _.padStart((this.getTotalLocations().length).toString(),3,'0'), // the locationID will be incremented from the total number of locations 
          level: 2,
          fromWins: false,
          quote: "premium"
        }
        this.menuClass.addMenuItemAt(data, "LocationSummary"); //add's our new menu item to our menu.
        //data.stateDataObject.AddnewLocation(); // commented this out because this was causing an extra invalid location form group to be added to the menu forms that would prevent the user from advancing.
        this.migsystemservice.notifyBlock({ block: true, block_message: data.block });
        this.menu.sublabel = '<small>' + this.locationObject.BOPBUILDINGS.filter(x=>x.RECORDSTATE != "D").length + ' Building' + (this.locationObject.BOPBUILDINGS.length == 1 ? '' : 's') + '</small>';
        this.menuClass.nextStep(this.menu.sublabel); // after we add the new location, we call nextStep so we move to the next location screen. We pass in the sublabel because for some reason the first location's sublabel will be lost if we don't otherwise.
  
    }

    deleteLocation(locationToDelete:BOPLOCATION){

      this.quote.deleteLocation(locationToDelete);

      // now we need to clear out the menu item of the location we are deleting.
      this.menuClass.ClearMenuItem("locationId", locationToDelete.LOCNUM);
      let locationSteps = this.menuClass.menu.filter(step => step.name == "LocationSummary" && step.locationId != undefined);

      this.quote.funcResequenceLocations();  // resequence LOCNUM and BLDNUM's for all locations & buildings. 
      let reIndex = 1;
      locationSteps.forEach(step => { // now we want to resequence the id's that are tied to each location menu step. 
        let newID = this.func.lpad((reIndex).toString(), "0", 3);
        this.quote.resequenceNumbers(locationSteps,step.locationId,newID,"locationId");
        reIndex ++;
      })
      // we want to go to the location menu step of a location not deleted
      this.menuClass.GotoMenuItem("locationId", this.quote.BOPLOCATIONS.find(loc => loc.RECORDSTATE != "D").LOCNUM);

    }

    acquiredTerritoryInfo(updatedAddressTerritoryObject: ADDRESSTERRITORY){
      this.territoryInfo = updatedAddressTerritoryObject;
      this.locationObject.ADDRESSTERRITORY = updatedAddressTerritoryObject;
      this.locationObject.getTotalBuildings().forEach((bld:BOPBUILDING) => {
        this.setLocationInfoFromAddressTerritory(bld);
      }) 
    }

    setLocationInfoFromAddressTerritory(building: BOPBUILDING) { // TODO: REFACTOR FOR ALL PRODUCT LINE
      if (this.territoryInfo == null) {
          return this.locationObject.setLocationInfoFromExistingLocation(building);
      }
      switch (this.territoryInfo.RETURNEDSTRUCTURECODE) {	
          case 'PPC':				
                building.TERR   = this.territoryInfo.TERRITORYCODE;
                building.TAXCTY = this.territoryInfo.RETPPCFIPSCOUNTYCODE;
                this.fireDistrictsArray = [];
                // building.TAXTWN = this.territoryInfo.RETPPCTAXCODE;
                let protectionClasses = this.territoryInfo.RETPPCPUBLICPROTECTIONCLASS.split("/").filter(function(value, index){
                  return value.replace(/\s/g, '') != '';
                }).map((value:string) => value.replace(/\s/g, ''));		
                if (protectionClasses.length == 1) {
                  building.PROCLS = this.territoryInfo.RETPPCPUBLICPROTECTIONCLASS;
                } else {
                  this.protectionClassesAandB = this.territoryInfo.RETPPCPUBLICPROTECTIONCLASS;
                }
                building.RATCTY = this.territoryInfo.RETPPCFIREDISTRICT;
                building.TAXDSC = this.territoryInfo.RETCOUNTYNAME;
                building.WNDZNE = this.territoryInfo.WNDZNE;
                this.fireDistrictsArray.push({"value": this.territoryInfo.RETPPCFIREDISTRICT, "label": this.territoryInfo.RETPPCFIREDISTRICT.substring(0,30)});
                this.migsystemservice.notifyGetFireDistricts(this.fireDistrictsArray); 

                break;
          case 'ZPP':						
                var zppStructureArray = this.territoryInfo.RETZPPFIREDISTRICTCODE2.match(/.{1,87}/g);																							
                this.fireDistrictsArray = [];
                building.RATCTY = ""; // clear out previous fire district so we can properly populate the Fire District dropdown. 
                zppStructureArray.forEach(element => {
                    this.fireDistrictsArray.push({"value": element, "label": element.substring(0,30)});							
                });	
                if (parseInt(this.territoryInfo.RETZPPTERRITORYCOUNT) == 1) {					
                    building.TERR = this.territoryInfo.RETZPPTERRITORYZIP.substring(3);
                } 
                else {
                var territories = this.territoryInfo.RETZPPTERRITORYZIP.match(/.{1,6}/g);
                  this.territoryArray = [];
                  territories.forEach(element => {
                      this.territoryArray.push({"value": element.substring(3), "label": element.substring(3)});
                  });
                }  
                building.WNDZNE = this.territoryInfo.WNDZNE;
                this.migsystemservice.notifyGetFireDistricts(this.fireDistrictsArray); // give our buildings our list of fire districts, if applicable
                break;
          default:
      }
    }


    canAddAnotherLocation():boolean{
      return _.filter(this.menu.forms, buildingFormGroup => buildingFormGroup.invalid).length == 0;
    }
    canDeleteLocation(): boolean {
      return this.getTotalLocations().length > 1; 
    }

    getTotalLocations() : BOPLOCATION[] {
      return this.quote.BOPLOCATIONS.filter(loc=>loc.RECORDSTATE != "D");
    }
    getTotalBuildings(): BOPBUILDING[] {
      return this.locationObject.BOPBUILDINGS.filter(x=>x.RECORDSTATE != "D");
    }
    btnAddBuilding(): void{
      this.locationObject.addNewBuilding(this.quote); // add building to our object graph
      this.updateBuildingCountSubLabel(); // update label on left menu to reflect our newly added building.
    }
    editBuilding(event: Event){ // TODO: Need more information on how this should function
      console.log("event: ", event)
    }

    updateBuildingCountSubLabel() // update our sublabel on the left menu to match the number of buildings on the location.
    {
        let buildingCount: number = this.getTotalBuildings().length;
        this.menuClass.stepActiveObject.sublabel = '<small>' + buildingCount + ' Building' + (buildingCount == 1 ? '' : 's') + '</small>';
    }

}
