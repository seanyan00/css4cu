/**  ****************************************************************************************************
* PROGRAM DESCRIPTION  - BOP Building Component
* NOTES: 
* - This component is specific to BOP and is a child component of the BOP location menu step. 
* - A BOP location can have multiple buildings. This component holds all the forms and information for a particular building. 
* - This component has 2 child components: Bop business class component and bop additional coverages component. 
*    Between these 3 components we are sharing the same BOPBUILDING object, BOPLOCATION object, and building FormGroup. 
*    These components share their information by importing their parent components in their constructors. 
*
* Bug Fixes: 
* 8/5/22: Percentage of receipts from installation... field now defaults to displaying blank, not 0 (Bug 368) -JTL 
* 8/9/22: Fixed issue where Apartment Occupancy was displaying before making a selection on Single Occupancy (Bug 384) -JTL 
* 8/12/22: Set Max limit for Forgery and Alteration from $250,000 to $200,000 (Bug 404) -JTL
* 8/16/22: Fixed issue where "Construction Year" wasn't validating properly on init (Bug 418) -JTL
* 8/16/22: Fixed issue where user would be able to enter a future year in "Year of Updates" fields (Bug 419) -JTL 
* 8/17/22: Fixed validation message for Interruption of Computers (Bug 424) -JTL
* 8/17/22: Fixed issue where DTRSTL field wasn't getting set properly (Bug 425) -JTL
****************************************************************************************************/
import { Component, Input, OnInit,ChangeDetectorRef, OnDestroy } from '@angular/core';
import { UntypedFormBuilder, FormControl, UntypedFormGroup, ValidatorFn, Validators } from '@angular/forms';
import { GUIDE } from '@classes/common/BusinessClass/GUIDE';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { IQuote } from '@interfaces/IQuote';
import { GuideService } from '@root/services/risk-appetite-guide.service';
import { MenuClass } from '@root/system/menu/menu';
import { Subscription } from 'rxjs/internal/Subscription';
import { MIGSystemService } from '@root/services/mig.service';
import * as _ from 'lodash';
import { Functions } from '@helpers/functions';
import { InputMasksClass } from '@helpers/masks';
import { distinctUntilChanged } from 'rxjs/operators';
import { BOPLOCATION } from '../../classes/BOPLOCATION';
import { BOPBUILDING } from '../../classes/BOPBUILDING';
import { BOPQuote } from '@classViewModels/BOP/BOPQuote';
import { MIGLiabilityResources } from '@CTRcomponents/additional_coverages/liability/extension/extension.resources';
import { BopLocationSummaryComponent } from '../bop-location-summary/bop-location-summary.component';
import { MIGBOPLocationBuildingValidators } from '../bop-location-summary/bop-location-building-validators';


@Component({
  selector: 'mig-bop-building',
  templateUrl: './bop-building.component.html',
  styleUrls: ['./bop-building.component.css']
})
export class BopBuildingComponent implements OnInit, OnDestroy {

  @Input() locationObject: BOPLOCATION;
  @Input() buildingObject: BOPBUILDING;
  @Input() quote: IQuote;
  @Input() guide: GUIDE[];
  fireDistrictsArray: any[] = [];
  @Input() territoryArray: any[] = [];
  buildingFormGroup: UntypedFormGroup; 
  includedCoverage: boolean = true;
  buildingId: string = "001" // placeholder
  isAccordionTabActive: boolean = true;
  computerDescription: string = "";
  FormGroupSubscription: Subscription;
  fireDistrictSubscription: Subscription;
  migLiabilityResources = new MIGLiabilityResources();
  bldValidators: MIGBOPLocationBuildingValidators;
  editable: boolean = true;
  saveClicked: boolean = false;
  editClicked: boolean = false;
  hasSplitProtectionClass: boolean = false; 
  splitProtectionClass: string = "";
  menu: any;
  //
  retailClassDisplay: GUIDE [] = [];
  retailClass: any;
  // retailClassDescription: string;
  // retailClassEligibility: string;
  showRetailClassDisplay:boolean;
  currentYear: number;
  constructor(
    public func: Functions,
    public menuClass: MenuClass,
    public formBuilder: UntypedFormBuilder,
    public migRoles: MIGSecurityRoles,
    public dropDowns: ContractorsDropDowns,
    public cd: ChangeDetectorRef,
    public guideService: GuideService,
    public migsystemservice: MIGSystemService,
    public masks: InputMasksClass,
    public locationComponent: BopLocationSummaryComponent
  ) {
    this.formBuilder = new UntypedFormBuilder();
    this.bldValidators = new MIGBOPLocationBuildingValidators(this.func);
    this.editable = this.migRoles.editable; // first set this flag based on if we are in colleague view or agent view. 
   }
   //use a getter here so we can just check the value on the checkbox if checked
   get RetailInstallationClass() { return this.buildingFormGroup.get("RetailInstallationClass"); }

  ngOnInit() {
      this.locationObject = this.locationComponent.locationObject;
      this.currentYear = new Date().getFullYear();
      this.buildingId = this.buildingObject.BLDNUM;
      this.initializeFormGroup();
      this.setUpFormGroupSubscription();
      this.menuClass.stepActiveObject.forms.push(this.buildingFormGroup);

      this.fireDistrictSubscription = this.migsystemservice.subscribeGetFireDistricts().subscribe(districts => {
        this.fireDistrictsArray = districts;
              if (districts.length == 1){
                this.buildingObject.RATCTY = districts[0].label.trim();
              }
              let currentRATCTY = this.buildingObject.RATCTY
              if (currentRATCTY == '')
              {
                  this.dropDowns.RATCTY = [];
                  this.fireDistrictsArray.forEach(element => {
                    this.dropDowns.RATCTY.push({"value": element.label, "label": element.label});
                    if (element.label.trim() === this.buildingObject.RATCTY.trim()) {
                      currentRATCTY = element.label;
                    }
                  });
              }
      });
      if(this.buildingObject.RATCTY != ''){ //the buildingObject's RATCTY won't be blank if we are adding another building, it should match building 001. 
        this.fireDistrictsArray.push(this.buildingObject.RATCTY); // this array should now have a length of 1, so we will only display the selected fire district instead of the dropdown.
      }
      this.updateValidation();
      if(this.buildingFormGroup.valid){
        this.editable = false; // if our building is valid, set our flag to false so our building is in a read-only state. 
        this.buildingFormGroup.disable();
      }
    //}
  }


  ngDoCheck(){
    if(this.retailClassDisplay.length == 0){
      this.retailClassDisplay = this.locationComponent.guide.filter(x=>x.STATECODE == this.buildingObject.PRMSTE && x.SICCDE == this.buildingObject.BLDSIC);
      this.showRetailClassDisplay = this.retailClassDisplay.some(retailClassDisplay => retailClassDisplay.PRODUCT == 'RTIN');
      //this is used for displaying the description and eligibilty of the RTIN class
      //* had to hrd code to class codes since there are duplcate RETL rekated clsses in the the data with same SICCDE AND STATE
      //* (Paint, Wallpaper or Wallcovering) and (Glass or Mirror Store - No Auto Glass) 
      if(this.buildingObject.BLDCLS == '131408' || this.buildingObject.BPPCLS == '131408'){
        this.retailClass = this.retailClassDisplay.find(x=>x.PRODUCT == 'RTIN' && x.CLASSCODE == '131412');
      }
      else if (this.buildingObject.BLDCLS == '131196' || this.buildingObject.BPPCLS == '131196') {
        this.retailClass = this.retailClassDisplay.find(x=>x.PRODUCT == 'RTIN' && x.CLASSCODE == '131198');
      }
      else{
        this.retailClass = this.retailClassDisplay.find(x=>x.PRODUCT == 'RTIN');
      }
    }
  }

  ngOnDestroy(): void {
    if(this.FormGroupSubscription) this.FormGroupSubscription.unsubscribe();
    if(this.fireDistrictSubscription) this.fireDistrictSubscription.unsubscribe();
  }

  initializeFormGroup(){
    if(this.quote instanceof BOPQuote){
      this.buildingFormGroup = this.formBuilder.group({
      BLDNUM: [this.buildingObject.BLDNUM],          
      RetailInstallationClass: [(this.buildingObject.BOPSEGMENTINFO.RTIFLT1 != 0 || this.buildingObject.BOPSEGMENTINFO.RTIPRT1 != 0)],
      RetailFullTime: [this.buildingObject.BOPSEGMENTINFO.RTIFLT1],
      RetailPartTime: [this.buildingObject.BOPSEGMENTINFO.RTIPRT1],
      PercentageOfReceipts: [this.buildingObject.BOPSEGMENTINFO.PCTRCT == 0 ? "" : this.buildingObject.BOPSEGMENTINFO.PCTRCT], // Bug 268: this field now defaults to displaying blank, not 0 - JTL
      Territory: [this.buildingObject.TERR],
      ProtectionClass: [this.buildingObject.PROCLS],
      FireDistrict: [this.buildingObject.RATCTY],
      FeetFromHydrant: [this.buildingObject.FTHYDT],
      MilesFromDepartment: [this.buildingObject.FDMILE],
      // PercentSprinklered: [this.buildingObject.SPRINK == "Y" ? "Y" : this.buildingObject.SPRINK == "N" ? "N" : ""],
      PercentSprinklered: [this.buildingObject.SPRINK == "Y" ? "Y" : "N"],
      FireAlarm: [this.buildingObject.FIRALM],
      BurglarAlarm: [this.buildingObject.BURGAL],
      WindstormDevices: [this.buildingObject.WINDPRT],
      ConstructionType: [this.buildingObject.CONSTR, this.bldValidators.ValidateRequired("ConstructionType", "Construction Type")],
      PropertyDeductible: [this.quote.QUOTEPERSONALINFO.PRPDED],
      WindstormHailDeductible: [this.buildingObject.WINHDED],
      ConstructionYear: [this.buildingObject.OCONYR == 0 ? "" : this.buildingObject.OCONYR.toString(), this.bldValidators.ValidateRequiredWithinDateRange("ConstructionYear","Year of Original Construction", "1800:" + this.currentYear.toString())],
      YearRoofInstalled: [this.buildingObject.YGROOF == 0 ? "" : this.buildingObject.YGROOF],
      YearElectricInstalled: [this.buildingObject.YGELEC == 0 ? "" : this.buildingObject.YGELEC],
      YearPlumbingInstalled: [this.buildingObject.YGPLMB == 0 ? "" : this.buildingObject.YGPLMB],
      YearHeatInstalled: [this.buildingObject.YGHEAT == 0 ? "" : this.buildingObject.YGHEAT],
      BLDLMT: [this.buildingObject.BLDLMT],
      BPPLMT: [this.buildingObject.BPPLMT],
      Occupancy: [this.buildingObject.OWNOCP],
      Valuation: [this.buildingObject.BLDVAL],
      SingleOccupancy: [this.buildingObject.SNGOFG == "Y" ? "Y" : this.buildingObject.SNGOFG == "N" ? "N" : "", this.bldValidators.ValidateRequired("SingleOccupancy", "Single Occupancy",false,true)],
      ApartmentOccupancy: [this.buildingObject.APTOCC == "Y" ? "Y" : this.buildingObject.APTOCC == "N" ? "N" : ""],
      ApartmentPercentage: [this.buildingObject.APTPCT],
      ApartmentUnits: [this.buildingObject.NOUNIT],
      TenantRelocation: [this.buildingObject.TRUNT],
      ConvertedDwelling: [this.buildingObject.CNVDWL == "Y" ? "Y" : this.buildingObject.CNVDWL == "N" ? "N" : "", this.bldValidators.ValidateRequired("ConvertedDwelling", "Converted Dwelling",false,true)],
      CookingOccupancy: [this.buildingObject.COOKFC == "Y" ? "Y" : this.buildingObject.COOKFC  == "N" ? "N" : ""],
      AutomaticExhaustSystem: [this.buildingObject.ACCSYS == "Y" ? "Y" : this.buildingObject.ACCSYS == "N" ? "N" : ""],
      CondoUnitOwner: [this.buildingObject.CONDUO],
      AccountsReceivableCB: [true],
      AccountsReceivableOn: [this.buildingObject.ACRON == 0 ? "$25,000" : this.buildingObject.ACRON],
      BaileesCB: [this.buildingObject.BAILMT > 0],
      BaileesLimit: [this.buildingObject.BAILMT],

      BusinessIncomeAndExtraExpenseCB: [true],
      TimePeriodDeductible: [this.buildingObject.TPDED],
      InterruptionOfComputersCB: [true],
      InterruptionOfComputersLimit: [this.buildingObject.BIEEIC == 0 ? "$25,000" : this.buildingObject.BIEEIC, this.bldValidators.ValidateMinValue("InterruptionOfComputersLimit", "Interruption Of Computers", 25000,"cannot be less than",true) ],
      DependentPartiesCB: [true],
      DataRestorationCB: [true],
      DataRestorationLimit: [this.buildingObject.DTRSTL == 0 ? "$10,000" : this.buildingObject.DTRSTL, [this.bldValidators.ValidateMinValue("DataRestorationLimit", "Data Restoration", 10000, "cannot be less than", true),
      this.bldValidators.ValidateMaxValue(250000,"DataRestorationLimit", "Data Restoration","cannot be greater than",true)]
      ],
      CondoCommercialUnitCB: [(this.buildingObject.LASLPU > 0) || (this.buildingObject.MRPLPU > 0)],
      LossAssessment: [this.buildingObject.LASLPU],
      MiscRealProperty: [this.buildingObject.MRPLPU],
      EarthquakeCB: [this.buildingObject.EQDFLG],
      ElevatorEscalatorCB: [this.buildingObject.ELVINSP != ""],
      NumberOfElevatorsEscalators: [this.buildingObject.ELVINSP],
      FineArtsCB: [true],
      FineArtsLimit: [this.buildingObject.FARTLM == 0 ? "$25,000" : this.buildingObject.FARTLM],
      FoodContaminationCB: [this.buildingObject.FCLAAE > 0],
      ForgeryAndAlterationCB: [true],
      ForgeryAndAlterationLimit: [this.buildingObject.FALTLM == 0 ? "$25,000" : this.buildingObject.FALTLM,[this.bldValidators.ValidateMinValue("ForgeryAndAlterationLimit", "Forgery and Alteration Total Limit", 25000, "cannot be less than", true),
      this.bldValidators.ValidateMaxValue(200000,"ForgeryAndAlterationLimit", "Forgery and Alteration Total Limit","cannot be greater than",true)]],
      GaragekeeperCB: [this.locationObject.GARAGEKEEPER.GKCMPL > 0],
      GaragekeeperDirectPrimary: [this.locationObject.GARAGEKEEPER.GKCMPL],
      LiquorLiabilityCB: [this.buildingObject.LIQUORLIABILITY.LIQAOR > 0],
      LiquorLiabilityLimit: [this.buildingObject.LIQUORLIABILITY.LIQAOR == 0 ? "" : this.buildingObject.LIQUORLIABILITY.LIQAOR],
      OutdoorPropertyCB: [true],
      OutdoorSignsCB: [true],
      OutdoorSignsLimit: [this.buildingObject.OUTSNL == 0 ? "$5,000" : this.buildingObject.OUTSNL],
      PetPlusCB: [this.locationObject.PETPLUS.PETLPA > 0],
      PetPlusLimit: [this.locationObject.PETPLUS.PETLPA + "/" + this.locationObject.PETPLUS.PETLAG],
      SpoilageCB: [true],
      SpoilageLimit: [this.buildingObject.SPLOLM == 0 ? "$25,000" : this.buildingObject.SPLOLM],
      TenantExteriorGlassCB: [true],
      UtilityCB: [true],
      DirectDamageLimit: [this.buildingObject.USDDLM == 0 ? "$25,000" : this.buildingObject.USDDLM],
      TimeElementLimit: [this.buildingObject.USTELM == 0 ? "$25,000" : this.buildingObject.USTELM],
      ValuablePapersCB: [true],
      ValuablePapersLimit: [this.buildingObject.VLPONL == 0 ? "$25,000" : this.buildingObject.VLPONL],
      WaterOverflowCB: [true],
      RECORDSTATE: [this.buildingObject.RECORDSTATE]
      });
    }
  }

  /**
 * 
 */

  setUpFormGroupSubscription(){
    this.FormGroupSubscription = this.buildingFormGroup.valueChanges.pipe(distinctUntilChanged()).subscribe(data =>{
      //console.log("FG: ", this.buildingFormGroup.value)
      // if(this.buildingObject.BOPSEGMENTINFO != undefined) {
      //   this.buildingObject.BOPSEGMENTINFO.PCTRCT = this.func.getValueFromPercentage(data.PercentageOfReceipts);
      // }
      this.buildingObject.BOPSEGMENTINFO.PCTRCT = this.func.getValueFromPercentage(data.PercentageOfReceipts);
      this.buildingObject.BOPSEGMENTINFO.RTIFLT1 = parseInt(data.RetailFullTime);       
      this.buildingObject.BOPSEGMENTINFO.RTIPRT1 = parseInt(data.RetailPartTime);
      this.buildingObject.BUSINESSLIABILITY.FULTIM = parseInt(data.RetailFullTime);       
      this.buildingObject.BUSINESSLIABILITY.PRTTIM = parseInt(data.RetailPartTime);

      this.buildingObject.SPRINK = data.PercentSprinklered === true ? "Y" : data.PercentSprinklered === false ? "N" : "";
      if(data.Territory != ""){
          this.buildingObject.TERR = data.Territory;
      }
      this.buildingObject.FTHYDT = data.FeetFromHydrant;
      this.buildingObject.PROCLS = data.ProtectionClass;
      this.buildingObject.FDMILE = data.MilesFromDepartment;
      this.buildingObject.FIRALM = data.FireAlarm;
      this.buildingObject.BURGAL = data.BurglarAlarm;
      //this.buildingObject.WINDPRT = data.WindstormDevices === true ? "Y" : data.WindstormDevices === false ? "N" : "";
      this.buildingObject.WINDPRT = this.func.setInputSwitchValue(data.WindstormDevices);
      this.buildingObject.CONSTR = data.ConstructionType;
      this.buildingObject.OCONYR = data.ConstructionYear != "" ? parseInt(data.ConstructionYear) : 0;
      this.buildingObject.YGROOF = data.YearRoofInstalled != "" ? parseInt(data.YearRoofInstalled): 0;
      this.buildingObject.YGELEC = data.YearElectricInstalled != "" ? parseInt(data.YearElectricInstalled): 0;
      this.buildingObject.YGPLMB = data.YearPlumbingInstalled != "" ? parseInt(data.YearPlumbingInstalled): 0;
      this.buildingObject.YGHEAT = data.YearHeatInstalled != "" ? parseInt(data.YearHeatInstalled): 0;

      this.buildingObject.BLDLMT = this.func.justNumbers(data.BLDLMT);
      this.buildingObject.BPPLMT = this.func.justNumbers(data.BPPLMT);
      this.buildingObject.OWNOCP = this.func.getValueFromPercentage(data.Occupancy).toString(); // remove percentage but store number as string
      this.buildingObject.BLDVAL = data.Valuation;
      //this.buildingObject.SNGOFG = data.SingleOccupancy === true ? "Y" : data.SingleOccupancy === false ? "N" : "";
      this.buildingObject.SNGOFG = this.func.setInputSwitchValue(data.SingleOccupancy);
      //this.buildingObject.APTOCC = (data.ApartmentOccupancy == true || data.ApartmentOccupancy == "Y" ) ? "Y" : (data.ApartmentOccupancy === false || data.ApartmentOccupancy == "N") ? "N" : "";
      this.buildingObject.APTOCC = this.func.setInputSwitchValue(data.ApartmentOccupancy);

      this.buildingObject.APTPCT = this.func.getValueFromPercentage(data.ApartmentPercentage);
      this.buildingObject.NOUNIT = data.ApartmentUnits;
      this.buildingObject.TRUNT = data.TenantRelocation;
      //this.buildingObject.CNVDWL = data.ConvertedDwelling === true ? "Y" : data.ConvertedDwelling === false ? "N" : "";
      this.buildingObject.CNVDWL = this.func.setInputSwitchValue(data.ConvertedDwelling);
      this.buildingObject.COOKFC = this.func.setInputSwitchValue(data.CookingOccupancy);
      this.buildingObject.ACCSYS = this.func.setInputSwitchValue(data.AutomaticExhaustSystem);
      //this.buildingObject.COOKFC = (data.CookingOccupancy == true || data.CookingOccupancy == "Y") ? "Y" : ( data.CookingOccupancy == "N" || data.CookingOccupancy == false) ? "N" : "";
      //this.buildingObject.ACCSYS = data.AutomaticExhaustSystem === true ? "Y" : data.AutomaticExhaustSystem === false ? "N" : "";
      //this.buildingObject.CONDUO = data.CondoUnitOwner === true ? "Y" : data.CondoUnitOwner === false ? "N" : "";
      this.buildingObject.CONDUO = this.func.setInputSwitchValue(data.CondoUnitOwner);
      // the following properties are getting set from the Additional Coverages section: 
      this.buildingObject.ACRON = this.func.justNumbers(data.AccountsReceivableOn);
      this.buildingObject.BAILMT =  this.func.justNumbers(data.BaileesLimit);
      this.buildingObject.BIEEIC = this.func.justNumbers(data.InterruptionOfComputersLimit);
      this.buildingObject.DTRSTL = this.func.justNumbers(data.DataRestorationLimit);
      this.buildingObject.LASLPU = this.func.justNumbers(data.LossAssessment);
      this.buildingObject.MRPLPU = this.func.justNumbers(data.MiscRealProperty);
      this.buildingObject.EQDFLG = data.EarthquakeCB === true ? "Y" : "";
      this.buildingObject.ELVINSP = data.NumberOfElevatorsEscalators != null ? this.func.lpad(data.NumberOfElevatorsEscalators.toString(),"0",2) : "";
      this.buildingObject.FARTLM = this.func.justNumbers(data.FineArtsLimit);
      this.buildingObject.FCLBIE = data.FoodContaminationCB === true ? 10000 : 0;
      this.buildingObject.FCLAAE = data.FoodContaminationCB === true ? 3000 : 0;
      this.buildingObject.FALTLM = this.func.justNumbers(data.ForgeryAndAlterationLimit);

      // this.locationObject.GARAGEKEEPER.GKCMPL = data.GaragekeeperDirectPrimary;
      // this.locationObject.GARAGEKEEPER.GKCOLL = data.GaragekeeperDirectPrimary;
      this.locationObject.GARAGEKEEPER.GKCMPDC = data.GaragekeeperCB ? 250 : 0;
      this.locationObject.GARAGEKEEPER.GKCMPDO = data.GaragekeeperCB ? 500 : 0;
      this.locationObject.GARAGEKEEPER.GKCOLD = data.GaragekeeperCB ? 500 : 0;

      this.buildingObject.LIQUORLIABILITY.LIQAOR = this.func.justNumbers(data.LiquorLiabilityLimit);
      this.buildingObject.OUTSNL = this.func.justNumbers(data.OutdoorSignsLimit);

      this.locationObject.PETPLUS.PETUSB = data.PetPlusCB ? 250 : 0;
      this.locationObject.PETPLUS.PETERA = data.PetPlusCB ? 2500 : 0;
      this.locationObject.PETPLUS.PETTRM = data.PetPlusCB ? 25000 : 0;
      this.locationObject.PETPLUS.PETOFP = data.PetPlusCB ? 25000 : 0;
      this.locationObject.PETPLUS.PETRWD = data.PetPlusCB ? 1000 : 0;
      this.locationObject.PETPLUS.PETDPA = data.PetPlusCB ? 25 : 0;
      this.locationObject.PETPLUS.PETDAG = data.PetPlusCB ? 100 : 0;

      this.buildingObject.SPLOLM = this.func.justNumbers(data.SpoilageLimit);

      this.buildingObject.USDDLM = this.func.justNumbers(data.DirectDamageLimit);
      this.buildingObject.USTELM = this.func.justNumbers(data.TimeElementLimit);
      this.buildingObject.VLPONL = this.func.justNumbers(data.ValuablePapersLimit);
      this.buildingObject.VLPOFL = this.hasBPPLimit() ? 10000 : 0;
      this.checkBusinessLogic();
      this.updateValidation();

    });
    //this.buildingFormGroup.updateValueAndValidity();
  }

  checkBusinessLogic(){
    // business logic that is based on the form control can stay here.
    if(!this.buildingFormGroup.get("CondoCommercialUnitCB").value){
      this.buildingObject.LASLPU = 0;
      this.buildingObject.MRPLPU = 0;
    }
    // if the user enters Apartment information, then switches Single Occupancy to Yes or clears out building limit, we want to clear out apartment occupancy, percentage, and # of units.
    if((this.buildingObject.SNGOFG == "Y" || !this.buildingObject.hasBuildingLimit()) && this.buildingObject.APTOCC != ""){ // checking for this.buildingObject.APTOCC != "" will prevent endless loop because we will set APTOCC to "" if this statement is true 
      this.buildingFormGroup.get("ApartmentOccupancy").setValue("",{emitEvent:false});
      this.buildingFormGroup.get("ApartmentPercentage").setValue(0,{emitEvent:false});
      this.buildingFormGroup.get("ApartmentUnits").setValue(0,{emitEvent:false});
      this.buildingObject.APTOCC = "";
      this.buildingObject.APTPCT = 0;
      this.buildingObject.NOUNIT = 0;
    }
    // if user enters apartment information, then selects No for Apartment Occupancy, we want to clear out apartment percentage and # of units.
    if(this.buildingObject.APTOCC == "N" && (this.buildingObject.APTPCT != 0 || this.buildingObject.NOUNIT != 0)){ 
      this.buildingFormGroup.get("ApartmentPercentage").setValue(0,{emitEvent:false});
      this.buildingFormGroup.get("ApartmentUnits").setValue(0,{emitEvent:false});
      this.buildingObject.APTPCT = 0;
      this.buildingObject.NOUNIT = 0;
    }
    

    if(this.buildingObject.LOCST != "37"){
      this.buildingFormGroup.get("ElevatorEscalatorCB").setValue(false,{emitEvent:false});
    }
    if(!this.buildingFormGroup.get("ElevatorEscalatorCB").value){
      this.buildingObject.ELVINSP = "";
    }

    this.buildingObject.checkBusinessLogic(); // the rest of the business logic that just manipulates the building object's properties is in here
  
  }



  updateValidation(){
    // this function will get called once on init, as well as every time the form gets updated. 
    // The form controls here are dynamic, many of them are dependent on other controls, so we need to determine whether or not we want to check for validation.

    let formGroupValidators: ValidatorFn[] = []; // this array will hold our validators that are tied to the FORM GROUP, not any particular control. Each time we update the form, we clear this array, and re-add our validators accordingly. 
    // Otherwise this or Business Personal Property must be greater than 0.  Able to have both building and BPP limit greater than 0
    if(!this.hasBuildingLimit() && !this.hasBPPLimit()){
      formGroupValidators.push(this.bldValidators.validateOneOfTwoFieldsRequired("BLDLMT", "Building Limit","BPPLMT", "Business Personal Property Limit", true));
    }
    // When lessors class selected (BLDSEG or BPPSEG = LSRO), building limit must be greater than 0.  
    this.buildingFormGroup.get("BLDLMT").setValidators(this.hasSegment("LSRO") ? 
    this.bldValidators.ValidateRequired("BLDLMT", "Building Limit", true)
    : Validators.nullValidator);

    /* Owner Occupancy: Do not display on first location, first building.
    Only show when building limit is greater than 0.
    Value must be between 25 - 100 if class code is not lessors (BLDSEG or BPPSEG = LSRO)
    Value must be between 0 - 24 if class code is lessors */  
    this.buildingFormGroup.get("Occupancy").setValidators(!this.firstLocationFirstBuilding() && this.hasBuildingLimit() ? [
      this.bldValidators.ValidateMinValue("Occupancy", "Owner Occupancy", this.hasSegment("LSRO") ? 0 : 25, "must be greater than", false, true),
      this.bldValidators.ValidateMaxValue(this.hasSegment("LSRO") ? 24 : 100,"Occupancy", "Owner Occupancy", "cannot be greater than", false, true)
    ]: Validators.nullValidator);
    // Apartment Occupancy: Only display when 'Single Occupancy' = No and building limit is greater than 0. Required when displayed
    this.buildingFormGroup.get("ApartmentOccupancy").setValidators(this.showApartmentOccupancy() ? 
      this.bldValidators.ValidateRequired("ApartmentOccupancy", "Apartment Occupancy", false, true)
      : Validators.nullValidator);
    // Apartment Percentage and Number of Units: Only display when 'Apartment Occupancy' = Yes. Required when displayed Min = 1 Max = 100
    this.buildingFormGroup.get("ApartmentPercentage").setValidators(this.hasApartmentOccupancy() ? [
      this.bldValidators.ValidateMinValue("ApartmentPercentage", "Apartment Percentage", 1, "must be at least", false, true),
      this.bldValidators.ValidateMaxValue(100,"ApartmentPercentage", "Apartment Percentage", "must be less than", false, true)
    ]: Validators.nullValidator);

    this.buildingFormGroup.get("ApartmentUnits").setValidators(this.hasApartmentOccupancy() ? [
      this.bldValidators.ValidateMinValue("ApartmentUnits", "Apartment Units", 1, "must be at least", false),
      this.bldValidators.ValidateMaxValue(99,"ApartmentUnits", "Apartment Units", "must be less than", false)
    ]: Validators.nullValidator);
    // Tenant Relocation Expense: Only display when 'Apartment Occupancy' = Yes and Location state = Mass
    this.buildingFormGroup.get("TenantRelocation").setValidators(this.hasApartmentOccupancy() && this.buildingObject.LOCST == "20" && this.hasBuildingLimit() ? 
    [
      this.bldValidators.ValidateMinValue("TenantRelocation", "Tenant Relocation Expense", 1, "must be at least", false),
      this.bldValidators.ValidateMaxValue(99,"TenantRelocation", "Tenant Relocation Expense", "must be less than", false)
    ]: Validators.nullValidator);
    
    // Commercial Cooking Occupancy: Only display and require when building limit is greater than 0
    this.buildingFormGroup.get("CookingOccupancy").setValidators(this.hasBuildingLimit() ? 
      this.bldValidators.ValidateRequired("CookingOccupancy", "Commercial Cooking Occupancy",false,true)
      : Validators.nullValidator);
    // Fire District: only validate required if the territory code returns more than one fire district. 
    this.buildingFormGroup.get("FireDistrict").setValidators(this.fireDistrictsArray.length > 1 ? 
      this.bldValidators.ValidateRequired("FireDistrict", "Fire District")
      : Validators.nullValidator);

    
    // Percentage of receipts from installation, service, or repair: Require when displayed. Min: 0%, Max 100%
    this.buildingFormGroup.get("PercentageOfReceipts").setValidators(this.hasSegment("RETL") ? [
      this.bldValidators.ValidateRequired("PercentageOfReceipts", "Percentage of receipts from installation, service or repair"),
      this.bldValidators.ValidateMaxValue(100, "PercentageOfReceipts", "Percentage of receipts from installation, service, or repair", "cannot be greater than", false, true)
    ]: Validators.nullValidator);
    

    // Windstorm Protective Devices: Only display when state = NY; Required when displayed
    this.buildingFormGroup.get("WindstormDevices").setValidators(this.locationObject.ADDRESS.STATE == "31" ? this.bldValidators.ValidateRequired("WindstormDevices", "Windstorm Protective Devices",false, true) : Validators.nullValidator);

    // Feet From Hydrant and Miles From Department: Only display when split protection class is returned. Required to make a selection when displayed
    this.buildingFormGroup.get("FeetFromHydrant").setValidators(this.splitProtectionClass ? this.bldValidators.ValidateRequired("FeetFromHydrant", "Feet From Hydrant") : Validators.nullValidator);
    this.buildingFormGroup.get("MilesFromDepartment").setValidators(this.splitProtectionClass ? this.bldValidators.ValidateRequired("MilesFromDepartment", "Miles From Department") : Validators.nullValidator);

    // Year of Updates: Optional : Cannot be less than year of original constuction. Cannot be a year that hasn't occurred yet.
    this.buildingFormGroup.get("YearRoofInstalled").setValidators(this.buildingObject.YGROOF > 0 ? [
        this.bldValidators.ValidateMinValue("YearRoofInstalled", "Year Roof Installed", this.buildingObject.OCONYR, "cannot be earlier than", false),
        this.bldValidators.ValidateMaxValue(this.currentYear, "YearRoofInstalled", "Year Roof Installed", "cannot be later than", false)
    ] : Validators.nullValidator);
    this.buildingFormGroup.get("YearElectricInstalled").setValidators(this.buildingObject.YGELEC > 0 ? [
        this.bldValidators.ValidateMinValue("YearElectricInstalled", "Year Electric Installed", this.buildingObject.OCONYR, "cannot be earlier than", false),
        this.bldValidators.ValidateMaxValue(this.currentYear, "YearElectricInstalled", "Year Electric Installed", "cannot be later than", false)
    ] : Validators.nullValidator);
    this.buildingFormGroup.get("YearPlumbingInstalled").setValidators(this.buildingObject.YGPLMB > 0 ? [
        this.bldValidators.ValidateMinValue("YearPlumbingInstalled", "Year Plumbing Installed", this.buildingObject.OCONYR, "cannot be earlier than", false),
        this.bldValidators.ValidateMaxValue(this.currentYear, "YearPlumbingInstalled", "Year Plumbing Installed", "cannot be later than", false)
    ] : Validators.nullValidator);
    this.buildingFormGroup.get("YearHeatInstalled").setValidators(this.buildingObject.YGHEAT > 0 ? [
        this.bldValidators.ValidateMinValue("YearHeatInstalled", "Year Heat Installed", this.buildingObject.OCONYR, "cannot be earlier than", false),
        this.bldValidators.ValidateMaxValue(this.currentYear, "YearHeatInstalled", "Year Heat Installed", "cannot be later than", false)
    ] : Validators.nullValidator);
    // Automatic Commercial Cooking Exhaust & Extinguishing System: Only display when Class segment = Food (BLDSEG or BPPSEG = FOOD)
    this.buildingFormGroup.get("AutomaticExhaustSystem").setValidators(this.hasSegment("FOOD") ? this.bldValidators.ValidateRequired("AutomaticExhaustSystem", "Is there an Automatic Commercial Cooking Exhaust & Extinguishing System?",false, true) : Validators.nullValidator);
    // Condo Unit Owner: "Display when only BPP limit > 0 and building limit not entered. Required when displayed"
    this.buildingFormGroup.get("CondoUnitOwner").setValidators(this.hasBPPLimit() && !this.hasBuildingLimit() ? this.bldValidators.ValidateRequired("CondoUnitOwner", "Condo Unit Owner?",false, true) : Validators.nullValidator);

    // Bailees: "Min = 1 Max = 50,000"
    this.buildingFormGroup.get("BaileesLimit").setValidators( this.buildingFormGroup.get("BaileesCB").value ? 
    [this.bldValidators.ValidateRequired("BaileesLimit", "Bailees",true),
    this.bldValidators.ValidateMaxValue(50000,"BaileesLimit", "Bailees","cannot be greater than",true)] 
    : Validators.nullValidator);

    // Loss Assessment: "Display when 'Condominium Commercial Unit Owners Optional Coverage Limit' is selected. This or 'Miscellaneous Real Property' must have valid limit entered.  Able to have both limits entered. 
    // "Min = 1,000 Max = 250,000 *After 1,000 valid limit entered must be divisible by 5,000 Example: $1,000, $5,000, $10,000, $15,000, etc.."
    
    this.buildingFormGroup.get("LossAssessment").setValidators( this.buildingFormGroup.get("CondoCommercialUnitCB").value ? 
    [ this.bldValidators.validateValueIsDivisible("LossAssessment", "Loss Assessment", this.buildingObject.LASLPU == 1000 ? 1000 : 5000, true),
      this.bldValidators.ValidateMaxValue(250000,"LossAssessment", "Loss Assessment","cannot be greater than",true)] 
    : Validators.nullValidator);

    // Full Time and Part Time Employees: Display and require this field or 'Part Time Employees' if the 'Class' checkbox is selected within the 'Business Liability/Retail-Installation' section. Both can have a value
    if(this.buildingFormGroup.get("RetailInstallationClass").value){
      // Part Time Employees: "If full time employees is blank, minimum = 2 Max = 999"
        this.buildingFormGroup.get("RetailPartTime").setValidators(this.buildingFormGroup.get("RetailFullTime").value == "" ? this.bldValidators.ValidateMinValue("RetailPartTime","Retail Part Time Employees",2,"cannot be less than",false): Validators.nullValidator)
      formGroupValidators.push(this.bldValidators.validateOneOfTwoFieldsRequired("RetailFullTime", "Full Time","RetailPartTime", "Part Time Employees", true));
    }
    // if(this.buildingFormGroup.get("CondoCommercialUnitCB").value == true){
      if(this.buildingFormGroup.get("CondoCommercialUnitCB").value){
      formGroupValidators.push(this.bldValidators.validateOneOfTwoFieldsRequired("LossAssessment", "Loss Assessment","MiscRealProperty", "Miscellaneous Real Property"));
    }

    // Number of Elevators and each Escalator: Display and require when 'Elevator Inspection (per landing)' is selected. Min: 1, Max: 99
    this.buildingFormGroup.get("NumberOfElevatorsEscalators").setValidators(this.buildingFormGroup.get("ElevatorEscalatorCB").value ? this.bldValidators.ValidateRequired("ELVINSP", "Number of Elevators and each Escalator", true) : Validators.nullValidator);
  
    // Fine Arts: "Display when building limit and BPP limit is greater than 0 OR when BPP is greater than 0. Min = 25,000 Max = 250,000
    this.buildingFormGroup.get("FineArtsLimit").setValidators(this.hasBPPLimit() ? 
    [ this.bldValidators.ValidateMinValue("FineArtsLimit", "Fine Arts", 25000, "cannot be less than", true),
      this.bldValidators.ValidateMaxValue(250000, "FineArtsLimit", "Fine Arts", "cannot be greater than", true)]
    : Validators.nullValidator);

    // Liquor Receipts: Display and require when 'Liquor Legal Liability' is selected
    this.buildingFormGroup.get("LiquorLiabilityLimit").setValidators(this.buildingFormGroup.get("LiquorLiabilityCB").value ? this.bldValidators.ValidateRequired("LiquorLiabilityLimit","LiquorLiabilityLimit",true): Validators.nullValidator);
    
    // Outdoor Signs: Do not display if class segment is Office (BLDSEG = OFFC). Min = 5,000 Max = 250,000
    this.buildingFormGroup.get("OutdoorSignsLimit").setValidators(!this.hasSegment("OFFC") ? [
      this.bldValidators.ValidateMinValue("OutdoorSignsLimit","Outdoor Signs",5000,"cannot be less than",true),
      this.bldValidators.ValidateMaxValue(250000,"OutdoorSignsLimit","Outdoor Signs","cannot be greater than",true)
    ]: Validators.nullValidator);

    // SpoilageLimit: "Display when building limit and BPP limit is greater than 0 OR when BPP is greater than 0. Min = 25,000 Max = 100,000
      this.buildingFormGroup.get("SpoilageLimit").setValidators(this.hasBPPLimit() ?
          [this.bldValidators.ValidateMinValue("SpoilageLimit", "Spoilage", 25000, "cannot be less than", true),
              this.bldValidators.ValidateMaxValue(100000, "SpoilageLimit", "Spoilage", "cannot be greater than", true)
       ]: Validators.nullValidator);

    // Valuable Papers - On Premises / Off Premises: Display when building limit and BPP limit is greater than 0 OR when BPP is greater than 0. Min = 25,000 Max = 1,000,000
    this.buildingFormGroup.get("ValuablePapersLimit").setValidators( this.hasBPPLimit() ? 
    [ this.bldValidators.ValidateMinValue("ValuablePapersLimit","Valuable Papers - On Premises / Off Premises",25000,"cannot be less than",true),
      this.bldValidators.ValidateMaxValue(1000000,"ValuablePapersLimit","Valuable Papers - On Premises / Off Premises","cannot be greater than",true)
    ]: Validators.nullValidator);

    this.bldValidators.TriggerValidation(this.buildingFormGroup); //loops through each control and update it's validation
    this.buildingFormGroup.setValidators(formGroupValidators); // set our validators for the Form group here. 
    this.buildingFormGroup.updateValueAndValidity({emitEvent:false});
    let errors = this.menuClass.CalculateErrorsFormGroup(this.buildingFormGroup);
    if(this.buildingFormGroup.errors){
      errors.push(this.buildingFormGroup.errors);
    }
    
    this.migsystemservice.notifyError(errors); // updates the error panel as they fix them.
    this.cd.detectChanges();
  }

  disableIncludedCoverageCheckboxes(){ // for included coverages, when the coverage is displayed, we always want the checkbox to be checked, and unable to uncheck.
    this.buildingFormGroup.get("AccountsReceivableCB").disable({emitEvent:false});
    this.buildingFormGroup.get("BusinessIncomeAndExtraExpenseCB").disable({emitEvent:false});
    this.buildingFormGroup.get("InterruptionOfComputersCB").disable({emitEvent:false});
    this.buildingFormGroup.get("DependentPartiesCB").disable({emitEvent:false});
    this.buildingFormGroup.get("DataRestorationCB").disable({emitEvent:false});
    this.buildingFormGroup.get("FineArtsCB").disable({emitEvent:false});
    this.buildingFormGroup.get("ForgeryAndAlterationCB").disable({emitEvent:false});
    this.buildingFormGroup.get("OutdoorPropertyCB").disable({emitEvent:false});
    this.buildingFormGroup.get("OutdoorSignsCB").disable({emitEvent:false});
    this.buildingFormGroup.get("SpoilageCB").disable({emitEvent:false});
    this.buildingFormGroup.get("TenantExteriorGlassCB").disable({emitEvent:false});
    this.buildingFormGroup.get("UtilityCB").disable({emitEvent:false});
    this.buildingFormGroup.get("ValuablePapersCB").disable({emitEvent:false});
    this.buildingFormGroup.get("WaterOverflowCB").disable({emitEvent:false})
  }

  getTotalBuildings(): BOPBUILDING[] {
    return this.locationObject.getTotalBuildings();
  }

  deleteBuilding(buildingToDelete): void{ 
    this.buildingFormGroup.get("RECORDSTATE").setValue("D",{emitEvent:false});
    this.locationObject.deleteBuilding(buildingToDelete); // delete our building and resequence our BLDNUM's on our building objects;

    let buildingFormGroups = this.menuClass.stepActiveObject.forms.filter((fg:UntypedFormGroup)=> fg.get("BLDNUM") != undefined); // holds all the building form groups on our location menu step. 
    _.remove(buildingFormGroups, (form:UntypedFormGroup)=> { // remove the formgroup from our menu step of the building we are deleting
      return form.get("BLDNUM").value == buildingToDelete.BLDNUM
    });

    this.menuClass.stepActiveObject.forms = this.menuClass.stepActiveObject.forms.filter((fg:UntypedFormGroup)=> fg.get("BLDNUM") == undefined); // strip all the building form groups of our menu step, we will be re-adding them back after resequencing.
    let reIndex = 1;    
    buildingFormGroups.forEach((form:UntypedFormGroup) => { // resequence building numbers
      let newBldNum = this.func.lpad((reIndex).toString(), "0", 3);
      this.locationObject.resequenceNumbers(buildingFormGroups, form.get("BLDNUM").value, newBldNum, "BLDNUM") // resequence each formGroup to match our resequencing of the BLDNUM's
      reIndex ++; 
    })
    this.menuClass.stepActiveObject.forms.push(...buildingFormGroups) // this syntax functions the same as this.menuClass.stepActiveObject.forms.concat(buildingFormGroups)

    this.updateBuildingCountSubLabel(); 
  }

  updateBuildingCountSubLabel() // update our sublabel on the left menu to match the number of buildings on the location.
  {
      let buildingCount: number = this.getTotalBuildings().length;
      this.menuClass.stepActiveObject.sublabel = '<small>' + buildingCount + ' Building' + (buildingCount == 1 ? '' : 's') + '</small>';
  }
    
  

  selectFireDistrict(){
    if (this.fireDistrictsArray.length == 0)
		{	
			return;
		}

		var selectedOption = '';
    this.fireDistrictsArray.forEach(element => {
			if (element.label == this.buildingFormGroup.get('FireDistrict').value) {
				selectedOption = element.value; // selection option will contain various info based on Fire District. 
			} 
		});
    //console.log("selected Object 0-30: ", selectedOption.substring(0,30));
    //console.log("selected Object 33-41: ", selectedOption.substring(33,41));
		//Protection class		
    let protectionClassesWorkField = selectedOption.substring(41,49);
        
		//if future protection class is not blank, use it; if it's blank, use protection class
		if (!protectionClassesWorkField.replace(/\s/g, '').length) {
			protectionClassesWorkField = selectedOption.substring(33,41); 
      this.splitProtectionClass = protectionClassesWorkField;
		}
        
    this.buildingObject.RATCTY = selectedOption.substring(0,30).trim(); // first 30 characters will contain the fire district name
    this.buildingObject.TAXDSC = selectedOption.substring(57,87).trim(); // these 30 characters will contain the County name
    this.locationObject.getTotalBuildings().forEach((bld:BOPBUILDING)=>{
      bld.RATCTY = selectedOption.substring(0,30).trim();
      bld.TAXDSC = selectedOption.substring(57,87).trim();
    })


    this.hasSplitProtectionClass = this.isSplitProtectionClass(protectionClassesWorkField);
    this.updateValidation();
  }

  isSplitProtectionClass(splitProtectionClass) : boolean {
		let protectionClasses = splitProtectionClass.split("/").filter(function(value, index){
			return value.replace(/\s/g, '') != '';
		}).map((value:string) => value.replace(/\s/g, ''));

    return protectionClasses.length != 1;
	}


  selectFeetAndMiles(event) {
		let feet = this.buildingFormGroup.get('FeetFromHydrant').value;
		let miles = this.buildingFormGroup.get('MilesFromDepartment').value;

		this.buildingFormGroup.get('ProtectionClass').setValue(this.getProtectionClass(feet,miles));
  		
	}

  getProtectionClass(feet, miles) : string {
		let protectionClasses = this.splitProtectionClass.split("/").filter(function(value, index){
			return value.replace(/\s/g, '') != '';
		}).map((value:string) => value.replace(/\s/g, ''));

		if (protectionClasses.length == 1) { // if the protection class is not split, simply return our only protection class
			return protectionClasses[0].padStart(2, '0');	
		}

		switch(miles){ // if the protection class is split, the PC is based on what is entered in the Feet from Hydrant and Miles from Department dropdowns.
			case 'OVER 5 MILES': // if miles from department is this, the PC is 10 regardless of what is entered in Feet from Hydrant dropdown
				return "10";
			case "WITHIN 5 MILES": // if the miles from department is this, then the PC is determined by what is entered in Feet from Hydrant dropdown. 
				switch(feet){
					case "WITHIN 1000 FT":
						return protectionClasses[0].padStart(2, '0'); // if Within 1000 FT, use the first class 
          case "OVER 1000 FT":
						return protectionClasses[1].padStart(2, '0'); // if Over 1000 FT, use the second class
          default:
            return "";
				}
			default: 
				return "";
    }
  }

  firstLocationFirstBuilding(): boolean{ // return true if we are viewing the LOC 001 BLD 001 
    return  this.buildingObject.firstLocationFirstBuilding();
  }

  // hasSplitProtectionClass(): boolean {
  //   return this.buildingObject.PROCLS == "" && this.protectionClassesAandB != ""
  // }

  //coverage logic: 
  hasApartmentOccupancy(): boolean{
    return this.buildingObject.APTOCC == "Y";
  }

  showApartmentOccupancy(): boolean{ // Apartment Occupancy: Only display when 'Single Occupancy' = No and building limit is greater than 0
    return this.buildingObject.SNGOFG == "N" && this.hasBuildingLimit();
  }

  hasSingleOccupancy() : boolean{
    // if Single Occupancy is blank or "Y", we return true; if Single occupancy is "N", we return false;
    if(this.buildingObject.SNGOFG == "Y"){ // when Single Occupancy is "Y", we want to ensure there are no values saved in the "Apartment" fields
      return true;
    }
    return this.buildingObject.SNGOFG == ""; // return true if hasn't been answered yet; false if it is answered "No"
  }

  hasSegment(segment: string) : boolean { // pass in a particular segment (ex: "RETL"), will return true if the class selected has that segment.
    return this.buildingObject.hasSegment(segment);
  }

  //AdditionalCoverages: 
  hasBuildingLimit(): boolean{ // returns true if a BUILDING limit is entered
    return this.buildingObject.hasBuildingLimit();
  }

  hasBPPLimit(): boolean { // returns true is a BPP limit is entered
    return this.buildingObject.hasBPPLimit();
  }

  showCondoCommercialUnitCoverage(): boolean {
    //Per DD: Display when 'Condo Unit Owner' = Yes AND only BPP limit entered (BLDLMT = 0 & BPPLMT > 0)
    return (this.buildingObject.CONDUO == "Y" && !this.hasBuildingLimit() && this.hasBPPLimit());
  }

  canDeleteBuilding(): boolean {
    return this.getTotalBuildings().length > 1;
  }

  hasPropertyDamageDeductible(): boolean { // returns true if RTIN classcode = '131012', '131222', or '131412'
    return this.retailClass != null && (this.retailClass.CLASSCODE == "131012" || this.retailClass.CLASSCODE == "131222" || this.retailClass.CLASSCODE == "131412");
  }
  retailInstallationClicked(event):void{
    
    if(!event.checked){     
      //
      this.buildingObject.BOPSEGMENTINFO.RTIFLT1 = 0;       
      this.buildingObject.BOPSEGMENTINFO.RTIPRT1 = 0;
      this.buildingObject.BUSINESSLIABILITY.FULTIM = 0;       
      this.buildingObject.BUSINESSLIABILITY.PRTTIM = 0;
      this.buildingObject.BOPSEGMENTINFO.RTICLS1 = "";
      this.buildingObject.BUSINESSLIABILITY.CLASX = "";
      this.buildingObject.BUSINESSLIABILITY.CLSDSC = "";
      this.buildingObject.BUSINESSLIABILITY.CLSSEG = "";
      this.buildingFormGroup.get("RetailFullTime").setValue(0,{emitEvent:false});
      this.buildingFormGroup.get("RetailPartTime").setValue(0,{emitEvent:false});
    }
    else{ // if RTIN checkbox is checked, set these values; 
      this.buildingObject.BOPSEGMENTINFO.RTICLS1 = this.retailClass.CLASSCODE;
      this.buildingObject.BUSINESSLIABILITY.CLASX = this.retailClass.CLASSCODE;
      this.buildingObject.BUSINESSLIABILITY.CLSDSC = this.retailClass.DESCRIPTION.substring(0,78);
      this.buildingObject.BUSINESSLIABILITY.CLSSEG = "RTIN";
    }
  }

  saveBuilding(){
    this.saveClicked = true;
    if(this.buildingFormGroup.valid){
      this.buildingFormGroup.disable();
      this.saveClicked = false;
      this.editClicked = false;
      this.editable = false; // makes the fields for this building read-only.
      this.isAccordionTabActive = false;
    }
    else{
      let errors = this.menuClass.CalculateErrorsFormGroup(this.buildingFormGroup);
      if(this.buildingFormGroup.errors){
        errors.push(this.buildingFormGroup.errors);
      }
      
      this.migsystemservice.notifyDoneClicked(errors); // updates the error panel as they fix them.
    }
  }

  editBuilding(){
    this.editClicked = true;
    this.buildingFormGroup.enable();
    this.editable = true; //makes the fields for this building editable.
    this.disableIncludedCoverageCheckboxes();
    this.isAccordionTabActive = true;
  }

  confirmLocationLevelChange(controlName: string, property: string | number){ // some fields on the building form group are location level. If we try to change them on a building, we must prompt the user if we want to change them for all buildings on the location. 
    // controlName is the name of the form control. property is the name of the property that we will be modifying for each building if the user clicks "Yes"
    if(this.locationObject.getTotalBuildings().length == 1){ // if there is only one building on the location, do not show the confirm dialog.
      this.locationObject.getTotalBuildings()[0][property] = this.buildingFormGroup.get(controlName).value; 
      if(property == "GKCMPL"){ // if changing Garagekeeper dropdown, we also need to store the new value in the GKCOLL field
        this.locationObject.getTotalBuildings()[0]["GKCOLL"] = this.buildingFormGroup.get(controlName).value;
      }
    }
    else{
      this.locationComponent.confirmationService.confirm({
        header: 'Change Coverage?',
        message: "Changing this coverage will update this coverage for all buildings for this location. Do you wish to continue?",
        acceptLabel: "Yes",
        accept: () => { // When we select "Yes", we perform the function below.
          this.locationObject.getTotalBuildings().forEach((bld:BOPBUILDING)=>{
            bld[property] = this.buildingFormGroup.get(controlName).value; // update the object graph for each building in the location so that each building has the same value for the given property
            if(property == "GKCMPL"){ // if changing Garagekeeper dropdown, we also need to store the new value in the GKCOLL field
              this.locationObject.GARAGEKEEPER.GKCMPL = this.buildingFormGroup.get(controlName).value;
              this.locationObject.GARAGEKEEPER.GKCOLL = this.buildingFormGroup.get(controlName).value;
            }
            if(property == "PETLPA"){
              this.locationObject.PETPLUS.PETLPA = this.func.justNumbers(this.migLiabilityResources.processSplitList(this.buildingFormGroup.get("PetPlusLimit").value)[0]);
              this.locationObject.PETPLUS.PETLAG = this.func.justNumbers(this.migLiabilityResources.processSplitList(this.buildingFormGroup.get("PetPlusLimit")[1]));
            }
          });
          this.menuClass.stepActiveObject.forms.filter(((fg:UntypedFormGroup)=>fg.get("BLDNUM") != undefined)).forEach((form:UntypedFormGroup)=>{
            form.get(controlName).setValue(this.buildingFormGroup.get(controlName).value,{emitEvent: false}); // set the form controls so that the value of the dropdown are displayed on each building.
          if(property == "GKCMPL"){
            form.get("GaragekeeperCB").setValue(true, {emitEvent:false}); // this ensures the Garagekeeper checkbox is checked for all buildings on the location. 
          }
          if(property == "PETLPA"){
            form.get("PetPlusCB").setValue(true, {emitEvent:false});
          }
          })
        },

        reject: () => { // When selecting No, we want to revert the form control back to it's original value, as the form control's value gets updated before our dialog box appears.
          if(property == "PETLPA"){
            this.buildingFormGroup.get(controlName).setValue(this.locationObject.PETPLUS.PETLPA + "/" + this.locationObject.PETPLUS.PETLAG,{emitEvent:false}); // Set the dropdown back to the initial value.
          }
          else if(property == "GKCMPL"){
            this.buildingFormGroup.get(controlName).setValue(this.locationObject.GARAGEKEEPER.GKCMPL,{emitEvent:false}); // Set the dropdown back to the initial value.
          }
          else{
            this.buildingFormGroup.get(controlName).setValue(this.buildingObject[property],{emitEvent:false}); // Set the dropdown back to the initial value.
          }
        }
      });
    }
  }

  confirmPolicyLevelChange(controlName: string, property: string | number ){ // some fields on the building form group are policy level. If we try to change them on a building, we must prompt the user if we want to change them for all buildings on ALL locations. 
    if(this.quote instanceof BOPQuote){
      if(this.quote.BOPLOCATIONS.length == 1 && this.quote.getTotalLocations()[0].getTotalBuildings().length == 1){ // if there is only 1 location 1 building, don't show confirm dialog
        if(property == "PRPDED"){
          this.quote.QUOTEPERSONALINFO.PRPDED = this.buildingFormGroup.get(controlName).value;
        }
        else{
          this.locationObject.getTotalBuildings()[0][property] = this.buildingFormGroup.get(controlName).value;
        }
      }
      else{
        this.locationComponent.confirmationService.confirm({
          header: 'Change Coverage?',
          message: "Changing this coverage will update this coverage for all buildings for all locations. Do you wish to continue?",
          acceptLabel: "Yes",
          accept: () => { // When we select "Yes", we perform the function below.
            if(this.quote instanceof BOPQuote){
              if(property == "PRPDED"){
                this.quote.QUOTEPERSONALINFO.PRPDED = this.buildingFormGroup.get(controlName).value;
              }
              this.quote.getTotalLocations().forEach((loc:BOPLOCATION)=>{
                loc.getTotalBuildings().forEach((bld:BOPBUILDING)=>{
                  if(bld[property] != undefined){
                    bld[property] = this.buildingFormGroup.get(controlName).value; // update the object graph for each building in the location so that each building has the same value for the given property
                  }
                });
              })
              this.menuClass.stepActiveObject.forms.filter(((fg:UntypedFormGroup)=>fg.get("BLDNUM") != undefined)).forEach((form:UntypedFormGroup)=>{
                form.get(controlName).setValue(this.buildingFormGroup.get(controlName).value,{emitEvent: false}); // set the form controls so that the value of the dropdown
              })
            }
          },
          reject: () => { 
            if(this.quote instanceof BOPQuote){
              this.buildingFormGroup.get(controlName).setValue(property == "PRPDED" ? this.quote.QUOTEPERSONALINFO.PRPDED : this.buildingObject[property],{emitEvent:false}); // Set the dropdown back to the initial value.
            }
          }
        });
      }
    }
  }
}
