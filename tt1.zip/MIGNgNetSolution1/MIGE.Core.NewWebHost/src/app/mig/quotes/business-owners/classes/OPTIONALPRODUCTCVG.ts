import { BOPBASECLASS } from "./BOPBASECLASS";

export class OPTIONALPRODUCTCVG extends BOPBASECLASS {
    CEDED: number = 0;
    CELMT: number = 0;
    CIDED: number = 0;
    CILIO: number = 0;
    CILIP: number = 0;
    CILWL: number = 0;
    CILWT: number = 0;
    CTELIM: number = 0;
    CTESDED: number = 0;
    CTEUDD: number = 0;
    CTEULM: number = 0;
    EDSDTE: number = 0;
    EDSNO: number = 0;
    EFFDTE: number = 0;
    EMPTOD: number = 0;
    EMPTOL: number = 0;
    MSCULM: number = 0;
    NONOWD: number = 0;
    NONOWL: number = 0;
    RECORDSTATE: string = "N";

    constructor(data?) {
        super(data);

        if (data != undefined)
        {
            Object.assign(this, data);
        }
    }
}