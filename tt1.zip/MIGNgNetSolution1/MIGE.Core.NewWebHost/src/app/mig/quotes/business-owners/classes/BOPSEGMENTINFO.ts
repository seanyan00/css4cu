
     /* ****************************************************************************************************
     * PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS - SEE LIBRARY AND TABLE/FILENAME 
     * AS400 LIBRARY        - MIGPUADTAM
     * TABLE/FILENAME       - DW5E035
     * DESCRIPTION          - Small Pkg U/W Segmenet Information Master File
     * DATE CREATED         - 6/23/2022 7:46:05 AM
     * AUTHOR               - RICHARD FUMERELLE
     * VERSION              - 1.0
     * CODE GENERATION      - Automatic code generation using CodeSmith GenerationTool
     * NOTES                - This table can be modified.
     ****************************************************************************************************/

import { BOPBASECLASS } from "./BOPBASECLASS";

     export class  BOPSEGMENTINFO extends BOPBASECLASS {

        LOCNUM : string = "";
        BLDNUM : string = "";
        CLSSEG : string = "";
        RCDTYP : number = 0;
        PCTRCT : number = 0;
        RTICLS1 : string = "";
        RTIFLT1 : number = 0;
        RTIPRT1 : number = 0;
        ANYDLVY : string = "";
        RECORDSTATE: string = "N"
        constructor(data?) {
          super(data);
         
          if (data != undefined) {
              Object.assign(this, data);              
          }
      }
 
}

