import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UntypedFormBuilder, UntypedFormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MenuClass } from '@root/system/menu/menu';
import { BopLiabilityLimitsComponent } from './bop-liability-limits.component';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { AccordionModule } from 'primeng/accordion';
import { PanelModule } from 'primeng/panel';
import { FieldsetModule } from 'primeng/fieldset';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { TableModule } from 'primeng/table';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { TextMaskModule } from 'angular2-text-mask';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';
import { MIGInputSwitchModule } from '@overridden/primeng-inputswitch/switch.module';
import { MIGCalendarModule } from '@overridden/primeng-calendar/calendar.module';



@NgModule({
  declarations: [BopLiabilityLimitsComponent],
  imports: [
    CommonModule,
    MIGDropDownModule,
    AccordionModule,
    PanelModule,
		FieldsetModule,
		MIGButtonModule,
    TableModule,
		FormsModule,
    MIGInputtextModule,
    TextMaskModule,
    MIGCheckboxModule,
	ReactiveFormsModule,
	MIGInputSwitchModule,
	MIGCalendarModule
  ],
  exports: [BopLiabilityLimitsComponent]
})
export class BopLiabilityLimitsModule { 
	liabilityLimitsFormGroup: UntypedFormGroup;

	constructor(
		public menuClass: MenuClass,
		private formBuilder: UntypedFormBuilder,

	) {
		this.liabilityLimitsFormGroup = this.formBuilder.group({});

		menuClass.addMenuItem({
			name: 'LiabilityLimits',
			label: 'Liability Limits',
			color: "ui-steps-number-default",
			navSkip: false,
			active: false,
			hasError: false,
			errors: [],
			buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }],
			form: this.liabilityLimitsFormGroup,
			icon: 'fa fa-layer-group',
			block: [],
			visible: true,
			quote: "premium"
		});
	}
  
}
