import { Component, Input, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup } from '@angular/forms';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { BOPQuote } from '@classViewModels/BOP/BOPQuote';
import { BopOptionalCoveragesData } from '@helpers/bop_optional_coverages';
import { Functions } from '@helpers/functions';
import { InputMasksClass } from '@helpers/masks';
import { MenuClass } from '@root/system/menu/menu';
import { Subscription } from 'rxjs';
import * as _ from 'lodash';
import { debounceTime } from 'rxjs/operators';
import { MIGBOPOptionalCoverageValidators } from './bop-optional-coverages-validators';
import { BOPLOCATION } from '../../classes/BOPLOCATION';
import { PROFLIABILITY, STATETRANSACTION } from '../../classes/BOPClasses';
import { ConfirmationService } from 'primeng/api';

@Component({
  selector: 'mig-bop-optional-coverages',
  templateUrl: './bop-optional-coverages.component.html',
  styleUrls: ['./bop-optional-coverages.component.css'],
  providers: [ConfirmationService]
})
export class BopOptionalCoveragesComponent implements OnInit {
    @Input() quote: BOPQuote;
    optionalCoveragesFormGroup: UntypedFormGroup;
    validators: MIGBOPOptionalCoverageValidators;

    scheduledOptionalCoverages: any[];
    optionalCoveragesFormGroupSubscription: Subscription;
    quoteHasRetailInstallationClass: boolean = false;
    formatter: Intl.NumberFormat;
    hasEmployeeDishonestyCoverage: boolean;
    lessorsPredominantSegment: boolean = false;
    hasOhioLocation: boolean = false;
    hasProfessionalClassCode: boolean = false;
    ohioStateTransactionRecordForQuote: STATETRANSACTION = null;
    quoteBuildingAndBPPClassCodes: string[];
    hasRetailOrServiceBPP: boolean = false;

    contractorsInstallationDropdownOptions: any[] = [
        {"value": "INCLUDED", "label": "Included"}
        , {"value": "OPTIONAL", "label": "Optional"}
    ];

    CYBAGGDropdownOptions: any[] = [{
        "value": 100000,
        "label": "$100,000",
        "states": ["31", "20", "21", "28", "29", "34", "37", "38", "44"]
    },
    {
        "value": 250000,
        "label": "$250,000",
        "states": ["20", "21", "28", "29", "34", "37", "38", "44"]
    },
    {
        "value": 500000,
        "label": "$500,000",
        "states": ["20", "21", "28", "29", "34", "37", "38", "44"]
    },
    {
        "value": 1000000,
        "label": "$1,000,000",
        "states": ["20", "21", "28", "29", "34", "37", "38", "44"]
    }
    ];

    ELDATADropdownOptions: any[] = [
        {"value": 25000, "label": "$25,000"}
        , {"value": 50000 , "label": "$50,000"}
        , {"value": 75000 , "label": "$75,000"}
    ];

    EMPOLMDropdownOptions: any[] = [
        {"value": 25000, "label": "$25,000"}
        , {"value": 50000 , "label": "$50,000"}
        , {"value": 100000 , "label": "$100,000"}
        , {"value": 150000 , "label": "$150,000"}
        , {"value": 200000 , "label": "$200,000"}
    ];

    MoneySecuritiesCCSlipDropdownOptions: any[] = [
        {"value": "10000/10000", "label": "$10,000/$10,000", "PRDSEGList": ["RETL", "SERV", "FOOD", "WHLS"]}
        , {"value": "15000/10000", "label": "$15,000/$10,000", "PRDSEGList": ["RETL", "SERV", "FOOD", "WHLS"]}
        , {"value": "20000/10000", "label": "$20,000/$10,000", "PRDSEGList": ["RETL", "SERV", "FOOD", "WHLS"]}
        , {"value": "25000/10000", "label": "$25,000/$10,000", "PRDSEGList": ["RETL", "SERV", "FOOD", "WHLS", "OFFC"]}
        , {"value": "50000/10000", "label": "$50,000/$10,000", "PRDSEGList": ["RETL", "SERV", "FOOD", "WHLS", "OFFC"]}
    ];

    OhioStopGapDropdownOptions: any[] = [
        {"value": "100000/100000/500000", "label": "$100,000/$100,000/$500,000"}
        , {"value": "500000/500000/500000", "label": "$500,000/$500,000/$500,000"}
        , {"value": "1000000/1000000/1000000", "label": "$1,000,000/$1,000,000/$1,000,000"}
    ];
    
    professionalTypesData: any[] = [
        {"PRFTYP": "BRL", "PRFDSC": "Barbers", "CLASSCODES": ["131026", "131272", "131136"]},
        {"PRFTYP": "BTL", "PRFDSC": "Beauty & Hair Stylist", "CLASSCODES": ["131026", "131272", "131136"]},
        {"PRFTYP": "SPA", "PRFDSC": "Day Spas", "CLASSCODES": ["131026", "131272", "131136"]},
        {"PRFTYP": "FDL", "PRFDSC": "Funeral Directors", "CLASSCODES": ["131188"]},
        {"PRFTYP": "HAL", "PRFDSC": "Hearing Aid", "CLASSCODES": ["131336", "131348"]},
        {"PRFTYP": "NSA", "PRFDSC": "Nail Salons", "CLASSCODES": ["131026", "131272", "131136"]},
        {"PRFTYP": "OPA", "PRFDSC": "NJSOP Optometrists Liability", "CLASSCODES": ["131404", "131364", "131365", "131348"]},
        {"PRFTYP": "OPL", "PRFDSC": "Opticians", "CLASSCODES": ["131404", "131364", "131365", "131348"]},
        {"PRFTYP": "OPT", "PRFDSC": "Optometrists", "CLASSCODES": ["131404", "131364", "131365", "131348"]},
        {"PRFTYP": "PGR", "PRFDSC": "Pet Groomers", "CLASSCODES": ["131232", "131418", "131420", "131422", "131524"]},
        {"PRFTYP": "PRL", "PRFDSC": "Printers Liability", "CLASSCODES": ["131452"]},
        {"PRFTYP": "VTL", "PRFDSC": "Veterinarians", "CLASSCODES": ["131232", "131418", "131420", "131422", "131524"]}
        ];
  
  constructor(
    public func: Functions,
    public migRoles: MIGSecurityRoles,
    public masks: InputMasksClass,
    public menuClass: MenuClass,
    public bopOptionalCoverageData: BopOptionalCoveragesData,
    public formBuilder: UntypedFormBuilder,
    public confirmationService: ConfirmationService,
    )
    { 
        this.formBuilder = new UntypedFormBuilder();
        this.validators = new MIGBOPOptionalCoverageValidators();
    }

  ngOnInit(): void {
    
    this.formatter = new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        maximumFractionDigits: 0}
    );
    
    this.lessorsPredominantSegment = (this.quote.QUOTEPERSONALINFO.PRDSEG == "LSRO");
    this.hasRetailOrServiceBPP = (this.hasBPPSegment("RETL") || this.hasBPPSegment('SERV'));
    if (this.quote.POLICYTRANS.CANSTE == "31") {
        this.CYBAGGDropdownOptions = _.filter(this.CYBAGGDropdownOptions, dropdownOption => {
            return (dropdownOption.value == 100000);
        });
    }
    this.optionalCoveragesFormGroup = this.formBuilder.group({});
    this.scheduledOptionalCoverages = this.bopOptionalCoverageData.scheduledOptionalCoverageData;
    this.quoteHasRetailInstallationClass = this.quote.HasRetailInstallationClass();
    this.initFormGroup();

  }

  ngOnDestroy(): void {
    this.optionalCoveragesFormGroupSubscription.unsubscribe();
  }

  initFormGroup() {
    
    this.initBlanketAndScheduledSections();

    if (this.quoteHasRetailInstallationClass) {
        this.optionalCoveragesFormGroup.addControl("checkboxCELMT", new UntypedFormControl({ value: true, disabled: true }));
        this.optionalCoveragesFormGroup.addControl("CELMT", new UntypedFormControl({value: this.getCELMTValue(), disabled: !this.migRoles.editable}));
        this.optionalCoveragesFormGroup.controls["CELMT"].addValidators(this.validators.ValidateMinValue("CELMT", "Communication Equipment Total Limit", 1000, "cannot be less than", true));
        this.optionalCoveragesFormGroup.controls["CELMT"].addValidators(this.validators.ValidateMaxValue(10000,"CELMT", "Communication Equipment Total Limit", "cannot be greater than", true));
    }
    

    this.optionalCoveragesFormGroup.addControl("ComputerFundsTransferFraud", new UntypedFormControl({ value: true, disabled: true }));
    //ADDITIONALINSURED.CMPFRD = 10000;

    this.initContractorsInstallationToolsAndEquipmentSection();

    this.initCyberLiabilitySection();

    this.initElectronicDataLiabilitySection();

    this.initEmployeeBenefitsLiabilityLimitsSection();

    this.initEmployeeDishonestySection();

    this.initEquipmentBreakdownSection();

    this.initMiscPropertyCoverageSection();

    this.initMoneyOrdersCounterfeitPaperMoneySection();

    this.initMoneySecuritiesAndCreditCardSlipsSection();

    this.initOhioStopGapSection();

    this.initProfessionalLiabilitySection();

    this.initSubcontractorsSection();

    this.menuClass.stepActiveObject.form = this.optionalCoveragesFormGroup;

    this.initFormGroupSubscription();

  }

  initSubcontractorsSection() {
    this.optionalCoveragesFormGroup.addControl("checkboxSUBCLS", new UntypedFormControl({ value: (this.quote.QUOTEPERSONALINFO.SUBCLS != ''), disabled: !this.migRoles.editable }));
    this.optionalCoveragesFormGroup.controls["checkboxSUBCLS"].valueChanges.subscribe(data => {
        if (data) {
            this.quote.determineSubcontractorsClassCode();
            this.quote.QUOTEPERSONALINFO.SUBDSC = "SUBCONTRACTED WORK";
            this.optionalCoveragesFormGroup.controls["SubcontractorsValidity"].setValue(false, {emitEvent: false});
            this.addSubcontractorsValidation();
        }
        else {
            this.quote.QUOTEPERSONALINFO.SUBCLS = "";
            this.quote.QUOTEPERSONALINFO.SUBDSC = "";
            this.quote.QUOTEPERSONALINFO.CSTSUB = 0;
            this.quote.QUOTEPERSONALINFO.SUBIFA = 'N';

            this.optionalCoveragesFormGroup.controls["SubcontractorsValidity"].clearValidators();
            this.optionalCoveragesFormGroup.controls["SubcontractorsValidity"].updateValueAndValidity();
            this.optionalCoveragesFormGroup.updateValueAndValidity();
        }
    });
    this.optionalCoveragesFormGroup.addControl("checkboxSUBIFA", new UntypedFormControl({ value: (this.quote.QUOTEPERSONALINFO.SUBIFA == 'Y'), disabled: ((!this.migRoles.editable) || (this.quote.QUOTEPERSONALINFO.CSTSUB > 0)) }));
    this.optionalCoveragesFormGroup.controls["checkboxSUBIFA"].valueChanges.subscribe(data => {
        if (data) {
            this.quote.QUOTEPERSONALINFO.SUBIFA = 'Y';
            this.optionalCoveragesFormGroup.controls["CSTSUB"].disable({emitEvent: false});
            this.optionalCoveragesFormGroup.controls["SubcontractorsValidity"].setValue(true, {emitEvent: false});
        }
        else {
            this.quote.QUOTEPERSONALINFO.SUBIFA = 'N';
            this.optionalCoveragesFormGroup.controls["CSTSUB"].enable({emitEvent: false});
            this.optionalCoveragesFormGroup.controls["SubcontractorsValidity"].setValue(false, {emitEvent: false});
        }
    });
    this.optionalCoveragesFormGroup.addControl("CSTSUB", new UntypedFormControl({value: this.quote.QUOTEPERSONALINFO.CSTSUB, disabled: ((!this.migRoles.editable) || (this.quote.QUOTEPERSONALINFO.SUBIFA == 'Y'))}));
    this.optionalCoveragesFormGroup.controls["CSTSUB"].valueChanges.subscribe(data => {
        let newCSTSUBValue: number = this.func.justNumbers(data);

        if (newCSTSUBValue == 0) {
            this.optionalCoveragesFormGroup.controls["checkboxSUBIFA"].enable({emitEvent: false});
            this.optionalCoveragesFormGroup.controls["SubcontractorsValidity"].setValue(false, {emitEvent: false});
        }
        
        if (newCSTSUBValue > 0) {
            this.optionalCoveragesFormGroup.controls["checkboxSUBIFA"].disable({emitEvent: false});
            this.optionalCoveragesFormGroup.controls["SubcontractorsValidity"].setValue(true, {emitEvent: false});
        }

        this.quote.QUOTEPERSONALINFO.CSTSUB = newCSTSUBValue;
    });

    this.optionalCoveragesFormGroup.addControl("SubcontractorsValidity", new UntypedFormControl());

    if (this.quote.QUOTEPERSONALINFO.SUBCLS != '') {
        this.addSubcontractorsValidation();
    }

  }

  addSubcontractorsValidation() {
    this.optionalCoveragesFormGroup.controls["SubcontractorsValidity"].setValidators(this.validators.ValidateRequired("SubcontractorsSection", "Either selecting Subcontractors 'If Any' or providing a Subcontractors Total Costs value"));
    this.optionalCoveragesFormGroup.controls["SubcontractorsValidity"].updateValueAndValidity();
    this.optionalCoveragesFormGroup.updateValueAndValidity();
  }

  initProfessionalLiabilitySection() {
    
    this.hasProfessionalClassCode = true;  //TODO:  detect if quote has professional class code
    this.quoteBuildingAndBPPClassCodes = this.quote.getBuildingAndBPPClassCodeList();
    let applicableProfessionalTypesData: string[] = [];
    let totalNumberOfProfessionals: number = 0;
    
    this.professionalTypesData.forEach(professionalType => {
        if ((professionalType.PRFTYP == 'OPA') && ((this.quote.QUOTEPOLICYINFORMATION.AGENTNUMBER != '79201') || (!this.quote.AllLocationsInState('29')))) {
                //NJ Optometrists can only be displayed if agent number is 79201 and all locations are in NJ
                //if we are here, then the agent number is not 79201 and/or there is a location not in NJ.
        }
        else if (_.intersection(professionalType.CLASSCODES, this.quoteBuildingAndBPPClassCodes).length > 0)
        {
            applicableProfessionalTypesData.push(professionalType);
            let currentProfLiabilityRec:PROFLIABILITY = this.quote.setAndRetrieveProfLiabilityRecord(professionalType.PRFTYP, professionalType.PRFDSC);
            this.optionalCoveragesFormGroup.addControl(professionalType.PRFTYP, new UntypedFormControl({value: currentProfLiabilityRec.PRFUNT, disabled: !this.migRoles.editable}));
            totalNumberOfProfessionals+=currentProfLiabilityRec.PRFUNT;

            this.optionalCoveragesFormGroup.controls[professionalType.PRFTYP].valueChanges.subscribe(data => {
                let newProfessionalTypeCount: number = this.func.justNumbers(data);
                let totalProfessionalsCount: number = this.optionalCoveragesFormGroup.get("NumberOfProfessionals").value;
                totalProfessionalsCount = totalProfessionalsCount + newProfessionalTypeCount - currentProfLiabilityRec.PRFUNT;
                currentProfLiabilityRec.PRFUNT = newProfessionalTypeCount;

                this.optionalCoveragesFormGroup.get("NumberOfProfessionals").setValue(totalProfessionalsCount, {emitEvent: false});

            });
        }
        else {
            this.quote.removeProfLiabilityRecord(professionalType.PRFTYP);
        }
    });
    this.optionalCoveragesFormGroup.addControl("NumberOfProfessionals", new UntypedFormControl(totalNumberOfProfessionals));
    this.professionalTypesData = applicableProfessionalTypesData;

    if (this.professionalTypesData.length == 0) {
        this.quote.QUOTEPERSONALINFO.PRFFLG = 'N';
        this.quote.PROFLIABILITY.forEach(profLiability => {
            profLiability.RECORDSTATE = 'D';
        });
    }

    this.optionalCoveragesFormGroup.addControl("checkboxPRFFLG", new UntypedFormControl({ value: (this.quote.QUOTEPERSONALINFO.PRFFLG == 'Y'), disabled: !this.migRoles.editable }));
    this.optionalCoveragesFormGroup.controls["checkboxPRFFLG"].valueChanges.subscribe(data => {
        if (data) {
            let totalNumberOfProfessionals: number = 0;
            this.quote.QUOTEPERSONALINFO.PRFFLG = 'Y';
            this.quote.QUOTEPERSONALINFO.PRFLOC = this.quote.QUOTEPERSONALINFO.EOLMT;
            this.quote.QUOTEPERSONALINFO.PRFLAG = this.quote.QUOTEPERSONALINFO.GALMT;
            

            this.professionalTypesData.forEach(professionalType => {
                let currentProfLiabilityRec:PROFLIABILITY = this.quote.setAndRetrieveProfLiabilityRecord(professionalType.PRFTYP, professionalType.PRFDSC);
                totalNumberOfProfessionals+=currentProfLiabilityRec.PRFUNT;
                this.optionalCoveragesFormGroup.get("NumberOfProfessionals").setValue(totalNumberOfProfessionals, {emitEvent: false});
            });

            this.addNumberOfProfessionalsValidation();
        }
        else {
            this.quote.QUOTEPERSONALINFO.PRFFLG = 'N';
            this.quote.QUOTEPERSONALINFO.PRFLOC = 0;
            this.quote.QUOTEPERSONALINFO.PRFLAG = 0;
            this.quote.PROFLIABILITY.forEach(profLiability => {
                profLiability.RECORDSTATE = 'D';
            });

            this.optionalCoveragesFormGroup.controls["NumberOfProfessionals"].clearValidators();
            this.optionalCoveragesFormGroup.controls["NumberOfProfessionals"].updateValueAndValidity();
            this.optionalCoveragesFormGroup.updateValueAndValidity();
            
        }
    });

    //set initial PRFLOC and PRFLAG values
    if (this.quote.QUOTEPERSONALINFO.PRFFLG == 'Y') {
        this.quote.QUOTEPERSONALINFO.PRFLOC = this.quote.QUOTEPERSONALINFO.EOLMT;
        this.quote.QUOTEPERSONALINFO.PRFLAG = this.quote.QUOTEPERSONALINFO.GALMT;
        this.addNumberOfProfessionalsValidation();
    }
    else {
        this.quote.QUOTEPERSONALINFO.PRFLOC = 0;
        this.quote.QUOTEPERSONALINFO.PRFLAG = 0;
    }
    
  }
  addNumberOfProfessionalsValidation() {
    this.optionalCoveragesFormGroup.controls["NumberOfProfessionals"].setValidators([
        this.validators.ValidateMinValue("NumberOfProfessionals", "Total Number of Professionals", 1, "cannot be less than", false)
    ]);
    this.optionalCoveragesFormGroup.controls["NumberOfProfessionals"].updateValueAndValidity();
    this.optionalCoveragesFormGroup.updateValueAndValidity();
  }

  initOhioStopGapSection() {
    let initialOhioStopGapDropdownValue: string = "100000/100000/500000";
    var initialSTGEMPValue: number = 0;
    this.optionalCoveragesFormGroup.addControl("checkboxOhioStopGap", new UntypedFormControl({ value: true, disabled: true }));

    this.hasOhioLocation = _.some(this.quote.getTotalLocations(), (location:BOPLOCATION) => {
        return location.locationIsInState("34")
    });

    this.ohioStateTransactionRecordForQuote = _.find(this.quote.STATETRANSACTION, (stateTransactionRec:STATETRANSACTION) => {
        return (stateTransactionRec.PRMSTE == "34" && stateTransactionRec.RECORDSTATE != 'D');
    })

    if (!this.hasOhioLocation) {

        if (this.ohioStateTransactionRecordForQuote != undefined) {
            this.ohioStateTransactionRecordForQuote.RECORDSTATE = 'D';
        }

    }

    if (this.hasOhioLocation) {

        if (this.ohioStateTransactionRecordForQuote == undefined) {
            this.ohioStateTransactionRecordForQuote = new STATETRANSACTION();
            this.ohioStateTransactionRecordForQuote.TRANS = this.quote.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;
            this.ohioStateTransactionRecordForQuote.POLICY = this.quote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
            this.ohioStateTransactionRecordForQuote.EFFDTE = this.quote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
            this.ohioStateTransactionRecordForQuote.EDSDTE = this.quote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;
            this.ohioStateTransactionRecordForQuote.RCDTYP = this.quote.QUOTEPOLICYINFORMATION.RECORDTYPE;
            this.ohioStateTransactionRecordForQuote.PRMSTE = "34";
            this.ohioStateTransactionRecordForQuote.RECORDSTATE = "U";
            this.quote.STATETRANSACTION.push(this.ohioStateTransactionRecordForQuote);
        }

        this.checkOhioStopGapDefaultValueConditions();

        initialOhioStopGapDropdownValue = this.ohioStateTransactionRecordForQuote.STGEA.toString() + '/' +
            this.ohioStateTransactionRecordForQuote.STGPE.toString() + '/' +
            this.ohioStateTransactionRecordForQuote.STGPP.toString();

        initialSTGEMPValue = this.ohioStateTransactionRecordForQuote.STGEMP;
    }

    
    this.optionalCoveragesFormGroup.addControl("OhioStopGapDropdown", new UntypedFormControl({value: initialOhioStopGapDropdownValue, disabled: !this.migRoles.editable}));
    this.optionalCoveragesFormGroup.addControl("STGEMP", new UntypedFormControl({value: initialSTGEMPValue, disabled: !this.migRoles.editable}));

    this.addSTGEMPValidation();
    this.addOhioStopGapDropdownValidation();
    
  }

  checkOhioStopGapDefaultValueConditions() {
    if ((this.ohioStateTransactionRecordForQuote.STGEA == 0) 
            || (this.ohioStateTransactionRecordForQuote.STGPE == 0) 
            || (this.ohioStateTransactionRecordForQuote.STGPP == 0)
            || ((this.quote.QUOTEPERSONALINFO.EOLMT == 300000) && (this.quote.QUOTEPERSONALINFO.GALMT == 600000))) {
            // if any of these values are 0, or Business Liability Limits are 300000/600000,
            // set them all to the default values.
            this.ohioStateTransactionRecordForQuote.STGEA = 100000;
            this.ohioStateTransactionRecordForQuote.STGPE = 100000;
            this.ohioStateTransactionRecordForQuote.STGPP = 500000;
        }
  }

  addSTGEMPValidation() {
    if (!this.hasOhioLocation)
        return;

    this.optionalCoveragesFormGroup.controls["STGEMP"].setValidators([
        this.validators.ValidateMinValue("STGEMP", "Number of Employees in Ohio", 1, "cannot be less than", false), 
        this.validators.ValidateMaxValue(999, "STGEMP", "Number of Employees in Ohio", "cannot be greater than", false)
    ]);
    this.optionalCoveragesFormGroup.controls["STGEMP"].updateValueAndValidity();
    this.optionalCoveragesFormGroup.updateValueAndValidity();
  }

  addOhioStopGapDropdownValidation() {
    if ((!this.hasOhioLocation) || (!((this.quote.QUOTEPERSONALINFO.EOLMT == 300000) && (this.quote.QUOTEPERSONALINFO.GALMT == 600000)))) {
        return;
    }
    this.optionalCoveragesFormGroup.controls["OhioStopGapDropdown"].setValidators([
        this.validators.ValidateOhioStopGapDropdownValue("OhioStopGapDropdown", "Stop Gap Each Accident Limit", "100000/100000/500000")
    ]);
    this.optionalCoveragesFormGroup.controls["OhioStopGapDropdown"].updateValueAndValidity();
    this.optionalCoveragesFormGroup.updateValueAndValidity();
  }

  initMoneySecuritiesAndCreditCardSlipsSection() {
    this.MoneySecuritiesCCSlipDropdownOptions = _.filter(this.MoneySecuritiesCCSlipDropdownOptions, dropdownOption => {
        return _.includes(dropdownOption.PRDSEGList, this.quote.QUOTEPERSONALINFO.PRDSEG);
    });

    if (this.lessorsPredominantSegment) {
        this.quote.QUOTEPERSONALINFO.MSECON = 0;
        this.quote.QUOTEPERSONALINFO.MSECOF = 0;
    }

    this.optionalCoveragesFormGroup.addControl("checkboxMoneySecuritiesCreditCardSlips", new UntypedFormControl({ value: true, disabled: true }));
    let initialMoneySecuritiesCCSlipDropdownValue:string = this.initMoneySecuritiesCCSlipValues();
    this.optionalCoveragesFormGroup.addControl("MoneySecuritiesCCSlipDropdown", new UntypedFormControl({value: initialMoneySecuritiesCCSlipDropdownValue, disabled: !this.migRoles.editable}));

  }

  initMoneySecuritiesCCSlipValues() {
    let currentdropdownOptionValue:string = "";
    if ((this.quote.QUOTEPERSONALINFO.MSECON != 0) && (this.quote.QUOTEPERSONALINFO.MSECOF != 0)) {
        currentdropdownOptionValue = this.quote.QUOTEPERSONALINFO.MSECON.toString() + '/' + this.quote.QUOTEPERSONALINFO.MSECOF.toString();

        if (_.some(this.MoneySecuritiesCCSlipDropdownOptions, dropdownOption => {
            return dropdownOption.value == currentdropdownOptionValue;
        })) {
            return currentdropdownOptionValue;
        }
        
        //Current MSECON and MSECOF values don't match available dropdown option values.
        //Reset to 0.
        this.quote.QUOTEPERSONALINFO.MSECON = 0;
        this.quote.QUOTEPERSONALINFO.MSECOF = 0;
        //Go through logic below to set defaults based on current PRDSEG.
    
        
    }

    if (this.quote.QUOTEPERSONALINFO.PRDSEG == "OFFC") {
        currentdropdownOptionValue = "25000/10000";
        this.quote.QUOTEPERSONALINFO.MSECON = 25000;
        this.quote.QUOTEPERSONALINFO.MSECOF = 10000;
    }

    if (_.includes(["RETL", "SERV", "FOOD", "WHLS"], this.quote.QUOTEPERSONALINFO.PRDSEG)) {
        currentdropdownOptionValue = "10000/10000";
        this.quote.QUOTEPERSONALINFO.MSECON = 10000;
        this.quote.QUOTEPERSONALINFO.MSECOF = 10000;
    }

    return currentdropdownOptionValue;
  }

  initMoneyOrdersCounterfeitPaperMoneySection() {
    this.optionalCoveragesFormGroup.addControl("checkboxMOCPLM", new UntypedFormControl({ value: true, disabled: true }));
    if ((this.quote.QUOTEPERSONALINFO.MOCPLM == 0) && (!this.lessorsPredominantSegment))
    {
        this.quote.QUOTEPERSONALINFO.MOCPLM = 10000; //default value;
    }

    if (this.lessorsPredominantSegment) {
        this.quote.QUOTEPERSONALINFO.MOCPLM = 0; //default value when lessors is predominant segment;
    }
    this.optionalCoveragesFormGroup.addControl("MOCPLM", new UntypedFormControl({ value: this.quote.QUOTEPERSONALINFO.MOCPLM, disabled: false }));
    
    if (!this.lessorsPredominantSegment) {
        this.addMOCPLMValidation();
    }
  }

  addMOCPLMValidation() {
    this.optionalCoveragesFormGroup.controls["MOCPLM"].setValidators([
        this.validators.ValidateMinValue("MOCPLM", "Money Orders and Counterfeit Paper Money Total Limit", 10000, "cannot be less than", true), 
        this.validators.ValidateMaxValue(250000,"MOCPLM", "Money Orders and Counterfeit Paper Money Total Limit", "cannot be greater than", true)
    ]);
    this.optionalCoveragesFormGroup.controls["MOCPLM"].updateValueAndValidity();
    this.optionalCoveragesFormGroup.updateValueAndValidity();
  }

  initMiscPropertyCoverageSection() {
    this.optionalCoveragesFormGroup.addControl("checkboxMiscPropertyCoverage", new UntypedFormControl({ value: (this.quote.OPTIONALPRODUCTCVG.MSCULM != 0), disabled: !this.migRoles.editable }));
    this.optionalCoveragesFormGroup.controls["checkboxMiscPropertyCoverage"].valueChanges.subscribe(data => {
        if (data) {
            this.addMSCULMValidation();
        }
        else {
            this.quote.OPTIONALPRODUCTCVG.MSCULM = 0;
            this.optionalCoveragesFormGroup.controls["MSCULM"].clearValidators();
            this.optionalCoveragesFormGroup.controls["MSCULM"].updateValueAndValidity();
            this.optionalCoveragesFormGroup.updateValueAndValidity();
        }
    });

    this.optionalCoveragesFormGroup.addControl("MSCULM", new UntypedFormControl({ value: this.quote.OPTIONALPRODUCTCVG.MSCULM, disabled: false }));
    
    if (this.quote.OPTIONALPRODUCTCVG.MSCULM != 0) {
        this.addMSCULMValidation();
    }
  }

  addMSCULMValidation() {
    this.optionalCoveragesFormGroup.controls["MSCULM"].setValidators([
        this.validators.ValidateMinValue("MSCULM", "Unscheduled Miscellaneous Property Coverage", 1, "cannot be less than", true), 
        this.validators.ValidateMaxValue(50000,"MSCULM", "Unscheduled Miscellaneous Property Coverage", "cannot be greater than", true)
    ]);
    this.optionalCoveragesFormGroup.controls["MSCULM"].updateValueAndValidity();
    this.optionalCoveragesFormGroup.updateValueAndValidity();
  }

  initEquipmentBreakdownSection() {
    this.optionalCoveragesFormGroup.addControl("checkboxEmploymentBreakdown", new UntypedFormControl({ value: true, disabled: true }));
  }

  initEmployeeDishonestySection() {
    this.hasEmployeeDishonestyCoverage = (this.quote.QUOTEPERSONALINFO.EMPLNOE <= 50);
    let defaultEmployeeDishonestyCoverageValue:number = 25000;
    if ((this.quote.QUOTEPERSONALINFO.EMPOLM == 0) && (this.hasEmployeeDishonestyCoverage)) {
        this.quote.QUOTEPERSONALINFO.EMPOLM = defaultEmployeeDishonestyCoverageValue;
    }

    if (!this.hasEmployeeDishonestyCoverage) {
        this.quote.QUOTEPERSONALINFO.EMPOLM = 0;
        this.quote.QUOTEPERSONALINFO.ERISA = 'N';
    }
    
    this.optionalCoveragesFormGroup.addControl("checkboxEMPOLM", new UntypedFormControl({ value: this.hasEmployeeDishonestyCoverage, disabled: true }));
    this.optionalCoveragesFormGroup.addControl("EMPOLM", new UntypedFormControl({value: (this.hasEmployeeDishonestyCoverage) ? this.quote.QUOTEPERSONALINFO.EMPOLM : defaultEmployeeDishonestyCoverageValue, disabled: false }));
    this.optionalCoveragesFormGroup.addControl("checkboxERISA", new UntypedFormControl({ value: (this.quote.QUOTEPERSONALINFO.ERISA == 'Y'), disabled: !this.migRoles.editable }));

  }

  initEmployeeBenefitsLiabilityLimitsSection() {
    let ebnflgValue:boolean = false;
    if (this.quote.QUOTEPERSONALINFO.EBNFLG == 'Y')
        ebnflgValue = true;

    this.optionalCoveragesFormGroup.addControl("checkboxEBNFLG", new UntypedFormControl({ value: ebnflgValue, disabled: !this.migRoles.editable }));
    this.optionalCoveragesFormGroup.controls["checkboxEBNFLG"].valueChanges.subscribe(data => {
        if (data) {
            this.quote.QUOTEPERSONALINFO.EBNFLG = 'Y';
            this.quote.QUOTEPERSONALINFO.EBLRDT = this.quote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
            this.optionalCoveragesFormGroup.controls["EBLRDT"].setValue(this.func.DTEWinsToPrimeNG(this.quote.QUOTEPERSONALINFO.EBLRDT), {emitEvent: false});
            
            this.quote.QUOTEPERSONALINFO.setEmployeeBenefitLiabilityValues();
            //this.quote.QUOTEPERSONALINFO.EBNOLM = this.quote.QUOTEPERSONALINFO;
        }
        else {
            this.quote.QUOTEPERSONALINFO.EBNFLG = 'N';
            this.quote.QUOTEPERSONALINFO.setEmployeeBenefitLiabilityValues();
        }
    });
    this.optionalCoveragesFormGroup.addControl("EBLRDT", new UntypedFormControl({value: this.func.DTEWinsToPrimeNG(this.quote.QUOTEPERSONALINFO.EBLRDT), disabled: true}));
  }

  initElectronicDataLiabilitySection() {
    //if (this.quoteHasRetailInstallationClass) {
    let quoteELDATA:number = this.quote.QUOTEPERSONALINFO.ELDATA;
    let eldataDropdownValue:number = 25000;
    if (quoteELDATA > 0) {
        eldataDropdownValue = quoteELDATA;
    }
    this.optionalCoveragesFormGroup.addControl("checkboxELDATA", new UntypedFormControl({ value: (quoteELDATA != 0), disabled: false }));
    this.optionalCoveragesFormGroup.addControl("ELDATA", new UntypedFormControl({value: eldataDropdownValue, disabled: false }));

  }

  initCyberLiabilitySection() {
    let initialCYBAGGValue = 100000;
    if ((this.quote.POLICYTRANS.CANSTE != '44') && (this.quote.QUOTEPERSONALINFO.CYBAGG > 0)) {
        this.quote.QUOTEPERSONALINFO.CYBRDT = this.quote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
        this.quote.QUOTEPERSONALINFO.CYBEFF = this.quote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;

        initialCYBAGGValue = this.quote.QUOTEPERSONALINFO.CYBAGG;
    }

    if (this.quote.POLICYTRANS.CANSTE == '44') {
        this.quote.removeCyberLiabilityCoverage();
    }
    
    this.optionalCoveragesFormGroup.addControl("checkboxCyberLiability", new UntypedFormControl(this.quote.QUOTEPERSONALINFO.CYBRDT != 0));
    this.optionalCoveragesFormGroup.addControl("CYBAGG", new UntypedFormControl({ value: initialCYBAGGValue, disabled: false }));
    this.optionalCoveragesFormGroup.addControl("CYBSAL", new UntypedFormControl({ value: this.quote.QUOTEPERSONALINFO.CYBSAL, disabled: false }));
    this.optionalCoveragesFormGroup.addControl("CYBRDT", new UntypedFormControl({ value: this.func.DTEWinsToPrimeNG(this.quote.QUOTEPERSONALINFO.CYBRDT), disabled: true }));
    
    this.optionalCoveragesFormGroup.controls["checkboxCyberLiability"].valueChanges.subscribe(data => {
        if (data) {
            this.quote.QUOTEPERSONALINFO.CYBRDT = this.quote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
            this.quote.QUOTEPERSONALINFO.CYBEFF = this.quote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
            this.quote.QUOTEPERSONALINFO.CYBAGG = 100000;
            this.quote.QUOTEPERSONALINFO.CYBSAL = 0;
            this.optionalCoveragesFormGroup.controls['CYBAGG'].setValue(this.quote.QUOTEPERSONALINFO.CYBAGG, {emitEvent: false});
            this.optionalCoveragesFormGroup.controls['CYBSAL'].setValue(this.quote.QUOTEPERSONALINFO.CYBSAL, {emitEvent: false});
            this.optionalCoveragesFormGroup.controls['CYBAGG'].updateValueAndValidity();
            this.optionalCoveragesFormGroup.controls['CYBSAL'].updateValueAndValidity();
            this.optionalCoveragesFormGroup.updateValueAndValidity();
            this.addCYBSALValidation();
        }
        else {
            this.quote.removeCyberLiabilityCoverage();
            this.optionalCoveragesFormGroup.controls["CYBSAL"].clearValidators();
            this.optionalCoveragesFormGroup.controls["CYBSAL"].updateValueAndValidity();
            this.optionalCoveragesFormGroup.updateValueAndValidity();
        }
    });

    this.optionalCoveragesFormGroup.controls["CYBAGG"].valueChanges.subscribe(data => {
        this.quote.QUOTEPERSONALINFO.CYBAGG = data;
        this.addCYBSALValidation();
    });

    if (this.quote.QUOTEPERSONALINFO.CYBRDT != 0)
        this.addCYBSALValidation();
  }



  addCYBSALValidation() {
    this.optionalCoveragesFormGroup.controls["CYBSAL"].clearValidators();
    this.optionalCoveragesFormGroup.controls["CYBSAL"].updateValueAndValidity();
    this.optionalCoveragesFormGroup.updateValueAndValidity();
    var maxValueCYBSAL = 999999999;

    if (this.quote.QUOTEPERSONALINFO.CYBAGG > 100000) {
        maxValueCYBSAL = 10000000;
    }

    this.optionalCoveragesFormGroup.controls["CYBSAL"].setValidators([
        this.validators.ValidateMinValue("CYBSAL", "Cyber Liability Annual Revenues", 1, "cannot be less than", true), 
        this.validators.ValidateMaxValue(maxValueCYBSAL,"CYBSAL", "Cyber Liability Annual Revenues", "cannot be greater than", true)
    ]);
    this.optionalCoveragesFormGroup.controls["CYBSAL"].updateValueAndValidity();
    this.optionalCoveragesFormGroup.updateValueAndValidity();
  }

  initContractorsInstallationToolsAndEquipmentSection() {
    //Contractor's Installation, Tools and Equipment
        this.optionalCoveragesFormGroup.addControl("checkboxCIDED", new UntypedFormControl({ value: true, disabled: true }));
        this.optionalCoveragesFormGroup.addControl("checkboxContractorsInstallation", new UntypedFormControl({ value: true, disabled: true }));

        //TODO:  disable dropdown and force Included in quote does not have retail installation class
        this.optionalCoveragesFormGroup.addControl("dropdownContractorsInstallation", new UntypedFormControl({ value: this.getContractorsInstallationDropdownValue(), disabled: !this.quoteHasRetailInstallationClass }));
        this.optionalCoveragesFormGroup.addControl("checkboxContractorsUnscheduled", new UntypedFormControl({ value: true, disabled: true }));

        //Bug 378:  Default limit is $3000
        if ((this.quote.OPTIONALPRODUCTCVG.CTEULM < 3000) && (this.hasRetailOrServiceBPP)) {
            this.quote.OPTIONALPRODUCTCVG.CTEULM = 3000;
        }

        if (!this.hasRetailOrServiceBPP) {
            this.quote.OPTIONALPRODUCTCVG.CTEULM = 0;
        }
        this.optionalCoveragesFormGroup.addControl("CTEULM", new UntypedFormControl({value: this.quote.OPTIONALPRODUCTCVG.CTEULM, disabled: !this.migRoles.editable}));
        
        if (this.hasRetailOrServiceBPP) {
            this.optionalCoveragesFormGroup.controls["CTEULM"].addValidators(this.validators.ValidateMinValue("CTEULM", "Contractor's Unscheduled Tools and Equipment Total Limit Max", 3000, "cannot be less than", true));
            this.optionalCoveragesFormGroup.controls["CTEULM"].addValidators(this.validators.ValidateMaxValue(50000,"CTEULM", "Contractor's Unscheduled Tools and Equipment Total Limit Max", "cannot be greater than", true));
            this.quote.OPTIONALPRODUCTCVG.CIDED = 250;
        }
        else {
            this.quote.OPTIONALPRODUCTCVG.CIDED = 0;
        }
    
        this.initContractorsScheduledToolsAndEquipmentSection();
        this.initNonOwnedToolsAndEquipmentSection();
        this.initEmployeeToolsSection();
  }


  initContractorsScheduledToolsAndEquipmentSection() {
    this.optionalCoveragesFormGroup.addControl("checkboxCTELIM", new UntypedFormControl({ value: this.quote.OPTIONALPRODUCTCVG.CTESDED == 250, disabled: !this.migRoles.editable }));
        this.optionalCoveragesFormGroup.addControl("CTELIM", new UntypedFormControl({value: this.quote.OPTIONALPRODUCTCVG.CTELIM, disabled: !this.migRoles.editable}));

        this.optionalCoveragesFormGroup.controls["checkboxCTELIM"].valueChanges.subscribe(data => {
            if (data) {
                this.quote.OPTIONALPRODUCTCVG.CTESDED = 250;
                this.addCTELIMValidation();
            }
            else {
                this.quote.OPTIONALPRODUCTCVG.CTESDED = 0;
                this.quote.OPTIONALPRODUCTCVG.CTELIM = 0;
                this.optionalCoveragesFormGroup.controls["CTELIM"].clearValidators();
                this.optionalCoveragesFormGroup.controls["CTELIM"].updateValueAndValidity();
                this.optionalCoveragesFormGroup.updateValueAndValidity();
            }
        });

        if (this.quote.OPTIONALPRODUCTCVG.CTESDED == 250) {
            this.addCTELIMValidation();
        }
  }
  addCTELIMValidation() {
    this.optionalCoveragesFormGroup.controls["CTELIM"].setValidators([
        this.validators.ValidateMinValue("CTELIM", "Contractor's Scheduled Tools and Equipment", 1, "cannot be less than", true), 
        this.validators.ValidateMaxValue(150000,"CTELIM", "Contractor's Scheduled Tools and Equipment", "cannot be greater than", true)
    ]);
    this.optionalCoveragesFormGroup.controls["CTELIM"].updateValueAndValidity();
    this.optionalCoveragesFormGroup.updateValueAndValidity();
  }

  initNonOwnedToolsAndEquipmentSection() {
    this.optionalCoveragesFormGroup.addControl("checkboxNONOWL", new UntypedFormControl({ value: this.quote.OPTIONALPRODUCTCVG.NONOWD == 250, disabled: !this.migRoles.editable }));
    this.optionalCoveragesFormGroup.addControl("NONOWL", new UntypedFormControl({value: this.quote.OPTIONALPRODUCTCVG.NONOWL, disabled: !this.migRoles.editable}));

    this.optionalCoveragesFormGroup.controls["checkboxNONOWL"].valueChanges.subscribe(data => {
        if (data) {
            this.quote.OPTIONALPRODUCTCVG.NONOWD = 250;
            this.addNONOWLValidation();
        }
        else {
            this.quote.OPTIONALPRODUCTCVG.NONOWD = 0;
            this.quote.OPTIONALPRODUCTCVG.NONOWL = 0;
            this.optionalCoveragesFormGroup.controls["NONOWL"].clearValidators();
            this.optionalCoveragesFormGroup.controls["NONOWL"].updateValueAndValidity();
            this.optionalCoveragesFormGroup.updateValueAndValidity();
        }
    });

    if (this.quote.OPTIONALPRODUCTCVG.NONOWD == 250) {
        this.addNONOWLValidation();
    }
  }

  addNONOWLValidation() {
    this.optionalCoveragesFormGroup.controls["NONOWL"].setValidators([
        this.validators.ValidateMinValue("NONOWL", "Non-Owned Tools and Equipment", 1, "cannot be less than", true), 
        this.validators.ValidateMaxValue(10000,"NONOWL", "Non-Owned Tools and Equipment", "cannot be greater than", true)
    ]);
    this.optionalCoveragesFormGroup.controls["NONOWL"].updateValueAndValidity();
    this.optionalCoveragesFormGroup.updateValueAndValidity();
  }

  initEmployeeToolsSection() {
    this.optionalCoveragesFormGroup.addControl("checkboxEMPTOL", new UntypedFormControl({ value: this.quote.OPTIONALPRODUCTCVG.EMPTOD == 250, disabled: !this.migRoles.editable }));
    this.optionalCoveragesFormGroup.addControl("EMPTOL", new UntypedFormControl({value: this.quote.OPTIONALPRODUCTCVG.EMPTOL, disabled: !this.migRoles.editable}));

    this.optionalCoveragesFormGroup.controls["checkboxEMPTOL"].valueChanges.subscribe(data => {
        if (data) {
            this.quote.OPTIONALPRODUCTCVG.EMPTOD = 250;
            this.addEMPTOLValidation();
        }
        else {
            this.quote.OPTIONALPRODUCTCVG.EMPTOD = 0;
            this.quote.OPTIONALPRODUCTCVG.EMPTOL = 0;
            this.optionalCoveragesFormGroup.controls["EMPTOL"].clearValidators();
            this.optionalCoveragesFormGroup.controls["EMPTOL"].updateValueAndValidity();
            this.optionalCoveragesFormGroup.updateValueAndValidity();
        }
    });

    if (this.quote.OPTIONALPRODUCTCVG.EMPTOD == 250) {
        this.addEMPTOLValidation();
    }
  }

  addEMPTOLValidation() {
    this.optionalCoveragesFormGroup.controls["EMPTOL"].setValidators([
        this.validators.ValidateMinValue("EMPTOL", "Employee Tools", 1, "cannot be less than", true), 
        this.validators.ValidateMaxValue(10000,"EMPTOL", "Employee Tools", "cannot be greater than", true)
    ]);
    this.optionalCoveragesFormGroup.controls["EMPTOL"].updateValueAndValidity();
    this.optionalCoveragesFormGroup.updateValueAndValidity();
  }

  initBlanketAndScheduledSections()
  {
    this.optionalCoveragesFormGroup.addControl("additionalInsureds", new UntypedFormControl({ value: true, disabled: true }));
    this.optionalCoveragesFormGroup.addControl("MU8277", new UntypedFormControl({ value: true, disabled: true }));
    this.optionalCoveragesFormGroup.addControl("MU8530", new UntypedFormControl(this.quote.QUOTEPERSONALINFO.ADINCO == "Y"));

    this.optionalCoveragesFormGroup.get("MU8530").valueChanges.subscribe(data => {
        this.quote.QUOTEPERSONALINFO.ADINCO = (data) ? 'Y' : 'N';
    });

    this.scheduledOptionalCoverages.forEach(coverageEntry => {
        var currentAdditionalInsuredCount = this.quote.additionalInsuredCount(coverageEntry.addTyp);
        this.optionalCoveragesFormGroup.addControl(coverageEntry.checkboxName, new UntypedFormControl(currentAdditionalInsuredCount > 0));
        this.optionalCoveragesFormGroup.addControl(this.getOptionalCoverageInputControlName(coverageEntry.checkboxName) , new UntypedFormControl(currentAdditionalInsuredCount));

        if (currentAdditionalInsuredCount > 0) {
            //add validation on the appropriate input box.
            this.optionalCoveragesFormGroup.controls[this.getOptionalCoverageInputControlName(coverageEntry.checkboxName)].setValidators
            (
                this.validators.ValidateRequired(coverageEntry.checkboxName, coverageEntry.coverageName, true)
            );
        }

        this.optionalCoveragesFormGroup.updateValueAndValidity();

    });
  }

  initFormGroupSubscription()
  {
    this.optionalCoveragesFormGroupSubscription = this.optionalCoveragesFormGroup.valueChanges.pipe(debounceTime(500))
    .subscribe(data => {

        this.scheduledOptionalCoverages.forEach(coverageEntry => {
            var additionalInsuredCountFromData = data[this.getOptionalCoverageInputControlName(coverageEntry.checkboxName)];
            
            if (additionalInsuredCountFromData == "") {
                additionalInsuredCountFromData = 0;
            }

            if (this.quote.additionalInsuredCount(coverageEntry.addTyp) != additionalInsuredCountFromData) {
                this.quote.updateScheduledAI(coverageEntry.addTyp, additionalInsuredCountFromData);
            }
        });

        if (this.quote.OPTIONALPRODUCTCVG.CEDED == 100) {
            var numericCELMTValue = this.func.justNumbers(data.CELMT);
            if ((data.CELMT == null) || (numericCELMTValue < 1000 ) || (numericCELMTValue > 10000)) {
                this.quote.OPTIONALPRODUCTCVG.CELMT = 1000;
            }
            else { 
                this.quote.OPTIONALPRODUCTCVG.CELMT = numericCELMTValue;
            }
            
        }

        //if (this.quote.HasRetailOrServiceBPPSEG()) {
        if (data.dropdownContractorsInstallation == "INCLUDED") {
            this.quote.OPTIONALPRODUCTCVG.CILIP = 10000;
            this.quote.OPTIONALPRODUCTCVG.CILWT = 5000;
            this.quote.OPTIONALPRODUCTCVG.CILWL = 5000;
            this.quote.OPTIONALPRODUCTCVG.CILIO = 30000;
        }

        if (data.dropdownContractorsInstallation == "OPTIONAL") {
            this.quote.OPTIONALPRODUCTCVG.CILIP = 20000;
            this.quote.OPTIONALPRODUCTCVG.CILWT = 7500;
            this.quote.OPTIONALPRODUCTCVG.CILWL = 7500;
            this.quote.OPTIONALPRODUCTCVG.CILIO = 60000;
        }

        this.quote.OPTIONALPRODUCTCVG.CTEULM = this.func.justNumbers(data.CTEULM);
        this.quote.OPTIONALPRODUCTCVG.CTEUDD = 250;
        
        if (data.checkboxCTELIM)
            this.quote.OPTIONALPRODUCTCVG.CTELIM = this.func.justNumbers(data.CTELIM);
        else 
            this.quote.OPTIONALPRODUCTCVG.CTELIM = 0;

        if (data.checkboxNONOWL)
            this.quote.OPTIONALPRODUCTCVG.NONOWL = this.func.justNumbers(data.NONOWL);
        else 
            this.quote.OPTIONALPRODUCTCVG.NONOWL = 0;

        if (data.checkboxEMPTOL)
            this.quote.OPTIONALPRODUCTCVG.EMPTOL = this.func.justNumbers(data.EMPTOL);
        else 
            this.quote.OPTIONALPRODUCTCVG.EMPTOL = 0;
        //}

        if (data.checkboxELDATA)
            this.quote.QUOTEPERSONALINFO.ELDATA = data.ELDATA;
        else
            this.quote.QUOTEPERSONALINFO.ELDATA = 0;

        if ((this.quote.POLICYTRANS.CANSTE != '44') && (data.checkboxCyberLiability)) {
            this.quote.QUOTEPERSONALINFO.CYBAGG = data.CYBAGG;
            this.quote.QUOTEPERSONALINFO.CYBSAL = (this.optionalCoveragesFormGroup.controls['CYBSAL'].valid) ? this.func.justNumbers(data.CYBSAL) : 0;

            if ((!this.optionalCoveragesFormGroup.controls['CYBSAL'].valid) && (this.func.justNumbers(data.CYBSAL) > 0)) {
                //If Total Limit is greater than $100,000 and annual revenues is greater than $10,000,000,
                // then advise that it is not eligible.  Display ""Annual Revenue exceed Cyber Liability eligibility.
                
                this.confirmationService.confirm({
                    message: 'Annual Revenue exceeds Cyber Liability eligibility.',
                    acceptLabel: 'OK',
                    rejectVisible: false,
                    accept: () => {
                        
                    }
                });
            }
        }
        else {
            this.quote.removeCyberLiabilityCoverage();
        }

        if (this.hasEmployeeDishonestyCoverage) {
            this.quote.QUOTEPERSONALINFO.EMPOLM = data.EMPOLM;
            this.quote.QUOTEPERSONALINFO.ERISA = (data.checkboxERISA) ? 'Y' : 'N';
        }
        else {
            this.quote.QUOTEPERSONALINFO.EMPOLM = 0;
            this.quote.QUOTEPERSONALINFO.ERISA = 'N';
        }

        if (data.checkboxMiscPropertyCoverage) {
            this.quote.OPTIONALPRODUCTCVG.MSCULM = this.func.justNumbers(data.MSCULM);
        }
        else {
            this.quote.OPTIONALPRODUCTCVG.MSCULM = 0;
        }

        if (!this.lessorsPredominantSegment) {
            this.quote.QUOTEPERSONALINFO.MOCPLM = this.func.justNumbers(data.MOCPLM);
            this.quote.QUOTEPERSONALINFO.MSECON = this.func.justNumbers(data.MoneySecuritiesCCSlipDropdown.toString().split("/")[0]);
            this.quote.QUOTEPERSONALINFO.MSECOF = this.func.justNumbers(data.MoneySecuritiesCCSlipDropdown.toString().split("/")[1]);
        }
        else {
            this.quote.QUOTEPERSONALINFO.MOCPLM = 0;
            this.quote.QUOTEPERSONALINFO.MSECON = 0;
            this.quote.QUOTEPERSONALINFO.MSECOF = 0;
        }

        if (this.hasOhioLocation) {
            this.ohioStateTransactionRecordForQuote.STGEA = this.func.justNumbers(data.OhioStopGapDropdown.toString().split("/")[0]);
            this.ohioStateTransactionRecordForQuote.STGPE = this.func.justNumbers(data.OhioStopGapDropdown.toString().split("/")[1]);
            this.ohioStateTransactionRecordForQuote.STGPP = this.func.justNumbers(data.OhioStopGapDropdown.toString().split("/")[2]);

            this.ohioStateTransactionRecordForQuote.STGEMP = this.func.justNumbers(data.STGEMP);

            this.checkOhioStopGapDefaultValueConditions();
        }
        
        this.menuClass.CalculateErrors(this.menuClass.stepActiveObject);

    });
  }

  isChecked(checkboxName:string): boolean {
    return this.optionalCoveragesFormGroup.get(checkboxName).value;
  }

  checkboxClicked(event, checkboxName:string, addTyp:string, coverageName:string): void {
    let addingOptionalCoverage:boolean = this.optionalCoveragesFormGroup.controls[checkboxName].value;

    if (addingOptionalCoverage) {
        //add validation on the appropriate input box.
        this.optionalCoveragesFormGroup.controls[this.getOptionalCoverageInputControlName(checkboxName)].setValidators
        (
            this.validators.ValidateRequired(checkboxName, coverageName, true)
        );
        this.optionalCoveragesFormGroup.controls[this.getOptionalCoverageInputControlName(checkboxName)].updateValueAndValidity();
        this.optionalCoveragesFormGroup.updateValueAndValidity();
    }

    if (!addingOptionalCoverage) {
        //remove validation on the appropriate input box.
        this.optionalCoveragesFormGroup.controls[this.getOptionalCoverageInputControlName(checkboxName)].clearValidators();
        this.optionalCoveragesFormGroup.controls[this.getOptionalCoverageInputControlName(checkboxName)].setValue(0, {emitEvent: false});
        this.optionalCoveragesFormGroup.controls[this.getOptionalCoverageInputControlName(checkboxName)].updateValueAndValidity();
        this.optionalCoveragesFormGroup.updateValueAndValidity();
        //remove appropriate additional insureds from quote.
        this.quote.updateScheduledAI(addTyp, 0);
    }

    this.menuClass.CalculateErrors(this.menuClass.stepActiveObject);

  }

  getOptionalCoverageInputControlName(optionalCoverageCode):string {
    return optionalCoverageCode + "COUNT"
  }

  getCELMTValue() {
    if ((this.quote.HasRetailInstallationClass()) && (this.quote.OPTIONALPRODUCTCVG.CELMT != 0)) {
        return this.quote.OPTIONALPRODUCTCVG.CELMT;
    }

    return 1000; //Default value.
  }

  getContractorsInstallationDropdownValue() {
    if ((this.quote.OPTIONALPRODUCTCVG.CILIP == 10000)
    && (this.quote.OPTIONALPRODUCTCVG.CILWT == 5000)
    && (this.quote.OPTIONALPRODUCTCVG.CILWL == 5000)
    && (this.quote.OPTIONALPRODUCTCVG.CILIO == 30000)) {
        return "INCLUDED";
    }

    if ((this.quote.OPTIONALPRODUCTCVG.CILIP == 20000)
    && (this.quote.OPTIONALPRODUCTCVG.CILWT == 7500)
    && (this.quote.OPTIONALPRODUCTCVG.CILWL == 7500)
    && (this.quote.OPTIONALPRODUCTCVG.CILIO == 60000)) {
        return "OPTIONAL";
    }
    

    return "INCLUDED";
  }

  hasBPPSegment(segment: string) : boolean { // pass in a particular segment (ex: "RETL"), will return true if a building on the quote has that segment.
    let segmentFlag = false;
    
    this.quote.getTotalLocations().forEach((location: BOPLOCATION) => {
        location.getTotalBuildings().forEach(building => {
            if(building.BPPSEG == segment){
            segmentFlag = true;
            }
        });
    });
    
    return segmentFlag;
  }
}
