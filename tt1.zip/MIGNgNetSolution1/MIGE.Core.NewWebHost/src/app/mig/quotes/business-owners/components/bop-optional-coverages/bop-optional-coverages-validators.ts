import { UntypedFormControl } from '@angular/forms';
import { Validation } from '@classes/Common/ValidatorClass/Validation';
import { AppErrors } from '@root/shared_components/errors/app-errors';

export class MIGBOPOptionalCoverageValidators extends Validation {
	constructor() {
        super();
	}

    ValidateOhioStopGapDropdownValue = (fieldId: string, fieldName: string, specificValue: string) => {
		return (control: UntypedFormControl): AppErrors | null  => {
            if(control.value !== specificValue)
                return { severity: "error", summary: fieldId, detail: fieldName + " should not be greater than the Business Liability Occurrence Limit", sticky: true, closable: false }
            
            return null; 
        }    
    }
}
