import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BopLocationSummaryComponent } from './bop-location-summary.component';
import { MIGSystemService } from '@root/services/mig.service';
import { MenuClass } from '@root/system/menu/menu';
import { IQuote } from '@interfaces/IQuote';
import { FormsModule, ReactiveFormsModule, FormGroup, FormBuilder } from '@angular/forms';
import { MIGOverlayPanelModule } from '@overridden/primeng-overlaypanel/overlay.module';
import { AddressInformationModule } from '@shared/address_info/address.module';
import { BusinessClassModule } from '@shared/business-class/business-class.module';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { PropertyCoverageModule } from '@CTRcomponents/property-coverage/property-coverage.module';
import { ReportItemModule } from '@shared/report_item/report_item.module';
import { RiskAppetiteGuideModule } from '@shared/risk-appetite-guide/risk-appetite-guide.module';
import { MIGMessageModule } from '@overridden/primeng-message/message.module';
import { MIGInputSwitchModule } from '@overridden/primeng-inputswitch/switch.module';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { FieldsetModule } from 'primeng/fieldset';
import { PanelModule } from 'primeng/panel';
import { TooltipModule } from 'primeng/tooltip';
import { ErrorModule } from '@shared/errors/errors.module';
import { PipesModule } from '@pipes/pipes.module';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { DialogModule } from 'primeng/dialog';
import { AccordionModule } from 'primeng/accordion';
import { TableModule } from 'primeng/table';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { BOPQuote } from '@classViewModels/BOP/BOPQuote';
import * as BOPClasses from '../../classes/BOPClasses';
import { ADDRESS } from '@root/shared_components/address_info/address.class';
import { BopBuildingModule } from '../bop-building/bop-building.module';
import { BOPLOCATION } from '../../classes/BOPLOCATION';
import { BOPBUILDING } from '../../classes/BOPBUILDING';


@NgModule({
  declarations: [
    BopLocationSummaryComponent
  ],
  imports: [
    CommonModule,
    AccordionModule,
    PanelModule,
		FieldsetModule,
		MIGButtonModule,
    TableModule,
		FormsModule,
		ConfirmDialogModule,
		ErrorModule,
		PipesModule,
		MIGOverlayPanelModule,
		TooltipModule,
		MIGDropDownModule,
    ReportItemModule, 
    //GrowlModule,
		RiskAppetiteGuideModule,
		PropertyCoverageModule,
		BusinessClassModule,
		AddressInformationModule,
		ReactiveFormsModule,
    MIGInputtextModule,
		MIGInputSwitchModule,
    MIGMessageModule,
    DialogModule,
    BopBuildingModule
  ],
	exports: [BopLocationSummaryComponent]
})
export class BopLocationSummaryModule { 
  constructor(
		public menuClass: MenuClass,
		// private formBuilder: FormBuilder,
		public migsystemservice: MIGSystemService
	) {	

		menuClass.addMenuItem({
			name: 'LocationSummary',
			label: 'Locations',
			color: "ui-steps-number-default",
			navSkip: true,
			active: false,
			hasError: false,
			errors: [],
			buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }, { button: "GetQuoteNow" }],
			icon: 'fa fa-globe-americas',
			block: [],
			visible: true,
			quote: "premium"
		});

		let loading = {
			name: 'LocationSummary',
			label: "Loading Data",
			sublabel: 'Please wait...',
			color: "ui-steps-number-danger",
			navSkip: true,
			active: false,
			hasError: false,
			errors: [],
			buttons: [],
			forms: [],
			icon: 'fa fa-map-pin',
			block: [],
			visible: true,
			locationId: parseInt("001"),
			level: 2
		}
		menuClass.addMenuItemAt(loading, "LocationSummary");

    this.migsystemservice.subscribeShareQuote().subscribe((quoteInfo: IQuote) => {
			this.respondToQuoteChanges(quoteInfo);
		})
    
  }

  respondToQuoteChanges(quoteInfo: IQuote)
  {
      var currentStep = this.menuClass.stepActiveObject;
      var currentStepIndex = this.menuClass.stepActive;
      var menuStepsToAdd:any[] = [];

      this.menuClass.ClearMenuItemAt("LocationSummary");
      if (quoteInfo instanceof BOPQuote) {

        let existingLocationsCount: number = quoteInfo.getTotalLocations().length;
        let existingLocations: BOPLOCATION[] = quoteInfo.getTotalLocations();
        if (existingLocationsCount == 0) {
          
          let locationMenuStep = {
            name: 'LocationSummary',
            label: 'New Location', 
            sublabel: '<small> 1 Building </small>',
            color: "ui-steps-number-default",
            navSkip: false,
            active: false,
            hasError: false,
            errors: [],
            buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }, { button: "GetQuoteNow" }],
            forms: [], //[this.stateFormGroup],
            icon: 'fa fa-map-pin',
            block: [],//[{ text: "Loading Data", success: false, icon: 'fa-spinner' }],
            visible: true,
            locationDataObject: new BOPLOCATION(),
            locationId: parseInt("001"),
            level: 2,
            fromWins: true,
            quote: "premium"
          };
          menuStepsToAdd.push(locationMenuStep);
        }

        let menuLabel:string = "New Location";
        let locationIndex = 0;
        
        existingLocations.forEach((location: BOPLOCATION) => {
          
          let addr = new ADDRESS(location.ADDRESS);
          let locnum = location.LOCNUM;

          if (quoteInfo.QUOTEPOLICYINFORMATION.TRANSACTIONTYPE != "PI") {
            menuLabel = addr.STREETNUMBER + " " + addr.STREETNAME;
          } 
          let locationMenuStep = {
            name: 'LocationSummary',
            label: menuLabel != "" ? menuLabel : 'New Location',
            sublabel: '<small>' + location.getTotalBuildings().length + ' Building' + (location.getTotalBuildings().length == 1 ? '' : 's') + '</small>',
            color: "ui-steps-number-default",
            navSkip: false,
            active: false,
            hasError: false,
            errors: [],
            buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }, { button: "GetQuoteNow" }],
            forms: [], //[this.stateFormGroup],
            icon: 'fa fa-map-pin',
            block: [],//[{ text: "Loading Data", success: false, icon: 'fa-spinner' }],
            visible: true,
            locationDataObject: location,
            level: 2,
            locationId: locnum,
            fromWins: true,
            id: locationIndex,
            quote: "premium"
          };
          menuStepsToAdd.push(locationMenuStep);
          locationIndex +=1;
        }); // end foreach
      } // end instanceOf BOPQuote
      
      menuStepsToAdd.forEach(menuStepToAdd => {
        this.menuClass.addMenuItemAt(menuStepToAdd, "LocationSummary");
      });

      if (currentStep.name == "LocationSummary") { // 2/4/22: If we are on the location screen when we save, we want to go to the menu step of the state we were currently on -JTL
          this.menuClass.gotoStep(currentStepIndex);
      }
      this.menuClass.UpdateMenu();
      // this.menuClass.ShowHideMenuItemAt(propertyCoverageFound, "AdditionalCoveragesProperty");
  }



}
