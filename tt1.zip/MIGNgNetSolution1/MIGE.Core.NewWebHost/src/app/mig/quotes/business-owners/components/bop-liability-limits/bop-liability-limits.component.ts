/* ****************************************************************************************************
* PROGRAM DESCRIPTION  - BOP Liability Limits Component
* NOTES: 
* - This component is specific to BOP and is the menu step that proceeds the location step(s). 
* 
* 7/18/22: Quote now saves on this screen (Bug 340) -JTL
* 8/5/22: Hired Non Owned Auto Checkbox now properly disables if Any Delivery or Commercial Policy is answered "Yes" (Bug 372) -JTL
* 8/5/22: Fixed Retro date logic so the user can select a future date, as long as its before the quotes effective date (Bug 371) - JTL
* 8/5/22: Changed Third Party Coverage Endorsement from checkbox to Input switch (Bug 373) -JTL
****************************************************************************************************/
import { ChangeDetectorRef, Component, Input, OnDestroy, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { BOPQuote } from '@classViewModels/BOP/BOPQuote';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { InputMasksClass } from '@helpers/masks';
import { Subscription } from 'rxjs';
import { distinctUntilChanged } from 'rxjs/operators';
import { BOPQUOTEPERSONALINFO } from '../../classes/BOPQUOTEPERSONALINFO';
import { MIGLiabilityResources } from '@CTRcomponents/additional_coverages/liability/extension/extension.resources';
import { Functions } from '@helpers/functions';
import { LiabilityLimitsBR } from '@CTRcomponents/liability_limits/liability_limits.business-rules';
import { MenuClass } from '@root/system/menu/menu';
import { MIGSystemService } from '@root/services/mig.service';
import { BOPLOCATION } from '../../classes/BOPLOCATION';
import { BOPBUILDING } from '../../classes/BOPBUILDING';
import * as _ from 'lodash';

@Component({
  selector: 'mig-bop-liability-limits',
  templateUrl: './bop-liability-limits.component.html',
  styleUrls: ['./bop-liability-limits.component.css']
})
export class BopLiabilityLimitsComponent implements OnInit, OnDestroy{
  disableCheckbox: boolean = true;
  liabilityLimitsFormGroup: UntypedFormGroup;
  liabilityLimitsObject: BOPQUOTEPERSONALINFO;
  FormGroupSubscription: Subscription;
  migLiabilityResources = new MIGLiabilityResources();
  HiredNonOwnedLimits: string = "";
  migValidator: LiabilityLimitsBR;
  maxDte: Date;
  nextClickSubscription: Subscription;

  formatter: Intl.NumberFormat;
  @Input() quote: BOPQuote;
  constructor(public migRoles: MIGSecurityRoles,
              public masks: InputMasksClass,
              public dropDowns: ContractorsDropDowns,
              public fb: UntypedFormBuilder,
              public func: Functions,
              public menuClass: MenuClass,
              public cd: ChangeDetectorRef,
              public migsystemservice: MIGSystemService) { 
                this.fb = new UntypedFormBuilder();
                this.migValidator = new LiabilityLimitsBR(this.func);
              }

  ngOnInit(): void {
    this.liabilityLimitsObject = this.quote.QUOTEPERSONALINFO;
    this.formatter = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0}
    );

    this.maxDte = this.func.DTEWinsToPrimeNG(this.quote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE);
    if(this.quote instanceof BOPQuote){
      this.liabilityLimitsFormGroup = this.fb.group({
        BLLOccurrenceAggregate: [this.liabilityLimitsObject.EOLMT == 0 ? "1000000/2000000" : this.liabilityLimitsObject.EOLMT + "/" + this.liabilityLimitsObject.GALMT],
        FireLegalLimit: [this.liabilityLimitsObject.FRLGLB == 0 ? "$500,000" : this.liabilityLimitsObject.FRLGLB],
        MedicalLimit: [this.liabilityLimitsObject.MEDLMT == 0 ? this.hasSegment("OFFC") ? 15000 : 5000 : this.liabilityLimitsObject.MEDLMT], // if MEDLMT is 0, that means they are accessing screen for the first time. If any of the buildings have an Office Segment, default to 15,000. If none, default to 5,000. If we are getting a persisted value, set form control to that value. 
        HiredNonAutoCB: [{value: this.liabilityLimitsObject.EMPHNO == "Y" || this.liabilityLimitsObject.CMLPOL == "Y" || this.quote.getTotalLocations()[0].getTotalBuildings()[0].BOPSEGMENTINFO.ANYDLVY == "Y", disabled: this.quote.getTotalLocations()[0].getTotalBuildings()[0].BOPSEGMENTINFO.ANYDLVY =="Y" || this.liabilityLimitsObject.CMLPOL == "Y"}], // disable the checkbox if Any delivery or Commercial policy is answered "Yes" (Bug 372)
        HiredNonOwnedOccurrence: [this.liabilityLimitsObject.ENHOCC],
        HiredNonOwnedAggregate: [this.liabilityLimitsObject.ENHAGR],
        CommercialAutoPolicy: [this.liabilityLimitsObject.CMLPOL == "Y" ? "Y" : this.liabilityLimitsObject.CMLPOL == "N" ? "N" : ""],

        AnyDelivery: [this.quote.getTotalLocations()[0].getTotalBuildings()[0].BOPSEGMENTINFO.ANYDLVY == "" ? "N" : this.quote.getTotalLocations()[0].getTotalBuildings()[0].BOPSEGMENTINFO.ANYDLVY],
        EmploymentPracticesCB: [{value: true, disabled: true}],
        // EmploymentPracticesAggregate: [this.includeEmploymentPracticesLiability() ? 100000 : 0 ],
        EmploymentPracticesDate: [this.liabilityLimitsObject.EPLEFF],
        EmploymentPracticesDeductible: [this.liabilityLimitsObject.EPLDED],
        EmploymentPracticesRetroDate: [this.func.DTEWinsToPrimeNG(this.liabilityLimitsObject.EPLRDT)],
        ThirdPartyCoverageEndorsement: [this.liabilityLimitsObject.EPLTDP == "Y" ? "Y" : "N"],
        LiquorLiabilityCB: [this.migValidator.showLiquorLegalLiability(this.quote)],
        LiquorLiabilityOccurrenceAggregate: [this.liabilityLimitsObject.LLCCLM + "/" + this.liabilityLimitsObject.LLAGLM],
        VoluntaryPropertyDamageCB: [{value: true, disabled: true}]
      });
    }
    this.menuClass.stepActiveObject.form = this.liabilityLimitsFormGroup; // this ties our formgroup to the menu step. This is a crucial step in ensuring the validation is wired up properly.  

    this.HiredNonOwnedLimits = this.liabilityLimitsObject.GALMT == 4000000 ? "$1,000,000/$2,000,000" : this.formatter.format(this.liabilityLimitsObject.EOLMT) + "/" + this.formatter.format(this.liabilityLimitsObject.GALMT) ;
    this.setUpFormGroupSubscription();
    this.updateValidation();
    if(this.quote instanceof BOPQuote){
      this.quote.QUOTEPERSONALINFO.PRDSEG = this.calculatePredominantSegment();
    }
    this.nextClickSubscription = this.migsystemservice.subscribeNextClicked().subscribe(()=>{
      let errors = this.menuClass.CalculateErrorsFormGroup(this.liabilityLimitsFormGroup);
      this.migsystemservice.notifyError(errors); // updates the error panel as they fix them.
    });
  } 

  onCheckboxChange(event, property: string){
    this.liabilityLimitsObject[property] = event.checked ? "Y" : "N";
  }

  setUpFormGroupSubscription(){
    this.FormGroupSubscription = this.liabilityLimitsFormGroup.valueChanges.pipe(distinctUntilChanged()).subscribe(data =>{
      this.liabilityLimitsObject.EOLMT = this.func.justNumbers(this.migLiabilityResources.processSplitList(data.BLLOccurrenceAggregate)[0]);
      //Optional Coverages - Employee Benefit Liabilities is driven from the EOLMT value.
      this.liabilityLimitsObject.setEmployeeBenefitLiabilityValues();
      this.liabilityLimitsObject.GALMT = this.func.justNumbers(this.migLiabilityResources.processSplitList(data.BLLOccurrenceAggregate)[1]);
      this.HiredNonOwnedLimits = this.liabilityLimitsObject.GALMT == 4000000 ? "$1,000,000/$2,000,000" : this.formatter.format(this.liabilityLimitsObject.EOLMT) + "/" + this.formatter.format(this.liabilityLimitsObject.GALMT) ;
      this.liabilityLimitsObject.MEDLMT = data.MedicalLimit;
      this.liabilityLimitsObject.ENHOCC = data.HiredNonOwnedOccurrence;
      this.liabilityLimitsObject.ENHAGR = data.HiredNonOwnedAggregate;
      this.liabilityLimitsObject.CMLPOL = this.func.setInputSwitchValue(data.CommercialAutoPolicy);
      this.liabilityLimitsObject.EPLEFF = data.EmploymentPracticesDate;
      this.liabilityLimitsObject.EPLDED = data.EmploymentPracticesDeductible;
      this.liabilityLimitsObject.EPLRDT = this.func.funcDateSelected(data.EmploymentPracticesRetroDate);
      this.liabilityLimitsObject.EPLTDP = this.func.setInputSwitchValue(data.ThirdPartyCoverageEndorsement);
      this.liabilityLimitsObject.LLCCLM = this.func.justNumbers(this.migLiabilityResources.processSplitList(data.LiquorLiabilityOccurrenceAggregate)[0]);
      this.liabilityLimitsObject.LLAGLM = this.func.justNumbers(this.migLiabilityResources.processSplitList(data.LiquorLiabilityOccurrenceAggregate)[1]);
      if(this.quote instanceof BOPQuote){
        this.quote.getTotalLocations().forEach((loc:BOPLOCATION)=>{
          loc.getTotalBuildings().forEach((bld:BOPBUILDING)=>{
            bld.BOPSEGMENTINFO.ANYDLVY = this.func.setInputSwitchValue(data.AnyDelivery);
          });
        });
      }
      this.liabilityLimitsObject.EMPHNO = data.HiredNonAutoCB || data.CommercialAutoPolicy != "" ? "Y" : "N";

      this.checkBusinessLogic();
      this.liabilityLimitsObject.FRLGLB = this.liabilityLimitsObject.GALMT == 600000 ? 500000 : this.func.justNumbers(this.liabilityLimitsFormGroup.get("FireLegalLimit").value);

      this.updateValidation();
    });
    this.liabilityLimitsFormGroup.updateValueAndValidity();
  }

  checkBusinessLogic(){
    if(this.hasSegment("OFFC")){
      this.liabilityLimitsFormGroup.get("MedicalLimit").setValue(15000,{emitEvent:false});
      this.liabilityLimitsFormGroup.get("MedicalLimit").disable({emitEvent:false});
      if(!this.hasClass("131380")){ // as long as the class code isn't 131380 (Real Estate Agent) we want to select and disable the hired Non Owned Auto Checkbox.
        this.liabilityLimitsFormGroup.get("HiredNonAutoCheckbox").setValue(true,{emitEvent: false});
        this.liabilityLimitsFormGroup.get("HiredNonAutoCheckbox").disable({emitEvent: false});

      }
    }
    // if(this)
    if(this.liabilityLimitsObject.GALMT == 600000){ //When 'Business Liability Limits - Occurrence / Aggregate' = $300,000/$600,000, lock field for editing and default to $500,000
      this.liabilityLimitsFormGroup.get("FireLegalLimit").patchValue("$500,000",{emitEvent: false});
      this.liabilityLimitsFormGroup.get("FireLegalLimit").disable({emitEvent:false});
      this.liabilityLimitsObject.FRLGLB = 500000;
    }
    else{
      this.liabilityLimitsFormGroup.get("FireLegalLimit").enable({emitEvent:false});
      //this.liabilityLimitsFormGroup.get("FireLegalLimit").patchValue(this.liabilityLimitsObject.FRLGLB == 0 ? "$500,000" : this.formatter.format(this.liabilityLimitsObject.FRLGLB),{emitEvent: false});
      
    }
    // Commercial Auto Policy & Any Delivery: If 'Yes' is selected, disable 'Hired Auto/Non Owned Auto Liability' checkbox.
    if(this.quote instanceof BOPQuote){
      if((this.quote.getTotalLocations()[0].getTotalBuildings()[0].BOPSEGMENTINFO.ANYDLVY == "Y") || this.liabilityLimitsObject.CMLPOL == "Y") {
        this.liabilityLimitsFormGroup.get("HiredNonAutoCB").disable({emitEvent:false});
      }
      if(this.quote.getTotalLocations()[0].getTotalBuildings()[0].BOPSEGMENTINFO.ANYDLVY != "Y" && this.liabilityLimitsObject.CMLPOL != "Y"){
        this.liabilityLimitsFormGroup.get("HiredNonAutoCB").enable({emitEvent:false});
      }
    }
    
      this.liabilityLimitsObject.EPLAGR = this.includeEmploymentPracticesLiability() ? 100000 : 0;
      this.liabilityLimitsObject.EPLDED = this.includeEmploymentPracticesLiability() ? 100000 : 0;
  }

  updateValidation(){
    this.liabilityLimitsFormGroup.get("FireLegalLimit").setValidators(
    [ this.migValidator.ValidateMinValue("FireLegalLimit", "Fire Legal Liability Limits", 500000, "must be at least", true),
      this.migValidator.ValidateMaxValue((this.liabilityLimitsObject.EOLMT < 1000000 && this.liabilityLimitsObject.EOLMT >= 500000) ? this.liabilityLimitsObject.EOLMT : 1000000, "FireLegalLimit", "Fire Legal Liability Limits", "cannot be greater than", true)
    ]);

    // Commercial Auto Policy & Any Delivery: Will display and be required only if 'Hired Non Owned Auto' is selected.
    this.liabilityLimitsFormGroup.get("AnyDelivery").setValidators(this.liabilityLimitsFormGroup.get("HiredNonAutoCB").value ?
      this.migValidator.ValidateRequired("AnyDelivery", "Is there any Delivery?",false, true)
      : Validators.nullValidator);

    this.liabilityLimitsFormGroup.get("CommercialAutoPolicy").setValidators(this.liabilityLimitsFormGroup.get("HiredNonAutoCB").value ? 
      this.migValidator.ValidateRequired("CommercialAutoPolicy", "Does Applicant have a commercial auto policy?",false, true)
      : Validators.nullValidator);

    if(this.migValidator.showLiquorLegalLiability(this.quote)){
      this.liabilityLimitsFormGroup.get("LiquorLiabilityCB").disable({emitEvent:false});
    }

    // Retro Date: Display when Employment Practices Liability is not equal to Excluded and cancel state is NY (DWXP110.CANSTE = 31). Date must be equal to or less than effective date
    this.liabilityLimitsFormGroup.get("EmploymentPracticesRetroDate").setValidators((this.displayDate()) ? 
    [ this.migValidator.ValidateRequired("EmploymentPracticesRetroDate", "Retro Date"),
      this.migValidator.ValidateDateIsBeforeDate("EmploymentPracticesRetroDate", "Retro Date", this.func.DTEWinsToPrimeNG(this.quote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE)) 
    ]
    : Validators.nullValidator);
    //Liquor Legal Liability: Will be displayed and selected (unable to de-select) when liquor receipts is greater than 0 (DW5P136.LIQAOR > 0)
    this.liabilityLimitsFormGroup.get("LiquorLiabilityOccurrenceAggregate").setValidators(this.migValidator.showLiquorLegalLiability(this.quote) ? 
      [this.migValidator.ValidateRequiredWithDefault("LiquorLiabilityOccurrenceAggregate", "Liquor Legal Liability", "0/0"),
      this.migValidator.ValidateMaxValue(this.liabilityLimitsObject.EOLMT,"LiquorLiabilityOccurrenceAggregate", "Liquor Legal Liability", "cannot be greater than",false),
      this.migValidator.ValidateMaxLimit(this.liabilityLimitsFormGroup.get("BLLOccurrenceAggregate").value, "LiquorLiabilityOccurrenceAggregate", "Liquor Legal Liability", "should be equal or less than the selected business limit")]
      :Validators.nullValidator);
    this.migValidator.TriggerValidation(this.liabilityLimitsFormGroup); //loops through each control and update it's validation

    let errors = this.menuClass.CalculateErrorsFormGroup(this.liabilityLimitsFormGroup);
    this.migsystemservice.notifyError(errors); // updates the error panel as they fix them.
    // this.cd.detectChanges();
  }

  includeHiredNonOwnedAuto(): boolean{ 
    /* Will be selected, unable to de-select when any class segment is office (BLDSEG or BPPSEG = OFFC) 
    EXCEPT for Office: Real Estate Agent (BLDCLS or BPPCLS = 131380) will not be displayed at all.
    When selected, coverage added.  
    Display "Each Occurrence/General Aggregate" limits that were selected on Liability Limits greyed out. 
    If $2M / $4M limits selected, Display $1,000,000/$2,000,000*/ 
    return this.hasSegment("OFFC") && !this.hasSegment("131380");
  }

  hasSegment(segment: string) : boolean { // pass in a particular segment (ex: "RETL"), will return true if a building on the quote has that segment.
      return this.migValidator.hasSegment(segment, this.quote);
  }

  hasClass(bClass: string) : boolean { // pass in a particular class (ex: "131380"), will return true if a building on the quote has that class.
      return this.migValidator.hasClass(bClass, this.quote)
  }

  displayDate() : boolean {
    // Display when Employment Practices Liability is not equal to Excluded and cancel state is NY (DWXP110.CANSTE = 31)
    return this.quote.POLICYTRANS.CANSTE == "31" && this.includeEmploymentPracticesLiability();
  }

  includeEmploymentPracticesLiability(): boolean {
    /*
    Included coverage, default to $100,000 unless any of the following is true, then display 'Excluded' as read only and do not display Deductible, Retro Date or Third Party Endorsement.
  - Total Number of Employees (DW5P120.EMPLNOE) > 250
  - Class code on any building = 131342 (BLDCLS or BPPCLS)
  - Location state = VT (DW5P130.LOCST = 44) */
    return this.migValidator.includeEmploymentPracticesLiability(this.quote);
  }

  calculatePredominantSegment() : string{ 
    /*"Do not display on screen.  This predominant segment will be used to determine drop down options for Money & Securities on optional coverages.  Will also save the predomninant segment to the WINS file/field identified.
    Step 1: Total all building and bpp limits with the same segment type.  Predominant segment will be the segment type with the highest total limits
    Step 2: If more than one segment has the same higher amount then count number of location/buildings in each of the high segments.  The segment with the highest number of location/buildings is the predominant segment.
    Step 3: If two or more segments are still equal after step 2, use the segment on the earliest location/building among the equal segments for the predominant segment." */
    let predominantSegment: string = "";
    let initialSegmentObject = []; 
    let orderedSegmentsArray = [];
    if(this.quote instanceof BOPQuote){
      this.quote.getTotalLocations().forEach((loc:BOPLOCATION)=>{
        loc.getTotalBuildings().forEach((bld:BOPBUILDING)=>{
          initialSegmentObject.push // first, get all the segments from each building of each location, along with its limits.
          ({segment: bld.BLDSEG != "" ? bld.BLDSEG : bld.BPPSEG,
            limit: bld.BLDLMT + bld.BPPLMT,
            bldnum: bld.BLDNUM,
            locnum: bld.LOCNUM
          });
        });
      });
      let groupedSegment = _.groupBy(initialSegmentObject, 'segment') // group together all the segments. this array will have properties of each segment type associated with the quote. 
      for(let segmentType in groupedSegment){ //
        // console.log("seg: ", segmentType)
        groupedSegment[segmentType].segment = segmentType; 
        groupedSegment[segmentType].totalLimits = _.sumBy(groupedSegment[segmentType], 'limit'); // add up all the limits for each segment. 
        groupedSegment[segmentType].segmentCount = _.countBy(groupedSegment[segmentType], 'segment')[segmentType]; // get the total number of buildings with this segment.
        groupedSegment[segmentType].earliestBuilding = _.orderBy(groupedSegment[segmentType], ['bldnum'], ['asc'])[0]['bldnum']; // get the first building that has this segment type 
        groupedSegment[segmentType].earliestLocation = _.orderBy(groupedSegment[segmentType], ['locnum'], ['asc'])[0]['locnum']; // get the first location that has this segment type
        orderedSegmentsArray.push(groupedSegment[segmentType]);
      }
      // here we are "ranking" the segments based on the criteria above. So we order the array by first the total limits, then by the number of buildings with that segment, then by whichever segment came earliest on the quote. 
      orderedSegmentsArray = _.orderBy(orderedSegmentsArray, ['totalLimits','segmentCount','earliestLocation','earliestBuilding'], ['desc','desc','asc','asc']);
      predominantSegment = orderedSegmentsArray[0].segment; // now that the segments are ordered, we can set our predominant segment based on the first entry in our array. 
      // console.log("segmentObject: ", initialSegmentObject);
      // console.log("segmentArray: ", orderedSegmentsArray)
      // console.log("segmentCalc: ", groupedSegment)
      // console.log("predominant : ", predominantSegment)
      return predominantSegment;
    }
  }

  ngOnDestroy(): void {
    if(this.FormGroupSubscription) { this.FormGroupSubscription.unsubscribe()}
    if(this.nextClickSubscription) { this.nextClickSubscription.unsubscribe()}
  }

}
