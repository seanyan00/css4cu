import { QUOTEPERSONALINFO } from "@classes/CTR/QUOTEPERSONALINFO";

export class BOPQUOTEPERSONALINFO extends QUOTEPERSONALINFO{
    YRBSTR: number = 0;
	EOLMT: number = 0; 
	GALMT: number = 0;
	FRLGLB: number = 0; 
    PAILMT: number = 0;
    PAEXC: string = "";
    MEDLMT: number = 0;
    MEDEXC: string = "";
    EMPHNO: string = "";
	EMPLNOE: number = 0;
    ENHOCC: number = 0;
    ENHAGR: number = 0; 
    CMLPOL: string = "";
    EPLAGR: number = 0;
    EPLEFF: number = 0;
    EPLDED: number = 0;
    EPLRDT: number = 0;
    EPLTDP: string = "";
    LLCCLM: number = 0;
    LLAGLM: number = 0;
    PRPDED: number = 0;
    ADINEM: number = 0;
    NOVEND: number = 0;
    ADINCO: string = "";
    CSTSUB:number = 0;
    CYBAGG:number = 0;
    CYBSAL:number = 0;
    CYBEFF:number = 0;
    CYBRDT:number = 0;
    EBLRDT:number = 0;
    EBNALM:number = 0;
    EBNFLG:string = "";
    EBNOLM:number = 0;
    ELDATA:number = 0;
    EMPOLM:number = 0;
    ERISA:string = "";
    MOCPLM:number = 0;
    MSECOF:number = 0;
    MSECON:number = 0;
    PRFFLG:string = "";
    PRFLAG:number = 0;
    PRFLOC:number = 0;
    SUBCLS:string = "";
    SUBDSC:string = "";
    SUBIFA:string = "";

    PRDSEG: string = "";
    constructor(data?) {
        super(data);

        if (data != undefined) {
            Object.assign(this, data);
        }

        this.RECORDSTATE = "U";
    }

    assignQuotePersonalInfoProperties(data):void {
        Object.assign(this, data);
    }

    setEmployeeBenefitLiabilityValues() {
        if (this.EBNFLG != 'Y') {
            this.EBNOLM = 0;
            this.EBNALM = 0;
            return;
        }
        
        if (this.EOLMT == 2000000) {
            this.EBNOLM = 1000000;
            this.EBNALM = 1000000;
        }
        else {
            this.EBNOLM = this.EOLMT;
            this.EBNALM = this.EOLMT;
        }
    }

    setEmployeeDishonestyValues() {
        if (this.EMPLNOE > 50) {
            this.EMPOLM = 0;
            this.ERISA = 'N';
        }
    }
}