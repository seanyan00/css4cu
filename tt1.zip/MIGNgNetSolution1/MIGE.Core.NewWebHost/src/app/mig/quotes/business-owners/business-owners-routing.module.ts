import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BusinessOwnersComponent } from "./business-owners.component";


const routes: Routes = [
    {
      path: '',
      component: BusinessOwnersComponent
    }
  ];
  
  @NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })
  export class BusinessOwnersRoutingModule { }
