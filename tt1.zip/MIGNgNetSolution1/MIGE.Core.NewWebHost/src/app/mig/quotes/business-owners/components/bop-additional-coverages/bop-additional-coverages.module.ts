import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BopAdditionalCoveragesComponent } from './bop-additional-coverages.component';
import { MIGOverlayPanelModule } from '@overridden/primeng-overlaypanel/overlay.module';
import { AddressInformationModule } from '@shared/address_info/address.module';
import { BusinessClassModule } from '@shared/business-class/business-class.module';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { PropertyCoverageModule } from '@CTRcomponents/property-coverage/property-coverage.module';
import { ReportItemModule } from '@shared/report_item/report_item.module';
import { RiskAppetiteGuideModule } from '@shared/risk-appetite-guide/risk-appetite-guide.module';
import { MIGMessageModule } from '@overridden/primeng-message/message.module';
import { MIGInputSwitchModule } from '@overridden/primeng-inputswitch/switch.module';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { FieldsetModule } from 'primeng/fieldset';
import { PanelModule } from 'primeng/panel';
import { TooltipModule } from 'primeng/tooltip';
import { ErrorModule } from '@shared/errors/errors.module';
import { PipesModule } from '@pipes/pipes.module';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { DialogModule } from 'primeng/dialog';
import { AccordionModule } from 'primeng/accordion';
import { TableModule } from 'primeng/table';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { BOPQuote } from '@classViewModels/BOP/BOPQuote';
import { ADDRESS } from '@root/shared_components/address_info/address.class';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';
import { TextMaskModule } from 'angular2-text-mask';


@NgModule({
  declarations: [
    BopAdditionalCoveragesComponent
  ],
  imports: [
    CommonModule,
    AccordionModule,
    PanelModule,
	FieldsetModule,
	MIGButtonModule,
	MIGCheckboxModule,
    TableModule,
	FormsModule,
	ConfirmDialogModule,
	ErrorModule,
	PipesModule,
	MIGOverlayPanelModule,
	TooltipModule,
	MIGDropDownModule,
    ReportItemModule, 
    //GrowlModule,
	RiskAppetiteGuideModule,
	BusinessClassModule,
	AddressInformationModule,
	ReactiveFormsModule,
    MIGInputtextModule,
	MIGInputSwitchModule,
	TextMaskModule,
    MIGMessageModule,
    DialogModule
  ],
  exports:  [BopAdditionalCoveragesComponent]

})
export class BopAdditionalCoveragesModule { }
