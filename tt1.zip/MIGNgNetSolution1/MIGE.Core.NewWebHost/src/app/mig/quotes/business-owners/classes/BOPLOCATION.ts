import { UntypedFormGroup } from "@angular/forms";
import { QUOTEPOLICYINFO } from "@classes/Common/QUOTEPOLICYINFO";
import { BOPQuote } from "@classViewModels/BOP/BOPQuote";
import { Functions } from "@helpers/functions";
import { IQuote } from "@interfaces/IQuote";
import { ADDRESS, ADDRESSTERRITORY } from "@root/shared_components/address_info/address.class";
import * as _ from 'lodash';
import { BOPBASECLASS } from "./BOPBASECLASS";
import { BOPBUILDING } from "./BOPBUILDING";
import { BUSINESSLIABILITY, GARAGEKEEPER, LIQUORLIABILITY, PETPLUS } from "./BOPClasses";
import { BOPSEGMENTINFO } from "./BOPSEGMENTINFO";

export class BOPLOCATION extends BOPBASECLASS{
    BOPBUILDINGS: BOPBUILDING[] = [];
    LOCNUM: string = "001";
    GARAGEKEEPER: GARAGEKEEPER;
    PETPLUS: PETPLUS;
    ADDRESS: ADDRESS;
    ADDRESSTERRITORY: ADDRESSTERRITORY = null;
    RECORDSTATE: string = "";

    constructor(data?:BOPLOCATION) {
        super(data);
        this.initializeGarageKeeper();
        this.initializePetPlus();
        
        if (data != undefined)
        {
            
            Object.assign(this, data);
            this.BOPBUILDINGS = [];  // 5/24/21 & 6/20/2022 : need to clear out the buildings otherwise they will quadruple every time this function is called 
            var buildingToAdd:BOPBUILDING;
            data.BOPBUILDINGS.forEach(bopBuilding => {
                buildingToAdd = new BOPBUILDING(bopBuilding);

                this.BOPBUILDINGS.push(buildingToAdd);
            });

            if (data.GARAGEKEEPER != undefined) { 
                this.GARAGEKEEPER = new GARAGEKEEPER(data.GARAGEKEEPER);
            }

            if (this.GARAGEKEEPER == null)
            {
                this.initializeGarageKeeper();
            }

            if (data.PETPLUS != undefined) {
                this.PETPLUS = new PETPLUS(data.PETPLUS);
            }

            if (this.PETPLUS == null)
            {
                this.initializePetPlus();
            }
        }
    }

    initializeGarageKeeper() {
        this.GARAGEKEEPER = new GARAGEKEEPER();
        this.GARAGEKEEPER.TRANS = this.TRANS;
        this.GARAGEKEEPER.POLICY = this.POLICY;
        this.GARAGEKEEPER.EFFDTE = this.EFFDTE;
        this.GARAGEKEEPER.EDSDTE = this.EDSDTE;
        this.GARAGEKEEPER.LOCNUM = this.LOCNUM;
    }

    initializePetPlus() {
        this.PETPLUS = new PETPLUS();
        this.PETPLUS.TRANS = this.TRANS;
        this.PETPLUS.POLICY = this.POLICY;
        this.PETPLUS.EFFDTE = this.EFFDTE;
        this.PETPLUS.EDSDTE = this.EDSDTE;
        this.PETPLUS.LOCNUM = this.LOCNUM;
    }

    addNewBuilding(quote: IQuote, classCode?, classDesc?) : BOPBUILDING { // TODO: Add SICCDE and Segment as optional params? 
        var newNumericBldNum:number = _.filter(this.BOPBUILDINGS, bld => bld.RECORDSTATE != 'D').length;
        newNumericBldNum++;
        let data ={
            TRANS: this.TRANS,
            POLICY: this.POLICY,
            EFFDTE: this.EFFDTE,
            EDSDTE: this.EDSDTE,
            LOCNUM: this.LOCNUM,
            PRMSTE:this.ADDRESS.STATE,
            BLDNUM: _.padStart(newNumericBldNum.toString(), 3, '0'),
            CLSSEG: '',
            RCDTYP: 3
        }
        var newBld = new BOPBUILDING(data);
        newBld.TRANS = this.TRANS;
        newBld.POLICY = this.POLICY;
        newBld.EFFDTE = this.EFFDTE;
        newBld.EDSDTE = this.EDSDTE;
        if (classCode != undefined) {
            newBld.BLDCLS = classCode;
            newBld.BPPCLS = classCode;
        }

        if (classDesc != undefined) {
            newBld.BLDDSC = classDesc.substring(0,30);
            newBld.BPPDSC = classDesc.substring(0,30);
        }
        newBld.RECORDSTATE = "N"
        newBld.RCDTYP = 3;
        newBld.LOCNUM = this.LOCNUM;
        if(this.getTotalBuildings().length > 0){ // the following fields will have the same values across all buildings at this location.
            newBld.WINHDED = this.getTotalBuildings()[0].WINHDED;
        }
        if(quote instanceof BOPQuote){ // the following fields will have the same values across all buildings of all locations. As such, we can look at LOC 1 BLDG 1's value to set our new buildings value. 
            newBld.ASCCRD = quote.getTotalLocations()[0].getTotalBuildings()[0].ASCCRD;
            newBld.FRNCRD = quote.getTotalLocations()[0].getTotalBuildings()[0].FRNCRD;
            newBld.TPDED = quote.getTotalLocations()[0].getTotalBuildings()[0].TPDED;
        }
        newBld.BLDNUM = _.padStart(newNumericBldNum.toString(), 3, '0');       
        this.BOPBUILDINGS.push(newBld);
        this.setLocationAddress(this.ADDRESS);
        return newBld;
    }

    locationIsInState(stateCode:string):boolean {
        return _.some(this.getTotalBuildings(), (building:BOPBUILDING) => {
            return building.LOCST == stateCode
        })
    }

    setLocationAddress(address:ADDRESS) {
        this.ADDRESS = address;
        this.getTotalBuildings().forEach(bopBuilding => {
            bopBuilding.STRNO = address.STREETNUMBER;
            bopBuilding.STRNME = address.STREETNAME;
            bopBuilding.LOCAD2 = address.ADDRESSLINE2;
            bopBuilding.SUITE = address.SUITENUMBER;
            bopBuilding.LOCCTY = address.CITY;
            bopBuilding.LOCST = address.STATE;
            bopBuilding.LOCZIP = address.ZIPCODE;
            bopBuilding.TERR = address.TERRITORYCODE;   
            if(bopBuilding.BLDNUM != "001"){
                this.setLocationInfoFromExistingLocation(bopBuilding);
            }
        });
    }
    setLocationInfoFromExistingLocation(building: BOPBUILDING){ 
            building.TERR = this.getTotalBuildings()[0].TERR;
            building.TAXCTY = this.getTotalBuildings()[0].TAXCTY;
            building.TAXDSC = this.getTotalBuildings()[0].TAXDSC;
            building.PROCLS = this.getTotalBuildings()[0].PROCLS;
            building.RATCTY = this.getTotalBuildings()[0].RATCTY;
            building.WNDZNE = this.getTotalBuildings()[0].WNDZNE;
            building.PRMSTE = this.getTotalBuildings()[0].PRMSTE;
    }

    getTotalBuildings(): BOPBUILDING[] {
        return this.BOPBUILDINGS.filter(x=>x.RECORDSTATE != "D");
    }

    deleteBuilding(buildingToDelete:BOPBUILDING){
        buildingToDelete.RECORDSTATE = "D";
        buildingToDelete.BOPSEGMENTINFO.RECORDSTATE = "D";
        buildingToDelete.LIQUORLIABILITY.RECORDSTATE = "D";
        buildingToDelete.BUSINESSLIABILITY.RECORDSTATE = "D";
        this.funcResequenceNumbers();
    }

    funcResequenceNumbers(){
        let reIndex = 1;    
        let func = new Functions();
        this.getTotalBuildings().forEach(bld => { // resequence building numbers
            let newBldNum = func.lpad((reIndex).toString(), "0", 3);
            this.resequenceNumbers(this.getTotalBuildings(), bld.BLDNUM, newBldNum, "BLDNUM");
            this.resequenceNumbers(this.getTotalBuildings(), bld.BLDNUM, newBldNum, "BLDNUM");
            bld.BOPSEGMENTINFO.BLDNUM = newBldNum;
            bld.LIQUORLIABILITY.BLDNUM = newBldNum;
            bld.BUSINESSLIABILITY.BLDNUM = newBldNum;
            bld.BLDNUM = newBldNum;
            reIndex ++; 
        })
    }

    resequenceNumbers(dataArray: any[], oldNum: string, newNum: string, property: string) // copied from location summary, opportunity here to put this functionality in a separate component
    {
        _.forEach(dataArray, dataItem => {

            if ((dataItem.RECORDSTATE != 'D') && (dataItem[property] == oldNum))
            {
                dataItem[property] = newNum;

            }
            else if(dataItem instanceof UntypedFormGroup){ // if we are resequencing numbers on a form control, we need to set the values in the following format.
                
                if(dataItem.get(property).value == oldNum){
                    dataItem.get(property).setValue(newNum);
                }
            }
  
        });
    }
}