import { ADDRESS } from "@root/shared_components/address_info/address.class";
import * as _ from 'lodash';

export abstract class BOPBASECLASS {
    TRANS: string = "";
	POLICY: string = "";
	EFFDTE: number = 0;
	EDSDTE: number = 0;
	RCDTYP: number = 0;

    constructor(data?) {
        if (data != undefined)
        {
            Object.assign(this, data);
        }
    }
}