import { ADDRESS } from "@root/shared_components/address_info/address.class";
import * as _ from 'lodash';
import { BOPBASECLASS } from "./BOPBASECLASS";

export class PROFLIABILITY extends BOPBASECLASS {
    PRFTYP: string = "";
    PRFDSC: string = "";
    PRFUNT:number = 0;
    RECORDSTATE: string = "N";
    constructor(data?) {
        super(data);
        if (data != undefined)
        {
            Object.assign(this, data);
        }
    }
}
export class EXTENDEDPOLICYCVG extends BOPBASECLASS {
}
export class STATETRANSACTION extends BOPBASECLASS {
    STGEA: number = 0;
    STGPE: number = 0;
    STGPP: number = 0;
    STGEMP: number = 0;
    PRMSTE: string = "";
    RECORDSTATE: string = "N";
    constructor(data?) {
        super(data);
        if (data != undefined)
        {
            Object.assign(this, data);
        }
    }
}
export class RATEMODIFICATION extends BOPBASECLASS {
}


export class BUSINESSLIABILITY extends BOPBASECLASS //DW5P131
{  
    COVEND: number = 0;
    STATS1: string = "";
    PRMSTE: string = "";
    LOCNUM: string = "";
    BLDNUM: string = "";
    CLASX: string = "";
    CLSSEG: string = "";
    CLSDSC: string = "";
    FULTIM: number = 0;
    PRTTIM: number = 0;
    IFANY: string = "";
    DEDUCT: number = 0;
    RECORDSTATE: string = "N";
    constructor(data?) {
        super(data);
        if (data != undefined)
        {
            Object.assign(this, data);
        }
    }
}

export class GARAGEKEEPER extends BOPBASECLASS //DW5P132
{  
    COVEND: number = 0;
    STATS1: string = "";
    PRMSTE: string = "";
    LOCNUM: string = "";
    GKCMPL: number = 0;
    GKCMPDC: number = 0;
    GKCMPDO: number = 0;
    GKCOLL: number = 0;
    GKCOLD: number = 0;
	RECORDSTATE: string = "N";

    constructor(data?) {
        super(data);

        if (data != undefined)
        {
            Object.assign(this, data);
        }
    }
}
export class PETPLUS extends BOPBASECLASS //DW5P133
{ 
    COVEND: number = 0;
    STATS1: string = "";
    PRMSTE: string = "";
    LOCNUM: string = "";
    PETUSB: number = 0;
    PETERA: number = 0;
    PETTRM: number = 0;
    PETLPA: number = 0;
    PETLAG: number = 0;
    PETOFP: number = 0;
    PETDPA: number = 0;
    PETDAG: number = 0;
    PETRWD: number = 0;
    RECORDSTATE: string = "N";

    constructor(data?) {
        super(data);

        if (data != undefined)
        {
            Object.assign(this, data);
        }
    }

}
export class FINEART extends BOPBASECLASS
{
    

}
export class LIQUORLIABILITY extends BOPBASECLASS // DW5P136
{
    COVEND: number = 0;
    STATS1: string = "";
    PRMSTE: string = "";
    LOCNUM: string = "";
    BLDNUM: string = "";
    SEQNO: string = "001"; // I believe this should be defaulted to "001" ? Could use confirmation on this -JTL
    LIQCLS: string = "";
    LIQDSC: string = "";
    LIQAOR: number = 0;
    LIQGRD: number = 0;
    LIQBID: string = "";
    RECORDSTATE: string = "N";
    constructor(data?) {
        super(data);
        if (data != undefined)
        {
            Object.assign(this, data);
        }
    }
}
export class CONTRACTORSLIABILITY extends BOPBASECLASS {  }