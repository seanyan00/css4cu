/* ****************************************************************************************************
* PROGRAM DESCRIPTION  - BOP Additional Coverages Component
* NOTES: 
* - This component is specific to BOP and is a child component of the bop-building component. 
* - this component holds all our additional coverages that is tied to a single building. We elected to create a separate component for this because of the size and complexity of the section
* - All business logic and functionality related to this component's form controls is handled in its parent component (bop-building-component.ts)
*
* Bug Fixes: 
* 8/9/22: Fixed issue where Accounts Receivable coverage was displaying when only a building limit was entered (Bug 388) -JTL 
* 8/22/22: removed "migInputText" properties in HTML in order for read-only values to display properly (Bug 427) -JTL
* 8/22/22: Fixed display logic for "Outdoor Signs" limit field (Bug 426) - JTL
****************************************************************************************************/
import { Component, OnInit } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { InputMasksClass } from '@helpers/masks';
import { BOPBUILDING } from '../../classes/BOPBUILDING';
import { BOPLOCATION } from '../../classes/BOPLOCATION';
import { BopBuildingComponent } from '../bop-building/bop-building.component';

@Component({
  selector: 'mig-bop-additional-coverages',
  templateUrl: './bop-additional-coverages.component.html'
})
export class BopAdditionalCoveragesComponent implements OnInit {
  buildingFormGroup: UntypedFormGroup;
  buildingObject: BOPBUILDING;
  locationObject: BOPLOCATION;
  computerDescription: string; 
  constructor(
    public migRoles: MIGSecurityRoles,
    public masks: InputMasksClass,
    public dropDowns: ContractorsDropDowns,
    public buildingComponent: BopBuildingComponent
  ) {}

  ngOnInit(): void {
    this.buildingFormGroup = this.buildingComponent.buildingFormGroup;
    this.buildingObject = this.buildingComponent.buildingObject;
    this.locationObject = this.buildingComponent.locationObject;
    this.buildingObject.BIEEVAL = "INCL"; // default value for "Actual Loss Sustained" (Included Coverage);
    this.buildingComponent.disableIncludedCoverageCheckboxes();
  }



  showLiquorLiability(): boolean {
    //Optional Coverage: Only display when class segment = Food, Service, or Retail (BLDSEG or BPPSEG = FOOD, SERV, RETL) and state is not Vermont
    return ((this.buildingObject.LOCST != "44") && (this.buildingComponent.hasSegment("FOOD") || this.buildingComponent.hasSegment("SERV") || this.buildingComponent.hasSegment("RETL")));
  }

  showPetPlus(): boolean {
    //Only display when Building or BPP Class code (BLDCLS / BPPCLS) is one of the following: 131232 131418 131420 131428 131524 131422
    let bld = this.buildingObject.BLDCLS;
    let bpp = this.buildingObject.BPPCLS;
    return (bld == "131232" || bld == "131418" || bld == "131420" || bld == "131422" || bld == "131428" || bld == "131524" || 
            bpp == "131232" || bpp == "131418" || bpp == "131420" || bpp == "131422" || bpp == "131428" || bpp == "131524"
    )
  }
  // hasBuildingLimit(): boolean{ // returns true if a BUILDING limit is entered
  //   return this.buildingComponent.hasBuildingLimit()//.BLDLMT > 0
  // }

  // hasBPPLimit(): boolean { // returns true is a BPP limit is entered
  //   return this.buildingComponent.hasBPPLimit()//.BPPLMT > 0
  // }
}
