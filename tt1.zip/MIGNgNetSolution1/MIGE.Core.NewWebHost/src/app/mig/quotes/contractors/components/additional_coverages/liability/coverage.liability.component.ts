/* NG Includes */
import { Component, ViewEncapsulation, Input, ViewChild, AfterViewInit } from '@angular/core';
import { MIGSystemService } from '@services/mig.service';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { MenuClass } from '@root/system/menu/menu';
import { ContractorsTooltips } from '@helpers/tooltips';
import { MIGCoverageLiabilityExtension } from './extension/extension.component';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';

@Component({
    selector: 'mig-additional-coverages-liability',
    templateUrl: './coverage.liability.component.html',
    styleUrls: ['coverage.liability.component.css'],
    encapsulation: ViewEncapsulation.None
})

export class MIGAdditionalCoveragesLiability implements AfterViewInit {

    @ViewChild(MIGCoverageLiabilityExtension, { static: true }) child;
    visContractorsEO: boolean = false;
    visCyber: boolean = false;
    visEmplBenefits: boolean = false;
    visHiredNOA: boolean = false;
    visRetroDate: boolean = false;
    visThirdPart: boolean = false;
	formBuilder: UntypedFormBuilder;
	@Input() ctrQuote: CTRQuote;
	formGroup: UntypedFormGroup;
	visLiability: boolean;
	stepName: string = "AdditionalCoveragesLiability";

	constructor(
		public migsystemservice: MIGSystemService,
		public contractorsTooltips: ContractorsTooltips,
		public menuClass: MenuClass,
		public migRoles: MIGSecurityRoles
	) {
		if (this.formBuilder == null) {
			this.formBuilder = new UntypedFormBuilder();
		}
		this.formGroup = this.menuClass.menuObject(this.stepName).forms[0];
	}

	updatePanel($event){
		if(this.visLiability){
			this.child.visEmplPractices=false;
			this.child.visRetroDate=false;
			this.child.visThirdPart=false;
			this.child.visContractorsEO=false;
			this.child.visCyber=false;
			this.child.visEmplBenefits=false;	
			this.child.visHiredNOA=false;
			this.visLiability=$event;
			return this.visLiability;	
		}
		this.visLiability=false;
		return this.visLiability;
	}

	ngAfterViewInit(): void { 
		if(!this.migRoles.editable) {
			this.formGroup.disable();
		}
	}
}
