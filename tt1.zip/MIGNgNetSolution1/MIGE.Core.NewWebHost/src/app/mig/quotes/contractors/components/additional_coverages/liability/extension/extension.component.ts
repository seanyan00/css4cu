/* ****************************************************************************************************
* PROGRAM DESCRIPTION  - Additional Coverages > Liability
* DESCRIPTION          -
* DATE CREATED         - 2-19-2019
* AUTHOR               - Mario Giambanco
* Data Dictionary VER: - 221
* NOTES
*
* Mario Giambanco 2-19-2019
* rebuild according to data dictionary version 221
* RRF - 2019-06-20 - Empty Liability Coverages were being added to the ctrQuote causing duplicate
*					 records in sum instances and causing underwriting questions to error out.
*                    This code needs to be refactored out and streamlined.
****************************************************************************************************/

import { Component, Input, OnInit, ChangeDetectorRef, OnDestroy, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, UntypedFormControl, Validators, FormArray} from '@angular/forms';
import { MenuClass } from '@root/system/menu/menu';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { Functions } from '@helpers/functions';
import { Subscription } from 'rxjs/internal/Subscription';
import { MIGLiabilityResources } from './extension.resources';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { ContractorsTooltips } from '@helpers/tooltips';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { MIGSystemService } from '@services/mig.service';
import { DateFormatPipe } from '@pipes/pipes';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { GLPLIABILITIES } from '@classes/CTR/GLPLIABILITIES';
import { CONSTPROJECTLIAB } from '@classes/CTR/CONSTPROJECTLIAB';
import { InputMasksClass } from '@helpers/masks';
import { MessageService } from 'primeng/api';
import { ErrorService } from '@root/services/error.service';
import { parseInt } from 'lodash';
import * as moment from 'moment';
import { ExtensionBusinessRules } from './extension-business-rules';
import * as _ from 'lodash';
import { environment } from '@environment/environment';


@Component({
	selector: 'mig-coverage-liability-extension',
	templateUrl: './extension.component.html',
	styleUrls: ['../coverage.liability.component.css'],
	//styles: ['../coverage.liability.component.css'],
	providers: [DateFormatPipe]
})

export class MIGCoverageLiabilityExtension implements OnInit, OnDestroy {

	visLiability: boolean = false; 
    visContractorsEO: boolean = false;
    visCyber: boolean = false;
    visEmplBenefits: boolean = false;
    visHiredNOA: boolean = false;
    visRetroDate: boolean = false;
    visThirdPart: boolean = false;
	visEmplPractices: boolean = false;
	visSTPollution: boolean = false;
    visTransferOfRights: boolean = false;
    visAdditionalInsuredDescription: boolean = false;
    currentAdditionalInsuredDescription: any = null;
	vis: boolean = false; 
	nextClicked: boolean = false; 
	AIcheckbox: boolean = false; 
	messages: any;
	retroMaxDte: Date = moment(new Date()).subtract(1,'d').toDate();
	minDte: Date;
    maxDte: Date;
    businessStartMaxDte: Date;
	formBuilder: UntypedFormBuilder;
	formChanged: boolean = false;
	FormGroupSubscription: Subscription;
	CAPPOLSubscription: Subscription;
	checkboxHIREOCSubscription: Subscription;
	//updateRecordStateChanged: Subscription;
	resetForm: boolean = false;
	//resetFormSubscription: Subscription;
	addInsuredsSubscription: Subscription;
	//the blanket scheduled insured types
	blanketArr: string[] = ['EA', 'OS', 'LS', 'GL', 'CA', 'IB'];

	@Input() ctrQuote: CTRQuote;
	@Input() formGroup: UntypedFormGroup;

	migLiabilityResources = new MIGLiabilityResources();

	@Output() onIClicked: EventEmitter<any>;

	clicked(): void {
		this.onIClicked.emit();		
	}
	
	// needed for tooltips here
	controllingState: string = "";

	// TEMP PROPERTIES
	tempDropDown: any[] = [];
    EPILIMDropDown: any[] = [];
    C01PCA_EO_Limits_DropDown: any[] = [];
	showHideEmploymentPractices: boolean = false;
	showHideOhioStopGap: boolean = false;
	showHideElevatorEscalator: boolean = false;
	showHideContractorsEO: boolean = false;
	showHideSeptic: boolean = false;
	constprojectliab: CONSTPROJECTLIAB [] = [];
	CEO: GLPLIABILITIES;// = new GLPLIABILITIES(this.ctrQuote.QUOTEPOLICYINFORMATION);
	//CEOIndex: number = 0;
	CEOIndex: number = null;

	CYB: GLPLIABILITIES;// = new GLPLIABILITIES(this.ctrQuote.QUOTEPOLICYINFORMATION);
	//CYBIndex: number = 0;
	CYBIndex: number =  null;

	EPL: GLPLIABILITIES;// = new GLPLIABILITIES(this.ctrQuote.QUOTEPOLICYINFORMATION);
	//EPL: GLPLIABILITIES;
	EPLIndex: number = null;

	EBL: GLPLIABILITIES;// = new GLPLIABILITIES(this.ctrQuote.QUOTEPOLICYINFORMATION);
	//EBLIndex: number = 0;
	EBLIndex: number = null;
	addInsuredsChecked: boolean;

	constructor(
		public func: Functions,
		public contractorsDropDowns: ContractorsDropDowns,
		public contractorsTooltips: ContractorsTooltips,
		public migsystemservice: MIGSystemService,
		public dateFormatPipe: DateFormatPipe,
		public migRoles: MIGSecurityRoles,
		public masks: InputMasksClass,
		public menuClass: MenuClass,
		public messageService: MessageService,
		public errorService: ErrorService,
		private cd: ChangeDetectorRef,
		public extBR : ExtensionBusinessRules
	) {
		if (this.formBuilder == null) {
			this.formBuilder = new UntypedFormBuilder();
		}
		this.migsystemservice.subscribeNextClicked().subscribe(() => {	
			this.nextClicked=true;
			this.resetPanel();
			//this.nextClick();
		});

		this.migsystemservice.subscribeXClicked().subscribe(() => {
			this.nextClicked=false;		
		});

		//check to see if the first location address has been changed to see if we need to reset the form.
		// this.migsystemservice.subscribeFirstLocationStateChanged().subscribe((resetValue: boolean) => {
		// 	this.resetForm = resetValue;
		// });

		//RRF - COMMENTED OUT THIS LINE
		this.addInsuredsSubscription = this.migsystemservice.subscribeAddInsureds().subscribe((value: boolean) => {
			this.addInsuredsChecked = value;
		});
		//RRF - END COMMENTED OUT THIS LINE

		// this.migsystemservice.subscribeFirstLocationStateChanged().subscribe(() => {
		// 	//update the object graph to mark these coverates as deleted.
		// 	this.CEO = null;
		// 	this.ctrQuote.GLPENTITY.RemoveAdditionalCoverage("CEO");
		// 	this.CEOIndex = this.ctrQuote.GLPENTITY.GLPLIABILITIES.findIndex(x=> x.COVERG === "CEO");
		// 	this.CYB = null;
		// 	this.ctrQuote.GLPENTITY.RemoveAdditionalCoverage("CYB");
		// 	this.CYBIndex = this.ctrQuote.GLPENTITY.GLPLIABILITIES.findIndex(x=> x.COVERG === "CYB");
		// 	this.EPL = null;
		// 	this.ctrQuote.GLPENTITY.RemoveAdditionalCoverage("EPL");
		// 	this.EPLIndex = this.ctrQuote.GLPENTITY.GLPLIABILITIES.findIndex(x=> x.COVERG === "EPL");
		// 	this.EBL = null;
		// 	this.ctrQuote.GLPENTITY.RemoveAdditionalCoverage("EBL");
		// 	this.EBLIndex = this.ctrQuote.GLPENTITY.GLPLIABILITIES.findIndex(x=> x.COVERG === "EBL");
			
		// 	this.migLiabilityResources.setCTRQuote(this.ctrQuote);			
		// 	this.EPILIMDropDown = this.migLiabilityResources.processEPILIM(this.contractorsDropDowns.EPILIM);
		// 	this.formGroup.reset();			
		// });
		
		this.extBR = new ExtensionBusinessRules(this.func);

	}
	
	EffDate() :number {
		if (this.ctrQuote.QUOTEPOLICYINFORMATION.NEWEFFECTIVEDATE > 0) {
			return this.ctrQuote.QUOTEPOLICYINFORMATION.NEWEFFECTIVEDATE;
		} else {
			if (this.ctrQuote.POLICYTRANS.EFFDTE == 0) {
				var uhoh = 0;
			}
			return this.ctrQuote.POLICYTRANS.EFFDTE;
		}
	}
	get LIACOV() { return this.formGroup.get("LIACOV");}
	// Employee Practices Liability
	get checkboxEPILIM() { return this.formGroup.get("checkboxEPILIM"); }
	get EPILIM() { return this.formGroup.get("EPILIM"); }
	get EPIDED() { return this.formGroup.get("EPIDED"); }
	get EPIOID() { return this.formGroup.get("EPIOID"); }

	// Third Party Coverage Endorsement
	get EPITPC() { return this.formGroup.get("EPITPC"); }

	// Elevator / Escalator
	get checkboxELVNBR() { return this.formGroup.get("checkboxELVNBR"); }
	get ELVNBR() { return this.formGroup.get("ELVNBR"); }
	get ELVINSPS() { return this.formGroup.get("ELVINSPS"); }

	// Ohio Stop Gap
	get checkboxSTAGLM() { return this.formGroup.get("checkboxSTAGLM"); }
	get dropdownSTAGLM() { return this.formGroup.get("dropdownSTAGLM"); }
	get STAGLM() { return this.formGroup.get("STAGLM"); }
	get STGPRL() { return this.formGroup.get("STGPRL"); }
	get STOTLM() { return this.formGroup.get("STOTLM"); }

	// ContractorsE&O
	get checkboxC01PCA() { return this.formGroup.get("checkboxC01PCA"); }
	get dropdownC01PCA() { return this.formGroup.get("dropdownC01PCA"); }
	get C01PCA() { return this.formGroup.get("C01PCA"); }
	get C01AGR() { return this.formGroup.get("C01AGR"); }
	get C01DED() { return this.formGroup.get("C01DED"); }
    get C01RTR() { return this.formGroup.get("C01RTR"); }
    get DTBSTR() { return this.formGroup.get("DTBSTR"); }

	// Cyber Liability
	get checkboxCYBAGG() { return this.formGroup.get("checkboxCYBAGG"); }
	get CYBAGG() { return this.formGroup.get("CYBAGG"); }
	get CYBSAL() { return this.formGroup.get("CYBSAL"); }
	get CYBRDT() { return this.formGroup.get("CYBRDT"); }

	// Septic
	get checkboxEOACTL() { return this.formGroup.get("checkboxEOACTL"); }
	get dropdownEOACTL() { return this.formGroup.get("dropdownEOACTL"); }
	get EOACTL() { return this.formGroup.get("EOACTL"); }
	get EOAGGR() { return this.formGroup.get("EOAGGR"); }
	get EOINSP() { return this.formGroup.get("EOINSP"); }

	// Employee Benefits Liability
	get checkboxEBPCLM() { return this.formGroup.get("checkboxEBPCLM"); }	
	get EBPCLM() { return this.formGroup.get("EBPCLM"); }
	get EBAGGR() { return this.formGroup.get("EBAGGR"); }
	get EOLMT() { return this.formGroup.get("EOLMT"); }
	get EBDED() { return this.formGroup.get("EBDED"); }
	get EBRETR() { return this.formGroup.get("EBRETR"); }

	// Electronic Data Liability
	get checkboxEDLLMT() { return this.formGroup.get("checkboxEDLLMT"); }
	get EDLLMT() { return this.formGroup.get("EDLLMT"); }

	// Additional Insureds
	get checkboxAdditionalInsureds() { return this.formGroup.get("checkboxAdditionalInsureds"); }
	get OSCNT() { return this.formGroup.get("OSCNT"); }
	get checkboxOSCNT() { return this.formGroup.get("checkboxOSCNT"); }
	get LSCNT() { return this.formGroup.get("LSCNT"); }
	get checkboxLSCNT() { return this.formGroup.get("checkboxLSCNT"); }

	get GLCNT() { return this.formGroup.get("GLCNT"); }
	get checkboxGLCNT() { return this.formGroup.get("checkboxGLCNT"); }

	get IBCNT() { return this.formGroup.get("IBCNT"); }
	get checkboxIBCNT() { return this.formGroup.get("checkboxIBCNT"); }

	get CNCNT() { return this.formGroup.get("CNCNT"); }
	get checkboxCNCNT() { return this.formGroup.get("checkboxCNCNT"); }
	get CICNT() { return this.formGroup.get("CICNT"); }
	get checkboxCICNT() { return this.formGroup.get("checkboxCICNT"); }

	get EACNT() { return this.formGroup.get("EACNT"); }
	get checkboxEACNT() { return this.formGroup.get("checkboxEACNT"); }

	get OBCNT() { return this.formGroup.get("OBCNT"); }
	get checkboxOBCNT() { return this.formGroup.get("checkboxOBCNT"); }
	get MLCNT() { return this.formGroup.get("MLCNT"); }
	get checkboxMLCNT() { return this.formGroup.get("checkboxMLCNT"); }

	get SPCNT() { return this.formGroup.get("SPCNT"); }
	get checkboxSPCNT() { return this.formGroup.get("checkboxSPCNT"); }

	get STCNT() { return this.formGroup.get("STCNT"); }
	get checkboxSTCNT() { return this.formGroup.get("checkboxSTCNT"); }
	get VECNT() { return this.formGroup.get("VECNT"); }
	get checkboxVECNT() { return this.formGroup.get("checkboxVECNT"); }
	get MTCNT() { return this.formGroup.get("MTCNT"); }
	get checkboxMTCNT() { return this.formGroup.get("checkboxMTCNT"); }

	// Added 1-17-2019 by MAG
	get OWCNT() { return this.formGroup.get("OWCNT"); }
	get checkboxOWCNT() { return this.formGroup.get("checkboxOWCNT"); }

	get POCNT() { return this.formGroup.get("POCNT"); }
	get checkboxPOCNT() { return this.formGroup.get("checkboxPOCNT"); }
	get COCNT() { return this.formGroup.get("COCNT"); }
	get checkboxCOCNT() { return this.formGroup.get("checkboxCOCNT"); }
	get GFCNT() { return this.formGroup.get("GFCNT"); }
	get checkboxGFCNT() { return this.formGroup.get("checkboxGFCNT"); }
	get LECNT() { return this.formGroup.get("LECNT"); }
	get checkboxLECNT() { return this.formGroup.get("checkboxLECNT"); }
	get ENCNT() { return this.formGroup.get("ENCNT"); }
	get checkboxENCNT() { return this.formGroup.get("checkboxENCNT"); }

	// added 1-17-2019 by MAG
	get GSCNT() { return this.formGroup.get("GSCNT"); }
	get checkboxGSCNT() { return this.formGroup.get("checkboxGSCNT"); }

	get CPCNT() { return this.formGroup.get("CPCNT"); }
	get checkboxCPCNT() { return this.formGroup.get("checkboxCPCNT"); }

	get CACNT() { return this.formGroup.get("CACNT"); }
	get checkboxCACNT() { return this.formGroup.get("checkboxCACNT"); }

	get WTCNT() { return this.formGroup.get("WTCNT"); }
	get IXCNT() { return this.formGroup.get("IXCNT"); }
	get ZZCNT() { return this.formGroup.get("ZZCNT"); }
	get checkboxWTCNT() { return this.formGroup.get("checkboxWTCNT"); }

	// Designated Construction Projects
	get checkboxDCPBLK() { return this.formGroup.get("checkboxDCPBLK"); }
	get checkboxDCPBLKmu() { return this.formGroup.get("checkboxDCPBLKmu"); }
	get checkboxDCPBLKcg() { return this.formGroup.get("checkboxDCPBLKcg"); }
	// number of designated construction projects
	get SPCSEQ() { return this.formGroup.get("SPCSEQ"); }

	// Short Term Pollution Coverage For Contractors
	get SHTPOL() { return this.formGroup.get("SHTPOL"); }

	// Hired and Non Owned Auto Liability
	get checkboxHIREOC() { return this.formGroup.get("checkboxHIREOC"); }
	get HIREOC() { return this.formGroup.get("HIREOC"); }
	get HIRAGG() { return this.formGroup.get("HIRAGG"); }
	toggleHIRNON: boolean = false;

	// Does applicant have a commercial auto policy?
	get CAPPOL() { return this.formGroup.get("CAPPOL"); }

	// Message
	get Message() { return this.formGroup.get("Message"); }


	funcGetMinDate() {
        let today = new Date();
        let day = today.getDate();
		this.minDte = new Date();
		this.minDte.setDate(day - 14);
    }

    funcGetMaxDate() {
        let today = new Date();
        let day = today.getDate();
        this.maxDte = new Date();
        this.maxDte.setDate(day + 90);
	}

	resetPanel(){
		this.visLiability=false; 
		this.visContractorsEO=false;
		this.visCyber=false;
		this.visEmplBenefits=false;
		this.visHiredNOA=false;
		this.visRetroDate=false;
		this.visThirdPart=false;
		this.visEmplPractices=false;
		this.visSTPollution=false; 
        this.visTransferOfRights=false;
        this.visAdditionalInsuredDescription=false;
		this.vis=false;
    }

    showAdditionalInsuredDescription(endorsementCode: string)
    {
        this.resetPanel();
        this.currentAdditionalInsuredDescription = _.find(this.contractorsTooltips.AdditionalInsuredDescriptions, (desc) => {
            return desc.endorsement == endorsementCode;
        });

        if (this.currentAdditionalInsuredDescription == undefined)
        {
            return;
        }
        
        this.vis=true;
        this.visAdditionalInsuredDescription=!this.visAdditionalInsuredDescription;
    }
    
    getValidEOLimits()
    {
        if (this.controllingState == '28')
        {
			return _.filter(this.contractorsDropDowns.C01PCA, limitEOSelection =>  (limitEOSelection.value == '100000/100000' && limitEOSelection.dvalue == "2500"));
        }
        return _.filter(this.contractorsDropDowns.C01PCA, limitEOSelection =>  (!(limitEOSelection.value == '100000/100000' && limitEOSelection.dvalue == "2500")));
    }

    shortTermPollutionCoverageEligible()
    {
        if (this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EOLMT == 2000000) {
            //Short term pollution coverage for 2m/4m liability limits
            //becomes available starting 08/01/2020
            //for NY cancel state quotes with an effective date of 09/01/2020 or later

			//Project A-02243 - SMB - 01/24/2022:
            //SHORT TERM POLLUTION: Changes to Short Term Pollution for State 29
            //Eff 04/01/22
            //Project A-02054 - SMB - 12/08/2021:
            //SHORT TERM POLLUTION: Changes to Short Term Pollution for State 37
            //Eff 02/1/22 New and 4/1/22 Renewal Only.
            let cancelState:string = this.ctrQuote.POLICYTRANS.CANSTE;

            // Massachusetts = 20, Michigan = 21, New Hampshire = 28, New Jersey = 29, New York = 31, Ohio = 34, Pennsylvania = 37
            if (!((cancelState == '20') || (cancelState == '21') || (cancelState == '28') || (cancelState == '29') || (cancelState == '31') || (cancelState == '34') || (cancelState == '37'))) {
                //Cancel state is not MA, MI, NH, NJ, NY, OH, or PA
                //not eligible for short term pollution coverage.
                return false;
            }

            if (((cancelState == '21') || (cancelState == '34')) && (this.ctrQuote.POLICYTRANS.EFFDTE < 20211001)) {
                //Cancel state is Michigan or Ohio, quote has 2m/4m liability limits, but an effective date BEFORE 10/01/2021
                //not eligible for short term pollution coverage.
                return false;
            }
            if ((cancelState == '28') && (this.ctrQuote.POLICYTRANS.EFFDTE < 20211101)) {
                //Cancel state is New Hampshire, quote has 2m/4m liability limits, but an effective date BEFORE 09/01/2020
                //not eligible for short term pollution coverage.
                return false;
            }

            if ((cancelState == '31') && (this.ctrQuote.POLICYTRANS.EFFDTE < 20200901)) {
                //Cancel state is New York, quote has 2m/4m liability limits, but an effective date BEFORE 09/01/2020
                //not eligible for short term pollution coverage.
                return false;
            }

            if ((cancelState == '37') && (this.ctrQuote.POLICYTRANS.EFFDTE < 20220201)) {
                //Cancel state is Pennsylvania, quote has 2m/4m liability limits, but an effective date BEFORE 02/01/2022
                //not eligible for short term pollution coverage.
                return false;
            }

			if ((cancelState == '29') && (this.ctrQuote.POLICYTRANS.EFFDTE < 20220401)) {
                //Cancel state is New Jersey, quote has 2m/4m liability limits, but an effective date BEFORE 04/01/2022
                //not eligible for short term pollution coverage.
                return false;
            }


            if ((cancelState == '20') && (this.ctrQuote.POLICYTRANS.EFFDTE < 20220401)) {
                //Cancel state is Massachusetts, quote has 2m/4m liability limits, but an effective date BEFORE 04/01/2022
                //not eligible for short term pollution coverage.
                return false;
            }

            

            var todaysDate = new Date();
            var currentYear = todaysDate.getFullYear();
            //Javascript date getMonth() method returns the month in the specified date according to local time.
            //The value returned by getMonth() is an integer between 0 and 11.
            //0 corresponds to January, 1 to February, and so on
            var currentMonth = todaysDate.getMonth();

            //REMEMBER:  getMonth() is zero based.  August getMonth() -> 7.
            if ((currentYear == 2020) && (currentMonth < 7) && (environment.serverType == 'PROD')) {
                //quote has 2m/4m liability limits and an effective date of 09/01/2020 or later
                //but today's date is BEFORE 08/01/2020
                //not eligible for short term pollution coverage.
                return false;
            }
            
            //quote has 2m/4m liability limits, an effective date of 09/01/2020 or later, and today's date is 08/01/2020 or later
            //Eligible for short term pollution coverage.
            return true;
            
        }
        //Eligible for short term pollution coverage.
        return true;
    }

	ngOnInit(): void {			
		
		try {

		if(this.ctrQuote.GLLIABSTATECHANGE === "Y"){
			this.formGroup.reset();
			this.ctrQuote.GLLIABSTATECHANGE = "N";
		}

        document.getElementById('liabilityForm').scrollTop;
        
        this.formGroup = this.formBuilder.group({});

        this.maxDte = new Date();
        this.businessStartMaxDte = new Date();

		var e = this.ctrQuote.POLICYTRANS.EFFDTE;
		
        if (e != null && e.toString().length == 8) {
            this.maxDte = this.func.WinsToDateObject(e);
            this.businessStartMaxDte = moment(new Date(this.func.WinsToDateObject(e))).subtract(1,'d').toDate();
		}

		this.getIndexes();

		if(this.ctrQuote.GLPENTITY.GLPLIABILITIES.findIndex(x=>x.COVERG === "EPL") === -1) {
			this.ctrQuote.GLPENTITY.GLPLIABILITIES.push(this.EPL);
			this.EPLIndex = this.ctrQuote.GLPENTITY.GLPLIABILITIES.findIndex(x=> x.COVERG === "EPL");
		}

		// shorten up our paths
		let policyLiabLim = this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS;
		//need to make this a deep copy instead of a shallow copy so it doesn't maintain the reference to the original object and this maintains it's temp status
		this.constprojectliab = _.cloneDeep(this.ctrQuote.GLPENTITY.CONSTPROJECTLIAB);
		
		//this.ctrQuote.POLICYTRANS.CANSTE;	
        this.controllingState = this.ctrQuote.GLPENTITY.GLPLOCATIONS.find(x=> x.LOCNUM === '001'&& x.RECORDSTATE !== 'D').LOCST;
        
		this.C01PCA_EO_Limits_DropDown = this.getValidEOLimits();
		// send ctrQuote to Resources
		this.migLiabilityResources.setCTRQuote(this.ctrQuote);

		// get the default EPILIM dropdown value		
		//this.contractorsDropDowns.EPILIM = this.migLiabilityResources.processEPILIM(this.contractorsDropDowns.EPILIM);	
		this.EPILIMDropDown = this.migLiabilityResources.processEPILIM(this.contractorsDropDowns.EPILIM);	
		let defaultEPILIM = this.migLiabilityResources.processEPL(this.contractorsDropDowns.defaultEPILIM);	

		// Liability - Dropdown - Employment Practices Liability - EPIDED	
		let defaultEPIDED = this.migLiabilityResources.processEPL(this.contractorsDropDowns.defaultEPIDED);
		let vermontCheck = this.migLiabilityResources.vermontCheck();
		// check to see if Ohio Stop Gap should be hidden
		this.showHideOhioStopGap = this.migLiabilityResources.processOhioStopGap();

		// check to see if Contractors E & O should be hidden processContractorsEClasses method checks to see if class 91629 is selected on any location and returns a boolean
		this.showHideContractorsEO = this.migLiabilityResources.processContractorsEOClasses(this.contractorsDropDowns.contractorsEOClasses);

		// Check to see if we should show Elevator / Escalator
		this.showHideElevatorEscalator = this.migLiabilityResources.processElevatorEscalator();

		this.contractorsDropDowns.CYBAGG = this.migLiabilityResources.processCyber(this.contractorsDropDowns.CYBAGG);	

		// check to see if we should show Septic
		this.showHideSeptic = this.migLiabilityResources.processSeptic(this.contractorsDropDowns.EOACTLClasses, this.contractorsDropDowns.EOACTLStates);

		let proceddedEOLMT = this.migLiabilityResources.processEOLMTvalue();
		// Check to see if we should show Employment Practices
		// this.showHideEmploymentPractices = this.migLiabilityResources.processEmploymentPractices();

		// if(!this.resetForm) {
			// Set Employment Practices Liability Dropdown Values	
			this.formGroup.addControl('LIACOV', new UntypedFormControl({ value: true, disabled: true }));
			// Liability - Checkbox - Employment Practices Liability
			this.formGroup.addControl('checkboxEPILIM', new UntypedFormControl({ value: true, disabled: true }));

			// Liability - Dropdown - Employment Practices Liability
			this.formGroup.removeControl('EPILIM');
			this.formGroup.addControl('EPILIM', new UntypedFormControl(this.EPL.EPILIM ? this.EPL.EPILIM : defaultEPILIM.toString()));

			this.formGroup.removeControl('EPIDED');
			if (this.EPL.EPILIM === "50000" && vermontCheck) {
				this.formGroup.addControl('EPIDED', new UntypedFormControl(defaultEPIDED.toString()));				
			}
			else {
				this.formGroup.addControl('EPIDED', new UntypedFormControl(this.EPL.EPIDED ? this.EPL.EPIDED : defaultEPIDED.toString()));	
			}		

			// Liability - Calendar - Employment Practices Liability - Retro Date - default to EFFDTE
			this.formGroup.addControl('EPIOID', new UntypedFormControl(this.EPL.EPIOID ? this.func.DTEWinsToPrimeNG(this.EPL.EPIOID) : this.func.DTEWinsToPrimeNG(this.EffDate())));

			// ******************************************************************************************

			// Liability - Checkbox - Third Party Coverage Endorsement
			this.formGroup.addControl('EPITPC', new UntypedFormControl(this.EPL.EPITPC == "Y" ? true : false));

			// ******************************************************************************************

			// Liability - Checkbox - Ohio Stop Gap
			this.formGroup.addControl('checkboxSTAGLM', new UntypedFormControl(false));

			// Liability - Dropdown - Ohio Stop Gap
			this.formGroup.addControl('dropdownSTAGLM', new UntypedFormControl(policyLiabLim.STAGLM ? policyLiabLim.STAGLM : ""));

			// Liability - Storage Fields - Ohio Stop Gap - Arr[0]
			this.formGroup.addControl('STAGLM', new UntypedFormControl(policyLiabLim.STAGLM ? policyLiabLim.STAGLM : 0));

			// Liability - Storage Fields - Ohio Stop Gap - Arr[1]
			this.formGroup.addControl('STGPRL', new UntypedFormControl(policyLiabLim.STGPRL ? policyLiabLim.STGPRL : 0));

			// Liability - Storage Fields - Ohio Stop Gap - Arr[2]
			this.formGroup.addControl('STOTLM', new UntypedFormControl(policyLiabLim.STOTLM ? policyLiabLim.STOTLM : 0));

			// ******************************************************************************************

			// Liability - Checkbox - Elevator / Escalator
			this.formGroup.addControl('checkboxELVNBR', new UntypedFormControl(false));
			// Liability - Elevator / Escalator		
			this.formGroup.addControl('ELVNBR', new UntypedFormControl(policyLiabLim.ELVNBR ? policyLiabLim.ELVNBR : 0));		
			this.formGroup.addControl('ELVINSPS', new UntypedFormControl(policyLiabLim.ELVINSPS ? policyLiabLim.ELVINSPS : 0));

			// ******************************************************************************************

			// Liability - Checkbox - Contractors E&O
			this.formGroup.addControl('checkboxC01PCA', new UntypedFormControl(false));

			// Liability - Dropdown - Contractors E&O Limits => be sure to set default value here in case user doesnt trigger form change subsribe
			this.formGroup.addControl('dropdownC01PCA', new UntypedFormControl((this.CEO.C01PCA && this.controllingState !='28'? this.CEO.C01PCA + '/' + this.CEO.C01AGR : this.controllingState == '28'? this.contractorsDropDowns.defaultC01PCA_NH : this.contractorsDropDowns.defaultC01PCA)));

			// Liability - Storage Fields - Contractors E&O Limits - Arr[0]
			this.formGroup.addControl('C01PCA', new UntypedFormControl(this.CEO.C01PCA ? this.CEO.C01PCA : "0"));

			// Liability - Storage Fields - Contractors E&O Limits - Arr[1]
			this.formGroup.addControl('C01AGR', new UntypedFormControl(this.CEO.C01AGR ? this.CEO.C01AGR : ""));

			// Liability - Contractors E&O Deductible				
			this.formGroup.addControl('C01DED', new UntypedFormControl(this.CEO.C01DED ? this.CEO.C01DED : this.contractorsDropDowns.defaultC01DED));

			// Liability - Contractors E&O Retro Date		
			this.formGroup.addControl('C01RTR', new UntypedFormControl(this.CEO.C01RTR ? this.func.DTEWinsToPrimeNG(this.CEO.C01RTR) : this.func.DTEWinsToPrimeNG(this.ctrQuote.POLICYTRANS.EFFDTE)));
            // ******************************************************************************************
            
            // Liability - Contractors E&O Date Business Started		
			this.formGroup.addControl('DTBSTR', new UntypedFormControl(this.CEO.DTBSTR ? moment(new Date(this.func.DTEWinsToPrimeNG(this.CEO.DTBSTR))).toDate() : 0 ));

			// Liability - Checkbox - Cyber Liability
			this.formGroup.addControl('checkboxCYBAGG', new UntypedFormControl(false));
			
			// Liability - Cyber Liability Total Limit
			this.formGroup.addControl('CYBAGG', new UntypedFormControl((this.CYB.CYBAGG ? this.CYB.CYBAGG : this.contractorsDropDowns.defaultCYBAGG)));		


			// Liability - Cyber Liability Retro Date
			this.CYBRDT ? this.CYBRDT.setValue(this.func.DTEWinsToPrimeNG(this.EffDate())) : this.formGroup.addControl('CYBRDT', new UntypedFormControl(this.func.DTEWinsToPrimeNG(this.EffDate())));

			// Liability - Cyber Liability Annual Revenues
			this.formGroup.addControl('CYBSAL', new UntypedFormControl(this.CYB.CYBSAL ? this.CYB.CYBSAL : '0'));

			// ******************************************************************************************

			// Liability - Checkbox - Septic Systems Design and Inspection Professional Liability Coverage Endorsement
			this.formGroup.addControl('checkboxEOACTL', new UntypedFormControl(false));

			// Liability - Dropdown - Septic Systems Design and Inspection Professional Liability Coverage Endorsement
            this.formGroup.addControl('dropdownEOACTL', new UntypedFormControl(""));
            
            if ((policyLiabLim.EOACTL != 0) && (policyLiabLim.EOAGGR != 0))
            {
                this.dropdownEOACTL.setValue(policyLiabLim.EOACTL.toString() + "/" + policyLiabLim.EOAGGR.toString());
            }

			// Liability - Storage Fields - Septic Systems Design and Inspection Professional Liability Coverage Endorsement - Arr[0]
			this.formGroup.addControl('EOACTL', new UntypedFormControl(policyLiabLim.EOACTL ? policyLiabLim.EOACTL : 0));

			// Liability - Storage Fields - Septic Systems Design and Inspection Professional Liability Coverage Endorsement - Arr[1]
			this.formGroup.addControl('EOAGGR', new UntypedFormControl(policyLiabLim.EOAGGR ? policyLiabLim.EOAGGR : 0));

			// Liability - Sepectic Systems - Number of Inspectors
			this.formGroup.addControl('EOINSP', new UntypedFormControl(policyLiabLim.EOINSP ? policyLiabLim.EOINSP : 0));

			// ******************************************************************************************

			// Liability - Checkbox - Employee Benefits Liability
			this.formGroup.addControl('checkboxEBPCLM', new UntypedFormControl(false));

			// Liability - Label - Employee Benefits Liability
			this.formGroup.removeControl('EOLMT');
				
			this.formGroup.addControl('EOLMT', new UntypedFormControl(proceddedEOLMT ? proceddedEOLMT : "0"));				

			// Liability - Storage Fields - Employee Benefits Liability - Arr[0]
			this.formGroup.addControl('EBPCLM', new UntypedFormControl(this.EBL.EBPCLM ? this.EBL.EBPCLM : ""));

			// Liability - Storage Fields - Employee Benefits Liability - Arr[1]
			this.formGroup.addControl('EBAGGR', new UntypedFormControl(this.EBL.EBAGGR ? this.EBL.EBAGGR : ""));

			// Liability - Employee Benefits Liability - Deductible
			this.formGroup.addControl('EBDED', new UntypedFormControl((this.EBL.EBDED ? this.EBL.EBDED : "1000")));		

			// Liability - Employee Benefits Liability - Retro date		
			this.formGroup.addControl('EBRETR', new UntypedFormControl(this.EBL.EBRETR ? this.func.DTEWinsToPrimeNG(this.EBL.EBRETR) : this.func.DTEWinsToPrimeNG(this.ctrQuote.POLICYTRANS.EFFDTE)));
			// ******************************************************************************************

			// Liability - Checkbox - Electronic Data Liability
			this.formGroup.addControl('checkboxEDLLMT', new UntypedFormControl(false));

			// Liability - Dropdown - Electronic Data Liability
			this.formGroup.addControl('EDLLMT', new UntypedFormControl(policyLiabLim.EDLLMT ? policyLiabLim.EDLLMT : null));

			// ******************************************************************************************

			// Liability - Checkbox - Additional Insureds ?
			this.formGroup.addControl('checkboxAdditionalInsureds', new UntypedFormControl(this.ctrQuote.HasAdditionalInsureds()));		

			// CG 2007
			this.formGroup.addControl('checkboxEACNT', new UntypedFormControl(false));
			this.formGroup.addControl('EACNT', new UntypedFormControl(policyLiabLim.EACNT == 1 ? true : false));

			// CG 2033
			this.formGroup.addControl('checkboxOSCNT', new UntypedFormControl(false));
			this.formGroup.addControl('OSCNT', new UntypedFormControl(policyLiabLim.OSCNT == 1 ? true : false));

			// CG 2034
			this.formGroup.addControl('checkboxLSCNT', new UntypedFormControl(false));
			this.formGroup.addControl('LSCNT', new UntypedFormControl(policyLiabLim.LSCNT == 1 ? true : false));

			// CG 2035
			this.formGroup.addControl('checkboxGLCNT', new UntypedFormControl(false));
			this.formGroup.addControl('GLCNT', new UntypedFormControl(policyLiabLim.GLCNT == 1 ? true : false));

			// MU 9064
			this.formGroup.addControl('checkboxIBCNT', new UntypedFormControl(false));
			this.formGroup.addControl('IBCNT', new UntypedFormControl(policyLiabLim.IBCNT == 1 ? true : false));

			// CG 2038
			this.formGroup.addControl('checkboxCACNT', new UntypedFormControl(false));
			this.formGroup.addControl('CACNT', new UntypedFormControl(policyLiabLim.CACNT == 1 ? true : false));

			// CG 2003
			this.formGroup.addControl('checkboxCNCNT', new UntypedFormControl(false));
			this.formGroup.addControl('CNCNT', new UntypedFormControl(policyLiabLim.CNCNT ? policyLiabLim.CNCNT : 0));

			// CG 2005
			this.formGroup.addControl('checkboxCICNT', new UntypedFormControl(false));
			this.formGroup.addControl('CICNT', new UntypedFormControl(policyLiabLim.CICNT ? policyLiabLim.CICNT : 0));


			// CG 2010
			this.formGroup.addControl('checkboxOBCNT', new UntypedFormControl(false));
			let ob = policyLiabLim.OBCNT;
			if(policyLiabLim.ZZCNT){
				ob = policyLiabLim.ZZCNT;
			}
			if(ob==null) ob=0;
			this.formGroup.addControl('OBCNT', new UntypedFormControl(ob));

			// CG 2011
			this.formGroup.addControl('checkboxMLCNT', new UntypedFormControl(false));
			this.formGroup.addControl('MLCNT', new UntypedFormControl(policyLiabLim.MLCNT ? policyLiabLim.MLCNT : 0));

			// CG 2012
			this.formGroup.addControl('checkboxSPCNT', new UntypedFormControl(false));
			this.formGroup.addControl('SPCNT', new UntypedFormControl(policyLiabLim.SPCNT ? policyLiabLim.SPCNT : 0));


			// CG 2013
			this.formGroup.addControl('checkboxSTCNT', new UntypedFormControl(false));
			this.formGroup.addControl('STCNT', new UntypedFormControl(policyLiabLim.STCNT ? policyLiabLim.STCNT : 0));

			// CG 2015
			this.formGroup.addControl('checkboxVECNT', new UntypedFormControl(false));
			this.formGroup.addControl('VECNT', new UntypedFormControl(policyLiabLim.VECNT ? policyLiabLim.VECNT : 0));

			// CG 2018
			this.formGroup.addControl('checkboxMTCNT', new UntypedFormControl(false));
			this.formGroup.addControl('MTCNT', new UntypedFormControl(policyLiabLim.MTCNT ? policyLiabLim.MTCNT : 0));

			// Added 1-17-2019 by MAG
			// CG 2024
			this.formGroup.addControl('checkboxOWCNT', new UntypedFormControl(false));
			this.formGroup.addControl('OWCNT', new UntypedFormControl(policyLiabLim.OWCNT ? policyLiabLim.OWCNT : 0));

			// CG 2026
			this.formGroup.addControl('checkboxPOCNT', new UntypedFormControl(false));
			this.formGroup.addControl('POCNT', new UntypedFormControl(policyLiabLim.POCNT ? policyLiabLim.POCNT : 0));

			// CG 2027
			this.formGroup.addControl('checkboxCOCNT', new UntypedFormControl(false));
			this.formGroup.addControl('COCNT', new UntypedFormControl(policyLiabLim.COCNT ? policyLiabLim.COCNT : 0));

			// CG 2028
			this.formGroup.addControl('checkboxGFCNT', new UntypedFormControl(false));
			this.formGroup.addControl('GFCNT', new UntypedFormControl(policyLiabLim.GFCNT ? policyLiabLim.GFCNT : 0));

			// CG 2029
			this.formGroup.addControl('checkboxLECNT', new UntypedFormControl(false));
			this.formGroup.addControl('LECNT', new UntypedFormControl(policyLiabLim.LECNT ? policyLiabLim.LECNT : 0));

			// CG 2032
			this.formGroup.addControl('checkboxENCNT', new UntypedFormControl(false));
			this.formGroup.addControl('ENCNT', new UntypedFormControl(policyLiabLim.ENCNT ? policyLiabLim.ENCNT : 0));

			// Added 1-17-2019 by MAG
			// CG 2036
			this.formGroup.addControl('checkboxGSCNT', new UntypedFormControl(false));
			this.formGroup.addControl('GSCNT', new UntypedFormControl(policyLiabLim.GSCNT ? policyLiabLim.GSCNT : 0));

			// CG 2037
			this.formGroup.addControl('checkboxCPCNT', new UntypedFormControl(false));
			let cp = policyLiabLim.CPCNT;
			if(policyLiabLim.IXCNT){
				cp = policyLiabLim.IXCNT;
			}
			if(cp == null) cp = 0;
			this.formGroup.addControl('CPCNT', new UntypedFormControl(cp));

			// CG 2024
			this.formGroup.addControl('checkboxWTCNT', new UntypedFormControl(policyLiabLim.WTCNT > 0 ? true : false));
			this.formGroup.addControl('WTCNT', new UntypedFormControl(policyLiabLim.WTCNT ? policyLiabLim.WTCNT : 0));
			
			this.formGroup.addControl('IXCNT', new UntypedFormControl(policyLiabLim.IXCNT ? policyLiabLim.IXCNT : 0));

			this.formGroup.addControl('ZZCNT', new UntypedFormControl(policyLiabLim.ZZCNT ? policyLiabLim.ZZCNT : 0));

			// ******************************************************************************************

			// Designated Construction Projects()
			this.formGroup.addControl('checkboxDCPBLK', new UntypedFormControl(this.constprojectliab.length > 0 || policyLiabLim.DCPBLK =='Y' ? true : false));
			this.formGroup.addControl('checkboxDCPBLKmu', new UntypedFormControl(policyLiabLim.DCPBLK =='Y' ? true : false));

			this.formGroup.addControl('checkboxDCPBLKcg', new UntypedFormControl(this.constprojectliab.length > 0 ? true : false));
			//this.formGroup.addControl('dropdownDCPBLK', new FormControl(policyLiabLim.DCPBLK ? policyLiabLim.DCPBLK : 0));				
			this.formGroup.addControl('SPCSEQ', new UntypedFormControl(this.constprojectliab.length > 0 ? this.constprojectliab.length : 0));

			// ******************************************************************************************

			// Short Term Pollution Coverage For Contractors
			this.formGroup.removeControl('SHTPOL');				
			if (!this.shortTermPollutionCoverageEligible()) {			
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.SHTPOL = 'N'
				this.formGroup.addControl('SHTPOL', new UntypedFormControl({ value: false, disabled: true }));
			}
			else {
				this.formGroup.addControl('SHTPOL', new UntypedFormControl(policyLiabLim.SHTPOL === 'Y' ? true : false));
			}	

			// ******************************************************************************************

			// Hired and Non Owned Auto Liability
			// this.formGroup.addControl('HIRNON', new FormControl(policyLiabLim.HIRNON == ' Y' ? true : false));				
			if (policyLiabLim.CAPPOL === 'Y') {
				this.formGroup.addControl('checkboxHIREOC', new UntypedFormControl(policyLiabLim.HIREOC > 0 ? true : false));
				this.checkboxHIREOC.setValue(false);
				this.checkboxHIREOC.disable();
			}		
			else {
				this.formGroup.addControl('checkboxHIREOC', new UntypedFormControl(policyLiabLim.HIREOC > 0 ? true : false));
			}
			this.formGroup.addControl('HIREOC', new UntypedFormControl(policyLiabLim.HIREOC ? policyLiabLim.HIREOC : 0));
			this.formGroup.addControl('HIRAGG', new UntypedFormControl(policyLiabLim.HIRAGG ? policyLiabLim.HIRAGG : 0));

			// ******************************************************************************************

			//going to subscribe to the checkbox event to determine whether the Commercial Auto policy is required


			// Does applicant have a commercial auto policy?			
			if (this.checkboxHIREOC.value === true) {
				this.formGroup.addControl('CAPPOL', new UntypedFormControl(policyLiabLim.CAPPOL == "N" ? 'N' : "", 
				this.extBR.ValidateRequired('CAPPOL', 'Does applicant have a commercial auto policy?')));	
			}
			else {
				this.formGroup.addControl('CAPPOL', new UntypedFormControl(policyLiabLim.CAPPOL == "Y" ? 'Y' : "", Validators.nullValidator));
			}

			this.formGroup.addControl('Message', new UntypedFormControl(""));
			this.Message ? this.Message.setValue("") : this.formGroup.addControl('Message', new UntypedFormControl(""));

			this.resetForm = false;

			
			this.checkboxAdditionalInsureds.valueChanges.pipe(distinctUntilChanged()).subscribe(data => {
				data ? this.migsystemservice.notifyAddInsureds(true) : this.migsystemservice.notifyAddInsureds(false);
			});

			this.checkboxHIREOCSubscription = this.checkboxHIREOC.valueChanges.pipe(distinctUntilChanged()).subscribe(data => {
			
			if(data) {
				this.CAPPOL.setValidators(this.extBR.ValidateRequired('CAPPOL', 'Does applicant have a commercial auto policy?'));
				this.HIREOC.setValue(this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EOLMT == 2000000 ? 1000000 : this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EOLMT, { emitEvent: false });
				this.HIRAGG.setValue(this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.GALMT == 4000000 ? 2000000 : this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.GALMT, { emitEvent: false });
				//set value to quote
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.HIREOC = this.HIREOC.value;
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.HIRAGG = this.HIRAGG.value;
				this.cd.detectChanges();
			}else {
				this.CAPPOL.setValidators(Validators.nullValidator);
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.HIREOC = 0;
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.HIRAGG = 0;
			}
			this.CAPPOL.updateValueAndValidity({emitEvent: false});
		});

		this.ApplyValidation();
		this.processCoverage();
		this.UpdateQuote();		

		
		//read the value coming back from the Behavior Subject
		this.checkboxAdditionalInsureds.setValue(this.addInsuredsChecked, {emitEvent: false});
		this.menuClass.stepActiveObject.forms[0] = this.formGroup;
			
		}
		catch(e) {
			let _e: Error = e;
			console.log(e);
		}
		
	}

	getIndexes() {
		this.CEO = this.ctrQuote.GLPENTITY.GetCoverage("CEO");
		this.CEOIndex = this.ctrQuote.GLPENTITY.GLPLIABILITIES.findIndex(x=> x.COVERG === "CEO");
		this.CYB = this.ctrQuote.GLPENTITY.GetCoverage("CYB");
		this.CYBIndex = this.ctrQuote.GLPENTITY.GLPLIABILITIES.findIndex(x=> x.COVERG === "CYB");
		this.EPL = this.ctrQuote.GLPENTITY.GetCoverage("EPL");
		this.EPLIndex = this.ctrQuote.GLPENTITY.GLPLIABILITIES.findIndex(x=> x.COVERG === "EPL");
		this.EBL = this.ctrQuote.GLPENTITY.GetCoverage("EBL");
		this.EBLIndex = this.ctrQuote.GLPENTITY.GLPLIABILITIES.findIndex(x=> x.COVERG === "EBL");
	}
	ApplyValidation() {
		this.extBR.TriggerValidation(this.formGroup);
		/*this.CYBSAL.valueChanges.pipe(debounceTime(100)).subscribe(data => {
			if (this.func.justNumbers(data) > this.func.justNumbers(this.contractorsDropDowns.CYBSALLimit)) {
				this.checkboxCYBAGG.setValue(false);
				this.CYBSAL.setValue(0);
				this.messageService.add({ severity: 'error', summary: 'Cyber Liability', detail: 'Annual Revenue exceed Cyber Liability eligibility.', sticky: true, closable:false })
			}
		});*/

		// apply our validation rules if a checkbox changes
		// We are not storing checkbox values on WINS
		// so we have to check them here, when they change
		this.checkboxEDLLMT.valueChanges.pipe(debounceTime(100)).subscribe(data => {

			if (data) { this.EDLLMT.setValidators(this.extBR.ValidateRequired('EDLLMT', "Electronic Data Liability Limit")); } else { this.EDLLMT.setValue(null); this.EDLLMT.setValidators(Validators.nullValidator); }
		})


		// Employement Practices Liability
		this.checkboxEPILIM.valueChanges.pipe(debounceTime(100)).subscribe(value => {

			if(value){

				this.ctrQuote.GLPENTITY.AddAdditionalCoverage("EPL");
				this.EPIDED.setValidators(this.extBR.ValidateRequired('EPIDED',"Employment Practices Liability Deductible"));
				this.EPIDED.setValidators(this.extBR.ValidateRequired('EPIDED',"Employment Practices Liability Deductible"));
			}
			else {

				this.ctrQuote.GLPENTITY.RemoveAdditionalCoverage("EPL");
				this.EPIDED.setValidators(Validators.nullValidator);
				this.EPIOID.setValidators(Validators.nullValidator);
			}
			this.EPIDED.updateValueAndValidity();
			this.EPIOID.updateValueAndValidity();
		})

		// Ohio Stop Gap
		this.checkboxSTAGLM.valueChanges.pipe(debounceTime(100)).subscribe(data => {
			if (data) { this.dropdownSTAGLM.setValidators(this.extBR.ValidateRequired('STAGLM',"Ohio Stop Gap")); } else { this.dropdownSTAGLM.setValidators(Validators.nullValidator); }
			this.dropdownSTAGLM.updateValueAndValidity();
		})

		// Elevator / Escalator
		this.checkboxELVNBR.valueChanges.pipe(debounceTime(100)).subscribe(data => {
			if (data) { 
				this.ELVNBR.setValidators(this.extBR.ValidateRequired('ELVNBR',"Number of Elevators and / or Escalator Landings")); 
				this.ELVINSPS.setValidators([this.extBR.ValidateRequired('ELVINSPS',"Number of Inspections"),
				this.extBR.ValidateMinValue('ELVINSPS', 'Number of Inspections', 2, 'must have have a minimum value of', false)]); 
			} else { 
				this.ELVNBR.setValidators(Validators.nullValidator); 	
				this.ELVINSPS.setValidators(Validators.nullValidator);			
			}
			this.ELVNBR.updateValueAndValidity();
			this.ELVINSPS.updateValueAndValidity();
		})


		// Contractors EO
		this.checkboxC01PCA.valueChanges.pipe(debounceTime(100)).subscribe(value => {
			//CHECK TO SEE IF E&O EXISTS ON THE OBJECT
			if (value) {
                
				this.ctrQuote.GLPENTITY.AddAdditionalCoverage("CEO");
				this.CEOIndex = this.ctrQuote.GLPENTITY.GLPLIABILITIES.findIndex(x=> x.COVERG === "CEO");
				this.dropdownC01PCA.setValidators(this.extBR.ValidateRequired('dropdownC01PCA', "Contractors E & O Limits"));
				if (this.controllingState == '28'){ // For New Hampshire
					this.C01PCA.setValue('100000');
					this.C01AGR.setValue('100000');
					this.dropdownC01PCA.setValue('100000/100000');
                    
				}
				else if (this.C01PCA.value == "0") {
					let firstC01PCA = this.contractorsDropDowns.C01PCA[0].value;
					let splitC01PCA = this.migLiabilityResources.processSplitList(firstC01PCA);
					this.C01PCA.setValue(splitC01PCA[0]);
					this.C01AGR.setValue(splitC01PCA[1]);
					this.dropdownC01PCA.setValue(firstC01PCA);
				}
				this.C01DED.setValidators(this.extBR.ValidateRequired('C01DED',"Contractors E & O Deductible"));
                this.C01RTR.setValidators(this.extBR.ValidateRequired('C01RTR',"Contractors E & O Retro Date"));
                
                let latestValidBusinessStartDate:Date = moment(this.func.DTEWinsToPrimeNG(this.ctrQuote.POLICYTRANS.EFFDTE)).subtract(3,'y').toDate();
                this.DTBSTR.setValidators(this.extBR.ValidateBusinessStartDate('DTBSTR', 'Business Start Date', latestValidBusinessStartDate));

			} else {

				//remove coverage
				this.ctrQuote.GLPENTITY.RemoveAdditionalCoverage("CEO");
				this.C01PCA.setValue("0");
				this.C01AGR.setValue("0");
				this.dropdownC01PCA.setValue("0/0");
				this.dropdownC01PCA.setValidators(Validators.nullValidator);

				this.C01DED.setValidators(Validators.nullValidator);
                this.C01RTR.setValidators(Validators.nullValidator);
                this.DTBSTR.setValidators(Validators.nullValidator);
			}
            
			this.dropdownC01PCA.updateValueAndValidity();
			this.C01DED.updateValueAndValidity();
            this.C01RTR.updateValueAndValidity();
            this.DTBSTR.updateValueAndValidity({onlySelf: true, emitEvent: true});
			
		})

		// Cyber
		this.checkboxCYBAGG.valueChanges.pipe(debounceTime(100)).subscribe(value => {

			if(value) {
				
				this.ctrQuote.GLPENTITY.AddAdditionalCoverage("CYB");
				this.CYBIndex = this.CEOIndex = this.ctrQuote.GLPENTITY.GLPLIABILITIES.findIndex(x=> x.COVERG === "CYB");
				this.CYBAGG.setValidators(this.extBR.ValidateRequired('CYBAGG',"Cyber Liability Total Limit"));
				this.CYBSAL.setValidators(
					[this.extBR.ValidateRequired('CYBSAL',"Cyber Liability Annual Revenues"),
					this.extBR.CyberLiabilityAnnualRevenue(this.formGroup, 10000000)])
			} else {
				this.ctrQuote.GLPENTITY.RemoveAdditionalCoverage("CYB");
				this.CYBAGG.setValidators(Validators.nullValidator);
				this.CYBSAL.setValidators(Validators.nullValidator);
			}
			
			this.CYBAGG.updateValueAndValidity();
			this.CYBSAL.updateValueAndValidity();
		})

		// Septic
		this.checkboxEOACTL.valueChanges.pipe(debounceTime(100)).subscribe(data => {
			if (data) { this.dropdownEOACTL.setValidators(this.extBR.ValidateRequired('dropdownEOACTL',"Septic Systems Design - Please choose an endorsement")); } else { this.EOINSP.setValue(0); this.EOINSP.setValidators(Validators.nullValidator); }
			if (data) { this.EOINSP.setValidators(this.extBR.ValidateRequired('EOINSP',"Septic Systems Design - Number of Inspectors", true)); } else { this.EOINSP.setValidators(Validators.nullValidator); }
			this.dropdownEOACTL.updateValueAndValidity();
			this.EOINSP.updateValueAndValidity();
		});

		// Employee Benefits Liability
		this.checkboxEBPCLM.valueChanges.pipe(debounceTime(100)).subscribe(value => {			
			if (value) { //need to check to make sure it's not greater than the General Liability occurence limit
				this.ctrQuote.GLPENTITY.AddAdditionalCoverage("EBL");
				this.EBLIndex = this.CEOIndex = this.ctrQuote.GLPENTITY.GLPLIABILITIES.findIndex(x=> x.COVERG === "EBL");
				this.EBRETR.setValidators(this.extBR.ValidateRequired('EBRETR',"Employee Benefits Liability Retro Date")); 
			} else { 
				this.ctrQuote.GLPENTITY.RemoveAdditionalCoverage("EBL");
				this.EBRETR.setValidators(Validators.nullValidator); 
			}
			this.EBRETR.updateValueAndValidity();
		});
		
		// ------------------------------------------------------------------------------------------------------------------------------------------------
		// Additional Insureds

		this.checkboxCNCNT.valueChanges.pipe(debounceTime(100)).subscribe(data => {
			if (data) { this.CNCNT.setValidators(this.extBR.ValidateRequired('CNCNT', "CG 2003", true)); } else { this.CNCNT.setValue(0); this.CNCNT.setValidators(Validators.nullValidator); }
			this.CNCNT.updateValueAndValidity();
		})

		this.checkboxCICNT.valueChanges.pipe(debounceTime(100)).subscribe(data => {
			if (data) { this.CICNT.setValidators(this.extBR.ValidateRequired('CICNT',"CG 2005", true)); } else { this.CICNT.setValue(0); this.CICNT.setValidators(Validators.nullValidator); }
			this.CICNT.updateValueAndValidity();
		})

		this.checkboxOBCNT.valueChanges.pipe(debounceTime(100)).subscribe(data => {
			if (data) { this.OBCNT.setValidators(this.extBR.ValidateRequired('OBCNT',"CG 2010", true)); } else { this.OBCNT.setValue(0); this.OBCNT.setValidators(Validators.nullValidator); }
			this.OBCNT.updateValueAndValidity();
		})

		this.checkboxMLCNT.valueChanges.pipe(debounceTime(100)).subscribe(data => {
			if (data) { this.MLCNT.setValidators(this.extBR.ValidateRequired('MLCNT',"CG 2011", true)); } else { this.MLCNT.setValue(0); this.MLCNT.setValidators(Validators.nullValidator); }
			this.MLCNT.updateValueAndValidity();
		})

		this.checkboxSPCNT.valueChanges.pipe(debounceTime(100)).subscribe(data => {
			if (data) { this.SPCNT.setValidators(this.extBR.ValidateRequired('SPCNT',"CG 2012", true)); } else { this.SPCNT.setValue(0); this.SPCNT.setValidators(Validators.nullValidator); }
			this.SPCNT.updateValueAndValidity();
		})

		this.checkboxSTCNT.valueChanges.pipe(debounceTime(100)).subscribe(data => {
			if (data) { this.STCNT.setValidators(this.extBR.ValidateRequired('STCNT',"CG 2013", true)); } else { this.STCNT.setValue(0); this.STCNT.setValidators(Validators.nullValidator); }
			this.STCNT.updateValueAndValidity();
		});

		this.checkboxVECNT.valueChanges.pipe(debounceTime(100)).subscribe(data => {
			if (data) { this.VECNT.setValidators(this.extBR.ValidateRequired('VECNT',"CG 2015", true)); } else { this.VECNT.setValue(0); this.VECNT.setValidators(Validators.nullValidator); }
			this.VECNT.updateValueAndValidity();
		})

		this.checkboxMTCNT.valueChanges.pipe(debounceTime(100)).subscribe(data => {
			if (data) { this.MTCNT.setValidators(this.extBR.ValidateRequired('MTCNT',"CG 2018", true)); } else { this.MTCNT.setValue(0); this.MTCNT.setValidators(Validators.nullValidator); }
			this.MTCNT.updateValueAndValidity();
		})

		this.checkboxOWCNT.valueChanges.pipe(debounceTime(100)).subscribe(data => {
			if (data) { this.OWCNT.setValidators(this.extBR.ValidateRequired('OWCNT',"CG 2024", true)); } else { this.OWCNT.setValue(0); this.OWCNT.setValidators(Validators.nullValidator); }
			this.OWCNT.updateValueAndValidity();
		})

		this.checkboxPOCNT.valueChanges.pipe(debounceTime(100)).subscribe(data => {
			if (data) { this.POCNT.setValidators(this.extBR.ValidateRequired('POCNT',"CG 2026", true)); } else { this.POCNT.setValue(0); this.POCNT.setValidators(Validators.nullValidator); }
			this.POCNT.updateValueAndValidity();
		})

		this.checkboxCOCNT.valueChanges.pipe(debounceTime(100)).subscribe(data => {
			if (data) { this.COCNT.setValidators(this.extBR.ValidateRequired('COCNT',"CG 2027", true)); } else { this.COCNT.setValue(0); this.COCNT.setValidators(Validators.nullValidator); }
			this.COCNT.updateValueAndValidity();
		})

		this.checkboxGFCNT.valueChanges.pipe(debounceTime(100)).subscribe(data => {
			if (data) { this.GFCNT.setValidators(this.extBR.ValidateRequired('GFCNT',"CG 2028", true)); } else { this.GFCNT.setValue(0); this.GFCNT.setValidators(Validators.nullValidator); }
			this.GFCNT.updateValueAndValidity();
		})

		this.checkboxLECNT.valueChanges.pipe(debounceTime(100)).subscribe(data => {
			if (data) { this.LECNT.setValidators(this.extBR.ValidateRequired('LECNT',"CG 2029", true)); } else { this.LECNT.setValue(0); this.LECNT.setValidators(Validators.nullValidator); }
			this.LECNT.updateValueAndValidity();
		})

		this.checkboxENCNT.valueChanges.pipe(debounceTime(100)).subscribe(data => {
			if (data) { this.ENCNT.setValidators(this.extBR.ValidateRequired('ENCNT',"CG 2032", true)); } else { this.ENCNT.setValue(0); this.ENCNT.setValidators(Validators.nullValidator); }
			this.ENCNT.updateValueAndValidity();
		})

		this.checkboxGSCNT.valueChanges.pipe(debounceTime(100)).subscribe(data => {
			if (data) { this.GSCNT.setValidators(this.extBR.ValidateRequired('GSCNT',"CG 2036", true)); } else { this.GSCNT.setValue(0); this.GSCNT.setValidators(Validators.nullValidator); }
			this.GSCNT.updateValueAndValidity();
		})

		this.checkboxCPCNT.valueChanges.pipe(debounceTime(100)).subscribe(data => {
			if (data) { 
				this.CPCNT.setValidators(this.extBR.ValidateRequired('CPCNT',"CG 2037", true)); 

			} else { 
				this.CPCNT.setValidators(Validators.nullValidator); 
			}
			this.CPCNT.updateValueAndValidity();
		})

		this.checkboxWTCNT.valueChanges.pipe(debounceTime(100)).subscribe(data => {
			if (data) { this.WTCNT.setValidators(this.extBR.ValidateRequired('WTCNT',"CG 2404", true)); 
		} else { 
			//we need to reset the entry count to 0 and also clear out the GLPFORMDATA as well.
			this.WTCNT.setValue(0);
			this.WTCNT.setValidators(Validators.nullValidator);
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.WTCNT = 0;
			//we need to set the RecordState to D to delete the items
			this.ctrQuote.GLPFORMDATA.forEach(item => {
				item.RECORDSTATE = 'D';
			});
		}
			this.WTCNT.updateValueAndValidity();
		})

		this.WTCNT.valueChanges.pipe(debounceTime(100), distinctUntilChanged()).subscribe(num => {
			
			//we need to set the RECORDSTATE to 'D' for these items since they are lessening the number of records in GLPFORMDATA
			//cannot rely on them going to the Finish App page to remove these items, need to do it here
			this.ctrQuote.GLPFORMDATA.forEach((item, index) => {
				item.RECORDSTATE = index <= num - 1 ? 'N' : 'D';
			});
		})

		this.checkboxDCPBLK.valueChanges.pipe().subscribe(data => {
			if (data) { 
				this.checkboxDCPBLK.setValidators(this.extBR.ConstructionProjectsGenAggLim(this.formGroup)); 
			} else { 
				this.checkboxDCPBLKmu.setValue(0); 
				this.checkboxDCPBLKcg.setValue(0); 
				this.checkboxDCPBLK.setValidators(Validators.nullValidator); 
			}
			this.checkboxDCPBLKmu.updateValueAndValidity();
		})

		this.checkboxDCPBLKcg.valueChanges.pipe().subscribe(data => {
			if(data) {
				this.SPCSEQ.setValidators(this.extBR.ValidateMinValue('SPCSEQ', 'Number of Designated Construction Projects', 1, 'must at least be', false))
			} else {
				this.SPCSEQ.setValidators(Validators.nullValidator);
			}
			this.SPCSEQ.updateValueAndValidity();
		})

		this.CAPPOLSubscription = this.CAPPOL.valueChanges.pipe().subscribe((data) => {			
			if (data === 'Y') {
				this.checkboxHIREOC.setValue(false);
				this.checkboxHIREOC.disable();

			} else if(data === 'N') {
                this.checkboxHIREOC.enable();
                this.checkboxHIREOC.setValue(true, {emitEvent: false});
                //** make sure we put the values back if they select mulitple times **//
                this.HIREOC.setValue(this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EOLMT == 2000000 ? 1000000 : this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EOLMT, { emitEvent: false });
                this.HIRAGG.setValue(this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.GALMT == 4000000 ? 2000000 : this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.GALMT, { emitEvent: false });
                //set value to quote
                this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.HIREOC = this.HIREOC.value;
                this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.HIRAGG = this.HIRAGG.value;
                this.cd.detectChanges();
            }
		});

	}

    
	UpdateQuote() {

		this.FormGroupSubscription = this.formGroup.valueChanges.pipe(debounceTime(100)).subscribe(data => {
			if (this.formGroup.dirty) {
				this.menuClass.isQuoteDirty = true;
            }
            

            var hadAdditionalInsureds:boolean = this.ctrQuote.HasAdditionalInsureds();

			// Ohio Stop Gap
			let dropdownSTAGLM = this.migLiabilityResources.processSplitList(data.dropdownSTAGLM);
			let STOTLMvalue = this.migLiabilityResources.processSTOTLM(dropdownSTAGLM[0], this.contractorsDropDowns.STAGLM);
			
			//this was reversed...STAGLM became STOTLM, wrong value was being saved MAE 10/18
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.STOTLM = this.func.justNumbers((dropdownSTAGLM[0] && data.checkboxSTAGLM) ? dropdownSTAGLM[0] : 0);

			// we're ignoring the second value per Data Dictionary version 221
			// this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.STGPRL = parseInt(dropdownSTAGLM[1] ? dropdownSTAGLM[1] : 0);
			
			//this was reversed...STOTLM became STAGLM, wrong value was being saved MAE 10/18
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.STAGLM= this.func.justNumbers((STOTLMvalue && data.checkboxSTAGLM) ? STOTLMvalue : 0);
			this.STAGLM.setValue(this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.STAGLM || 0, {emitEvent: false}); 
			// end ohio stop gap
			this.getIndexes();
			// Contractors E&O Limits
			if (data.checkboxC01PCA) {

				let dropdownC01PCA = this.migLiabilityResources.processSplitList(data.dropdownC01PCA);

        let eodeductible = this.migLiabilityResources.processContractorsEODeductible(this.C01PCA_EO_Limits_DropDown, data.dropdownC01PCA);				
        this.C01DED.setValue(eodeductible.label, { emitEvent: false });
        this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.CEOIndex].C01PCA = (dropdownC01PCA[0] && data.checkboxC01PCA) ? dropdownC01PCA[0] : '0';
        this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.CEOIndex].C01AGR = (dropdownC01PCA[0] && data.checkboxC01PCA) ? dropdownC01PCA[1] : '0';

        //we need to update the CEO object = since this a reference to the this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.CEOIndex] in memory
        this.CEO.C01PCA = (dropdownC01PCA[0] && data.checkboxC01PCA) ? dropdownC01PCA[0] : '0';
        this.CEO.C01AGR =  (dropdownC01PCA[0] && data.checkboxC01PCA) ? dropdownC01PCA[1] : '0';

        this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.CEOIndex].C01DED = eodeductible.value;
        this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.CEOIndex].C01RTR = data.checkboxC01PCA ? this.func.funcDateSelected(data.C01RTR) : 0;
        
        /**User Story 2128 added 20210212: Pre-fill Date Business started if Contractors E&O 
         * is selected and date is stored in LANSA file */
        
        if(data.DTBSTR !=0 && data.DTBSTR !='undefined'){  					              	
            this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.CEOIndex].DTBSTR = this.func.funcDateSelected(data.DTBSTR);
        }
        else{
            if(this.ctrQuote.QUOTEPOLICYINFORMATION.EODATEBUSINESSSTARTED !=0){
                this.DTBSTR.setValue(this.func.DTEWinsToPrimeNG(this.ctrQuote.QUOTEPOLICYINFORMATION.EODATEBUSINESSSTARTED),{emitEvent: false});								
                this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.CEOIndex].DTBSTR = this.ctrQuote.QUOTEPOLICYINFORMATION.EODATEBUSINESSSTARTED;
            }									
        }
			}

			// Septic Systems
			if (data.checkboxEOACTL) {
				let dropdownEOACTL = this.migLiabilityResources.processSplitList(data.dropdownEOACTL);
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EOACTL = parseInt(dropdownEOACTL[0] ? dropdownEOACTL[0] : 0);
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EOAGGR = parseInt(dropdownEOACTL[1] ? dropdownEOACTL[1] : 0);
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EOINSP = this.func.justNumbers(data.EOINSP);
			}
			//ZJG 10262020
			//need to reset values to 0 when checkbox not checked
			else{
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EOACTL = 0;
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EOAGGR = 0;
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EOINSP = 0;
			}
			//Employee Liability Limits
			if (data.checkboxEBPCLM) {
				let evaluatedEBPCLM = this.migLiabilityResources.processEBPCLM(data.EOLMT);
				let liabset = this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.EBLIndex];
				if (liabset != null) {
					liabset.EBPCLM = (evaluatedEBPCLM[0] ? evaluatedEBPCLM[0] : "");
					liabset.EBAGGR = (evaluatedEBPCLM[1] ? evaluatedEBPCLM[1] : "");
					liabset.EBDED = data.EBDED ? data.EBDED : "";
					liabset.EBRETR = data.EBRETR ? this.func.funcDateSelected(data.EBRETR) : 0;
				}
			}
		
			// Elevator / Escalator
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.ELVNBR = (data.ELVNBR && data.checkboxELVNBR == true) ? data.ELVNBR : 0;					
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.ELVINSPS = (data.ELVINSPS && data.checkboxELVNBR == true) ? parseInt(data.ELVINSPS) : 0;			

			this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.EPLIndex].EPILIM = data.EPILIM ? data.EPILIM : "0";
			this.EPL.EPILIM = data.EPILIM

			if (data.EPILIM == "50000" && this.migLiabilityResources.vermontCheck) {
				this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.EPLIndex].EPIDED = "5000";
				this.EPL.EPIDED = "5000";
			}
			else {
				this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.EPLIndex].EPIDED = data.EPIDED ? data.EPIDED : "";
				this.EPL.EPIDED = data.EPIDED ? data.EPIDED : "";
			}
		

			// Retro Date
			this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.EPLIndex].EPIOID = this.func.funcDateSelected(data.EPIOID);
			this.EPL.EPIOID = this.func.funcDateSelected(data.EPIOID);

			// Third Party Coverage Endorsement
			this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.EPLIndex].EPITPC = data.EPITPC == true ? "Y" : "N";
			this.EPL.EPITPC = data.EPITPC == true ? "Y" : "N";

			if (data.checkboxCYBAGG && this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.CYBIndex]) {				
				this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.CYBIndex].CYBAGG = data.CYBAGG ? data.CYBAGG : "";
				this.CYB.CYBAGG = data.CYBAGG ? data.CYBAGG : "";				
				this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.CYBIndex].CYBSAL = data.CYBSAL ? this.func.justNumbers(data.CYBSAL) : 0;
				this.CYB.CYBSAL = data.CYBSAL ? this.func.justNumbers(data.CYBSAL) : 0;
				this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.CYBIndex].CYBRDT = this.ctrQuote.POLICYTRANS.EFFDTE; //<= always same as effective date
				this.CYB.CYBRDT = this.ctrQuote.POLICYTRANS.EFFDTE;
				this.CYB.CYBEFF = this.ctrQuote.POLICYTRANS.EFFDTE;
			}

			// Electronic Data Liability
			if (data.checkboxEDLLMT) {
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EDLLMT = data.EDLLMT ? data.EDLLMT : 0;
			}
			else {
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EDLLMT = 0;
			}	
			// Additional Insureds			
			if (data.checkboxAdditionalInsureds) {	//There is an issue here because the AI's will not get updated unless this checkbox is checked!
				
				this.checkboxAdditionalInsureds.setValidators(this.extBR.AtLeastOneAdditionalInsured(this.formGroup));
				//need to update the validators or else this validator change won't work properly
				this.checkboxAdditionalInsureds.updateValueAndValidity({emitEvent: false});

				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EACNT = (data.EACNT ? 1 : 0);
				this.ctrQuote.updateBlanketAI('EA', data.EACNT);
				//var ea = this.ctrQuote.ADDITIONALINSUREDS.find(f => f.ADDTYP == "EA");
				//if (ea != null) ea.RECORDSTATE = (data.EACNT ? "U" : "D");

				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.OSCNT = (data.OSCNT ? 1 : 0);
				this.ctrQuote.updateBlanketAI('OS', data.OSCNT);
				//var ea = this.ctrQuote.ADDITIONALINSUREDS.find(f => f.ADDTYP == "OS");
				//if (ea != null)
					//ea.RECORDSTATE = (data.OSCNT ? "U" : "D");

				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.LSCNT = (data.LSCNT ? 1 : 0);
				this.ctrQuote.updateBlanketAI('LS', data.LSCNT);
				//var ea = this.ctrQuote.ADDITIONALINSUREDS.find(f => f.ADDTYP == "LS");
				//if (ea != null)
					//ea.RECORDSTATE = (data.LSCNT ? "U" : "D");

				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.GLCNT = (data.GLCNT ? 1 : 0);
				this.ctrQuote.updateBlanketAI('GL', data.GLCNT);
				//var ea = this.ctrQuote.ADDITIONALINSUREDS.find(f => f.ADDTYP == "GL");
				//if (ea != null)
					//ea.RECORDSTATE = (data.GLCNT ? "U" : "D");

				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.CACNT = (data.CACNT ? 1 : 0);
				this.ctrQuote.updateBlanketAI('CA', data.CACNT);
				//var ea = this.ctrQuote.ADDITIONALINSUREDS.find(f => f.ADDTYP == "CA");
				//if (ea != null)
					//ea.RECORDSTATE = (data.CACNT ? "U" : "D");

				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.IBCNT = (data.IBCNT ? 1 : 0);
				this.ctrQuote.updateBlanketAI('IB', data.IBCNT);
				//var ea = this.ctrQuote.ADDITIONALINSUREDS.find(f => f.ADDTYP === "IB");
				//if (ea != null)
					//ea.RECORDSTATE = (data.IBCNT ? "U" : "D");

				//If CG 2037 is selected
				if(data.checkboxCPCNT) {
					if(data.IBCNT) { //if MU 9064 is selected
						this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.IXCNT = data.CPCNT ? data.CPCNT : 0;
						this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.CPCNT = 0;
						this.ctrQuote.changeAddType('CP');					
					}else { //MU not selected
						this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.CPCNT = data.CPCNT ? data.CPCNT : 0;
						this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.IXCNT = 0;
						this.ctrQuote.changeAddType('IX');
					}
				} else {
					this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.CPCNT = 0;	
					this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.IXCNT = 0;
					
				}
				
				//if CG 2010 is selected
				if(data.checkboxOBCNT) {
					if(data.OSCNT || data.CACNT) { //if CG 2033 and/or CG 2038 is selected
						this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.ZZCNT = data.OBCNT ? data.OBCNT : 0;
						this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.OBCNT = 0;
						//this.ctrQuote.changeAddType('OB');
					} else { //CG 2033 and/or CG 2038 is not selected
						this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.ZZCNT = 0;
						this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.OBCNT = data.OBCNT ? data.OBCNT : 0;
						//this.ctrQuote.changeAddType('ZZ');
					}
				} else {
					this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.OBCNT = 0;
					this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.ZZCNT = 0;
					
				}
				
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.GLCNT = data.GLCNT == true ? 1 : 0;
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.LSCNT = data.LSCNT == true ? 1 : 0;
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.CACNT = data.CACNT == true ? 1 : 0;
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.CNCNT = data.CNCNT != '' ? data.CNCNT : 0;
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.CICNT = data.CICNT != '' ? data.CICNT : 0;
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.MLCNT = data.MLCNT ? data.MLCNT : 0;
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.SPCNT = data.SPCNT ? data.SPCNT : 0;
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.STCNT = data.STCNT ? data.STCNT : 0;
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.VECNT = data.VECNT ? data.VECNT : 0;
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.MTCNT = data.MTCNT ? data.MTCNT : 0;
				// Added 1-17-2019 by MAG
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.OWCNT = data.OWCNT ==true ? data.OWCNT : 0;
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.POCNT = data.POCNT ? data.POCNT : 0;
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.COCNT = data.COCNT ? data.COCNT : 0;
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.GFCNT = data.GFCNT ? data.GFCNT : 0;
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.LECNT = data.LECNT ? data.LECNT : 0;
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.ENCNT = data.ENCNT ? data.ENCNT : 0;
				// added 1-17-2019 by MAG
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.GSCNT = data.GSCNT ? data.GSCNT : 0;		
				
				this.checkScheduledInsuredForDeletion(data);

				//if CG 2010 is selected
				if(data.checkboxOBCNT) {
					if(data.OSCNT || data.CACNT) { //if CG 2033 and/or CG 2038 is selected					
						this.ctrQuote.changeAddType('OB');
					} else { //CG 2033 and/or CG 2038 is not selected
					
						this.ctrQuote.changeAddType('ZZ');
					}
				} 
				
			}
			else {
				this.checkboxAdditionalInsureds.clearValidators();
				this.checkboxAdditionalInsureds.updateValueAndValidity({emitEvent: false});
				this.clearAI();
            }
            


			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.WTCNT = data.checkboxWTCNT ? parseInt(data.WTCNT) : 0;

			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.SHTPOL = data.SHTPOL == true ? 'Y' : 'N';
			
			if (this.checkboxHIREOC.value) {
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.CAPPOL = data.CAPPOL == 'N' ? 'N' : "";
			}			
			else {
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.CAPPOL = data.CAPPOL == 'Y' ? 'Y' : "";
			}
			
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.DCPBLK = data.checkboxDCPBLK && data.checkboxDCPBLKmu ? "Y" : "N";

			//FOR CONSTPROJECTLIAB
			//clear the array & use data.SPCSEQ for number to be added
			this.ctrQuote.GLPENTITY.CONSTPROJECTLIAB.length = 0;			
			if(data.checkboxDCPBLK && data.checkboxDCPBLKcg){								
				for(let i=0; i < data.SPCSEQ; i++)
				{
					this.ctrQuote.GLPENTITY.CONSTPROJECTLIAB.push(new CONSTPROJECTLIAB());					
					this.ctrQuote.GLPENTITY.CONSTPROJECTLIAB[i].POLICY = this.ctrQuote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
					this.ctrQuote.GLPENTITY.CONSTPROJECTLIAB[i].EFFDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
					this.ctrQuote.GLPENTITY.CONSTPROJECTLIAB[i].TRANS = this.ctrQuote.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;
					this.ctrQuote.GLPENTITY.CONSTPROJECTLIAB[i].RCDTYP = this.ctrQuote.QUOTEPOLICYINFORMATION.RECORDTYPE;
					this.ctrQuote.GLPENTITY.CONSTPROJECTLIAB[i].EDSDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;
					this.ctrQuote.GLPENTITY.CONSTPROJECTLIAB[i].RECORDSTATE = "U";
					this.ctrQuote.GLPENTITY.CONSTPROJECTLIAB[i].COVERG = 'CGL';					
					this.ctrQuote.GLPENTITY.CONSTPROJECTLIAB[i].SPCSEQ = this.func.lpad(((i + 1).toString()),'0',3);
					
					//need to push onto temp arrya as well to preserve description when adding more on.
					//deep clone here removes the description.
					this.constprojectliab.push(this.ctrQuote.GLPENTITY.CONSTPROJECTLIAB[i]);					
					//need to put the Description property back in or else it ends up blanking it out
					//if(!this.constprojectliab.length) return;					 
					this.ctrQuote.GLPENTITY.CONSTPROJECTLIAB[i].SPCDSC = this.constprojectliab.find(x => x.SPCSEQ === this.ctrQuote.GLPENTITY.CONSTPROJECTLIAB[i].SPCSEQ).SPCDSC;				
					
				}
								
            }
            
			if ((this.checkboxAdditionalInsureds.value != this.ctrQuote.HasAdditionalInsureds()) && (hadAdditionalInsureds))
            {
                this.checkboxAdditionalInsureds.setValue(this.ctrQuote.HasAdditionalInsureds());
            }
			this.formChanged = true;
			this.migsystemservice.notifyQuoteChanged(this.ctrQuote);
			this.extBR.TriggerValidation(this.formGroup);
			//let errors =  this.menuClass.CalculateErrorsFormGroup(this.formGroup);
			this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive);
		});
	}



	nextClick(){
		this.nextClicked=true;
		if(this.formGroup.valid) this.migsystemservice.notifyToastMessagesCleared();
	}

	clearAI(){
		//this function is used to clear the ADDTL insureds values. 
		//This is called in the UpdateQuote() function when the "Additional Insureds" checkbox is set to false. -7/7/2020 JTL
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.CACNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EACNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.OBCNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.OSCNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.LSCNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.GLCNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.IBCNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.CNCNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.CICNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.CPCNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.MLCNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.SPCNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.STCNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.VECNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.MTCNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.OWCNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.POCNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.COCNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.GFCNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.LECNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.ENCNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.GSCNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.CACNT=0;
			// this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.WTCNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.ZZCNT=0;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.IXCNT=0;
		//Need to set the nested checkboxes to false for form validation purposes
			this.EACNT.setValue(0, {emitEvent: false});
			this.OSCNT.setValue(0, {emitEvent: false});
			this.LSCNT.setValue(0, {emitEvent: false});
			this.GLCNT.setValue(0, {emitEvent: false});
			this.IBCNT.setValue(0, {emitEvent: false});
			this.ENCNT.setValue(0, {emitEvent: false});
			this.CICNT.setValue(0, {emitEvent: false});
			this.CNCNT.setValue(0, {emitEvent: false});
			this.CPCNT.setValue(0, {emitEvent: false});
			this.COCNT.setValue(0, {emitEvent: false});
			this.GFCNT.setValue(0, {emitEvent: false});
			this.GSCNT.setValue(0, {emitEvent: false});
			this.CACNT.setValue(false, {emitEvent: false});
			this.checkboxCNCNT.setValue(false, {emitEvent: false});
			this.checkboxCICNT.setValue(false, {emitEvent: false});
			this.checkboxOBCNT.setValue(false, {emitEvent: false});
			this.checkboxMLCNT.setValue(false, {emitEvent: false});
			this.checkboxSPCNT.setValue(false, {emitEvent: false});
			this.checkboxSTCNT.setValue(false, {emitEvent: false});
			this.checkboxVECNT.setValue(false, {emitEvent: false});
			this.checkboxMTCNT.setValue(false, {emitEvent: false});
			this.checkboxOWCNT.setValue(false, {emitEvent: false});
			this.checkboxPOCNT.setValue(false, {emitEvent: false});
			this.checkboxCOCNT.setValue(false, {emitEvent: false});
			this.checkboxGFCNT.setValue(false, {emitEvent: false});
			this.checkboxLECNT.setValue(false, {emitEvent: false});
			this.checkboxENCNT.setValue(false, {emitEvent: false});
			this.checkboxGSCNT.setValue(false, {emitEvent: false});
			this.checkboxCPCNT.setValue(false, {emitEvent: false});
			// this.checkboxWTCNT.setValue(false);
		//updates the scheduled and blanket insureds so that the quote is updated with this new info when the user saves the quote. 
			this.checkScheduledInsuredForDeletion(this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS);
			this.ctrQuote.updateBlanketAI('EA', false);
			this.ctrQuote.updateBlanketAI('OS', false);
			this.ctrQuote.updateBlanketAI('LS', false);
			this.ctrQuote.updateBlanketAI('GL', false);
			this.ctrQuote.updateBlanketAI('CA', false);
			this.ctrQuote.updateBlanketAI('IB', false);
	}
	
	removeCoverage(coverage) {
		
		this.ctrQuote.GLPENTITY.RemoveAdditionalCoverage(coverage);
		
		this.CEOIndex = this.ctrQuote.GLPENTITY.GLPLIABILITIES.findIndex(x=>x.COVERG == "CEO") === -1 ? null : this.ctrQuote.GLPENTITY.GLPLIABILITIES.findIndex(x=>x.COVERG == "CEO");
		this.CYBIndex = this.ctrQuote.GLPENTITY.GLPLIABILITIES.findIndex(x=>x.COVERG == "CYB") === -1 ? null : this.ctrQuote.GLPENTITY.GLPLIABILITIES.findIndex(x=>x.COVERG == "CYB");
		this.EPLIndex = this.ctrQuote.GLPENTITY.GLPLIABILITIES.findIndex(x=>x.COVERG == "EPL") === -1 ? null : this.ctrQuote.GLPENTITY.GLPLIABILITIES.findIndex(x=>x.COVERG == "EPL");
		this.EBLIndex = this.ctrQuote.GLPENTITY.GLPLIABILITIES.findIndex(x=>x.COVERG == "EBL") === -1 ? null : this.ctrQuote.GLPENTITY.GLPLIABILITIES.findIndex(x=>x.COVERG == "EBL"); 	
	
	}

	//we need to check to see if a scheduled insured needs to be deleted. 
	//If so we call the method to delete from Common Quote which then calls the method from the Additional Insured Class
	checkScheduledInsuredForDeletion(data: any) {
		
			//need to delete scheduled additional insureds when needed
			this.ctrQuote.updateScheduledAI('CN', data.CNCNT);
			this.ctrQuote.updateScheduledAI('CI', data.CICNT);
			this.ctrQuote.updateScheduledAI('ML', data.MLCNT);
			this.ctrQuote.updateScheduledAI('SP', data.SPCNT);
			this.ctrQuote.updateScheduledAI('ST', data.STCNT);
			this.ctrQuote.updateScheduledAI('VE', data.VECNT);
			this.ctrQuote.updateScheduledAI('MT', data.MTCNT);
			this.ctrQuote.updateScheduledAI('OW', data.OWCNT);
			this.ctrQuote.updateScheduledAI('PO', data.POCNT);
			this.ctrQuote.updateScheduledAI('CO', data.COCNT);
			this.ctrQuote.updateScheduledAI('GF', data.GFCNT);
			this.ctrQuote.updateScheduledAI('LE', data.LECNT);
			this.ctrQuote.updateScheduledAI('EN', data.ENCNT);
			this.ctrQuote.updateScheduledAI('GS', data.GSCNT);
			this.ctrQuote.updateScheduledAI('CP', this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.CPCNT, 'IX', this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.IXCNT || 0);
			this.ctrQuote.updateScheduledAI('OB', this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.OBCNT, 'ZZ', this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.ZZCNT || 0);
		
	}
	ngOnDestroy(): void {
		// we need to tell underwriting schedule
		// ctrquote changes so we can calculate additional insureds
		// lets do that here so we're not doing it in the valuechanges loop
		//this.removeUncheckedCoverages();

		document.getElementById('liabilityForm').scrollTop;
		if(this.FormGroupSubscription)this.FormGroupSubscription.unsubscribe();
		if(this.CAPPOLSubscription)this.CAPPOLSubscription.unsubscribe();
		if(this.checkboxHIREOCSubscription)this.checkboxHIREOCSubscription.unsubscribe();
		//RRF - COMMENTED OUT THE FOLLOWING LINE
		this.addInsuredsSubscription.unsubscribe();
		this.migsystemservice.notifyToastMessagesCleared();
		this.cd.detach();
	
	}

	processCoverage()
	{
		if(this.ctrQuote.GLPENTITY.GLPLIABILITIES.length) {
		// Employment Practices Liability <-- DEFAULT coverage
			if (this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.EPLIndex].COVERG)
			{
				this.checkboxEPILIM.setValue(true);
				this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.EPLIndex].EPILIM = this.EPILIM.value;
				this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.EPLIndex].EPIDED = this.EPIDED.value;			
				this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.EPLIndex].EPIOID = this.func.funcDateSelected(this.EPIOID.value);
				//need this to default to a decimal value for referrals to load.
				//this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.EPLIndex].C01PCA = this.C01PCA.value;	<-- removed; not used to EPL cvg, generates duplicate referral		
				this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.EPLIndex].POLICY 	= this.ctrQuote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;			
				this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.EPLIndex].EFFDTE 	= this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
				this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.EPLIndex].TRANS 	= this.ctrQuote.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;
				this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.EPLIndex].RCDTYP 	= this.ctrQuote.QUOTEPOLICYINFORMATION.RECORDTYPE;
				this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.EPLIndex].EDSDTE 	= this.ctrQuote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;			
				//this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.EPLIndex].RECORDSTATE = "U";
			}

			// Contractors EO
			if (this.CEOIndex > -1 && (this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.CEOIndex].C01PCA != '0'	&& this.ctrQuote.GLPENTITY.GLPLIABILITIES[this.CEOIndex].C01PCA != '')) {
				if(this.ctrQuote.GLPENTITY.GLPLIABILITIES.filter(x => x.COVERG === "CEO" && x.RECORDSTATE != "D" ).length > 0){
					this.checkboxC01PCA.setValue(true);
				}
			}
			
			// Cyber
			if(this.ctrQuote.GLPENTITY.GLPLIABILITIES.filter(x => x.COVERG === "CYB" && x.RECORDSTATE != "D" ).length > 0){
				this.checkboxCYBAGG.setValue(true);
			}

			//Employee Benefits Liability
			if(this.ctrQuote.GLPENTITY.GLPLIABILITIES.filter(x => x.COVERG === "EBL" && x.RECORDSTATE != "D" ).length > 0){
				this.checkboxEBPCLM.setValue(true); 
			}
		  
			// ohio stop gap
			if (this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.STAGLM) { this.checkboxSTAGLM.setValue(true); }
			// Elevator / Escalator
			//neither of these can be strings or else the value will be set to true even if 0 --ELVNBR is being set to a string for some reason
			if (this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.ELVNBR || this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.ELVINSPS) { this.checkboxELVNBR.setValue(true); }
			// Septic Systems
			if (this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EOACTL) { this.checkboxEOACTL.setValue(true); }

			// Electronic Data Liability
			if (this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EDLLMT) { this.checkboxEDLLMT.setValue(true); }

			// check if any additional insureds are checked
			let tmp = this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS;
			if (tmp.LSCNT || tmp.CNCNT || tmp.CICNT || tmp.OBCNT || tmp.MLCNT || tmp.SPCNT || tmp.STCNT || 
				tmp.VECNT || tmp.MTCNT || tmp.OWCNT || tmp.EACNT || tmp.POCNT || tmp.COCNT || tmp.GFCNT || 
				tmp.LECNT || tmp.ENCNT || tmp.GSCNT || tmp.CPCNT || tmp.OSCNT || tmp.GLCNT || tmp.IBCNT || tmp.CACNT) {
				this.checkboxAdditionalInsureds.setValue(true);
			}

		// now check each additional insured
		if (tmp.EACNT) { this.EACNT.setValue(true); }
		if (tmp.CNCNT) { this.checkboxCNCNT.setValue(true); }
		if (tmp.CICNT) { this.checkboxCICNT.setValue(true); }		
		if (tmp.OBCNT||tmp.ZZCNT) { this.checkboxOBCNT.setValue(true); 
		if (tmp.ZZCNT) {this.OBCNT.setValue(tmp.ZZCNT)} };
		if (tmp.MLCNT) { this.checkboxMLCNT.setValue(true); }
		if (tmp.SPCNT) { this.checkboxSPCNT.setValue(true); }
		if (tmp.STCNT) { this.checkboxSTCNT.setValue(true); }
		if (tmp.VECNT) { this.checkboxVECNT.setValue(true); }
		if (tmp.MTCNT) { this.checkboxMTCNT.setValue(true); }
		if (tmp.OWCNT) { this.checkboxOWCNT.setValue(true); }
		if (tmp.POCNT) { this.checkboxPOCNT.setValue(true); }
		if (tmp.COCNT) { this.checkboxCOCNT.setValue(true); }
		if (tmp.GFCNT) { this.checkboxGFCNT.setValue(true); }
		if (tmp.LECNT) { this.checkboxLECNT.setValue(true); }
		if (tmp.ENCNT) { this.checkboxENCNT.setValue(true); }
		if (tmp.WTCNT) { this.checkboxWTCNT.setValue(true); }

			// added 1-17-2019 by MAG
			if (tmp.GSCNT) { this.checkboxGSCNT.setValue(true); }

		    if (tmp.CPCNT||tmp.IXCNT) { this.checkboxCPCNT.setValue(true); }

			if (tmp.CACNT) { this.CACNT.setValue(true); }		

			// Short Term Pollution Coverage For Contractors
			if (this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.SHTPOL == 'Y') { this.SHTPOL.setValue(true); }		
		}
	}
}
