/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule, UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { TextMaskModule } from 'angular2-text-mask';
import { PipesModule } from '@pipes/pipes.module';
import { TooltipModule } from 'primeng/tooltip';
import { TabViewModule } from 'primeng/tabview';
import { PanelModule } from 'primeng/panel';
import { FieldsetModule } from 'primeng/fieldset';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { MIGCoverageLiabilityExtension } from './extension/extension.component';
import { MIGIncludeLiability } from './whats_included/include.liability.component';
import { MIGInputSwitchModule } from '@overridden/primeng-inputswitch/switch.module';
import { MIGAdditionalCoveragesLiability } from './coverage.liability.component';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';
import { MIGCalendarModule } from '@overridden/primeng-calendar/calendar.module';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { MIGMessageModule } from '@overridden/primeng-message/message.module';
import { MenuClass } from '@root/system/menu/menu';

@NgModule({
    imports: [
        MIGButtonModule,
        FieldsetModule,
        FormsModule,
        TabViewModule,
        CommonModule,
		FieldsetModule,
        PanelModule,
        MIGDropDownModule,
		TooltipModule,
		TextMaskModule,
		ReactiveFormsModule,
		MIGCheckboxModule,
		MIGInputtextModule,
		MIGInputSwitchModule,
		PipesModule,
		MIGDropDownModule,
		MIGCalendarModule,
		MIGMessageModule
    ],
    declarations: [
        MIGIncludeLiability,
        MIGCoverageLiabilityExtension,
		MIGAdditionalCoveragesLiability,

	],
    exports: [MIGAdditionalCoveragesLiability]
})
export class AdditionalCoveragesLiabilityModule {
	formGroup: UntypedFormGroup;
	constructor(
		public menuClass: MenuClass,
		private formBuilder: UntypedFormBuilder,
	) {
		this.formGroup = this.formBuilder.group({});

		menuClass.addMenuItem({
			name: 'AdditionalCoveragesLiability',
			label: 'Liability',
			color: "ui-steps-number-default",
			navSkip: false,
			active: false,
			hasError: false,
			errors: [],
			buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }, { button: "GetQuoteNow" }],
			forms:[this.formGroup],
			icon: "fa fa-user-shield",
			level: 2,
			block: [],
			visible: true,
			quote: "premium"
		});
	}
}
