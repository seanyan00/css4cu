
import { Validation } from '@classes/Common/ValidatorClass/Validation';


export class MIGLiabilityValidator extends Validation {
  constructor(){
    super();
  }
}
