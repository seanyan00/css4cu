/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule, UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { MIGOverlayPanelModule } from '@overridden/primeng-overlaypanel/overlay.module';
import { AddressInformationModule } from '@shared/address_info/address.module';
import { BusinessClassModule } from '@shared/business-class/business-class.module';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { MIGLocation } from '@CTRcomponents/location_summary/location_summary.component';
import { PropertyCoverageModule } from '@CTRcomponents/property-coverage/property-coverage.module';
import { ReportItemModule } from '@shared/report_item/report_item.module';
import { RiskAppetiteGuideModule } from '@shared/risk-appetite-guide/risk-appetite-guide.module';

import { MIGMessageModule } from '@overridden/primeng-message/message.module';
import { MIGInputSwitchModule } from '@overridden/primeng-inputswitch/switch.module';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { FieldsetModule } from 'primeng/fieldset';
//import { GrowlModule } from 'primeng/growl';
import { PanelModule } from 'primeng/panel';
import { TooltipModule } from 'primeng/tooltip';
import { ErrorModule } from '@shared/errors/errors.module';
import { PipesModule } from '@pipes/pipes.module';
import { MenuClass } from '@root/system/menu/menu';
import { MIGSystemService } from '@services/mig.service';
import { GLPLOCATION } from '@classes/CTR/GLLOCATION';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import * as _ from 'lodash';
import { ADDRESS } from '@root/shared_components/address_info/address.class';
import { DialogModule } from 'primeng/dialog';

@NgModule({
	imports: [
		PanelModule,
		FieldsetModule,
		MIGButtonModule,
		FormsModule,
		ConfirmDialogModule,
		CommonModule,
		ErrorModule,
		PipesModule,
		MIGOverlayPanelModule,
		TooltipModule,
		MIGDropDownModule,
        ReportItemModule, 
        //GrowlModule,
		RiskAppetiteGuideModule,
		PropertyCoverageModule,
		BusinessClassModule,
		AddressInformationModule,
		ReactiveFormsModule,
		MIGInputSwitchModule,
        MIGMessageModule,
        DialogModule
	],
	declarations: [MIGLocation],
	exports: [MIGLocation]
})
export class LocationSummaryModule {
	locationAddressFormGroup: UntypedFormGroup;
	PropertyCoverageFormGroup: UntypedFormGroup;
    homebuilderFormGroup: UntypedFormGroup;
    generalLiabilityClassListFormGroup: UntypedFormGroup;

	constructor(
		public menuClass: MenuClass,
		private formBuilder: UntypedFormBuilder,
		public migsystemservice: MIGSystemService
	) {	

		menuClass.addMenuItem({
			name: 'LocationSummary',
			label: 'Locations',
			color: "ui-steps-number-default",
			navSkip: true,
			active: false,
			hasError: false,
			errors: [],
			buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }, { button: "GetQuoteNow" }],
			icon: 'fa fa-globe-americas',
			block: [],
			visible: true,
			quote: "premium"
		});

		let loading = {
			name: 'LocationSummary',
			label: "Loading Data",
			sublabel: 'Please wait...',
			color: "ui-steps-number-danger",
			navSkip: true,
			active: false,
			hasError: false,
			errors: [],
			buttons: [],
			forms: [],
			icon: 'fa fa-map-pin',
			block: [],
			visible: true,
			locationId: parseInt("001"),
			level: 2
		}
		menuClass.addMenuItemAt(loading, "LocationSummary");

		this.migsystemservice.subscribeQuoteChanged().subscribe((quoteInfo: CTRQuote) => {
			this.respondToQuoteChanges(quoteInfo);
		})
    }
    
    respondToQuoteChanges(quoteInfo: CTRQuote)
    {
        let propertyCoverageFound: boolean = false;
        var currentStep = this.menuClass.stepActiveObject;
        var currentStepIndex = this.menuClass.stepActive;

        this.menuClass.ClearMenuItemAt("LocationSummary");
        let existingGlpLocationCount: number = quoteInfo.GLPENTITY.GLPLOCATIONS.length ? quoteInfo.GLPENTITY.GLPLOCATIONS.length : 0;
        let allExistingGLpLocationsDeleted: boolean = _.every(quoteInfo.GLPENTITY.GLPLOCATIONS, glpLocation => glpLocation.RECORDSTATE == 'D');
        if ((existingGlpLocationCount == 0) || (allExistingGLpLocationsDeleted))
        {
            return this.noExistingGlpLocations(quoteInfo);
        }

        quoteInfo.GLPENTITY.GLPLOCATIONS = _.sortBy(quoteInfo.GLPENTITY.GLPLOCATIONS, (glpLocation) => { return parseInt(glpLocation.LOCNUM)});
        // lets build our list of addresses
        for (let i = 0; i < existingGlpLocationCount; i++) {
            
            if (quoteInfo.GLPENTITY.GLPLOCATIONS[i].RECORDSTATE == "D") {
                continue; // skip this iteration
            }

            //we clear out the formGroups to ensure we are only passing the appropraite instance of these form groups for this location
            //instead of the entire array for each location	
            this.PropertyCoverageFormGroup = null;
            this.locationAddressFormGroup = null;
            
            // just to shorten things up a bit
            let addr = new ADDRESS(quoteInfo.GLPENTITY.GLPLOCATIONS[i].ADDRESS);
            let locnum = quoteInfo.GLPENTITY.GLPLOCATIONS[i].LOCNUM;
            let buildings = 0;
            let existingCfpLocationCount: number = quoteInfo.CFPENTITY.CFPLOCATIONS.length ? quoteInfo.CFPENTITY.CFPLOCATIONS.length : 0;
            
            for (let i = 0; i < existingCfpLocationCount; i++) {
                if (quoteInfo.CFPENTITY.CFPLOCATIONS[i].RECORDSTATE == "D")
                {
                    continue; // skip this iteration
                }

                let cfplocnum = quoteInfo.CFPENTITY.CFPLOCATIONS[i].LOCNUM;
                if (cfplocnum == locnum) {
                    buildings++;
                    propertyCoverageFound = true;
                    this.PropertyCoverageFormGroup = this.formBuilder.group({});
                }
            }
            
            
            this.locationAddressFormGroup = this.formBuilder.group({});
            this.homebuilderFormGroup = this.formBuilder.group({});
            this.generalLiabilityClassListFormGroup = this.formBuilder.group({});

            let menuLabel:string;
            if(quoteInfo.QUOTEPOLICYINFORMATION.TRANSACTIONTYPE != "PI"){
                menuLabel = addr.STREETNUMBER + " " + addr.STREETNAME;
            } 
            else{
                menuLabel = quoteInfo.GLPENTITY.GLPLOCATIONS[i].LOCATN
            }
            if (addr.isBlankAddress() && quoteInfo.QUOTEPOLICYINFORMATION.TRANSACTIONTYPE !="PI")
            {
                menuLabel = "New Location";
            }
            let data = {
                name: 'LocationSummary',
                label: menuLabel,
                sublabel: '<small>' + buildings + ' Building' + (buildings == 1 ? '' : 's') + '</small>',
                color: "ui-steps-number-default",
                navSkip: false,
                active: false,
                hasError: false,
                errors: [],
                buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }, { button: "GetQuoteNow" }],

                //we only add the homebuilderFormGroup if it is the first location because this question doesn't exist on subsequent locations
                forms: i === 0 ? [this.locationAddressFormGroup, this.PropertyCoverageFormGroup, this.generalLiabilityClassListFormGroup, this.homebuilderFormGroup] : 
                [this.locationAddressFormGroup, this.PropertyCoverageFormGroup, this.generalLiabilityClassListFormGroup],
                icon: 'fa fa-map-pin',
                block: [],//[{ text: "Loading Data", success: false, icon: 'fa-spinner' }],
                visible: true,
                locationId: parseInt(locnum),
                level: 2,
                fromWins: true,
                quote: "premium"
            };
            this.menuClass.addMenuItemAt(data, "LocationSummary");
        }
		
        if(currentStep.name == "LocationSummary"){ // 2/4/22: If we are on the location screen when we save, we want to go to the menu step of the state we were currently on -JTL
            this.menuClass.gotoStep(currentStepIndex);
        }
        this.menuClass.UpdateMenu();
        this.menuClass.ShowHideMenuItemAt(propertyCoverageFound, "AdditionalCoveragesProperty");
    }

    noExistingGlpLocations(quoteInfo: CTRQuote)
    {
        // no GLPLOCATIONS exist
        // We need at least 1
        // if (!quoteInfo.GLPENTITY) { quoteInfo.GLPENTITY = new GLPEntity(); }
        quoteInfo.GLPENTITY.GLPLOCATIONS.push(new GLPLOCATION());
        quoteInfo.GLPENTITY.GLPLOCATIONS[0].LOCNUM = "001";
        quoteInfo.GLPENTITY.GLPLOCATIONS[0].BLDNUM = "001";

        // make sure there is at least something in the address
        // before trying to copy it over
        quoteInfo.GLPENTITY.GLPLOCATIONS[0].ADDRESS = new ADDRESS();

        this.locationAddressFormGroup = this.formBuilder.group({});
        let data = {
            name: 'LocationSummary',
            label: "New Location",
            sublabel: '<small>0 buildings</small>',
            color: "ui-steps-number-default",
            navSkip: false,
            active: false,
            hasError: false,
            errors: [],
            buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }, { button: "GetQuoteNow" }],
            forms: [this.locationAddressFormGroup, this.formBuilder.group({}), this.formBuilder.group({}), this.formBuilder.group({})],
            icon: 'fa fa-map-pin',
            block: [],//[{ text: "Loading Data", success: false, icon: 'fa-spinner' }],
            visible: true,
            locationId: parseInt("001"),
            level: 2,
            fromWins: false,
            quote: "premium"

        };
        this.menuClass.addMenuItemAt(data, "LocationSummary");
    }
}
