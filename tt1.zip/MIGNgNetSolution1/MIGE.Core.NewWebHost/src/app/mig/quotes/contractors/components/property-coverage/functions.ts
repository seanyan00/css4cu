// load data needed for dropdowns in property coverage
export function funcLoadDropdownData(options) {
    let ret = [];
    switch (options) {
        
    }

    return ret;
}