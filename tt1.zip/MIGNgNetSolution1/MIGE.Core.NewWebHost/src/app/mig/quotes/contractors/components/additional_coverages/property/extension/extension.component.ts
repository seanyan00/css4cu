import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, UntypedFormControl, SelectControlValueAccessor } from '@angular/forms';
import { Subscription } from 'rxjs/internal/Subscription';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { Functions } from '@helpers/functions';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { MIGPropertyResources } from './extension.resources';
import { MIGSystemService } from '@services/mig.service';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { InputMasksClass } from '@helpers/masks';
import { CFPCOVERAGES } from '@classes/CTR/CFPCOVERAGES';
import { ContractorsTooltips } from '@helpers/tooltips';
import { MenuClass } from '@root/system/menu/menu';
import { MIGLiabilityValidator } from '@CTRcomponents/additional_coverages/inland/extension/liability.validator';

@Component({
	selector: 'mig-coverage-property-extension',
	templateUrl: './extension.component.html',
})

export class MIGCoveragePropertyExtension implements OnInit, OnDestroy {
	ngOnDestroy(): void {
		if(this.FormGroupSubscription)this.FormGroupSubscription.unsubscribe();
		if(this.updateRecordStateSubscription) this.updateRecordStateSubscription.unsubscribe();
	}
	visProperty: boolean = false; 
	formBuilder: UntypedFormBuilder;
	formChanged: boolean = false;
	
	FormGroupSubscription: Subscription;
	updateRecordStateSubscription: Subscription;
	migLiabilityValidator: MIGLiabilityValidator;
	migPropertyResources = new MIGPropertyResources();
	showHideDebrisRemoval: boolean = false;
	resetForm: boolean = false;

	@Input() ctrQuote: CTRQuote;
	@Input() formGroup: UntypedFormGroup;

	constructor(
		public func: Functions,
		public contractorsDropDowns: ContractorsDropDowns,
		public contractorsTooltips: ContractorsTooltips,
		public migsystemservice: MIGSystemService,
		public migRoles: MIGSecurityRoles,
		public masks: InputMasksClass,
		public menuClass: MenuClass
	) {
		if (this.formBuilder == null) {
			this.formBuilder = new UntypedFormBuilder();
		}
		this.migLiabilityValidator = new MIGLiabilityValidator();
		
	}

	get SUPPTY() {return this.formGroup.get("SUPPTY"); }
	get checkboxACRON() { return this.formGroup.get("checkboxACRON"); }
	get dropdownACRON() { return this.formGroup.get("dropdownACRON"); }
	get ACRON() { return this.formGroup.get("ACRON"); }
	get ACROF() { return this.formGroup.get("ACROF"); }

	get checkboxBPPTMP() { return this.formGroup.get("checkboxBPPTMP"); }
	get BPPTMP() { return this.formGroup.get("BPPTMP"); }

	get checkboxCOMEQP() { return this.formGroup.get("checkboxCOMEQP"); }
	get COMEQP() { return this.formGroup.get("COMEQP"); }

	get checkboxDBRRMV() { return this.formGroup.get("checkboxDBRRMV"); }
	get DBRRMV() { return this.formGroup.get("DBRRMV"); }

	// get checkboxEDLLMT() { return this.formGroup.get("checkboxEDLLMT"); }
	// get EDLLMT() { return this.formGroup.get("EDLLMT"); }
	get checkboxEDPELM() { return this.formGroup.get("checkboxEDPELM"); }
	get EDPELM() { return this.formGroup.get("EDPELM"); }

	get checkboxETFTLM() { return this.formGroup.get("checkboxETFTLM"); }
	get ETFTLM() { return this.formGroup.get("ETFTLM"); }
	//added
	get RATEMP() { return this.formGroup.get("RATEMP"); }

	get checkboxFALTLM() { return this.formGroup.get("checkboxFALTLM"); }
	get FALTLM() { return this.formGroup.get("FALTLM"); }

	get checkboxMNSILM() { return this.formGroup.get("checkboxMNSILM"); }
	get dropdownMNSILM() { return this.formGroup.get("dropdownMNSILM"); }
	get MNSILM() { return this.formGroup.get("MNSILM"); }
	get MNSOLM() { return this.formGroup.get("MNSOLM"); }

	get checkboxOUTPRP() { return this.formGroup.get("checkboxOUTPRP"); }
	get OUTPRP() { return this.formGroup.get("OUTPRP"); }

	get checkboxOUTSNL() { return this.formGroup.get("checkboxOUTSNL"); }
	get OUTSNL() { return this.formGroup.get("OUTSNL"); }

	
	get checkboxVLPONL() { return this.formGroup.get("checkboxVLPONL"); }
	get dropdownVLPONL() { return this.formGroup.get("dropdownVLPONL"); }
	get VLPONL() { return this.formGroup.get("VLPONL"); }
	get VLPOFL() { return this.formGroup.get("VLPOFL"); }

	ngOnInit() {
		document.getElementById('propertyForm').scrollTop;
		let cfpCov: CFPCOVERAGES;
		
		if(!this.ctrQuote.CFPENTITY.CFPCOVERAGES.POLICY && !this.ctrQuote.CFPENTITY.CFPCOVERAGES.EFFDTE){
			this.ctrQuote.CFPENTITY.CFPCOVERAGES = new CFPCOVERAGES(this.ctrQuote.QUOTEPOLICYINFORMATION);
		}
		cfpCov = this.ctrQuote.CFPENTITY.CFPCOVERAGES;
		
		//let impLoc = this.ctrQuote.IMPENTITY.IMPLOCATIONS;
		let policyLiabLim = this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS;

		if(!this.resetForm) {
			this.formGroup.addControl('SUPPTY', new UntypedFormControl({ value: true, disabled: true })); 
			//console.log('cfpCov? ', cfpCov);
			//  Accounts Recievable
			this.formGroup.addControl('checkboxACRON', new UntypedFormControl({ value: true, disabled: true }));
			this.formGroup.addControl('dropdownACRON', new UntypedFormControl(cfpCov.ACRON !=0 ? cfpCov.ACRON : this.contractorsDropDowns.defaultACRON));
			this.formGroup.addControl('ACRON', new UntypedFormControl(0));
			this.formGroup.addControl('ACROF', new UntypedFormControl(10000));

			// Business personal property
			this.formGroup.addControl('checkboxBPPTMP', new UntypedFormControl({ value: true, disabled: true }));
			this.formGroup.addControl('BPPTMP', new UntypedFormControl(cfpCov.BPPTMP ? cfpCov.BPPTMP : this.contractorsDropDowns.defaultBPPTMP));

			// Communication Equipment
			this.formGroup.addControl('checkboxCOMEQP', new UntypedFormControl({ value: true, disabled: true }));
			this.formGroup.addControl('COMEQP', new UntypedFormControl(cfpCov.COMEQP ? cfpCov.COMEQP : this.contractorsDropDowns.defaultCOMEQP));

			// Debris Removal 25% Building Plus
			this.formGroup.addControl('checkboxDBRRMV', new UntypedFormControl({ value: true, disabled: true }));
			this.formGroup.addControl('DBRRMV', new UntypedFormControl(cfpCov.DBRRMV ? cfpCov.DBRRMV : this.contractorsDropDowns.defaultACPDBRRMV));

			// Electronic Data Processing Equipment
			// this.formGroup.addControl('checkboxEDLLMT', new FormControl({ value: true, disabled: true }));
			// this.formGroup.addControl('EDLLMT', new FormControl((policyLiabLim.EDLLMT ? policyLiabLim.EDLLMT : this.contractorsDropDowns.defaultACPEDLLMT)));
			this.formGroup.addControl('checkboxEDPELM', new UntypedFormControl({ value: true, disabled: true }));
			this.formGroup.addControl('EDPELM', new UntypedFormControl(cfpCov.EDPELM ? cfpCov.EDPELM : this.contractorsDropDowns.defaultEDPELM));

			// Employee Theft
			this.formGroup.addControl('checkboxETFTLM', new UntypedFormControl({ value: true, disabled: true }));
			this.formGroup.addControl('ETFTLM', new UntypedFormControl(cfpCov.ETFTLM ? cfpCov.ETFTLM : this.contractorsDropDowns.defaultETFTLM));
			//added
			this.formGroup.addControl('RATEMP', new UntypedFormControl(cfpCov.RATEMP ? cfpCov.RATEMP : 0, cfpCov.ETFTLM>50000? this.migLiabilityValidator.ValidateRequired('RATEMP', 'Number of Employees',true):null));

			// Forgery or Alteration
			this.formGroup.addControl('checkboxFALTLM', new UntypedFormControl({ value: true, disabled: true }));
			this.formGroup.addControl('FALTLM', new UntypedFormControl(cfpCov.FALTLM ? cfpCov.FALTLM : this.contractorsDropDowns.defaultFALTLM));

			// Money and Securities - Inside the Premises/Outside the Premises
			this.formGroup.addControl('checkboxMNSILM', new UntypedFormControl({ value: true, disabled: true }));
			this.formGroup.addControl('dropdownMNSILM', new UntypedFormControl(cfpCov.MNSILM ? cfpCov.MNSILM : this.contractorsDropDowns.defaultMNSILM));
			this.formGroup.addControl('MNSILM', new UntypedFormControl(0));
			this.formGroup.addControl('MNSOLM', new UntypedFormControl(10000));

			// Outdoor Property
			this.formGroup.addControl('checkboxOUTPRP', new UntypedFormControl({ value: true, disabled: true }));
			this.formGroup.addControl('OUTPRP', new UntypedFormControl(cfpCov.OUTPRP ? cfpCov.OUTPRP : this.contractorsDropDowns.defaultOUTPRP));

			// Outdoor Signs
			this.formGroup.addControl('checkboxOUTSNL', new UntypedFormControl({ value: true, disabled: true }));
			this.formGroup.addControl('OUTSNL', new UntypedFormControl(cfpCov.OUTSNL ? cfpCov.OUTSNL : this.contractorsDropDowns.defaultOUTSNL));

			// Valuable Papers - On Premises / Off Premises
			this.formGroup.addControl('checkboxVLPONL', new UntypedFormControl({ value: true, disabled: true }));
			this.formGroup.addControl('dropdownVLPONL', new UntypedFormControl(cfpCov.VLPONL ? cfpCov.VLPONL : this.contractorsDropDowns.defaultVLPONL));
			this.formGroup.addControl('VLPONL', new UntypedFormControl(this.contractorsDropDowns.defaultVLPONL));
			this.formGroup.addControl('VLPOFL', new UntypedFormControl(10000));
		}else { //reset the form
			this.SUPPTY ? this.SUPPTY.setValue({ value: true, disabled: true }) : this.formGroup.addControl('SUPPTY', new UntypedFormControl({ value: true, disabled: true })); 
			//  Accounts Recievable
			this.checkboxACRON ? this.checkboxACRON.setValue({ value: true, disabled: true }) : this.formGroup.addControl('checkboxACRON', new UntypedFormControl({ value: true, disabled: true }));
			this.dropdownACRON ? this.dropdownACRON.setValue(this.contractorsDropDowns.defaultACRON) : this.formGroup.addControl('dropdownACRON', new UntypedFormControl(( this.contractorsDropDowns.defaultACRON)));
			this.ACRON ? this.ACRON.setValue(0) : this.formGroup.addControl('ACRON', new UntypedFormControl(0));
			this.ACROF ? this.ACROF.setValue(0) : this.formGroup.addControl('ACROF', new UntypedFormControl(0));
	
			// Business personal property
			this.checkboxBPPTMP ? this.checkboxBPPTMP.setValue({ value: true, disabled: true }) : this.formGroup.addControl('checkboxBPPTMP', new UntypedFormControl({ value: true, disabled: true }));
			this.BPPTMP ? this.BPPTMP.setValue(this.contractorsDropDowns.defaultBPPTMP) : this.formGroup.addControl('BPPTMP', new UntypedFormControl((this.contractorsDropDowns.defaultBPPTMP)));
	
			// Communication Equipment
			this.checkboxCOMEQP ? this.checkboxCOMEQP.setValue({ value: true, disabled: true }) : this.formGroup.addControl('checkboxCOMEQP', new UntypedFormControl({ value: true, disabled: true }));
			this.COMEQP ? this.COMEQP.setValue(this.contractorsDropDowns.defaultCOMEQP) :  this.formGroup.addControl('COMEQP', new UntypedFormControl((this.contractorsDropDowns.defaultCOMEQP)));
	
			// Debris Removal 25% Building Plus
			this.checkboxDBRRMV ? this.checkboxDBRRMV.setValue({ value: true, disabled: true }) : this.formGroup.addControl('checkboxDBRRMV', new UntypedFormControl({ value: true, disabled: true }));
			this.DBRRMV ? this.DBRRMV.setValue(this.contractorsDropDowns.defaultACPDBRRMV) :  this.formGroup.addControl('DBRRMV', new UntypedFormControl((this.contractorsDropDowns.defaultACPDBRRMV)));
	
			// Electronic Data Processing Equipment
			// this.formGroup.addControl('checkboxEDLLMT', new FormControl({ value: true, disabled: true }));
			// this.formGroup.addControl('EDLLMT', new FormControl((policyLiabLim.EDLLMT ? policyLiabLim.EDLLMT : this.contractorsDropDowns.defaultACPEDLLMT)));
			this.checkboxEDPELM ? this.checkboxEDPELM.setValue({ value: true, disabled: true }) : this.formGroup.addControl('checkboxEDPELM', new UntypedFormControl({ value: true, disabled: true }));
			this.EDPELM ? this.EDPELM.setValue(this.contractorsDropDowns.defaultEDPELM) : this.formGroup.addControl('EDPELM', new UntypedFormControl((this.contractorsDropDowns.defaultEDPELM)));
	
			// Employee Theft
			this.checkboxETFTLM ? this.checkboxETFTLM.setValue({ value: true, disabled: true }) : this.formGroup.addControl('checkboxETFTLM', new UntypedFormControl({ value: true, disabled: true }));
			this.ETFTLM ? this.ETFTLM.setValue(this.contractorsDropDowns.defaultETFTLM):  this.formGroup.addControl('ETFTLM', new UntypedFormControl(this.contractorsDropDowns.defaultETFTLM));
			//added
			this.RATEMP ? this.RATEMP.setValue(0):  this.formGroup.addControl('RATEMP', new UntypedFormControl(0, this.ETFTLM.value>50000 ? this.migLiabilityValidator.ValidateRequired('RATEMP', 'Number of Employees'):null));
	
			// Forgery or Alteration
			this.checkboxFALTLM ? this.checkboxFALTLM.setValue({ value: true, disabled: true }) : this.formGroup.addControl('checkboxFALTLM', new UntypedFormControl({ value: true, disabled: true }));
			this.FALTLM ? this.FALTLM.setValue(this.contractorsDropDowns.defaultFALTLM) : this.formGroup.addControl('FALTLM', new UntypedFormControl((this.contractorsDropDowns.defaultFALTLM)));
	
			// Money and Securities - Inside the Premises/Outside the Premises
			this.checkboxMNSILM ? this.checkboxMNSILM.setValue({ value: true, disabled: true }) :  this.formGroup.addControl('checkboxMNSILM', new UntypedFormControl({ value: true, disabled: true }));
			this.dropdownMNSILM ? this.dropdownMNSILM.setValue(this.contractorsDropDowns.defaultMNSILM) : this.formGroup.addControl('dropdownMNSILM', new UntypedFormControl((this.contractorsDropDowns.defaultMNSILM)));
			this.MNSILM ? this.MNSILM.setValue(0) : this.formGroup.addControl('MNSILM', new UntypedFormControl(0));
			this.MNSOLM ? this.MNSOLM.setValue(0) : this.formGroup.addControl('MNSOLM', new UntypedFormControl(0));
	
			// Outdoor Property
			this.checkboxOUTPRP ? this.checkboxOUTPRP.setValue({ value: true, disabled: true }) : this.formGroup.addControl('checkboxOUTPRP', new UntypedFormControl({ value: true, disabled: true }));
			this.OUTPRP ? this.OUTPRP.setValue(this.contractorsDropDowns.defaultOUTPRP) : this.formGroup.addControl('OUTPRP', new UntypedFormControl((this.contractorsDropDowns.defaultOUTPRP)));
	
			// Outdoor Signs
			this.checkboxOUTSNL ? this.checkboxOUTSNL.setValue({ value: true, disabled: true }) : this.formGroup.addControl('checkboxOUTSNL', new UntypedFormControl({ value: true, disabled: true }));
			this.OUTSNL ? this.OUTSNL.setValue(this.contractorsDropDowns.defaultOUTSNL) : this.formGroup.addControl('OUTSNL', new UntypedFormControl((this.contractorsDropDowns.defaultOUTSNL)));
	
			// Valuable Papers - On Premises / Off Premises
			this.checkboxVLPONL ? this.checkboxVLPONL.setValue({ value: true, disabled: true }) : this.formGroup.addControl('checkboxVLPONL', new UntypedFormControl({ value: true, disabled: true }));
			this.dropdownVLPONL ? this.dropdownVLPONL.setValue(this.contractorsDropDowns.defaultVLPONL) :  this.formGroup.addControl('dropdownVLPONL', new UntypedFormControl((this.contractorsDropDowns.defaultVLPONL)));
			this.VLPONL ? this.VLPONL.setValue(this.contractorsDropDowns.defaultVLPONL) : this.formGroup.addControl('VLPONL', new UntypedFormControl(this.contractorsDropDowns.defaultVLPONL));
			this.VLPOFL ? this.VLPOFL.setValue(10000) : this.formGroup.addControl('VLPOFL', new UntypedFormControl(10000));
		}

		this.FormGroupSubscription = this.formGroup.valueChanges.pipe(debounceTime(100), distinctUntilChanged()).subscribe(data => {
			data = this.formGroup.getRawValue();

			if (this.formGroup.dirty) {
				this.menuClass.isQuoteDirty = true;
			}
			//let dropdownACRON = this.migPropertyResources.processSplitList(data.dropdownACRON);
			this.ctrQuote.CFPENTITY.CFPCOVERAGES.ACRON = this.func.justNumbers(data.dropdownACRON ? data.dropdownACRON : 0);
			this.ctrQuote.CFPENTITY.CFPCOVERAGES.ACROF = 10000
			//this.ctrQuote.CFPENTITY.CFPCOVERAGES.ACRON = this.func.justNumbers(dropdownACRON[0] ? dropdownACRON[0] : 0);
			//this.ctrQuote.CFPENTITY.CFPCOVERAGES.ACROF = this.func.justNumbers(dropdownACRON[1] ? dropdownACRON[1] : 0);//<=default this in the form builder
			

			//let dropdownMNSILM = this.migPropertyResources.processSplitList(data.dropdownMNSILM);
			this.ctrQuote.CFPENTITY.CFPCOVERAGES.MNSILM = this.func.justNumbers(data.dropdownMNSILM ? data.dropdownMNSILM : 0);
			this.ctrQuote.CFPENTITY.CFPCOVERAGES.MNSOLM = 10000;
			//this.ctrQuote.CFPENTITY.CFPCOVERAGES.MNSILM = this.func.justNumbers(dropdownMNSILM[0] ? dropdownMNSILM[0] : 0);
			//this.ctrQuote.CFPENTITY.CFPCOVERAGES.MNSOLM = this.func.justNumbers(dropdownMNSILM[1] ? dropdownMNSILM[1] : 0);

			//let dropdownVLPONL = this.migPropertyResources.processSplitList(data.dropdownVLPONL);
			this.ctrQuote.CFPENTITY.CFPCOVERAGES.VLPONL = this.func.justNumbers(data.dropdownVLPONL ? data.dropdownVLPONL : 0);
			this.ctrQuote.CFPENTITY.CFPCOVERAGES.VLPOFL = 10000;

			this.ctrQuote.CFPENTITY.CFPCOVERAGES.BPPTMP = data.BPPTMP ? data.BPPTMP : 0;
			this.ctrQuote.CFPENTITY.CFPCOVERAGES.COMEQP = data.COMEQP ? data.COMEQP : 0;
			this.ctrQuote.CFPENTITY.CFPCOVERAGES.DBRRMV = data.DBRRMV ? data.DBRRMV : 0;
			// this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EDLLMT = data.EDLLMT ? data.EDLLMT : 0;
			this.ctrQuote.CFPENTITY.CFPCOVERAGES.EDPELM = data.EDPELM ? data.EDPELM : 0;
			this.ctrQuote.CFPENTITY.CFPCOVERAGES.ETFTLM = data.ETFTLM ? data.ETFTLM : 0;
			if(data.ETFTLM>50000){
				this.RATEMP.setValidators(
					[this.migLiabilityValidator.ValidateRequired('RATEMP', 'Number of Employees required when over $50,000',true)
				]);
			} else {
				this.RATEMP.clearValidators();
			}
			this.RATEMP.updateValueAndValidity({emitEvent:false});
			//added
			this.ctrQuote.CFPENTITY.CFPCOVERAGES.RATEMP = data.RATEMP ? data.RATEMP : 0;
			this.ctrQuote.CFPENTITY.CFPCOVERAGES.FALTLM = data.FALTLM ? data.FALTLM : 0;
			this.ctrQuote.CFPENTITY.CFPCOVERAGES.OUTPRP = data.OUTPRP ? data.OUTPRP : 0;
			this.ctrQuote.CFPENTITY.CFPCOVERAGES.OUTSNL = data.OUTSNL ? data.OUTSNL : 0;

			this.formChanged = true;
			//update any errors on the form
			this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive);
		});
		this.migPropertyResources.setCTRQuote(this.ctrQuote);
		this.showHideDebrisRemoval = this.migPropertyResources.processDebrisRemoval();

		this.updateRecordStateSubscription = this.migsystemservice.subscribeUpdateRecordState().subscribe(() => {

			if (this.formChanged) {
				// this.ctrQuote.IMPENTITY.IMPLOCATIONS.POLICY = this.ctrQuote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
				// this.ctrQuote.IMPENTITY.IMPLOCATIONS.EFFDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
				// this.ctrQuote.IMPENTITY.IMPLOCATIONS.TRANS = this.ctrQuote.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;
				// this.ctrQuote.IMPENTITY.IMPLOCATIONS.RCDTYP = this.ctrQuote.QUOTEPOLICYINFORMATION.RECORDTYPE;
				// this.ctrQuote.IMPENTITY.IMPLOCATIONS.EDSDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;
				//this.ctrQuote.IMPENTITY.IMPLOCATIONS.RECORDSTATE = "U";
				this.ctrQuote.CFPENTITY.CFPCOVERAGES.POLICY = this.ctrQuote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
				this.ctrQuote.CFPENTITY.CFPCOVERAGES.EFFDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
				this.ctrQuote.CFPENTITY.CFPCOVERAGES.TRANS = this.ctrQuote.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;
				this.ctrQuote.CFPENTITY.CFPCOVERAGES.RCDTYP = this.ctrQuote.QUOTEPOLICYINFORMATION.RECORDTYPE;
				this.ctrQuote.CFPENTITY.CFPCOVERAGES.EDSDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;
				this.ctrQuote.CFPENTITY.CFPCOVERAGES.RECORDSTATE = "U";
				
			}
		});
	}
}
