import { AbstractControl, UntypedFormControl, Validators, FormGroup } from "@angular/forms";

import { AppErrors } from '@root/shared_components/errors/app-errors';
import { Validation } from '@classes/Common/ValidatorClass/Validation';

export class MIGValidatorPropertyCoverage extends Validation {
	errors: AppErrors 
	constructor() {
		super();
	}

	validateBLDLM1_BPPLM1 = (fld1: string, fld2: string) => {
		return (control: UntypedFormControl) => {
			//console.log("fld1: " + fld1);
			//console.log("fld2: " + fld2);
			if (fld1 || fld2)  return { severity: "error",  summary: 'BLDLM1', detail: "Building Limit and or Business Personal Limit" + " is required" , sticky: true, closable: false};
			return null;
		}
	}

	oneOfControlRequired = (...controls: AbstractControl[]) => {
		return (control: AbstractControl) => {
			for (const aControl of controls) {
			  if (!Validators.required(aControl)) {
				return null;
			  }
			}
			return { oneOfRequired: true };
		 };
	}


	
}
