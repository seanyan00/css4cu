/* **************************************************************************************************
* COMPONENT DESCRIPTION  - Handle file upload via a modal window
* AS400 LIBRARY          - N/A
* TABLE/FILENAME         - N/A
*
* DATE CREATED           - N/A
* AUTHOR                 - MAG
* VERSION                - 1.0
* CODE GENERATION        - N/A
*
* Of all components in this system, this component is by far the most complicated
* We are taking in 3 individual arrays consisting of
* GLPENTITY.GLPLOCATIONS
* CFPENTITY.CFPLOCATIONS
* GLENTITY.GLCLASSLIST
*
* After the constructor boilerplate, ngOnInit takes over
* we first get which menu item is active
* Our menu item has our LOCNUM in it - because the menu controls the show,
* we can trust that this LOCNUM is correct
* Next we check to see if the fromWins property is set on the menu item
* this tells us if we can just delete the location from the array (fromWins == false)
* or if we need to set the RECORDSTATE = "D" (fromWins == true)
* Next we load our reactive form groups
* store our LOCNUM in a local property (this.paddedLocationID)
* and proceed to load our data (funcGatherData)
*
* funcGatherData loops through our ctrQuote and... gathers our data
* first checking to make sure our paddedLocationID is correct
* next initiallizing local variables to store our data (this.GLPLOCATIONS, this.associatedCFPLocations and this.GLCLASSLIST)
* this are used simply for tracking purposes
* Next we loop though GLPENTITY.GLPLOCATIONS and set our array index
* we need this when saving data to ctrQuote when a RECORDSTATE has been set to D
* Next we load our data into our local arrays and populate our form groups
* back in ngOnInit execute a changeDetectionRef.detectChanges() just to be sure
* and control is given back to the user


****************************************************************************************************/

import { ChangeDetectorRef, Component, Input, OnDestroy, OnInit, ViewEncapsulation, Inject } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, UntypedFormControl} from '@angular/forms';
import { GLPLOCATION } from '@classes/CTR/GLLOCATION';
import { CFPLOCATION } from '@classes/CTR/CFPLOCATION';
import { MIGLocationSummaryValidator } from '@CTRcomponents/location_summary/location_summary.validators';
import { ConfirmationService } from 'primeng/api';
import { MIGSystemService } from '@services/mig.service';
import { MenuClass } from '@root/system/menu/menu';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { Functions } from '@helpers/functions';
import { ADDRESS, ADDRESSTERRITORY } from '@shared/address_info/address.class';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { GLClasses } from '@classes/CTR/GLCLASSES';
import { Subscription } from 'rxjs';
import { distinctUntilChanged } from 'rxjs/operators';
import { DOCUMENT } from "@angular/common";
import * as _ from 'lodash';
import { MIGBusinessClassValidators } from '@root/shared_components/business-class/business-class.validators';


@Component({
	selector: 'mig-location',
	templateUrl: './location_summary.component.html',
	styleUrls: ['location_summary.component.css'],
	encapsulation: ViewEncapsulation.None,
	providers: [ConfirmationService]
})



export class MIGLocation implements OnInit, OnDestroy {
	// @ViewChild(RiskAppetiteGuideComponent) RAGComponent: RiskAppetiteGuideComponent;
	// @ViewChild(MIGPropertyCoverage) MIGPropertyCoverage: MIGPropertyCoverage;
	// @ViewChild(OverlayPanel) businessClassPanel: OverlayPanel;
	// @ViewChild("PropertyCoveragePanel") PropertyCoveragePanel: OverlayPanel;
	// @ViewChild(MIGPropertyCoverage) PropertyCoverageComponent: MIGPropertyCoverage;

	formGroup: UntypedFormGroup;

	// for local
	@Input() locationID: number;
	//@Input() addressFormGroup: FormGroup;

	// for WINS
	paddedLocationID: string;

	// Index of current GLLocation
	GLPLOCATIONSINDEX: number = 0;

	// are we adding property coverage or editing it
	@Input() mode: string = "new";

	// an array to hold our formgroups
	locationAddressFormGroup: any[];

	// property coverage form group
	PropertyCoverageFormGroup: any[] = [];

	// we need effective date and other properties from CRTQuote
	//@Input() ctrQuote: any;
	@Input() ctrQuote: CTRQuote;

	// an index for new property coverage
	newPropertyCoverage: number = 0;

	// setup form builder
	formBuilder: UntypedFormBuilder;

	//home builders question
    homeBuilderFormGroup: UntypedFormGroup = null;
    businessClassFormGroup: UntypedFormGroup;

	// validators
	migLocationSummaryValidator: MIGLocationSummaryValidator;

	// show or hide add property coverage
	showAddPropertyCoverage: boolean = false;

	// local array to hold GLPLocations
	GLPLOCATIONS: {};

	// Local array to hold Property Coverages
	associatedCFPLocations: CFPLOCATION[] = [];

	// Local array to hold GLClasses
	GLCLASSLIST: any[] = [];

	fromWins: boolean = false;

    loading: boolean = true;
	editMode: boolean = false;
	saveLocationClicked: boolean = false;
    CFPTerritoryInfoAvailable: boolean = false;
    CFPTerritoryInfo: ADDRESSTERRITORY = null;
	homeBuilderFormSubscription: Subscription;
	stepName: string = '';
	panelAddress: boolean = false;
	mailingAddress: boolean = false;
	fireDistrictsArray: any[] = [];
	territoryArray: any[] =[];
	classesAandB: string = '';
	getTerritoryCode: boolean = false;
	stopQuote: boolean = true;
    businessClassValidators: MIGBusinessClassValidators;
	stopQuoteMsg: string = 'Thank you for your interest in Merchants.  Unfortunately, this risk does not meet our underwriting guidelines:  Insured works in the capacity of a General Contractor or Homebuilder.';
	display: boolean;
	nextClicked: boolean; 

    constructor
    (
        @Inject(DOCUMENT) public document: Document,
		public menuClass: MenuClass,
		public migRoles: MIGSecurityRoles,
		public migsystemservice: MIGSystemService,
		public changeDetectionRef: ChangeDetectorRef,
		public confirmationService: ConfirmationService,
		public confirmationServiceAddress: ConfirmationService,
		private func: Functions
    )
    {
		this.migLocationSummaryValidator = new MIGLocationSummaryValidator();
        this.formBuilder = new UntypedFormBuilder();
		this.businessClassValidators = new MIGBusinessClassValidators();

	}

	ngOnDestroy() {
		// fringe case where we've been here before, clicked add property coverage, but hit back and stopnavigation was still true
		this.menuClass.stopNavigation = false;
		//this.migsystemservice.notifyStepChanged(null);
		this.PropertyCoverageFormGroup = [];
		this.locationAddressFormGroup = [];
		if(this.homeBuilderFormSubscription) this.homeBuilderFormSubscription.unsubscribe();
		this.changeDetectionRef.detach();	
	}


	get HOMBLD() { return this.homeBuilderFormGroup.get("HOMBLD"); }

	ngOnInit() {
		let menu = this.menuClass.stepActiveObject;
		this.paddedLocationID = this.func.lpad(menu.locationId, "0", 3);
		this.fromWins = menu.fromWins;

		//set up the form groups
		this.setFormGroups(menu);
		
		if (!this.paddedLocationID) { this.paddedLocationID = "001"; }

		// get our data for this lOCNUM
		this.funcGatherData(this.locationID);

		// because we're sharing the address component with quote info
		// we have to reset the formBuilder when we get here
		this.formBuilder = new UntypedFormBuilder();
		
		this.getTerritoryCode = true;
	}

	setFormGroups(menu: any) {
		//this gives us the location id from the menu class stepActive Object
		let locId = menu.locationId - 1;
		let hombld = this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.HOMBLD;

		//the forms indexes match the order in which they are passed into the location summary module menuclass forms array
		//0 is for locationAddressFormGroup, 1 is for propertyCoverageFormGroup and 2 is for homeBuilderFormGroup
		this.locationAddressFormGroup = menu.forms[0] || this.formBuilder.group({});

		//only adds this if there is property coverage on the location, otherwise adds an empty placeholder array so we don't screw up the indexing
		this.PropertyCoverageFormGroup =  menu.forms[1] || this.formBuilder.group({});

        this.businessClassFormGroup = menu.forms[2] || this.formBuilder.group({});

        //home builder
        this.homeBuilderFormGroup = this.formBuilder.group({});
		

		if(locId === 0) {
            
            if (menu.forms[3] != undefined) {
                this.homeBuilderFormGroup = menu.forms[3];
            }
            
            
            this.homeBuilderFormGroup.addControl("HOMBLD", new UntypedFormControl(hombld != '' ? hombld : '', 
			    this.migLocationSummaryValidator.ValidateRequired('HOMBLD', 'Do you work in the capacity of a General Contractor or Home Builder')));

			this.homeBuilderFormSubscription = this.homeBuilderFormGroup.valueChanges.pipe(distinctUntilChanged()).subscribe(()=> {
				if(this.HOMBLD.value === 'Y') this.display = true;
				this.menuClass.CalculateErrors(menu, this.menuClass.stepActive);
			});
		};
	}

	//home builder click event
	handleQ(event) {
		
		//this.HOMBLD.setValue(event);
		let hb = event;
		if ((hb !== undefined)) {
			//this.Quote.GLPENTITY.QUOTEPOLICYLIABLIMITS.HOMBLD = (hb == true ? "Y" : "N");
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.HOMBLD = event;
		}
	}

    //stop quote save
    StopQuoteSaveExit() {
        this.display = false;
        this.migsystemservice.notifyUpdateRecordState();
        //boolean added for stop quote redirect
        this.migsystemservice.notifySaveQuote(true);
    }

    //stop close and return
    StopQuoteCloseReturn() {
        this.display = false;
        this.HOMBLD.setValue(null);
    }
    
	funcGatherData(id) { // TODO: REFACTOR FOR ALL PRODUCT LINES
		this.loading = true;
		this.showAddPropertyCoverage = false;
		
		// ID is already padded out / probably came from the menu
		if (id && id.length === 3) {
			this.locationID = parseInt(id);
			this.paddedLocationID = id;
			
		} else {
			this.paddedLocationID = this.func.lpad(id.toString(), "0", 3);
		}

		this.GLPLOCATIONS = [];
		
		this.GLCLASSLIST = [];
		
		//needed for application => default to a 'N'
		if(this.ctrQuote.GLPENTITY.GLPLOCATIONS.find(x => x.LOCNUM == this.paddedLocationID).ANARLS == ''){
			this.ctrQuote.GLPENTITY.GLPLOCATIONS.find(x => x.LOCNUM == this.paddedLocationID).ANARLS = 'N'
		}

		if (this.ctrQuote.GLPENTITY.GLPLOCATIONS && this.ctrQuote.GLPENTITY.GLPLOCATIONS.length) {
			this.ctrQuote.GLPENTITY.GLPLOCATIONS.forEach((element,index) => {
				if ((element.RECORDSTATE != "D") && (element.LOCNUM === this.paddedLocationID)) {
					this.GLPLOCATIONSINDEX = index;
					this.GLPLOCATIONS = element;
				}
				//count++;
			});
		} else {
			this.ctrQuote.GLPENTITY.GLPLOCATIONS = [];
        }
        
        this.processAssociatedCfpLocations();

		if (this.ctrQuote.GLPENTITY.GLCLASSLIST && this.ctrQuote.GLPENTITY.GLCLASSLIST.length) {
			this.ctrQuote.GLPENTITY.GLCLASSLIST.forEach(element => {
				if (element.LOCNUM == this.paddedLocationID) {
					if (element.RECORDSTATE == "D") { return; }
					this.GLCLASSLIST.push(element);
				}
			});
		} else {
			this.ctrQuote.GLPENTITY.GLCLASSLIST = [];
		}
		this.formBuilder = new UntypedFormBuilder();
		this.loading = false;
    }
    
    processAssociatedCfpLocations() {
        /*
        *    Determine which CFPLocations (aka "Buildings" aka "Property Coverages")
        *    are associated with the current location address (GLPLOCATION)
        *    and are not marked for deletion.
        * 
        *    Also determine if every associated CFPLocation has its territory info populated.
        */
        this.associatedCFPLocations = [];
        this.PropertyCoverageFormGroup = [];
        this.CFPTerritoryInfoAvailable = true;

        if (this.ctrQuote.GLPENTITY.GLPLOCATIONS[this.GLPLOCATIONSINDEX].PROPERTYCOVERAGEINFO != null) {
            this.CFPTerritoryInfo = this.ctrQuote.GLPENTITY.GLPLOCATIONS[this.GLPLOCATIONSINDEX].PROPERTYCOVERAGEINFO;
        }

        this.ctrQuote.CFPENTITY.CFPLOCATIONS.forEach(cfpLocation => {
            if ((cfpLocation.LOCNUM !== this.paddedLocationID) || (cfpLocation.RECORDSTATE == "D")) {
                return; //skip this iteration
            }

            let realCfpInstance:CFPLOCATION = Object.assign(new CFPLOCATION(this.ctrQuote.QUOTEPOLICYINFORMATION), cfpLocation);
            this.associatedCFPLocations.push(cfpLocation);
            this.setCFPLocationInfoFromAddressTerritory(cfpLocation);
            this.PropertyCoverageFormGroup.push({ errors: 0, form: this.formBuilder.group({})});

            this.CFPTerritoryInfoAvailable = ((this.CFPTerritoryInfoAvailable) && ((realCfpInstance.hasTerritoryInfoPopulated() || this.CFPTerritoryInfo != null)));
        });
        
        if (this.PropertyCoverageFormGroup.length == 0) {
            this.PropertyCoverageFormGroup.push({ errors: 0, form: this.formBuilder.group({})});
        }

        if ((this.associatedCFPLocations.length == 0) && (this.CFPTerritoryInfo == null))
            this.CFPTerritoryInfoAvailable = false;
    }

	saveLocation(showSaveBtn: boolean) {
		this.saveLocationClicked = true;
		//this.editMode = showSaveBtn;
		
    }

	addressChanged(updatedAddressObject: ADDRESS) { // TODO: REFACTOR FOR ALL PRODUCT LINES
        // Update CTR Quote
		let originalPRMSTE: string = this.ctrQuote.GLPENTITY.GLPLOCATIONS[this.GLPLOCATIONSINDEX].PRMSTE;
        if ((originalPRMSTE != '') && (originalPRMSTE != updatedAddressObject.STATE) && (this.ctrQuote.QUOTEPOLICYINFORMATION.TRANSACTIONTYPE!="PI") )
        {
            //set recstate to 'D' for current GLPLOCATION and GLCLASS
            //create new instance of GLPLOCATION and GLCLASS using new address instance
            let newGLPLocation: GLPLOCATION = Object.assign(new GLPLOCATION, this.ctrQuote.GLPENTITY.GLPLOCATIONS[this.GLPLOCATIONSINDEX]);
            this.ctrQuote.GLPENTITY.GLPLOCATIONS[this.GLPLOCATIONSINDEX].RECORDSTATE = 'D';
            newGLPLocation.PRMSTE = updatedAddressObject.STATE;
            this.GLPLOCATIONS = newGLPLocation;
            this.GLPLOCATIONSINDEX = this.ctrQuote.GLPENTITY.GLPLOCATIONS.push(newGLPLocation);
            this.GLPLOCATIONSINDEX--;
        }
		let index = this.GLPLOCATIONSINDEX;

		let currentLoc: GLPLOCATION = this.ctrQuote.GLPENTITY.GLPLOCATIONS[index];
		currentLoc.STRNO = updatedAddressObject.STREETNUMBER;
		currentLoc.STRNME = updatedAddressObject.STREETNAME;
		currentLoc.LOCCTY = updatedAddressObject.CITY;
		currentLoc.LOCST = updatedAddressObject.STATE;
        currentLoc.LOCAD2 = updatedAddressObject.ADDRESSLINE2;
		currentLoc.LOCZIP = updatedAddressObject.ZIPCODE;
        currentLoc.TERR = updatedAddressObject.TERRITORYCODE;

		currentLoc.POLICY = this.ctrQuote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
		currentLoc.EFFDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
		currentLoc.TRANS = this.ctrQuote.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;
		currentLoc.RCDTYP = this.ctrQuote.QUOTEPOLICYINFORMATION.RECORDTYPE;
		currentLoc.EDSDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;

		currentLoc.ADDRESS = updatedAddressObject;
		//currentLoc.LOCATN = this.ctrQuote.POLICYTRANS.ADDRESS.LOCATN
        if (this.paddedLocationID == '001')
        {
            this.ctrQuote.POLICYTRANS.CANSTE = updatedAddressObject.STATE;
        }
		
		if(currentLoc.RECORDSTATE != 'D'){
			let label: string = "";
			if(this.ctrQuote.QUOTEPOLICYINFORMATION.TRANSACTIONTYPE !="PI"){
				label = (updatedAddressObject.STREETNUMBER ? updatedAddressObject.STREETNUMBER + " " + updatedAddressObject.STREETNAME : updatedAddressObject.POBOX ? "POBOX " + updatedAddressObject.POBOX : "New Location");
				this.menuClass.updateMenuItemAt(label, "locationId", this.paddedLocationID, "LocationSummary");

			}
			else{
				// if this is a policy inquiry, we use the LOCATN field. 
				label = updatedAddressObject.LOCATN;
				this.menuClass.updateMenuItemAt(label, "locationId", this.paddedLocationID, "LocationSummary");
			}
		}

		//need to get the state for the  GLClass if adding or changing a location		
		//** updated this - 'find' returns after finding the first instance and only updates that, not all of them */
		this.ctrQuote.GLPENTITY.GLCLASSLIST.forEach(_class => {
			if(_class.RECORDSTATE !='D' && _class.LOCNUM == this.paddedLocationID){
				_class.PRMSTE = updatedAddressObject.STATE;
			}
		});
        //send in the update to calculate any errors
        this.checkForValidPrimaryClass();
		this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive);
    }

    validateLocationStates() // TODO: REFACTOR FOR ALL PRODUCT LINES
    {
        let index = this.GLPLOCATIONSINDEX;
        if (this.ctrQuote.GLPENTITY.GLPLOCATIONS[index].LOCNUM != '001')
        {
            return;
        }
        let newStateCode = this.ctrQuote.GLPENTITY.GLPLOCATIONS[index].ADDRESS.STATE;
        let foundInvalidatedLocations:boolean = false;
        _.forEach(this.ctrQuote.GLPENTITY.GLPLOCATIONS, (glpLocation) => {
            if (glpLocation.LOCNUM == '001')
            {
                return;
            }
            //If changing first location state to VT, subsequent locations must also be in VT.
            //If changing first location state to something other than VT, subsequent locations must also NOT be in VT.
            if (((newStateCode == '44') && (glpLocation.ADDRESS.STATE != '44')) || (((newStateCode != '44') && (glpLocation.ADDRESS.STATE == '44'))))
            {
                //This location violates the VT location state rule.  Set for deletion.
                glpLocation.RECORDSTATE = 'D';
                this.deleteDataElementByLocationNumber(this.ctrQuote.CFPENTITY.CFPLOCATIONS, glpLocation.LOCNUM);
                this.deleteDataElementByLocationNumber(this.ctrQuote.CFPENTITY.CFPMORTGAGEE, glpLocation.LOCNUM);
                this.deleteDataElementByLocationNumber(this.ctrQuote.GLPENTITY.GLCLASSLIST, glpLocation.LOCNUM);
                this.deleteDataElementByLocationNumber(this.ctrQuote.IMPENTITY.IMPMORTGAGEE, glpLocation.LOCNUM);
                foundInvalidatedLocations = true;
            }
        });

        if (foundInvalidatedLocations)
        {
            this.funcRecalculateLocationNumbers();
            this.migsystemservice.notifySaveQuote(false);
        }
    }

    deleteDataElementByLocationNumber(dataArray: any[], locNumToDelete: string) 
    {
        _.forEach(dataArray, dataElement => {
            if (((dataElement.LOCNUM == locNumToDelete)) && (dataElement.RECORDSTATE != 'D'))
            {
                dataElement.RECORDSTATE = 'D';
            }
        });
    }
    
    checkForValidPrimaryClass()
    {
        this.businessClassValidators.checkForValidPrimaryClass(this.businessClassFormGroup, this.ctrQuote);
    }

    acquiredTerritoryInfo(updatedCFPAddressTerritoryObject: ADDRESSTERRITORY) { // TODO: REFACTOR FOR ALL PRODUCT LINES 
        this.CFPTerritoryInfoAvailable = false;
        this.changeDetectionRef.detectChanges();
        this.ctrQuote.GLPENTITY.GLPLOCATIONS[this.GLPLOCATIONSINDEX].PROPERTYCOVERAGEINFO = updatedCFPAddressTerritoryObject;
        this.CFPTerritoryInfo = this.ctrQuote.GLPENTITY.GLPLOCATIONS[this.GLPLOCATIONSINDEX].PROPERTYCOVERAGEINFO;
        this.associatedCFPLocations.forEach((cfpLocation, index) => {
            this.setCFPLocationInfoFromAddressTerritory(cfpLocation);
        });
        this.CFPTerritoryInfoAvailable = (this.CFPTerritoryInfo != null);
        if (this.CFPTerritoryInfoAvailable)
        {
            this.validateLocationStates();
        }
        this.changeDetectionRef.detectChanges();
    }

    setCFPLocationInfoFromAddressTerritory(cfpLocation: CFPLOCATION) { // TODO: REFACTOR FOR ALL PRODUCT LINES
        if (this.CFPTerritoryInfo == null)
            return this.setCFPLocationInfoFromExistingLocation(cfpLocation);

        cfpLocation.FTSHOR = this.CFPTerritoryInfo.GEOLOCATION.FEETTOSHORE;
        cfpLocation.MLSHOR = this.CFPTerritoryInfo.GEOLOCATION.MILESTOSHORE;
        switch (this.CFPTerritoryInfo.RETURNEDSTRUCTURECODE) {	
            case 'PPC':				
                cfpLocation.TERR   = this.CFPTerritoryInfo.TERRITORYCODE;
                cfpLocation.TAXCTY = this.CFPTerritoryInfo.RETPPCFIPSCOUNTYCODE;
                cfpLocation.TAXTWN = this.CFPTerritoryInfo.RETPPCTAXCODE;
				let protectionClasses = this.CFPTerritoryInfo.RETPPCPUBLICPROTECTIONCLASS.split("/").filter(function(value, index){
					return value.replace(/\s/g, '') != '';
				}).map((value:string) => value.replace(/\s/g, ''));		
				if (protectionClasses.length == 1) {
					cfpLocation.PRTCLS = this.CFPTerritoryInfo.RETPPCPUBLICPROTECTIONCLASS;
				} else {
					this.classesAandB = this.CFPTerritoryInfo.RETPPCPUBLICPROTECTIONCLASS;
				}
                cfpLocation.RATCTY = this.CFPTerritoryInfo.RETPPCFIREDISTRICT;
                cfpLocation.CONTY = this.CFPTerritoryInfo.RETCOUNTYNAME;
                break;
            case 'ZPP':						
                var zppStructureArray = this.CFPTerritoryInfo.RETZPPFIREDISTRICTCODE2.match(/.{1,87}/g);																							
                this.fireDistrictsArray = [];
                zppStructureArray.forEach(element => {
                    this.fireDistrictsArray.push({"value": element, "label": element.substring(0,30)});							
                });	
                if (parseInt(this.CFPTerritoryInfo.RETZPPTERRITORYCOUNT) == 1) {					
                    cfpLocation.TERR = this.CFPTerritoryInfo.RETZPPTERRITORYZIP.substr(3,3);
                } else {
					var territories = this.CFPTerritoryInfo.RETZPPTERRITORYZIP.match(/.{1,6}/g);
                    this.territoryArray = [];
                    territories.forEach(element => {
                        this.territoryArray.push({"value": element.substr(3,3), "label": element.substr(3,3)});
                    });
                }           									
                break;
            default:
        }
    }
    setCFPLocationInfoFromExistingLocation(cfpLocation: CFPLOCATION) { // TODO: REFACTOR FOR ALL PRODUCT LINES
        if (!(this.CFPTerritoryInfoAvailable))
            return;
        cfpLocation.TERR = this.associatedCFPLocations[0].TERR;
        cfpLocation.FTSHOR = this.associatedCFPLocations[0].FTSHOR;
        cfpLocation.MLSHOR = this.associatedCFPLocations[0].MLSHOR;
        cfpLocation.TAXCTY = this.associatedCFPLocations[0].TAXCTY;
        cfpLocation.TAXTWN = this.associatedCFPLocations[0].TAXTWN;
        cfpLocation.PRTCLS = this.associatedCFPLocations[0].PRTCLS;
        cfpLocation.RATCTY = this.associatedCFPLocations[0].RATCTY;
        cfpLocation.CONTY = this.associatedCFPLocations[0].CONTY;
	}
	
	//emits an event from the address component to close the panel
	showSaveBtn(showSaveBtn: boolean) {
		//this.editMode = showSaveBtn;
	}

	btnAddLocation() {
        let currentStepValidationErrors:any[] = this.menuClass.CalculateErrors(this.menuClass.stepActiveObject);
		if(this.CFPTerritoryInfo !=null && this.CFPTerritoryInfo.WNDZNE == 3){ 
			// If the windzone returned is 3, display the stop quote 
			this.displayStopQuote();
			return;
		}
        this.migsystemservice.notifyNextClicked(currentStepValidationErrors);
        if (currentStepValidationErrors.length > 0)
        {
            return;
        }

		this.loading = true;

		let count = 0;
		for (let i = 0; i < this.ctrQuote.GLPENTITY.GLPLOCATIONS.length; i++) {
			if (this.ctrQuote.GLPENTITY.GLPLOCATIONS[i].RECORDSTATE == "D") { continue; }
			count++;
		}

		let locnum = count + 1;

		let locnumPadded = this.func.lpad(locnum.toString(), "0", 3);
		let out = new GLPLOCATION();
		out.LOCNUM = locnumPadded;
		out.BLDNUM = "001";
		out.RECORDSTATE = "N";
		//check for Lessors Risk - Office Only class code, check the default class code coming from QUOTEPOLICYINFO
		if(this.ctrQuote.QUOTEPOLICYINFORMATION.CLASSCODEINFO.CLASSCODE == '061217'){
			out.ANARLS = 'Y';
		}
		else{
			out.ANARLS ='N';
		}
		this.ctrQuote.GLPENTITY.GLPLOCATIONS.push(out);
		
		//need to add default class when adding location
		//NOTE: PRMSTE state code is updated on glclasslist when addressChanged() is called (above)
		let defaultClass = new GLClasses();
		defaultClass.TRANS  = this.ctrQuote.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;
		defaultClass.POLICY = this.ctrQuote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
		defaultClass.EFFDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
		defaultClass.EDSDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;
		defaultClass.RCDTYP = this.ctrQuote.QUOTEPOLICYINFORMATION.RECORDTYPE;
		defaultClass.LOCNUM = locnumPadded;
		defaultClass.BLDNUM = '001';
		defaultClass.CLASX  = this.ctrQuote.QUOTEPOLICYINFORMATION.CLASSCODEINFO.CLASSCODE;
		defaultClass.CLSDSC = this.ctrQuote.QUOTEPOLICYINFORMATION.CLASSCODEINFO.DESCRIPTION;
		defaultClass.EXPDSC = this.ctrQuote.QUOTEPOLICYINFORMATION.CLASSCODEINFO.EXPDSC;
		defaultClass.PRMDSC = this.ctrQuote.QUOTEPOLICYINFORMATION.CLASSCODEINFO.EXPDSC;
		defaultClass.PRDINC = this.ctrQuote.QUOTEPOLICYINFORMATION.CLASSCODEINFO.PRDINC;
		defaultClass.SICCDE = this.ctrQuote.QUOTEPOLICYINFORMATION.CLASSCODEINFO.SICCDE;
		defaultClass.IFANY  = (locnumPadded != '001' ? 'Y' : '');
		defaultClass.PKGMOD = 'CO';
		defaultClass.RECORDSTATE = 'U';
		this.ctrQuote.GLPENTITY.GLCLASSLIST.push(defaultClass);

		let data = {
			name: 'LocationSummary',
			label: "New Location",
			sublabel: '<small>0 buildings</small>',
			color: "ui-steps-number-default",
			navSkip: false,
			active: false,
			hasError: false,
			errors: [],
			buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }, { button: "GetQuoteNow" }],
			// forms: [{ errors: 0, form: this.formBuilder.group({}) }, { errors: 0, form: this.formBuilder.group({}) }],
			forms: [this.formBuilder.group({}), this.formBuilder.group({}), this.formBuilder.group({})],
			icon: 'fa fa-map-pin',
			block: [],
			visible: true,
			locationId: locnumPadded,
			level: 2
		};

		this.menuClass.addMenuItemAt(data, "LocationSummary");
        //this.migsystemservice.notifyBlock({ block: true, block_message: data.block });
        
		this.menuClass.GotoMenuItem("locationId", locnumPadded);
		//this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive);
	}

	//show delete button on mark up?
	funcCanIRemoveLocation() {
		let count = 0;
		for (let i = 0; i < this.ctrQuote.GLPENTITY.GLPLOCATIONS.length; i++) {
			if (this.ctrQuote.GLPENTITY.GLPLOCATIONS[i].RECORDSTATE == 'D') { continue; }
			if (this.ctrQuote.GLPENTITY.GLPLOCATIONS[i].LOCNUM == '001') { continue; }
			count++;
		}
		if (this.locationID == 1) { return false; }
		if (count > 0) { return true; } else { return false; }
	}
	
	btnRemoveLocation() { // TODO: REFACTOR FOR ALL PRODUCT LINES
		
		this.confirmationServiceAddress.confirm({
			message: 'Are you sure you want to remove this location?',
			accept: () => {
				//set location RECORDSTATE to 'D"
				this.ctrQuote.GLPENTITY.GLPLOCATIONS.find(x => x.LOCNUM == this.paddedLocationID && x.RECORDSTATE != 'D').RECORDSTATE = 'D';
				
				//set location/Properties RECORDSTATE to 'D"
				this.ctrQuote.CFPENTITY.CFPLOCATIONS.forEach(prop => {
					if(prop.RECORDSTATE !='D' && prop.LOCNUM == this.paddedLocationID){
						prop.RECORDSTATE = 'D'
					}
				});
				
				//set location/GL Classes RECORDSTATE to 'D"
				this.ctrQuote.GLPENTITY.GLCLASSLIST.forEach(_class => {
					if(_class.RECORDSTATE !='D' && _class.LOCNUM == this.paddedLocationID){
						_class.RECORDSTATE = 'D';
					}
				});
								
                this.funcRecalculateLocationNumbers();
                this.migsystemservice.notifyQuoteChanged(this.ctrQuote);
				this.migsystemservice.notifyError([]);
				this.migsystemservice.notifyWindZone(0); //When deleting a location, we need to tell the menu and footer to reset the windzone so the user is allowed to proceed.
				this.stopQuote = false; 
                //this.migsystemservice.notifyBlock({ block: true, block_message: [{ text: "Loading Data", success: false, icon: 'fa-spinner' }]});
                //Need a better way to switch off this menu step thats about to be deleted...
                //This will have to do for now.  -SMB
                this.menuClass.GotoMenuItem("locationId", "001");
                
                
                //this.updateMenuSteps("001");
			}
		});
		
    }
    
    recalculateLocationNumber(dataArray: any[], oldLocNum: string, newLocNum: string) // TODO: REFACTOR FOR ALL PRODUCT LINES
    {
        _.forEach(dataArray, dataItem => {
            if ((dataItem.RECORDSTATE != 'D') && (dataItem.LOCNUM == oldLocNum))
            {
                dataItem.LOCNUM = newLocNum;
            }
        });
    }

	funcRecalculateLocationNumbers() { // TODO: REFACTOR FOR ALL PRODUCT LINES ? 
		let reIndex = 1;
        
        _.sortBy(this.ctrQuote.GLPENTITY.GLPLOCATIONS, location => {return location.LOCNUM; });
		this.ctrQuote.GLPENTITY.GLPLOCATIONS.forEach(loc => {
            if (loc.RECORDSTATE == "D")
                return;
			
            let newLocNum = this.func.lpad((reIndex).toString(), "0", 3);
            
            this.recalculateLocationNumber(this.ctrQuote.GLPENTITY.GLCLASSLIST, loc.LOCNUM, newLocNum);
            this.recalculateLocationNumber(this.ctrQuote.CFPENTITY.CFPLOCATIONS, loc.LOCNUM, newLocNum);
            this.recalculateLocationNumber(this.ctrQuote.CFPENTITY.CFPMORTGAGEE, loc.LOCNUM, newLocNum);
            this.recalculateLocationNumber(this.ctrQuote.IMPENTITY.IMPMORTGAGEE, loc.LOCNUM, newLocNum);
            
            //SET THE NEW LOCNUM AFTER COMPARING TO THE CLASSLIST AND PROPERTIES
            loc.LOCNUM = newLocNum;
            //
            reIndex++;
			
		});
		
	}

	filterPropertyCoverage() {
		return this.ctrQuote.CFPENTITY.CFPLOCATIONS.filter(x => x.LOCNUM == this.paddedLocationID && x.RECORDSTATE != "D");
	}

	btnAddPropertyCoverage() {
        if (!(this.CFPTerritoryInfoAvailable))
            return;
        
        if(this.CFPTerritoryInfo != null && this.CFPTerritoryInfo.WNDZNE == 3){
			// if windzone returned = 3, display the stop quote and do not advance to the property coverage screen. 
			this.displayStopQuote();
			this.showAddPropertyCoverage = false; 
			return;
		}
		this.menuClass.stopNavigation = true;
		// create a new property coverage
		let out = new CFPLOCATION(this.ctrQuote.QUOTEPOLICYINFORMATION);

		// set our location id		
		out.LOCNUM = this.paddedLocationID;
		

		this.setCFPLocationInfoFromAddressTerritory(out);
		// count how many we have
		let tot = 0;
		for (let i = 0; i < this.ctrQuote.CFPENTITY.CFPLOCATIONS.length; i++) {
			if (this.ctrQuote.CFPENTITY.CFPLOCATIONS[i].LOCNUM == this.paddedLocationID) {
				if (this.ctrQuote.CFPENTITY.CFPLOCATIONS[i].RECORDSTATE == "D") { continue; }
				tot++;				
			}
		}
		
		//add the new to the total here
		tot++;
		// set our building number and recordstate
		out.BLDNUM = this.func.lpad(tot.toString(), "0", 3);
		out.RECORDSTATE = "D";//<- default this to 'D' to protect clicking next and adding prop cvg; when the user hits 'done' we chnage the recordstate to 'N'

		// push on to ctrQuote
		let dummy = new UntypedFormGroup({});
		this.PropertyCoverageFormGroup.push({ errors: 0, form: dummy });
		
		//TODO: REFACTOR this - varaible 'out' is pushing onto object graph? 
		this.newPropertyCoverage = this.ctrQuote.CFPENTITY.CFPLOCATIONS.push(out);	
		
		//check here for lessors rick CLASX and add office blg occupncy class
		if(this.ctrQuote.GLPENTITY.GLCLASSLIST.find(x=>x.LOCNUM == this.paddedLocationID && x.CLASX == '061217')){
			if(!this.ctrQuote.CFPENTITY.CFPLOCATIONS.find(x=>x.LOCNUM == this.paddedLocationID).BLDCLSLIST.find(x=>x == 'OFFICE')){
				this.ctrQuote.CFPENTITY.CFPLOCATIONS.find(x=>x.LOCNUM == this.paddedLocationID).BLDCLSLIST.push('OFFICE');
			}
		};
		
		this.newPropertyCoverage--;
		this.associatedCFPLocations.push(out);
		

		this.setWindstormHailDeductible(this.ctrQuote.CFPENTITY.CFPLOCATIONS,this.paddedLocationID);
		// show our form
		this.showAddPropertyCoverage = !this.showAddPropertyCoverage;
		//this.changeDetectionRef.detectChanges();
		
	}

	cancelPropertyCoverage(mode) {
		this.confirmationService.confirm({
            header: 'Cancel Adding Property Coverage?',
			message: 'Are you sure?',
            accept: () =>
                {
                    this.loading = true;
					this.menuClass.stopNavigation = false;
                    this.ctrQuote.CFPENTITY.CFPLOCATIONS.splice(this.newPropertyCoverage, 1);
                    this.showAddPropertyCoverage = !this.showAddPropertyCoverage;
                    this.resequencePropertyCoverageBuildings();
                    this.funcGatherData(this.paddedLocationID);
				}
		});
	}

	donePropertyCoverage(data, idx, mode) {
        
        this.loading = true;
		if (mode == "new") {
			this.showAddPropertyCoverage = !this.showAddPropertyCoverage;
		}
		
		this.menuClass.stopNavigation = false;
        this.resequencePropertyCoverageBuildings();
        this.checkAdditionalPropertyCoverageMenuItem();
        this.funcGatherData(this.paddedLocationID);
        
        this.document.getElementById('center_wrapper').scrollTop = 0;
        this.document.getElementById('center_wrapper').scroll({ top: 0, left: 0, behavior: "smooth" });
        this.loading = false;
	}

	deletePropertyCoverage(locationIds) {
        this.loading = true;
        this.confirmationService.confirm({
			message: 'You are about to delete property coverage on Location ' + locationIds.locNum + ' Building ' + locationIds.bldNum + ', do you wish to continue?',
			header: 'Delete Property?',
			icon: 'pi pi-exclamation-triangle',
			accept: () => {
                _.find(this.ctrQuote.CFPENTITY.CFPLOCATIONS, (cfpLocation) => 
                    cfpLocation.BLDNUM == locationIds.bldNum && cfpLocation.LOCNUM == locationIds.locNum && cfpLocation.RECORDSTATE != 'D'
                ).RECORDSTATE = 'D';

                this.resequencePropertyCoverageBuildings();
                this.checkAdditionalPropertyCoverageMenuItem();
                this.funcGatherData(this.paddedLocationID);
            },
            reject: () => {
                this.loading = false;
            }
        });
	}

	//
	setWindstormHailDeductible(cfplocations,currentLocnum){
		//set the WindStorm Deductable to the first property setting
		cfplocations.forEach(prop => {
			
			if ((prop.LOCNUM == currentLocnum)) {				
				//prop.WNDDCT = cfplocations[0].WNDDCT;
				let prop1 = cfplocations.filter((x:any)=>x.LOCNUM == currentLocnum); 
				prop.WNDDCT = prop1[0].WNDDCT;
			}
		});
	}


	resequencePropertyCoverageBuildings() { // TODO: REFACTOR FOR ALL PRODUCT LINES
		let count = 0;
		for (let i = 0; i < this.ctrQuote.CFPENTITY.CFPLOCATIONS.length; i++) {
			if (this.ctrQuote.CFPENTITY.CFPLOCATIONS[i].RECORDSTATE == "D") { continue; }
            
            
			if (this.ctrQuote.CFPENTITY.CFPLOCATIONS[i].LOCNUM == this.paddedLocationID) {
                count++;
				this.ctrQuote.CFPENTITY.CFPLOCATIONS[i].BLDNUM = this.func.lpad(count.toString(), "0", 3);
			}
        }
        this.updateBuildingCountSubLabel();
    }

    updateBuildingCountSubLabel() 
    {
        let buildingCount: number = this.currentBuildingCount();

        this.menuClass.stepActiveObject.sublabel = '<small>' + buildingCount + ' Building' + (buildingCount == 1 ? '' : 's') + '</small>';
    }

    currentBuildingCount(): number { // TODO: REFACTOR FOR ALL PRODUCT LINES
        return _.size(_.filter(this.ctrQuote.CFPENTITY.CFPLOCATIONS, (cfpLocation) => {
            return (cfpLocation.RECORDSTATE != 'D' && cfpLocation.LOCNUM == this.paddedLocationID);
        }));
    }

    locationHasExistingPropertyCoverage(): boolean {
        
        return (this.currentBuildingCount() > 0);
    }

    userIsChangingTheAddress() // TODO: REFACTOR FOR ALL PRODUCT LINES
    {
        this.ctrQuote.GLPENTITY.GLPLOCATIONS[this.GLPLOCATIONSINDEX].PROPERTYCOVERAGEINFO = null;
        this.CFPTerritoryInfoAvailable = false;
        this.CFPTerritoryInfo = null;

        this.associatedCFPLocations.forEach((location) => {
                location.RECORDSTATE = 'D';
        });

        this.menuClass.stepActiveObject.sublabel = '<small>0 Buildings</small>';
        this.checkAdditionalPropertyCoverageMenuItem();
    }

    checkAdditionalPropertyCoverageMenuItem() // TODO: REFACTOR FOR ALL PRODUCT LINES?
    {
        let quoteHasPropertyCoverage = false;

        this.ctrQuote.GLPENTITY.GLPLOCATIONS.forEach(loc=> {
			
            if(loc.RECORDSTATE == 'D')
            {
                return;
            }

            this.ctrQuote.CFPENTITY.CFPLOCATIONS.forEach(prop => {
                if(prop.RECORDSTATE !='D' && prop.LOCNUM == loc.LOCNUM){
                    quoteHasPropertyCoverage = true;
                }
            });
        });

        this.menuClass.ShowHideMenuItemAt(quoteHasPropertyCoverage, "AdditionalCoveragesProperty");
	}
	displayStopQuote(){
		//This function displays the stop quote modal. It is called when the user clicks Add Location or Add Property Coverage, when the windzone for that location is 3. 
		this.confirmationService.confirm({
			message: 'Risk ineligible due to Coastal Restrictions.',
			header: 'Stop Quote',
			icon: 'pi pi-exclamation-triangle',
			acceptLabel: "Save and Exit",
			accept: (() => this.StopQuoteSaveExit()),
			rejectLabel: "Close",
		});
	}
}
