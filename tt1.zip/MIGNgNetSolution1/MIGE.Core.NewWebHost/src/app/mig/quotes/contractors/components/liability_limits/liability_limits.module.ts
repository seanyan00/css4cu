/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { InputTextModule } from 'primeng/inputtext';
import { PanelModule } from 'primeng/panel';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { CheckboxModule } from 'primeng/checkbox';
import { FormsModule, ReactiveFormsModule, UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { PipesModule } from '@pipes/pipes.module';
import { MIGLiabilityLimits } from '@CTRcomponents/liability_limits/liability_limits.component';
import { MIGValidatorLiability } from '@CTRcomponents/liability_limits/liability_limits.validators';
import { MenuClass } from '@root/system/menu/menu';

@NgModule({
    imports: [
        MIGButtonModule,
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        PanelModule,
        CheckboxModule,
		MIGDropDownModule,
        InputTextModule,
        PanelModule
    ],
    declarations: [MIGLiabilityLimits],
    exports: [MIGLiabilityLimits],
    providers: [MIGValidatorLiability, PipesModule]
})
export class LiabilityLimitsModule {
	formGroup: UntypedFormGroup;

	constructor(
		public menuClass: MenuClass,
		private formBuilder: UntypedFormBuilder,

	) {
		this.formGroup = this.formBuilder.group({});

		menuClass.addMenuItem({
			name: 'LiabilityLimits',
			label: 'Liability Limits',
			color: "ui-steps-number-default",
			navSkip: false,
			active: false,
			hasError: false,
			errors: [],
			buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }],
			form: this.formGroup,
			icon: 'fa fa-layer-group',
			block: [],
			visible: true,
			quote: "premium"
		});
	}
}
