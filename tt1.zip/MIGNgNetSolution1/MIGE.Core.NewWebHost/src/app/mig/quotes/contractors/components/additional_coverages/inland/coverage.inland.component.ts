/* NG Includes */
import { Component, ViewEncapsulation, Input } from '@angular/core';
import { MIGSystemService } from '@services/mig.service';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { MenuClass } from '@root/system/menu/menu';
import { ContractorsTooltips } from '@helpers/tooltips';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';

@Component({
	selector: 'mig-additional-coverages-inland',
	templateUrl: './coverage.inland.component.html',
	styleUrls: ['coverage.inland.component.css'],
	encapsulation: ViewEncapsulation.None
})

export class MIGAdditionalCoveragesInland {
    visInland: boolean = false;
    visLiability: boolean = false;
	formBuilder: UntypedFormBuilder;
	stepName = "AdditionalCoveragesInland";
	formGroup: UntypedFormGroup;

	@Input() ctrQuote: CTRQuote;
	@Input() additionalCoveragesInlandFormGroup: UntypedFormGroup;

	constructor(
		public migsystemservice: MIGSystemService,
		public contractorsTooltips: ContractorsTooltips,
		public menuClass: MenuClass,
		public migRoles: MIGSecurityRoles
	) {
		this.formGroup = this.menuClass.menuObject(this.stepName).forms[0];

	}
	
	ngAfterViewInit(): void { 
		if(!this.migRoles.editable) {
			this.formGroup.disable();
		}
	}

}
