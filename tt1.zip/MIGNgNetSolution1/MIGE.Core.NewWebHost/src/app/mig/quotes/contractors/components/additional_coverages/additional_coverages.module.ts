/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule, UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { CalendarModule } from 'primeng/calendar';
import { CheckboxModule } from 'primeng/checkbox';
import { FieldsetModule } from 'primeng/fieldset';
import { InputTextModule } from 'primeng/inputtext';
import { PanelModule } from 'primeng/panel';
import { TabViewModule } from 'primeng/tabview';

import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { MIGAdditionalCoverages } from './additional_coverages.component';
import { MIGInputSwitchModule } from '@overridden/primeng-inputswitch/switch.module';
import { TextMaskModule } from 'angular2-text-mask';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';
import { MenuClass } from '@root/system/menu/menu';
@NgModule({
	imports: [
		MIGButtonModule,
		CalendarModule,
		FieldsetModule,
		CheckboxModule,
		FormsModule,
		TabViewModule,
		CommonModule,
		FieldsetModule,
		PanelModule,
		MIGDropDownModule,
		InputTextModule,
		MIGInputSwitchModule,
		TextMaskModule,
		MIGCheckboxModule,
		ReactiveFormsModule
	],
	declarations: [
		MIGAdditionalCoverages,
	],
	exports: [MIGAdditionalCoverages]
})
export class AdditionalCoveragesModule {
	formGroup: UntypedFormGroup;
	constructor(
		public menuClass: MenuClass,
		private formBuilder: UntypedFormBuilder,
	) {
		this.formGroup = this.formBuilder.group({});

		menuClass.addMenuItem({
			name: 'AdditionalCoverages',
			label: 'Additional Coverages',
			color: "ui-steps-number-default",
			navSkip: true,
			active: false,
			hasError: false,
			errors: [],
			form: [],
			buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }, { button: "GetQuoteNow" }],
			icon: "fa fa-shield-alt",
			block: [],
			visible: true
		});
	}
}
