import { Injectable } from "@angular/core";
import { Validators } from "@angular/forms";

@Injectable()
export class PropertyCoverageFieldRules {

	ApplyValidation(_this) {
		
		// Building Occupancy Class -
		// Required. Choose from list of Options.
		// Able to select one to all four options.
		//_this.BLDCLSLIST.setValidators([_this.pcBRValidation.ValidateRequired("BLDCLSLIST", "Building Occupancy Class")])

		// Single Occupancy - Required
		//_this.SNGOFG.setValidators([_this.pcBRValidation.ValidateRequired("SNGOFG","Other Occupancies")])

		// Property Deductible
		// Required. Choose from list of Options.
		// Cannot be higher than the sum of Building and Business Personal Property Limits on the location building that is being added.
		//below updated 20190619
		//_this.BLDGDD.setValidators([_this.pcBRValidation.ValidateRequired("BLDGDD","Property Deductible")]);

		// Construction Type - Required
		//_this.CONSYM.setValidators([_this.pcBRValidation.ValidateRequired("CONSYM","Construction Type")]);

		// Year Built - Required
		//_this.CONYR.setValidators([_this.pcBRValidation.ValidateRequired("CONYR","Year Built")]);
		

		// Building property tenants policy can only be checked IF BPP limit exists
		// so disable it until we get there, unless its been enabaled from a previous session;check BPPLM1 value for that
		if(_this.BPPLM1.value == 0){ _this.checkboxPSLI.disable(); }


		// CP 1219: Building Owner
		//if checkboxBOCNT == true, CCPALL required to complete 'Number of Additional Insureds' when selected. MIN = 1, MAX = 99
		// _this.checkboxCCPALLSubscription = _this.checkboxCCPALL.valueChanges.subscribe(data => {
		// 	if (_this.checkboxCCPALL.value) {
		// 		_this.CCPALL.setValidators([_this.migPropertyCoverageValidator.ValidateRequired("CCPALL", "CP 1219 > Additional Insureds")])
		// 	} else {
		// 		_this.CCPALL.setValidators([Validators.nullValidator])
		// 		_this.CCPALL.setValue(0);
		// 	}
		// });
		//** commented out, chnage was needed to identify this with LOCNUM/BLDNUM
		// _this.checkboxBOCNTSubscription = _this.checkboxBOCNT.valueChanges.subscribe(data => {
		// 	if (_this.checkboxBOCNT.value) {
		// 		_this.BOCNT.setValidators([_this.migPropertyCoverageValidator.ValidateRequired("BOCNT", "CP 1219 > Additional Insureds")])
		// 	} else {
		// 		_this.BOCNT.setValidators([Validators.nullValidator])
		// 		_this.BOCNT.setValue(0);
		// 	}
		// });

		//commented this out as part of validation cleanup -JTL 7/29/19
		// _this.checkboxUTLSVCSubscription = _this.checkboxUTLSVC.valueChanges.subscribe(data => {
		// 	if (_this.checkboxUTLSVC.value) {
		// 		_this.UTLSVC.setValidators([_this.pcBRValidation.ValidateRequired("Utility Services - Time Element")])
		// 	} else {
		// 		_this.UTLSVC.setValidators([Validators.nullValidator])
		// 		_this.UTLSVC.setValue(0);
		// 	}
		// });


		//BPPLM1
		_this.BPPLM1Subcription = _this.BPPLM1.valueChanges.subscribe(data => {
			// Theft Exclusion & Building Property Tenants Policy
			// Can only be checked if Business personal property limit has value
			if (_this.func.justNumbers(data) > 0) {
				
				//peak season
				_this.checkboxPSLI.enable();
				// Business Personal Property Limit > Valuation and Coinsurance - Required if Business Personal Property Limit is entered
				_this.BPPVN1.setValidators([_this.BPPLM1.value ? _this.pcBRValidation.ValidateRequired("BPPVN1", "Business Personal Property Coverage > Valuation") : Validators.nullValidator])
				// Theft Exclusion & Building Property Tenants Policy
				// Can only be checked if Business personal property limit has value
				_this.BPPCN1.setValidators([_this.BPPLM1.value ? _this.pcBRValidation.ValidateRequired("BPPCN1", "Business Personal Property Coverage > Coinsurance %") : Validators.nullValidator])

			} else {
								
				//peak season
				_this.checkboxPSLI.setValue(false);
				_this.checkboxPSLI.disable();
				
				// Business Personal Property Limit > Valuation and Coinsurance - Required if Business Personal Property Limit is entered
				_this.BPPVN1.setValidators([Validators.nullValidator]);
				//_this.BPPVN1.setValue("");

				_this.BPPCN1.setValidators([Validators.nullValidator]);
				//_this.BPPCN1.setValue("");
			}
		});


		// Peak season limit of insurance
		// When checked, coverage is added and the following 4 fields are displayed
		// Must have BPP in order to view.  Need the ability to add 2 separate entries
		_this.checkboxPSLISubcription = _this.checkboxPSLI.valueChanges.subscribe(data => {
			if (_this.checkboxPSLI.value == true) {
				_this.BPPDF1.setValidators([_this.pcBRValidation.ValidateRequired("BPPDF1", "Peak Season Limit of Insurance Period: from")])
				_this.BPPDT1.setValidators([_this.pcBRValidation.ValidateRequired("BPPDT1", "Peak Season Limit of Insurance Period: to")])
				
			} else {
				_this.BPPDF1.setValidators([Validators.nullValidator]);
				_this.BPPDF1.setValue(0);
				_this.BPPDT1.setValidators([Validators.nullValidator]);
				_this.BPPDT1.setValue(0);				
				_this.BPPDF2.setValue(0);
				_this.BPPDT2.setValue(0);

				_this.BPPSL1.setValue('');
				_this.BPPSL2.setValue('');

				_this.P1230CVPP.setValue('');
				_this.P1230CV1P.setValue('');				
				
			}
		});

	


		// _this.BLDTP1Subscription = _this.BLDTP1.valueChanges.subscribe(data => {
		// 	// Building Limit > Valuation and Coinsurance - Required if building limit is entered.
		// 	if (_this.BLDTP1.value == "B") {
		// 		_this.BLDVAL.setValidators([_this.pcBRValidation.ValidateRequired("Building Valuation")])
		// 		_this.BLDCIN.setValidators([_this.pcBRValidation.ValidateRequired("Building Coinsurance")])
		// 	} else {
		// 		_this.BLDVAL.setValidators([Validators.nullValidator]);
		// 		_this.BLDVAL.setValue("");

		// 		_this.BLDCIN.setValidators([Validators.nullValidator]);
		// 		_this.BLDCIN.setValue("");
		// 	}
		// });

		// Building Property Tenants Policy
		// If Checked - Building Limits gets disabled
		// _this.checkboxBLDTP1Subscription = _this.checkboxBLDTP1.valueChanges.subscribe(data => {
		// 	if (_this.checkboxBLDTP1.value == true) {
		// 		_this.BLDLM1.disable();
		// 		_this.BLDLM1.setValue('');
		// 		_this.dropdownBLDTP1.enable();
		// 		_this.dropdownBLDTP1.setValidators([_this.pcBRValidation.ValidateRequired("Building Property Tenants Policy")]);
		// 	} else {
		// 		_this.BLDLM1.enable();
		// 		_this.dropdownBLDTP1.setValidators([Validators.nullValidator]);
		// 		_this.dropdownBLDTP1.setValue("");
		// 		_this.tmpBLDLM1.setValue('');
		// 		_this.BLDLM2.setValue('');
		// 	}
		// });

		// Building Property Tenants Policy limit Glass
		// _this.tmpBLDLM1.setValidators([_this.pcBRValidation.ValidateRequired('Limit Required'),
		// 								_this.pcBRValidation.ValidateMaxValue('100,000',100000,'Glass Limit'),
		// 								_this.pcBRValidation.ValidateMinValue('1',1,'Glass Limit')
		// 							   ]);

		// Building Property Tenants Policy limit Other than Glass
		// _this.BLDLM2.setValidators([_this.pcBRValidation.ValidateRequired('Limit Required'),
		// 							_this.pcBRValidation.ValidateMaxValue('100,000',100000,'Other than Glass'),
		// 							_this.pcBRValidation.ValidateMinValue('1',1,'Other than Glass')
	   	// 							]);

		// Peak Season Limit Additional Limit of Insurance 1
		// _this.BPPSL1.setValidators([_this.pcBRValidation.ValidateRequired('Limit Required'),
		// 							_this.pcBRValidation.ValidateMaxValue('100,000',100000,'Additional Limit of Insurance'),
		// 							_this.pcBRValidation.ValidateMinValue('1',1,'Additional Limit of Insurance')
		// 							]);
		
		// // Peak Season Limit Additional Limit of Insurance 2
		// _this.BPPSL2.setValidators([_this.pcBRValidation.ValidateRequired('Limit Required'),
		// 							_this.pcBRValidation.ValidateMaxValue('100,000',100000,'Additional Limit of Insurance'),
		// 							_this.pcBRValidation.ValidateMinValue('1',1,'Additional Limit of Insurance')
		// 						   ]);

		_this.PropertyCoverageFormGroup.updateValueAndValidity();
		_this.cd.detectChanges();
	}
}
