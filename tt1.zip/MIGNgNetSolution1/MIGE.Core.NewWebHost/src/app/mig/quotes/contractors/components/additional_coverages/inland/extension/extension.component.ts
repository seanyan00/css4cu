import { Component, Input, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { CurrencyFormatPipe } from '@pipes/pipes';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { UntypedFormBuilder, UntypedFormGroup, Validators, FormControl } from '@angular/forms';
import { Functions } from '@helpers/functions';
import { MenuClass } from '@root/system/menu/menu';
import { Subscription } from 'rxjs/internal/Subscription';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { ContractorsTooltips } from '@helpers/tooltips';
import { MIGSystemService } from '@services/mig.service';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { InputMasksClass } from '@helpers/masks';
import { MIGLiabilityValidator} from './liability.validator';


@Component({
	selector: 'mig-coverage-inland-extension',
	templateUrl: './extension.component.html',
	providers: [CurrencyFormatPipe]
})

export class MIGCoverageInlandExtension implements OnInit, OnDestroy {
	currencyPipe = new CurrencyFormatPipe;

	tempDropDown: any[] = [];

	@Input() ctrQuote: CTRQuote;
	@Input() formGroup: UntypedFormGroup;

	formBuilder: UntypedFormBuilder;
	formChanged: boolean = false;
	migLiabilityValidtor: MIGLiabilityValidator;
	FormGroupSubscription: Subscription;
	updateRecordState: Subscription;
	visInland: boolean = false;	
	visDown: boolean = false;
    resetForm: boolean = false;
    
    dropdownOptionsCTRUPL: any[];
    dropdownOptionsTCPOLL: any[];
    dropdownOptionsFUELAC: any[];
    dropdownOptionsRNOOLL: any[];
    dropdownOptionsTRLCON: any[];
    dropdownOptionsEQPBOR: any[];
    dropdownOptionsEQPRNT: any[];
    
	

cnt: number = 0;
	constructor(
		public func: Functions,
		public contractorsDropDowns: ContractorsDropDowns,
		public contractorsTooltips: ContractorsTooltips,
		public migsystemservice: MIGSystemService,
		public migRoles: MIGSecurityRoles,
		public masks: InputMasksClass,
		public menuClass: MenuClass,
		public cd: ChangeDetectorRef
	) {
		if (this.formBuilder == null) {
			this.formBuilder = new UntypedFormBuilder();
		}
		this.migLiabilityValidtor = new MIGLiabilityValidator();

		// this.migsystemservice.subscribeFirstLocationStateChanged().subscribe(() => {
		// 	this.formGroup.reset();
		// });

	}


	get CTRDED() { return this.formGroup.get("CTRDED"); }

	get checkboxCTRCNS() { return this.formGroup.get("checkboxCTRCNS"); }
	get CTRCNS() { return this.formGroup.get("CTRCNS"); }

	get checkboxCTRSCL() { return this.formGroup.get("checkboxCTRSCL"); }
	get CTRSCL() { return this.formGroup.get("CTRSCL"); }

	get checkboxCTRUPL() { return this.formGroup.get("checkboxCTRUPL"); }
	get CTRUPL() { return this.formGroup.get("CTRUPL"); }

	get checkboxTCPOLL() { return this.formGroup.get("checkboxTCPOLL"); }
	get TCPOLL() { return this.formGroup.get("TCPOLL"); }

	get checkboxFUELAC() { return this.formGroup.get("checkboxFUELAC"); }
	get FUELAC() { return this.formGroup.get("FUELAC"); }

	get checkboxRNOOLL() { return this.formGroup.get("checkboxRNOOLL"); }
	get RNOOLL() { return this.formGroup.get("RNOOLL"); }

	get checkboxTRLCON() { return this.formGroup.get("checkboxTRLCON"); }
	get TRLCON() { return this.formGroup.get("TRLCON"); }

	get checkboxEQPBOR() { return this.formGroup.get("checkboxEQPBOR"); }
	get EQPBOR() { return this.formGroup.get("EQPBOR");}

	get checkboxEQPRNT() { return this.formGroup.get("checkboxEQPRNT"); }
	get EQPRNT() { return this.formGroup.get("EQPRNT"); }

	get checkboxCTRRPL() { return this.formGroup.get("checkboxCTRRPL"); }
	get CEQVAL() { return this.formGroup.get("CEQVAL"); }

	get DOWHOL() { return this.formGroup.get("DOWHOL"); }

	ngOnInit(): void {
		
		if(this.ctrQuote.INLANDSTATECHANGE === "Y") {
			this.formGroup.reset();
			this.ctrQuote.INLANDSTATECHANGE = "N";
		}
		
		document.getElementById('inlandMarineForm').scrollTop;
		// shorten our path				
		let impProducts = this.ctrQuote.IMPENTITY.IMPPRODUCTS;

		//there need to be set before premium is called in order to save the DWIP120 correctly
		this.ctrQuote.IMPENTITY.IMPPRODUCTS.POLICY = this.ctrQuote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
		this.ctrQuote.IMPENTITY.IMPPRODUCTS.EFFDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
		this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRANS  = this.ctrQuote.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;
		this.ctrQuote.IMPENTITY.IMPPRODUCTS.RCDTYP = this.ctrQuote.QUOTEPOLICYINFORMATION.RECORDTYPE;
		this.ctrQuote.IMPENTITY.IMPPRODUCTS.EDSDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.RECORDSTATE = "U";
        
        this.determineDropdownOptions();
        
        this.formGroup = this.formBuilder.group({
            // Deductible
            CTRDED: [impProducts.CTRDED ? impProducts.CTRDED : this.contractorsDropDowns.defaultCTRDED],
            // CoInsurance
            checkboxCTRCNS: [{ value: true, disabled: true }],
            CTRCNS: [impProducts.CTRCNS ? impProducts.CTRCNS : this.contractorsDropDowns.defaultCTRCNS],
            // Scheduled Tools and Equipment
            checkboxCTRSCL: [false],
            CTRSCL: [impProducts.CTRSCL ? impProducts.CTRSCL : 0],
            // Unscheduled Tools and Equipment
            checkboxCTRUPL: [{ value: true, disabled: true }],
            CTRUPL: [impProducts.CTRUPL ? impProducts.CTRUPL : this.contractorsDropDowns.defaultCTRUPL],
            // Employee Tools and Clothing
            checkboxTCPOLL: [{ value: true, disabled: true }],
            TCPOLL: [impProducts.TCPOLL ? impProducts.TCPOLL : this.contractorsDropDowns.defaultTCPOLL],
            // Fuel Accessories and Spare Parts
            checkboxFUELAC: [{ value: true, disabled: true }],
            FUELAC: [impProducts.FUELAC ? impProducts.FUELAC : this.contractorsDropDowns.defaultFUELAC],
            // Rental Reimbursement
            checkboxRNOOLL: [{ value: true, disabled: true }],
            RNOOLL: [impProducts.RNOOLL ? impProducts.RNOOLL : this.contractorsDropDowns.defaultRNOOLL],
            // Trailers and Contents
            checkboxTRLCON: [{ value: true, disabled: true }],
            TRLCON: [impProducts.TRLCON ? impProducts.TRLCON : this.contractorsDropDowns.defaultTRLCON],
            // Equipment Borrowed from Others
            checkboxEQPBOR:[false],
            EQPBOR: [impProducts.EQPBOR ? impProducts.EQPBOR: 0],
            // Equipment Leased or rented from others
            checkboxEQPRNT: [{ value: true, disabled: true }],
            EQPRNT: [impProducts.EQPRNT ? impProducts.EQPRNT : this.contractorsDropDowns.defaultEQPRNT],
            // Replacement cost valuation
            checkboxCTRRPL: [{ value: true, disabled: true }],
            CEQVAL: [impProducts.CEQVAL ? impProducts.CEQVAL : "R"],
            // Down the hole endorsement
            DOWHOL: [impProducts.DOWHOL == "Y" ? true : false]
        });	

        //need default values to fill in obj graph if formGroup.valueChanges does not fire.
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRDED = (impProducts.CTRDED ? impProducts.CTRDED : this.contractorsDropDowns.defaultCTRDED);			
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRCNS = (impProducts.CTRCNS ? impProducts.CTRCNS : this.contractorsDropDowns.defaultCTRCNS);
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL = (impProducts.CTRSCL ? Number(impProducts.CTRSCL.toString().replace(/[^0-9.-]+/g,"")) : 0);
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUPL = (impProducts.CTRUPL ? impProducts.CTRUPL : this.contractorsDropDowns.defaultCTRUPL);		
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCPOLL = (impProducts.TCPOLL ? impProducts.TCPOLL : this.contractorsDropDowns.defaultTCPOLL);						
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELAC = (impProducts.FUELAC ? impProducts.FUELAC : this.contractorsDropDowns.defaultFUELAC);
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.RNOOLL = (impProducts.RNOOLL ? impProducts.RNOOLL : this.contractorsDropDowns.defaultRNOOLL);
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRLCON = (impProducts.TRLCON ? impProducts.TRLCON : this.contractorsDropDowns.defaultTRLCON);
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBOR = (impProducts.EQPBOR ? impProducts.EQPBOR : 0);
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPRNT = (impProducts.EQPRNT ? impProducts.EQPRNT : this.contractorsDropDowns.defaultEQPRNT);			
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.CEQVAL = (impProducts.CEQVAL ? impProducts.CEQVAL : "R");			
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.DOWHOL = (impProducts.DOWHOL == 'true' ? "Y" : "N");


		this.menuClass.stepActiveObject.forms[1] = this.formGroup;
	
		this.FormGroupSubscription = this.formGroup.valueChanges.pipe(debounceTime(100), distinctUntilChanged()).subscribe(data => {
			data = this.formGroup.getRawValue();

			if (this.formGroup.dirty) {
				this.menuClass.isQuoteDirty = true;
			}
			//validators for max amount on Scheduled tools and equipement
			if (this.checkboxCTRSCL.value) { 
				this.CTRSCL.setValidators(
					 [this.migLiabilityValidtor.ValidateMinValue( 'CTRSCL', 'Scheduled Tools and Equipment Total Limit', 1, 'must be at least', true), 
				 this.migLiabilityValidtor.ValidateMaxValue(5000000, 'CTRSCL', 'Scheduled Tools and Equipment Total Limit', 'cannot be >', true),
				this.migLiabilityValidtor.ValidateRequired('CTRSCL','Scheduled Tools and Equipment Total Limit')]); 
				
				this.CTRDED.setValidators(this.migLiabilityValidtor.ValidateRequired('CTRDED','Scheduled Tools and Equipment Deductible (Applies to Scheduled Tools and Equipment Only)'));
				this.CTRCNS.setValidators(this.migLiabilityValidtor.ValidateRequired('CTRCNS', 'Scheduled Tools and Equipment Coinsurance'));
			} else { 
				//SCHEDULED TOOLS AND EQUIOPMENT HAVE BEEN REMOVED RESET CTRSCL TO 0
				data.CTRSCL = "";
				this.CTRSCL.setValue("", {emitEvent: false});
				this.CTRSCL.setValidators(Validators.nullValidator); 
				//
				data.CTRDED = "";
				this.CTRDED.setValue("",{emitEvent: false});
				this.CTRDED.setValidators(Validators.nullValidator);
				//
				data.CTRCNS = "";
				this.CTRCNS.setValue("",{emitEvent: false});				
				this.CTRCNS.setValidators(Validators.nullValidator);
				//need to set the rate back to 0 also otherwise it stays at 1.5 even when removed.
				this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCR = 0;

				//set all items to RecordState 'D' for Scheduled Items
				this.ctrQuote.removeIMPScheduledItems();
			}
			
			this.CTRSCL.updateValueAndValidity({ emitEvent: false });
			this.CTRDED.updateValueAndValidity({ emitEvent: false });
			this.CTRCNS.updateValueAndValidity({ emitEvent: false });

			if (this.checkboxEQPBOR.value) {
				this.EQPBOR.setValidators(
					[this.migLiabilityValidtor.ValidateRequired('EQPBOR', 'Equipment Borrowed From Others')
				]);
			} else {
				this.EQPBOR.setValidators(Validators.nullValidator);
			}
			this.EQPBOR.updateValueAndValidity({emitEvent:false});

			this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRDED = (data.CTRDED ? data.CTRDED : 0);
			this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRCNS = (data.CTRCNS ? data.CTRCNS : "");
			this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL = (data.CTRSCL ? Number(data.CTRSCL.toString().replace(/[^0-9.-]+/g,"")) : 0);
			this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUPL = (data.CTRUPL ? data.CTRUPL : 0);		
			this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCPOLL = (data.TCPOLL ? data.TCPOLL : 0);						
			this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELAC = (data.FUELAC ? data.FUELAC : 0);
			this.ctrQuote.IMPENTITY.IMPPRODUCTS.RNOOLL = (data.RNOOLL ? data.RNOOLL : 0);
			this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRLCON = (data.TRLCON ? data.TRLCON : 0);
			this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBOR = (data.EQPBOR ? data.EQPBOR : 0);
			this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPRNT = (data.EQPRNT ? data.EQPRNT : 0);			
			this.ctrQuote.IMPENTITY.IMPPRODUCTS.CEQVAL = (data.CEQVAL ? data.CEQVAL : "");			
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.DOWHOL = (data.DOWHOL == true ? "Y" : "N");
            
            this.setRatesBasedOnLimits();

			this.migsystemservice.notifyQuoteChanged(this.ctrQuote);
			//updates errors
			this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive);
			this.formChanged = true;
			this.formGroup.updateValueAndValidity({emitEvent:false});
		});


		// check incomming data
		// we're not storing checkbox values in WINS
		// so set checkboxes based on form fields != ""
		this.processCoverage();

		this.updateRecordState = this.migsystemservice.subscribeUpdateRecordState().subscribe(() => {

			if (this.formChanged) {
				this.ctrQuote.IMPENTITY.IMPPRODUCTS.POLICY = this.ctrQuote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
				this.ctrQuote.IMPENTITY.IMPPRODUCTS.EFFDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
				this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRANS  = this.ctrQuote.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;
				this.ctrQuote.IMPENTITY.IMPPRODUCTS.RCDTYP = this.ctrQuote.QUOTEPOLICYINFORMATION.RECORDTYPE;
				this.ctrQuote.IMPENTITY.IMPPRODUCTS.EDSDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;
				this.ctrQuote.IMPENTITY.IMPPRODUCTS.RECORDSTATE = "U";
			}
		});

		this.cd.detectChanges();
    }

    determineDropdownOptions()
    {
        if (this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE < 20210401)
        {
            this.dropdownOptionsCTRUPL = this.contractorsDropDowns.preApril2021CTRUPL;
            this.dropdownOptionsTCPOLL = this.contractorsDropDowns.preApril2021TCPOLL;
            this.dropdownOptionsFUELAC = this.contractorsDropDowns.preApril2021FUELAC;
            this.dropdownOptionsRNOOLL = this.contractorsDropDowns.preApril2021RNOOLL;
            this.dropdownOptionsTRLCON = this.contractorsDropDowns.preApril2021TRLCON;
            this.dropdownOptionsEQPBOR = this.contractorsDropDowns.preApril2021EQPBOR;
            this.dropdownOptionsEQPRNT = this.contractorsDropDowns.preApril2021EQPRNT;
        }
        else
        {
            this.dropdownOptionsCTRUPL = this.contractorsDropDowns.CTRUPL;
            this.dropdownOptionsTCPOLL = this.contractorsDropDowns.TCPOLL;
            this.dropdownOptionsFUELAC = this.contractorsDropDowns.FUELAC;
            this.dropdownOptionsRNOOLL = this.contractorsDropDowns.RNOOLL;
            this.dropdownOptionsTRLCON = this.contractorsDropDowns.TRLCON;
            this.dropdownOptionsEQPBOR = this.contractorsDropDowns.EQPBOR;
            this.dropdownOptionsEQPRNT = this.contractorsDropDowns.EQPRNT;
        }
    }
    setUnscheduledToolsAndEquipRates() {
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUNR = 0;
        if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUPL == 250000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUNR = 0.64;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUPL == 225000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUNR = 0.68;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUPL == 200000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUNR = 0.72;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUPL == 175000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUNR = 0.78;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUPL == 150000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUNR = 0.83;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUPL == 125000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUNR = 0.90;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUPL == 100000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUNR = 0.96;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUPL == 75000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUNR = 1.06;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUPL == 50000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUNR = 1.21;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUPL == 40000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUNR = 1.31;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUPL == 30000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUNR = 1.45;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUPL == 20000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUNR = 1.66;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUPL == 10000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUNR = 2.00;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUPL == 5000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUNR = 2.32;
        }
    }
    setEmployeeToolsAndClothingRates() {
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCRATE = 0;
        if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCPOLL == 100000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCRATE = 0.96
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCPOLL == 75000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCRATE = 1.06
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCPOLL == 50000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCRATE = 1.21
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCPOLL == 45000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCRATE = 1.26
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCPOLL == 40000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCRATE = 1.31
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCPOLL == 35000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCRATE = 1.37
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCPOLL == 30000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCRATE = 1.45
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCPOLL == 25000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCRATE = 1.54
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCPOLL == 20000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCRATE = 1.66
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCPOLL == 15000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCRATE = 1.83
        }
        else if(this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCPOLL == 10000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCRATE = 2.00
        }
    }
    setTotalLimitRates() {
        if(this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL > 0 && this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL <= 100000){
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCR = 1.15;
        }
        else if(this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL > 100000 && this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL <= 250000){
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCR = 0.84;
        }
        else if(this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL > 250000 && this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL <= 500000){
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCR = 0.70;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL > 500000 && this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL <= 1000000){
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCR = 0.62;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL > 1000000 && this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL <= 5000000){
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCR = 0.51;
        }
        else {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCR = 0;
        }
    }
    setFuelAccSparePartsRates() {
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELRT = 0;
        if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELAC == 100000)
        { 
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELRT = 1.04;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELAC == 75000)
        { 
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELRT = 1.15;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELAC == 50000)
        { 
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELRT = 1.32;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELAC == 45000)
        { 
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELRT = 1.37;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELAC == 40000)
        { 
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELRT = 1.43;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELAC == 35000)
        { 
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELRT = 1.50;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELAC == 30000)
        { 
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELRT = 1.58;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELAC == 25000)
        { 
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELRT = 1.68;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELAC == 20000)
        { 
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELRT = 1.81;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELAC == 15000)
        { 
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELRT = 2.00;
        }
    }
    setRentalReimbursementRates() {
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.RNRRTE = 0;
        if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.RNOOLL == 50000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.RNRRTE = 0.83;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.RNOOLL == 45000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.RNRRTE = 0.86;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.RNOOLL == 35000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.RNRRTE = 0.93;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.RNOOLL == 30000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.RNRRTE = 0.99;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.RNOOLL == 25000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.RNRRTE = 1.05;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.RNOOLL == 20000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.RNRRTE = 1.13;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.RNOOLL == 15000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.RNRRTE = 1.25;
        }
    }
    setTrailersAndContentsRates() {
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRLRTE = 0;
        if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRLCON == 150000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRLRTE = 1.36;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRLCON == 125000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRLRTE = 1.48;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRLCON == 100000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRLRTE = 1.58;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRLCON == 75000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRLRTE = 1.74;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRLCON == 50000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRLRTE = 2.00;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRLCON == 40000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRLRTE = 2.16;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRLCON == 30000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRLRTE = 2.38;
        }
    }
    setEquipBorrowedRates() {
        if (!(this.checkboxEQPBOR.value)) {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBOR = 0
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBRT = 0;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBOR == 250000) {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBRT = 1.05;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBOR == 225000) {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBRT = 1.12;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBOR == 200000) {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBRT = 1.18;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBOR == 175000) {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBRT = 1.28;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBOR == 150000) {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBRT = 1.36;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBOR == 125000) {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBRT = 1.48;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBOR == 100000) {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBRT = 1.58;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBOR == 75000) {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBRT = 1.74;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBOR == 50000) {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBRT = 2.00;
        }
    }
    setEquipRentedRates() {
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPRRT = 0
        if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPRNT == 250000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPRRT = 1.34;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPRNT == 225000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPRRT = 1.43;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPRNT == 200000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPRRT = 1.49;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPRNT == 175000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPRRT = 1.62;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPRNT == 150000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPRRT = 1.73;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPRNT == 125000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPRRT = 1.88;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPRNT == 100000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPRRT = 2.00;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPRNT == 75000)
        {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPRRT = 2.21;
        }
    }
    setRatesBasedOnLimits()
    {
        //Per Chris, if effective date is prior to April 1st, 2021, we need to use the old rates and limits.
        if (this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE < 20210401)
        {
            this.usePreApril2021RatesBasedOnLimits();
            return;
        }

        this.setEmployeeToolsAndClothingRates();
        this.setTotalLimitRates();
        this.setUnscheduledToolsAndEquipRates();
        this.setFuelAccSparePartsRates();
        this.setRentalReimbursementRates();
        this.setTrailersAndContentsRates();
        this.setEquipBorrowedRates();
        this.setEquipRentedRates();
    }
    usePreApril2021RatesBasedOnLimits()
    {
        if(this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCPOLL > 5000){ this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCRATE = 2.5 }

        //ADDED FOR RATING 20190506
        if(this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL > 0 && this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL <= 100000){
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCR = 1.5;
        }
        else if(this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL > 100000 && this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL <= 250000){
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCR = 0.9;
        }
        else if(this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL > 250000 && this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL <= 500000){
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCR = 0.8;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL > 500000 && this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL <= 1000000){
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCR = .65;
        }
        else if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL > 1000000 && this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL <= 5000000){
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCR = .60;
        }
        else {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCR = 0;
        }

        //ADDED FOR RATING 20190506
        if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUPL > 3000){ this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUNR = 2.5; }
        else { this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUNR = 0; }

        //ADDED FOR RATING 20190506
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELRT = 0;
        if(this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELAC > 10000){ this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELRT = 2.5; }

        //ADDED FOR RATING 20190506
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRLRTE = 0;
        if(this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRLCON > 25000){ this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRLRTE = 2.5; }

        //ADDED FOR RATING 20190506
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPRRT = 0
        if(this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPRNT > 50000){ this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPRRT = 2.5; }

        //ADDED FOR RATING 20190506
        // this check box is not read only and can be toggled, so need to check if they de-select it
        if (this.checkboxEQPBOR.value){
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBRT = 2.5;
        }
        else{
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBOR = 0
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBRT = 0;
        }
    }

	processCoverage() {
		// Scheduled Tools and Equipment
		if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRSCL) { this.checkboxCTRSCL.setValue(true); }

		// Replacement Cost Valuation
		if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.CEQVAL) { this.checkboxCTRRPL.setValue(true); }

		// Equipment Borrowed From Others
		if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPBOR) { this.checkboxEQPBOR.setValue(true); }
	}

	ngOnDestroy(): void {
		//Called once, before the instance is destroyed.
		//Add 'implements OnDestroy' to the class.
		if(this.FormGroupSubscription) this.FormGroupSubscription.unsubscribe();
		this.cd.detach();
		
	}

	CalcAllCoveredProperty(val, pos) {
		// this.arr[pos] = Number(val.replace(/[^0-9\.-]+/g,""));

		// let out = this.currencyPipe.transform((this.arr[0] + this.arr[1] + this.arr[2]), "$", 0,",", ".", 3);
		// this.globals.formData.input_all_covered_property_included_in_abc = out;

	}
}
