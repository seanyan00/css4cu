import { Validation } from '@classes/Common/ValidatorClass/Validation';

export class MIGLocationSummaryValidator extends Validation {
	constructor() {
        super();
	}
}
