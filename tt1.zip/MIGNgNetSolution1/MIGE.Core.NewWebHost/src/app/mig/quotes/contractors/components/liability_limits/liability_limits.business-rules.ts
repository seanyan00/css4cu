import { AbstractControl,ValidatorFn, FormGroup} from "@angular/forms";
import { Functions } from '@helpers/functions';
import { Validation } from '@classes/Common/ValidatorClass/Validation';
import { IQuote } from "@interfaces/IQuote";
import { BOPQuote } from "@classViewModels/BOP/BOPQuote";
import { BOPLOCATION } from "@mig/quotes/business-owners/classes/BOPLOCATION";
import { BOPBUILDING } from "@mig/quotes/business-owners/classes/BOPBUILDING";

export class LiabilityLimitsBR extends Validation {
    constructor(public func: Functions) {
        super();
    }

    hasSegment(segment: string, quote: IQuote) : boolean { // pass in a particular segment (ex: "RETL"), will return true if a building on the quote has that segment.
        let segmentFlag = false;
        if(quote instanceof BOPQuote){
            quote.getTotalLocations().forEach((location: BOPLOCATION) => {
            location.getTotalBuildings().forEach(building => {
                if(building.BLDSEG == segment || building.BPPSEG == segment){
                segmentFlag = true;
                }
            });
            });
        }
        return segmentFlag;
      }

      hasClass(bClass: string, quote: IQuote) : boolean { // pass in a particular class (ex: "131380"), will return true if a building on the quote has that class.
        let classFlag = false;
        if(quote instanceof BOPQuote) {
            quote.getTotalLocations().forEach((location: BOPLOCATION) => {
            location.getTotalBuildings().forEach(building => {
                if(building.BLDCLS == bClass || building.BPPCLS == bClass){
                classFlag = true;
                }
            });
            });
        }
        return classFlag;
      }

      includeEmploymentPracticesLiability(quote: IQuote): boolean {
        /*
        Included coverage, default to $100,000 unless any of the following is true, then display 'Excluded' as read only and do not display Deductible, Retro Date or Third Party Endorsement.
       - Total Number of Employees (DW5P120.EMPLNOE) > 250
       - Class code on any building = 131342 (BLDCLS or BPPCLS)
       - Location state = VT (DW5P130.LOCST = 44) */
        let flag = true;
        if(quote instanceof BOPQuote){
            if(quote.QUOTEPERSONALINFO.EMPLNOE > 250) {
            flag = false; 
            }
            quote.getTotalLocations().forEach((loc: BOPLOCATION) => {
                if(loc.ADDRESS.STATE == "44"){
                    flag = false;
                }
                loc.getTotalBuildings().forEach((bld:BOPBUILDING) => {
                    if(bld.BLDCLS == "131342" || bld.BPPCLS == "131342"){
                        flag = false;
                    }
                });
            });
        }
        return flag;
      }
      
    showLiquorLegalLiability(quote: IQuote): boolean {
        //Will be displayed and selected (unable to de-select) when liquor receipts is greater than 0 (DW5P136.LIQAOR > 0)
        let flag = false;

        if(quote instanceof BOPQuote){
            quote.getTotalLocations().forEach((loc: BOPLOCATION) => {
                loc.getTotalBuildings().forEach((bld:BOPBUILDING) => {
                    if(bld.LIQUORLIABILITY.LIQAOR > 0) {
                        flag = true; 
                    }
                });
            });
        }
        return flag;
    }

    //compareOccurrenceAggregateLimits(quote:IQuote) : 

}



