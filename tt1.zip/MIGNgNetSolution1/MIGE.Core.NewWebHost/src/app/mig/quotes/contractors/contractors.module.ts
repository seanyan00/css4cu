import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MIGOverlayPanelModule } from '@overridden/primeng-overlaypanel/overlay.module';
import { MIGFileUploadModule } from '@overridden/primeng-fileupload/fileupload';
import { PipesModule } from '@pipes/pipes.module';
import { ContractorsComponent } from '@root/mig/quotes/contractors/contractors.component';
import { ApplicationCompleteModule } from '@shared/application_complete/application_complete.module';
import { FinishApplicationModule } from '@shared/finish_application/finish_application.module';
import { ReferralsModule } from '@shared/referrals/referrals.module';
import { ReportItemModule } from '@shared/report_item/report_item.module';
import { RiskAppetiteGuideModule } from '@shared/risk-appetite-guide/risk-appetite-guide.module';
import { TestingModule } from '@shared/testing/testing.module';

import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ToastModule } from 'primeng/toast';
import { PanelModule } from 'primeng/panel';
import { DomHandler } from 'primeng/dom';
import { ErrorModule } from '@shared/errors/errors.module';
import { ChangeLogModule } from '@shared/changelog/changelog.module';
import { ProgressModule } from '@shared/progress/progress.module';
import { MessageService } from 'primeng/api';

import { QuoteInformationModule } from '@shared/quote_information/quote_information.module';
import { LiabilityLimitsModule } from '@CTRcomponents/liability_limits/liability_limits.module';
import { LocationSummaryModule } from '@CTRcomponents/location_summary/location_summary.module';
import { AdditionalCoveragesModule } from '@CTRcomponents/additional_coverages/additional_coverages.module';
import { AdditionalCoveragesLiabilityModule } from '@CTRcomponents/additional_coverages/liability/coverage.liability.component.module';
import { AdditionalCoveragesInlandModule } from '@CTRcomponents/additional_coverages/inland/coverage.inland.component.module';
import { AdditionalCoveragesPropertyModule } from '@CTRcomponents/additional_coverages/property/coverage.property.component.module';
import { PremiumSummaryModule } from '@CTRcomponents/premium_summary/premium_summary.module';
import { UnderwritingModule } from '@shared/underwriting/underwriting.module';
import { MIGAdditionalInformationStubModule } from '@shared/additional_information/additional_information_stub/additionalinformation.module';
import { MIGAdditionalInformationAdditionalInsuredsModule } from '@shared/additional_information/additional_insureds/insureds.module';
import { MIGAdditionalInformationScheduledItemsModule } from '@shared/additional_information/scheduled_items/items.module';
import { MIGAdditionalInformationDesignatedConstructionProjectsModule } from '@shared/additional_information/designated_construction_projects/designated_construction_projects.module';
import { DiscretionaryWorkSheetModule } from '@shared/Discretionary_WorkSheet/discretionary-worksheet.module';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { LansaAcctManagementModule } from '@shared/lansa_account_manage/lansa-acct-management.module';
import { ContractorsRoutingModule } from './contractors-routing.module';

//import { GrowlModule } from 'primeng/growl';
//import { LoadingModule } from '@shared/loading/loading.module';
//import { UnderwritingTriggerModule } from '@shared/underwriting_trigger/trigger.module';

@NgModule({
	imports: [
		 //BrowserAnimationsModule,
		 ContractorsRoutingModule,
		// MIGButtonModule,
		CommonModule,
		// ConfirmDialogModule,
		// FormsModule,
		//GrowlModule,
		// PanelModule,
		// RiskAppetiteGuideModule,
		// MIGOverlayPanelModule,
		// PipesModule,
		// ReportItemModule,
		// ReactiveFormsModule,
		// MIGFileUploadModule,
		TestingModule,
		ErrorModule,
		ChangeLogModule,
		ProgressModule,
		// ToastModule,
		// SystemErrorModule,
		LansaAcctManagementModule, // added 20190627 for a link menu step to return to acct management
		QuoteInformationModule, // these steps modules need to be in order of
		LiabilityLimitsModule, // how they need to appear in the menu
		LocationSummaryModule, // as the menu is controlled by each sub component's module
		AdditionalCoveragesModule, // as they get loaded, here, in this component,
		AdditionalCoveragesLiabilityModule, // they'll inject their menu step into the menu
		AdditionalCoveragesInlandModule, // all of these
		AdditionalCoveragesPropertyModule, // anything that is a major step in the process
		PremiumSummaryModule, // no subcomponents need to be in order
		DiscretionaryWorkSheetModule, // this one too
		UnderwritingModule, // this one too
		MIGAdditionalInformationStubModule, // this one too
		MIGAdditionalInformationAdditionalInsuredsModule, // this one too
        MIGAdditionalInformationScheduledItemsModule, // this one too
        MIGAdditionalInformationDesignatedConstructionProjectsModule,
		ReferralsModule, // this one too
		FinishApplicationModule, // this one too
		ApplicationCompleteModule
		
	],
	declarations: [
		ContractorsComponent
	],
	providers: [DomHandler, MessageService ],
})
export class ContractorsModule {

	constructor() {}
 }
