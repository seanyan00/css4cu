import { Component, Input, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, UntypedFormControl } from '@angular/forms';
import { Subscription } from 'rxjs/internal/Subscription';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { Functions } from '@helpers/functions';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { MIGPropertyResources } from './optional.resources';
import { MIGSystemService } from '@services/mig.service';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

@Component({
	selector: 'mig-coverage-property-optional',
	templateUrl: './optional.component.html',
})

export class MIGCoveragePropertyOptional implements OnInit {
	// optionsCoinsurance: any = ["80%", "90%", "100%"];
	// optionsDeductibleGlass: any = ["$250", "$500", "$1,000", "$2,500", "$5,000", "$10,000"];
	// optionsValuation: any = ["RCV", "ACV"];

	formBuilder: UntypedFormBuilder;
	formChanged: boolean = false;

	FormGroupSubscription: Subscription;
	updateRecordState: Subscription;

	migPropertyResources = new MIGPropertyResources();

	showHideEarthquake: boolean = false;

	@Input() ctrQuote: CTRQuote;
	@Input() formGroup: UntypedFormGroup;

	constructor(
		public func: Functions,
		public contractorsDropDowns: ContractorsDropDowns,
		public migsystemservice: MIGSystemService,
		public migRoles: MIGSecurityRoles
	) {
		if (this.formBuilder == null) {
			this.formBuilder = new UntypedFormBuilder();
		}
	}

	ngOnInit() {
		let cfpCov = this.ctrQuote.CFPENTITY.CFPCOVERAGES;

		this.formGroup.addControl('checkboxBINTIM', new UntypedFormControl({ value: true, disabled: true }));
		this.formGroup.addControl('BINTIM', new UntypedFormControl((cfpCov.BINTIM ? cfpCov.BINTIM : "72")));

		this.formGroup.addControl('EQUAKE', new UntypedFormControl(cfpCov.EQUAKE == 'Y' ? true : false));

		this.FormGroupSubscription = this.formGroup.valueChanges.pipe(debounceTime(100), distinctUntilChanged()).subscribe(data => {			
			let processedBINTIM = this.migPropertyResources.processBINTIM(data.BINTIM);
					
			this.ctrQuote.CFPENTITY.CFPCOVERAGES.BINTIM = processedBINTIM ? processedBINTIM : "";						
			this.ctrQuote.CFPENTITY.CFPCOVERAGES.EQUAKE = (data.EQUAKE ==true) ? 'Y' : 'N';
			this.formChanged = true;
		});

		this.migPropertyResources.setCTRQuote(this.ctrQuote);
		this.showHideEarthquake = this.migPropertyResources.processEarthquake();

		this.updateRecordState = this.migsystemservice.subscribeUpdateRecordState().subscribe(() => {

			if (this.formChanged) {
				this.ctrQuote.CFPENTITY.CFPCOVERAGES.POLICY = this.ctrQuote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
				this.ctrQuote.CFPENTITY.CFPCOVERAGES.EFFDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
				this.ctrQuote.CFPENTITY.CFPCOVERAGES.TRANS = this.ctrQuote.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;
				this.ctrQuote.CFPENTITY.CFPCOVERAGES.RCDTYP = this.ctrQuote.QUOTEPOLICYINFORMATION.RECORDTYPE;
				this.ctrQuote.CFPENTITY.CFPCOVERAGES.EDSDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;
				this.ctrQuote.CFPENTITY.CFPCOVERAGES.RECORDSTATE = "U";
			}
		});
	}

	get checkboxBINTIM() { return this.formGroup.get("checkboxBINTIM"); }
	get BINTIM() { return this.formGroup.get("BINTIM"); }
	get EQUAKE() { return this.formGroup.get("EQUAKE"); }
}
