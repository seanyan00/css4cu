import { Validation } from '@classes/Common/ValidatorClass/Validation';


export class MIGValidatorExtension extends Validation {
	constructor() {
		super();
    
	}
	

}