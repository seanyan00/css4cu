/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule, UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';

import { PanelModule } from 'primeng/panel';
import { TabViewModule } from 'primeng/tabview';
import { TooltipModule } from 'primeng/tooltip';
import { CalendarModule } from 'primeng/calendar';
import { CheckboxModule } from 'primeng/checkbox';
import { FieldsetModule } from 'primeng/fieldset';
import { InputTextModule } from 'primeng/inputtext';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';

import { MIGCoveragePropertyExtension } from './extension/extension.component';
import { MIGCoveragePropertyOptional } from './optional/optional.component';
import { MIGInputSwitchModule } from '@overridden/primeng-inputswitch/switch.module';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { TextMaskModule } from 'angular2-text-mask';
import { MIGAdditionalCoveragesProperty } from './coverage.property.component';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';
import { PipesModule } from '@pipes/pipes.module';
import { MenuClass } from '@root/system/menu/menu';


@NgModule({
	imports: [
		MIGButtonModule,
		CalendarModule,
		FieldsetModule,
		CheckboxModule,
		FormsModule,
		TabViewModule,
		CommonModule,
		FieldsetModule,
		PanelModule,
		MIGDropDownModule,
		InputTextModule,
		MIGInputSwitchModule,
		MIGInputtextModule,
		TextMaskModule,
		MIGCheckboxModule,
		ReactiveFormsModule,
		PipesModule,
		TooltipModule
	],
	declarations: [
		MIGCoveragePropertyExtension,
		MIGCoveragePropertyOptional,
		MIGAdditionalCoveragesProperty
	],
	exports: [MIGAdditionalCoveragesProperty]
})
export class AdditionalCoveragesPropertyModule {
	formGroup: UntypedFormGroup;
	constructor(
		public menuClass: MenuClass,
		private formBuilder: UntypedFormBuilder,
	) {
		this.formGroup = this.formBuilder.group({});

		menuClass.addMenuItem({
			name: 'AdditionalCoveragesProperty',
			label: 'Property',
			color: "ui-steps-number-default",
			navSkip: false,
			active: false,
			hasError: false,
			errors: [],
			buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }, { button: "GetQuoteNow" }],
			form: this.formGroup,
			icon: "fa fa-warehouse",
			level: 2,
			block: [],
			visible: false,
			quote: "premium"
		});
	}
 }
