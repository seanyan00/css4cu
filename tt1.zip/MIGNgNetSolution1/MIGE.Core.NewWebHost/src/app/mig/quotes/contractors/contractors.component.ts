import { Component, OnInit, ViewEncapsulation, OnDestroy, ChangeDetectorRef, Inject } from '@angular/core';
import { Subscription } from 'rxjs';
import * as _ from "lodash";
import diff from 'deep-diff';
import { finalize } from 'rxjs/operators';
import { ConfirmationService } from 'primeng/api';
import { MessageService } from 'primeng/api';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { MIGSystemService } from '@services/mig.service';
import { QuoteService } from '@services/quote.service';
import { AuthService } from '@auth/auth.service';
import { TokenResponse } from '@auth/tokenresponse.class';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { MenuClass } from '@root/system/menu/menu';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { CTRQuoteClass } from '@classViewModels/CTR/quote.class';
import { environment } from '@environment/environment';
import { IQuote } from '@interfaces/IQuote';
import { PolicyService } from '@root/services/policy.service';
import { DOCUMENT } from "@angular/common";
import { UnderwritingService } from '@root/services/underwriting.service';
import { MIGLiabilityResources } from '@CTRcomponents/additional_coverages/liability/extension/extension.resources';
import { IMPPRODUCTS } from '@classes/CTR/IMPPRODUCTS';
import { IMPJOBSITES } from '@classes/CTR/IMPJOBSITES';
import { QUOTEPOLICYLIABLIMITS } from '@classes/CTR/QUOTEPOLICYLIABLIMITS';
import { DiscretionaryClass } from '@shared/Discretionary_WorkSheet/discretionary-class';

@Component({
	selector: 'mig-contractors-component',
	templateUrl: './contractors.component.html',
	styleUrls: ['contractors.component.css'],
	encapsulation: ViewEncapsulation.None,
	providers: [ConfirmationService]
})

export class ContractorsComponent implements OnInit, OnDestroy {
    ngOnDestroy(): void {
       if(this.quoteServiceSubscription) this.quoteServiceSubscription.unsubscribe();
        if(this.stepChangeSubscription) this.stepChangeSubscription.unsubscribe();
        this.cd.detach();
    }
    activeMenuItemIndex: number;
    activeMenuItem: any = {name: 'default'};
	roles: any[] = [];
    isInRole: boolean = false;
    //this controls whether we see the testing controls or not
    showTestingControls: boolean = true;
	token: TokenResponse;

	sessionid:string = '';
	//for testing redirect to Acct Management 
	//sessionid:string = 'L024C0F6480706101DC0F07032019075802';
	lansaUrl:string = environment.lansaAcct; 
    quote_id: string = '';
    effective_date: number = 20210306;
    endorsement_date: number = 20210306;
    endorsement_number: number = 0;
    transaction_type: string = 'N';
	// contractors html is made up of multiple sub blocks
	// set our initial value to "block" while we load data
	subStep: string = "block";

    // our quote class
    ctrQuote: CTRQuote;
    product:string;
    private ctrQuoteMemento: CTRQuote;
	
	quoteInfoOut: any;
	messages:any[]= []; 
	// our subscriptions to various notifications
	quoteServiceSubscription: Subscription;
	displayToastMessages: boolean = false; 
    private stepChangeSubscription: Subscription = null;
    /** new 20210330 */
    showDiscretionaryWorksheet:boolean = false;


	constructor(
		public authService: AuthService,
		public confirmationService: ConfirmationService,
		public quoteService: QuoteService,
		public policyService: PolicyService,
		public contractorsDropDowns: ContractorsDropDowns,
		public migsystemservice: MIGSystemService,
		public menuClass: MenuClass,
		public messageService: MessageService,
		public migRoles: MIGSecurityRoles,
		public ctrQuoteClass: CTRQuoteClass,
        public cd: ChangeDetectorRef,
        public underwritingService: UnderwritingService,
        private discClass: DiscretionaryClass,
        @Inject(DOCUMENT) public document: Document
	) {
		//getAuth Token for getQuote from Lansa
		this.token = authService.getAuth();
		if(this.token != null){
            this.sessionid = this.token.SessionId;
            this.transaction_type = this.token.TransType;
        }
        this.product = this.authService.LOB;
		this.ctrQuote = new CTRQuote();
		// ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** 
		if (environment.production) {
            this.ctrQuote.POLICYTRANS.POLICY = this.token.QuoteId;
            this.ctrQuote.POLICYTRANS.EFFDTE = this.token.EffectiveDate;
            this.ctrQuote.POLICYTRANS.EDSDTE = this.token.EndorsementDate;
            this.ctrQuote.POLICYTRANS.EDSNO = this.token.EndorsementNo;
            this.ctrQuote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER = this.token.QuoteId;
            this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE = this.token.EffectiveDate;
            this.ctrQuote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE = this.token.EndorsementDate;
            this.ctrQuote.QUOTEPOLICYINFORMATION.ENDORSEMENTNUMBER = this.token.EndorsementNo;
            this.ctrQuote.QUOTEPOLICYINFORMATION.TRANSACTIONTYPE = this.token.TransType;
		} else {
            
            //TODO: uncomment this section out and remove token code

            this.ctrQuote.POLICYTRANS.POLICY = this.quote_id;

            this.ctrQuote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER = this.quote_id;
            //this.ctrQuote.QUOTEPOLICYINFORMATION.TRANSACTIONTYPE = this.transaction_type;
           
            if (this.transaction_type == "PI")
            {
                this.ctrQuote.POLICYTRANS.EFFDTE = this.effective_date;
                this.ctrQuote.POLICYTRANS.EDSDTE = this.endorsement_date;
                this.ctrQuote.POLICYTRANS.EDSNO = this.token.EndorsementNo;
                this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE = this.effective_date;
                this.ctrQuote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE = this.endorsement_date;
                this.ctrQuote.QUOTEPOLICYINFORMATION.ENDORSEMENTNUMBER = this.token.EndorsementNo;
            }
		}
		// ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** **
        //console.log(this.ctrQuote);

        if (this.ctrQuote.QUOTEPOLICYINFORMATION.TRANSACTIONTYPE.toUpperCase() == "PI")
        {
			this.policyService.GetPolicy(this.ctrQuote)
				.pipe(finalize(()=>{}))
				.subscribe(response => {
                    this.ctrQuote = new CTRQuote(<CTRQuote>response);
					//UPDATE set menu to 3 to skip the first 3 menu steps and display quote info
					this.migsystemservice.notifyBlock(this.menuClass.menu[3].block);
                    this.beginQuoteChangeDetection();
                    migsystemservice.notifyQuoteChanged(this.ctrQuote);
                    this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Contractors', detail: "Loaded!", event: "end" });
				});
        }
        else
        {
                this.quoteService.GetQuote(this.ctrQuote)
				.pipe(finalize(()=>{ 
				}))
				.subscribe(response => {
                    this.ctrQuote = new CTRQuote(<CTRQuote>response);
					//UPDATE set menu to 1 to skip Accountmanagment module and display quote info
					this.migsystemservice.notifyBlock(this.menuClass.menu[1].block);
                    this.beginQuoteChangeDetection();
                    migsystemservice.notifyGetQuote(this.ctrQuote);
                    migsystemservice.notifyQuoteChanged(this.ctrQuote);
                    if( this.authService.retryPremium == 0){ //When we we retry premium we are doing a seperate notify block so don't want this to show -ZJG
                        this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Contractors', detail: "Loaded!", event: "end" });
                    }
                     /** new 20210330 */
                     this.showDiscretionaryWorksheetMenu(this.ctrQuote);
				});
        }
        
		//Subscribe to Save Quote notify here;moved out of quote.class.ts
		//because UWQ was not being sent to backend and subscribeQuoteChanged is in this constructor		
		this.migsystemservice.subscribeSaveQuote().subscribe(redirect => {

            if (!this.migRoles.editable) {                
                if(redirect){
                    this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Contractors', detail: 'Exiting......', event: "start" })
					let btn = this.document.getElementById('btnAcctManagement');
					btn.click();
				}
                return;
            }

            if (this.ctrQuote.QUOTEPOLICYINFORMATION.NEWEFFECTIVEDATE > 0)
            {
                //if new effective date is April 1st, 2021 or later, and old effective date is before April 1st, 2021
                //we need to reset inland marine rates and limits.
                if ((this.ctrQuote.QUOTEPOLICYINFORMATION.NEWEFFECTIVEDATE >= 20210401) && (this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE < 20210401))
                {
                    this.ensureDefaultImpProducts(true);
                    this.ensureDefaultImpJobsites(true);
                }
                //if new effective date before April 1st, 2021, and old effective date is on or after April 1st, 2021
                //we need to reset inland marine rates and limits.
                if ((this.ctrQuote.QUOTEPOLICYINFORMATION.NEWEFFECTIVEDATE < 20210401) && (this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE >= 20210401))
                {
                    this.ensureDefaultImpProducts(true);
                    this.ensureDefaultImpJobsites(true);
                }
            }
            
            this.quoteChangesDetected();
            
            this.migsystemservice.notifyUpdateRecordState();
            
            let saveQuoteDetailMessage: string = 'Saving quote. Please wait.'
			this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Contractors', detail: saveQuoteDetailMessage, event: "start" })
            /** */
            //this.messageService.add({ severity: 'info', summary: 'Contractors', detail: saveQuoteDetailMessage });
            
			this.quoteService.SaveQuote(this.ctrQuote).subscribe(quoteInfo => {
                this.ctrQuote = new CTRQuote(quoteInfo as CTRQuote);
                this.beginQuoteChangeDetection();
                this.migsystemservice.notifyQuoteChanged(this.ctrQuote);
				this.migsystemservice.notifySystemNotification({ severity: 'success', summary: 'Contractors', detail: 'Quote Saved. ', event: "end" });
                //this.messageService.add({ severity: 'success', summary: 'Contractors', detail: 'Quote Saved. ' });
                
                
				if(redirect){
					let btn = this.document.getElementById('btnAcctManagement');
					btn.click();
				}

			}, (error) => {
				this.migsystemservice.notifySystemNotification({ severity: 'error', summary: 'Contractors', detail: 'Quote Save Failed. ', event: "end" })

			}, () => {

			})
		});
		
		this.migsystemservice.subscribeCopyQuote().subscribe(() => {
            this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Contractors', detail: 'Copying quote. Please wait.', event: "start" });
            this.underwritingService.getUWQuestions(this.ctrQuote)
			.pipe(
				finalize(() => {
				})
			)
			.subscribe(data => {
				this.ctrQuote.UWQUESTIONSCATEGORY = data.UWQUESTIONSCATEGORY;
				this.quoteService.CopyQuote(this.ctrQuote)
                .pipe(finalize(()=>{ 
                }))
                .subscribe(response => {
                    this.migsystemservice.notifySystemNotification({ severity: 'success', summary: 'Contractors', detail: 'Quote Copied!  New Quote Number: ' + response.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER, event: "end" });
                    this.ctrQuote = new CTRQuote(<CTRQuote>response);
                    this.beginQuoteChangeDetection();
                    this.migsystemservice.notifyGetQuote(this.ctrQuote);
                    // Staying consistant with WorkersComp component
                   // this.migsystemservice.notifyQuoteChanged(this.ctrQuote);
                    //enable insured and address for the new copied quote
                    if (this.menuClass.stepActiveObject.name == "QuoteInformation")
                    {
                        this.menuClass.stepActiveObject.forms.forEach(element => {
                            if (element.get('INSTEL') != null) 
                                element.get('INSTEL').enable();   
                            if (element.get('INSNAM') != null) 
                                element.get('INSNAM').enable();    
                            if (element.get('INSAD1') != null) 
                                element.get('INSAD1').enable();                                                                                        
                            if (element.get('POBOX') != null) 
                                element.get('POBOX').enable();
                            if (element.get('SUITENUMBER') != null) 
                                element.get('SUITENUMBER').enable();
                            if (element.get('STREETNUMBER') != null) 
                                element.get('STREETNUMBER').enable();                                 
                            if (element.get('STREETNAME') != null) 
                                element.get('STREETNAME').enable();                                
                            if (element.get('ADDRESSLINE2') != null) 
                                element.get('ADDRESSLINE2').enable();
                            if (element.get('CITY') != null) 
                                element.get('CITY').enable();
                            if (element.get('STATE') != null) 
                                element.get('STATE').enable();   
                            if (element.get('ZIPCODE') != null) 
                                element.get('ZIPCODE').enable();                                                                   
                        });
                    }
                    //take them back to the quote information screen
                    this.menuClass.GotoMenuItem('name', 'QuoteInformation');
                    this.cd.detectChanges();
                },
                error => {
                    this.migsystemservice.notifySystemNotification({ severity: 'error', summary: 'Contractors', detail: 'Copy Quote Failed...', event: "end" });
                });
                },
            error => {
                this.migsystemservice.notifySystemNotification({ severity: 'error', summary: 'Contractors', detail: 'Copy Quote Failed...', event: "end" });
			});
            
		});


        this.migsystemservice.subscribeSystemNotification().subscribe((systemNotification) => {
            if ((systemNotification.severity == "success") && (systemNotification.detail == "Quote Saved. ") 
                && ((this.activeMenuItem.name == "PremiumSummary") || (this.activeMenuItem.name == "LocationSummary")))
            {                
                //Whenever we save, the quote changes (notifyQuoteChanged), and we rebuild the menu steps for Location Summary (see location_summary.module.ts).
                //We need to make sure a Location Summary current active step remains active after we rebuild the menu steps.

                //This code is also necessary if a user is navigating to Premium Summary.
                this.menuClass.gotoStep(this.activeMenuItemIndex);
                this.cd.detectChanges();
            }
        });

        this.migsystemservice.subscribePremium().subscribe((premium) => {
            this.beginQuoteChangeDetection();
        });

        this.migsystemservice.subscribeGetQuoteNow().subscribe(() => {
            this.getQuoteNow();
            this.menuClass.gotoStep(this.menuClass.menuObjectIndex("PremiumSummary"));
        });

        this.migsystemservice.subscribeQuoteChanged().subscribe(quoteInfo=> {
            this.ctrQuote = quoteInfo as CTRQuote;
			this.handleUserRoleRestrictions(this.ctrQuote);
			this.ctrQuote.ADDITIONALINSUREDSVALIDATED = false;
			this.ctrQuote.CONSTPROJVALIDATED = false;
            this.ctrQuote.SCHEDITEMSVALIDATED = false;
			if (this.ctrQuote.POLICYTRANS != null && this.ctrQuote.POLICYTRANS.POLICY != "") {
                
                this.quoteChangesDetected();
                
                if ((this.ctrQuote.POLICYTRANS.APRP == 0) || (this.ctrQuote.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'N') || (this.ctrQuote.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'I'))
                {
                    this.menuClass.isQuoteDirty = true;
                }
                
                this.menuClass.NeedNewPremSummary();

			}
        });
		
		this.migsystemservice.subscribeFirstLocationStateChanged().subscribe(() => {
            this.ctrQuote.IMPENTITY.IMPPRODUCTS = new IMPPRODUCTS(this.ctrQuote.QUOTEPOLICYINFORMATION);
            this.ctrQuote.IMPENTITY.IMPPRODUCTS.POLICY = "";

            this.ctrQuote.IMPENTITY.IMPJOBSITES = new IMPJOBSITES(this.ctrQuote.QUOTEPOLICYINFORMATION);
            this.ctrQuote.IMPENTITY.IMPJOBSITES.POLICY = "";

            //-SMB 1/15/2020
            //Need to remove additional coverages, but deleting existing GLPLIABILITY records (DWGP122)
            //is not working.
            
            // _.forEach(this.ctrQuote.GLPENTITY.GLPLIABILITIES, glpLiability => {
            //     if (glpLiability.COVERG != 'EPL')
            //         glpLiability.RECORDSTATE = 'D';
            // });

            //-SMB 1/15/2020
            //Instantiating a new instance of QUOTEPOLICYLIABLIMITS will reset the fields we need to reset
            //like the Additional Insureds count fields.
            //We still need to preserve these fields on QUOTEPOLICYLIABLIMITS that are used in the code below.
            //Rating would fail otherwise.

            let GALMT = this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.GALMT;
            let EOLMT = this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EOLMT;
            let MEDLMT = this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.MEDLMT;
            let FDLMT = this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.FDLMT;

            // let SHTPOL = this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.SHTPOL;
            // let HOMBLD = this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.HOMBLD;
            // let PAEXC = this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.PAEXC;
             let EOLMTFORMAT = this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EOLMTFORMAT;
            // let PAILMT = this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.PAILMT;
             let PAILMTFORMAT = this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.PAILMTFORMAT;
            // let PCOLMT = this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.PCOLMT;
             let PCOLMTFORMAT = this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.PCOLMTFORMAT;

            this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS = new QUOTEPOLICYLIABLIMITS(this.ctrQuote.QUOTEPOLICYINFORMATION);
            this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.setLiabilityLimits(GALMT, EOLMT, MEDLMT, FDLMT, EOLMTFORMAT, PAILMTFORMAT, PCOLMTFORMAT);
            
            // this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.SHTPOL = SHTPOL;
            // this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.HOMBLD = HOMBLD;

            // this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.PAEXC = PAEXC;
            // this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EOLMTFORMAT = EOLMTFORMAT;
            // this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.PAILMT = PAILMT;
            // this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.PAILMTFORMAT = PAILMTFORMAT;
            // this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.PCOLMT = PCOLMT;
            // this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.PCOLMTFORMAT = PCOLMTFORMAT; 

            
			this.ctrQuote.GLPENTITY.RemoveAdditionalCoverage("CEO");
			this.ctrQuote.GLPENTITY.RemoveAdditionalCoverage("CYB");
			this.ctrQuote.GLPENTITY.RemoveAdditionalCoverage("EPL");
            this.ctrQuote.GLPENTITY.RemoveAdditionalCoverage("EBL");
            this.ensureDefaultImpProducts(true);
            this.ensureDefaultImpJobsites();
			//this.migLiabilityResources.setCTRQuote(this.ctrQuote);			
			//this.EPILIMDropDown = this.migLiabilityResources.processEPILIM(this.contractorsDropDowns.EPILIM);
			//this.formGroup.reset();			

		    this.ctrQuote.GLPENTITY.CONSTPROJECTLIAB = [];

            this.getQuoteNow();
        });
    }
    
    beginQuoteChangeDetection() {
        this.ctrQuoteMemento = _.cloneDeep(this.ctrQuote);
        
        if (this.stepChangeSubscription != null)
        {
            this.stepChangeSubscription.unsubscribe();
        }

        this.stepChangeSubscription = this.migsystemservice.subscribeStepChanged().subscribe(() => {
            
            this.quoteChangesDetected();
            this.activeMenuItem = this.menuClass.stepActiveObject;
            if (this.activeMenuItem.name == "PremiumSummary")
            {
                if (this.ctrQuote.GLPENTITY.GLPLOCATIONS.some(s=>s.LOCNUM=="001" && s.TERR ==''))
                {
                    this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Contractors', detail: "In order to rate the quote, please enter a location address that results in a successful territory code lookup.", event: "start" });
                    this.menuClass.GotoMenuItem('locationId', '001');
                    setTimeout(() => {
                        this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Contractors', detail: "In order to rate the quote, please enter a location address that results in a successful territory code lookup.", event: "end" });
                    }, 3000);
                    return;
                }
                this.getQuoteNow();
            }

            if (this.menuClass.menuObjectIndex("Referrals") > this.menuClass.stepActive)
            {
                this.menuClass.menuObject("Referrals").navSkip = false;
            }
        });
    }

    quoteChangesDetected() {
       
        this.activeMenuItemIndex = this.menuClass.stepActive;
        let currentCTRQuote = new CTRQuote(this.ctrQuote);
        let mementoCTRQuote = new CTRQuote(this.ctrQuoteMemento);
        if (!(_.isEqual(currentCTRQuote, mementoCTRQuote)) && this.migRoles.editable)
        {            
            this.ctrQuote.UpdateQuoteStatus(this.menuClass, true);
            
            var differences = diff(mementoCTRQuote, currentCTRQuote);            
            // if (!(environment.production))
            //console.log(differences);
        }
    }

    updateQuoteStatus() {
        this.ctrQuote.UpdateQuoteStatus(this.menuClass, false);
        
        if (!(environment.production))
        {
            //console.log("WEBSTATUSCODE", this.ctrQuote.QUOTEPOLICYINFORMATION.WEBSTATUSCODE);
            //console.log("PREMIUM", this.ctrQuote.POLICYTRANS.APRP);
        }
    }

	ngOnInit(): void {
        if (environment.serverType == 'PROD')
        {
            this.showTestingControls = false;
        }
	}

    getQuoteNow(): void {
        let migLiabilityResources:MIGLiabilityResources = new MIGLiabilityResources();
        migLiabilityResources.setCTRQuote(this.ctrQuote);
        migLiabilityResources.ensureDefaultGlpLiabilityCoverage();
        this.ensureDefaultImpProducts(false);
        this.ensureDefaultImpJobsites();
    }

    ensureDefaultImpProducts(forceDefaults : boolean): void {
        //there need to be set before premium is called in order to save the DWIP120 correctly
        if(forceDefaults === false) {
            if (this.ctrQuote.IMPENTITY.IMPPRODUCTS.POLICY == this.ctrQuote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER){
               return;
            }
        }
        this.ctrQuote.IMPENTITY.IMPPRODUCTS = new IMPPRODUCTS(this.ctrQuote.QUOTEPOLICYINFORMATION);
		this.ctrQuote.IMPENTITY.IMPPRODUCTS.POLICY = this.ctrQuote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
		this.ctrQuote.IMPENTITY.IMPPRODUCTS.EFFDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
		this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRANS  = this.ctrQuote.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;
		this.ctrQuote.IMPENTITY.IMPPRODUCTS.RCDTYP = this.ctrQuote.QUOTEPOLICYINFORMATION.RECORDTYPE;
		this.ctrQuote.IMPENTITY.IMPPRODUCTS.EDSDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.RECORDSTATE = "U";
        
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRDED = this.contractorsDropDowns.defaultCTRDED;
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRCNS = this.contractorsDropDowns.defaultCTRCNS;
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.CTRUPL = this.contractorsDropDowns.defaultCTRUPL;
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.TCPOLL = this.contractorsDropDowns.defaultTCPOLL;
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.FUELAC = this.contractorsDropDowns.defaultFUELAC;
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.RNOOLL = this.contractorsDropDowns.defaultRNOOLL;
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.TRLCON = this.contractorsDropDowns.defaultTRLCON;
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.EQPRNT = this.contractorsDropDowns.defaultEQPRNT;
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.CEQVAL = "R";
        this.ctrQuote.IMPENTITY.IMPPRODUCTS.DOWHOL = 'N';
    }

    ensureDefaultImpJobsites(forceDefaults: boolean = false): void {

        if ((this.ctrQuote.IMPENTITY.IMPJOBSITES.POLICY == this.ctrQuote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER) && (!forceDefaults))
            return;
        
        this.ctrQuote.IMPENTITY.IMPJOBSITES = new IMPJOBSITES(this.ctrQuote.QUOTEPOLICYINFORMATION);
        this.ctrQuote.IMPENTITY.IMPJOBSITES.POLICY = this.ctrQuote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
        this.ctrQuote.IMPENTITY.IMPJOBSITES.EFFDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
        this.ctrQuote.IMPENTITY.IMPJOBSITES.TRANS = this.ctrQuote.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;
        this.ctrQuote.IMPENTITY.IMPJOBSITES.RCDTYP = this.ctrQuote.QUOTEPOLICYINFORMATION.RECORDTYPE;
        this.ctrQuote.IMPENTITY.IMPJOBSITES.EDSDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;
        this.ctrQuote.IMPENTITY.IMPJOBSITES.RECORDSTATE = "U";

        this.ctrQuote.IMPENTITY.IMPJOBSITES.CINJST = "ANY COVERED JOBSITE OF THE NAMED INSURED";
        this.ctrQuote.IMPENTITY.IMPJOBSITES.CINPRJ = "ANY COVERED INSTALLATION PROJECT OF THE NAMED INSURED";
        
        this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSLM = parseInt(this.contractorsDropDowns.defaultCINSLM);
        this.ctrQuote.IMPENTITY.IMPJOBSITES.CINLLM = parseInt(this.contractorsDropDowns.defaultCINLLM);
        this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTLM = parseInt(this.contractorsDropDowns.defaultCINTLM);
        this.ctrQuote.IMPENTITY.IMPJOBSITES.CINOLM = this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSLM + this.ctrQuote.IMPENTITY.IMPJOBSITES.CINLLM + this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTLM;
    }

    private handleUserRoleRestrictions(quote: IQuote): void{
        let roleSecurity = this.authService.isEditiable(quote);
        this.migRoles.editable = roleSecurity.editable;
        this.migRoles.roles = roleSecurity.roles;
        this.migRoles.ratingOverride = roleSecurity.ratingOverride;
        this.migRoles.transactionTypeOverride = roleSecurity.transactionTypeOverride;
        if (environment.serverType == 'PROD')
        {
            this.migsystemservice.notifyValidateForm(this.migRoles.editable);
        }
    }
    
    private showDiscretionaryWorksheetMenu(quote:CTRQuote) : void{
        /** COMMENTED OUT for testing */
        if(this.discClass.ShowDiscretioanryMenuItem(quote)){
            this.showDiscretionaryWorksheet = true;
           this.menuClass.ShowHideMenuItemAt(true,'DiscretionaryWorksheet');
        }
        else{
            this.menuClass.ShowHideMenuItemAt(false,'DiscretionaryWorksheet');
        }
    }

}
