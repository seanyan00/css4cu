/* ****************************************************************************************************
* PROGRAM DESCRIPTION  - Location Summary > Property Coverage
* AS400 LIBRARY        -
* TABLE/FILENAME       -
* DESCRIPTION          - Allows CRUD operations for property coverage for location summary
* DATE CREATED         - 1-5-2019
* AUTHOR               - Mario Giambanco
* Data Dictionary VER: - 214
* CODE GENERATION      -
* NOTES
*
* Mario Giambanco 1-5-2019
* rebuild according to data dictionary version 214
****************************************************************************************************/

import { Component, EventEmitter, Input, OnInit, Output, ViewEncapsulation, OnDestroy, ChangeDetectorRef} from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, UntypedFormControl, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { MIGValidatorPropertyCoverage } from './property-coverage.validators';
import { Functions } from '@helpers/functions';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { ContractorsTooltips } from '@helpers/tooltips';
import { debounceTime } from 'rxjs/operators'
import { MIGSystemService } from '@services/mig.service';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { Panel } from 'primeng/panel';
import { MenuClass } from '@root/system/menu/menu';
import { PropertyCoverageFieldRules } from './property-coverage.fieldrules';
import { InputMasksClass } from '@helpers/masks';
import { ConfirmationService } from 'primeng/api';
import { AppErrors } from '@root/shared_components/errors/app-errors';
import { ErrorService } from '@root/services/error.service';
import { PropertyCoverageBRValidation as PCBRValidation, PropertyCoverageBRValidation } from './property-coverage.business-rules';
import * as _ from 'lodash';

@Component({
	selector: 'mig-property-coverage',
	templateUrl: './property-coverage.component.html',
	styleUrls: ['property-coverage.component.css'],
	encapsulation: ViewEncapsulation.None,
	providers: [ConfirmationService]
})

export class MIGPropertyCoverage implements OnInit, OnDestroy {

    visBURGAL1: boolean = false;
    visBURGAL2: boolean = false;
    visBURGAL3: boolean = false;
    visFIRALM1: boolean = false;
    visFIRALM2: boolean = false;
    visScheduled: boolean = false;
    visSPRINK: boolean = false;
    visUnscheduled: boolean = false;
	visWINDEV: boolean = false;
	visFrame: boolean = false;
	visJointedMas: boolean = false; 
	visCombustible: boolean = false; 
	visMas: boolean = false; 
	visModFire: boolean = false; 
	visFire: boolean = false; 
	visErrors: boolean = false; 
	vis: boolean = false; 
	doneClicked: boolean = false;
	messages:any=[]; //array that holds all the toast messages 
	validateFormSubscription: Subscription;
	pcBRValidation: PCBRValidation
	// incoming reactive form group
	@Input() public PropertyCoverageFormGroup: UntypedFormGroup;
	// incoming data
	@Input() public loopId: number;
	@Input() PropertyCoverageData: any;
	@Input() ctrQuote: any;
	//@Input() ctrQuote: CTRQuote;
	// are we creating new or updating existing
	@Input() mode: string = "new";

	// passing in variables from mig-property-coverage
	@Input() toggleable: boolean = false;
	@Input() collapse: boolean;

	@Output() cancelPropertyCoverage = new EventEmitter<any>();
	@Output() donePropertyCoverage 	 = new EventEmitter<any>();
	@Output() deletePropertyCoverage = new EventEmitter<any>();

	// title for our panel
	@Input() title: string = "";
	@Input() state: string = "";

	@Input() fireDistrictsArray: any[];
	@Input() territoryArray: any[];
	@Input() classesAandB: string;

	errors: AppErrors[] = [];
	//errors: any;
	// our formbuilder stub
	formBuilder: UntypedFormBuilder;
	// validation
	migPropertyCoverageValidator: MIGValidatorPropertyCoverage;

	// so we can unsubscribe from our FormGroup
	FormGroupSubscription: Subscription;
	//checkboxCCPALLSubscription: Subscription;
	//BLDTP1Subscription: Subscription;
	BPPLM1Subcription: Subscription;
	//BLDLM1Subcription: Subscription;
	checkboxPSLISubcription: Subscription;
	checkboxBLDTP1Subscription: Subscription;
	checkboxUTLSVCSubscription: Subscription;

	errorHandler: any[] = [];
	hasError: boolean = false;
	filteredOptionsAny: any;

	// remove once we get JSON values from WINS
	formChanged: boolean = false;
	 
	updateRecordState: Subscription;
	pcBusinessRules: PropertyCoverageBRValidation;
	causeOfLoss:string = 'Special';
	fieldRules: PropertyCoverageFieldRules;
	locationId:string;
	buildingId:string; 
	validateForm: boolean;

	hasSplitProtectionClass: boolean = false;
	splitProtectionClass: string;
	canChangeFeetAndMiles: boolean;
	selectedTAXTWN: string;

	constructor(
		public func: Functions,
		public contractorsDropDowns: ContractorsDropDowns,
		public contractorsTooltips: ContractorsTooltips,
		public migsystemservice: MIGSystemService,
		public migRoles: MIGSecurityRoles,
		public menuClass: MenuClass,
        private cd: ChangeDetectorRef,
		public masks: InputMasksClass,
		public confirmationService: ConfirmationService,
		public errorService: ErrorService
	) {

		this.migPropertyCoverageValidator = new MIGValidatorPropertyCoverage();
		
		this.migsystemservice.subscribeLessorsRiskAdd().subscribe(type => {
			if(type=='add'){
				this.BLDCLS.setValue(true);
				this.BLDCLS5.setValue(true);
				let office = this.PropertyCoverageData.BLDCLSLIST.find((x:string)=>x == 'OFFICE');
				if(office == 'undefined' || office == '' || office == null ){
					this.PropertyCoverageData.BLDCLSLIST.push('OFFICE');
				}
			}
			else{
				this.BLDCLS5.setValue(false);
			}
        });
        this.migsystemservice.subscribeXClicked().subscribe(() => {
            this.doneClicked = false;
		});


	}


	get BLDNUM() { return this.PropertyCoverageFormGroup.get('BLDNUM'); }
	get LOCNUM() { return this.PropertyCoverageFormGroup.get('LOCNUM'); }

	// Territory
	get TERR() { return this.PropertyCoverageFormGroup.get('TERR'); }

	// County Name
	get CONTY() { return this.PropertyCoverageFormGroup.get('CONTY'); }
	get TAXCTY() { return this.PropertyCoverageFormGroup.get('TAXCTY'); }

	// Protection Class
	get PRTCLS() { return this.PropertyCoverageFormGroup.get('PRTCLS'); }

	// Fire District Name
	get RATCTY() { return this.PropertyCoverageFormGroup.get('RATCTY'); }

	// Feet from Hydrant
	get FTHYDT() { return this.PropertyCoverageFormGroup.get('FTHYDT'); }

	// Miles from Fire Department
	get FDMILE() { return this.PropertyCoverageFormGroup.get('FDMILE'); }

	// Fire Protection Safeguards
	//get FIRALMLIST() { return this.PropertyCoverageFormGroup.get('FIRALMLIST'); }
	get FIRALM1() { return this.PropertyCoverageFormGroup.get('FIRALM1'); }
	get FIRALM2() { return this.PropertyCoverageFormGroup.get('FIRALM2'); }
	get SPRINK() { return this.PropertyCoverageFormGroup.get('SPRINK'); }
	get FIRALM() { return this.PropertyCoverageFormGroup.get('FIRALM'); }
	// Burglary and Robbery Protective Safeguards
	//get BURGALLIST() { return this.PropertyCoverageFormGroup.get('BURGALLIST'); }

	get BURGAL1() { return this.PropertyCoverageFormGroup.get('BURGAL1'); }
	get BURGAL2() { return this.PropertyCoverageFormGroup.get('BURGAL2'); }
	get BURGAL3() { return this.PropertyCoverageFormGroup.get('BURGAL3'); }
	get BURGAL() { return this.PropertyCoverageFormGroup.get('BURGAL'); }
	// Building Occupancy Class
	get BLDCLS() { return this.PropertyCoverageFormGroup.get('BLDCLS'); }
	get BLDCLS2() { return this.PropertyCoverageFormGroup.get('BLDCLS2'); }
	get BLDCLS3() { return this.PropertyCoverageFormGroup.get('BLDCLS3'); }
	get BLDCLS4() { return this.PropertyCoverageFormGroup.get('BLDCLS4'); }
	get BLDCLS5() { return this.PropertyCoverageFormGroup.get('BLDCLS5'); }
	get BLDCLS6() { return this.PropertyCoverageFormGroup.get('BLDCLS6'); }

	get BLDCLSLIST() { return this.PropertyCoverageFormGroup.get('BLDCLSLIST'); }

	// added 1-5-2019 MG
	// Single Occupancy
	get SNGOFG() { return this.PropertyCoverageFormGroup.get('SNGOFG'); }

	// Property Deductible
	//get BLDDED() { return this.PropertyCoverageFormGroup.get('BLDDED'); }
	get BLDGDD() { return this.PropertyCoverageFormGroup.get('BLDGDD'); }

	//Windstorm Or Hair Deduction
	get WNDDCT() { return this.PropertyCoverageFormGroup.get('WNDDCT'); }

	// Miles to Shore
	get MLSHOR() { return this.PropertyCoverageFormGroup.get('MLSHOR'); }

	// Feet to shore
	get FTSHOR() { return this.PropertyCoverageFormGroup.get('FTSHOR'); }

	// Construction Type
	get CONSYM() { return this.PropertyCoverageFormGroup.get('CONSYM'); }

	// Construction Year
	get CONYR() { return this.PropertyCoverageFormGroup.get('CONYR'); }

	// REMOVED TASK 1435
	// CP 1219: Building Owner
	//get checkboxBOCNT() { return this.PropertyCoverageFormGroup.get('checkboxBOCNT'); }
	//get BOCNT() { return this.PropertyCoverageFormGroup.get('BOCNT'); }
	// get checkboxCCPALL() { return this.PropertyCoverageFormGroup.get('checkboxCCPALL'); }
	// get CCPALL() { return this.PropertyCoverageFormGroup.get('CCPALL'); }
	

	// Building Limit
	get BLDLM1() { return this.PropertyCoverageFormGroup.get('BLDLM1'); }
	// BLDTP1 = B if BLDLM1 has value
	get BLDTP1() { return this.PropertyCoverageFormGroup.get('BLDTP1'); }

	// Building Valuation
	get BLDVAL() { return this.PropertyCoverageFormGroup.get('BLDVAL'); }

	// Coinsurance %
	//get BLDCIN() { return this.PropertyCoverageFormGroup.get('BLDCIN'); }
	get BLDCN1() { return this.PropertyCoverageFormGroup.get('BLDCN1'); }

	// Cause of Loss
	get BLDCOL() { return this.PropertyCoverageFormGroup.get('BLDCOL'); }

	// Windstorm Protective Devices
	get WINDEV() { return this.PropertyCoverageFormGroup.get('WINDEV'); }

	// BUILDING PERSONAL PROPERTY COVERAGE

	// Business Personal Property Limit
	get BPPLM1() { return this.PropertyCoverageFormGroup.get('BPPLM1'); }

	// Theft Exclusion
	//get BPPTFE() { return this.PropertyCoverageFormGroup.get('BPPTFE'); }

	// Valuation
	get BPPVN1() { return this.PropertyCoverageFormGroup.get('BPPVN1'); }

	// Coinsurance %
	get BPPCN1() { return this.PropertyCoverageFormGroup.get('BPPCN1'); }

	// Cause of Loss
	get BPPCOL() { return this.PropertyCoverageFormGroup.get('BPPCOL'); }

	// Peak Season Limit of Insurance CHECKBOX
	get checkboxPSLI() { return this.PropertyCoverageFormGroup.get('checkboxPSLI'); }

	//ADDED Block 1-5-2019 MG - Peak Season Limit of Insurance CHECKBOX
	// Row 1
	// Period from
	get BPPDF1() { return this.PropertyCoverageFormGroup.get('BPPDF1'); }

	// Period to
	get BPPDT1() { return this.PropertyCoverageFormGroup.get('BPPDT1'); }	

	// Additional Limit of Insurance
	get BPPSL1() { return this.PropertyCoverageFormGroup.get('BPPSL1'); }

	// Row 2
	// Period from
	get BPPDF2() { return this.PropertyCoverageFormGroup.get('BPPDF2'); }

	// Period to
	get BPPDT2() { return this.PropertyCoverageFormGroup.get('BPPDT2'); }

	// Covered Property
	get P1230CVPP() { return this.PropertyCoverageFormGroup.get('P1230CVPP'); }

	// Covered Property
	get P1230CV1P() { return this.PropertyCoverageFormGroup.get('P1230CV1P'); }

	// Additional Limit of Insurance
	get BPPSL2() { return this.PropertyCoverageFormGroup.get('BPPSL2'); }
	// end add block

	// Building Property Tenants Policy
	get BLDTP2() { return this.PropertyCoverageFormGroup.get('BLDTP2'); }
	// checkbox for Building Property Tenants Policy
	get checkboxBLDTP1() { return this.PropertyCoverageFormGroup.get('checkboxBLDTP1'); }
	get dropdownBLDTP1() { return this.PropertyCoverageFormGroup.get('dropdownBLDTP1'); }

	// Limit of Insurance on Building Glass
	get tmpBLDLM1() { return this.PropertyCoverageFormGroup.get('tmpBLDLM1'); }

	// Limit of Insurance on Building Property Other than Glass
	get BLDLM2() { return this.PropertyCoverageFormGroup.get('BLDLM2'); }

	// Utility Services - Time Element
	get checkboxUTLSVC() { return this.PropertyCoverageFormGroup.get('checkboxUTLSVC'); }
	get UTLSVC() { return this.PropertyCoverageFormGroup.get('UTLSVC'); }

	ngOnInit() {
		// we only want to stop navigation if it's a new building
		// otherwise, we're editing a building and that is a live update right to the object graph	
        // but if they dirty the form need to reset to true for 'next button'
        
		if (this.mode == "new") {
			this.menuClass.stopNavigation = true;
		}

		this.validateFormSubscription = this.migsystemservice.subscribeValidateForm().subscribe((validate) => {
			this.validateForm = validate;
		})

		//need to have this befiore BuildForm()
		this.locationId = this.PropertyCoverageData.LOCNUM;
		this.buildingId = this.PropertyCoverageData.BLDNUM;
		this.PropertyCoverageData.PRMSTE = this.state;
		//add in the validators once the ctrQuote has populated
		this.pcBRValidation = new PCBRValidation(this.func);
		this.BuildForm();

		// ** REMOVED ** //
		//check to see if Building Property TEnants should be selected
		//this.checkboxBLDTP1.setValue(this.isBuildingPropTenantSelected());

		this.fieldRules = new PropertyCoverageFieldRules;
		this.fieldRules.ApplyValidation(this);

		
		this.UpdateQuote();
	}
	isBuildingPropTenantSelected(): Boolean {
		if(this.PropertyCoverageData.BLDTP1 !== '' && this.PropertyCoverageData.BLDTP2 !== '') return true;
		return false;
	}
	ngOnDestroy() {		
		this.FormGroupSubscription.unsubscribe();
		this.checkboxPSLISubcription.unsubscribe();
		this.BPPLM1Subcription.unsubscribe();
        
        if (this.checkboxBLDTP1Subscription)
            this.checkboxBLDTP1Subscription.unsubscribe();
		
        if (this.checkboxUTLSVCSubscription)
            this.checkboxUTLSVCSubscription.unsubscribe();

		this.migsystemservice.notifyToastMessagesCleared();
        
        if (this.validateFormSubscription)
            this.validateFormSubscription.unsubscribe();
        
        if (this.updateRecordState)
            this.updateRecordState.unsubscribe();
		
	}

	resetPanel(){
		this.visBURGAL1 = false;
		this.visBURGAL2 = false;
		this.visBURGAL3 = false;
		this.visFIRALM1 = false;
		this.visFIRALM2 = false;
		this.visScheduled = false;
		this.visSPRINK = false;
		this.visUnscheduled = false;
		this.visWINDEV = false;
		this.visFrame = false;
		this.visJointedMas = false;
		this.visCombustible = false;
		this.visMas = false;
		this.visModFire = false;
		this.visFire = false;
		this.vis = false;
	}

	editProperty(panel: Panel) {
        this.ngOnDestroy();
        this.ngOnInit();
        panel.collapsed = false;
	}

	afterToggle(panel: Panel) {
        if (!(panel.collapsed))
        {
            document.getElementById('propCovScroll').scrollIntoView({behavior: 'smooth', block: 'start'});
        }
	}

	//BLDLM1 change event;using a new subsicrbe gives a Max stack error;
	//circular dependency becasue of checkboxBLDTP1
	onBLDLM1Change(data){
		if (this.func.justNumbers(data) > 0) {				
			//tenants policy
			this.checkboxBLDTP1.disable();
		} else {
			//tenants policy
			this.checkboxBLDTP1.enable();
			this.checkboxBLDTP1.setValue(false);
		}
	}

	//BLDTP1 change event;using a subscribe gives a Max stack error;
	//circular dependency becasue of BLDLM1
	cbBLDTP1Change(event){
		if (event.checked) {
			 this.BLDLM1.disable();
			 this.dropdownBLDTP1.enable();
			 this.tmpBLDLM1.setValue('');
		}
		else{
			this.BLDLM1.enable();
			this.dropdownBLDTP1.setValue("");
			this.tmpBLDLM1.setValue('');
			//this.BLDLM1.setValue('');
			//this.BLDLM2.setValue('');
			
		}
	}
	
	/* setting BLDCLSLIST events */
	SetBLDCLSOffice(event){
		if (event.checked) {
			this.PropertyCoverageData.BLDCLSLIST.push('OFFICE');
		}
		else{
			let index = this.PropertyCoverageData.BLDCLSLIST.findIndex((d:string) => d === 'OFFICE'); //find index in your array
			this.PropertyCoverageData.BLDCLSLIST.splice(index, 1);//remove element from array
			//this.ctrQuote.CFPENTITY.CFPLOCATIONS[this.loopId].BLDCLSLIST.pop(d=>d === 'Office');
		}
	}

	SetBLDCLSShop(event){
		if (event.checked) {
			this.PropertyCoverageData.BLDCLSLIST.push('SHOP');
		}
		else{
			let index = this.PropertyCoverageData.BLDCLSLIST.findIndex((d:string) => d === 'SHOP'); //find index in your array
			this.PropertyCoverageData.BLDCLSLIST.splice(index, 1);//remove element from array
			//this.ctrQuote.CFPENTITY.CFPLOCATIONS[this.loopId].BLDCLSLIST.pop('Shop');
		}
	}

	SetBLDCLSRetail(event){
		if (event.checked) {
			this.PropertyCoverageData.BLDCLSLIST.push('RETAIL');
		}
		else{
			let index = this.PropertyCoverageData.BLDCLSLIST.findIndex((d:string) => d === 'RETAIL'); //find index in your array
			this.PropertyCoverageData.BLDCLSLIST.splice(index, 1);//remove element from array
			//this.ctrQuote.CFPENTITY.CFPLOCATIONS[this.loopId].BLDCLSLIST.pop('Retail');
		}
	}

	SetBLDCLSStorage(event){
		if (event.checked) {
			this.PropertyCoverageData.BLDCLSLIST.push('STORAGE');
		}
		else{
			let index = this.PropertyCoverageData.BLDCLSLIST.findIndex((d:string) => d === 'STORAGE'); //find index in your array
			this.PropertyCoverageData.BLDCLSLIST.splice(index, 1);//remove element from array
			//this.ctrQuote.CFPENTITY.CFPLOCATIONS[this.loopId].BLDCLSLIST.pop('Storage');
		}
	}
	
	SetBLDCLSLessorRisk(event){		
		if (event.checked) {
			this.BLDCLS.setValue(true);
			//this.BLDCLS.disable();
			this.BLDCLS6.setValue(false);
			
			//
			let office = this.PropertyCoverageData.BLDCLSLIST.find((x:string)=>x == 'OFFICE');
			if(office == 'undefined' || office == '' || office == null ){
				this.PropertyCoverageData.BLDCLSLIST.push('OFFICE');
			}

			//
			this.ctrQuote.GLPENTITY.GLPLOCATIONS.find((x:any) => x.LOCNUM == this.locationId).ANARLS = 'Y'
			
			//check for class 061217 in DWGP135;if not there will need to be added based on this event
			let glclass = this.ctrQuote.GLPENTITY.GLCLASSLIST.find((x:any)=>x.CLASX == '061217' && x.LOCNUM == this.locationId);
			if(glclass == 'undefined' || glclass == '' || glclass == null){
				//No 061217 was found
				//ADD the 061217 class here, hard coded so we dont have to go back to DB for info
				let _glclass = {
					TRANS:  this.ctrQuote.POLICYTRANS.TRANS,
					POLICY: this.ctrQuote.POLICYTRANS.POLICY,
					EFFDTE: this.ctrQuote.POLICYTRANS.EFFDTE,
					EDSDTE: this.ctrQuote.POLICYTRANS.EDSDTE,
					RCDTYP: this.ctrQuote.QUOTEPOLICYINFORMATION.RECORDTYPE,
					EDSNO: 0,
					COVERG: "CGL",
					PRMSTE: this.ctrQuote.GLPENTITY.GLPLOCATIONS.find((x:any) => x.LOCNUM == this.locationId).ADDRESS.STATE,
					LOCNUM: this.locationId,
					BLDNUM: this.buildingId,
					CLASX: '061217',
					SEQNO: "",
					EXPOSE: '0',
					IFANY:  '',
					CLSDSC: "BUILDING OR PREMISES - BANK OR OFFICE - MERCANTILE OR MANUFACTURING (LESSOR'S RISK ONLY) - OTHER THAN NOT FOR PROFIT",
					EXPDSC: 'AREA',
					PRMDSC: 'AREA',
					PRDINC: 'Y',
					SICCDE: '6029',
					ELIGIBILTY: '',
					PKGMOD:'CO',
					RECORDSTATE: 'U'
				}
				this.ctrQuote.GLPENTITY.GLCLASSLIST.push(_glclass);
			} else 
			{
				//061217 was found
				//check if its already been deleted
				let duplicate = this.ctrQuote.GLPENTITY.GLCLASSLIST.find((x:any) => x.CLASX === glclass.CLASX && x.LOCNUM === this.locationId && x.RECORDSTATE =='D');
				if(duplicate){ duplicate.RECORDSTATE ='U'; }	
			}
		}
		else{
			//this.BLDCLS.enable();
			//this.ctrQuote.GLPENTITY.GLCLASSLIST.pop('061217');
			this.ctrQuote.GLPENTITY.GLCLASSLIST.find((x:any)=>x.LOCNUM == this.locationId && x.CLASX == '061217').RECORDSTATE ='D';
			this.ctrQuote.GLPENTITY.GLPLOCATIONS.find((x:any) => x.LOCNUM == this.locationId).ANARLS = 'N'
		}
	}

	SetBLDCLSLessorRiskOther(event, panel){
        
		if(event) {
			this.BLDCLS5.setValue(false);
			this.confirmationService.confirm({
				message: 'Thank you for your interest in Merchants.  Unfortunately, this risk does not meet our underwriting guidelines:  A Lessors Risk exposure other than Office exists. Do you wish to continue with this quote?',
				header: 'Stop Quote',
				icon: 'pi pi-exclamation-triangle',
				accept: () => {
					this.BLDCLS6.setValue(false);
				},
				reject: () => {
					if (this.mode == "new") {
						this.BLDCLS6.setValue(false);
						this.ctrQuote.CFPENTITY.CFPLOCATIONS.pop(this.loopId);
						//then redirect to account management
						this.migsystemservice.notifyUpdateRecordState();
						this.migsystemservice.notifySaveQuote(true);
					} else {
						//else just redirect to account management
						this.migsystemservice.notifyUpdateRecordState();
						this.migsystemservice.notifySaveQuote(true);		
					}
				}
			});
		}
	}
	/* END setting BLDCLSLIST events */
	

	//Change to subscription??
	//DONE BUTTON CLICK
	checkForErrors(panel: Panel){
		// method is called when the user clicks "done" (the method should switch names with btnDone later)
		this.errors = [];
		if(!this.validateForm) {
			this.processChanges(panel); 
			return; 
		}

        this.errors = this.menuClass.CalculateErrorsFormGroup(this.PropertyCoverageFormGroup, true);
        
		if(this.errors.length != 0){ //if there are errors, go into btnDone method to push the error messages into the array
			this.migsystemservice.notifyDoneClicked(this.errors);
		}
		else{
		//if there are no errors and the user clicks done, we need to collapse the panel 
			this.processChanges(panel);
		}
	
	}

	processChanges(panel: Panel) {
        panel.collapsed = true;
        this.migsystemservice.notifyToastMessagesCleared();
		this.menuClass.stopNavigation = false;
		this.menuClass.isQuoteDirty = true;
		//when adding a new location the obj graph is filled from the location.component
		//so it is already in the obj graph. so when adding new; recordstate is set to 'D' until they click done.
		//protecting when hitting 'next' on footer instead of done.
		if (this.mode == 'new')
        {
			this.PropertyCoverageData.RECORDSTATE ='N';
		}
		this.donePropertyCoverage.emit(this.PropertyCoverageData);
	}

	btnDelete(panel: Panel) {
        if (this.mode == 'new')
        {
            this.cancelPropertyCoverage.emit();
            return;
        }
        this.deletePropertyCoverage.emit({bldNum: this.PropertyCoverageData.BLDNUM, locNum: this.PropertyCoverageData.LOCNUM});
	}

	BuildForm() {

		this.formBuilder = new UntypedFormBuilder();
		this.PropertyCoverageFormGroup = this.formBuilder.group({});


		let PropCov = this.PropertyCoverageData;
		this.PropertyCoverageFormGroup.addControl('BLDNUM', new UntypedFormControl(PropCov.BLDNUM));
		this.PropertyCoverageFormGroup.addControl('LOCNUM', new UntypedFormControl(PropCov.LOCNUM));

		/*************************************************************                        
		 *
		 * Location Information
		 *
		 * **********************************************************/

		this.PropertyCoverageFormGroup.addControl('checkboxBLDTP1', new UntypedFormControl(""));

		this.PropertyCoverageFormGroup.addControl('dropdownBLDTP1', new UntypedFormControl(PropCov.BLDTP1 == 'G' ? "SCHEDULED" : PropCov.BLDTP1 == 'T' ? "UNSCHEDULED" : ""));

		
		/* Utility Services - Time Element */
		//this.PropertyCoverageFormGroup.addControl('checkboxUTLSVC', new FormControl({ value: false }));
		this.PropertyCoverageFormGroup.addControl('checkboxUTLSVC', new UntypedFormControl());

		/* Territory */
		this.PropertyCoverageFormGroup.addControl('TERR', new UntypedFormControl(PropCov.TERR ? PropCov.TERR : ""));
        if (this.territoryArray.length)
        {
            this.TERR.setValidators(this.pcBRValidation.ValidateRequired("TERR", "Territory Code"));
            this.PropertyCoverageFormGroup.updateValueAndValidity();
        }
		/* County Name */
		this.PropertyCoverageFormGroup.addControl('CONTY', new UntypedFormControl(PropCov.CONTY ? PropCov.CONTY : ""));
		this.PropertyCoverageFormGroup.addControl('TAXCTY', new UntypedFormControl(PropCov.TAXCTY ? PropCov.TAXCTY : ""));

		this.processTerritoryInfoForBuilding()

		this.selectFireDistrict();

        if (this.fireDistrictsArray.length > 1)
        {
            this.TAXCTY.setValidators(this.pcBRValidation.ValidateRequired("TAXCTY", "Fire District Name"));
            this.PropertyCoverageFormGroup.updateValueAndValidity();
        }

        /* Feet from hydrant */
		// If protection class is split, they need to choose this
		this.PropertyCoverageFormGroup.addControl('FTHYDT', new UntypedFormControl(PropCov.FTHYDT ? PropCov.FTHYDT : ""));

		/* Miles from fire department */
		// If protection class is split, they need to choose this
		this.PropertyCoverageFormGroup.addControl('FDMILE', new UntypedFormControl(PropCov.FDMILE ? PropCov.FDMILE : ""));
        
        this.CheckFireDistrictAndHydrantDistanceValidation();
		
		/* Fire Protective Safeguards */
		this.PropertyCoverageFormGroup.addControl('FIRALM1', new UntypedFormControl(PropCov.FIRALM1 =='P2' ? true :  false));
		this.PropertyCoverageFormGroup.addControl('FIRALM2', new UntypedFormControl(PropCov.FIRALM2 =='P3' || (PropCov.FIRALM1 =='P3' && PropCov.FIRALM2.trim() =='') ? true :  false));
		this.PropertyCoverageFormGroup.addControl('SPRINK', new UntypedFormControl(PropCov.SPRINK == 'Y' ? true :  false));
		this.PropertyCoverageFormGroup.addControl('FIRALM', new UntypedFormControl());
		//this.PropertyCoverageFormGroup.addControl('FIRALMLIST', new FormControl(PropCov.FIRALMLIST ? PropCov.FIRALMLIST : ""));

		/* Burglary and Robbery Protective Safeguards */
		this.PropertyCoverageFormGroup.addControl('BURGAL1', new UntypedFormControl(PropCov.BURGAL1 == 'B1' ? true : false));
		this.PropertyCoverageFormGroup.addControl('BURGAL2', new UntypedFormControl(PropCov.BURGAL2 == 'B2' ? true : false));
		this.PropertyCoverageFormGroup.addControl('BURGAL3', new UntypedFormControl(PropCov.BURGAL3 == 'B3' ? true : false));
		this.PropertyCoverageFormGroup.addControl('BURGAL', new UntypedFormControl());
		
		/* Building Occupancy class */
		this.PropertyCoverageFormGroup.addControl('BLDCLS', new UntypedFormControl(PropCov.BLDCLSLIST.find((x:string)=>x =='OFFICE')  ? true : false));
		this.PropertyCoverageFormGroup.addControl('BLDCLS2', new UntypedFormControl(PropCov.BLDCLSLIST.find((x:string)=>x == 'SHOP') ? true : false));
		this.PropertyCoverageFormGroup.addControl('BLDCLS3', new UntypedFormControl(PropCov.BLDCLSLIST.find((x:string)=>x == 'RETAIL') ? true : false));
		this.PropertyCoverageFormGroup.addControl('BLDCLS4', new UntypedFormControl(PropCov.BLDCLSLIST.find((x:string)=>x == 'STORAGE') ? true : false));		

		//Lessors Risk - Office Only should be able to select this on any building 
		this.PropertyCoverageFormGroup.addControl('BLDCLS5', new UntypedFormControl(this.ctrQuote.GLPENTITY.GLPLOCATIONS.find((x:any) => x.LOCNUM == this.locationId).ANARLS == 'Y' ? true : false));			
		if (this.PropertyCoverageFormGroup.get('BLDCLS5').value ) {
			this.PropertyCoverageFormGroup.get('BLDCLS').setValue(true);
			let office = this.PropertyCoverageData.BLDCLSLIST.find((x:string)=>x == 'OFFICE');
				if(office == 'undefined' || office == '' || office == null ){
					this.PropertyCoverageData.BLDCLSLIST.push('OFFICE');
				}
		}

		//
		this.PropertyCoverageFormGroup.addControl('BLDCLS6', new UntypedFormControl(''));
		this.PropertyCoverageFormGroup.addControl('BLDCLSLIST', new UntypedFormControl(PropCov.BLDCLSLIST ? PropCov.BLDCLSLIST : "", 
		this.pcBRValidation.BuildingOccupancyClass(this.PropertyCoverageData)));
		
		// updated 20190807 BDK
		/* Other Occupancies */
		this.PropertyCoverageFormGroup.addControl('SNGOFG', new UntypedFormControl(PropCov.SNGOFG ? PropCov.SNGOFG : '', this.pcBRValidation.ValidateRequired('SNGOFG', 'Other Occupancies')));
		

		/* Property Deductible */
		// let BLDDEDTotalLimit = this.processBLDDED(PropCov.BLDDED);
		//this.PropertyCoverageFormGroup.addControl('BLDDED', new FormControl(PropCov.BLDDED ? PropCov.BLDDED : this.contractorsDropDowns.defaultBLDDED));
		this.PropertyCoverageFormGroup.addControl('BLDGDD', new UntypedFormControl(PropCov.BLDGDD ? PropCov.BLDGDD : this.contractorsDropDowns.defaultBLDGDD,
			[this.pcBRValidation.LocationInfoPropDedeductible(this.PropertyCoverageData), 
			this.pcBRValidation.ValidateRequired('BLDGDD', 'Property Deductible')]));

		/* Windstorm or Hail Deductible */
		this.PropertyCoverageFormGroup.addControl('WNDDCT', new UntypedFormControl(PropCov.WNDDCT ? PropCov.WNDDCT : "0"));

		/* Miles to shore */
		// rule in HTML
		this.PropertyCoverageFormGroup.addControl('MLSHOR', new UntypedFormControl(PropCov.MLSHOR));

		/* Feet to shore */
		// rule in HTML
		this.PropertyCoverageFormGroup.addControl('FTSHOR', new UntypedFormControl(PropCov.FTSHOR));

		/* Construction Type*/
		this.PropertyCoverageFormGroup.addControl('CONSYM', new UntypedFormControl(PropCov.CONSYM ? PropCov.CONSYM : "",
			this.pcBRValidation.ValidateRequired("CONSYM","Construction Type")));

		
		/* Year Built */
		this.PropertyCoverageFormGroup.addControl('CONYR', new UntypedFormControl(PropCov.CONYR ? PropCov.CONYR : "", 
			this.pcBRValidation.ValidateRequired("CONYR", "Year Built", true)));

		
		/*CP 1219: Building Owner */
		// TODO: Add rule once field added to Class
		// this.PropertyCoverageFormGroup.addControl('checkboxBOCNT', new FormControl(this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.BOCNT ? true : false));
		// this.PropertyCoverageFormGroup.addControl('BOCNT', new FormControl(this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.BOCNT ? this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.BOCNT : '',
		
		//REMOVED TASK 1435
		/*CP 1219: Building Owner */
		//** WE USE CPPALL PER KEVIN TO ASSOCIATE BOCNT IN DWGP120 TO A LOCNUM/BLDNUM */
		// this.PropertyCoverageFormGroup.addControl('checkboxCCPALL', new FormControl(this.ctrQuote.CFPENTITY.CFPLOCATIONS[this.loopId].CCPALL ? true : false));
		// this.PropertyCoverageFormGroup.addControl('CCPALL', new FormControl(this.ctrQuote.CFPENTITY.CFPLOCATIONS[this.loopId].CCPALL ? 
		// 	this.ctrQuote.CFPENTITY.CFPLOCATIONS[this.loopId].CCPALL : ''));
			//,this.migPropertyCoverageValidator.ValidateMinValue('1', 1, 'CCPALL', 'Number of Additional Insureds')));


		/* Building Limit */
		this.PropertyCoverageFormGroup.addControl('BLDLM1', new UntypedFormControl(PropCov.BLDLM1 ? PropCov.BLDLM1 : '',
			[this.pcBRValidation.BuildingLimitOrBPPLimit(this.PropertyCoverageData),
			this.pcBRValidation.BuildingLimitMin(this.PropertyCoverageData)
			])
		);

		/* Owner Occupancy */
		// REMOVED 1-5-2019 MG
		// this.PropertyCoverageFormGroup.addControl('OCCPCY', new FormControl(PropCov.OCCPCY ? PropCov.OCCPCY : "", (this.BLDLM1.value ? this.migPropertyCoverageValidator.ValidateRequired("Owner Occupancy") : Validators.nullValidator)));

		/* Building Valuation */
		this.PropertyCoverageFormGroup.addControl('BLDVAL', new UntypedFormControl(PropCov.BLDVAL ? PropCov.BLDVAL : 'R'));

		/* Building Coinsurance % */
		//this.PropertyCoverageFormGroup.addControl('BLDCIN', new FormControl(PropCov.BLDCIN ? PropCov.BLDCIN : '80'));
		this.PropertyCoverageFormGroup.addControl('BLDCN1', new UntypedFormControl(PropCov.BLDCN1 ? PropCov.BLDCN1 : '80'));

		/* Cause of Loss */
		this.PropertyCoverageFormGroup.addControl('BLDCOL', new UntypedFormControl({ value: PropCov.BLDCOL ? PropCov.BLDCOL : "Special", disabled: true }));

		/* Windstorm Protective Device */
        // Rule in HTML
        var windevRadioValue;
        windevRadioValue = false;
        if (PropCov.WINDEV == 'Y')
            windevRadioValue = true;
        
        if (PropCov.WINDEV == 'N')
            windevRadioValue = 'N';

		this.PropertyCoverageFormGroup.addControl('WINDEV', new UntypedFormControl(windevRadioValue, 
			this.pcBRValidation.WindStormProtectiveDevices(this.PropertyCoverageData)));

		/*************************************************************
		 *
		 * Business Personal Property Coverage
		 *
		 * **********************************************************/
		/* Business Personal Property Limit */
		this.PropertyCoverageFormGroup.addControl('BPPLM1', new UntypedFormControl(PropCov.BPPLM1 ? PropCov.BPPLM1 : '', 
			this.pcBRValidation.BPPLimitRange(this.PropertyCoverageData)));

		/* Theft Exclusion */
		//this.PropertyCoverageFormGroup.addControl('BPPTFE', new FormControl({ value: PropCov.BPPTFE == 'Y' ? true : false, disabled: (this.BPPLM1.value == "0") }));

		/* BPP Valuation */
		this.PropertyCoverageFormGroup.addControl('BPPVN1', new UntypedFormControl(PropCov.BPPVN1 ? PropCov.BPPVN1 : this.contractorsDropDowns.defaultBPPVN1, 
			(this.BPPLM1.value ? this.pcBRValidation.ValidateRequired("BPPVN1", "Valuation") : Validators.nullValidator)));

		/* BPP Coinsurance % */
		this.PropertyCoverageFormGroup.addControl('BPPCN1', new UntypedFormControl(PropCov.BPPCN1 ? PropCov.BPPCN1 : this.contractorsDropDowns.defaultBPPCN1, 
			(this.BPPLM1.value ? this.pcBRValidation.ValidateRequired("BPPCN1", "Coinsurance %") : Validators.nullValidator)));

		/* Cause of Loss*/
		this.PropertyCoverageFormGroup.addControl('BPPCOL', new UntypedFormControl({ value: "Special", disabled: true }));

		/* Peak Season Limit of Insurance */
		this.PropertyCoverageFormGroup.addControl('checkboxPSLI', new UntypedFormControl({ value: false }));

		//ADDED Block 1-5-2019 MG
		/* Peak Season Limit of Insurance > Row 1 > Period From */
		//this.PropertyCoverageFormGroup.addControl('BPPDF1', new FormControl(this.func.DTEWinsToPrimeNG(PropCov.BPPDF1)));
		//this.func.DTEWinsToPrimeNG(PropCov.BPPDF1) : 0,
		this.PropertyCoverageFormGroup.addControl('BPPDF1', new UntypedFormControl(PropCov.BPPDF1? this.func.DTEWinsToPrimeNG(PropCov.BPPDF1) : 0));

		/* Peak Season Limit of Insurance > Row 1 > Period To */
		//this.PropertyCoverageFormGroup.addControl('BPPDT1', new FormControl(this.func.DTEWinsToPrimeNG(PropCov.BPPDT1)));
		this.PropertyCoverageFormGroup.addControl('BPPDT1', new UntypedFormControl(PropCov.BPPDT1 ? this.func.DTEWinsToPrimeNG(PropCov.BPPDT1) : 0));

		/* Peak Season Limit of Insurance > Row 1 > Covered Property */
		this.PropertyCoverageFormGroup.addControl('P1230CVPP', new UntypedFormControl(PropCov.P1230CVPP ? PropCov.P1230CVPP : '',
			this.pcBRValidation.PeakSeasonProp1Required(this.PropertyCoverageFormGroup, this.PropertyCoverageData)));
		/* Peak Season Limit of Insurance > Row 2 > Covered Property */
		this.PropertyCoverageFormGroup.addControl('P1230CV1P', new UntypedFormControl(PropCov.P1230CV1P ? PropCov.P1230CV1P : '',
			this.pcBRValidation.PeakSeasonProp2Required(this.PropertyCoverageFormGroup, this.PropertyCoverageData)));	

		/* Peak Season Limit of Insurance > Row 1 > Additional Limit of Insurance */
		this.PropertyCoverageFormGroup.addControl('BPPSL1', new UntypedFormControl(PropCov.BPPSL1 != 0 ? PropCov.BPPSL1 : '', 
			this.pcBRValidation.BPPAddlLimit1(this.PropertyCoverageFormGroup, this.PropertyCoverageData)));

		/* Peak Season Limit of Insurance > Row 2 > Period From */
		//this.PropertyCoverageFormGroup.addControl('BPPDF2', new FormControl(this.func.DTEWinsToPrimeNG(PropCov.BPPDF1)));
		this.PropertyCoverageFormGroup.addControl('BPPDF2', new UntypedFormControl( PropCov.BPPDF2 ? this.func.DTEWinsToPrimeNG(PropCov.BPPDF2) : 0,
			this.pcBRValidation.BPPPeriodToFrom2(this.PropertyCoverageFormGroup, this.PropertyCoverageData)));

		/* Peak Season Limit of Insurance > Row 2 > Period To */
		//this.PropertyCoverageFormGroup.addControl('BPPDT2', new FormControl(this.func.DTEWinsToPrimeNG(PropCov.BPPDT2)));
		this.PropertyCoverageFormGroup.addControl('BPPDT2', new UntypedFormControl( PropCov.BPPDT2 ? this.func.DTEWinsToPrimeNG(PropCov.BPPDT2) : 0,
			this.pcBRValidation.BPPPeriodToFrom1(this.PropertyCoverageFormGroup, this.PropertyCoverageData)));


		/* Peak Season Limit of Insurance > Row 2 > Additional Limit of Insurance */
		this.PropertyCoverageFormGroup.addControl('BPPSL2', new UntypedFormControl(PropCov.BPPSL2 != 0 ? PropCov.BPPSL2 : '',
			this.pcBRValidation.BPPAddlLimit2(this.PropertyCoverageFormGroup, this.PropertyCoverageData)));
		// end add block

		/* Building Property Tenants Policy */
		this.PropertyCoverageFormGroup.addControl('BLDTP1', new UntypedFormControl({ value: ""}));



		// Limit of insurance on building glass
		// Temporary field - this is just a place holder
		// to send the data to WINS
		this.PropertyCoverageFormGroup.addControl('tmpBLDLM1', new UntypedFormControl(PropCov.BLDLM1 !== 0 ? PropCov.BLDLM1 : '',
			[this.pcBRValidation.BPPBuildGlassORBuildPropRequired(this.PropertyCoverageFormGroup, this.BLDLM2 ? this.BLDLM2.value: null, this.PropertyCoverageData),
				this.pcBRValidation.BuildingPropTenants(this.PropertyCoverageFormGroup)]));

		// Limit of Insurance on Building Property Other than Glass
		this.PropertyCoverageFormGroup.addControl('BLDLM2', new UntypedFormControl(PropCov.BLDLM2 !== 0  ? PropCov.BLDLM2 : '',
			this.pcBRValidation.BPPLimitBuildPropGlassRange(this.PropertyCoverageFormGroup, this.BLDLM2 ? this.BLDLM2.value : null, 
				this.PropertyCoverageData)));

		//this.PropertyCoverageFormGroup.setValidators([this.migPropertyCoverageValidator.oneOfControlRequired(this.tmpBLDLM1, this.BLDLM2)])

		this.PropertyCoverageFormGroup.addControl('UTLSVC', new UntypedFormControl(PropCov.UTLSVC !== 0 ? PropCov.UTLSVC : 0,
			this.pcBRValidation.UtilityServicesLimit(this.PropertyCoverageFormGroup, this.PropertyCoverageData)));


		// let's do some final processing on values
		// if we have Period From for Peak Season Limit of Insurance - check the checkbox set above
		if (this.PropertyCoverageData.BPPLM1 > 0 && this.PropertyCoverageData.BPPDF1 != 0) {
			this.checkboxPSLI.setValue(true);
		} else {
			this.checkboxPSLI.setValue(false);
		}

		//need to check for BLDLM1 has value and diable BLDTP1 field
		if (PropCov.BLDTP1 === 'B' && this.func.justNumbers(PropCov.BLDLM1) !== 0) {
			this.checkboxBLDTP1.disable();
			this.checkboxBLDTP1.setValue(false);
		} else {
			this.checkboxBLDTP1.enable();
		}

		// Check for data for Building Property Tenants Policy and check the checkbox if true
		// 'G','T" is for sceduled and unscheduled selection
		if ((PropCov.BLDTP1 === 'G' || PropCov.BLDTP1 === 'T') && this.func.justNumbers(PropCov.BPPLM1) !== 0) {
			this.checkboxBLDTP1.setValue(true);
			this.BLDLM1.disable();
			this.BLDLM1.setValue('');
		} else {
			this.checkboxBLDTP1.setValue(false);
		}
		

		// Check for utility services and check the checkbox if true
		if (this.UTLSVC.value > 0) {
			this.checkboxUTLSVC.setValue(true);
		} else {
			this.checkboxUTLSVC.setValue(false);
		}

    }
    
    processTerritoryInfoForBuilding()
    {
        
        let PropCov = this.PropertyCoverageData;
        /* Protection Class */
        let currentPRTCLS = '';
        /* Fire district name */
        let currentRATCTY = '';
		if (PropCov.BLDNUM == "001")
		{
			currentPRTCLS = PropCov.PRTCLS;	
			if (currentPRTCLS == '' && this.classesAandB != '') {
				this.hasSplitProtectionClass = true;
                
                this.canChangeFeetAndMiles = (PropCov.FTHYDT == '' || PropCov.FDMILE == '');
                    
				this.splitProtectionClass = this.classesAandB;
				currentPRTCLS = this.getProtectionClass(PropCov.FTHYDT, PropCov.FDMILE);
            }
            
            currentRATCTY = PropCov.RATCTY
            if (currentRATCTY == '')
            {
                this.contractorsDropDowns.RATCTY = [];
                this.fireDistrictsArray.forEach(element => {
					this.contractorsDropDowns.RATCTY.push({"value": element.label, "label": element.label});
					if (element.label.trim() === PropCov.RATCTY.trim()) {
						currentRATCTY = element.label;
					}
				});	
            }
            else
            {
                //don't allow change the Fire District selection, because other buildings are all defaulted by what selected
				this.fireDistrictsArray.length = 0;
            }
		} 
		else {
            //We are dealing with this location's n'th building where n >= 2
            //Copy over information from the first building
            let firstBuildingForCurrentLocation = _.find(this.ctrQuote.CFPENTITY.CFPLOCATIONS, (location) => (PropCov.LOCNUM == location.LOCNUM && location.BLDNUM == "001" && location.RECORDSTATE != "D"));
            currentPRTCLS = firstBuildingForCurrentLocation.PRTCLS;
            PropCov.FTHYDT = firstBuildingForCurrentLocation.FTHYDT;
            PropCov.FDMILE = firstBuildingForCurrentLocation.FDMILE;
            
            currentRATCTY =  firstBuildingForCurrentLocation.RATCTY;	
            PropCov.CONTY =  firstBuildingForCurrentLocation.CONTY;
            PropCov.PRTCLS = firstBuildingForCurrentLocation.PRTCLS;
            
            this.fireDistrictsArray.length = 0;
			this.PropertyCoverageFormGroup.get('CONTY').setValue(PropCov.CONTY);
        }
        
        this.PropertyCoverageFormGroup.addControl('PRTCLS', new UntypedFormControl(currentPRTCLS ? currentPRTCLS : ""));
        this.PropertyCoverageFormGroup.addControl('RATCTY', new UntypedFormControl(currentRATCTY ? currentRATCTY : ""));
        if (this.fireDistrictsArray.length) {
			this.RATCTY.setValidators(this.pcBRValidation.ValidateRequired("RATCTY", "Fire District Name"));
		}
    }

	//set the default values for PSLI out
	//form chnage subscribe to keep date values
	//from changing on every click event
	PSLIDefaultValues(event){
		//pre-fill values if PSLI is checked
		if (event == true){
			this.BPPDF1.setValue(this.func.DTEWinsToPrimeNG(0));
			this.BPPDT1.setValue(this.func.DTEWinsToPrimeNG(0));
			this.BPPDF2.setValue(this.func.DTEWinsToPrimeNG(0));
			this.BPPDT2.setValue(this.func.DTEWinsToPrimeNG(0));
			//this.BPPSL1.setValue(1);
			//this.BPPSL2.setValue(1);
			// this.BPPSL1.setValidators([this.migPropertyCoverageValidator.ValidateRequired('Limit Required'),
			// 							this.migPropertyCoverageValidator.ValidateMaxValue('100,000',100000,'Additional Limit of Insurance'),
			// 							this.migPropertyCoverageValidator.ValidateMinValue('1',1,'Additional Limit of Insurance')
	   		// 						]);
		}
		else{
			this.BPPDF1.setValue(0);
			this.BPPDT1.setValue(0);
			this.BPPDF2.setValue(0);
			this.BPPDT2.setValue(0);
			//this.BPPSL1.setValue(0);
			//this.BPPSL2.setValue(0);
		}
	}

	CheckFireDistrictAndHydrantDistanceValidation() {
        if (this.hasSplitProtectionClass)
        {
            this.FTHYDT.setValidators(this.pcBRValidation.ValidateRequired("FTHYDT", "Feet from hydrant"));
            this.FDMILE.setValidators(this.pcBRValidation.ValidateRequired("FDMILE", "Miles from fire department"));
        }
        else 
        {
            if (this.PropertyCoverageFormGroup.get('FTHYDT'))
            {
                this.PropertyCoverageFormGroup.get('FTHYDT').setValue('');
                this.PropertyCoverageFormGroup.get('FTHYDT').clearValidators();
            }
            
            if (this.PropertyCoverageFormGroup.get('FDMILE'))
            {
                this.PropertyCoverageFormGroup.get('FDMILE').setValue('');
                this.PropertyCoverageFormGroup.get('FDMILE').clearValidators();
            }
        }

        this.PropertyCoverageFormGroup.updateValueAndValidity();

    }

	UpdateQuote() {
		this.FormGroupSubscription = this.PropertyCoverageFormGroup.valueChanges.pipe(debounceTime(500)).subscribe(data => {

            // Territory
			this.PropertyCoverageData.TERR = data.TERR ? data.TERR : "";

			// County Name
			this.PropertyCoverageData.CONTY = data.CONTY ? data.CONTY : "";
			this.PropertyCoverageData.TAXCTY = data.TAXCTY ? data.TAXCTY : "";			
			if (this.selectedTAXTWN != null && this.selectedTAXTWN != undefined && this.selectedTAXTWN.trim() != "")
				this.PropertyCoverageData.TAXTWN = this.selectedTAXTWN;

			// Protection Class
			this.PropertyCoverageData.PRTCLS = data.PRTCLS ? data.PRTCLS : "";			

			// Fire District Name
			this.PropertyCoverageData.RATCTY = data.RATCTY ? data.RATCTY : "";

			// Feet from hydrant
			this.PropertyCoverageData.FTHYDT = data.FTHYDT ? data.FTHYDT : "";

			// Miles from fire department
			this.PropertyCoverageData.FDMILE = data.FDMILE ? data.FDMILE : "";

			
			//Fire Protective Safeguards
			//this.ctrQuote.CFPENTITY.CFPLOCATIONS[this.loopId].FIRALMLIST = data.FIRALMLIST ? data.FIRALMLIST : "";
			this.PropertyCoverageData.SPRINK  = (data.SPRINK == true) ? 'Y' : '';
			this.PropertyCoverageData.FIRALM1 = (data.FIRALM1 == true) ? 'P2' : '';
			this.PropertyCoverageData.FIRALM2 = (data.FIRALM2 == true) ? 'P3' : '';

			// Burglary and Robbery Protective Safeguards
			//this.ctrQuote.CFPENTITY.CFPLOCATIONS[this.loopId].BURGALLIST = data.BURGALLIST ? data.BURGALLIST : "";
			this.PropertyCoverageData.BURGAL1 = (data.BURGAL1 == true) ? 'B1' : '';
			this.PropertyCoverageData.BURGAL2 = (data.BURGAL2 == true) ? 'B2' : '';
			this.PropertyCoverageData.BURGAL3 = (data.BURGAL3 == true) ? 'B3' : '';

			// Building Occupancy Class
			this.PropertyCoverageData.BLDCLSLIST = data.BLDCLSLIST ? data.BLDCLSLIST : "";
		

			// updated 20190807
			// Other Occupancies
			this.PropertyCoverageData.SNGOFG = data.SNGOFG ? data.SNGOFG : '';

			// Property Deductible
			//this.ctrQuote.CFPENTITY.CFPLOCATIONS[this.loopId].BLDDED = data.BLDDED ? data.BLDDED : "";
			this.PropertyCoverageData.BLDGDD = data.BLDGDD ? data.BLDGDD : "";

			// Windstorm or Hail Deductibe - here we know only the first prop cvg can be updated
			//all others are readonly - so we can just set the value to the rest of them.
			this.ctrQuote.CFPENTITY.CFPLOCATIONS.forEach(prop => {
				if ((prop.LOCNUM == this.locationId)) {
					prop.WNDDCT = data.WNDDCT ? data.WNDDCT : "0";		
				}
			});

			// Construction Type
			this.PropertyCoverageData.CONSYM = data.CONSYM ? data.CONSYM : "";

			// Year Built
			this.PropertyCoverageData.CONYR = data.CONYR ? data.CONYR : "";
			

			// Building Valuation
			this.PropertyCoverageData.BLDVAL = data.BLDVAL ? data.BLDVAL : "";

			// Building Coinsurance
			//this.ctrQuote.CFPENTITY.CFPLOCATIONS[this.loopId].BLDCIN = data.BLDCIN ? data.BLDCIN.replace('%', '') : "";
			this.PropertyCoverageData.BLDCN1 = data.BLDCN1 ? data.BLDCN1.replace('%', '') : "";

			// Cause of Loss
			this.PropertyCoverageData.BLDCOL = data.BLDCOL ? data.BLDCOL : "";

            // Windstorm Protective Device

            if (!(this.WINDEV.pristine)) {
                this.PropertyCoverageData.WINDEV = (data.WINDEV == true) ? 'Y' : 'N';
            }

			// this.ctrQuote.CFPENTITY.CFPLOCATIONS[this.loopId].BPPLM1 = data.BPPLM1 ? (data.BPPLM1).replace('$','') : "0";

			// BPP Limit
			this.PropertyCoverageData.BPPLM1 = data.BPPLM1 ? this.func.justNumbers(data.BPPLM1) : 0;

			// Theft Exclusion
			//this.ctrQuote.CFPENTITY.CFPLOCATIONS[this.loopId].BPPTFE = (data.BPPTFE == true) ? 'Y' : 'N';

			// BPP Valuation
			this.PropertyCoverageData.BPPVN1 = data.BPPVN1 ? data.BPPVN1 : "";

			// BPP Coinsurance
			this.PropertyCoverageData.BPPCN1 = data.BPPCN1 ? data.BPPCN1 : "";

			// Cause of Loss
			this.PropertyCoverageData.BPPCOL = data.BPPCOL ? data.BPPCOL : "";

			// Peak Season Limit of Insurance - Row 1 - Period From
			this.PropertyCoverageData.BPPDF1 = data.BPPDF1 ? this.func.funcDateSelected(data.BPPDF1) : 0;

			// PSLI - Row 1 - Period to
			this.PropertyCoverageData.BPPDT1 = data.BPPDT1 ? this.func.funcDateSelected(data.BPPDT1) : 0;

			// PSLI - Row 1 - Covered Property
			this.PropertyCoverageData.P1230CVPP = data.P1230CVPP ? data.P1230CVPP : '';

			// PSLI - Row 1 - Additional Limit of Insurance
			this.PropertyCoverageData.BPPSL1 = data.BPPSL1 != '' ? this.func.justNumbers(data.BPPSL1) : 0;

			// Peak Season Limit of Insurance - Row 2 - Period From
			this.PropertyCoverageData.BPPDF2 = data.BPPDF2 ? this.func.funcDateSelected(data.BPPDF2) : 0;

			// PSLI - Row 2 - Period to
			this.PropertyCoverageData.BPPDT2 = data.BPPDT2 ? this.func.funcDateSelected(data.BPPDT2) : 0;

			// PSLI - Row 2 - Covered Property
			this.PropertyCoverageData.P1230CV1P = data.P1230CV1P ? data.P1230CV1P : '';

			// PSLI - Row 2 - Additional Limit of Insurance
			this.PropertyCoverageData.BPPSL2 = data.BPPSL2 != '' ? this.func.justNumbers(data.BPPSL2) : 0;

            
			// Building Limit
			if (this.func.justNumbers(data.BLDLM1) > 0) {
				
				// If building limit, set BLDTP1 to "B"
				this.PropertyCoverageData.BLDTP1 = "B";
				this.PropertyCoverageData.BLDTP2 = "";
				this.PropertyCoverageData.BLDLM1 = this.func.justNumbers(data.BLDLM1);
				//
				this.PropertyCoverageData.BLDLM2 = 0;
				
			}
			else{
				this.PropertyCoverageData.BLDTP1 = "";
				this.PropertyCoverageData.BLDLM1 = 0;
                this.PropertyCoverageData.BLDLM2 = 0;
                this.PropertyCoverageData.WINDEV = '';
			}

			//Building Property Tenants Policy
			if (this.checkboxBLDTP1.value) {
				if (this.dropdownBLDTP1.value.toUpperCase() === 'SCHEDULED') {
					this.PropertyCoverageData.BLDTP1 = "G";
					this.PropertyCoverageData.BLDTP2 = "P";
				} else {
					this.PropertyCoverageData.BLDTP1 = "T";
					this.PropertyCoverageData.BLDTP2 = "O";
				}
				this.PropertyCoverageData.BLDLM1 = this.func.justNumbers(data.tmpBLDLM1 != '' ? data.tmpBLDLM1 : '');
				this.PropertyCoverageData.BLDLM2 = this.func.justNumbers(data.BLDLM2 != '' ? data.BLDLM2 : '');
			}
			// else{
			// 	this.ctrQuote.CFPENTITY.CFPLOCATIONS[this.loopId].BLDTP1 = "";
			// 	this.ctrQuote.CFPENTITY.CFPLOCATIONS[this.loopId].BLDTP2 = "";
			// }
			
		
			this.PropertyCoverageData.UTLSVC = data.UTLSVC ? data.UTLSVC : 0;
			
			//REMOVED TASK 1435
			//FOR CP 1219 Additional Insured; need to add to the DWXP111
			//this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.BOCNT = data.BOCNT ? data.BOCNT : 0;
			// this.ctrQuote.CFPENTITY.CFPLOCATIONS[this.loopId].CCPALL = data.CCPALL ? Number(data.CCPALL) : 0;
			// let _total:number = 0; 
			// this.ctrQuote.CFPENTITY.CFPLOCATIONS.forEach(item => {
			// 	_total = _total + item.CCPALL;
			// 	this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.BOCNT = _total;
			// });

			// Update Record State
			this.PropertyCoverageData.PRMSTE = this.state;
			this.PropertyCoverageData.POLICY = this.ctrQuote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
			this.PropertyCoverageData.EFFDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
			this.PropertyCoverageData.TRANS = this.ctrQuote.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;
			this.PropertyCoverageData.RCDTYP = this.ctrQuote.QUOTEPOLICYINFORMATION.RECORDTYPE;
			this.PropertyCoverageData.EDSDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;
            
            if (this.PropertyCoverageData.RECORDSTATE != 'D') 
                this.PropertyCoverageData.RECORDSTATE = "U";
            
                this.PropertyCoverageData.BPPCOL = (this.BPPCOL.value == 'Special') ? 'SP' : '';


			//check if they made any changes and prompt modal from 'next button'
			if(this.mode == 'update' && (this.PropertyCoverageFormGroup.dirty || this.PropertyCoverageFormGroup.touched)){
				this.menuClass.stopNavigation = true;
			}	

			/*if(this.doneClicked){
				let processBR = new PropertyCoverageBR();
				let result: IBRR = processBR.ProcessBR(this.ctrQuote.CFPENTITY.CFPLOCATIONS[this.loopId], this.PropertyCoverageFormGroup);
				this.errors = this.menuClass.CalculateErrorsFormGroup(this.PropertyCoverageFormGroup, result.errors);
				if(!this.errors.length){
					this.migsystemservice.notifyToastMessagesCleared();
					this.doneClicked=false;
				}
				this.btnDone()
			}*/
			//this.PropertyCoverageFormGroup.updateValueAndValidity();
			this.BLDLM1.setValidators([this.pcBRValidation.BuildingLimitOrBPPLimit(this.PropertyCoverageData),
			this.pcBRValidation.BuildingLimitMin(this.PropertyCoverageData)]);

			this.pcBRValidation.TriggerValidation(this.PropertyCoverageFormGroup);
			
		});
		
	}
	
	selectFireDistrict() {
        
		if (this.fireDistrictsArray.length == 0)
		{	
			return;
		}

		var selectedOption = '';
		this.fireDistrictsArray.forEach(element => {
			if (element.label == this.PropertyCoverageFormGroup.get('RATCTY').value) {
				selectedOption = element.value;
			}
		});

		//Fire district
		this.PropertyCoverageData.RATCTY = selectedOption.substring(0,30);

		//County name
		this.PropertyCoverageFormGroup.get('CONTY').setValue(selectedOption.substring(57,87));
		this.PropertyCoverageFormGroup.get('TAXCTY').setValue(selectedOption.substring(54,57));
		this.selectedTAXTWN = selectedOption.substring(49,54)

		//Protection class		
        let protectionClassesWorkField = selectedOption.substring(41,49);
        
		//if future protection cloass is not blank, use it; if it's blank, use protection class
		if (!protectionClassesWorkField.replace(/\s/g, '').length) {
			protectionClassesWorkField = selectedOption.substring(33,41);
		}
        
		this.splitProtectionClass = protectionClassesWorkField;

		if ((this.splitProtectionClass == '') || (!this.isSplitProtectionClass(protectionClassesWorkField))) {
			//only has protection class A; protection class B is lbank
			//Miles from Dire Dept hand Feet to Hydrant are NOT required
			this.hasSplitProtectionClass = false;	
			this.PropertyCoverageFormGroup.get('PRTCLS').setValue(this.getProtectionClass('',''));	
            
		} else {
			this.hasSplitProtectionClass = true;
			this.canChangeFeetAndMiles = true;
        }
        
        this.CheckFireDistrictAndHydrantDistanceValidation();
	}

	isSplitProtectionClass(splitProtectionClass) : boolean {
		let protectionClasses = splitProtectionClass.split("/").filter(function(value, index){
			return value.replace(/\s/g, '') != '';
		}).map((value:string) => value.replace(/\s/g, ''));

		if (protectionClasses.length == 1)
			return false
		else	
			return true;
	}

	getProtectionClass(feet, miles) : string {
		var theProtectionClass = '';

		let protectionClasses = this.splitProtectionClass.split("/").filter(function(value, index){
			return value.replace(/\s/g, '') != '';
		}).map((value:string) => value.replace(/\s/g, ''));

		if (protectionClasses.length == 1) {
			theProtectionClass = protectionClasses[0].padStart(2, '0');	
		} else {
			//has both protection class A and B
			//Miles from Dire Dept hand Feet to Hydrant are required
			if( feet != '' && miles != '') {				
				if (miles.toUpperCase() == "OVER 5 MILES") {
					//If Miles from Fire Dept is Over 5 Miles,then default Protection Class to 10
					theProtectionClass = "10";
				} else {
					if (feet.toUpperCase() == "WITHIN 1000 FT") {
						//If Miles from Fire Dept is Within 5 Miles and if Feet to Hydrant is "Within 1000 Ft" then use Protection Class A as Protection Class					
						theProtectionClass = protectionClasses[0].padStart(2, '0');
					} else {
						//If Miles from Fire Dept is Within 5 Miles and if Feet to Hydrant is "Over 1000 Ft"  then use Protection Class B as Protection class
						theProtectionClass = protectionClasses[1].padStart(2, '0');
					}
				}
			} else {
				theProtectionClass = '';
			}	
		}

		//correct a Protection class of 8B to 09
		if (theProtectionClass == '8B') {
			theProtectionClass = '09';
		}
		return theProtectionClass;
	}

	selectFeetAndMiles() {
		let feet = this.PropertyCoverageFormGroup.get('FTHYDT').value;
		let miles = this.PropertyCoverageFormGroup.get('FDMILE').value;

		this.PropertyCoverageFormGroup.get('PRTCLS').setValue(this.getProtectionClass(feet,miles));
		this.PropertyCoverageData.PRTCLS = this.PropertyCoverageFormGroup.get('PRTCLS').value;
		
	}
}
