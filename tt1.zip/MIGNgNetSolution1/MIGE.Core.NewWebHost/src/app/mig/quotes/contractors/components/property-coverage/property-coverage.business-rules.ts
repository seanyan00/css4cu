import { AbstractControl, UntypedFormGroup } from "@angular/forms";
import { Validation } from '@classes/Common/ValidatorClass/Validation';
import { CFPLOCATION } from '@classes/CTR/CFPLOCATION';
import { Functions } from '@helpers/functions';
import { AppErrors } from '@root/shared_components/errors/app-errors';

export class PropertyCoverageBRValidation extends Validation {
	constructor(
		private func: Functions
				
		) {
	
		super();
	}

	LocationInfoPropDedeductible = (cfpLocation: CFPLOCATION) =>  {
		return (ac: AbstractControl): AppErrors | null => {
			// Location > Property Deductible
			// Required. Choose from list of Options.
			// Cannot be higher than the sum of Building and Business Personal Property Limits on the location building that is being added.
			if (cfpLocation.BLDGDD) {
				let BLBPPLTot: number = this.func.justNumbers(cfpLocation.BLDLM1) + this.func.justNumbers(cfpLocation.BPPLM1);
				if (Number(cfpLocation.BLDGDD) > BLBPPLTot) {
					return { severity: "error", 
					summary: "BLDGDD",
					detail: "Location Information Property Deductible cannot be greater than the sum of Building Limits and Building Personal Property Limits", 
					sticky: true, 
					closable: false };
				}
			}	
			return null;
		}
	}

	//BLDCLSLIST Building Occupancy class
	BuildingOccupancyClass = (cfpLocation: CFPLOCATION) => {
		return (ac:AbstractControl): AppErrors | null => {
			if(cfpLocation.BLDCLSLIST.length < 1) {
				return { severity: "error", summary:"BLDCLSLIST", detail: "Building Occupancy Class must be selected.", sticky: true, closable:false };
			}
			return null;
		}
	}

	
	BuildingLimitOrBPPLimit = (cfpLocation: CFPLOCATION) => {
		return (ac:AbstractControl): AppErrors | null => {				
			// Building Limit OR BPP limit is required
			if (!(this.func.justNumbers(cfpLocation.BLDLM1) > 0) && !(this.func.justNumbers(cfpLocation.BPPLM1) > 0)) {
				return{ severity: "error", summary: "BLDLM1", detail: "Building Limit OR Business Personal Property Limit is required", sticky: true, closable:false };
			}
			let BLBPPLTot: number = this.func.justNumbers(cfpLocation.BLDLM1) + this.func.justNumbers(cfpLocation.BPPLM1);
			// Building Limit and BPP Limit cannot exceed $5,000,000 combined
			if (BLBPPLTot > 5000000) {
				return { severity: "error", summary: "BLDLM1", detail: "Building Limit and Business Personal Property Limit cannot exceed $5,000,000 combined", sticky: true, closable:false };
			}
			return null;
		}
	}

	// Building > Building Limit
	// Cannot be less then $5,000
	BuildingLimitMin = (cfpLocation: CFPLOCATION) =>  {
		return (ac: AbstractControl): AppErrors | null => {
			if ((cfpLocation.BLDTP1 == "B" && cfpLocation.BLDLM1 < 5000) && this.func.justNumbers(cfpLocation.BPPLM1) == 0) {
				return { severity: "error", summary: "BLDLM1", detail: "Building Limit cannot be less than $5,000", sticky: true, closable:false };
			}
			return null;
		}
	}
	// BPP > Building Personal Property Limit
	// Cannot be less then $1,000 or more than 5,000,000
	BPPLimitRange = (cfpLocation: CFPLOCATION) =>  {
		return (ac: AbstractControl): AppErrors | null => {
			if ((this.func.justNumbers(cfpLocation.BPPLM1) < 1000 || this.func.justNumbers(cfpLocation.BPPLM1) > 5000000) && this.func.justNumbers(cfpLocation.BPPLM1) !=0) {		
				return { severity: "error", summary: "BPPLM1", detail: "Business Personal Property Limit must be between $1,000 & $5,000,000", sticky: true, closable:false };
			}
			return null;
		}
	}

	// BPP > Period from - Period to - Row 1 
	// period to cannot be less than period from
	BPPPeriodToFrom1 = (fg:UntypedFormGroup, cfpLocation: CFPLOCATION) => {
		return (ac: AbstractControl): AppErrors | null => {
			if (cfpLocation.BPPDF1 > 0 && cfpLocation.BPPDT1 > 0) {
				//console.log(fg.get('BPPDT1').value);
				let d1 = Number(this.func.WinsToDateObject(cfpLocation.BPPDF1));
				let d2 = Number(this.func.WinsToDateObject(cfpLocation.BPPDT1));
				let ddiff = Math.round((d2 - d1) / 864e5);
				if (d2 < d1) {
					return{ severity: "error", summary:"BPPDT1", detail: "Peak Season Limit of Insurance: Period to cannot be less than Period from", sticky: true, closable:false };
				}
				if (d1 > d2) {
					return { severity: "error", summary:"BPPDF1",detail: "Peak Season Limit of Insurance: Period to cannot be greater than Period from", sticky: true, closable:false };
				}
				if (ddiff > 182) {
					return { severity: "error", summary:"BPPDT1", detail: "Peak Season Limit of Insurance: Period from and Period to cannot exceed 6 months", sticky: true, closable:false };
				}
			}
			return null;
		}
	}

	BPPPeriodToFrom2=(fg: UntypedFormGroup, cfpLocation: CFPLOCATION) => {
		return (ac: AbstractControl): AppErrors | null => {
			if (cfpLocation.BPPDF2 > 0 && cfpLocation.BPPDT2 > 0) {
				let d1 = Number(this.func.WinsToDateObject(cfpLocation.BPPDF2));
				let d2 = Number(this.func.WinsToDateObject(cfpLocation.BPPDT2));
				let ddiff = Math.round((d2 - d1) / 864e5);
				if (d2 < d1) {
					return{ severity: "error", summary:"BPPDT2", detail: "Peak Season Limit of Insurance: Period to cannot be less than Period from", sticky: true, closable:false };
				}
				if (d1 > d2) {
					return { severity: "error", summary:"BPPDF2",detail: "Peak Season Limit of Insurance: Period to cannot be greater than Period from", sticky: true, closable:false };
				}
				if (ddiff > 182) {
					return { severity: "error", summary:"BPPDT2", detail: "Peak Season Limit of Insurance: Period from and Period to cannot exceed 6 months", sticky: true, closable:false };
				}
			}
			return null;
		}
	}

	// BPP > Additional Limit of Insurance - Row 1
	// Cannot exceed $100,000
	BPPAddlLimit1 = (fg: UntypedFormGroup, cfpLocation: CFPLOCATION) => {
		return (ac: AbstractControl): AppErrors | null => {
			if(fg.get('checkboxPSLI') == null) return null;
			if ((cfpLocation.BPPSL1 < 1 || cfpLocation.BPPSL1 > 100000) && fg.get('checkboxPSLI').value) {
				return { severity: "error", summary:"BPPSL1", detail: "Additional Limit of Insurance 1, must between $1 & $100,000", sticky: true, closable:false };
			}
			return null;
		}
	}

	// BPP > Additional Limit of Insurance - Row 2
	// Cannot exceed $100,000
	BPPAddlLimit2 = (fg: UntypedFormGroup, cfpLocation: CFPLOCATION) => {
		return (ac:AbstractControl): AppErrors | null => {
			if(fg.get('checkboxPSLI') == null) return null;
			if ((cfpLocation.BPPSL2 < 1 || cfpLocation.BPPSL2 > 100000) && fg.get('checkboxPSLI').value) {
				return { severity: "error", summary:"BPPSL2", detail: "Additional Limit of Insurance 2, must between $1 & $100,000", sticky: true, closable:false};
			}
			return null;
		}
	}

	// BPP > Limit of Insurance on Building Glass OR Limit of Insurance on Building Property Other than Glass Required
	BPPBuildGlassORBuildPropRequired = ( fg: UntypedFormGroup, BLDLM2 :string | number, cfpLocation: CFPLOCATION )	 => {
		return (ac:AbstractControl): AppErrors | null => {
			if(fg.get('checkboxBLDTP1') == null) return null;
			if (cfpLocation.BLDTP1 != "B") {
				if ((fg.get('tmpBLDLM1') == null || fg.get('tmpBLDLM1').value === '') && ( fg.get('BLDLM2') == null || fg.get('BLDLM2').value === '') && (cfpLocation.BLDTP1 == "G" || cfpLocation.BLDTP1 == "T")) {
					return { severity: "error", summary:"tmpBLDLM1", detail: "Limit of Insurance on Building Glass OR Limit of Insurance on Building Property Other than Glass is required", sticky: true, closable:false };
				}
				else 
				{
					// BPP > Limit of Insurance on Building Glass
					// Cannot exceed $100,000
					// Cannot have Building Limit
					// BPP Limit > $0	
					if(fg.get('tmpBLDLM1') != null && fg.get('tmpBLDLM1').value !== '') {
												
						if(this.func.justNumbers(fg.get('tmpBLDLM1').value) > 100000 || this.func.justNumbers(fg.get('tmpBLDLM1').value) < 1 && (cfpLocation.BLDTP1 == "G" || cfpLocation.BLDTP1 == "T"))  
						{	
							return{ severity: "error", summary:"tmpBLDLM1", detail: "Limit of Insurance on Building Glass must be between $1 and $100,000", sticky: true, closable:false };
						}
					}
				}
			}
			return null;
		}
	}
	// BPP > Limit of Insurance on Building Property Other than Glass
	// Cannot exceed $100,000
	// Cannot have Building Limit
	// BPP Limit > $0
	BPPLimitBuildPropGlassRange = (fg: UntypedFormGroup, BLDLM2: string | number, cfpLocation: CFPLOCATION)	 => {
		return (ac:AbstractControl): AppErrors | null => {
			if(fg.get('checkboxBLDTP1') == null) return null;
			if (cfpLocation.BLDTP1 != "B") {
				if ((fg.get('tmpBLDLM1') == null || fg.get('tmpBLDLM1').value === '') && ( fg.get('BLDLM2') == null || fg.get('BLDLM2').value == null ) && ((cfpLocation.BLDTP1 === "G") || (cfpLocation.BLDTP1 === "T"))) {
					return null
				}else {
					if(fg.get('BLDLM2') == null) return null;
					if((cfpLocation.BLDLM2 > 100000 || cfpLocation.BLDLM2 < 1) && fg.get('BLDLM2').value !== '') {
						return{ severity: "error", summary:"BLDLM2", detail: "Limit of Insurance on Building Property Other than Glass must be between $1 and $100,000", sticky: true, closable:false };
					}
					
				}
			}
			return null;
		}

	}
	PeakSeasonProp1Required = (fg: UntypedFormGroup, cfpLocation: CFPLOCATION) => {
		return (ac:AbstractControl): AppErrors | null => {
			//Peak Season Covered Property 1 P1230CVPP
			if(fg.get('checkboxPSLI') == null) return null;
			if (fg.get('checkboxPSLI').value && cfpLocation.P1230CVPP === '' ) {
				return { severity: "error", summary:"P1230CVPP", detail: "Peak Season Limit of Insurance: Covered Property cannot be blank", sticky: true, closable:false };
			}
			return null;
		}
	}
	//P1230CV1P
	PeakSeasonProp2Required = (fg: UntypedFormGroup, cfpLocation: CFPLOCATION) => {
		return (ac:AbstractControl): AppErrors | null => {
			//Peak Season Covered Property 1 P1230CVPP
			if(fg.get('checkboxPSLI')== null) return null;
			if (fg.get('checkboxPSLI').value && cfpLocation.P1230CV1P === '') {
				return { severity: "error", summary:"P1230CV1P", detail: "Peak Season Limit of Insurance: Covered Property cannot be blank", sticky: true, closable:false };
			}
			return null;
		}
	}

	//UTLSVC Limit
	UtilityServicesLimit = (fg: UntypedFormGroup, cfpLocation: CFPLOCATION) => {
		return (ac: AbstractControl): AppErrors | null => {
			if(fg.get('checkboxUTLSVC') == null) return null;
			if (fg.get('checkboxUTLSVC').value && cfpLocation.UTLSVC === 0) {
				return { severity: "error", summary:"UTLSVC", detail: "Utility Services must have a limit", sticky: true, closable:false };
			}
			return null;
		}
	}

	//Building Property Tenants
	BuildingPropTenants = (fg: UntypedFormGroup) => {
		return (ac: AbstractControl): AppErrors | null => {
			if (fg.get('checkboxBLDTP1') == null || fg.get('dropdownBLDTP1') == null) return null;
			if (fg.get('checkboxBLDTP1').value && fg.get('dropdownBLDTP1').value === '') {
				return { severity: "error", summary:"checkboxBLDTP1", detail: "Building Property Tenants Policy must be selected.", sticky: true, closable:false };
			}
			return null;
		}
	}

	//Windstorm Protective Devices must be answered if building limit is entered and state is NY(#31)
	WindStormProtectiveDevices = (cfpLocation: CFPLOCATION) => {
		return (ac: AbstractControl): AppErrors | null => {
			if(cfpLocation.BLDLM1 && cfpLocation.PRMSTE === '31' && cfpLocation.BLDTP1 === 'B' && (!(cfpLocation.WINDEV == 'Y' || cfpLocation.WINDEV == 'N'))) {
				return {severity: 'error', summary: 'WINDEV', detail: 'Windstorm Protective Devices is required when Building Limit is entered in New York State.', sticky: true, closable: false};
			}
			return null;
		}
    }
}		
