
import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, UntypedFormControl } from '@angular/forms';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { Functions } from '@helpers/functions';
import { Subscription } from 'rxjs/internal/Subscription';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { MIGSystemService } from '@services/mig.service';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { MenuClass } from '@root/system/menu/menu';

@Component({
	selector: 'mig-coverage-inland-optional',
	templateUrl: './optional.component.html',
})

export class MIGCoverageInlandOptional implements OnInit, OnDestroy {
	tempDropDown: any[] = [];

	formBuilder: UntypedFormBuilder;
	formChanged: boolean = false;

	FormGroupSubscription: Subscription;
	updateRecordState: Subscription;
    resetForm: boolean = false;
    dropdownOptionsCINSLM: any[];
    dropdownOptionsCINLLM: any[];
    dropdownOptionsCINTLM: any[];

	@Input() ctrQuote: CTRQuote;
	@Input() formGroup: UntypedFormGroup;

	constructor(
		public func: Functions,
		public contractorsDropDowns: ContractorsDropDowns,
		public migsystemservice: MIGSystemService,
		public migRoles: MIGSecurityRoles,
		public menuClass: MenuClass
	) {
		if (this.formBuilder == null) {
			this.formBuilder = new UntypedFormBuilder();
		}
	}

	ngOnInit(): void {

        let mnu = this.menuClass.stepActiveObject;
        mnu.forms[0] = new UntypedFormGroup({});
		this.formGroup = mnu.forms[0];
		
		// shorten up our path
        let impJobsites = this.ctrQuote.IMPENTITY.IMPJOBSITES;
		
		// A. Property at the job site
		this.formGroup.addControl('checkboxCINSLM', new UntypedFormControl({ value: true, disabled: true }));
		this.formGroup.addControl('CINSLM', new UntypedFormControl((impJobsites.CINSLM ? impJobsites.CINSLM : this.contractorsDropDowns.defaultCINSLM)));

		// B. Property while held at any temporary storage location
		this.formGroup.addControl('checkboxCINLLM', new UntypedFormControl({ value: true, disabled: true }));
		this.formGroup.addControl('CINLLM', new UntypedFormControl((impJobsites.CINLLM ? impJobsites.CINLLM : this.contractorsDropDowns.defaultCINLLM)));

		// C. Property In Transit
		this.formGroup.addControl('checkboxCINTLM', new UntypedFormControl({ value: true, disabled: true }));
		this.formGroup.addControl('CINTLM', new UntypedFormControl((impJobsites.CINTLM ? impJobsites.CINTLM : this.contractorsDropDowns.defaultCINTLM)));
		// D. All covered property included in a, b, and c combined in any one occurrence
        this.formGroup.addControl('CINOLM', new UntypedFormControl(impJobsites.CINOLM));

        this.determineDropdownOptions();

        this.CalcAllCoveredProperty();
		

		this.FormGroupSubscription = this.formGroup.valueChanges.pipe(debounceTime(100), distinctUntilChanged()).subscribe(data => {
			data = this.formGroup.getRawValue();

			this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSLM = data.CINSLM ? data.CINSLM : 0;
			this.ctrQuote.IMPENTITY.IMPJOBSITES.CINLLM = data.CINLLM ? data.CINLLM : 0;
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTLM = data.CINTLM ? data.CINTLM : 0;
            this.CalcAllCoveredProperty();
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINOLM = this.CINOLM.value;

			this.setRatesBasedOnLimits();

			this.ctrQuote.IMPENTITY.IMPJOBSITES.CINJST = "ANY COVERED JOBSITE OF THE NAMED INSURED";
			this.ctrQuote.IMPENTITY.IMPJOBSITES.CINPRJ = "ANY COVERED INSTALLATION PROJECT OF THE NAMED INSURED";

			this.formChanged = true;
			this.menuClass.CalculateErrorsFormGroup(this.formGroup,true);
		});

		this.CalcAllCoveredProperty();

		this.updateRecordState = this.migsystemservice.subscribeUpdateRecordState().subscribe(() => {

			if (this.formChanged) {
				this.ctrQuote.IMPENTITY.IMPJOBSITES.POLICY = this.ctrQuote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
				this.ctrQuote.IMPENTITY.IMPJOBSITES.EFFDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
				this.ctrQuote.IMPENTITY.IMPJOBSITES.TRANS = this.ctrQuote.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;
				this.ctrQuote.IMPENTITY.IMPJOBSITES.RCDTYP = this.ctrQuote.QUOTEPOLICYINFORMATION.RECORDTYPE;
				this.ctrQuote.IMPENTITY.IMPJOBSITES.EDSDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;
				this.ctrQuote.IMPENTITY.IMPJOBSITES.RECORDSTATE = "U";
			}
		});

		this.menuClass.stepActiveObject.forms[0] = this.formGroup;
    }
    determineDropdownOptions()
    {
        if (this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE < 20210401)
        {
            this.dropdownOptionsCINSLM = this.contractorsDropDowns.preApril2021CINSLM;
            this.dropdownOptionsCINLLM = this.contractorsDropDowns.preApril2021CINLLM;
            this.dropdownOptionsCINTLM = this.contractorsDropDowns.preApril2021CINTLM;
        }
        else
        {
            this.dropdownOptionsCINSLM = this.contractorsDropDowns.CINSLM;
            this.dropdownOptionsCINLLM = this.contractorsDropDowns.CINLLM;
            this.dropdownOptionsCINTLM = this.contractorsDropDowns.CINTLM;
        }
    }
    setJobSiteRates() {
        this.ctrQuote.IMPENTITY.IMPJOBSITES.CINJRT = 0;
        if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSLM >= 450000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINJRT = 0.13;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSLM >= 350000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINJRT = 0.14;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSLM == 300000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINJRT = 0.15;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSLM == 250000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINJRT = 0.17;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSLM == 225000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINJRT = 0.18;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSLM == 200000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINJRT = 0.19;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSLM == 175000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINJRT = 0.20;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSLM == 150000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINJRT = 0.21;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSLM == 125000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINJRT = 0.23;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSLM == 100000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINJRT = 0.25;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSLM == 75000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINJRT = 0.27;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSLM == 50000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINJRT = 0.32;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSLM == 25000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINJRT = 0.40;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSLM == 20000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINJRT = 0.43;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSLM == 15000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINJRT = 0.48;
        }
    }
    setTempStorageRates() {
        this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSRT = 0;
        if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINLLM >= 450000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSRT = 0.10;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINLLM >= 350000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSRT = 0.11;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINLLM == 300000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSRT = 0.12;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINLLM == 250000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSRT = 0.13;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINLLM == 225000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSRT = 0.14;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINLLM == 200000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSRT = 0.14;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINLLM == 175000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSRT = 0.16;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINLLM == 150000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSRT = 0.17;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINLLM == 125000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSRT = 0.18;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINLLM == 100000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSRT = 0.19;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINLLM == 75000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSRT = 0.21;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINLLM == 50000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSRT = 0.24;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINLLM == 25000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSRT = 0.31;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINLLM == 20000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSRT = 0.33;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINLLM == 15000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSRT = 0.37;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINLLM == 10000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSRT = 0.40;
        }
    }
    setPropertyInTransitLimits() {
        this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTRT = 0;
        if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTLM >= 450000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTRT = 0.10;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTLM >= 350000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTRT = 0.11;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTLM == 300000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTRT = 0.12;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTLM == 250000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTRT = 0.13;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTLM == 200000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTRT = 0.14;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTLM == 175000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTRT = 0.16;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTLM == 150000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTRT = 0.17;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTLM == 125000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTRT = 0.18;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTLM == 100000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTRT = 0.19;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTLM == 75000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTRT = 0.21;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTLM == 50000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTRT = 0.24;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTLM == 25000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTRT = 0.31;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTLM == 20000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTRT = 0.33;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTLM == 15000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTRT = 0.37;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTLM == 10000)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTRT = 0.40;
        }
        else if (this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTLM == 7500)
        {
            this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTRT = 0.46;
        }
    }
    setRatesBasedOnLimits() {
        //Per Chris, if effective date is prior to April 1st, 2021, we need to use the old rates and limits.
        if (this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE < 20210401)
        {
            this.usePreApril2021RatesBasedOnLimits();
            return;
        }
        
        this.setJobSiteRates();
        this.setTempStorageRates();
        this.setPropertyInTransitLimits();
    }
    usePreApril2021RatesBasedOnLimits()
    {
        if(this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSLM > 10000){	this.ctrQuote.IMPENTITY.IMPJOBSITES.CINJRT = 0.5 }

        this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSRT = 0;
        if(this.ctrQuote.IMPENTITY.IMPJOBSITES.CINLLM > 5000){	this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSRT = 0.5 }

        this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTRT = 0;
        if(this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTLM > 5000){	this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTRT = 0.5 }

    }

	ngOnDestroy(): void {
		//Called once, before the instance is destroyed.
		//Add 'implements OnDestroy' to the class.
		if(this.FormGroupSubscription) this.FormGroupSubscription.unsubscribe();
		if(this.updateRecordState) this.updateRecordState.unsubscribe();

	}

	get checkboxCINSLM() { return this.formGroup.get("checkboxCINSLM"); }
	get CINSLM() { return this.formGroup.get("CINSLM"); }

	get checkboxCINLLM() { return this.formGroup.get("checkboxCINLLM"); }
	get CINLLM() { return this.formGroup.get("CINLLM"); }

	get checkboxCINTLM() { return this.formGroup.get("checkboxCINTLM"); }
	get CINTLM() { return this.formGroup.get("CINTLM"); }

	get CINOLM() { return this.formGroup.get("CINOLM"); }

	CalcAllCoveredProperty() {
		let a = this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSLM ? this.ctrQuote.IMPENTITY.IMPJOBSITES.CINSLM : parseInt(this.contractorsDropDowns.defaultCINSLM);
        let b = this.ctrQuote.IMPENTITY.IMPJOBSITES.CINLLM ? this.ctrQuote.IMPENTITY.IMPJOBSITES.CINLLM : parseInt(this.contractorsDropDowns.defaultCINLLM);
        let c = this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTLM ? this.ctrQuote.IMPENTITY.IMPJOBSITES.CINTLM : parseInt(this.contractorsDropDowns.defaultCINTLM);

        let d = a + b + c;
        this.ctrQuote.IMPENTITY.IMPJOBSITES.CINOLM = d;
		this.CINOLM.setValue(d, {emitEvent:false});
	}
}
