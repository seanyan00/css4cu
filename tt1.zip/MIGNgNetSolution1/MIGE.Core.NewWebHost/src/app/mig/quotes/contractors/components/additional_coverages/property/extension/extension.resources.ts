import { Injectable } from "@angular/core";
import { CTRQuote } from "@classViewModels/CTR/CTRQuote";

@Injectable()
export class MIGPropertyResources {
	ctrQuote: CTRQuote;

	setCTRQuote(quote) {
		this.ctrQuote = quote;
	}

	processSplitList(data): any {
		//console.log('processSplitList DATA: ' + data);
		let arr: any[] = [];
		if(data == undefined || data == null || data == ''){
			return arr;
		}
		else{
			let tmp: string = data.toString();
			arr  = tmp.split("/");
			return arr;
		}
	}

	processDebrisRemoval(): boolean {
		if (this.ctrQuote.CFPENTITY && this.ctrQuote.CFPENTITY.CFPLOCATIONS && this.ctrQuote.CFPENTITY.CFPLOCATIONS.length) {
			return true;
		}
		return false;
	}
}