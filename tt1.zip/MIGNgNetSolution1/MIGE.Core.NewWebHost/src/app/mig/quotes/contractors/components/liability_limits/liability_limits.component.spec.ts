import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { Functions } from '@helpers/functions';
import { MIGLiabilityLimits } from '@CTRcomponents/liability_limits/liability_limits.component';

describe('MIGLiabilityLimits', () => {
	let comp: MIGLiabilityLimits;
	let fixture: ComponentFixture<MIGLiabilityLimits>;

	beforeEach(() => {
		const contractorsDropDownsStub = {};
		const functionsStub = {};
		TestBed.configureTestingModule({
			declarations: [ MIGLiabilityLimits ],
			schemas: [ NO_ERRORS_SCHEMA ],
			providers: [
				{ provide: ContractorsDropDowns, useValue: contractorsDropDownsStub },
				{ provide: Functions, useValue: functionsStub }
			]
		});
		fixture = TestBed.createComponent(MIGLiabilityLimits);
		comp = fixture.componentInstance;
	});

	it('can load instance', () => {
		expect(comp).toBeTruthy();
	});

	it('hasError defaults to: false', () => {
		expect(comp.hasError).toEqual(false);
	});

});
