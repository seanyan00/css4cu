/* ****************************************************************************************************
* PROGRAM DESCRIPTION  - Premium Summary (CTR) 
* NOTES: 
* This component is tied to the Premium Summary menu step, specifically for CTR. 
*
****************************************************************************************************/
import { Component, EventEmitter, Input, Output, ViewChild, ViewEncapsulation, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { MIGOverlayPanel } from '@overridden/primeng-overlaypanel/overlay';
import { OverlayPanel } from 'primeng/overlaypanel';
import { Subscription } from 'rxjs';
import { timer } from 'rxjs';
import { MIGSystemService } from '@services/mig.service';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { IQuote } from '@interfaces/IQuote';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { InputMasksClass } from '@helpers/masks';
import { RatingService } from '@root/services/rating.service';
import { finalize } from "rxjs/operators";
import { DocumentService } from '@root/services/document.service';
import { CoverageToConsider, RATINGRETURN } from '@classes/Common/RATINGRETURN';
import { ContractorsTooltips } from '@helpers/tooltips';
import * as moment from 'moment';
import {Functions} from '@helpers/functions';
import { MenuClass } from '@root/system/menu/menu';
import {} from 'primeng/primeng';
import { ReportItemService } from '@root/shared_components/report_item/report_item.service';
import * as _ from 'lodash';
import { DiscretionaryClass } from '@shared/Discretionary_WorkSheet/discretionary-class';

@Component({
	selector: 'mig-premium-summary',
	templateUrl: './premium_summary.component.html',
	styleUrls: ['premium_summary.component.css'],
    encapsulation: ViewEncapsulation.None
})

export class MIGQuoteReportComponent implements OnDestroy{
    ngOnDestroy(): void {
        if(this.subscription) this.subscription.unsubscribe();
        if(this.timerSubscription) this.timerSubscription.unsubscribe();
        this.changeDetectionRef.detach();
    }
    
	@Input() formData: any;
    @Input() ctrQuote: CTRQuote;
    
	@Output() GoBackToSectionEmitter = new EventEmitter<any>();
	@Output() GoBackToAddressEmitter = new EventEmitter<any>();
	@ViewChild(OverlayPanel, { static: false }) ProposalPanel: OverlayPanel;
	@ViewChild(OverlayPanel, { static: false }) PrintPanel: OverlayPanel;

	@ViewChild(OverlayPanel, { static: false }) WorksheetPanel: OverlayPanel;
	@ViewChild(OverlayPanel, { static: false }) preferred: OverlayPanel;
	@ViewChild("summaryPricing", { static: false }) summaryPricing: MIGOverlayPanel;
    
    subscription: Subscription;
    timerSubscription: Subscription;

    quote_valid: Date;
	premium: any = 0;
    discretionaryRatingResult: RATINGRETURN;

	tmp_pricing: number;
	og_premium: number = this.premium;
	tmp_discretionary_pricing: number;

	company: string = "Merchants Preferred Insurance Company";
	collapsed: boolean = true;
	preferred_pricing: boolean = false;
	calculating: boolean = false;
	showCoverage1: boolean = false;
	showCoverage2: boolean = false;
	showCoverage3: boolean = false;
	showCoverage4: boolean = false;
	showCoverage5: boolean = false;
    showDiscretionaryPricing: boolean = false;
    discPricingApplied: boolean = false;
    showBillingCalculator: boolean = false;
    reRateToApplyDiscPricing: boolean = false;

	coverage1: any;
	coverage2: any;
	coverage3: any;
	coverage4: any;
	coverage5: any;
	discretionary_pricing: boolean;
	effective_date: "20181117";
    // decimalMask = [/[0-1]/, '?', /\./, /[0-9]/, /[0-9]/];
    
    ratingServiceSubscription: any;
    
    loaded: boolean = undefined;
    invalid: boolean = false;
    showUpdatePremiumBtn: boolean = false;
    TimeToComplete: string = "";
	block_message: any[] = [{ success: false, text: "Calculating Premium...", visible: true },
                        	{ success: false, icon: "fa-info-circle",text: "Quote Information", visible: true },
                        	{ success: false, icon: "fa-thermometer-half",text: "Liability Limits",visible: true },
                        	{ success: false, icon: "fa-globe-americas",text: "Location Summary",visible: true },
                        	{ success: false, icon: "fa-shield-alt",text: "Additional Coverages",visible: true },
                        	{ success: false, icon: "fa-list-alt",text: "Preparing Premium Summary",visible: true },
                        	{ success: false, icon: "fa-check",text: "Retrieving available Additional Coverages",visible: true }];
    
	coveragesToConsider: CoverageToConsider[] = [];
	coveragesToConsiderExists: boolean;

    hasCG2033: boolean;
    CG2033endorsementPremium: number = 0;
    ratingError: boolean = false;
    ratingErrorMessage: string = "";
    LocationSummaryIndex: number = 4;
    hasSubcontractedWorkClass: boolean = true;
    showDiscretionaryWorksheet:boolean = false;
    before: string = "";


	constructor(
        public func: Functions,
		public migsystemservice: MIGSystemService,
		public migRoles: MIGSecurityRoles,
        public masks: InputMasksClass,
        public changeDetectionRef: ChangeDetectorRef,
        public contractorsTooltips: ContractorsTooltips,
        public ratingService: RatingService,
        public documentService: DocumentService,
        private menuClass: MenuClass,        
        private discClass: DiscretionaryClass
	) { 

    }

    ngOnInit(): void {
        this.calculating = true;

        //this sets the quote valid until date to 30 days from the effetive date
        this.quote_valid = this.ctrQuote.QUOTEPOLICYINFORMATION.NEWEFFECTIVEDATE === 0 ?  
        moment(this.func.DTEWinsToPrimeNG(this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE)).add(30, 'd').toDate() : 
        moment(this.func.DTEWinsToPrimeNG(this.ctrQuote.QUOTEPOLICYINFORMATION.NEWEFFECTIVEDATE)).add(30, 'd').toDate();
        
        if(this.ctrQuote.GLPENTITY.GLPLOCATIONS.some(s=>s.LOCNUM=="001" && s.TERR !='')){
            //We want to get the time before going into the service call
            var date = new Date();
            this.loaded = false;
            this.before = date.toLocaleTimeString();           
            this.funcGetPremium(this.ctrQuote);	
    	} else {
            this.invalid =  true; // 5/27/22: show error screen with button that navigates back to location screen. 
        } 
        
    }

	unmask(val) {
		return val.replace(/\D+/g, '');
	}


    //take them to the first location screen
    addPropCoverage(): void {
        this.menuClass.gotoStep(4);
	}
	addAddtlInsured(): void {
		this.menuClass.gotoStep(6);
	}

    //this checks to make sure we have coverages selected
    anyCoverageSelected() {
        //check to see if any of the checkboxes return true
        this.showUpdatePremiumBtn = this.coveragesToConsider.some(item => item.CONSIDER);
         //
         if(this.coveragesToConsider.some(item => item.CONSIDER && item.COVERG == 'CEO')){
            this.ctrQuote.AddAdditionalCoverage('CEO');
            this.menuClass.GotoMenuItemAndScroll("name", "AdditionalCoveragesLiability", 'DTBSTR');
            this.GoBackToSectionEmitter.emit(4);
         }
    }

	funcCalculateCoverage(): void {
		this.premium = this.og_premium;
		this.coveragesToConsider.forEach(coverage => {
           
            if (coverage.CONSIDER) {
                this.premium+=coverage.PREMIUM;
                this.ctrQuote.AddAdditionalCoverage(coverage.COVERG);
            }
            else {
                this.ctrQuote.RemoveAdditionalCoverage(coverage.COVERG);
            }
		})
        this.coveragesToConsiderExists = this.CoveragesToConsiderExists();        
        //call rating engine again on Update Premium click 
        if (this.calculating)
            return;     
        this.ngOnInit();
    }

    removePricingModifer(val: string, event): void {
        switch (val) {
            case "discretionary":
                this.discretionary_pricing = false;
                this.premium -= 25;
                this.summaryPricing.toggle(event);
                this.summaryPricing.toggle(event);
                break;
            case "c1":
                this.coverage1 = false;
                break;
            case "c2":
                this.coverage2 = false;
                break;
            case "c3":
                this.coverage3 = false;
                break;
            case "c4":
                this.coverage4 = false;
                break;

            case "c5":
                this.coverage5 = false;
                break;
        }
    }

    funcIsPricingModifed() {
        let out = false;
        if (this.discretionary_pricing) { out = true; }
        if (this.coverage1) { out = true; }
        if (this.coverage2) { out = true; }
        if (this.coverage3) { out = true; }
        if (this.coverage4) { out = true; }
        if (this.coverage5) { out = true; }
        return out;
    }


    funcGoBackToSection(section) {
        this.GoBackToSectionEmitter.emit(section);
    }

    funcGoToAddress(address) {
        this.GoBackToAddressEmitter.emit(address);
        this.GoBackToSectionEmitter.emit(3);
    }

    funcExpandAll() {
        this.collapsed = false;
    }

    funcCollapseAll() {
        this.collapsed = true;
    }

    funcRemovePreferredPricing() {

        let tick = timer(1000, 1000);
        this.calculating = true;
        this.subscription = tick.subscribe(t => {
            if (t) {
                this.preferred_pricing = false;
                this.company = "Merchants Mutual Insurance Company";
                this.premium = this.tmp_pricing;
                this.subscription.unsubscribe();
                this.calculating = false;
            }
        });
    }

    funcCalculatePreferredPricing() {

        let tick = timer(1000, 1000);
        this.calculating = true;
        this.subscription = tick.subscribe(t => {
            if (t) {
                this.preferred_pricing = true;
                this.tmp_pricing = this.formData.premium;
                this.premium -= 100;
                this.company = "Merchants Preferred Insurance Company";
                this.subscription.unsubscribe();
                this.calculating = false;
            }
        });

    }

    navigateToLocation($event){ // navigates to our first location in the event that the user gets to the premium summary w/o going to the location summary screen first
        this.menuClass.GotoMenuItem('locationId', '001');
    }

	funcGetPremium(quote: CTRQuote): any {
        
        if (this.migRoles.editable || this.reRateToApplyDiscPricing) {
        //Reset Premium;
        this.ctrQuote.POLICYTRANS.APRP = 0;
        //GET PREMIUM RATING SERVICE CALL
        this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Contractors', detail: "Initiating Premium Summary...", event: "start" });
		return this.ratingServiceSubscription = this.ratingService.GetRating(quote)
            .pipe(finalize(() => {
                //need to notify the quote here in case EFFDTE changed
                this.migsystemservice.notifyQuoteChanged(this.ctrQuote);
                this.calculating = false;
                this.showDiscretionaryWorksheet = false;
                /** COMMENTED OUT for testing */
                /**check for discretionary worksheet menu option */
                this.showDiscretionaryWorksheetMenu(quote);
                this.changeDetectionRef.detectChanges();
                
            }))
			.subscribe(ratingResponse => {
                //console.log('Rating return? ', rating);
                if(ratingResponse.RATING == undefined)
                {
                    //this.ratingError = true;
                    // this.ratingErrorMessage = ratingResponse.RATING.RATINGRETURN.RETURNMESSAGE;
                    // this.premium = ratingResponse.RATING.RATINGRETURN.RETURNPREMIUM;
                    //this.migsystemservice.notifyPremium(0);
                    //this.preferredPricingEligibilityFlag = ratingResponse.RATING.RATINGRETURN.PREFERREDPRICINGELIGIBLE; // commenting this out because per Sara the system should no longer determine eligibility, the eligibility is now determined by the Underwriter's referral -JTL
                    this.funcWait();
                    this.migsystemservice.notifySystemNotification({ severity: 'error', summary: 'Contractors', detail: "Failed to initiate Premium Summary", event: "end" });
                    this.ctrQuote.HTTPREQUESTRESPONSE.HTTPREQUEST = this.before;
                    var date = new Date();
                    this.ctrQuote.HTTPREQUESTRESPONSE.HTTPRESPONSE = date.toLocaleTimeString();
                    this.changeDetectionRef.detectChanges();
                    return;
                }
                if (ratingResponse.RATING.RATINGRETURN.RETURNCODE == "ERROR")
                {  
                    /* need to assign the saved quote back to screen in case of effdte change happens during save quote */
                    //this.ctrQuote = new CTRQuote(<CTRQuote>ratingResponse.QUOTE);                  
                    
                    this.ratingError = true;
                    this.ratingErrorMessage = ratingResponse.RATING.RATINGRETURN.RETURNMESSAGE;
                    this.premium = ratingResponse.RATING.RATINGRETURN.RETURNPREMIUM;
                    this.migsystemservice.notifyPremium(0);
                    this.funcWait();
                    this.migsystemservice.notifySystemNotification({ severity: 'error', summary: 'Contractors', detail: "Failed to initiate Premium Summary", event: "end" });
                    this.changeDetectionRef.detectChanges();
                    this.ctrQuote.HTTPREQUESTRESPONSE.HTTPREQUEST = this.before;
                    var date = new Date(); // Create new date object to get timestamp 
                    this.ctrQuote.HTTPREQUESTRESPONSE.HTTPRESPONSE = date.toLocaleTimeString();
                    return;
                }
                /* need to assign the saved quote back to screen in case of effdte change happens during save quote */
                this.ctrQuote = new CTRQuote(<CTRQuote>ratingResponse.QUOTE);
                //discretionaryRatingResult - added for NJ and PA dereg since Haoling is now sending flags for unmodified premium
                this.discretionaryRatingResult = ratingResponse.RATING.RATINGRETURN;
                this.premium = ratingResponse.RATING.RATINGRETURN.RETURNPREMIUM;
                this.ctrQuote.POLICYTRANS.APRP = ratingResponse.RATING.RATINGRETURN.RETURNPREMIUM;
				this.coveragesToConsider = ratingResponse.RATING.RATINGRETURN.COVERAGESTOCONSIDER;
				this.filterVermontCoverage();
				this.coveragesToConsiderExists = this.CoveragesToConsiderExists();
                this.funcWait();
                this.migsystemservice.notifySystemNotification({ severity: 'success', summary: 'Contractors', detail: 'Ready to process Premium Summary!', event: "end" });
                this.og_premium = this.premium;
                this.migsystemservice.notifyQuoteChanged(this.ctrQuote);
                this.hasSubcontractedWorkClass = this.ctrQuote.HasSubcontractedWorkClass();
				this.migsystemservice.notifyPremium(this.premium);

                this.determineAdditionalInsuredsLogic();

				this.menuClass.isQuoteDirty = false;
                //this.ctrQuote.HTTPREQUESTRESPONSE.HTTPRESPONSE = Math.floor(Date.now()/1000).toString(); // will bomb out until we set up our object on the backend. 
                //Store the timestamps once the request comes back
                this.ctrQuote.HTTPREQUESTRESPONSE.HTTPREQUEST = this.before;
                var date = new Date();
                this.ctrQuote.HTTPREQUESTRESPONSE.HTTPRESPONSE = date.toLocaleTimeString(); 
                this.changeDetectionRef.detectChanges();        
            });
           
        }
        else {
            this.premium = this.ctrQuote.POLICYTRANS.APRP;
            this.calculating = false;
			this.loaded = true;
			this.menuClass.isQuoteDirty = false;
        }
	}

    determineAdditionalInsuredsLogic() {
        var endorsementPremiumStatRec = _.find(this.ctrQuote.STATISTICS, stat => stat.INTCOV == "AX0");
        this.hasCG2033 = (this.ctrQuote.HasAdditionalInsureds() && this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.OSCNT > 0 && (endorsementPremiumStatRec != undefined));
        if (this.hasCG2033) {
                this.CG2033endorsementPremium = endorsementPremiumStatRec.PREMO;
        }
    }

    funcWait() {
		for (let i = 0; i < this.block_message.length; i++) {
			this.block_message[i].success = false;
        }
        
		let len = this.block_message.filter(x => x.visible == true).length;

		this.loaded = false;

		let steplength = 500;
		let ticktock = len;
		let tick = timer(0, steplength);

		this.timerSubscription = tick.subscribe(t => {
			if (t == (ticktock - 1 ? ticktock - 1 : 1)) {
				this.loaded = true;
				this.timerSubscription.unsubscribe();
				this.changeDetectionRef.detectChanges();

			} else {
				if (this.block_message && this.block_message[t] && this.block_message[t].text && this.block_message[t].visible) {

					this.block_message[t].success = true;
					this.changeDetectionRef.detectChanges();
				}
			}
		});
    }

    
    openDiscretionaryPricing() {
        this.showDiscretionaryPricing = true;
    }

    cancelDiscPricing() {
        this.showDiscretionaryPricing = false;
    }

    clearForm(event){
        if(this.ctrQuote.GLPENTITY.GLPSTATEINFO.length){ this.ctrQuote.GLPENTITY.GLPSTATEINFO.find(x=>x.PRMSTE == this.ctrQuote.POLICYTRANS.CANSTE).IRPMOD = 0;}
        if(this.ctrQuote.CFPENTITY.CFPSTATEINFO.length) { this.ctrQuote.CFPENTITY.CFPSTATEINFO.find(x=>x.PRMSTE == this.ctrQuote.POLICYTRANS.CANSTE).IRPMOD = 0;}        
    }

    applyDiscPricing(quote: IQuote) {
        if (this.calculating)
            return;

        this.reRateToApplyDiscPricing = true;
        var newQuote = Object.assign(new CTRQuote(), quote);
        this.ctrQuote = newQuote;        
        this.cancelDiscPricing();
        this.block_message.forEach(msg => {
            msg.success = false;
        });
        this.ngOnInit();
    }
	filterVermontCoverage() {
		if (this.ctrQuote.POLICYTRANS.CANSTE == "44") {
			this.coveragesToConsider=this.coveragesToConsider.filter(f => f.COVERG != "CEO" && f.COVERG != "CYB");
		}
	}
    showAdditionalCoverageDescription(COVERG: string) {
        this.coveragesToConsider.forEach(cov => {
            cov.TOOLTIPDISPLAY = (cov.COVERG == COVERG);
		})
		this.coveragesToConsiderExists = this.CoveragesToConsiderExists();
	}

	private CoveragesToConsiderExists() {
        return (
                    (this.coveragesToConsider != null && this.coveragesToConsider.length > 0)
                    || 
                    (!(this.ctrQuote.HasPropertyCoverage()))
                    ||
                    (!(this.ctrQuote.HasAdditionalInsureds()))
                );
    }
    
    openBillingCalculator() {
        this.showBillingCalculator = true;
    }

    cancelBillingCalculator() {
        this.showBillingCalculator = false;
    }

    private showDiscretionaryWorksheetMenu(quote:CTRQuote) : void{
        if(this.discClass.ShowDiscretioanryMenuItem(quote)){
           this.showDiscretionaryWorksheet = true;
           this.menuClass.ShowHideMenuItemAt(true,'DiscretionaryWorksheet');
        }
        else{
            this.menuClass.ShowHideMenuItemAt(false,'DiscretionaryWorksheet');
        }
    }
}
