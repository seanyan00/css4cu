import { Component, EventEmitter, Output } from '@angular/core';
import { ContractorsTooltips } from '@helpers/tooltips';

@Component({
    selector: 'mig-include-inland',
    templateUrl: './include.inland.component.html',
    styleUrls: ['../coverage.inland.component.css']
})
export class MIGIncludeInland {
    constructor(public contractorsTooltips: ContractorsTooltips){}
    @Output() funcClose = new EventEmitter<any>();

    funcCloseBtn() {
        this.funcClose.emit();
    }
}
