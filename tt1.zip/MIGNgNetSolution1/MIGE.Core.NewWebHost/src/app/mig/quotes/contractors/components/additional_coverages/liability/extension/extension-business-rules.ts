import { AbstractControl, FormControl, Validators, UntypedFormGroup, Validator, ValidatorFn, ValidationErrors } from "@angular/forms";

import { Validation } from '@classes/Common/ValidatorClass/Validation';
import { CFPLOCATION } from '@classes/CTR/CFPLOCATION';
import { Functions } from '@helpers/functions';
import { AppErrors } from '@root/shared_components/errors/app-errors';
import { Injectable } from '@angular/core';

@Injectable()
export class ExtensionBusinessRules extends Validation {
	constructor(private func: Functions) {
		super();
	}

	LocationInfoPropDedeductible = (cfpLocation: CFPLOCATION, func: Functions) =>  {
		return (ac: AbstractControl): AppErrors | null => {
			// Location > Property Deductible
			// Required. Choose from list of Options.
			// Cannot be higher than the sum of Building and Business Personal Property Limits on the location building that is being added.
			if (cfpLocation.BLDGDD) {
				let BLBPPLTot: number = func.justNumbers(cfpLocation.BLDLM1) + func.justNumbers(cfpLocation.BPPLM1);
				if (Number(cfpLocation.BLDGDD) > BLBPPLTot) {
					return { severity: "error", 
					summary: "BLDGDD",
					detail: "Location Information Property Deductible cannot be greater than the sum of Building Limits and Building Personal Property Limits", 
					sticky: true, 
					closable: false };
				}
			}	
			return null;
		}
	}

	AtLeastOneAdditionalInsured = (fg: UntypedFormGroup) => {
		return (): AppErrors | null => {
			if (fg.get("LSCNT").value > 0 || fg.get("checkboxCNCNT").value > 0 || fg.get("checkboxCICNT").value > 0 || fg.get("checkboxOBCNT").value > 0 || 
			fg.get("checkboxMLCNT").value > 0 || fg.get("checkboxSPCNT").value > 0 || fg.get("checkboxSTCNT").value > 0 || fg.get("checkboxVECNT").value > 0 || 
			fg.get("checkboxMTCNT").value > 0 || fg.get("checkboxOWCNT").value > 0 || fg.get("EACNT").value > 0 || fg.get("checkboxPOCNT").value > 0 || 
			fg.get("checkboxCOCNT").value > 0 || fg.get("checkboxGFCNT").value > 0 || fg.get("checkboxLECNT").value > 0 || fg.get("checkboxENCNT").value > 0 || 
			fg.get("checkboxGSCNT").value > 0 || fg.get("checkboxCPCNT").value > 0 || fg.get("checkboxOSCNT").value > 0 || fg.get("GLCNT").value > 0 || 
			fg.get("OSCNT").value > 0 || fg.get("CACNT").value > 0 || fg.get("IBCNT").value > 0) {

			} else {
				return {
					severity: 'error',
					summary: 'checkboxAdditionalInsureds',
					detail: `At least one additional insured is required when 'Additional Insureds' is checked.`,
					sticky: true,
					closable: false
				};
			}
				return null;
			}
		}
	
		//Business Rule Validation
		CyberLiabilityAnnualRevenue = (fg: UntypedFormGroup, maxValue: number) => {
			return (ac: AbstractControl): AppErrors | null => {
				if(fg.get('CYBSAL') && fg.get('checkboxCYBAGG')) {					
					if(this.func.justNumbers(fg.get('CYBSAL').value) > maxValue 
						&& fg.get('checkboxCYBAGG').value
						&& fg.get('CYBAGG').value > 100000){
						return { severity: 'error', 
							summary: 'CYBSAL', 
						detail: `Annual Revenue exceeds Cyber Liability eligibility of $${maxValue.toLocaleString()}.`,
						sticky: true, 
						closable:false};
					}
					if (this.func.justNumbers(fg.get('CYBSAL').value) == 0 && fg.get('checkboxCYBAGG').value) {
						return { 
							severity: 'error',
							summary: 'CYBSAL',
							detail: `Annual Revenues for Cyber Liability must be greater than $0.`,
							sticky: true,
							closable: false
						};
					}
					return null;
				}
			}
		}

		//check to make sure Number of Designated Construction Projects is required when both MU 9217 and CG 2503 are selected
		ConstructionProjectsGenAggLim = (fg: UntypedFormGroup) => {
			return(ac: AbstractControl): AppErrors | null => {
				if(!fg.get('checkboxDCPBLKmu').value && !fg.get('checkboxDCPBLKcg').value) {
					return {
						severity: 'error', 
						summary: 'checkboxDCPBLK', 
						detail: 'MU 9217 and/or CG 2503 MUST be selected when Construction Project(s) Aggregate Limit is selected.',
						sticky: true,
						closable: false
					};
				}
				return null;
			}
		}

		//check to make sure "number of Additional Insureds" is not 0
}
