/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule, UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { PipesModule } from '@pipes/pipes.module';
import { FieldsetModule } from 'primeng/fieldset';
import { InputTextModule } from 'primeng/inputtext';
import { PanelModule } from 'primeng/panel';
import { TabViewModule } from 'primeng/tabview';
import { TooltipModule } from 'primeng/tooltip';

import { MIGCalendarModule} from '@overridden/primeng-calendar/calendar.module';
import { MIGCheckboxModule} from '@overridden/primeng-checkbox/checkbox.module';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { MIGMessageModule } from '@overridden/primeng-message/message.module';
import { MIGCoverageInlandExtension } from './extension/extension.component';
import { MIGCoverageInlandOptional } from './optional/optional.component';
import { MIGIncludeInland } from './whats_included/include.inland.component';
import { MIGInputSwitchModule } from '@overridden/primeng-inputswitch/switch.module';
import { TextMaskModule } from 'angular2-text-mask';
import { MIGAdditionalCoveragesInland } from './coverage.inland.component';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { MenuClass } from '@root/system/menu/menu';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';

@NgModule({
	imports: [
		MIGButtonModule,
		MIGCalendarModule,
		FieldsetModule,
		MIGCheckboxModule,
		FormsModule,
		TabViewModule,
		CommonModule,
		FieldsetModule,
		PanelModule,
		MIGDropDownModule,
		InputTextModule,
		MIGInputSwitchModule,
		TextMaskModule,
		MIGCheckboxModule,
		TooltipModule,
		ReactiveFormsModule,
		PipesModule,
		MIGMessageModule,
		MIGInputtextModule
	],
	declarations: [
		MIGIncludeInland,
		MIGCoverageInlandExtension,
		MIGCoverageInlandOptional,
		MIGAdditionalCoveragesInland
	],
	exports: [MIGAdditionalCoveragesInland]
})
export class AdditionalCoveragesInlandModule {
	formGroup: UntypedFormGroup;
	formGroupOptional: UntypedFormGroup;
	constructor(
		public menuClass: MenuClass,
		private formBuilder: UntypedFormBuilder,
	) {
		this.formGroup = this.formBuilder.group({});
		this.formGroupOptional = this.formBuilder.group({});
		menuClass.addMenuItem({
			name: 'AdditionalCoveragesInland',
			label: 'Inland Marine',
			color: "ui-steps-number-default",
			navSkip: false,
			active: false,
			hasError: false,
			errors: [],
			buttons: [{ button: "Next" }, { button: "Back" }, { button: "Save" }, { button: "GetQuoteNow" }],
			forms: [this.formGroupOptional, this.formGroup],
			icon: "fa fa-snowplow",
			level: 2,
			block: [],
			visible: true,
			quote: "premium"
		});
	}
}
