import { Injectable } from "@angular/core";
import { CTRQuote } from "@classViewModels/CTR/CTRQuote";

@Injectable()
export class MIGPropertyResources {
	ctrQuote: CTRQuote;

	setCTRQuote(quote) {
		this.ctrQuote = quote;
	}

	processEarthquake(): boolean {
		if (this.ctrQuote.CFPENTITY 
			&& this.ctrQuote.CFPENTITY.CFPLOCATIONS 
			&& this.ctrQuote.CFPENTITY.CFPLOCATIONS.length) {
			
			return true;
		}
		return false;
	}

	//Checks if BINTIM value is eligable to save to DWFP120 
	processBINTIM(currentBINTIMvalue): string {
		let calcBINTIMvalue: string;
		if (currentBINTIMvalue == "72") {
			calcBINTIMvalue = "";
		}
		else {
			calcBINTIMvalue = currentBINTIMvalue;
		}
		return calcBINTIMvalue;
	}
}