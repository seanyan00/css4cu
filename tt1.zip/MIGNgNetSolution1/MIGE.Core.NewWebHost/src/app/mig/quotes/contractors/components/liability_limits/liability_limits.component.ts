/* ****************************************************************************************************
          * PROGRAM DESCRIPTION  		- Liability Limits
          * DATE CREATED         		- 1-14-2019
          * AUTHOR               		- Mario Giambanco
          * Curent Data Dictionary VER: - 221
          * NOTES
		  *
		  * Mario Giambanco 1-14-2019
		  * updated component according to data dictionary version 221
		  * added business rules
          ****************************************************************************************************/


import { Component, Input, OnInit, OnDestroy, AfterViewChecked, ChangeDetectorRef } from '@angular/core';
import { ContractorsDropDowns } from '@helpers/dropdowns';
import { UntypedFormBuilder, UntypedFormGroup, UntypedFormControl } from '@angular/forms';
import { MIGValidatorLiability } from '@CTRcomponents/liability_limits/liability_limits.validators';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { Functions } from '@helpers/functions';
import { Subscription } from 'rxjs/internal/Subscription';
import { distinctUntilChanged } from 'rxjs/operators';
import { MIGSystemService } from '@services/mig.service';
import { MenuClass } from '@root/system/menu/menu';
import { MIGSecurityRoles } from '@classes/Common/roles/roles.class';
import { ContractorsTooltips } from '@helpers/tooltips';


@Component({
	selector: 'mig-liability-limits',
	templateUrl: './liability_limits.component.html'
})

export class MIGLiabilityLimits implements OnInit, OnDestroy, AfterViewChecked {

	formBuilder: UntypedFormBuilder;
	formChanged: boolean = false;
	formGroup: UntypedFormGroup;
	vis: boolean = false;
	@Input() public ctrQuote: CTRQuote;
	@Input() public hasError: boolean = false;
	@Input() menuSteps: any[] = [];
	@Input() step: number = 1;
	migLiabilityValidator: MIGValidatorLiability;
	FormGroupSubscription: Subscription;
	EOLMTSubscription: Subscription;
	PAEXCSubscription: Subscription;
	updateRecordState: Subscription;
	nextButtonClickedSub: Subscription;
	businessRules: true;
	errors: any[] = [];
	stepName = "LiabilityLimits";
	lob: string = "";

	constructor(
		public contractorsDropDowns: ContractorsDropDowns,
		public func: Functions,
		public migsystemservice: MIGSystemService,
		public menuClass: MenuClass,
		public migRoles: MIGSecurityRoles,
		public contractorsTooltips: ContractorsTooltips,
        private changeDetectorRef: ChangeDetectorRef
	) {
		
		if (this.formBuilder == null) {
			this.formBuilder = new UntypedFormBuilder();
		}
		this.migLiabilityValidator = new MIGValidatorLiability(this.func);
	}

	//Contractors
	get EOLMTFORMAT() { return this.formGroup.get("EOLMTFORMAT"); }
	get MEDLMT() { return this.formGroup.get("MEDLMT"); }
	get FDLMT() { return this.formGroup.get("FDLMT"); }
	get PCOLMTFORMAT() { return this.formGroup.get("PCOLMTFORMAT"); }
	get PAILMTFORMAT() { return this.formGroup.get("PAILMTFORMAT"); }
	get PAEXC() { return this.formGroup.get("PAEXC"); }


	ngOnDestroy() {		
		if (this.FormGroupSubscription) { this.FormGroupSubscription.unsubscribe(); }
		if (this.EOLMTSubscription) { this.EOLMTSubscription.unsubscribe(); }
		if (this.PAEXCSubscription) { this.PAEXCSubscription.unsubscribe(); }
		if(this.updateRecordState) this.updateRecordState.unsubscribe();
		if(this.nextButtonClickedSub) this.nextButtonClickedSub.unsubscribe();
	}

	ngAfterViewInit(): void{
		if(!this.migRoles.editable) {
			this.formGroup.disable();
		}
	}

	ngAfterViewChecked() {
		//let's the app footer component know that there are BRR rules for this form.
		//this.migsystemservice.notifyBRRRules(true);
	}
	ngOnInit() {
		
		document.getElementById('liabilityLimitsForm').scrollTop;
		
		//let processBR = new LiabilityLimitsBR();

		// get our form group for error checking
		this.formGroup = this.menuClass.menuObject(this.stepName).form; 

		//bdk - to set paexc checkbox on load
		let PAEXC: boolean = (this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.PAEXC == 'Y') ? true : false;
		
		
		// General Liability - Each Occurrence / General Aggregate
		this.formGroup.addControl('EOLMTFORMAT', new UntypedFormControl(this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EOLMT ? this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EOLMTFORMAT : 
			this.contractorsDropDowns.defaultEOLMT, [this.migLiabilityValidator.ValidateRequired('EOLMTFORMAT',"General Liability - Occurrence/Aggregate")]));

		// Products-Completed Operations Aggregate Limit
		this.formGroup.addControl('PCOLMTFORMAT', new UntypedFormControl({ value: this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.PCOLMT ? this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.PCOLMTFORMAT : 
			this.contractorsDropDowns.defaultEOLMT.split("/")[1], disabled: true }));

		// Personal & Advertising Injury Liability Limit
		this.formGroup.addControl('PAILMTFORMAT', new UntypedFormControl({ value: this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.PAILMT ? this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.PAILMTFORMAT : 
			this.contractorsDropDowns.defaultEOLMT.split("/")[0], disabled: true }));

		// Medical Payments
		this.formGroup.addControl('MEDLMT', new UntypedFormControl(this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.MEDLMT ? this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.MEDLMT : 
			this.contractorsDropDowns.defaultMEDLMT, this.migLiabilityValidator.ValidateRequired('MEDLMT',"Medical Expense")));
		
		this.formGroup.addControl('FDLMT', new UntypedFormControl(this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.FDLMT, [this.migLiabilityValidator.ValidateDamageToPremises(this.formGroup)]));
		
		this.formGroup.addControl('PAEXC', new UntypedFormControl(PAEXC));

		this.FormGroupSubscription = this.formGroup.valueChanges.pipe(distinctUntilChanged()).subscribe(data => {
			this.setValues();
			//this.applyEOLMTPAEXCRules(data);<--removed; put in setValues()
			
			let eol = data.EOLMTFORMAT.split("/");
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EOLMT = this.func.justNumbers(eol[0]);
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.GALMT = this.func.justNumbers(eol[1]);
				
			if (data.FDLMT === 0) {
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.FDLMT = 0;
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.FDEXC = "Y";
			} else {
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.FDLMT = this.func.justNumbers(data.FDLMT);
				this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.FDEXC = "N";
			}
			
			//need to retrigger validation because there are 2 fields to look at in regards to seeing if the Damage To Premises Rented field passes validation
			//unless we re-trigger validation if the General Liability Field is changed to make sure it is matching the Damage to Premises rented, it will only
			//run validation on the item changed and will leave the validation error on the other. This makes sure the errors are properly re-ran.
			this.migLiabilityValidator.TriggerValidation(this.formGroup);

			//allows for form auto error updating on the panels
			this.menuClass.CalculateErrors(this.menuClass.stepActiveObject, this.menuClass.stepActive);

		});

		this.updateRecordState = this.migsystemservice.subscribeUpdateRecordState().subscribe(() => {
			
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.POLICY = this.ctrQuote.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EFFDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.TRANS = this.ctrQuote.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.RCDTYP = this.ctrQuote.QUOTEPOLICYINFORMATION.RECORDTYPE;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EDSDTE = this.ctrQuote.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.RECORDSTATE = "U";

		});

		this.setValues();
	}

	setValues() {
		
		// moving the set ctrquote values code from the form group subscription
		// to here because, you may not touch this form
		// (default values provided may be acceptable)
		// and therefor never trigger the form update
		let data = this.formGroup.getRawValue();
		let eol = data.EOLMTFORMAT.split("/");
		
		this.PCOLMTFORMAT.setValue(eol[1], {emitEvent: false});
		this.PAILMTFORMAT.setValue(eol[0], {emitEvent: false});
		//this.quoteDetails.QUOTEPOLICYLIABLIMITS.EOLMT = data.EOLMT as number;
		this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EOLMT = this.func.justNumbers(eol[0]);
		this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.GALMT = this.func.justNumbers(eol[1]);
		this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EOLMTFORMAT = data.EOLMTFORMAT ? data.EOLMTFORMAT : "";		

		this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.MEDLMT = data.MEDLMT ? data.MEDLMT : 0;
		this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.FDLMT = data.FDLMT;

		this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.PCOLMTFORMAT = eol[1];
		this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.PAILMTFORMAT = eol[0];
		//needed for rating
		this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.COVERG = 'CGL';
			
		//need to process Hired and Non Owned Auto Liability if this changes and they have not clicked dane yet
		if(this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.HIREOC != 0){
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.HIREOC = (this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EOLMT == 2000000 ? 1000000 : this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EOLMT);
			this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.HIRAGG = (this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.GALMT == 4000000 ? 2000000 : this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.GALMT);
		}

        this.formChanged = true;
        this.changeDetectorRef.detectChanges();
		
	}
	
}
