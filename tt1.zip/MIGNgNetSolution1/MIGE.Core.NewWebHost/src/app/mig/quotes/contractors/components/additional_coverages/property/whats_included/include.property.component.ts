//import { Component, EventEmitter, Output } from '@angular/core';
//import { ContractorsTooltips } from '@helpers/tooltips';

//@Component({
//    selector: 'mig-include-property',
//    templateUrl: './include.property.component.html',
//    styleUrls: ['../coverage.property.component.css']
//})
//export class MIGIncludeProperty {
//    @Output() funcClose = new EventEmitter<any>();
//    constructor(public contractorsTooltips: ContractorsTooltips){}
//    funcCloseBtn() {
//        this.funcClose.emit();
//    }
//}
