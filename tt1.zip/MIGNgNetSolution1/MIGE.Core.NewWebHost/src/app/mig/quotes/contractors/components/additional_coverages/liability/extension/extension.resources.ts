import { Injectable } from "@angular/core";
import { CTRQuote } from "@classViewModels/CTR/CTRQuote";
import * as _ from 'lodash';
import { GLPLIABILITIES } from '@classes/CTR/GLPLIABILITIES';

@Injectable()
export class MIGLiabilityResources {
	ctrQuote: CTRQuote;
	controllingState: string = "";

	setCTRQuote(quote) {
		this.ctrQuote = quote;
		if (this.ctrQuote.GLPENTITY && this.ctrQuote.GLPENTITY.GLPLOCATIONS && this.ctrQuote.GLPENTITY.GLPLOCATIONS.length) {
			this.ctrQuote.GLPENTITY.GLPLOCATIONS.forEach(element => {
				if (element.RECORDSTATE == "D") { return; }
				if (element.LOCNUM == "001") {
					// this.controllingState = element.ADDRESS.STATEFORMAT;
					//this.controllingState = element.PRMSTE;
					this.controllingState = element.ADDRESS.STATE;
				}
			});
		}
	}

	processSplitList(data): any {				
		let arr: any[] = [];
		if (data == undefined || data == null || data == '') {					
			return arr;
		}
		else {
			let tmp: string = data.toString();			
			arr = tmp.split("/");			
			return arr;
		}
	}

	// no longer needed 2-19-2019 MG
	// processEmploymentPractices(): boolean {
	// 	// Not available in New Jersey or Ohio
	// 	if ((this.controllingState == "NJ") || (this.controllingState == "OH")) { return false; }
	// 	return true;
	// }
	processEPL(dropdown: any[]): number {
		let dd = dropdown;
		
		for (let a = 0; a < dd.length; a++) {
			if (dd[a].states.indexOf(this.controllingState) >= 0) 
			{ 
				return dd[a].value; 
			}
		}
	}

	processEPILIM(dropdown: any[]): any[] {
		// EPILIM dropdowns are state specific. Process them here.		
		let retArray = [];
		
		if (this.vermontCheck()) {
			return dropdown.filter(x=>x.states == "44")
		}
		else {
			return dropdown.filter(x=>x.states != "44")
		}	
	}	

	processOhioStopGap(): boolean {
		// Only available when controlling state is Ohio			
		if (this.controllingState == "34") { return true; }
		return false;
	}

	processElevatorEscalator(): boolean {
		// Only available in PA
		if (this.controllingState == "37") { return true; }
		return false;
	}

	vermontCheck(): boolean {
		// Only available in VT
		if (this.controllingState == "44") { return true; }
		return false;
	}

	processContractorsEOClasses(contractorsEOClasses): boolean {
		if (this.ctrQuote.GLPENTITY && this.ctrQuote.GLPENTITY.GLCLASSLIST && this.ctrQuote.GLPENTITY.GLCLASSLIST.length) {
			//TODO DO NOT HARD CODE THIS!! per RF
			if (this.vermontCheck()) { return false; }
			if(this.ctrQuote.GLPENTITY.GLCLASSLIST.find(x=>x.CLASX == '091629' && x.RECORDSTATE != 'D')) {return false;}			
		}
		return true;
	}

	processContractorsEODeductible(contractorsEODropdown, val): any {
		for (let i = 0; i < contractorsEODropdown.length; i++) {			
			if (contractorsEODropdown[i].value == val) {
				return { value: contractorsEODropdown[i].dvalue, label: contractorsEODropdown[i].dlabel }
			};
		}
		return {};
	}

	//Checks if Cyber Liability Total Limit value is available for quote state
	processCyber(dropdown): any {
		let a = dropdown.length;		
		while(a--) {		
			let id = dropdown[a].states.indexOf(this.controllingState);		
			if (id == -1) { dropdown.splice(id, 1); }		
		}			
		return dropdown;
	}

	processSeptic(classes, states): boolean {
		// Only display for class codes 98805 or 98806
		// states contains a list of states Septic is NOT available in - so return false
		if (states.indexOf(this.controllingState) >= 0 || this.controllingState == "44") { return false; }

		// if our classes is in the list, return true
		if (this.ctrQuote.GLPENTITY && this.ctrQuote.GLPENTITY.GLCLASSLIST && this.ctrQuote.GLPENTITY.GLCLASSLIST.length) {
			let ClassList = this.ctrQuote.GLPENTITY.GLCLASSLIST;
			for (let i = 0; i < ClassList.length; i++) {
				if (ClassList[i].RECORDSTATE == "D") { return; }

				if (classes.indexOf(ClassList[i].CLASX) >= 0) {
					return true;
				}
			};
		}
		return false;
	}

	//Get the current STOTLM value based on the current STAGLM value
	processSTOTLM(currentSTAGLMvalue, allDropDownData): string {
		let currentSTOTLMvalue : string;
		allDropDownData.forEach(element => {			
			if (element.value == currentSTAGLMvalue) {
				currentSTOTLMvalue= element.STOTLMvalue;
			} 
		});
		return currentSTOTLMvalue;
	}

	//For EOLMT display value on EBL coverage
	processEOLMTvalue(): string {
		let currentLiabilityValue = this.ctrQuote.GLPENTITY.QUOTEPOLICYLIABLIMITS.EOLMT;
		let calculatedEOLMT: string;
		if (currentLiabilityValue == 300000) {
			calculatedEOLMT = "$300,000/$300,000";
		}
		else if (currentLiabilityValue == 500000) {
			calculatedEOLMT = "$500,000/$500,000";
		}
		else if (currentLiabilityValue >= 1000000) {
			calculatedEOLMT = "$1,000,000/$1,000,000";
		}
		return calculatedEOLMT;
	}

	//Formats EBPCLM for save
	processEBPCLM(currentEOLMTvalue): any {
		let arr: any[] = [];
		if (currentEOLMTvalue == undefined || currentEOLMTvalue == null || currentEOLMTvalue == '') {					
			return arr;
		}
		else {					
			arr = currentEOLMTvalue.split("/");				
			arr.forEach(function(element, index) {
				this[index] = element.replace(/[^a-zA-Z0-9]/g, '');
			  }, arr); 												
			return arr;
		}
    }
    //GlpLiabilities -> DWGP122
    ensureDefaultGlpLiabilityCoverage()
    {
        if (_.some(this.ctrQuote.GLPENTITY.GLPLIABILITIES, glpLiability => glpLiability.COVERG == 'EPL' && glpLiability.RECORDSTATE != 'D'))
            return;

		this.ctrQuote.GLPENTITY.GLPLIABILITIES.push(new GLPLIABILITIES(this.ctrQuote.QUOTEPOLICYINFORMATION, "EPL", this.ctrQuote.GLPENTITY.GLPLOCATIONS));
	
    }
}
