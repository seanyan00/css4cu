/* NG Includes */
import { Component, ViewEncapsulation, OnDestroy, OnInit } from '@angular/core';
// import { Globals } from '@globals';
import { MIGSystemService } from '@services/mig.service';
import { Subscription } from 'rxjs';
/* Prime Includes */
@Component({
    selector: 'mig-additional-coverages',
    templateUrl: './additional_coverages.component.html',
    styleUrls: ['additional_coverages.component.css'],
    encapsulation: ViewEncapsulation.None
})

export class MIGAdditionalCoverages implements OnInit, OnDestroy {
    ngOnDestroy(): void {
        if(this.goToACTabSubscription) this.goToACTabSubscription.unsubscribe();
    }
    dataInlandMarineDeductible: any[];
    dataInlandMarineReplacementCost: any[];
    visInland: boolean = false;
    visProperty: boolean = false;
    
	ACIndex: number = 0;
	LiabilityIndex: number = 0;
	InlandIndex: number = 0;
	PropertyIndex: number = 0;

    optionsValuation: any = ["RC", "ACV"];
    optionsCoinsurance: any = ["80%", "90%", "100%"];
    optionsDeductible: any = ["$250", "$500", "$1,000", "$2,500", "$5,000", "$10,000"];
    optionsDeductibleGlass: any = ["$250", "$500", "$1,000", "$2,500", "$5,000", "$10,000"];

    goToACTabSubscription: Subscription;
    
	constructor(
		// public globals: Globals,
		public migsystemservice: MIGSystemService
	) { }

    // funcShowPanel(panel) {

    //     switch (panel) {
    //         case "liability":
    //             this.visInland = false;
    //             this.visProperty = false;
    //             this.visLiability = !this.visLiability;

    //             break;

    //         case "inland":
    //             this.visLiability = false;
    //             this.visProperty = false;
    //             this.visInland = !this.visInland;
    //             break;
    //         case "property":
    //             this.visLiability = false;
    //             this.visInland = false;
    //             this.visProperty = !this.visProperty;
    //             break;
    //     }
    // }

    ACIndexChanged(event) {
        //console.log(event);
        // this.ScrollToTop();
        this.ACIndex = event.index;
    }

    LiabilityIndexChanged(event) {
        // this.ScrollToTop();
        this.LiabilityIndex = event.index;
    }

    InlandIndexChanged(event) {
        // this.ScrollToTop();
        this.InlandIndex = event.index;
    }

    PropertyIndexChanged(event) {
        // this.ScrollToTop();
        this.PropertyIndex = event.index;
    }

    funcAddJobClassificationRow() {
        // this.globals.formData.discretionary_payroll.push({ job_class: "", discretionary_expense: "" });
    }
    funcDateSelected(event) {
        if (event === undefined) { return false; }
        //console.log(event);
        var d = new Date();
        d = event;
        let mm = (d.getMonth() + 1).toString();
        let pad = "00";
        mm = pad.substring(mm.length) + mm
        let dd = (d.getDate()).toString();
        dd = pad.substring(dd.length) + dd
        let yy = d.getFullYear();

        let out = yy.toString() + mm.toString() + dd.toString();
        // this.globals.formData.effdte = out;
        // this.globals.formData.effective_date = event;
        //console.log(out);
    }

    ngOnInit() {
        //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
        //Add 'implements OnInit' to the class.
        this.dataInlandMarineDeductible = ["$250", "$500", "$1000", "$2500"];
        this.dataInlandMarineReplacementCost = ['Yes', 'No'];
        // console.log(this.globals.formData.cyber_liability_limit);

        // let dummy = this.globals.formData.addresses;
        // console.log(dummy);
        // if (dummy.length) {

        //     for (let i = 0; i < dummy.length; i++) {
        //         if (dummy[i].buildings.length) {
        //             for (let a = 0; a < dummy[i].buildings.length; a++) {
        //                 // if (dummy[i].buildings[a].propertyCoverageVisible) { this.globals.showP = true;}
        //             }
        //         }
        //     }
        // }
		// console.log("ShowP: " + this.globals.showP);
		// this.globals.formData.contractors_eo_retrodate = this.globals.formData.effective_date;
		// this.globals.formData.cyber_retrodate = this.globals.formData.effective_date;

		this.goToACTabSubscription = this.migsystemservice.subscribeGoToACTab().subscribe(tab => {
			this.ACIndex = tab;
		})
    }
}