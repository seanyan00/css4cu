import { Component, EventEmitter, Output } from '@angular/core';
import { ContractorsTooltips } from '@helpers/tooltips';
@Component({
    selector: 'mig-include-liability',
    templateUrl: './include.liability.component.html',
    styleUrls: ['../coverage.liability.component.css']
})
export class MIGIncludeLiability {
    constructor(public contractorsTooltips: ContractorsTooltips){}
    @Output() funcClose = new EventEmitter<any>();

    funcCloseBtn() {
        this.funcClose.emit();
    }
}
