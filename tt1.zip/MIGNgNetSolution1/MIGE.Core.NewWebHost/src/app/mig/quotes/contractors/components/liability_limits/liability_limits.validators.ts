import { AbstractControl,ValidatorFn, UntypedFormGroup} from "@angular/forms";
import { Functions } from '@helpers/functions';
import { Validation } from '@classes/Common/ValidatorClass/Validation';
import { Injectable } from '@angular/core';
@Injectable()
export class MIGValidatorLiability extends Validation {
    constructor(public func: Functions) {
        super();
    }
   
    ValidateDamageToPremises = (fg: UntypedFormGroup) => {
        return (ac: AbstractControl) => {
            if(fg.get('EOLMTFORMAT') && fg.get('FDLMT')) {
                const EOLMTFORMAT: string = fg.get('EOLMTFORMAT').value;
                const FDLMT: number = fg.get('FDLMT').value;
                const EOLMT : number = this.func.justNumbers(EOLMTFORMAT.split('/')[0]);
            
                //its an error if the FDLMT is greater than the EOLMT and not set to certain values
                if (FDLMT > EOLMT && (EOLMT !== 300000 || FDLMT !== 500000)) {
                    return{ severity: "error", 
                    detail: "Damage to Premises Rented To You cannot be higher than General Liability Each Occurence", 
                    summary: 'FDLMT', 
                    sticky: true, 
                    closable: false };
                }
            }
            return null
        }
        
    }
    

}
