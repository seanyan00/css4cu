import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MIGPropertyCoverage } from '@CTRcomponents/property-coverage/property-coverage.component';
import { FieldsetModule } from 'primeng/fieldset';
import { InputMaskModule } from 'primeng/inputmask';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ErrorModule } from '@shared/errors/errors.module';
import { PanelModule } from 'primeng/panel';
import { MIGInputSwitchModule } from '@overridden/primeng-inputswitch/switch.module';
import { TextMaskModule } from 'angular2-text-mask';
import { MIGMessageModule } from '@overridden/primeng-message/message.module';

import { MIGCalendarModule } from '@overridden/primeng-calendar/calendar.module';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { MIGMultiselectModule } from '@overridden/primeng-multiselect/multiselect.module';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';
import { TooltipModule} from 'primeng/tooltip';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import {ListboxModule} from 'primeng/listbox';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
@NgModule({
	imports: [
		MIGDropDownModule,
		MIGButtonModule,
		MIGCheckboxModule,
		MIGInputtextModule,
		MIGCalendarModule,
		MIGMultiselectModule,
		MIGMessageModule,
		MIGInputSwitchModule,
		FieldsetModule,
		ErrorModule,
		FormsModule,
		ReactiveFormsModule,
		CommonModule,
		FieldsetModule,
		InputMaskModule,
		PanelModule,
		TextMaskModule,
		MessagesModule,
		MessageModule,
		ToastModule,
		//MIGYearPickerModule,
		TooltipModule,
		ListboxModule,
		ConfirmDialogModule
	],
	providers:[MessageService],
	declarations: [MIGPropertyCoverage],
	exports: [MIGPropertyCoverage]
})
export class PropertyCoverageModule { }
