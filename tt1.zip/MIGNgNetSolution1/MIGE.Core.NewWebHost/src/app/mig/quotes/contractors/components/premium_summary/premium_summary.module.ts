/* NG Includes */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { MIGOverlayPanelModule } from '@overridden/primeng-overlaypanel/overlay.module';
import { PipesModule } from '@pipes/pipes.module';
import { FieldsetModule } from 'primeng/fieldset';
import { PanelModule } from 'primeng/panel';
import { TooltipModule } from 'primeng/tooltip';
import { TabViewModule } from 'primeng/tabview';
import { MIGButtonModule } from '@overridden/primeng-button/button.module';
import { MIGInputtextModule } from '@overridden/primeng-inputtext/input.module';
import { MIGCheckboxModule } from '@overridden/primeng-checkbox/checkbox.module';
import { MIGQuoteReportComponent } from './premium_summary.component';
import { MIGDropDownModule } from '@overridden/primeng-dropdown/dropdown.module';
import { TextMaskModule } from 'angular2-text-mask';
import { MenuClass } from '@root/system/menu/menu';
import { MIGProgessbarModule } from '@overridden/primeng-progressbar/progress.module';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import { DialogModule } from 'primeng/dialog';
import { DiscretionaryPricingModule } from '@shared/discretionary_pricing/discretionary_pricing.module';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { MIGMessageModule } from '@overridden/primeng-message/message.module';
import { MIGDocumentButtonModule} from '@shared/document_button/document_button.module';

import {NgxPrintModule} from 'ngx-print';
import { AuthService } from '@auth/auth.service';
import { BillingCalculatorModule } from '@root/shared_components/billing_calculator/billing-calculator.module';

@NgModule({
	imports: [
		MIGButtonModule,
		FormsModule,
		CommonModule,
		MIGDropDownModule,
		PanelModule,
		FieldsetModule,
		PipesModule,
		MIGOverlayPanelModule,
		MIGInputtextModule,
		TabViewModule,
		TooltipModule,
		TextMaskModule,
		MIGCheckboxModule,
		MIGProgessbarModule,
		DialogModule,
		DynamicDialogModule,
		DiscretionaryPricingModule,
        ProgressSpinnerModule,
        MIGMessageModule,
		MIGDocumentButtonModule,
		NgxPrintModule,
        BillingCalculatorModule
	],
	declarations: [
		MIGQuoteReportComponent
	],
	exports: [MIGQuoteReportComponent]
})
export class PremiumSummaryModule {
	formGroup: UntypedFormGroup;
	constructor(
		public menuClass: MenuClass,
		private formBuilder: UntypedFormBuilder,
		private authService: AuthService
	) {
		this.formGroup = this.formBuilder.group({});

		menuClass.addMenuItem({
			name: 'PremiumSummary',
			label: 'Premium Summary',
			color: "ui-steps-number-default",
			navSkip: false,
			active: false,
			hasError: false,
			errors: [],
			buttons: [ !this.authService.isPolicyInquiry() ? { button: "Next" } : { button: ""}, { button: "Back" }, { button: "Save" }, { button: "Save&Exit" }, { button: "ContinueToUnderwritting" }],
			icon: "fa fa-list-alt",
			block: [],
			visible: true,
			quote: "premium"
		});
	}
}
