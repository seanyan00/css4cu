import { Component, OnInit, ViewEncapsulation } from '@angular/core';
//import { LocalStorage } from '@ngx-pwa/local-storage';

@Component({
    templateUrl: './dashboard.component.html',
    styleUrls: ['dashboard.component.css'],
    encapsulation: ViewEncapsulation.None
})
export class DashboardComponent implements OnInit {
    activeIndex: number = 0;

    index: number = 0;
    settings: any = { dashboard_last_viewed: this.index };

    //constructor(protected localStorage: LocalStorage) { }
    constructor() { }

    handleChange(e) {
        var index = e.index;
        //console.log("tab selected: " + index);
        //this.localStorage.setItem('settings', this.settings).subscribe(() => { });
    }

    ngOnInit() {
        try {
            // this.localStorage.getItem<any>('settings').subscribe((settings) => {
            //     let index = 0;
            //     if (settings) { index = this.settings.dashboard_last_viewed; }
            //     this.activeIndex = index;
            // }, (error) => {
            //     //console.log("Nothing set yet!");
            //     //console.log(error);
            // });
        } catch (e) {
            return 0;
        }
        //console.log(this.activeIndex);
    }
}
