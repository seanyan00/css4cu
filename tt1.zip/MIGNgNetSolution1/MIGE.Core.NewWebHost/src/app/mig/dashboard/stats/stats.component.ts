import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'mig-stats',
    templateUrl: './stats.component.html',
    styleUrls: ['./stats.component.css']
})
export class StatsComponent implements OnInit {

    data: any;
    pie: any;
    optionsBar: any;
    optionsPie: any;

    constructor() { }

    ngOnInit() {
        this.optionsBar = {}

        this.optionsPie = {}

        this.data = { }

        this.pie = {
            labels: [],
            datasets: []
        };
    }
}
