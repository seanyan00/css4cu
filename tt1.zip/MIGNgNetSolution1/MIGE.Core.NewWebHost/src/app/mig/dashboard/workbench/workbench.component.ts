import { Component, OnInit } from '@angular/core';
import { Workbench, WorkbenchService } from '@services/workbench.service';

@Component({
    selector: 'mig-workbench',
    templateUrl: './workbench.component.html',
    styleUrls: ['./workbench.component.css'],

})

export class WorkbenchComponent implements OnInit {
    loading: boolean = true;
    data: any;
    workbench: Workbench[];
    rowCount: number = 0;
    dataLoaded: boolean = false;
    dte: string = "";

    actions: any = []

    funcTableFiltered(event) {
        //console.log(event.filteredValue.length);
        this.rowCount = event.filteredValue.length;
    }

    funcDateSelected(event) {
        if (event === undefined) { return false; }
        //console.log(event);
        var d = new Date();
        d = event;
        let mm = (d.getMonth() + 1).toString();
        let pad = "00";
        mm = pad.substring(mm.length) + mm
        let dd = (d.getDate()).toString();
        dd = pad.substring(dd.length) + dd
        let yy = d.getFullYear();

        let out = yy.toString() + mm.toString() + dd.toString();
        this.dte = out;
        //console.log(out);
    }

    constructor(private workbenchService: WorkbenchService) { }

    ngOnInit() {
        //console.log("Workbench Component Loaded");
        this.workbenchService.getWorkbench().subscribe(data => {
            this.workbench = data;
            this.rowCount = data.length;
            this.dataLoaded = true;
            this.loading = false;
        })
    }
}
