import { POLICYTRANS } from '@classes/Common/POLICYTRANS';
import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';
//import { UWQUESTIONROOT } from '@classes/Common/UWQuestionClasses/UWQUESTIONROOT';
import { CONTACTINFOLOSSES } from '@classes/Common/CONTACTINFOLOSSES';
import { ADDITIONALINSURED } from '@classes/Common/ADDITIONALINSUREDS';
import { UWREFERRALS } from '@classes/Common/UWREFERRALS';
import { GLPFORMDATA } from '@classes/Common/GLPFORMDATA';
import { UWQUESTIONSCATEGORY } from '@classes/Common/UWQuestionClasses/UWQUESTIONCATEGORY';
import { STATISTICS } from '@classes/Common/STATISTICS';
import { HTTPREQUESTRESPONSE } from '@classes/Common/HTTPREQUESTRESPONSE';
//import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
//import { IQuote } from '@interfaces/IQuote';
//import { templateJitUrl } from '@angular/compiler';



export class CommonQuote   {

    public POLICYTRANS: POLICYTRANS;
    public QUOTEPOLICYINFORMATION: QUOTEPOLICYINFO;	
	public CONTACTINFOLOSSES: CONTACTINFOLOSSES;  //DWXE110

	public STATISTICS: STATISTICS[] = [];
	public GLPFORMDATA: GLPFORMDATA[] = [];
	public UWREFERRALS: UWREFERRALS[] = [];
	public ADDITIONALINSUREDS: ADDITIONALINSURED[] = [];
	public UWQUESTIONSCATEGORY: UWQUESTIONSCATEGORY[] = [];
	public HTTPREQUESTRESPONSE: HTTPREQUESTRESPONSE;
    constructor() {

        this.POLICYTRANS = new POLICYTRANS();
		this.QUOTEPOLICYINFORMATION = new QUOTEPOLICYINFO();
		this.HTTPREQUESTRESPONSE = new HTTPREQUESTRESPONSE(this.QUOTEPOLICYINFORMATION);
	}
	
		// public changeAddType(fromAddType: string, toAddType: string) : void {
		// 	//et tmpAI = new ADDITIONALINSURED(this.QUOTEPOLICYINFORMATION);
		// 	// //tmpAI.changeAddType(fromAddType, toAddType)
		// 	//tmpAI.changeAddType(this.ADDITIONALINSUREDS);
		
		// }


		public changeAddType(fromAddType: string) : void {
			let tmpAI = new ADDITIONALINSURED(this.QUOTEPOLICYINFORMATION, this.ADDITIONALINSUREDS);
			tmpAI.changeAddType(fromAddType);
		}

    	//delete additional insureds for scheduled items --- need to see how many are in there and then delete any others
		public updateScheduledAI(addType: string, count: number, secondAddType?: string, secondCount?: number) : void {
             let tmpAI = new ADDITIONALINSURED(this.QUOTEPOLICYINFORMATION, this.ADDITIONALINSUREDS);
			 tmpAI.updateScheduledAI(this.QUOTEPOLICYINFORMATION, addType, count, secondAddType, secondCount);
		}
	
		public updateScheduledAIData(data: any) {
			let tmpAI = new ADDITIONALINSURED(this.QUOTEPOLICYINFORMATION, this.ADDITIONALINSUREDS);
			tmpAI.updateScheduledAIData(data);
		}
		//update for Blanket Additional Insureds.
		public updateBlanketAI( addType: string, updateRecord: boolean) : void {
             let tmpAI = new ADDITIONALINSURED(this.QUOTEPOLICYINFORMATION, this.ADDITIONALINSUREDS);
			 tmpAI.updateBlanketAI(this.QUOTEPOLICYINFORMATION, this.POLICYTRANS.CANSTE, addType, updateRecord);
		}

		public updateERISA(data: any) : void {
			let tmpAI = new ADDITIONALINSURED(this.QUOTEPOLICYINFORMATION, this.ADDITIONALINSUREDS);
			tmpAI.updateERISA(data, this.QUOTEPOLICYINFORMATION);
		}
		
		public deleteERISA(): void {
			let tmpAI = new ADDITIONALINSURED(this.QUOTEPOLICYINFORMATION, this.ADDITIONALINSUREDS);
			tmpAI.deleteERISA();
		}
}
