import { Injectable, Input } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { map } from 'rxjs/operators';
@Injectable()
export class PersistFormErrors {

    http: HttpClient;

    /** @param number total # of errors */
    @Input() errorTot: number = 0;

    /** @param array list of errors */
    @Input() errors: any[] = [];

    /** @param number which step the errors belong to */
    @Input() step: number = 0;

    funcSave() {
        let url: string = "";
        let body = { errorTot: this.errorTot, errors: this.errors, step: this.step };
        return this.http.post(url, body)
            .pipe(map((response: Response) => response))
            .subscribe(data => {
                return true;
            });
    }

    funcGet(step: number): any {
        let errors = [];

        // some code
        return { step: step, errorTot: errors.length, errors: errors };
    }
}