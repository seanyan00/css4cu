/******************************************************************************************************
     * PROGRAM DESCRIPTION  - Class file for our WCA Quote 
     * NOTES                - 5/25/22: removed reference to QUOTEPERSONALINFO as this is not needed for WCA -JTL
****************************************************************************************************/

import { IQuote } from '@interfaces/IQuote';
import { ILocation } from '@interfaces/ILocation';
import { CommonQuote } from '@classViewModels/CommonQuote/CommonQuote';
import { QUOTEPERSONALINFO } from '@classes/CTR/QUOTEPERSONALINFO';
import * as _ from "lodash";
import { POLICYTRANS } from '@classes/Common/POLICYTRANS';
import { MenuClass } from '@root/system/menu/menu';
import { environment } from '@environment/environment';
import { LOSSCLAIM } from '@classes/Common/LOSSCLAIM';
import { CFPMORTGAGEE } from '@classes/CTR/CFPMORTGAGEE';
import { IMortgagee } from '@interfaces/IMortgagee';
import { IScheduledItem } from '@interfaces/IScheduledItems';
import { EMPLOYERSLIABLIMITS } from '@classes/WCA/EMPLOYERSLIABLIMITS';
import { WCASTATES } from '@classes/WCA/WCAStates';
import { WCALOCATIONS } from '@classes/WCA/WCALocations';
import { WCAClassExtended } from '@classes/WCA/WCCLASSEXTENDEDABSTRACT';
import { STATISTICS } from '@classes/Common/STATISTICS';
import { WCAIndividual } from '@classes/WCA/WCAIndividual';
import { WCAACOUNTINGCONTACT } from '@classes/WCA/WCAACOUNTINGCONTACT';
import { HTTPREQUESTRESPONSE } from '@classes/Common/HTTPREQUESTRESPONSE';

export class WCAQuote extends CommonQuote implements IQuote {
    QUOTEPERSONALINFO: QUOTEPERSONALINFO;
    LOSSCLAIMS: LOSSCLAIM[];
    EMPLOYERSLIABLIMITS: EMPLOYERSLIABLIMITS;
    STATES: WCASTATES[] = [];
    CLASSEXTENDED: WCAClassExtended[] = [];
    ACCOUNTINGCONTACT: WCAACOUNTINGCONTACT;
    HTTPREQUESTRESPONSE: HTTPREQUESTRESPONSE;
    constructor(quote?: WCAQuote){
        super();
        this.EMPLOYERSLIABLIMITS = new EMPLOYERSLIABLIMITS();
        this.ACCOUNTINGCONTACT = new WCAACOUNTINGCONTACT();
        //this.QUOTEPERSONALINFO = new QUOTEPERSONALINFO();

        if (quote != undefined && quote != null && quote.STATES != undefined && quote.STATES != null) {
            this.initializeQuote(quote);
            //this.QUOTEPERSONALINFO = new QUOTEPERSONALINFO(quote.QUOTEPERSONALINFO);
        }

        this.POLICYTRANS.ADDRESS.POLICY = this.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
        this.POLICYTRANS.ADDRESS.AGENTNUMBER = this.QUOTEPOLICYINFORMATION.AGENTNUMBER;
        this.POLICYTRANS.RCDTYP = 3;
    }

    private initializeQuote(quote: WCAQuote): void{
        
        this.POLICYTRANS = new POLICYTRANS(quote.POLICYTRANS);
        this.QUOTEPOLICYINFORMATION = quote.QUOTEPOLICYINFORMATION;
        this.EMPLOYERSLIABLIMITS = quote.EMPLOYERSLIABLIMITS;
        this.CLASSEXTENDED = quote.CLASSEXTENDED;
        this.ACCOUNTINGCONTACT = quote.ACCOUNTINGCONTACT;
        this.HTTPREQUESTRESPONSE = new HTTPREQUESTRESPONSE(this.QUOTEPOLICYINFORMATION);
        var stateToAdd:WCASTATES;
        var locationToAdd:WCALOCATIONS;
        var businessClassToAdd:WCAClassExtended;
        var individualToAdd: WCAIndividual;

        quote.STATES.forEach( state => {
            stateToAdd = Object.assign(new WCASTATES(), state);
            stateToAdd.RCDTYP = 3;
            stateToAdd.LOCATIONS = [];
            stateToAdd.INDIVIDUALS = []; // 5/24/21: need to clear out the individuals otherwise they will quadruple every time this function is called 
            //stateToAdd.RTEFDT = this.POLICYTRANS.EFFDTE; // need to set the rate effdte to the EFFDTE, or else we will get a rating error.

            state.LOCATIONS.forEach(location => {
                locationToAdd = Object.assign(new WCALOCATIONS(), location);
                locationToAdd.RCDTYP = 3;
                locationToAdd.BUSINESSCLASSES = [];
                
                location.BUSINESSCLASSES.forEach(businessClass => {
                    businessClass.COVRG = "11"; // this field used for rating should always default to "11"
                    businessClassToAdd = Object.assign(new WCAClassExtended(), businessClass);
                    businessClassToAdd.RCDTYP = 3;
                    businessClassToAdd.BUSINESSCLASSSTATS = Object.assign(new STATISTICS(quote.QUOTEPOLICYINFORMATION), businessClass.BUSINESSCLASSSTATS);
                    businessClassToAdd.BUSINESSCLASSSTATS.RCDTYP = 3;
                    locationToAdd.BUSINESSCLASSES.push(businessClassToAdd);
                    this.STATISTICS.push(businessClassToAdd.BUSINESSCLASSSTATS)
                });
                stateToAdd.LOCATIONS.push(locationToAdd);
            });

            state.INDIVIDUALS.forEach(individual=> {
                individualToAdd = Object.assign(new WCAIndividual(), individual);
                stateToAdd.INDIVIDUALS.push(individualToAdd);
            });
            //stateToAdd.INDIVIDUALS.push(individualToAdd);
            this.STATES.push(stateToAdd);
        });
    
        //this.STATES = quote.STATES;
        
        // if ((quote.CONTACTINFOLOSSES != undefined) && (quote.CONTACTINFOLOSSES.POLICY == this.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER)) {
        //     this.CONTACTINFOLOSSES = new CONTACTINFOLOSSES(quote.QUOTEPOLICYINFORMATION);
        //     this.CONTACTINFOLOSSES = Object.assign(this.CONTACTINFOLOSSES, quote.CONTACTINFOLOSSES);
        // }

        this.ADDITIONALINSUREDS = quote.ADDITIONALINSUREDS; //Need this uncommented so we don't lose data for finish app
        //this.QUOTEPERSONALINFO = quote.QUOTEPERSONALINFO;
       // this.GLPFORMDATA = quote.GLPFORMDATA;
        this.STATISTICS = quote.STATISTICS;        
        //this.LOSSCLAIMS = quote.LOSSCLAIMS;

        if (quote.UWQUESTIONSCATEGORY && quote.UWQUESTIONSCATEGORY.length > 0) {
            this.UWQUESTIONSCATEGORY = quote.UWQUESTIONSCATEGORY;
        }
    }

    SaveQuote(): boolean {
        return true;
    }
    GetQuote(): boolean {
       return true;
    }
    AddNewStateObject(): WCASTATES {
        var newState = new WCASTATES();
        newState.TRANS = this.POLICYTRANS.TRANS;
        newState.POLICY = this.POLICYTRANS.POLICY;
        newState.EFFDTE = this.POLICYTRANS.EFFDTE;
        newState.EDSDTE = this.POLICYTRANS.EDSDTE;
        newState.EDSNO = this.POLICYTRANS.EDSNO;
        //newState.RTEFDT = this.POLICYTRANS.EFFDTE;
        newState.RECORDSTATE = "N";
        newState.RCDTYP = 3;
        //newState.RCDTYP = this.POLICYTRANS.RCDTYP;
        this.STATES.push(newState);
        return newState;
    }
    // Ommiting in WCA
    InitializeLoss(): boolean {
        return true;
       //throw new Error('Method not implemented.');
    }
    //Ommiting in WCA
    GetLocations(coverage: string): ILocation[] {
        return null;
       // throw new Error('Method not implemented.');
    }
    //Ommiting in WCA
    GetMortgagees(coverage: string): IMortgagee[] {
        return null;
        throw new Error('Method not implemented.');
    }
    //Ommiting in WCA
    DeleteMortgagee(coverage: string, index: number, coverageType: string): void {
        return;
        throw new Error('Method not implemented.');
    }
    //Ommiting in WCA
    SaveMortgagee(coverage: string, mortgage: CFPMORTGAGEE, coverageType: string): void {
        return;
        throw new Error('Method not implemented.');
    }
    //Ommiting in WCA
    GetScheduledItems(coverage: string): IScheduledItem[] {
        return;
        throw new Error('Method not implemented.');
    }
    //Ommiting in WCA
    AddAdditionalCoverage(coverage: string): void {
        return;
        throw new Error('Method not implemented.');
    }
    //Ommiting in WCA
    RemoveAdditionalCoverage(coverage: string): void {
        return;
        throw new Error('Method not implemented.');
    }
    //For Discretionary Pricing
    DisableScheduleField(scheduleStateMinimums: any): boolean {
        if (scheduleStateMinimums == null) {
            return true;
        }

        let totalPolicyPremiumMin = scheduleStateMinimums.policyPremiumMin;
        let totalPolicyPremium = this.POLICYTRANS.APRP;
        let cancelState = this.POLICYTRANS.CANSTE;
        if(cancelState == "29" || cancelState == "37" || cancelState == "44"){
            totalPolicyPremiumMin = this.QUOTEPOLICYINFORMATION.CLASSCODEINFO.MINPRE;
        }
        
        let schedulePremiumMin = scheduleStateMinimums.glPremiumMin;
        
        return ( totalPolicyPremium <= totalPolicyPremiumMin) && (this.STATES.every(s => s.SCHMOD == 0 || s.SCHMOD == 1));
    }
    //For Discretionary Pricing
    DisableIrpmField(): boolean {
        return true;
        throw new Error('Method not implemented.');
    }

    //For Discretionary Pricing
    ShowNjDeregField(deregFlag: string): boolean {
        return false;
        throw new Error('Method not implemented.');
    }
    //For Discretionary Pricing
    ShowPaDeregField(deregFlag: string): boolean {
        return false;
        throw new Error('Method not implemented.');
    }
    //For Discretionary Pricing
    GetDPScheduleValue(): number {
        let distinctExpModArray = _.uniqBy(this.STATES, "IRPMOD");
        if (distinctExpModArray.length == 0)
            return 0;

        if (distinctExpModArray.length > 1)
            throw Error("More than one IRPMOD value");

        return distinctExpModArray[0].SCHMOD;
    }
    //For Discretionary Pricing
    GetDPIrpmValue(): number {
        return 1;
        throw new Error('Method not implemented.');
    }
    //For Discretionary Pricing
    GetDPNjPaDeregValue(): number {
        return 1;
        throw new Error('Method not implemented.');
    }
    //For Discretionary Pricing
    SetDPScheduleValue(value: number) {
        this.STATES.forEach((stateInfo) => {
            stateInfo.SCHMOD = value;
        });
    }
    //For Discretionary Pricing
    SetDPIrpmValue(value: number) { // No IRPM for WCA as of now 3/4/22
        return;
        throw new Error('Method not implemented.');
    }
    //For Discretionary Pricing
    SetDPNjPaDeregValue(value: number) {
        return;
        throw new Error('Method not implemented.');
    }
    //For Discretionary Pricing
    ApplyDiscretionaryPricing(originalPremium: number): number {
        var schedule = ((this.GetDPScheduleValue() == undefined) || (this.GetDPScheduleValue() == 0)) ? 1 : this.GetDPScheduleValue();
        var premium = originalPremium;
        premium = premium * schedule;
        //premium = premium * irpm;
        //premium = premium * njDereg;
        //premium = premium * NjPaDereg;

        //if (schedule != 1 || irpm != 1 || njDereg != 1) {
        if (schedule != 1 ){//|| irpm != 1 || NjPaDereg != 1) {
            return premium;
        }
        else {
            return originalPremium;
        }
    }
    UpdateQuoteStatus(menuClass: MenuClass, quoteChangesDetected: boolean): void {
        // N	New Quote	Brand new pre-filled quote created during business eligibility process.  Once quote is touched it will become Incomplete.
        // I	Incomplete Quote	A partial quote that has yet to be rated; Or a modified quote that contains changes that require a re-rate.  An incomplete quote has no premium.
        // Q	Complete Quote	A quote that is successfully rated and contains a premium.
        // A	Incomplete Application	A completed quote that has partial application data completed.
        // C	Complete Application	A completed quote that has all application data completed.  This status is only achieved on the very last page of the application.
        // S	Submitted Application	A quote that is submitted to the company for policy issuance.  The quote receives a new policy number and can no longer be edited.
        // R	Refer to Company	A completed quote that contains pending referrals that need to be cleared by an underwriter.  This quote cannot be edited until the underwriter has cleared the referrals. 
        /******************************************************************
        ***** Statuses 'U', 'P', 'D', 'F' do not apply to Contractors *****
        ******************************************************************/
        // U	Contact U/W	A WCA quote that is in a complete application state that has been submitted to MIG for review.  Conditions on this quote made it ineligible to submit online, so the application is still sent to MIG for review.  The quote is then unassigned from the account and can be edited. 
        // P	Active Policy	A posted policy that is within its’ current policy term.
        // D	Pending Cancel	An active policy that is pending cancelation due to non-payment.
        // F	Canceled	A posted policy that is within its’ current policy term and has been canceled.

        var PremiumSummaryMenuObjectIndex = menuClass.menuObjectIndex('PremiumSummary');

        if (this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'N') {
            //'N' - New Quote Becomes 'I' - Incomplete Quote
            this.MarkQuoteAsIncomplete();
        }
        else if (this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'R') {
            //Quote is in 'R' - Refer to Company status.
            //'R' - Refer to Company status can only be changed to 'I' - Incomplete Quote status when an underwriter or colleague releases the quote.
            //The 'R' to 'I' status change is done in the /ReleaseQuote api endpoint.
            return;
        }
        else if (PremiumSummaryMenuObjectIndex == menuClass.stepActive) {
            // If a complete quote / incomplete application is loaded on the Premium Summary screen,
            if (this.POLICYTRANS.APRP > 0) {
                // and we have a premium greater than 0, the status should be 'Q' - Complete Quote.
                this.MarkQuoteAsComplete();
            }
            else {
                // and we DO NOT have a premium greater than 0, the status should be 'I' - Incomplete Quote
                menuClass.isQuoteDirty = true;
                this.MarkQuoteAsIncomplete();
            }

        }
        else if ((PremiumSummaryMenuObjectIndex > menuClass.stepActive) && (quoteChangesDetected)) {
            //  If a complete quote / incomplete application is loaded on any screen BEFORE Premium Summary,
            //  'Q' - Complete Quote or 'A' - Incomplete Application
            //  becomes 'I' - Incomplete Quote w/ the premium value set to 0.
            menuClass.isQuoteDirty = true;
            this.MarkQuoteAsIncomplete();
        }
        else if ((this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'I') && (this.POLICYTRANS.APRP > 0)) {
            //  If an incomplete quote has a successful rating and a premium value
            //  'I' - Incomplete Quote becomes 'Q' - Complete Quote
            this.MarkQuoteAsComplete();
        }
        else if ((menuClass.stepActiveObject.name == 'ApplicationComplete') && (this.POLICYTRANS.APRP > 0) &&
            ((this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'C') ||
                (this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'A'))) {
            // If an Incomplete Application is loaded on the 'Application Complete screen',
            // 'A' - Incomplete Application becomes 'C' - Complete Application
            this.MarkAsCompletedApplication();
        }
        else if (
            (PremiumSummaryMenuObjectIndex < menuClass.stepActive) &&
            (quoteChangesDetected) &&
            (this.POLICYTRANS.APRP > 0) &&
            ((this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'Q') || (this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'A') || (this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'C'))
        ) {
            //  If a complete quote / incomplete application is loaded in any screen AFTER Premium Summary,
            //  user has made changes to the quote,
            //  the premium is greater than 0,
            //  and the quote status is 'Q' (Complete Quote), 'A' (Incomplete Application), or 'C' (Complete Application)
            //  'Q' - Complete Quote becomes 'A' - Incomplete Application.
            //  'A' - Incomplete Application remains Incomplete Application
            //  'C' - Complete Application reverts to Incomplete Application
            this.MarkAsIncompleteApplication();

        }
        // Questions
        // What triggers an 'S' - Submitted Application status?
        // What triggers an 'R' - Refer to Company status?  (Possibly Refer to Company button on Referral Screen?)
    }

    private MarkQuoteAsIncomplete() {
        this.LogMessage("Marking quote as incomplete - Status: I - Premium set to 0");
        this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE = 'I';
        this.POLICYTRANS.APRP = 0;
    }

    private MarkQuoteAsComplete() {
        this.LogMessage("Marking quote as complete - Status: Q");
        this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE = 'Q';
    }

    private MarkAsCompletedApplication() {
        this.LogMessage("Marking application as complete - Status: C");
        this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE = "C";
    }

    private MarkAsIncompleteApplication() {
        this.LogMessage("Marking application as incomplete - Status: A");
        this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE = "A";
    }
    private LogMessage(messageToLog: string) {
        let enableLog: boolean = false;
        if ((!(environment.production)) && (enableLog)) {
            console.log(messageToLog);
        }
    }
    HasAdditionalInsureds(): boolean {
        throw new Error('Method not implemented.');
    }
    HasPropertyCoverage(): boolean {
        throw new Error('Method not implemented.');
    }
    
}
