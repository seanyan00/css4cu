import { IQuote } from '@interfaces/IQuote';
import { ILocation } from '@interfaces/ILocation';
import { CommonQuote } from '@classViewModels/CommonQuote/CommonQuote';
import * as _ from "lodash";
import { POLICYTRANS } from '@classes/Common/POLICYTRANS';
import { MenuClass } from '@root/system/menu/menu';
import { environment } from '@environment/environment';
import { LOSSCLAIM } from '@classes/Common/LOSSCLAIM';
import { CFPMORTGAGEE } from '@classes/CTR/CFPMORTGAGEE';
import { IMortgagee } from '@interfaces/IMortgagee';
import { IScheduledItem } from '@interfaces/IScheduledItems';
import { HTTPREQUESTRESPONSE } from '@classes/Common/HTTPREQUESTRESPONSE';
import { CONTACTINFOLOSSES } from '@classes/Common/CONTACTINFOLOSSES';
import { ADDRESS } from '@root/shared_components/address_info/address.class';
import { BOPLOCATION } from '@mig/quotes/business-owners/classes/BOPLOCATION';
import { BOPBUILDING } from '@mig/quotes/business-owners/classes/BOPBUILDING';
import { OPTIONALPRODUCTCVG } from '@mig/quotes/business-owners/classes/OPTIONALPRODUCTCVG';
import { EXTENDEDPOLICYCVG, PROFLIABILITY, RATEMODIFICATION, STATETRANSACTION } from '@mig/quotes/business-owners/classes/BOPClasses';
import { Functions } from '@helpers/functions';
import { BOPQUOTEPERSONALINFO } from '@mig/quotes/business-owners/classes/BOPQUOTEPERSONALINFO';
import { ADDITIONALINSURED } from '@classes/Common/ADDITIONALINSUREDS';


export class BOPQuote extends CommonQuote implements IQuote {
    public LOSSCLAIMS: LOSSCLAIM[];
    QUOTEPERSONALINFO: BOPQUOTEPERSONALINFO;
    // BOP-Specific Objects go here:
    HTTPREQUESTRESPONSE: HTTPREQUESTRESPONSE;

    OPTIONALPRODUCTCVG: OPTIONALPRODUCTCVG;
    PROFLIABILITY: PROFLIABILITY[] = [];
    EXTENDEDPOLICYCVG: EXTENDEDPOLICYCVG[];
    STATETRANSACTION: STATETRANSACTION[] = [];
    RATEMODIFICATION: RATEMODIFICATION;
    BOPLOCATIONS: BOPLOCATION[] = []; // object we created on BE that consists of our LOCNUM, Garage coverage, Pet Plus coverage, and all buildings (DW5P130 records) associated w/ our location -JTL
    
    constructor(quote?: BOPQuote){
        super();
        this.QUOTEPERSONALINFO = new BOPQUOTEPERSONALINFO();
        this.OPTIONALPRODUCTCVG = new OPTIONALPRODUCTCVG();

        

        if (quote != undefined && quote != null) {
            this.initializeQuote(quote)
        }
        this.InitializeLoss();
        this.POLICYTRANS.ADDRESS.POLICY = this.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
        this.POLICYTRANS.ADDRESS.AGENTNUMBER = this.QUOTEPOLICYINFORMATION.AGENTNUMBER;
        this.POLICYTRANS.RCDTYP = 3;
        
        this.QUOTEPERSONALINFO.POLICY = this.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
        this.QUOTEPERSONALINFO.EFFDTE = this.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
        this.QUOTEPERSONALINFO.TRANS =  this.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;
        this.QUOTEPERSONALINFO.RCDTYP = this.QUOTEPOLICYINFORMATION.RECORDTYPE;
        this.QUOTEPERSONALINFO.EDSDTE = this.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;

        this.OPTIONALPRODUCTCVG.POLICY = this.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
        this.OPTIONALPRODUCTCVG.EFFDTE = this.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
        this.OPTIONALPRODUCTCVG.TRANS =  this.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;
        this.OPTIONALPRODUCTCVG.RCDTYP = this.QUOTEPOLICYINFORMATION.RECORDTYPE;
        this.OPTIONALPRODUCTCVG.EDSDTE = this.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;
        this.OPTIONALPRODUCTCVG.RECORDSTATE = "U";
        
    }

    private initializeQuote(quote: BOPQuote): void{
        this.POLICYTRANS = new POLICYTRANS(quote.POLICYTRANS);
        this.QUOTEPOLICYINFORMATION = quote.QUOTEPOLICYINFORMATION;
        this.HTTPREQUESTRESPONSE = new HTTPREQUESTRESPONSE(this.QUOTEPOLICYINFORMATION);

        if ((quote.CONTACTINFOLOSSES != undefined) && (quote.CONTACTINFOLOSSES.POLICY == this.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER)) {
            this.CONTACTINFOLOSSES = new CONTACTINFOLOSSES(quote.QUOTEPOLICYINFORMATION);
            this.CONTACTINFOLOSSES = Object.assign(this.CONTACTINFOLOSSES, quote.CONTACTINFOLOSSES);
        }

        if(quote.QUOTEPERSONALINFO != undefined)
        {
            this.QUOTEPERSONALINFO = new BOPQUOTEPERSONALINFO(quote.QUOTEPERSONALINFO);
        }

        if (quote.OPTIONALPRODUCTCVG != undefined)
        {
            this.OPTIONALPRODUCTCVG = new OPTIONALPRODUCTCVG(quote.OPTIONALPRODUCTCVG);
        }



        var locationToAdd:BOPLOCATION;

        if(quote.BOPLOCATIONS != undefined) {
            quote.BOPLOCATIONS.forEach(bopLocation => {
                locationToAdd = new BOPLOCATION(bopLocation);
                this.BOPLOCATIONS.push(locationToAdd);
            });
            //this.BOPLOCATIONS =  Object.assign(this.BOPLOCATIONS, quote.BOPLOCATIONS)
        }
        var stateTransactionRecToAdd:STATETRANSACTION;
        if(quote.STATETRANSACTION != undefined) {
            quote.STATETRANSACTION.forEach(stateTransactionRec => {
                stateTransactionRecToAdd = new STATETRANSACTION(stateTransactionRec);
                this.STATETRANSACTION.push(stateTransactionRecToAdd);
            });
            
        }

        var profLiabilityRecToAdd:PROFLIABILITY;
        if(quote.PROFLIABILITY != undefined) {
            quote.PROFLIABILITY.forEach(profLiabilityRec => {
                profLiabilityRecToAdd = new PROFLIABILITY(profLiabilityRec);
                this.PROFLIABILITY.push(profLiabilityRecToAdd);
            });
            
        }
        this.ADDITIONALINSUREDS = quote.ADDITIONALINSUREDS; //Need this uncommented so we don't lose data for finish app

       this.STATISTICS = quote.STATISTICS;
        this.LOSSCLAIMS = quote.LOSSCLAIMS;

        this.setNewQuoteCyberLiabilityCoverage()
        //Don't need yet for BOP -ZJG
        // if (quote.UWQUESTIONSCATEGORY && quote.UWQUESTIONSCATEGORY.length > 0) {
        //     this.UWQUESTIONSCATEGORY = quote.UWQUESTIONSCATEGORY;
        // }
    }

    setNewQuoteCyberLiabilityCoverage() {
        if (this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE != 'N') {
            //if it's not a new quote, we don't need to do anything here.
            return;
        }

        if (this.POLICYTRANS.CANSTE == '44') {
            //VT cannot have Cyber Liability
            return;
        }

        //Set Cyber Liability Default Values for a new, non-VT, quote
        this.QUOTEPERSONALINFO.CYBRDT = this.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
        this.QUOTEPERSONALINFO.CYBEFF = this.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
        this.QUOTEPERSONALINFO.CYBAGG = 100000;
    }
    
    removeCyberLiabilityCoverage() {
        this.QUOTEPERSONALINFO.CYBRDT = 0;
        this.QUOTEPERSONALINFO.CYBEFF = 0;
        this.QUOTEPERSONALINFO.CYBAGG = 0;
        this.QUOTEPERSONALINFO.CYBSAL = 0;
    }

    AllLocationsInState(stateCode:string):boolean {
        return _.every(this.getTotalLocations(), (location:BOPLOCATION) => {
            return location.locationIsInState(stateCode);
        });
    }
    setAndRetrieveProfLiabilityRecord(prfTyp:string, prfDsc: string, prfUnt?: number):PROFLIABILITY {
        let profLiabilityRec:PROFLIABILITY = _.find(this.PROFLIABILITY, (profLiabilityRec:PROFLIABILITY) => {
            return (profLiabilityRec.PRFTYP == prfTyp);
        });

        if (profLiabilityRec == undefined) {
            profLiabilityRec = new PROFLIABILITY();
            profLiabilityRec.TRANS = this.POLICYTRANS.TRANS;
            profLiabilityRec.POLICY = this.POLICYTRANS.POLICY;
            profLiabilityRec.EFFDTE = this.POLICYTRANS.EFFDTE;
            profLiabilityRec.EDSDTE = this.POLICYTRANS.EDSDTE;
            profLiabilityRec.RCDTYP = this.POLICYTRANS.RCDTYP;

            this.PROFLIABILITY.push(profLiabilityRec);
        }
        profLiabilityRec.PRFTYP = prfTyp;
        profLiabilityRec.PRFDSC = prfDsc;

        profLiabilityRec.RECORDSTATE = "N";
        
        if (prfUnt != undefined)
            profLiabilityRec.PRFUNT = prfUnt;
        
        return profLiabilityRec;
    }

    removeProfLiabilityRecord(prfTyp:string) {
        // _.remove(this.PROFLIABILITY, (profLiabilityRec:PROFLIABILITY) => {
        //     return (profLiabilityRec.PRFTYP == prfTyp);
        // });

        let profLiabilityRec:PROFLIABILITY = _.find(this.PROFLIABILITY, (profLiabilityRec:PROFLIABILITY) => {
            return (profLiabilityRec.PRFTYP == prfTyp);
        });

        if (profLiabilityRec != undefined)
            profLiabilityRec.RECORDSTATE = 'D';
    }

    AddNewLocationObject(): BOPLOCATION{ // called within BOPLocationSummary, will add a new location in our object graph if either 1: No locations currently exist or 2: We click "Add New Location"
        var newLoc: BOPLOCATION = new BOPLOCATION();
        newLoc.TRANS = this.POLICYTRANS.TRANS;
        newLoc.POLICY = this.POLICYTRANS.POLICY;
        newLoc.EFFDTE = this.POLICYTRANS.EFFDTE;
        newLoc.EDSDTE = this.POLICYTRANS.EDSDTE;
        newLoc.RECORDSTATE = "N";
        //newLoc.RCDTYP = 3;
        newLoc.ADDRESS = new ADDRESS();
        var newNumericLocNum:number = _.filter(this.BOPLOCATIONS, loc => loc.RECORDSTATE != "D").length; 
            newNumericLocNum++;
        newLoc.LOCNUM = _.padStart(newNumericLocNum.toString(), 3, '0');
        newLoc.initializeGarageKeeper();
        newLoc.initializePetPlus();
        
        this.BOPLOCATIONS.push(newLoc);
        return newLoc;

    }
    
    getTotalLocations() : BOPLOCATION[] {
        return this.BOPLOCATIONS.filter(loc=>loc.RECORDSTATE != "D")
    }

    deleteLocation(locationToDelete:BOPLOCATION) {
        // first we need to set the record state for the locationObject to "D".
        locationToDelete.RECORDSTATE = "D";
        locationToDelete.GARAGEKEEPER.RECORDSTATE = "D";
        locationToDelete.PETPLUS.RECORDSTATE = "D";
        // next we need to set the record state for all locations and buildings to D
        locationToDelete.BOPBUILDINGS.forEach((building: BOPBUILDING) => {
            locationToDelete.deleteBuilding(building);
        });
        this.funcResequenceLocations();  // resequence LOCNUM and BLDNUM's for all locations & buildings. 
 
    }

    getBuildingAndBPPClassCodeList() {
        let quoteBPPAndBuildingClassCodeList:string[] = [];
        this.getTotalLocations().forEach((location:BOPLOCATION) => {
            location.getTotalBuildings().forEach((building:BOPBUILDING) => {
                quoteBPPAndBuildingClassCodeList.push(building.BLDCLS);
                quoteBPPAndBuildingClassCodeList.push(building.BPPCLS);
            });
        });

        return _.uniq(quoteBPPAndBuildingClassCodeList);
    }

    determineSubcontractorsClassCode() {
        let firstLocation:BOPLOCATION = _.find(this.getTotalLocations(), loc => {return loc.LOCNUM == '001'});
        let firstLocationBuildings: BOPBUILDING[] = firstLocation.getTotalBuildings();
        let func = new Functions();
        let lastBLDNUM: string = func.lpad(firstLocationBuildings.length.toString(), '0', 3);
        let lastBuilding:BOPBUILDING = _.find(firstLocationBuildings, building => {return building.BLDNUM == lastBLDNUM});
        this.QUOTEPERSONALINFO.SUBCLS = "";
        if ((lastBuilding.BLDSEG == "LSRO") || (lastBuilding.BPPSEG == "LSRO")) {
            this.QUOTEPERSONALINFO.SUBCLS = "131498";
        }

        if ((lastBuilding.BLDSEG == "FOOD") || (lastBuilding.BPPSEG == "FOOD")) {
            this.QUOTEPERSONALINFO.SUBCLS = "131500";
        }

        if ((lastBuilding.BLDSEG == "RETL") || (lastBuilding.BPPSEG == "RETL")) {
            this.QUOTEPERSONALINFO.SUBCLS = "131502";
        }

        if ((lastBuilding.BLDSEG == "WHLS") || (lastBuilding.BPPSEG == "WHLS")) {
            this.QUOTEPERSONALINFO.SUBCLS = "131504";
        }
        
        if ((lastBuilding.BLDSEG == "SERV") || (lastBuilding.BPPSEG == "SERV")) {
            this.QUOTEPERSONALINFO.SUBCLS = "131506";
        }

        if ((lastBuilding.BLDSEG == "OFFC") || (lastBuilding.BPPSEG == "OFFC")) {
            this.QUOTEPERSONALINFO.SUBCLS = "131508";
        }
    }

    funcResequenceLocations() { // 
        let reIndex = 1;
            
              this.getTotalLocations().forEach(loc => { // for each location that isn't deleted...
                let func = new Functions();
                let newLocNum = func.lpad((reIndex).toString(), "0", 3);
                let buildings = loc.getTotalBuildings();
                loc.GARAGEKEEPER.LOCNUM = newLocNum;
                loc.PETPLUS.LOCNUM = newLocNum;
                buildings.forEach((bld:BOPBUILDING)=>{
                    bld.BOPSEGMENTINFO.LOCNUM = newLocNum;
                    bld.BUSINESSLIABILITY.LOCNUM = newLocNum;
                    bld.LIQUORLIABILITY.LOCNUM = newLocNum;
                })
                this.resequenceNumbers(buildings, loc.LOCNUM, newLocNum, "LOCNUM"); // resequence the LOCNUM's for each building record first. 
                this.resequenceNumbers(this.getTotalLocations(), loc.LOCNUM, newLocNum, "LOCNUM"); // next resequence the LOCNUMS of our Location objects

                //SET THE NEW LOCNUM AFTER COMPARING TO THE CLASSLIST AND PROPERTIES
                loc.LOCNUM = newLocNum;
                //
                reIndex++;
        });
        
      }
    
    additionalInsuredCount(addTyp:string): number {
        return _.filter(this.ADDITIONALINSUREDS, additionalInsured => {
            return additionalInsured.ADDTYP == addTyp && additionalInsured.RECORDSTATE != 'D'
        }).length;
    }
    resequenceNumbers(dataArray: any[], oldNum: string, newNum: string, property: string)
    // dataArray holds the array we need to resequence. oldNum holds the number that is out of place. newNum holds the number we want to set the oldNum to. property holds the property we want to resequence (LOCNUM, BLDNUM, SEQNO, etc).
    {
        _.forEach(dataArray, dataItem => {
            if ((dataItem.RECORDSTATE != 'D') && (dataItem[property] == oldNum))
            {
                dataItem[property] = newNum;
            }
        });
    }

    SaveQuote(): boolean {
        return true;
    }
    GetQuote(): boolean {
       return true;
    }

    InitializeLoss(): boolean {

        if (this.CONTACTINFOLOSSES == undefined) {
            this.CONTACTINFOLOSSES = new CONTACTINFOLOSSES(this.QUOTEPOLICYINFORMATION);
            this.LOSSCLAIMS = [];
            return true;
        }
        return false;
    }
    GetLocations(coverage: string): ILocation[] {
        return null;
       // throw new Error('Method not implemented.');
    }
    GetMortgagees(coverage: string): IMortgagee[] {
        return null;
        throw new Error('Method not implemented.');
    }
    DeleteMortgagee(coverage: string, index: number, coverageType: string): void {
        return;
        throw new Error('Method not implemented.');
    }
    SaveMortgagee(coverage: string, mortgage: CFPMORTGAGEE, coverageType: string): void {
        return;
        throw new Error('Method not implemented.');
    }
    GetScheduledItems(coverage: string): IScheduledItem[] {
        return;
        throw new Error('Method not implemented.');
    }
    AddAdditionalCoverage(coverage: string): void {
        return;
        throw new Error('Method not implemented.');
    }
    RemoveAdditionalCoverage(coverage: string): void {
        return;
        throw new Error('Method not implemented.');
    }
    
    //For Discretionary Pricing
    DisableScheduleField(scheduleStateMinimums: any): boolean {
        return false; // add logic when we begin implementing discretionary pricing.
    }
    //For Discretionary Pricing
    DisableIrpmField(): boolean {
        return false; // add logic when we begin implementing discretionary pricing.
        throw new Error('Method not implemented.');
    }

    //For Discretionary Pricing
    ShowNjDeregField(deregFlag: string): boolean {
        return false; // add logic when we begin implementing discretionary pricing.
        throw new Error('Method not implemented.');
    }
    //For Discretionary Pricing
    ShowPaDeregField(deregFlag: string): boolean {
        return false; // add logic when we begin implementing discretionary pricing.
        throw new Error('Method not implemented.');
    }
    //For Discretionary Pricing
    GetDPScheduleValue(): number {
        return 0; // add logic when we begin implementing discretionary pricing.
    } 
    //For Discretionary Pricing
    GetDPIrpmValue(): number {
        return 1; // add logic when we begin implementing discretionary pricing.
        throw new Error('Method not implemented.');
    }
    //For Discretionary Pricing
    GetDPNjPaDeregValue(): number {
        return 1; // add logic when we begin implementing discretionary pricing.
        throw new Error('Method not implemented.');
    }
    //For Discretionary Pricing
    SetDPScheduleValue(value: number) {
        return; // add logic when we begin implementing discretionary pricing.
    }
    //For Discretionary Pricing
    SetDPIrpmValue(value: number) {
        return;
        throw new Error('Method not implemented.');
    }
    //For Discretionary Pricing
    SetDPNjPaDeregValue(value: number) {
        return;
        throw new Error('Method not implemented.');
    }
    //For Discretionary Pricing
    ApplyDiscretionaryPricing(originalPremium: number): number {
        var schedule = ((this.GetDPScheduleValue() == undefined) || (this.GetDPScheduleValue() == 0)) ? 1 : this.GetDPScheduleValue();
        var premium = originalPremium;
        premium = premium * schedule;
        //premium = premium * irpm;
        //premium = premium * njDereg;
        //premium = premium * NjPaDereg;

        //if (schedule != 1 || irpm != 1 || njDereg != 1) {
        if (schedule != 1 ){//|| irpm != 1 || NjPaDereg != 1) {
            return premium;
        }
        else {
            return originalPremium;
        }
    }
    UpdateQuoteStatus(menuClass: MenuClass, quoteChangesDetected: boolean): void {
        // N	New Quote	Brand new pre-filled quote created during business eligibility process.  Once quote is touched it will become Incomplete.
        // I	Incomplete Quote	A partial quote that has yet to be rated; Or a modified quote that contains changes that require a re-rate.  An incomplete quote has no premium.
        // Q	Complete Quote	A quote that is successfully rated and contains a premium.
        // A	Incomplete Application	A completed quote that has partial application data completed.
        // C	Complete Application	A completed quote that has all application data completed.  This status is only achieved on the very last page of the application.
        // S	Submitted Application	A quote that is submitted to the company for policy issuance.  The quote receives a new policy number and can no longer be edited.
        // R	Refer to Company	A completed quote that contains pending referrals that need to be cleared by an underwriter.  This quote cannot be edited until the underwriter has cleared the referrals. 
        /******************************************************************
        ***** Statuses 'U', 'P', 'D', 'F' do not apply to Contractors *****
        ******************************************************************/
        // U	Contact U/W	A WCA quote that is in a complete application state that has been submitted to MIG for review.  Conditions on this quote made it ineligible to submit online, so the application is still sent to MIG for review.  The quote is then unassigned from the account and can be edited. 
        // P	Active Policy	A posted policy that is within its’ current policy term.
        // D	Pending Cancel	An active policy that is pending cancelation due to non-payment.
        // F	Canceled	A posted policy that is within its’ current policy term and has been canceled.

        var PremiumSummaryMenuObjectIndex = menuClass.menuObjectIndex('PremiumSummary');

        if (this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'N') {
            //'N' - New Quote Becomes 'I' - Incomplete Quote
            this.MarkQuoteAsIncomplete();
        }
        else if (this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'R') {
            //Quote is in 'R' - Refer to Company status.
            //'R' - Refer to Company status can only be changed to 'I' - Incomplete Quote status when an underwriter or colleague releases the quote.
            //The 'R' to 'I' status change is done in the /ReleaseQuote api endpoint.
            return;
        }
        else if (PremiumSummaryMenuObjectIndex == menuClass.stepActive) {
            // If a complete quote / incomplete application is loaded on the Premium Summary screen,
            if (this.POLICYTRANS.APRP > 0) {
                // and we have a premium greater than 0, the status should be 'Q' - Complete Quote.
                this.MarkQuoteAsComplete();
            }
            else {
                // and we DO NOT have a premium greater than 0, the status should be 'I' - Incomplete Quote
                menuClass.isQuoteDirty = true;
                this.MarkQuoteAsIncomplete();
            }

        }
        else if ((PremiumSummaryMenuObjectIndex > menuClass.stepActive) && (quoteChangesDetected)) {
            //  If a complete quote / incomplete application is loaded on any screen BEFORE Premium Summary,
            //  'Q' - Complete Quote or 'A' - Incomplete Application
            //  becomes 'I' - Incomplete Quote w/ the premium value set to 0.
            menuClass.isQuoteDirty = true;
            this.MarkQuoteAsIncomplete();
        }
        else if ((this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'I') && (this.POLICYTRANS.APRP > 0)) {
            //  If an incomplete quote has a successful rating and a premium value
            //  'I' - Incomplete Quote becomes 'Q' - Complete Quote
            this.MarkQuoteAsComplete();
        }
        else if ((menuClass.stepActiveObject.name == 'ApplicationComplete') && (this.POLICYTRANS.APRP > 0) &&
            ((this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'C') ||
                (this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'A'))) {
            // If an Incomplete Application is loaded on the 'Application Complete screen',
            // 'A' - Incomplete Application becomes 'C' - Complete Application
            this.MarkAsCompletedApplication();
        }
        else if (
            (PremiumSummaryMenuObjectIndex < menuClass.stepActive) &&
            (quoteChangesDetected) &&
            (this.POLICYTRANS.APRP > 0) &&
            ((this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'Q') || (this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'A') || (this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'C'))
        ) {
            //  If a complete quote / incomplete application is loaded in any screen AFTER Premium Summary,
            //  user has made changes to the quote,
            //  the premium is greater than 0,
            //  and the quote status is 'Q' (Complete Quote), 'A' (Incomplete Application), or 'C' (Complete Application)
            //  'Q' - Complete Quote becomes 'A' - Incomplete Application.
            //  'A' - Incomplete Application remains Incomplete Application
            //  'C' - Complete Application reverts to Incomplete Application
            this.MarkAsIncompleteApplication();

        }
        // Questions
        // What triggers an 'S' - Submitted Application status?
        // What triggers an 'R' - Refer to Company status?  (Possibly Refer to Company button on Referral Screen?)
    }

    private MarkQuoteAsIncomplete() {
        this.LogMessage("Marking quote as incomplete - Status: I - Premium set to 0");
        this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE = 'I';
        this.POLICYTRANS.APRP = 0;
    }

    private MarkQuoteAsComplete() {
        this.LogMessage("Marking quote as complete - Status: Q");
        this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE = 'Q';
    }

    private MarkAsCompletedApplication() {
        this.LogMessage("Marking application as complete - Status: C");
        this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE = "C";
    }

    private MarkAsIncompleteApplication() {
        this.LogMessage("Marking application as incomplete - Status: A");
        this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE = "A";
    }
    private LogMessage(messageToLog: string) {
        let enableLog: boolean = false;
        if ((!(environment.production)) && (enableLog)) {
            console.log(messageToLog);
        }
    }
    HasAdditionalInsureds(): boolean {
        throw new Error('Method not implemented.');
    }
    HasPropertyCoverage(): boolean {
        throw new Error('Method not implemented.');
    }

    //delete additional insureds for scheduled items --- need to see how many are in there and then delete any others
    public updateScheduledAI(addType: string, count: number, secondAddType?: string, secondCount?: number) : void {
        super.updateScheduledAI(addType, count, secondAddType, secondCount);
        this.updateScheduledCountFields();
    }

    updateScheduledCountFields() {
        var addTypList = ["ML", "CI", "ST", "AT", "MT", "OW", "CO", "EA", "LE", "DO", "EN", "O1", "CC", "SP", "BO", "GF"];
        var nonVendorCount = 0;
        var vendorCount = this.additionalInsuredCount("VE");
        
        _.forEach(addTypList, addTyp => {
            nonVendorCount+=this.additionalInsuredCount(addTyp);
        })

        this.QUOTEPERSONALINFO.NOVEND = vendorCount;
        this.QUOTEPERSONALINFO.ADINEM = nonVendorCount;

    }

    HasRetailInstallationClass() {

        let hasRetailInstallationClass:boolean = false;
        let currentBopLocation:BOPLOCATION;
        let currentBopBuilding:BOPBUILDING;
        let currentBopLocations:BOPLOCATION[] = this.getTotalLocations();
        let currentBopBuildings:BOPBUILDING[];
        for (var i = 0; i < currentBopLocations.length; i++) {
            currentBopLocation = currentBopLocations[i];
            currentBopBuildings = currentBopLocation.getTotalBuildings();

            for (var j = 0; j < currentBopBuildings.length; j++) {
                currentBopBuilding = currentBopBuildings[j];
                if (currentBopBuilding.BOPSEGMENTINFO.RTICLS1 == null)
                    currentBopBuilding.BOPSEGMENTINFO.RTICLS1 = "";

                if (currentBopBuilding.BOPSEGMENTINFO.RTICLS1.trim() != "") {
                    hasRetailInstallationClass = true;
                    break;
                }
            }

            if (hasRetailInstallationClass) {
                this.OPTIONALPRODUCTCVG.CEDED = 100;
                if ((this.OPTIONALPRODUCTCVG.CELMT == null) || (this.OPTIONALPRODUCTCVG.CELMT < 1000 ) || (this.OPTIONALPRODUCTCVG.CELMT > 10000)) {
                    this.OPTIONALPRODUCTCVG.CELMT = 1000;
                }
                break;
            }

        }

        return hasRetailInstallationClass;
    }
    
}
