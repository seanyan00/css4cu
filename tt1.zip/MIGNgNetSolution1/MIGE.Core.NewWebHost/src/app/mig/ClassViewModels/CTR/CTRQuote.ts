/******************************************************************************************************
     * PROGRAM DESCRIPTION  - Component for Contractors Quote 
     * NOTES                - RRF 2019-07-11 - Removed unused imports.
****************************************************************************************************/
import { IQuote } from '@interfaces/IQuote';
import { ILocation } from '@interfaces/ILocation';
import { CommonQuote } from '@classViewModels/CommonQuote/CommonQuote';
import { GLPEntity } from '@classes/CustomEntity/GLPEntity';
import { CFPEntity } from '@classes/CustomEntity/CFPEntity';
import { IMPEntity } from '@classes/CustomEntity/IMPEntity';
import { QUOTEPERSONALINFO } from '@classes/CTR/QUOTEPERSONALINFO';
import { CONTACTINFOLOSSES } from '@classes/Common/CONTACTINFOLOSSES';
import { IMortgagee } from '@interfaces/IMortgagee';
import { IScheduledItem } from '@interfaces/IScheduledItems';
import * as _ from "lodash";
import { POLICYTRANS } from '@classes/Common/POLICYTRANS';
import { LOSSCLAIM } from '@classes/Common/LOSSCLAIM';
import { MenuClass } from '@root/system/menu/menu';
import { CFPMORTGAGEE } from '@classes/CTR/CFPMORTGAGEE';
import { environment } from '@environment/environment';
import { ADDRESS } from '@root/shared_components/address_info/address.class';
import { HTTPREQUESTRESPONSE } from '@classes/Common/HTTPREQUESTRESPONSE';





export class CTRQuote extends CommonQuote implements IQuote {

    //returnSave: CTRQuote;

    public GLPENTITY: GLPEntity;
    public CFPENTITY: CFPEntity;
    public IMPENTITY: IMPEntity;
    public QUOTEPERSONALINFO: QUOTEPERSONALINFO;
    public LOSSCLAIMS: LOSSCLAIM[]; //DW1P123[]
    public GLLIABSTATECHANGE: string = "N";
    public INLANDSTATECHANGE: string = "N";

    //This is to check if pages past Premium Summary have been validated
    //and will need to be revisited if leave the quote and come back
    public ADDITIONALINSUREDSVALIDATED: boolean = false;
    public SCHEDITEMSVALIDATED: boolean = false;
    public CONSTPROJVALIDATED: boolean = false;
    public HTTPREQUESTRESPONSE: HTTPREQUESTRESPONSE;

    //This is an optional parameter and is used to initialize 
    //a quote returned from the quote service.
    //this is needed so that any public methods on any of the 
    //classes are not removed from the Observable<ctrQuote>
    constructor(quote?: CTRQuote) {
        super();

        this.CFPENTITY = new CFPEntity();
        this.GLPENTITY = new GLPEntity();
        this.IMPENTITY = new IMPEntity();
        this.QUOTEPERSONALINFO = new QUOTEPERSONALINFO();

        if (quote != undefined || quote != null) {
            this.initializeQuote(quote);
            this.initializeCFPEntity(quote);
            this.initializeGLPEntity(quote);
            this.initializeIMPEntity(quote);
            if(quote.POLICYTRANS.INSTYP == "IN" || quote.POLICYTRANS.INSTYP == "PA"){ // for persistence. If the insured type is individual or partnership, add our persisted info to the object graph.
                this.QUOTEPERSONALINFO = new QUOTEPERSONALINFO(quote.QUOTEPERSONALINFO);
            }
            else{ // If the insured type isn't individual or partnership, we do not need this object included in the object graph.
                this.QUOTEPERSONALINFO = undefined;
            }
        }
        this.InitializeLoss();

        this.POLICYTRANS.ADDRESS.POLICY = this.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
        this.POLICYTRANS.ADDRESS.AGENTNUMBER = this.QUOTEPOLICYINFORMATION.AGENTNUMBER;
    }

    //Initialize the new instance of the quote being returned from the quote
    //service so that the class methods are not disgarded from
    //an Observable<ctrQuote>
    private initializeQuote(quote: CTRQuote): void {

        this.POLICYTRANS = new POLICYTRANS(quote.POLICYTRANS);
        this.QUOTEPOLICYINFORMATION = quote.QUOTEPOLICYINFORMATION;
        this.HTTPREQUESTRESPONSE = new HTTPREQUESTRESPONSE(this.QUOTEPOLICYINFORMATION);

        if ((quote.CONTACTINFOLOSSES != undefined) && (quote.CONTACTINFOLOSSES.POLICY == this.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER)) {
            this.CONTACTINFOLOSSES = new CONTACTINFOLOSSES(quote.QUOTEPOLICYINFORMATION);
            this.CONTACTINFOLOSSES = Object.assign(this.CONTACTINFOLOSSES, quote.CONTACTINFOLOSSES);
        }

        this.ADDITIONALINSUREDS = quote.ADDITIONALINSUREDS;
        this.QUOTEPERSONALINFO = quote.QUOTEPERSONALINFO;
        this.GLPFORMDATA = quote.GLPFORMDATA;
        this.STATISTICS = quote.STATISTICS;
        this.LOSSCLAIMS = quote.LOSSCLAIMS;
        if (quote.UWQUESTIONSCATEGORY && quote.UWQUESTIONSCATEGORY.length > 0) {
            this.UWQUESTIONSCATEGORY = quote.UWQUESTIONSCATEGORY;
        }
    }

    private initializeCFPEntity(quote?: CTRQuote) {
        this.CFPENTITY = new CFPEntity(this.QUOTEPOLICYINFORMATION);

        // if(quote == undefined || quote == null)
        //     return;

        /* INITIALIZE CFP ENTITY */
        this.CFPENTITY.CFPCOVERAGES = quote.CFPENTITY.CFPCOVERAGES;
        this.CFPENTITY.CFPMORTGAGEE = quote.CFPENTITY.CFPMORTGAGEE;
        this.CFPENTITY.CFPSCHEDULEDITEMS = quote.CFPENTITY.CFPSCHEDULEDITEMS;
        this.CFPENTITY.CFPLOCATIONS = quote.CFPENTITY.CFPLOCATIONS;
        this.CFPENTITY.CFPSTATEINFO = quote.CFPENTITY.CFPSTATEINFO;
    }



    private initializeGLPEntity(quote?: CTRQuote) {
		this.GLPENTITY = new GLPEntity(this.QUOTEPOLICYINFORMATION);
        
        if (quote == undefined || quote == null || quote.GLPENTITY == undefined || quote.GLPENTITY == null)
			return;
        
        if (quote.GLPENTITY.GLPLIABILITIES.length > 0)
			this.GLPENTITY.GLPLIABILITIES = quote.GLPENTITY.GLPLIABILITIES;
        
        if (quote.GLPENTITY.QUOTEPOLICYLIABLIMITS.POLICY != "")
		    this.GLPENTITY.QUOTEPOLICYLIABLIMITS = quote.GLPENTITY.QUOTEPOLICYLIABLIMITS;
        
        this.GLPENTITY.GLPLOCATIONS = quote.GLPENTITY.GLPLOCATIONS;

        this.GLPENTITY.GLPLOCATIONS.forEach(glpLocation => {
            glpLocation.ADDRESS = new ADDRESS(glpLocation.ADDRESS);
            glpLocation.ADDRESS.POLICY = this.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
            glpLocation.ADDRESS.AGENTNUMBER = this.QUOTEPOLICYINFORMATION.AGENTNUMBER;
        })

		this.GLPENTITY.GLCLASSLIST = quote.GLPENTITY.GLCLASSLIST;
        this.GLPENTITY.CONSTPROJECTLIAB = quote.GLPENTITY.CONSTPROJECTLIAB;
        this.GLPENTITY.GLPSTATEINFO = quote.GLPENTITY.GLPSTATEINFO;

        if (this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'N') {
            //Default CG 2033 to checked on new quotes.
            //Once a quote is saved, the WEBSTATUSCODE will never be 'N' again.
            //This ensures the OSCNT value persisted in the database will be respected once a quote advances beyond "New Quote" status.
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.OSCNT = 1;
        }

    }

    private initializeIMPEntity(quote?: CTRQuote) {
        this.IMPENTITY = new IMPEntity(this.QUOTEPOLICYINFORMATION);

        // if(quote == undefined || quote == null)
        //     return;

        this.initializeIMPEntityProperty("IMPPRODUCTS", quote.IMPENTITY);
        this.initializeIMPEntityProperty("IMPJOBSITES", quote.IMPENTITY);
        //this.initializeIMPEntityProperty("IMPLOCATIONS", quote.IMPENTITY);
        this.initializeIMPEntityProperty("IMPMORTGAGEE", quote.IMPENTITY);
        this.initializeIMPEntityProperty("IMPSCHEDULEDITEMS", quote.IMPENTITY);
        this.initializeIMPEntityProperty("IMPSCHEDULEDTRANS", quote.IMPENTITY);
        this.initializeIMPEntityProperty("IMPSTATEINFO", quote.IMPENTITY);
    }

    private initializeIMPEntityProperty(propertyName: string, propertySource: IMPEntity) {
        if (propertySource == null)
            return;

        if ((propertySource[propertyName] == undefined) || (propertySource[propertyName] == null))
            return;

        if ((Array.isArray(propertySource[propertyName])) && (propertySource[propertyName].length <= 0))
            return;

        this.IMPENTITY[propertyName] = propertySource[propertyName];
    }

    InitializeLoss(): boolean {

        if (this.CONTACTINFOLOSSES == undefined) {
            this.CONTACTINFOLOSSES = new CONTACTINFOLOSSES(this.QUOTEPOLICYINFORMATION);
            this.LOSSCLAIMS = [];
            return true;
        }
        return false;
    }

    GetQuote(): boolean {
        return true;
    }

    SaveQuote(): boolean {
        return true;
    }

    public GetLocations(coverage: string): ILocation[] {

        if (coverage == "CFP") {
            return this.CFPENTITY.CFPLOCATIONS;
        }
        if (coverage == "GLP") {
            return this.GLPENTITY.GLPLOCATIONS;
        }
    }

    public GetMortgagees(coverage: string): IMortgagee[] {
        if (coverage === "CFP") {
            if (this.CFPENTITY.CFPMORTGAGEE.length > 0) {

                this.CFPENTITY.CFPMORTGAGEE.forEach(element => {
                    let obj = Object.keys(element).find(key => key === "LOCBLDSTATUS");
                    obj = element["LOCBLDSTATUS"];
                    if (obj != null) {
                        Object.keys(obj).forEach((key) => {
                            (element as any)[key] = obj[key];
                        })
                        delete element["LOCBLDSTATUS"];
                    }
                });
            }
            return this.CFPENTITY.CFPMORTGAGEE.filter(x=>x.RECORDSTATE!='D');
            //return this.CFPENTITY.CFPMORTGAGEE;
        }
        if (coverage === "IMP") {
            return this.IMPENTITY.IMPMORTGAGEE;
        }
    }

    public DeleteMortgagee(coverage: string, index: number, coverageType: string): void {
        if (coverage === "CFP") {
            this.CFPENTITY.deleteMortgagee(this.CFPENTITY.CFPMORTGAGEE[index]);
        }
        if (coverage === "IMP") {
            this.IMPENTITY.deleteMortgagee(this.IMPENTITY.IMPMORTGAGEE[index], coverageType);
        }

    }

    //public SaveMortgagee(coverage: string, mortgageList: IMortgagee[], coverageType: string) : void {
    //let i: number = 0;
    public SaveMortgagee(coverage: string, mortgagee: CFPMORTGAGEE, coverageType: string): void {
        if (coverage === "CFP") {
            this.CFPENTITY.saveMortgagee(mortgagee, coverageType);
        }

        if (coverage === "IMP") {
            this.IMPENTITY.saveMortgagee(mortgagee, coverageType);
        }

    }

    public GetScheduledItems(coverage: string): IScheduledItem[] {

        if (coverage === "IMP") {
            //sort the items by item description
            this.IMPENTITY.IMPSCHEDULEDITEMS = _.sortBy(this.IMPENTITY.IMPSCHEDULEDITEMS, x => x.ITEMDC);
            return this.IMPENTITY.IMPSCHEDULEDITEMS;
        }
        if (coverage === "CFP") {
            //sort the items by item description
            this.CFPENTITY.CFPSCHEDULEDITEMS = _.sortBy(this.CFPENTITY.CFPSCHEDULEDITEMS, x => x.ITEMDC);
            return this.CFPENTITY.CFPSCHEDULEDITEMS;
        }

    }

    //removes all scheduled items 
    removeIMPScheduledItems() {
        this.IMPENTITY.IMPSCHEDULEDITEMS.forEach(item => {
            item.RECORDSTATE = 'D';
        });
    }
    public AddAdditionalCoverage(coverage: string): void {
        this.GLPENTITY.AddAdditionalCoverage(coverage);
    }
    public RemoveAdditionalCoverage(coverage: string): void {
        this.GLPENTITY.RemoveAdditionalCoverage(coverage);
    }

	/*
		Discretionary Pricing field disabling functions
	*/
    DisableScheduleField(scheduleStateMinimums: any): boolean {

        if (scheduleStateMinimums == null) {
            return true;
        }

        let totalPolicyPremiumMin = scheduleStateMinimums.policyPremiumMin;
        let totalPolicyPremium = this.POLICYTRANS.APRP;
        let schedulePremiumMin = scheduleStateMinimums.glPremiumMin;
        let glPremium = 0;
        //Schedule credit/debit => "Premises/Operations" and "Products/Completed Operations" 
        this.STATISTICS.filter(x => x.INTCOV == 'OPS' || x.INTCOV == 'PRD').forEach(statObj => {
            glPremium = glPremium + statObj.PREMO
        });        
        // Disable if the glPremium is less than the schedulePremiumMin
        // OR
        // if the totalPolicyPremium is less than the totalPolicyPremiumMin
        //console.log('glPremium? ', glPremium);
        return ((glPremium < schedulePremiumMin || totalPolicyPremium < totalPolicyPremiumMin) && (this.GLPENTITY.GLPSTATEINFO.every(s => s.IRPMOD ==0 || s.IRPMOD == 1)));
    }

    DisableIrpmField(): boolean {
        let premium = 0;
        let stateCode = Number(this.POLICYTRANS.CANSTE);

        let nyCode = 31;
        let irpmNyPremiumMin = 2500;
        let irpmPremiumMin = 500;
        let irpmCoverage = "CPC";

        //IRPM "credit/debit" field 
        this.STATISTICS.filter(x => x.COVERG == 'CPC').forEach(statObj => {
            premium = premium + statObj.PREMO
        });

        // Disable if the state is NY AND the premium us less than the irpmNyPremiumMin.
        // If the state is NOT NY, disable if the premium is less than the general irpmPremiumMin        
        if (stateCode == nyCode && premium < irpmNyPremiumMin && this.CFPENTITY.CFPSTATEINFO.every(s => s.IRPMOD ==0 || s.IRPMOD == 1)) {
            return true;
        }
        else if (stateCode != nyCode && premium < irpmPremiumMin && this.CFPENTITY.CFPSTATEINFO.every(s => s.IRPMOD ==0 || s.IRPMOD == 1)) {
            return true;
        }
        //if no property then disable
        else if (!this.CFPENTITY.CFPLOCATIONS.some(x => x.COVERG == 'CPC')) {
            return true;
        }
        else {
            return false;
        }
    }

    ShowNjDeregField(deregFlag): boolean {
        var premium = this.POLICYTRANS.APRP;
        var stateCode = Number(this.POLICYTRANS.CANSTE);

        var njCode = 29;
        var njPremiumMin = 10000;

        // Hide if state is NOT NJ
        if (stateCode != njCode) {
            return false;
        }

        // Hide if the premium is not greater than the njPremiumMin
        // if (premium <= njPremiumMin) {
        //     return false;
        // }
        if (deregFlag != 'Y') {
            return false;
        }

        // Hide if any GLP location is NOT NJ
        var locCheck: boolean = true;
        var glpLocationsList = this.GLPENTITY.GLPLOCATIONS;
        glpLocationsList.forEach((loc) => {
            if (Number(loc.LOCST) != njCode) {
                locCheck = false;
            }
        });

        return locCheck;
    }

    ShowPaDeregField(deregFlag): boolean {
        var premium = this.POLICYTRANS.APRP;
        var stateCode = Number(this.POLICYTRANS.CANSTE);

        var paCode = 37;
        //var paPremiumMin = 15000;

        // Hide if state is NOT NJ
        if (stateCode != paCode) {
            return false;
        }
        // Hide if the premium is not greater than the njPremiumMin
        // if (premium <= paPremiumMin) {
        //     return false;
        // }        
        if (deregFlag != 'Y') {
            return false;
        }

        // Hide if any GLP location is NOT NJ
        var locCheck: boolean = true;
        var glpLocationsList = this.GLPENTITY.GLPLOCATIONS;
        glpLocationsList.forEach((loc) => {
            if (Number(loc.LOCST) != paCode) {
                locCheck = false;
            }
        });

        return locCheck;
        
    }

    /*    
		Discretionary Pricing getters
	*/
    GetDPScheduleValue(): number {
        let distinctExpModArray = _.uniqBy(this.GLPENTITY.GLPSTATEINFO, "IRPMOD");

        if (distinctExpModArray.length == 0)
            return 0;

        if (distinctExpModArray.length > 1)
            throw Error("More than one IRPMOD value");

        return distinctExpModArray[0].IRPMOD;
    }

    GetDPIrpmValue(): number {
        let distinctIRPMODArray = _.uniqBy(this.CFPENTITY.CFPSTATEINFO, "IRPMOD");

        if (distinctIRPMODArray.length == 0)
            return 0;

        if (distinctIRPMODArray.length > 1)
            throw Error("More than one IRPMOD value");

        return distinctIRPMODArray[0].IRPMOD;
    }

    // GetDPNjDeregValue(): number {
    //     let distinctDRGFACArray = _.uniqBy(this.GLPENTITY.GLPSTATEINFO, "DRGFAC");

    //     if (distinctDRGFACArray.length == 0)
    //         return 0;
    //     if (distinctDRGFACArray.length > 1)
    //         throw Error("More than one DRGFAC value");

    //     return distinctDRGFACArray[0].DRGFAC;
    // }

    GetDPNjPaDeregValue(): number {
        let distinctDRGFACArray = _.uniqBy(this.GLPENTITY.GLPSTATEINFO, "DRGFAC");
        if (distinctDRGFACArray.length == 0)
            return 0;
        if (distinctDRGFACArray.length > 1)
            throw Error("More than one DRGFAC value");
        return distinctDRGFACArray[0].DRGFAC;
    }

	/*
		Discretionary Pricing setters
	*/
    SetDPScheduleValue(value: number) {
        this.GLPENTITY.GLPSTATEINFO.forEach((stateInfo) => {
            stateInfo.IRPMOD = value;
        });
    }

    SetDPIrpmValue(value: number) {
        this.CFPENTITY.CFPSTATEINFO.forEach((stateInfo) => {
            stateInfo.IRPMOD = value
        });
    }

    // SetDPNjDeregValue(value: number) {
    //     this.GLPENTITY.GLPSTATEINFO.forEach((stateInfo) => {
    //         stateInfo.DRGFAC = value;
    //     });

    //     this.CFPENTITY.CFPSTATEINFO.forEach((stateInfo) => {
    //         stateInfo.DRGFAC = value
    //     });

    //     this.IMPENTITY.IMPSTATEINFO.forEach((stateInfo) => {
    //         stateInfo.DRGFAC = value
    //     });
    // }
    
    SetDPNjPaDeregValue(value: number) {
        //console.log('value? ', value);
        this.GLPENTITY.GLPSTATEINFO.forEach((stateInfo) => {
            stateInfo.DRGFAC = value;
        });
        
        if(this.HasPropertyCoverage){
            
            this.CFPENTITY.CFPSTATEINFO.forEach((stateInfo) => {                
                stateInfo.DRGFAC = value
            });
        }
        if (this.IMPENTITY.IMPSTATEINFO.length == 0){
            let impstateinfo = {
                TRANS:  this.QUOTEPOLICYINFORMATION.TRANSACTIONCODE,
                PRMSTE:  this.POLICYTRANS.CANSTE,
                POLICY: this.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER,
                EFFDTE:  this.QUOTEPOLICYINFORMATION.EFFECTIVEDATE,
                EDSDTE:  this.QUOTEPOLICYINFORMATION.ENDORSEMENTNUMBER,
                RCDTYP:  this.QUOTEPOLICYINFORMATION.RECORDTYPE,
                EDSNO:   0,
                DRGFAC:  value
            }
            this.IMPENTITY.IMPSTATEINFO.push(impstateinfo);
        }
        else{
            this.IMPENTITY.IMPSTATEINFO.forEach((stateInfo) => {
                stateInfo.DRGFAC = value
            });
        }        
    }

	/*
		Apply Discretionary Pricing
	*/
    ApplyDiscretionaryPricing(originalPremium: number): number {
        var schedule = ((this.GetDPScheduleValue() == undefined) || (this.GetDPScheduleValue() == 0)) ? 1 : this.GetDPScheduleValue();
        var irpm = ((this.GetDPIrpmValue() == undefined) || (this.GetDPIrpmValue() == 0)) ? 1 : this.GetDPIrpmValue();
        //var njDereg = ((this.GetDPNjDeregValue() == undefined) || (this.GetDPNjDeregValue() == 0)) ? 1 : this.GetDPNjDeregValue();
        var NjPaDereg = ((this.GetDPNjPaDeregValue() == undefined) || (this.GetDPNjPaDeregValue() == 0)) ? 1 : this.GetDPNjPaDeregValue();

        var premium = originalPremium;
        premium = premium * schedule;
        premium = premium * irpm;
        //premium = premium * njDereg;
        premium = premium * NjPaDereg;

        //if (schedule != 1 || irpm != 1 || njDereg != 1) {
        if (schedule != 1 || irpm != 1 || NjPaDereg != 1) {
            return premium;
        }
        else {
            return originalPremium;
        }
    }

    UpdateQuoteStatus(menuClass: MenuClass, quoteChangesDetected: boolean): void {
        // N	New Quote	Brand new pre-filled quote created during business eligibility process.  Once quote is touched it will become Incomplete.
        // I	Incomplete Quote	A partial quote that has yet to be rated; Or a modified quote that contains changes that require a re-rate.  An incomplete quote has no premium.
        // Q	Complete Quote	A quote that is successfully rated and contains a premium.
        // A	Incomplete Application	A completed quote that has partial application data completed.
        // C	Complete Application	A completed quote that has all application data completed.  This status is only achieved on the very last page of the application.
        // S	Submitted Application	A quote that is submitted to the company for policy issuance.  The quote receives a new policy number and can no longer be edited.
        // R	Refer to Company	A completed quote that contains pending referrals that need to be cleared by an underwriter.  This quote cannot be edited until the underwriter has cleared the referrals. 
        /******************************************************************
        ***** Statuses 'U', 'P', 'D', 'F' do not apply to Contractors *****
        ******************************************************************/
        // U	Contact U/W	A WCA quote that is in a complete application state that has been submitted to MIG for review.  Conditions on this quote made it ineligible to submit online, so the application is still sent to MIG for review.  The quote is then unassigned from the account and can be edited. 
        // P	Active Policy	A posted policy that is within its’ current policy term.
        // D	Pending Cancel	An active policy that is pending cancelation due to non-payment.
        // F	Canceled	A posted policy that is within its’ current policy term and has been canceled.

        var PremiumSummaryMenuObjectIndex = menuClass.menuObjectIndex('PremiumSummary');

        if (this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'N') {
            //'N' - New Quote Becomes 'I' - Incomplete Quote
            this.MarkQuoteAsIncomplete();
        }
        else if (this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'R') {
            //Quote is in 'R' - Refer to Company status.
            //'R' - Refer to Company status can only be changed to 'I' - Incomplete Quote status when an underwriter or colleague releases the quote.
            //The 'R' to 'I' status change is done in the /ReleaseQuote api endpoint.
            return;
        }
        else if (PremiumSummaryMenuObjectIndex == menuClass.stepActive) {
            // If a complete quote / incomplete application is loaded on the Premium Summary screen,
            if (this.POLICYTRANS.APRP > 0) {
                // and we have a premium greater than 0, the status should be 'Q' - Complete Quote.
                this.MarkQuoteAsComplete();
            }
            else {
                // and we DO NOT have a premium greater than 0, the status should be 'I' - Incomplete Quote
                menuClass.isQuoteDirty = true;
                this.MarkQuoteAsIncomplete();
            }

        }
        else if ((PremiumSummaryMenuObjectIndex > menuClass.stepActive) && (quoteChangesDetected)) {
            //  If a complete quote / incomplete application is loaded on any screen BEFORE Premium Summary,
            //  'Q' - Complete Quote or 'A' - Incomplete Application
            //  becomes 'I' - Incomplete Quote w/ the premium value set to 0.
            menuClass.isQuoteDirty = true;
            this.MarkQuoteAsIncomplete();
        }
        else if ((this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'I') && (this.POLICYTRANS.APRP > 0)) {
            //  If an incomplete quote has a successful rating and a premium value
            //  'I' - Incomplete Quote becomes 'Q' - Complete Quote
            this.MarkQuoteAsComplete();
        }
        else if ((menuClass.stepActiveObject.name == 'ApplicationComplete') && (this.POLICYTRANS.APRP > 0) &&
            ((this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'C') ||
                (this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'A'))) {
            // If an Incomplete Application is loaded on the 'Application Complete screen',
            // 'A' - Incomplete Application becomes 'C' - Complete Application
            this.MarkAsCompletedApplication();
        }
        else if (
            (PremiumSummaryMenuObjectIndex < menuClass.stepActive) &&
            (quoteChangesDetected) &&
            (this.POLICYTRANS.APRP > 0) &&
            ((this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'Q') || (this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'A') || (this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE == 'C'))
        ) {
            //  If a complete quote / incomplete application is loaded in any screen AFTER Premium Summary,
            //  user has made changes to the quote,
            //  the premium is greater than 0,
            //  and the quote status is 'Q' (Complete Quote), 'A' (Incomplete Application), or 'C' (Complete Application)
            //  'Q' - Complete Quote becomes 'A' - Incomplete Application.
            //  'A' - Incomplete Application remains Incomplete Application
            //  'C' - Complete Application reverts to Incomplete Application
            this.MarkAsIncompleteApplication();

        }
        // Questions
        // What triggers an 'S' - Submitted Application status?
        // What triggers an 'R' - Refer to Company status?  (Possibly Refer to Company button on Referral Screen?)
    }

    private MarkQuoteAsIncomplete() {
        this.LogMessage("Marking quote as incomplete - Status: I - Premium set to 0");
        this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE = 'I';
        this.POLICYTRANS.APRP = 0;
        let count: number = 1;
        this.ADDITIONALINSUREDS.forEach(addIns => {
            if (addIns.ADDCDE == 'G') {
                addIns.RECORDSTATE = 'D';
            }

            if (addIns.RECORDSTATE != 'D') {
                addIns.AINNUM = count.toString().padStart(3,'0');
                count++;
            } 
        });
        
    }

    private MarkQuoteAsComplete() {
        this.LogMessage("Marking quote as complete - Status: Q");
        this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE = 'Q';
    }

    private MarkAsCompletedApplication() {
        this.LogMessage("Marking application as complete - Status: C");
        this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE = "C";
    }

    private MarkAsIncompleteApplication() {
        this.LogMessage("Marking application as incomplete - Status: A");
        this.QUOTEPOLICYINFORMATION.WEBSTATUSCODE = "A";
    }

    private LogMessage(messageToLog: string) {
        let enableLog: boolean = false;
        if ((!(environment.production)) && (enableLog)) {
            console.log(messageToLog);
        }
    }

    HasAdditionalInsureds() {
        return ((_.filter(this.ADDITIONALINSUREDS, additionalInsured => additionalInsured.RECORDSTATE != 'D' && additionalInsured.ADDCDE != 'G').length > 0) ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.OSCNT > 0 ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.GLCNT > 0 ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.IBCNT > 0 ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.LSCNT > 0 ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.EACNT > 0 ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.CACNT > 0 ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.CNCNT > 0 ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.CICNT > 0 ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.OBCNT > 0 ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.ZZCNT > 0 ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.MLCNT > 0 ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.SPCNT > 0 ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.STCNT > 0 ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.VECNT > 0 ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.MTCNT > 0 ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.OWCNT > 0 ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.POCNT > 0 ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.COCNT > 0 ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.GFCNT > 0 ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.LECNT > 0 ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.ENCNT > 0 ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.GSCNT > 0 ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.CPCNT > 0 ||
            this.GLPENTITY.QUOTEPOLICYLIABLIMITS.IXCNT > 0);
    }

    HasPropertyCoverage() {
        let allPropCoverageRecsSetToBeDeleted: boolean = false;
        allPropCoverageRecsSetToBeDeleted = _.every(this.CFPENTITY.CFPLOCATIONS, (location) => {
            return location.RECORDSTATE == 'D';
        });        
        return (this.CFPENTITY.CFPLOCATIONS.length > 0 && !allPropCoverageRecsSetToBeDeleted);
    }

    public HasSubcontractedWorkClass()
    {
        let subcontractedWorkClassCodes: string[] = ['091581', '091582', '091583', '091585', '091591'];
        return this.GLPENTITY.GLCLASSLIST.filter((glClass) => ((subcontractedWorkClassCodes.includes(glClass.CLASX) && glClass.RECORDSTATE != "D"))).length > 0 // 9/10/21: added to filter so we are not including classcode objects with RECORDSTATE == "D" -JTL 
    }

    public changeAddType(fromAddType: string): void {
        //let tmpAI = new ADDITIONALINSURED(this.QUOTEPOLICYINFORMATION, this);
        //tmpAI.changeAddType(fromAddType, toAddType);
        super.changeAddType(fromAddType);
    }

     public updateScheduledAI(addType: string, count: number, secondAddType?: string, secondCount?: number, quote?: IQuote): void {
        //let tmpAI = new ADDITIONALINSURED(this.QUOTEPOLICYINFORMATION, this.ADDITIONALINSUREDS);
         //tmpAI.updateScheduledAI(addType, count, secondAddType, secondCount);
         super.updateScheduledAI(addType, count, secondAddType, secondCount);
     }

     public updateBlanketAI(addType: string, updateRecord: boolean): void {
    //     //let tmpAI = new ADDITIONALINSURED(this.QUOTEPOLICYINFORMATION, this);
    //     //tmpAI.updateBlanketAI(addType, updateRecord);
         super.updateBlanketAI(addType, updateRecord);
     }

     public updateERISA(data:any): void {
         super.updateERISA(data);
     }
     
     public deleteERISA(): void {
        super.deleteERISA();
    }

    public updateScheduledAIData(data: any) {
        super.updateScheduledAIData(data);
    }
}
