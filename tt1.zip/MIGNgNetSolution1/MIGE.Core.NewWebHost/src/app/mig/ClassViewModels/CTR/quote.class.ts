import { QuoteService } from "@services/quote.service";
import { finalize } from "rxjs/operators";
import { MIGSystemService } from "@services/mig.service";
import { MenuClass } from "@root/system/menu/menu";
import { MessageService } from 'primeng/api';
import { CTRQuote } from "./CTRQuote";
import { Injectable, ChangeDetectorRef } from "@angular/core";
import { PipesModule } from "@pipes/pipes.module";
import { PrettyPrintPipe } from "@pipes/pipes";
import { DomSanitizer } from "@angular/platform-browser";


@Injectable()
export class CTRQuoteClass {
	ctrQuote: CTRQuote;
	quoteServiceSubscription: any;
	pipe: PrettyPrintPipe;
	cd: ChangeDetectorRef;

	constructor(
		public quoteService: QuoteService,
		public migsystemservice: MIGSystemService,
		public menuClass: MenuClass,
		public messageService: MessageService,
		// private cdd: ChangeDetectorRef
	) {
		//this.ctrQuote = new CTRQuote();
		
	}


	ApiGetCheck() {

		// console.log('**********************');
		// console.log('contractorsQuote POLICY: ' + this.ctrQuote.POLICYTRANS.POLICY);
		// console.log('contractorsQuote EFFDTE: ' + this.ctrQuote.POLICYTRANS.EFFDTE);
		// console.log('contractorsQuote INSNAM: ' + this.ctrQuote.POLICYTRANS.INSNAM);
		// console.log('contractorsQuote BUSDSC: ' + this.ctrQuote.POLICYTRANS.BUSDSC);
		// console.log('contractorsQuote EDSDTE: ' + this.ctrQuote.POLICYTRANS.EDSDTE);
		// console.log('contractorsQuote EDSNO:  ' + this.ctrQuote.POLICYTRANS.EDSNO);
		// console.log('contractorsQuote INSAD1: ' + this.ctrQuote.POLICYTRANS.INSAD1);
		// console.log('contractorsQuote INSAD2: ' + this.ctrQuote.POLICYTRANS.INSAD2);
		// console.log('contractorsQuote INSAD3: ' + this.ctrQuote.POLICYTRANS.INSAD3);

	}

	funcGetQuote(quote: CTRQuote): any {

		// this.ctrQuote = quote;

		// //GET QUOTE SERVICE CALL
		// this.quoteServiceSubscription = this.quoteService.GetQuote(this.ctrQuote)
		// 	.pipe(finalize(() => this.ApiGetCheck()))
		// 	.subscribe(quoteInfo => {
		// 		let dummy: any = quoteInfo;
		// 		if (dummy.statusCode == "400") {
		// 			console.log("ERROR")
		// 			this.migsystemservice.notifySystemError({ msg: "A fatal system error has occurred.<br>Please contact the development team. <br>Status Code: " + dummy.statusCode + "<br>funcGetQuote Failed<br>", obj: dummy });
		// 		} else {
		// 			//console.log(quoteInfo);
		// 			this.ctrQuote = quoteInfo;
		// 			this.migsystemservice.notifyBlock(this.menuClass.menu[0].block);
		// 			this.migsystemservice.notifyQuoteChanged(quoteInfo);
		// 			return quoteInfo;
		// 		}
		// 	});
	}

	// funcSubscribeSave() {
	// 	this.migsystemservice.subscribeSaveQuote().subscribe(dummy => {
	
	// 		this.migsystemservice.notifyUpdateRecordState();
	
	// 		this.migsystemservice.notifySystemNotification({ severity: 'info', summary: 'Contractors', detail: 'Saving quote. Please wait.', event: "start" })
	// 		let tmp: any;
		
	// 		console.log('funcSubscribeSave? ',this.ctrQuote)
	// 		this.quoteService.SaveQuote(this.ctrQuote).subscribe(quoteInfo => {
	// 			//console.log(quoteInfo);
	// 			this.migsystemservice.notifySystemNotification({ severity: 'success', summary: 'Contractors', detail: 'Quote Saved. ', event: "end" })
	
	// 		}, (error) => {
	// 			this.migsystemservice.notifySystemNotification({ severity: 'error', summary: 'Contractors', detail: 'Quote Save Failed. ', event: "end" })
	
	// 		}, () => {
	
	// 		})
	// 	})
	// }

}
