﻿export class FileMetaData {

    ID:number
    FILENAME: string
    FILESIZE: number
    FILEBINARY: any
    QUOTEID: string
    DESCRIPTION: string
    AGENTNUMBER: string
    STATUS:string
    SENT_TO_IMGRIGHT:number
    CREATEDBY: string
    CREATEDATE: any
    MODIFIEDBY: string
    MODIFIEDDATE: any
}
