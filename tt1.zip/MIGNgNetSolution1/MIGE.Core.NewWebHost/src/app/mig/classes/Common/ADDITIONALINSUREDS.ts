import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';
import { IAdditionalInsureds } from '@interfaces/IAdditionalInsureds';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';
import { IQuote } from '@interfaces/IQuote';
import { CommonQuote } from '@classViewModels/CommonQuote/CommonQuote';


export class ADDITIONALINSURED {
	// Keys
	TRANS: string = "";
	POLICY: string = "";
	EFFDTE: number = 0;
	EDSDTE: number = 0;
	EDSNO:  number = 0;
	AINNUM: string = "";
	RCDTYP: number = 0;

	// New 2-22-2019
	// Finish Application - Name of Plan - ADDCDE = "E"
	ADDCDE: string = "";

	AINRCN: string="";
	// Record Type
	ADDTYP: string = "";

	// Insured's Name First 30 Characters
	AINNAM: string = "";

	// New 2-22-2019 Insured's Name Characters 31-60
	AINNM2: string = "";

	// New 2-22-2019 Insured's Name If more than 30 characters, write to AINNM2 AND AINAM2
	AINAM2: string = "";

	// Street Number
	AINAD1: string = "";

	// New 2-22-2019 Street Name
	AINAD2: string = "";

	// New 2-22-2019 Street Name
	AINAD3: string = "";

	// City
	AINCTY: string = "";

	// State
	AINST: string = "";

	// Zip code
	AINZIP: string = "";

	// Location of covered operations
	LOCOPS: string = "";

	// Designation of premises
	DESPAD: string = "";

	// Your Products
	YORPRD: string = "";

	// Federal Employer ID Number
	FEDEID: string = "";

	/** @param string Record State */
	RECORDSTATE: string = "N";

	//optional parameter to give an IQuote when needed
	//QUOTE: IQuote;
	additionalInsureds: ADDITIONALINSURED[];
	//quotePolicyInfo: QUOTEPOLICYINFO;

	//constructor (quotePolicyInfo: QUOTEPOLICYINFO, quote?: IQuote){
	constructor (quotePolicyInfo: QUOTEPOLICYINFO, additionalInsureds?: ADDITIONALINSURED[]){
		
		this.POLICY = quotePolicyInfo.QUOTEPOLICYNUMBER;
		this.RCDTYP = quotePolicyInfo.RECORDTYPE;
		this.TRANS = quotePolicyInfo.TRANSACTIONCODE.toString();
		this.EFFDTE = quotePolicyInfo.EFFECTIVEDATE;
		this.EDSDTE = quotePolicyInfo.ENDORSEMENTDATE;
		this.EDSNO = quotePolicyInfo.ENDORSEMENTNUMBER;

		//if(quote) this.QUOTE = quote;
		//this.quotePolicyInfo = quotePolicyInfo;
		if(additionalInsureds) this.additionalInsureds = additionalInsureds;
	}
	


	//updates the ERISA AI
	public updateERISA(data: any, qpInfo: QUOTEPOLICYINFO)  {
	
		// if(this.QUOTE instanceof CTRQuote) {

		 	if(!this.additionalInsureds.some(x => x.ADDCDE === 'E')) this.createAI('', qpInfo);

		 	let ERISA = this.additionalInsureds.find(x=> x.ADDCDE === 'E');
		 	ERISA.AINNAM = data.AINNAM;
		 	ERISA.AINAD1 = data.AINAD1;
		 	ERISA.AINAD2 = data.AINAD2;
		 	ERISA.AINCTY = data.AINCTY;
		 	ERISA.AINST = data.AINST;
			ERISA.AINZIP = data.AINZIP;
			ERISA.RECORDSTATE = 'U';
			this.reSequenceAINNUM();
	}
	
	public deleteERISA() {
		this.additionalInsureds.filter(x=> x.ADDCDE === 'E').forEach(item => {
			item.RECORDSTATE = 'D';
		});
	}
	//this changes the ADDTYP type based on what is being selected.
	// public changeAddType( fromAddType: string, toAddType: string) : void {
	
	// 	if(this.QUOTE instanceof CTRQuote) {
	// 		this.QUOTE.ADDITIONALINSUREDS.forEach(item => {
	// 			if(item.ADDTYP === fromAddType) item.ADDTYP = toAddType;
	// 		});
	// 	}
	// }

	public changeAddType(fromAddType: string) : void {
	
		//make sue that this.addionalInsured.length > 0 ;
		this.additionalInsureds.filter(x=> x.ADDTYP === fromAddType).forEach(item => {
			switch(fromAddType) {
				case 'OB' : item.ADDTYP = 'ZZ'; break;
				case 'ZZ' : item.ADDTYP = 'OB'; break;
				case 'CP' : item.ADDTYP = 'IX'; break;
				case 'IX' : item.ADDTYP = 'CP'; break;
			}
		});
		
	}



	//update for Blanket Additional Insureds.
	public updateBlanketAI(qpInfo: QUOTEPOLICYINFO, canSTE: string, addType: string, updateRecord: boolean) : void {

		// if(this.QUOTE instanceof CTRQuote) {
		 	let item = this.additionalInsureds.find(f => f.ADDTYP === addType);
		// 	//if there is no item and we need to add it then do so.
		 	if(!item && updateRecord) this.createAI(addType, qpInfo);

		 	if(item) {
				 item.RECORDSTATE = updateRecord ? 'U' : 'D';
				 item.AINAD1 = '';
				 item.AINAD2 = '';
				 item.AINAD3 = '';
				 item.AINCTY = '';
				 item.AINZIP = '';
		 		//need to update the AINST to the POLICYTRANS Cancel State for Blanket Additional Insureds 
		 		item.AINST = canSTE;
		 	};
		 	this.reSequenceAINNUM();
		// 	this.addPolicyInfo();
		 
	}

	//this should only be taking an additional insured and deleting it -- should not be worried about which one it is.
	private deleteScheduledOrERISAAI(deletedItems: ADDITIONALINSURED[], count: number) : void{

			 //if the index is greater than the count OR the counts are 0, set the recordstate to 'D' since it needs to be deleted, if not, set it to 'U'
			 deletedItems.forEach((item, index) => {
			 	if(index > count - 1){
			 		item.RECORDSTATE = 'D'
				} else {
			 		item.RECORDSTATE = 'U';
			 	}
			 });
	}

	//this updates or adds a scheduled Insured(s) depending on the type
	public updateScheduledAI(qpInfo: QUOTEPOLICYINFO, addType: string, newCount: number, secondAddType?: string, secondNewCount?: number): void {
		
		// if(this.QUOTE instanceof CTRQuote) {
		 	let items = this.additionalInsureds.filter(x => x.ADDTYP === addType || x.ADDTYP === secondAddType);
		 	if(!secondNewCount) secondNewCount = 0;
		 	if(typeof(secondNewCount) === 'string') secondNewCount = parseInt(secondNewCount);

		 	let currentNewCount = typeof(newCount) === 'string' ? parseInt(newCount) + secondNewCount: newCount + secondNewCount;
			

		 	//set all the recordstates back to 'U'
		 	if(currentNewCount >= items.length) {
		 		items.forEach(item => {
		 			item.RECORDSTATE = 'U';
		 		});
		 		//create a new additional insured for each one over
		 		for(let i = 0; i < currentNewCount - items.length; i++) {
					 this.createAI(addType, qpInfo);
		 		}
		 	}
		 	else if(currentNewCount < items.length) {
		 			this.deleteScheduledOrERISAAI(items, currentNewCount);
		 	}
		 	this.reSequenceAINNUM();
		// 	this.addPolicyInfo();
		// }
	}

	//this will update the data from the Scheduled AI being written in the additional info - insureds componen
	public updateScheduledAIData(data: any) {

		//loop through each AI
		this.additionalInsureds.forEach(item => {
			//filter the data that has a key that includes the AI's AINNUM 
			let newData = Object.keys(data).filter(x => x.includes(item.AINNUM));
			if(newData.length) {
				//associate the proper data key for each property with the matching AI property
				item.AINNAM = data[newData.find(key => key.includes("AINNAM"))] || "";
				item.AINAD1 = data[newData.find(key => key.includes("AINAD1"))] || "";
				item.AINAD2 = data[newData.find(key => key.includes("AINAD2"))] || "";
				item.AINAD3 = data[newData.find(key => key.includes("AINAD3"))] || "";
				item.AINCTY = data[newData.find(key => key.includes("AINCTY"))] || "";
				item.AINST =  data[newData.find(key => key.includes("AINST"))]  || "";
				item.AINZIP = data[newData.find(key => key.includes("AINZIP"))] || "";
				item.AINRCN = data[newData.find(key => key.includes("AINRCN"))] || "";
				item.LOCOPS = data[newData.find(key => key.includes("LOCOPS"))] || "";
				item.DESPAD = data[newData.find(key => key.includes("DESPAD"))] || "";
				item.YORPRD = data[newData.find(key => key.includes("YORPRD"))] || "";
			}
		});
	}
	//create a new Additional insured and return it to the caller to be added to the array
	 private createAI(addType: string, qpInfo: QUOTEPOLICYINFO): void {

	// 	if(this.QUOTE instanceof CTRQuote) {
		let tmpAI = new ADDITIONALINSURED(qpInfo);
		tmpAI.ADDTYP = addType;
		tmpAI.RECORDSTATE = 'U';
		//this is an ERISA record if it has no ADDTYP
	    tmpAI.ADDCDE = addType === '' ?  'E': 'A';

		this.additionalInsureds.push(tmpAI);
	}
		
	 

	//we need to skip any AI with a record state of D
	private reSequenceAINNUM(): void {

		// if(this.QUOTE instanceof CTRQuote) {
		 	let count: number = 1;
		 	//we are only incrementing the count if the recordState is not 'D'
		 	this.additionalInsureds.filter(x => x.RECORDSTATE !== 'D').forEach((item) => {
		 		item.AINNUM = count.toString().padStart(3,'0');
		 		count++;
		 	});
		
	}

}
