import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';

export class GLPFORMDATA {
	// used in Finish Application > CG2404 for Contractors
	TRANS: string = "";
	POLICY: string = "";
	EFFDTE: number = 0;
	EDSDTE: number = 0;
	EDSNO: number = 0;	
	RECORDSTATE: string = "N";
	RCDTYP: number = 0;

	NMEORG: string = "";


	constructor (quotePolicyInfo: QUOTEPOLICYINFO){
		
		this.POLICY = quotePolicyInfo.QUOTEPOLICYNUMBER;
		this.RCDTYP = quotePolicyInfo.RECORDTYPE;
		this.TRANS = quotePolicyInfo.TRANSACTIONCODE.toString();
		this.EFFDTE = quotePolicyInfo.EFFECTIVEDATE;
		this.EDSDTE = quotePolicyInfo.ENDORSEMENTDATE;
		this.EDSNO = quotePolicyInfo.ENDORSEMENTNUMBER;				
	}
}
