export class UWREFERRALS {

	// ID
	REFID: string;

	// referral type
	REFTYPE: string;

	// Agent ID
	AGTUSER: string;

	// Agent Response
	AGTRESP: string;

	// Underwriting User Id
	UWUSER: string;

	// Underwriting Response
	UWRESP: string;

	// Status
	STATUS: string;

	// Underwriting Comment
	UWINTCMT: string;

	// Referral Message
	REGMSG: string;

	// Internal Commnets
	INTERNALRESP: string;

	//Need for WINS
	WINSWEBBOTH: string;
}
