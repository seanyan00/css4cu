import { QUOTEPOLICYINFO } from './QUOTEPOLICYINFO';

export class HTTPREQUESTRESPONSE {

	// KEYS
	POLICY: string = "";
	// EFFDTE: number = 0;
	// COVEND: number = 0;
	// RCDTYP: number = 0;
	// EDSDTE: number = 0;
	// EDSNO: number = 0;

	/** @param string RequestTimeStamp */
    HTTPREQUEST: string = "";
	/** @param string ResponseTimeStamp*/
	HTTPRESPONSE: string = "";

	constructor(quotePolicyInfo: QUOTEPOLICYINFO) {
        this.POLICY = quotePolicyInfo.QUOTEPOLICYNUMBER;
        // this.EFFDTE = quotePolicyInfo.EFFECTIVEDATE;
        // this.RCDTYP = quotePolicyInfo.RECORDTYPE;
		// this.EDSDTE = quotePolicyInfo.ENDORSEMENTDATE;
	}
	
}
