import { PolicyMasterAbstract } from '@classes/PolicyMasterAbstract';
import { ADDRESS } from '@shared/address_info/address.class';

export class POLICYTRANS extends PolicyMasterAbstract {

    // KEYS
    /** string WINS TRANSACTION CODE */
    TRANS: string;
    ADDRESS: ADDRESS;
    PRGMID: string; // 4/14/21: the PRGMID field is the FEIN Number used for WCA -JTL
    CLNTID: string; // Client ID used on Finish App in WCA
    CO: string;

	constructor(policyTrans?: POLICYTRANS) {

        super();
        this.ADDRESS = new ADDRESS;
        if ((policyTrans != undefined) && (policyTrans != null))
        {
            Object.assign(this, policyTrans);

            if ((policyTrans.ADDRESS != undefined && policyTrans.ADDRESS != null))
            {
                this.ADDRESS = new ADDRESS(policyTrans.ADDRESS);
            }
        }
		
	}
}