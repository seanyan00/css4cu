import { IQuote } from "@interfaces/IQuote";
import { QUOTEBASECLASS } from "./QUOTEBASECLASS";
import { QUOTEPOLICYINFO } from "./QUOTEPOLICYINFO";
import * as _ from "lodash";


// This class file could be used for common functionality (ex. CRUD functionality) between buildings for CTR, BOP, and any other future product lines which involve a Location/Building Object. 
export class BUILDINGS extends QUOTEBASECLASS {
		// RCDTYP: number = 0;
		LOCNUM: string = "";
		BLDNUM: string = "";
	


	constructor(quote: IQuote ){
		super();
		let quotePolicyInfo: QUOTEPOLICYINFO = quote.QUOTEPOLICYINFORMATION;
		this.POLICY = quotePolicyInfo.QUOTEPOLICYNUMBER;
		this.RCDTYP = quotePolicyInfo.RECORDTYPE;
		this.TRANS = quotePolicyInfo.TRANSACTIONCODE.toString();
		this.EFFDTE = quotePolicyInfo.EFFECTIVEDATE;
		this.EDSDTE = quotePolicyInfo.ENDORSEMENTDATE;
		
	}

	
    deleteDataElementByLocationNumber(dataArray: any[], locNumToDelete: string)
    {
        _.forEach(dataArray, dataElement => {
            if (((dataElement.LOCNUM == locNumToDelete)) && (dataElement.RECORDSTATE != 'D'))
            {
                dataElement.RECORDSTATE = 'D';
            }
        });
    }

	recalculateLocationNumber(dataArray: any[], oldLocNum: string, newLocNum: string)
    {
        _.forEach(dataArray, dataItem => {
            if ((dataItem.RECORDSTATE != 'D') && (dataItem.LOCNUM == oldLocNum))
            {
                dataItem.LOCNUM = newLocNum;
            }
        });
    }
	
}
// Keys

	// AINNUM: string = "";
	// RCDTYP: number = 0;

	// // New 2-22-2019
	// // Finish Application - Name of Plan - ADDCDE = "E"
	// ADDCDE: string = "";

	// AINRCN: string="";
	// // Record Type
	// ADDTYP: string = "";

	// // Insured's Name First 30 Characters
	// AINNAM: string = "";

	// // New 2-22-2019 Insured's Name Characters 31-60
	// AINNM2: string = "";

	// // New 2-22-2019 Insured's Name If more than 30 characters, write to AINNM2 AND AINAM2
	// AINAM2: string = "";

	// // Street Number
	// AINAD1: string = "";

	// // New 2-22-2019 Street Name
	// AINAD2: string = "";

	// // New 2-22-2019 Street Name
	// AINAD3: string = "";

	// // City
	// AINCTY: string = "";

	// // State
	// AINST: string = "";

	// // Zip code
	// AINZIP: string = "";

	// // Location of covered operations
	// LOCOPS: string = "";

	// // Designation of premises
	// DESPAD: string = "";

	// // Your Products
	// YORPRD: string = "";

	// // Federal Employer ID Number
	// FEDEID: string = "";

	// /** @param string Record State */
	// RECORDSTATE: string = "N";

	// //optional parameter to give an IQuote when needed
	// //QUOTE: IQuote;
	// additionalInsureds: ADDITIONALINSURED[];
	// //quotePolicyInfo: QUOTEPOLICYINFO;

	// //constructor (quotePolicyInfo: QUOTEPOLICYINFO, quote?: IQuote){
	// constructor (quotePolicyInfo: QUOTEPOLICYINFO, additionalInsureds?: ADDITIONALINSURED[]){
		
	// 	this.POLICY = quotePolicyInfo.QUOTEPOLICYNUMBER;
	// 	this.RCDTYP = quotePolicyInfo.RECORDTYPE;
	// 	this.TRANS = quotePolicyInfo.TRANSACTIONCODE.toString();
	// 	this.EFFDTE = quotePolicyInfo.EFFECTIVEDATE;
	// 	this.EDSDTE = quotePolicyInfo.ENDORSEMENTDATE;
	// 	this.EDSNO = quotePolicyInfo.ENDORSEMENTNUMBER;

	// 	//if(quote) this.QUOTE = quote;
	// 	//this.quotePolicyInfo = quotePolicyInfo;
	// 	if(additionalInsureds) this.additionalInsureds = additionalInsureds;
	// }
	