import { QUOTEPOLICYINFO } from './QUOTEPOLICYINFO';

export class STATISTICS {

    // KEYS
    TRANS: string = ''
	POLICY: string = '';
	EFFDTE: number = 0;
	COVERG: string = '';
    RCDTYP: number = 0;
    LOCNUM: string = '';
    BLDNUM: string = '';
    CLASX: string = '';
	EDSDTE: number = 0;
	EDSNO: number = 0;
	COMCOV: string = "";
	COLCOV: string = "";
    EXPOSE: number = 0;
    DWETYP: string = "";
    PRMSTE: string = "";
    CDDESC: string = "";
    ASLOB: number = 0;

    CONYR: number = 1;

    

	/** @param string  */
	INTCOV: string = "";

	/** @param string Losses Date of Occurence */
	PREMO: number = 0;
	
	/** @param string Losses Record State */
	RECORDSTATE: string = "N";

	constructor(quotePolicyInfo?: QUOTEPOLICYINFO) {
        if ((quotePolicyInfo != undefined) && (quotePolicyInfo != null))
        {
            this.TRANS = quotePolicyInfo.TRANSACTIONCODE.toString();
            this.POLICY = quotePolicyInfo.QUOTEPOLICYNUMBER;
            this.EFFDTE = quotePolicyInfo.EFFECTIVEDATE;
            this.RCDTYP = quotePolicyInfo.RECORDTYPE;
            this.EDSDTE = quotePolicyInfo.ENDORSEMENTDATE;
        }
        
	}
	
}
