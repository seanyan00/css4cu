import { IBRR } from '@interfaces/IBRR';
import { IProcessBRR } from '@interfaces/IProcessBRR';

export abstract class BusinessRules implements IProcessBRR{
    ProcessBRR(): IBRR {
        throw new Error("Method not implemented.");
    }
}