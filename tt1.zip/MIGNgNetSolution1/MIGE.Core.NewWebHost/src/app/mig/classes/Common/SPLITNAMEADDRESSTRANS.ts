import { SplitNameAddressMasterAbstract } from '@classes/SplitNameAddressMasterAbstract';
export class SPLITNAMEADDR extends SplitNameAddressMasterAbstract {
    // KEYS
    TRANS: string;
    RCDTYP: string;
    
}