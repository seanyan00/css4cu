// Footer for use in a UW Schedule TYPE == table

export class UWSCHEDULETABLEFOOTER {

	// label for footer row
	LABEL?: string;

	// how many columns to span
	COLSPAN?: number;
}
