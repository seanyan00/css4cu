// header row property for a TYPE == table
export class UWSCHEDULETABLEHEADER {
	// label for header column
	LABEL: string;

	// width as a string for column style
	WIDTH?: string;
}
