import { QUOTEPOLICYINFO } from './QUOTEPOLICYINFO';
export class LOSSCLAIM {

	// KEYS
	TRANS: string = "";
	POLICY: string = "";
	EFFDTE: number = 0;
	COVEND: number = 0;
	RCDTYP: number = 0;
	EDSDTE: number = 0;
	EDSNO: number = 0;
    // END KEYS

    LOSNUM: string = "000";
    LOSDTE: number = 0;
    CATCLM: string = "";
    /** @param string Losses Description */
    LOSSDS1: string;
    /** @param string Losses Amount Paid */
    TOTPAID: number = 0;
    /** @param string Losses Amount Reserved */
    TOTRESV: number = 0;
    ACCCLM: string = "AG";
    /** @param string Losses Open Claim */
    CLMSTS: string = "";
    /** @param string Losses Line Of Business */
    LOSLOB: string;
    /** @param string Losses Subrogation */
    LOSSUB: string = "";
    /** @param decimal Losses RPTDTE */
    RPTDTE: number = 0;
	/** @param string Losses Record State */
	RECORDSTATE: string = "N";

	constructor(quotePolicyInfo: QUOTEPOLICYINFO) {
        this.TRANS = quotePolicyInfo.TRANSACTIONCODE.toString();
        this.POLICY = quotePolicyInfo.QUOTEPOLICYNUMBER;
        this.EFFDTE = quotePolicyInfo.EFFECTIVEDATE;
        this.RCDTYP = quotePolicyInfo.RECORDTYPE;
        this.EDSDTE = quotePolicyInfo.ENDORSEMENTDATE;
	}
	
}
