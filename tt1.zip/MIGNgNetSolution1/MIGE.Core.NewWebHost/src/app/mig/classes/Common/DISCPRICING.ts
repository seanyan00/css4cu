export class DISCPRICING {
    STATE: number = 0;
    MIN: number = 0;
    MAX: number = 0;

    constructor(STATE: number, MIN: number, MAX: number) {
        this.STATE = STATE;
        this.MIN = MIN;
        this.MAX = MAX;
    }
}
