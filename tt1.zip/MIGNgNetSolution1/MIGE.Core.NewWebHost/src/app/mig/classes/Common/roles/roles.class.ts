// MIGSecurityRoles
// Class which holds the Roles and Restrictions for the currently authenticated User.
export class MIGSecurityRoles {
	// "Global" setting for Quote Read Only Status
	editable: boolean = false;
	roles: string[] = [];
	// Used to explicity state when a Quote has a rating and therefore has specific
	// control settings on certain views
		// Has Rating
			// Insured Type
				// Corporation OR Limited Liability
					// Disable Specific Quote Info Controls
				// Individual OR Partnership
					// Disable Specific Quote Info Controls AND Insured Personal Information controls
	ratingOverride: MIGSecurityRolesRatingOverride = new MIGSecurityRolesRatingOverride();
	// Used to explicity state when a Quote has a transaction type that requires specific
	// control settings
		// PI (Policy Inquiry) -> Read Only
		// RF (Referral) -> Read Only EXCEPT referral view
	transactionTypeOverride: MIGSecurityRoleTransactionTypeOverride = new MIGSecurityRoleTransactionTypeOverride();
}

// MIGSecurityRole
// Class to handle storing of Role Restrictions including
// TransactionType overrides and Rating overrides
export class MIGSecurityRole {
	editable: boolean;
	roles: string[];
	transactionTypeOverride: MIGSecurityRoleTransactionTypeOverride;
	ratingOverride: MIGSecurityRolesRatingOverride;

	constructor();
	constructor(obj ?){
		this.editable = obj && obj.editable || false;
		this.roles = obj && obj.roles || []
		this.transactionTypeOverride = obj && obj.transactionTypeOverride || new MIGSecurityRoleTransactionTypeOverride();
		this.ratingOverride = obj && obj.ratingOverride || new MIGSecurityRolesRatingOverride();
	}
}

// MIGSecurityRoleTransactionTypeOverride
// Class which'll store whether or not the quote has a transcation type override
// as well as what type of transaction it is to make formGroup control availability easier
export class MIGSecurityRoleTransactionTypeOverride {
	override: boolean;
	transactionType: string;

	constructor();
	constructor(obj?){
		this.override = obj && obj.override || false;
		this.transactionType = obj && obj.transactionType || "";
	}
}

// MIGSecurityRolesRatingOverride
// Class which stores whether or not a rating exists on the quote and will set the override
// to make it easier for formGroup control availability easier
export class MIGSecurityRolesRatingOverride {
	override: boolean;
	insuredType: string;

	constructor();
	constructor(obj?){
		this.override = obj && obj.override || false;
		this.insuredType = obj && obj.insuredType || "";
	}
}