import { UWSCHEDULEFIELDS } from './UWSCHEDULEFIELDS';
import { UWSCHEDULETABLEHEADER } from './UWSCHEDULETABLEHEADER';
import { UWSCHEDULETABLEROW } from './UWSCHEDULETABLEROW';
import { UWSCHEDULETABLEFOOTER } from './UWSCHEDULETABLEFOOTER';

export class UWSCHEDULE {

	// Title of section to create
	SECTION: string;

	// sub label for section heading
	SUBLABEL?: string;

	// Type of section to create - form | table | block
	TYPE: string;

	// Maximum number of rows to allow to be created
	ROWLIMIT?: number;

	// array of fields for TYPE == form || TYPE == block
	FIELDS?: UWSCHEDULEFIELDS[];

	// fields to be used in a TYPE == table header row
	HEADER?: UWSCHEDULETABLEHEADER[];

	// Fields to be used in a TYPE == table row
	ROW?: UWSCHEDULETABLEROW[];

	// fields to be used in a TYPE == table footer row
	FOOTER?: UWSCHEDULETABLEFOOTER[];
}
