import { Validators, UntypedFormControl, UntypedFormGroup } from "@angular/forms";
import * as _ from 'lodash';
import { AppErrors } from '@root/shared_components/errors/app-errors';
import { Functions } from "@helpers/functions";

//There are many repeats of the same validation functionality on various compoonents,
//This class will be the base class for them to get this common functionality
//and then those other classes can extend it with their own specific functionality

export abstract class Validation extends Validators {

    constructor() {
        super();
    }

    //Required Field
    ValidateRequired = (fieldId: string, fieldName: string, noZero?: boolean, isToggle?: boolean) => {
		return (control: UntypedFormControl): AppErrors | null  => {
            //need a special case for toggle switches since we don't get the values passed in, only a true/false value. Need to check to see if it is undefined or and empty string
            if(isToggle) {
                if(control.value == null || control.value === '') return { severity: "error", summary: fieldId, detail: fieldName + " is required", sticky: true, closable: false }
                return null;
            }
            if(noZero) {
                if(control.value === 0 || control.value === '0') return { severity: "error", summary: fieldId, detail: fieldName + " is required", sticky: true, closable: false }
            } 
            if(!control.value || control.value === '') return { severity: "error", summary: fieldId, detail: fieldName + " is required", sticky: true, closable: false }
            //this prevents items from validating true when they are loaded with a 0 or '0' for whatever reason instead of remaining blank
            
            return null; 
        }    
    }
    //Validate required with default/null form
    ValidateRequiredWithDefault = (fieldId: string, fieldName: string, nallValue: string) => {
		return (control: UntypedFormControl): AppErrors | null  => {
            let temp : string = control.value.toString();
         
            if(!control.value || control.value === '' || temp === nallValue) 
                return { severity: "error", summary: fieldId, detail: fieldName + " is required", sticky: true, closable: false }
            return null; 
        }
    }    
    ValidateSpecificNumericValue = (fieldId: string, fieldName: string, specificValue: number) => {
		return (control: UntypedFormControl): AppErrors | null  => {
            if(control.value !== specificValue)
                return { severity: "error", summary: fieldId, detail: fieldName + " must be " + specificValue.toString(), sticky: true, closable: false }
            
            return null; 
        }    
    }

    ValidateEmailAddress = (fieldId: string, fieldName: string) => {
        return (control: UntypedFormControl): AppErrors | null  => {
            
            if (control.value == null || control.value === '')
            {
                return { severity: "error", summary: fieldId, detail: fieldName + " is required", sticky: true, closable: false };
            }

            let emailAddress:string = control.value;
            if (!(emailAddress.match(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/)))
            {
                return { severity: "error", summary: fieldId, detail: fieldName + " must be a valid email address", sticky: true, closable: false };
            }
            
            return null;
        }
    }

    //Validate Min (String or Number)
    ValidateMinValue = (fieldId: string, fieldName: string, min: number | string, message: string, isCurrency: boolean, isPercentage?: boolean) => {
        return (control: UntypedFormControl): AppErrors | null  => {
            
            if (control.value == null) return null;
            let value;
            if(isCurrency || isPercentage){
                value = _.isNumber(control.value) ? control.value : parseInt(control.value.toString().replace(/\D+/g, ''));
            }
            else{
                value = _.toNumber(control.value);
            }

            let amount = isCurrency ? `$${min.toLocaleString()}` : `${min}`;
            if(isPercentage){
                amount = `${min.toLocaleString()}%`
            }
            if (value < min) return {severity: 'error', summary: fieldId, detail: `${fieldName} ${message} ${amount}`, sticky: true, closable: false }
            if (control.value == "" && !isPercentage) return {severity: 'error', summary: fieldId, detail: `${fieldName} ${message} ${amount}`, sticky: true, closable: false } // 5/19/21: used for WCA Exposure field. If the controls value is blank, we treat this as if the value is 0. -JTL 
            return null;
        }
    }
    //Validate current low/hign value e.g. 30000/60000 against passed in limit in form of 10000/40000. 
    //Return error if either 30000 > 10000 or 60000 > 40000. 
    ValidateMaxLimit = (lrange: string, fieldId: string, fieldName: string, message: string) => {
        return (control: UntypedFormControl): AppErrors | null => {
            if(control.value == null) return null;
            
            let tlimit = lrange.split("/");
            let slimit = control.value.split("/");
            if(slimit.length < 2 || tlimit.length < 2)
               return null;

            let tlow : number = parseInt(tlimit[0].replace(/\D+/g, ''));
            let thigh : number = parseInt(tlimit[1].replace(/\D+/g, ''));
            let slow : number = parseInt(slimit[0].replace(/\D+/g, ''));
            let shigh : number = parseInt(slimit[1].replace(/\D+/g, ''));
                       
            if((slow - tlow > 0) || (shigh - thigh > 0))
                return {severity: 'error', summary: fieldId, detail: `${fieldName} ${message} ${lrange}`, sticky: true, closable: false}
              
            return null;
        }
    }

    //Validate Max can take in a String or a Number
    //max can be a number or string value
    //fieldId is the FormControl name
    //fieldName is the FormControl label
    //message is the message you want to display
    //isCurrency specifies whether the value is a currency or not
    ValidateMaxValue = (max: number | string, fieldId: string, fieldName: string, message: string, isCurrency: boolean, isPercentage?:boolean) => {
		return (control: UntypedFormControl): AppErrors | null => {
            let value;
            if (control.value == null) return null;
            if(isCurrency || isPercentage){ // If our form control is in the form of a currency, we want to replace the dollar sign and commas with blank spaces, to just get the number.
                value = _.isNumber(control.value)  ? control.value : control.value.toString().replace(/\D/g, '');
            }
            else{
                value = _.toNumber(control.value); // 6/22/21 if our control is not in the form of a currency, we simply convert the control value to a number -JTL
            }
            let amount = isCurrency ? `$ ${max.toLocaleString()}` : `${max}`;
            if(isPercentage){
                amount = `${max.toLocaleString()}%`
            }
			if (value > max) return { severity: "error", summary: fieldId, detail: `${fieldName} ${message} ${amount}`, sticky: true, closable: false } 
			return null;
		}
    }

    ValidateMinLength = (min: number,  fieldId: string, fieldName: string) =>  {
        return(control: UntypedFormControl): AppErrors | null => {
            if(control != null){ // 9/22/21: added nullcheck -JTL
                if(control.value.length < min) return {severity: 'error', summary: fieldId, detail: `${fieldName} must be at least ${min} characters long`, sticky: true, closable: false}
            }
            return null;
        }
    }

    ValidateMaxLength = (max: number, fieldId: string, fieldName: string) => {
        return(control: UntypedFormControl): AppErrors | null => {
            if(control.value != null){ // 9/22/21: added nullcheck -JTL
                if(control.value.length > max) return {severity: 'error', summary: fieldId, detail: `${fieldName} cannot be more than ${max} characters long`, sticky: true, closable: false}
            }
            return null;
        }
    }

    
    //Validate between 2 values
    ValidateRequiredMinMax = (fieldId: string, fieldName: string, min: number | string, max: number | string) => {
		return (control:UntypedFormControl): AppErrors | null => {
            var val = _.isNumber(control.value) ? control.value : control.value.toString().replace(/\D/g, '');
            let msg =  fieldName + " is required and should be a length of " + min + " to " + max + "."; 
            if(min == max){ // 4/16/21: if a field is a required and must have a specific length, (ex: FEIN number), we trim the message so the error message makes more sense. -JTL
                msg =  fieldName + " is required and should be a length of " + max + "."
            }
			if (val.length > max || val.length < min) return { severity: "error", summary: fieldId, detail: msg, sticky: true, closable: false };
			return null;
		  };
    }

    //Date Range validation
    ValidateWithinDateRange = (fieldId: string, fieldName: string, yearRange: string) => {
        return (control: UntypedFormControl): AppErrors | null => {
            let dateInput: any = control.value;
            if ((dateInput == null) || (dateInput == 0))
                return null;
            
            let years:string[] = yearRange.split(':');
            let yearStart:number = parseInt(years[0]);
            let yearEnd:number = parseInt(years[1]);
            let selectedYear:number = new Date(dateInput).getFullYear();
            
            if ((yearStart > selectedYear) || (selectedYear > yearEnd))
                return { severity: "error", summary: fieldId, detail: fieldName +  " must be a date between the years " + yearStart.toString() + " and " + yearEnd.toString(), sticky: true, closable: false }

            return null
        }
    }

     //Required Date Range validation
     ValidateRequiredWithinDateRange = (fieldId: string, fieldName: string, yearRange: string) => {
        return (control: UntypedFormControl): AppErrors | null => {
            let dateInput: any = control.value;
            let years:string[] = yearRange.split(':');
            let yearStart:number = parseInt(years[0]);
            let yearEnd:number = parseInt(years[1]);
            let selectedYear:number = new Date(dateInput).getFullYear(); // This returns controls value -1 for some reason -ZJG
            selectedYear++;
            if ((dateInput == null) || (dateInput == 0) || (dateInput.length < 4)) //since it's required we need to make sure control value is a 4 didgits -ZJG
                return { severity: "error", summary: fieldId, detail: fieldName +  " is required and must be a date between the years " + yearStart.toString() + " and " + yearEnd.toString(), sticky: true, closable: false }
            
            if ((yearStart > selectedYear) || (selectedYear > yearEnd))
                return { severity: "error", summary: fieldId, detail: fieldName +  " is required and must be a date between the years " + yearStart.toString() + " and " + yearEnd.toString(), sticky: true, closable: false }

            return null;
        }
    }

    //Date validation
    ValidateBusinessStartDate = (fieldId: string, fieldName: string, latestPossibleValidBizStartDate: Date) => {
        return (control: UntypedFormControl): AppErrors | null => {
            let dateInput: any = control.value;
            let selectedDate:Date = new Date(dateInput);

            if ((selectedDate > latestPossibleValidBizStartDate)  || (dateInput == 0) || (dateInput == null))
                return { severity: "error", summary: fieldId, detail: fieldName +  " must be at least 3 years prior to the effective date.", sticky: true, closable: false }

            return null
        }
    }

    ValidateDateIsBeforeDate = (fieldId: string, fieldName: string, latestPossibleDate: Date) => { // this validator can be used to ensure a selected date is before a particular date. 
        // the control is invalid if its date is past our latest possible date.
        return (control: UntypedFormControl): AppErrors | null => {
            let func = new Functions();
            let dateInput: Date = control.value;
            let selectedDate:Date = new Date(dateInput);
            let latestDateFormat = func.funcDateSelected(latestPossibleDate);
            let selectedDateFormat = func.funcDateSelected(selectedDate);
            if ((selectedDateFormat > latestDateFormat) || (dateInput == null)){
                return { severity: "error", summary: fieldId, detail: fieldName +  " must be before " + func.DTEWinsToDisplayFormat(latestDateFormat),  sticky: true, closable: false }
            }
            return null
        }
    }
    //this will trigger the updating of all validation on child form controls in a form group
    TriggerValidation = (formGroup: UntypedFormGroup) => {
        for(let item in formGroup.controls) {
            formGroup.controls[item].updateValueAndValidity({emitEvent: false});
            //if(item === 'BPPDF1') console.log('BPPDF1: ' + formGroup.controls[item]);
        }
    }

    ValidateEmptyField = (fieldId: string, fieldName: string) => {
        return (control: UntypedFormControl): AppErrors | null  => {
            if(control.value === ""){
                return { severity: "error", summary: fieldId, detail: fieldName + " cannot be blank.", sticky: true, closable: false }
            }
        }
    }
    
}