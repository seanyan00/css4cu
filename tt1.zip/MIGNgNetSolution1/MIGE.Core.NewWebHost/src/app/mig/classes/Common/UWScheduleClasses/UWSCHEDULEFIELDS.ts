// Fields for use in a UW Schedule TYPE == form || TYPE == block
export class UWSCHEDULEFIELDS {

	// unique ID of this field
	ID: number;

	// Label for this field
	LABEL: string;

	// small text below label
	SUBLABEL?: string;

	// Type of field - TEXT | SWITCH | CALENDAR
	TYPE: string;

	// Place holder for answer
	ANSWER: string;
}
