
import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';
import { GLClasses } from '@classes/CTR/GLCLASSES';


export class UWQUESTIONSDTO {

	QUOTEPOLICYINFORMATION: QUOTEPOLICYINFO;
	//GLClasses: GLClasses[];    
	GLClassList: GLClasses[] = [new GLClasses];

}

