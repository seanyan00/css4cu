export class RATING{
    RATINGRETURN: RATINGRETURN
    constructor(rating?)
    {
        if (rating != null) {
            Object.assign(this, rating);
            this.RATINGRETURN = new RATINGRETURN(this.RATINGRETURN);
        }
    }
}

export class RATINGRETURN {
    RETURNCODE: string = "";
    RETURNMESSAGE: string = "";
    RETURNPREMIUM: number = 0;
    //** Added 20200921 */
    RETURNDEREGFLAG: string  = ""
    RETURNIRPMFLAG: string  = ""
    RETURNSCHEDULEFLAG: string  = ""

    COVERAGESTOCONSIDER: CoverageToConsider[] = null;
    constructor(ratingReturn?)
    {
        if (ratingReturn != null)
        {
            Object.assign(this, ratingReturn);
            this.instantiateCoveragesToConsider()
        }
    }

    instantiateCoveragesToConsider() {
        let newCoveragesArray: CoverageToConsider[] = [];
        let newCoverage: CoverageToConsider = null;
        this.COVERAGESTOCONSIDER.forEach(coverage => {
            newCoverage = new CoverageToConsider(coverage);
            newCoveragesArray.push(newCoverage);
        });

        this.COVERAGESTOCONSIDER = newCoveragesArray;
    }
}

export class CoverageToConsider {
    INTCOV: string = "";
    COVERG: string = "";
    PREMIUM: number = 0;
    COVERAGENAME: string = "";
    CONSIDER: boolean = false;
    TOOLTIPCODE: string = "";
    TOOLTIPDISPLAY: boolean = false;
    constructor(coverageToConsider?)
    {
        if (coverageToConsider != null)
        {
            Object.assign(this, coverageToConsider);
        }
    }
}