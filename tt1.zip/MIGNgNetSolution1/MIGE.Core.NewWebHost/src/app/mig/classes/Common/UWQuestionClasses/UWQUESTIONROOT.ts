
import { UWQUESTIONSCATEGORY } from './UWQUESTIONCATEGORY'
import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';
             
export class UWQUESTIONROOT {

    UWQUESTIONSCATEGORY: UWQUESTIONSCATEGORY[];
    QUOTEPOLICYINFORMATION: QUOTEPOLICYINFO;
    
    //options: {key: string, value: string}[] = [];
    
    // constructor(options: {} = {}) {
    //     super(options);
    //     this.options = options['options'] || [];
    //   }

}