export class GUIDE {
    
    PRODUCT: string = "";
    CDKEY1: string = "";
    CDKEY2: string = "";
    STATECODE: string = "";
    STATE: string = "";
    CLASSCODE: string = "";
    DESCRIPTION: string = "";
    EFFDTE: number = 0;
    ENDDTE: number = 0;
    FSTTRK: string = "";
    EXPOSURE: string = "";
    SICCDE: string = "";
    IFANY: string = "";
    INJPAY :number = 0;
    eligibility: string = "";
    exposure: string = "";
    exposure_label: string = "";
    expanded: boolean;
}