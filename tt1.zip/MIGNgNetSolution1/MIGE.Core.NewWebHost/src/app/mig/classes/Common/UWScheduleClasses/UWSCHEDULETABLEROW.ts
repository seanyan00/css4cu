// Rows for use in a UW Schedule TYPE == table

export class UWSCHEDULETABLEROW {

	// unique id for field cell
	ID: number;

	// type of field we need - LABEL | TOTAL | TEXT
	TYPE: string;

	// mask for field - currencyMask | percentMask | null
	MASK?: string;

	// placeholder for answer
	ANSWER: string;

	// For row type == TOTAL, array of column indexes [0, 1, 2, etc...] to calculate total against
	COLUMNS?: any[];
}
