import { QUOTEPOLICYINFO } from './QUOTEPOLICYINFO';

export class CONTACTINFOLOSSES {

	// KEYS
	TRANS: string = "";
	POLICY: string = "";
	EFFDTE: number = 0;
	COVEND: number = 0;
	RCDTYP: number = 0;
	EDSDTE: number = 0;
	EDSNO: number = 0;

	/** @param string Losses */
	NOLSIND: string = "";

	/** @param string Losses Date of Occurence */
	LOSDTE: number = 0;

	/** @param string Losses Description */
	LOSDES: string = "";

	/** @param string Losses Amount Paid */
	LOSAMT: number = 0;

	/** @param string Losses Open Claim */
	LOSFLG: string = "";

	/** @param string Losses Amount Reserved */
	LOSRSV: number = 0;

	/** @param string Losses Line Of Business */
	LOSLOB: string = "";

	/** @param string Losses Subrogation */
	LOSSUB: string = "";

	/** @param string Finish App Contact Info Name 1 */
	CNTNAM: string = "";

	/** @param string Finish App Contact Info Phone 1*/
	CNTPHO: string = "";

	/** @param string Finish App Contact Info Type 1*/
	CNPHTY: string = "";

	/** @param string Finish App Contact Info Name 2*/
	CNTNAM2: string = "";

	/** @param string Finish App Contact Info Phone 2*/
	CNTPHO2: string = "";

	/** @param string Finish App Contact Info Type 2*/
	CNPHTY2: string = "";

	/** @param string Losses Record State */
	RECORDSTATE: string = "N";

	constructor(quotePolicyInfo: QUOTEPOLICYINFO) {
        this.TRANS = quotePolicyInfo.TRANSACTIONCODE.toString();
        this.POLICY = quotePolicyInfo.QUOTEPOLICYNUMBER;
        this.EFFDTE = quotePolicyInfo.EFFECTIVEDATE;
        this.RCDTYP = quotePolicyInfo.RECORDTYPE;
		this.EDSDTE = quotePolicyInfo.ENDORSEMENTDATE;
	}
	
}
