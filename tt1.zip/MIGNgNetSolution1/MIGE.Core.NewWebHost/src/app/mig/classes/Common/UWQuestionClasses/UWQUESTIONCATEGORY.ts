import { UWQUESTION } from './UWQUESTION'


export class UWQUESTIONSCATEGORY {
   
    public UWQUESTIONSCATEGORY(){ }
    
    CATEGORY: string = "";
    UWQUESTIONS:UWQUESTION[];    
    
    //options: {key: string, value: string}[] = [];
    
    // constructor(options: {} = {}) {
    //     super(options);
    //     this.options = options['options'] || [];
    //   }

}

