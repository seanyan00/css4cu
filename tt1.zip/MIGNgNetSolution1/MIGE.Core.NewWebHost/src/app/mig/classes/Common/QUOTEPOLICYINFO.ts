export class QUOTEPOLICYINFO {
    AGENTNUMBER: string = "";
    AGENTNAME: string = "";
    EMAIL: string = "";
	EFFECTIVEDATE: number = 0;
    ENDORSEMENTNUMBER: number = 0;
    ENDORSEMENTDATE: number = 0;
	QUOTEPOLICYNUMBER: string = "";
    RECORDTYPE: number = 0;
    TRANSACTIONCODE: string = "";
    TRANSACTIONTYPE: string = "";
    TRANSACTIONDATE: number = 0;
    WEBACCOUNTNUMBER: string = "";
    WEBACCOUNTNAME: string = "";
    WEBSTATUSCODE: string = "";
    CLASSCODEINFO:any; //added as an object on backend 20190813
    AGENTLICENSEDSTATES: any[];
    NEWEFFECTIVEDATE: number = 0;
    CLASSCODE: string = "";
    EODATEBUSINESSSTARTED: number = 0;
    DPWORKSHEETEFFDTE: number = 0;
    DPWORKSHEETPOLICY:boolean;
    MINPRE: number = 0; // 4/21/22: added MINPRE for WCA Discretionary pricing -JTL
    WCNYMERITFACTORDTE: number //added to check NY merit factor date and make configurable
}
