
export class UWQUESTION {

	ID: number;
	PARENTID: number;
	ACCORDLOC: string;
	CLASSCODE: string;
	STATES: string;
	QUESTION: string;
	QUESORDER: number;
	ELEMENTTYPE: string;
	ANSWER: string;
	MULTIANSWER: string;
	DATAFORMAT: string;
	CONDITION: string;
	REQUIRED: string;
	DATATYPE: number;
	DATALENGTH: number;
	SUBQUESTION: UWQUESTION[];
	OPTIONS: any[];
	FORMSTATUS: boolean;
	VISABLE: string;
	FASTTRACK: string;
	TAB: string;
	REFERRALS: string;
	PRODUCTID: string;
	REMARKS: string;
	MESSAGE:string;
	STOPQUOTE: string;
	
	// constructor(options: {
	//     id?: string,
	//     question?: string,
	//     order?: number,
	//     elementType?: string,
	//     answer?: string,
	//     rule?: string,
	//     datatype?:string,
	//     datalength?:string,
	//     subQuestions?: Question[]

	//   } = {}) {

	//     this.id = options.id;
	//     this.question = options.question;
	//     this.order= options.order;
	//     this.elementType= options.elementType;
	//     this.answer= options.answer;
	//     this.rule= options.rule;
	//     this.datatype= options.datatype;
	//     this.datalength= options.datalength;
	//     this.subQuestions =options.subQuestions;
	// }

}
