﻿
/* ****************************************************************************************************
* PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS - SEE LIBRARY AND TABLE/FILENAME
* AS400 LIBRARY        - DVDTA
* TABLE/FILENAME       - DWXP010
* DESCRIPTION          - Policy Master File
* DATE CREATED         - 5/16/2018 6:59:44 AM
* AUTHOR               - RICHARD FUMERELLE
* VERSION              - 1.0
* CODE GENERATION      - Automatic code generation using CodeSmith GenerationTool
* NOTES                - This table can be modified.
****************************************************************************************************/

export abstract class PolicyMasterAbstract {

    // KEYS
    POLICY: string = "";
    EFFDTE: number = 0;
    EDSNO: number = 0;
    EDSDTE: number = 0;
    EXPDTE: number = 0;
	RCDTYP: number = 0;
    /** @param string Insured Name 1 */
    INSNAM: string = "";

    /** @param string Split NameAddr Flag */
    NMADIN:string = "";

    /** @param string Insured Address line 1 */
    INSAD1: string = "";

    /** @param string Insured Address Line 2 */
    INSAD2: string = "";

    /** @param string Insured Address Line 3 */
    INSAD3: string = "";

    /** @param string City */
    INSCTY: string = "";

    /** @param string State */
    INSST: string = "";

    /** @param string Zip Code */
    INSZIP: string = "";

    /** @param string Phone # */
    INSTEL: string = "";

    /** @param string Insured Type */
    INSTYP: string = "";

    // TODO: RRF - FEDID doesn't exist in DWXP110
    /** @param string SS# / TaxID */
    FEDID: string = "";

    /** @param string BUSINESS DESCRIPTION */
    BUSDSC: string = "";

    /** @param string POLICY PREMIUM */
    PREDST: string = "";

    /** @param string POLICY PREMIUM */
    APRP: number = 0; //<--- updated to this field from POLPRE 20190603
    //POLPRE: number = 0;

    /** @param string Record State */
    RECORDSTATE: string = "N";

    /** @param string Cancel State */
    CANSTE: string = "";

    /** @param string Apply Account Credit?  "ACCTCREDIT" or "" only two valid values */
    RELPOL: string = "";
    /**@param string Quote Description
     * Per John Salvisburg:
     * The quote description needs to be mapped to field EDMNTS in DWXP110.
     * The value of this field for this quote is blank.
     * When the description is blank the insured name is used in it's place.
     * Need to reassign to .NET team to correct this field mapping.*/
    EDMNTS: string = "";

    constructor() { }

}

