import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';
import { CTRBASECLASS } from './CTRBASECLASS';

export class CFPCOVERAGES extends CTRBASECLASS {
	COVEND: number = 0;

	EDSNO: number = 0;

	COVERG: string = "CPC";

	/** @param number Property Coverage - Accounts Receivable - On Premises / Off premises */
	ACRON: number = 0;

	/** @param number  */
	ACROF: number = 0;

	/** @param number Property Coverage - Business Personal Property Temporarily in Portable Storage Units */
	BPPTMP: number = 0;

	/** @param number Property Coverage Employee Theft */
	ETFTLM: number = 0;

	/** @param number Property Coverage - Forgery or Alteration */
	FALTLM: number = 0;

	/** @param number Property Coverage - Money and Securities - Inside the Premises/Outside the premises */
	MNSILM: number = 0;

	/** @param number  */
	MNSOLM: number = 0;

	/** @param number Property Coverage - Outdoor Property */
	OUTPRP: number = 0;

	/** @param number Property Coverage - Outdoor Signs */
	OUTSNL: number = 0;

	/** @param string  */
	INFGRD: string = "";

	/** @param number Property Coverage - Communication Equipment */
	COMEQP: number = 0;

	/** @param number Property Coverage - Debris Removal 25% Building Plus */
	DBRRMV: number = 0;

	/** @param string Property Coverage - Business Income Changes - Beginning of the Period of Restoration */
	BINTIM: string = "";

	/** @param string Property Coverage - Earthquake */
	EQUAKE: string = "";

	/** @param string Property Coverage - Electronic Data Processing Equipment */
	EDPELM: number = 0;
	
	/** @param string Property Coverage - Number of employees */
	RATEMP:number = 0; 

	/** @param string Valuable Papers - On Premises */
	VLPONL:number = 0; 
	
	/** @param string Valuable Papers - Off Premises */
	VLPOFL:number = 0; 
	

	/** @param string  */
	RECORDSTATE: string = "N";

	constructor (quotePolicyInfo: QUOTEPOLICYINFO){
		super();
		//console.log('CFPCOVERAGES class constructor? ', quotePolicyInfo);
		this.POLICY = quotePolicyInfo.QUOTEPOLICYNUMBER;
		this.RCDTYP = quotePolicyInfo.RECORDTYPE;
		this.TRANS = quotePolicyInfo.TRANSACTIONCODE.toString();
		this.EFFDTE = quotePolicyInfo.EFFECTIVEDATE;
		this.EDSDTE = quotePolicyInfo.ENDORSEMENTDATE;
		this.EDSNO = quotePolicyInfo.ENDORSEMENTNUMBER;

	}
}
