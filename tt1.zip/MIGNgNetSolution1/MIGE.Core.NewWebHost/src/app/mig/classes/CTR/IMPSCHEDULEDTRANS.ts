import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';
import { CTRBASECLASS } from './CTRBASECLASS';
/*

RRF - 2019-05-22 Added defaults for COVERG and SEQNCE

*/
export class IMPSCHEDULEDTRANS  extends CTRBASECLASS{
	// DWIP141 IMP SCHEDULED TRANSACTIONS


	//Premium state
	PRMSTE: string = "";

	// Location Number
	LOCNUM: string = "";

	// Building number
	BLDNUM: string = "";

	// Coverage
	COVERG: string = "CEQ";

	// Mortgagee Number
	MRTGNO: string = "";

	// Item No
	ITEMNO: string = "";

	// Request Sequence
	SEQNCE: number = 1;

	EDSNO: number = 0;
	
	// Item Description
	ITEMDC: string = "";

	// coverage ending date
	COVEND: number = 0;

	RECORDSTATE: string = 'N';

	constructor(quotePolicyInfo: QUOTEPOLICYINFO) {
		super();
		this.POLICY = quotePolicyInfo.QUOTEPOLICYNUMBER;
		this.RCDTYP = quotePolicyInfo.RECORDTYPE;
		this.TRANS = quotePolicyInfo.TRANSACTIONCODE.toString();
		this.EFFDTE = quotePolicyInfo.EFFECTIVEDATE;
		this.EDSDTE = quotePolicyInfo.ENDORSEMENTDATE;
		this.EDSNO = quotePolicyInfo.ENDORSEMENTNUMBER;
		
	}

}
