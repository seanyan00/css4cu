import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';
import { CTRBASECLASS } from './CTRBASECLASS';
//import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
//import { error } from '@angular/compiler/src/util';
import { GLPLOCATION } from './GLLOCATION';
//import {JsonIgnore} from 'json-object-mapper';

export class GLPLIABILITIES extends CTRBASECLASS {
	// KEYS
	COVEND: number = 0;
	EDSNO: number = 0;
	COVERG: string = "";

	/** @param string Liability - Employment Practices Liability */
	EPILIM: string = "";

	/** @param string Liability - Employment Practices Liability > Deductible */
	EPIDED: string = "";

	/** @param string Liability - EPLI ORIGINAL DATE */
	EPIOID: number = 0;

	/** @param string Liability - Third Party Coverage Endorsement */
	EPITPC: string = "0"

	/** @param string Liability - Contractors E&O Limits */
	C01PCA: string = "0";

	/** @param string  */
	C01AGR: string = "0";

	/** @param string Liability - Contractors E&O Deductible */
	C01DED: string = "";

	/** @param number Liability - Contractors E&O Retro Date */
	C01RTR: number = 0;

	/** @param number Liability - Cyber Liability Total Limit */
	CYBAGG: number = 0;

	/** @param number Liability - Cyber Liability Retro Date */
	CYBRDT: number = 0;

	/** @param number Liability - Cyber Liability Annual Revenues */
	CYBSAL: number = 0;
	
	/** @param number Liability - Cyber Liability Effective Date */
	CYBEFF: number = 0

	/** @param string Liability - Checkbox Employee Benefits Liability */
	EBPCLM: string = "";

	/** @param string  Liability - Dropdown Employee Benefits Liability */
	EBAGGR: string = "";

	/** @param string Liability - Employee Benefits Liability Deductible */
	EBDED: string = "";

	/** @param number Employee Benefits Liability Retro Date */
    EBRETR: number = 0;
    
    DTBSTR: number = 0;

	/** @param string  */
	RECORDSTATE: string = "N";
	
	//@JsonIgnore()
	private _controllingState: string = "";

	
	/**
	 * @description Locations are required to determine the controlling state of the quote
	 * in order to apply the state specfic business rules for each type of coverage.
	 * @param quotePolicyInfo 
	 * @param coverage
	 * @param locations 
	 */

	constructor (quotePolicyInfo: QUOTEPOLICYINFO, coverage: string, locations: GLPLOCATION[]){
		super();
		this.POLICY = quotePolicyInfo.QUOTEPOLICYNUMBER;
		this.RCDTYP = quotePolicyInfo.RECORDTYPE;
		this.TRANS = quotePolicyInfo.TRANSACTIONCODE.toString();
		this.EFFDTE = quotePolicyInfo.EFFECTIVEDATE;
		this.EDSDTE = quotePolicyInfo.ENDORSEMENTDATE;
		this.EDSNO = quotePolicyInfo.ENDORSEMENTNUMBER;
		this.COVERG = coverage;
		
		//the cancel state is needed from the first location in order to apply state specific rules around
		//liability coverage defaults
		
		if(locations.find(x=>x.LOCNUM === "001" && x.RECORDSTATE != "D") === undefined){
			//throw error("Location 001 is Missing");
		}
		this._controllingState = locations.find(x=>x.LOCNUM === "001" && x.RECORDSTATE != "D").ADDRESS.STATE;
		locations = null;
		this.SetDefaultCoverages();
	}
	
	private SetDefaultCoverages() : void {

		switch(this.COVERG) {
			case "EPL":
				this.SetDefaultEPLCoverages();
				break;
			case "CEO":
				this.SetDefaultCEOCoverages();
				break;
			case "CYB":
				this.SetDefaultCYBCoverages();
				break;
			case "EBL":
				this.SetDefaulEBLCoverages();
				break;
			default:
				//throw error("Invalid GLP Liability Selected");

		}

	}

	//Employee Practices Liability
	private SetDefaultEPLCoverages() : void {
			this.COVEND = 0;
			//Vermont Controlling Sate
			if(this._controllingState ==="44") {
				this.EPILIM = "50000";
				this.EPIDED = "5000";
			}
			else {
				this.EPILIM = "100000";
				this.EPIDED = "10000";
			}
			this.EPIOID =  this.EDSDTE;
			this.EPITPC = "N";
			this.C01PCA = "0";
			this.C01AGR = "0";
			this.C01RTR = 0;
			this.CYBAGG = 0;
			this.CYBRDT = 0;
			this.CYBSAL = 0;
			this.EBRETR = 0;

	}

	//Contractors E & O
	private SetDefaultCEOCoverages() : void {
		this.C01PCA = "10000";
		this.C01AGR = "50000";
		this.C01DED = "1000";
		this.C01RTR = this.EFFDTE;	
		if(this._controllingState =='28'){	//If New Hampshire, these are the defaults we use. 
			this.C01PCA = "100000";
			this.C01AGR = "100000"; 
			this.C01DED = "2500";
		}
	}

	//Cyber Liability
	private SetDefaultCYBCoverages() : void {
		this.CYBAGG = 100000;
		// considered.CYBSAL = ""
		this.CYBRDT = this.EFFDTE;
	}

	//Employee Benefits Liability
	private SetDefaulEBLCoverages() : void {
		this.EBDED = "1000";
	}
}
