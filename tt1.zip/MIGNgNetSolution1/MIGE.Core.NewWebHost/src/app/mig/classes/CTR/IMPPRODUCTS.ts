import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';
import { CTRBASECLASS } from './CTRBASECLASS';
export class IMPPRODUCTS extends CTRBASECLASS {
	// KEYS

	COVEND: number = 0;

	EDSNO: number = 0;


	/** @param number  */
	CTRDED: number = 0;

	/** @param number  */
	DBRRTE: number = 0;

	/** @param number  */
	FUELRT: number = 0;

	/** @param number  */
	RNRRTE: number = 0;

	/** @param number  */
	TRLRTE: number = 0;

	/** @param number  */
	EQPBRT: number = 0;

	/** @param number  */
	EQPRRT: number = 0;

	/** @param number Inland Marine - Contractors Equipment Coverage - Deductibe */
	CTRSCD: number = 0;

	/** @param number Inland Marine - Contractors Equipment Coverage - Coinsurance */
	CTRCNS: string = "";

	/** @param number Inland Marine - Scheduled Tools and Equipment - Total Limit */
	CTRSCL: number = 0;

	/** @param number Inland Marine - Unscheduled Tools and Equipment */
	CTRUPL: number = 0;

	/** @param number Inland Marine - Debris Removal Additional Limit */
	DBRRMV: number = 0;

	/** @param number Inland Marine - Employee Tools and Clothing */
	TCPPEL: number = 0;
	
	/** @param number Inland Marine - Fuel, Accessories and Spare Parts  */
	FUELAC: number = 0;

	/** @param number Inland Marine - Employee Tools and Clothing Per Employee Limit */
	TCPOLL: number = 0;

	/** @param number Inland Marine - Rental Reimbursement */
	RNOOLL: number = 0;

	/** @param string Inland Marine - Replacement Cost Valuation */
	CEQVAL: string = "";

	/** @param string Inland Marine - Down the Hole Endorsement */
	DOWHOL: string = "";

	/** @param number Inland Marine - Trailers and Contents */
	TRLCON: number = 0;

	/** @param number Inland Marine - Equipment Borrowed From Others */
	EQPBOR: number = 0;

	/** @param number Inland Marine - Equipment Leased or Rented From Others */
	EQPRNT: number = 0;

	/** @param number ADDED 20190506 for RATING  - Employee Tools and Clothing Per Employee Limit */
	TCRATE: number = 0;

	/** @param number ADDED 20190506 for RATING  - */
	CTRSCR: number = 0;

	/** @param number ADDED 20190506 for RATING  - */
	CTRUNR: number = 0;	


	/** @param number  */
    RECORDSTATE: string = "N";
    
    constructor(quotePolicyInfo: QUOTEPOLICYINFO) {
		super();
        this.TRANS = quotePolicyInfo.TRANSACTIONCODE.toString();
        this.POLICY = quotePolicyInfo.QUOTEPOLICYNUMBER;
        this.EFFDTE = quotePolicyInfo.EFFECTIVEDATE;
        this.RCDTYP = quotePolicyInfo.RECORDTYPE;
        this.EDSNO = quotePolicyInfo.ENDORSEMENTNUMBER;
        this.EDSDTE = quotePolicyInfo.ENDORSEMENTDATE;
	}

}
