import { CTRBASECLASS } from './CTRBASECLASS';

// DWIP125
export class IMPSTATEINFO extends CTRBASECLASS {
    // KEYS
    EDSNO: number = 0;

    // End keys
    DRGFAC: number = 0;
}
