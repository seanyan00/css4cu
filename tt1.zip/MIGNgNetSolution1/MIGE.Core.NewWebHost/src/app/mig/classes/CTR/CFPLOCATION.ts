import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';
import { ILocation } from '@interfaces/ILocation';
import { CTRBASECLASS } from './CTRBASECLASS';

export class CFPLOCATION extends CTRBASECLASS implements ILocation {

	PRMSTE: string = "";

	EDSNO: number = 0;
	COVERG: string = '';

    FTSHOR: number = 0;
    MLSHOR: number = 0;
	/** @param string Location Number */
	LOCNUM: string = "0";

	/** @param string Building Number */
	BLDNUM: string = "0";

	/** @param string Fire District Name */
	RATCTY: string = "";

	/** @param string Territory */
	TERR: string = "";

	/** @param string Country */
	CONTY: string = "";

	/** @param string Protection Class */
	PRTCLS: string = "";

	/** @param string Feet from Hydrant */
	FTHYDT: string = "";

	/** @param string Miles from Fire Department */
	FDMILE: string = "";

	/** @param string Fire Alarm */
	FIRALM1: string = "";

	/** @param string Fire Alarm */
	FIRALM2: string = "";

	/** @param string  Fire Protective Safeguards Array for back-end*/
	//FIRALMLIST:string[] =[];

	/** @param string Burglar Alarm */
	BURGAL1: string = "";

	/** @param string Burglar Alarm */
	BURGAL2: string = "";

	/** @param string Burglar Alarm */
	BURGAL3: string = "";

	/** @param string Burglary and Robbery Protective Safeguards Array for back-end*/
	//BURGALLIST:string[] = [];

	/** @param string Sprinklered building */
	SPRINK: string = "";

	/** @param string Building Occupancy Class */
	BLDCLS: string = "";

	/** @param string Building Occupancy Class */
	//BLDCLS2: string = "";

	/** @param string Building Occupancy Class */
	//BLDCLS3: string = "";

	/** @param string Building Occupancy Class Array for back-end*/
	BLDCLSLIST: string[] = [];

	// single occupancy
	SNGOFG: string = "";

	/** @param string Building Deductable */
	//BLDDED: string = "0"; 
	//UPDATED TO BELOW 20190619
	BLDGDD: number = 0;

	/** @param string Wind Deductable */
	WNDDCT: string = "0";

	/** @param string Alarm Credit */
	BPPACR: string = "";

	/** @param string Construction Type */
	CONSYM: string = "";

	/** @param string Year of Original Construction */
	CONYR: string = "0";

	/** @param string Building Limit */
	BLDLM1: number = 0; //<-- decimal on backend

	/** @param string Valuation */
	BLDVAL: string = "";

	/** @param string Building Coinsurance */
	BLDCIN: string = "";

	/** @param string Building Cause of Loss */
	BLDCOL: string = "";

	/** @param string Wind Protection Device */
	WINDEV: string = "";

	/** @param string BPP Limit 1 */
	BPPLM1: number = 0;

	/** @param string BPP Theft Exclusion */
	BPPTFE: string = "";

	/** @param string BPP Valuation 1 */
	BPPVN1: string = "";

	/** @param string BPP Coinsurance 1 */
	BPPCN1: string = "";

	/** @param string BPP Cause of Loss */
	BPPCOL: string = "";


	/** @param string  */
	UTLSVC: number = 0;


	/** @param string  */
	BLDLM2: number = 0;

	/** @param string Peak Season Limit of Insurance -> Row 1 - Period From */
	BPPDF1: number = 0;

	/** @param string Peak Season Limit of Insurance -> Row 1 - Period To */
	BPPDT1: number = 0;

	/** @param string Peak Season Limit of Insurance -> Row 1 - Covered Property */
	P1230CVPP: string = '';

	/** @param string Peak Season Limit of Insurance -> Row 1 - Additional Limit of Insurance */
	BPPSL1: number = 0 ;

	/** @param string Peak Season Limit of Insurance -> Row 2 - Period From */
	BPPDF2: number = 0;

	/** @param string Peak Season Limit of Insurance -> Row 2 - Period To */
	BPPDT2: number = 0;

	/** @param string Peak Season Limit of Insurance -> Row 2 - Covered Property */
	P1230CV1P: string = '';

	/** @param string Peak Season Limit of Insurance -> Row 2 - Additional Limit of Insurance */
	BPPSL2: number = 0;


	/** @param string  Scheduled Building Property Tenants Policy */
	BLDTP1: string = "";

	/** @param string Unscheduled Building Property Tenants Policy */
    BLDTP2: string = "";
    
    TAXTWN: string = "";
    TAXCTY: string = "";

	//THIS FIELD IS BEING USED FOR THE CP 1219 ADDITIONAL INSURED
	//SO WE CAN ASSSOCIATE THEM WITH THE CORRECT LOCNUM/BLDNUM
	//FIELD WAS OK'D TO USE BY KEVIN
	//CCPALL:number = 0;

	RECORDSTATE: string = "N";

	constructor (quotePolicyInfo: QUOTEPOLICYINFO){
		super();
		this.POLICY = quotePolicyInfo.QUOTEPOLICYNUMBER;
		this.RCDTYP = quotePolicyInfo.RECORDTYPE;
		this.TRANS = quotePolicyInfo.TRANSACTIONCODE.toString();
		this.EFFDTE = quotePolicyInfo.EFFECTIVEDATE;
		this.EDSDTE = quotePolicyInfo.ENDORSEMENTDATE;
		this.EDSNO = quotePolicyInfo.ENDORSEMENTNUMBER;

	}

    hasTerritoryInfoPopulated(): boolean {
        return (this.TERR != ""
        && (this.FTSHOR != 0 || this.MLSHOR != 0)
        && this.TAXCTY != ""
        && this.PRTCLS != ""
        && this.RATCTY != ""
        //Missing CONTY sometimes...?
        //&& this.CONTY != ""
        );
    }

}
