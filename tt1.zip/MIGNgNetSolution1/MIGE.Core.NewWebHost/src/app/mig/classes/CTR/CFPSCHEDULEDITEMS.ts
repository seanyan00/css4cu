import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';
import { IScheduledItem } from '@interfaces/IScheduledItems'
import { CTRBASECLASS } from './CTRBASECLASS';
/*

RRF - 2019-05-22 ADDED EDSNO, Default COVERG
RRF - 2019-05-22 ADDED Constructor and Record State Property

*/

export class CFPSCHEDULEDITEMS extends CTRBASECLASS implements IScheduledItem {
	// DWFP141
	EDSNO: number = 0;

	// Coverage Part
	COVERG: string = "CPC";


	// Location Number
	LOCNUM: string = "";

	// Building Number
	BLDNUM: string = "";

	// Mortgagee Nmber
	MRTGNO: string = "";

	// Premium State
	PRMSTE: string = "";

	// MISC Sequence
	MSCSEQ: string = "";

	// Request Sequence
	SEQNCE: number = 0;

	// Schedule of Item
	SCHITM: string = "";

	// Coverage Ending Date
	COVEND: number = 0;

	/** @param string Record State */
	RECORDSTATE: string = "N";

	//Mortgage Type Coverage
	MRTGTPCOVERG: string = "";
	
	/*these fields are not used an only exist to support the interface of IScheduledItems */
	ITEMNO: string;
    ITEMDC: string;
    ITMMYR: number;

	constructor(quotePolicyInfo: QUOTEPOLICYINFO){
		super();
		this.POLICY = quotePolicyInfo.QUOTEPOLICYNUMBER;
		this.RCDTYP = quotePolicyInfo.RECORDTYPE;
		this.TRANS = quotePolicyInfo.TRANSACTIONCODE.toString();
		this.EFFDTE = quotePolicyInfo.EFFECTIVEDATE;
		this.EDSDTE = quotePolicyInfo.ENDORSEMENTDATE;
		this.EDSNO = quotePolicyInfo.ENDORSEMENTNUMBER;
	}

}
