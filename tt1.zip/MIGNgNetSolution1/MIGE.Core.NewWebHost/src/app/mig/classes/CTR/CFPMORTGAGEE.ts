import { IMortgagee } from '@interfaces/IMortgagee';
import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';
import { CTRBASECLASS } from './CTRBASECLASS';

/* 
RRF - 2019-05-22 Added default for COVERG
*/

export class CFPMORTGAGEE extends CTRBASECLASS implements IMortgagee {
	// For Finish Application
	// For Property Coverage
	// DWFP140
	// KEYS
	EDSNO: number = 0;
	
	COVERG: string = "CPC";
	LOCNUM: string = "";
	BLDNUM: string = "";
	MRTGNO: string = "";

	// Mortgagee Type
	MRTGTP: string = "";

	// Mortgage Coverage
	MRTGTPCOVERG: string = "";
	
	// Mortgagee Name
	MRTGNM: string = "";

	// Second Mortgagee Name
	MRTNM2: string = "";

	// Mortgagee Address Line 1
	MRTGA1: string = "";

	// Mortgagee Address Line 2
	MRTGA2: string = "";

	// Mortgagee Address Line 3
	MRTGA3: string = "";

	// Mortgagee City
	MRTGCT: string = "";

	// Mortgagee State
	MRTGST: string = "";

	// Mortgagee Zipcode
	MRTGZP: string = "";

	// Mortgagee Description
    MRTITD: string = "";
    
    RECORDSTATE: string = "N";

	constructor (quotePolicyInfo: QUOTEPOLICYINFO){
		super();
		this.POLICY = quotePolicyInfo.QUOTEPOLICYNUMBER;
		this.RCDTYP = quotePolicyInfo.RECORDTYPE;
		this.TRANS = quotePolicyInfo.TRANSACTIONCODE.toString();
		this.EFFDTE = quotePolicyInfo.EFFECTIVEDATE;
		this.EDSDTE = quotePolicyInfo.ENDORSEMENTDATE;
		this.EDSNO = quotePolicyInfo.ENDORSEMENTNUMBER;

	}

}

