//DWGFP130
import { CFPLOCATION } from './CFPLOCATION';
import { GLClasses } from './GLCLASSES';
import { ADDRESS, ADDRESSTERRITORY } from '@shared/address_info/address.class';
import { CTRBASECLASS } from './CTRBASECLASS';
export class GLPLOCATION extends CTRBASECLASS {

	// START KEYS


	/** @param string Premium State */
	PRMSTE: string = "";

	/** @param string Coverage Part */
	COVERG: string = "";

	/** @param string Location # */
	LOCNUM: string = "0";

	/** @param string Building # */
	BLDNUM: string = "0";

	// END KEYS

	/** @param string Record State */
	RECORDSTATE: string = "N";

	/** @param string Street Number */
	STRNO: string = "";

	/** @param string Street Name */
	STRNME: string = "";

	/** @param string Suite # */
	SUITE: string = "";

	/** @param string City */
	LOCCTY: string = "";

	/** @param string State */
	LOCST: string = "";

	/** @param string Location Zip Code */
	LOCZIP: string = "";

	/** @param string Territory */
	TERR: string = "";

	/** @param string Miles to shore */
	MLSHOR: number = 0;

	/** @param string Feet to shore */
	FTSHOR: number = 0;

	/** @param string Building Occupancy Class Option */
	ANARLS: string = '';

	EDITLOCATION: boolean = true;

	/** @param class Address Class */
    ADDRESS: ADDRESS = new ADDRESS;
    PROPERTYCOVERAGEINFO: ADDRESSTERRITORY = null;

	WNDZNE: number = 0; 
	LOCATN : string = ""; 
	DESPRM: string = ""; 
	//Used to save AddressLine2 
	LOCAD2: string = "";
	/** @param class GL Classes List */
	// GLClassList: GLClasses[] = [new GLClasses];
	// GLClassList: GLClasses = new GLClasses;

	/** @param class Property Coverage / Building List */
	// CFPLOCATIONS: CFPLOCATION[] = [new CFPLOCATION];

}
