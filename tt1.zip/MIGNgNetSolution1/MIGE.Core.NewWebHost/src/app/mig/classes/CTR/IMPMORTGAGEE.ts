import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';
import { CTRBASECLASS } from './CTRBASECLASS';
/*

RRF - 2019-05-22 Default COVERGE

*/
export class IMPMORTGAGEE extends CTRBASECLASS{
	// For Finish Application
	// for Inland Marine
	// DWIP140

	// KEYS


	COVERG: string = "CEQ";
	LOCNUM: string = "";
	BLDNUM: string = "";
    EDSNO: number = 0;
	MRTGNO: string = "";

	// Mortgagee Type
	MRTGTP: string = "";

	//Mortgage Type Coverage
	MRTGTPCOVERG: string = "";

	// Mortgagee Name
	MRTGNM: string = "";

	// Second Mortgagee Name
	MRTNM2: string = "";

	// Mortgagee Address Line 1
	MRTGA1: string = "";

	// Mortgagee Address Line 2
	MRTGA2: string = "";

	// Mortgagee Address Line 3
	MRTGA3: string = "";

	// Mortgagee City
	MRTGCT: string = "";

	// Mortgagee State
	MRTGST: string = "";

	// Mortgagee Zipcode
	MRTGZP: string = "";

	// Mortgagee Description
	MRTITD: string = "";
	
	RECORDSTATE: string = "N";
    
    constructor(quotePolicyInfo: QUOTEPOLICYINFO) {
		super();
        this.TRANS = quotePolicyInfo.TRANSACTIONCODE.toString();
        this.POLICY = quotePolicyInfo.QUOTEPOLICYNUMBER;
        this.EFFDTE = quotePolicyInfo.EFFECTIVEDATE;
        this.RCDTYP = quotePolicyInfo.RECORDTYPE;
        this.EDSDTE = quotePolicyInfo.ENDORSEMENTDATE;
	}
}
