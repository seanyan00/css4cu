import { CTRBASECLASS } from './CTRBASECLASS';

export class CONSTPROJECTLIAB extends CTRBASECLASS{

	COVERG: string = "";
	EDSNO: number = 0;
    /** @param string Number of Designated Construction Projects */
	SPCSEQ: string = "0";	
	SPCDSC: string = "";
	RECORDSTATE: string = "N";
}