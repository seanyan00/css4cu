import { CTRBASECLASS } from './CTRBASECLASS';

export class SCHEDULEDITEM extends CTRBASECLASS {

	// KEYS

	EDSNO: number;

	// item number
	ITEMNO: string = '';

	// item description
	ITEMDC: string = '';

	// item manufacturer
	ITMMFG: string = '';

	// item model
	ITMMDL: string = '';

	// item model year
	ITMMYR: number = 0;

	// Serial number
	SERIAL: string = '';

	// Value per Item
	ITMVAL: number = 0;

	/** @param string Record State */
	RECORDSTATE: string = "N";

}
