import { QUOTEBASECLASS } from '@classes/Common/QUOTEBASECLASS';

export class QUOTEPERSONALINFO extends QUOTEBASECLASS {

	// KEYS

	COVEND: number = 0;

	EDSNO: number = 0;

	/** @param string Personal Info  First Name */
	FSTNME1: string = "";

	/** @param string Personal Info Middle Name */
	MIDNME1: string = "";

	/** @param string  Personal Info Last Name*/
	LSTNME1: string = "";

	/** @param string  Personal Info NameSuf1 */
	NAMSUF1: string = "";

	/** @param string  Personal Info Street Number */
	STRNO: string = "";

	/** @param string  Personal Info Street Name */
	STRNME: string = "";

	/** @param string  Personal Info PO Box */
	POBOX: string = "";

	/** @param string  Personal Info Apt No */
	APTNO: string = "";

	/** @param string Personal Info City */
	INSCTY: string = "";

	/** @param string Personal Info State */
	INSST: string = "";

	/** @param string Personal Info Zip */
	INSZIP: string = "";

	/** @param string Personal Info Phone */
	INSTEL: string = "";

	CREDSC: string = "";
    /** @param number Credit score order date */
    CRODTE: number = 0;

	/** @param string Personal Info Record State */
	RECORDSTATE: string = "N";
    constructor(personalInfo?) {
		super();
        if (personalInfo != undefined && personalInfo.RECORDSTATE != "0") {
            Object.assign(this, personalInfo);
        }
        if (this.INSTEL != null)
            this.INSTEL = this.INSTEL.replace(/-/g, "").replace(/\(/g, "").replace(/\)/g, "").replace(/\s/g, "");
        
        if (this.INSZIP != null)
            this.INSZIP = this.INSZIP.replace(/-/g, "");
    }

    assignQuotePersonalInfoProperties(data):void {
        Object.assign(this, data);
    }
}
