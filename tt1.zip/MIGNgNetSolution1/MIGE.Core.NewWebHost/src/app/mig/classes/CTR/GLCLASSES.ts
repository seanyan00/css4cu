﻿import { CTRBASECLASS } from './CTRBASECLASS';

// 
export class GLClasses extends CTRBASECLASS {



	EDSNO: number = 0;

	/** @param string Coverage Part */
	COVERG: string = "";

	/** @param string Premium State */
	PRMSTE: string = "";

	/** @param string Location Number */
	LOCNUM: string = "000";

	/** @param string Building Number*/
	BLDNUM: string = "000";

    /** @param string CLASS Code */
	CLASX: string = "";
	
	/** @param string EDSFRM Sequence Number */
	SEQNO: string = "";


    /** @param string Class Description */
	CLSDSC: string = "";
	
    /** @param number Exposure */
	EXPOSE: number = 0;
	
	/** @param string predominant state */
	PRMDSC: string = "";

    /** @param string Class Description */
	EXPDSC: string = "";
	
    /** @param string IF Any*/
	IFANY: string = "";
	
	/**@param string Needed for Rating */
	PRDINC: string = "";
	
	/**@param string SICCDE */
	SICCDE: string = "";
	
	/**@param string PKMOD defualt this to "CO" */
	PKGMOD: string = "";

	/** @param string Record State */
	RECORDSTATE: string = "N";


}