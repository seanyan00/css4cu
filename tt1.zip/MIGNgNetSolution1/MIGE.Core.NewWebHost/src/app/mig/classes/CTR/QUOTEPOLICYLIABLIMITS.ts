import { CTRBASECLASS } from './CTRBASECLASS';
import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';
import { IQuote } from '@interfaces/IQuote';
import { CTRQuote } from '@classViewModels/CTR/CTRQuote';

export class QUOTEPOLICYLIABLIMITS extends CTRBASECLASS {

	// KEYS

	COVERG: string = "";


	EDSNO: number = 0;

	GALMT: number = 2000000; //default value NOT state specific

	/** @param number General Liability - Each Occurrence/General Aggregate */
	EOLMT: number = 1000000; //default value NOT state specific

	/** @param number Medical Expense */
	MEDLMT: number = 5000;

	/** @param number Damage To Premises Rented To You */
	FDLMT: number = 500000;

	// Fire Damage Excluded Flag
	FDEXC: string = "N";

	/** @param number Products - Completed Operations Aggregate */
	PCOLMT: number = 0;

	/** @param number Personal and Advertising Injury Liability */
	PAILMT: number = 0;

	/** @param number Exclude Personal and Advertising Injury Liability */
	PAEXC: string = "";

	/** @param string General Liability - Each Occurrence/General Aggregate Formatted */
	EOLMTFORMAT: string = "$1,000,000/$2,000,000";

	/** @param string Products - Completed Operations Aggregate Formatted */
	PCOLMTFORMAT: string = "$2,000,000";

	/** @param string Personal and Advertising Injury Liability Formatted */
	PAILMTFORMAT: string = "$1,000,000";

	//** ADDITINAL COVERAGE **//
	/** @param number Liability - Ohio Stop Gap */
	STAGLM: number = 0;

	/** @param number Liability - Ohio Stop Gap */
	STOTLM: number = 0;

	/** @param number Liability - Ohio Stop Gap */
	STGPRL: number = 0;

	/** @param number Liability - Elevator, Escalator */
	ELVNBR: number = 0;

	/** @param number Liability - Elevator, Escalator */
	ELVINSPS: number = 0;
	
	/** @param number Liability - Electronic Data Liability */
	EDLLMT: number = 0;

	/** @param string Liability - Short Term Pollution Coverage For Contractors */
	SHTPOL: string = "";

	/** @param string Designated Construction Projects */
	DCPBLK: string = "";

/** @param string Designated Construction Projects - Number of Designated Construction Projects */
	SPCSEQ: string = "";

	/** @param string Liability - Checkbox Septic Systems Design and Inspection Professional Liability Coverage Endorsement */
	EOACTL: number = 0;

	/** @param string Liability - Septic Systems Design - Number of Inspectors */
	EOINSP: number = 0;

	/** @param string Liability - Dropdown Septic Systems Design and Inspection Professional Liability Coverage Endorsement  */
	EOAGGR: number = 0;

	/** @param string Liability - Hired and Non Owned Auto Liability */
	// HIRNON: string;
	HIREOC: number = 0;
	HIRAGG: number = 0;

	/** @param number Liability - CG 2033: Owners, Lessees or Contractors - Automatic Status When Required in Construction Agreement with You */
	//SMB:  For Project A-02142, we want CG 2033 additional coverage to be included by default.
    //Defaulting the OSCNT property, which corresponds to CG 2033, to 1.
    //This comes into play when we reset additional coverages to defaults when the first location state changes.
    OSCNT: number = 1;

	/** @param number Liability - CG 2034: Lessor of Leased Equipment - Automatic Status When Required in Lease Agreement with You */
	LSCNT: number = 0;

	/** @param number Liability - CG 2003: Concessionaires Trading Under Your Name */
	CNCNT: number = 0;

	/** @param number Liability - CG 2005: Controlling Interests */
	CICNT: number = 0;

	/** @param number Liability - CG 2007: Engineers, Architects or Surveyors */
	EACNT: number = 0;

	/** @param number Liability - CG 2010: Owners, Lessees or Contractors - Scheduled Person or Organization */
	OBCNT: number = 0;

	/** @param number Liability - CG 2011: Managers or Lessors of Premises */
	MLCNT: number = 0;

	/** @param number Liability - CG 2013: State or Governmental Agency or Subdivision or Political Subdivision - Permits or Authorizations Relating to Premises */
	STCNT: number = 0;

	/** @param number Liability - CG 2015: Vendors */
	VECNT: number = 0;

	/** @param number Liability - CG 2018: Mortgagee Assignee or Receiver */
	MTCNT: number = 0;

	/** @param number Liability - CG 2024: Owners or Other Interests From Whom Land Has Been Leased */
	OWCNT: number = 0;

	/** @param number Liability - CG 2026: Designated Person or Organization */
	POCNT: number = 0;

	/** @param number Liability - CG 2027: Co-Owner of Insured Premises */
	COCNT: number = 0;

	/** @param number Liability - CG 2028: Lessor of Leased Equipment */
	GFCNT: number = 0;

	/** @param number Liability - CG 2029: Grantor or Franchise */
	LECNT: number = 0;

	/** @param number Liability - CG 2032: Engineers, Architects or Surveyors Not Engaged by the Named Insured */
	ENCNT: number = 0;

	/** @param number Liability - CG 2036: Grantor of Licenses */
	GSCNT: number = 0;

	/** @param number Liability - CG 2037: Owners, Lessees or Contractors - Completed Operations */
	CPCNT: number = 0;

	/** @param number Liability - CG 2038: Owners, Lessees or Contractors - Automatic Status For Other Parties When Required in Written Construction Agreement */
	CACNT: number = 0;

	/** @param number Liability - CG 2035: Grantor of Licenses - Automatic Status When Required By Licensor */
	GLCNT: number = 0;

	/** @param number Liability - MU 9064: Owners, Lessee or Contractors Completed Operations */
	IBCNT: number = 0;

	/** @param number Liability - CG 2012: State or Governmental Agency or Subdivision or Political Subdivision - Permits or Authorizations  */
	SPCNT: number = 0;

	/** @param number Liability - CG 2404: Wavier of Transfer of Rights of Recovery Against Others To Us  */
	WTCNT: number = 0;
	
	/** @param number Liability - CP 1219: */
	BOCNT: number = 0;

	IXCNT: number = 0;
	ZZCNT: number = 0; 

	/** @param string  */
	CAPPOL: string = "";

	/** @param string  */
	HOMBLD: string = "";

	/** @param string Record State */
	RECORDSTATE: string = "N";


	constructor (quotePolicyInfo?: QUOTEPOLICYINFO){
        super();

		if(quotePolicyInfo!=null) {
            this.POLICY = quotePolicyInfo.QUOTEPOLICYNUMBER;
            this.RCDTYP = quotePolicyInfo.RECORDTYPE;
            this.TRANS  = quotePolicyInfo.TRANSACTIONCODE.toString();
            this.EFFDTE = quotePolicyInfo.EFFECTIVEDATE;
            this.EDSDTE = quotePolicyInfo.ENDORSEMENTDATE;
            this.EDSNO  = quotePolicyInfo.ENDORSEMENTNUMBER;
		    this.COVERG = 'CGL';
        }
    }
	//Need to add in the format properties to prevent them from being reset and effecting the other items.
    setLiabilityLimits(GALMT: number, EOLMT: number, MEDLMT: number, FDLMT: number, EOLMTFORMAT: string, PAILMTFORMAT: string, PCOLMTFORMAT: string)
    {
        this.GALMT = GALMT;
        this.EOLMT = EOLMT;
        this.MEDLMT = MEDLMT;
		this.FDLMT = FDLMT;
		this.EOLMTFORMAT = EOLMTFORMAT;
		this.PAILMTFORMAT = PAILMTFORMAT;
		this.PCOLMTFORMAT = PCOLMTFORMAT;

    }
}
