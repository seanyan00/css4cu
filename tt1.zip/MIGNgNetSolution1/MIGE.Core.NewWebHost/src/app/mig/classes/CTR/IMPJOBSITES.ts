import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';
import { CTRBASECLASS } from './CTRBASECLASS';

export class IMPJOBSITES extends CTRBASECLASS {
	// KEYS

	COVEND: number = 0;

	EDSNO: number = 0;


	/** @param number Inland Marine - Installation Coverage Form - Deductible */
	CINDED: number = 0;

	/** @param string Inland Marine - Installation Coverage Form - Coinsurance */
	CINCNS: string = "";

	/** @param number Inland Marine - Installation Coverage Form - A. Property At The Job Site */
	CINSLM: number = 10000;

	/** @param number Inland Marine - Installation Coverage Form - C. Property In Transit */
	CINTLM: number = 5000;

	/** @param number Inland Marine - Installation Coverage Form - B. Property While Held At Any Temporary Storage Location */
	CINLLM: number = 5000;

	/** @param number Inland Marine - Installation Coverage Form - "D. All Covered Property Included in A, B, and C. Combined in Any One Occurrence" */
	CINOLM: number = 20000;

	/** @param number ADDED 20190506 for RATING  - */
	CINJRT: number = 0;
	
	/** @param number ADDED 20190506 for RATING  - */
	CINSRT: number = 0;

	/** @param number ADDED 20190506 for RATING  - */
	CINTRT: number = 0;

	/** @param string ADDED 20190506 for RATING  - */
	CINJST: string = "";

	/** @param string ADDED 20190506 for RATING  - */
	CINPRJ: string = "";

	/** @param string  */
	RECORDSTATE: string = "N";
    constructor(quotePolicyInfo: QUOTEPOLICYINFO) {
		super();
        this.TRANS = quotePolicyInfo.TRANSACTIONCODE.toString();
        this.POLICY = quotePolicyInfo.QUOTEPOLICYNUMBER;
        this.EFFDTE = quotePolicyInfo.EFFECTIVEDATE;
        this.RCDTYP = quotePolicyInfo.RECORDTYPE;
        this.EDSNO = quotePolicyInfo.ENDORSEMENTNUMBER;
        this.EDSDTE = quotePolicyInfo.ENDORSEMENTDATE;
	}
}
