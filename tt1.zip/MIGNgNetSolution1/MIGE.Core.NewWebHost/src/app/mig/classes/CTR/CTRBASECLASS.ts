//base class needed to be able to pass in base class type in validation
export abstract class CTRBASECLASS {
    TRANS: string = "";
	POLICY: string = "";
	EFFDTE: number = 0;
	EDSDTE: number = 0;
	RCDTYP: number = 0;
}