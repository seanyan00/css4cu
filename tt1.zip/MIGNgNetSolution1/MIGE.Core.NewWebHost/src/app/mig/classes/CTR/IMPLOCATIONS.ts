import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';
import { CTRBASECLASS } from './CTRBASECLASS';

export class IMPLOCATIONS extends CTRBASECLASS {
	// KEYS

	COVEND: number = 0;
	EDSNO: number = 0;

	/** @param string  */
	PRMSTE: string = "";

	/** @param string  */
	RECORDSTATE: string = "N";
    constructor(quotePolicyInfo: QUOTEPOLICYINFO) {
		super();
        this.TRANS = quotePolicyInfo.TRANSACTIONCODE.toString();
        this.POLICY = quotePolicyInfo.QUOTEPOLICYNUMBER;
        this.EFFDTE = quotePolicyInfo.EFFECTIVEDATE;
        this.RCDTYP = quotePolicyInfo.RECORDTYPE;
        this.EDSNO = quotePolicyInfo.ENDORSEMENTNUMBER;
        this.EDSDTE = quotePolicyInfo.ENDORSEMENTDATE;
	}
}
