import { CTRBASECLASS } from './CTRBASECLASS';

//DWGP125
export class GLPSTATEINFO extends CTRBASECLASS {
    // KEYS

    EDSNO: number = 0;
    // End keys
    DRGFAC: number = 0;
    EXPMOD: number = 0;
    IRPMOD: number = 0;
    PRMSTE:string = '';
}
