import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';
import { IScheduledItem } from '@interfaces/IScheduledItems'
import { CTRBASECLASS } from './CTRBASECLASS';
/*

RRF - 2019-05-22 ADDED PROPERTIES SEQNCE AND COVERG WITH CORRESPONDING DEFAULTS

*/
export class IMPSCHEDULEDITEM extends CTRBASECLASS implements IScheduledItem {
		// DWIP142
		// KEYS
		EDSNO: number;

		//coverage
		COVERG: string = "CEQ";
		//SEQNCE
		SEQNCE: number = 1;
		// item number
		ITEMNO: string = '';
		// mortage number
		MRTGNO: string = "";
		// item description
		ITEMDC: string = '';
		// item manufacturer
		ITMMFG: string = '';
		// item model
		ITMMDL: string = '';
		// item model year
		ITMMYR: number = 0;
		// Serial number
		SERIAL: string = '';
		// Value per Item
		ITMVAL: number = 0;

		//Mortgage Type Coverage
		MRTGTPCOVERG: string = "";

		/** @param string Record State */
		RECORDSTATE: string = "N";

	constructor(quotePolicyInfo: QUOTEPOLICYINFO){
		super();
		this.POLICY = quotePolicyInfo.QUOTEPOLICYNUMBER;
		this.RCDTYP = quotePolicyInfo.RECORDTYPE;
		this.TRANS = quotePolicyInfo.TRANSACTIONCODE.toString();
		this.EFFDTE = quotePolicyInfo.EFFECTIVEDATE;
		this.EDSDTE = quotePolicyInfo.ENDORSEMENTDATE;
		this.EDSNO = quotePolicyInfo.ENDORSEMENTNUMBER;
	}

}
