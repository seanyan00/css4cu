import { CTRBASECLASS } from './CTRBASECLASS';

// DWFP0125
export class CFPSTATEINFO extends CTRBASECLASS {
    // KEYS
    EDSNO: number = 0;
    // End keys
    DRGFAC: number = 0;
    IRPMOD: number = 0;
    PRMSTE:string = '';
}
