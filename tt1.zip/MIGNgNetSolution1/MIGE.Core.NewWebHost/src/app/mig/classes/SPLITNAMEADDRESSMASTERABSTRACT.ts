﻿
/* ****************************************************************************************************
* PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS - SEE LIBRARY AND TABLE/FILENAME 
* AS400 LIBRARY        - DVDTA
* TABLE/FILENAME       - DWXP017
* DESCRIPTION          - Split Name/Address Master File
* DATE CREATED         - 5/16/2018 6:59:45 AM
* AUTHOR               - RICHARD FUMERELLE
* VERSION              - 1.0
* CODE GENERATION      - Automatic code generation using CodeSmith GenerationTool
* NOTES                - This table can be modified.
****************************************************************************************************/

export abstract class SplitNameAddressMasterAbstract {
    // KEYS
    POLICY: string = "";
    EFFDTE: number = 0;
    EDSDTE: number = 0;
    EDSNO: number = 0;

    /** @param string Named Insured 1 */
    BUSNME1: string = "";

    /** @param string Named Insured 2 */
    BUSNME2: string = "";

    /** @param string STREET NUMBER */
    STRNO: string = "";

    /** @param string STREET NAME */
    STRNME: string = "";

    /** @param string POBOX # */
    POBOX: string = "";

    /** @param string Apartment / suite # */
    APTNO: string = "";

    /** @param string Insured Address line 2 */
    SPLAD2: string = "";

    /** @param string Insured Address line 3 */
    INSAD3: string = "";

    /** @param string City */
    INSCTY: string = "";

    /** @param string State */
    INSST: string = "";

    /** @param string Zip Code */
    INSZIP: string = "";

    /** @param string Telephone */
    INSTEL: string = "";

    /** @param string Record State */
    RECORDSTATE: string = "N";

    constructor() { }

}

