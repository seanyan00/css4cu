import { IMPPRODUCTS } from '@classes/CTR/IMPPRODUCTS';
import { IMPJOBSITES } from '@classes/CTR/IMPJOBSITES';
import { IMPMORTGAGEE } from '@classes/CTR/IMPMORTGAGEE';
import { IMPSCHEDULEDITEM } from '@classes/CTR/IMPSCHEDULEDITEMS';
import { IMPSCHEDULEDTRANS } from '@classes/CTR/IMPSCHEDULEDTRANS';
import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';
import { IMortgagee } from '@interfaces/IMortgagee';
import { IMPSTATEINFO } from '@classes/CTR/IMPSTATEINFO';
import { FormArray, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import * as _ from 'lodash';


export class IMPEntity {

    public IMPPRODUCTS:  IMPPRODUCTS;
    public IMPJOBSITES:  IMPJOBSITES;
	//public IMPLOCATIONS: IMPLOCATIONS;

	// for finish application
	public IMPMORTGAGEE: IMPMORTGAGEE[] = []; // DWIP140
    public IMPSCHEDULEDITEMS: IMPSCHEDULEDITEM[] = []; // DWIP142
    public IMPSCHEDULEDTRANS: IMPSCHEDULEDTRANS[] = []; // DWIP141
    //public SCHEDULEDITEMS: SCHEDULEDITEM[] = [];
    protected QUOTEPOLICYINFORMATION: QUOTEPOLICYINFO;
    public IMPSTATEINFO: IMPSTATEINFO[] = []; //DWIP125

    constructor(quotePolicyInformation?: QUOTEPOLICYINFO){
        
        if(quotePolicyInformation != undefined || quotePolicyInformation != null)
        {
            this.QUOTEPOLICYINFORMATION = quotePolicyInformation;
            // this.IMPPRODUCTS  = new IMPPRODUCTS(quotePolicyInformation);
            // this.IMPJOBSITES  = new IMPJOBSITES(quotePolicyInformation);
            // this.IMPLOCATIONS = new IMPLOCATIONS(quotePolicyInformation);

            // this.IMPMORTGAGEE.push(
            //     new IMPMORTGAGEE(quotePolicyInformation)
            // )

            // this.IMPSCHEDULEDITEMS.push(
            //     new IMPSCHEDULEDITEMS(quotePolicyInformation)
            // )

            // this.IMPSCHEDULEDTRANS.push(
            //     new IMPSCHEDULEDTRANS(quotePolicyInformation)
            // )
        }

    }

    public saveScheduledItem(scheduledItem: IMPSCHEDULEDITEM) {

        if(this.IMPSCHEDULEDITEMS.length === 0) {
            scheduledItem.ITEMNO = "0001";
        }
        else {
            let unique = Array.from(new Set(this.IMPSCHEDULEDITEMS.map((item:any)=> item.ITEMNO))).sort().reverse();

            let itemNumber = Number(unique[0]) + 1;
            
            if(itemNumber === 999){
                 throw new Error("Error in adding scheduled item.");
            }
            if(itemNumber.toString().length === 1){
                scheduledItem.ITEMNO = "000" + itemNumber.toString();
            }
            if(itemNumber.toString().length === 2){
                scheduledItem.ITEMNO = "00" + itemNumber.toString();
            }
            if(itemNumber.toString().length === 3) {
                scheduledItem.ITEMNO = "0" + itemNumber.toString();
            }
        }
		this.IMPSCHEDULEDITEMS.push(Object.assign(new IMPSCHEDULEDITEM(this.QUOTEPOLICYINFORMATION), scheduledItem));
    }

    public deleteScheduledItem(scheduledItem: IMPSCHEDULEDITEM){
        
        let i = this.IMPSCHEDULEDITEMS.indexOf(scheduledItem);
        this.IMPSCHEDULEDITEMS.splice(i,1);
        
    }

    public saveMortgagee(mortgageList: any, coverageType: string) : boolean {
        try {    

            if(coverageType.toUpperCase() === "SI"){         
                this.IMPMORTGAGEE.push(Object.assign(new IMPMORTGAGEE(this.QUOTEPOLICYINFORMATION),mortgageList));
                //this.updateScheduledItemsTrans(mortgageList);                        
                return true;
            }

            if(coverageType.toUpperCase() === "UI") {              
                this.IMPMORTGAGEE.push(Object.assign(new IMPMORTGAGEE(this.QUOTEPOLICYINFORMATION),mortgageList));              
                return true;
            }

            if(coverageType.toUpperCase() === "IC") {        
                //need to change the controls back to upper case versions: 
                //installationCoverage --> INSTALLATIONCOVERAGE
                //icDescription --> ICDESCRIPTION
                mortgageList = this.updateICControl(mortgageList);
                this.IMPMORTGAGEE.push(Object.assign(new IMPMORTGAGEE(this.QUOTEPOLICYINFORMATION),mortgageList));
                this.addICDescription(mortgageList);              
                return true;
            }
            
        } catch (error) {
            
            //console.log(error);
            throw new Error(error);
        }
    } 
    //update the control name if its an IC
    private updateICControl(mortgageList: any) : any{
        //let formBuilder: FormBuilder = new FormBuilder();
        let temp = [] as any;
        let tempMortg = _.cloneDeep(mortgageList);
        mortgageList.installationCoverage.forEach(item => {
            temp.push({ICDESCRIPTION: item.icDescription});
        });
        delete tempMortg.installationCoverage;
        tempMortg.INSTALLATIONCOVERAGE = temp;
        return tempMortg
    }
    //THIS IS NOT RIGHT - NEED TO SET RECORD STATE TO "D" NOT REMOVE FROM OBJECT GRAPH!!
    //need to add other types in here.
    public deleteMortgagee(mortgagee: IMPMORTGAGEE, coverageType: string) : boolean {
        
        let idx = this.IMPMORTGAGEE.indexOf(mortgagee);
        let found: boolean = false;
        try {

            if(coverageType == null)  {
                this.IMPMORTGAGEE[idx].RECORDSTATE = 'D'; 
                return false;
            }

            switch(coverageType.toUpperCase()) {
                case "SI": {
                    this.IMPSCHEDULEDITEMS.forEach((item)=> {
                        if(item.MRTGNO === mortgagee.MRTGNO) {
                            //we need to create a new Scheduled Item and set the MRTGNO to blank
                            let temp = _.cloneDeep(item);
                            temp.MRTGNO = ""
                            //set the RECORDSTATE to D of the original item to delete it
                            item.RECORDSTATE = 'D';
                            //add the newly created item to the scheduled items
                            this.IMPSCHEDULEDITEMS.push(temp);
                        }
                    })
                    this.IMPMORTGAGEE[idx].RECORDSTATE = 'D';
                    this.calculateMortgageeNumber();
                    found = true;
                    break;
                }
                
                //same process for UI or IC
                case "UI":
                case "IC": {
                    Object.keys(mortgagee).filter(key=>key.startsWith("INSTALLATIONCOVERAGE") || key.startsWith("installationCoverage"))
                    .forEach((key)=> {
                        if(mortgagee[key].length > 0) {
                            for(let i=0; i< mortgagee[key].length; i++){
                                //let impSCHEDULEDTRAN : IMPSCHEDULEDTRANS;
                                //impSCHEDULEDTRAN.ITEMDC = mortgagee[key][i]['icDescription'];
                                let idx = this.IMPSCHEDULEDTRANS.indexOf(this.IMPSCHEDULEDTRANS.find(element=>
                                    element.MRTGNO === mortgagee.MRTGNO &&
                                    element.ITEMDC === mortgagee[key][i]['ICDESCRIPTION'] || mortgagee[key][i]['icDescription']
                                ))
                                
                                this.IMPSCHEDULEDTRANS[idx].RECORDSTATE = 'D';
                                
                                //this.IMPSCHEDULEDTRANS.splice(idx,1);
                            }
                        }
                    })
                    this.IMPMORTGAGEE[idx].RECORDSTATE = 'D';
                    found = true;
                    break;
                }

                default: {
                    this.IMPMORTGAGEE[idx].RECORDSTATE = 'D';
                    found = false;
                }
            }
        
        } catch(ex) {
            //console.log(ex.toString());
        } finally {
            return found; 
        }
    }

    private calculateMortgageeNumber() {

        //CLEAR OUT THE SCHEDULEDITEM TRANSACTION FILE BECAUSE
        //THE ITEMS IN THE FILE NEED TO BE RENUMBERED WITH THE NEW
        //MORTGAGE NUMBER
        //this.IMPSCHEDULEDTRANS = [];

        let counter: number;
        counter = 1;
        this.IMPMORTGAGEE.forEach(mortgage=> {
            let counterString = "00" + counter.toString();
            mortgage.MRTGNO = counterString;
            this.updateScheduledItemsTrans(mortgage);
            counter++;
        })
    }

    private addICDescription(mortgagee: IMortgagee): void {
        
        let itemNo : number;
        itemNo = 0;

        Object.keys(mortgagee).filter(key=>key.startsWith("installationCoverage") || key.startsWith('INSTALLATIONCOVERAGE'))
        .forEach((key)=> {
            if(mortgagee[key].length > 0) {
                for(let i=0; i< mortgagee[key].length; i++){
                    let impSCHEDULEDTRAN: IMPSCHEDULEDTRANS;
                    impSCHEDULEDTRAN = new IMPSCHEDULEDTRANS(this.QUOTEPOLICYINFORMATION);
                    impSCHEDULEDTRAN.MRTGNO = mortgagee.MRTGNO;
                    impSCHEDULEDTRAN.ITEMDC = mortgagee[key][i]['icDescription'] || mortgagee[key][i]['ICDESCRIPTION'];
                    itemNo++;
                    if(itemNo.toString().length === 3){
                        if(itemNo > 999){
                            throw new Error("Unable to save description.")
                        }
                        impSCHEDULEDTRAN.ITEMNO = itemNo.toString();
                    }
                    if(itemNo.toString().length === 2){
                        impSCHEDULEDTRAN.ITEMNO === "0" + itemNo.toString();
                    }
                    if(itemNo.toString().length === 1) {
                        impSCHEDULEDTRAN.ITEMNO = "00" + itemNo.toString();
                    }
                    //this.IMPSCHEDULEDTRANS.push(Object.assign(new IMPSCHEDULEDTRANS(this.QUOTEPOLICYINFORMATION), impSCHEDULEDTRAN))
                    this.IMPSCHEDULEDTRANS.push(impSCHEDULEDTRAN);
                }
            }
        })
    }

    //This is causing an issue --- putting the Scheduled Items in the same place as the Installation Coverage Items which incorrectly adds them
    //does this function have any other use in the code?
    private updateScheduledItemsTrans(mortgagee: IMPMORTGAGEE) : void {
        
        Object.keys(mortgagee).filter(key=>key.startsWith("ITEM_D"))
        .forEach((key)=>{ 
            if(mortgagee[key]) {
                let impSCHEDULEDITEM: IMPSCHEDULEDITEM;
                
               impSCHEDULEDITEM = this.IMPSCHEDULEDITEMS.find(record=>record.ITEMNO === key.substr(6,4));
               impSCHEDULEDITEM.MRTGNO = mortgagee.MRTGNO;
                
                this.IMPSCHEDULEDTRANS.forEach(item => {
                    if(impSCHEDULEDITEM.ITEMNO === item.ITEMNO) item.MRTGNO = impSCHEDULEDITEM.MRTGNO
                })
                //this.IMPSCHEDULEDTRANS.push(Object.assign(new IMPSCHEDULEDTRANS(this.QUOTEPOLICYINFORMATION),impSCHEDULEDITEM));
                
               
        
            }
            
          });
    }

}
