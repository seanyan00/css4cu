import { CFPLOCATION } from '@classes/CTR/CFPLOCATION';
import { CFPCOVERAGES } from '@classes/CTR/CFPCOVERAGES';
import { CFPMORTGAGEE } from '@classes/CTR/CFPMORTGAGEE';
import { CFPSCHEDULEDITEMS } from '@classes/CTR/CFPSCHEDULEDITEMS';
import { CFPSTATEINFO } from '@classes/CTR/CFPSTATEINFO';
import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';

export class CFPEntity {

	public CFPCOVERAGES: CFPCOVERAGES;
    public CFPSTATEINFO: CFPSTATEINFO[]; //DWFP125    
    public CFPLOCATIONS: CFPLOCATION[] = [];  //DWFP130    
    // for finish application
	public CFPMORTGAGEE: CFPMORTGAGEE[] = []; // DWFP140 
    public CFPSCHEDULEDITEMS: CFPSCHEDULEDITEMS[] = []; // DWFP141
    protected QUOTEPOLICYINFORMATION: QUOTEPOLICYINFO;

    constructor(quotePolicyInformation?: QUOTEPOLICYINFO){
        //this.CFPSTATEINFO = new CFPSTATEINFO();

        if(quotePolicyInformation != undefined || quotePolicyInformation != null) {
            this.QUOTEPOLICYINFORMATION = quotePolicyInformation;
        }
    }

    //public saveMortgagee(mortgageList: CFPMORTGAGEE[], coverageType: string) : boolean  {
    public saveMortgagee(mortgagee: CFPMORTGAGEE, coverageType: string) : boolean  {
        try 
        {
            //mortgageList.forEach(element=> this.CFPMORTGAGEE.push(Object.assign(new CFPMORTGAGEE(this.QUOTEPOLICYINFORMATION),element)));           
            mortgagee.POLICY = this.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
            mortgagee.EFFDTE = this.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
            mortgagee.EDSDTE = this.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;            
            mortgagee.TRANS  = this.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;            
            mortgagee.RCDTYP = this.QUOTEPOLICYINFORMATION.RECORDTYPE;  
            mortgagee.EDSNO  = this.QUOTEPOLICYINFORMATION.ENDORSEMENTNUMBER;    
            mortgagee.COVERG = (mortgagee.COVERG != '' && mortgagee.COVERG != null) ? mortgagee.COVERG : 'CPC';   

            this.CFPMORTGAGEE.push(Object.assign(new CFPMORTGAGEE(this.QUOTEPOLICYINFORMATION),mortgagee));            
            //this.CFPMORTGAGEE.push(new CFPMORTGAGEE(this.QUOTEPOLICYINFORMATION),mortgagee);

            if(coverageType === "BPP") {
                //this.saveScheduledItems(this.CFPMORTGAGEE[0]?
                this.saveScheduledItems(mortgagee);
            }
            else if (coverageType === "SI") {                
                this.saveScheduledItems(mortgagee);
            }

            return true;
            
        } catch (error) {
            
            //console.log(error);
            throw(error);

        }
    }

    public deleteMortgagee(mortgagee: CFPMORTGAGEE) : boolean {
        try {
                        
            //let idx = this.CFPMORTGAGEE.indexOf(mortgagee);            
            let idx = 0;            
            this.CFPMORTGAGEE.forEach((x, index) =>{
                       if(x=>x.RECORDSTATE!='D'
                                && x.MRTGNO == mortgagee.MRTGNO
                                && x.LOCNUM == mortgagee.LOCNUM
                                && x.BLDNUM == mortgagee.BLDNUM
                                && x.POLICY == mortgagee.POLICY
                                && x.EFFDTE == mortgagee.EFFDTE
                                && x.EDSDTE == mortgagee.EDSDTE
                                && x.TRANS == mortgagee.TRANS){
                           idx = index;
                       }                        
            });

            this.CFPMORTGAGEE[idx].RECORDSTATE = 'D';
            //let items = this.CFPMORTGAGEE.find(key => key.MRTGNO === mortgagee.MRTGNO);

            //need to set the COVERG to blank because the repository bombs out when attempting to delete 2 items with the same key
            //(one with RECORDSTATE D and one with RECORDSTATE U). There are no keys that are different between the two and it throws an error
            //when trying to delete a duplicate key. This is a workaround but theoretically why are we creating a new object instead of just updating
            //the original one??  Done for immutability of the object graph??
            //this.CFPMORTGAGEE[idx].COVERG = '';

            //set scheduled itemns mortgage number to blank
            this.CFPSCHEDULEDITEMS.forEach(item => {
                if(item.MRTGNO === mortgagee.MRTGNO) {
                    //item.MRTGNO = ''; //can't delete the mortgage number or else it will not delete as it's a required key
                    item.RECORDSTATE = 'D';
                }
            })
            //set BPP items to blank
            
            //this.CFPMORTGAGEE.splice(idx,1);
            this.calculateMortgageeNumber();
            return true;

        } catch (error) {
            //console.log(error);
            throw(error);
        }
    }

    private calculateMortgageeNumber(){
        let counter: number;
        
        counter=1       
        this.CFPMORTGAGEE.filter(x=>x.RECORDSTATE != 'D').forEach(element=>{
        //this.CFPMORTGAGEE.forEach(element=>{
            let counterString = "00" + counter.toString();
            element.MRTGNO = counterString;
            counter++;
            
        })
    }

    private saveScheduledItems(mortgagee: CFPMORTGAGEE) :void {
    
        Object.keys(mortgagee).filter(key=>key.startsWith("itemDescription"))
            .forEach((key)=>{
                if(mortgagee[key].length > 0) {
                    for(let i=0; i < mortgagee[key].length; i++){
                        let cfpScheduledItems: CFPSCHEDULEDITEMS;
                        cfpScheduledItems = new CFPSCHEDULEDITEMS(this.QUOTEPOLICYINFORMATION);
                        cfpScheduledItems.LOCNUM = key.substr(15,3);
                        cfpScheduledItems.BLDNUM = key.substr(18,3);
                        cfpScheduledItems.SCHITM = mortgagee[key][i]["desc"];
                        cfpScheduledItems.MRTGNO = mortgagee.MRTGNO;
                        //need to increment the SEQNCE or else the hash will be the same resulting a duplicate key when saving if there are multiple items in the same mortgage number
                        cfpScheduledItems.SEQNCE = i;
                        this.CFPSCHEDULEDITEMS.push(cfpScheduledItems);
                    }
                }
            })
    }
}
