export class CAPEntity {
    
    
}
