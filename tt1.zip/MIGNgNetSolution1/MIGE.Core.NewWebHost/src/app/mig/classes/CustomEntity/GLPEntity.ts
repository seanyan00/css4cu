import { GLClasses } from '@classes/CTR/GLCLASSES';
import { GLPLOCATION } from '@classes/CTR/GLLOCATION';
import { QUOTEPOLICYLIABLIMITS } from '@classes/CTR/QUOTEPOLICYLIABLIMITS';
import { GLPLIABILITIES } from '@classes/CTR/GLPLIABILITIES';
import { CONSTPROJECTLIAB } from '@classes/CTR/CONSTPROJECTLIAB';
import { GLPSTATEINFO } from '@classes/CTR/GLPSTATEINFO';
import { QUOTEPOLICYINFO } from '@classes/Common/QUOTEPOLICYINFO';


export class GLPEntity {

    public GLPLOCATIONS: GLPLOCATION[] = [];
    public GLCLASSLIST: GLClasses[] = [];
    public GLPLIABILITIES: GLPLIABILITIES[] = [];
    public QUOTEPOLICYLIABLIMITS: QUOTEPOLICYLIABLIMITS;
    public CONSTPROJECTLIAB: CONSTPROJECTLIAB[] = [];
    public GLPSTATEINFO: GLPSTATEINFO[]; //DWGP125 
    protected QUOTEPOLICYINFORMATION: QUOTEPOLICYINFO;

    
    constructor(quotePolicyInformation?: QUOTEPOLICYINFO){
        
        this.QUOTEPOLICYLIABLIMITS = new QUOTEPOLICYLIABLIMITS(quotePolicyInformation);
        //this.GLPSTATEINFO = new GLPSTATEINFO();
        if(quotePolicyInformation != undefined || quotePolicyInformation != null) {
            this.QUOTEPOLICYINFORMATION = quotePolicyInformation;
        
        }
    }
    public AddAdditionalCoverage(coverage: string): void {
        
        //Return only if there are coverages that are not marked to be deleted for the coverage
        if(this.GLPLIABILITIES.filter(x=>x.COVERG === coverage && x.RECORDSTATE !="D").length > 0){
            return;
        }
        this.GLPLIABILITIES.push(new GLPLIABILITIES(this.QUOTEPOLICYINFORMATION, coverage, this.GLPLOCATIONS ));
        // //If the coverage does not exist - instantiate a new coverage and add it to the 
        // //array of GLPLIABILITIES
        // let considered: GLPLIABILITIES = new GLPLIABILITIES(this.QUOTEPOLICYINFORMATION, coverage, this.GLPLOCATIONS );
        // considered.COVERG = coverage;
        // // considered.POLICY = this.QUOTEPOLICYINFORMATION.QUOTEPOLICYNUMBER;
        // // considered.EFFDTE = this.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
        // // considered.TRANS  = this.QUOTEPOLICYINFORMATION.TRANSACTIONCODE;
        // // considered.RCDTYP = this.QUOTEPOLICYINFORMATION.RECORDTYPE;
        // // considered.EDSDTE = this.QUOTEPOLICYINFORMATION.ENDORSEMENTDATE;
        // considered.RECORDSTATE = "U";
        // if (considered.COVERG != 'EPL') { considered.EPILIM = '0'};
        
        // if (considered.COVERG == 'CEO')
        // {
        //     considered.C01PCA = "10000";
        //     considered.C01AGR = "50000";
        //     considered.C01DED = "1000";
        //     considered.C01RTR = this.QUOTEPOLICYINFORMATION.EFFECTIVEDATE;
        // }

        // if (considered.COVERG == 'CYB')
        // {
        //     considered.CYBAGG = 100000;
        //     // considered.CYBSAL = ""
        //     considered.CYBRDT = this.QUOTEPOLICYINFORMATION.EFFECTIVEDATE; //<= always same as effective date
        // }

        // this.GLPLIABILITIES.push(considered);

    }
    public RemoveAdditionalCoverage(coverage: string): void {

         //SET THE RECORD STATE OF THOSE ITEMS TO BE DELETED TO D
         this.GLPLIABILITIES.filter(x=>x.COVERG === coverage).forEach(x=>{
             x.RECORDSTATE = "D";
         })

    }

    public GetCoverage(coverage:string) : GLPLIABILITIES {

        let idx : number = -1;

        //Check to see if coverage already exists on the incoming quote.
        this.GLPLIABILITIES.find((x,index) => {
            if(x.COVERG === coverage && x.RECORDSTATE != "D") {
                idx = index;
            }
        });

        if(idx > -1){
            this.GLPLIABILITIES[idx].C01PCA = this.GLPLIABILITIES[idx].C01PCA.trim();
            this.GLPLIABILITIES[idx].C01AGR = this.GLPLIABILITIES[idx].C01AGR.trim();
            return this.GLPLIABILITIES[idx];
        }
        else {
            return new GLPLIABILITIES(this.QUOTEPOLICYINFORMATION, coverage, this.GLPLOCATIONS);
        }

    }

    
}
