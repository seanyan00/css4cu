
     /* ****************************************************************************************************
     * PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS - SEE LIBRARY AND TABLE/FILENAME 
     * AS400 LIBRARY        - MIGPUADTAM
     * TABLE/FILENAME       - DWCP032
     * DESCRIPTION          - WCA Recovery Waiver Master File
     * DATE CREATED         - 1/20/2021 9:59:45 AM
     * AUTHOR               - RICHARD FUMERELLE
     * VERSION              - 1.0
     * CODE GENERATION      - Automatic code generation using CodeSmith GenerationTool
     * NOTES                - This table can be modified.
     ****************************************************************************************************/

    export abstract class  DWCP032Abstract {
      
        POLICY : string = "";
        EFFDTE : number = 0;
        COVERG : string = "";
        SEQNO : string = "";
        EDSDTE : number = 0;
        EDSNO : number = 0;
        COVEND : number = 0;
        POTYPE : string = "";
        PODSC1 : string = "";
        PODSC2 : string = "";
        WAVPCT : number = 0;
        COVPRM : number = 0;
        WAVEFF : number = 0;
        STATS1 : string = "";

        constructor(){}
 
}

