
     /* ****************************************************************************************************
     * PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS - SEE LIBRARY AND TABLE/FILENAME 
     * AS400 LIBRARY        - MIGPUADTAM
     * TABLE/FILENAME       - DWCP035
     * DESCRIPTION          - WCA Location Information Master File
     * DATE CREATED         - 1/20/2021 9:59:48 AM
     * AUTHOR               - RICHARD FUMERELLE
     * VERSION              - 1.0
     * CODE GENERATION      - Automatic code generation using CodeSmith GenerationTool
     * NOTES                - This table can be modified.
     * BUG FIXES: 
     * 8/4/21: Fixed issue where premium was not generating the proper amount (TFS 2321) 
     * 10/19/21: Changed DWETYP to blank instead of N (TFS 2450)
     * 10/27/21: NEMPL default set to '0000' (TFS 2450)
     ****************************************************************************************************/

import { QUOTEBASECLASS } from "@classes/Common/QUOTEBASECLASS";
import { STATISTICS } from "@classes/Common/STATISTICS";
import { WCAClassExtended } from "./WCCLASSEXTENDEDABSTRACT";

    export class  WCALOCATIONS extends QUOTEBASECLASS {
      
        POLICY : string = "";
        EFFDTE : number = 0;
        COVERG : string = "";
        LOCNUM : string = "";
        EDSDTE : number = 0;
        EDSNO  : number = 0;

        TAXTER : string = "";
        COVEND : number = 0;
        LOCNAM : string = "";
        LOCAD1 : string = "";
        LOCAD2 : string = "";
        LOCCTY : string = "";
        LOCST : string = "";
        LOCZIP : string = "";
        NEMPL : string = "0000";
        BUSINESSCLASSES: WCAClassExtended[] = [];
        RECORDSTATE: string = "";

        constructor(){
            super();
        }

        // 8/5/21: added ASLOB as parameter in the event that the ASLOB changes from 160 in the future; the ASLOB is necessary for Rating. -JTL
        addNewBusinessClass(classCode: string, seqNo: string, classDescription: string, aslob: number, row?: WCAClassExtended): WCAClassExtended {
            //row is the row that we were editing.
            var newBusinessClass = new WCAClassExtended();
            newBusinessClass.TRANS = this.TRANS;
            newBusinessClass.POLICY = this.POLICY;
            newBusinessClass.EFFDTE = this.EFFDTE;
            newBusinessClass.LOCNUM = this.LOCNUM;
            newBusinessClass.EDSDTE = this.EDSDTE;
            newBusinessClass.COVERG = this.COVERG;
            newBusinessClass.CLASX = classCode;
            newBusinessClass.BLDNUM = seqNo;
            newBusinessClass.EXTDSC = classDescription;
            newBusinessClass.RECORDSTATE = "N";
            newBusinessClass.RCDTYP = 3; 
            newBusinessClass.COVRG = "11";
            newBusinessClass.BUSINESSCLASSSTATS.TRANS = this.TRANS;
            newBusinessClass.BUSINESSCLASSSTATS.POLICY = this.POLICY;
            newBusinessClass.BUSINESSCLASSSTATS.EFFDTE = this.EFFDTE;
            newBusinessClass.BUSINESSCLASSSTATS.LOCNUM = this.LOCNUM;
            newBusinessClass.BUSINESSCLASSSTATS.EDSDTE = 0;  //Because of blanking out of EDSDTE in DWXP150 after rating!
            newBusinessClass.BUSINESSCLASSSTATS.COVERG = this.COVERG;
            newBusinessClass.BUSINESSCLASSSTATS.CLASX = classCode;
            newBusinessClass.BUSINESSCLASSSTATS.BLDNUM = seqNo;
            newBusinessClass.BUSINESSCLASSSTATS.RECORDSTATE = "N";
            newBusinessClass.BUSINESSCLASSSTATS.COLCOV = "";
            newBusinessClass.BUSINESSCLASSSTATS.COMCOV = "";
            newBusinessClass.BUSINESSCLASSSTATS.DWETYP = "";
            newBusinessClass.BUSINESSCLASSSTATS.EXPOSE = 0;
            newBusinessClass.BUSINESSCLASSSTATS.PRMSTE = this.COVERG;
            newBusinessClass.BUSINESSCLASSSTATS.ASLOB = aslob; 
            newBusinessClass.BUSINESSCLASSSTATS.RCDTYP = 3; // when setting RCDTYP to 3 then it causes duplicate row but successful rate 
            //newBusinessClass.BUSINESSCLASSSTATS.CDDESC = classDescription;
            
            //let duplicate = this.BUSINESSCLASSES.find(x => x.CLASX === classCode && x.LOCNUM == this.LOCNUM && x.BUSINESSCLASSSTATS.RECORDSTATE !='D');
            //check to see if the classcode you are trying to select is a duplicate
            let duplicate = this.BUSINESSCLASSES.find(x => x.CLASX === classCode && x.LOCNUM == this.LOCNUM && x.BLDNUM == seqNo && x.BUSINESSCLASSSTATS.RECORDSTATE !='D');

            //chech new class to see if duplicate
            //this is emitting from the edit click
            if(this.BUSINESSCLASSES.length == 0 ){ //if no businessclasses on location, we know there can't be a duplicate
                this.BUSINESSCLASSES.push(newBusinessClass);
                return newBusinessClass;
            }
            else if (classCode != null && !duplicate){ // 
                if(row !=undefined || row != null){// row is defined when we are editing a previous business class.
                    this.BUSINESSCLASSES.find(x => x.CLASX === row.CLASX && x.LOCNUM === this.LOCNUM  && x.BLDNUM == row.BLDNUM).RECORDSTATE = 'D';
                    this.BUSINESSCLASSES.find(x => x.CLASX === row.CLASX && x.LOCNUM === this.LOCNUM  && x.BLDNUM == row.BLDNUM).BUSINESSCLASSSTATS.RECORDSTATE = 'D';
                    this.BUSINESSCLASSES.unshift(newBusinessClass); // since we only are able to edit the first business class, instead of pushing this onto the end. we add it to the beginning
                }
                else{
                    this.BUSINESSCLASSES.push(newBusinessClass);
                }
                return newBusinessClass;
		    }
            
        }
 
}

