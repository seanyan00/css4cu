
     /* ****************************************************************************************************
     * PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS - SEE LIBRARY AND TABLE/FILENAME 
     * AS400 LIBRARY        - MIGPUADTA
     * TABLE/FILENAME       - DWCP036
     * DESCRIPTION          - WCA Class Extended Text Master File
     * DATE CREATED         - 1/20/2021 9:59:50 AM
     * AUTHOR               - RICHARD FUMERELLE
     * VERSION              - 1.0
     * CODE GENERATION      - Automatic code generation using CodeSmith GenerationTool
     * NOTES                - This table can be modified.
     ****************************************************************************************************/

import { QUOTEBASECLASS } from "@classes/Common/QUOTEBASECLASS";
import { STATISTICS } from "@classes/Common/STATISTICS";

    export class WCAClassExtended extends QUOTEBASECLASS {
      
        POLICY : string = "";
        EFFDTE : number = 0;
        COVERG : string = "";
        EDSDTE : number = 0;
        CLASX : string = "";
        EXTDSC : string = "";
        LOCNUM : string = "";
        BUSINESSCLASSSTATS: STATISTICS = new STATISTICS();
        BLDNUM : string = "";
        COVRG: string = "11";
        RCDTYP: number = 3;
        RECORDSTATE: string = "";

        constructor(){
            super();
            this.BUSINESSCLASSSTATS = new STATISTICS();
        }
 
}

