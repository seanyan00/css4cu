/* ****************************************************************************************************
     * PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS - SEE LIBRARY AND TABLE/FILENAME 
     * AS400 LIBRARY        - MIGPUADTAM
     * TABLE/FILENAME       - DWCP062
     * DESCRIPTION          - WCA Application Master File
     * DATE CREATED         - 6/18/2021
     * AUTHOR               - Zach Gabel
     * VERSION              - 1.0
     * NOTES                - This table can be modified.
     ****************************************************************************************************/

import { QUOTEBASECLASS } from "@classes/Common/QUOTEBASECLASS";

    export class WCAACOUNTINGCONTACT extends QUOTEBASECLASS{
        POLICY : string = "";
        EFFDTE : number = 0;
        APPINC : string = "";
        APINCN : string = "";
        APINTL : string = "";
        APACCN : string = "";
        APACTL : string = "";

        APINPT : string = ""; // Added new fields to hold phone types
        APACPT : string = "";

        TRANS: string = "10";
        RCDTYP: number = 3;
        constructor(){
            super();
        }
    }