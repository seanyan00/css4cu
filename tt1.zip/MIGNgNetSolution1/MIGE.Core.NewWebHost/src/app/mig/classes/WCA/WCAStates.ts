     /* ****************************************************************************************************
     * PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS - SEE LIBRARY AND TABLE/FILENAME 
     * AS400 LIBRARY        - MIGPUADTAM
     * TABLE/FILENAME       - DWCP030
     * DESCRIPTION          - WCA Location Master File
     * DATE CREATED         - 1/20/2021 9:59:42 AM
     * AUTHOR               - RICHARD FUMERELLE
     * VERSION              - 1.0
     * CODE GENERATION      - Automatic code generation using CodeSmith GenerationTool
     * NOTES                - This table can be modified.
     *                      - 10/8/21: Set DWCP130.APPDIS to "N" (TFS 2476) -JTL
     ****************************************************************************************************/

import { QUOTEBASECLASS } from "@classes/Common/QUOTEBASECLASS";
import { WCALOCATIONS } from "./WCALocations";
import * as _ from 'lodash';
import { WCAIndividual } from "./WCAIndividual";

    export class  WCASTATES extends QUOTEBASECLASS{
      
        POLICY : string = "";
        EFFDTE : number = 0;
        COVERG : string = "";
        EDSDTE : number = 0;
        EDSNO : number = 0;
        COVEND : number = 0;

        PRMSTE : string = ""; // Premium State
        EXPMD1 : number = 0;  // Experience Mod 1
        EM1EFF : number = 0; // Experience Mod 1 Eff Date
        EM1EXP: number = 0; // Experience Mod Exp dates
        MERFCT : number = 0; // Merit Rating Factor

        DIAFCT : string = ""; // DIA Assesment Type 
        ARAFCT : number = 0; //  Mass ARAP Factor
        SCHMOD : number = 0;
        APPDIS : string = "N";
        AVHRWG : number = 0;
        INTRAR : string = "";
        UNEMPN : string = ""; 
        RCDTYP : number = 3;
        DEVCDE: string = "";
        //RTEFDT : number = 0;
        LOCATIONS: WCALOCATIONS[] = [];
        INDIVIDUALS: WCAIndividual[] = [];
        RECORDSTATE: string = "";
        StateLabel: string = "";
        constructor(){
            super();
        }



        AddnewLocation(): WCALOCATIONS {
            var newLocation = new WCALOCATIONS();
            newLocation.TRANS = this.TRANS;
            newLocation.POLICY = this.POLICY;
            newLocation.EFFDTE = this.EFFDTE;
            newLocation.EDSDTE = this.EDSDTE;
            newLocation.EDSNO = this.EDSNO;
            newLocation.COVEND = this.COVEND;
            newLocation.COVERG = this.COVERG;
            newLocation.LOCST = this.COVERG;
            newLocation.RECORDSTATE = "N"
            newLocation.RCDTYP = 3;

            var newNumericLocNum:number = _.filter(this.LOCATIONS, loc => loc.RECORDSTATE != 'D').length;
            newNumericLocNum++;
            newLocation.LOCNUM = _.padStart(newNumericLocNum.toString(), 3, '0');

            this.LOCATIONS.push(newLocation);
            return newLocation;
        }

        AddNewIndividual(): WCAIndividual {
            var newIndividual = new WCAIndividual();
            newIndividual.TRANS = this.TRANS;
            newIndividual.POLICY = this.POLICY;
            newIndividual.EFFDTE = this.EFFDTE;
            newIndividual.EDSDTE = this.EDSDTE;
            newIndividual.EDSNO = this.EDSNO;
            newIndividual.RCDTYP = 3;
            newIndividual.RECORDSTATE = "N";
            newIndividual.STCODE = this.PRMSTE;
            this.INDIVIDUALS.push(newIndividual);
            return newIndividual;

        }
 
}



