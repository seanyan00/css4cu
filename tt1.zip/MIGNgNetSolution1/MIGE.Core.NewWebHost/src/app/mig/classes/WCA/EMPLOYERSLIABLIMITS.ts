
     /* ****************************************************************************************************
     * PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS - SEE LIBRARY AND TABLE/FILENAME 
     * AS400 LIBRARY        - MIGPUADTAM
     * TABLE/FILENAME       - DWCP020
     * DESCRIPTION          - WCA Product Master File
     * DATE CREATED         - 1/20/2021 9:59:38 AM
     * AUTHOR               - RICHARD FUMERELLE
     * VERSION              - 1.0
     * CODE GENERATION      - Automatic code generation using CodeSmith GenerationTool
     * NOTES                - This table can be modified.
     ****************************************************************************************************/

import { QUOTEBASECLASS } from "@classes/Common/QUOTEBASECLASS";

    export class  EMPLOYERSLIABLIMITS extends QUOTEBASECLASS{
      
        // POLICY : string = "";
        // EFFDTE : number = 0;
        // EDSDTE : number = 0;
        // EDSNO : number = 0;
        COVEND : number = 0;
        EMPLIA : string = "";
        ANRTDT : number = 0;
        USLHFL : string = ""; // USL & H, used for WCA
        VLCMFL : string = ""; // Voluntary Compensation, used for WCA
        EMPFLG: string = "N"; // Setting this to an N so we can successfully rate quote - ZJG
        YRSBUS: number;
        EXPIND:string;
        //EMPLIAFORMAT: string = "";

        RECORDSTATE: string = "";
        
        constructor(){
            super();
        }
 
}

