     /* ****************************************************************************************************
     * PROGRAM DESCRIPTION  - EntityObject for LANSA or WINS - SEE LIBRARY AND TABLE/FILENAME 
     * AS400 LIBRARY        - MIGPUADTA
     * TABLE/FILENAME       - DWCP041
     * DESCRIPTION          - WCA Miscellaneous Individual Entry Master File
     * DATE CREATED         - 1/20/2021 9:59:50 AM
     * AUTHOR               - RICHARD FUMERELLE
     * VERSION              - 1.0
     * CODE GENERATION      - Automatic code generation using CodeSmith GenerationTool
     * NOTES                - This table can be modified.
     ****************************************************************************************************/

import { QUOTEBASECLASS } from "@classes/Common/QUOTEBASECLASS";

    export class  WCAIndividual extends QUOTEBASECLASS  {
      
        POLICY : string = "";
        EFFDTE : number = 0;
        MSCSEQ : string = "";
        RCDTYP : number = 0;
        EDSDTE : number = 0;
        EDSNO : number = 0;
        MSCNAM : string = "";
        MSCCLS : string = "";
        MSCPER : number = 0;
        MSCTTL : string = "";
        MSCDUT : string = "";
        MSCDOB : number = 0;
        MSCINC : string = "";
        MSCREM : number = 0;
        OTHEMPS : string = "";
        AFFIND : string = "";
        STCODE : string = "";
        RECORDSTATE: string = "";
        constructor(){
            super();
        }
 
}

