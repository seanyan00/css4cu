import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule,UntypedFormBuilder, ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule,HTTP_INTERCEPTORS} from '@angular/common/http';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {AppRoutingModule} from './app-routing.module';

//primeng componenets
import {AccordionModule} from 'primeng/accordion';
import {AutoCompleteModule} from 'primeng/autocomplete';
import {BreadcrumbModule} from 'primeng/breadcrumb';
import {ButtonModule} from 'primeng/button';
import {CalendarModule} from 'primeng/calendar';
import {CardModule} from 'primeng/card';
import {CarouselModule} from 'primeng/carousel';
import {CheckboxModule} from 'primeng/checkbox';
import {ChipsModule} from 'primeng/chips';
import {CodeHighlighterModule} from 'primeng/codehighlighter';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {ColorPickerModule} from 'primeng/colorpicker';
import {ContextMenuModule} from 'primeng/contextmenu';
import {DialogModule} from 'primeng/dialog';
import {DropdownModule} from 'primeng/dropdown';
import {FieldsetModule} from 'primeng/fieldset';
import {FileUploadModule} from 'primeng/fileupload';
import {GalleriaModule} from 'primeng/galleria';
import {InplaceModule} from 'primeng/inplace';
import {InputNumberModule} from 'primeng/inputnumber';
import {InputMaskModule} from 'primeng/inputmask';
import {InputSwitchModule} from 'primeng/inputswitch';
import {InputTextModule} from 'primeng/inputtext';
import {InputTextareaModule} from 'primeng/inputtextarea';
import {LightboxModule} from 'primeng/lightbox';
import {ListboxModule} from 'primeng/listbox';
import {MegaMenuModule} from 'primeng/megamenu';
import {MenuModule} from 'primeng/menu';
import {MenubarModule} from 'primeng/menubar';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import {MultiSelectModule} from 'primeng/multiselect';
import {OrderListModule} from 'primeng/orderlist';
//import {OrganizationChartModule} from 'primeng/organizationchart';
import {OverlayPanelModule} from 'primeng/overlaypanel';
import {PaginatorModule} from 'primeng/paginator';
import {PanelModule} from 'primeng/panel';
import {PanelMenuModule} from 'primeng/panelmenu';
import {PasswordModule} from 'primeng/password';
import {PickListModule} from 'primeng/picklist';
import {ProgressBarModule} from 'primeng/progressbar';
import {RadioButtonModule} from 'primeng/radiobutton';
import {RatingModule} from 'primeng/rating';
import {RippleModule} from 'primeng/ripple';
import {ScrollPanelModule} from 'primeng/scrollpanel';
import {SelectButtonModule} from 'primeng/selectbutton';
import {SlideMenuModule} from 'primeng/slidemenu';
import {SidebarModule} from 'primeng/sidebar';
import {SliderModule} from 'primeng/slider';
import {SpinnerModule} from 'primeng/spinner';
import {SplitButtonModule} from 'primeng/splitbutton';
import {StepsModule} from 'primeng/steps';
import {TabMenuModule} from 'primeng/tabmenu';
import {TableModule} from 'primeng/table';
import {TabViewModule} from 'primeng/tabview';
import {TerminalModule} from 'primeng/terminal';
import {TieredMenuModule} from 'primeng/tieredmenu';
import {ToastModule} from 'primeng/toast';
import {ToggleButtonModule} from 'primeng/togglebutton';
import {ToolbarModule} from 'primeng/toolbar';
import {TooltipModule} from 'primeng/tooltip';
import {TreeModule} from 'primeng/tree';
import {TreeTableModule} from 'primeng/treetable';
import {ConfirmationService} from 'primeng/api';
//import {DataViewModule} from 'primeng/dataview';
//import {FullCalendarModule} from 'primeng/fullcalendar';
import { DialogService } from 'primeng/dynamicdialog';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { DynamicDialogConfig } from 'primeng/dynamicdialog';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import { DividerModule } from 'primeng/divider';

/*overriden primeng components */
import {MIGYearPickerModule} from '@overridden/mig-yearpicker/year.module';
import {MIGButtonModule} from '@overridden/primeng-button/button.module';
import {MIGCalendarModule} from '@overridden/primeng-calendar/calendar.module';
import {MIGCheckboxModule} from '@overridden/primeng-checkbox/checkbox.module';
import {MIGDropDownModule} from '@overridden/primeng-dropdown/dropdown.module';
import {MIGInputModule} from '@overridden/primeng-input-text/mig-input.module';
import {MIGInputtextModule} from '@overridden/primeng-inputtext/input.module';
import {MIGMultiselectItemModule} from '@overridden/primeng-multiselect/item.module';
import {MIGMultiselectModule} from '@overridden/primeng-multiselect/multiselect.module';
import {MIGOverlayPanelModule} from '@overridden/primeng-overlaypanel/overlay.module';
import {MIGProgessbarModule} from '@overridden/primeng-progressbar/progress.module';
import {MIGSpinnerModule} from '@overridden/primeng-spinner/spinner.module';
import {MIGTextareaModule} from '@overridden/primeng-textarea/area.module';

/*MIG services and misc modules*/
import {Functions} from '@helpers/functions'; 
import {AuthModule} from '@auth/auth.module';
import {PipesModule} from '@pipes/pipes.module';
import {MIGNotifyModule} from './shared_components/notify/notify.module';
import {SystemErrorModule} from '@shared/system_error/system_error.module';
import {MIGFileUploadModule} from '@overridden/primeng-fileupload/fileupload';
/**services */
import {MessageService} from 'primeng/api';
import {AuthGuard} from '@auth/auth.guard';
import {AuthService} from '@auth/auth.service';
import {CookieService} from 'ngx-cookie-service';
import {MenuClass} from '@root/system/menu/menu';
import {QuoteService} from '@services/quote.service';
import {ErrorService} from '@services/error.service';
import {LogService} from './services/logging.service';
import {PolicyService} from '@services/policy.service';
import {MIGSystemService} from '@services/mig.service';
import {RatingService} from './services/rating.service';
import {StatesService} from '@services/states.service';
import {TooltipService} from './services/tooltip.service';
import {WhatsnewService} from '@services/whatsnew.service';
import {DropDownService} from '@services/dropdown.service';
import {BopOptionalCoveragesService} from '@services/bop_optional_coverages.service';
import {DocumentService} from './services/document.service';

import {AuthInterceptor} from '@auth/auth-interceptor.service';
import {WorkbenchService} from './services/workbench.service';
import {MIGSecurityRoles} from '@classes/Common/roles/roles.class';
import {DiscWorksheetService} from '@services/disc-worksheet.service'
import {ErrorInterceptor} from '@system/interceptors/error-interceptor.service';


//MIG components
import {AppComponent} from './app.component';
import {InputMasksClass} from '@helpers/masks';
import {ContractorsTooltips} from '@helpers/tooltips';
import {ContractorsDropDowns} from '@helpers/dropdowns';
import {AppMenuComponent} from '@system/menu/app.menu.component';
import {AppSubMenuComponent} from '@system/menu/app.menu.component';
import {AppTopBarComponent} from '@system/topbar/topbar.component';

import {AppFooterComponent} from '@system/footer/app.footer.component';
import {AppRightNavComponent} from '@system/right_nav/rightnav.component';
import {FilelistingComponent} from '@system/right_nav/FileListing/filelisting.component';
import {PublicErrorDisplayComponent} from '@shared/public_error_display/public_error_display.component';

import {CTRQuoteClass} from '@classViewModels/CTR/quote.class';
import { DiscretionaryClass } from '@shared/Discretionary_WorkSheet/discretionary-class';
import {ExtensionBusinessRules} from '@CTRcomponents/additional_coverages/liability/extension/extension-business-rules';
import { UnderwritingService } from './services/underwriting.service';
import { ReportItemModule } from './shared_components/report_item/report_item.module';
import { RiskAppetiteGuideModule } from './shared_components/risk-appetite-guide/risk-appetite-guide.module';
import { ErrorModule } from './shared_components/errors/errors.module';
import { ProgressModule } from './shared_components/progress/progress.module';
import { ChangeLogModule } from './shared_components/changelog/changelog.module';
import { DEFAULT_TIMEOUT, TimeoutInterceptor } from './services/timeout-interceptor.service';
import { RoutingredirectComponent } from './system/redirect/routingredirect.component';
import { BopOptionalCoveragesData } from '@helpers/bop_optional_coverages';

@NgModule({
  declarations: [
    AppComponent,
    AppMenuComponent,
    AppSubMenuComponent,
    AppTopBarComponent,
    AppFooterComponent,
    AppRightNavComponent,
    FilelistingComponent,
    PublicErrorDisplayComponent,
    RoutingredirectComponent,
  ],
  imports: [
    AppRoutingModule,
    CommonModule,
    FormsModule,
    AccordionModule,
    AutoCompleteModule,
    BreadcrumbModule,
    BrowserModule,
    BrowserAnimationsModule,
    ButtonModule,
    CalendarModule,
    CardModule,
    CarouselModule,
    ChangeLogModule,
    CheckboxModule,
    ChipsModule,
    CodeHighlighterModule,
    ConfirmDialogModule,
    ColorPickerModule,
    ContextMenuModule,    
    DialogModule,
    DropdownModule,
    ErrorModule,
    FieldsetModule,
    FileUploadModule,
    // FormsModule,
    GalleriaModule,
    HttpClientModule,
    InplaceModule,
    InputNumberModule,
    InputMaskModule,
    InputSwitchModule,
    InputTextModule,
    InputTextareaModule,
    LightboxModule,
    ListboxModule,
    MegaMenuModule,
    MenuModule,
    MenubarModule,
    MessageModule,
    MessagesModule,
    MultiSelectModule,
    OrderListModule,
    //OrganizationChartModule,
    OverlayPanelModule,
    PaginatorModule,
    PanelModule,
    PanelMenuModule,
    PasswordModule,
    PickListModule,
    PipesModule,
    ProgressModule,
    ProgressBarModule,
    PanelModule,
    RadioButtonModule,
    RatingModule,
    ReportItemModule,
		ReactiveFormsModule,
    RippleModule,
    RiskAppetiteGuideModule,
    ScrollPanelModule,
    SelectButtonModule,
    SlideMenuModule,
    SidebarModule,
    SliderModule,
    SpinnerModule,
    SplitButtonModule,
    StepsModule,
    TableModule,
    TabMenuModule,
    TabViewModule,
    TerminalModule,
    TieredMenuModule,
    ToastModule,
    ToggleButtonModule,
    ToolbarModule,
    TooltipModule,
    TreeModule,
    TreeTableModule,   
    DynamicDialogModule, 
    DividerModule,
    //DataViewModule,
    //FullCalendarModule,
    /*overridden components*/
    MIGYearPickerModule,
    MIGButtonModule,
    MIGCalendarModule,
    MIGCheckboxModule,
    MIGDropDownModule,
    MIGFileUploadModule,
    MIGInputModule,
    MIGInputtextModule,
    MIGMultiselectItemModule,
    MIGMultiselectModule,
    MIGOverlayPanelModule,
    MIGProgessbarModule,
    MIGSpinnerModule,
    MIGTextareaModule,
    MIGFileUploadModule,
    //WorkersCompModule, 
    // ContractorsModule, // we are now lazy loading this module in app.routing.ts -JTL
    MIGNotifyModule,
    SystemErrorModule,
    /*extras*/
    AuthModule,
    PipesModule
  ],
  providers: [
    AuthGuard,	
		WorkbenchService,		
    //
    MIGSystemService, 
    AuthService,
    CookieService,
    QuoteService,
    MenuClass,
    MessageService,
    ErrorService,
    MIGSecurityRoles,
    TooltipService,
    UntypedFormBuilder,
    ConfirmationService,
    WhatsnewService,
    ContractorsTooltips,
    PolicyService,
    ContractorsDropDowns,
    DropDownService,
    BopOptionalCoveragesData,
    BopOptionalCoveragesService,
    CTRQuoteClass,
    InputMasksClass,
    ExtensionBusinessRules,
    DialogService,
		DynamicDialogRef,
		DynamicDialogConfig,
    LogService,
    RatingService,
    DocumentService,
    StatesService,
    DiscWorksheetService,
		DiscretionaryClass,
    UnderwritingService,
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
		{ provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    [{ provide: HTTP_INTERCEPTORS, useClass: TimeoutInterceptor, multi: true }],
     [{ provide: DEFAULT_TIMEOUT, useValue: 210000 }],
    //[{ provide: DEFAULT_TIMEOUT, useValue: 20000 }],

    Functions],
 
  bootstrap: [AppComponent]
})
export class AppModule { }
