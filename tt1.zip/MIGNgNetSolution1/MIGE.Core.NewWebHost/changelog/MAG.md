### week of 7-16-2018

*Monday*
* Created this list
* Fixed responsiveness
* Cross browser testing in IE, FF, & Chrome
* Fixed side navigation expand / collapse when changing browser window size
* Fixed ui-float-label for dropdowns and quote description
* Cleaned up quote_information.component.ts

*Tuesday*
* Visio diagram for location / property coverage
* fixed bugs in next() / prev() functions in contractors.component.ts
* merged into contractors-3.0 branch
* started going through the attachments user stories and updating overridden_components/primeng_fileupload

*Wednesday*
* removed app.component import from contractors.component - switched to using the navigation service
* prototype of dynamic form generator for underwriting questions

*Thursday*
* out sick

*Friday*
* finished up underwriting prototype
* moved erros block to own component / module
* moved CTR footer to component / module
* Visio diagram of component relationship to each other
