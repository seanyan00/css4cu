﻿using System;
using System.Threading.Tasks;
using System.Linq;
using System.Reflection;
using Grpc.Core;
using Google.Protobuf.WellKnownTypes;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;

using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Util;
using CRFS.IS.Service.Security;
using CRFS.IS.Service.Business;
using CRFS.IS.Service.Common;

namespace CRFS.IS.Service.Services
{
    public class DataAutomationService : DataAutomation.DataAutomationBase
    {
        private readonly IConfiguration _config;
        private readonly ILogger<DataAutomationService> _logger;
        public DataAutomationService(ILogger<DataAutomationService> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
        }
        public override Task<GetFHAConnectionAccountsReply> GetFHAConnectionAccounts(Empty _, ServerCallContext context)
        {
            var ret = new GetFHAConnectionAccountsReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                return Task.FromResult(new DataAutomationProvider(_config, _logger, user.UserId).GetFHASystemAccounts());
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
            }
            return Task.FromResult(ret);
        }
        public override Task<DAMessageReply> GetFHAConnPwd(DAIdRequest request, ServerCallContext context)
        {
            var ret = new DAMessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                ret.Message = new DataAutomationProvider(_config, _logger, user.UserId).GetPassword(request.Id);
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = Constant.PasswordStr;
            }
            return Task.FromResult(ret);
        }
        public override Task<DAMessageReply> SaveFHAConnectionAccount(AutoSystem request, ServerCallContext context)
        {
            var ret = new DAMessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new DataAutomationProvider(_config, _logger, user.UserId).SaveAutoSystem(request);
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
    }
}
