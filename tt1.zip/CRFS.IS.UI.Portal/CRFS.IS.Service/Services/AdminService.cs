﻿using System;
using System.Threading.Tasks;
using System.Linq;
using System.Reflection;
using Grpc.Core;
using Google.Protobuf.WellKnownTypes;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;

using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Business;
using CRFS.IS.Service.Util;
using CRFS.IS.Service.Security;

namespace CRFS.IS.Service.Services
{
    public class AdminService : Admin.AdminBase
    {
        private readonly IConfiguration _config;
        private readonly ILogger<AdminService> _logger;
        public AdminService(ILogger<AdminService> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
        }
        public override Task<GetUsersReply> GetUsers(Empty _, ServerCallContext context)
        {
            var ret = new GetUsersReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);

                ret = new AdminProvider(_config, _logger, user.UserId).GetUsers();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
            }
            return Task.FromResult(ret);
        }
        public override Task<AdminMessageReply> SaveUser(PortalUser request, ServerCallContext context)
        {
            var ret = new AdminMessageReply();

            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "LossAnalysis", true))
                {
                    throw new Exception("Not a valid token or timed out");
                }
                var user = SessionProvider.GetUser(token.Value);
                ret.Message = new AdminProvider(_config, _logger, user.UserId).SaveUser(request);
            }
            catch (Exception ex)
            {
                Util.SessionMessage.Write(string.Format("Error at {0}, {1} {2}", MethodBase.GetCurrentMethod().Name, ex.Message, ex.StackTrace));
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return Task.FromResult(ret);
        }
    }
}