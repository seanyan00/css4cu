﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRFS.IS.Service.Common.TransferObjects
{
    public class DataEntityDTO
    {
        public int Idx { get; set; }
        public List<DataField> DataFields { get; set; }
        public DataEntityDTO()
        {
            DataFields = new List<DataField>();
        }
    }
    public class DataField
    {
        public string Name { get; set; }
        public int Idx { get; set; }
        public object Value { get; set; }
    }
}
