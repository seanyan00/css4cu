﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRFS.IS.Service.Common.TransferObjects
{
    public class LAExpenseDTO
    {
        public string LoanNumber { get; set; }
        public string FHACaseNumber { get; set; }
        public string Category { get; set; }
        public DateTime? PaidDate { get; set; }
        public double? AmoutDisbursed { get; set; }
        public double? AmoutClaimed { get; set; }
        public string ItemDescription { get; set; }
        public string AdvaceFrom { get; set; }
        public DateTime? WorkCompleteDate { get; set; }
        public double? Quantity { get; set; }
        public DateTime? CoverageStartDate { get; set; }
        public DateTime? CoverageEndDate { get; set; }
        public string ChargeOffReason { get; set; }
        public double? ClaimAmountOverride { get; set; }
        public string ResponsibleParty { get; set; }
        public double? PenaltiesFeesInterest { get; set; }
        public string InvoiceNumber { get; set; }
        public string Details { get; set; }
    }
}
