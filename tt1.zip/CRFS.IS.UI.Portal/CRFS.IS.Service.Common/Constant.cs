﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Common
{
    public static class Constant
    {
        public const int MB = 1048576;
        public const int NULLINT = 999999999;
        public const string PasswordStr = "************";
        public const string InitPassword = "password";
        public const string DOMAIN = "crfs.crfservices.com";
        public const string EmptyDateTime = "01/01/1900";
        public const string DateString = "MM/dd/yyyy";
        public const string DateTimeString = "MM/dd/yyyy HH:mm:ss";
        public const string DateTimeStringFlat = "yyyyMMddHHmmss";
        public const string DateStringFlat = "yyyyMMdd";
        public const string Success = "Success";
        public const string FailedNum = "-1";
        public const string SuccessNum = "0";
        public const int MAXEXPENSEROW = 4000;
        public const int ERRORMSGLEN = 2000;
        public const int DBCommandTimeout = 300;
        public const int DBCommandTimeoutLong = 1800;
        public const string TypeNamespace = "CRFS.IS.Service.Data";
        public const string SendFrom = "DoNotReply@crfservices.com";

        public enum UIPrivilege
        {
            None = 0,
            Read,
            Write,
            Delete,
            Admin
        }

        public static readonly Dictionary<string, string> DBTypeMap = new Dictionary<string, string>
        {
            { "Byte", "System.Byte" }
        };
    }
}
