﻿namespace CRFS.IS.Service.Common
{
    public class AppSettings
    {
        public string FilePath { get; set; }
        public int Scheduler_Interval { get; set; }
        public string CompressorUsers { get; set; }
        public int CompressorSessionIdleTime { get; set; }
        public string MailServer { get; set; }
        public int FHAConn_PWDPastDue { get; set; }
        public int FHAConn_PWDIsDue { get; set; }
    }
}
