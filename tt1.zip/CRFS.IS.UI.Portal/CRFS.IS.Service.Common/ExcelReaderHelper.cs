﻿using System;
using System.Collections.Generic;
using System.Text;

using NPOI;
using NPOI.SS.UserModel;
using NPOI.HSSF.UserModel;

namespace CRFS.IS.Service.Common
{
    public static class ExcelReaderHelper
    {
        public static T? GetCellValue<T>(this ICell cell) where T : struct
        {
            var t = typeof(T);

            if (cell == null || cell.CellType == CellType.Blank)
                return null;

            switch (t.FullName)
            {
                case "System.Boolean":
                    return (T)Convert.ChangeType(cell.BooleanCellValue, t);
                case "System.Int32":
                case "System.Double":
                    return (T)Convert.ChangeType(cell.NumericCellValue, t);
                case "System.DateTime":
                    return (T)Convert.ChangeType(cell.DateCellValue, t);
                default:
                    return default(T);
            }
        }
        public static string GetCellValueAsString(this ICell cell)
        {
            if (cell == null || cell.CellType == CellType.Blank)
                return null;

            if (cell.CellType == CellType.String)
                return cell.StringCellValue;

            return cell.ToString();
        }
        public static string GetCellString(this ICell cell)
        {
            if (cell == null || cell.CellType == CellType.Blank)
                return null;

            if (cell.CellType == CellType.Numeric)
                return cell.NumericCellValue.ToString();

            return cell.StringCellValue;
        }
        public static bool IsRowEmpty(IRow row)
        {
            if (row == null)
                return true;
            if (row.LastCellNum <= 0)
                return true;

            for (int i = row.FirstCellNum; i < row.LastCellNum; i++)
            {
                ICell cell = row.GetCell(i);
                if (cell != null && cell.CellType != CellType.Blank && !string.IsNullOrEmpty(cell.ToString()))
                {
                    return false;
                }
            }

            return true;
        }
    }
}
