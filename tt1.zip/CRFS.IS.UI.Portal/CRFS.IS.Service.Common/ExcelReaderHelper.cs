﻿using System;
using System.Collections.Generic;
using System.Text;

using NPOI;
using NPOI.SS.UserModel;
using NPOI.HSSF.UserModel;
using NPOI.XSSF.UserModel;

namespace CRFS.IS.Service.Common
{
    public static class ExcelReaderHelper
    {
        public static T? GetCellValue<T>(this ICell cell) where T : struct
        {
            var t = typeof(T);

            if (cell == null || cell.CellType == CellType.Blank)
                return null;

            switch (t.FullName)
            {
                case "System.Boolean":
                    return (T)Convert.ChangeType(cell.BooleanCellValue, t);
                case "System.Int32":
                case "System.Double":
                    return (T)Convert.ChangeType(cell.NumericCellValue, t);
                case "System.DateTime":
                    return (T)Convert.ChangeType(cell.DateCellValue, t);
                default:
                    return default(T);
            }
        }
        
        public static void SetCellValue(this ICell cell, object val, string typename)
        {
            if (val == null)
            {
                cell.SetCellValue("");
            }
            else
            {
                switch (typename)
                {
                    case "Boolean":
                        cell.SetCellValue((bool)val);
                        break;
                    case "Integer":
                        cell.SetCellValue((int)val);
                        break;
                    case "Double":
                        cell.SetCellValue(Convert.ToDouble(val));
                        break;
                    case "Date":
                        cell.SetCellValue(((DateTime)val).ToString(Constant.DateString));
                        break;
                    case "DateTime":
                        cell.SetCellValue(((DateTime)val).ToString(Constant.DateTimeString));
                        break;
                    default:
                        cell.SetCellValue(val.ToString());
                        break;
                }
            }
        }
        public static string GetCellValueAsString(this ICell cell)
        {
            if (cell == null || cell.CellType == CellType.Blank)
                return null;

            if (cell.CellType == CellType.String)
                return cell.StringCellValue;

            if (cell.CellType == CellType.Formula)
            {
                switch (cell.CachedFormulaResultType)
                {
                    case CellType.Numeric:
                        return cell.NumericCellValue.ToString();
                    case CellType.String:
                        return cell.RichStringCellValue.ToString();
                    default:
                        return cell.NumericCellValue.ToString();
                }
            }
        
            return cell.ToString();
        }
        public static string GetCellString(this ICell cell)
        {
            if (cell == null || cell.CellType == CellType.Blank)
                return null;

            if (cell.CellType == CellType.Numeric)
                return cell.NumericCellValue.ToString();

            return cell.StringCellValue;
        }
        public static bool IsRowEmpty(IRow row)
        {
            if (row == null)
                return true;
            if (row.LastCellNum <= 0)
                return true;

            for (int i = row.FirstCellNum; i < row.LastCellNum; i++)
            {
                ICell cell = row.GetCell(i);
                if (cell != null && cell.CellType != CellType.Blank && !string.IsNullOrEmpty(cell.ToString()))
                {
                    return false;
                }
            }

            return true;
        }
    }
}
