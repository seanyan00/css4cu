﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace CRFS.IS.Service.Common
{
    public static class CommonHelper
    {
        public static T? GetNullValue<T>(this string s) where T : struct
        {
            return string.IsNullOrEmpty(s) ? null : (T?)Convert.ChangeType(s, typeof(T));
        }
        public static T? GetNullValue<T>(this T v) where T : struct
        {
            if(Convert.ToInt32(v) == Constant.NULLINT)
            {
                return (T?)null;
            }
            return (T?)v;
        }
        public static DateTime? GetNullDate(this string s)
        {
            return string.IsNullOrEmpty(s) ? (DateTime?)null : Convert.ToDateTime(s.GetSafeDateString());
        }
        public static T? GetNullIntOrId<T>(this T v) where T : struct
        {
            if (Object.Equals(v, Convert.ChangeType(Constant.NULLINT, typeof(T))) || Object.Equals(v, default(T)))
                return default(T);

            return v;
        }
        public static DateTime SetKind(this DateTime dt, DateTimeKind kind)
        {
            return DateTime.SpecifyKind(dt, kind);
        }
        public static string GetSafeString(this DateTime? dt)
        {
            return dt == null || dt == DateTime.MinValue || dt <= Convert.ToDateTime(Constant.EmptyDateTime) ? "" : ((DateTime)dt).ToString(Constant.DateString);
        }
        public static string GetSafeString(this DateTime dt)
        {
            return dt == null || dt == DateTime.MinValue ? "" : dt.ToString(Constant.DateString);
        }
        public static string GetSafeDateTimeString(this DateTime dt)
        {
            return dt == null || dt == DateTime.MinValue ? "" : dt.ToString(Constant.DateTimeString);
        }
        public static string GetSafeDateTimeString(this DateTime? dt)
        {
            return dt.IsNullDate() ? "" : ((DateTime)dt).ToString(Constant.DateTimeString);
        }
        public static bool IsNullDate(this DateTime? dt)
        {
            return dt == null || dt == DateTime.MinValue || dt <= Convert.ToDateTime(Constant.EmptyDateTime);
        }
        public static string GetSafeString(this string s)
        {
            return string.IsNullOrEmpty(s) ? "" : s;
        }
        public static T GetSafeValue<T>(this T v)
        {
            Type t = typeof(T);
            if(t == typeof(string))
                return v == null ? (T)(object)string.Empty : v;
            if (t.IsValueType) {
                var ut = Nullable.GetUnderlyingType(t);
                if (ut == null)
                    return v == null ? default(T) : v;
                else {
                    return v == null ? (T)Activator.CreateInstance(ut) : v;
                }
            } 
            return v;
        }
        public static bool? GetBoolValue(this int v)
        {
            if (v == 0)
                return false;
            if (v == 1)
                return true;
            return null;
        }
        public static int GetIntValue(this bool? v)
        {
            if (v == null)
                return Constant.NULLINT;
            if (v == true)
                return 1;
            else
                return 0;
        }
        public static int GetIntValue(this int? v)
        {
            if (v == null)
                return Constant.NULLINT;
            
            return v ?? 0;
        }
        public static string GetSafeDateString(this string s)
        {
            if (string.IsNullOrEmpty(s))
                return Constant.EmptyDateTime;
            return s;
        }
        public static string GetDateString(this string s)
        {
            var reg = new Regex(@"^\d{1,2}/\d{1,2}/(\d{2}|\d{4})$");
            var cy = DateTime.Now.Year.ToString().Substring(2);
            if (reg.IsMatch(s))
            {
                var darr = s.Split("/");
                var m = darr[0].PadLeft(2, '0');
                var d = darr[1].PadLeft(2, '0');
                var y = darr[2].Length == 4 ? darr[2] : (Convert.ToInt32(darr[2]) > Convert.ToInt32(cy) ? ("19" + darr[2]) : ("20" + darr[2]));
                 return m + "/" + d + "/" + y;
            }
            return string.IsNullOrEmpty(s) ? "" : s;
        }
    }
}
