﻿using System;

namespace CRFS.IS.Service.Data.DAOs.Models
{
    public class SiteUser
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string UName { get; set; }
        public int Lock { get; set; }
        public DateTime LockedAt { get; set; }
        public string Domain { get; set; }
        public int DomainId { get; set; }
        public bool Status { get; set; }
    }
}
