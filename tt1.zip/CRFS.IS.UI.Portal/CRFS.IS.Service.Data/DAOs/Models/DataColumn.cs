﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRFS.IS.Service.Data.DAOs.Models
{
    class DataColumn
    {
    }
}
