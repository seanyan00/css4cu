﻿using System.Collections.Generic;

namespace CRFS.IS.Service.Data.DAOs.Models
{
    public class SiteTable
    {
        public string Name { get; set;}
        public string TType { get; set; }
        public List<Column> Cols { get; set; }
        public SiteTable()
        {
            Cols = new List<Column>();
        }
    }

    public class Column
    {
        public string Name { get; set; }
        public int Idx { get; set; }
        public string DataType { get; set; }
        public bool IsKey { get; set; }
        public bool Nullable { get; set; }
        public string DefaultValue { get; set; }
        public bool HasDefaultValue { get; set; }
        public int MaxLength { get; set; }
    }

}
