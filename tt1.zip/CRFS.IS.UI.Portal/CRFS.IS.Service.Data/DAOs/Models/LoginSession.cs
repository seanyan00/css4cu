﻿using System;

namespace CRFS.IS.Service.Data.DAOs.Models
{
    public class LoginSession
    {
        public int Id { get; set; }
        public int UId { get; set; }
        public DateTime LoginStart { get; set; }
        public int FailedCount { get; set; }
        public DateTime LastFailed { get; set; }
        public DateTime LastLog { get; set; }
    }
}
