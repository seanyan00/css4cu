﻿namespace CRFS.IS.Service.Data.DAOs.Models
{
    public class Grant
    {
        public int Id { get; set; }
        public int UId { get; set; }
        public string UType { get; set; }
        public int OId { get; set; }
        public int Perm { get; set; }
        public int Status { get; set; }
    }
}
