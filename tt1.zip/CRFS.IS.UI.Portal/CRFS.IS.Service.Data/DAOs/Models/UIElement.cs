﻿namespace CRFS.IS.Service.Data.DAOs.Models
{
    public class UIElement
    {
        public int id { get; set; }
        public string nm { get; set; }
        public string typ { get; set; }
        public int said { get; set; }
        public string site { get; set; }
        public string desc { get; set; }
        public int dtcid { get; set; }
        public int ftblid { get; set; }
        public int ttblid { get; set; }
        public int perm { get; set; }
        public string pos { get; set; }
        public int stat { get; set; }
        public int pid { get; set; }
        public int cbyid { get; set; }
    }
}
