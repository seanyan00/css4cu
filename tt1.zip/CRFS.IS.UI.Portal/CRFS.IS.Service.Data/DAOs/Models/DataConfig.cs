﻿namespace CRFS.IS.Service.Data.DAOs.Models
{
    public class DataConfig
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string DCType { get; set; }
        public string EntName { get; set; }
        public string Sql { get; set; }
        public int DBCId { get; set; } 
    }
}
