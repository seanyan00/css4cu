﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.Common.TransferObjects;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.Data.DAOs.Models;
using CRFS.IS.Service.Data.Extensions;

namespace CRFS.IS.Service.Data.DAOs
{
    public class RawSqlDAO 
    {
        public static readonly Dictionary<string, string> MSSqlTypeMap = new Dictionary<string, string>
        {
            {"bigint", "System.Int64" },
            {"binary", "System.Byte[]" },
            { "bit", "System.Boolean"},
            {"char", "System.String" },
            { "date", "System.DateTime"},
            {"datetime", "System.DateTime" },
            {"datatime2", "System.DateTime" },
            {"datetimeoffset", "System.DateTimeOffset" },
            {"decimal", "System.Decimal" },
            {"float", "System.Double" },
            {"geography", "System.Byte[]" },
            {"geometry", "System.Byte[]" },
            {"hierarchyid", "System.Int32" },
            {"image", "System.Byte[]" },
            {"int", "System.Int32" },
            {"money", "System.Decimal" },
            {"nchar", "System.String" },
            {"ntext", "System.String" },
            {"numeric", "System.Decimal" },
            {"nvarchar", "System.String" },
            {"real", "System.Single" },
            {"smalldatetime", "System.DateTime" },
            {"smallint", "System.Int16" },
            {"smallmoney", "System.Decimal" },
            {"sql_variant", "System.String" },
            {"text", "System.String" },
            {"time", "System.TimeSpan" },
            {"timestamp", "System.DateTime" },
            {"tinyint", "System.Byte" },
            {"uniqueidentifier", "System.String" },//System.Guid
            {"varbinary", "System.Byte[]" },
            {"varchar", "System.String" },
            {"xml", "System.Xml" },
        };

        private SqlConnection _conn;
        private SqlTransaction _tran;
        private int _uid;
        private bool _disposed = false;
       
        public List<SqlParameter> Params { get; set; }

        public RawSqlDAO()
        {

        }

        public RawSqlDAO(int uid, DbContext ctx, SqlTransaction tran) 
        {
            _uid = uid;
            _conn = (SqlConnection)ctx.Database.GetDbConnection();
            _tran = tran;
            Init();
        }

        protected void Init()
        {
            Params = new List<SqlParameter>();

            try
            {
                
            }
            catch
            {
                throw; 
            }
        }

        protected void Dispose(bool disposing)
        {

            if (disposing)
            {
                if (!_disposed)
                {
                    _conn.Dispose();
                    _disposed = true;
                }
            }
        }
             
        private string GetAlias(string pname, Dictionary<string, string> alias)
        {
            var ret = pname;
            var tn = pname.Split(new char[] { '.' })[0];

            foreach (var a in alias)
            {
                var tn1 = a.Key.Split(new char[] { '.' })[1];
                if (tn.ToLower() == tn1.ToLower())
                {
                    ret = a.Value + "." + pname.Split(new char[] { '.' })[1];
                    break;
                }
            }
            return ret;
        }
    
        public SqlDataReader GetReader(string sql)
        {
            return (SqlDataReader)GetDataReader(sql);
        }
        public object GetDataReader(string sql)
        {
            SqlCommand cmd = new SqlCommand(sql, _conn);
            if (_tran != null)
                cmd.Transaction = _tran;

            if (Params.Count > 0)
                cmd.Parameters.AddRange(Params.ToArray());
            SqlDataReader r = cmd.ExecuteReader();
            if (Params.Count > 0)
                Params.Clear();
            return r;
        }
      
        public void LoadData(string tblnm, List<DataEntityDTO> deds, LkpDataset ds)
        {
            var tbl = GetClientTable(tblnm);
          
            if(ds.ClearBeforeLoad ?? false)
            {
                var sql = "delete " + tblnm + ";";
                RunSql(sql);
            }

            foreach (var ded in deds)
            {
                var clist = new StringBuilder();
                var vlist = new StringBuilder();
                bool first = true;
                LkpDatasetFieldMapping dfm = null;

                string searchnm = "";

                clist.Append("insert into " + tblnm + "(");
                vlist.Append(" values(");

                foreach (var c in tbl.Cols)
                {
                    searchnm = c.Name;

                    if (c.IsIdentity)
                        continue;

                    dfm = ds.LkpDatasetFieldMapping.Where(x => x.AttributeName.NormalString().ToLower() == c.Name.NormalString().ToLower()).SingleOrDefault();
                    if(dfm != null && (dfm.AutoFill ?? false))
                    {
                        clist.Append((first ? "" : ",") + c.Name);
                        switch (dfm.FillType)
                        {
                            case "Date":
                                vlist.Append((first ? "" : ",") + "getdate()");
                                break;
                            case "UserID":
                                vlist.Append((first ? "" : ",") + _uid.ToString());
                                break;
                            default:
                                break;
                        }
                        first = false;
                        continue;
                    }                    
                    foreach (var ele in ded.DataFields)
                    {
                        if (ele.Name.NormalString().ToLower() == ((dfm != null && !(dfm.AutoFill ?? false)) ? dfm.FieldName.NormalString().ToLower() : c.Name.NormalString().ToLower()))
                        {
                            if (ele.Value != null)
                            {
                                clist.Append((first ? "" : ",") + c.Name);
                                var v = ExcelDateTimeFromNumber(ele.Value.ToString(), c.DataType);
                                vlist.Append((first ? "" : ",") + DecoString(v, c.DataType));
                                first = false;
                            }
                        }
                    }
                }
                clist.Append(")");
                vlist.Append(");");

                RunSql(clist.ToString() + vlist.ToString());
            }
            _tran.Commit();

            if(!string.IsNullOrEmpty(ds.Sproc))
            {
                var sql = "exec " + ds.Sproc + ";";
                RunSql(sql);
            }
        }
       
        private string DecoString(string v, string t)
        {
            if (t == "System.String" || t == "System.DateTime" || t == "System.Date")
                return "'" + v + "'";
            else
                return v;
        }
        private string ExcelDateTimeFromNumber(string value, string t)
        {
            if (t == "System.DateTime" || t == "System.Date")
            {
                double d = 0.0;
                var result = double.TryParse(value, out d);
                if (result && d >= 1 && d <= 60000)
                    return DateTime.FromOADate(d).ToString();
            }

            return value;
        }
        public void BeginTran()
        {
            _tran = _conn.BeginTransaction();
        }
        public void Commit()
        {
            _tran.Commit();
            _tran = null;
        }
        public void Rollback()
        {
            _tran.Rollback();
            _tran = null;
        }
        public int RunSql(string sql)
        {
            int ret = 0;

            SqlCommand cmd = new SqlCommand(sql, _conn);
            if (_tran != null)
                cmd.Transaction = _tran;

            if (Params.Count > 0)
                cmd.Parameters.AddRange(Params.ToArray());
            ret = cmd.ExecuteNonQuery();
            if (Params.Count > 0)
                Params.Clear();

            return ret;
        }
        public object RunSproc(string procname)
        {
            SqlCommand cmd = new SqlCommand(procname, _conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            if (_tran != null)
                cmd.Transaction = _tran;

            if (Params.Count > 0)
                cmd.Parameters.AddRange(Params.ToArray());
            var ret = cmd.ExecuteReader();
            if (Params.Count > 0)
                Params.Clear();

            return ret;
        }
        private string BuildOp(string op, string colnm)
        {
            var ret = "";

            switch (op)
            {
                case "eq":
                    ret = colnm + "=@p_" + colnm;
                    break;
                case "eqn":
                    ret = "(" + colnm + " is null or " + colnm + "=@p_" + colnm + ")";
                    break;
                case "ne":
                    ret = colnm + "!=@p_" + colnm;
                    break;
                case "cn":
                    ret = colnm + " like '%@p_" + colnm + "%'";
                    break;
                case "nc":
                    ret = colnm + " not like '%@p_" + colnm + "%'";
                    break;
                case "gt":
                    ret = colnm + " >@p_" + colnm;
                    break;
                case "lt":
                    ret = colnm + " <@p_" + colnm;
                    break;
                case "ge":
                    ret = colnm + " >=@p_" + colnm;
                    break;
                case "le":
                    ret = colnm + " <=@p_" + colnm;
                    break;
                default:
                    break;
            }

            return ret;
        }
        private string BuildOp(string op, string colnm, int idx)
        {
            var ret = "";

            switch (op)
            {
                case "eq":
                    ret = colnm + "=@p_" + idx;
                    break;
                case "eqn":
                    ret = "(" + colnm + " is null or " + colnm + "=@p_" + idx + ")";
                    break;
                case "nen":
                    ret = "(" + colnm + " is null or " + colnm + "!=@p_" + idx + ")";
                    break;
                case "ne":
                    ret = colnm + "!=@p_" + idx;
                    break;
                case "cn":
                    ret = colnm + " like '%@p_" + idx + "%'";
                    break;
                case "nc":
                    ret = colnm + " not like '%@p_" + idx + "%'";
                    break;
                case "gt":
                    ret = colnm + " >@p_" + idx;
                    break;
                case "lt":
                    ret = colnm + " <@p_" + idx;
                    break;
                case "ge":
                    ret = colnm + " >=@p_" + idx;
                    break;
                case "le":
                    ret = colnm + " <=@p_" + idx;
                    break;
                default:
                    break;
            }

            return ret;
        }
     
        public ClientTable GetClientTable(string tname)
        {
            var tbls = GetAllTableWithCols();
            return tbls.Where(x => x.Name.ToUpper() == tname.ToUpper()).Select(x => x).Single();
        }
        
        public List<ClientTable> GetAllTableWithCols()
        {
            Params.Clear();

            var ret = new List<ClientTable>();

            var sql = "select c.name + '.' + a.name tblnm, ltrim(a.type) ttype, b.column_id, b.name colnm,"
                    + " b.max_length, d.name datatype, b.is_nullable, isnull(e.column_id, 0) pk, isnull(f.COLUMN_DEFAULT, '') defval,"
                    + " isnull(g.fkcol, '') fkcol, b.is_identity iden, a.object_id "
                    + " from sys.objects a join sys.columns b on a.object_id = b.object_id"
                    + "                  join sys.schemas c on a.schema_id = c.schema_id"
                    + "                    join sys.types d on b.system_type_id = d.system_type_id and d.is_user_defined = 0"
                    + "                                   and d.user_type_id = (select min(user_type_id) from sys.types where system_type_id = b.system_type_id)"
                    + "               left join(select ib.object_id, ia.column_id"
                    + "                            from sys.index_columns ia join sys.indexes ib on ia.object_id = ib.object_id and ia.index_id = ib.index_id"
                    + "                           where ib.is_primary_key = 1) e on b.object_id = e.object_id and b.column_id = e.column_id"
                    + "                left join INFORMATION_SCHEMA.COLUMNS f on c.name = f.TABLE_SCHEMA and a.name = f.TABLE_NAME and b.name = f.COLUMN_NAME"
                    + "                left join(select i1c.object_id tblid, i1d.column_id, i1g.name +'.' + i1e.name + '.' + i1f.name fkcol"
                    + "                            from sys.foreign_keys i1a join sys.foreign_key_columns i1b on i1a.object_id = i1b.constraint_object_id"
                    + "                                                       join sys.tables i1c on i1b.parent_object_id = i1c.object_id"
                    + "                                                       join sys.columns i1d on i1b.parent_object_id = i1d.object_id"
                    + "                                                                            and i1b.parent_column_id = i1d.column_id"
                    + "                                                       join sys.tables i1e on i1b.referenced_object_id = i1e.object_id"
                    + "                                                       join sys.columns i1f on i1b.referenced_object_id = i1f.object_id"
                    + "                                                                           and i1b.referenced_column_id = i1f.column_id"
                    + "                                                       join sys.schemas i1g on i1e.schema_id = i1g.schema_id) g"
                    + "                          on b.object_id = g.tblid and b.column_id = g.column_id"
                    + " where a.type in ('U', 'V', 'SN', 'IF', 'TF')"
                    + " order by 1, 8, 3; ";

            var rd = GetReader(sql);
            while (rd.Read())
            {
                if (!ret.Any(x => x.Name == rd.GetString(0)))
                {
                    ret.Add(new ClientTable
                    {
                        Name = rd.GetString(0),
                        TType = rd.GetString(1),
                        ObjId = rd.GetInt32(11)
                    });
                }
                var cols = ret.Where(x => x.Name == rd.GetString(0)).Select(x => x.Cols).Single();
                var temp = new Models.ClientTableColumn();
                temp.ColId = rd.GetInt32(2);
                temp.Name = rd.GetString(3);
                temp.MaxLength = rd.GetInt16(4);
                temp.DataType = MSSqlTypeMap[rd.GetString(5)];
                temp.IsNullable = rd.GetBoolean(6);
                temp.IsKey = Convert.ToInt32(rd[7]) == 1;
                temp.DefaultValue = rd.GetString(8);
                temp.FK = rd.GetString(9);
                temp.IsIdentity = rd.GetBoolean(10);
                cols.Add(temp);
            }
            rd.Close();

            return ret;
        }
    }
}
