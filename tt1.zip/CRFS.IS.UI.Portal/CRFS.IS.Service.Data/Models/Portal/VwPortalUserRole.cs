﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwPortalUserRole
    {
        public int Id { get; set; }
        public int Uid { get; set; }
        public int Rid { get; set; }
        public string UserName { get; set; }
        public string RoleName { get; set; }
    }
}
