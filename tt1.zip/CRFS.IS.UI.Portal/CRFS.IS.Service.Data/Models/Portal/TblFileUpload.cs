﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblFileUpload
    {
        public TblFileUpload()
        {
            TblDataLoad = new HashSet<TblDataLoad>();
            TblWorkItemAttachment = new HashSet<TblWorkItemAttachment>();
        }

        public int Id { get; set; }
        public string FileName { get; set; }
        public string ServerPath { get; set; }
        public long? Size { get; set; }
        public string AppName { get; set; }
        public string UploadedBy { get; set; }
        public DateTime UploadDate { get; set; }

        public virtual ICollection<TblDataLoad> TblDataLoad { get; set; }
        public virtual ICollection<TblWorkItemAttachment> TblWorkItemAttachment { get; set; }
    }
}
