﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblWorkItemAttachment
    {
        public int Id { get; set; }
        public int ItemGroupId { get; set; }
        public int ItemId { get; set; }
        public string AttachmentType { get; set; }
        public string Name { get; set; }
        public int FileUploadId { get; set; }
        public bool MarkedForDelete { get; set; }

        public virtual TblFileUpload FileUpload { get; set; }
        public virtual LkpWorkItemGroup ItemGroup { get; set; }
    }
}
