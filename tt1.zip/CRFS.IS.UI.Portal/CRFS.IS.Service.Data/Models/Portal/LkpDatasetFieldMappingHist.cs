﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpDatasetFieldMappingHist
    {
        public int Id { get; set; }
        public string Act { get; set; }
        public DateTime DateAdded { get; set; }
        public int OrgId { get; set; }
        public int Dsid { get; set; }
        public string FieldName { get; set; }
        public string AttributeName { get; set; }
        public bool? AutoFill { get; set; }
        public string FillType { get; set; }
    }
}
