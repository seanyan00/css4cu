﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpWorkItemStatus
    {
        public int Id { get; set; }
        public int ItemGroupId { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public int StatusOrder { get; set; }

        public virtual LkpWorkItemGroup ItemGroup { get; set; }
    }
}
