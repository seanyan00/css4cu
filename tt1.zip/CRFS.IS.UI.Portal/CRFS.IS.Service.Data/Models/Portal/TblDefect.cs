﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblDefect
    {
        public int Id { get; set; }
        public int TypeId { get; set; }
        public string Name { get; set; }
        public int AppId { get; set; }
        public int? SubAppId { get; set; }
        public int ObservePersonId { get; set; }
        public DateTime ObserveTime { get; set; }
        public int? ReferenceId { get; set; }
        public int? ReferenceTypeId { get; set; }
        public string Environment { get; set; }
        public int? TestStepNum { get; set; }
        public string Description { get; set; }
        public bool? IsReplicable { get; set; }
        public bool? IsSystemwide { get; set; }
        public string TechResolution { get; set; }
        public DateTime DateEntered { get; set; }
        public int EnteredBy { get; set; }
        public DateTime? DateUpdated { get; set; }
        public int? UpdatedBy { get; set; }

        public virtual LkpWorkItemGroup ReferenceType { get; set; }
    }
}
