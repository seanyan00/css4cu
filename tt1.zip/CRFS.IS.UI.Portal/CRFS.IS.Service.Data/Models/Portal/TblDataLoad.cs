﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblDataLoad
    {
        public TblDataLoad()
        {
            TblDataLoadDetail = new HashSet<TblDataLoadDetail>();
        }

        public int Id { get; set; }
        public int UploadId { get; set; }
        public int Dsid { get; set; }
        public string Status { get; set; }
        public int? TotalRows { get; set; }

        public virtual LkpDataset Ds { get; set; }
        public virtual TblFileUpload Upload { get; set; }
        public virtual ICollection<TblDataLoadDetail> TblDataLoadDetail { get; set; }
    }
}
