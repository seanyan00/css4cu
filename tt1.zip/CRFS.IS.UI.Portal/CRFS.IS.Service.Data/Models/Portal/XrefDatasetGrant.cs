﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefDatasetGrant
    {
        public int Id { get; set; }
        public int Dsid { get; set; }
        public int Gid { get; set; }
        public int Permit { get; set; }

        public virtual LkpDataset Ds { get; set; }
    }
}
