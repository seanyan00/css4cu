﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwClientPdfcompressionSummary
    {
        public int BatchId { get; set; }
        public string ClientDisplayName { get; set; }
        public DateTime RunDate { get; set; }
        public string RunBy { get; set; }
        public int? TtlFile { get; set; }
        public int? TtlComp { get; set; }
        public int? TtlErr { get; set; }
        public int? TtlTime { get; set; }
    }
}
