﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpWorkItemGroup
    {
        public LkpWorkItemGroup()
        {
            LkpWorkItemStatus = new HashSet<LkpWorkItemStatus>();
            TblDefect = new HashSet<TblDefect>();
            TblWorkItemAttachment = new HashSet<TblWorkItemAttachment>();
            TblWorkItemNotes = new HashSet<TblWorkItemNotes>();
            TblWorkItemStatusLog = new HashSet<TblWorkItemStatusLog>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public virtual ICollection<LkpWorkItemStatus> LkpWorkItemStatus { get; set; }
        public virtual ICollection<TblDefect> TblDefect { get; set; }
        public virtual ICollection<TblWorkItemAttachment> TblWorkItemAttachment { get; set; }
        public virtual ICollection<TblWorkItemNotes> TblWorkItemNotes { get; set; }
        public virtual ICollection<TblWorkItemStatusLog> TblWorkItemStatusLog { get; set; }
    }
}
