﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblScheduledJobStatus
    {
        public int Id { get; set; }
        public int JobId { get; set; }
        public string Status { get; set; }
        public string Message { get; set; }
        public DateTime TimeStart { get; set; }
        public DateTime? TimeEnd { get; set; }
        public bool? Emailed { get; set; }
        public string RunBy { get; set; }
        public string FileFullPath { get; set; }
        public string JobParameters { get; set; }

        public virtual TblScheduledJob Job { get; set; }
    }
}
