﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblWorkItemStatusLog
    {
        public int Id { get; set; }
        public int ItemGroupId { get; set; }
        public int ItemId { get; set; }
        public int StatusId { get; set; }
        public int StatusPersonId { get; set; }
        public DateTime StatusDate { get; set; }
        public string Notes { get; set; }
        public DateTime DateCreated { get; set; }
        public int CreatedBy { get; set; }

        public virtual LkpWorkItemGroup ItemGroup { get; set; }
    }
}
