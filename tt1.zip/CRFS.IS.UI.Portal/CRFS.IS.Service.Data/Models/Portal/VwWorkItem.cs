﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwWorkItem
    {
        public int Id { get; set; }
        public int ItemGroupId { get; set; }
        public string ItemGroupName { get; set; }
        public string Name { get; set; }
        public int AppId { get; set; }
        public string AppName { get; set; }
        public int? SubAppId { get; set; }
        public string SubAppName { get; set; }
        public string Environment { get; set; }
        public int StatusId { get; set; }
        public string StatusName { get; set; }
        public DateTime StatusDate { get; set; }
        public int StatusPersonId { get; set; }
        public string StatusPersonName { get; set; }
        public string Description { get; set; }
        public DateTime DateEntered { get; set; }
    }
}
