﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblDocuwareClientCabinetClientName
    {
        public long DocuwareClientCabinetClientName { get; set; }
        public long FhaclientId { get; set; }
        public string Cabinet { get; set; }
        public string ClientName { get; set; }
    }
}
