﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblAopAdjustmentMessages
    {
        public long AopAdjustmentMessageId { get; set; }
        public long PaymentAdviceId { get; set; }
        public long AdjustmentCodeId { get; set; }
        public DateTime EnteredDate { get; set; }
        public DateTime LastUpdateDate { get; set; }

        public virtual TblFhapaymentAdvices PaymentAdvice { get; set; }
    }
}
