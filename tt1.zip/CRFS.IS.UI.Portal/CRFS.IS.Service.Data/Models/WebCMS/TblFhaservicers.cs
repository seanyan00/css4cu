﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblFhaservicers
    {
        public TblFhaservicers()
        {
            TblFhaediTransmitAck = new HashSet<TblFhaediTransmitAck>();
            TblFhaloans = new HashSet<TblFhaloans>();
            XrefServicerHolder = new HashSet<XrefServicerHolder>();
        }

        public long ServicerId { get; set; }
        public string ServicerName { get; set; }
        public string ServicingMortageeNumber { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string StateCode { get; set; }
        public string ZipCode { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUser { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUser { get; set; }

        public virtual ICollection<TblFhaediTransmitAck> TblFhaediTransmitAck { get; set; }
        public virtual ICollection<TblFhaloans> TblFhaloans { get; set; }
        public virtual ICollection<XrefServicerHolder> XrefServicerHolder { get; set; }
    }
}
