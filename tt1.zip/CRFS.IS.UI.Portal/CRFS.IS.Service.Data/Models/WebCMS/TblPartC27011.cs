﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblPartC27011
    {
        public TblPartC27011()
        {
            TblProtectionPreservationDisbursements = new HashSet<TblProtectionPreservationDisbursements>();
        }

        public long PartC27011id { get; set; }
        public long FhaclaimId { get; set; }
        public DateTime? DateFormPrepared { get; set; }
        public string MortgageeComments { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUser { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUser { get; set; }

        public virtual TblFhaclaims Fhaclaim { get; set; }
        public virtual ICollection<TblProtectionPreservationDisbursements> TblProtectionPreservationDisbursements { get; set; }
    }
}
