﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblFhaedicontrol
    {
        public long EdicontrolId { get; set; }
        public long ClaimTypeId { get; set; }
        public string Block1 { get; set; }
        public string Block2 { get; set; }
        public string Block3 { get; set; }
        public string Block4 { get; set; }
        public string Block5 { get; set; }
        public string Block6 { get; set; }
        public string Block7 { get; set; }
        public string Block8 { get; set; }
        public string Block9 { get; set; }
        public string Block10 { get; set; }
        public string Block11 { get; set; }
        public string Block12 { get; set; }
        public string Block13 { get; set; }
        public string Block14 { get; set; }
        public string Block15 { get; set; }
        public string Block16 { get; set; }
        public string Block17 { get; set; }
        public string Block18 { get; set; }
        public string Block19 { get; set; }
        public string Block20 { get; set; }
        public string Block21 { get; set; }
        public string Block22 { get; set; }
        public string Block23 { get; set; }
        public string Block24 { get; set; }
        public string Block25 { get; set; }
        public string Block26 { get; set; }
        public string Block27 { get; set; }
        public string Block28 { get; set; }
        public string Block29 { get; set; }
        public string Block30 { get; set; }
        public string Block31 { get; set; }
        public string Block32 { get; set; }
        public string Block33 { get; set; }
        public string Block34 { get; set; }
        public string Block35 { get; set; }
        public string Block36 { get; set; }
        public string Block37 { get; set; }
        public string Block38 { get; set; }
        public string Block39 { get; set; }
        public string Block40 { get; set; }
        public string Block41 { get; set; }
        public string Block42 { get; set; }
        public string Block43 { get; set; }
        public string Block44 { get; set; }
        public string Block45 { get; set; }
        public string Block100 { get; set; }
        public string Block101 { get; set; }
        public string Block102 { get; set; }
        public string Block103 { get; set; }
        public string Block104 { get; set; }
        public string Block105 { get; set; }
        public string Block106 { get; set; }
        public string Block107 { get; set; }
        public string Block108 { get; set; }
        public string Block109 { get; set; }
        public string Block110 { get; set; }
        public string Block111 { get; set; }
        public string Block112 { get; set; }
        public string Block113 { get; set; }
        public string Block114 { get; set; }
        public string Block115 { get; set; }
        public string Block116 { get; set; }
        public string Block117 { get; set; }
        public string Block118 { get; set; }
        public string Block119 { get; set; }
        public string Block120 { get; set; }
        public string Block121 { get; set; }
        public string Block122 { get; set; }
        public string Block123 { get; set; }
        public string Block124 { get; set; }
        public string Block125 { get; set; }
        public string Block126 { get; set; }
        public string Block127 { get; set; }
        public string Block128 { get; set; }
        public string Block129 { get; set; }
        public string Block130 { get; set; }
        public string Block131 { get; set; }
        public string Block132 { get; set; }
        public string Block133 { get; set; }
        public string Block134 { get; set; }
        public string Block135 { get; set; }
        public string Block136 { get; set; }
        public string Block137 { get; set; }
    }
}
