﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpFhalookups
    {
        public LkpFhalookups()
        {
            LkpAlternateAopmesssages = new HashSet<LkpAlternateAopmesssages>();
            XrefClaimDocuments = new HashSet<XrefClaimDocuments>();
        }

        public long FhalookupId { get; set; }
        public string Lucategory { get; set; }
        public string DisplayCode1 { get; set; }
        public string DisplayCode2 { get; set; }
        public string Lutext { get; set; }
        public DateTime EffectiveFromDate { get; set; }
        public DateTime EffectiveToDate { get; set; }
        public bool? Active { get; set; }

        public virtual XrefEnvironmentClientCabinet XrefEnvironmentClientCabinet { get; set; }
        public virtual ICollection<LkpAlternateAopmesssages> LkpAlternateAopmesssages { get; set; }
        public virtual ICollection<XrefClaimDocuments> XrefClaimDocuments { get; set; }
    }
}
