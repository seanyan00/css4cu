﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblFhaclaimSubmitLog
    {
        public long FhaclaimSubmitLogId { get; set; }
        public long FhaclaimId { get; set; }
        public long ClaimEdilogId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUser { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUser { get; set; }
        public long? SubmitTypeId { get; set; }
        public bool MarkedForDelete { get; set; }
        public string TrackingNumber { get; set; }
        public long? ShippingVendorId { get; set; }
        public string Comment1 { get; set; }
        public string Comment2 { get; set; }
        public string AssembledCommentText { get; set; }

        public virtual TblFhaclaimEdilog ClaimEdilog { get; set; }
        public virtual TblFhaclaims Fhaclaim { get; set; }
    }
}
