﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpAlternateAopmesssages
    {
        public long AlternateMessageId { get; set; }
        public long FhalookupId { get; set; }
        public string AlternateMesssage { get; set; }
        public DateTime EffectiveFromDate { get; set; }
        public DateTime EffectiveToDate { get; set; }
        public bool Active { get; set; }

        public virtual LkpFhalookups Fhalookup { get; set; }
    }
}
