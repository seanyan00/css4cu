﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpForm27011Blocks
    {
        public LkpForm27011Blocks()
        {
            TblPartD27011MultiBlock = new HashSet<TblPartD27011MultiBlock>();
            TblPartE27011MultiBlock = new HashSet<TblPartE27011MultiBlock>();
        }

        public int Form27011BlockId { get; set; }
        public string BlockCode { get; set; }
        public string BlockName { get; set; }

        public virtual ICollection<TblPartD27011MultiBlock> TblPartD27011MultiBlock { get; set; }
        public virtual ICollection<TblPartE27011MultiBlock> TblPartE27011MultiBlock { get; set; }
    }
}
