﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblFhaediTransmitAck
    {
        public long TransmitAckId { get; set; }
        public long FhaclaimId { get; set; }
        public long ServicerId { get; set; }
        public string ControlNumber { get; set; }
        public DateTime TransmitDate { get; set; }
        public DateTime? AckDate { get; set; }
        public long? XactSetAckCodeId { get; set; }
        public long? XactSetAckSyntaxErrorCodeId { get; set; }

        public virtual TblFhaclaims Fhaclaim { get; set; }
        public virtual TblFhaservicers Servicer { get; set; }
    }
}
