﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class EdiextractLoggingRecords
    {
        public long EdiextractLoggingRecordId { get; set; }
        public DateTime LogDate { get; set; }
        public long ClientServicerSortrow { get; set; }
        public long FhaclaimId { get; set; }
        public int HeaderDetailSort { get; set; }
        public string Data { get; set; }
    }
}
