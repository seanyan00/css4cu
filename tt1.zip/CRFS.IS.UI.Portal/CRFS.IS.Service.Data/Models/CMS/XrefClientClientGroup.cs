﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefClientClientGroup
    {
        public int ClientClientGroupId { get; set; }
        public int ClientId { get; set; }
        public int ClientGroupId { get; set; }

        public virtual LkpClientGroup ClientGroup { get; set; }
    }
}
