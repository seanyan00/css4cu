﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblInvestorTrackingClaims
    {
        public TblInvestorTrackingClaims()
        {
            TblInvestorTrackingClaimsFhaclaim = new HashSet<TblInvestorTrackingClaimsFhaclaim>();
        }

        public int Id { get; set; }
        public int LoanId { get; set; }
        public int ClaimType { get; set; }
        public DateTime? ClaimDueDate { get; set; }
        public decimal? ClaimAmount { get; set; }
        public bool? NoBill { get; set; }
        public bool? NoClaimSubmitted { get; set; }
        public DateTime? ClaimPerfectionDate { get; set; }
        public DateTime? ClaimPaidDate { get; set; }
        public decimal? ClaimPaidAmount { get; set; }
        public bool ClaimClosed { get; set; }
        public DateTime? ClaimClosedDate { get; set; }
        public int? ClaimClosedUser { get; set; }
        public DateTime DateEntered { get; set; }
        public int? EnteredByUser { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int? LastUpdateUser { get; set; }
        public DateTime? ReferralDate { get; set; }
        public DateTime? RejectedDate { get; set; }
        public int? ClosingReason { get; set; }
        public bool? PfuEobreviewOnly { get; set; }
        public decimal? PreSaleSettlementProceedsAmount { get; set; }
        public decimal? OptionSettlementCoveragePct { get; set; }
        public DateTime? RecissionDate { get; set; }
        public DateTime? CancellationDate { get; set; }
        public DateTime? ClosedWithoutPaymentDate { get; set; }
        public string SingleUseImportGuid { get; set; }
        public int? CarrierSettlementType { get; set; }
        public decimal? RevisedClaimAmt { get; set; }
        public decimal? RevisedProceedsAmt { get; set; }
        public decimal? RevisedEstSettlementAmt { get; set; }
        public DateTime? SecondaryClaimDueDate { get; set; }
        public bool IsClaimCancelled { get; set; }
        public DateTime? ClaimCancelledDate { get; set; }
        public int? ClaimCancelledUserId { get; set; }
        public bool IsZeroNeg { get; set; }
        public DateTime? ZeroNegDate { get; set; }
        public int? ZeroNegUserId { get; set; }
        public DateTime? IndustryClaimDueDate { get; set; }
        public bool? ConventionalUsdasupplemental { get; set; }
        public bool? ConventionalTaxSupplemental { get; set; }
        public int? SuppParentClaimId { get; set; }
        public DateTime? OpsModifiableIndustryDueDate { get; set; }
        public DateTime? OpsModifiableSladueDate { get; set; }
        public bool? OpsModifiableNotWorkable { get; set; }
        public string ClientUniqueId { get; set; }

        public virtual TblInvestorTrackingLoans Loan { get; set; }
        public virtual ICollection<TblInvestorTrackingClaimsFhaclaim> TblInvestorTrackingClaimsFhaclaim { get; set; }
    }
}
