﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpClientGroup
    {
        public LkpClientGroup()
        {
            XrefClientClientGroup = new HashSet<XrefClientClientGroup>();
        }

        public int ClientGroupId { get; set; }
        public string ClientGroupName { get; set; }

        public virtual ICollection<XrefClientClientGroup> XrefClientClientGroup { get; set; }
    }
}
