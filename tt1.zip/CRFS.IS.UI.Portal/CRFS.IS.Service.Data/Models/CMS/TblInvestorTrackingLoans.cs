﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblInvestorTrackingLoans
    {
        public TblInvestorTrackingLoans()
        {
            TblInvestorTrackingClaims = new HashSet<TblInvestorTrackingClaims>();
        }

        public int Id { get; set; }
        public string LoanNumber { get; set; }
        public int ClientId { get; set; }
        public string PropertyAddress { get; set; }
        public string PropertyCity { get; set; }
        public string PropertyState { get; set; }
        public string PropertyZip { get; set; }
        public string ServicerNumber { get; set; }
        public string ServicerName { get; set; }
        public string ServicerAddress { get; set; }
        public string ServicerCity { get; set; }
        public string ServicerState { get; set; }
        public string ServicerZip { get; set; }
        public int InternalFormId { get; set; }
        public string InvestorId { get; set; }
        public string InvestorName { get; set; }
        public int? MicompanyId { get; set; }
        public string MiguarantyNumber { get; set; }
        public string BorrowerFirstName { get; set; }
        public string BorrowerLastName { get; set; }
        public string InvestorLoanNumber { get; set; }
        public DateTime? ReferDateToMi { get; set; }
        public DateTime? PreForeclosureSettlementDate { get; set; }
        public DateTime? DeedInLeuRecordDate { get; set; }
        public DateTime? ForeClosureDate { get; set; }
        public DateTime? ForeclosureSaleDate { get; set; }
        public DateTime? ReosaleDate { get; set; }
        public DateTime? Rrcdate { get; set; }
        public string FhacaseNumber { get; set; }
        public string MicertNumber { get; set; }
        public DateTime? MifiledDate { get; set; }
        public string PoolCompany { get; set; }
        public string PoolCertNumber { get; set; }
        public DateTime? PoolFiledDate { get; set; }
        public DateTime? ThirdPartySaleDate { get; set; }
        public string AttorneyName { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public DateTime DateEntered { get; set; }
        public int? EnteredByUser { get; set; }
        public int? LastUpdateUser { get; set; }
        public DateTime? Pccdate { get; set; }
        public DateTime? Gadate { get; set; }
        public string CmaxClientId { get; set; }
        public string OldLoanNumber { get; set; }
        public int? ClaimGroupId { get; set; }
        public string SellerServicerNumber { get; set; }
        public string VacaseNumber { get; set; }
        public DateTime? MarketingExpirationDate { get; set; }
        public DateTime? LiquidationDate { get; set; }
        public DateTime? RefundingDate { get; set; }
        public string EvictionAttorney { get; set; }
        public string TitleCompany { get; set; }
        public string PandPcompany { get; set; }
        public bool? IsAcquisitionLoan { get; set; }
        public int? AcquisitionLoanSetByUserId { get; set; }
        public DateTime? AquisitionLoanSetDate { get; set; }
        public int? AquisitionLoanSetOnClaimId { get; set; }
        public int? ForeclosureTypeId { get; set; }
        public DateTime? PropertyAcquisitionDate { get; set; }
        public DateTime? NplsaleDate { get; set; }
        public DateTime? NonLiquidationDate { get; set; }
        public string ClientUniqueId { get; set; }

        public virtual ICollection<TblInvestorTrackingClaims> TblInvestorTrackingClaims { get; set; }
    }
}
