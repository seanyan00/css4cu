﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TbllkpClaimTypesByForm
    {
        public int Id { get; set; }
        public int FormId { get; set; }
        public string ClaimType { get; set; }
        public DateTime DateEntered { get; set; }
        public bool? Active { get; set; }
    }
}
