﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwDw4ClientsDrop08012021Lr
    {
        public int ApplicationClientId { get; set; }
        public int ApplicationId { get; set; }
        public int ClientId { get; set; }
        public string ApplicationName { get; set; }
        public string ClientDisplayName { get; set; }
    }
}
