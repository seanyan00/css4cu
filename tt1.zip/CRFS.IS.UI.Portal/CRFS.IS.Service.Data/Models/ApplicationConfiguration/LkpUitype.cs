﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpUitype
    {
        public string Code { get; set; }
        public string Description { get; set; }
    }
}
