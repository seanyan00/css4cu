﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpFtmstasks
    {
        public LkpFtmstasks()
        {
            LkpFtmstaskDestinations = new HashSet<LkpFtmstaskDestinations>();
        }

        public int TaskId { get; set; }
        public int ClientId { get; set; }
        public string TaskName { get; set; }
        public string TaskType { get; set; }
        public bool TaskEnabled { get; set; }
        public int PriorityWithinClientTasks { get; set; }
        public string SourceFolder { get; set; }
        public string SourceMask { get; set; }
        public bool SendEmail { get; set; }
        public string EmailText { get; set; }
        public string EmailSubject { get; set; }
        public bool EmailFilesAsAttachments { get; set; }
        public bool SendEachMatchingFileAsSeparateEmail { get; set; }
        public bool IncludeFileDetailsInEmailBody { get; set; }
        public bool LogFileMove { get; set; }

        public virtual LkpClients Client { get; set; }
        public virtual LkpFtmsFtpjobParameters LkpFtmsFtpjobParameters { get; set; }
        public virtual ICollection<LkpFtmstaskDestinations> LkpFtmstaskDestinations { get; set; }
    }
}
