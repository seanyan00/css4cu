﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpFtmsDeleteFolderTasks
    {
        public int TaskId { get; set; }
        public string SourceFolder { get; set; }

        public virtual LkpFtmsJobTasks Task { get; set; }
    }
}
