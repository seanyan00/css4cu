﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpFtmsCreateFolderTasks
    {
        public int TaskId { get; set; }
        public string SourceFolder { get; set; }
        public string FolderBaseName { get; set; }
        public string FolderNameMask { get; set; }

        public virtual LkpFtmsJobTasks Task { get; set; }
    }
}
