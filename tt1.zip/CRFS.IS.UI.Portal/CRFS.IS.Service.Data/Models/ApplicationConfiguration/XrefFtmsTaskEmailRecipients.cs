﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefFtmsTaskEmailRecipients
    {
        public int TaskRecipientId { get; set; }
        public int FtmsjobId { get; set; }
        public int FtmsrecipientId { get; set; }
        public string RecipientType { get; set; }
        public string MessageType { get; set; }

        public virtual LkpFtmsEmailRecipients TaskRecipient { get; set; }
    }
}
