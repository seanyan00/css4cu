﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefFtmsTaskEmailRecipients
    {
        public int TaskRecipientId { get; set; }
        public int JobId { get; set; }
        public int? TaskId { get; set; }
        public int RecipientId { get; set; }
        public string RecipientType { get; set; }
        public string MessageType { get; set; }

        public virtual LkpFtmsEmailRecipients TaskRecipient { get; set; }
    }
}
