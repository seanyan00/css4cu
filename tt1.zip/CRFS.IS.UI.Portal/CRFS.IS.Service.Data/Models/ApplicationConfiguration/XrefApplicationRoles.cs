﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefApplicationRoles
    {
        public XrefApplicationRoles()
        {
            XrefAppplicationUserApplicationRole = new HashSet<XrefAppplicationUserApplicationRole>();
        }

        public int ApplicationRoleId { get; set; }
        public int ApplicationId { get; set; }
        public int RoleId { get; set; }
        public bool MarkedForDelete { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual LkpApplications Application { get; set; }
        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual LkpRoles Role { get; set; }
        public virtual ICollection<XrefAppplicationUserApplicationRole> XrefAppplicationUserApplicationRole { get; set; }
    }
}
