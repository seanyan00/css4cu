﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwGenerateRunSessionValues
    {
        public int? Number { get; set; }
        public string RunSession { get; set; }
    }
}
