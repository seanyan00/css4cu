﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblEntityGroupContacts
    {
        public long EntityGroupContactId { get; set; }
        public int ApplicationId { get; set; }
        public int GroupId { get; set; }
        public string ContactName { get; set; }
        public string EmailAddress { get; set; }
        public bool Active { get; set; }
        public DateTime? EnteredDate { get; set; }
        public int? EnteredByUser { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUser { get; set; }

        public virtual LkpApplications Application { get; set; }
        public virtual LkpEntityGroups Group { get; set; }
    }
}
