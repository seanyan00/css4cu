﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class DocuwareCabinets
    {
        public DocuwareCabinets()
        {
            DocuwareCabinetApplicationClients = new HashSet<DocuwareCabinetApplicationClients>();
            DocuwareCabinetDocumentTypes = new HashSet<DocuwareCabinetDocumentTypes>();
            DocuwareInstanceDocuwareCabinets = new HashSet<DocuwareInstanceDocuwareCabinets>();
        }

        public int DocuwareCabinetId { get; set; }
        public string DocuwareCabinetName { get; set; }
        public bool MarkedForDelete { get; set; }
        public bool? Active { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }

        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual ICollection<DocuwareCabinetApplicationClients> DocuwareCabinetApplicationClients { get; set; }
        public virtual ICollection<DocuwareCabinetDocumentTypes> DocuwareCabinetDocumentTypes { get; set; }
        public virtual ICollection<DocuwareInstanceDocuwareCabinets> DocuwareInstanceDocuwareCabinets { get; set; }
    }
}
