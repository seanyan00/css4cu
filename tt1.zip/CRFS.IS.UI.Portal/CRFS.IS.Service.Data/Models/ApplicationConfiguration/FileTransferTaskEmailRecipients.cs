﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class FileTransferTaskEmailRecipients
    {
        public int TaskRecipientId { get; set; }
        public long FtmstaskId { get; set; }
        public int FtmsrecipientId { get; set; }
        public string RecipientType { get; set; }

        public virtual FileTransferManagementTasks Ftmstask { get; set; }
        public virtual FileTransferManagementEmailRecipients TaskRecipient { get; set; }
    }
}
