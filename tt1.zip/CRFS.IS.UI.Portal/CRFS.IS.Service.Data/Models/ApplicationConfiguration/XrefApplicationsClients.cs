﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefApplicationsClients
    {
        public XrefApplicationsClients()
        {
            DocuwareCabinetApplicationClients = new HashSet<DocuwareCabinetApplicationClients>();
            XrefApplicationClientReports = new HashSet<XrefApplicationClientReports>();
        }

        public int ApplicationClientId { get; set; }
        public int ApplicationId { get; set; }
        public int ClientId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public bool? Active { get; set; }
        public DateTime ActiveFromDate { get; set; }
        public DateTime ActiveToDate { get; set; }

        public virtual LkpApplications Application { get; set; }
        public virtual LkpClients Client { get; set; }
        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual ICollection<DocuwareCabinetApplicationClients> DocuwareCabinetApplicationClients { get; set; }
        public virtual ICollection<XrefApplicationClientReports> XrefApplicationClientReports { get; set; }
    }
}
