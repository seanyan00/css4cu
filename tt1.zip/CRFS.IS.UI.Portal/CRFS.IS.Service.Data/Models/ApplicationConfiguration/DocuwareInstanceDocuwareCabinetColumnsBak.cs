﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class DocuwareInstanceDocuwareCabinetColumnsBak
    {
        public int DocuwareInstanceDocuwareCabinetColumnId { get; set; }
        public int DocuwareInstanceDocuwareCabinetId { get; set; }
        public int DocuwareColumnId { get; set; }
        public bool MarkedForDelete { get; set; }
        public bool Active { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
    }
}
