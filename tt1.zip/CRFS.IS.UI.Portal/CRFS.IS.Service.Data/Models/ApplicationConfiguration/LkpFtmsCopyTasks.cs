﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpFtmsCopyTasks
    {
        public int TaskId { get; set; }
        public string SourceFolder { get; set; }
        public string SourceMask { get; set; }
        public string DestinationFolder { get; set; }

        public virtual LkpFtmsJobTasks Task { get; set; }
    }
}
