﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpFtmsJobTasks
    {
        public int TaskId { get; set; }
        public int JobId { get; set; }
        public string TaskName { get; set; }
        public int TaskTypeId { get; set; }
        public bool TaskEnabled { get; set; }
        public int JobTaskPriority { get; set; }

        public virtual LkpFtmstaskTypes TaskType { get; set; }
        public virtual LkpFtmsCopyTasks LkpFtmsCopyTasks { get; set; }
        public virtual LkpFtmsCreateFolderTasks LkpFtmsCreateFolderTasks { get; set; }
        public virtual LkpFtmsDeleteFolderTasks LkpFtmsDeleteFolderTasks { get; set; }
        public virtual LkpFtmsEmailTasks LkpFtmsEmailTasks { get; set; }
        public virtual LkpFtmsFtptasks LkpFtmsFtptasks { get; set; }
        public virtual LkpFtmsRenameTasks LkpFtmsRenameTasks { get; set; }
        public virtual LkpFtmsZipTasks LkpFtmsZipTasks { get; set; }
        public virtual LkpFtmsdeleteTasks LkpFtmsdeleteTasks { get; set; }
    }
}
