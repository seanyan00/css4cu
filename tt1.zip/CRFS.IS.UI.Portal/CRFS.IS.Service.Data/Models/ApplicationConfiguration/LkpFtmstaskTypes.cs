﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpFtmstaskTypes
    {
        public LkpFtmstaskTypes()
        {
            LkpFtmsJobTasks = new HashSet<LkpFtmsJobTasks>();
        }

        public int TaskTypeId { get; set; }
        public string TaskType { get; set; }

        public virtual ICollection<LkpFtmsJobTasks> LkpFtmsJobTasks { get; set; }
    }
}
