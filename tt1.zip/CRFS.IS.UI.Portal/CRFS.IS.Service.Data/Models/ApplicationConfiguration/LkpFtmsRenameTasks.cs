﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpFtmsRenameTasks
    {
        public int TaskId { get; set; }
        public string SourceFolder { get; set; }
        public string SourceMask { get; set; }
        public string Prefix { get; set; }
        public string Suffix { get; set; }
        public string TimeStampFormatString { get; set; }

        public virtual LkpFtmsJobTasks Task { get; set; }
    }
}
