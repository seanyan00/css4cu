﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpPfueobCompleteMatrix
    {
        public int PfueobCompleteMatrixId { get; set; }
        public int Bitvalue { get; set; }
        public bool ClaimPaidAmountSet { get; set; }
        public bool ClaimPaidDateSet { get; set; }
        public bool DeniedDateSet { get; set; }
        public bool RecissionDateSet { get; set; }
        public bool CancellationDateSet { get; set; }
        public bool AllowPfueobComplete { get; set; }
    }
}
