﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwExternalClientReportingConfiguredClients
    {
        public string ClientName { get; set; }
    }
}
