﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpMifollowup
    {
        public int MifollowupId { get; set; }
        public int MicompanyId { get; set; }
        public int ClaimTypeId { get; set; }
        public int FollowupDaysAfterSubmit { get; set; }
        public int SubsequentFollowupDays { get; set; }
    }
}
