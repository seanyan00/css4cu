﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class ConfigurationSettings
    {
        public int SettingId { get; set; }
        public string Application { get; set; }
        public string SettingName { get; set; }
        public string SettingValue { get; set; }
        public string Description { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public int? LastUpdateUserId { get; set; }
    }
}
