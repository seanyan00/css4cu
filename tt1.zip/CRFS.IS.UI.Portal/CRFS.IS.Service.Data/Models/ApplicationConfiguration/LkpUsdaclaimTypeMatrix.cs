﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpUsdaclaimTypeMatrix
    {
        public LkpUsdaclaimTypeMatrix()
        {
            XrefClientUsdaclaimScope = new HashSet<XrefClientUsdaclaimScope>();
        }

        public int UsdaclaimTypeMatrixId { get; set; }
        public bool UsdaMraClaim { get; set; }
        public bool UsdaSafpClaim { get; set; }
        public bool UsdaGeneralClaim { get; set; }
        public int BitValue { get; set; }
        public string Result { get; set; }
        public bool Active { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual ICollection<XrefClientUsdaclaimScope> XrefClientUsdaclaimScope { get; set; }
    }
}
