﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpInvestorFollowup
    {
        public int InvestorFollowupId { get; set; }
        public int InvestorId { get; set; }
        public int ClaimTypeId { get; set; }
        public int FollowupDaysAfterSubmit { get; set; }
        public int SubsequentFollowupDays { get; set; }

        public virtual TblControlInvestorGroup Investor { get; set; }
    }
}
