﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefClientMicompanyServices
    {
        public int ClientMicompanyServicesId { get; set; }
        public int ClientId { get; set; }
        public int MicompanyId { get; set; }
    }
}
