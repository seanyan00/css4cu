﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefEntityGroupUserAssignment
    {
        public long EntityGroupUserAssignmentId { get; set; }
        public int GroupId { get; set; }
        public int UserId { get; set; }

        public virtual LkpEntityGroups Group { get; set; }
    }
}
