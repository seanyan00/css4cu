﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpFtmstaskDestinations
    {
        public int TaskDestinationId { get; set; }
        public int TaskId { get; set; }
        public string CopyMove { get; set; }
        public string Destination { get; set; }

        public virtual LkpFtmstasks Task { get; set; }
    }
}
