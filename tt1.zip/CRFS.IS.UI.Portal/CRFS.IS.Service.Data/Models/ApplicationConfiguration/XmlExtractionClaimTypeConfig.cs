﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XmlExtractionClaimTypeConfig
    {
        public int XmlextractionId { get; set; }
        public long ClaimType { get; set; }
        public long FhalookUpId { get; set; }
        public bool Active { get; set; }
        public DateTime DateAdded { get; set; }
        public int AddedBy { get; set; }
        public DateTime DateUpdated { get; set; }
        public int UpdatedBy { get; set; }
        public int FhaclaimGroup { get; set; }
        public string SubmitPart { get; set; }
    }
}
