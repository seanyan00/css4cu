﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblSubscriptionUser
    {
        public TblSubscriptionUser()
        {
            TblSubscriptionUserParameters = new HashSet<TblSubscriptionUserParameters>();
        }

        public int SubscriptionUserId { get; set; }
        public int? SubscriptionId { get; set; }
        public int? UserId { get; set; }

        public virtual TblSubscriptionsDataDriven Subscription { get; set; }
        public virtual ICollection<TblSubscriptionUserParameters> TblSubscriptionUserParameters { get; set; }
    }
}
