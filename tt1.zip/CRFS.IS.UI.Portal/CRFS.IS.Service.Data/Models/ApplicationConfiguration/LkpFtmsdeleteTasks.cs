﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpFtmsdeleteTasks
    {
        public int TaskId { get; set; }
        public string SourceFolder { get; set; }
        public string SourceMask { get; set; }

        public virtual LkpFtmsJobTasks Task { get; set; }
    }
}
