﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpFtmsZipTasks
    {
        public int TaskId { get; set; }
        public string SourceFolder { get; set; }
        public string SourceMask { get; set; }
        public string DestinationFolder { get; set; }
        public string ZipFileName { get; set; }
        public bool RemoveAfterZip { get; set; }

        public virtual LkpFtmsJobTasks Task { get; set; }
    }
}
