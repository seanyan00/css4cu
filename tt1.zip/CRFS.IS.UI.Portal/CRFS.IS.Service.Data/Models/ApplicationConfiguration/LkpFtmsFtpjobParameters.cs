﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpFtmsFtpjobParameters
    {
        public int FtmsFtpjobId { get; set; }
        public string Sftpsite { get; set; }
        public string UserId { get; set; }
        public string Password { get; set; }
        public string RemoteDestination { get; set; }

        public virtual LkpFtmstasks FtmsFtpjob { get; set; }
    }
}
