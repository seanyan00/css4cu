﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwDw2Clients
    {
        public int ApplicationClientId { get; set; }
        public int ApplicationId { get; set; }
        public int ClientId { get; set; }
        public string ApplicationName { get; set; }
        public string ClientDisplayName { get; set; }
    }
}
