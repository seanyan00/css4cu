﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class DeliveryMethods
    {
        public DeliveryMethods()
        {
            DeliveryEndPoints = new HashSet<DeliveryEndPoints>();
        }

        public int DeliveryMethodId { get; set; }
        public string DeliveryMethodCode { get; set; }
        public string DeliveryMethodDescription { get; set; }
        public bool Active { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }

        public virtual ICollection<DeliveryEndPoints> DeliveryEndPoints { get; set; }
    }
}
