﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblReportGeneration
    {
        public int Id { get; set; }
        public int JobStatusId { get; set; }
        public string DatasetsParameters { get; set; }
    }
}
