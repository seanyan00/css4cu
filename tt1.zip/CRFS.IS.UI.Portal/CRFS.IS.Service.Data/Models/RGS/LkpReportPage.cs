﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpReportPage
    {
        public int Id { get; set; }
        public int ReportId { get; set; }
        public int PageNum { get; set; }
        public string PageName { get; set; }
        public int DatasetId { get; set; }
        public string Template { get; set; }
        public bool IsPivot { get; set; }
        public DateTime DateCreated { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? DateUpdated { get; set; }
        public int? UpdatedBy { get; set; }

        public virtual LkpReportDataset Dataset { get; set; }
        public virtual LkpReport Report { get; set; }
    }
}
