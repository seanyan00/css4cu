﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwReportRunHist
    {
        public int Id { get; set; }
        public int JobId { get; set; }
        public int JobStatusId { get; set; }
        public int? ClientId { get; set; }
        public string AppName { get; set; }
        public string ClientDisplayName { get; set; }
        public int ReportId { get; set; }
        public string ReportName { get; set; }
        public string DatasetsParameters { get; set; }
        public string Status { get; set; }
        public string FileFullPath { get; set; }
        public bool? Emailed { get; set; }
        public string Message { get; set; }
        public DateTime? TimeEnd { get; set; }
        public DateTime TimeStart { get; set; }
        public string RunBy { get; set; }
        public string JobParameters { get; set; }
    }
}
