﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwClientReport
    {
        public int ReportId { get; set; }
        public string ReportName { get; set; }
        public string FileName { get; set; }
        public string ReportTemplate { get; set; }
        public string Destination { get; set; }
        public int PageId { get; set; }
        public string PageName { get; set; }
        public int PageNum { get; set; }
        public string PageTemplate { get; set; }
        public bool IsPivot { get; set; }
        public int DatasetId { get; set; }
        public string Sproc { get; set; }
        public string SqlStr { get; set; }
        public int ParameterId { get; set; }
        public string ParamDbName { get; set; }
        public string ParamReportName { get; set; }
        public string DataType { get; set; }
        public string ParamDirection { get; set; }
        public string ParamPivotDirection { get; set; }
        public string DefaultValue { get; set; }
        public bool Nullable { get; set; }
        public int? ForReportName { get; set; }
        public int? MaxLen { get; set; }
        public int ClientReportId { get; set; }
        public int ClientId { get; set; }
        public string Holiday { get; set; }
        public string Delimiter { get; set; }
        public string ClientDisplayName { get; set; }
        public string Params { get; set; }
    }
}
