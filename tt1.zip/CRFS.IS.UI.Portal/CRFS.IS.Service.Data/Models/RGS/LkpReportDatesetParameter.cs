﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpReportDatesetParameter
    {
        public int Id { get; set; }
        public int DataSetId { get; set; }
        public string Dbname { get; set; }
        public string ReportName { get; set; }
        public string DataType { get; set; }
        public string Direction { get; set; }
        public string PivotDirection { get; set; }
        public string DefaultValue { get; set; }
        public bool Nullable { get; set; }
        public int? ForReportName { get; set; }
        public int? MaxLen { get; set; }
        public DateTime DateCreated { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? DateUpdated { get; set; }
        public int? UpdatedBy { get; set; }

        public virtual LkpReportDataset DataSet { get; set; }
    }
}
