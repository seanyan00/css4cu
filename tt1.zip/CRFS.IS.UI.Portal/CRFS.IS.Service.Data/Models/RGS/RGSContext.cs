﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CRFS.IS.Service.Data
{
    public partial class RGSContext : DbContext
    {
        public RGSContext()
        {
        }

        public RGSContext(DbContextOptions<RGSContext> options)
            : base(options)
        {
        }

        public virtual DbSet<LkpReport> LkpReport { get; set; }
        public virtual DbSet<LkpReportDataset> LkpReportDataset { get; set; }
        public virtual DbSet<LkpReportDatasetParameter> LkpReportDatasetParameter { get; set; }
        public virtual DbSet<LkpReportPage> LkpReportPage { get; set; }
        public virtual DbSet<TblReportGeneration> TblReportGeneration { get; set; }
        public virtual DbSet<VwClientReport> VwClientReport { get; set; }
        public virtual DbSet<VwReportRunHist> VwReportRunHist { get; set; }
        public virtual DbSet<XrefClientReport> XrefClientReport { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=vm-sql1-dev.dev.crfs.crfservices.com\\cms_d;Initial Catalog=RGS;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<LkpReport>(entity =>
            {
                entity.ToTable("lkp_Report");

                entity.Property(e => e.DateCreated).HasColumnType("datetime");

                entity.Property(e => e.DateUpdated).HasColumnType("datetime");

                entity.Property(e => e.Destination)
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.FileName)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.Template)
                    .HasMaxLength(256)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LkpReportDataset>(entity =>
            {
                entity.ToTable("lkp_ReportDataset");

                entity.Property(e => e.DateCreated).HasColumnType("datetime");

                entity.Property(e => e.DateUpdated).HasColumnType("datetime");

                entity.Property(e => e.Sproc)
                    .IsRequired()
                    .HasColumnName("SProc")
                    .HasMaxLength(512)
                    .IsUnicode(false);

                entity.Property(e => e.SqlStr).IsUnicode(false);
            });

            modelBuilder.Entity<LkpReportDatasetParameter>(entity =>
            {
                entity.ToTable("lkp_ReportDatasetParameter");

                entity.Property(e => e.DataType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DateCreated).HasColumnType("datetime");

                entity.Property(e => e.DateUpdated).HasColumnType("datetime");

                entity.Property(e => e.Dbname)
                    .IsRequired()
                    .HasColumnName("DBName")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DefaultValue)
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.Direction)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PivotDirection)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ReportName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.DataSet)
                    .WithMany(p => p.LkpReportDatasetParameter)
                    .HasForeignKey(d => d.DataSetId)
                    .HasConstraintName("FK_lkp_ReportDatesetParameter_lkp_ReportDataset");
            });

            modelBuilder.Entity<LkpReportPage>(entity =>
            {
                entity.ToTable("lkp_ReportPage");

                entity.Property(e => e.DateCreated).HasColumnType("datetime");

                entity.Property(e => e.DateUpdated).HasColumnType("datetime");

                entity.Property(e => e.PageName)
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.Template)
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.HasOne(d => d.Dataset)
                    .WithMany(p => p.LkpReportPage)
                    .HasForeignKey(d => d.DatasetId)
                    .HasConstraintName("FK_lkp_ReportPage_lkp_ReportDataset");

                entity.HasOne(d => d.Report)
                    .WithMany(p => p.LkpReportPage)
                    .HasForeignKey(d => d.ReportId)
                    .HasConstraintName("FK_lkp_ReportPage_lkp_Report");
            });

            modelBuilder.Entity<TblReportGeneration>(entity =>
            {
                entity.ToTable("tbl_ReportGeneration");

                entity.Property(e => e.DatasetsParameters).IsUnicode(false);
            });

            modelBuilder.Entity<VwClientReport>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vwClientReport");

                entity.Property(e => e.ClientDisplayName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DataType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DefaultValue)
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.Delimiter)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Destination)
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.FileName)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.Holiday)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PageName)
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.PageTemplate)
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.ParamDbName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ParamDirection)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ParamPivotDirection)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ParamReportName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Params)
                    .HasMaxLength(4000)
                    .IsUnicode(false);

                entity.Property(e => e.ReportName)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.ReportTemplate)
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.Sproc)
                    .IsRequired()
                    .HasColumnName("SProc")
                    .HasMaxLength(512)
                    .IsUnicode(false);

                entity.Property(e => e.SqlStr).IsUnicode(false);
            });

            modelBuilder.Entity<VwReportRunHist>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vwReportRunHist");

                entity.Property(e => e.AppName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ClientDisplayName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.DatasetsParameters).IsUnicode(false);

                entity.Property(e => e.FileFullPath)
                    .HasMaxLength(512)
                    .IsUnicode(false);

                entity.Property(e => e.JobParameters).IsUnicode(false);

                entity.Property(e => e.Message)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.ReportName)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.RunBy)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TimeEnd).HasColumnType("datetime");

                entity.Property(e => e.TimeStart).HasColumnType("datetime");
            });

            modelBuilder.Entity<XrefClientReport>(entity =>
            {
                entity.ToTable("xref_ClientReport");

                entity.Property(e => e.DateCreated).HasColumnType("datetime");

                entity.Property(e => e.DateUpdated).HasColumnType("datetime");

                entity.Property(e => e.Delimiter)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Holiday)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Report)
                    .WithMany(p => p.XrefClientReport)
                    .HasForeignKey(d => d.ReportId)
                    .HasConstraintName("FK_xref_ClientReport_lkp_Report");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
