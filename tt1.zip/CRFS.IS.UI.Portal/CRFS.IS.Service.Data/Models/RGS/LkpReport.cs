﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpReport
    {
        public LkpReport()
        {
            LkpReportPage = new HashSet<LkpReportPage>();
            XrefClientReport = new HashSet<XrefClientReport>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string FileName { get; set; }
        public string Template { get; set; }
        public string Destination { get; set; }
        public bool Active { get; set; }
        public DateTime DateCreated { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? DateUpdated { get; set; }
        public int? UpdatedBy { get; set; }

        public virtual ICollection<LkpReportPage> LkpReportPage { get; set; }
        public virtual ICollection<XrefClientReport> XrefClientReport { get; set; }
    }
}
