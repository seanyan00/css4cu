﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefClientReport
    {
        public int Id { get; set; }
        public int ClientId { get; set; }
        public int ReportId { get; set; }
        public string Holiday { get; set; }
        public string Delimiter { get; set; }
        public bool Active { get; set; }
        public DateTime DateCreated { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? DateUpdated { get; set; }
        public int? UpdatedBy { get; set; }

        public virtual LkpReport Report { get; set; }
    }
}
