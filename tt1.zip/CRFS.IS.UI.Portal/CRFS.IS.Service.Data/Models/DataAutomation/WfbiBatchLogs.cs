﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class WfbiBatchLogs
    {
        public WfbiBatchLogs()
        {
            WfbiErrorLogs = new HashSet<WfbiErrorLogs>();
        }

        public long WfbiBatchLogId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public int BatchStatusId { get; set; }
        public string SourceFile { get; set; }
        public string LoanNumber { get; set; }
        public long? FhaloanId { get; set; }
        public long? FhaclaimId { get; set; }
        public long? PartA27011id { get; set; }
        public long? PartB27011id { get; set; }
        public long? PartC27011id { get; set; }
        public long? PartD27011id { get; set; }
        public long? PartE27011id { get; set; }
        public int? Block2XxentriesDetected { get; set; }
        public int? Block2XxentriesLoaded { get; set; }
        public int? Block305EntriesDetected { get; set; }
        public int? Block305EntriesLoaded { get; set; }
        public int? Block306EntriesDetected { get; set; }
        public int? Block306EntriesLoaded { get; set; }
        public int? Block307EntriesDetected { get; set; }
        public int? Block307EntriesLoaded { get; set; }
        public int? Block308EntriesDetected { get; set; }
        public int? Block308EntriesLoaded { get; set; }
        public int? Block309EntriesDetected { get; set; }
        public int? Block309EntriesLoaded { get; set; }
        public int? Block310EntriesDetected { get; set; }
        public int? Block310EntriesLoaded { get; set; }
        public int? Block311EntriesDetected { get; set; }
        public int? Block311EntriesLoaded { get; set; }
        public int? Block405EntriesDetected { get; set; }
        public int? Block405EntriesLoaded { get; set; }
        public int? Block406EntriesDetected { get; set; }
        public int? Block406EntriesLoaded { get; set; }
        public int? Block407EntriesDetected { get; set; }
        public int? Block407EntriesLoaded { get; set; }
        public int? Block408EntriesDetected { get; set; }
        public int? Block408EntriesLoaded { get; set; }
        public int? Block409EntriesDetected { get; set; }
        public int? Block409EntriesLoaded { get; set; }
        public int? Block410EntriesDetected { get; set; }
        public int? Block410EntriesLoaded { get; set; }
        public int? Block411EntriesDetected { get; set; }
        public int? Block411EntriesLoaded { get; set; }
        public int? Block412EntriesDetected { get; set; }
        public int? Block412EntriesLoaded { get; set; }

        public virtual WfbiBatchStatuses BatchStatus { get; set; }
        public virtual ICollection<WfbiErrorLogs> WfbiErrorLogs { get; set; }
    }
}
