﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwChaseImpedimentBump
    {
        public string LoanNo { get; set; }
        public string ClientNo { get; set; }
        public string FhaCaseNo { get; set; }
        public short BatchNo { get; set; }
        public string Mortgagor { get; set; }
        public string State { get; set; }
        public DateTime? SaleDate { get; set; }
        public DateTime? MarketableTitle { get; set; }
        public DateTime? ExpOfRedemption { get; set; }
        public DateTime? VacancyDate { get; set; }
        public DateTime? CcCompletedDt { get; set; }
        public string CommentAnalyst { get; set; }
        public DateTime? CommentDate { get; set; }
        public string CommentText { get; set; }
        public DateTime? LastPaidTaxDate { get; set; }
        public DateTime? ClearTitleDate { get; set; }
        public string FirmName { get; set; }
        public string PrepAnalystDisp { get; set; }
        public DateTime? PrepDate { get; set; }
        public string ThirdPartyDeed { get; set; }
        public string PartaAnalyst { get; set; }
        public DateTime? AInQcr { get; set; }
        public DateTime? FileRcd { get; set; }
        public DateTime? PartaApproved { get; set; }
        public string CommentCode { get; set; }
        public DateTime? ARtnToAnalyst { get; set; }
        public DateTime? PartaAssign { get; set; }
        public DateTime? IccPrepDate { get; set; }
        public string IccPrepAnalyst { get; set; }
        public DateTime? WorkCompletedDt { get; set; }
        public string IsPropertyOccupied { get; set; }
        public DateTime? AttyDocReqDt { get; set; }
        public int? NumberImpediments { get; set; }
        public DateTime? G11 { get; set; }
        public DateTime? _174 { get; set; }
        public DateTime? Q93 { get; set; }
        public DateTime? MaxDate { get; set; }
        public string Iccdate35days { get; set; }
        public string Nicc { get; set; }
        public string Iccstatus { get; set; }
        public string Bucket { get; set; }
        public string Referred { get; set; }
        public int? Aging { get; set; }
        public int? CheckDigit { get; set; }
        public string IccPrepAnalyst2 { get; set; }
        public int? DaysSinceAssigned { get; set; }
        public string TitleStatus { get; set; }
        public string TaxStatus { get; set; }
        public DateTime? E06Dt { get; set; }
        public DateTime? E09Dt { get; set; }
        public DateTime? E10Dt { get; set; }
        public DateTime? E11Dt { get; set; }
        public DateTime? E32Dt { get; set; }
        public DateTime? E35Dt { get; set; }
        public DateTime? E36Dt { get; set; }
        public DateTime? E37Dt { get; set; }
        public DateTime? _120Dt { get; set; }
        public DateTime? _218Dt { get; set; }
        public DateTime? U43Dt { get; set; }
        public string SecondChance { get; set; }
        public string ThirdChance { get; set; }
        public DateTime? HudDueDate { get; set; }
        public string ParentImpediment { get; set; }
        public bool? HasConveyIssue { get; set; }
        public int? ConveyStatusCount { get; set; }
        public string CountyName { get; set; }
        public string ProcessorName { get; set; }
        public string FileReceivedAge { get; set; }
        public string Owner { get; set; }
        public DateTime? _333 { get; set; }
        public DateTime? _383 { get; set; }
    }
}
