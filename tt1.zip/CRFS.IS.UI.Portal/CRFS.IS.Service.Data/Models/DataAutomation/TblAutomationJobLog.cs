﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblAutomationJobLog
    {
        public TblAutomationJobLog()
        {
            DelegatedReferrals = new HashSet<DelegatedReferrals>();
            TblJobSystemLog = new HashSet<TblJobSystemLog>();
        }

        public long AutomationJobLogId { get; set; }
        public string MachineName { get; set; }
        public string Command { get; set; }
        public string Arguments { get; set; }
        public string RestartFileName { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }

        public virtual ICollection<DelegatedReferrals> DelegatedReferrals { get; set; }
        public virtual ICollection<TblJobSystemLog> TblJobSystemLog { get; set; }
    }
}
