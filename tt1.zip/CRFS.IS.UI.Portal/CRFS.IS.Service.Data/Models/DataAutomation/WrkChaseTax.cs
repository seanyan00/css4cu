﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class WrkChaseTax
    {
        public long Id { get; set; }
        public string LoanNo { get; set; }
        public string FhaCaseNo { get; set; }
        public string SubjectCode { get; set; }
        public string CommentText { get; set; }
        public DateTime? EditedDate { get; set; }
    }
}
