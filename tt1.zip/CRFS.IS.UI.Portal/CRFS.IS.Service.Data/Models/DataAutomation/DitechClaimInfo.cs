﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class DitechClaimInfo
    {
        public string LoanNumber { get; set; }
        public string StatusCode { get; set; }
        public decimal? SubmittedTotal { get; set; }
        public decimal? ReimbursedTotal { get; set; }
        public DateTime? SubmittedDatetime { get; set; }
        public decimal? LineRequestedAmount { get; set; }
        public decimal? LineCurtailedAmount { get; set; }
        public decimal? LinePaidAmount { get; set; }
        public bool LineExceptionIndicator { get; set; }
        public string LineExceptionDescription { get; set; }
        public short? LineCategoryId { get; set; }
        public short? LineSubcategoryId { get; set; }
        public DateTime? LineFromDate { get; set; }
        public DateTime? LineToDate { get; set; }
        public string LineDescription { get; set; }
    }
}
