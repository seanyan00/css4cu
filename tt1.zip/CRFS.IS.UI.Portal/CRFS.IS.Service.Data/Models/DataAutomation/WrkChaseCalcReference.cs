﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class WrkChaseCalcReference
    {
        public long Id { get; set; }
        public string ItemType { get; set; }
        public string Descr { get; set; }
        public string InitialStep { get; set; }
        public string ClosingStep { get; set; }
    }
}
