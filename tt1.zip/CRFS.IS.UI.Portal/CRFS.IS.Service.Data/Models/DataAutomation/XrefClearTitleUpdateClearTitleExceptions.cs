﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefClearTitleUpdateClearTitleExceptions
    {
        public long ClearTitleUpdateXexceptionId { get; set; }
        public long ClearTitleUpdateId { get; set; }
        public long ClearTitleUpdateExceptionId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public bool MarkedForDelete { get; set; }

        public virtual ClearTitleUpdates ClearTitleUpdate { get; set; }
        public virtual ClearTitleUpdateExceptions ClearTitleUpdateException { get; set; }
    }
}
