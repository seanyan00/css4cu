﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class AssurantAutomationExceptionMatrix
    {
        public int AssurantAutomationExceptionMatrixId { get; set; }
        public int BitValue { get; set; }
        public string Result { get; set; }
        public bool ReferredByCrfs { get; set; }
        public bool ReturnedByAssurant { get; set; }
        public bool Hoadetermination { get; set; }
        public bool FollowupExists { get; set; }
        public bool FollowupComplete { get; set; }
    }
}
