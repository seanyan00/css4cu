﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class ClientClaimPackagesFilesSent
    {
        public int FileId { get; set; }
        public int? ClientId { get; set; }
        public DateTime? DateSent { get; set; }
        public string FileName { get; set; }
    }
}
