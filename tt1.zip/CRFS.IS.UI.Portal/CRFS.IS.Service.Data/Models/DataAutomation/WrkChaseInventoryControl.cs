﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class WrkChaseInventoryControl
    {
        public long Id { get; set; }
        public string LoanNumber { get; set; }
        public string CountyName { get; set; }
        public DateTime? _120Dt { get; set; }
        public DateTime? _174Dt { get; set; }
        public DateTime? _218Dt { get; set; }
        public DateTime? _333Dt { get; set; }
        public DateTime? _383Dt { get; set; }
        public DateTime? E06Dt { get; set; }
        public DateTime? E09Dt { get; set; }
        public DateTime? E10Dt { get; set; }
        public DateTime? E11Dt { get; set; }
        public DateTime? E32Dt { get; set; }
        public DateTime? E35Dt { get; set; }
        public DateTime? E36Dt { get; set; }
        public DateTime? E37Dt { get; set; }
        public DateTime? F50Dt { get; set; }
        public DateTime? F52Dt { get; set; }
        public DateTime? F54Dt { get; set; }
        public DateTime? G11Dt { get; set; }
        public DateTime? Q85Dt { get; set; }
        public DateTime? Q86Dt { get; set; }
        public DateTime? Q87Dt { get; set; }
        public DateTime? Q93Dt { get; set; }
        public DateTime? Q95Dt { get; set; }
        public DateTime? U21Dt { get; set; }
        public DateTime? U32Dt { get; set; }
        public DateTime? U43Dt { get; set; }
        public DateTime? U63Dt { get; set; }
        public bool HasConveyIssue { get; set; }
        public int? ConveyStatusCount { get; set; }
    }
}
