﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpDocuwareProcesses
    {
        public LkpDocuwareProcesses()
        {
            XrefDataAutomationDocuware = new HashSet<XrefDataAutomationDocuware>();
        }

        public int ProcessId { get; set; }
        public string ProcessName { get; set; }

        public virtual ICollection<XrefDataAutomationDocuware> XrefDataAutomationDocuware { get; set; }
    }
}
