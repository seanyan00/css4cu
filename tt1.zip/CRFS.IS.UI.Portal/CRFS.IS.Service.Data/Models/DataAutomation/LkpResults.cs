﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpResults
    {
        public LkpResults()
        {
            TblTargetActionLog = new HashSet<TblTargetActionLog>();
        }

        public long ResultId { get; set; }
        public string ResultCode { get; set; }
        public string ResultDescription { get; set; }

        public virtual ICollection<TblTargetActionLog> TblTargetActionLog { get; set; }
    }
}
