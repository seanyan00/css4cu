﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class XrefDataAutomationDocuware
    {
        public int AutomationXrefDocuwareId { get; set; }
        public int DwdocTypeId { get; set; }
        public int DwcabinetId { get; set; }
        public int DwprocessId { get; set; }
        public int AutomationProcessId { get; set; }

        public virtual LkpAutomationProcess AutomationProcess { get; set; }
        public virtual LkpDocuwareCabinets Dwcabinet { get; set; }
        public virtual LkpDocType DwdocType { get; set; }
        public virtual LkpDocuwareProcesses Dwprocess { get; set; }
    }
}
