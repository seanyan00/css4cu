﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class WrkChasePrepLookup
    {
        public string State { get; set; }
        public string Processor { get; set; }
    }
}
