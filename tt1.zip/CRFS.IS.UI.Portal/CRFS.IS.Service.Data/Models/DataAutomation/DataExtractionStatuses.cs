﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class DataExtractionStatuses
    {
        public DataExtractionStatuses()
        {
            DataExtractionLogs = new HashSet<DataExtractionLogs>();
        }

        public int DataExtractionStatusId { get; set; }
        public string DataExtractionStatus { get; set; }
        public bool Active { get; set; }

        public virtual ICollection<DataExtractionLogs> DataExtractionLogs { get; set; }
    }
}
