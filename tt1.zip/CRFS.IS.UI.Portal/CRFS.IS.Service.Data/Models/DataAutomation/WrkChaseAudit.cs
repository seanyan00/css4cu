﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class WrkChaseAudit
    {
        public long Id { get; set; }
        public string FhaCaseNo { get; set; }
        public string ClientNo { get; set; }
        public int? ClaimType { get; set; }
        public string Batch { get; set; }
        public string LoanNo { get; set; }
        public string PartbAnalystFname { get; set; }
        public string PartbAnalyst { get; set; }
        public string PartbQcrAnalystFname { get; set; }
        public string PartbQcrAnalyst { get; set; }
        public string CmaxTableName { get; set; }
        public string CmaxColumnName { get; set; }
        public DateTime? BInQcr { get; set; }
        public DateTime? BSubmit { get; set; }
        public DateTime? OldValue { get; set; }
        public DateTime? NewValue { get; set; }
        public string AssignedProcessor { get; set; }
        public DateTime? ChangeDateTime { get; set; }
        public string CmaxUserId { get; set; }
    }
}
