﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblSystemTargetLog
    {
        public TblSystemTargetLog()
        {
            TblTargetActionLog = new HashSet<TblTargetActionLog>();
        }

        public long SystemTargetLogId { get; set; }
        public long JobSystemLogId { get; set; }
        public long? TargetId { get; set; }

        public virtual TblJobSystemLog JobSystemLog { get; set; }
        public virtual LkpTargets Target { get; set; }
        public virtual ICollection<TblTargetActionLog> TblTargetActionLog { get; set; }
    }
}
