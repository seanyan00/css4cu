﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class DataExtractionDetails
    {
        public long DataExtractionDetailId { get; set; }
        public long DataExtractionLogId { get; set; }
        public int ExtractionDetailAttributeId { get; set; }
        public string ExtractionDetailValue { get; set; }
        public bool MarkedForDelete { get; set; }

        public virtual DataExtractionLogs DataExtractionLog { get; set; }
        public virtual ExtractionDetailAttributes ExtractionDetailAttribute { get; set; }
    }
}
