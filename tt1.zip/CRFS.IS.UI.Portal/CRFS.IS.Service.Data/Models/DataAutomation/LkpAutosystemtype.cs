﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpAutosystemType
    {
        public string Code { get; set; }
        public string Description { get; set; }
    }
}
