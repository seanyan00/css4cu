﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class ClientClaimPackagesSent
    {
        public int PackageSentId { get; set; }
        public int ClientId { get; set; }
        public string LoanNumber { get; set; }
        public DateTime? ClaimPackageSentDate { get; set; }
        public DateTime ClaimSubmitDate { get; set; }
        public string ClaimCategory { get; set; }
        public string ClaimType { get; set; }
    }
}
