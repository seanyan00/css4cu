﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgHoaresponse
    {
        public int ImportBatchId { get; set; }
        public string Client { get; set; }
        public string Contract { get; set; }
        public string Portfolio { get; set; }
        public string CaseNumber { get; set; }
        public string AssignmentDate { get; set; }
        public string Sowdate { get; set; }
        public string HoareferralId { get; set; }
        public string RairesultStatus { get; set; }
        public string Iddate { get; set; }
        public string OrgConfirmationResult { get; set; }
        public string OrgConfirmationDate { get; set; }
        public string OrgPositionType { get; set; }
        public string OrgRole { get; set; }
        public string OrgName { get; set; }
        public string OrgCareOf { get; set; }
        public string OrgAddress { get; set; }
        public string OrgCity { get; set; }
        public string OrgState { get; set; }
        public string OrgZip { get; set; }
        public string OrgPhone { get; set; }
        public string OrgEmail { get; set; }
        public string OrgPmtSubmissionDate { get; set; }
        public string PrecedentResponseDate { get; set; }
        public string SourceFile { get; set; }
    }
}
