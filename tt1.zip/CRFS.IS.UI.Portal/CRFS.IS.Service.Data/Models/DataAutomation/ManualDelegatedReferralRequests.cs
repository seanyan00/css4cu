﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class ManualDelegatedReferralRequests
    {
        public int ManualDelegatedReferralRequestId { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public int InvTrkFhaclaimSubtypeFhaclaimId { get; set; }
        public bool Canceled { get; set; }
        public bool Processed { get; set; }
        public DateTime ProcessDate { get; set; }
    }
}
