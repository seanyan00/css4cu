﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpDitechLoanLookup
    {
        public string InvestorNumber { get; set; }
        public string DitechLoanNumber { get; set; }
        public string ShellpointLoanNumber { get; set; }
    }
}
