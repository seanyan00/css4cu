﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblDaLpsImportInvoiceMgmtExistingClaimHistory
    {
        public int CmsClaimId { get; set; }
        public int? LastUpdateType { get; set; }
        public DateTime? LastUpdateDate { get; set; }
        public DateTime? Pfudate { get; set; }
    }
}
