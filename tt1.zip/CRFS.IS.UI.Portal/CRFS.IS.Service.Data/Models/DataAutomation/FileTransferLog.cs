﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class FileTransferLog
    {
        public int FtmstransferId { get; set; }
        public int? FtmstaskId { get; set; }
        public string TransferFileName { get; set; }
        public DateTime TransferDateTime { get; set; }
    }
}
