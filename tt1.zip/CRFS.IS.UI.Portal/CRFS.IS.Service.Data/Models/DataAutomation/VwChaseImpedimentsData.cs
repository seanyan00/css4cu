﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwChaseImpedimentsData
    {
        public string LoanNo { get; set; }
        public string ClientNo { get; set; }
        public string FhaCaseNo { get; set; }
        public short BatchNo { get; set; }
        public string Mortgagor { get; set; }
        public string PropState { get; set; }
        public DateTime? SaleDate { get; set; }
        public DateTime? MarketableTitle { get; set; }
        public DateTime? ExpOfRedemption { get; set; }
        public DateTime? VacancyDate { get; set; }
        public DateTime? CcCompletedDt { get; set; }
        public string CommentAnalyst { get; set; }
        public DateTime? CommentDate { get; set; }
        public string CommentText { get; set; }
        public DateTime? LastPaidTaxDate { get; set; }
        public DateTime? ClearTitleDate { get; set; }
        public string FirmName { get; set; }
        public string APrepAnalyst { get; set; }
        public DateTime? PrepDate { get; set; }
        public string ThirdPartyDeed { get; set; }
        public string PartaAnalyst { get; set; }
        public DateTime? AInQcr { get; set; }
        public DateTime? FileRcd { get; set; }
        public DateTime? PartaApproved { get; set; }
        public string CommentCode { get; set; }
        public DateTime? InfoRequested { get; set; }
        public DateTime? CriticalDueDate { get; set; }
        public string InfoReqFrom { get; set; }
        public string ItemType { get; set; }
        public string Descr { get; set; }
        public string InfoComments { get; set; }
        public DateTime? AttyDocReqDt { get; set; }
        public string ParentImpediment { get; set; }
        public string Nicc { get; set; }
        public string Iccstatus { get; set; }
        public string TitleStatus { get; set; }
        public string TaxStatus { get; set; }
        public DateTime? IccPrepDate { get; set; }
        public string IccPrepAnalyst { get; set; }
        public string WorkCompletedDate { get; set; }
        public string SingleMultImped { get; set; }
        public bool? HasConveyIssue { get; set; }
        public int? ConveyStatusCount { get; set; }
        public string CountyName { get; set; }
        public string ProcessorName { get; set; }
        public string FileReceivedAge { get; set; }
        public string DelayStep { get; set; }
        public string Owner { get; set; }
        public DateTime? _333 { get; set; }
        public DateTime? _383 { get; set; }
    }
}
