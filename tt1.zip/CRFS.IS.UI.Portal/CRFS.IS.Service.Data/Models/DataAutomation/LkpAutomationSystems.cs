﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LkpAutomationSystems
    {
        public LkpAutomationSystems()
        {
            TblJobSystemLog = new HashSet<TblJobSystemLog>();
            XrefClientProcess = new HashSet<XrefClientProcess>();
        }

        public int AutomationSystemId { get; set; }
        public string SystemName { get; set; }
        public string SystemType { get; set; }
        public string SystemUrl { get; set; }
        public string SystemId { get; set; }
        public string SystemPassword { get; set; }
        public string SystemOtherCode { get; set; }
        public string MainFrameCommand { get; set; }
        public string SystemPageCheck { get; set; }
        public string SystemKey { get; set; }
        public DateTime DateEntered { get; set; }
        public bool? CredentialsValid { get; set; }
        public DateTime? DateUpdated { get; set; }
        public int? CmsClientId { get; set; }
        public long? WebCmsClientId { get; set; }
        public bool? AuthPmtAdvRetrieve { get; set; }
        public bool? AuthSs820alt { get; set; }
        public bool? AuthSs824alt { get; set; }
        public int? OwnerId { get; set; }
        public DateTime? PwdchangeDate { get; set; }
        public bool? Active { get; set; }
        public string UsedFor { get; set; }
        public int? EnteredBy { get; set; }
        public int? UpdatedBy { get; set; }

        public virtual ICollection<TblJobSystemLog> TblJobSystemLog { get; set; }
        public virtual ICollection<XrefClientProcess> XrefClientProcess { get; set; }
    }
}
