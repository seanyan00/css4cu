﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class WfbiBatchStatuses
    {
        public WfbiBatchStatuses()
        {
            WfbiBatchLogs = new HashSet<WfbiBatchLogs>();
        }

        public int BatchStatusId { get; set; }
        public string BatchStatus { get; set; }

        public virtual ICollection<WfbiBatchLogs> WfbiBatchLogs { get; set; }
    }
}
