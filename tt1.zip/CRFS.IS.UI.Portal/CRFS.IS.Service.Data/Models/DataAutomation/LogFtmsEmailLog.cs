﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LogFtmsEmailLog
    {
        public int FtmsemailLogId { get; set; }
        public int TaskId { get; set; }
        public DateTime SentDate { get; set; }
        public string RecipTo { get; set; }
        public string RecipCc { get; set; }
        public string RecipBcc { get; set; }
        public string EmailText { get; set; }
    }
}
