﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblMachineProcessAssignments
    {
        public int MachineProcessAssignmentId { get; set; }
        public int ClientProcessId { get; set; }
        public string MachineName { get; set; }
        public string ImportBatchGuid { get; set; }
        public bool ProcessComplete { get; set; }
        public DateTime DateEntered { get; set; }
        public DateTime? ProcessCompleteDate { get; set; }

        public virtual XrefClientProcess ClientProcess { get; set; }
    }
}
