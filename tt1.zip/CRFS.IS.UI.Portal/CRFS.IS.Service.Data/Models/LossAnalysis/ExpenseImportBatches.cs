﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class ExpenseImportBatches
    {
        public ExpenseImportBatches()
        {
            StgExpenseImport = new HashSet<StgExpenseImport>();
        }

        public int BatchId { get; set; }
        public string SourceFileName { get; set; }
        public DateTime ImportDateTime { get; set; }

        public virtual ICollection<StgExpenseImport> StgExpenseImport { get; set; }
    }
}
