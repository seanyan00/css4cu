﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class ExpSubCatMapping
    {
        public int ExpSubCatMapId { get; set; }
        public int ClientId { get; set; }
        public string ClientExpCatCode { get; set; }
        public string ClientExpCatDescription { get; set; }
        public int? CrfsexpSubCatId { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
