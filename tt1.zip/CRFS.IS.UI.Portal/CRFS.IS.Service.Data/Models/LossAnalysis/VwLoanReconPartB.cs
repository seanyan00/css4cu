﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwLoanReconPartB
    {
        public int LoanId { get; set; }
        public int? LoanReconPartBid { get; set; }
        public decimal? ReconUpb { get; set; }
        public decimal? ReconInterest { get; set; }
        public decimal? ReconEscrowBalance { get; set; }
        public decimal? ReconCorporateBalance { get; set; }
        public decimal? ReconSuspenseBalance { get; set; }
        public decimal? ReconRestrictedBalance { get; set; }
        public decimal? ReconLiquidationProceeds { get; set; }
        public decimal? ReconTwoMonthsInterestUl { get; set; }
        public decimal? ReconInterestDifferentialUl { get; set; }
        public decimal? ReconControllableInterest { get; set; }
        public decimal? CurrentSystemBalance { get; set; }
        public decimal? InterestCurtAmount { get; set; }
        public decimal? ReconAppliedFunds { get; set; }
        public decimal? ReconPaidAfterClaim { get; set; }
        public decimal? ReconCreditAfterClaim { get; set; }
        public decimal? ReconControllableExpense { get; set; }
        public decimal? ReconPartialProceeds { get; set; }
        public decimal? ReconFinalProceeds { get; set; }
        public decimal? TotalInterestPaid { get; set; }
        public decimal? ReconAttorneyFeesUl { get; set; }
        public decimal? ReconAttorneyCostsUl { get; set; }
        public decimal? ReconBankruptcyFeesUl { get; set; }
    }
}
