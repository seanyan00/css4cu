﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblConReconSummary
    {
        public int Id { get; set; }
        public int LoanId { get; set; }
        public decimal? NonClaimableFees { get; set; }
        public decimal? CurtailmentAmount { get; set; }
        public decimal? UnpaidBalance { get; set; }
        public decimal? MiescrowBalance { get; set; }
        public decimal? Mifees { get; set; }
        public decimal? MiinvRecBalance { get; set; }
        public decimal? MinonRecBalance { get; set; }
        public decimal? RemainingAmount { get; set; }
        public string Ufbucket { get; set; }
        public decimal? Ufamount { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public int? UpdatedBy { get; set; }

        public virtual TblConLoan Loan { get; set; }
    }
}
