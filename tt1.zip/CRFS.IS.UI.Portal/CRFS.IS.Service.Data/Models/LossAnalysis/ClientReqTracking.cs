﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class ClientReqTracking
    {
        public ClientReqTracking()
        {
            ClientReqLoanTracking = new HashSet<ClientReqLoanTracking>();
        }

        public int ClientReqTrackId { get; set; }
        public string ReqInfo { get; set; }
        public string ReqInfoDataType { get; set; }
        public string Purpose { get; set; }
        public bool ActiveInd { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual ICollection<ClientReqLoanTracking> ClientReqLoanTracking { get; set; }
    }
}
