﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TblConExpense
    {
        public int Id { get; set; }
        public int LoanId { get; set; }
        public decimal? ClaimAmount { get; set; }
        public string Comment { get; set; }
        public bool? IsControllable { get; set; }
        public int? RespPartId { get; set; }
        public int? CategoryId { get; set; }
        public int? ReasonId { get; set; }
        public string CurtailmentReason { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public int? UpdatedBy { get; set; }

        public virtual TblConLoan Loan { get; set; }
    }
}
