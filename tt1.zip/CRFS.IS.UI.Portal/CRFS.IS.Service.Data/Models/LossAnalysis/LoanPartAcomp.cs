﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LoanPartAcomp
    {
        public LoanPartAcomp()
        {
            LoanLivingUnits = new HashSet<LoanLivingUnits>();
        }

        public int PartAcompId { get; set; }
        public int LoanId { get; set; }
        public DateTime? EndorsementDate { get; set; }
        public DateTime? ClaimFiledDate { get; set; }
        public DateTime? DueDateOfLastPaymentInstallment { get; set; }
        public DateTime? DateOfPossessionAcquisition { get; set; }
        public DateTime? DateDeedOrAssignmentFiled { get; set; }
        public DateTime? ForeclosureFirstLegalDate { get; set; }
        public DateTime? DeedInLieuDate { get; set; }
        public decimal? OriginalPrincipalBalance { get; set; }
        public decimal? UnpaidPrincipalBalance { get; set; }
        public DateTime? InstitutionExtensionDate { get; set; }
        public DateTime? ConveyanceExtensionDate { get; set; }
        public DateTime? BankruptcyLiftDate { get; set; }
        public decimal? AuthorizedBidAmount { get; set; }
        public DateTime? MortgageeCurtailmentDate { get; set; }
        public int? NumberOfLivingUnits { get; set; }
        public decimal? DebentureInterestRate { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual Loan Loan { get; set; }
        public virtual ICollection<LoanLivingUnits> LoanLivingUnits { get; set; }
    }
}
