﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class VwTblConLoan
    {
        public int Id { get; set; }
        public int InvTrkLoanId { get; set; }
        public string LoanNumber { get; set; }
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public string InvestorName { get; set; }
        public int? MicompanyId { get; set; }
        public string MicompanyName { get; set; }
        public string BorrowerFirstName { get; set; }
        public string BorrowerLastName { get; set; }
        public int ClaimTypeId { get; set; }
        public string ClaimTypeName { get; set; }
        public DateTime? ClosingDate { get; set; }
        public DateTime? ThirdPartFundReceived { get; set; }
        public DateTime? Reodisposition { get; set; }
        public string PriorServicer { get; set; }
        public DateTime? InitialClaimDate { get; set; }
        public DateTime? InitialClaimPaymentReceived { get; set; }
        public string ClaimFiledBy { get; set; }
        public DateTime? FinalClaimDate { get; set; }
        public DateTime? FinalClaimPaymentReceived { get; set; }
        public DateTime? AddedDate { get; set; }
        public string SaleType { get; set; }
        public DateTime? LacompletedDate { get; set; }
        public int? AssignedAnalyst { get; set; }
    }
}
