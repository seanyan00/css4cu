﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LoanMilestone
    {
        public int LoanMilestoneId { get; set; }
        public int LoanId { get; set; }
        public int MilestoneId { get; set; }
        public DateTime MilestoneDate { get; set; }
        public int? AssignedUser { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual Loan Loan { get; set; }
        public virtual LkpMileStoneType Milestone { get; set; }
    }
}
