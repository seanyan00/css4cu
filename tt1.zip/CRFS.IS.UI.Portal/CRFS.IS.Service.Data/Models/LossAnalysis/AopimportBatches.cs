﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class AopimportBatches
    {
        public AopimportBatches()
        {
            StgAopimport = new HashSet<StgAopimport>();
        }

        public int BatchId { get; set; }
        public string SourceFileName { get; set; }
        public DateTime ImportDateTime { get; set; }

        public virtual ICollection<StgAopimport> StgAopimport { get; set; }
    }
}
