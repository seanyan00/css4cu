﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class LoanSupplemental
    {
        public int LoanSuppId { get; set; }
        public int LoanId { get; set; }
        public int SupplementalType { get; set; }
        public int SupplementalPart { get; set; }
        public decimal? SuppAmtCalculated { get; set; }
        public decimal? SuppAmtOverride { get; set; }
        public int AddedBy { get; set; }
        public DateTime AddedDate { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

        public virtual Loan Loan { get; set; }
    }
}
