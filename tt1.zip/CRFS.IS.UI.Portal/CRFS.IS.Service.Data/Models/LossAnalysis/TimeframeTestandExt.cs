﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class TimeframeTestandExt
    {
        public int LoanId { get; set; }
        public int? ConveyanceTest { get; set; }
        public int? ClaimDueTest { get; set; }
        public int? EvictionTest { get; set; }
        public int? ReasonableDiligenceTest { get; set; }
        public int? Sfdmstest { get; set; }
        public int? InstitutionTest { get; set; }
        public int? ConveyanceExtension { get; set; }
        public int? ClaimDueExtension { get; set; }
        public int? EvictionExtension { get; set; }
        public int? ReasonableDiligenceExtension { get; set; }
        public int? Sfdmsextension { get; set; }
        public int? InstitutionExtension { get; set; }
    }
}
