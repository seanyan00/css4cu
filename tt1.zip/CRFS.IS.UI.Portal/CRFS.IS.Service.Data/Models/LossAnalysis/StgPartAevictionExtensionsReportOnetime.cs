﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgPartAevictionExtensionsReportOnetime
    {
        public string LoanNumber { get; set; }
        public string FhaCaseNumber { get; set; }
        public string CloseAndBillDate { get; set; }
        public string EvictionFirstLegalDate { get; set; }
        public string ReoccupancyDate { get; set; }
        public string UnacceptableDelayStartDate { get; set; }
        public string VacancyDate { get; set; }
        public string VacancyType { get; set; }
    }
}
