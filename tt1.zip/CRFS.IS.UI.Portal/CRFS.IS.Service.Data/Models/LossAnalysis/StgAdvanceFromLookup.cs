﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgAdvanceFromLookup
    {
        public int LookupId { get; set; }
        public int ClientId { get; set; }
        public string AdvanceFrom { get; set; }
        public int CrfsAdvanceFromId { get; set; }

        public virtual LkpTypeCat CrfsAdvanceFrom { get; set; }
    }
}
