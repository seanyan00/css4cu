﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgControllableExpenseOnetime
    {
        public string Row { get; set; }
        public string PropertyLoanNumber { get; set; }
        public string ClaimCustomFhacaseNo { get; set; }
        public string ClaimCalculatedControllableExpenseLoss { get; set; }
    }
}
