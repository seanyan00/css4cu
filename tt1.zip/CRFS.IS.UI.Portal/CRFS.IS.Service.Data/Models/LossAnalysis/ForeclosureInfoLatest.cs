﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class ForeclosureInfoLatest
    {
        public int LoanId { get; set; }
        public int? MaxLoanForeclosureId { get; set; }
        public int? Type { get; set; }
        public DateTime? FirstLegalDate { get; set; }
        public DateTime? Sfdmscode68Date { get; set; }
        public int? RestartReason { get; set; }
        public bool? RestartValid { get; set; }
        public string Comments { get; set; }
    }
}
