﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgPartBreportOnetime
    {
        public string LoanNumber { get; set; }
        public string FhaCaseNumber { get; set; }
        public string ExpenseCategory { get; set; }
        public string ExpenseSubCategory { get; set; }
        public string AdvanceFrom { get; set; }
        public string PaidDate { get; set; }
        public string AmountDisbursed { get; set; }
        public string AmountClaimedPaid { get; set; }
        public string DebentureInterestClaimedPaid { get; set; }
        public string Review { get; set; }
        public string RecommendedClaimAmount { get; set; }
        public string RecommendedDebentureInterest { get; set; }
        public string ProjectedLossAmount { get; set; }
        public string ChargeOffReason { get; set; }
        public string ResponsibleParty { get; set; }
        public string Description { get; set; }
        public string InvoiceNumber { get; set; }
        public string AppraisalType { get; set; }
        public string SaleType { get; set; }
        public string ShortSaleAttempt { get; set; }
        public string WorkCompleteDate { get; set; }
        public string ForeclosureAction { get; set; }
        public string BankruptcyId { get; set; }
        public string ExpenseType { get; set; }
        public string CoverageStartDate { get; set; }
        public string CoverageEndDate { get; set; }
        public string PenaltiesFeesInterest { get; set; }
        public string CancellationDate { get; set; }
        public string EstHazRefOnClaim { get; set; }
        public string EstHazRefRecommended { get; set; }
        public string PolicyNumber { get; set; }
        public string RefundAmount { get; set; }
        public string CompletedDate { get; set; }
        public string EvictionAction { get; set; }
        public string CostEstimatorAmount { get; set; }
        public string HudApprovedAmount { get; set; }
        public string HudApprovedDate { get; set; }
        public string LotSize { get; set; }
        public string Quantity { get; set; }
        public int PartBrowId { get; set; }
    }
}
