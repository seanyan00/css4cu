﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class ControllableLossesByCat
    {
        public int LoanId { get; set; }
        public decimal InterestCurtAmount { get; set; }
        public decimal? BankruptcyFeesCosts { get; set; }
        public decimal? BpoAppraisal { get; set; }
        public decimal? PropertyPreservation { get; set; }
        public decimal? AttorneyCosts { get; set; }
        public decimal? AttorneyFees { get; set; }
        public decimal? Insurance { get; set; }
        public decimal? EvictionFeesCosts { get; set; }
        public decimal? HomeownersAssociation { get; set; }
        public decimal? Utilities { get; set; }
        public decimal? LiensCodeViolations { get; set; }
        public decimal? MortgageInsurancePremiums { get; set; }
        public decimal? Taxes { get; set; }
        public decimal? Misc { get; set; }
    }
}
