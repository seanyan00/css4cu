﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data
{
    public partial class StgLoanDataReportOnetime
    {
        public string LoanNumber { get; set; }
        public string FhaCaseNumber { get; set; }
        public string BuyOutDate { get; set; }
        public string DebentureInterestRate { get; set; }
        public string EndorsementDate { get; set; }
        public string Investor { get; set; }
        public string NoteRate { get; set; }
        public string OriginalDefaultDate { get; set; }
        public string ClaimType { get; set; }
        public string Client { get; set; }
        public string FhaCaseNumber1 { get; set; }
        public string LoanNumber1 { get; set; }
        public string PartAAnalyst { get; set; }
        public string PartBAnalyst { get; set; }
        public string Status { get; set; }
        public string ClosingDate { get; set; }
        public string ClosingReason { get; set; }
        public string CompleteDate { get; set; }
        public string DueDate { get; set; }
        public string ReferralDate { get; set; }
        public string ServiceTransferDate { get; set; }
    }
}
