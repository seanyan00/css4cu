﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

using CRFS.IS.Service.Common;

namespace CRFS.IS.Service.Data.Extensions
{
    public static class TypeHelper
    {
        public static Type GetDataType(string tname)
        {
            //TODO: EF core, using _ctx.Model.GetEntityTypes().First(x => x.ClrType == typeof(T));
            var type = Assembly.GetExecutingAssembly()
                             .GetTypes()
                             .FirstOrDefault(t => t.Name.ToUpper() == tname.ToUpper());

            if (type == null)
            {
                if (tname[tname.Length - 1] == 's')
                    type = GetDataType(tname.Substring(0, tname.Length - 1));
                if (type == null)
                    throw new TypeAccessException("Type loading failed on " + tname);
            }
            return type;
        }
        public static Type GetDataType(string tname, string ns)
        {
            var type = Assembly.GetExecutingAssembly()
                             .GetTypes().Where(t => t.IsClass && t.Namespace == ns)
                             .FirstOrDefault(t => t.Name.ToUpper() == tname.ToUpper());

            if (type == null)
            {
                throw new TypeAccessException("Type loading failed on " + tname);
            }
            return type;
        }
        public static string ToSysType(this string s)
        {
            return Constant.DBTypeMap[s];
        }
        public static string GetNonNullType(this Type t)
        {
            if (Nullable.GetUnderlyingType(t) == null)
                return t.FullName;

            return Nullable.GetUnderlyingType(t).FullName;
        }
        public static bool IsNullable(this Type t)
        {
            return Nullable.GetUnderlyingType(t) != null;
        }
        public static string GetContextName(this string target)
        {
            var ns = target.Split(".");
            return ns[0];
        }
        public static string GetClassName(this string target)
        {
            var ns = target.Split(".");
            if (ns.Length < 3)
                throw new Exception("Not a well-formed fully qualified table name");

            return ns[2].Replace("_", "").CapFirstLetter();
        }
        public static string GetTableName(this string target)
        {
            var ns = target.Split(".");
            if (ns.Length < 3)
                throw new Exception("Not a well-formed fully qualified table name");

            return ns[1] + "." + ns[2];
        }
        public static List<string> GetTypePropertiesName(string typename)
        {
            var ret = new List<string>();

            Type clstype = GetDataType(typename, "CRFS.IS.Service.Data");
            var props = clstype.GetProperties(BindingFlags.Instance | BindingFlags.Public);
            ret.AddRange(props.Where(x => x.PropertyType.Namespace == "System").Select(x => x.Name).ToList());

            return ret;
        }
    }
}
