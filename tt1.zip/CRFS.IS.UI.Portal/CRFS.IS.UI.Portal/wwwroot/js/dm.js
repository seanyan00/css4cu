﻿var PWDSTR = "************";
var dm = {
    data: {
        dataautomation: {
            cmsclientlist: {},
            cmsclientlistabbr: {},
            webcmsclientlist: {},
            userlist: {},
            autosystypelist: {}
        }
    },
    init: function () {
        $("#dv_da_fhaconncred").on("click change input", "select, input, a.btn, button", function (e) {
            dm.clearpwd();
        });
        $(document).on("click", "a.btngetpwd", function (e) {
            dm.getpwd(e);
        });
        this.loadlists();
        this.loadfhaconncredgrid();
    },
    loadlists: function () {
        this.data.dataautomation.cmsclientlist = home.loadlisttolocal("cmsclient", "");
        this.data.dataautomation.cmsclientlistabbr = home.loadlisttolocal("cmsclientabbr", "");
        this.data.dataautomation.webcmsclientlist = home.loadlisttolocal("webcmsclient", "");
        this.data.dataautomation.userlist = home.loadlisttolocal("dauser", "");
        this.data.dataautomation.autosystypelist = home.loadlisttolocal("dasystemtype", "");
        this.data.dataautomation.userlist = home.prepand({ "": "" }, this.data.dataautomation.userlist);
        this.data.dataautomation.webcmsclientlist = home.prepand({ "0": "" }, this.data.dataautomation.webcmsclientlist);
        this.data.dataautomation.autosystypelist = home.prepand({"0" : ""}, this.data.dataautomation.autosystypelist);
    },
    getpwd: function (p) {
       p.preventDefault();
       p.stopPropagation();
        
        var $tr = $(p.target).closest("tr");
        var id = $tr[0].id;
        $.ajax({
            headers: tokenhead,
            url: getDAPasswordUrl,
            data: {id: id},
            cache: false,
            dataType: "json"
        }).done(function (data) {
            if (data.success) {
                $tr.find("td:nth-child(5)").html(data.message);
                home.copytoclipboard(data.message);
            }
        }).fail(ajaxFailed);
    },
    clearpwd: function () {
        var $trs = $("tr.jqgrow", "#tbl_da_fhaconncred");
        $.each($trs, function () {
            $(this).find("td:nth-child(5)").html(PWDSTR);
        });
    },
    getapppermit: function (p) {
        var ret = 0;

        $.each(userperms, function () {
            if (this.uiType === "SubApp" && this.uiName === p) {
                if (this.uiPermit > ret)
                    ret = this.uiPermit;
            }
        })
        return ret;
    },
    getuid: function () {
        return userperms[0].uId;
     },
    onbeforeshowformfhaconncrededit: function (p) {
        $("#pData, #nData", "#Act_Buttons").hide();
        var perm = dm.getapppermit("DataAutomation");
        $("#systemName", p).attr("disabled", true);
        $("#cmS_ClientId", p).attr("disabled", true);
        if (perm <= 3) {
            $("#systemId", p).attr("disabled", true);
            $("#systemKey", p).hide();
            $("#systemPageCheck", p).hide();
            $("#mainFrameCommand", p).hide();
            $("#systemOtherCode", p).hide();
            $("#systemURL", p).hide();
            $("#auth_PmtAdv_Retrieve", p).hide();
            $("#authSS_820Alt", p).hide();
            $("#authSS_824Alt", p).hide();
            $("#credentialsValid", p).hide();
            if (perm < 3) {
                $("#ownerId", p).attr("disabled", true);
            }
        } else {
            $("#systemName", p).attr("disabled", false);
        }
    },
    onbeforeinitdatafhaconn: function (p) {
        var $grid = $("#tbl_da_fhaconncred"), rd = $grid.jqGrid("getLocalRow", $grid.jqGrid("getGridParam", "selrow"));
        var perm = dm.getapppermit("DataAutomation");
        if (perm < 3 && rd.ownerId != userperms[0].uId)
            return false;
        return true;
    },
    onbeforeshowformfhaconncredadd: function (p) {
        var perm = dm.getapppermit("DataAutomation");
        $("#systemName", p).attr("disabled", true);

        if (perm <= 3) {
            $("#systemKey", p).hide();
            $("#systemPageCheck", p).hide();
            $("#mainFrameCommand", p).hide();
            $("#systemOtherCode", p).hide();
            $("#systemURL", p).hide();
            $("#auth_PmtAdv_Retrieve", p).hide();
            $("#authSS_820Alt", p).hide();
            $("#authSS_824Alt", p).hide();
            $("#credentialsValid", p).hide();
            if (perm < 3) {
                $("#ownerId", p).val(dm.getuid());
                $("#ownerId", p).attr("disabled", true);
            }
        } else {
            $("#systemName", p).attr("disabled", false);
        }
    },
    onbeforerequestfhaconn: function () {
        var $grid = $("#tbl_da_fhaconncred");
        var perm = dm.getapppermit("DataAutomation");

        if (perm < 3) {
            $grid.jqGrid("hideCol", ["auth_PmtAdv_Retrieve", "authSS_820Alt", "authSS_824Alt", "systemType", "webCMS_ClientID", "credentialsValid", "pwdChangeDate"]);
        } else {
            $grid.jqGrid("setColProp", "systemURL", { editrules: { edithidden: true } });
            $grid.jqGrid("setColProp", "systemOtherCode", { editrules: { edithidden: true } });
            $grid.jqGrid("setColProp", "mainFrameCommand", { editrules: { edithidden: true } });
            $grid.jqGrid("setColProp", "systemPageCheck", { editrules: { edithidden: true } });
            $grid.jqGrid("setColProp", "systemKey", { editrules: { edithidden: true } });
        }
    },
    getpwdformatter: function () {
        return "<a href='#' class='btn btn-xxs btn-primary btngetpwd'>Get Password</a>";
    },
    onaftersubmitfhaconn: function (p) {
        $("#tbl_da_fhaconncred_ro").jqGrid("setGridParam", { datatype: "json" }).trigger("reloadGrid");
        return home.onaftersubmit(p);
    },
    pwdstatusformatter: function (p, p1, p2) {
        switch (p) {
            case 0:
                return "<span class='bg-success text-center text-white' style='display: block;'>&nbsp;</span>";
            case 1:
                return "<span class='bg-warning text-center text-white'  style='display: block; height: 24px;'>Past Due</span>";
            case 2:
                return "<span class='bg-warning text-center text-white'  style='display: block; height: 24px;'>Is Due</span>";
            default:
                return "<span class='bg-primary text-center text-white' style='display: block;'>Unknown</span>";
        }
    },
    onloadcompletefhaconn: function (p) {
        $.each(p, function (i, item) {
            var $td = $("#" + p[i].id).find("td").eq(16);
            $td.addClass('compacttd');
        });
    },
    loadfhaconncredgrid: function () {
        $("#tbl_da_fhaconncred").jqGrid({
            editurl: saveDAAccountUrl,
            url: getDAAccountUrl,
            datatype: "json",
            postData: { gid: 2 },
            colModel: [
                { label: "Id", name: "id", key: true, hidden: true, editable: true },
                {
                    label: "CMS Client", name: 'cmS_ClientId', width: 120, editable: true,
                    edittype: "select", formatter: 'select', editrules: { required: true }, 
                    formatoptions: { value: dm.data.dataautomation.cmsclientlist },
                    editoptions: {
                        value: dm.data.dataautomation.cmsclientlist,
                        dataEvents: [{
                            type: "change", fn: function (e) {
                                var abbr = dm.data.dataautomation.cmsclientlistabbr[$(e.target).val()]
                                var $fm = $(e.target).closest("form");
                                var rd = $("#tbl_da_fhaconncred").jqGrid("getRowData");
                                var cnt = 0, mx = 0, pat = new RegExp("^(FHA_)?" + abbr + "_?[0-9]*$", "i"), pat1 = new RegExp("[0-9]+");
                                $.each(rd, function () {
                                    var nm = this["systemName"];
                                    if (nm.search(pat) >= 0) {
                                        ++cnt;
                                        var s = nm.match(pat1);
                                        if (s) {
                                            var temp = parseInt(s[0]);
                                            if (temp > mx)
                                                mx = temp;
                                        }
                                    }
                                });
                                if (mx >= cnt)
                                    cnt = mx + 1;
                                $("#systemName", $fm).val(abbr +  (cnt == 0 ? "" : ("_" + cnt)));
                            }
                        }]
                    }
                },
                { label: "System Name", name: "systemName", width: 120, editable: true, editrules: { required: true } },
                { label: "User ID", name: "systemId", width: 90, editable: true, editrules: { required: true } },
                {
                    label: "Password", name: 'systemPassword', width: 110, editable: true, edittype: 'password', editoptions: { size: 30, maxLength: 20 },
                    editrules: { required: true }
                },
                {
                    label: " ", name: 'act', width: 100, align: 'center', formatter: dm.getpwdformatter
                },
                {
                    label: "Account Owner", name: 'ownerId', width: 100, editable: true, edittype: "select", formatter: 'select', editrules: { required: true },
                    editoptions: {
                        value: dm.data.dataautomation.userlist,
                        dataEvents: [{
                            type: "change", fn: function (e) {
                                var sleval = $(e.target).val(), perm = dm.getapppermit("DataAutomation");
                                var uid = dm.getuid();
                                if (perm < 3 && uid != sleval) {
                                    e.preventDefault();
                                    e.stopPropagation();
                                    return false;
                                }
                            }
                        }]
                    }
                },
                { label: "Purpose", name: 'usedFor', width: 150, editable: true, editoptions: { maxlength: 256 }, editrules: { required: true } },
                {
                    label: "Active", name: 'active', width: 80, editable: true, align: 'center', formatter: 'checkbox', edittype: 'checkbox', editoptions: { value: "True: False" }
                },   
                {
                    label: "PmtAdv", name: 'auth_PmtAdv_Retrieve', width: 60, editable: true, align: 'center', formatter: 'checkbox', edittype: 'checkbox', editoptions: {value: "True: False"}
                },
                {
                    label: "820Alt", name: 'authSS_820Alt', width: 60, editable: true, align: 'center', formatter: 'checkbox', edittype: 'checkbox', editoptions: { value: "True: False" }
                },
                {
                    label: "824Alt", name: 'authSS_824Alt', width: 60, editable: true, align: 'center', formatter: 'checkbox', edittype: 'checkbox', editoptions: { value: "True: False" }
                },
                {
                    label: "System Type", name: "systemType", width: 100, editable: true, edittype: "select", formatter: 'select', editrules: { required: true },
                    editoptions: {
                        value: dm.data.dataautomation.autosystypelist
                    }
                },
                {
                    label: "WebCMS Client", name: 'webCMS_ClientID', width: 100, editable: true,
                    formatter: "select", edittype: "select", editrules: { required: true },
                    editoptions: {
                        value: dm.data.dataautomation.webcmsclientlist
                    }
                },
                {
                    label: "Valid Credential", name: 'credentialsValid', width: 80, editable: true, align: 'center', formatter: 'checkbox', edittype: 'checkbox', editoptions: { value: "True: False" }
                },
               
                { label: "PWD Change Date", name: 'pwdChangeDate', width: 100 },
                { label: "PWD Status", name: 'pwdStatus', width: 80, formatter: dm.pwdstatusformatter},
                {
                    label: "Url", name: "systemURL", width: 120, editable: true, hidden: true
                },
                {
                    label: "Other Code", name: "systemOtherCode", width: 120, editable: true, hidden: true
                },
                {
                    label: "Mainframe CMD", name: "mainFrameCommand", width: 120, editable: true, hidden: true//, editrules: { edithidden: true }
                },
                {
                    label: "PageCheck", name: "systemPageCheck", width: 120, editable: true, hidden: true
                },
                {
                    label: "Key", name: "systemKey", width: 120, editable: true, hidden: true
                }
            ],
            loadonce: true,
            autowidth: true,
            viewrecords: true,
            pginput: false,
            pgbuttons: false,
            height: 300,
            rowNum: 300,
            pager: "#tbl_da_fhaconncred_pager",
            ondblClickRow: dm.ondblclickrowfhaconn,
            beforeRequest: dm.onbeforerequestfhaconn//,
           // loadComplete: dm.onloadcompletefhaconn
        });
        $("#tbl_da_fhaconncred").navGrid("#tbl_da_fhaconncred_pager", {
            del: false, search: false, beforeRefresh: home.onbeforerefresh
        }, { closeAfterEdit: true, recreateForm: true, beforeShowForm: dm.onbeforeshowformfhaconncrededit, afterSubmit: dm.onaftersubmitfhaconn, beforeInitData: dm.onbeforeinitdatafhaconn },
            { closeAfterAdd: true, recreateForm: true, beforeShowForm: dm.onbeforeshowformfhaconncredadd, afterSubmit: dm.onaftersubmitfhaconn }
        );
        $("#tbl_da_fhaconncred").jqGrid("setGroupHeaders", {
            groupHeaders: [
                { startColumnName: 'auth_PmtAdv_Retrieve', numberOfColumns: 3, titleText: 'Used by Automation' }
            ]
        });
    },
    ondblclickrowfhaconn: function (p, p1, p2, p3) {
        if (p2 == 3) {
            home.copytoclipboard($(p3.target).html());
        }
    }
  
}