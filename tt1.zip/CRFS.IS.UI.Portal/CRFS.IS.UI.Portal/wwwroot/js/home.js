﻿/* jquery 3.3.1, jqgrid 5.4.0 */
var NULLINT = "999999999";

function ajaxFailed(jqXHR, status, errmsg) {
    alert(errmsg);
}
var home = {
    data: {
        gridid: "",
        elepos: null,
        dragfileicon: null,
        scrolltop: 0,
        orgviewmodal: $.jgrid.viewModal,
        submitcallback: null,
        inlineeditoptions: {
            keys: true,
            successfunc: function () {
                var $self = $(this);
                setTimeout(function () {
                    $self.jqGrid("setGridParam", { datatype: "json" }).trigger("reloadGrid");
                }, 50);
            }
        }
    },
    init: function () {
        $.extend($.jgrid, {
            viewModal: function (selector, o) {
                if (selector.indexOf("#alertmod_") === 0) {
                    var $gbox = $(o.gbox), $selector = $(selector);
                    var of = $gbox.offset(), w = $gbox.width(), h = $gbox.height();
                    var w1 = $selector.width(), h1 = $selector.height();
                    $selector.css({
                        'top': of.top + ((h - h1) / 2),
                        'left': of.left + ((w - w1) / 2)
                    });
                }
                home.data.orgviewmodal.call(this, selector, o);
            }
        });
        $(".datepicker").datepicker({
            format: 'mm/dd/yyyy',
            todayHighlight: true,
            autoclose: true,
            forceParse: false
        });
        $("#frm_dummy").on("load", function () {
            var message = $("#frm_dummy").contents().find("body").html();
            var ttl = $("#frm_dummy").contents()[0].title;
            var $dlg = $("#dlg_info"), $lbr = $dlg.find(".row"), $lb = $dlg.find("label");
            $dlg.modal("dispose");
            if (ttl.length > 0 && ttl === "Success") {
                if (home.data.submitcallback != null) {
                    home.data.submitcallback(message.trim());
                    home.data.submitcallback = null;
                }

                $lbr.removeClass("bg-warning");
                $lbr.addClass("bg-success");
                $lb.text("Data Saved");
                $dlg.attr("data-backdrop", "false");
                $dlg.modal({
                    backdrop: false,
                    show: true
                });
           
                window.setTimeout(function () { $("#dlg_info").modal("hide"); }, 2000);
             
                // home.showinfo(message, false);
            }
            else {
               $lbr.removeClass("bg-success");
                $lbr.addClass("bg-warning");
                $lb.text(message);
                $dlg.attr("data-backdrop", "true");
                $dlg.modal({
                    backdrop: true,
                    show: true
                });
            //    home.showinfo(message, true);
            }
            $dlg[0].style.top = (home.data.elepos.top - 50) + "px";
           // $(window)['scrollTop'](home.data.scrolltop);
        });
        $('#sidebar .sub-menu > a').click(function () {
            var last = $('.sub-menu.open', $('#sidebar'));
            $('.menu-arrow').removeClass('arrow_carrot-right');
            $('.sub', last).slideUp(200);
            var sub = $(this).next();
            if (sub.is(":visible")) {
                $('.menu-arrow').addClass('arrow_carrot-right');
                sub.slideUp(200);
            } else {
                $('.menu-arrow').addClass('arrow_carrot-down');
                sub.slideDown(200);
            }
            var o = ($(this).offset());
            diff = 200 - o.top;
            if (diff > 0) {
                $("#sidebar").scrollTop = 500;
                $("#sidebar").scrollLeft -= Math.abs(diff);
            }
            else {
                $("#sidebar").scrollTop = 500;
                $("#sidebar").scrollLeft += Math.abs(diff);
            }
        });
        $(window).on('load', home.responsive);
        $(window).on('resize', home.responsive);
                 
        $('.toggle-nav').click(function () {
            if ($('#sidebar > ul').is(":visible") === true) {
                $('#main-content').css({
                    'margin-left': '0px'
                });
                $('#sidebar').css({
                    'margin-left': '-200px'
                });
                $('#sidebar > ul').hide();
                $("#container").addClass("sidebar-closed");
            } else {
                $('#main-content').css({
                    'margin-left': '200px'
                });
                $('#sidebar > ul').show();
                $('#sidebar').css({
                    'margin-left': '0'
                });
                $("#container").removeClass("sidebar-closed");
            }
        });
    },
    getinlineeditvalue: function (p, p1, p2) {
        return $("#" + p + "_" + p1, p2).val();
    },
    responsive: function() {
        var wSize = $(window).width();
        if (wSize <= 768) {
            $('#container').addClass('sidebar-close');
            $('#sidebar > ul').hide();
        }
        if (wSize > 768) {
            $('#container').removeClass('sidebar-close');
            $('#sidebar > ul').show();
        }
    },
    showinfo: function (p, p1) {
        var $lb = $(".lb-info");
        $lb.text(p);
        if (p1) {
            $lb.removeClass("bg-success");
            $lb.addClass("bg-danger");
        } else {
            $lb.removeClass("bg-danger");
            $lb.addClass("bg-success");
        }
    },
    clearinfo: function () {
        $(".lb-info").text("");
    },
    showloading: function () {
        var html = $("#scp_loading").html();
        $("body").append(html);
    },
    removeloading: function () {
        $("div.loading-overlay").remove();
    },
    logout: function () {
        $.ajax({
            type: "POST",
            headers: tokenhead,
            url: logoutUrl
        }).done(function () {}).fail(ajaxFailed);
    },
    onbeforerefresh: function () {
        $(this).jqGrid("setGridParam", { datatype: "json" });
        return [true, "", ""];
    },
    onbeforeshowform: function (p) {
        var gid = p[0].id.substr("FrmGrid_".length); //FrmGrid_tbl_parta_lossmit
        home.data.gridid = gid;
    },
    onaftersubmit: function (p) {
        if (p.status == 200) {
            var res = $.parseJSON(p.responseText);
            return [true, res.message];
        } else
            return [false, "Error Occurred"];
    },
    collopsesgrows: function (p, p1, p2) {
        var $grid = $(p);
        var trs = $("tr:has('.sgexpanded')", $grid);
        $.each(trs, function () {
            $grid.collapseSubGridRow(this.id);
        });
    },
    getfloat: function (p) {
        var ret = 0;
        if (p.length > 0) {
            var temp = p.indexOf("$") >= 0 ? p.substring(p.indexOf("$") + 1) : p;
            ret = isNaN(parseFloat(temp)) ? 0 : parseFloat(temp);
        }
        return ret;
    },
    setelepos: function (p) {
        home.data.elepos = p.getBoundingClientRect();
        home.data.scrolltop = $(window)['scrollTop']();
    },
    datenorm: function (p) {
        var ret = p;
        var reg = /^\d{1,2}\/\d{1,2}\/(\d{2}|\d{4})$/;
        var cy = parseInt(new Date().getFullYear().toString().substr(-2));
        if (reg.test(p)) {
            var darr = p.split("/");
            var m = ("0" + darr[0]).slice(-2), d = ("0" + darr[1]).slice(-2);
            var y = darr[2].length == 4 ? darr[2]
                : (parseInt(darr[2]) > cy ? ("19" + darr[2]) : ("20" + darr[2]));
            ret = m + "/" + d + "/" + y;
        } 
        return ret;
    },
    griddateformatter: function (p, p1, p2) {
        return home.datenorm(p);
    },
    prepand: function (p, p1) {
        var ret = p;
        $.each(p1, function (key, value) {
            ret[key] = value;
        });
        return p;
    },
    getcolidxbyname: function (p, p1) {
        var cm = p.jqGrid("getGridParam", "colModel"), i = 0, l = cm.length;
        for (; i < l; i++) {
            if (p1 === cm[i].name)
                return i;
        }
        return -1;
    },
    loadlisttolocal: function (p, p1) {
        var ret = {};
        $.ajax({
            url: getKeyValueListUrl + "?name=" + p + "&id=" + p1,
            dataType: "json",
            async: false
        }).done(function (data) {
            if (data.success) {
                $.each(data.data, function () {
                    ret[this.Key] = this.Value;
                });
            }
        }).fail(ajaxFailed);
        return ret;
    },
    copytoclipboard: function (p) {
        var $temp = $("<input>");
        $("body").append($temp);
        $temp.val(p).select();
        document.execCommand("copy");
        $temp.remove();
    }
};

