﻿var admin = {
    data: {

    },
    init: function () {

    }
}