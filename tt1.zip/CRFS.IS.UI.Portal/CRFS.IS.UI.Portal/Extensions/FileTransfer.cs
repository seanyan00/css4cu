﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using Microsoft.Extensions.Configuration;
using Grpc.Core;
using Google.Protobuf.WellKnownTypes;

using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Common;

namespace CRFS.IS.UI.Portal.Extensions
{
    public class FileTransfer
    {
        public async Task<string> FileUpload(MemoryStream ms, string appname, string filename, 
            int filetype, IConfiguration config, Metadata md)
        {
            var ret = Constant.Success;
            var buffsize = 512 * 1024;
            byte[] buffer = new byte[buffsize];

            try
            {
                var channel = ChannelHelper.GetChannel(config);
                
                var client = new Service.GRpc.FileTransfer.FileTransferClient(channel);
                using(var call = client.UploadFile(md))
                {
                    ms.Seek(0, SeekOrigin.Begin);
                    var br = ms.Read(buffer, 0, buffsize);
                   
                    await call.RequestStream.WriteAsync(new UploadFileRequest
                    {
                        Appname = appname,
                        Name = filename,
                        Type = filetype,
                        Content = Google.Protobuf.ByteString.CopyFrom(buffer, 0, br)
                    });
                    if(br == buffsize)
                    {
                        while((br = ms.Read(buffer, 0, buffsize)) > 0)
                        {
                            await call.RequestStream.WriteAsync(new UploadFileRequest
                            {
                                Content = Google.Protobuf.ByteString.CopyFrom(buffer, 0, br)
                            });
                        }
                    }
                    await call.RequestStream.CompleteAsync();

                    var reply = await call.ResponseAsync;
                    ret = reply.Message;
                }
            }
            catch(Exception ex)
            {
                ret = ex.Message;
                throw;
            }
            if(ret != Constant.Success)
            {
                throw new Exception(ret);
            }
            return ret;
        }
    }
}
