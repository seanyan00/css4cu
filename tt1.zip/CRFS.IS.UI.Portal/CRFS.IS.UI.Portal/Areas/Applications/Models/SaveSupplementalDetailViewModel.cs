﻿using System.ComponentModel.DataAnnotations;

namespace CRFS.IS.UI.Portal.Areas.Applications.Models
{
    public class SaveSupplementalDetailViewModel
    {
        [Required]
        public int LoanId { get; set; }
        public string SuppTrackingInfo { get; set; }
        public string HUDRecvdDate { get; set; }
        public double? HUDRecvdAmt { get; set; }
        public string RecoveryFiled { get; set; }
        public string RefundFiled { get; set; }
        public double RecoveryAmount { get; set; }
        public double RefundAmount { get; set; }
    }
}
