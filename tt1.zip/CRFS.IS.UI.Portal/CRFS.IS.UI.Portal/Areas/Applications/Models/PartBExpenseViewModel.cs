﻿using System.ComponentModel.DataAnnotations;

namespace CRFS.IS.UI.Portal.Areas.Applications.Models
{
    public class PartBExpenseViewModel
    {  
        [Required]
        public int id { get; set; }
        [Required]
        public int LoanId { get; set;}
        [Required]
        public int ExpenseCategory { get; set; }
        public int ExpenseSubCategory { get; set; }
        public string ExpenseSubCategoryName { get; set; }
        [StringLength(500, ErrorMessage = "Exceeded 500 characters")]
        public string ExpenseDescription { get; set; }
        public int AdvanceFrom { get; set; }
        [StringLength(50, ErrorMessage = "Exceeded 50 characters")]
        public string InvoiceNumber { get; set; }
        public string DisbursedDate { get; set; }
        public double DisbursedAmount { get; set; }
        public double EstimatedRefundAmount { get; set; }
        public double PreviousClaimAmount { get; set; }
        public double PreviousDebentureInterest { get; set; }
        public double PreviousChargeOffAmount { get; set; }
        public double PreviousEstimatedRefundAmount { get; set; }
        public double ClaimAmount { get; set; }
        public double DebentureInterestAmount { get; set; }
        public double ChargeOffAmount { get; set; }
        public int ChargeOffReason { get; set; }
        public int ResponsibleParty { get; set; }
        public double RecoveryAmount { get; set; }
        public double RefundAmount { get; set; }
        public double UncontrollableLossAmount { get; set; }
        public int ParentExpenseId { get; set; }
        public string oper { get; set; }
    }
}
