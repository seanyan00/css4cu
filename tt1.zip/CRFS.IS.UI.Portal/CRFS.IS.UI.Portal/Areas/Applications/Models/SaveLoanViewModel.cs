﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CRFS.IS.UI.Portal.Areas.Applications.Models
{
    public class SaveLoanViewModel
    {
        [Required]
        public int LoanId { get; set; }
        public string LoanNumber { get; set; }
        public string FHACaseNumber { get; set; }
        public int ClientID { get; set; }
        public int ClaimTypeID { get; set; }
        public int InvestorID { get; set; }
        public string BorrowerFirstName { get; set; }
        public string BorrowerLastName { get; set; }
        public string PropertyStreetAddressLine1 { get; set; }
        public string PropertyStreetAddressLine2 { get; set; }
        public string PropertyCity { get; set; }
        public int PropertyStateId { get; set; }
        public string PropertyZipCode { get; set; }
        public int PropertyLotSize { get; set; }
        public string LossAnalysisReferralDate { get; set; }
        public string LossAnalysisDueDate { get; set; }
        public string BuyOutDate { get; set; }
        public string ServiceTransferDate { get; set; }
       // public double DebentureInterestRate { get; set; }
        public double NoteRate { get; set; }
        public string CloseDate { get; set; }
        public int ClosingReasonId { get; set; }
        [Required]
        public int StatusId { get; set; }
        public string StatusDate { get; set; }
    }
}
