﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

using CRFS.IS.Service.GRpc;

namespace CRFS.IS.UI.Portal.Areas.Applications.Models
{
    public class TimeframeItem
    {
        public int LoanTimeframeId { get; set; }
        public int? LoanId { get; set; }
        public int TimeframeTypeId { get; set; }
        public string TimeframeTypeName { get; set; }
        public string TimeframeActivityDate { get; set; }
        public string TimeframeCalcDeadlineDate { get; set; }
        public string TimeframeOverrideDeadlineDate { get; set; } 
        public bool? TimeframeExtensionUsed { get; set; }
        public string TimeframeTestPass { get; set; }
    }
    public class TimeframeViewModel
    {
        [Required]
        public int LoanId { get; set; }
        public List<TimeframeItem> Timeframes { get; set; }
        public TimeframeViewModel()
        {
            Timeframes = new List<TimeframeItem>();
        }
    }
}
