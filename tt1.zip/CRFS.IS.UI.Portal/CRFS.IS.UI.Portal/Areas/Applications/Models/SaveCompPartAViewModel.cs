﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CRFS.IS.UI.Portal.Areas.Applications.Models
{
    public class SaveCompPartAViewModel
    {
        [Required]
        public int PartACompId { get; set; }
        [Required]
        public int LoanId { get; set; }
        public string EndorsementDate { get; set; }
        public string ClaimFiledDate { get; set; }
        public string DueDateOfLastPaymentInstallment { get; set; }
        public string DateOfPossessionAcquisition { get; set; }
        public string DateDeedOrAssignmentFiled { get; set; }
        public string ForeclosureFirstLegalDate { get; set; }
        public string DeedInLieuDate { get; set; }
        public double OriginalPrincipalBalance { get; set; }
        public double UnpaidPrincipalBalance { get; set; }
        public string InstitutionExtensionDate { get; set; }
        public string ConveyanceExtensionDate { get; set; }
        public string BankruptcyLiftDate { get; set; }
        public double AuthorizedBidAmount { get; set; }
        public string MortgageeCurtailmentDate { get; set; }
        public double DebentureInterestRate { get; set; }
        public int NumberOfLivingUnits { get; set; }
        public List<LivingUnitViewModel> LivingUnits { get; set; }
        public SaveCompPartAViewModel()
        {
            LivingUnits = new List<LivingUnitViewModel>();
        }
    }
    public class LivingUnitViewModel
    {
        public int LoanLivingUnitId { get; set; }
        public int LivingUnitPartATypeId { get; set; }
        public int PartAId { get; set; }
        public int UnitNum { get; set; }
        public string UnitSecuredDate { get; set; }
        public string UnitVacatedDate { get; set; }
        public string UnitOccupantName { get; set; }
        public int UnitOccupancyStatusId { get; set; }
    }
}
