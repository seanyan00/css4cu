﻿using System.ComponentModel.DataAnnotations;

namespace CRFS.IS.UI.Portal.Areas.Applications.Models
{
    public class SaveReconPartAViewModel
    {
        public int LoanReconPartAId { get; set; }
        [Required]
        public int LoanId { get; set; }
        public string UpdatedInterestCurtDate { get; set; }
        public double UpdateInterestAmount { get; set; }
        public double InterestCurtAmount { get; set; }
        public int InterestCurtRespParty { get; set; }
        public string LoanComment { get; set; }
        public string ExpenseCurtDate { get; set; }
    }
}
