﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRFS.IS.UI.Portal.Areas.Administration.Models
{
    public class PortalUserViewModel
    {
        public int id { get; set; }
        public string Login { get; set; }
        public string UserName { get; set; }
        public int Active { get; set; } 
        public string Password { get; set; }
        public string LastPWChange { get; set; }
        public int SecurityGroupID { get; set; }
        public string PhoneNum { get; set; }
        public string UserEmailAddress { get; set; }
        public int LegacyCMSUserID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int EmploymentTypeID { get; set; }
        public string oper { get; set; }
    }
}
