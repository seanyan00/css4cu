﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CRFS.IS.UI.Portal.Areas.Administration.Controllers
{
    public class SecurityController : Controller
    {
         public ActionResult Index()
        {
            return View();
        }
    }
}