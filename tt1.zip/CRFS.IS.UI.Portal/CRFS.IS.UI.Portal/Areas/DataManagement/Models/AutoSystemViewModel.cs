﻿using System.ComponentModel.DataAnnotations;

namespace CRFS.IS.UI.Portal.Areas.DataManagement.Models
{
    public class AutoSystemViewModel
    {
        [Required]
        public int id { get; set; }
        public string SystemName { get; set; }
        public string SystemType { get; set; }
        public string SystemURL { get; set; }
        public string SystemId { get; set; }
        public string SystemPassword { get; set; }
        public string SystemOtherCode { get; set; }
        public string MainFrameCommand { get; set; }
        public string SystemPageCheck { get; set; }
        public string SystemKey { get; set; }
        public bool? CredentialsValid { get; set; }
        public int CMS_ClientId { get; set; }
        public long WebCMS_ClientID { get; set; }
        public bool? Auth_PmtAdv_Retrieve { get; set; }
        public bool? AuthSS_820Alt { get; set; }
        public bool? AuthSS_824Alt { get; set; }
        public int OwnerId { get; set; }
        public string PWDChangeDate { get; set; }
        public bool? Active { get; set; }
        public string UsedFor { get; set; }
        public int PWDStatus { get; set; }
        public string oper { get; set; }
    }
}
