﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Http;

namespace CRFS.IS.UI.Portal.Models
{
    public class UploadFileViewModel
    {
        public int Template { get; set; }
        public IFormFile DataFile { get; set; }
        public List<DataFile> DataFiles { get; set; }
        public UploadFileViewModel()
        {
            DataFiles = new List<DataFile>();
        }
    }
    public class  DataFile{
        public IFormFile DF { get; set; }
    }
}
