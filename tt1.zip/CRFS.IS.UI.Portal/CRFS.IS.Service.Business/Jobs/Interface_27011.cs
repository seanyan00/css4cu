﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.Data;

namespace CRFS.IS.Service.Business.Jobs
{
    [ServiceContract(Namespace = "Interface_27011")]
    public interface Interface_27011
    {
        [OperationContract]
        DataTable save27011(DataTable dt);
        [OperationContract]
        DataTable saveEDI();
    }
}
