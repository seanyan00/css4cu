﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using System.Reflection;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Linq;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;

using NPOI;
using NPOI.SS.UserModel;
using NPOI.HSSF.UserModel;

using iText.Kernel.Pdf;

using CRFS.IS.Service.Util;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.Data.DAOs;
using CRFS.IS.Service.Data.Extensions;
using CRFS.IS.Service.Common;
using CRFS.IS.Service.Business.Models;
using CRFS.IS.Service.GRpc;

namespace CRFS.IS.Service.Business.Jobs
{
    public class ReportGenerationJob : JobBase
    {
        private int _userid;
        private string _targetfile = "";

        public string SendTo { get; set; }
        public string Subject { get; set; }
        public string TargetFolder { get; set; }
        public string FileName { get; set; }
        
        public ReportGenerationJob(SchItem schitem, ILogger logger, AppSettings appsetting) : base(schitem, logger, appsetting)
        {
            Init();
        }
        public override void Init()
        {
            
        }
        public override string DoJob(int userid = 0, string runby = "Scheduler")
        {
            var ret = Constant.Success;

            _userid = userid;

            return ret;
        }
        public override string DoJob(RunReportRequest req, int userid = 0, string runby = "Scheduler")
        {
            var ret = Constant.Success;

            _userid = userid;

            object ctx = null;
            var pctx = new PortalContext();
            var rctx = new RGSContext();

            var ljparam = req.JobParameters.ToKeyValueList(";", "=");
            
            try
            {
                var ritem = rctx.VwClientReport.Where(x => x.ReportId.ToString() == Item.ClassName && x.ClientId == Item.ClientId).ToList();
                var tempjparam = ritem.Select(x => x.Params).Take(1).Single();
                var jparam = tempjparam.ToKeyValueList("\r\n", "=");

                ljparam.AddRange(jparam.Where(x => !ljparam.Any(y => y.Key == x.Key)).ToList());

                InitJobParams(ljparam, ritem, null);

                var targetfile = Path.Combine(TargetFolder, FileName);

                foreach (var pgid in ritem.Select(x => x.PageId).Distinct().ToList())
                {
                    var ds = ritem.Where(x => x.PageId == pgid).Select(x => new ReportDataset
                    {
                        Id = x.DatasetId,
                        SProc = x.Sproc,
                        SqlStr = x.SqlStr
                    }).Take(1).Single();
                    var dbparam = new DatasetParameter { DatasetId = ds.Id };
                    dbparam.DBParameters = ritem.Where(x => x.DatasetId == ds.Id).Select(x => new DBParameter
                    {
                        ParameterId = x.ParameterId,
                        ParamDbName = x.ParamDbName,
                        ParamReportName = x.ParamReportName,
                        DataType = x.DataType,
                        ParamDirection = x.ParamDirection,
                        ParamPivotDirection = x.ParamPivotDirection,
                        DefaultValue = x.DefaultValue,
                        IsNullable = x.Nullable,
                        ForReportName = x.ForReportName ?? 0,
                        MaxLen = x.MaxLen ?? 0,
                        Value = ""
                    }).Distinct().ToList();

                    UpdateDatasetParameter(dbparam.DBParameters, req.ReportDatasetParameters.Where(x => x.DataSetId == ds.Id).ToList());

                    var lsqlparam = CreateSqlParameter(ds.Id, dbparam.DBParameters);

                    switch (ds.SProc.GetContextName().ToUpper())
                    {
                        case "CLAIMSMANAGEMENT":
                            ctx = new ClaimsManagementContext();
                            break;
                        case "HUDCLAIMS":
                            ctx = new HUDClaimsContext();
                            break;
                        default:
                            throw new Exception("No mapping for DbConext of Stored Procedure " + ds.SProc);
                    }

                    var rd = (SqlDataReader)new RawSqlDAO(userid, (DbContext)ctx, null).RunSproc(ds.SProc);

                    var rpt = ritem.Take(1).Single();
                    switch (rpt.FileName.GetFileExtension().ToUpper())
                    {
                        case "XLSX":
                            CreateExeclReport(targetfile, rd, ritem, pgid, dbparam.DBParameters);
                            break;
                        case "PDF":
                            CreatePDFReport(targetfile, rd, ritem, pgid, dbparam.DBParameters);
                            break;
                        default:
                            CreateTextReport(targetfile, rd, dbparam.DBParameters, string.IsNullOrEmpty(rpt.Delimiter) ? "," : rpt.Delimiter);
                            break;

                    }
                }

            }
            catch
            {
                throw;
            }
            finally
            {
                if (pctx != null)
                    pctx.Dispose();
                if (rctx != null)
                    rctx.Dispose();
                if (ctx != null)
                    ((DbContext)ctx).Dispose();        
                
            }
            return ret;
        }
        private void InitJobParams(List<KeyValuePair<string, string>> ljp, List<VwClientReport> lclnrpt, List<DBParameter> ldbp)
        {
            /*{Name}{Client}{RunDateTime}{Yesterday}{Parameter})*/
            SendTo = ljp.GetJobParamValue("SendTo");
            Subject = ljp.GetJobParamValue("Subject");
            TargetFolder = lclnrpt.GetReportParamValue("Destination");
            FileName = lclnrpt.GetReportParamValue("FileNme");

            if (FileName.IndexOf("{Name}") != -1)
                FileName = FileName.Replace("{Name}", lclnrpt.GetReportParamValue("ReportName"));
            if (FileName.IndexOf("{Client}") != -1)
                FileName = FileName.Replace("{Client}", lclnrpt.GetReportParamValue("ClientDisplayName"));
            if (FileName.IndexOf("{RunDateTime}") != -1)
                FileName = FileName.Replace("{RunDateTime}", DateTime.Now.ToString(Constant.DateTimeStringFlat));
            if (FileName.IndexOf("{Yesterday}") != -1)
                FileName = FileName.Replace("{Yesterday}", DateTime.Today.AddDays(-1).ToString(Constant.DateStringFlat));
            if (FileName.IndexOf("{LastWeek}") != -1)
                FileName = FileName.Replace("{LastWeek}", DateTime.Now.AddDays(-(int)DateTime.Now.DayOfWeek - 6).ToString(Constant.DateStringFlat));
            if (FileName.IndexOf("{LastMonth}") != -1)
                FileName = FileName.Replace("{LastMonth}", DateTime.Now.AddMonths(-1).ToString("Y"));
            if (FileName.IndexOf("{LastYear}") != -1)
                FileName = FileName.Replace("{LastYear}", DateTime.Now.AddYears(-1).ToString());
        }
        private void UpdateDatasetParameter(List<DBParameter> ldbp, List<ReportDatasetParameter> lrdsp)
        {
            foreach(var p in ldbp)
            {
                if(lrdsp.Any(x => x.DBName == p.ParamDbName && p.ParamDirection == "Input"))
                {
                    p.Value = lrdsp.Single(x => x.DBName == p.ParamDbName && p.ParamDirection == "Input").Value;
                }
            }
        }
        private List<SqlParameter> CreateSqlParameter(int dsid, List<DBParameter> ldbp)
        {
            var ret = new List<SqlParameter>();

            foreach(var p in ldbp.Where(x => x.ParamDirection == "Input").ToList())
            {
                var val = !string.IsNullOrEmpty(p.Value) ? p.Value : p.DefaultValue;
                if(string.IsNullOrEmpty(val) && !p.IsNullable)
                {
                    throw new Exception("Dataset: " + dsid.ToString() + ", Sql Parameter " + p.ParamDbName + " is non-nullable");
                }
                Type t = Type.GetType(p.DataType);

                ret.Add(new SqlParameter(p.ParamDbName, EntityAttributeHelper.GetValue(p.Value, t)));
            }
            return ret;
        }
        private void CreateExeclReport(string fnm, SqlDataReader rd, List<VwClientReport> lclnrpt, int dsid, List<DBParameter> ldbp) { }
        private void CreatePDFReport(string fnm, SqlDataReader rd, List<VwClientReport> lclnrpt, int dsid, List<DBParameter> ldbp) { }
        private void CreateTextReport(string fnm, SqlDataReader rd, List<DBParameter> ldbp, string dlm) { }
    }
}
