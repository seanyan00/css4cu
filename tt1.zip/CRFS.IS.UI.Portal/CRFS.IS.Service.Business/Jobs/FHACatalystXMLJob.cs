﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using System.Reflection;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Linq;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;

using CRFS.IS.Service.Util;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.Common;
using CRFS.IS.Service.Business.Models;

namespace CRFS.IS.Service.Business.Jobs
{
    public class FHACatalystXMLJob : JobBase
    {
        private class ClaimGroup
        {
            public int GroupId { get; set; }
            public string GroupName { get; set; }
            public long ClaimTypeId { get; set; }
            public string ClaimTypeName { get; set; }
            public long ClaimSubTypeId { get; set; }
            public string ClaimSubTypeName { get; set; }
        }
        private readonly Dictionary<string, string> FHAClaimTypeMap = new Dictionary<string, string>
        {
            { "05-Supplemental", "05" },
            { "31-Special Forbearance", "31" },
            { "32-Loan Modification", "32" },
            { "33-HAMP Partial Claim", "33" },
            { "33-Natural Disaster Partial Claim", "33" },
            { "33-National Emergency Partial Claim", "33" }
        };
        private readonly string SUBJECT = "{0} Claim XML Run Results";
        private readonly string ERRORSUBJECT = "{0} Claim XML Error Results";

        public string SendFrom { get; set; }
        public string SendTo { get; set; }
        public string Subject { get; set; }
        public string DestinationFolder { get; set; }
        public string DestinationFile { get; set; }
        public List<string> DestinationFiles { get; set; }
        public string ErrorStart { get; set; }
        public string ErrorEnd { get; set; }
        public string ErrorSendTo { get; set; }
        public string SProcName { get; set; }
        public string LinkedFolder { get; set; }
        public string CC { get; set; }
        public int UserId { get; set; }
        public string XsdFile { get; set; }
        public List<LkpClaimGroup> ClaimGroups { get; set; }

        public string CurrGroup = "";
        public string CurrFHACaseNumber = "";

        public FHACatalystXMLJob(SchItem schitem, ILogger logger, AppSettings appsetting) : base(schitem, logger, appsetting)
        {
            XsdFile = Path.Combine(appsetting.FilePath, "Templates", "Bulk Claims Input.xsd");
            DestinationFiles = new List<string>();
            Init();
        }
        public override string DoJob(int userid = 0, string runby = "Scheduler", params string[] parr)
        {
            throw new NotImplementedException();
        }
        public override string DoJob(int userid = 0, string runby = "Scheduler")
        {
            var ret = Constant.Success;

            var clmtypes = new List<ClaimGroup>();
            var lkps = new List<LkpFhalookups>();
            var ids = new List<SubmitItem>();
            var cls = new List<LkpClients>();
            var loans = new List<InvTrkLoan>();
            var analyts = new List<string>();
            var users = new List<LkpUsers>();
            var badclaims = new List<NodeMessage>();
            var desfile = "";

            object temp = null;
            int id = 0;
            Logger.LogInformation("FHACatalystXMLJob started at " + DateTime.Now.ToString());
            try
            { 
                UserId = userid > 0 ? userid : UserId;
                var status = new TblScheduledJobStatus
                {
                    Id = 0,
                    JobId = Item.Id,
                    RunBy = runby,
                    TimeStart = DateTime.Now,
                    Message = "",
                    Status = "Started"
                };
 
                id = JobStatusHelper.SaveStatus(status);
                using(var hudctx = new HUDClaimsContext())
                {
                    lkps = hudctx.LkpFhalookups.ToList();
                }
                using (var appctx = new ApplicationConfigurationContext())
                {
                    cls = appctx.LkpClients.ToList();
                    users = appctx.LkpUsers.Where(x => x.Active).ToList();
                    clmtypes =   appctx.XmlExtractionClaimTypeConfig.Where(x => x.Active).ToList().Select(x => new ClaimGroup { 
                        GroupId = x.FhaclaimGroup,
                        GroupName = lkps.Single(y => y.FhalookupId == x.FhaclaimGroup).Lutext,
                        ClaimTypeId = x.ClaimType,
                        ClaimTypeName = lkps.Single(y => y.FhalookupId == x.ClaimType).Lutext,
                        ClaimSubTypeId = x.FhalookUpId,
                        ClaimSubTypeName = lkps.Single(y => y.FhalookupId == x.FhalookUpId).DisplayCode1
                    }).ToList();
                }
              
                foreach (var clmtype in clmtypes.Select(x => x.GroupId).Distinct()) {
                    badclaims.Clear();
                    ids.Clear();
                    analyts.Clear();

                    CurrGroup = clmtypes.Where(x => x.GroupId == clmtype).First().GroupName;

                    var CurrGroupCon = ClaimGroups.Single(x => x.FhaclaimGroup == clmtype);

                    using (var cmd = new HUDClaimsContext().Database.GetDbConnection().CreateCommand())
                    {
                        desfile = DestinationFile + "_" + clmtypes.First(x => x.GroupId == clmtype).GroupName.Replace(" ", "") + "_" + DateTime.Now.ToString("yyyyMMdd_hhmm") + ".xml";

                        cmd.CommandText = SProcName;
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@claimGroup", clmtype));

                        if (cmd.Connection.State != System.Data.ConnectionState.Open)
                            cmd.Connection.Open();

                        temp = cmd.ExecuteScalar();
                    }
                    if (!(temp is DBNull) && ((string)temp).Length > 100)
                    {
                        var sc = new XmlSchemaSet();
                        sc.Add("", XsdFile);

                        // var xmle = XDocument.Load("C:\\working\\tasks\\portal\\t15159 fha catalyst\\test\\claims.xml");
                        var xmle = XDocument.Parse((string)temp);

                        xmle.Validate(sc, delegate (object sender, ValidationEventArgs e)
                        {
                            XmlSchemaValidationException ve = e.Exception as XmlSchemaValidationException;
                            if (ve != null)
                            {
                                object errorNode = ve.SourceObject;
                                var ele = (XElement)sender;
                                var pele = ele.Ancestors("CLAIM_INPUT").Single();
                                badclaims.Add(new NodeMessage { Node = pele, Message = ve.Message });
                            }
                        });

                        var claims = xmle.Descendants("CLAIM_INPUT");

                        var cnt = claims.Count();
                        for (var i = cnt - 1; i >= 0; i--)
                        {
                            var fhacasenum = claims.ElementAt(i).Element("FHA_CASE_NUMBER").Value;
                            var claimtype = claims.ElementAt(i).Element("FORM_TYPE").Value;
                            var typecode = Regex.Match(claimtype, @"^[a-zA-Z0-9]{2,4}-").Value;
                            if (!string.IsNullOrEmpty(typecode))
                                typecode = typecode.Replace("-", "");

                            CurrFHACaseNumber = fhacasenum;

                            var errnodes = claims.ElementAt(i).Descendants().Where(x => x.Value.IndexOf(ErrorStart) >= 0 && x.Value.IndexOf(ErrorEnd) >= 0 && !x.HasElements);
                            if (errnodes.Count() > 0)
                            {
                                foreach (var errn in errnodes)
                                {
                                    badclaims.Add(new NodeMessage { Node = claims.ElementAt(i), Message = errn.Value.Replace(ErrorStart, "").Replace(ErrorEnd, "") });
                                }
                            }
                            var items = badclaims.Where(x => x.Node == claims.ElementAt(i)).ToList();
                            if (items.Count > 0)
                            {
                                claims.ElementAt(i).Remove();
                                ids.Add(new SubmitItem
                                {
                                    FHACaseNum = fhacasenum,
                                    ClaimTypeCode = typecode,
                                    IsError = true,
                                    Message = string.Join(";", items.Select(x => x.Message).ToArray())
                                });
                            }
                            else
                                ids.Add(new SubmitItem {FHACaseNum = fhacasenum, ClaimTypeCode = typecode, IsError = false });
                        }

                        if (claims.Count() > 0)
                        {
                            using (var writer = new XmlTextWriter(Path.Combine(CurrGroupCon.Destination, desfile), new UTF8Encoding(false)))
                            {
                                xmle.Save(writer);
                                DestinationFiles.Add(desfile); // fine, destinationfile will be a new object everytime it changes
                            }
                        }
                    }
                    using (var hudctx = new HUDClaimsContext())
                    {
                        var edis = hudctx.TblFhaclaimEdilog.Where(x => (x.OutboundExtractDate == null
                                                                        || x.OutboundExtractDate == Convert.ToDateTime("1/1/1900"))
                                                                        && !x.MarkedForDelete).ToList();
                        foreach (var c in ids)
                        {
                            var typecode = Convert.ToInt32(Regex.Match(c.ClaimTypeCode, @"^\d+").Value);
                            var tid = hudctx.VwFhaClaimTypes.Where(x => Convert.ToInt32(x.ClaimTypeCode) == typecode).Select(x => x.ClaimTypeId).Single();
                            var fhaclaims = hudctx.TblFhaclaims.Where(x => x.ClaimTypeId == tid && x.Fhaloan.FhacaseNumber == c.FHACaseNum).ToList();
                            var part = c.ClaimTypeCode == "01A" ? "A" : (c.ClaimTypeCode == "01B" ? "B" : "X");
                            var edi = edis.Where(x => fhaclaims.Any(y => y.FhaclaimId == x.FhaclaimId) && x.SubmitPart == part).Single();

                            if (!c.IsError)
                            {
                                edi.OutboundExtractDate = DateTime.Now;
                                if (c.ClaimTypeCode == "01A")
                                    edi.EdiXmlIndicator = true;
                            }
                            var t1 = (from a in hudctx.TblFhaclaims
                                      join floan in hudctx.TblFhaloans on a.FhaloanId equals floan.FhaloanId
                                      join l in hudctx.VwInvTrkLoan on floan.InvTrkLoanId equals l.Id
                                      where a.FhaclaimId == edi.FhaclaimId
                                      select new
                                      {
                                          ClaimTypeId = a.ClaimTypeId,
                                          ClaimSubTypeId = a.FhaclaimSubTypeId,
                                          LoanNum = l.LoanNumber,
                                          InvTrkClaimId = a.InvTrkClaimId,
                                          ClientId = floan.FhaclientId
                                      }).Single();

                            c.ClientName = cls.Where(x => x.ClientId == t1.ClientId).Select(x => x.ClientDisplayName).Single();
                            c.ClaimSubTypeName = lkps.Where(x => x.FhalookupId == t1.ClaimSubTypeId).Select(x => x.DisplayCode1).Single();
                            c.ClaimTypeName = lkps.Where(x => x.FhalookupId == t1.ClaimTypeId).Select(x => x.Lutext).Single();
                            c.LoanNumber = t1.LoanNum;
                            c.InvTrkClaimId = t1.InvTrkClaimId ?? 0;
                            c.CMSSubmitTime = (edi.EnteredDate ?? DateTime.MinValue).ToString(Constant.DateTimeString);

                            if (c.IsError)
                            {
                                var anas = (from a in hudctx.TblFhaclaims
                                            join b in hudctx.VwInvTrkFhaclaim on a.InvTrkClaimId equals b.ClaimId
                                            where a.FhaclaimId == edi.FhaclaimId
                                            select new { AAnalystID = b.PartAanalyst ?? 0, BQCId = b.PartBqcanalyst ?? 0 }).Single();

                                if (users.Any(x => x.UserId == anas.AAnalystID))
                                    analyts.Add(users.Where(x => x.UserId == anas.AAnalystID).Select(x => x.UserEmailAddress).Single());
                                if (users.Any(x => x.UserId == anas.BQCId))
                                    analyts.Add(users.Where(x => x.UserId == anas.BQCId).Select(x => x.UserEmailAddress).Single());
                            }
                        }
                        hudctx.SaveChanges();
                    }

                    using (var cmsctx = new ClaimsManagementContext())
                    {
                        cmsctx.Database.SetCommandTimeout(Constant.DBCommandTimeoutLong);
                      
                        foreach (var c in ids.Where(x => !x.IsError).ToList())
                        {  
                            var fhac = cmsctx.TblInvestorTrackingClaimsFhaclaim.Where(x => x.ClaimId == c.InvTrkClaimId).Single();
                            if (c.ClaimTypeCode == "01A")
                            {
                                fhac.ConvPartAsubmittedAnalystId = 3;
                                fhac.ConvPartAsubmittedDate = DateTime.UtcNow;
                            }
                            else {
                                fhac.ClaimSubmittedAnalystId = 3;
                                fhac.ClaimSubmittedDate = DateTime.UtcNow;
                            }
                            fhac.LastUpdateDate = DateTime.UtcNow;
                            fhac.LastUpdateUser = UserId;
                            cmsctx.SaveChanges();
                        }
                    }
                    using (var portalctx = new PortalContext())
                    {
                        foreach (var i in ids)
                        {
                            portalctx.TblJobItemDetail.Add(new TblJobItemDetail
                            {
                                Id = 0,
                                KeyName = "Id",
                                KeyTable = "ClaimsManegement.dbo.tblInvestortracking_Claims",
                                KeyValue = i.InvTrkClaimId.ToString(),
                                ScheduledJobId = id,
                                Message = i.Message,
                                EnteredDate = DateTime.Now
                            });
                            portalctx.SaveChanges();
                        }
                    }

                    string body = "";
                    if (ids.Any(x => x.IsError))
                    {
                        var errmsg = string.Join(";", ids.Where(x => x.IsError).Select(x => x.FHACaseNum + ":" + x.Message).ToArray());
                        JobStatusHelper.UpdateStatus(id, "Error", (DateTime?)null, errmsg);

                        analyts = analyts.Distinct().ToList();

                        var esend = analyts.Count > 0 ? string.Join(",", analyts.ToArray()) : CurrGroupCon.ErrorEmail;
                        var cc = analyts.Count == 0 ? "" : CurrGroupCon.ErrorEmail;

                        body = GetEmailBody(ids, CurrGroup, true);
                        Email.SendMail(SendFrom, esend, string.Format(ERRORSUBJECT, CurrGroup), body,
                                            null,
                                            Setting.MailServer, cc);

                        using (var cmd = new ClaimsManagementContext().Database.GetDbConnection().CreateCommand())
                        {
                            cmd.CommandText = "dbo.usp_ClaimsManagement_UncheckEDI";
                            cmd.CommandType = System.Data.CommandType.StoredProcedure;
                            if (cmd.Connection.State != System.Data.ConnectionState.Open)
                                cmd.Connection.Open();
                            foreach (var claim in ids.Where(x => x.IsError).ToList())
                            {
                                cmd.Parameters.Clear();
                                SqlParameter param = new SqlParameter("@UserID", System.Data.SqlDbType.BigInt);
                                param.Value = UserId;
                                cmd.Parameters.Add(param);
                                param = new SqlParameter("@ClaimID", System.Data.SqlDbType.BigInt);
                                param.Value = claim.InvTrkClaimId;
                                cmd.Parameters.Add(param);
                                param = new SqlParameter("@FHACaseNumber", System.Data.SqlDbType.VarChar, 12);
                                param.Value = claim.FHACaseNum;
                                cmd.Parameters.Add(param);
                                param = new SqlParameter("@LoanNumber", System.Data.SqlDbType.VarChar, 10);
                                param.Value = claim.LoanNumber;
                                cmd.Parameters.Add(param);
                                param = new SqlParameter("@Client", System.Data.SqlDbType.VarChar, 50);
                                param.Value = "%";
                                cmd.Parameters.Add(param);
                                param = new SqlParameter("@ClaimType", System.Data.SqlDbType.VarChar, 50);
                                param.Value = "%";
                                cmd.Parameters.Add(param);
                                param = new SqlParameter("@ClaimPart", System.Data.SqlDbType.VarChar, 1);
                                param.Value = claim.ClaimTypeCode == "01A" ? "A" : (claim.ClaimTypeCode == "01B" ? "B" : "X"); 
                                cmd.Parameters.Add(param);
                                var t2 = cmd.ExecuteScalar();
                            }
                        }
                    }
                    body = GetEmailBody(ids, CurrGroup);
                    Email.SendMail(SendFrom, CurrGroupCon.SendToEmail, string.Format(SUBJECT, CurrGroup), body,
                                        null,
                                        Setting.MailServer, CC);
                }
                           
                JobStatusHelper.UpdateStatus(status.Id, "Complete", DateTime.Now);
                Logger.LogInformation("FHACatalystXMLJob complete");
            }
            catch(Exception ex)
            {
                JobStatusHelper.UpdateStatus(id, "Error", (DateTime?)null, ex.Message);
                Logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                Email.SendMail(SendFrom, "Larry.Roggow@crfservices.com,Rhiannon.Moody@crfservices.com,sean.yan@crfservices.com", "XML Run Exception", 
                                   CurrGroup + " " + CurrFHACaseNumber + ":" + ex.Message,
                                   null,
                                   Setting.MailServer);
                ret = ex.Message;
            }
            return ret;
        }
        public override void Init()
        {
            SendFrom = Item.GetParamValue("EmailFrom");
            SendTo = Item.GetParamValue("EmailTo");
            Subject = //Item.GetParamValue("Subject");
            DestinationFolder = Item.GetParamValue("DestinationFolder");
            DestinationFile = Item.GetParamValue("DestinationFile");
            ErrorStart = Item.GetParamValue("ErrorStart");
            ErrorEnd = Item.GetParamValue("ErrorEnd");
            SProcName = Item.GetParamValue("StoredProcedure");
            LinkedFolder = Item.GetParamValue("LinkedFolder");
            ErrorSendTo = Item.GetParamValue("ErrorSendTo");
            UserId = Convert.ToInt32(Item.GetParamValue("UserId"));
            CC = Item.GetParamValue("CC");
            using(var appctx = new ApplicationConfigurationContext())
            {
                ClaimGroups = appctx.LkpClaimGroup.ToList();
            }
        }
        public string GetEmailBody(List<SubmitItem> items, string gname, bool forerr = false)
        {
            var sb = new StringBuilder();
            var completetitle = "<table cellspacing='0' cellpadding='0' width='800px' border=0><tr><td width='58%' style='border: 0;vertical-align: top;'><h3>{2} Claims XML Run Results {0}</h3></td>"
                                + "<td  style='border: 0; margin-left: 5px;'>{1}</td></tr></table>";
            var errortitle = "<h3>{1} Claims XML Error Results-{0}</h3>";
            var rundate = DateTime.Now.ToString("MM/dd/yyyy hh:mmtt");
            var folder = new StringBuilder();

            if (forerr)
            {
                sb.Append(string.Format(errortitle, rundate, gname));
                sb.Append("<table cellspacing='0' cellpadding='0' width='800px' border=1 style='border-collapse: collapse;'>");
                sb.Append("<tr><th width='12%'>FHACaseNumber</th><th width='15%'>Client</th>");
                sb.Append("<th width='12%'>LoanNumber</th><th width='12%'>ClaimType</th><th width='12%'>SubType</th><th>Error</th></tr>");
                foreach (var si in items.Where(x => x.IsError))
                {
                    sb.Append("<tr style='background-color: #fadbd8;'>");
                    sb.Append("<td>" + si.FHACaseNum + "</td>");
                    sb.Append("<td>" + si.ClientName + "</td>");
                    sb.Append("<td>" + si.LoanNumber + "</td>");
                    sb.Append("<td>" + si.ClaimTypeName + "</td>");
                    sb.Append("<td>" + si.ClaimSubTypeName + "</td>");
                    sb.Append("<td style='word-wrap: break-word;'>" + si.Message + "</td>");
                    sb.Append("</tr>");
                }
            }
            else
            {
                var first = "";
                if (DestinationFiles.Count > 0)
                {
                    foreach (var df in DestinationFiles)
                    {
                        folder.Append(first);
                        folder.Append("<a href='" + Path.Combine(string.IsNullOrEmpty(LinkedFolder) ? DestinationFolder : LinkedFolder, df) + "'>" + df + "</a>");
                        first = "<br />";
                    }
                }
                sb.Append(string.Format(completetitle, rundate, folder.ToString(), gname));
                sb.Append("<table width='600px' cellspacing='0' cellpadding='0' border=1 style='border-collapse: collapse;margin-top: 8px;'>");
                sb.Append("<tr><th width='10%'>Status</th><th width='15%'>FHACaseNumber</th><th width='20%'>ClientName</th>");
                sb.Append("<th width='12%'>LoanNumber</th><th width='15%'>ClaimTypeName</th><th width='12%'>SubType</th><th>CMS Submit Time</th></tr>");
                foreach(var si in items.OrderBy(x => x.ClientName))
                {
                    if(si.IsError)
                        sb.Append("<tr style='background-color: #fadbd8;'>");
                    else
                        sb.Append("<tr style='background-color: #d5f5e3;'>");
                    sb.Append("<td>" + (si.IsError ? "Fail" : "Success") + "</td>");
                    sb.Append("<td>" + si.FHACaseNum + "</td>");
                    sb.Append("<td>" + si.ClientName + "</td>");
                    sb.Append("<td>" + si.LoanNumber + "</td>");
                    sb.Append("<td>" + si.ClaimTypeName + "</td>");
                    sb.Append("<td>" + si.ClaimSubTypeName + "</td>");
                    sb.Append("<td>" + si.CMSSubmitTime + "</td>");
                    sb.Append("</tr>");
                }
            }
            sb.Append("</table>");

            return sb.ToString();
        }
    }
}
