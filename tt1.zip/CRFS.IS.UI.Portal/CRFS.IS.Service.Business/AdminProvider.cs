﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Google.Protobuf.WellKnownTypes;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.Common.TransferObjects;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Security;

namespace CRFS.IS.Service.Business
{
    public class AdminProvider
    {
        private IConfiguration _config;
        private ILogger _logger;
        private int _userid;

        public AdminProvider(IConfiguration config, ILogger logger, int uid)
        {
            _config = config;
            _logger = logger;
            _userid = uid;
        }
        public GetUsersReply GetUsers()
        {
            var ret = new GetUsersReply();

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    var temp = acctx.LkpUsers.Select(x => new PortalUser
                    {
                        Active = x.Active ? 1 : 0,
                     //   AllClientAccess = x.AllClientAccess.GetIntValue(),
                        EmploymentTypeID = x.EmploymentTypeId.GetIntValue(),
                        FirstName = x.FirstName.GetSafeString(),
                        LastName = x.LastName.GetSafeString(),
                        LastPWChange = x.LastPwchange.GetSafeString(),
                        LegacyCMSUserID = x.LegacyCmsuserId.GetIntValue(),
                        Login = x.Login,
                        Password = Constant.PasswordStr,
                        PhoneNum = x.PhoneNum.GetSafeString(),
                        SecurityGroupID = x.SecurityGroupId.GetIntValue(),
                        UserEmailAddress = x.UserEmailAddress.GetSafeString(),
                        UserID = x.UserId,
                        UserName = x.UserName
                    }).ToList();

                    ret.Users.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public string SaveUser(PortalUser data)
        {
            var ret = Constant.Success;

            try
            {
                using (var acctx = new ApplicationConfigurationContext())
                {
                    if(data.UserID > 0)
                    {
                        var temp = acctx.LkpUsers.Where(x => x.UserId == data.UserID).Single();
                        temp.LastUpdateDate = DateTime.Now;
                        temp.LastUpdateUserId = _userid;

                        temp.Active = data.Active == 1;
                    //    temp.AllClientAccess = data.AllClientAccess.GetBoolValue();
                        temp.EmploymentTypeId = data.EmploymentTypeID.GetNullValue();
                        temp.FirstName = data.FirstName;
                        temp.LastName = data.LastName;
                        //temp.LastPwchange = Convert.ToDateTime(data.LastPWChange);
                        temp.LegacyCmsuserId = data.LegacyCMSUserID.GetNullValue();
                        //temp.Password =
                        temp.PhoneNum = data.PhoneNum;
                        temp.SecurityGroupId = data.SecurityGroupID.GetNullValue();
                        temp.UserEmailAddress = data.UserEmailAddress;
                        temp.UserName = data.UserName;
                    }
                    else
                    {
                        acctx.LkpUsers.Add(new LkpUsers
                        {
                            //using logic in usp_CreateUser
                        });
                    }
                    acctx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }
    }
}
