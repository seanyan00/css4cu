﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRFS.IS.Service.Business.Models
{
    public class SchItem
    {
        public int Id { get; set; }
        public string AppName { get; set; }
        public string ClassName { get; set; }
        public string Cron { get; set; }
        public string Params { get; set; }
        public int ClientId { get; set; }

        public SchItem()
        {
            Params = "";
        }
        public string GetParamValue(string key)
        {
            string ret = null;

            if (!string.IsNullOrEmpty(Params))
            {
                var temp = Params.Split("\r\n");
                foreach(var t in temp)
                {
                    var p = t.Split("=");
                    if (p.Length != 2)
                        throw new Exception("SchItem params in wrong format for Key " + key);
                    if (p[0].ToUpper() == key.ToUpper())
                        return p[1];
                }
            }
            return ret;
        }
        public void AddParam(string key, string value)
        {
            Params = Params + (Params.Length > 0 ? ";" : "") + key + ":" + value; 
        }
    }
}
