﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CRFS.IS.Service.Business.Models
{
    public class DatasetParameter
    {
        public int DatasetId { get; set; }
        public List<DBParameter> DBParameters { get; set; }
        public DatasetParameter() {
            DBParameters = new List<DBParameter>();
        }
    }
    public class DBParameter
    {
        public int ParameterId { get; set; }
        public string ParamDbName { get; set; }
        public string ParamReportName { get; set; }
        public string DataType { get; set; }
        public string ParamDirection { get; set; }
        public string ParamPivotDirection { get; set; }
        public string DefaultValue { get; set; }
        public bool IsNullable { get; set; }
        public int ForReportName { get; set; }
        public int MaxLen { get; set; }
        public string Value { get; set; }
    }
}
