﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using System.Reflection;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;

using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.Common;
using CRFS.IS.Service.Business.Jobs;
using CRFS.IS.Service.Business.Models;

namespace CRFS.IS.Service.Business
{
    public class JobProvider
    {
        private ILogger _logger;
        private AppSettings _appsetting;
        private LkpUsers _user;
        public JobProvider(ILogger logger, AppSettings appsetting, LkpUsers user)
        {
            _logger = logger;
            _appsetting = appsetting;
            _user = user;
        }
        public MessageReply RunJob(int id)
        {
            var ret = new MessageReply { Message = Constant.Success };

            try
            {
                using (var ctx = new PortalContext())
                {
                    var config = ctx.TblScheduledJob.Where(x => x.Id == id && x.Active).Select(x => new SchItem { 
                         Id = x.Id,
                         AppName = x.AppName,
                         ClassName = x.ClassName,
                         Params = x.Params,
                         Cron = x.Cron
                    }).Single();

                    ret.Message = new FHACatalystXMLJob(config, _logger, _appsetting).DoJob(_user.UserId, _user.UserName);
                }
            } 
            catch(Exception ex)
            {
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return ret;
        }
        public MessageReply RunJob(RunReportRequest req)
        {
            var ret = new MessageReply { Message = Constant.Success };
            try {
                using (var ctx = new PortalContext())
                {
                    var config = ctx.TblScheduledJob.Where(x => x.AppName == "ReportGeneration" && x.ClassName == req.ReportId.ToString() 
                                                                && (x.ClientId == null || x.ClientId == 0 || x.ClientId == req.ClientId))
                                 .Select(x => new SchItem { 
                                    Id = x.Id,
                                    AppName = x.AppName,
                                    ClassName = x.ClassName.GetSafeString(),
                                    Params = x.Params,
                                    Cron = x.Cron,
                                    ClientId = x.ClientId ?? 0
                                 }).Single();

                    ret.Message = new ReportGenerationJob(config, _logger, _appsetting).DoJob(req, _user.UserId, _user.UserName);
                }
            }
            catch(Exception ex)
            {
                _logger.LogError(ex, MethodBase.GetCurrentMethod().Name);
                ret.Message = ex.Message;
            }
            return ret;
        }
        public MessageReply SaveConfig(JobConfig config)
        {
            var ret = new MessageReply { Id = 0, Message = Constant.Success };

            try
            {
                using (var ctx = new PortalContext())
                {
                    if (config.Id > 0)
                    {
                        var jc = ctx.TblScheduledJob.Where(x => x.Id == config.Id).Single();
                        jc.ClassName = config.ClassName;
                        jc.Cron = config.Cron;
                        jc.Active = config.Active == 1;
                        jc.UpdatedBy = _user.UserId;
                        jc.UpdatedDate = DateTime.Now;
                        jc.Params = config.Params;
                        jc.ClientId = config.ClientId;
                        ctx.SaveChanges();
                    }
                    else
                    {
                        var temp = new TblScheduledJob
                        {
                            Id = 0,
                            AppName = config.AppName,
                            ClassName = config.ClassName,
                            Cron = config.Cron,
                            Params = config.Params,
                            Active = true,
                            ClientId = config.ClientId,
                            EnteredBy = _user.UserId,
                            EnteredDate = DateTime.Now,
                            UpdatedBy = _user.UserId,
                            UpdatedDate = DateTime.Now

                        };
                        ctx.TblScheduledJob.Add(temp);
                        ctx.SaveChanges();
                        ret.Id = temp.Id;
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public MessageReply SaveReportJobConfig(JobConfig config)
        {
            var ret = new MessageReply { Id = 0, Message = Constant.Success };

            try
            {
                using (var ctx = new PortalContext())
                {
                    if (ctx.TblScheduledJob.Any(x => x.AppName == "ReportGeneration" && x.ClassName == config.ClassName
                                                      && ((config.ClientId == 0 && x.ClientId == null) || x.ClientId == config.ClientId)))
                    {
                        var jc = ctx.TblScheduledJob.Where(x => x.AppName == "ReportGeneration" && x.ClassName == config.ClassName
                                                      && ((config.ClientId == 0 && x.ClientId == null)|| x.ClientId == config.ClientId)).Single();
                        jc.ClassName = config.ClassName;
                        jc.Cron = config.Cron;
                        jc.Active = config.Active == 1;
                        jc.UpdatedBy = _user.UserId;
                        jc.UpdatedDate = DateTime.Now;
                        jc.Params = config.Params;
                        jc.ClientId = config.ClientId;
                        ctx.SaveChanges();
                    }
                    else
                    {
                        var temp = new TblScheduledJob
                        {
                            Id = 0,
                            AppName = config.AppName,
                            ClassName = config.ClassName,
                            Cron = config.Cron,
                            Params = config.Params,
                            Active = true,
                            ClientId = config.ClientId,
                            EnteredBy = _user.UserId,
                            EnteredDate = DateTime.Now,
                            UpdatedBy = _user.UserId,
                            UpdatedDate = DateTime.Now

                        };
                        ctx.TblScheduledJob.Add(temp);
                        ctx.SaveChanges();
                        ret.Id = temp.Id;
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public JobConfig GetConfig(int id)
        {
            var ret = new JobConfig();

            try
            {
                using(var ctx = new PortalContext())
                {
                    if(id == 0)
                    {
                        ret = ctx.TblScheduledJob.Select(x => new JobConfig
                        {
                            Id = x.Id,
                            AppName = x.AppName,
                            ClassName = x.ClassName.GetSafeString(),
                            Cron = x.Cron,
                            Active = x.Active ? 1 : 0,
                            Params = x.Params.GetSafeString(),
                            ClientId = x.ClientId.GetValueOrDefault()
                        }).First();
                    }
                    if (id > 0)
                    {
                        ret = ctx.TblScheduledJob.Where(x => x.Id == id).Select(x => new JobConfig
                        {
                            Id = x.Id,
                            AppName = x.AppName,
                            ClassName = x.ClassName.GetSafeString(),
                            Cron = x.Cron,
                            Active = x.Active ? 1 : 0,
                            Params = x.Params.GetSafeString(),
                            ClientId = x.ClientId.GetValueOrDefault()
                        }).Single();
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public JobConfig GetConfig(GetReportJobConfigRequest req)
        {
            var ret = new JobConfig();

            try
            {
                using (var ctx = new PortalContext())
                {
                    ret = ctx.TblScheduledJob.Where(x => x.AppName == "ReportGeneration" && x.ClassName == req.ReportId.ToString()
                                                         && (req.ClientId == 0 || x.ClientId == req.ClientId))
                        .Select(x => new JobConfig
                        {
                            Id = x.Id,
                            AppName = x.AppName,
                            ClassName = x.ClassName.GetSafeString(),
                            Cron = x.Cron,
                            Active = x.Active ? 1 : 0,
                            Params = x.Params.GetSafeString(),
                            ClientId = x.ClientId.GetValueOrDefault()
                        }).Single();
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public GetJobHistoryReply GetHistory()
        {
            var ret = new GetJobHistoryReply();
            try
            {
                using(var ctx = new PortalContext())
                {
                    var temp = ctx.TblScheduledJobStatus.Include(x => x.Job).ToList().Select(x => new JobHistory
                    {
                        Id = x.Id,
                        AppName = x.Job.AppName,
                        Message = x.Message,
                        Status = x.Status,
                        TimeEnd = x.TimeEnd.GetSafeDateTimeString(),
                        TimeStart = x.TimeStart.GetSafeDateTimeString(),
                        RunBy = x.RunBy,
                        RunDate = x.TimeStart.GetSafeString(),
                        FilePath = x.FileFullPath.GetSafeString(),
                        JobParameters = x.JobParameters.GetSafeString()
                    }).OrderByDescending(x => x.Id).ToList();
                    ret.Hists.AddRange(temp);
                }
            }
            catch(Exception ex)
            {
                throw;
            }

            return ret;
        }
        public GetClaimGroupReply GetClaimGroup()
        {
            var ret = new GetClaimGroupReply();
            var clmgrps = new List<LkpFhalookups>();

            try
            {
                using(var hudctx = new HUDClaimsContext())
                {
                    clmgrps = hudctx.LkpFhalookups.Where(x => x.Lucategory == "FHAClaimGroup").ToList();
                }
                using (var ctx = new ApplicationConfigurationContext())
                {
                    var temp = ctx.LkpClaimGroup.ToList().Select(x => new ClaimGroup
                    {
                        Id = x.Id,
                        FHAClaimGroup = x.FhaclaimGroup ?? 0,
                        GroupName = clmgrps.Single(y => y.FhalookupId == x.FhaclaimGroup).Lutext,
                        SendToEmail = x.SendToEmail.GetSafeString(),
                        ErrorEmail = x.ErrorEmail.GetSafeString(),
                        Destination = x.Destination.GetSafeString(),
                        Code1 = x.Code1.GetSafeString(),
                        Code2 = x.Code2.GetSafeString(),
                        UIAct = ""
                    }).OrderBy(x => x.GroupName).ToList();
                    ret.ClaimGroups.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveClaimGroup(ClaimGroup cg)
        {
            var ret = new MessageReply { Id = 0, Message = Constant.Success };
            var appctx = new ApplicationConfigurationContext();
            var hudctx = new HUDClaimsContext();

            try
            {
                if (cg.Id > 0)
                {
                    var temp1 = appctx.LkpClaimGroup.Single(x => x.Id == cg.Id);
                    if (cg.UIAct == "Delete")
                    {
                       /* var lu = hudctx.LkpFhalookups.Single(x => x.FhalookupId == temp1.FhaclaimGroup);
                        hudctx.LkpFhalookups.Remove(lu);
                        hudctx.SaveChanges();*/

                        appctx.LkpClaimGroup.Remove(temp1);
                    }
                    else
                    {
                        temp1.FhaclaimGroup = cg.FHAClaimGroup;
                        temp1.SendToEmail = cg.SendToEmail;
                        temp1.ErrorEmail = cg.ErrorEmail;
                        temp1.Destination = cg.Destination;
                        temp1.Code1 = cg.Code1;
                        temp1.Code2 = cg.Code2;
                        temp1.DateUpdated = DateTime.Now;
                        temp1.UpdatedBy = _user.UserId;
                    }
                    appctx.SaveChanges();

                   /* var temp2 = hudctx.LkpFhalookups.Single(x => x.FhalookupId == cg.FHAClaimGroup);
                    temp2.Lutext = cg.GroupName;
                    hudctx.SaveChanges();*/
                }
                else
                {
                    var temp = cg.FHAClaimGroup;
                    if(temp == 0)
                    {
                        var temp1 = new LkpFhalookups {
                            FhalookupId = 0,
                            Lucategory = "FHAClaimGroup",
                            Lutext = cg.GroupName,
                            Active = true,
                            DisplayCode1 = "",
                            DisplayCode2 = "",
                            EffectiveFromDate = DateTime.Now,
                            EffectiveToDate = Convert.ToDateTime("12/31/2078")
                        };
                        hudctx.LkpFhalookups.Add(temp1);
                        hudctx.SaveChanges();

                        temp = (int)temp1.FhalookupId;
                    }
                    var fhacg = hudctx.LkpFhalookups.Where(x => x.Lucategory == "FHAClaimGroup").ToList();

                    var temp2 = new LkpClaimGroup
                    {
                        Id = 0,
                        FhaclaimGroup = temp,
                        GroupName = fhacg.Single(x => x.FhalookupId == temp).Lutext,
                        SendToEmail = cg.SendToEmail,
                        ErrorEmail = cg.ErrorEmail,
                        Destination = cg.Destination,
                        Code1 = cg.Code1,
                        Code2 = cg.Code2,
                        CreatedBy = _user.UserId,
                        DateCreated = DateTime.Now,
                        UpdatedBy = _user.UserId,
                        DateUpdated = DateTime.Now 
                    };
                    appctx.LkpClaimGroup.Add(temp2);
                    appctx.SaveChanges();
                    ret.Id = temp2.Id;
                }
                
            }
            catch
            {
                throw;
            }
            finally
            {
                appctx.Dispose();
                hudctx.Dispose();
            }
            return ret;
        }
        public GetXMLExtClaimTypeReply GetXMLExtClaimType()
        {
            var ret = new GetXMLExtClaimTypeReply();
            try
            {
                using (var ctx = new ApplicationConfigurationContext())
                {
                    var temp = ctx.XmlExtractionClaimTypeConfig.Select(x => new XMLExtClaimType
                    {
                        Id = x.XmlextractionId,
                        Active = x.Active ? 1 : 0,
                        FHAClaimGroup = x.FhaclaimGroup,
                        FHALookUpId = x.FhalookUpId,
                        ClaimType = x.ClaimType,
                        SubmitPart = x.SubmitPart.GetSafeString()
                    }).ToList();
                    ret.XMLExtClaimTypes.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return ret;
        }
        public MessageReply SaveXMLExtClaimType(XMLExtClaimType xct)
        {
            var ret = new MessageReply { Id = 0, Message = Constant.Success };

            try
            {
                using (var ctx = new ApplicationConfigurationContext())
                {
                    if (xct.Id > 0)
                    {
                        var temp = ctx.XmlExtractionClaimTypeConfig.Single(x => x.XmlextractionId == xct.Id);
                        temp.FhaclaimGroup = xct.FHAClaimGroup;
                        temp.Active = xct.Active == 1;
                        temp.ClaimType = xct.ClaimType;
                        temp.DateUpdated = DateTime.Now;
                        temp.FhalookUpId = xct.FHALookUpId;
                        temp.SubmitPart = xct.SubmitPart;
                        temp.UpdatedBy = _user.UserId;
                        
                        ctx.SaveChanges();
                    }
                    else
                    {
                        var temp = new XmlExtractionClaimTypeConfig
                        {
                           XmlextractionId = 0,
                           Active = true,
                           AddedBy = _user.UserId,
                           DateAdded = DateTime.Now,
                           DateUpdated = DateTime.Now,
                           UpdatedBy = _user.UserId,
                           ClaimType = xct.ClaimType,
                           FhaclaimGroup = xct.FHAClaimGroup,
                           FhalookUpId = xct.FHALookUpId,
                           SubmitPart = xct.SubmitPart
                        };
                        ctx.XmlExtractionClaimTypeConfig.Add(temp);
                        ctx.SaveChanges();
                        ret.Id = temp.XmlextractionId;
                    }
                }
            }
            catch
            {
                throw;
            }
            return ret;
        }
        public GetCatalystClaimsReply GetCatalystClaims()
        {
            var ret = new GetCatalystClaimsReply();
          /*  HUDClaimsContext hudctx = null;
            ClaimsManagementContext cmsctx = null;
            try
            {
                hudctx = new HUDClaimsContext();
                cmsctx = new ClaimsManagementContext();

                using (var ctx = new PortalContext())
                {
                    var fromdate = DateTime.Now.AddDays(-3);

                    var clms = (from a in ctx.TblJobItemDetail
                                join b in ctx.TblScheduledJobStatus on a.ScheduledJobId equals b.Id
                                where b.TimeStart > fromdate
                                select new
                                {
                                    ClaimId = a.KeyValue,
                                    TimeStart = b.TimeStart
                                }).ToList();
                    var t1 = (from a in hudctx.TblFhaclaims
                                         join floan in hudctx.TblFhaloans on a.FhaloanId equals floan.FhaloanId
                                         join l in hudctx.VwInvTrkLoan on floan.InvTrkLoanId equals l.Id
                                         where a.FhaclaimId == edi.FhaclaimId
                                         select new
                                         {
                                             ClaimTypeId = a.ClaimTypeId,
                                             ClaimSubTypeId = a.FhaclaimSubTypeId,
                                             LoanNum = l.LoanNumber,
                                             InvTrkClaimId = a.InvTrkClaimId,
                                             ClientId = floan.FhaclientId
                                         }).Single();
                    ret.CatalystClaims.AddRange(temp);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                if (hudctx != null)
                    hudctx.Dispose();
                if (cmsctx != null)
                    cmsctx.Dispose();
            }
            */
            return ret;
        }
    }
}