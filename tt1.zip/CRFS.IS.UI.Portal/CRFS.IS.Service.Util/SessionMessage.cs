﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using CRFS.IS.Service.Data;
using CRFS.IS.Service.Common;

namespace CRFS.IS.Service.Util
{
    public static class SessionMessage
    {
        public static void Write(string msg, string token, string type)
        {
            if (string.IsNullOrEmpty(token)) return;

            using (var ctx = new PortalContext())
            {
                var detail = ctx.TblSession.Where(x => x.Token == token)
                             .Select(x => x.TblSessionDetail.Where(y => y.SvcName == type)).SingleOrDefault();

                var dd = detail.OrderByDescending(x => x.EnteredDate).First();

                ctx.TblSessionMessage.Add(new TblSessionMessage
                {
                    Msg = msg,
                    SessionDetailId = dd.Id,
                    EnteredDate = DateTime.Now
                });

                ctx.SaveChanges();
            }
        }
        public static void Write(string msg)
        {
            using (var ctx = new PortalContext())
            {
                var did = ctx.TblSessionDetail.Select(x => x.Id).OrderBy(x => x).First();

                ctx.TblSessionMessage.Add(new TblSessionMessage
                {
                    Msg = msg.Length > Constant.ERRORMSGLEN ? msg.Substring(0, Constant.ERRORMSGLEN - 1) : msg,
                    SessionDetailId = did,
                    EnteredDate = DateTime.Now
                });

                ctx.SaveChanges();
            }
        }
        public static Dictionary<string, string>Get(string token, string svcname, int id = 0)
        {
            var ret = new Dictionary<string, string>();
            if (string.IsNullOrEmpty(token))
                return ret;

            using (var ctx = new PortalContext())
            {
                var detail = ctx.TblSession.Where(x => x.Token == token)
                            .Select(x => x.TblSessionDetail.Where(y => y.SvcName == svcname)).SingleOrDefault();

                var dd = detail.OrderByDescending(x => x.EnteredDate).First();

                var list = ctx.TblSessionMessage.Where(x => x.Id > id && x.SessionDetailId == dd.Id)
                    .OrderBy(x => x.Id).ToList();
               // var d = l.ToDictionary<int, string>(x => x.Id, x => x.Msg);
               foreach(var l in list)
                {
                    ret.Add(l.Id.ToString(), l.Msg);
                }
            }
            return ret;
        }
    }
}
