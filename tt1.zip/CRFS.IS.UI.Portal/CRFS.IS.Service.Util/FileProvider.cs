﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.Data;

namespace CRFS.IS.Service.Util
{
    public static class FileProvider
    {
        public static Task<int> UploadFile(MemoryStream ms, string appname, string filename, string uname, string fpath)
        {
            var ret = 0;
            ms.Seek(0, SeekOrigin.Begin);
            try
            {
                using (var fs = File.Create(fpath))
                {
                    ms.CopyTo(fs);
                    using(var ctx = new PortalContext())
                    {
                        var ul = new TblFileUpload
                        {
                            Id = 0,
                            AppName = appname,
                            FileName = filename,
                            ServerPath = fpath,
                            Size = ms.Length,
                            UploadDate = DateTime.Now,
                            UploadedBy = uname
                        };
                        ctx.TblFileUpload.Add(ul);
                        ctx.SaveChanges();
                        ret = ul.Id;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return Task.FromResult(ret);
        }
    }
}
