﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Data;

using BT.Service.TransferObject.Main;
using BT.Service.Data.Extensions;

namespace BT.Service.Data.Base
{
   
    public static class DBConverter 
    {
        public static T DB2Entity<T>(IDataRecord record) where T : class, new()
        {
            T ret = new T();
            bool found = true;
            var props = typeof(T).GetProperties(BindingFlags.DeclaredOnly | BindingFlags.Public | BindingFlags.Instance);

            foreach (var p in props)
            {
                found = false;
                for(var i = 0; i < record.FieldCount; i++)
                {
                    if(record.GetName(i) == p.Name)
                    {
                        var dataval = record.GetValue(i);
                        p.SetValue(ret, EntityAttrHelper.GetValue(dataval, p.PropertyType));
                        found = true;
                        break;
                    }
                }
                if (!found)
                    p.SetValue(ret, EntityAttrHelper.GetDefaultValue(p.PropertyType));
            }
           
            return ret;
        }

        public static List<EleRowDTO> DB2Ele(IDataRecord record, int rowid)
        {
            var ret = new List<EleRowDTO>();

            for (var i = 0; i < record.FieldCount; i++)
            {
               var dataval = record.GetValue(i);
                ret.Add(new EleRowDTO
                {
                    DataType = record.GetFieldType(i).Name,
                    DataValue = EntityAttrHelper.SetValue(record.GetValue(i)),
                    DBName = record.GetName(i),
                    DefValue = "",
                    IsKey = false,
                    Nullable = false,
                    UIName = "",
                    RowId = rowid.ToString()
                });
            }

            return ret;
        }

       
    }
}
