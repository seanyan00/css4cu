﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.SqlClient;

using BT.Service.Data.Base;
using BT.Service.Data.Extensions;
using BT.Service.Data.Models;
using BT.Service.TransferObject.Main;
using BT.Service.TransferObject.ClientAdmin;

namespace BT.Service.Data.DAOs
{
    public class MSSqlDAO : DbAccess
    {
        public static readonly Dictionary<string, string> MSSqlTypeMap = new Dictionary<string, string>
        {
            {"bigint", "System.Int64" },
            {"binary", "System.Byte[]" },
            { "bit", "System.Boolean"},
            {"char", "System.String" },
            { "date", "System.DateTime"},
            {"datetime", "System.DateTime" },
            {"datatime2", "System.DateTime" },
            {"datetimeoffset", "System.DateTimeOffset" },
            {"decimal", "System.Decimal" },
            {"float", "System.Double" },
            {"geography", "System.Byte[]" },
            {"geometry", "System.Byte[]" },
            {"hierarchyid", "System.Int32" },
            {"image", "System.Byte[]" },
            {"int", "System.Int32" },
            {"money", "System.Decimal" },
            {"nchar", "System.String" },
            {"ntext", "System.String" },
            {"numeric", "System.Decimal" },
            {"nvarchar", "System.String" },
            {"real", "System.Single" },
            {"smalldatetime", "System.DateTime" },
            {"smallint", "System.Int16" },
            {"smallmoney", "System.Decimal" },
            {"sql_variant", "System.String" },
            {"text", "System.String" },
            {"time", "System.TimeSpan" },
            {"timestamp", "System.DateTime" },
            {"tinyint", "System.Byte" },
            {"uniqueidentifier", "System.String" },//System.Guid
            {"varbinary", "System.Byte[]" },
            {"varchar", "System.String" },
            {"xml", "System.Xml" },
        };

        private SqlConnection _conn;
        private SqlTransaction _tran;
        public BTClientUserDTO UDTO;
        
        public List<SqlParameter> Params { get; set; }

        public MSSqlDAO() 
        {
            
        }

        public MSSqlDAO(BTClientUserDTO udto, string connstr) : base(connstr)
        {
            UDTO = udto;
        }

        protected override void Init()
        {
            Params = new List<SqlParameter>();

            try
            {
                _tran = null;
                _conn = DBOpen();
            }
            catch
            {
                throw; // throw new TypeInitializationException()
            }
        }

        protected override void Dispose(bool disposing)
        {

            if (disposing)
            {
                if (!_disposed)
                {
                    // let Oracle.DataAccess takes care of Finalizer
                    _conn.Dispose();
                    _disposed = true;
                }
            }
        }

        private SqlConnection DBOpen()
        {
            SqlConnection conn = new SqlConnection(_connstr);
            
            conn.Open();
            return conn;
        }

        public string GetValue(string sql)
        {
            string ret = null;
            SqlCommand cmd = new SqlCommand(sql, _conn);
            if (Params.Count > 0)
                cmd.Parameters.AddRange(Params.ToArray());
            ret = cmd.ExecuteScalar().ToString();

            if (Params.Count > 0)
                Params.Clear();

            return ret;
        }

        public override List<string> GetStringList(string sql)
        {
            List<string> ret = new List<string>();
            SqlCommand cmd = new SqlCommand(sql, _conn);
            if (Params.Count > 0)
                cmd.Parameters.AddRange(Params.ToArray());
            SqlDataReader r = cmd.ExecuteReader();
            while (r.Read())
            {
                ret.Add(r[0].ToString());
            }

            if (Params.Count > 0)
                Params.Clear();
            return ret;
        }
        public List<RowDataValue> GetKeyValueList(string sql)
        {
            var ret = new List<RowDataValue>();
            SqlCommand cmd = new SqlCommand(sql, _conn);
            if (Params.Count > 0)
                cmd.Parameters.AddRange(Params.ToArray());
            SqlDataReader r = cmd.ExecuteReader();
            var ridx = 0;
            while (r.Read())
            {
                for(int i = 0; i < r.FieldCount; i++)
                {
                    ret.Add(new RowDataValue
                    {
                        RowIdx = ridx,
                        ColIdx = i,
                        ColName = r.GetName(i),
                        ColValue = r[i].ToString(),
                        ColType = r.GetFieldType(i).FullName
                    });
                }
                ++ridx;
            }

            if (Params.Count > 0)
                Params.Clear();
            return ret;
        }
        public string AddParamList(string sql, List<ReportQueryParamDTO> ll)
        {
            var ret = new StringBuilder();

            if (!(Params.Count > 0))
                return sql;

            var regfrom = @"( where |order by|group by|;$)";
            var regwhere = @"(order by|group by|;$)";
            var sel = sql.Substring(0, sql.ToLower().IndexOf("from "));
            var remain = sql.Substring(sql.ToLower().IndexOf("from ")).ToLower();

            var m1 = Regex.Match(remain, regfrom);
            var from = remain.Substring(0, m1.Index);
            remain = remain.Substring(from.Length);

            string w = "";
            var m2 = Regex.Match(remain, regwhere);
            if (remain.IndexOf("where ") >= 0)
            {
                w = remain.Substring("where ".Length, m2.Index);
                remain = remain.Substring(w.Length);
            }
            var alias = new Dictionary<string, string>();

            //Caution: only table is used on forming column's name, possible bug
            var tbls = from.Substring(from.IndexOf("from ") + "from ".Length).Split(new string[] { " join " }, StringSplitOptions.None);
            foreach (var t in tbls)
            {
                var temp = t.Trim();
                if (temp.IndexOf(" on ") > 0)
                {
                    temp = temp.Substring(0, t.IndexOf(" on "));
                }

                var tarr = temp.Split(new char[] { ' ' });
                alias.Add(tarr[0], tarr[tarr.Length - 1]);
            }
            var sb = new StringBuilder(w);

            var idx = 0;
            bool first = w.Length < 5;
            foreach (var l in ll)
            {
                sb.Append((first ? " " : " and ") + BuildOp(l.op, GetAlias(l.nm, alias), ++idx));
                first = false;
            }

            ret.Append(sel + " " + from + " where " + sb.ToString() + " " + remain);
            return ret.ToString();
        }
        private string GetAlias(string pname, Dictionary<string, string> alias)
        {
            var ret = pname;
            var tn = pname.Split(new char[] { '.' })[0];
            
            foreach(var a in alias)
            {
                var tn1 = a.Key.Split(new char[] { '.' })[1];
                if(tn.ToLower() == tn1.ToLower())
                {
                    ret = a.Value + "." + pname.Split(new char[] { '.' })[1];
                    break;
                }
            }
            return ret;
        }
        public override List<int> GetIntList(string sql)
        {
            List<int> ret = new List<int>();
            SqlCommand cmd = new SqlCommand(sql, _conn);
            if (Params.Count > 0)
                cmd.Parameters.AddRange(Params.ToArray());
            SqlDataReader r = cmd.ExecuteReader();
            while (r.Read())
            {
                ret.Add(r.GetInt32(0));
            }

            if (Params.Count > 0)
                Params.Clear();
            return ret;

        }
        public override List<T> GetEntityList<T>(string sql)
        {
            List<T> lsli = new List<T>();

            if (_conn.State != ConnectionState.Open)
                _conn.Open();
            SqlCommand cmd = new SqlCommand(sql, _conn);
            cmd.CommandTimeout = CMDTIMEOUT;
            if (Params.Count > 0)
                cmd.Parameters.AddRange(Params.ToArray());

            SqlDataReader r = cmd.ExecuteReader();
            while (r.Read())
            {
                lsli.Add(DBConverter.DB2Entity<T>(r));
            }
            if (Params.Count > 0)
                Params.Clear();


            return lsli;
        }
        public SqlDataReader GetReader(string sql)
        {
            return (SqlDataReader)GetDataReader(sql);
        }
        public override object GetDataReader(string sql)
        {
            SqlCommand cmd = new SqlCommand(sql, _conn);
            if (_tran != null)
                cmd.Transaction = _tran;

            if (Params.Count > 0)
                cmd.Parameters.AddRange(Params.ToArray());
            SqlDataReader r = cmd.ExecuteReader();
            if (Params.Count > 0)
                Params.Clear();
            return r;
        }
        public override int SaveDataSet(ElementDataDTO edd)
        {
            var ret = 0;
            if (edd.DataElements.Length > 0)
            {

                var tbl = GetClientTable(edd.TableName);

                switch (edd.Action)
                {
                    case "Merge":
                        Merge(edd, tbl);
                        break;
                    case "Delete":
                        Delete(edd, tbl);
                        break;
                    case "Create":
                        Create(edd, tbl);
                        break;
                    case "Update":
                        Update(edd, tbl);
                        break;
                    default:
                        throw new Exception("Unknown Action");
                }
            }
            return ret;
        }
        public void LoadData(ElementDataDTO edd)
        {
            var tbl = GetClientTable(edd.TableName);
            var rowids = edd.DataElements.Select(x => x.RowId).Distinct().ToList();
          
            foreach (var rid in rowids)
            {
                var clist = new StringBuilder();
                var vlist = new StringBuilder();
                bool first = true;
                clist.Append("insert into " + edd.TableName + "(");
                vlist.Append(" values(");

                foreach (var c in tbl.Cols)
                {
                    if (c.IsIdentity)
                        continue;

                    var rowdata = edd.DataElements.Where(x => x.RowId == rid).ToList();

                    for (int i = 0; i < rowdata.Count; i++)
                    {
                        var ele = rowdata[i];
                        if (ele.DBName.ToLower() == c.Name.ToLower())
                        {
                            clist.Append((first ? "" : ",") + c.Name);
                            var v = ExcelDateTimeFromNumber(ele.DataValue, c.DataType);
                            vlist.Append((first ? "" : ",") + DecoString(v, c.DataType));
                            first = false;
                        }
                    }
                }
                clist.Append(")");
                vlist.Append(");");
       
                RunSql(clist.ToString() + vlist.ToString());
            }
        }
        public void Delete(ElementDataDTO edd, Models.ClientTable st)
        {
            var sql = new StringBuilder();
            var where = "";
            sql.Append("delete from " + st.Name);
            where = BuildWhereClauseDel(edd.DataElements);
            if (string.IsNullOrEmpty(where))
                return;
            sql.Append(where);
            sql.Append(";");

            RunSql(sql.ToString());
        }
        public void Merge(ElementDataDTO edd, Models.ClientTable st)
        {
            if (Update(edd, st) == 0)
                Create(edd, st);
        }
        public int Update(ElementDataDTO edd, ClientTable st)
        {
            var setlist = new StringBuilder();

            bool first = true;
            setlist.Append("update " + st.Name + " set ");

            foreach (var ele in edd.DataElements.ToList())
            {
                if (!ele.IsKey && !ele.ReserveOriginal)
                {
                    setlist.Append((first ? "" : ",") + ele.DBName + "=" + DecoString(ele.DataValue, ele.DataType));

                    first = false;
                }
            }
           
            var where = BuildWhereClause(edd.DataElements);
            if (string.IsNullOrEmpty(where))
                return 0;
            setlist.Append(where);
            setlist.Append(";");

            return RunSql(setlist.ToString());
        }
        public int Create(ElementDataDTO edd, Models.ClientTable st)
        {
            var clist = new StringBuilder();
            var vlist = new StringBuilder();
            bool first = true;
            clist.Append("insert into " + st.Name + "(");
            vlist.Append(" values(");

            foreach (var c in st.Cols)
            {
                if (c.IsIdentity)
                    continue;

                for (int i = 0; i < edd.DataElements.Length; i++)
                {
                    var ele = edd.DataElements[i];
                    if (ele.DBName == c.Name)
                    {
                        clist.Append((first ? "" : ",") + c.Name);
                        vlist.Append((first ? "" : ",") + DecoString(ele.DataValue, ele.DataType));
                        first = false;
                    }
                }
            }
            clist.Append(")");
            vlist.Append(");");
            RunSql(clist.ToString() + vlist.ToString());

            var sql = "select isnull(@@identity, 0);";

            if (st.Cols.Any(x => x.IsKey && x.Name == "id"))
                return Convert.ToInt32(GetValue(sql));
            else
                return 0;
        }
        private string DecoString(string v, string t)
        {
            if (t == "System.String" || t == "System.DateTime" || t == "System.Date")
                return "'" + v + "'";
            else
                return v;
        }
        private string ExcelDateTimeFromNumber(string value, string t)
        {
            if (t == "System.DateTime" || t == "System.Date")
            {
                double d = 0.0;
                var result = double.TryParse(value, out d);
                if (result && d >= 1 && d <= 60000)
                    return DateTime.FromOADate(d).ToString();
            }
            
            return value;
        }
        public override void BeginTran()
        {
            _tran = _conn.BeginTransaction();
        }
        public override void Commit()
        {
            _tran.Commit();
            _tran = null;
        }
        public override void Rollback()
        {
            _tran.Rollback();
            _tran = null;
        }
        public override int RunSql(string sql)
        {
            int ret = 0;

            SqlCommand cmd = new SqlCommand(sql, _conn);
            if (_tran != null)
                cmd.Transaction = _tran;

            if (Params.Count > 0)
                cmd.Parameters.AddRange(Params.ToArray());
            ret = cmd.ExecuteNonQuery();
            if (Params.Count > 0)
                Params.Clear();

            return ret;
        }

        public override string BuildSql(ElementRequestDTO erd)
        {
            var ret = new StringBuilder();
            if (erd.NameType == "table")
            {
                var st = GetClientTable(erd.Name);
                ret.Append(BuildSelectList(st));
                ret.Append(BuildWhereClauseSelect(erd, st));
                ret.Append(BuildOrderBy(erd));
            }

            return ret.ToString();
        }
        public string BuildWhereClause(EleRowDTO[] rows, bool key = true)
        {
            var where = new StringBuilder();
            var first = true;

            Params.Clear();
            if (rows.Length > 0 && rows.Any(x => (!key || (key && x.IsKey))))
            {
                where.Append(" where ");

                foreach (var r in rows.ToList())
                {
                    if (!key || (key && r.IsKey))
                    {
                        where.Append((first ? "" : " and ") + r.DBName + "=@p_" + r.DBName);
                        first = false;
                        Type t = Type.GetType(r.DataType);
                        Params.Add(new SqlParameter("@p_" + r.DBName, EntityAttrHelper.GetValue(r.DataValue, t)));
                    }
                }
            }
            return where.ToString();
        }
        public string BuildWhereClauseDel(EleRowDTO[] rows)
        {
            var where = new StringBuilder();
            var first = true;

            Params.Clear();
            if (rows.Length > 0)
            {
                where.Append(" where ");

                foreach (var r in rows.ToList())
                {
                    where.Append((first ? "" : " and ") + r.DBName + "=@p_" + r.DBName);
                    first = false;
                    Type t = Type.GetType(r.DataType);
                    Params.Add(new SqlParameter("@p_" + r.DBName, EntityAttrHelper.GetValue(r.DataValue, t)));
                }
            }
            else
                throw new ArgumentNullException();

            return where.ToString();
        }
        private string BuildWhereClauseSelect(ElementRequestDTO erd, Models.ClientTable st)
        {
            var ret = new StringBuilder();
            var first = true;

            Params.Clear();

            if (erd.Filters.Count > 0)
            {
                ret.Append(" where ");

                foreach (var f in erd.Filters)
                {
                    ret.Append((first ? "" : " and ") + BuildOp(f.Oper, f.ColName));
                    Type t = Type.GetType(st.Cols.Where(x => x.Name == f.ColName).Select(x => x.DataType).Single());
                    Params.Add(new SqlParameter("@p_" + f.ColName, EntityAttrHelper.GetValue(f.Value, t)));

                    first = false;
                }
            }

            return ret.ToString();
        }
        private string BuildOp(string op, string colnm)
        {
            var ret = "";

            switch (op)
            {
                case "eq":
                    ret = colnm + "=@p_" + colnm;
                    break;
                case "eqn":
                    ret = "(" + colnm + " is null or " + colnm + "=@p_" + colnm + ")";
                    break;
                case "ne":
                    ret = colnm + "!=@p_" + colnm;
                    break;
                case "cn":
                    ret = colnm + " like '%@p_" + colnm + "%'";
                    break;
                case "nc":
                    ret = colnm + " not like '%@p_" + colnm + "%'";
                    break;
                case "gt":
                    ret = colnm + " >@p_" + colnm;
                    break;
                case "lt":
                    ret = colnm + " <@p_" + colnm;
                    break;
                case "ge":
                    ret = colnm + " >=@p_" + colnm;
                    break;
                case "le":
                    ret = colnm + " <=@p_" + colnm;
                    break;
                default:
                    break;
            }

            return ret;
        }
        private string BuildOp(string op, string colnm, int idx)
        {
            var ret = "";

            switch (op)
            {
                case "eq":
                    ret = colnm + "=@p_" + idx;
                    break;
                case "eqn":
                    ret = "(" + colnm + " is null or " + colnm + "=@p_" + idx + ")";
                    break;
                case "nen":
                    ret = "(" + colnm + " is null or " + colnm + "!=@p_" + idx + ")";
                    break;
                case "ne":
                    ret = colnm + "!=@p_" + idx;
                    break;
                case "cn":
                    ret = colnm + " like '%@p_" + idx + "%'";
                    break;
                case "nc":
                    ret = colnm + " not like '%@p_" + idx + "%'";
                    break;
                case "gt":
                    ret = colnm + " >@p_" + idx;
                    break;
                case "lt":
                    ret = colnm + " <@p_" + idx;
                    break;
                case "ge":
                    ret = colnm + " >=@p_" + idx;
                    break;
                case "le":
                    ret = colnm + " <=@p_" + idx;
                    break;
                default:
                    break;
            }

            return ret;
        }
        private string BuildSelectList(Models.ClientTable st)
        {
            var ret = new StringBuilder();
            var first = true;

            ret.Append("select ");
            foreach (var c in st.Cols)
            {
                ret.Append((first ? "" : ",") + c.Name);
                first = false;
            }

            return ret.ToString();
        }
        private string BuildOrderBy(ElementRequestDTO erd)
        {
            var ret = new StringBuilder();
            var first = true;

            if (erd.Sorts.Count > 0)
            {
                ret.Append(" order by ");
                foreach (var s in erd.Sorts)
                {
                    ret.Append((first ? "" : ",") + s.ColName);
                    if (!s.Asc)
                        ret.Append(" desc");
                    first = false;
                }
            }

            return ret.ToString();
        }
        public void BuildParameter(List<Parameter> lpdto)
        {
            Params.Clear();

            var ret = new List<SqlParameter>();

            foreach (var p in lpdto)
            {
                Type t = Type.GetType(p.DataType);

                ret.Add(new SqlParameter(p.Name, EntityAttrHelper.GetValue(p.Value, t)));
            }
            Params.AddRange(ret);
        }
       
        public override void TestDBConfig()
        {
            return;
        }
        public override int InsertDataReturnId(string sql)
        {
            throw new NotImplementedException();
        }
        public override Models.SiteTable GetSiteTable(string tname)
        {
            throw new NotImplementedException();
        }
        public ClientTable GetClientTable(string tname)
        {
            var tbls = GetAllTableWithCols();
            return tbls.Where(x => x.Name == tname).Select(x => x).Single();
        }
       /* public List<AssignedTableDTO> GetTables(int dbcid, string schema = "")
        {
            var ret = new List<AssignedTableDTO>();
            var cmd = new SqlCommand("select table_schema + '.' + table_name nm, 0 id," + dbcid + " dbcid from information_schema.tables order by 1;", _conn);
            var dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                ret.Add(new AssignedTableDTO {
                    nm = dr.GetString(0),
                    id = dr.GetInt32(1),
                    dbcid = dr.GetInt32(2)
                });
            }
            dr.Close();

            return ret;
        }*/
        public List<AssignedTableDTO> GetTables(int dbcid, string schema = "")
        {
            var ret = new List<AssignedTableDTO>();
            var sql = "select a.object_id id, b.name + '.' + a.name nm, trim(a.type) typ," + dbcid.ToString() + " dbcid"
                    + " from sys.objects a join sys.schemas b on a.schema_id = b.schema_id where trim(a.type) in ('U', 'V', 'IF', 'SN', 'TF') order by 2;";
            var cmd = new SqlCommand(sql, _conn);
            if (_tran != null)
                cmd.Transaction = _tran;

            var dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                ret.Add(new AssignedTableDTO
                {
                    id = dr.GetInt32(0),
                    nm = dr.GetString(1),
                    typ = dr.GetString(2),
                    dbcid = dr.GetInt32(3)
                });
            }
            dr.Close();

            return ret;
        }
        public List<Models.TablePK> GetPK(string tname)
        {
            var ret = new List<Models.TablePK>();

            var sql = "select s.name + '.' + t.name as TableName, tc.name as ColumnName, ic.key_ordinal as Idx"
                    + " from sys.schemas s inner join sys.tables t on s.schema_id = t.schema_id " 
                    + "                    inner join sys.indexes i  on t.object_id = i.object_id"
                    + "                    inner join sys.index_columns ic on i.object_id = ic.object_id and i.index_id = ic.index_id"
                    + "                    inner join sys.columns tc on ic.object_id = tc.object_id and ic.column_id = tc.column_id"
                    + " where i.is_primary_key = 1 and s.order by 1,2,4;";
            using (var dao = new SqliteDAO())
            {
                ret.AddRange(dao.GetEntityList<Models.TablePK>(sql));
            }
            return ret;
        }
        public override ElementDataDTO GetTargetTableData(string tname)
        {
            throw new NotImplementedException();
        }
        public List<ClientTable> GetAllTableWithCols()
        {
            Params.Clear();

            var ret = new List<ClientTable>();

            var sql = "select c.name + '.' + a.name tblnm, trim(a.type) ttype, b.column_id, b.name colnm,"
                    + " b.max_length, d.name datatype, b.is_nullable, isnull(e.column_id, 0) pk, isnull(f.COLUMN_DEFAULT, '') defval,"
                    + " isnull(g.fkcol, '') fkcol, b.is_identity iden, a.object_id "
                    + " from sys.objects a join sys.columns b on a.object_id = b.object_id"
                    + "                  join sys.schemas c on a.schema_id = c.schema_id"
                    + "                    join sys.types d on b.system_type_id = d.system_type_id and d.is_user_defined = 0"
                    + "                                   and d.user_type_id = (select min(user_type_id) from sys.types where system_type_id = b.system_type_id)"
                    + "               left join(select ib.object_id, ia.column_id"
                    + "                            from sys.index_columns ia join sys.indexes ib on ia.object_id = ib.object_id and ia.index_id = ib.index_id"
                    + "                           where ib.is_primary_key = 1) e on b.object_id = e.object_id and b.column_id = e.column_id"
                    + "                left join INFORMATION_SCHEMA.COLUMNS f on c.name = f.TABLE_SCHEMA and a.name = f.TABLE_NAME and b.name = f.COLUMN_NAME"
                    + "                left join(select i1c.object_id tblid, i1d.column_id, i1g.name +'.' + i1e.name + '.' + i1f.name fkcol"
                    + "                            from sys.foreign_keys i1a join sys.foreign_key_columns i1b on i1a.object_id = i1b.constraint_object_id"
                    + "                                                       join sys.tables i1c on i1b.parent_object_id = i1c.object_id"
                    + "                                                       join sys.columns i1d on i1b.parent_object_id = i1d.object_id"
                    + "                                                                            and i1b.parent_column_id = i1d.column_id"
                    + "                                                       join sys.tables i1e on i1b.referenced_object_id = i1e.object_id"
                    + "                                                       join sys.columns i1f on i1b.referenced_object_id = i1f.object_id"
                    + "                                                                           and i1b.referenced_column_id = i1f.column_id"
                    + "                                                       join sys.schemas i1g on i1e.schema_id = i1g.schema_id) g"
                    + "                          on b.object_id = g.tblid and b.column_id = g.column_id"
                    + " where a.type in ('U', 'V', 'SN', 'IF', 'TF')"
                    + " order by 1, 8, 3; ";

            var rd = GetReader(sql);
            while (rd.Read())
            {
                if(!ret.Any(x => x.Name == rd.GetString(0)))
                {
                    ret.Add(new ClientTable
                    {
                        Name = rd.GetString(0),
                        TType = rd.GetString(1),
                        ObjId = rd.GetInt32(11)
                    });
                }
                var cols = ret.Where(x => x.Name == rd.GetString(0)).Select(x => x.Cols).Single();
                var temp = new Models.ClientTableColumn();
                temp.ColId = rd.GetInt32(2);
                temp.Name = rd.GetString(3);
                temp.MaxLength = rd.GetInt16(4);
                temp.DataType = MSSqlTypeMap[rd.GetString(5)];
                temp.IsNullable = rd.GetBoolean(6);
                temp.IsKey = Convert.ToInt32(rd[7]) == 1;
                temp.DefaultValue = rd.GetString(8);
                temp.FK = rd.GetString(9);
                temp.IsIdentity = rd.GetBoolean(10);
                cols.Add(temp);
            }
            rd.Close();

            return ret;
        }
    }
}
