﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SQLite;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;

using BT.Service.Data.Base;
using BT.Service.Data.Extensions;
using BT.Service.Data.Models;
using BT.Service.TransferObject.Main;
using BT.Service.TransferObject.ClientAdmin;

namespace BT.Service.Data.DAOs
{
    public class SqliteDAO : Base.DbAccess
    {
        public static readonly Dictionary<string, string> SqliteTypeMap = new Dictionary<string, string>
        {
            { "integer", "System.Int32"},
            { "int", "System.Int32"},
            {"text", "System.String" },
            {"datetime", "System.DateTime" },
            {"integer parimary key", "System.Int32" }
        };
        private SQLiteConnection _conn;
        private SQLiteTransaction _tran;
        private BTClientUserDTO _udto;

        public List<SQLiteParameter> Params { get; set; }

        public SqliteDAO() : base()
        {
            _udto = new BTClientUserDTO();
        }

        public SqliteDAO(BTClientUserDTO udto) : base()
        {
            _udto = udto;
        }

        protected override void Init()
        {
            Params = new List<SQLiteParameter>();

            _connstr = ConfigurationManager.ConnectionStrings["SqliteConnection"].ToString();
            try
            {
                _conn = DBOpen();
            }
            catch
            {
                throw; // throw new TypeInitializationException()
            }
        }

        protected override void Dispose(bool disposing)
        {

            if (disposing)
            {
                if (!_disposed)
                {
                    // let Oracle.DataAccess takes care of Finalizer
                    _conn.Dispose();
                    _disposed = true;
                }
            }
        }

        private SQLiteConnection DBOpen()
        {
            SQLiteConnection conn;
            string[] temp = _connstr.Split(';');
            string fname = temp[0].Substring(temp[0].IndexOf('=') + 1);
            //string pwd = temp[2].Substring(temp[2].IndexOf('=') + 1);
            if (File.Exists(fname) && temp.Length == 2)
            {
                conn = new SQLiteConnection(temp[0] + ";" + temp[1]);
                //  conn.SetPassword(pwd);
            }
            else
            {
                conn = new SQLiteConnection(_connstr);
            }
            conn.Open();
            return conn;
        }

        public string GetValue(string sql)
        {
            string ret = null;
            SQLiteCommand cmd = new SQLiteCommand(sql, _conn);
            if (Params.Count > 0)
                cmd.Parameters.AddRange(Params.ToArray()); 
            ret = cmd.ExecuteScalar().ToString();
            
            if (Params.Count > 0)
                Params.Clear();

            return ret;
        }

        public override List<string> GetStringList(string sql)
        {
            List<string> ret = new List<string>();
            SQLiteCommand cmd = new SQLiteCommand(sql, _conn);
            if (Params.Count > 0)
                cmd.Parameters.AddRange(Params.ToArray());
            SQLiteDataReader r = cmd.ExecuteReader();
            while (r.Read())
            {
                ret.Add(r[0].ToString());
            }

            if (Params.Count > 0)
                Params.Clear();
            return ret;

        }
        public override List<int> GetIntList(string sql)
        {
            List<int> ret = new List<int>();
            SQLiteCommand cmd = new SQLiteCommand(sql, _conn);
            if (Params.Count > 0)
                cmd.Parameters.AddRange(Params.ToArray());
            SQLiteDataReader r = cmd.ExecuteReader();
            while (r.Read())
            {
                ret.Add(r.GetInt32(0));
            }

            if (Params.Count > 0)
                Params.Clear();
            return ret;

        }
        public SQLiteDataReader GetReader(string sql)
        {
            return (SQLiteDataReader)GetDataReader(sql);
        }
        public override object GetDataReader(string sql)
        {
            SQLiteCommand cmd = new SQLiteCommand(sql, _conn);
            if (Params.Count > 0)
                cmd.Parameters.AddRange(Params.ToArray());
            SQLiteDataReader r = cmd.ExecuteReader();
            if (Params.Count > 0)
                Params.Clear();
            return r;
        }
        public override int SaveDataSet(ElementDataDTO edd)
        {
            var ret = 0;
            if (edd.DataElements.Length > 0)
            {

                var tbl = GetSiteTable(edd.TableName);

                switch (edd.Action)
                {
                    case "Merge":
                        Merge(edd, tbl);
                        break;
                    case "Delete":
                        Delete(edd, tbl);
                        break;
                    case "Create":
                        ret = Create(edd, tbl);
                        break;
                    case "Update":
                        ret = Update(edd, tbl);// affected
                        break;
                    default:
                        throw new Exception("Unknown Action");
                }
            }
            return ret;
        }
        public void Delete(ElementDataDTO edd, SiteTable st)
        {
            var sql = new StringBuilder();
            var where = "";
            sql.Append("delete from " + st.Name);
            where = BuildWhereClause(edd.DataElements, false);
            if (string.IsNullOrEmpty(where))
                return;
            sql.Append(where);
            sql.Append(";");

            RunSql(sql.ToString());
        }
        public void Merge(ElementDataDTO edd, SiteTable st)
        {
            if (Update(edd, st) == 0)
                Create(edd, st);
        }
        public int Update(ElementDataDTO edd, SiteTable st)
        {
            var setlist = new StringBuilder();
           
            bool first = true;
            setlist.Append("update " + st.Name + " set ");

           /* if (!edd.DataElements.Any(x => !x.IsKey))
                return 0;*/

            foreach(var ele in edd.DataElements.ToList())
            {
                if (ele.DataType.Contains("System.Collections"))
                    continue;
                if (ele.DBName == "id" && ele.IsKey)
                    continue;
                if (/*!ele.IsKey &&*/ !ele.ReserveOriginal
                    && st.Cols.Any(x => x.Name == ele.DBName))
               {
                    setlist.Append((first ? "" : ",") + ele.DBName + "=" + DecoString(ele.DataValue, ele.DataType));
                                           
                        first = false;
               }
            }
            if(st.Cols.Any(x => x.Name == "udt"))
            {
                setlist.Append((first ? "" : ",") + "uby='" + _udto.Uname + "',udt=current_timestamp");
            }
            var where = BuildWhereClause(edd.DataElements);
            if (string.IsNullOrEmpty(where))
                return 0;
            setlist.Append(where);
            setlist.Append(";");

            return RunSql(setlist.ToString());
        }
        public int Create(ElementDataDTO edd, SiteTable st)
        {
            var clist = new StringBuilder();
            var vlist = new StringBuilder();
            bool first = true;
            clist.Append("insert into " + st.Name + "(");
            vlist.Append(" values(");

            foreach (var c in st.Cols)
            {
                if (c.Name == "id" && c.IsKey)
                    continue;

                if (c.Name == "cby")
                {
                    clist.Append(first ? "cby" : ",cby");
                    vlist.Append((first ? "" : ",") + DecoString(_udto.Uname, "System.String"));
                    first = false;
                    continue;
                }
                if (c.Name == "cdt")
                {
                    clist.Append(first ? "cdt" : ",cdt");
                    vlist.Append((first ? "" : ",") + "current_timestamp");
                    first = false;
                    continue;
                }

                for (int i = 0; i < edd.DataElements.Length; i++)
                {
                    var ele = edd.DataElements[i];
                    if (ele.DBName == c.Name)
                    {
                        clist.Append((first ? "" : ",") + c.Name);
                        vlist.Append((first ? "" : ",") + DecoString(ele.DataValue, ele.DataType));
                        first = false;
                    }
                }
            }
            clist.Append(")");
            vlist.Append(");");
            RunSql(clist.ToString() + vlist.ToString());

            var sql = "select last_insert_rowid();";

            if (st.Cols.Any(x => x.IsKey && x.Name == "id"))
                return Convert.ToInt32(GetValue(sql));
            else
                return 0;
        }
        private string DecoString(string v, string t)
        {
            if (v == null)
                return "null";
            if (t == "System.String")
                return "'" + v + "'";
            else
                return v;
        }
        public override void BeginTran()
        {
            _tran = _conn.BeginTransaction();
        }
        public override void Commit()
        {
            _tran.Commit();
        }
        public override void Rollback()
        {
            _tran.Rollback();
        }
        public override int RunSql(string sql)
        {
            int ret = 0;

            SQLiteCommand cmd = new SQLiteCommand(sql, _conn);
            if (Params.Count > 0)
                cmd.Parameters.AddRange(Params.ToArray());
            ret = cmd.ExecuteNonQuery();
            if (Params.Count > 0)
                Params.Clear();

            return ret;
        }
       
        public override string BuildSql(ElementRequestDTO erd)
        {
            var ret = new StringBuilder();
            if(erd.NameType == "table")
            {
                var st = GetSiteTable(erd.Name);
                ret.Append(BuildSelectList(st));
                ret.Append(BuildWhereClauseSelect(erd, st));
                ret.Append(BuildOrderBy(erd));
            }
           
            return ret.ToString();
        }
        public string BuildWhereClause(EleRowDTO[] rows, bool key = true)
        {
            var where = new StringBuilder();
            var first = true;

            Params.Clear();
            if (rows.Length > 0 && rows.Any(x => (!key || (key && x.IsKey))))
            {
                where.Append(" where ");

                foreach (var r in rows.ToList())
                {
                    if (r.DBName == "id" && r.IsKey && (string.IsNullOrEmpty(r.DataValue) || Convert.ToInt32(r.DataValue) == 0))
                        continue;
                    if (!key || (key && r.IsKey))
                    {
                        where.Append((first ? "" : " and ") + r.DBName + "=@p_" + r.DBName);
                        first = false;
                        Type t = Type.GetType(r.DataType);
                        Params.Add(new SQLiteParameter("@p_" + r.DBName, EntityAttrHelper.GetValue(r.DataValue, t)));
                    }
                }
            }
            return where.ToString();
        }
        private string BuildWhereClauseSelect(ElementRequestDTO erd, SiteTable st)
        {
            var ret = new StringBuilder();
            var first = true;

            Params.Clear();

            if (erd.Filters.Count > 0)
            {
                ret.Append(" where ");

                foreach(var f in erd.Filters)
                {
                    ret.Append((first ? "" : " and ") + BuildOp(f.Oper, f.ColName));
                    Type t = Type.GetType(st.Cols.Where(x => x.Name == f.ColName).Select(x => x.DataType).Single());
                    Params.Add(new SQLiteParameter("@p_" + f.ColName, EntityAttrHelper.GetValue(f.Value, t)));

                    first = false;
                }
            }

            return ret.ToString();
        }
        private string BuildOp(string op, string colnm)
        {
            var ret = "";

            switch (op)
            {
                case "eq":
                    ret = colnm + "=@p_" + colnm;
                    break;
                case "gt":
                    ret = colnm + ">@p_" + colnm;
                    break;
                case "lt":
                    ret = colnm + "<@p_" + colnm;
                    break;
                case "le":
                    ret = colnm + "<=@p_" + colnm;
                    break;
                case "ge":
                    ret = colnm + ">=@p_" + colnm;
                    break;
                case "eqn":
                    ret = "(" + colnm + " is null or " + colnm + "=@p_" + colnm + ")";
                    break;
                case "ne":
                    ret = colnm + "!=@p_" + colnm;
                    break;
                case "cn":
                    ret = colnm + " like '%@p_" + colnm + "%'";
                    break;
                case "nc":
                    ret = colnm + " not like '%@p_" + colnm + "%'";
                    break;
                default:
                    break;
            }

            return ret;
        }
        private string BuildSelectList(SiteTable st)
        {
            var ret = new StringBuilder();
            var first = true;

            ret.Append("select ");
            foreach(var c in st.Cols)
            {
                ret.Append((first ? "" : ",") + c.Name);
                first = false;
            }

            return ret.ToString();
        }
        private string BuildOrderBy(ElementRequestDTO erd)
        {
            var ret = new StringBuilder();
            var first = true;

            if(erd.Sorts.Count > 0)
            {
                ret.Append(" order by ");
                foreach(var s in erd.Sorts)
                {
                    ret.Append((first ? "" : ",") + s.ColName);
                    if (!s.Asc)
                        ret.Append(" desc");
                    first = false;
                }
            }

            return ret.ToString();
        }
        public void BuildParameter(List<Parameter> lpdto)
        {
            Params.Clear();

            var ret = new List<SQLiteParameter>();

            foreach (var p in lpdto)
            {
                Type t = Type.GetType(p.DataType);

                ret.Add(new SQLiteParameter(p.Name, EntityAttrHelper.GetValue(p.Value, t)));
            }
            Params.AddRange(ret);
        }
        public override List<T> GetEntityList<T>(string sql)
        {
            List<T> lsli = new List<T>();
                    
            if(_conn.State != ConnectionState.Open)
                _conn.Open();
            SQLiteCommand cmd = new SQLiteCommand(sql, _conn);
            cmd.CommandTimeout = CMDTIMEOUT;
            if (Params.Count > 0)
                cmd.Parameters.AddRange(Params.ToArray());
               
            SQLiteDataReader r = cmd.ExecuteReader();
            while (r.Read())
            {
                lsli.Add(DBConverter.DB2Entity<T>(r));
            }
            if (Params.Count > 0)
                Params.Clear();

           
            return lsli;
        }
        public override void TestDBConfig()
        {
            throw new NotImplementedException();
        }
        public override ElementDataDTO GetTargetTableData(string tname)
        {
            throw new NotImplementedException();
        }
        public override int InsertDataReturnId(string sql)
        {
            RunSql(sql);
            var temp = "select last_insert_rowid();";

            return Convert.ToInt32(GetValue(temp));
        }
        public override SiteTable GetSiteTable(string tname)
        {
            var ret = new SiteTable { Name = tname, TType = "Table" };

            var cmd = new SQLiteCommand("PRAGMA table_info(" + tname + ")", _conn);
            var dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                ret.Cols.Add(new Column {
                    Name = dr.GetString(1),
                    Idx = dr.GetInt32(0),
                    DataType = SqliteTypeMap[dr.GetString(2)],
                    Nullable = Convert.ToBoolean(dr.GetInt32(3)),
                    DefaultValue = EntityAttrHelper.SafeStringValue(dr.GetValue(4)),
                    IsKey = Convert.ToBoolean(dr.GetInt32(5)) 
                });
            }
            dr.Close();
           
            return ret;
        }
      
    }
}
