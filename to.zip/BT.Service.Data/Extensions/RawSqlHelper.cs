﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BT.Service.Data.Extensions
{
    public static class RawSqlHelper
    {
        public static string RemoveDML(this string s)
        {
            var reg = new Regex(@"(drop)|(delete)|(alter)|(xp_)", RegexOptions.IgnoreCase);

            return reg.Replace(s, "####");
        }

        public static string SafeLikeString(this string s)
        {
            s = s.Replace("[", "[[]");
            s = s.Replace("%", "[%]");
            s = s.Replace("_", "[_]");

            return s;
        }
        public static string SafeString(this string s)
        {
           // s = s.Replace(";", "\\;");
            s = s.Replace("'", "''");
           // s = s.Replace("--", "\\-\\-");
           // s = s.Replace("/\\*", "####");
           // s = s.Replace("*/", "####");
           // s = s.Replace("xp_", " ")

            return s;
        }
    }
}
