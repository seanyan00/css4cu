﻿using System;
using System.Collections.Generic;
using System.Linq;
//using System.Linq.Expressions;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Reflection;

using BT.Service.TransferObject.ClientSite;
using BT.Service.TransferObject.Main;

namespace BT.Service.Data.Extensions
{
    public class EntityHelper<T> where T : class, new()
    {
        private DbContext _ctx;
        public BTClientUserDTO BUD { get; private set; }   
        public ElementDataDTO EDD { get; private set; }
        public ElementRequestDTO ERD { get; private set; }

        public EntityHelper(DbContext ctx, ElementDataDTO edd, BTClientUserDTO bud)
        {
            _ctx = ctx;
            _ctx.Database.CommandTimeout = 3000;

            EDD = edd;
            BUD = bud;
        }
        public EntityHelper(DbContext ctx, ElementRequestDTO erd, BTClientUserDTO bud)
        {
            _ctx = ctx;
            _ctx.Database.CommandTimeout = 3000;

            ERD = erd;
            BUD = bud;
        }
        public string[] FindPrimaryKeyNames() 
        {
            var objectSet = ((IObjectContextAdapter)_ctx).ObjectContext.CreateObjectSet<T>();
            var keyNames = objectSet.EntitySet.ElementType.KeyMembers.Select(k => k.Name).ToArray();
            return keyNames;
        }
        public Type[] FindPrimaryKeyTypes()
        {
            var keyNames = FindPrimaryKeyNames();
            var types = keyNames.Select(x => typeof(T).GetProperty(x).PropertyType).ToArray();
            return types;
        }
        public object[] FindPrimaryKeyDefaultValues()
        {
            var types = FindPrimaryKeyTypes();
            var defaultValues = types.Select(x => x.IsValueType ? Activator.CreateInstance(x) : null).ToArray();
            return defaultValues;
        }
        public int PersistChange()
        {
            int ret = 0;
            T o = null;

            DbSet st = _ctx.Set(typeof(T));

            switch(EDD.Action)
            {
                case "Create":
                    o = AddEntity(st);
                    break;
                case "Update":
                    UpdateEntity(st);
                    break;
                case "Delete":
                    DeleteEntity(st);
                    break;
                case "DeleteCreate":
                    DeleteEntity(st);
                    _ctx.SaveChanges();

                    o = AddEntity(st);
                    break;
                case "DeleteAll":
                    DeleteEntityAll(st);
                  
                    break;
                default:
                    throw new Exception("Unknown Action Required");
            }
            _ctx.SaveChanges();

            if ((EDD.Action == "Create" || EDD.Action == "DeleteCreate") && o.GetType().GetProperty("Id") != null)
                ret = (int)(o.GetType().GetProperty("Id").GetValue(o));
            return ret;
        }
        private T AddEntity(DbSet st)
        {
            var et = (T)st.Create();
            SetObjectValues(et, EDD.Action);
            st.Add(et);
            return et;
        }
        private void DeleteEntity(DbSet st)
        {
            foreach(var o in st)
            {
                if(IsSameEntity((T)o))
                {
                    st.Remove(o);
                    break;
                }
            }
        }
        private void DeleteEntityAll(DbSet st)
        {
            foreach (var o in st)
            {
                if (IsTargetEntity((T)o))
                {
                    st.Remove(o);
                }
            }
        }
        private void UpdateEntity(DbSet st)
        {
            foreach(var o in st)
            {
                if(IsSameEntity((T)o))
                {
                    SetObjectValues(o, EDD.Action);
                    break;
                }
            }
        }
        private PropertyInfo[] GetProps(T obj)
        {
            var props = obj.GetType().GetProperties(BindingFlags.Instance|BindingFlags.Public);
            //only system data types, no collection nor class
            return props.Where(x => x.PropertyType.Namespace == "System").ToArray();
        }
        public static PropertyInfo[] GetProperties(T obj)
        {
            var props = obj.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);
            //only system data types, no collection nor class
            return props.Where(x => x.PropertyType.Namespace == "System").ToArray();
        }
        private bool IsTargetEntity(T obj)
        {
            var props = GetProps(obj);
        
            foreach(var p in props)
            {
                string v = null;

                if(p.GetValue(obj, null) != null)
                   v = EntityAttrHelper.SetValue(p.GetValue(obj, null));

                foreach(var col in EDD.DataElements)
                {
                    if(col.DBName == p.Name && col.DataValue != v)
                    {
                        return false;
                    }
                }
            }
            return true;
        }
        private bool IsSameEntity(T obj)
        {
            var props = GetProps(obj);
            var keys = FindPrimaryKeyNames();
            bool ret = true;

            foreach(var k in keys)
            {
                var v = props.First(x => x.Name == k).GetValue(obj, null);
                if(EDD.DataElements.Any(x => x.DBName == k))
                {
                    if (v.GetType() == typeof(DateTime))
                    {
                        if (string.Compare(EDD.DataElements.First(x => x.DBName == k).DataValue, 
                                           EntityAttrHelper.SetDateTimeValue((DateTime)v)) != 0)
                        {
                            ret = false;
                            break;
                        }
                    }
                    else
                    {
                        if (string.Compare(EDD.DataElements.First(x => x.DBName == k).DataValue, v.ToString()) != 0)
                        {
                            ret = false;
                            break;
                        }
                    }
                } else
                {
                    ret = false;
                    break;
                }
            }

            return ret;
        }

        public ElementDataDTO GetDTO()
        {
            var ret = new ElementDataDTO {
                TableName = typeof(T).FullName
            };

        /*    List<EleRowDTO> tl = new List<EleRowDTO>();
            int rid = 0;

            List<T> ds = new List<T>();
            
            switch (ERD.Sorts.Count) {
                case 1:
                   ds = ERD.Sorts[0].Asc ? _ctx.Set<T>().OrderBy(ERD.Sorts[0].ColName).ToList<T>()
                                          : _ctx.Set<T>().OrderByDescending(ERD.Sorts[0].ColName).ToList<T>();

                   break;
                case 2:
                    ds = ERD.Sorts[1].Asc ? _ctx.Set<T>().ThenBy(ERD.Sorts[1].ColName).ToList<T>()
                                          : _ctx.Set<T>().ThenByDescending(ERD.Sorts[1].ColName).ToList<T>();
                    break;
                default:
                    ds = _ctx.Set<T>().ToList<T>();
                    break;
            }
                       
            List<string> incids = new List<string>();

            foreach (var v in ds)
            {
                if (IsInSet(v))
                {
                    ++rid;
                    var pts = GetProps((T)v);

                    foreach (var p in pts)
                    {
                        var row = new EleRowDTO
                        {
                            RowId = rid.ToString(),
                            DBName = p.Name,
                            DataType = p.PropertyType.FullName,
                            DataValue = p.GetValue(v) == null ? Convert.ToString(EntityAttrHelper.GetDefaultValue(p.GetType()))
                                                              : EntityAttrHelper.SetValue(p.GetValue(v))
                        };
                        if (!string.IsNullOrEmpty(ERD.PId) && row.DBName == ERD.PName && row.DataValue == ERD.PId)
                            incids.Add(row.RowId);

                        tl.Add(row);
                    }
                }
            }
            if (!string.IsNullOrEmpty(ERD.PId))
            {
                if (ERD.Incl)
                {
                    tl = tl.Where(x => incids.Any(y => y == x.RowId)).ToList();
                } else
                {
                    tl = tl.Where(x => !incids.Any(y => y == x.RowId)).ToList();
                }
            }
           
            ret.DataElements = tl.ToArray();*/
            
            return ret;
        }
        private bool IsInSet(object v)
        {
            foreach(var f in ERD.Filters)
            {
                var val = v.GetType().GetProperty(f.ColName).GetValue(v);

                if (string.IsNullOrEmpty(f.Value) && val == null)
                    continue;

                switch (f.Oper)
                {
                    case "eq":
                        if (f.Value == val.ToString())
                            continue;
                        break;
                    case "ne":
                        if (f.Value != val.ToString())
                            continue;
                        break;
                    case "cn":
                        if (f.Value.IndexOf(val.ToString()) >= 0)
                            continue;
                        break;
                    default:
                        break;
                }
                return false;
            }
         
            return true;
        }
        private void GetDTOByCols(ElementDataDTO ret, DbSet ds)
        {
            List<EleRowDTO> tl = new List<EleRowDTO>();
            int rid = 0;
            List<string> incids = new List<string>();
            foreach (var v in ds)
            {
                ++rid;
                var pts = GetProps((T)v);

                foreach (var p in pts)
                {
                    var row = new EleRowDTO
                    {
                        RowId = rid.ToString(),
                        DBName = p.Name,
                        DataType = p.PropertyType.FullName,
                        DataValue = p.GetValue(v) == null ? Convert.ToString(EntityAttrHelper.GetDefaultValue(p.GetType()))
                                                          : EntityAttrHelper.SetValue(p.GetValue(v))
                    };
                    if (!string.IsNullOrEmpty(EDD.PId) && row.DBName == EDD.PName && row.DataValue == EDD.PId)
                        incids.Add(row.RowId);

                    tl.Add(row);
                }
            }
            if (incids.Count > 0)
                tl = tl.Where(x => incids.Any(y => y == x.RowId)).ToList();

            ret.DataElements = tl.ToArray();
        }
        public IEnumerable<T> GetList()
        {
            var pi = _ctx.GetType().GetProperty(EDD.TableName);
            return ((IEnumerable<T>)pi.GetValue(_ctx)).ToList<T>();
        }  
        //var ret = GetList<T>(ctx, x => (T)x);
        public IEnumerable<T> GetList(Func<object, T> caster)
        {
           
            var setmethod = _ctx.GetType().GetMethod("Set").MakeGenericMethod(typeof(T));

            var querable = ((DbSet<object>)setmethod
                            .Invoke(this, null))
                            .AsNoTracking()
                            .AsQueryable();

            return querable
                .Select(x => caster(x))
                .ToList();
        }
      
        private void SetObjectValues(object obj, string act)
        {
            bool found = false;

            var pts = GetProps((T)obj);
            foreach (var p in pts)
            {
                found = false;
                if(act == "Create" || act == "DeleteCreate")
                {
                    if (p.Name == "CreateDate")
                    {
                        p.SetValue(obj, DateTime.Now);
                        continue;
                    }
                    if (p.Name == "CreatedBy")
                    {
                        p.SetValue(obj, BUD.Uname);
                        continue;
                    }
                    if (p.Name == "UpdateDate" || p.Name == "UpdatedBy")
                        continue;
                } 
                if(act == "Update")
                {
                    if (p.Name == "UpdateDate")
                    {
                        p.SetValue(obj, DateTime.Now);
                        continue;
                    }
                    if (p.Name == "UpdatedBy")
                    {
                        p.SetValue(obj, BUD.Uname);
                        continue;
                    }
                    if (p.Name == "CreateDate" || p.Name == "CreatedBy")
                        continue;
                }
                foreach(var d in EDD.DataElements)
                {
                    if(p.Name == d.DBName)
                    {
                        Type t = Type.GetType(d.DataType);

                        var tname = IsNullable(p.PropertyType) ?
                            Nullable.GetUnderlyingType(p.PropertyType).FullName :
                            p.PropertyType.FullName;

                        if (tname == "System.DateTime" 
                            && t.FullName == "System.String")
                            p.SetValue(obj, EntityAttrHelper.GetDateTimeValue(d.DataValue));
                        else
                           p.SetValue(obj, EntityAttrHelper.GetValue(d.DataValue, t));

                        found = true;
                        break;
                    }
                }
                if(!found)
                {
                    p.SetValue(obj, EntityAttrHelper.GetDefaultValue(p.PropertyType));
                }
            }
        }  
        private bool IsNullable(Type t)
        {
            return Nullable.GetUnderlyingType(t) != null;
        }
    }
    
}  
