﻿namespace BT.Service.Data.Models
{
    public class ApplTbl
    {
        public int id { get; set; }
        public string nm { get; set; }
        public int dbcid { get; set; }
        public string typ { get; set; }

    }
}
