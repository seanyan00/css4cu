﻿namespace BT.Service.Data.Models
{
    public class UIAttrCode
    {
        public int id { get; set; }
        public string cde { get; set; }
        public int pid { get; set; }
        public string uityp { get; set; }
    }
}
