﻿using System.Collections.Generic;

namespace BT.Service.Data.Models
{
    public class DBConnConfig
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Type { get; set; }
        public string Server { get; set; }
        public int Port { get; set; }
        public string SID { get; set; }
        public string Protocol { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Caller { get; set; }
        public bool WinAuth { get; set; }
        public int SubID { get; set; }
    }
    
    public class ORA_Address
    {
         public string Protocol { get; set; }
         public string Host { get; set; }
         public int Port { get; set; }
    }

    public class ORA_Address_List
    {
        public bool Failover { get; set; }
        public bool Loadbalance { get; set; }
        public List<ORA_Address> AddrList { get; set; }
    }

    public class TableAudit
    {
        public string DBName { get; set; }
        public string Schema { get; set; }
        public string TblName { get; set; }
        public int DBConfigId { get; set; }
        public string SubsysName { get; set; }
        public int ScriptsCreated { get; set; }
        public string CreatedBy { get; set; }
    }
}
