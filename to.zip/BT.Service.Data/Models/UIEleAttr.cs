﻿namespace BT.Service.Data.Models
{
    public class UIEleAttr
    {
         public int id { get; set; }
         public int eid { get; set; }
         public int codeid { get; set; }
         public string value { get; set; }
         public int idx { get; set; }
         public string cde { get; set; }
         public int codepid { get; set; } 
    }
}
