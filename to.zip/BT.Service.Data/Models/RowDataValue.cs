﻿namespace BT.Service.Data.Models
{
   public class RowDataValue
    {
        public int RowIdx { get; set; }
        public int ColIdx { get; set; }
        public string ColName { get; set; }
        public string ColValue { get; set; }
        public string ColType { get; set; }
    }
}
