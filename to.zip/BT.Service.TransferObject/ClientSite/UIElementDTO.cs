﻿using System;
using System.Runtime.Serialization;

namespace BT.Service.TransferObject.ClientSite
{
    [DataContract]
    public class UIElementDTO
    {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public int ParentId { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string EleType { get; set; }
        [DataMember]
        public string SubCode { get; set; }
        [DataMember]
        public DateTime CreateDate { get; set; }
        [DataMember]
        public string CreatedBy { get; set; }
        [DataMember]
        public DateTime UpdateDate { get; set; }
        [DataMember]
        public string UpdatedBy { get; set; }
        [DataMember]
        public int ContainerId { get; set; }
        [DataMember]
        public string Description { get; set; }
        [DataMember]
        public string DataTarget { get; set; }
        [DataMember]
        public string Controller { get; set; }
        [DataMember]
        public bool Status { get; set; }
        [DataMember]
        public int Perm { get; set; }
        [DataMember]
        public ElementAttributeDTO[] Attrs { get; set; }

        public UIElementDTO()
        {
            Attrs = new ElementAttributeDTO[] { };
        }
    }

    [DataContract]
    public class ElementAttributeDTO
    {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public string Code { get; set; }
        [DataMember]
        public string ValueType { get; set; }
        [DataMember]
        public string Value { get; set; }
        [DataMember]
        public string DefaultValue { get; set; }
        [DataMember]
        public string ValueFrom { get; set; }
        [DataMember]
        public string ValueTo { get; set; }
        [DataMember]
        public int Idx { get; set; }
        [DataMember]
        public int PId { get; set; }
        [DataMember]
        public string PName { get; set; }
        [DataMember]
        public string DBName { get; set; }
        [DataMember]
        public DateTime CreateDate { get; set; }
        [DataMember]
        public string CreatedBy { get; set; }
        [DataMember]
        public DateTime UpdateDate { get; set; }
        [DataMember]
        public string UpdatedBy { get; set; }
    }
}
