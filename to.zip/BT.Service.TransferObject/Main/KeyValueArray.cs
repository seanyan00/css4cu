﻿using System;
using System.Runtime.Serialization;

namespace BT.Service.TransferObject.Main
{
    [DataContract]
    public class KeyValueArray
    {
        [DataMember]
        public KeyValueItem[] Items { get; set; }

        public KeyValueArray()
        {
            Items = new KeyValueItem[] { };
        }
    }

    [DataContract]
    public class KeyValueItem
    {
        [DataMember]
        public string Key { get; set; }
        [DataMember]
        public string Value { get; set; }
    }
}
