﻿using System.Runtime.Serialization;

namespace BT.Service.TransferObject.Main
{
    [DataContract]
    public class TableColumnDTO
    {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public int TableId { get; set; }
        [DataMember]
        public string TableName { get; set; }
        [DataMember]
        public string TableType { get; set; }
        [DataMember]
        public string DataType { get; set; }
        [DataMember]
        public bool PK { get; set; }
        [DataMember]
        public int Length { get; set; }
        [DataMember]
        public string DefaultValue { get; set; }
        [DataMember]
        public bool Nullable { get; set; }
        [DataMember]
        public string FK { get; set; }
        [DataMember]
        public bool Identity { get; set; }
        [DataMember]
        public ColConstraintDTO[] Constraints { get; set; }
        public TableColumnDTO()
        {
            Constraints = new ColConstraintDTO[] { };
        }
    }
    [DataContract]
    public class ColConstraintDTO
    {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public string ConsType { get; set; }
        [DataMember]
        public string Val1 { get; set; }
        [DataMember]
        public string Val2 { get; set; }
    }
}
