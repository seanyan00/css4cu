﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace BT.Service.TransferObject.Main
{
    [DataContract]
    public class ReportRequestDTO
    {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public List<QueryParamDTO> QPs { get; set; }
        public ReportRequestDTO()
        {
            QPs = new List<QueryParamDTO>();
        }
    }
    [DataContract]
    public class QueryParamDTO
    {
        [DataMember]
        public int QId { get; set; }
        [DataMember]
        public List<KeyValueItem> Params { get; set; }
        public QueryParamDTO()
        {
            Params = new List<KeyValueItem>();
        }
    }
}
