﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace BT.Service.TransferObject.Main
{
    [DataContract]
    public class ElementRequestDTO
    {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string NameType { get; set; }
        [DataMember]
        public int PageNum { get; set; }
        [DataMember]
        public int RowsPerPage { get; set; }
        [DataMember]
        public List<Filter> Filters { get; set; }
        [DataMember]
        public List<Sort> Sorts { get; set; }
      
        public ElementRequestDTO()
        {
            Filters = new List<Filter>();
            Sorts = new List<Sort>();
        }
    }
}
