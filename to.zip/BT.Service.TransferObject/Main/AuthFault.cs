﻿using System;
using System.Runtime.Serialization;

namespace BT.Service.TransferObject.Main
{
    [DataContract]
    public class AuthFault
    {
        [DataMember]
        public int Code { get; set; }
        [DataMember]
        public string ErrorMsg { get; set; }

        public AuthFault(int code, string msg)
        {
            Code = code;
            ErrorMsg = msg;
        }
    }
}
