﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace BT.Service.TransferObject.Main
{
    [DataContract]
    public class ClientTableDTO
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string TType { get; set; }
        [DataMember]
        public ClientTableColumn[] Cols { get; set; }
        public ClientTableDTO()
        {
            Cols = new ClientTableColumn[] { };
        }
    }
    [DataContract]
    public class ClientTableColumn
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string DataType { get; set; }
        [DataMember]
        public bool IsKey { get; set; }
        [DataMember]
        public int KeyIdx { get; set; }
        [DataMember]
        public bool IsNullable { get; set; }
        [DataMember]
        public bool HasDefaultValue { get; set; }
        [DataMember]
        public int MaxLength { get; set; }
    }

}

