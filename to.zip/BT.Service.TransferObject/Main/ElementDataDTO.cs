﻿using System.Runtime.Serialization;

namespace BT.Service.TransferObject.Main
{
    [DataContract]
    public class ElementDataDTO
    {
        [DataMember]
        public string TableName { get; set; }
        [DataMember]
        public string Action { get; set; }
        [DataMember]
        public string PId { get; set; }
        [DataMember]
        public string PName { get; set; }
        [DataMember]
        public bool Incl { get; set; }
        [DataMember]
        public Sort[] Sorts { get; set; }
        [DataMember]
        public EleRowDTO[] DataElements { get; set; }
        public ElementDataDTO()
        {
            DataElements = new EleRowDTO[] { };
            Sorts = new Sort[] { };
        }
    }
    [DataContract]
    public class EleRowDTO
    {
        [DataMember]
        public string RowId { get; set; }
        [DataMember]
        public string UIName { get; set; }
        [DataMember]
        public string DataType { get; set; }
        [DataMember]
        public string DataValue { get; set; }
        [DataMember]
        public string DefValue { get; set; }
        [DataMember]
        public bool Nullable { get; set; }
        [DataMember]
        public string DBName { get; set; }
        [DataMember]
        public bool IsKey { get; set; }
        [DataMember]
        public bool IsIden { get; set; }
        [DataMember]
        public bool ReserveOriginal { get; set; }
    }
    [DataContract]
    public class Sort
    {
        [DataMember]
        public string ColName { get; set; }
        [DataMember]
        public bool Asc { get; set; }
    }
    [DataContract]
    public class Filter
    {
        [DataMember]
        public string ColName { get; set; }
        [DataMember]
        public string DataType { get; set; }
        [DataMember]
        public string Value { get; set; }
        [DataMember]
        public string Oper { get; set; }
    }
}
