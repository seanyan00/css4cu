﻿using System;
using System.Runtime.Serialization;

namespace BT.Service.TransferObject.Main
{
    [DataContract]
    public class FileDTO
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public string nm { get; set; }
        [DataMember]
        public string typ { get; set; }
        [DataMember]
        public int said { get; set; }
        [DataMember]
        public string applnm { get; set; }
        [DataMember]
        public int dbcid { get; set; }
        [DataMember]
        public string tgt { get; set; }
        [DataMember]
        public string orgnm { get; set; }
        [DataMember]
        public string docpath { get; set; }
        [DataMember]
        public string delimiter { get; set; }
        [DataMember]
        public byte[] content { get; set; }
    }
}
