﻿using System.Runtime.Serialization;

namespace BT.Service.TransferObject.Main
{
    [DataContract]
    public class GrantDTO
    {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public int UId { get; set; }
        [DataMember]
        public string UType { get; set; }
        [DataMember]
        public int OId { get; set; }
        [DataMember]
        public string OName { get; set; }
        [DataMember]
        public int Perm { get; set; }
        [DataMember]
        public int Status { get; set; }
    }
}
