﻿using System;
using System.Runtime.Serialization;

namespace BT.Service.TransferObject.Main
{
    [DataContract]
    public class BTClientUserDTO
    {
        public BTClientUserDTO() { }
        public BTClientUserDTO(BTClientUserDTO udto)
        {
            this.DomainId = udto.DomainId;
            this.Domain = udto.Domain;
            this.Id = udto.Id;
            this.Email = udto.Email;
            this.Uname = udto.Uname;
            this.FromApp = udto.FromApp;
            this.FromDevice = udto.FromDevice;
            this.FromIP = udto.FromIP;
            this.Grants = udto.Grants;
            this.Roles = udto.Roles;
            this.Timestamp = udto.Timestamp;
            this.Token = udto.Token;
        }
        [DataMember]
        public int DomainId { get; set; }
        [DataMember]
        public string Domain { get; set; }
       [DataMember]
       public int Id { get; set; }
       [DataMember]
       public string Email { get; set; }
        [DataMember]
        public string Uname { get; set; }
        [DataMember]
        public string Token { get; set; }
        [DataMember]
        public SiteRoleDTO[] Roles { get; set; }
        [DataMember]
        public GrantDTO[] Grants { get; set; }
        [DataMember]
        public string FromApp { get; set; }
        [DataMember]
        public string FromIP { get; set; }
        [DataMember]
        public string FromDevice { get; set; }
        [DataMember]
        public DateTime Timestamp { get; set; }
    }
}
