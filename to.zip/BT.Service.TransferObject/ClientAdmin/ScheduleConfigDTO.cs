﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace BT.Service.TransferObject.ClientAdmin
{
    [DataContract]
    public class ScheduleConfigDTO
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public int said { get; set; }
        [DataMember]
        public string nm { get; set; }
        [DataMember]
        public string desc { get; set; }
        [DataMember]
        public string crn { get; set; }
        [DataMember]
        public string typ { get; set; }
        [DataMember]
        public string fltyp { get; set; }
        [DataMember]
        public int fid { get; set; }
        [DataMember]
        public int stat { get; set; }
        [DataMember]
        public ScheduleEmail SchEmail { get; set;}
        [DataMember]
        public ScheduleDTran SchDTran { get; set; }
        [DataMember]
        public List<ScheduleRptParam> RptParams { get; set; }
        public ScheduleConfigDTO()
        {
            RptParams = new List<ScheduleRptParam>();
        }
    }
    [DataContract]
    public class ScheduleRptParam
    {
        [DataMember]
        public int schid { get; set; }
        [DataMember]
        public int qid { get; set; }
        [DataMember]
        public string nm { get; set; }
        [DataMember]
        public string op { get; set; }
        [DataMember]
        public string val { get; set; }
    }
    [DataContract]
    public class ScheduleEmail
    {
        [DataMember]
        public int schid { get; set; }
        [DataMember]
        public string frm { get; set; }
        [DataMember]
        public string rcp { get; set; }
        [DataMember]
        public string sub { get; set; }
        [DataMember]
        public string msg { get; set; }
    }
    [DataContract]
    public class ScheduleDTran
    {
        [DataMember]
        public int schid { get; set; }
        [DataMember]
        public string typ { get; set; }
        [DataMember]
        public int tarid { get; set; }
        [DataMember]
        public string mthd { get; set; }
        [DataMember]
        public string ip { get; set; }
        [DataMember]
        public int prt { get; set; }
        [DataMember]
        public string fnm { get; set; }
        [DataMember]
        public string unm { get; set; }
        [DataMember]
        public string pwd { get; set; }
    }
}
