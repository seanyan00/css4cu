﻿using System.Collections.Generic;
using System.Data;
using System.Runtime.Serialization;

namespace BT.Service.TransferObject.ClientAdmin
{
    [DataContract]
    public class CommandDTO
    {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Type { get; set; }
        [DataMember]
        public List<Parameter> Params { get; set; }
        public CommandDTO()
        {
            Params = new List<Parameter>();
        }
    }

    [DataContract]
    public class Parameter
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string DataType { get; set; }
        [DataMember]
        public string Value { get; set; }
        [DataMember]
        public string Direction { get; set; }
        public Parameter() { }
        public Parameter(string nm, string typ, string val, string dir)
        {
            Name = nm;
            DataType = typ;
            Value = val;
            Direction = dir;
        }
    }
}
