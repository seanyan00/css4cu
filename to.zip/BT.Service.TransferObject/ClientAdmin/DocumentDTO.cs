﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.Service.TransferObject.ClientAdmin
{
    public class DocumentDTO
    {
        public int Id { get; set; }
        public string ProjectNo { get; set; }
        public string Name { get; set; }
        public string DocType { get; set; }
        public bool Status { get; set; }
        public string DocPath { get; set; }
        public string Author { get; set; }
        public string Notes { get; set; }
    }
}
