﻿using System.Runtime.Serialization;

namespace BT.Service.TransferObject.ClientAdmin
{
    [DataContract]
    public class AssignedTableDTO
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public int dbcid { get; set; }
        [DataMember]
        public string nm { get; set; }
        [DataMember]
        public string typ { get; set; }
    }
}
