﻿using System.Runtime.Serialization;

namespace BT.Service.TransferObject.ClientAdmin
{
    [DataContract]
    public class DBConfigDTO
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public string nm { get; set; }
        [DataMember]
        public string desc { get; set; }
        [DataMember]
        public string dbtyp { get; set; }
        [DataMember]
        public string srv { get; set; }
        [DataMember]
        public int port { get; set; }
        [DataMember]
        public string svc { get; set; }
        [DataMember]
        public string prot { get; set; }
        [DataMember]
        public string usr { get; set; }
        [DataMember]
        public string pwd { get; set; }
        [DataMember]
        public int said { get; set; }
        [DataMember]
        public int stat { get; set; }
    }
}
