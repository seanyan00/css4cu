﻿using System.Runtime.Serialization;

namespace BT.Service.TransferObject.ClientAdmin
{
    [DataContract]
    public class SearchResultDTO
    {
        [DataMember]
        public string Id { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Type { get; set; }
        [DataMember]
        public string Status { get; set; }
        [DataMember]
        public string StatusDate { get; set; }
        [DataMember]
        public string UpdatedBy { get; set; }
    }
}
