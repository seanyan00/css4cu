﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace BT.Service.TransferObject.ClientAdmin
{
    [DataContract]
    public class PageConfigDTO
    {
        [DataMember]
        public int pageid { get; set; }
        [DataMember]
        public string pagenm { get; set; }
        [DataMember]
        public int said { get; set; }
        [DataMember]
        public PWGridDTO[] eles { get; set; }
        public PageConfigDTO()
        {
            eles = new PWGridDTO[0] { };
        }
    }
    [DataContract]
    public class PWGridDTO
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public string nm { get; set; }
        [DataMember]
        public string typ { get; set; }
        [DataMember]
        public string pos { get; set; }
        [DataMember]
        public bool remove { get; set; }
        [DataMember]
        public int perm { get; set; }
        [DataMember]
        public int pid { get; set; }
        [DataMember]
        public int dtcid { get; set; }
        [DataMember]
        public int ftblid { get; set; }
        [DataMember]
        public int ttblid { get; set; }
        [DataMember]
        public string frow { get; set; }
        [DataMember]
        public string pager { get; set; }
        [DataMember]
        public string del { get; set; }
        [DataMember]
        public string add { get; set; }
        [DataMember]
        public string edit { get; set; }
        [DataMember]
        public string grouping { get; set; }
        [DataMember]
        public string csv { get; set; }
        [DataMember]
        public string excel { get; set; }
        [DataMember]
        public string pdf { get; set; }
        [DataMember]
        public string fields { get; set; }
        [DataMember]
        public string orders { get; set; }
        [DataMember]
        public string sum { get; set; }
        [DataMember]
        public GridColumnDTO[] cols { get; set; }
        [DataMember]
        public PageChart Chart { get; set; }
        [DataMember]
        public PageText Text { get; set; }
        [DataMember]
        public PageLink[] Links { get; set; }
        [DataMember]
        public PageDDL DDL { get; set; }
    }
    [DataContract]
    public class GridColumnDTO
    {
        [DataMember]
        public int idx { get; set; }
        [DataMember]
        public string title { get; set; }
        [DataMember]
        public string datacol { get; set; }
        [DataMember]
        public string editable { get; set; }
        [DataMember]
        public string hidden { get; set; }
        [DataMember]
        public string align { get; set; }
        [DataMember]
        public string sumtyp { get; set; }
    }
    [DataContract]
    public class PageDDL
    {
        [DataMember]
        public int eleid { get; set; }
        [DataMember]
        public int dtcid { get; set; }
        [DataMember]
        public int tareleid { get; set; }
        [DataMember]
        public string tarelefld { get; set; }
        [DataMember]
        public string act { get; set; }
    }
    [DataContract]
    public class PageText
    {
        [DataMember]
        public int eleid { get; set; }
        [DataMember]
        public string cnt { get; set; }
        [DataMember]
        public string typ { get; set; }
    }
    [DataContract]
    public class PageChart
    {
        [DataMember]
        public int eleid { get; set; }
        [DataMember]
        public string typ { get; set; }
        [DataMember]
        public int rptid { get; set; }
    }
    [DataContract]
    public class PageLink
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public int eleid { get; set; }
        [DataMember]
        public string lnk { get; set; }
        [DataMember]
        public string ttl { get; set; }
        [DataMember]
        public int idx { get; set; }
        [DataMember]
        public string frm { get; set; }
    }
}
