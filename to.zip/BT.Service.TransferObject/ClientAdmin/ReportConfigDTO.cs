﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace BT.Service.TransferObject.ClientAdmin
{
    [DataContract]
    public class ReportConfigDTO
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public string nm { get; set; }
        [DataMember]
        public int said { get; set; }
        public string sanm { get; set; }
        [DataMember]
        public string desc { get; set; }
        [DataMember]
        public string media { get; set; }
        [DataMember]
        public string dlm { get; set; }
        [DataMember]
        public string pntsz { get; set; }
        [DataMember]
        public string pntori { get; set; }
        [DataMember]
        public List<ReportQueryDTO> qrys { get; set; }
        [DataMember]
        public List<ReportElementDTO> eles { get; set; }
        public ReportConfigDTO()
        {
            qrys = new List<ReportQueryDTO>();
            eles = new List<ReportElementDTO>();
        }
    }
    [DataContract]
    public class ReportQueryDTO
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public int dtcid { get; set; }
        [DataMember]
        public int idx { get; set; }
        [DataMember]
        public int rid { get; set; }
        [DataMember]
        public List<ReportQueryParamDTO> pms { get; set; }
        public ReportQueryDTO()
        {
            pms = new List<ReportQueryParamDTO>();
        }
    }
    [DataContract]
    public class ReportQueryParamDTO
    {
        [DataMember]
        public int qid { get; set; }
        [DataMember]
        public string nm { get; set; }
        [DataMember]
        public string op { get; set; }
    }
    [DataContract]
    public class ReportQueryParamValueDTO
    {
        [DataMember]
        public int qid { get; set; }
        [DataMember]
        public string nm { get; set; }
        [DataMember]
        public string value { get; set; }
    }
    [DataContract]
    public class ReportElementDTO
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public string iconid { get; set; }
        [DataMember]
        public int rid { get; set; }
        [DataMember]
        public string nm { get; set; }
        [DataMember]
        public string piconid { get; set; }
        [DataMember]
        public string typ { get; set; }
        [DataMember]
        public string sz { get; set; }
        [DataMember]
        public string pos { get; set; }
        [DataMember]
        public int ep { get; set; }
        [DataMember]
        public int qryid { get; set; }//qry idx
        [DataMember]
        public string colnm { get; set; }
        [DataMember]
        public string fmt { get; set; }
        [DataMember]
        public string ffm { get; set; }
        [DataMember]
        public string fwt { get; set; }
        [DataMember]
        public float fsz { get; set; }
        [DataMember]
        public string fcl { get; set; }
        [DataMember]
        public int bgimg { get; set; }
        [DataMember]
        public string bgcl { get; set; }
        [DataMember]
        public string bd { get; set; }
        [DataMember]
        public int bdwt { get; set; }
        [DataMember]
        public string bdcl { get; set; }
        [DataMember]
        public string bdsty { get; set; }
        [DataMember]
        public ReportFooterDTO ft { get; set; }
        [DataMember]
        public ReportTextDTO txt { get; set; }
        [DataMember]
        public List<ReportTableColumnDTO> tblcols { get; set; }
        public ReportElementDTO()
        {
            tblcols = new List<ReportTableColumnDTO>();
        }
    }
    [DataContract]
    public class ReportFooterDTO
    {
        [DataMember]
        public int eid { get; set; }
        [DataMember]
        public string pna { get; set; }
        [DataMember]
        public string ts { get; set; }
    }
    [DataContract]
    public class ReportTextDTO
    {
        [DataMember]
        public int eid { get; set; }
        [DataMember]
        public string alg { get; set; }
        [DataMember]
        public string cnt { get; set; }
        [DataMember]
        public string ts { get; set; }
        [DataMember]
        public string fund { get; set; }
    }
    [DataContract]
    public class ReportTableColumnDTO
    {
        [DataMember]
        public int id { get; set; }
        [DataMember]
        public int tid { get; set; }
        [DataMember]
        public string nm { get; set; }
        [DataMember]
        public string dbnm { get; set; }
        [DataMember]
        public int idx { get; set; }
        [DataMember]
        public int wt { get; set; }
        [DataMember]
        public string align { get; set; }
        [DataMember]
        public string fmt { get; set; }
        [DataMember]
        public string ftyp { get; set; }
        [DataMember]
        public string ftxt { get; set; }
    }
}
