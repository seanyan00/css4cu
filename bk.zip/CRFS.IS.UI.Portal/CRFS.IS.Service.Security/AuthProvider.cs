﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Data.SqlClient;
using System.DirectoryServices.AccountManagement;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Data;

namespace CRFS.IS.Service.Security
{
    public class AuthProvider
    {
        private static IConfiguration _config;
        private static ILogger _log;

        public AuthProvider(IConfiguration config, ILogger log)
        {
            if (_config == null)
                _config = config;
            if (_log == null)
                _log = log;
        }
        public GetAppRoleReply GetAppRoleAD(GetAppRoleRequest request)
        {
            var ret = new GetAppRoleReply{
                Message = "",
                Token = ""
            };
            var uname = request.Uname.Substring(request.Uname.LastIndexOf('\\') + 1);

            try
            {
                var uid = new ApplicationConfigurationContext().LkpUsers.Where(x => x.Login == uname && x.Active)
                                                               .Select(x => x.UserId)
                                                               .SingleOrDefault();
                var appid = new ApplicationConfigurationContext().LkpApplications.Where(x => x.ApplicationName == request.Appname
                                                                                          && (x.Active ?? false))
                                                                 .Select(x => x.ApplicationId).SingleOrDefault();
                if (uid > 0 && appid > 0) 
                {
                    using (var adctx = new PrincipalContext(ContextType.Domain, Constant.DOMAIN))
                    {
                        var success = adctx.ValidateCredentials(request.Uname, request.Pwd);
                        using (var conn = new PortalContext().Database.GetDbConnection())
                        {
                            var locked = 1;
                            var cmdtxt = "usp_GetLoginStatus";
                            var cmd = conn.CreateCommand();
                            cmd.CommandText = cmdtxt;
                            cmd.CommandType = System.Data.CommandType.StoredProcedure;
                            var par = new SqlParameter("@p_uid", uid);
                            cmd.Parameters.Add(par);
                            par = new SqlParameter("@p_appid", appid);
                            cmd.Parameters.Add(par);
                            par = new SqlParameter("@p_success", success);
                            cmd.Parameters.Add(par);
                            SqlParameter op = new SqlParameter("@p_locked", System.Data.SqlDbType.Int);
                            op.Direction = System.Data.ParameterDirection.Output;
                            cmd.Parameters.Add(op);
                            
                            conn.Open();
                            cmd.ExecuteNonQuery();

                            locked = (int)op.Value;
                            
                            if(locked == 1)
                            {
                                ret.Message = "Account is temporarily locked due to failed logins";
                            }
                            else if (!success)
                            {
                                ret.Message = "Incorrect Username/Password";
                            } else
                            {
                                List<AppRole> lapprole = new List<AppRole>();

                                conn.Close(); //ef core doesn't support concurrent dbcontexts?
                                lapprole = new PortalContext().VwUserPermit.Where(x => x.Uid == uid)
                                                                           .Select(x => new AppRole
                                                                           {
                                                                               Appid = x.AppId,
                                                                               Appname = x.AppName,
                                                                               Apppermit = x.AppPermit,
                                                                               Roleid = x.Gid,
                                                                               Rolename = x.Gname,
                                                                               Uiid = x.Uiid,
                                                                               Uilevel = x.AccessLevel,
                                                                               Uiname = x.Uiname,
                                                                               Uipermit = x.Uipermit,
                                                                               Uitype = x.Uitype,
                                                                               Uid = x.Uid,
                                                                               Uname = x.Login
                                                                           }).ToList();
                                ret.Approles.AddRange(lapprole);
                                ret.Token = SessionProvider.GetSessionToken(request.Uname, request.Appname, _config);
                                ret.Message = "Success";
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _log.LogError("GetAppRoleAD: " + ex.Message);
                ret.Message = "Internal Error";
                ret.Token = "";
            }
            return ret;
        }
    }
}
