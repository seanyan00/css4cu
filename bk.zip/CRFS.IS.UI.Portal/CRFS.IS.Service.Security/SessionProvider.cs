﻿using System;
using System.Linq;
using System.Collections.Generic;
using Microsoft.Extensions.Configuration;

using CRFS.IS.Service.Data;
using CRFS.IS.Service.Common;

namespace CRFS.IS.Service.Security
{
    public static class SessionProvider
    {
        private static IConfiguration _config;
      
        public static string GetSessionToken(string uname, string appname, 
                IConfiguration config)
        {
            var ret = "";
            var un = uname.Substring(uname.LastIndexOf('\\') + 1);
            _config = config;
         
            var appsettings = _config.GetSection("AppSettings").Get<AppSettings>();
        
            if (appsettings.CompressorUsers.Split(";").Contains(un))
            {
                ret = Guid.NewGuid().ToString();
                try
                {
                    using (var ctx = new PortalContext())
                    {
                        ctx.TblSession.Add(new TblSession
                        {
                            Active = true,
                            AppFrom = appname,
                            StartTime = DateTime.Now,
                            Token = ret,
                            Uname = un
                        });
                        ctx.SaveChanges();
                    }
                } catch(Exception ex)
                {
                    throw new Exception("GetSessionToken: " + ex.Message);
                }
            }
            
            return ret;
        }
        public static bool IsValidSession(string token, string actname, bool sessiondetail = false)
        {
            var ret = false;
            if (_config == null)
                throw new Exception("Null config in Session validation");

            try
            {
                using(var ctx = new PortalContext())
                {
                    var r = ctx.TblSession.Where(x => x.Token == token).SingleOrDefault();
                    if (r == null)
                        return ret;

                    var recordedtime = r.StartTime;

                    var rd = ctx.TblSessionDetail.Where(x => x.SessionId == r.Id).ToList();
                    if(rd.Count > 0)
                    {
                        recordedtime = rd.Max(x => x.EnteredDate);
                    }
                    var appsettings = _config.GetSection("AppSettings").Get<AppSettings>();

                    if (recordedtime.AddMinutes(appsettings.CompressorSessionIdleTime) >= DateTime.Now)
                    {
                        ret = true;
                        //if (sessiondetail)
                        //{
                            ctx.TblSessionDetail.Add(new TblSessionDetail
                            {
                                SessionId = r.Id,
                                EnteredDate = DateTime.Now,
                                SvcName = actname
                            });
                            ctx.SaveChanges();
                       // }
                    } 
                }
            }
            catch(Exception ex)
            {
                throw new Exception("Session Validation exception:" + ex.Message);
            }
            return ret;
        }
    }
}
