﻿using System;
using System.Net.Mail;
using System.Net.Mime;
using System.IO;

namespace CRFS.IS.Service.Util
{
    public static class Email
    {
        public static void SendMail(string sendfrom, string sendto,
                         string subject, string text, string[] files,
                         string mailserver)
        {
            var mmsg = new MailMessage(sendfrom, sendto, subject, text);
            mmsg.IsBodyHtml = true;

            try
            {
                if (files != null && files.Length > 0)
                {
                    foreach (var f in files)
                    {
                        Attachment data = new Attachment(f, MediaTypeNames.Application.Octet);
                        //TODO: encoding, setpayload
                        data.TransferEncoding = TransferEncoding.Base64;

                        ContentDisposition dispos = data.ContentDisposition;
                        dispos.DispositionType = DispositionTypeNames.Attachment;
                        dispos.FileName = Path.GetFileName(f);

                        mmsg.Attachments.Add(data);
                    }
                }

                SmtpClient client = new SmtpClient(mailserver);

                client.Send(mmsg);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                foreach (var att in mmsg.Attachments)
                {
                    att.Dispose();
                }
            }
        }
    }
}
