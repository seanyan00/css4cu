﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;

using BitMiracle.Docotic.Pdf;
using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Data;
using CRFS.IS.Service.Common;

namespace CRFS.IS.Service.Util
{
    public static class PDFCompressor
    {
        private const string EmailMessage = "Source Directory: {0}<br />Target Directory: {1}<br />Error Directory: {2}"
                                          + "<br />Total files: {3}; Compressed: {4}; Large Files: {5}";
        private static bool _running;

        public static bool Running { get { return _running; } }
        private static volatile object _locker = new object();

        private static CancellationToken _token;


        private static void ClearRunningStatus(CompressRequest request)
        {
            var dir = new DirectoryInfo(request.TargetDir);
            foreach (var f in dir.GetFiles()) f.Delete();
            dir = new DirectoryInfo(request.ErrorDir);
            foreach (var f in dir.GetFiles()) f.Delete();
            lock (_locker)
            {
                _running = false;
            }
        }
        public static CompressReply Compress(CancellationToken token, CompressRequest request,
            ILogger logger, string session, AppSettings appsetting)
        {
            var ret = new CompressReply();
            if (_running)
                return ret;
            lock (_locker)
            {
                _running = true;
            }
            _token = token;

            var comconfigs = new List<TblClientPdfcompression>();
            var portalctx = new PortalContext();

            try
            {
                using (var ctx = new ApplicationConfigurationContext())
                {
                    comconfigs = ctx.TblClientPdfcompression.Where(x => (request.ClientId == 0 || x.ClientId == request.ClientId)
                                                               && x.Active).Include(x => x.Client).ToList();
                }
                TblClientPdfcompressionBatch batch = new TblClientPdfcompressionBatch
                {
                    Id = 0,
                    RunBy = string.IsNullOrEmpty(session) ? "Scheduler"
                                                           : portalctx.TblSession.Single(x => x.Token == session).Uname,
                    RunDate = DateTime.Now
                };
                if (comconfigs.Count > 0)
                {
                    portalctx.TblClientPdfcompressionBatch.Add(batch);
                    portalctx.SaveChanges();
                }
                foreach (var conf in comconfigs)
                {
                    if (_token.IsCancellationRequested)
                    {
                        ClearRunningStatus(request);
                        SessionMessage.Write("Cancelled", session, "Compress");
                        break;
                    }

                    var temp = new CompressRequest(request);
                    if (string.IsNullOrEmpty(request.SourceDir)
                       || string.IsNullOrEmpty(request.TargetDir)
                       || string.IsNullOrEmpty(request.ErrorDir)
                       || request.Limit == 0)
                    {
                        temp.ClientId = conf.ClientId;
                        temp.SourceDir = string.IsNullOrEmpty(temp.SourceDir) ? conf.SourceFolder : temp.SourceDir;
                        temp.TargetDir = string.IsNullOrEmpty(temp.TargetDir) ? conf.DestinationFolder : temp.TargetDir;
                        temp.ErrorDir = string.IsNullOrEmpty(temp.ErrorDir) ? conf.ErrorFolder : temp.ErrorDir;
                        temp.Limit = temp.Limit == 0 ? (conf.SizeLimitMb ?? 0) : temp.Limit;
                    }

                    //BitMiracle.Docotic.LicenseManager.AddLicenseData("6EOI3-DXN35-5M8G6-8QGW9-Y18Z5");
                    BitMiracle.Docotic.LicenseManager.AddLicenseData("7I5L5-MDT40-T0NHP-LOG5W-VL2UG");
                    var cpFile = "";

                    string[] filePaths = Directory.GetFiles(temp.SourceDir,
                                             "*.pdf",
                                             SearchOption.TopDirectoryOnly);

                    if(filePaths.Length == 0)
                    {
                        portalctx.TblClientPdfcompressionBatchDetail.Add(new TblClientPdfcompressionBatchDetail
                        {
                            BatchId = batch.Id,
                            ClientId = conf.ClientId,
                            FileName = "",
                            FileSizeAfter = 0,
                            FileSizeBefore = 0,
                            TimeEnd = DateTime.Now,
                            TimeStart = DateTime.Now,
                            Status = "Not Compressed",
                            Reason = "No File In Directory"
                        });
                        portalctx.SaveChanges();
                    }

                    DateTime timestart;
                    string status = "Compressed";
                    string reason = "";
                    FileInfo fi = null;

                    SessionMessage.Write("Total files to compress: " + filePaths.Length, session, "Compress");
                    var comcount = 0;
                    var largecount = 0;
                    foreach (var fn in filePaths)
                    {
                        if (_token.IsCancellationRequested)
                        {
                            ClearRunningStatus(request);
                            SessionMessage.Write("Cancelled", session, "Compress");
                            break;
                        }
                        cpFile = Path.Combine(temp.TargetDir,
                                string.Format("{0}{1}",
                                Path.GetFileNameWithoutExtension(fn),
                                //   DateTime.Now.ToString("yyyyMMddHHmmss"),
                                Path.GetExtension(fn)));

                        var fi1 = new FileInfo(fn);
                        if (fi1.Length <= temp.Limit * Constant.MB)
                        {
                            File.Move(fn, cpFile);
                            status = "Not Compressed";
                            reason = "Under Limit";
                            SessionMessage.Write(Path.GetFileName(fn) + " is under limitation", session, "Compress");
                            portalctx.TblClientPdfcompressionBatchDetail.Add(new TblClientPdfcompressionBatchDetail
                            {
                                BatchId = batch.Id,
                                ClientId = conf.ClientId,
                                FileName = fn,
                                FileSizeAfter = fi1 == null ? 0 : (int)fi1.Length / Constant.MB,
                                FileSizeBefore = (int)(new FileInfo(fn).Length / Constant.MB),
                                TimeEnd = DateTime.Now,
                                TimeStart = DateTime.Now,
                                Status = status,
                                Reason = reason
                            });
                            portalctx.SaveChanges();
                            continue;
                        }

                        timestart = DateTime.Now;
                        status = "Compressed";
                        reason = "";

                        SessionMessage.Write("Starting processing " + Path.GetFileName(fn) + " target " + cpFile, session, "Compress");
                        using (var pdf = new PdfDocument(fn))
                        {
                            try
                            {
                                SessionMessage.Write("Total pages " + pdf.Pages.Count, session, "Compress");
                                var pagecount = 0;
                                var loop = 0;
                                foreach (PdfPage page in pdf.Pages)
                                {
                                    _token.ThrowIfCancellationRequested();
                                    ++pagecount;
                                    ++loop;
                                    if (loop == 50)
                                    {
                                        SessionMessage.Write("Processing page " + pagecount, session, "Compress");
                                        loop = 0;
                                    }

                                    foreach (PdfPaintedImage painted in page.GetPaintedImages())
                                    {
                                        _token.ThrowIfCancellationRequested();

                                        PdfImage image = painted.Image;

                                        if (image.IsInline)
                                            continue;

                                        if (image.IsMask || image.Mask != null || image.Width < 8 || image.Height < 8)
                                            continue;

                                        int width = Math.Max(1, (int)(painted.Bounds.Width * 1));
                                        int height = Math.Max(1, (int)(painted.Bounds.Height * 1));
                                        if (width >= image.Width || height >= image.Height)
                                        {
                                            if (image.ComponentCount == 1 && image.BitsPerComponent == 1 &&
                                                image.Compression != PdfImageCompression.Group4Fax)
                                            {
                                                image.RecompressWithGroup4Fax();
                                            }
                                            else if (image.BitsPerComponent == 8 &&
                                                image.ComponentCount >= 3 &&
                                                image.Compression != PdfImageCompression.Jpeg &&
                                                image.Compression != PdfImageCompression.Jpeg2000)
                                            {
                                                image.RecompressWithJpeg2000(10);
                                                // or image.RecompressWithJpeg();
                                            }
                                        }
                                        else
                                        {
                                            if (image.Compression == PdfImageCompression.Group4Fax ||
                                                image.Compression == PdfImageCompression.Group3Fax)
                                            {
                                                int ratio = Math.Min(image.Width / width, image.Height / height);
                                                image.ResizeTo(image.Width / ratio, image.Height / ratio, PdfImageCompression.Group4Fax);
                                            }
                                            else if (image.ComponentCount >= 3 && image.BitsPerComponent == 8)
                                            {
                                                image.ResizeTo(width, height, PdfImageCompression.Jpeg, 90);
                                            }
                                            else
                                            {
                                                image.ResizeTo(width, height, PdfImageCompression.Flate, 9);
                                            }
                                        }
                                    }
                                }

                                pdf.SaveOptions.Compression = PdfCompression.Flate;
                                pdf.SaveOptions.UseObjectStreams = true;
                                pdf.SaveOptions.RemoveUnusedObjects = true;
                                pdf.SaveOptions.OptimizeIndirectObjects = true;
                                pdf.SaveOptions.WriteWithoutFormatting = true;

                                pdf.RemoveStructureInformation();

                                pdf.FlattenControls();

                                pdf.Metadata.Basic.Clear();
                                pdf.Metadata.DublinCore.Clear();
                                pdf.Metadata.MediaManagement.Clear();
                                pdf.Metadata.Pdf.Clear();
                                pdf.Metadata.RightsManagement.Clear();
                                pdf.Metadata.Custom.Properties.Clear();

                                foreach (XmpSchema schema in pdf.Metadata.Schemas)
                                    schema.Properties.Clear();

                                pdf.Info.Clear(false);
                                pdf.ReplaceDuplicateFonts();
                                pdf.RemoveUnusedResources();
                                pdf.Save(cpFile);
                                /* Donald 12/30/19
                                 We are copying everything on the backend the second before we sent it to client, 
                                 so we don’t need the huge copies. 
                                 */
                                File.Delete(fn);

                                fi = new FileInfo(cpFile);
                                if (fi.Length > temp.Limit * Constant.MB)
                                {
                                    ++largecount;
                                    var fname = Path.GetFileName(cpFile);
                                    File.Move(cpFile, Path.Combine(temp.ErrorDir, fname));
                                    status = "Error";
                                    reason = "Limit Exceeded";
                                    SessionMessage.Write(Path.GetFileName(fn) + " has been processed but moved to error folder",
                                        session, "Compress");
                                }
                                else
                                {
                                    ++comcount;
                                    status = "Compressed";
                                    SessionMessage.Write("Completed processing " + Path.GetFileName(fn), session, "Compress");
                                }
                            }
                            catch (Exception ex)
                            {
                                ClearRunningStatus(temp);
                                // logger.LogError("PDFCompressor:" + ex.Message);
                                status = "Error";
                                reason = ex.Message;
                                if (ex is TaskCanceledException || ex is OperationCanceledException)
                                {
                                    SessionMessage.Write("Cancelled", session, "Compress");
                                }
                                else
                                    SessionMessage.Write("Exception: " + ex.Message, session, "Compress");

                                throw new Exception(ex.Message);
                            }
                            finally
                            {
                                pdf.Dispose();
                                portalctx.TblClientPdfcompressionBatchDetail.Add(new TblClientPdfcompressionBatchDetail
                                {
                                    BatchId = batch.Id,
                                    ClientId = conf.ClientId,
                                    FileName = fn,
                                    FileSizeAfter = fi == null ? 0 : (int)fi.Length / Constant.MB,
                                    FileSizeBefore = (int)(new FileInfo(fn).Length / Constant.MB),
                                    TimeEnd = DateTime.Now,
                                    TimeStart = timestart,
                                    Status = status,
                                    Reason = reason
                                });
                                portalctx.SaveChanges();
                            }
                        }
                    }
                    if (filePaths.Length > 0 && conf.NotifyCrfsDl.Length > 0)
                    {
                        Email.SendMail("DoNotReply@crfservices.com", conf.NotifyCrfsDl,
                                      "PDF Compression summary for " + conf.Client.ClientName,
                                      string.Format(EmailMessage, temp.SourceDir, temp.TargetDir, temp.ErrorDir,
                                                                  filePaths.Length, comcount, largecount),
                                      null,
                                      appsetting.MailServer);
                    }
                }
            }
            catch (Exception ex)
            {
                logger.LogError("PDFCompressor:" + ex.Message);
                /*  if (ex is TaskCanceledException || ex is OperationCanceledException)
                  {
                      SessionMessage.Write("Cancelled", session);
                  }
                  else*/
                SessionMessage.Write("Exception: " + ex.Message, session, "Compress");
            }
            finally
            {
                portalctx.Dispose();
                lock (_locker)
                {
                    _running = false;
                }
                SessionMessage.Write("Done", session, "Compress");
            }
            return ret;
        }
    }
}
