﻿using System;

namespace CRFS.IS.Service.Common
{
    public static class Constant
    {
        public const int MB = 1000000;
    }
}
