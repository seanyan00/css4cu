﻿namespace CRFS.IS.Service.Common
{
    public class AppSettings
    {
        public int Scheduler_Interval { get; set; }
        public string CompressorUsers { get; set; }
        public int CompressorSessionIdleTime { get; set; }
        public string MailServer { get; set; }
    }
}
