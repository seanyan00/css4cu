﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.GRpc;
using CRFS.IS.UI.Portal.Models;
using CRFS.IS.UI.Portal.Extensions;

namespace CRFS.IS.UI.Portal.Controllers
{
    public class AccountController : Controller
    {
        private readonly ILogger<AccountController> _logger;
        private readonly IConfiguration _config;

        public AccountController(ILogger<AccountController> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
        }
        [HttpGet]
        [AllowAnonymous]
        public IActionResult Login()
        {
            return View(new LoginViewModel());
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Login(LoginViewModel loginmodel, string returnurl)
        {
            string msg = "";

            if (!ModelState.IsValid)
            {
                msg = string.Join("; ", ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage));
            }
            else
            {
                msg = LoginUser(loginmodel.Username, loginmodel.Password);
                if (msg == "Success")
                {
                    var claims = new List<Claim>
                                    {
                                       new Claim(ClaimTypes.Name, loginmodel.Username)
                                    };

                    var userIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                    await HttpContext.SignInAsync(
                    CookieAuthenticationDefaults.AuthenticationScheme,
                    new ClaimsPrincipal(userIdentity));

                    if (Url.IsLocalUrl(returnurl))
                        return Redirect(returnurl);
                    else
                        return Redirect("/");
                }
            }
            loginmodel.Message = msg;

            return View(loginmodel);
        }

        private string LoginUser(string username, string password)
        {
            try
            {
                var channel = ChannelHelper.GetChannel(_config);

                var client = new SecurityProvider.SecurityProviderClient(channel);
                var reply = client.GetAppRoleAD(new GetAppRoleRequest { Uname = username, Pwd = password, Appname = "Portal.Home" });

                if (!string.IsNullOrEmpty(reply.Token))
                {
                    var usergrants = new UserGrantViewModel();
                    foreach (var ug in reply.Approles)
                    {
                        usergrants.UserGrants.Add(new UserGrant
                        {
                            AppId = ug.Appid,
                            AppName = ug.Appname,
                            AppPermit = ug.Apppermit,
                            RId = ug.Roleid,
                            RName = ug.Rolename,
                            UId = ug.Uid,
                            UName = ug.Uname,
                            UIId = ug.Uiid,
                            UILevel = ug.Uilevel,
                            UIName = ug.Uiname,
                            UIPermit = ug.Uipermit,
                            UIType = ug.Uitype
                        });
                    }
                    HttpContext.Session.Clear();
                    HttpContext.Session.Set<string>("SessionToken", reply.Token);
                    HttpContext.Session.Set<UserGrantViewModel>("UserGrants", usergrants);
                    return "Success";
                }
                return reply.Message;
            } catch(Exception ex)
            {
                return ex.Message;
            }
        }
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Clear();

            return View("/Account/Login");
        }

    }
}