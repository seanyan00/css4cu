﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Session;
using Microsoft.Extensions.Configuration;
using Grpc.Net.Client;
using Grpc.Core;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.GRpc;
using CRFS.IS.UI.Portal.Models;
using CRFS.IS.UI.Portal.Extensions;

namespace CRFS.IS.UI.Portal.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IConfiguration _config;

        public HomeController(ILogger<HomeController> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
        }
        public IActionResult Index()
        {
            ViewBag.UName = User.Identity.Name;

            if(string.IsNullOrEmpty(HttpContext.Session.Get<string>("SessionToken"))
                || HttpContext.Session.Get<UserGrantViewModel>("UserGrants") == null)
                  return Json(new { success = false, message = "No domain session variables" });
            /*  if (string.IsNullOrEmpty(HttpContext.Session.Get<string>("SessionToken")))
              {
                  var channel = ChannelHelper.GetChannel(_config);

                  var client = new SecurityProvider.SecurityProviderClient(channel);
                  var reply = client.GetSessionToken(new GetSessionTokenRequest { Uname = User.Identity.Name, Appname = "Portal.Home" });

                  HttpContext.Session.Set<string>("SessionToken", reply.Token);
              }
              if (HttpContext.Session.Get<UserGrantViewModel>("UserGrants") == null)
              {
                  var channel = ChannelHelper.GetChannel(_config);

                  var client = new SecurityProvider.SecurityProviderClient(channel);
                  var reply = client.GetAppRoleAD(new GetAppRoleRequest { Uname = User.Identity.Name,  Pwd = "Ionsysxy!124",  Appname = "Portal.Home" });

                  if (!string.IsNullOrEmpty(reply.Token))
                  {
                      var usergrants = new UserGrantViewModel();
                      foreach(var ug in reply.Approles)
                      {
                          usergrants.UserGrants.Add(new UserGrant
                          {
                              AppId = ug.Appid,
                              AppName = ug.Appname,
                              AppPermit = ug.Apppermit,
                              RId = ug.Roleid,
                              RName = ug.Rolename,
                              UId = ug.Uid,
                              UName = ug.Uname,
                              UIId = ug.Uiid,
                              UILevel = ug.Uilevel,
                              UIName = ug.Uiname,
                              UIPermit = ug.Uipermit,
                              UIType = ug.Uitype
                          });
                      }
                      HttpContext.Session.Set<UserGrantViewModel>("UserGrants", usergrants);
                  } else
                  {
                      return Json(new { success = false, message = reply.Message });
                  }
              }*/
            return View();
        }
        [Authorize(Policy= "TokenExists")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Compress(RunCompressViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View("Error"); 
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new PdfCompressor.PdfCompressorClient(channel);
                client.CompressAsync(new CompressRequest
                {
                    ClientId = model.ClientId,
                    SourceDir = model.SourceDir == null ? "" : model.SourceDir,
                    TargetDir = model.TargetDir == null ? "" : model.TargetDir,
                    ErrorDir = model.ErrorDir == null ? "" : model.ErrorDir,
                    Limit = model.Limit ?? 0
                }, mdata);
            }catch(Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(new { success = true, message = "Processing..." });
        }
        [Authorize(Policy = "TokenExists")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Write, "Compressor")]
        public IActionResult SaveConfig(CompressConfigViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return Json(new
                {
                    success = false,
                    message = string.Join("; ", ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage))
                });
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new PdfCompressor.PdfCompressorClient(channel);
                var reply = client.SaveConfig(new Config
                {
                    ClientId = model.ClientId,
                    SourceDir = model.SourceDir,
                    TargetDir = model.TargetDir,
                    ErrorDir = model.ErrorDir,
                    Limit = model.Limit ?? 0,
                    Cron = model.Cron,
                    CrfsDL = model.CrfsDL,
                    Comment = string.IsNullOrEmpty(model.Comment) ? "" : model.Comment,
                    ClientDL = string.IsNullOrEmpty(model.ClientDL) ? "" : model.ClientDL,
                    Active = model.Active ? 1 : 0
                }, mdata);
                return Json(new { success = true, message = reply.Msg });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }
        public IActionResult GetCompressConfig(int clientid)
        {
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new PdfCompressor.PdfCompressorClient(channel);
                var reply = client.GetConfig(new GetConfigRequest
                {
                   Id = clientid
                }, mdata);
                return Json(reply);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }
        public IActionResult GetSessionMsg(int id)
        {
            var ret = new List<KeyValuePair<string, string>>();

            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };

            try
            {
                var client = new Common.CommonClient(channel);
                var temp = client.GetKeyValueList(new GetKeyValueListRequest
                {
                    Id = id.ToString(),
                    Type = "SessionMessage"
                }, mdata);
                foreach (var item in temp.KVList)
                {
                    ret.Add(new KeyValuePair<string, string>(item.Key, item.Value));
                }
            }
            catch (Exception) { //drop it 
            }
            return Json(ret);
        }
        public IActionResult Cancel()
        {
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };

            var client = new PdfCompressor.PdfCompressorClient(channel);
            client.CancelAsync(new CancelRequest {}, mdata);
            return Json(new { success = true, message = ""});
        }
        public IActionResult GetCompressHist()
        {
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };

            var client = new PdfCompressor.PdfCompressorClient(channel);
            var reply = client.GetHistory(new GetHistoryRequest { }, mdata);
            var list = new List<History>();
            foreach(var h in reply.Hists)
            {
                list.Add(h);
            }
            return new JsonStringResult<History>(list);
        }
        public IActionResult GetCompressHistDetail(int batchid)
        {
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };

            var client = new PdfCompressor.PdfCompressorClient(channel);
            var reply = client.GetBatchDetail(new GetBatchDetailRequest { BatchId = batchid }, mdata);
            var list = new List<BatchDetail>();
            foreach (var h in reply.Details)
            {
                list.Add(h);
            }
            return new JsonStringResult<BatchDetail>(list);
        }
        [Authorize(Policy = "TokenExists")]
        public IActionResult GetDDL(string type)
        {
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };

            var client = new Common.CommonClient(channel);
            var reply = client.GetKeyValueList(new GetKeyValueListRequest
            {
                Type = "Client",
                Id = "0"
            }, mdata);

            var ret = new StringBuilder();
            string end = null;

            ret.Append("<option value='0'>-- Select --</option>");
            end = "";
            foreach(var item in reply.KVList)
            {
                ret.Append("<option value='" + item.Key + "'>" + item.Value + "</option>");
            }
            ret.Append(end);
            // return Json(reply);
            return Content(ret.ToString());
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
