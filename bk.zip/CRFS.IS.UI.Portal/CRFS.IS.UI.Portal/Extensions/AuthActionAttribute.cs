﻿using System;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;

using CRFS.IS.Service.Common;

namespace CRFS.IS.UI.Portal.Extensions
{
    internal class AuthActionAttribute : AuthorizeAttribute
    {
        const string POLICY_PREFIX = "AuthAction";
        const string POLICY_PREFIX_Privilege = "AuthAction_Privilege";
        const string POLICY_PREFIX_Appname = "AuthAction_Appname";

        public AuthActionAttribute(Constant.UIPrivilege privilege, string appname)
        {
           Privilege = privilege;
           Appname = appname;
        }

        // Get or set the Privilege property by manipulating the underlying Policy property
        public Constant.UIPrivilege Privilege
        {
            get
            {
                if (int.TryParse(Policy.Substring(POLICY_PREFIX_Privilege.Length), out var priv))
                {
                    return (Constant.UIPrivilege)priv;
                }
                return default(int);
            }
            set
            {
                Policy = Policy == null ? $"{POLICY_PREFIX_Privilege}{value.ToString("d")}" 
                                        : Policy + $";{POLICY_PREFIX_Privilege}{value.ToString("d")}";
            }
        }
        public string Appname
        {
            get
            {
                return Policy.Substring(POLICY_PREFIX_Appname.Length);
            }
            set
            {
                Policy = Policy == null ? $"{POLICY_PREFIX_Appname}{value}"
                                        : Policy + $";{POLICY_PREFIX_Appname}{value}";
            }
        }
    }
    internal class AuthActionPolicyProvider : IAuthorizationPolicyProvider 
     { 
         const string POLICY_PREFIX = "AuthAction";
         const string POLICY_PREFIX_Privilege = "AuthAction_Privilege";
         const string POLICY_PREFIX_Appname = "AuthAction_Appname";
         public DefaultAuthorizationPolicyProvider FallbackPolicyProvider { get; } 
  
         public AuthActionPolicyProvider(IOptions<AuthorizationOptions> options)
         { 
              FallbackPolicyProvider = new DefaultAuthorizationPolicyProvider(options); 
         } 
  
         public Task<AuthorizationPolicy> GetDefaultPolicyAsync() => FallbackPolicyProvider.GetDefaultPolicyAsync(); 
         public Task<AuthorizationPolicy> GetFallbackPolicyAsync() => FallbackPolicyProvider.GetDefaultPolicyAsync();

         public Task<AuthorizationPolicy> GetPolicyAsync(string policyname)
         { 
             if (policyname.StartsWith(POLICY_PREFIX, StringComparison.OrdinalIgnoreCase)) 
             {
                var val = policyname.Split(";");
                var privilege = val.FirstOrDefault(x => x.StartsWith(POLICY_PREFIX_Privilege, StringComparison.OrdinalIgnoreCase))
                               .Substring(POLICY_PREFIX_Privilege.Length).Select(x => Convert.ToInt32(x)).Single();

                var appname = val.FirstOrDefault(x => x.StartsWith(POLICY_PREFIX_Appname, StringComparison.OrdinalIgnoreCase))
                               .Substring(POLICY_PREFIX_Appname.Length);

                var policy = new AuthorizationPolicyBuilder(); 
                 policy.AddRequirements(new AuthActionRequirement((Constant.UIPrivilege)privilege, appname)); 
                 return Task.FromResult(policy.Build()); 
             } 
             return FallbackPolicyProvider.GetPolicyAsync(policyname); 
         } 
    } 
}
