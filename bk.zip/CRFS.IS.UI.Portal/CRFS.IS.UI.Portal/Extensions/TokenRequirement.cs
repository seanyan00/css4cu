﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Filters;

namespace CRFS.IS.UI.Portal.Extensions
{
    public class TokenRequirement: IAuthorizationRequirement
    {

    }
    public class TokenRequirementHandler : AuthorizationHandler<TokenRequirement>
    {
        IHttpContextAccessor _httpContextAccessor;

        public TokenRequirementHandler(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        protected override Task Handle​Requirement​Async(AuthorizationHandlerContext context, TokenRequirement requirement)
        {
            var token = _httpContextAccessor.HttpContext.Session.GetString("SessionToken");

            if (string.IsNullOrEmpty(token))
                context.Fail();
            else
            {
                context.Succeed(requirement);
            }

            return Task.CompletedTask;
        }
    }
}
