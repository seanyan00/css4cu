﻿using System;
using Microsoft.Extensions.Configuration;
using Grpc.Net.Client;

namespace CRFS.IS.UI.Portal.Extensions
{
    public static class ChannelHelper
    {
        public static GrpcChannel GetChannel(IConfiguration config)
        {
            var appsetting = config.GetSection("AppSettings").Get<Models.AppSettings>();
            AppContext.SetSwitch("System.Net.Http.SocketsHttpHandler.Http2UnencryptedSupport", true);
            
            return GrpcChannel.ForAddress("http://" + appsetting.Service_Address + ":" + appsetting.Service_Port);
        }
    }
}
