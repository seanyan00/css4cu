﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CRFS.IS.UI.Portal.Models
{
    public class CompressConfigViewModel
    {
        [Required]
        public int ClientId { get; set; }
        [Required]
        [StringLength(200, ErrorMessage = "MaxLength 200 exceeded")]
        public string SourceDir { get; set; }
        [Required]
        [StringLength(200, ErrorMessage = "MaxLength 200 exceeded")]
        public string TargetDir { get; set; }
        [Required]
        [StringLength(200, ErrorMessage = "MaxLength 200 exceeded")]
        public string ErrorDir { get; set; }
        [Required]
        public int? Limit { get; set; }
        [Required]
        [StringLength(50, ErrorMessage = "MaxLength 50 exceeded")]
        public string Cron { get; set; }
        [StringLength(2000, ErrorMessage = "MaxLength 2000 exceeded")]
        public string Comment { get; set; }
        [Required]
        [StringLength(200, ErrorMessage = "MaxLength 200 exceeded")]
        public string CrfsDL { get; set; }
        [MaxLength(200, ErrorMessage = "MaxLength 200 exceeded")]
        public string ClientDL { get; set; }
        public bool Active { get; set; }
    }
}
