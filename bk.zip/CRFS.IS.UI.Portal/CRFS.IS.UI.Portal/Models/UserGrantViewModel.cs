﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRFS.IS.UI.Portal.Models
{
    public class UserGrantViewModel
    {
        public List<UserGrant> UserGrants { get; set; }
        public UserGrantViewModel()
        {
            UserGrants = new List<UserGrant>();
        }
    }
    public class UserGrant
    {
        public int UId { get; set; }
        public string UName { get; set; }
        public int RId { get; set; }
        public string RName { get; set; }
        public int AppId { get; set; }
        public string AppName { get; set; }
        public int UIId { get; set; }
        public string UIType { get; set; }
        public string UIName { get; set; }
        public int AppPermit { get; set; }
        public int UILevel { get; set; }
        public int UIPermit { get; set; }
    }
}
