﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Grpc.Core;

using CRFS.IS.Service.Common;
using CRFS.IS.Service.GRpc;
using CRFS.IS.UI.Portal.Models;
using CRFS.IS.UI.Portal.Extensions;

namespace CRFS.IS.UI.Portal.Areas.Tools.Controllers
{
    [Area("Tools")]
    [Authorize]
    // [Route("Tools/[controller]/[action]")]
    public class PDFCompressorController : Controller
    {
        private readonly ILogger<PDFCompressorController> _logger;
        private readonly IConfiguration _config;
        public PDFCompressorController(ILogger<PDFCompressorController> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
        }
        public ActionResult Index()
        {
            return View();
        }

        [Authorize(Policy = "TokenExists")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Compress(RunCompressViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View("Error");
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new PdfCompressor.PdfCompressorClient(channel);
                client.CompressAsync(new CompressRequest
                {
                    ClientId = model.ClientId,
                    SourceDir = model.SourceDir == null ? "" : model.SourceDir,
                    TargetDir = model.TargetDir == null ? "" : model.TargetDir,
                    ErrorDir = model.ErrorDir == null ? "" : model.ErrorDir,
                    Limit = model.Limit ?? 0
                }, mdata);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
            return Json(new { success = true, message = "Processing..." });
        }
        [Authorize(Policy = "TokenExists")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthAction(Constant.UIPrivilege.Write, "Compressor")]
        public IActionResult SaveConfig(CompressConfigViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return Json(new
                {
                    success = false,
                    message = string.Join("; ", ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage))
                });
            }
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new PdfCompressor.PdfCompressorClient(channel);
                var reply = client.SaveConfig(new Config
                {
                    ClientId = model.ClientId,
                    SourceDir = model.SourceDir,
                    TargetDir = model.TargetDir,
                    ErrorDir = model.ErrorDir,
                    Limit = model.Limit ?? 0,
                    Cron = model.Cron,
                    CrfsDL = model.CrfsDL,
                    Comment = string.IsNullOrEmpty(model.Comment) ? "" : model.Comment,
                    ClientDL = string.IsNullOrEmpty(model.ClientDL) ? "" : model.ClientDL,
                    Active = model.Active ? 1 : 0
                }, mdata);
                return Json(new { success = true, message = reply.Msg });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }
        public IActionResult GetCompressConfig(int clientid)
        {
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };
            try
            {
                var client = new PdfCompressor.PdfCompressorClient(channel);
                var reply = client.GetConfig(new GetConfigRequest
                {
                    Id = clientid
                }, mdata);
                return Json(reply);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }
        public IActionResult GetSessionMsg(int id)
        {
            var ret = new List<KeyValuePair<string, string>>();

            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };

            try
            {
                var client = new Common.CommonClient(channel);
                var temp = client.GetKeyValueList(new GetKeyValueListRequest
                {
                    Id = id.ToString(),
                    Type = "SessionMessage"
                }, mdata);
                foreach (var item in temp.KVList)
                {
                    ret.Add(new KeyValuePair<string, string>(item.Key, item.Value));
                }
            }
            catch (Exception)
            { //drop it 
            }
            return Json(ret);
        }
        public IActionResult Cancel()
        {
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };

            var client = new PdfCompressor.PdfCompressorClient(channel);
            client.CancelAsync(new CancelRequest { }, mdata);
            return Json(new { success = true, message = "" });
        }
        public IActionResult GetCompressHist()
        {
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };

            var client = new PdfCompressor.PdfCompressorClient(channel);
            var reply = client.GetHistory(new GetHistoryRequest { }, mdata);
            var list = new List<History>();
            foreach (var h in reply.Hists)
            {
                list.Add(h);
            }
            return new JsonStringResult<History>(list);
        }
        public IActionResult GetCompressHistDetail(int batchid)
        {
            var channel = ChannelHelper.GetChannel(_config);

            var mdata = new Metadata {
                new Metadata.Entry( "SessionToken", HttpContext.Session.Get<string>("SessionToken"))
            };

            var client = new PdfCompressor.PdfCompressorClient(channel);
            var reply = client.GetBatchDetail(new GetBatchDetailRequest { BatchId = batchid }, mdata);
            var list = new List<BatchDetail>();
            foreach (var h in reply.Details)
            {
                list.Add(h);
            }
            return new JsonStringResult<BatchDetail>(list);
        }
      
    }
}