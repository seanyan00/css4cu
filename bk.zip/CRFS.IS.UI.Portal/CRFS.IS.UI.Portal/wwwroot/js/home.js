﻿/* jquery 3.3.1, jqgrid 5.4.0 */

function ajaxFailed(jqXHR, status, errmsg) { alert(errmsg); }
var compressor = {
    data: { done: false, dirty: true },
    init: function () {
        $("#tb_his").on('shown.bs.tab', function (e) {
            compressor.loadhistgrid();
        });
        $("select[id^='ddl_client']").on("change", function (e) {
            compressor.loadclientconfig(e);
        });
        $("#btn_cancel").on("click", function (e) {
            compressor.onbtncancelclick(e);
        });
        $("select, input:checkbox, input:text", "#fm_config").on("change input click", function () {
            compressor.data.dirty = true;
            compressor.clearinfo();
        });
        $("#fm_config").submit(function (e) {
            e.preventDefault();
            if (compressor.data.dirty) {
                var $this = $(this);
                var vm = $this.serialize();

                vm += "&Cron=" + $('#txt_min').val() + "+" + $('#txt_hr').val() + "+" + $('#txt_day').val()
                    + "+" + $('#txt_mon').val() + "+" + $('#txt_dow').val() + "&Active=" + ($("#chk_act").is(":checked") ? "True" : "False");
                $.ajax({
                    type: $this.attr('method'),
                    url: $this.attr('action'),
                    data: vm
                }).done(function (data) {
                    compressor.data.dirty = false;

                    if (data.success) {
                        compressor.showinfo("Data saved", false);
                    } else {
                        compressor.showinfo(data.message, true);
                    }
                }).fail(ajaxFailed);
            }
        });
        $("#fm_run").submit(function (e) {
            e.preventDefault();
            $("#txt_msg").val("");

            var $this = $(this);
            var vm = $this.serialize();
            compressor.data.done = false;

            $.ajax({
                type: $this.attr('method'),
                url: $this.attr('action'),
                data: vm
            }).done(function (data) {
                if (data.success) {
                    $("#hdn_msgid").val("0");
                    compressor.getsessionmsg();
                }
            }).fail(ajaxFailed);
        })
        compressor.loadddls();
    },
    onbtncancelclick: function (p) {
        p.preventDefault();
        $.ajax({
            url: cancelUrl,
            cache: false
        }).done(function (data) { }).fail(ajaxFailed);
    },
    onbeforerefresh: function () {
        $(this).jqGrid("setGridParam", { datatype: "json" });
        return [true, "", ""];
    },
    getsessionmsg: function () {
        var id = $("#hdn_msgid").val();
        $.ajax({
            url: getSessionMsgUrl + "?id=" + id,
            async: false,
            cache: false
        }).done(function (data) {
            var $text = $("#txt_msg");
            $.each(data, function () {
                if (this.Value === "Done" || this.Value == "Cancelled")
                    compressor.data.done = true;

                if (parseInt(this.Key) > parseInt(id)) {
                    id = this.Key;
                    $text.val($text.val() + "\n" + this.Value);
                    $text.scrollTop($text[0].scrollHeight - $text.height());
                }
            })
            $("#hdn_msgid").val(id);
            if (!compressor.data.done)
                window.setTimeout(compressor.getsessionmsg, 30000);

        }).fail(ajaxFailed);
    },
    loadddls: function () {
        $.ajax({
            url: getDDLUrl + "?type=client",
            success: function (data) {
                $("#ddl_client").html(data);
                $("#ddl_client_l").html(data);
            }
        })
    },
    loadclientconfig: function (p) {
        var id = $(p.target).val();
        if (id.length === 0)
            return;
        $.ajax({
            url: getCompressConfigUrl + "?clientid=" + id,
            success: function (data) {
                if (p.target.id === "ddl_client") {
                    $("#txt_srcdir").val(data.sourceDir);
                    $("#txt_tardir").val(data.targetDir);
                    $("#txt_errdir").val(data.errorDir);
                    $("#txt_limit").val(data.limit);
                } else {
                    $("#txt_srcdir_l").val(data.sourceDir);
                    $("#txt_tardir_l").val(data.targetDir);
                    $("#txt_errdir_l").val(data.errorDir);
                    $("#txt_limit_l").val(data.limit);
                    var cron = data.cron.split(" ");
                    if (cron.length < 5)
                        return;
                    $("#txt_min").val(cron[0]);
                    $("#txt_hr").val(cron[1]);
                    $("#txt_day").val(cron[2]);
                    $("#txt_mon").val(cron[3]);
                    $("#txt_dow").val(cron[4]);
                    $("#txt_crfsdl").val(data.crfsDL);
                    $("#txt_clientdl").val(data.clientDL);
                    $("#txt_comment").val(data.comment);

                    $("#chk_act").prop("checked", data.active ? "checked" : "");
                }
            }
        });

    },
    showinfo: function (p, p1) {
        var $lb = $(".lb-info");
        $lb.text(p);
        if (p1) {
            $lb.removeClass("bg-success");
            $lb.addClass("bg-danger");
        } else {
            $lb.removeClass("bg-danger");
            $lb.addClass("bg-success");
        }
    },
    clearinfo: function () {
        $(".lb-info").text("");
    },
    loadhistgrid: function () {
        $("#tbl_hist").jqGrid({
            url: getCompressHistUrl,
            mtype: "GET",
            datatype: "json",
            colModel: [
                { label: 'Id', name: 'BatchId', key: true, width: 50 },
                { label: 'Client', name: 'ClientName', width: 150 },
                { label: 'Run Date', name: 'RunDate', width: 150 },
                { label: 'Run By', name: 'RunBy', width: 150 },
                { label: 'Total Time', name: 'TtlTime', sortable: false, width: 80 },
                { label: 'Total File', name: 'TtlFile', sortable: false, width: 80 },
                { label: 'Compressed', name: 'TtlCompressed', sortable: false, width: 80 },
                { label: 'Error', name: 'TtlError', sortable: false, width: 150 }
            ],
            viewrecords: true,
            autowidth: true,
            height: 350,
            rowNum: 50,
            loadonce: true,
            pager: "#tbl_hist_pager",
            subGrid: true,
            subGridRowExpanded: function (subgrid_id, row_id) {
                var subgrid_table_id;
                subgrid_table_id = subgrid_id + "_t";
                $("#" + subgrid_id).html("<table id='" + subgrid_table_id + "' class='scroll'></table>");
                $("#" + subgrid_table_id).jqGrid({
                    url: getCompressHistDetailUrl + "?batchid=" + row_id,
                    datatype: "json",
                    colNames: ['', 'File Name', 'Size Before', 'Size After', 'Time Start', 'Time End', 'Status', 'Reason'],
                    colModel: [
                        { name: "DetailId", key: true, hidden: true },
                        { name: "FName", width: 150, sortable: false },
                        { name: "SizeBefore", width: 50, sortable: false },
                        { name: "SizeAfter", width: 50, sortable: false },
                        { name: "TimeStart", width: 110, sortable: false },
                        { name: "TimeEnd", width: 110, sortable: false },
                        { name: "Status", width: 80, sortable: false },
                        { name: "Reason", sortable: false }
                    ],
                    height: 'auto',
                    rowNum: 50,
                    sortname: 'DetailId',
                    sortorder: "asc"
                });
            }
        });
        $("#tbl_hist").navGrid("#tbl_hist_pager", {
            edit: false,
            add: false,
            del: false,
            search: false,
            beforeRefresh: compressor.onbeforerefresh
        });
    }
}
