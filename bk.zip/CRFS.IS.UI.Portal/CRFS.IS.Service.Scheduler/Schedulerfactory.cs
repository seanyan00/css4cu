﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace CRFS.IS.Service.Scheduler
{
    public class SchedulerFactory : ISchedulerFactory
    {
        private IConfiguration _config;
        private ILogger _logger;

        public SchedulerFactory(IConfiguration config, ILogger logger)
        {
            _config = config;
            _logger = logger;
        }
        public Scheduler Create()
        {
             return Scheduler.CreateInstance(_config, _logger);
        }
    }
}
