   #region Imports

    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Runtime.Serialization;
    using Debug = System.Diagnostics.Debug;

    #endregion

namespace CRFS.IS.Service.Scheduler.Cron
{
 

    public delegate ExceptionProvider CronFieldAccumulator(int start, int end, int interval, ExceptionHandler onError);

    [ Serializable ]
    public sealed class CronFieldImpl : IObjectReference
    {
        public static readonly CronFieldImpl Minute    = new CronFieldImpl(CronFieldKind.Minute, 0, 59, null);
        public static readonly CronFieldImpl Hour      = new CronFieldImpl(CronFieldKind.Hour, 0, 23, null);
        public static readonly CronFieldImpl Day       = new CronFieldImpl(CronFieldKind.Day, 1, 31, null);
        public static readonly CronFieldImpl Month     = new CronFieldImpl(CronFieldKind.Month, 1, 12, new[] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" });
        public static readonly CronFieldImpl DayOfWeek = new CronFieldImpl(CronFieldKind.DayOfWeek, 0, 6, new[] { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" });

        private static readonly CronFieldImpl[] _fieldByKind = new[] { Minute, Hour, Day, Month, DayOfWeek };

        private static readonly CompareInfo _comparer = CultureInfo.InvariantCulture.CompareInfo;
        private static readonly char[] _comma = new[] { ',' };

        private readonly CronFieldKind _kind;
        private readonly int _minValue;
        private readonly int _maxValue;
        private readonly string[] _names;

        public static CronFieldImpl FromKind(CronFieldKind kind)
        {
            if (!Enum.IsDefined(typeof(CronFieldKind), kind))
            {
                throw new ArgumentException(string.Format(
                    "Invalid Cron field kind. Valid values are {0}.",
                    string.Join(", ", Enum.GetNames(typeof(CronFieldKind)))), "kind");
            }

            return _fieldByKind[(int) kind];
        }

        private CronFieldImpl(CronFieldKind kind, int minValue, int maxValue, string[] names)
        {
            Debug.Assert(Enum.IsDefined(typeof(CronFieldKind), kind));
            Debug.Assert(minValue >= 0);
            Debug.Assert(maxValue >= minValue);
            Debug.Assert(names == null || names.Length == (maxValue - minValue + 1));

            _kind = kind;
            _minValue = minValue;
            _maxValue = maxValue;
            _names = names;
        }

        public CronFieldKind Kind
        {
            get { return _kind; }
        }

        public int MinValue
        {
            get { return _minValue; }
        }

        public int MaxValue
        {
            get { return _maxValue; }
        }

        public int ValueCount
        {
            get { return _maxValue - _minValue + 1; }
        }

        public void Format(ICronField field, TextWriter writer)
        {
            Format(field, writer, false);
        }

        public void Format(ICronField field, TextWriter writer, bool noNames)
        {
            if (field == null)
                throw new ArgumentNullException("field");

            if (writer == null)
                throw new ArgumentNullException("writer");

            var next = field.GetFirst();
            var count = 0;

            while (next != -1)
            {
                var first = next;
                int last;

                do
                {
                    last = next;
                    next = field.Next(last + 1);
                }
                while (next - last == 1);

                if (count == 0 
                    && first == _minValue && last == _maxValue)
                {
                    writer.Write('*');
                    return;
                }
                
                if (count > 0)
                    writer.Write(',');

                if (first == last)
                {
                    FormatValue(first, writer, noNames);
                }
                else
                {
                    FormatValue(first, writer, noNames);
                    writer.Write('-');
                    FormatValue(last, writer, noNames);
                }

                count++;
            }
        }

        private void FormatValue(int value, TextWriter writer, bool noNames)
        {
            Debug.Assert(writer != null);

            if (noNames || _names == null)
            {
                if (value >= 0 && value < 100)
                {
                    FastFormatNumericValue(value, writer);
                }
                else
                {
                    writer.Write(value.ToString(CultureInfo.InvariantCulture));
                }
            }
            else
            {
                var index = value - _minValue;
                writer.Write(_names[index]);
            }
        }

        private static void FastFormatNumericValue(int value, TextWriter writer)
        {
            Debug.Assert(value >= 0 && value < 100);
            Debug.Assert(writer != null);

            if (value >= 10)
            {
                writer.Write((char) ('0' + (value / 10)));
                writer.Write((char) ('0' + (value % 10)));
            }
            else
            {
                writer.Write((char) ('0' + value));
            }
        }

        public void Parse(string str, CronFieldAccumulator acc)
        {
            TryParse(str, acc, ErrorHandling.Throw);
        }

        public ExceptionProvider TryParse(string str, CronFieldAccumulator acc, ExceptionHandler onError)
        {
            if (acc == null)
                throw new ArgumentNullException("acc");

            if (string.IsNullOrEmpty(str))
                return null;

            try
            {
                return InternalParse(str, acc, onError);
            }
            catch (FormatException e)
            {
                return OnParseException(e, str, onError);
            }
            catch (CronException e)
            {
                return OnParseException(e, str, onError);
            }
        }

        private ExceptionProvider OnParseException(Exception innerException, string str, ExceptionHandler onError)
        {
            Debug.Assert(str != null);
            Debug.Assert(innerException != null);

            return ErrorHandling.OnError(
                       () => new CronException(string.Format("'{0}' is not a valid [{1}] Cron field expression.", str, Kind), innerException), 
                       onError);
        }

        private ExceptionProvider InternalParse(string str, CronFieldAccumulator acc, ExceptionHandler onError)
        {
            Debug.Assert(str != null);
            Debug.Assert(acc != null);

            if (str.Length == 0)
                return ErrorHandling.OnError(() => new CronException("A Cron field value cannot be empty."), onError);

            //
            // Next, look for a list of values (e.g. 1,2,3).
            //
    
            var commaIndex = str.IndexOf(",");

            if (commaIndex > 0)
            {
                ExceptionProvider e = null;
                var token = ((IEnumerable<string>) str.Split(_comma)).GetEnumerator();
                while (token.MoveNext() && e == null)
                    e = InternalParse(token.Current, acc, onError);
                return e;
            }
            
            var every = 1;

            //
            // Look for stepping first (e.g. */2 = every 2nd).
            // 

            var slashIndex = str.IndexOf("/");

            if (slashIndex > 0)
            {
                every = int.Parse(str.Substring(slashIndex + 1), CultureInfo.InvariantCulture);
                str = str.Substring(0, slashIndex);
            }

            //
            // Next, look for wildcard (*).
            //
    
            if (str.Length == 1 && str[0]== '*')
            {
                return acc(-1, -1, every, onError);
            }

            //
            // Next, look for a range of values (e.g. 2-10).
            //

            var dashIndex = str.IndexOf("-");
        
            if (dashIndex > 0)
            {
                var first = ParseValue(str.Substring(0, dashIndex));
                var last = ParseValue(str.Substring(dashIndex + 1));

                return acc(first, last, every, onError);
            }

            //
            // Finally, handle the case where there is only one number.
            //

            var value = ParseValue(str);

            if (every == 1)
                return acc(value, value, 1, onError);

            Debug.Assert(every != 0);
            return acc(value, _maxValue, every, onError);
        }

        private int ParseValue(string str)
        {
            Debug.Assert(str != null);

            if (str.Length == 0)
                throw new CronException("A Cron field value cannot be empty.");

            var firstChar = str[0];
        
            if (firstChar >= '0' && firstChar <= '9')
                return int.Parse(str, CultureInfo.InvariantCulture);

            if (_names == null)
            {
                throw new CronException(string.Format(
                    "'{0}' is not a valid [{3}] Cron field value. It must be a numeric value between {1} and {2} (all inclusive).",
                    str, _minValue.ToString(), _maxValue.ToString(), _kind.ToString()));
            }

            for (var i = 0; i < _names.Length; i++)
            {
                if (_comparer.IsPrefix(_names[i], str, CompareOptions.IgnoreCase))
                    return i + _minValue;
            }

            throw new CronException(string.Format(
                "'{0}' is not a known value name. Use one of the following: {1}.", 
                str, string.Join(", ", _names)));
        }

        object IObjectReference.GetRealObject(StreamingContext context)
        {
            return FromKind(Kind);
        }
    }
}
