﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace CRFS.IS.Service.Scheduler.Base
{
    interface IScheduledTask
    {
        void Run(CancellationToken token);
    }
}
