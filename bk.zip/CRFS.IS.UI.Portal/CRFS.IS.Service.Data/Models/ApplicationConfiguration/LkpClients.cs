﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service
{
    public partial class LkpClients
    {
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public string ClientDisplayName { get; set; }
        public string ClientLegalName { get; set; }
        public string ClientAbbreviation { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public bool Active { get; set; }
        public bool MarkedForDelete { get; set; }
        public DateTime EffectiveFromDate { get; set; }
        public DateTime EffectiveToDate { get; set; }

        public virtual LkpUsers EnteredByUser { get; set; }
        public virtual LkpUsers LastUpdateUser { get; set; }
        public virtual TblClientPdfcompression TblClientPdfcompression { get; set; }
    }
}
