﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service
{
    public partial class LkpUsers
    {
        public LkpUsers()
        {
            LkpClientsEnteredByUser = new HashSet<LkpClients>();
            LkpClientsLastUpdateUser = new HashSet<LkpClients>();
            LkpEmploymentTypesEnteredByUser = new HashSet<LkpEmploymentTypes>();
            LkpEmploymentTypesLastUpdateUser = new HashSet<LkpEmploymentTypes>();
            TblClientPdfcompressionAddedByNavigation = new HashSet<TblClientPdfcompression>();
            TblClientPdfcompressionUpdatedByNavigation = new HashSet<TblClientPdfcompression>();
        }

        public int UserId { get; set; }
        public string Login { get; set; }
        public string UserName { get; set; }
        public DateTime EnteredDate { get; set; }
        public int EnteredByUserId { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public int LastUpdateUserId { get; set; }
        public bool Active { get; set; }
        public string Password { get; set; }
        public DateTime LastPwchange { get; set; }
        public int? SecurityGroupId { get; set; }
        public string PhoneNum { get; set; }
        public string UserEmailAddress { get; set; }
        public int? LegacyCmsuserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int? EmploymentTypeId { get; set; }

        public virtual LkpEmploymentTypes EmploymentType { get; set; }
        public virtual ICollection<LkpClients> LkpClientsEnteredByUser { get; set; }
        public virtual ICollection<LkpClients> LkpClientsLastUpdateUser { get; set; }
        public virtual ICollection<LkpEmploymentTypes> LkpEmploymentTypesEnteredByUser { get; set; }
        public virtual ICollection<LkpEmploymentTypes> LkpEmploymentTypesLastUpdateUser { get; set; }
        public virtual ICollection<TblClientPdfcompression> TblClientPdfcompressionAddedByNavigation { get; set; }
        public virtual ICollection<TblClientPdfcompression> TblClientPdfcompressionUpdatedByNavigation { get; set; }
    }
}
