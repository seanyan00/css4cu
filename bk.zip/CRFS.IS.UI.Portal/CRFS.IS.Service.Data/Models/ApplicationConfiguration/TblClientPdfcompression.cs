﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service
{
    public partial class TblClientPdfcompression
    {
        public int ClientId { get; set; }
        public string SourceFolder { get; set; }
        public string DestinationFolder { get; set; }
        public string ErrorFolder { get; set; }
        public int? SizeLimitMb { get; set; }
        public string Cron { get; set; }
        public string Comment { get; set; }
        public string NotifyCrfsDl { get; set; }
        public string NotifyClientDl { get; set; }
        public bool Active { get; set; }
        public int? AddedBy { get; set; }
        public DateTime? AddedDate { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }

        public virtual LkpUsers AddedByNavigation { get; set; }
        public virtual LkpClients Client { get; set; }
        public virtual LkpUsers UpdatedByNavigation { get; set; }
    }
}
