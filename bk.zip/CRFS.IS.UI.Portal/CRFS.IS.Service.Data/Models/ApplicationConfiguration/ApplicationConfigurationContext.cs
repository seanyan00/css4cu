﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CRFS.IS.Service
{
    public partial class ApplicationConfigurationContext : DbContext
    {
        public ApplicationConfigurationContext()
        {
        }

        public ApplicationConfigurationContext(DbContextOptions<ApplicationConfigurationContext> options)
            : base(options)
        {
        }

        public virtual DbSet<LkpClients> LkpClients { get; set; }
        public virtual DbSet<LkpEmploymentTypes> LkpEmploymentTypes { get; set; }
        public virtual DbSet<LkpUsers> LkpUsers { get; set; }
        public virtual DbSet<TblClientPdfcompression> TblClientPdfcompression { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=vm-sql1-uat.uat.crfs.crfservices.com\\cms_u;Initial Catalog=ApplicationConfiguration;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<LkpClients>(entity =>
            {
                entity.HasKey(e => e.ClientId);

                entity.ToTable("lkp_Clients");

                entity.HasComment("A lookup table that displays Client Names, in addition to their abbreviations. ");

                entity.HasIndex(e => e.ClientAbbreviation)
                    .HasName("UK2_lkp_Clients_ClientAbbreviation")
                    .IsUnique();

                entity.HasIndex(e => e.ClientName)
                    .HasName("UK1_lkp_Clients_ClientName")
                    .IsUnique();

                entity.HasIndex(e => new { e.ClientName, e.ClientAbbreviation })
                    .HasName("UK3_lkp_Clients_ClientName_ClientAbbreviation")
                    .IsUnique();

                entity.Property(e => e.ClientId).HasColumnName("ClientID");

                entity.Property(e => e.ClientAbbreviation)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ClientDisplayName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ClientLegalName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ClientName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EffectiveFromDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("('1/1/1900')");

                entity.Property(e => e.EffectiveToDate)
                    .HasColumnType("date")
                    .HasDefaultValueSql("('12/31/2015')");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.LkpClientsEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_lkp_Users_lkp_Clients_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.LkpClientsLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_lkp_Users_lkp_Clients_LastUpdateUserID");
            });

            modelBuilder.Entity<LkpEmploymentTypes>(entity =>
            {
                entity.HasKey(e => e.EmploymentTypeId);

                entity.ToTable("lkp_EmploymentTypes");

                entity.HasIndex(e => e.EmploymentType)
                    .HasName("UK1_EmploymentTypes_EmploymentType")
                    .IsUnique();

                entity.Property(e => e.EmploymentTypeId).HasColumnName("EmploymentTypeID");

                entity.Property(e => e.EmploymentType)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.HasOne(d => d.EnteredByUser)
                    .WithMany(p => p.LkpEmploymentTypesEnteredByUser)
                    .HasForeignKey(d => d.EnteredByUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK1_lkp_EmploymentTypes_lkp_Users_EnteredByUserID");

                entity.HasOne(d => d.LastUpdateUser)
                    .WithMany(p => p.LkpEmploymentTypesLastUpdateUser)
                    .HasForeignKey(d => d.LastUpdateUserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK2_lkp_EmploymentTypes_lkp_Users_LastUpdateUserID");
            });

            modelBuilder.Entity<LkpUsers>(entity =>
            {
                entity.HasKey(e => e.UserId);

                entity.ToTable("lkp_Users");

                entity.HasComment("A lookup table that contains user data. Utilized by a variety of tables within the database.");

                entity.HasIndex(e => e.Login)
                    .HasName("UK1_lkp_Users_Login")
                    .IsUnique();

                entity.HasIndex(e => e.UserName)
                    .HasName("idx_lkp_Users_UserName");

                entity.HasIndex(e => new { e.UserId, e.FirstName, e.LastName })
                    .HasName("idx_lkp_Users_FirstName_LastName_UserID");

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.Property(e => e.EmploymentTypeId).HasColumnName("EmploymentTypeID");

                entity.Property(e => e.EnteredByUserId).HasColumnName("EnteredByUserID");

                entity.Property(e => e.EnteredDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.FirstName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastPwchange)
                    .HasColumnName("LastPWChange")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getutcdate())");

                entity.Property(e => e.LastUpdateUserId).HasColumnName("LastUpdateUserID");

                entity.Property(e => e.LegacyCmsuserId).HasColumnName("LegacyCMSUserID");

                entity.Property(e => e.Login)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.PhoneNum)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.SecurityGroupId).HasColumnName("SecurityGroupID");

                entity.Property(e => e.UserEmailAddress)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.EmploymentType)
                    .WithMany(p => p.LkpUsers)
                    .HasForeignKey(d => d.EmploymentTypeId)
                    .HasConstraintName("FK1_lkp_Users_lkp_EmploymentTypes");
            });

            modelBuilder.Entity<TblClientPdfcompression>(entity =>
            {
                entity.HasKey(e => e.ClientId)
                    .HasName("PK_ClientPDFCompression1");

                entity.ToTable("tbl_ClientPDFCompression");

                entity.Property(e => e.ClientId)
                    .HasColumnName("ClientID")
                    .ValueGeneratedNever();

                entity.Property(e => e.AddedDate).HasColumnType("datetime");

                entity.Property(e => e.Comment)
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.Property(e => e.Cron)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DestinationFolder).HasMaxLength(200);

                entity.Property(e => e.ErrorFolder).HasMaxLength(200);

                entity.Property(e => e.NotifyClientDl).HasColumnName("NotifyClientDL");

                entity.Property(e => e.NotifyCrfsDl).HasColumnName("NotifyCrfsDL");

                entity.Property(e => e.SizeLimitMb).HasColumnName("SizeLimit_MB");

                entity.Property(e => e.SourceFolder).HasMaxLength(200);

                entity.Property(e => e.UpdatedDate).HasColumnType("datetime");

                entity.HasOne(d => d.AddedByNavigation)
                    .WithMany(p => p.TblClientPdfcompressionAddedByNavigation)
                    .HasForeignKey(d => d.AddedBy)
                    .HasConstraintName("FK_ClientPDFCompression_lkp_Users2");

                entity.HasOne(d => d.Client)
                    .WithOne(p => p.TblClientPdfcompression)
                    .HasForeignKey<TblClientPdfcompression>(d => d.ClientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ClientPDFCompression_lkp_Clients1");

                entity.HasOne(d => d.UpdatedByNavigation)
                    .WithMany(p => p.TblClientPdfcompressionUpdatedByNavigation)
                    .HasForeignKey(d => d.UpdatedBy)
                    .HasConstraintName("FK_ClientPDFCompression_lkp_Users3");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
