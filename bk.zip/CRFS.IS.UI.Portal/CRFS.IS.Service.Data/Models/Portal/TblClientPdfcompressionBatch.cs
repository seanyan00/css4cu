﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service
{
    public partial class TblClientPdfcompressionBatch
    {
        public TblClientPdfcompressionBatch()
        {
            TblClientPdfcompressionBatchDetail = new HashSet<TblClientPdfcompressionBatchDetail>();
        }

        public int Id { get; set; }
        public string RunBy { get; set; }
        public DateTime RunDate { get; set; }

        public virtual ICollection<TblClientPdfcompressionBatchDetail> TblClientPdfcompressionBatchDetail { get; set; }
    }
}
