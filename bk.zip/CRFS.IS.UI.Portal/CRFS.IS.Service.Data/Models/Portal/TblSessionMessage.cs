﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service
{
    public partial class TblSessionMessage
    {
        public int Id { get; set; }
        public int SessionDetailId { get; set; }
        public string Msg { get; set; }
        public DateTime EnteredDate { get; set; }

        public virtual TblSessionDetail SessionDetail { get; set; }
    }
}
