﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service
{
    public partial class TblSession
    {
        public TblSession()
        {
            TblSessionDetail = new HashSet<TblSessionDetail>();
        }

        public int Id { get; set; }
        public string Token { get; set; }
        public string AppFrom { get; set; }
        public string Uname { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public bool? Active { get; set; }

        public virtual ICollection<TblSessionDetail> TblSessionDetail { get; set; }
    }
}
