﻿using System;
using System.Collections.Generic;

namespace CRFS.IS.Service.Data.Data.Data
{
    public partial class LkpApplication
    {
        public LkpApplication()
        {
            LkpApplicationUi = new HashSet<LkpApplicationUi>();
            XrefAppGrant = new HashSet<XrefAppGrant>();
        }

        public int Id { get; set; }
        public string Name { get; set; }

        public virtual ICollection<LkpApplicationUi> LkpApplicationUi { get; set; }
        public virtual ICollection<XrefAppGrant> XrefAppGrant { get; set; }
    }
}
