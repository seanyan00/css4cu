﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CRFS.IS.Service
{
    public partial class PortalContext : DbContext
    {
        public PortalContext()
        {
        }

        public PortalContext(DbContextOptions<PortalContext> options)
            : base(options)
        {
        }

        public virtual DbSet<TblClientPdfcompressionBatch> TblClientPdfcompressionBatch { get; set; }
        public virtual DbSet<TblClientPdfcompressionBatchDetail> TblClientPdfcompressionBatchDetail { get; set; }
        public virtual DbSet<TblSession> TblSession { get; set; }
        public virtual DbSet<TblSessionDetail> TblSessionDetail { get; set; }
        public virtual DbSet<TblSessionMessage> TblSessionMessage { get; set; }
        public virtual DbSet<VwClientPdfcompressionSummary> VwClientPdfcompressionSummary { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=vm-sql1-uat.uat.crfs.crfservices.com\\cms_u;Initial Catalog=Portal;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TblClientPdfcompressionBatch>(entity =>
            {
                entity.ToTable("tbl_ClientPDFCompressionBatch");

                entity.Property(e => e.RunBy)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.RunDate).HasColumnType("datetime");
            });

            modelBuilder.Entity<TblClientPdfcompressionBatchDetail>(entity =>
            {
                entity.HasKey(e => new { e.BatchId, e.ClientId, e.FileName, e.TimeStart });

                entity.ToTable("tbl_ClientPDFCompressionBatchDetail");

                entity.Property(e => e.FileName)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.TimeStart).HasColumnType("datetime");

                entity.Property(e => e.Reason)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TimeEnd).HasColumnType("datetime");

                entity.HasOne(d => d.Batch)
                    .WithMany(p => p.TblClientPdfcompressionBatchDetail)
                    .HasForeignKey(d => d.BatchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tbl_ClientPDFCompressionBatchDetail_tbl_ClientPDFCompressionBatch");
            });

            modelBuilder.Entity<TblSession>(entity =>
            {
                entity.ToTable("tbl_Session");

                entity.Property(e => e.AppFrom)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.EndTime).HasColumnType("datetime");

                entity.Property(e => e.StartTime).HasColumnType("datetime");

                entity.Property(e => e.Token)
                    .IsRequired()
                    .HasMaxLength(256)
                    .IsUnicode(false);

                entity.Property(e => e.Uname)
                    .IsRequired()
                    .HasColumnName("UName")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblSessionDetail>(entity =>
            {
                entity.ToTable("tbl_SessionDetail");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.SvcName)
                    .IsRequired()
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.SvcParams)
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.HasOne(d => d.Session)
                    .WithMany(p => p.TblSessionDetail)
                    .HasForeignKey(d => d.SessionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tbl_SessionDetail_tbl_Session");
            });

            modelBuilder.Entity<TblSessionMessage>(entity =>
            {
                entity.ToTable("tbl_SessionMessage");

                entity.Property(e => e.EnteredDate).HasColumnType("datetime");

                entity.Property(e => e.Msg)
                    .IsRequired()
                    .HasMaxLength(2000)
                    .IsUnicode(false);

                entity.HasOne(d => d.SessionDetail)
                    .WithMany(p => p.TblSessionMessage)
                    .HasForeignKey(d => d.SessionDetailId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tbl_SessionMessage_tbl_SessionDetail");
            });

            modelBuilder.Entity<VwClientPdfcompressionSummary>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_ClientPDFCompressionSummary");

                entity.Property(e => e.ClientDisplayName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.RunBy)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.RunDate).HasColumnType("datetime");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
