﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Grpc.Core;
using Microsoft.Extensions.Logging;

using CRFS.IS.Service.GRpc;
using CRFS.IS.Service.Business;
using CRFS.IS.Service.Security;

namespace CRFS.IS.Service.Services
{
    public class CommonService : GRpc.Common.CommonBase
    {
        private readonly ILogger<CommonService> _logger;
        public CommonService(ILogger<CommonService> logger)
        {
            _logger = logger;
        }

        public override Task<GetKeyValueListReply> GetKeyValueList(GetKeyValueListRequest request, ServerCallContext context)
        {
            try
            {
                var token = context.RequestHeaders.FirstOrDefault(x => x.Key == "sessiontoken");

                if (token == null || !SessionProvider.IsValidSession(token.Value, "GetKeyValueList", false))
                {
                    _logger.LogWarning("GetKeyValueList: Not a valid token or timed out");
                    return Task.FromResult(new GetKeyValueListReply { });
                }
             
                return Task.FromResult(PortalProvider.GetKeyValueListByType(request.Type, request.Id, token.Value));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return Task.FromResult(new GetKeyValueListReply { });
            }
        }
    }
}
