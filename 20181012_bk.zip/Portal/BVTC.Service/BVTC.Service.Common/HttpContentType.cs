﻿using System.Collections.Generic;
using System.Linq;


namespace BVTC.Service.Common
{
    public class ByteExt
    {
        public byte Code { get; set; }
        public string Ext { get; set; }
        public string ContentType { get; set; }
    }
    public static class HttpContentType
    {
        public static readonly List<ByteExt> ByteExtList;
        
        static HttpContentType()
        {
            ByteExtList = new List<ByteExt>
            {
                new ByteExt{ Code = 0x00, Ext = "TXT", ContentType = "text/plain" },
                new ByteExt{ Code = 0x01, Ext = "PDF", ContentType = "application/pdf" },
                new ByteExt{ Code = 0x02, Ext = "PNG", ContentType = "image/png" },
                new ByteExt{ Code = 0x03, Ext = "JPG", ContentType = "image/jpeg" },
                new ByteExt{ Code = 0x04, Ext = "JPEG", ContentType = "image/jpeg" },
                new ByteExt{ Code = 0x05, Ext = "TIFF", ContentType = "image/tiff" },
                new ByteExt{ Code = 0x06, Ext = "TIF", ContentType = "image/tiff" },
                new ByteExt{ Code = 0x07, Ext = "BMP", ContentType = "image/bmp" },
                new ByteExt{ Code = 0x08, Ext = "DOC", ContentType = "application/msword" },
                new ByteExt{ Code = 0x09, Ext = "DOCX", ContentType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document" },
                new ByteExt{ Code = 0x0A, Ext = "XLS", ContentType = "application/vnd.ms-excel" },
                new ByteExt{ Code = 0x0B, Ext = "XLSX", ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" },
                new ByteExt{ Code = 0x0C, Ext = "XML", ContentType = "application/xml" },
                new ByteExt{ Code = 0x0D, Ext = "ZIP", ContentType = "application/zip" },
                new ByteExt{ Code = 0x0E, Ext = "CSV", ContentType = "text/csv" },
                new ByteExt{ Code = 0xFF, Ext = "", ContentType = "" },
            };
        }

        public static string GetContentType(byte code)
        {
            return ByteExtList.Where(x => x.Code == code).Select(x => x.ContentType).Single();
        }
        public static byte GetCode(string ext)
        {
            return ByteExtList.Where(x => x.Ext == ext.ToUpper()).Select(x => x.Code).Single();
        }
        public static string GetExt(byte code)
        {
            return ByteExtList.Where(x => x.Code == code).Select(x => x.Ext.ToLower()).Single();
        }
    }
}
