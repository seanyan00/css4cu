﻿using System;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.ServiceModel;

namespace BVTC.Service.Common
{
    [AttributeUsage(AttributeTargets.All, Inherited = false, AllowMultiple = false)]
    public class TokenValidateAttribute : Attribute
    {
        public ValidationResult IsValid(object value)
        {
            string msgid = OperationContext.Current.IncomingMessageHeaders.MessageId.ToString();

            if (!SessionUserList.Users.Any(x => x.Key == msgid))
            {
                return new ValidationResult("No Session Found");
            }
            return null;
        }
    }
}
