﻿using System;

namespace BVTC.Service.Common
{
    public class GraceShutDownEvent
    {
        private static EventHandler serviceclosing;
        public static event EventHandler ServiceClosing
        {
            add
            {
               // keep all instance handlers
               // serviceclosing -= value; 
                serviceclosing += value;
            }
            remove
            {
                serviceclosing -= value;
            }
        }

        public void RaiseClosing()
        {
           OnServiceClosing();
        }

        private void OnServiceClosing()
        {
            serviceclosing?.Invoke(this, EventArgs.Empty);
        }

    }
}
