﻿using System;
using System.Data;
using System.Net.Mail;
using System.Configuration;

namespace BVTC.Service.Common.Utilities
{
    public class Email
    {
        public string Server { get; }
        public string Port { get; }
        public string Encryption { get; }
        public string User { get; }
        public string Pwd { get; }
        public string From { get; }
        public string FromEmail { get; set; }
        public string ToEmail { get; set; }
        public string CCEmail { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public string Attachment { get; set; }

        public Email()
        {
            Server = ConfigurationManager.AppSettings[Constants.KEY_EMAIL_SERVER].ToString();
            Port = ConfigurationManager.AppSettings[Constants.KEY_EMAIL_PORT].ToString();
            Encryption = ConfigurationManager.AppSettings[Constants.KEY_EMAIL_ENCRYPTION].ToString();
            User = ConfigurationManager.AppSettings[Constants.KEY_EMAIL_USER].ToString();
            Pwd = ConfigurationManager.AppSettings[Constants.KEY_EMAIL_PWD].ToString();
            From = ConfigurationManager.AppSettings[Constants.KEY_EMAIL_FROM].ToString();

        }
        public bool ValidateEmailIds(DataTable dt, int[] EmailColumnIndex)
        {
            bool ValidEmailIds = true;
            System.Text.RegularExpressions.Regex ValidEmailID = new System.Text.RegularExpressions.Regex(@"([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})");
            foreach (int columnIndex in EmailColumnIndex)
                foreach (DataRow dr in dt.Rows)
                {
                    string[] EmailIds = Convert.ToString(dr[columnIndex]).Split(',');
                    foreach (string EmailID in EmailIds)
                    {
                        if (!string.IsNullOrEmpty(EmailID))
                            if (!ValidEmailID.IsMatch(EmailID))
                            {
                                ValidEmailIds = false;
                                Log2File.LogInfo("Invalid Email ID found: " + EmailID);
                                break;
                            }
                    }
                    if (!ValidEmailIds) break;
                }
            return ValidEmailIds;
        }

        public bool SendEmail(string host = "", int port = 0)
        {
            bool bIsEmailSuccess = true;
            try
            {
                if (string.IsNullOrEmpty(FromEmail))
                    FromEmail = From;

                MailMessage message = new MailMessage(FromEmail,
                                                    ToEmail,
                                                    Subject,
                                                    Body);
                message.IsBodyHtml = true;
                if (!string.IsNullOrEmpty(Attachment))
                    message.Attachments.Add(new Attachment(Attachment));

                SmtpClient client = new SmtpClient(string.IsNullOrEmpty(host) ? Server : host,
                                                   port == 0 ? Convert.ToInt32(Port) : port);
                // client.UseDefaultCredentials = true;
                client.Credentials = new System.Net.NetworkCredential(User, Pwd);
                client.EnableSsl = true;

                client.Send(message);
            }
            catch (Exception exp)
            {
                Log2File.LogInfo("Error: " + exp.Message);
                bIsEmailSuccess = false;
            }
            return bIsEmailSuccess;
        }
    }
}
