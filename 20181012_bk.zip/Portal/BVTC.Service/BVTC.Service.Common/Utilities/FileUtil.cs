﻿using System;
using System.IO;
using System.Xml;
using System.Text.RegularExpressions;
using System.Configuration;
using System.Collections.Generic;

namespace BVTC.Service.Common.Utilities
{
    public static class FileUtil
    {
        public static void HtmlTableToCSV(string fname)
        {
            string text = "";
            string line = "";
            string fname1 = fname.Replace(".txt", "_a.txt");
            try
            {
                if (!File.Exists(fname))
                    return;

                if (File.Exists(fname1))
                    File.Delete(fname1);

                using (var sw = new StreamWriter(fname1))
                {
                    using (var sr = new StreamReader(fname))
                    {
                        text = sr.ReadToEnd();
                    }
                    var xd = new XmlDocument();
                    xd.LoadXml(text);

                    var trs = xd.GetElementsByTagName("TR");
                    if (trs.Count == 0)
                        trs = xd.GetElementsByTagName("tr");

                    for (int i = 0; i < trs.Count; i++)
                    {
                        var tds = trs[i].ChildNodes;
                        line = "";
                        for (int j = 0; j < tds.Count; j++)
                        {
                            if (tds[j].Name.ToUpper() == "TD")
                            {
                                line = line + (line.Length > 0 ? "|" : "") + tds[j].InnerText;
                            }
                        }
                        sw.WriteLine(line);
                    }
                }
            }
            catch (Exception e)
            {
                Log2File.LogInfo("Error: " + e.Message);
            }

        }
        public static void AddLineBreak(string fname, int index)
        {
            string line = "";
            string fname1 = fname.Replace(".txt", "_a.txt");
            try
            {
                if (!File.Exists(fname))
                    return;

                if (File.Exists(fname1))
                    File.Delete(fname1);

                using (var sw = new StreamWriter(fname1))
                {
                    using (var sr = new StreamReader(fname))
                    {
                        int count = -1;

                        while (sr.Peek() >= 0)
                        {
                            int temp = sr.Read();
                            if (temp == ',') ++count;
                            if (count == index)
                            {
                                sw.WriteLine(line.Substring(0, line.Length - 2));
                                line = line.Substring(line.Length - 2) + ",";
                                count = 0;
                            }
                            else
                                line += (char)temp;
                        }
                        if (line.Length > 3)
                            sw.WriteLine(line);

                    }
                }
            }
            catch (Exception e)
            {
                Log2File.LogInfo("Error: " + e.Message);
            }

        }

        public static string GetFileExt(this string s)
        {
            return s.LastIndexOf('.') >= 0 ? s.Substring(s.LastIndexOf('.') + 1) : "";
        }
        public static string GetFileName(this string s)
        {
            return s.IndexOf("\\") < 0 ? s : s.Substring(s.LastIndexOf("\\") + 1);
        }
        public static string GetFileNameNoExt(this string s)
        {
            var ext = s.GetFileExt();
            return s.Substring(0, ext.Length > 0 ? s.LastIndexOf(".") : s.Length);
        }
        public static string GetFileNameTimeStamp(this string s)
        {
            var ext = s.GetFileExt();
            var fn = s.Substring(0, ext.Length > 0 ? s.LastIndexOf(".") : s.Length);

            return fn + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + (ext.Length > 0 ? "." + ext : "");
        }
        public static string GetTimeStamp(this string s)
        {
            var reg = new Regex(@"_\d{14}");
            var mat = reg.Match(s);
            return mat.Success ? mat.Value.Substring(1) : DateTime.Now.ToString("yyyyMMddhhmmss");
        }
        public static bool IsSameName(this string s, string s1)
        {
            var snext = s.GetFileNameNoExt();
            var s1next = s1.GetFileNameNoExt();

            return s.Equals(s1) || s.Equals(s1next) || snext.Equals(s1) || snext.Equals(s1next);
               
        }
        public static string GetFileName(string fname, string projno, string ftype, string ofname, bool hist = false, string timestamp = "")
        {
            var ret = "";
            var root = ConfigurationManager.AppSettings[Constants.KEY_FILEROOT].ToString();
            var ext = fname.GetFileExt();

            if (string.IsNullOrEmpty(ext))
                ext = ofname.GetFileExt();

            ret = fname.GetFileNameNoExt() + "_" + (string.IsNullOrEmpty(timestamp) ? DateTime.Now.ToString("yyyyMMddhhmmss") : timestamp) + "." + ext;

            ret = root + @"\" + (string.IsNullOrEmpty(projno) ? "Misc" : projno) + @"\" + (hist ? @"Hist\" : "") + ftype + @"\" + ret;

            return ret;
        }
        public static void BuildProjDir(string projno, List<string> dtyps)
        {
            if (string.IsNullOrEmpty(projno))
                return;

            var root = ConfigurationManager.AppSettings[Constants.KEY_FILEROOT].ToString();
            root += @"\" + projno;
            if (!Directory.Exists(root))
            {
                Directory.CreateDirectory(root);
           
                foreach (var t in dtyps)
                {
                    var dn = root + @"\" + t;
                    Directory.CreateDirectory(dn);
                }
                var hist = root + @"\Hist";
                Directory.CreateDirectory(hist);
                foreach (var t in dtyps)
                {
                    var dn = hist + @"\" + t;
                    Directory.CreateDirectory(dn);
                }
            }
        }
    }
}
