﻿using System;
using System.Configuration;
using System.Diagnostics;
using System.IO;

namespace BVTC.Service.Common.Utilities
{
    public static class Log2File
    {
        private static object Locker = new object();

        public static void LogInfo(string Message, TraceLevel tl = TraceLevel.Error)
        {
            string logmsg = string.Empty;
            string logfile = ConfigurationManager.AppSettings["LogFilePath"].ToString();
            StreamWriter sw = null;

            logmsg = string.Format("{0}: {1}", DateTime.Now, Message);

            try
            {
                lock (Locker)
                {
                    if (!File.Exists(logfile))
                    {
                        sw = new StreamWriter(logfile);
                    }
                    else
                    {
                        sw = File.AppendText(logfile);
                    }

                    sw.WriteLine(logmsg);
                    sw.WriteLine();
                }
            }
            catch
            { }
            finally
            {
                if (sw != null)
                {
                    sw.Close();
                    // just being clear
                    sw = null;
                }
            }
        }
        public static void LogInfo(string Message, Exception ex, TraceLevel tl = TraceLevel.Error)
        {
            var msg = ex.InnerException == null ? Message + "##" + ex.Message + "\r\n" + ex.StackTrace
                                                : Message + "##" + ex.InnerException.Message + "\r\n" + ex.InnerException.StackTrace;
            LogInfo(msg, tl);
        }
    }

    public class Log
    {
        private static string KEY_TRACETARGET = "TraceTarget";
        private static string KEY_TRACELEVEL = "TraceLevel";
        
        public void Tracing(string info, string sid = "")
        {
            var target = ConfigurationManager.AppSettings[KEY_TRACETARGET].ToString();
            var level = Convert.ToInt32(ConfigurationManager.AppSettings[KEY_TRACELEVEL].ToString());

            if (level >= (int)TraceLevel.Off)
            {
                switch (target)
                {
                    case "Debug":
                        Debug.WriteLine(info);
                        break;
                    case "Console":
                        Console.WriteLine(info);
                        break;
                    case "File":
                        Log2File.LogInfo(info);
                        break;
                    case "DB":
                        AddDBTracing(info, sid);                   
                        break;
                    default:
                        break;
                }
            }
        }

        public void Tracing(string info, TraceLevel lvl, string sid = "")
        {
            var tlevel = Convert.ToInt32(ConfigurationManager.AppSettings[KEY_TRACELEVEL].ToString());

            if ((int)lvl <= tlevel)
            {
                Tracing(info, sid);
            }
        }

        public virtual void AddDBTracing(string info, string id)
        {
            throw new NotImplementedException();
        }
    }
}
