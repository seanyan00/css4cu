﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BVTC.Service.Common.Utilities
{
    public static class DateTimeHelper
    {
        public static int IsDifferent(DateTime t1, DateTime t2)
        {
            DateTime tt1 = new DateTime(t1.Year, t1.Month, t1.Day, t1.Hour, t1.Minute, t1.Second);
            DateTime tt2 = new DateTime(t2.Year, t2.Month, t2.Day, t2.Hour, t2.Minute, t2.Second);

            return DateTime.Compare(tt1, tt2);
        }
    }
}
