﻿using System.Collections.Generic;
using System.Linq;

using BVTC.Service.TransferObject.Main;

namespace BVTC.Service.Common
{
    public static class SessionUserList
    {
        private static object locker = new object();
        public static Dictionary<string, BVTCUserDTO> Users { get; set; }

        static SessionUserList()
        {
            Users = new Dictionary<string, BVTCUserDTO>();
        }
      
        public static string GetLastUser()
        {
            string ret = "";
           
            var mt = Users.Select(x => (x.Value).Timestamp).Max();

            return Users.Where(x => x.Value.Timestamp == mt).Select(x => x.Value.Uname).First();
        }
        public static void AddUser(string id, BVTCUserDTO bud)
        {
            lock (locker)
            {
                Users.Add(id, bud);
            }
        }
        public static void RemoveUser(BVTCUserDTO bud)
        {
            lock (locker)
            {
                string key = Users.Where(x => x.Value.Uname == bud.Uname && x.Value.Token == bud.Token).Select(x => x.Key).Single();
                Users.Remove(key);
            }
        }
    }
}
