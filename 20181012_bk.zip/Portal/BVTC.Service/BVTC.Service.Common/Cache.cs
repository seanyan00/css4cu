﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BVTC.Service.Common
{
    public sealed class Cache
    {
        private static readonly Cache inst = new Cache();

        private static Dictionary<string, object> Body;

        static Cache() {
            Body = new Dictionary<string, object>();
        }

        private Cache() { }

        public static Cache Inst
        {
            get
            {
                return inst;
            }
        }
    }
}
