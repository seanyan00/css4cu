﻿using System.Collections.Generic;

namespace BVTC.Service.Common
{
    public enum LoginStatus { Active = 0, LogedOut, Failed, Rejected, ExceededAttempt, TimedOut, IdleTooLong, NoGroupAssigned, Locked, ServerError }
    public enum UIPermission { None = 0, View, Modify, Delete, Create, Admin }
    public enum Error { Failure = -1, Success }

    public class Constants
    {
        //globals
        public const int DBCommandTimeout = 2100;

        public const string Processing = "Processing";
        public const string INVALIDUSER = "InvalidUserAppName";
        public const string IDENTITYPROVIDER = "Portal Security";
        public const string KEY_BVTCUSER = "Auth_BVTCUser";
        public const string KEY_TOKENWINDOW = "Auth_TokenWindow";
        public const string DATETIMEFORMAT = "MM/dd/yyyy HH:mm:ss";
        public const string KEY_FILEROOT = "Portal_FileDir";
        public const string KEY_AUTH_ADDOMAIN = "Auth_ADDomain";
        public const string KEY_AUTH_ADPATH = "Auth_ADPath";
        public const string KEY_BVTC_UPLOADROOT = "BVTC_FileUploadFrom";
        public const string KEY_BVTC_UPLOADROOTIP = "BVTC_FileUploadFromIP";
        public const string KEY_BVTC_SERVICEUSER = "BVTC_ServiceUser";
        public const string KEY_BVTC_SERVICEUSERPWD = "BVTC_ServiceUserPwd";
        public const string KEY_EMAIL_SERVER = "Email_Server"; //smtp.office365.com";
        public const string KEY_EMAIL_PORT = "Email_Port"; // = 587;
        public const string KEY_EMAIL_ENCRYPTION = "Email_Encryption"; // TLS";
        public const string KEY_EMAIL_USER = "Email_User"; // xerox@bostonvalley.com";
        public const string KEY_EMAIL_PWD = "Email_Pwd"; // bvtcX3r0x";
        public const string KEY_EMAIL_FROM = "Email_From"; // it@bostonvalley.com";

        public const string KEY_PORTALCONNSTR = "MPMPortalEntities";

        public static readonly List<string> FILEEXT = new List<string> { "PDF", "PNG", "JPG", "GIF", "BMP", "TXT", "DOC", "DOCX",
            "XLS", "XLSX", "JPEG", "TIFF", "TIF", "XML", "ZIP" };

        public static readonly Dictionary<string, string> DBTypeMap = new Dictionary<string, string>
        {
            {"Byte", "System.Byte" },
       /* typeMap[typeof(sbyte)] = DbType.SByte;
typeMap[typeof(short)] = DbType.Int16;
typeMap[typeof(ushort)] = DbType.UInt16;
typeMap[typeof(int)] = DbType.Int32;
typeMap[typeof(uint)] = DbType.UInt32;
typeMap[typeof(long)] = DbType.Int64;
typeMap[typeof(ulong)] = DbType.UInt64;
typeMap[typeof(float)] = DbType.Single;
typeMap[typeof(double)] = DbType.Double;
typeMap[typeof(decimal)] = DbType.Decimal;
typeMap[typeof(bool)] = DbType.Boolean;
typeMap[typeof(string)] = DbType.String;
typeMap[typeof(char)] = DbType.StringFixedLength;
typeMap[typeof(Guid)] = DbType.Guid;
typeMap[typeof(DateTime)] = DbType.DateTime;
typeMap[typeof(DateTimeOffset)] = DbType.DateTimeOffset;
typeMap[typeof(byte[])] = DbType.Binary;
typeMap[typeof(byte?)] = DbType.Byte;
typeMap[typeof(sbyte?)] = DbType.SByte;
typeMap[typeof(short?)] = DbType.Int16;
typeMap[typeof(ushort?)] = DbType.UInt16;
typeMap[typeof(int?)] = DbType.Int32;
typeMap[typeof(uint?)] = DbType.UInt32;
typeMap[typeof(long?)] = DbType.Int64;
typeMap[typeof(ulong?)] = DbType.UInt64;
typeMap[typeof(float?)] = DbType.Single;
typeMap[typeof(double?)] = DbType.Double;
typeMap[typeof(decimal?)] = DbType.Decimal;
typeMap[typeof(bool?)] = DbType.Boolean;
typeMap[typeof(char?)] = DbType.StringFixedLength;
typeMap[typeof(Guid?)] = DbType.Guid;
typeMap[typeof(DateTime?)] = DbType.DateTime;
typeMap[typeof(DateTimeOffset?)] = DbType.DateTimeOffset;
*/
        };

    }
}
