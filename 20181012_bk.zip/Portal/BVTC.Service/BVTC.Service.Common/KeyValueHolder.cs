﻿namespace BVTC.Service.Common
{
    public class KeyValueHolder
    {
        public string Key { get; set; }
        public string Value { get; set; }
    }
}
