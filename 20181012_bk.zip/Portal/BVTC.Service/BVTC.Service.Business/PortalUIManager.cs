﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;

using BVTC.Service.TransferObject.Portal;
using BVTC.Service.TransferObject.Main;
using BVTC.Service.Common;
using BVTC.Service.Common.Utilities;

namespace BVTC.Service.Business
{
    public class PortalUIManager
    {
        public BVTCUserDTO BUD { get; private set; }
        public Providers.PortalUIProvider UIPro { get; set; }

        public PortalUIManager(BVTCUserDTO bud)
        {
            BUD = bud;
            UIPro = new Providers.PortalUIProvider(BUD);
        }
        public Dictionary<int, int> GetUIPermsByUser(string uname)
        {
            return null;
        }

        public UIElementDTO GetElementById(string id)
        {
            int temp;

            if (!int.TryParse(id, out temp))
                temp = UIPro.GetUIIdByUIName(id);

            return GetElementById(temp);
        }
        public UIElementDTO GetElementById(int id)
        {
            try
            {
                AccessAssert(id);

                var viewonly = UIPro.IsViewOnlyUI(id);

                return UIPro.GetElementById(id, viewonly);
            }
            catch(AccessViolationException ex)
            {
                throw new FaultException(ex.Message);
            }
            catch(Exception ex)
            {
                Log2File.LogInfo("Error: " + ex.Message + " " + ex.StackTrace, System.Diagnostics.TraceLevel.Error);
                throw new FaultException("Server Error");
            }
        }
        public KeyValueItem[] GetKeyValueArray(string name, string parent)
        {
            return UIPro.GetKeyValueListByEntityName(name, parent).Select(x => new KeyValueItem { Key = x.Key, Value = x.Value }).ToArray();
        }
        public ElementDataDTO GetDataSourceByRequest(ElementRequestDTO erd)
        {
            try
            {
                if (erd.Id == 0)
                {
                    if (string.IsNullOrEmpty(erd.NameType))
                    {
                        erd.Id = UIPro.GetUIIdByUIName(erd.Name);
                       
                    } else
                    {
                       if (erd.NameType == "Entity")
                            return UIPro.GetDataSourceByDataTarget(erd);
                    }
                }

                return UIPro.GetDataSourceByUIID(erd);
            }
            catch (AccessViolationException ex)
            {
                throw new FaultException(ex.Message);
            }
            catch (Exception ex)
            {
                Log2File.LogInfo("Error: " + ex.Message + " " + ex.StackTrace, System.Diagnostics.TraceLevel.Error);
                throw new FaultException("Server Error");
            }
        }
        public ElementDataDTO GetDataSourceByCols(ElementDataDTO edd)
        {
            try
            {
                return UIPro.GetDataSourceByCols(new ElementRequestDTO { Name = edd.TableName, PId = edd.PId, PName = edd.PName, Incl = edd.Incl });
            }
            catch (AccessViolationException ex)
            {
                throw new FaultException(ex.Message);
            }
            catch (Exception ex)
            {
                Log2File.LogInfo("Error: " + ex.Message + " " + ex.StackTrace, System.Diagnostics.TraceLevel.Error);
                throw new FaultException("Server Error");
            }
        }
        public int GetUIdByUName(string uname)
        {
            try
            {
                return UIPro.GetUIdByUName(uname);
            }
            catch (AccessViolationException ex)
            {
                throw new FaultException(ex.Message);
            }
            catch (Exception ex)
            {
                Log2File.LogInfo("Error: " + ex.Message + " " + ex.StackTrace, System.Diagnostics.TraceLevel.Error);
                throw new FaultException("Server Error");
            }
        }
        public int SaveDataRecord(ElementDataDTO edd)
        {
            try
            {
                return UIPro.SaveDataRecord(edd);
            }
            catch(Exception ex)
            {
                Log2File.LogInfo("Error: " + ex.Message + " " + ex.StackTrace, System.Diagnostics.TraceLevel.Error);
                throw new FaultException("Server Error");
            }
        }
        public string UploadFile(byte[] content, string filename, string type)
        {
            try
            {
                return UIPro.SaveFile(content, filename, type);
            }
            catch (Exception ex)
            {
                Log2File.LogInfo("Error: " + ex.Message + " " + ex.StackTrace, System.Diagnostics.TraceLevel.Error);
                throw new FaultException("Server Error");
            }
        }
        public bool IsEditAllowed(string gname)
        {
            try
            {
                return UIPro.IsGridEditAllowedToUser(gname);
            }
            catch (Exception ex)
            {
                Log2File.LogInfo("Error: " + ex.Message + " " + ex.StackTrace, System.Diagnostics.TraceLevel.Error);
                throw new FaultException("Server Error");
            }
        }
        public void SendEmailMessage(string name, string type, string[] ps)
        {
            try
            {
                Providers.MessageProvider.SendEmailMessage(name, type, ps, BUD);
            }
            catch (Exception ex)
            {
                Log2File.LogInfo("Error: " + ex.Message + " " + ex.StackTrace, System.Diagnostics.TraceLevel.Error);
                throw new FaultException("Server Error");
            }
        }
        public void RunSql(CommandDTO cmdd)
        {
            try
            {
                new Providers.DirectDataProvider().RunSql(cmdd);
            }
            catch (Exception ex)
            {
                Log2File.LogInfo("Error: ", ex, System.Diagnostics.TraceLevel.Error);
                throw new FaultException("Server Error");
            }
        }
        private void AccessAssert(string name)
        {
            int id = UIPro.GetUIIdByUIName(name);

            AccessAssert(id);
        }
        private void AccessAssert(int uiid)
        {
            if (UIPro.NoPerm(uiid))
                return;

            var temp = UIPro.GetEleIdsOfRoles(BUD.Roles);
            
            if(!temp.Any(x => x.Key == uiid && x.Value > (int)UIPermission.None))
                 throw new AccessViolationException("Not Authorized Access on ID#" + uiid.ToString());
        }
    }
}
