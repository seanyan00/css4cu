﻿using System;
using System.Collections.Generic;
using System.Linq;

using BVTC.Service.Data.Models.Simulator;
using BVTC.Service.Business.TransferObjects;

namespace BVTC.Service.Business
{
    public static class StatusManager
    {
        public static List<DryerStatus> LDryerStatus;
        public static List<KilnStatus> LKilnStatus;

        static StatusManager()
        {
            var ds = new SimulatorEntities().Dryers.ToList();
            LDryerStatus = new List<DryerStatus>();

            foreach (var d in ds)
            {
                LDryerStatus.Add(new DryerStatus
                {
                    DryerNo = d.DryerNumber,
                    InUse = false,
                    UsedBy = ""
                });
            }

            var ks = new SimulatorEntities().Kilns.ToList();
            LKilnStatus = new List<KilnStatus>();

            foreach (var k in ks)
            {
                LKilnStatus.Add(new KilnStatus
                {
                    KilnNo = k.KilnNumber,
                    InUse = false,
                    UsedBy = ""
                });
            }
        }
        public static void SetStatus<T>(int dno, string tnm)
        {
            if(typeof(T) == typeof(Dryer))
                foreach (var d in LDryerStatus)
                {
                    if (d.DryerNo == dno)
                    {
                        d.InUse = true;
                        d.UsedBy = tnm;
                    }
                }
            else
                foreach (var d in LKilnStatus)
                {
                    if (d.KilnNo == dno)
                    {
                        d.InUse = true;
                        d.UsedBy = tnm;
                    }
                }
        }
        public static void ReSetStatus<T>()
        {
            if(typeof(T) == typeof(Dryer))
                foreach (var tt in LDryerStatus)
                {
                    tt.UsedBy = "";
                    tt.InUse = false;
                }
            else
                foreach (var tt in LKilnStatus)
                {
                    tt.UsedBy = "";
                    tt.InUse = false;
                }

        }
        public static bool CanUse<T>(int dno, string tnm)
        {
            if(typeof(T) == typeof(Dryer))
               return LDryerStatus.Any(x => x.DryerNo == dno && ((!x.InUse) || (x.UsedBy == tnm)));
            else
               return LKilnStatus.Any(x => x.KilnNo == dno && ((!x.InUse) || (x.UsedBy == tnm)));
        }
        
    }
}
