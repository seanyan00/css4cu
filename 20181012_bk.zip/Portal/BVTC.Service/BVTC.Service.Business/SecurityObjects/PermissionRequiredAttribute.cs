﻿
namespace BVTC.Service.Business.SecurityObjects
{
    class PermissionRequiredAttribute
    {
    }
}
