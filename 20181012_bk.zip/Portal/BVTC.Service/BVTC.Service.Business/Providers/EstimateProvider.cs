﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Data.Entity.Validation;

using BVTC.Service.Data.Models.Simulator;
using BVTC.Service.Common;
using BVTC.Service.Common.Utilities;
using BVTC.Service.Business.TransferObjects;

namespace BVTC.Service.Business
{
    public class EstimateProvider
    {
        private SimulatorTracing _st;

        public List<EstimateSummary> EstSums { get; set; }
        public List<EstimateDetail> EstDetails { get; set; }
        public EstimateRun EstRun { get; set; } 
        
        public Guid SessionId { get; set; }
        public int RunNo { get; set; }
        public string ShiftNm { get; set; }
        public List<PlanStatus> CurrPlans;

        private SimulatorEntities Ent;

        public EstimateProvider(int runno, Guid sid)
        {
            _st = new SimulatorTracing();
            InitRun(runno, sid);
        }
        public void SaveSummary(int pid)
        {
            var lsum = EstSums.Where(x => x.PPId == pid).Single();
            var ld = EstDetails.Where(x => x.SumId == lsum.Id).Single();

            using (var ent = new SimulatorEntities()) {
                var s = ent.EstimateSummaries.Where(x => x.PPId == pid && x.SessionId == SessionId.ToString()).Single();

                s.Carts = lsum.Carts;
                s.Hours = ld.AtHour + 1;
                s.Panels = lsum.Panels;
                s.Racks = lsum.Racks;
                s.KilnCarts = lsum.KilnCarts;
                s.KilnRacks = lsum.KilnRacks;

                ent.SaveChanges();
            }
            _st.Tracing("Plan#" + lsum.PPId.ToString() + " ended", SessionId.ToString());
        }

        public void SaveDetail(string team = "", int pid = 0)
        {
            EstimateSummary lsum;
            if (!EstSums.Any(x => x.PPId == pid))
                lsum = EstSums.Last(); //this is likely for dryer/kiln process
            else
                lsum = EstSums.Where(x => x.PPId == pid).Single();

            var ld = EstDetails.Where(x => x.SumId == lsum.Id).Single();

            using (var ent = new SimulatorEntities())
            {
                try
                {
                    var d = ent.EstimateDetails.Where(x => x.Id == ld.Id).Single();

                    d.Action = string.IsNullOrEmpty(d.Action) ? ld.Action : d.Action + "\r\n" + ld.Action;
                    d.Note = ld.Note; 
                    d.PanelExted = ld.PanelExted;
                    d.RackExted = ld.RackExted;
                    d.CartExted = ld.CartExted;
                    d.Team = string.IsNullOrEmpty(d.Team) ? team : d.Team + "\r\n" + team;
                    ent.SaveChanges();
                }
                catch (DbEntityValidationException dbEx)
                {
                    foreach (var validationErrors in dbEx.EntityValidationErrors)
                    {
                        foreach (var validationError in validationErrors.ValidationErrors)
                        {
                            System.Diagnostics.Trace.TraceInformation("Property: {0} Error: {1}",
                                                    validationError.PropertyName,
                                                    validationError.ErrorMessage);
                        }
                    }
                }
            }
        }
        public void Dump()
        {
            throw new NotImplementedException();
        }
        
        public bool AllPanelLoaded(int pid)
        {
            if (GetPlanPanel(pid) > 0 && !EstSums.Any(x => x.PPId == pid))
                return false;

            var lsum = EstSums.Where(x => x.PPId == pid && x.SessionId == SessionId.ToString()).Single();

            if(lsum.Panels >= GetPlanPanel(pid))
            {
                return true;
            }
            return false;
        }
        public bool AllPlanExted()
        {
            foreach(var tt in GetAllPlans())
            {
                if (!AllPanelLoaded(tt.Id))
                    return false;
            }
            return true;
        }
        public List<ProductionPlan> GetAllPlans()
        {
            var plans = Ent.ProductionPlans
                        .Where(x => (x.Id >= (EstRun.PlanStart ?? 1)) && (x.Id <= (EstRun.PlanEnd ?? 9999))).ToList();

            if (string.IsNullOrEmpty(EstRun.PlanOrder)
                || EstRun.PlanOrder.ToUpper() == "ID")
            {
                plans = plans.OrderBy(x => x.Id).ToList();
            }
            else
            {
                plans = plans.OrderBy(x => x.EstShipDate).ToList();
            }
            return plans;

        }
        public int GetPlanPanel(int pid)
        {
            var p = new SimulatorEntities().ProductionPlans.Where(x => x.Id == pid).Single();
          
            return (int)Math.Ceiling(p.Total * (1 + (EstRun.DryerRejRate ?? 0)/100) * (1 + (EstRun.KilnRejRate ?? 0) / 100));
        }
        public void InitDetail(int pid, int currhour)
        {
            var lsum = EstSums.Where(x => x.PPId == pid).Single();

            using(var ent = new SimulatorEntities())
            {
                var temp = new EstimateDetail { 
                   Action = "",
                   AtHour = currhour - lsum.PlanStart,
                   CreateDate = DateTime.Now,
                   SumId = lsum.Id,
                   Note = "",
                   PanelExted = 0,
                   RackExted = 0,
                   CartExted = 0
                };
                if (EstDetails.Any(x => x.SumId == lsum.Id))
                {
                    var ld = EstDetails.Where(x => x.SumId == lsum.Id).Single();
                    EstDetails.Remove(ld);
                }
                ent.EstimateDetails.Add(temp);
                ent.SaveChanges();
                EstDetails.Add(temp);
            }
        }
        public void InitRun(int runno, Guid sid)
        {
            SessionId = sid;
            CurrPlans = new List<PlanStatus>();

            Ent = new SimulatorEntities();

            RunNo = runno;
         
            EstRun = Ent.EstimateRuns.Where(x => x.RunNum == RunNo).Single();

            ShiftNm = EstRun.ShiftName;

            if (string.IsNullOrEmpty(ShiftNm))
                  ShiftNm = Ent.ShiftInfoes.Where(x => x.DaysPerWeek == 5).Select(y => y.ShiftName).SingleOrDefault();
            
            if(string.IsNullOrEmpty(ShiftNm))
            {
                _st.Tracing("No Shift can be found", SessionId.ToString());
                throw new Exception("No default/reqular Shift can be found");
            }
            EstSums = new List<EstimateSummary>();
            EstDetails = new List<EstimateDetail>();

            KilnProvider.InitKiln();

            _st.Tracing("End InitRun", SessionId.ToString());
        }
        public Error InitSum(ProductionPlan plan, int currhour, string team = "")
        {
            Error ret = Error.Success;

            string notes = "";
            _st.Tracing("Starting Plan#" + plan.Id.ToString(), SessionId.ToString());

            using (var ent = new SimulatorEntities())
            {
                //create init record
                string extname = !string.IsNullOrEmpty(team) ? GetUniqueExtName(plan.Id, team) : GetExtName(plan.Id);
                if (string.IsNullOrEmpty(extname))
                {
                    extname = null;
                    ret = Error.Failure;
                    notes = "No Extruder";
                    _st.Tracing("##### Warning: No Extruder/Dye fits Plan#" + plan.Id.ToString(), SessionId.ToString());
                }

                var temp = new EstimateSummary
                {
                    CreateDate = DateTime.Now,
                    PPId = plan.Id,
                    Hours = 0,
                    ShiftName = GetShiftNm(),
                    ExtruderName = extname,
                    PanelsPerShelf = GetPanelsPerShelf("dryer", plan.Id),
                    ShelvesPerCart = GetShelvesPerCart("dryer", plan.Id),
                    DryersUsed = "",
                    RunNum = RunNo,
                    PlanStart = currhour,
                    Panels = 0,
                    Racks = 0,
                    Carts = 0,
                    KilnPanelsPerShelf = GetPanelsPerShelf("kiln", plan.Id),
                    KilnShelvesPerCart = GetShelvesPerCart("kiln", plan.Id),
                    Notes = notes,
                    SessionId = SessionId.ToString()
                };
                ent.EstimateSummaries.Add(temp);
                ent.SaveChanges();
                EstSums.Add(temp);

                _st.Tracing("Panels:" + plan.Total.ToString() 
                               + " PPS:" + EstSums.Last().PanelsPerShelf.ToString() + " SPC:" + EstSums.Last().ShelvesPerCart.ToString()
                               + " KilnPPS:" + EstSums.Last().KilnPanelsPerShelf.ToString() + " KilnSPC:" + EstSums.Last().KilnShelvesPerCart.ToString(), SessionId.ToString());
            }
         
            return ret;
        }
    
        public void SaveActivity(TeamActivity ta)
        {
            using (var ent = new SimulatorEntities())
            {
                var temp = new TeamActivity
                {
                    Act = ta.Act,
                    TeamName = ta.TeamName,
                    RunNum = RunNo,
                    AtHour = GetCurrentHour(ta.PId ?? 0),
                    DryerNo = ta.DryerNo,
                    KilnNo = ta.KilnNo,
                    ExtName = ta.ExtName,
                    PId = ta.PId,
                    SessionId = SessionId.ToString()
                };

                ent.TeamActivities.Add(temp);

                ent.SaveChanges();
            }
        }
        private string GetShiftNm()
        {
           return new SimulatorEntities().procGetShiftName(RunNo).SingleOrDefault().ToString();
        }
        private int GetPanelsPerShelf(string type, int pid)
        {
            int ret = 0;

            string extnm = GetExtName(pid);
            if (!string.IsNullOrEmpty(extnm))
                ret = new SimulatorEntities().Database.SqlQuery<int>("select dbo.fnGetPanelPerShelf(@p_pid, @p_extnm, @p_type)",
                                                            new SqlParameter("@p_pid", pid),
                                                            new SqlParameter("@p_extnm", extnm),
                                                            new SqlParameter("@p_type", type))
                                                            .SingleOrDefault();
            return ret;
        }

        private int GetShelvesPerCart(string type, int pid)
        {
            int ret = 0;

            string extnm = GetExtName(pid);
            if(!string.IsNullOrEmpty(extnm))
                ret = new SimulatorEntities().Database.SqlQuery<int>("select dbo.fnGetShelfPerCart(@p_pid, @p_extnm, @p_type)",
                                                       new SqlParameter("@p_pid", pid),
                                                       new SqlParameter("@p_extnm", extnm),
                                                       new SqlParameter("@p_type", type))
                                                       .SingleOrDefault();
            return ret;
        }
        
        public string GetExtName(int pid)
        {
            var temp = new SimulatorEntities().procGetExtruderByPlan(pid).ToList();

            if(temp.Count<string>() > 0)
                return temp.SingleOrDefault().ToString();
            else
               return null;
        }
        public void AddNote(int pid, string note)
        {
            int sumid = GetSummary(pid).Id;

            for (int i = 0; i < EstDetails.Count; i++)
            {
                if (EstDetails[i].SumId == sumid)
                {
                    EstDetails[i].Note = EstDetails[i].Note + "\r\n" + note;
                    break;
                }
            }
        }
        public void AddAction(int pid, string action)
        {
            int sumid = GetSummary(pid).Id;

            for (int i = 0; i < EstDetails.Count; i++)
            {
                if (EstDetails[i].SumId == sumid)
                {
                    EstDetails[i].Action += string.IsNullOrEmpty(EstDetails[i].Action) ? action : EstDetails[i].Action + ", " + action;
                    break;
                }
            }
        }
        public void AddNote(string note)
        {
            AddNote(CurrPlans.Last().Plan.Id, note);
        }
        public ProductionPlan GetProcessingPlan(string team)
        {
            return CurrPlans.Where(x => x.Team == team && x.Status == Constants.Processing).Select(x => x.Plan).Single();
        }
        public void AddAction(string action)
        {
            AddAction(CurrPlans.Last().Plan.Id, action);
        }
        public EstimateSummary GetSummary(int pid = 0)
        {
            if (pid == 0)
                return EstSums.Last();

            return EstSums.Where(x => x.PPId == pid).Single();
        }
        public EstimateSummary GetSummaryById(int sumid)
        {
            return EstSums.Where(x => x.Id == sumid).Single();
        }
        public EstimateDetail GetDetail(int pid = 0)
        {
            if (pid == 0)
                return EstDetails.Last();

            return EstDetails.Where(x => x.SumId == GetSummary(pid).Id).Single();
        }
        public int GetCurrentHour(int pid)
        {
            return GetSummary(pid).PlanStart + GetDetail(pid).AtHour;
        }
        public int GetCurrentHour()
        {
            var lsum = EstSums.Join(EstDetails, a => new { Id = a.Id }, b => new { Id = b.SumId }, (a, b) => new { HR = a.PlanStart + b.AtHour }).ToList();
            return lsum.Max(x => x.HR);
        }
        public int GetLastPlan(int pid, string team)
        {
            int ret = 0;

            if (CurrPlans.Where(x => x.Team == team).Count() > 1)
            {
                var cps = CurrPlans.Where(x => x.Team == team && x.Plan.Id != pid)
                        .Join(new SimulatorEntities().EstimateSummaries, a => new { Id = a.Plan.Id }, b => new { Id = b.PPId }, (a, b) => b )
                        .Where(x => x.SessionId == SessionId.ToString()).ToList();

                ret = cps.Where(x => x.PlanStart == cps.Max(y => y.PlanStart)).Select(z => z.PPId).Single();
            }
            return ret;
        }

        public int GetNextPlan(string team, List<ProductionPlan> plans)
        {
            int ret = 0; //no more plans

            if (CurrPlans.Count == 0)
                ret = plans.First().Id;
            else
            {
                if (CurrPlans.Any(x => x.Team == team && x.Status == Constants.Processing))
                    ret = -9999; //in processing plan exists
                else
                {
                    string extname = null;
                    if(CurrPlans.Any(x => x.Team != team && x.Status == Constants.Processing))
                    {
                        extname = CurrPlans.Where(x => x.Team != team && x.Status == Constants.Processing).Select(x => x.ExtName).First();
                    }

                    var tplans = new List<ProductionPlan>();
                    foreach (var p in plans)
                    { //plans.Except(CurrPlans.Select(x => x.Plan).ToList()).ToList();
                        if(!CurrPlans.Any(x => x.Plan.Id == p.Id))
                        {
                            tplans.Add(p);
                        }
                    }

                    if (tplans.Count == 0 && !string.IsNullOrEmpty(extname)
                        && (EstRun.SameExt ?? false))
                    {
                        var ps = CurrPlans.Where(x => x.Team != team && x.Status == Constants.Processing).First();
                        if(ps.ExtName.Contains("Bongioanni"))
                            ret = ps.Plan.Id;
                    }
                    else
                    {
                        foreach (var pp in tplans)
                        {
                            var lextname = GetExtName(pp.Id);

                            if(lextname == null)
                            {
                                Log2File.LogInfo("Error: No Extruder found for Plan " + pp.Id.ToString());
                                continue;
                            }

                            if (lextname.Contains("Bongioanni"))
                            {
                                ret = pp.Id;
                                break;
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(extname) && extname.Contains("Bannot"))
                                    continue;
                                else
                                    ret = pp.Id;
                            }
                        }
                    }
                }

            }

            return ret;
        }

        public string GetUniqueExtName(int pid, string team)
        {
            string ret = GetExtName(pid);

            if (CurrPlans.Any(x => x.Team != team && x.Status == Constants.Processing))
            {
                var temp = CurrPlans.Where(x => x.Team != team && x.Status == Constants.Processing).Select(x => x.ExtName).First();

                if(ret.Contains("Bongioanni") && temp.Contains("Bongioanni"))
                {
                    if (temp.Contains("1"))
                        ret = ret.Replace("1", "2");
                    else
                        ret = ret.Replace("2", "1");
                }
            }

            return ret;
        }
        public void SaveSessionRun()
        {
            using (var ent = new SimulatorEntities())
            {
                ent.SessionRuns.Add(new SessionRun
                {
                    SessionId = SessionId.ToString(),
                    RunNum = RunNo,
                    CreateDate = DateTime.Now
                });
                ent.SaveChanges();
            }
        }
        public string GetSessionFromRunName(string nm)
        {
            //first is sufficient 
            return new SimulatorEntities().EstimateRuns.Where(x => x.RunNm == nm).Select(x => x.SessionRuns).First().Select(y => y.SessionId).Single();
        }
    }
}

