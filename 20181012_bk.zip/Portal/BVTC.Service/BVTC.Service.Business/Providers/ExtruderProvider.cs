﻿using System;
using System.Linq;
using System.Data;
using System.Diagnostics;

using BVTC.Service.Data.Models.Simulator;
using BVTC.Service.Business.TransferObjects;
using BVTC.Service.Common;
using BVTC.Service.Common.Utilities;

namespace BVTC.Service.Business
{
    public class ExtruderProvider
    {
        private SimulatorTracing _st;

        public EstimateProvider EstPro { get; set; }
        public SimulatorEntities Ent { get; set; }
        public string TeamNm { get; set; }
        public string ExtNm { get; set; }

        public int ColorTime { get; set; } //-1 unknown, 9999 changed. Assuming can be interuppted by dryer
        public int DyeTime { get; set; }
        //TODO: build a temp Extruder table
        public int ColorTime1 { get; set; } //only team specific variable
        public int DyeTime1 { get; set; }

        public ExtruderProvider(EstimateProvider estpro)
        {
            _st = new SimulatorTracing();

            EstPro = estpro;
            Ent = new SimulatorEntities();
            Init();
        }
        public void Init()
        {
            ColorTime = -1;
            DyeTime = -1;
            ColorTime1 = -1;
            DyeTime = -1;

            TeamNm = "";
            ExtNm = "";
        }
        public void SetTeamAndExt(string team, string ext)
        {
            TeamNm = team;
            ExtNm = ext;
        }
        public void DoExt()
        {
            if(!ChangeColor() 
                && !ChangeDye())
                Extrusion();
        }
        private int GetPId()
        {
            return EstPro.CurrPlans.Where(x => x.Team == TeamNm && x.Status == Constants.Processing).Select(x => x.Plan.Id).Single();
        }
        private bool ChangeColor()
        {
            bool ret = false;

            object ct = new object();

            if (TeamNm.Contains("1"))
                ct = ColorTime;
            else
                ct = ColorTime1;

            if ((int)ct == 9999 || !NeedToChangeColor())
                return ret;

            using(var ent = new SimulatorEntities())
            {
                int ctime = ent.Extruders.Where(x => x.ExtruderName == ExtNm)
                               .Select(x => x.ColorCleanOut).Single()??0;

                if((int)ct == -1)
                     ct = 0;

                _st.Tracing("At " + EstPro.GetCurrentHour(GetPId()) + ": Plan#" + GetPId() + ": Changing color on " + ExtNm + ", T#" + TeamNm, EstPro.SessionId.ToString());

                EstPro.AddNote(GetPId(), "Changing extruder color");
                EstPro.GetDetail(GetPId()).Action = "Changing Color";
                EstPro.SaveActivity(new TeamActivity {
                    TeamName = TeamNm,
                    Act = "Changing Color",
                    ExtName = ExtNm,
                    PId = GetPId(),
                    SessionId = EstPro.SessionId.ToString()
                });

                ct = (int)ct + 1;
                if ((int)ct == ctime)
                    ct = 9999;
                ret = true;

                if (TeamNm.Contains("1"))
                    ColorTime = (int)ct;
                else
                    ColorTime1 = (int)ct;
            }
            return ret;
        }
        private bool ChangeDye()
        {
            bool ret = false;

            object dt = new object();

            if (TeamNm.Contains("1"))
                dt = DyeTime;
            else
                dt = DyeTime1;

            if ((int)dt == 9999 || !NeedToChangeDye())
                return ret;

            using (var ent = new SimulatorEntities())
            {
                int ctime = ent.Extruders.Where(x => x.ExtruderName == ExtNm)
                               .Select(x => x.DyeCleanOut).Single() ?? 0;

                if ((int)dt == -1)
                    dt = 0;

                _st.Tracing("At " + EstPro.GetCurrentHour(GetPId()) + ": Plan#" + GetPId() + ": Changing dye on " + ExtNm + ", T#" + TeamNm, EstPro.SessionId.ToString());


                EstPro.AddNote(GetPId(), "Changing extruder dye");
                EstPro.GetDetail(GetPId()).Action = "Changing Dye";
                EstPro.SaveActivity(new TeamActivity
                {
                    TeamName = TeamNm,
                    Act = "Changing Dye",
                    ExtName = ExtNm,
                    PId = GetPId(),
                    SessionId = EstPro.SessionId.ToString()
                });

                dt = (int)dt + 1;
                if ((int)dt == ctime)
                    dt = 9999;
                ret = true;

                if (TeamNm.Contains("1"))
                    DyeTime = (int)dt;
                else
                    DyeTime1 = (int)dt;
            }
            return ret;
        }
        private void Extrusion()
        {
            CartPoolProvider cppro = new CartPoolProvider(EstPro);
            ShelfProvider sfpro = new ShelfProvider(EstPro);

            EstimateSummary sum = EstPro.GetSummary(GetPId());
            EstimateDetail detail = EstPro.GetDetail(GetPId());

            //var cpdto = cppro.GetPoolToPush("ED");
            int poolcap = cppro.GetPoolCap("ED");

            int usedsf = sfpro.GetUsedShelves(sum.PPId);
            int sfcap = sfpro.GetShelfTotal(sum.PPId);

            var extor = Ent.Extruders.Where(x => x.ExtruderName == sum.ExtruderName).Single();

            int panelstoext = EstPro.GetPlanPanel(sum.PPId) - sum.Panels??0;

            int tt1 = sum.PanelsPerShelf??0;
            int tt2 = sum.ShelvesPerCart??0;

            int shelevestoext = (sum.PanelsPerShelf) == 0 ? 0 : (int)Math.Ceiling((double)panelstoext /tt1);
            int cartstoext = (sum.ShelvesPerCart) == 0 ? 0 : (int)Math.Ceiling((double)shelevestoext /tt2);


            if (usedsf >= sfcap
                || Math.Min(shelevestoext, extor.ExtrusionRate * sum.ShelvesPerCart??0) 
                             > sfcap - usedsf)
            {
                _st.Tracing("No shelves", EstPro.SessionId.ToString());

                EstPro.AddNote(GetPId(), "No enough Shelves for Extrusion");
                EstPro.GetDetail(GetPId()).Action = "None";
                return;
            }

            var cartaval = new SimulatorEntities().Database.SqlQuery<int>("select sum(a.carts) from dbo.temp_cartpoolplan a join dbo.cartpool b on a.poolnum = b.poolnum and a.sessionid = '" 
                                                                          + EstPro.SessionId.ToString() + "' and b.pooltype = 'KE'")
                                         .Single();

            if(cartaval < extor.ExtrusionRate)
            {
                _st.Tracing("No Carts in pool for ext", EstPro.SessionId.ToString());

                EstPro.AddNote(GetPId(), "No cart available for ext load");
                EstPro.GetDetail(GetPId()).Action = "None";
                return;
            }
            // no Math.Min(cartstoext, extor.ExtrusionRate). extruder extruding extra racks/carts to feed the cart's cap
            if (Math.Min(cartstoext, extor.ExtrusionRate) > poolcap - cppro.GetTotalUsedInPools("ED"))
            {
                _st.Tracing("No Ext Pool for Push", EstPro.SessionId.ToString());

                EstPro.AddNote(GetPId(), "No ED Pool available for push");
                EstPro.GetDetail(GetPId()).Action = "None";
                return;
            }
                        
            using (var ent = new SimulatorEntities())
            {
                _st.Tracing("At " + EstPro.GetCurrentHour(GetPId())  + ": Plan#" + GetPId() + ": Extruding " + extor.ExtrusionRate + " carts on " + ExtNm + ", T#" + TeamNm, EstPro.SessionId.ToString());

                EstPro.AddNote(GetPId(), "Extruding on Extruder#" + extor.ExtruderName);
                detail.Action = "Extruding";
                EstPro.SaveActivity(new TeamActivity
                {
                    TeamName = TeamNm,
                    Act = detail.Action,
                    ExtName = ExtNm,
                    PId = sum.PPId,
                    SessionId = EstPro.SessionId.ToString()
                });

                cppro.Remove(new CartPoolDTO {
                    PId = 0, //insignificant
                    PoolNo = cppro.GetPoolNumByType("KE"),
                    Carts = extor.ExtrusionRate
                });

                var cp = new CartPoolDTO {
                    Carts = extor.ExtrusionRate,
                    PId = sum.PPId,
                    PoolNo = cppro.GetPoolNumByType("ED")
                };
                cppro.Add(cp);
                _st.Tracing("Debug: P#" + sum.PPId + " added " + cp.Carts + " carts. EDPool, T#" + TeamNm, TraceLevel.Verbose, EstPro.SessionId.ToString());

                detail.CartExted = cp.Carts;
            
                sfpro.Add((int)cp.Carts * tt2, cp.PId);
                EstPro.AddNote(GetPId(), "Added Shelves");

                detail.RackExted = (int)detail.CartExted * tt2; 
                detail.PanelExted = tt1 * (int)detail.RackExted; 

                sum.Panels = sum.Panels + detail.PanelExted;
                sum.Racks = sum.Racks + detail.RackExted;
                sum.Carts = sum.Carts + detail.CartExted;
            }
        }
        private bool NeedToChangeColor()
        {
            bool ret = false;

            string lastcolor;
            int lastpid = EstPro.GetLastPlan(GetPId(), TeamNm);

            if (lastpid == 0)
            {
                lastcolor = EstPro.EstRun.ExtColor;
            }
            else
            {
                lastcolor = Ent.ProductionPlans.Where(x => x.Id == lastpid).Select(x => x.Color).SingleOrDefault();
            }
            int pid = GetPId();
            if (!string.IsNullOrEmpty(lastcolor)
                    && lastcolor.ToUpper() != EstPro.CurrPlans.Where(x => x.Plan.Id == pid).Select(x => x.Plan.Color).Single().ToUpper())
                   ret = true;

            return ret;
        }
        private bool NeedToChangeDye()
        {
            bool ret = false;

            int lastdye;
            int lastpid = EstPro.GetLastPlan(GetPId(), TeamNm);

            if (lastpid == 0)
            {
                lastdye = EstPro.EstRun.ExtDye ?? 0;
            }
            else
            {
                lastdye = Ent.ProductionPlans.Where(x => x.Id == lastpid).Select(x => x.Dye).SingleOrDefault();
            }

            int pid = GetPId();
            if (lastdye > 0 && lastdye != EstPro.CurrPlans.Where(x => x.Plan.Id == pid).Select(x => x.Plan.Dye).Single())
                ret = true;

            return ret;
        }
        
    }
}
