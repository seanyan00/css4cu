﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Configuration;
using System.Linq;
using System.ServiceModel;

using BVTC.Service.Common;
using BVTC.Service.Common.Utilities;
using BVTC.Service.Data.Models.Portal;
using BVTC.Service.TransferObject.Main;

namespace BVTC.Service.Business.Providers
{
    public class AuthProvider
    {
        private const string LOCKEDBYNAME = "MPMLogin";

        private const string KEY_LOGINWINDOW = "Auth_LoginWindow";
        private const string KEY_LOGINATTEMPTS = "Auth_LoginAttempts";
        private const string KEY_LOGINRESET = "Auth_LoginReset";

        private String _path;
        private String _filterAttribute;

        private static double _tokenWindow;
        private static string _appDomain;
        private static int _loginWindow;
        private static int _loginAttempts;
        private static int _loginReset;

        static AuthProvider()
        {
            _appDomain = ConfigurationManager.AppSettings[Constants.KEY_AUTH_ADDOMAIN].ToString();
            _tokenWindow = Convert.ToDouble(ConfigurationManager.AppSettings[Constants.KEY_TOKENWINDOW].ToString());
            _loginAttempts = Convert.ToInt32(ConfigurationManager.AppSettings[KEY_LOGINATTEMPTS].ToString());
            _loginReset = Convert.ToInt32(ConfigurationManager.AppSettings[KEY_LOGINRESET].ToString());
            _loginWindow = Convert.ToInt32(ConfigurationManager.AppSettings[KEY_LOGINWINDOW].ToString());
        }
        public AuthProvider(String path)
        {
            _path = path;
        }

        public bool IsAuthenticated(String domain, String uname, String pwd)
        {
            bool ret = false;
            string d = domain;

            if(string.IsNullOrEmpty(domain))
                d = _appDomain;

            String domainAndUsername = d + @"\" + uname;
            DirectoryEntry entry = new DirectoryEntry(_path, domainAndUsername, pwd);

            try
            {
                Object obj = entry.NativeObject;

                DirectorySearcher search = new DirectorySearcher(entry);

                search.Filter = "(SAMAccountName=" + uname + ")";
                search.PropertiesToLoad.Add("cn");
                SearchResult result = search.FindOne();

                if (null == result)
                {
                    return ret;
                }

                _path = result.Path;
                _filterAttribute = (String)result.Properties["cn"][0];
                ret = true;
            }
            catch (Exception ex)
            {
                ret = false;
            }

            return ret;
        }

        public List<string> GetGroups()
        {
            var ret = new List<string>();

            DirectorySearcher search = new DirectorySearcher(_path);
            search.Filter = "(cn=" + _filterAttribute + ")";
            search.PropertiesToLoad.Add("memberOf");
            
            try
            {
                SearchResult result = search.FindOne();

                int pcount = result.Properties["memberOf"].Count;

                String dn;
                int equalsIndex, commaIndex;

                for (int i = 0; i < pcount; i++)
                {
                    dn = (String)result.Properties["memberOf"][i];

                    equalsIndex = dn.IndexOf("=", 1);
                    commaIndex = dn.IndexOf(",", 1);
                    if (-1 == equalsIndex)
                    {
                        return null;
                    }

                    ret.Add(dn.Substring((equalsIndex + 1), (commaIndex - equalsIndex) - 1));
                  

                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }

        public List<string> GetGroupManager()
        {
            var ret = new List<string>();

            DirectorySearcher search = new DirectorySearcher(_path);
            search.Filter = "(cn=" + _filterAttribute + ")";
            search.PropertiesToLoad.Add("manager");

            try
            {
                SearchResult result = search.FindOne();

                int pcount = result.Properties["memberOf"].Count;

                String dn;
                int equalsIndex, commaIndex;

                for (int i = 0; i < pcount; i++)
                {
                    dn = (String)result.Properties["memberOf"][i];

                    equalsIndex = dn.IndexOf("=", 1);
                    commaIndex = dn.IndexOf(",", 1);
                    if (-1 == equalsIndex)
                    {
                        return null;
                    }

                    ret.Add(dn.Substring((equalsIndex + 1), (commaIndex - equalsIndex) - 1));


                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return ret;
        }

        private void CreateLogin()
        {
            throw new NotImplementedException();
        }

        public BVTCUserDTO CreateSession(string pwd, int eid)
        {
            var uname = new MPMPortalEntities().Employees.Where(x => x.Id == eid).Select(x => x.UserName).Single();
            return CreateSession("", pwd,
                   new BVTCUserDTO
                   {
                       UId = eid,
                       Uname = uname, 
                       FromApp = "User ID Auth",
                       FromDevice = "",
                       FromIP = "",
                       FullName = "",
                       Timestamp = DateTime.Now,
                       Token = ""
                   }
                );
        }
        public BVTCUserDTO CreateSession(string domain, string pwd, BVTCUserDTO bu)
        {
            var bud = new SessionToken {
                       FromApp = bu.FromApp,
                       FromDevice = bu.FromDevice,
                       FromIP = bu.FromIP,
                       Token = bu.Token,
                       UserName = bu.Uname
            };

            int uid = 0;

            var ret = new List<string>();
            try
            {
                using (var ent = new MPMPortalEntities())
                {
                    SessionToken temp = null;

                    if (ent.SessionTokens.Any(x => x.UserName == bud.UserName
                                                  && x.FromApp == bud.FromApp))
                    {
                        temp = ent.SessionTokens.Where(x => x.UserName == bud.UserName
                                                     && x.FromApp == bud.FromApp)
                                                     .OrderByDescending(x => x.LastLogin).First();

                        if (temp != null && (temp.Locked ?? false))
                        {
                            if (temp.LockedBy == LOCKEDBYNAME)
                            {
                                if (DateTime.Compare(temp.LastLogin.AddMinutes(_loginReset), DateTime.Now) > 0)
                                {
                                    throw new FaultException<AuthFault>(new AuthFault((int)LoginStatus.ExceededAttempt, "Too many failed attempts"));
                                }
                            }
                            else
                            {
                                throw new FaultException<AuthFault>(new AuthFault((int)LoginStatus.Locked, "Locked account"));
                            }
                        }

                        temp.Locked = false;
                    }

                    if (IsAuthenticated(domain, bu.Uname, pwd))
                    {
                        if (temp == null)
                        {
                            bud.Id = 0;
                        }
                        else
                        {
                            bud = temp;
                        }
                        bud.LoginCount = 0;
                        bud.LoginStart = DateTime.Now;
                        bud.LastLogin = DateTime.Now;
                        bud.CreateDate = DateTime.Now;
                        bud.UpdateDate = DateTime.Now;
                        bud.LastAccess = DateTime.MaxValue;
                        bud.Token = Guid.NewGuid().ToString();
                        bud.LoginStatus = (int)LoginStatus.Active;
                        uid = ent.Employees.Where(x => x.UserName == bu.Uname).Select(x => x.Id).Single();
                       
                        ret = GetGroups();

                        if(ret.Count == 0)
                        {
                            bud.LoginStatus = (int)LoginStatus.NoGroupAssigned;
                            throw new FaultException<AuthFault>(new AuthFault((int)LoginStatus.NoGroupAssigned, "No group was assigned"));
                        }
                        if (temp == null)
                            ent.SessionTokens.Add(bud);

                        ent.SaveChanges();

                    }
                    else
                    {
                        if (temp == null)
                        {
                            bud.Id = 0;
                            bud.LoginStart = DateTime.Now;  
                            bud.LoginCount = 1;
                            bud.LastAccess = DateTime.MaxValue;
                            bud.CreateDate = DateTime.Now;
                            bud.UpdateDate = DateTime.Now;
                        } else
                        {
                            bud = temp;
                            bud.LoginCount = temp.LoginCount + 1;
                            bud.UpdateDate = DateTime.Now;

                            if (DateTime.Compare(bud.LoginStart.AddMinutes(_loginWindow), DateTime.Now) <= 0 || bud.LoginCount <= 1)// previously successed
                            {
                                bud.LoginStart = DateTime.Now;
                                bud.LoginCount = 1;
                            }
                        }
                        bud.LastLogin = DateTime.Now;
                        bud.LoginStatus = (int)LoginStatus.Failed;

                        if (bud.LoginCount > _loginAttempts)
                        {
                            bud.LoginStatus = (int)LoginStatus.ExceededAttempt;
                            bud.Locked = true;
                            bud.LockedBy = LOCKEDBYNAME;
                            ent.SaveChanges();
                            throw new FaultException<AuthFault>(new AuthFault((int)LoginStatus.ExceededAttempt, "Too many failed attempts"));
                        }
                        else
                        {
                            if (temp == null)
                                ent.SessionTokens.Add(bud);

                            ent.SaveChanges();
                            throw new FaultException<AuthFault>(new AuthFault((int)LoginStatus.Failed, "Incorrect Username or Password"));
                        }
                       
                    }
                }
            }
            catch(FaultException<AuthFault> ex)
            {
                Log2File.LogInfo("Error: " + bud.UserName + " -- " + ex.Detail.ErrorMsg);
                throw new FaultException<AuthFault>(ex.Detail);
            }
            catch (Exception ex)
            {
                Log2File.LogInfo("Error: for User " + bud.UserName + " " + ex.Message);
                throw new FaultException<AuthFault>(new AuthFault((int)LoginStatus.ServerError, "Server Error on creating user's session"), 
                                                    new FaultReason("See Detail"));
            }

            return new BVTCUserDTO {
                FromApp = bud.FromApp,
                FromDevice = bud.FromDevice,
                FromIP = bud.FromIP,
                Token = bud.Token,
                Uname = bud.UserName,
                Roles = ret.ToArray(),
                Timestamp = DateTime.Now,
                UId = uid
            };
        }

        public void SignOut(string appname, string uname)
        {
            using(var ent = new MPMPortalEntities())
            {
                var st = ent.SessionTokens.Where(x => x.FromApp == appname && x.UserName == uname && x.LoginStatus == (int)LoginStatus.Active).SingleOrDefault();
                if(st != null)
                {
                    st.LoginStatus = (int)LoginStatus.LogedOut;
                    st.UpdateDate = DateTime.Now;
                    ent.SaveChanges();
                }
               
            }
        }
    }
}
