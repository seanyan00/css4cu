﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;
using System.Reflection;

using iText.Kernel.Pdf;
using iText.Kernel.Geom;
using iText.Kernel.Font;
using iText.Kernel.Events;
using iText.Kernel.Pdf.Xobject;
using iText.Kernel.Pdf.Canvas;
using iText.Kernel.Pdf.Canvas.Draw;
using iText.Kernel.Colors;
using iText.Layout;
using iText.Layout.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;
using iText.Layout.Renderer;
using iText.Layout.Borders;
using iText.Layout.Font;

using iText.IO;
using iText.IO.Font.Otf;
using iText.IO.Util;
using iText.IO.Source;
using iText.IO.Image;
using iText.Forms;
using iText.Pdfa;

using BVTC.Service.Common;
using BVTC.Service.Data.Models;
using BVTC.Service.TransferObject.Main;
using BVTC.Service.Data.Models.Portal;
using BVTC.Service.Common.Utilities;

namespace BVTC.Service.Business.Providers
{
    public class PDFProvider
    {
        private const int A4_AXIS_X = 595;
        private const int A4_AXIS_Y = 842;
        private const int A4_MARGIN = 36;
        private const int A4_AVAIL_X = A4_AXIS_X - 2 * A4_MARGIN;
        private const float A4_TABLE_X = A4_AXIS_X * 0.8F;
        private const int A4_FOOTER_HEIGHT = 72;
        private const int A4_FOOTER_HEIGHT_SHORT = 45;
        private const int A4_HEADER_HEIGHT = 72;

        private const int LETTER_AXIS_X = 612;
        private const int LETTER_AXIS_Y = 792;
        private const int LETTER_MARGIN = 36;
        private const int LETTER_AVAIL_X = LETTER_AXIS_X - 2 * LETTER_MARGIN;
        private const float LETTER_TABLE_X = LETTER_AXIS_X * 0.8F;
        private const float LETTER_TABLE_Y = LETTER_AXIS_Y;
        private const int LETTER_FOOTER_HEIGHT = 72;
        private const int LETTER_FOOTER_HEIGHT_SHORT = 45;
        private const int LETTER_HEADER_HEIGHT = 72;

        private const string LOGO_NAME = "BVTC-Logo-BLACK-horizontal.jpg";
        private const string LOGO_NAME_G = "BVTC-Logo-CMYK-horizontal.jpg";
        private const string BOLTOP_NAME = "New_BOL_Top.png";
        private const string BOLTOPCOPY_NAME = "New_BOL_Top_Copy.png";
        private const string BOLBOTTOM_NAME = "New_BOL_Bottom.png";
        private const string POTOP_NAME = "poheader.png";
        private const string POBOTTOM_NAME = "pobottom.png";
        private const string PDL_NAME = "Parts_Sheet.png";
        private const string PDL_EMPTY_THUMB = "empty_thumb.png";


        private readonly string File_Path;
        private readonly string BVTC_Logo;
        private readonly string BVTC_Logo_G;
        private readonly string BOLTop;
        private readonly string BOLTopCopy;
        private readonly string BOLBottom;
        private readonly string POTop;
        private readonly string POBottom;
        private readonly string PDLSIDE;
        private readonly string PDLEMPTYTHUMB;

        private int pageNum = 0;
        private string projNo = "";
        private string oId = "";

        public BVTCUserDTO BUD { get; private set; }
        public PdfFont PageFont { get; set; }
        public PdfFont PageFontBold { get; set; }
  
        class PackingListHeader
        {
            internal int PackId { get; set; }
            internal int CrateNo { get; set; }
            internal string PackedBy { get; set; }
            internal string InspectedBy { get; set; }
            internal DateTime DatePacked { get; set; }
            internal string PackingListNo { get; set; }
        }
        class CMBSListHeader
        {
            internal string Priority { get; set; }
            internal string BlockId { get; set; }
            internal string BlkTyp { get; set; }
            internal string Sample { get; set; }
            internal string DrawingNumber { get; set; }
            internal string Typ { get; set; }
            internal int Qty { get; set; }
            internal string User { get; set; }
            internal string Submitted { get; set; }
            internal string Approved { get; set; }
            internal string Length { get; set; }
            internal string Height { get; set; }
            internal string Depth { get; set; }
            internal string Description { get; set; }
            internal string Comments { get; set; }
        }
        public PDFProvider(BVTCUserDTO bud)
        {
            BUD = bud;

            File_Path = ConfigurationManager.AppSettings[Constants.KEY_FILEROOT].ToString();
            BVTC_Logo = File_Path + "\\Templates\\" + LOGO_NAME;
            BVTC_Logo_G = File_Path + "\\Templates\\" + LOGO_NAME_G;
            BOLTop = File_Path + "\\Templates\\" + BOLTOP_NAME;
            BOLTopCopy = File_Path + "\\Templates\\" + BOLTOPCOPY_NAME;
            BOLBottom = File_Path + "\\Templates\\" + BOLBOTTOM_NAME;
            POTop = File_Path + "\\Templates\\" + POTOP_NAME;
            POBottom = File_Path + "\\Templates\\" + POBOTTOM_NAME;
            PDLSIDE = File_Path + "\\Templates\\" + PDL_NAME;
            PDLEMPTYTHUMB = File_Path + "\\Templates\\" + PDL_EMPTY_THUMB;

            PageFont = PdfFontFactory.CreateFont(iText.IO.Font.Constants.StandardFonts.HELVETICA);
            PageFontBold = PdfFontFactory.CreateFont(iText.IO.Font.Constants.StandardFonts.HELVETICA_BOLD);
        }
        public PDFProvider(BVTCUserDTO bud, string projno) : this(bud)
        {
            BuildProjDir(projno);
        }
        private void BuildProjDir(string projno)
        {
            if (string.IsNullOrEmpty(projno))
                return;

            var dtyps = new MPMPortalEntities().DocumentTypes.Where(x => x.CreateDir && x.ProjectRelated).Select(x => x.Code).ToList();

            Common.Utilities.FileUtil.BuildProjDir(projno, dtyps);
        }
        public string CreateFile(string id, string doctype, string projectno = "")
        {
            if (string.IsNullOrEmpty(projectno))
                throw new Exception("ProjectNo cannot empty for PDF files");

            projNo = projectno;

            var path = Common.Utilities.FileUtil.GetFileName(id + ".pdf", projectno, doctype, "");
            var dtyps = new MPMPortalEntities().DocumentTypes.Where(x => x.CreateDir).Select(x => x.Code).ToList();
            Common.Utilities.FileUtil.BuildProjDir(projectno, dtyps);
            
            oId = id;

            try
            {
                switch (doctype)
                {
                    case "PackList":
                        CreatePackList(path);
                        break;
                    case "PackListByBOL":
                        CreatePackListByBOL(path);
                        break;
                    case "BOL":
                        CreateBOL(path);
                        break;
                    case "PO":
                        CreatePO(path);
                        break;
                    case "PartDrawingList":
                        CreatePartDrawingList(path);
                        break;
                    case "CMBS":
                        CreateCMBS(path);
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                Log2File.LogInfo("Error: " + ex.Message + "\r\n" + ex.StackTrace);
                throw;
            }

            return path;
        }
        public Stream Create(string id, string doctype, string projectno = "")
        {
            try
            {
                return File.OpenRead(CreateFile(id, doctype, projectno));
            }
            catch(Exception ex)
            {
                throw;
            }
        }
        private void CreatePO(string fname)
        {
            var id = Convert.ToInt32(oId);

            var writer = new PdfWriter(fname);

            var pdf = new PdfDocument(writer);
            var doc = new iText.Layout.Document(pdf, PageSize.LETTER);

            doc.SetMargins(LETTER_MARGIN, LETTER_MARGIN, LETTER_MARGIN, LETTER_MARGIN);

            var obj = new MPMPortalEntities().vwPOHeaders.Where(x => x.Id == id).Single();

            pdf.AddEventHandler(PdfDocumentEvent.END_PAGE, new TableFooterEventHandler(true));

            Image potop = new Image(ImageDataFactory.Create(POTop));

            potop.ScaleToFit(LETTER_AXIS_X - 2 * LETTER_MARGIN, 270);

            doc.Add(GetPOTopImage(pdf, potop, obj));

            float ttl;

            Table tbl = GetPODetail(320, out ttl);

            doc.Add(tbl);

            Image pobottom = new Image(ImageDataFactory.Create(POBottom));
            pobottom.ScaleToFit(LETTER_AXIS_X - 2 * LETTER_MARGIN, 223);
            Image img = GetPOBottomImage(pdf, pobottom, obj, ttl);
            doc.Add(img);
           // AddPONotes(pdf, obj.Notes);
                    
            PdfCanvas pdfca = new PdfCanvas(pdf.GetLastPage());
            Rectangle rect = new Rectangle(87, 130, 198, 40);
            new Canvas(pdfca, pdf, rect).SetFontSize(8).Add(new Paragraph(obj.Notes));
          //  pdfca.Rectangle(rect);
            pdfca.Stroke();

            doc.Close();
            pdf.Close();
        }
        private void CreatePartDrawingList(string fname)
        {
            var id = Convert.ToInt32(oId);

             var writer = new PdfWriter(fname);

            var pdf = new PdfDocument(writer);
            var doc = new iText.Layout.Document(pdf, PageSize.LETTER.Rotate());
                       
            doc.SetMargins(15, 15 + 145, 15, 15);
            float height = PageSize.LETTER.GetWidth() - 20;
            float width = PageSize.LETTER.GetHeight() - 30;

            var header = new MPMPortalEntities().vwPartDrawingListHeaders.Where(x => x.Id == id).Single();
            var dl = new MPMPortalEntities().vwPartDrawingListDetails.Where(x => x.Id == id)
                .OrderBy(x => x.ProfileCode).ToList();

            Image pdlside = new Image(ImageDataFactory.Create(PDLSIDE));
            pdlside.ScaleToFit(145, height);

            pdf.AddEventHandler(PdfDocumentEvent.END_PAGE, new MixPageEventHandler(header, pdlside, doc));

          
            Table maintbl = GetPDLDrawingTable(width - 145, height - 10, dl, pdf);
            doc.Add(maintbl);
                    
            doc.Close();
        }
        private float GetStringWidth(string txt, float size, PdfFont font)
        {
            GlyphLine glyphLine = font.CreateGlyphLine(txt);
            int width = 0;
            for (int i = 0; i < glyphLine.Size(); i++)
            {
               Glyph glyph = glyphLine.Get(i);
               width += glyph.GetWidth();
            }

            float userspacewidth = width * size / 1000.0f;
            
            return width;
        }
        private void CreateBOL(string fname)
        {
            var id = Convert.ToInt32(oId);

            bool firstbol = !File.Exists(fname);

            if(!firstbol && !File.Exists(fname + ".orig"))
            {
                File.Copy(fname, fname + ".orig");
            }

            var writer = new PdfWriter(fname);

            var pdf = new PdfDocument(writer);
            var doc = new iText.Layout.Document(pdf, PageSize.LETTER);

            doc.SetMargins(10, LETTER_MARGIN, LETTER_MARGIN, LETTER_MARGIN);

            var obj = new MPMPortalEntities().vwBOLMasters.Where(x => x.Id == id).Single();

            pdf.AddEventHandler(PdfDocumentEvent.END_PAGE, new TableFooterEventHandler(true));

            Image boltop = new Image(ImageDataFactory.Create(firstbol ? BOLTop : BOLTopCopy));
           
            boltop.ScaleToFit(LETTER_AXIS_X - 2 * LETTER_MARGIN, 270);
           
            doc.Add(GetBOLTopImage(pdf, boltop, obj));

            Table tbl = GetCrateBlock(253);
         
            doc.Add(tbl);
            
            Image bolbottom = new Image(ImageDataFactory.Create(BOLBottom));
            bolbottom.ScaleToFit(LETTER_AXIS_X - 2 * LETTER_MARGIN, 223);
            Image img = GetBOLBottomImage(pdf, bolbottom, obj);
            
            doc.Add(img);

            doc.Close();
        }
        private void CreatePackList(string fname)
        {
            var writer = new PdfWriter(fname);

            var pdf = new PdfDocument(writer);
            var doc = new iText.Layout.Document(pdf, PageSize.LETTER);

            doc.SetMargins(LETTER_HEADER_HEIGHT, LETTER_MARGIN, LETTER_FOOTER_HEIGHT, LETTER_MARGIN);

            var name = new MPMPortalEntities().ProjectHeaders.Where(x => x.ProjectNo == projNo).Select(x => x.ShortDesc).SingleOrDefault();

            Table htbl = CreatePagerTableHeader(name);
          
            pdf.AddEventHandler(PdfDocumentEvent.END_PAGE, new TableHeaderEventHandler(doc, htbl));
            pdf.AddEventHandler(PdfDocumentEvent.END_PAGE, new TableFooterEventHandler(false));

            using (var ent = new MPMPortalEntities())
            {
                List<PackingListHeader> packs = new List<PackingListHeader>();

                if (string.IsNullOrEmpty(oId))
                {
                    packs = (from a in ent.Packagings
                             join b in ent.Employees on a.PackagedBy equals b.Id
                             join c in ent.Employees on a.InspectedBy equals c.Id
                             where a.ProjectNo == projNo
                             select new PackingListHeader
                             {
                                 PackId = a.Id,
                                 CrateNo = a.CrateNo,
                                 PackedBy = b.FirstName + " " + b.LastName,
                                 InspectedBy = c.FirstName + " " + c.LastName,
                                 DatePacked = a.DatePacked ?? DateTime.MinValue,
                                 PackingListNo = a.ProjectNo + "-" + a.CrateNo.ToString()
                             }).OrderBy(x => x.CrateNo).ToList();
                } else
                {
                    var id = Convert.ToInt32(oId);

                    packs = (from a in ent.Packagings
                             join b in ent.Employees on a.PackagedBy equals b.Id
                             join c in ent.Employees on a.InspectedBy equals c.Id
                             where a.Id == id
                             select new PackingListHeader
                             {
                                 PackId = a.Id,
                                 CrateNo = a.CrateNo,
                                 PackedBy = b.FirstName + " " + b.LastName,
                                 InspectedBy = c.FirstName + " " + c.LastName,
                                 DatePacked = a.DatePacked ?? DateTime.MinValue,
                                 PackingListNo = a.ProjectNo + "-" + a.CrateNo.ToString()
                             }).OrderBy(x => x.CrateNo).ToList();
                }
                for(int i = 0; i < packs.Count; i++)
                {
                    var blocks = 0;
                    var units = 0;
                    var cratetbl = CreateCrateTable(packs[i]);

                    doc.Add(cratetbl);

                    int pid = packs[i].PackId;
                    var pl = ent.vwPackingLists.Where(x => x.PackId == pid).OrderBy(x => x.BlockId).ToList();

                    var bodytbl = new Table(2);
                    bodytbl.SetWidth(UnitValue.CreatePercentValue(60));
                    bodytbl.SetFontSize(10);
                    bodytbl.SetMarginTop(25);

                    string hs = "Block Id|Unit Quantity";
                    Process(bodytbl, hs, PageFontBold, true, true);

                    foreach (var v in pl)
                    {
                        ++blocks;
                        units += v.Qty ?? 0;

                        var s = v.BlockId + "|" + v.Qty.ToString();
                        Process(bodytbl, s, PageFont, false, false);
                    }
                
                    Process(bodytbl, "Total Blocks: " + blocks.ToString() + "|Total Units: " + units.ToString(), PageFontBold, true, false);

                    doc.Add(bodytbl);
                    if(i + 1 < packs.Count)
                       doc.Add(new AreaBreak(AreaBreakType.NEXT_PAGE));
                }
            }
           
            doc.Close();
        }
        private void CreatePackListByBOL(string fname)
        {
            var writer = new PdfWriter(fname);

            var pdf = new PdfDocument(writer);
            var doc = new iText.Layout.Document(pdf, PageSize.LETTER);

            doc.SetMargins(LETTER_HEADER_HEIGHT, LETTER_MARGIN, LETTER_FOOTER_HEIGHT, LETTER_MARGIN);

            var name = new MPMPortalEntities().ProjectHeaders.Where(x => x.ProjectNo == projNo).Select(x => x.ShortDesc).SingleOrDefault();

            Table htbl = CreatePagerTableHeader(name);

            pdf.AddEventHandler(PdfDocumentEvent.END_PAGE, new TableHeaderEventHandler(doc, htbl));
            pdf.AddEventHandler(PdfDocumentEvent.END_PAGE, new TableFooterEventHandler(false));

            using (var ent = new MPMPortalEntities())
            {
                //hhandler.setHeader(String.format("THE FACTORS OF %s", i));

                int id = Convert.ToInt32(oId);

                var packs = (from  a1 in ent.BOLLines
                             join  a in ent.Packagings on a1.PackId equals a.Id
                             join b in ent.Employees on a.PackagedBy equals b.Id
                             join c in ent.Employees on a.InspectedBy equals c.Id
                             where a1.BOLMId == id
                             select new PackingListHeader
                             {
                                 PackId = a.Id,
                                 CrateNo = a.CrateNo,
                                 PackedBy = b.FirstName + " " + b.LastName,
                                 InspectedBy = c.FirstName + " " + c.LastName,
                                 DatePacked = a.DatePacked ?? DateTime.MinValue,
                                 PackingListNo = a.ProjectNo + "-" + a.CrateNo.ToString()
                             }).OrderBy(x => x.CrateNo).ToList();
                
              
                for (int i = 0; i < packs.Count; i++)
                {
                    var blocks = 0;
                    var units = 0;
                    var cratetbl = CreateCrateTable(packs[i]);

                    doc.Add(cratetbl);

                    int pid = packs[i].PackId;
                    var pl = ent.vwPackingLists.Where(x => x.PackId == pid).OrderBy(x => x.BlockId).ToList();

                    var bodytbl = new Table(2);
                    bodytbl.SetWidth(UnitValue.CreatePercentValue(60));
                    bodytbl.SetFontSize(10);
                    bodytbl.SetMarginTop(25);

                    string hs = "Block Id|Unit Quantity";
                    Process(bodytbl, hs, PageFontBold, true, true);

                    foreach (var v in pl)
                    {
                        ++blocks;
                        units += v.Qty ?? 0;

                        var s = v.BlockId + "|" + v.Qty.ToString();
                        Process(bodytbl, s, PageFont, false, false);
                    }

                    Process(bodytbl, "Total Blocks: " + blocks.ToString() + "|Total Units: " + units.ToString(), PageFontBold, true, false);

                    doc.Add(bodytbl);
                    if (i + 1 < packs.Count)
                        doc.Add(new AreaBreak(AreaBreakType.NEXT_PAGE));
                }
            }

            doc.Close();
        }
        private void CreateCMBS(string fname)
        {
            int id = Convert.ToInt32(oId);
            var writer = new PdfWriter(fname);

            var pdf = new PdfDocument(writer);
            var doc = new iText.Layout.Document(pdf, PageSize.LETTER.Rotate());

            doc.SetMargins(LETTER_HEADER_HEIGHT, LETTER_MARGIN, LETTER_FOOTER_HEIGHT, LETTER_MARGIN);

            var name = new MPMPortalEntities().ProjectHeaders.Where(x => x.ProjectNo == projNo).Select(x => x.ShortDesc).SingleOrDefault();
            var priname = new MPMPortalEntities().ProjectDetails.Where(x => x.Id == id).Select(x => x.Priority).Single();

            //var ini = new MPMPortalEntities().Employees.Where(x => x.Id == BUD.UId).Select(x => x.Abbr).SingleOrDefault();

            Table htbl = CreatePagerTableHeaderCMBS(name);

            pdf.AddEventHandler(PdfDocumentEvent.END_PAGE, new TableHeaderEventHandlerCMBS(doc, htbl));
            pdf.AddEventHandler(PdfDocumentEvent.END_PAGE, new TableFooterEventHandlerCMBS(priname));

            using (var ent = new MPMPortalEntities())
            {
                var blks = ent.vwPriorityCMBS.Where(x => x.Id == id).Select(x => new CMBSListHeader {
                    Approved = x.Approved,
                    BlkTyp = x.BlkTyp,
                    BlockId = x.BlockId,
                    Comments = x.Comments,
                    Depth = x.Depth,
                    Description = x.Description,
                    DrawingNumber = x.DrawingNumber,
                    Height = x.Height,
                    Length = x.Length,
                    Priority = x.Priority,
                    Qty = x.Qty,
                    Sample = x.Sample,
                    Submitted = x.Submitted,
                    Typ = x.Typ,
                    User = x.User
                }).OrderByDescending(x => x.Typ).ThenBy(x => x.BlockId).ToList();

                var bodytbl = new Table(14);
                bodytbl.SetWidth(UnitValue.CreatePercentValue(100));
                bodytbl.SetFontSize(10);
                bodytbl.SetMarginTop(25);

                var hs = "Block ID|Blk Typ|Sample|Drawing Number|Typ|Qty|User|Submitted|Approved|Length|Height|Depth|Description|Comments";

                Process(bodytbl, hs, PageFontBold, true, true);
                
                int ttlblk = 0;
                for (int i = 0; i < blks.Count; i++)
                {
                    ttlblk += blks[i].Qty;

                    var s = blks[i].BlockId + "|" + blks[i].BlkTyp + "|" + blks[i].Sample + "|" + blks[i].DrawingNumber 
                            + "|" + blks[i].Typ + "|" + blks[i].Qty.ToString() 
                            + "|" + (blks[i].User.Length > 0 ? blks[i].User : " ") 
                            + "|" + (blks[i].Submitted.Length > 0 ? blks[i].Submitted : " ")
                            + "|" + (blks[i].Approved.Length > 0 ? blks[i].Approved : " ")
                            + "|" + (blks[i].Length.Length > 0 ? blks[i].Length : " ")
                            + "|" + blks[i].Height + "|" + blks[i].Depth
                            + "|" + (blks[i].Description.Length > 0 ? blks[i].Description : " ") + "|" + blks[i].Comments;

                    Process(bodytbl, s, PageFont, false, false);
                }
                Cell c = new Cell(1, 5).Add(new Paragraph("Total Units").SetFont(PageFontBold));
              //  c.SetBackgroundColor(ColorConstants.LIGHT_GRAY);
                c.SetTextAlignment(TextAlignment.CENTER);
                bodytbl.AddCell(c);

                c = new Cell().Add(new Paragraph(ttlblk.ToString()).SetFont(PageFontBold));
               // c.SetBackgroundColor(ColorConstants.LIGHT_GRAY);
                c.SetTextAlignment(TextAlignment.CENTER);
                bodytbl.AddCell(c);

                doc.Add(bodytbl);
            }

            doc.Close();
        }
        private void Process(Table table, String line, PdfFont font, 
            bool headerfooter, bool top = false, TextAlignment align = TextAlignment.LEFT)
        {
            var tokenizer = new StringTokenizer(line, "|");

            while (tokenizer.HasMoreTokens())
            {

                if (headerfooter)
                {
                    Cell cell = new Cell().Add(new Paragraph(tokenizer.NextToken()).SetFont(font));
                    cell.SetBackgroundColor(ColorConstants.LIGHT_GRAY);
                    cell.SetTextAlignment(align);
                    if (top)
                        table.AddHeaderCell(cell);
                    else
                        table.AddCell(cell);
                }
                else
                {
                    table.AddCell(new Cell().Add(new Paragraph(tokenizer.NextToken())
                        .SetFont(font)).SetTextAlignment(align));

                }
            }
        }
        private Table CreateCrateTable(PackingListHeader p)
        {
            var tbl = new Table(5);
            tbl.SetWidth(UnitValue.CreatePercentValue(100));
            tbl.SetFontSize(10);
            tbl.SetMarginTop(20);

            string s = "Crate #|Packed By|Inspected By|Date Packed|Packing List Number";

            Process(tbl, s, PageFontBold, true, true);

            s = p.CrateNo.ToString() + "|" + p.PackedBy + "|" + p.InspectedBy + "|" + p.DatePacked.ToString("MM/dd/yyyy") + "|" + p.PackingListNo;

            Process(tbl, s, PageFont, false, false);

            return tbl;
        }
       
        private Table CreatePagerTableHeader(string projname)
        {
            Table tbl = new Table(2);

            tbl.SetWidth(LETTER_TABLE_X);
            tbl.SetFont(iText.IO.Font.Constants.StandardFonts.HELVETICA_BOLD);
            tbl.SetFont(PdfFontFactory.CreateFont(iText.IO.Font.Constants.StandardFonts.HELVETICA_BOLD));
            tbl.SetFontSize(14);
            tbl.SetBorder(Border.NO_BORDER);
            // tbl.SetBorderBottom(new SolidBorder(1));
            tbl.SetMarginTop(10);
       
            Cell cell = new Cell(2, 1);
            cell.SetWidth(UnitValue.CreatePercentValue(60));
            cell.SetHeight(50);
            cell.SetBorder(Border.NO_BORDER);
            Image logo = new Image(ImageDataFactory.Create(BVTC_Logo));
            cell.Add(logo.SetAutoScale(true));
            tbl.AddCell(cell);

            cell = new Cell().Add(new Paragraph("Packing List"));
            cell.SetBorder(Border.NO_BORDER);
            cell.SetTextAlignment(TextAlignment.CENTER);
            tbl.AddCell(cell);

            cell = new Cell().Add(new Paragraph(projname));
            cell.SetBorder(Border.NO_BORDER);
            cell.SetTextAlignment(TextAlignment.CENTER);
            tbl.AddCell(cell);
          
            return tbl;
        }
        private Table CreatePagerTableHeaderCMBS(string projname)
        {
            Table tbl = new Table(2);

            tbl.SetWidth(LETTER_TABLE_Y);
            tbl.SetFont(iText.IO.Font.Constants.StandardFonts.HELVETICA_BOLD);
            tbl.SetFont(PdfFontFactory.CreateFont(iText.IO.Font.Constants.StandardFonts.HELVETICA_BOLD));
            tbl.SetFontSize(14);
            tbl.SetBorder(Border.NO_BORDER);
            // tbl.SetBorderBottom(new SolidBorder(1));
            tbl.SetMarginTop(10);

            Cell cell = new Cell(2, 1);
            cell.SetWidth(UnitValue.CreatePercentValue(45));
            cell.SetHeight(50);
            cell.SetBorder(Border.NO_BORDER);
            Image logo = new Image(ImageDataFactory.Create(BVTC_Logo_G));
            cell.Add(logo.SetAutoScale(true));
            tbl.AddCell(cell);

            cell = new Cell().Add(new Paragraph("Client Master Blockstyle Spreedsheet"));
            cell.SetBorder(Border.NO_BORDER);
            cell.SetTextAlignment(TextAlignment.CENTER);
            tbl.AddCell(cell);

            cell = new Cell().Add(new Paragraph(projname));
            cell.SetBorder(Border.NO_BORDER);
            cell.SetTextAlignment(TextAlignment.CENTER);
            tbl.AddCell(cell);

            return tbl;
        }
        private Image GetBOLTopImage(PdfDocument doc, Image img, vwBOLMaster bolm)
        {
            float width = img.GetImageScaledWidth();
            float height = img.GetImageScaledHeight();
            PdfFormXObject template = new PdfFormXObject(new Rectangle(width, height));
            Canvas ca = new Canvas(template, doc);
            ca.Add(img);

            ca.SetFontColor(DeviceGray.BLACK);
           
            var pdfc = ca.GetPdfCanvas();

            pdfc.Rectangle(397, 247, 68, 10);
            pdfc.Rectangle(356, 224, 149, 23);
            pdfc.ClosePathStroke();

            ca.SetFontSize(8);
            ca.ShowTextAligned("B.O.L. Number", 402, 248, TextAlignment.LEFT);

            ca.SetFontSize(10);
            ca.ShowTextAligned(bolm.Id.ToString(), 426, 230, TextAlignment.CENTER);

            if(!string.IsNullOrEmpty(bolm.MethodOfTrans))
            {
                ca.SetFont(PageFontBold);
                if(bolm.MethodOfTrans == "By Truck")
                   ca.ShowTextAligned("X", 447, 194, TextAlignment.CENTER);
                else
                   ca.ShowTextAligned("X", 508, 194, TextAlignment.CENTER);
            }

            ca.SetFont(PageFont);
            ca.SetFontSize(10);
            ca.ShowTextAligned(bolm.CurrentDate, 350, 134, TextAlignment.CENTER);
            ca.ShowTextAligned(bolm.Idx.ToString(), 458, 134, TextAlignment.CENTER);

            ca.SetFontSize(8);
            ca.ShowTextAligned(bolm.ShipToName, 105, 110, TextAlignment.CENTER);
            ca.ShowTextAligned(bolm.Addr1, 106, 100, TextAlignment.CENTER);
            var city = bolm.CityName + ", " + bolm.State + " " + bolm.Zip;
            ca.ShowTextAligned(city, 123, 90, TextAlignment.CENTER);

            ca.ShowTextAligned(bolm.PrimaryPhone, 105, 70, TextAlignment.CENTER);

            ca.SetFont(PageFontBold);
            ca.SetFontSize(10);
            ca.ShowTextAligned(bolm.Carrier, 390, 91, TextAlignment.CENTER);
            var proj = bolm.ProjectNo + "   " + bolm.ShortDesc;
            ca.ShowTextAligned(proj, 96, 25, TextAlignment.CENTER);

            ca.ShowTextAligned(bolm.BOLDate, 332, 25, TextAlignment.CENTER);

            ca.SetFont(PageFont);
            ca.SetFontSize(8);
            var temp = bolm.Instructions.Trim();
            ca.ShowTextAligned(temp, 375, 35, TextAlignment.LEFT);

            ca.Close();

            return new Image(template);
        }
        private Image GetBOLBottomImage(PdfDocument pdf, Image img, vwBOLMaster bolm)
        {
            float width = img.GetImageScaledWidth();
            float height = img.GetImageScaledHeight();
            PdfFormXObject template = new PdfFormXObject(new Rectangle(width, height));
            Canvas ca = new Canvas(template, pdf);
            ca.Add(img);

            ca.SetBold();
            ca.SetFontSize(10);
            ca.ShowTextAligned(bolm.Weight.ToString(), 94, 56, TextAlignment.CENTER);
            ca.ShowTextAligned(bolm.ShortDesc, 310, 36, TextAlignment.CENTER);

            ca.Close();

            return new Image(template);
        }
      
        private Table GetPDLDrawingTable(float width, float height, List<vwPartDrawingListDetail> dls, PdfDocument pdf)
        {
            float cellw = width / 6 - 1;
            float cellh = height / 5 - 1;
            float innerh1 = cellh * 0.7F;
            float innerh2 = cellh - innerh1;

            Table tbl = new Table(new float[] {1,1,1,1,1,1});
            tbl.SetPadding(0);
            tbl.SetWidth(width).SetHeight(height);
           // tbl.SetBorder(Border.NO_BORDER);

            int ttlcell = 0;
            int curr = 0;
            string profilecode = "1";
            int remain = 0;

            foreach (var v in dls)
            {
                Cell cell = new Cell();
                //cell.SetHeight(cellh).SetPadding(0);

                ++ttlcell;

                if (++curr == 7) curr = 1;
                if (profilecode != v.ProfileCode)
                {
                    if (profilecode == "1")
                        profilecode = v.ProfileCode;
                    else
                    {
                        profilecode = v.ProfileCode;
                        remain = dls.Where(x => x.ProfileCode == v.ProfileCode).Count();

                        int cellleft = 6 - curr;

                        if (cellleft >= remain)
                        {
                            cell = GetBlankPDLCell(cellw, innerh1);
                            tbl.AddCell(cell);

                            cell = new Cell();

                            ++ttlcell;
                            ++curr;
                        }
                        else
                        {
                            for (int i = 0; i <= cellleft; i++)
                            {

                                cell = GetBlankPDLCell(cellw, innerh1);
                                tbl.AddCell(cell);
                                ++ttlcell;
                            }
                            curr = 1;

                            cell = new Cell();
                        }
                    }
                }
              
                Div div = new Div();
                div.SetHeight(innerh1);
                Image img;

                if (!string.IsNullOrEmpty(v.DocPath))
                {
                    string ext = v.DocPath.Substring(v.DocPath.LastIndexOf('.') + 1).ToUpper();
                    if (ext == "PDF")
                    {
                        PdfDocument origpdf = new PdfDocument(new PdfReader(v.DocPath));
                        PdfPage origpage = origpdf.GetPage(1);

                        PdfFormXObject pagecopy = origpage.CopyAsFormXObject(pdf);
                        
                        img = new Image(pagecopy);
                    }
                    else
                        img = new Image(ImageDataFactory.Create(v.DocPath));
                             
                    img.ScaleToFit(cellw - 4, innerh1 - 1);
                }
                else
                    img = new Image(ImageDataFactory.Create(PDLEMPTYTHUMB))
                            .ScaleToFit(cellw - 4, innerh1 - 1);
                div.Add(img);
                
                cell.Add(div);
                div = new Div();
                div.SetTextAlignment(TextAlignment.CENTER);
                div.SetVerticalAlignment(VerticalAlignment.BOTTOM);
                div.SetFontSize(6);
                Paragraph p = new Paragraph();
                p.SetPadding(0).SetMultipliedLeading(1.1F);
                p.Add("QTY: " + v.Qty);
                p.Add("\n(INCLUDES " + v.Extra + " EXTRA)");
                div.Add(p);
           
                cell.Add(div);

                tbl.AddCell(cell);
            }
            remain = 0;
            if (ttlcell > 30)
                remain = 30 - (ttlcell % 30);
            else
                remain = 30 - ttlcell;

            for(int i = 0; i < remain; i++)
            {
                Cell cell = GetBlankPDLCell(cellw, innerh1);
              
                tbl.AddCell(cell);
            }
            return tbl;
        }
        private Cell GetBlankPDLCell(float w, float h)
        {
            Cell cell = new Cell();
           
            Div div = new Div();
            div.SetHeight(h);
            Image img = new Image(ImageDataFactory.Create(PDLEMPTYTHUMB))
                        .ScaleToFit(w - 4, h - 1);
            div.Add(img);

            cell.Add(div);
            div = new Div();
           
            div.SetFontSize(8);
            div.Add(new Paragraph("\u00a0"));
            cell.Add(div);
                       
            return cell;
        }
        private Table GetCrateBlock(int height)
        {
            int bolmid = Convert.ToInt32(oId);
            int units = 0;
            int crates = 0;
            int cellheight = 16;

            Table tbl = new Table(2);
          
            tbl.SetWidth(UnitValue.CreatePercentValue(40));
            tbl.SetFontSize(8);
            tbl.SetBorder(Border.NO_BORDER);
            tbl.SetPadding(0);
            tbl.SetMarginLeft(20);
            tbl.SetHeight(height);
           
            using (var ent = new MPMPortalEntities())
            {
                foreach(var o in ent.vwBOLBlocks.Where(x => x.BOLMId == bolmid).OrderBy(x => x.CrateNo).ToList())
                {
                    ++crates;
                    units += o.BlockTtl;

                    Cell cell = new Cell().Add(new Paragraph(o.BlockTtl.ToString()));
                    cell.SetWidth(UnitValue.CreatePercentValue(50));
                    cell.SetPadding(0);
                   // cell.SetHeight(cellheight);

                    cell.SetTextAlignment(TextAlignment.LEFT);
                    cell.SetBorder(Border.NO_BORDER);
                    tbl.AddCell(cell);
                    cell = new Cell().Add(new Paragraph("Crate # " + o.CrateNo.ToString()));
                    cell.SetPadding(0);
                    cell.SetBorder(Border.NO_BORDER);
                    tbl.AddCell(cell);
                }
            }

            Cell c = new Cell().Add(new Paragraph("Total Blocks: " + units.ToString()));
            c.SetBorder(Border.NO_BORDER);
            c.SetHeight(cellheight);
            c.SetTextAlignment(TextAlignment.LEFT);
            tbl.AddCell(c);
            c = new Cell().Add(new Paragraph("Total Crates: " + crates.ToString()));
            c.SetBorder(Border.NO_BORDER);
            tbl.AddCell(c);

            for (int i = 0; i < 150; i++)
            {
                c = new Cell(1, 2).Add(new Paragraph(" "));
                c.SetBorder(Border.NO_BORDER);
                // c.SetHeight(height - (crates + 1) * cellheight); //
                tbl.AddCell(c);
            }

            return tbl;
        }
        private Image GetPOTopImage(PdfDocument doc, Image img, vwPOHeader pom)
        {
            float width = img.GetImageScaledWidth();
            float height = img.GetImageScaledHeight();
            PdfFormXObject template = new PdfFormXObject(new Rectangle(width, height));
            Canvas ca = new Canvas(template, doc);
            ca.Add(img);

            ca.SetFontSize(10);
            ca.SetFontColor(DeviceGray.BLACK);
            ca.ShowTextAligned(pom.PONumber, 311, 116, TextAlignment.CENTER);
         
            ca.ShowTextAligned(pom.DateSubmitted ?? DateTime.MaxValue.ToString("MM/dd/yyyy"), 310, 101, TextAlignment.CENTER);
                       
            ca.ShowTextAligned(pom.VendorName, 84, 63, TextAlignment.CENTER);
            ca.ShowTextAligned(pom.Address1 ?? "", 81, 51, TextAlignment.CENTER);
            ca.ShowTextAligned((pom.City ?? "") + ", " + (pom.State ?? "") + " " + (pom.Zip ?? ""), 93, 40, TextAlignment.CENTER);

            ca.ShowTextAligned(pom.AttnName ?? "" + " " + pom.AttnPhone ?? "", 92, 2, TextAlignment.CENTER);
            ca.ShowTextAligned(pom.ShortDesc, 366, 2, TextAlignment.CENTER);

            ca.Close();

            return new Image(template);
        }
        private void AddPONotes(PdfDocument pdf, string notes)
        {
            PdfFormXObject template = new PdfFormXObject(new Rectangle(87, 130, 198, 40));
            PdfCanvas pdfca = new PdfCanvas(template, pdf);
           
            pdfca.BeginText().SetFontAndSize(PageFont, 8)
                .ShowText(notes).EndText().Stroke();
                        
        }
        private Image GetPOBottomImage(PdfDocument pdf, Image img, vwPOHeader pom, float ttl)
        {
            float width = img.GetImageScaledWidth();
            float height = img.GetImageScaledHeight();
            PdfFormXObject template = new PdfFormXObject(new Rectangle(width, height));
            Canvas ca = new Canvas(template, pdf);
            ca.Add(img);
            ca.SetFontSize(10);
            
           // ca.ShowTextAligned(pom.Notes, 84, 70, TextAlignment.CENTER);
            if(pom.Taxable)
            ca.ShowTextAligned("X", 306, 95, TextAlignment.CENTER);
            else
            ca.ShowTextAligned("X", 306, 68, TextAlignment.CENTER);

            ca.SetBold();
            ca.ShowTextAligned(ttl.ToString("C2"), 414, 108, TextAlignment.CENTER);
            
            ca.Close();

            return new Image(template);
        }
        private Table GetPODetail(int height, out float ttl)
        {
            int pohid = Convert.ToInt32(oId);
            ttl = 0F;

            var count = 0;

            Table tbl = new Table(new float[]{3, 1, 4, 2, 1, 1});

            tbl.SetWidth(UnitValue.CreatePercentValue(100));
            tbl.SetFontSize(8);
            tbl.SetBorder(new SolidBorder(1));
            tbl.SetPadding(0);
            tbl.SetMinHeight(height);

            string s = "Item|Quantity|Description|Date Required|Price|Total";
            Process(tbl, s, PageFontBold, true, true, TextAlignment.CENTER);

            using (var ent = new MPMPortalEntities())
            {
                foreach (var o in ent.vwPODetails.Where(x => x.POHId == pohid).OrderBy(x => x.ItemName).ToList())
                {
                    ++count;

                    s = o.ItemName + "|" + o.Quantity.ToString() + "|" + o.Description + "|"
                        + o.DateExpected + "|" + o.UnitPrice.ToString() + "|" + o.Cost.ToString();

                    Process(tbl, s, PageFont, false, false, TextAlignment.CENTER);
                    ttl = ttl + (float)o.Cost;
                }
            }
            //both 18, header 27, footer 33, 42 
            int erows = 0;

            if (count <= 18)
                erows = 18 - count;
            if (count > 18 && count <= 27)
                erows = 27 - count + 33;
            if(count > 27)
            {
                int remain = (count - 27);
                if (remain <= 33)
                    erows = 33 - remain;
                else
                {
                    remain = remain % 42;
                    erows = remain <= 33 ? 33 - remain : 42 - remain + 33;
                }
            }
            
            for(int i = 0; i < erows; i++)
            {
                s = "\u00a0| | | | | ";
                Process(tbl, s, PageFont, false, false, TextAlignment.CENTER);
            }
            return tbl;
        }
     
    }
    public class TableHeaderEventHandler : IEventHandler
    {
        protected Table table;
        protected float tableHeight;
        protected iText.Layout.Document doc;

        public TableHeaderEventHandler(iText.Layout.Document doc, Table tbl)
        {
            this.doc = doc;
            table = tbl;
                   
            TableRenderer renderer = (TableRenderer)table.CreateRendererSubTree();
            renderer.SetParent(new iText.Layout.Document(new PdfDocument(new PdfWriter(new ByteArrayOutputStream()))).GetRenderer());
            tableHeight = renderer.Layout(new LayoutContext(new LayoutArea(0, PageSize.LETTER))).GetOccupiedArea().GetBBox().GetHeight();
        }

        public void HandleEvent(Event e)
        {
            PdfDocumentEvent docEvent = (PdfDocumentEvent)e;
            PdfDocument pdfDoc = docEvent.GetDocument();
            PdfPage page = docEvent.GetPage();
            PdfCanvas canvas = new PdfCanvas(page.NewContentStreamBefore(), page.GetResources(), pdfDoc);
            Rectangle rect = new Rectangle(pdfDoc.GetDefaultPageSize().GetX() + doc.GetLeftMargin(),
                pdfDoc.GetDefaultPageSize().GetTop() - doc.GetTopMargin(), 100, GetTableHeight());
        
            new Canvas(canvas, pdfDoc, rect).Add(table);//.Add(new LineSeparator(new SolidLine(1)));
        }

        public float GetTableHeight()
        {
            return tableHeight;
        }
    }

    public class TableFooterEventHandler : IEventHandler
    {
        public bool Simple { get; set; }
        public TableFooterEventHandler(bool simple)
        {
            Simple = simple;
        }
        private Table CreatePagerTableFooter(int pageno)
        {
            Table tbl = new Table(2);

            tbl.SetWidth(UnitValue.CreatePercentValue(100));
            tbl.SetFontSize(8);
            tbl.SetBorder(Border.NO_BORDER);
            tbl.SetMarginLeft(25);

            Cell cell = new Cell().Add(new Paragraph("Page " + pageno));
            cell.SetWidth(UnitValue.CreatePercentValue(80));
            cell.SetBorder(Border.NO_BORDER);
            tbl.AddCell(cell);
            cell = new Cell().Add(new Paragraph("Date: " + DateTime.Now.ToString("MM/dd/yyyy")));
            cell.SetBorder(Border.NO_BORDER);
            tbl.AddCell(cell);
            cell = new Cell().Add(new Paragraph(" "));
            cell.SetBorder(Border.NO_BORDER);
            tbl.AddCell(cell);
            cell = new Cell().Add(new Paragraph("Time: " + DateTime.Now.ToString("hh:mm")));
            cell.SetBorder(Border.NO_BORDER);
            tbl.AddCell(cell);

            return tbl;
        }
        private Table CreatePagerTableFooterSimple(int pageno, int pagettl)
        {
            Table tbl = new Table(1);

            tbl.SetWidth(UnitValue.CreatePercentValue(100));
            tbl.SetFontSize(8);
            tbl.SetBorder(Border.NO_BORDER);

            Cell cell = new Cell().Add(new Paragraph("Page " + pageno + " of " + pagettl).SetTextAlignment(TextAlignment.RIGHT));
            cell.SetWidth(UnitValue.CreatePercentValue(80));
            cell.SetBorder(Border.NO_BORDER);
            tbl.AddCell(cell);
          
            return tbl;
        }
        public void HandleEvent(Event e)
        {
            PdfDocumentEvent docEvent = (PdfDocumentEvent)e;
            PdfDocument pdfDoc = docEvent.GetDocument();
            PdfPage page = docEvent.GetPage();
            int pno = pdfDoc.GetPageNumber(page);
            int pttl = pdfDoc.GetNumberOfPages();

            PdfCanvas canvas = new PdfCanvas(page.NewContentStreamBefore(), page.GetResources(), pdfDoc);

            Table tbl;
            Canvas fc;
            if (!Simple)
            {
                tbl = CreatePagerTableFooter(pno);
                fc = new Canvas(canvas, pdfDoc, new Rectangle(36, 15, page.GetPageSize().GetWidth() - 72, 50));
            }
            else
            {
                tbl = CreatePagerTableFooterSimple(pno, pttl);
                fc = new Canvas(canvas, pdfDoc, new Rectangle(36, 10, page.GetPageSize().GetWidth() - 72, 26));
            }
           
            fc.Add(new LineSeparator(new SolidLine(1))).Add(tbl);
        }
    }
    public class MixPageEventHandler : IEventHandler
    {
        private vwPartDrawingListHeader header;
        private Image img;
        private iText.Layout.Document doc;

        public MixPageEventHandler(vwPartDrawingListHeader h, Image i, iText.Layout.Document d)
        {
            header = h;
            img = i;
            doc = d;
        }
        public void HandleEvent(Event e)
        {
            PdfDocumentEvent docEvent = (PdfDocumentEvent)e;
            PdfDocument pdfDoc = docEvent.GetDocument();
            PdfPage page = docEvent.GetPage();
            int pno = pdfDoc.GetPageNumber(page);

            float left = pdfDoc.GetDefaultPageSize().GetRight() - doc.GetLeftMargin() - 145;
            float top = pdfDoc.GetDefaultPageSize().GetTop() - doc.GetTopMargin();
            //float bottom = pdfDoc.GetDefaultPageSize().GetBottom() - doc.GetBottomMargin();

            PdfCanvas canvas = new PdfCanvas(page.NewContentStreamBefore(), page.GetResources(), pdfDoc);
            Rectangle rect = new Rectangle(left, top, 145, pdfDoc.GetDefaultPageSize().GetY());
            Rectangle rectproj = new Rectangle(left + 8, 135, 130, 25);
            Canvas ca = new Canvas(canvas, pdfDoc, rect);
            Canvas caproj = new Canvas(canvas, pdfDoc, rectproj);

            Paragraph p = new Paragraph(header.ShortDesc);
                        
            ca.Add(img);
            ca.SetFontSize(4);
            ca.ShowTextAligned(new Paragraph(DateTime.Now.ToString("MM/dd/yy")), left + 22, 217, TextAlignment.CENTER);
            ca.SetFontSize(8);
            ca.ShowTextAligned(new Paragraph(header.City + ", " + header.StateCode), left + 29, 120, TextAlignment.CENTER);
            ca.SetFontSize(10);
            ca.ShowTextAligned(new Paragraph("PARTS LIST"), left + 75, 85, TextAlignment.CENTER);
            ca.ShowTextAligned(new Paragraph(header.ProjectNo.Substring(1) + "-" + header.Idx.ToString()), left + 85, 62, TextAlignment.CENTER);
          //  ca.ShowTextAligned(new Paragraph("NTS"), left + 55, 45, TextAlignment.CENTER);
            ca.ShowTextAligned(new Paragraph(header.PCode), left + 16, 20, TextAlignment.CENTER);
            ca.ShowTextAligned(new Paragraph(pno.ToString()), left + 80, 20, TextAlignment.CENTER);

            caproj.SetFontSize(10);
            caproj.Add(p);      
            
            //ca.ShowTextAligned(p, left, 80, TextAlignment.CENTER);
            canvas.Stroke();
           
        }
    }
    public class VariableHeaderEventHandler : IEventHandler
    {
        protected String header;

        public void SetHeader(String header)
        {
            this.header = header;
        }
          
        public void HandleEvent(Event e)
        {
            PdfDocumentEvent docevent = (PdfDocumentEvent)e;
            try
            {
                new PdfCanvas(docevent.GetPage())
                        .BeginText()
                        .SetFontAndSize(PdfFontFactory.CreateFont(iText.IO.Font.Constants.StandardFonts.HELVETICA), 12)
                        .MoveText(450, 806)
                        .ShowText(header)
                        .EndText()
                        .Stroke();
            }
            catch (iText.IO.IOException ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
    public class TableHeaderEventHandlerCMBS : IEventHandler
    {
        protected Table table;
        protected float tableHeight;
        protected iText.Layout.Document doc;

        public TableHeaderEventHandlerCMBS(iText.Layout.Document doc, Table tbl)
        {
            this.doc = doc;
            table = tbl;

            TableRenderer renderer = (TableRenderer)table.CreateRendererSubTree();
            renderer.SetParent(new iText.Layout.Document(new PdfDocument(new PdfWriter(new ByteArrayOutputStream()))).GetRenderer());
            tableHeight = renderer.Layout(new LayoutContext(new LayoutArea(0, PageSize.LETTER.Rotate()))).GetOccupiedArea().GetBBox().GetHeight();
        }

        public void HandleEvent(Event e)
        {
            PdfDocumentEvent docEvent = (PdfDocumentEvent)e;
            PdfDocument pdfDoc = docEvent.GetDocument();
            PdfPage page = docEvent.GetPage();
            PdfCanvas canvas = new PdfCanvas(page.NewContentStreamBefore(), page.GetResources(), pdfDoc);
            Rectangle rect = new Rectangle(pdfDoc.GetDefaultPageSize().GetX() + doc.GetLeftMargin(),
                pdfDoc.GetDefaultPageSize().GetTop() - doc.GetTopMargin(), 100, GetTableHeight());

            new Canvas(canvas, pdfDoc, rect).Add(table);
        }

        public float GetTableHeight()
        {
            return tableHeight;
        }
    }

    public class TableFooterEventHandlerCMBS : IEventHandler
    {
        public string Priname { get; set; }
        public TableFooterEventHandlerCMBS(string priname)
        {
            Priname = priname;
        }
        private Table CreatePagerTableFooter(int pageno)
        {
            Table tbl = new Table(3);

            tbl.SetWidth(UnitValue.CreatePercentValue(100));
            tbl.SetFontSize(8);
            tbl.SetBorder(Border.NO_BORDER);
            tbl.SetMarginLeft(25);

            Cell cell = new Cell().Add(new Paragraph("Page " + pageno));
            cell.SetWidth(UnitValue.CreatePercentValue(20));
            cell.SetBorder(Border.NO_BORDER);
            tbl.AddCell(cell);

            cell = new Cell(2, 1).Add(new Paragraph(Priname).SetFont(PdfFontFactory.CreateFont(iText.IO.Font.Constants.StandardFonts.HELVETICA_BOLD)));
            cell.SetWidth(UnitValue.CreatePercentValue(60));
            cell.SetBorder(Border.NO_BORDER);
            cell.SetTextAlignment(TextAlignment.CENTER);
            cell.SetVerticalAlignment(VerticalAlignment.MIDDLE);
            cell.SetFontSize(12);
            tbl.AddCell(cell);

            cell = new Cell().Add(new Paragraph("Date: " + DateTime.Now.ToString("MM/dd/yyyy")));
            cell.SetBorder(Border.NO_BORDER);
            tbl.AddCell(cell);
            cell = new Cell().Add(new Paragraph(" "));
            cell.SetBorder(Border.NO_BORDER);
            tbl.AddCell(cell);
            cell = new Cell().Add(new Paragraph("Time: " + DateTime.Now.ToString("hh:mm")));
            cell.SetBorder(Border.NO_BORDER);
            tbl.AddCell(cell);

            return tbl;
        }
        public void HandleEvent(Event e)
        {
            PdfDocumentEvent docEvent = (PdfDocumentEvent)e;
            PdfDocument pdfDoc = docEvent.GetDocument();
            PdfPage page = docEvent.GetPage();
            int pno = pdfDoc.GetPageNumber(page);
            int pttl = pdfDoc.GetNumberOfPages();

            PdfCanvas canvas = new PdfCanvas(page.NewContentStreamBefore(), page.GetResources(), pdfDoc);

            Table tbl;
            Canvas fc;
           
            tbl = CreatePagerTableFooter(pno);
            fc = new Canvas(canvas, pdfDoc, new Rectangle(36, 15, page.GetPageSize().GetWidth() - 72, 50));
        
            fc.Add(new LineSeparator(new SolidLine(1))).Add(tbl);
        }

       
    }
}
