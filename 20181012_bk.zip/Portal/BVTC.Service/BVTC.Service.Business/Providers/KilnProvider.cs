﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;

using BVTC.Service.Data.Models.Simulator;
using BVTC.Service.Business.TransferObjects;
using BVTC.Service.Common;
using BVTC.Service.Common.Utilities;

namespace BVTC.Service.Business
{
    public class KilnProvider
    {
        private const bool StrictMode = false;
        private const bool LoadFirst = true; // plan first or load rate first

        private const int MAX_LOADIDX = 9999999;

        private SimulatorTracing _st;
        
        public static int Idx;

        public EstimateProvider EstPro { get; set; }
        public SimulatorEntities Ent { get; set; }

        public static object Locker;

        public string TeamNm { get; set; }
        public int CurrHour { get; set; }
        
        public KilnProvider(EstimateProvider estpro)
        {
            _st = new SimulatorTracing();

            EstPro = estpro;
            Ent = new SimulatorEntities();
            TeamNm = "";
        }
        public void SetTeam(string team, int hour)
        {
            TeamNm = team;
            CurrHour = hour;
        }
        public static void InitKiln()
        {
            KilnProvider.Idx = 0;
            Locker = new object();
        }
        public static void IncreaseIdx()
        {
            lock (Locker)
            {
                //only one instruction, not needed
                ++Idx;
            }
        }
        public bool UnloadKiln()
        {
            bool ret = true;
            var kilnno = GetKilnToUnload();

            if (kilnno > 0)
            {
                var kn = Ent.Kilns.Where(x => x.KilnNumber == kilnno).Single();

                var totalcarts = new SimulatorEntities().Temp_KilnPlan.Where(x => x.KilnNumber == kilnno).Sum(x => x.Carts);

                _st.Tracing("At " + CurrHour + ": Unloading kiln#" + kilnno.ToString() + " by " + TeamNm, EstPro.SessionId.ToString());

                EstPro.AddNote("Unloading kiln#" + kilnno.ToString());
                EstPro.AddAction("Unload Kiln");
                EstPro.SaveActivity(new TeamActivity
                {
                    TeamName = TeamNm,
                    Act = "Unloading Kiln",
                    KilnNo = kilnno,
                    PId = 0,
                    SessionId = EstPro.SessionId.ToString()
                });

                using (var ent = new SimulatorEntities())
                {
                    var tempdps = ent.Temp_KilnPlan.Where(x => x.KilnNumber == kilnno).ToList();
                   
                    if (totalcarts - kn.UnloadRate <= 0) //
                    {
                        SaveActivity(new KilnActivity {
                            KilnNumber = kilnno,
                            PId = 0,
                            Carts = tempdps.Sum(x => x.Carts),
                            Operation = "Unloading",
                            SessionId = EstPro.SessionId.ToString()
                        });
                        ent.Temp_KilnPlan.RemoveRange(tempdps);
                    }
                    else
                    {
                        int remine = kn.UnloadRate ?? 0;

                        foreach (var tempdp in tempdps)
                        {
                            var tempsum = new SimulatorEntities().EstimateSummaries.Where(x => x.RunNum == EstPro.RunNo && x.PPId == tempdp.PId && x.SessionId == EstPro.SessionId.ToString()).Single();

                            int unloaded = tempdp.Carts >= remine ? remine : tempdp.Carts ?? 0;
                            tempdp.Carts = tempdp.Carts >= remine ? tempdp.Carts - remine : 0;
                            tempdp.Panels = tempdp.Carts * tempsum.KilnShelvesPerCart * tempsum.KilnPanelsPerShelf;
                            tempdp.UpdateDate = DateTime.Now;

                            SaveActivity(new KilnActivity
                            {
                                KilnNumber = kilnno,
                                PId = tempdp.PId,
                                Carts = tempdp.Carts,
                                Operation = "Unloading",
                                SessionId = EstPro.SessionId.ToString()
                            });

                            remine = remine - unloaded;
                            if (remine <= 0) break;
                        }
                    }
                    ent.SaveChanges();
                }
            }
            else
            {
                ret = false;
                EstPro.AddNote("No kiln to unload");
            }

            return ret;
        }
        public bool LoadKiln()
        {
            bool ret = true;
            var kilnnos = GetKilnsToLoad();

            if (kilnnos.Count == 0)
            {
                EstPro.AddNote("No kiln to load");
                return false;
            }

            var cppro = new CartPoolProvider(EstPro);
            var kts = GetTotalInKiln(kilnnos);
            var cpfl = cppro.GetTotalInPoolsToLoad(kts, this);

            var tempkps = GetKilnToLoad(kts, cpfl);

            if (kilnnos.Count > 0 && (cpfl.Count == 0 || tempkps.Count == 0))
            {
                EstPro.AddNote("No enough carts in Pool for kiln");
                return false;
            }

            int tt = tempkps[0].KilnNo;
            var kn = Ent.Kilns.Where(x => x.KilnNumber == tt).Single();

            StatusManager.SetStatus<Kiln>(kn.KilnNumber, TeamNm);

            _st.Tracing("At " + CurrHour + ": Loading kiln#" + kn.KilnNumber.ToString() + " by " + TeamNm, EstPro.SessionId.ToString());
            EstPro.AddNote("Loading kiln#" + kn.KilnNumber.ToString());
            EstPro.AddAction("Load Kiln");
            EstPro.SaveActivity(new TeamActivity
            {
                TeamName = TeamNm,
                Act = "Loading Kiln",
                KilnNo = kn.KilnNumber,
                PId = 0,
                SessionId = EstPro.SessionId.ToString()
            });

            int remine = kn.LoadRate * Ent.Carts.Where(x => x.CartType == "KC").Select(x => x.ShelfCount).Single() ?? 0;

            using (var ent = new SimulatorEntities())
            {
                var tempkilns = ent.Temp_KilnPlan.Where(x => x.KilnNumber == kn.KilnNumber && x.SessionId == EstPro.SessionId.ToString()).ToList();
              
                foreach (var tkp in tempkps)
                {
                    
                    if (remine <= 0)
                        break;
                    if (remine < tkp.Height)
                        continue;

                    int freeracks = GetFreeRacks(tempkps); //incorrect. use new temp_kilnplan generated

                    var tempsum = ent.EstimateSummaries.Where(x => x.RunNum == EstPro.RunNo && x.PPId == tkp.PId).Single();
                    //TODO: panel/shelf mismath, significant?? -- do a post merge under Strict Mode
                    //per cart based caculation
                    int remined = GetRemine(remine, tkp, tempsum);
                    int panelloaded = Math.Min(tkp.Panels, remined * tempsum.KilnPanelsPerShelf ?? 0);
                    // loaded pieces must be times of ext PanelsPerShelf 
                    // the best place to apply or still use shelves?
                    if (panelloaded > 0 && panelloaded % tempsum.PanelsPerShelf != 0 && !IsLastLoad(panelloaded, tkp.PId))
                    {
                        panelloaded = panelloaded - panelloaded % tempsum.PanelsPerShelf ?? 0;
                    }
                                                       
                    if (panelloaded > 0) {
                        FreeShelves(panelloaded, tkp.PId);
                        EstPro.AddNote("Freed Shelves");

                        cppro.Remove(new KilnTotalDTO{
                            PId = tkp.PId,
                            KilnNo = 0,
                            Shelevs = 0, 
                            Panels = panelloaded,
                            Carts = 0 
                        });

                        if (tempkilns.Any(x => x.PId == tkp.PId && x.Panels > 0))
                        {
                            var tempk = tempkilns.Where(x => x.PId == tkp.PId).Single();
                            tempk.Panels = tempk.Panels + panelloaded;
                            tempk.Carts = tempk.Carts + GetCarts(panelloaded, tkp.PId, kn.KilnNumber); 
                            tempk.UpdateDate = DateTime.Now;
                        }
                        else
                        {
                            KilnProvider.IncreaseIdx();

                            ent.Temp_KilnPlan.Add(new Temp_KilnPlan
                            {
                                KilnNumber = kn.KilnNumber,
                                PId = tkp.PId,
                                Panels = panelloaded,
                                LoadIdx = CurrHour + KilnProvider.Idx,
                                //TODO: a dedicated function for calculate carts and using free space
                                Carts = GetCarts(panelloaded, tkp.PId, kn.KilnNumber),  
                                FiringAt = -1,
                                UpdateDate = DateTime.Now,
                                SessionId = EstPro.SessionId.ToString()
                            });
                        }
                        ent.SaveChanges();

                        remine = remine - (int)Math.Ceiling((double)panelloaded /(double)tempsum.KilnPanelsPerShelf) * tkp.Height;

                        _st.Tracing("Debug: P#" + tkp.PId + ", K#" + kn.KilnNumber + " added " + panelloaded + " panels by T#" + TeamNm, TraceLevel.Verbose, EstPro.SessionId.ToString());

                        SaveActivity(new KilnActivity
                        {
                            KilnNumber = kn.KilnNumber,
                            PId = tkp.PId,
                            Carts = 0,
                            Panels = panelloaded,
                            Operation = "Loading",
                            SessionId = EstPro.SessionId.ToString()

                        });

                        if (EstPro.CurrPlans.Any(x => x.Plan.Id == tkp.PId && x.Status == Constants.Processing))
                        {
                            var lsum = EstPro.GetSummary(tkp.PId);
                            var ld = EstPro.GetDetail(tkp.PId);

                            ld.PanelFired = (ld.PanelFired ?? 0) + panelloaded;
                            ld.RackFired = (int)Math.Ceiling((double)ld.PanelFired / (double)tempsum.KilnPanelsPerShelf);
                            ld.CartFired = (int)Math.Ceiling((double)ld.RackFired / (double)tempsum.KilnShelvesPerCart);
                            lsum.KilnRacks = (lsum.KilnRacks ?? 0) + (int)Math.Ceiling((double)panelloaded / (double)tempsum.KilnPanelsPerShelf);
                            lsum.KilnCarts = (int)Math.Ceiling((double)lsum.KilnRacks / (double)tempsum.KilnShelvesPerCart);
                            _st.Tracing("Debug: P#" + tkp.PId + " added " + ld + " racks by T#" + TeamNm, TraceLevel.Verbose, EstPro.SessionId.ToString());
                        } else
                        {
                            tempsum.KilnRacks = (tempsum.KilnRacks ?? 0) + (int)Math.Ceiling((double)panelloaded / (double)tempsum.KilnPanelsPerShelf);
                            tempsum.KilnCarts = (int)Math.Ceiling((double)tempsum.KilnRacks / (double)tempsum.KilnShelvesPerCart);
                            _st.Tracing("Debug: P#" + tkp.PId + " added " + (int)Math.Ceiling((double)panelloaded / (double)tempsum.KilnPanelsPerShelf) + " racks by T#" + TeamNm, 
                                TraceLevel.Verbose, EstPro.SessionId.ToString());
                        }

                        string strku = "," + (string.IsNullOrEmpty(tempsum.KilnUsed) ? "" : tempsum.KilnUsed) + ",";

                        if(strku.IndexOf("," + kn.KilnNumber.ToString() + ",") < 0)
                            tempsum.KilnUsed = string.IsNullOrEmpty(tempsum.KilnUsed)
                                                          ? kn.KilnNumber.ToString()
                                                          : tempsum.KilnUsed + "," + kn.KilnNumber.ToString();

                        ent.SaveChanges();
                    }
                }
            }
        
            return ret;
        }
        private void FreeShelves(int panels, int pid)
        {
            //moved from dryerpro
            ShelfProvider spro = new ShelfProvider(EstPro);
            
            int ret = spro.Free(panels, pid);

            if (ret > 0)
                ;// throw new Exception("Shelves of a plan should match");
        }
        //shelves of the plan
        private int GetRemine(int shelves, KilnTotalDTO ktd, EstimateSummary tempsum)
        {
            //
            int rpc = Ent.Carts.Where(x => x.CartType == "KC").Select(x => x.ShelfCount).Single();
            int carts = (int)Math.Floor((double)shelves / rpc); 
            return carts * (int)tempsum.KilnShelvesPerCart + ((shelves - carts * rpc) / ktd.Height);
        }
        //get number of carts to be used by utilizing free sapces. auto merge - what will happen in the field
        private int GetCarts(int panels, int pid, int kno)
        {
            //assumption: processed by extrution order -- either by plan order or target date
            var kns = new SimulatorEntities().Temp_KilnPlan.Where(x => x.KilnNumber == kno && x.SessionId == EstPro.SessionId.ToString()).OrderBy(x => x.LoadIdx).ToList();
            var cart = Ent.Carts.Where(x => x.CartType == "KC").Single();
            int freesp = 0;
            
            foreach (var kn in kns)
            {
                var tempsum = new SimulatorEntities().EstimateSummaries.Where(x => x.PPId == kn.PId && x.RunNum == EstPro.RunNo && x.SessionId == EstPro.SessionId.ToString()).Single();
                int height = (int)Math.Ceiling((double)cart.ShelfCount / (double)(1 + tempsum.KilnShelvesPerCart));

                int shelves = (int)Math.Ceiling((double)kn.Panels / (double)tempsum.KilnPanelsPerShelf);
                shelves = shelves - (int)Math.Floor((double)freesp / height); //shelves of new carts
                int tempfree = shelves % tempsum.KilnShelvesPerCart ?? 0; // plan shelves outside a cart 

                freesp = tempfree > 0 ? cart.ShelfCount - tempfree * height : 0; // remining cart space
            }
            var ssum = new SimulatorEntities().EstimateSummaries.Where(x => x.RunNum == EstPro.RunNo && x.PPId == pid && x.SessionId == EstPro.SessionId.ToString()).Single();

            int rs = (int)Math.Ceiling((double)panels / (double)ssum.KilnPanelsPerShelf) 
                - (int)Math.Floor((double)freesp / (double)(int)Math.Ceiling((double)cart.ShelfCount / (double)(1 + ssum.KilnShelvesPerCart)));
              
            return (int)Math.Ceiling((double)rs/(double)ssum.KilnShelvesPerCart);
        }
        private List<KilnTotalDTO> GetKilnToLoad(List<KilnTotalDTO> ks, List<KilnTotalDTO> ps)
        {
            //order matters, maintained
            var ret = new List<KilnTotalDTO>();

            int ttlcarts = 0;
            KilnTotalDTO ktd = null;
            
            int ccap = Ent.Carts.Where(x => x.CartType == "KC").Select(x => x.ShelfCount).SingleOrDefault();

            foreach (var k in ks)
            {
                List<KilnTotalDTO> temp = null;
               
                var kiln = Ent.Kilns.Where(x => x.KilnNumber == k.KilnNo).Single();
                ttlcarts = kiln.LoadRate ?? 0;

                if (k.PId == 0) // no pending loading, fresh load
                {
                    temp = ps.Where(x => x.KilnNo == 0).OrderBy(x => x.LoadIdx).ToList();
                    
                    bool haslastload = false;
                    int remine = ttlcarts;
                    ktd = null;
                    foreach (var tp in temp)
                    {
                        ktd = tp;

                        if (!LessThanCap(ttlcarts, 0, temp.Where(x => x.LoadIdx == ktd.LoadIdx).ToList()))
                        {
                            temp = temp.Where(x => x.LoadIdx == ktd.LoadIdx).ToList();
                            for (int i = 0; i < temp.Count; i++)
                                temp[i].KilnNo = k.KilnNo;

                            ret.AddRange(temp);

                            break;
                        }
                    }
                    if (ret.Count > 0)
                        break;

                    foreach (var t in temp)
                    {
                        ktd = t;

                        if (IsLastLoad(remine,
                            0,
                            t))
                        {
                            haslastload = true;
                            break;
                        }
                    }
                    if (haslastload)
                    {
                        temp = temp.Where(x => x.LoadIdx == ktd.LoadIdx).ToList();
                        for (int i = 0; i < temp.Count; i++)
                             temp[i].KilnNo = k.KilnNo;

                        ret.AddRange(temp.Where(x => x.PId == ktd.PId).ToList());
                        ret.AddRange(temp.Where(x => x.PId != ktd.PId).ToList());
                        break;
                    }
                }
                else
                {
                    temp = ps.Where(x => x.KilnNo == k.KilnNo).ToList();
                    if (temp.Count == 0)
                        continue;

                    bool haslastload = false;
                    int remine = ttlcarts;
                    if (!LessThanCap(ttlcarts, GetFreeRacks(ks.Where(x => x.KilnNo == k.KilnNo).ToList()), temp))
                    {
                        ret.AddRange(temp);
                        break;
                    }
                    else
                    {
                        foreach (var t in temp)
                        {
                            if (IsLastLoad(remine,
                                GetFreeRacks(ks.Where(x => x.KilnNo == k.KilnNo).ToList()),
                                t))
                            {
                                haslastload = true;
                                break;
                            }
                        }
                        if (haslastload)
                        {
                            ret.AddRange(temp);
                            break;
                        }
                    }
                }
                if (ret.Count > 0)
                    break;
            }
            return ret;
        }
        private bool LessThanCap(int kcarts, int freeracks, List<KilnTotalDTO> ps)
        {
            int ttlcarts = 0;
            int remine = freeracks;

            foreach (var p in ps.OrderBy(x => x.LoadIdx).ThenBy(x => x.Height).ToList())
            {
                var tempsum = new SimulatorEntities().EstimateSummaries.Where(x => x.RunNum == EstPro.RunNo && x.PPId == p.PId && x.SessionId == EstPro.SessionId.ToString()).Single();

                int ss = p.Shelevs - (int)Math.Floor((double)remine / p.Height);
                int cs = (int)Math.Ceiling((double)ss / (double)tempsum.KilnShelvesPerCart);
                int diff = (cs * tempsum.KilnShelvesPerCart ?? 0) - ss;

                ttlcarts += cs;
                remine = diff > 0 ? Ent.Carts.Where(x => x.CartType == "KC").Select(x => x.ShelfCount).Single()
                                                                - (diff * p.Height)
                                  : 0;
            }
            return ttlcarts < kcarts ;
        }
        private bool IsLastLoad(int panels, int pid)
        {
            var tempsum = new SimulatorEntities().EstimateSummaries.Where(x => x.RunNum == EstPro.RunNo && x.PPId == pid).Single();

            int loaded = 0;
            int exted = 0;
            
            if (EstPro.CurrPlans.Any(x => x.Plan.Id == pid && x.Status == Constants.Processing))
            {
                exted = EstPro.GetSummary(pid).Panels ?? 0;

                loaded = (EstPro.GetSummary(pid).KilnRacks ?? 0) * (EstPro.GetSummary(pid).KilnPanelsPerShelf ?? 0);
                   // + new SimulatorEntities().Temp_KilnPlan.Where(x => x.PId == pid).Sum(x => x.Panels));
            }
            else
            {
                exted = new SimulatorEntities().EstimateSummaries.Where(x => x.RunNum == EstPro.RunNo && x.PPId == pid && x.SessionId == EstPro.SessionId.ToString() && x.Panels > 0).Sum(x => x.Panels) ?? 0;

                loaded = (tempsum.KilnRacks ?? 0) * (tempsum.KilnPanelsPerShelf ?? 0);
                       //  + new SimulatorEntities().Temp_KilnPlan.Where(x => x.PId == pid).Sum(x => x.Panels) ?? 0;
            }

            return loaded + panels >= exted;
        }
        private bool IsLastLoad(int kcarts, int freeracks, KilnTotalDTO p)
        {//kcarts carts avail in kiln, loadrate or the remining. p is from pool
            var tempsum = new SimulatorEntities().EstimateSummaries.Where(x => x.RunNum == EstPro.RunNo && x.PPId == p.PId && x.SessionId == EstPro.SessionId.ToString()).Single();

            int loaded = 0;
            int exted = 0;
            int loading = 0;

            if (EstPro.CurrPlans.Any(x => x.Plan.Id == p.PId && x.Status == Constants.Processing))
            {
                exted = EstPro.GetSummary(p.PId).Panels ?? 0;

                loaded = (EstPro.GetSummary(p.PId).KilnRacks ?? 0) * (EstPro.GetSummary(p.PId).KilnPanelsPerShelf ?? 0);
                   // + new SimulatorEntities().Temp_KilnPlan.Where(x => x.PId == p.PId).Sum(x => x.Panels));
            }
            else
            {
                exted = new SimulatorEntities().EstimateSummaries.Where(x => x.RunNum == EstPro.RunNo && x.PPId == p.PId && x.SessionId == EstPro.SessionId.ToString() && x.Panels > 0).Sum(x => x.Panels) ?? 0;

                loaded = (tempsum.KilnRacks ?? 0) * tempsum.KilnPanelsPerShelf ?? 0;
                         //+ new SimulatorEntities().Temp_KilnPlan.Where(x => x.PId == p.PId).Sum(x => x.Panels) ?? 0;
            }

            loading = Math.Min((kcarts * (tempsum.ShelvesPerCart ?? 0) + (int)Math.Floor((double)(freeracks / p.Height))) * tempsum.PanelsPerShelf ?? 0, p.Panels);
                      //maximum free space, in panel in kiln 

            return loaded + loading >= exted;

        }
       
        public bool HasPlanInLoading(int pid)
        {
            if (EstPro.CurrPlans.Any(x => x.Plan.Id == pid && x.Status == Constants.Processing))
                return EstPro.GetSummary(pid).KilnRacks > 0 || new SimulatorEntities().Temp_KilnPlan.Any(x => x.PId == pid && x.SessionId == EstPro.SessionId.ToString());
            else
                return new SimulatorEntities().EstimateSummaries.Any(x => x.RunNum == EstPro.RunNo && x.PPId == pid && x.SessionId == EstPro.SessionId.ToString() && x.KilnRacks > 0)
                    || new SimulatorEntities().Temp_KilnPlan.Any(x => x.PId == pid);
        }
        private int GetFreeRacks(List<KilnTotalDTO> kts)
        {
            if (!StrictMode)
                return 0;
            //assume only last partially filled cart will be loaded for next load(on same or different plan)
            var ret = 0;

            var cart = Ent.Carts.Where(x => x.CartType == "KC").Single();

            foreach (var kt in kts.OrderBy(x => x.LoadIdx))
            {
                if (kt.PId == 0)
                    break;

                var tempsum = new SimulatorEntities().EstimateSummaries.Where(x => x.RunNum == EstPro.RunNo && x.PPId == kt.PId && x.SessionId == EstPro.SessionId.ToString()).Single();
                //relative shelf
                int diff = kt.Carts * tempsum.KilnShelvesPerCart ?? 0 //total shelves of all plan carts can load
                           - (int)(kt.Shelevs - Math.Floor((double)ret / kt.Height)); //actual shelves on the carts of the loaded PId

                // ret as absolute single layer of shelf - Height = 1
                if (diff > 0)
                    ret = diff * kt.Height + (cart.ShelfCount - tempsum.KilnShelvesPerCart * kt.Height ?? 0); //remines of a cart
            }

            return ret;
        }
        private int GetFreeRacks(int carts, int racks, int pid, int ttlfree = 0)
        {
            if (!StrictMode)
                return 0;
           
            var ret = 0;
            var tempsum = new SimulatorEntities().EstimateSummaries.Where(x => x.RunNum == EstPro.RunNo && x.PPId == pid && x.SessionId == EstPro.SessionId.ToString()).Single();

            int h = GetPlanHeight(pid);

            int shelvesavail = carts * tempsum.KilnShelvesPerCart ?? 0 + (int)Math.Floor((double)ttlfree / h);

            if (shelvesavail > racks)
            {
                ret = (racks % tempsum.KilnShelvesPerCart ?? 0) * h + 
                      (int)(Ent.Carts.Where(x => x.CartType == "KC").Select(x => x.ShelfCount).SingleOrDefault() 
                      - tempsum.KilnShelvesPerCart * h);
            }
            return ret;
        }
        public int GetPlanHeight(int pid)
        {
            return (int)Math.Floor((double)(Ent.Carts.Where(x => x.CartType == "KC").Select(x => x.ShelfCount).SingleOrDefault()
                / new SimulatorEntities().EstimateSummaries.Where(x => x.RunNum == EstPro.RunNo && x.PPId == pid && x.SessionId == EstPro.SessionId.ToString()).Select(x => x.KilnShelvesPerCart).Single()));
        }
        private List<int> GetKilnsToLoad()
        {
            var ret = new List<int>();

            var tt = Ent.vwKilnsToLoads.ToList()
                     .OrderBy(x => x.KilnNumber).OrderByDescending(x => x.aval)
                     .OrderByDescending(x => x.inuse).ToList();

            var run = Ent.EstimateRuns.Where(x => x.RunNum == EstPro.RunNo).Single();

            var tt1 = new List<int>();
            foreach (var t in tt)
            {
                if (t.KilnNumber < (run.KilnStart ?? -9999) || t.KilnNumber > (run.KilnEnd ?? 9999))
                    continue;

                tt1.Add(t.KilnNumber);
            }

            foreach (var tkp in tt1)
            {
                if (StatusManager.CanUse<Kiln>(tkp, TeamNm))
                {
                    ret.Add(tkp);
                }
            }

            return ret;
        }
        private int GetKilnToUnload()
        {
            int kilnno = 0;

            var tt = Ent.vwKilnsToUnloads.OrderByDescending(x => x.inunload)
                                   .Select(x => x.kilnnumber).ToList();

            foreach (var t in tt)
            {
                if (StatusManager.CanUse<Kiln>(t, TeamNm))
                {
                    StatusManager.SetStatus<Kiln>(t, TeamNm);
                    kilnno = t;
                    break;
                }
            }
            return kilnno;
        }
        private List<KilnTotalDTO> GetTotalInKiln(List<int> nos)
        {
            var ret = new List<KilnTotalDTO>();

            var ppro = new CartPoolProvider(EstPro);
            int pno = ppro.GetPoolNumByType("DK");
            var temppools = new SimulatorEntities().Temp_CartPoolPlan.Where(x => x.PoolNum == pno && x.SessionId == EstPro.SessionId.ToString() && x.Panels > 0).ToList();
            var cart = Ent.Carts.Where(x => x.CartType == "KC").Single();

            foreach (var no in nos)
            {
                var kiln = Ent.Kilns.Where(x => x.KilnNumber == no).Single();
                var tempkilns = new SimulatorEntities().Temp_KilnPlan.Where(x => x.KilnNumber == no && x.SessionId == EstPro.SessionId.ToString()).ToList();

                if (tempkilns.Count > 0)
                {
                    foreach (var tk in tempkilns)
                    {
                        var estsum = new SimulatorEntities().EstimateSummaries.Where(x => x.PPId == tk.PId && x.RunNum == EstPro.EstRun.RunNum && x.SessionId == EstPro.SessionId.ToString()).Single();
                        var plan = Ent.ProductionPlans.Where(x => x.Id == tk.PId).Single();

                        var ss = (int)Math.Ceiling((double)(tk.Panels / estsum.KilnPanelsPerShelf));

                        ret.Add(new KilnTotalDTO {
                            PId = tk.PId,
                            KilnNo = tk.KilnNumber,
                            Panels = tk.Panels ?? 0,
                            Shelevs = ss,
                            Carts = (int)Math.Ceiling((double)ss / (double)estsum.KilnShelvesPerCart),
                            Height = (int)Math.Floor((double)cart.ShelfCount / (double)estsum.KilnShelvesPerCart),
                            LoadIdx = tk.LoadIdx ?? 0
                        });
                    }
                }
                else
                {
                    ret.Add(new KilnTotalDTO {
                        PId = 0,
                        KilnNo = kiln.KilnNumber,
                        Panels = 0,
                        Shelevs = 0,
                        Carts = 0,
                        Height = 0,
                        LoadIdx = MAX_LOADIDX
                    });
                }
            }
            return ret;
        }
        public void FireAll()
        {
            using (var ent = new SimulatorEntities())
            {
                var ks = ent.Temp_KilnPlan.Where(x => x.FiringAt == -1 && x.SessionId == EstPro.SessionId.ToString() && x.Panels > 0).ToList();

                foreach (var k in ks)
                {
                    if (CanFire(k.KilnNumber))
                    {
                        k.FiringAt = CurrHour;
                        k.UpdateDate = DateTime.Now;
                        ent.SaveChanges();

                        SaveActivity(new KilnActivity
                        {
                            KilnNumber = k.KilnNumber,
                            PId = k.PId,
                            Carts = k.Carts,
                            Panels = k.Panels,
                            Operation = "Firing",
                            SessionId = EstPro.SessionId.ToString()

                        });
                        _st.Tracing("Debug: P#" + k.PId + ", K#" + k.KilnNumber.ToString() + " firing " + k.Panels + " panels by T#" + TeamNm, 
                                        TraceLevel.Verbose, 
                                        EstPro.SessionId.ToString());
                    }
                }
            }
        }
        private bool AllPlanDried()
        {
            int pno = new CartPoolProvider(EstPro).GetPoolNumByType("DK");

            return EstPro.AllPlanExted() 
                && !new SimulatorEntities().Temp_CartPoolPlan.Any(x => x.PoolNum == pno && x.SessionId == EstPro.SessionId.ToString() && x.Panels > 0) 
                && !new SimulatorEntities().Temp_DryerPlan.Any(x => x.Carts > 0 && x.SessionId == EstPro.SessionId.ToString());
        }
        private bool CanFire(int kno)
        {
            bool loaded = false;
            var ppro = new CartPoolProvider(EstPro);
            int wt = GetWaitTime();

            var ks = new SimulatorEntities().Temp_KilnPlan.Where(x => x.KilnNumber == kno && x.SessionId == EstPro.SessionId.ToString()).ToList();
         
            if (ks.Sum(x => x.Carts) >= Ent.Kilns.Where(x => x.KilnNumber == kno).Select(x => x.Capacity).Single() || AllPlanDried())
                //kiln is full
                loaded = true;
            else
            {
                int lr = Ent.Kilns.Where(x => x.KilnNumber == kno).Select(x => x.LoadRate).SingleOrDefault() ?? 0;

                if (!(new CartPoolProvider(EstPro).IsSameTypeInPool(ks[0].PId, lr, this)))
                {
                    bool haslastfiring = false;

                    foreach (var k in ks)
                    {
                        if (EstPro.CurrPlans.Any(x => x.Plan.Id == k.PId && x.Status == Constants.Processing))
                            haslastfiring = EstPro.GetSummary(k.PId).KilnRacks * EstPro.GetSummary(k.PId).KilnPanelsPerShelf >= EstPro.GetSummary(k.PId).Panels;
                        else
                        {
                            var tempsum = new SimulatorEntities().EstimateSummaries.Where(x => x.RunNum == EstPro.RunNo && x.PPId == k.PId && x.SessionId == EstPro.SessionId.ToString()).Single();

                            haslastfiring = tempsum.KilnRacks * tempsum.KilnPanelsPerShelf >= tempsum.Panels;
                           
                        }
                        if (haslastfiring)
                                break;
                    }
                    if (haslastfiring)
                    {
                        if (wt == 0 || wt <= CurrHour)
                            loaded = true;
                    }
                }
            }
            return loaded;
        }

        private int GetWaitTime() //absolute hrs
        {
            //none, shift, time or plan
            int hr = EstPro.EstRun.KilnWaitTime ?? 0;

            if (!string.IsNullOrEmpty(EstPro.EstRun.KilnWaitType))
            {
                if (EstPro.EstRun.KilnWaitType.ToLower() == "shift")
                {
                    ShiftProvider sp = new ShiftProvider(EstPro);

                    hr = sp.GetShiftEnd() - 1; //guaranteed

                    if (hr > (EstPro.EstRun.KilnWaitTime ?? 24))//maximum 24
                        hr = EstPro.EstRun.KilnWaitTime ?? 0;
                }
                else
                {
                    if(EstPro.EstRun.KilnWaitType.ToLower() == "time")
                    {
                        hr = EstPro.EstRun.KilnWaitTime ?? 0;
                    }
                    else
                    {
                        if(EstPro.EstRun.KilnWaitType.ToLower() == "plan")
                        {
                            //TODO: requires more work to impl
                            throw new NotImplementedException("Plan Panels Reach Kiln Time. Full Simulation On Time Axis");
                        }
                    }
                }
            } 
                      
            return  hr == 0 ? 0 : CurrHour + hr; // hr is the offset to current hour
        }
        public bool IsSameType(int pid1, int pid2)
        {
            if (pid1 == 0 || pid2 == 0)
                return true;

            var p1 = Ent.ProductionPlans.Where(x => x.Id == pid1).Single();
            var p2 = Ent.ProductionPlans.Where(x => x.Id == pid2).Single();
            double tol = (double)(new SimulatorEntities().EstimateRuns.Where(x => x.RunNum == EstPro.RunNo).Select(x => x.TempTolerance).SingleOrDefault() ?? 0);

            return p2.KilnTime == p1.KilnTime && (double)(p2.KilnTemp) >= (double)(p1.KilnTemp) - tol 
                                              && (double)(p2.KilnTemp) <= (double)(p1.KilnTemp) + tol;
        }
        private void SaveActivity(KilnActivity da)
        {
            using (var ent = new SimulatorEntities())
            {
                ent.KilnActivities.Add(new KilnActivity
                {
                    HourAt = CurrHour,
                    Carts = da.Carts,
                    PId = da.PId,
                    CreateDate = DateTime.Now,
                    KilnNumber = da.KilnNumber,
                    Operation = da.Operation,  //drying/firing, loading, unloading, cleaned
                    Panels = da.Panels,
                    RunNum = EstPro.RunNo,
                    SessionId = EstPro.SessionId.ToString()
                });

                ent.SaveChanges();
            }
        }
    }
   
}
