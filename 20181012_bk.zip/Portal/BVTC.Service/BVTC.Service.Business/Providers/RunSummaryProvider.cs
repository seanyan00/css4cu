﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;

using BVTC.Service.Data.Models.Simulator;
using BVTC.Service.TransferObject;

namespace BVTC.Service.Business.Providers
{
    public class RunSummaryProvider
    {
        public List<ShiftDTO> GetShifts()
        {
            return new SimulatorEntities().ShiftInfoes.Select(x => new ShiftDTO {
                ShiftName = x.ShiftName,
                DaysPerWeek = x.DaysPerWeek,
                DayStart = x.DayStart,
                DayEnd = x.DayEnd
            }).ToList();
        }
        public List<DryerDTO> GetDryers()
        {
            return new SimulatorEntities().Dryers.Select(x => new DryerDTO
            {
                DryerNumber = x.DryerNumber,
                DryerName = x.DryerName,
                Capacity = x.Capacity,
                LoadRate = x.LoadRate,
                Manufacturer = x.Manufacturer
            }).ToList();
        }
        public List<KilnDTO> GetKilns()
        {
            return new SimulatorEntities().Kilns.Select(x => new KilnDTO
            {
                KilnNumber = x.KilnNumber,
                KilnName = x.KilnName,
                Capacity = x.Capacity,
                LoadRate = x.LoadRate ?? 0,
                Manufacturer = x.Manufacturer,
                UnloadRate = x.UnloadRate ?? 0
            }).ToList();
        }
        public void SaveEstRun(EstRunDTO erd)
        {
            using (var ent = new SimulatorEntities())
            {
                var esrun = new EstimateRun {
                    RunNm = erd.RunNm,
                    CartPool1 = erd.CartPool1,
                    CartPool2 = erd.CartPool2,
                    CartPool3 = erd.CartPool3,
                    CreateDate = DateTime.Now,
                    CreatedBy = erd.CreatedBy,
                    DKTeams = erd.DKTeams,
                    DryerEnd = erd.DryerEnd,
                    DryerStart = erd.DryerStart,
                    KilnEnd = erd.KilnEnd,
                    KilnStart = erd.KilnStart,
                    KilnRejRate = erd.KilnRejRate,
                    DryerRejRate = erd.DryerRejRate,
                    KilnWaitType = erd.KilnWaitType,
                    KilnWaitTime = erd.KilnWaitTime,
                    PlanEnd = erd.PlanEnd,
                    PlanOrder = erd.PlanOrder,
                    PlanStart = erd.PlanStart,
                    ShiftName = erd.ShiftName,
                    ShiftTeams = erd.ShiftTeams,
                    SameExt = erd.SameExt
                };

                ent.EstimateRuns.Add(esrun);
                ent.SaveChanges();
            }
        }

        public List<EstRunDTO> GetRuns()
        {
            var ent = new SimulatorEntities();

            //var temp = ent.EstimateSummaries.GroupBy(x => x.RunNum).Select(y => new { CreateDate = y.Max(z => z.CreateDate), RunNum = y.Key }).ToList();
            var temp = ent.SessionRuns.GroupBy(x => x.RunNum).Select(y => new { CreateDate = y.Max(z => z.CreateDate), RunNum = y.Key }).ToList();
            var temp1 = ent.EstimateRuns.ToList();

            var q = from x in temp1
                    join y in temp on x.RunNum equals y.RunNum into jointable
                    from z in jointable.DefaultIfEmpty()
                    select new EstRunDTO
                    {
                        RunNum = x.RunNum,
                        RunNm = x.RunNm,
                        CartPool1 = x.CartPool1 ?? 0,
                        CartPool2 = x.CartPool2 ?? 0,
                        CartPool3 = x.CartPool3 ?? 0,
                        CreateDate = x.CreateDate,
                        CreatedBy = x.CreatedBy,
                        DKMode = x.DKMode,
                        DKTeams = x.DKTeams ?? 0,
                        DryerStart = x.DryerStart ?? 0,
                        DryerEnd = x.DryerEnd ?? 9999,
                        DryerRejRate = x.DryerRejRate ?? 0,
                        CartTransTime = x.CartTransTime ?? 0,
                        DyerLoader = x.DyerLoader,
                        ExtColor = x.ExtColor,
                        ExtDye = x.ExtDye ?? 0,
                        KilnStart = x.KilnStart ?? 0,
                        KilnEnd = x.KilnEnd ?? 9999,
                        KilnLoader = x.KilnLoader,
                        KilnRejRate = x.KilnRejRate ?? 0,
                        KilnWaitType = x.KilnWaitType,
                        KilnWaitTime = x.KilnWaitTime ?? 0,
                        PlanStart = x.PlanStart ?? 0,
                        PlanEnd = x.PlanEnd ?? 0,
                        PlanOrder = x.PlanOrder,
                        RackTotal = x.RackTotal ?? 0,
                        SameExt = x.SameExt ?? false,
                        ShiftName = x.ShiftName,
                        ShiftName1 = x.ShiftName1,
                        ShiftName2 = x.ShiftName2,
                        ShiftTeams = x.ShiftTeams ?? 0,
                        TempTolerance = x.TempTolerance ?? 0,
                        LastRun = z == null ? default(DateTime) : z.CreateDate

                    };
            return q.ToList();
        }
        public SummaryDTO GetSummary(int runno)
        {
            var ent = new SimulatorEntities();

            if (!ent.EstimateSummaries.Any(x => x.RunNum == runno || x.Hours == 0))
                throw new ArgumentException("RunNum not found in Summary or No Hours recorded");

            var rsum = ent.Database.SqlQuery<SummaryDTO>("procGetRunSumHead @p_runno", new SqlParameter("@p_runno", runno)).Single();

            List<TeamActSummary> tass = ent.procGetTeamSummary(runno).Select(x => new TeamActSummary
            {
                Name = x.Name,
                WorkHour = x.WorkHour ?? 0,
                ActHour = x.ActHour ?? 0,
                ActRate = (double)(x.ActHour / (double)x.WorkHour)
            }).ToList();

            rsum.ExtTeamAct = tass.Where(x => x.Name.Contains("Ext")).ToArray();
            rsum.KilnTeamAct = tass.Where(x => x.Name.Contains("DK")).ToArray();

            var dss = ent.procGetDryerActSummary(runno).Select(x => new
            {
                Name = x.Name,
                TotalHour = x.TotalHour,
                Used = x.Used,
                Util = x.Utilization
            }).OrderBy(x => x.Name).ToList();

            rsum.DryerAct.Used = dss.First().Used;
            rsum.DryerAct.TotalHour = dss.First().TotalHour ?? 0;
            rsum.DryerAct.Utils = new Utilization[dss.Count];
            for (int i = 0; i < dss.Count; i++)
            {
                rsum.DryerAct.Utils[i] = new Utilization { Key = dss[i].Name, Value = (double)dss[i].Util };
            }

            var kss = ent.procGetKilnActSummary(runno).Select(x => new
            {
                Name = x.Name,
                TotalHour = x.TotalHour,
                Used = x.Used,
                Util = x.Utilization
            }).OrderBy(x => x.Name).ToList();

            rsum.KilnAct.Used = kss.First().Used;
            rsum.KilnAct.TotalHour = kss.First().TotalHour ?? 0;
            rsum.KilnAct.Utils = new Utilization[kss.Count];
            for (int i = 0; i < kss.Count; i++)
            {
                rsum.KilnAct.Utils[i] = new Utilization { Key = kss[i].Name, Value = (double)kss[i].Util };
            }
            return rsum;
        }

        public PlanDTO[] GetPlans()
        {
            return new SimulatorEntities().ProductionPlans.Where(x => x.Id != 0).Select(x => new PlanDTO {
                Id = x.Id,
                Color = x.Color,
                DryerTime = x.DryerTime,
                Dye = x.Dye,
                EstShipDate = x.EstShipDate,
                ExtrusionHeight = (double)x.ExtrusionHeight,
                ExtrusionLength = (double)x.ExtrusionLength,
                ExtrusionWidth = (double)x.ExtrusionWidth,
                KilnTemp = (double)x.KilnTemp,
                KilnTime = x.KilnTime,
                ProjectNumber = x.ProjectNumber,
                Shrinkage = (double)x.Shrinkage,
                Total = x.Total
            }).OrderBy(y => y.Id).ToArray();
        }
        
        public EstSummaryDTO[] GetEstSummaries(int runno)
        {
            var ent = new SimulatorEntities();
            var temp = ent.SessionRuns.Where(x => x.RunNum == runno).ToList();
            var sid = temp.Where(x => x.CreateDate == temp.Max(y => y.CreateDate)).Select(z => z.SessionId).Single();

            return ent.EstimateSummaries.Where(x => x.SessionId == sid && x.RunNum == runno).Select(x => new EstSummaryDTO
            {
                Carts = x.Carts,
                CreateDate = x.CreateDate,
                DryersUsed = x.DryersUsed,
                ExtruderName = x.ExtruderName,
                Hours = x.Hours,
                Id = x.Id,
                KilnCarts = x.KilnCarts,
                KilnPanelsPerShelf = x.KilnPanelsPerShelf,
                KilnRacks = x.KilnRacks,
                KilnShelvesPerCart = x.KilnShelvesPerCart,
                KilnUsed = x.KilnUsed,
                Notes = x.Notes,
                PanelFired = x.PanelFired,
                Panels = x.Panels,
                PanelsPerShelf = x.PanelsPerShelf,
                PlanEnd = x.PlanEnd,
                PlanStart = x.PlanStart,
                PPId = x.PPId,
                Racks = x.Racks,
                RunNum = x.RunNum,
                SessionId = x.SessionId,
                ShelvesPerCart = x.ShelvesPerCart,
                ShiftName = x.ShiftName
            }).OrderBy(y => y.CreateDate).ToArray();

        }

        public EstDetailDTO[] GetEstDetails(int runno)
        {
            var ent = new SimulatorEntities();
            var temp = ent.SessionRuns.Where(x => x.RunNum == runno).ToList();
            var sid = temp.Where(x => x.CreateDate == temp.Max(y => y.CreateDate)).Select(z => z.SessionId).Single();

            var sumids = ent.EstimateSummaries.Where(x => x.SessionId == sid && x.RunNum == runno).Select(x => x.Id).ToList();
            return ent.EstimateDetails.Where(x => sumids.Contains(x.SumId)).Select(x => new EstDetailDTO
            {
                Action = x.Action,
                AtHour = x.AtHour,
                CartExted = x.CartExted,
                CartFired = x.CartFired,
                CreateDate = x.CreateDate,
                Id = x.Id,
                Note = x.Note,
                PanelExted = x.PanelExted,
                PanelFired = x.PanelFired,
                PlanExecuted = x.PlanExecuted,
                RackExted = x.RackExted,
                RackFired = x.RackFired,
                SumId = x.SumId,
                Team = x.Team,
                ThreadId = x.ThreadId

            }).OrderBy(y => y.SumId).ThenBy(z => z.AtHour).ToArray();
        }

        public TeamActDTO[] GetTeamActs(int runno)
        {
            var ent = new SimulatorEntities();
            var temp = ent.SessionRuns.Where(x => x.RunNum == runno).ToList();
            var sid = temp.Where(x => x.CreateDate == temp.Max(y => y.CreateDate)).Select(z => z.SessionId).Single();

            return ent.TeamActivities.Where(x => x.SessionId == sid).Select(x => new TeamActDTO
            {
                Act = x.Act,
                AtHour = x.AtHour,
                DryerNo = x.DryerNo,
                ExtName = x.ExtName,
                Id = x.Id,
                KilnNo = x.KilnNo,
                PId = x.PId,
                RunNum = x.RunNum,
                SessionId = x.SessionId,
                TeamName = x.TeamName

            }).OrderBy(y => y.Id).ToArray();
        }

        public DryerActDTO[] GetDryerActs(int runno)
        {
            var ent = new SimulatorEntities();
            var temp = ent.SessionRuns.Where(x => x.RunNum == runno).ToList();
            var sid = temp.Where(x => x.CreateDate == temp.Max(y => y.CreateDate)).Select(z => z.SessionId).Single();

            return ent.DryerActivities.Where(x => x.SessionId == sid).Select(x => new DryerActDTO
            {
                Carts = x.Carts,
                CreateDate = x.CreateDate,
                DryerNumber = x.DryerNumber,
                HourAt = x.HourAt,
                Id = x.Id,
                Operation = x.Operation,
                PId = x.PId,
                RunNum = x.RunNum,
                SessionId = x.SessionId
            }).OrderBy(y => y.Id).ToArray();
        }
        public KilnActDTO[] GetKilnActs(int runno)
        {
            var ent = new SimulatorEntities();
            var temp = ent.SessionRuns.Where(x => x.RunNum == runno).ToList();
            var sid = temp.Where(x => x.CreateDate == temp.Max(y => y.CreateDate)).Select(z => z.SessionId).Single();

            return ent.KilnActivities.Where(x => x.SessionId == sid).Select(x => new KilnActDTO
            {
                Carts = x.Carts,
                CreateDate = x.CreateDate,
                HourAt = x.HourAt,
                Id = x.Id,
                KilnNumber = x.KilnNumber,
                Operation = x.Operation,
                Panels = x.Panels,
                PId = x.PId,
                RunNum = x.RunNum,
                SessionId = x.SessionId
            }).OrderBy(y => y.Id).ToArray();
        }

        public CartDTO[] GetCarts()
        {
            return new SimulatorEntities().Carts.Select(x => new CartDTO
            {
                CartLength = (double)x.CartLength,
                CartName = x.CartName,
                CartType = x.CartType,
                CartWidth = (double)x.CartWidth,
                PadHeight = (double)x.PadHeight,
                PadLength = (double)x.PadLength,
                PadWidth = (double)x.PadWidth,
                RobotLoading = x.RobotLoading,
                ShelfCount = x.ShelfCount,
                ShelfSpacing = (double)x.ShelfSpacing,
                TotalCarts = x.TotalCarts
            }).OrderBy(y => y.CartName).ToArray();
        }

        public ShelfDTO[] GetShelves()
        {
            return new SimulatorEntities().Shelves.Select(x => new ShelfDTO
            {
                Manufacturer = x.Manufacturer,
                RobotLoading = x.RobotLoading,
                ShelfLength = (double)x.ShelfLength,
                ShelfName = x.ShelfName,
                ShelfThickness = (double)x.ShelfThickness,
                ShelfTotal = x.ShelfTotal,
                ShelfType = x.ShelfType,
                ShelfWidth = (double)x.ShelfWidth
            }).OrderBy(y => y.ShelfName).ToArray();
        }

        public CartPoolDTO[] GetCartPools()
        {
            return new SimulatorEntities().CartPools.Select(x => new CartPoolDTO
            {
                Capacity = x.Capacity,
                PoolNum = x.PoolNum,
                PoolType = x.PoolType
            }).OrderBy(y => y.PoolNum).ToArray();
        }

        public ExtruderDTO[] GetExtruders()
        {
            return new SimulatorEntities().Extruders.Select(x => new ExtruderDTO
            {
                ColorCleanOut = x.ColorCleanOut,
                DyeCleanOut = x.DyeCleanOut,
                DyeMaxHeight = (double)x.DyeMaxHeight,
                DyeMaxWidth = (double)x.DyeMaxWidth,
                DyeMinHeight = (double)x.DyeMinHeight,
                DyeMinWidth = (double)x.DyeMinWidth,
                ExtruderName = x.ExtruderName,
                ExtrusionRate = x.ExtrusionRate,
                LoaderLength = (double)x.LoaderLength,
                LoaderMaxParallel = x.LoaderMaxParallel,
                LoaderWidth = (double)x.LoaderWidth,
                Manufacturer = x.Manufacturer,
                RobotLoading = x.RobotLoading
            }).OrderBy(y => y.ExtruderName).ToArray();
        }

        public ShiftBreakDTO[] GetShiftBreaks()
        {
            return new SimulatorEntities().ShiftBreaks.Select(x => new ShiftBreakDTO
            {
                EndAt = x.EndAt,
                Id = x.Id,
                ShiftName = x.ShiftName,
                StartAt = x.StartAt
            }).OrderBy(y => y.ShiftName).ToArray();
        }

        public void SavePlan(PlanDTO pd)
        {
            using(var ent = new SimulatorEntities())
            {
                if (pd.Id <= 0)
                {
                    ent.ProductionPlans.Add(new ProductionPlan
                    {
                        Color = pd.Color,
                        DryerTime = pd.DryerTime,
                        Dye = pd.Dye,
                        EstShipDate = pd.EstShipDate,
                        ExtrusionHeight = (decimal)pd.ExtrusionHeight,
                        ExtrusionLength = (decimal)pd.ExtrusionLength,
                        ExtrusionWidth = (decimal)pd.ExtrusionWidth,
                        KilnTemp = (decimal)pd.KilnTemp,
                        ProjectNumber = pd.ProjectNumber,
                        KilnTime = pd.KilnTime,
                        Shrinkage = (decimal)pd.Shrinkage,
                        Total = pd.Total
                    });
                } else
                {
                    var plan = ent.ProductionPlans.Where(x => x.Id == pd.Id).Single();

                    plan.Color = pd.Color;
                    plan.DryerTime = pd.DryerTime;
                    plan.Dye = pd.Dye;
                    plan.EstShipDate = pd.EstShipDate;
                    plan.ExtrusionHeight = (decimal)pd.ExtrusionHeight;
                    plan.ExtrusionLength = (decimal)pd.ExtrusionLength;
                    plan.ExtrusionWidth = (decimal)pd.ExtrusionWidth;
                    plan.KilnTemp = (decimal)pd.KilnTemp;
                    plan.ProjectNumber = pd.ProjectNumber;
                    plan.KilnTime = pd.KilnTime;
                    plan.Shrinkage = (decimal)pd.Shrinkage;
                    plan.Total = pd.Total;
                }
                ent.SaveChanges();
            }
        }
        public void SaveCartPool(CartPoolDTO cd)
        {
            using (var ent = new SimulatorEntities())
            {
                if (ent.CartPools.Any(x => x.PoolNum == cd.PoolNum))
                {
                    var cp = ent.CartPools.Where(x => x.PoolNum == cd.PoolNum).Single();

                    cp.PoolNum = cd.PoolNum;
                    cp.PoolType = cd.PoolType;
                    cp.Capacity = cd.Capacity;
                  
                }
                else
                {
                    ent.CartPools.Add(new CartPool
                    {
                        Capacity = cd.Capacity,
                        PoolNum = cd.PoolNum,
                        PoolType = cd.PoolType
                    });
                }
                ent.SaveChanges();
            }
        }

        public void SaveCart(CartDTO cd)
        {
            using(var ent = new SimulatorEntities())
            {
                if (ent.Carts.Any(x => x.CartName == cd.CartName))
                {
                    var cart = ent.Carts.Where(x => x.CartName == cd.CartName).Single();

                    cart.CartLength = (decimal)cd.CartLength;
                    cart.CartType = cd.CartType;
                    cart.CartWidth = (decimal)cd.CartWidth;
                    cart.PadHeight = (decimal)cd.PadHeight;
                    cart.PadLength = (decimal)cd.PadLength;
                    cart.PadWidth = (decimal)cd.PadWidth;
                    cart.RobotLoading = cd.RobotLoading;
                    cart.ShelfCount = cd.ShelfCount;
                    cart.ShelfSpacing = (decimal)cd.ShelfSpacing;
                    cart.TotalCarts = cd.TotalCarts;
                }
                else
                {
                    ent.Carts.Add(new Cart
                    {
                        CartLength = (decimal)cd.CartLength,
                        CartName = cd.CartName,
                        CartType = cd.CartType,
                        CartWidth = (decimal)cd.CartWidth,
                        PadHeight = (decimal)cd.PadHeight,
                        PadLength = (decimal)cd.PadLength,
                        PadWidth = (decimal)cd.PadWidth,
                        RobotLoading = cd.RobotLoading,
                        ShelfCount = cd.ShelfCount,
                        ShelfSpacing = (decimal)cd.ShelfSpacing,
                        TotalCarts = cd.TotalCarts
                    });
                }
                ent.SaveChanges();
            }
        }

        public void SaveShelf(ShelfDTO sd)
        {
            using (var ent = new SimulatorEntities())
            {
                if (ent.Shelves.Any(x => x.ShelfName == sd.ShelfName))
                {
                    var shelf = ent.Shelves.Where(x => x.ShelfName == sd.ShelfName).Single();

                    shelf.Manufacturer = sd.Manufacturer;
                    shelf.RobotLoading = sd.RobotLoading;
                    shelf.ShelfLength = (decimal)sd.ShelfLength;
                    shelf.ShelfThickness = (decimal)sd.ShelfThickness;
                    shelf.ShelfTotal = sd.ShelfTotal;
                    shelf.ShelfType = sd.ShelfType;
                    shelf.ShelfWidth = (decimal)sd.ShelfWidth;
                }
                else
                {
                    ent.Shelves.Add(new Shelf
                    {
                        Manufacturer = sd.Manufacturer,
                        RobotLoading = sd.RobotLoading,
                        ShelfLength = (decimal)sd.ShelfLength,
                        ShelfName = sd.ShelfName,
                        ShelfThickness = (decimal)sd.ShelfThickness,
                        ShelfTotal = sd.ShelfTotal,
                        ShelfType = sd.ShelfType,
                        ShelfWidth = (decimal)sd.ShelfWidth
                    });
                }
                ent.SaveChanges();

            }
        }

        public void SaveExtruder(ExtruderDTO ed)
        {
            using (var ent = new SimulatorEntities())
            {
                if (ent.Extruders.Any(x => x.ExtruderName == ed.ExtruderName))
                {
                    var ext = ent.Extruders.Where(x => x.ExtruderName == ed.ExtruderName).Single();

                    ext.ColorCleanOut = ed.ColorCleanOut;
                    ext.DyeCleanOut = ed.DyeCleanOut;
                    ext.DyeMaxHeight = (decimal)ed.DyeMaxHeight;
                    ext.DyeMaxWidth = (decimal)ed.DyeMaxWidth;
                    ext.DyeMinHeight = (decimal)ed.DyeMinHeight;
                    ext.DyeMinWidth = (decimal)ed.DyeMinWidth;
                    ext.ExtruderName = ed.ExtruderName;
                    ext.ExtrusionRate = ed.ExtrusionRate;
                    ext.LoaderLength = (decimal)ed.LoaderLength;
                    ext.LoaderMaxParallel = ed.LoaderMaxParallel;
                    ext.LoaderWidth = (decimal)ed.LoaderWidth;
                    ext.Manufacturer = ed.Manufacturer;
                    ext.RobotLoading = ed.RobotLoading;
                }
                else
                {
                    ent.Extruders.Add(new Extruder
                    {
                        ColorCleanOut = ed.ColorCleanOut,
                        DyeCleanOut = ed.DyeCleanOut,
                        DyeMaxHeight = (decimal)ed.DyeMaxHeight,
                        DyeMaxWidth = (decimal)ed.DyeMaxWidth,
                        DyeMinHeight = (decimal)ed.DyeMinHeight,
                        DyeMinWidth = (decimal)ed.DyeMinWidth,
                        ExtruderName = ed.ExtruderName,
                        ExtrusionRate = ed.ExtrusionRate,
                        LoaderLength = (decimal)ed.LoaderLength,
                        LoaderMaxParallel = ed.LoaderMaxParallel,
                        LoaderWidth = (decimal)ed.LoaderWidth,
                        Manufacturer = ed.Manufacturer,
                        RobotLoading = ed.RobotLoading
                    });
                }
                ent.SaveChanges();
            }
        }

        public void SaveShiftBreak(ShiftBreakDTO sd)
        {
            using (var ent = new SimulatorEntities())
            {
                if (sd.Id <= 0)
                {
                    ent.ShiftBreaks.Add(new ShiftBreak
                    {
                        EndAt = sd.EndAt,
                        ShiftName = sd.ShiftName,
                        StartAt = sd.StartAt
                    });
                } else
                {
                    var sb = ent.ShiftBreaks.Where(x => x.Id == sd.Id).Single();

                    sb.EndAt = sd.EndAt;
                    sb.StartAt = sd.StartAt;
                    sb.ShiftName = sd.ShiftName;
                }
                ent.SaveChanges();
            }
        }

        public void SaveShift(ShiftDTO sd)
        {
            using (var ent = new SimulatorEntities())
            {
                if (ent.ShiftInfoes.Any(x => x.ShiftName == sd.ShiftName))
                {
                    var shift = ent.ShiftInfoes.Where(x => x.ShiftName == sd.ShiftName).Single();
                    shift.DaysPerWeek = sd.DaysPerWeek;
                    shift.DayStart = sd.DayStart;
                    shift.DayEnd = sd.DayEnd;
                }
                else
                {
                    ent.ShiftInfoes.Add(new ShiftInfo
                    {
                        DayEnd = sd.DayEnd,
                        DaysPerWeek = sd.DaysPerWeek,
                        DayStart = sd.DayStart,
                        ShiftName = sd.ShiftName
                    });
                }
                ent.SaveChanges();
            }
        }

        public void SaveDryer(DryerDTO dd)
        {
            using (var ent = new SimulatorEntities())
            {
                if (ent.Dryers.Any(x => x.DryerNumber == dd.DryerNumber))
                {
                    var d = ent.Dryers.Where(x => x.DryerNumber == dd.DryerNumber).Single();

                    d.Capacity = dd.Capacity;
                    d.DryerName = dd.DryerName;
                    d.LoadRate = dd.LoadRate;
                    d.Manufacturer = dd.Manufacturer;
                }
                else
                {
                    ent.Dryers.Add(new Dryer
                    {
                        Capacity = dd.Capacity,
                        DryerName = dd.DryerName,
                        DryerNumber = dd.DryerNumber,
                        LoadRate = dd.LoadRate,
                        Manufacturer = dd.Manufacturer

                    });
                }
                ent.SaveChanges();
            }
        }

        public void SaveKiln(KilnDTO kd)
        {
            using (var ent = new SimulatorEntities())
            {
                if (ent.Kilns.Any(x => x.KilnNumber == kd.KilnNumber))
                {
                    var k = ent.Kilns.Where(x => x.KilnNumber == kd.KilnNumber).Single();

                    k.Capacity = kd.Capacity;
                    k.KilnName = kd.KilnName;
                    k.LoadRate = kd.LoadRate;
                    k.Manufacturer = kd.Manufacturer;
                    k.UnloadRate = kd.UnloadRate;
                }
                else
                {
                    ent.Kilns.Add(new Kiln
                    {
                        Capacity = kd.Capacity,
                        KilnName = kd.KilnName,
                        KilnNumber = kd.KilnNumber,
                        LoadRate = kd.LoadRate,
                        Manufacturer = kd.Manufacturer,
                        UnloadRate = kd.UnloadRate
                    });
                }
                ent.SaveChanges();
            }
        }
    }
}
