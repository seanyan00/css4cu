﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BVTC.Service.Common.Utilities;
using BVTC.Service.Data.Models.Portal;
using BVTC.Service.Data.Extensions;
using BVTC.Service.TransferObject.Main;

namespace BVTC.Service.Business.Providers
{
    public static class MessageProvider
    {
        public static BVTCUserDTO Bud;

        public static void SendEmailMessage(string name, string sub, string[] ps, BVTCUserDTO bud)
        {
            Bud = bud;
            
            using (var ent = new MPMPortalEntities()) {
                var im = ent.IMs.Where(x => x.Name == name && x.SubCode == sub && x.Status).Single();

                string msg = string.Format(im.Body, ps);

                var attachment = GetAttachment(im, ps);

                var email = new Email { Body = msg, FromEmail = im.SendFrom,
                                        Subject = im.Subject, ToEmail = im.SendTo,
                                        Attachment = attachment };

                email.SendEmail();

                im.LastSent = DateTime.Now;
                im.Params = string.Join("|", ps);

                ent.SaveChanges();
            }
            
        }
        
        public static string GetAttachment(IM im, string[] ps)
        {
            if (string.IsNullOrEmpty(im.Method))
            {
                if (string.IsNullOrEmpty(im.Attachment))
                    return string.Empty;
                else
                    return im.Attachment;
            }

            return (string)Type.GetType("BVTC.Service.Business.Providers.MessageProvider")
                .GetMethod(im.Method).Invoke(null, new Object[] { ps });
        }

        public static string GetPackList(string[] ps)
        {
            var projno = ps[0];
            var id = ps[1];

            var pro = new PDFProvider(Bud);

            return pro.CreateFile(id, "PackListByBOL", projno);
        }
    }
}
