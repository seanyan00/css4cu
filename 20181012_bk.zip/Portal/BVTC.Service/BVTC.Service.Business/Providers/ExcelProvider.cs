﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using NPOI;
using NPOI.XSSF.UserModel;
using NPOI.SS.UserModel;

using BVTC.Service.Data.Models.Portal;
using BVTC.Service.TransferObject.Portal;
using BVTC.Service.Common.Utilities;
using BVTC.Service.Common;

namespace BVTC.Service.Business.Providers
{
    public static class ExcelProvider
    {
        private static string cname;
        private static int rowid;

        public static void LoadData(string fname, string type, string projno, string uname, int uid = 0)
        {
            cname = "";
            rowid = 0;

            switch(type)
            {
                case "TrackNClip":
                    LoadTC(fname, projno, uname, uid);
                    break;
                default:
                    break;
            }
        }

        private static void LoadTC(string fname, string projno, string uname, int uid = 0)
        {
            IWorkbook wb; 
         
            using (FileStream file = new FileStream(fname, FileMode.Open, FileAccess.Read))
            {
                wb = WorkbookFactory.Create(file);
                ISheet sheet = wb.GetSheetAt(0);

                var datalist = new List<TCBatchImportDTO>();
                var hrow = sheet.GetRow(0);

                try
                {
                    for (int i = 1; i <= sheet.LastRowNum; i++)
                    {
                        rowid = i;

                        var row = sheet.GetRow(i);
                        if (row != null && row.Cells.Count > 0)
                        {
                            var temp = new TCBatchImportDTO();
                            cname = hrow.GetCell(0).StringCellValue;
                            temp.PartNo = row.GetCell(0).StringCellValue;
                            cname = hrow.GetCell(1).StringCellValue;
                            temp.Type = row.GetCell(1).StringCellValue;
                            cname = hrow.GetCell(2).StringCellValue;
                            temp.Qty = SafeGetCellValue<int>(row.GetCell(2));
                            cname = hrow.GetCell(3).StringCellValue;
                            temp.Length = SafeGetCellValue<decimal>(row.GetCell(3));
                            cname = hrow.GetCell(4).StringCellValue;
                            temp.Profile = SafeGetCellValue<string>(row.GetCell(4));
                            cname = hrow.GetCell(5).StringCellValue;
                            temp.FinishCode = SafeGetCellValue<string>(row.GetCell(5));
                            cname = hrow.GetCell(6).StringCellValue;
                            temp.DrawingName = SafeGetCellValue<string>(row.GetCell(6));
                            temp.DocId = 0;
                            temp.DrawingId = 0;

                            if (string.IsNullOrEmpty(temp.FinishCode))
                                temp.FinishCode = "AL";

                            datalist.Add(temp);
                        }
                    }
                }
                catch(Exception ex)
                {
                    throw new Exception(ex.Message + " @Row: " + (++rowid).ToString() + ", Column: " + cname);
                }
                using (var ent = new MPMPortalEntities())
                {
                    using (var trans = ent.Database.BeginTransaction())
                    {
                        try
                        {
                            var docs = ent.Documents.Where(x => x.ProjectNo == projno && (x.Status ?? true)
                                                                && (x.DocType == "ShopDrawing" || x.DocType == "PartDrawing")).ToList();
                            foreach (var data in datalist)
                            {
                                Drawing dw = new Drawing { Id = 0 };
                                
                                // not necessary but as a reference 
                                if (!string.IsNullOrEmpty(data.DrawingName))
                                {
                                    var n1 = Constants.FILEEXT.Contains(data.DrawingName.GetFileExt().ToUpper()) ? data.DrawingName
                                                                                                             : data.DrawingName + ".pdf";
                                    foreach (var d in docs)
                                    {
                                        var n2 = Constants.FILEEXT.Contains(d.Name.GetFileExt().ToUpper()) ? d.Name
                                                                                                           : d.Name + ".pdf";

                                        if (n1.ToUpper() == n2.ToUpper())
                                        {
                                            data.DocId = d.Id;
                                            break;
                                        }
                                    }
                               
                                    if (ent.Drawings.Any(x => x.ProjectNo == projno && x.DrawingNo == data.DrawingName))
                                    {
                                        dw = ent.Drawings.Where(x => x.ProjectNo == projno && x.DrawingNo == data.DrawingName).Single();

                                        if (dw.ShopPDF == 0)
                                        {
                                            dw.ShopPDF = data.DocId;
                                            dw.UpdateDate = DateTime.Now;
                                            dw.UpdatedBy = uname;

                                            ent.SaveChanges();
                                        }
                                    }
                                    else
                                    {
                                        dw = new Drawing
                                        {
                                            DrawingNo = data.DrawingName,
                                            ProjectNo = projno,
                                            Comments = data.Profile,
                                            DrawingType = data.Type,
                                            Status = "DRAWN",
                                            DrawnBy = uid,
                                            ShopPDF = data.DocId,
                                            CreateDate = DateTime.Now,
                                            CreatedBy = uname
                                        };

                                        ent.Drawings.Add(dw);
                                        ent.SaveChanges();
                                    }
                                }
                                                        
                                switch (data.Type)
                                {
                                    case "T":
                                        if (!ent.ClipTracks.Any(x => x.TrackNo == data.PartNo && x.ProjectNo == projno))
                                        {
                                            var ct = new ClipTrack
                                            {
                                                DrawingId = dw.Id,
                                                TrackNo = data.PartNo,
                                                Length = data.Length,
                                                QtyPlanned = data.Qty,
                                                ProfileCode = data.Profile,
                                                CreateDate = DateTime.Now,
                                                CreatedBy = uname,
                                                ProjectNo = projno,
                                                FinishCode = data.FinishCode
                                            };
                                            ent.ClipTracks.Add(ct);
                                        }
                                        else
                                        {
                                            var track = ent.ClipTracks.Where(x => x.TrackNo == data.PartNo && x.ProjectNo == projno).Single();

                                            track.DrawingId = dw.Id;
                                            track.Length = data.Length;
                                            track.QtyPlanned = data.Qty;
                                            track.ProfileCode = data.Profile;
                                            track.FinishCode = data.FinishCode;
                                            track.UpdateDate = DateTime.Now;
                                            track.UpdatedBy = uname;
                                        }
                                        break;
                                    case "C":
                                        if (!ent.ClipParts.Any(x => x.PartNo == data.PartNo))
                                        {
                                            var cp = new ClipPart
                                            {
                                                PartNo = data.PartNo,
                                                Length = data.Length.ToString(),
                                                ProfileCode = data.Profile,
                                                ColorStatus = data.FinishCode,
                                                CreateDate = DateTime.Now,
                                                CreatedBy = uname
                                            };
                                            ent.ClipParts.Add(cp);
                                            ent.SaveChanges();
                                            var pp = new ProjectPart
                                            {
                                                PartId = cp.Id,
                                                ProjectNo = projno,
                                                Qty = data.Qty,
                                                CreateDate = DateTime.Now,
                                                CreatedBy = uname
                                            };
                                            ent.ProjectParts.Add(pp);
                                        }
                                        else
                                        {
                                            var part = ent.ClipParts.Where(x => x.PartNo == data.PartNo).Single();
                                            
                                            if (ent.ProjectParts.Any(x => x.ProjectNo == projno && x.PartId == part.Id))
                                            {
                                                var pp = ent.ProjectParts.Where(x => x.ProjectNo == projno && x.PartId == part.Id).Single();
                                                pp.Qty = data.Qty;
                                            } else
                                            {
                                                var pp = new ProjectPart
                                                {
                                                    PartId = part.Id,
                                                    ProjectNo = projno,
                                                    Qty = data.Qty,
                                                    CreateDate = DateTime.Now,
                                                    CreatedBy = uname
                                                };
                                                ent.ProjectParts.Add(pp);
                                            }
                                        }
                                        break;
                                    default:
                                        break;

                                }
                            }
                            ent.SaveChanges();
                            trans.Commit();
                        }
                        catch(Exception ex)
                        {
                            trans.Rollback();
                            throw;
                        }
                    }

                }
            }
        }

        private static T SafeGetCellValue<T>(ICell cell)
        {
            Type t = typeof(T);

            if (cell != null)
            {
                switch (cell.CellType)
                {
                    case CellType.Boolean:
                        return (T)Convert.ChangeType(cell.BooleanCellValue, t);
                    case CellType.String:
                        return (T)Convert.ChangeType(cell.StringCellValue, t);
                    case CellType.Numeric:
                        return (T)Convert.ChangeType(cell.NumericCellValue, t);
                    default:
                        break;
                }
            }
            return default(T);
        }
    }
}
