﻿using System;
using System.Linq;
using System.Collections.Generic;

using BVTC.Service.Data.Models.Simulator;

namespace BVTC.Service.Business
{
    public class ShiftProvider
    {
        public EstimateProvider EstPro { get; set; }
        private List<KeyValuePair<TimeSpan, TimeSpan>> Breaks = new List<KeyValuePair<TimeSpan, TimeSpan>>
        {
            new KeyValuePair<TimeSpan, TimeSpan>(new TimeSpan(12, 0, 0), new TimeSpan(13, 0, 0)),
            new KeyValuePair<TimeSpan, TimeSpan>(new TimeSpan(23, 0, 0), new TimeSpan(23, 59, 59))
        };

        private List<ShiftInfo> lsi;
        private List<ShiftBreak> lsb;

        public ShiftProvider(EstimateProvider estpro)
        {
            EstPro = estpro;
            var ent = new SimulatorEntities();

            lsi = ent.ShiftInfoes.ToList();
            lsb = ent.ShiftBreaks.ToList();
        }
        public bool CanWork(int currhour)
        {
            //always start on monday
            bool ret = false;

            var si = lsi.Where(x => x.ShiftName == EstPro.ShiftNm).FirstOrDefault();

            int hofd = currhour % 24;
            int d = (int)Math.Ceiling((double)currhour / 24);

            if ((d % 7 == 0 ? 7 : d % 7) <= si.DaysPerWeek)
            {
                if (new TimeSpan(hofd, 0, 0) >= si.DayStart && new TimeSpan(hofd, 0, 0) < si.DayEnd)
                    ret = true;

                if (ret)
                {
                    foreach (var b in lsb.Where(x => x.ShiftName == EstPro.ShiftNm).ToList())
                    {
                        if (new TimeSpan(hofd, 0, 0) >= b.StartAt && new TimeSpan(hofd, 0, 0) < b.EndAt)
                        {
                            ret = false;
                            break;
                        }
                    }
                }
            }

            if (!ret)
            {
                foreach (var tt in EstPro.EstDetails)
                {
                    EstPro.AddNote(EstPro.GetSummaryById(tt.SumId).PPId, "Out of working hour");
                    tt.Action = "None";
                }
            }

            return ret;
        }
        public int GetShiftEnd(string snm = "") 
        {
            // shift will be ended immidately at the dayend time. it's OK for the estimater to consider hours only while evaluating 
            // unloading dryer to kiln process

            int currh = EstPro.GetCurrentHour();

            int ret = 24;
            string shiftname = string.IsNullOrEmpty(snm) ? EstPro.ShiftNm : snm;
            var si = lsi.Where(x => x.ShiftName == shiftname).FirstOrDefault();

            int hofd = currh % 24;

            if (si.DayEnd - si.DayStart <= new TimeSpan(23, 0, 0))
            {
                ret = si.DayEnd.Hours /* * 60*/ - hofd;
            }

            return ret;
        }

    }
}
