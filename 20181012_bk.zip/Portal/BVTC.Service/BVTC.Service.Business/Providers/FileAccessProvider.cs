﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Security.Principal;

using BVTC.Service.Common;
using BVTC.Service.Common.Utilities;
using BVTC.Service.TransferObject.Main;
using BVTC.Service.TransferObject.Portal;
using BVTC.Service.Data.Models.Portal;

namespace BVTC.Service.Business.Providers
{
    public class FileAccessProvider
    {
        public BVTCUserDTO BUD { get; private set; }
        public string ProjectNo { get; set; } 
        private static int FId = 0;

        static FileAccessProvider()
        {
            if (FId + 1000000 >= Int32.MaxValue)
                FId = 0;
        }
        public FileAccessProvider(BVTCUserDTO bud)
        {
            BUD = bud;
            ProjectNo = "";
        }
        public FileAccessProvider(BVTCUserDTO bud, string projno)
        {
            BUD = bud;
            ProjectNo = projno;

            BuildProjDir();
        }
        public string SaveFile(byte[] data, string filename, string type)
        {
            var root = ConfigurationManager.AppSettings[Constants.KEY_FILEROOT].ToString();

            var fn = root + "\\" + type + "\\" + filename;

            using (BinaryWriter fs = new BinaryWriter(new FileStream(fn, FileMode.Create)))
            {
                fs.Write(data);
            }
            return fn;
        }
        public string SaveFile(byte[] data, DocumentDTO ddto)
        {
            var fn = GetFileName(ddto.Name, ddto.ProjectNo, ddto.DocType, ddto.OriginalName);

            using (BinaryWriter fs = new BinaryWriter(new FileStream(fn, FileMode.Create)))
            {
                fs.Write(data);
            }
            return fn;
        }
        public int SaveDoc(DocumentDTO ddto)
        {
            var ret = 0;
            using (var ent = new MPMPortalEntities())
            {
                if(ent.Documents.Any(x => x.Name == ddto.Name && (x.Status ?? true) && x.DocType == ddto.DocType 
                                         && (((x.ProjectNo == null || x.ProjectNo.Length == 0) && (ddto.ProjectNo == null || ddto.ProjectNo.Length == 0))
                                             || (x.ProjectNo == ddto.ProjectNo))))
                {
                    var doc = ent.Documents.Where(x => x.Name == ddto.Name && (x.Status ?? true) && x.DocType == ddto.DocType
                                         && (((x.ProjectNo == null || x.ProjectNo.Length == 0) && (ddto.ProjectNo == null || ddto.ProjectNo.Length == 0))
                                             || (x.ProjectNo == ddto.ProjectNo))).Single();


                    var histname = GetFileName(doc.Name, doc.ProjectNo, doc.DocType, doc.OriginalName, true, doc.DocPath.GetTimeStamp());
                    File.Move(doc.DocPath, histname);

                    ent.DocumentHists.Add(new DocumentHist {
                        Author = doc.Author,
                        CreateDate = DateTime.Now,
                        CreatedBy = BUD.Uname,
                        DateUploaded = doc.DateUploaded,
                        DId = doc.Id,
                        DocPath = histname,
                        DocType = doc.DocType,
                        Name = doc.Name,
                        OriginalName = doc.OriginalName,
                        UploadedBy = doc.UploadedBy
                    });

                    doc.DocPath = ddto.DocPath;
                    doc.DateUploaded = DateTime.Now;
                    doc.UploadedBy = BUD.Uname;
                    doc.UpdateDate = DateTime.Now;
                    doc.UpdatedBy = BUD.Uname;
                    doc.OriginalName = ddto.OriginalName;
                } else
                {
                    ent.Documents.Add(new Document
                    {
                        Author = ddto.Author,
                        CreateDate = DateTime.Now,
                        CreatedBy = BUD.Uname,
                        DateUploaded = DateTime.Now,
                        DocPath = ddto.DocPath,
                        DocType = ddto.DocType,
                        Name = ddto.Name,
                        Notes = ddto.Notes,
                        OriginalName = ddto.OriginalName,
                        ProjectNo = string.IsNullOrEmpty(ddto.ProjectNo) ? string.Empty : ddto.ProjectNo,
                        Status = true,
                        UploadedBy = BUD.Uname
                    });
                }
                ent.SaveChanges();
            }
            return ret;
        }
        public Stream GetFile(string fname)
        {
            return File.OpenRead(fname);
        }
        public Stream GetFile(string fname, string type, string projno)
        {
           // string fn = ConfigurationManager.AppSettings[Constants.KEY_FILEROOT].ToString();
            string fn = GetFileName(fname, projno, type, "");

            return File.OpenRead(fn);
        }
        public Stream GetFile(int id, bool hist = false)
        {
            Document fn;
            if (hist) {
                var fnh = new MPMPortalEntities().DocumentHists.Where(x => x.Id == id).Single();
                fn = new Document {
                    CreateDate = fnh.CreateDate,
                    CreatedBy = fnh.CreatedBy,
                    Id = fnh.DId,
                    Name = fnh.Name,
                    OriginalName = fnh.OriginalName,
                    ProjectNo = "",
                    DocType = fnh.DocType,
                    DocPath = fnh.DocPath
                };
            }
            else
                fn = new MPMPortalEntities().Documents.Where(x => x.Id == id).Single();
            byte b = 0x00;

            MemoryStream ms = new MemoryStream();
            using (var fs = new FileStream(fn.DocPath, FileMode.Open, FileAccess.Read))
            {
                string ext = fn.OriginalName.Substring(fn.OriginalName.LastIndexOf('.') + 1).ToLower();
                b = HttpContentType.GetCode(ext);
                
                ms.WriteByte(b);
                fs.CopyTo(ms);
            }
            ms.Seek(0, SeekOrigin.Begin);
          
            return ms; 
        }
        public void SaveData(byte[] data, string type, string projno)
        {
            //  var root = ConfigurationManager.AppSettings[Constants.KEY_FILEROOT].ToString();

            //  var fn = root + "\\DataImport\\" + (string.IsNullOrEmpty(projno) ? "" : projno + ".") + type + "." + DateTime.Now.ToString("yyyyMMddhhmmss") + "." + BUD.Uname + ".xlsx";
            var fn = GetFileName(type + "_" + BUD.Uname + ".xlsx", projno, type, "");

            using (BinaryWriter fs = new BinaryWriter(new FileStream(fn, FileMode.Create)))
            {
                fs.Write(data);
            }

            ExcelProvider.LoadData(fn, type, projno, BUD.Uname, BUD.UId);
        }
        public void ResetDocDefault(int id)
        {
            using(var ent = new MPMPortalEntities())
            {
                var hist = ent.DocumentHists.Where(x => x.Id == id).Single();
                var doc = ent.Documents.Where(x => x.Id == hist.DId).Single();

                var histname = GetFileName(doc.Name, doc.ProjectNo, doc.DocType, doc.OriginalName, 
                                           true, doc.DocPath.GetTimeStamp());
                var docname = GetFileName(hist.Name, doc.ProjectNo, hist.DocType, hist.OriginalName, 
                                          false, hist.DocPath.GetTimeStamp());

                File.Move(doc.DocPath, histname);
                File.Move(hist.DocPath, docname);

                var tempdoc = new Document
                {
                    Id = doc.Id,
                    Name = doc.Name,
                    DocPath = doc.DocPath,
                    DocType = doc.DocType,
                    DateUploaded = doc.DateUploaded,
                    UploadedBy = doc.UploadedBy,
                    ProjectNo = doc.ProjectNo,
                    OriginalName = doc.OriginalName
                };

                doc.DocPath = docname;
                doc.OriginalName = hist.OriginalName;
                doc.DateUploaded = hist.DateUploaded;
                doc.UploadedBy = hist.UploadedBy;
                doc.UpdateDate = DateTime.Now;
                doc.UpdatedBy = BUD.Uname;

                hist.DocPath = histname;
                hist.OriginalName = tempdoc.OriginalName;
                hist.DateUploaded = tempdoc.DateUploaded;
                hist.UploadedBy = tempdoc.UploadedBy;

                ent.SaveChanges();
            }
        }
        public FileDirDTO GetDirInfo(string path, int pid)
        {
            var root = ConfigurationManager.AppSettings[Constants.KEY_BVTC_UPLOADROOT].ToString();
            var domain = ConfigurationManager.AppSettings[Constants.KEY_AUTH_ADDOMAIN].ToString();
            var uname = ConfigurationManager.AppSettings[Constants.KEY_BVTC_SERVICEUSER].ToString();
            var pwd = ConfigurationManager.AppSettings[Constants.KEY_BVTC_SERVICEUSERPWD].ToString();
         
            AppDomain.CurrentDomain.SetPrincipalPolicy(PrincipalPolicy.WindowsPrincipal);

            Impersonation imper = new Impersonation();

            var fd = new FileDirDTO();
           
            try
            {
                if (imper.ImpersonateUser(domain, uname, pwd))
                {
                    var fname = string.IsNullOrEmpty(path) ? @"\\" + root : path;
                    DirectoryInfo dt = new DirectoryInfo(fname);
            
                    if (string.IsNullOrEmpty(path))
                    {
                        FId = 1;

                        fd.Files.Add(new FileItem
                        {
                            Id = FId,
                            PId = 0,
                            FName = root,
                            LastAccess = "",
                            HasChildren = true,
                            FType = "D",
                            Size = ""
                        });
                    }
                    GetFlatDir(dt, fd.Files, string.IsNullOrEmpty(path) ? FId : pid);
                }
            }
            catch (Exception ex)
            {
               throw;
            }
            finally
            {
                if (imper != null)
                    imper.UndoImpersonation();
            }
           
            return fd; 
        }
        private void GetFlatDir(DirectoryInfo di, List<FileItem> lin, int pid)
        {
            var currd = di.EnumerateDirectories("*");
            var currf = di.EnumerateFiles("*");

            foreach(var cd in currd)
            {
                lin.Add(new FileItem
                {
                    Id = ++FId,
                    PId = pid,
                    FName = cd.FullName,
                    HasChildren = DirHasChildren(cd),
                    FType = "D",
                    LastAccess = cd.LastAccessTime.ToString(),
                    Size = ""

                });
            }
            foreach(var cf in currf)
            {
                lin.Add(new FileItem
                {
                    Id = ++FId,
                    PId = pid,
                    FName = cf.FullName,
                    FType = "F",
                    HasChildren = false,
                    LastAccess = cf.LastAccessTime.ToString(),
                    Size = cf.Length.ToString()
                });
            }
        }
        private void GetFlatDir(DirectoryInfo di, int idin, List<FileItem> lin)
        {
            
            var currd = di.EnumerateDirectories("*");
       
            if (currd == null || currd.Count() == 0)
                return;

            foreach(var cd in currd)
            {
                int pid = ++FId;
                lin.Add(new FileItem
                {
                    Id = pid,
                    PId = idin,
                    FName = cd.FullName,
                    HasChildren = DirHasChildren(cd),
                    FType = "D",
                    LastAccess = cd.LastAccessTime.ToString(),
                    Size = ""
                });

                foreach(var fi in cd.EnumerateFiles("*"))
                {
                    lin.Add(new FileItem
                    {
                        Id = ++FId,
                        PId = pid,
                        FName = fi.FullName,
                        FType = "F",
                        HasChildren = false,
                        LastAccess = fi.LastAccessTime.ToString(),
                        Size = fi.Length.ToString()
                    });
                }
                GetFlatDir(cd, pid, lin);
            }
        }

        private bool DirHasChildren(DirectoryInfo di)
        {
            return di.GetDirectories().Length > 0 || di.GetFiles().Length > 0; 
        }
        public int BulkUpload(BulkUploadDTO buld)
        {
            var froot = ConfigurationManager.AppSettings[Constants.KEY_BVTC_UPLOADROOT].ToString();
            var troot = ConfigurationManager.AppSettings[Constants.KEY_FILEROOT].ToString();
            var domain = ConfigurationManager.AppSettings[Constants.KEY_AUTH_ADDOMAIN].ToString();
            var uname = ConfigurationManager.AppSettings[Constants.KEY_BVTC_SERVICEUSER].ToString();
            var pwd = ConfigurationManager.AppSettings[Constants.KEY_BVTC_SERVICEUSERPWD].ToString();

            AppDomain.CurrentDomain.SetPrincipalPolicy(PrincipalPolicy.WindowsPrincipal);

            Impersonation imper = new Impersonation();
            try
            {
                if (imper.ImpersonateUser(domain, uname, pwd))
                {
                    if(buld.FType == "F")
                    {
                        CopyFile(buld.FName, buld, troot);
                    } else
                    {
                        DirectoryInfo dt = new DirectoryInfo(buld.FName);

                        foreach (var fi in dt.EnumerateFiles(buld.Pattern))
                        {
                            CopyFile(fi.FullName, buld, troot);
                        }
                    }
                }
                else
                    return (int)Error.Failure;
            }
            catch(Exception ex)
            {
                throw;
            }
            finally
            {
                if (imper != null)
                    imper.UndoImpersonation();
            }

            return (int)Error.Success;
        }

        private void CopyFile(string fname, BulkUploadDTO buld, string troot)
        {
            string ofname = fname.GetFileName();

            using (var ent = new MPMPortalEntities())
            {
                // string nfname = troot + @"\" + buld.DocType + @"\" + (!string.IsNullOrEmpty(buld.ProjectNo) ? buld.ProjectNo + "_" : "") + ofname.GetFileNameTimeStamp();

                string nfname = GetFileName(ofname, buld.ProjectNo, buld.DocType, fname);

                File.Copy(fname, nfname);

                var temp = ofname.GetFileNameNoExt();

                if(ent.Documents.Any(x => (x.Name == ofname || x.Name == temp) && x.DocType == buld.DocType 
                                          && ((x.ProjectNo == null && buld.ProjectNo == null) || x.ProjectNo == buld.ProjectNo)))
                {

                    var doc = ent.Documents.Where(x => (x.Name == ofname || x.Name == temp) && x.DocType == buld.DocType
                                          && ((x.ProjectNo == null && buld.ProjectNo == null) || x.ProjectNo == buld.ProjectNo)).First();

                    ofname = doc.DocPath;
                    // string histfname = troot + @"\Hist\" + doc.DocType + @"\" + ofname.GetFileName();

                    string histfname = GetFileName(doc.Name, doc.ProjectNo, doc.DocType, doc.OriginalName, 
                                                   true, doc.DocPath.GetFileName().GetTimeStamp());
                    File.Move(ofname, histfname);

                    ent.DocumentHists.Add(new DocumentHist
                    {
                        DId = doc.Id,
                        Author = doc.Author,
                        DocPath = histfname,
                        DocType = doc.DocType,
                        Name = doc.Name,
                        OriginalName = doc.OriginalName,
                        DateUploaded = doc.DateUploaded,
                        UploadedBy = doc.UploadedBy,
                        CreateDate = DateTime.Now,
                        CreatedBy = BUD.Uname
                    });

                    ent.SaveChanges();

                    doc.DocPath = nfname;
                    doc.OriginalName = fname;
                    doc.UploadedBy = BUD.Uname;
                    doc.DateUploaded = DateTime.Now;
                    doc.UpdateDate = DateTime.Now;
                    doc.UpdatedBy = BUD.Uname;
                } else
                {
                    var ndoc = new Document
                    {
                        Name = ofname,
                        DocPath = nfname,
                        DocType = buld.DocType,
                        ProjectNo = buld.ProjectNo,
                        Author = BUD.Uname,
                        CreateDate = DateTime.Now,
                        CreatedBy = BUD.Uname,
                        Notes = buld.Notes,
                        OriginalName = fname,
                        DateUploaded = DateTime.Now,
                        UploadedBy = BUD.Uname,
                        Status = true
                    };
                    ent.Documents.Add(ndoc);

                    if(buld.DocType == "ShopDrawing" 
                        ||buld.DocType == "PartDrawing")
                    {
                        ent.SaveChanges();

                        var dtype = buld.DocType == "PartDrawing" ? "C" 
                                                                  : (buld.DocType == "ShopDrawing" ? "T" : "A");

                        var ds = ent.Drawings.Where(x => x.ProjectNo == buld.ProjectNo
                                                         && (x.DrawingType == "T" || x.DrawingType == "C")
                                                         && (x.ShopPDF == 0)).ToList();

                        foreach(var d in ds)
                        {
                            if(d.DrawingNo.IsSameName(ndoc.Name) && d.DrawingType == dtype)
                            {
                                d.ShopPDF = ndoc.Id;
                                d.UpdateDate = DateTime.Now;
                                d.UpdatedBy = "BulkUpload-" + BUD.Uname;
                            }
                        }
                    }
                }

                ent.SaveChanges();
            }
        }
        private string GetFileName(string fname, string projno, string ftype, string ofname, bool hist = false, string timestamp = "")
        {
            return FileUtil.GetFileName(fname, projno, ftype, ofname, hist, timestamp);
        }

        private void BuildProjDir()
        {
            if (string.IsNullOrEmpty(ProjectNo))
                return;

            var dtyps = new MPMPortalEntities().DocumentTypes.Where(x => x.CreateDir && x.ProjectRelated).Select(x => x.Code).ToList();

            FileUtil.BuildProjDir(ProjectNo, dtyps);
        }
    }
}
