﻿using System;
using System.Collections.Generic;
using System.Linq;

using BVTC.Service.Data.Models.Simulator;
using BVTC.Service.Common;
using BVTC.Service.Business.TransferObjects;

namespace BVTC.Service.Business
{
    public class CartPoolProvider
    {
        public EstimateProvider EstPro { get; set; }

        public SimulatorEntities Ent { get; set; }

        public CartPoolProvider(EstimateProvider estpro)
        {
            EstPro = estpro;
            Ent = new SimulatorEntities();
        }
        public int GetTotalUsedInPools(string pooltype)
        {
            int pno = GetPoolNumByType(pooltype);

            return Ent.Temp_CartPoolPlan.Where(x => x.PoolNum == pno && x.SessionId == EstPro.SessionId.ToString()).Sum(x => x.Carts)??0;
        }
        public int GetTotalInPoolsToLoad(string pooltype)
        {
            int pno = GetPoolNumByType(pooltype);

            return Ent.Temp_CartPoolPlan.Where(x => x.PId > 0 && x.PoolNum == pno && x.SessionId == EstPro.SessionId.ToString()).Sum(x => x.Carts) ?? 0;
        }
        public List<KilnTotalDTO> GetTotalInPoolsToLoad(List<KilnTotalDTO> ktin, KilnProvider kpro)
        {
            //the total cart returned by this method is large than really allocated becase of partially filling 
            //if carts of a plan is evaluated for different kiln is fine. only one kiln is loaded at onr time
            var ret = new List<KilnTotalDTO>();
            int pno = GetPoolNumByType("DK");
            var cart = Ent.Carts.Where(x => x.CartType == "KC").Single();
            var temppool = new SimulatorEntities().Temp_CartPoolPlan.Where(x => x.PoolNum == pno && x.Panels > 0 && x.SessionId == EstPro.SessionId.ToString())
                .OrderBy(x => x.PId).ToList();

            var idxbase = EstPro.GetCurrentHour(EstPro.CurrPlans.Last().Plan.Id); //last should be good enough
            int currpid = 0;
           // bool sametype = false;

            if (ktin.Count > 0)
            {
                foreach (var kt in ktin)
                {
                    KilnProvider.IncreaseIdx();

                    if (kt.PId == 0)
                    {
                        //judge same type loading in kiln process. in plan order
                        var tsum = new SimulatorEntities().EstimateSummaries.Where(x => x.RunNum == EstPro.RunNo);
                        foreach(var p in temppool.Join(tsum,
                                                       x => x.PId,
                                                       y => y.PPId,
                                                       (x, y) => new {
                                                           PId = x.PId,
                                                           Carts = x.Carts,
                                                           Panels = x.Panels,
                                                           PlanStart = y.PlanStart
                                                       }).OrderBy(z => z.PlanStart).ToList())
                        {
                            if (!ret.Any(x => x.KilnNo == 0 && x.PId == p.PId))
                            {
                                var tempplan = Ent.ProductionPlans.Where(x => x.Id == p.PId).Single();
                                var tempsum = new SimulatorEntities().EstimateSummaries.Where(x => x.RunNum == EstPro.RunNo && x.PPId == p.PId).Single();

                                int ss = (int)Math.Ceiling((double)p.Panels / (double)tempsum.KilnPanelsPerShelf);
                                if (p.PId != currpid)
                                {
                                    if (currpid == 0 || !kpro.IsSameType(currpid, p.PId))
                                        KilnProvider.IncreaseIdx();

                                    currpid = p.PId;
                                }
                                if (kpro.IsSameType(kt.PId, p.PId))
                                {
                                    ret.Add(new KilnTotalDTO
                                    {
                                        Panels = p.Panels ?? 0,
                                        KilnNo = 0, 
                                        PId = p.PId,
                                        Shelevs = ss,
                                        Carts = (int)Math.Ceiling((double)ss / (double)tempsum.KilnShelvesPerCart),
                                        Height = kpro.GetPlanHeight(p.PId),
                                        InLoading = kpro.HasPlanInLoading(p.PId),
                                        LoadIdx = idxbase + KilnProvider.Idx
                                    });
                                }
                            }
                        }
                    }
                    else
                    {
                        foreach (var tp in temppool)
                        {
                            var tempsum = new SimulatorEntities().EstimateSummaries.Where(x => x.RunNum == EstPro.RunNo && x.PPId == tp.PId).Single();
                         
                            if (tp.PId == kt.PId || kpro.IsSameType(kt.PId, tp.PId))
                            {
                                int ss = (int)Math.Ceiling((double)tp.Panels /(double)tempsum.KilnPanelsPerShelf);

                                if (!ret.Any(x => x.Panels == tp.Panels && x.KilnNo == kt.KilnNo && x.PId == tp.PId))
                                {
                                    ret.Add(new KilnTotalDTO
                                    {
                                        Panels = tp.Panels ?? 0,
                                        KilnNo = kt.KilnNo,
                                        PId = tp.PId,
                                        Shelevs = ss,
                                        Carts = (int)Math.Ceiling((double)ss / (double)tempsum.KilnShelvesPerCart),
                                        Height = kpro.GetPlanHeight(tp.PId),
                                        InLoading = kpro.HasPlanInLoading(tp.PId),
                                        LoadIdx = kt.LoadIdx + KilnProvider.Idx
                                    });
                                }
                            }
                        }
                    }
                }
            }

            return ret;
        }
        public bool HasPlanInPool(string type, int pid)
        {
            int pno = GetPoolNumByType(type);

            return new SimulatorEntities().Temp_CartPoolPlan.Any(x => x.PoolNum == pno && x.PId == pid && x.SessionId == EstPro.SessionId.ToString() && x.Carts > 0);
        }
       
        public List<CartPoolDTO> GetPoolToTarget(string pooltype)
        {
            var ret = new List<CartPoolDTO>();

            if (pooltype == "ED")
            {
                ret = Ent.vwCartPoolToDryers
                     .OrderBy(x => x.planstart)
                    .ToList().Select(x => new CartPoolDTO
                    {
                        PoolNo = x.PoolNum,
                        Carts = x.carts,
                        PId = x.PId
                    }).ToList();
            }
            if (pooltype == "DK")
            {
                ret = Ent.vwCartPoolToKilns
                     .OrderBy(x => x.planstart)
                    .ToList().Select(x => new CartPoolDTO
                    {
                        PoolNo = x.PoolNum,
                        Carts = x.carts,
                        PId = x.PId
                    }).ToList();
            }
            return ret;
        }
        public int GetPoolCap(string pooltype)
        {
            var pool = Ent.CartPools.Where(x => x.PoolType == pooltype).Single();

           return pool.Capacity
                    - new SimulatorEntities().Temp_CartPoolPlan.Where(x => x.PId == 0 && x.PoolNum == pool.PoolNum && x.SessionId == EstPro.SessionId.ToString()).Sum(x => x.Carts)??0;
        }
        public List<CartPoolDTO> GetPoolToPush(string type)
        {
            int poolno = GetPoolNumByType(type);

            List<CartPoolDTO> ret = new SimulatorEntities().Temp_CartPoolPlan.Where(x => x.PoolNum == poolno)
                                                .GroupBy(x => new { x.PoolNum, x.PId })
                                                .Select(y => new CartPoolDTO
                    {
                        Carts = y.Sum(x => x.Carts),
                        PId = y.Key.PId,
                        PoolNo = y.Key.PoolNum
                    }).ToList();

             return ret;
        }
        public void AddKEPool(CartPoolDTO cp)
        {
            using (var ent = new SimulatorEntities())
            {
                if (ent.Temp_CartPoolPlan.Any(x => x.PId == cp.PId && x.PoolNum == cp.PoolNo && x.SessionId == EstPro.SessionId.ToString()))
                {
                    var temp = ent.Temp_CartPoolPlan.Where(x => x.PId == cp.PId && x.PoolNum == cp.PoolNo && x.SessionId == EstPro.SessionId.ToString()).Single();
                    temp.Carts = temp.Carts + cp.Carts;
                    temp.UpdateDate = DateTime.Now;

                }
                else
                {
                    var temp1 = new Temp_CartPoolPlan
                    {
                        PoolNum = cp.PoolNo,
                        Carts = cp.Carts,
                        PId = cp.PId,
                        UpdateDate = DateTime.Now,
                        Panels = 0,
                        SessionId = EstPro.SessionId.ToString()
                    };
                    ent.Temp_CartPoolPlan.Add(temp1);
                }

                ent.SaveChanges();
                EstPro.AddNote("Added " + cp.Carts.ToString() + " carts to KEPool");
            }
        }
        public void Add(CartPoolDTO cp)
        {
            int pno = GetPoolNumByType("KE");
            EstimateSummary sum;
            
            using(var ent = new SimulatorEntities())
            {
                if (EstPro.CurrPlans.Any(x => x.Plan.Id == cp.PId && x.Status == Constants.Processing))
                    sum = EstPro.EstSums.Where(x => x.PPId == cp.PId).Single();
                else
                    sum = ent.EstimateSummaries.Where(x => x.RunNum == EstPro.RunNo && x.PPId == cp.PId).Single();

                if (ent.Temp_CartPoolPlan.Any(x => x.PId == cp.PId && x.PoolNum == cp.PoolNo && x.SessionId == EstPro.SessionId.ToString()))
                {
                    var temp = ent.Temp_CartPoolPlan.Where(x => x.PId == cp.PId && x.PoolNum == cp.PoolNo && x.SessionId == EstPro.SessionId.ToString()).Single();
                    temp.Carts = temp.Carts + cp.Carts;
                    temp.UpdateDate = DateTime.Now;
                    if (cp.PoolNo != pno)
                    {
                        temp.Panels += cp.Carts * sum.ShelvesPerCart * sum.PanelsPerShelf;
                    }
                }
                else
                {
                    int panels = 0;
                    if (sum.PPId == cp.PId)
                        panels = cp.PoolNo == pno ? 0 : cp.Carts * sum.ShelvesPerCart * sum.PanelsPerShelf ?? 0;
                    else
                    {
                        if (cp.PoolNo == pno)
                            panels = 0;
                        else
                        {
                            panels = cp.Carts * sum.ShelvesPerCart * sum.PanelsPerShelf ?? 0;
                        }
                    }
                    var temp1 = new Temp_CartPoolPlan
                    {
                        PoolNum = cp.PoolNo,
                        Carts = cp.Carts,
                        PId = cp.PId,
                        UpdateDate = DateTime.Now,
                        Panels = panels,
                        SessionId = EstPro.SessionId.ToString()
                    };
                    ent.Temp_CartPoolPlan.Add(temp1);
                }
            
                ent.SaveChanges();
                EstPro.AddNote(sum.PPId, "Added " + cp.Carts.ToString() + " carts to CartPool");
            }
        }
        public void AddRemove(int carts, int pno, int pid)
        {
            string pat = "EDKED";
            using(var ent = new SimulatorEntities())
            {
                string type = ent.CartPools.Where(x => x.PoolNum == pno).Select(x => x.PoolType).Single();
                type = pat.Substring(pat.LastIndexOf(type) - 1, 2);

                var pool = ent.CartPools.Where(x => x.PoolType == type).Single();
                var temppool = ent.Temp_CartPoolPlan.Where(x => x.PoolNum == pool.PoolNum && x.PId == pid && x.SessionId == EstPro.SessionId.ToString()).ToList();
                int remine = carts;
                foreach(var tp in temppool)
                {
                    if(tp.Carts >= remine)
                    {
                 
                        tp.Carts = tp.Carts - remine;  tp.Panels = (tp.Carts - remine) * EstPro.GetSummary(pid).ShelvesPerCart * EstPro.GetSummary(pid).PanelsPerShelf;
                        remine = 0;
                    }
                    else
                    {
                        remine = remine - tp.Carts??0;
                        tp.Carts = 0;
                        tp.Panels = 0;
                    }
                    if (remine <= 0) break;
                }
                ent.SaveChanges();
            }

        }
        public bool RemoveAdd(int carts, int pno, int pid)
        {
            string pat = "EDKED";
            using (var ent = new SimulatorEntities())
            {
                string type = ent.CartPools.Where(x => x.PoolNum == pno).Select(x => x.PoolType).Single();
                type = pat.Substring(pat.IndexOf(type) + 1, 2);

                var pool = ent.CartPools.Where(x => x.PoolType == type).Single();
                var temppool = ent.Temp_CartPoolPlan.Where(x => x.PoolNum == pool.PoolNum && x.PId == pid && x.SessionId == EstPro.SessionId.ToString()).ToList();
                int remine = carts;
                foreach (var tp in temppool)
                {
                    if (tp.Carts >= remine)
                    {
                        tp.Carts = tp.Carts - remine;
                        tp.Panels = tp.Carts * EstPro.GetSummary(pid).ShelvesPerCart * EstPro.GetSummary(pid).PanelsPerShelf;
                        remine = 0;
                    }
                    else
                    {
                        remine = remine - tp.Carts ?? 0;
                        tp.Carts = 0;
                        tp.Panels = 0;
                    }
                    if (remine <= 0) break;
                }
                ent.SaveChanges();
            }
            return true;
        }
        public void Remove(KilnTotalDTO ktd)
        {
            var pno = GetPoolNumByType("DK");

            using(var ent = new SimulatorEntities())
            {
                var tempsum = ent.EstimateSummaries.Where(x => x.RunNum == EstPro.RunNo && x.PPId == ktd.PId && x.SessionId == EstPro.SessionId.ToString()).Single();

                var cp = ent.Temp_CartPoolPlan.Where(x => x.PoolNum == pno && x.PId == ktd.PId && x.SessionId == EstPro.SessionId.ToString()).Single();

                if (cp.Panels - ktd.Panels <= 0)
                {
                    AddKEPool(new CartPoolDTO {
                        PId = 1,
                        PoolNo = GetPoolNumByType("KE"),
                        Carts = cp.Carts 
                    });
                    ent.Temp_CartPoolPlan.Remove(cp);
                }
                else
                {
                    var temp = new CartPoolDTO{
                        PId = 1,
                        PoolNo =GetPoolNumByType("KE"),
                        Carts = cp.Carts
                    };

                    cp.Panels = cp.Panels - ktd.Panels;
                    cp.Carts = (int)Math.Ceiling((double)Math.Ceiling((double)cp.Panels / (double)tempsum.PanelsPerShelf)
                               / (double)tempsum.ShelvesPerCart);

                    temp.Carts = temp.Carts - cp.Carts;
                    AddKEPool(temp);
                }
                ent.SaveChanges();
            }
        }
        public void Remove(CartPoolDTO cp)
        {
            int remine = cp.Carts??0;
            int pno = GetPoolNumByType("KE");

            using (var ent = new SimulatorEntities())
            {
                var pools = ent.Temp_CartPoolPlan.Where(x => x.Carts > 0 && x.PoolNum == cp.PoolNo && x.SessionId == EstPro.SessionId.ToString()).ToList();

                foreach(var p in pools)
                {
                    var tt = p.Carts;
                    p.Carts = p.Carts > remine ? p.Carts - remine : 0;
                    if (p.PoolNum == pno)
                        p.Panels = 0;
                    else
                        p.Panels = p.Carts * EstPro.GetSummary(cp.PId).ShelvesPerCart * EstPro.GetSummary(cp.PId).PanelsPerShelf;

                    p.UpdateDate = DateTime.Now;

                    remine = tt > remine ? 0 : remine - tt??0;
                    if (remine <= 0) break;
                }
             
                ent.SaveChanges();
                EstPro.AddNote(cp.PId, "Removed " + cp.Carts.ToString() + " carts from CartPool");
            }
        }

        public int Remove(CartPoolDTO cp, int carts, List<CartPoolDTO>pool)
        {
            int remine = carts;  

            using (var ent = new SimulatorEntities())
            {
                if (ent.Temp_CartPoolPlan.Any(x => x.PId == cp.PId && x.SessionId == EstPro.SessionId.ToString()))
                {
                    var temp = ent.Temp_CartPoolPlan.Where(x => x.PId == cp.PId && x.Carts > 0 && x.PoolNum == cp.PoolNo && x.SessionId == EstPro.SessionId.ToString()).ToList();
                    foreach (var t in temp)
                    {
                        if(remine >= t.Carts)
                        {
                            pool.Add(new CartPoolDTO { PId = cp.PId, Carts = t.Carts, PoolNo = t.PoolNum });
                            remine = remine - t.Carts??0;
                            t.Carts = 0;
                            t.Panels = 0;
                        }
                        else
                        {
                            pool.Add(new CartPoolDTO { PId = cp.PId, Carts = remine, PoolNo = t.PoolNum });
                            t.Carts = t.Carts - remine;
                            remine = 0;
                            t.Panels = t.Carts * EstPro.GetSummary(cp.PId).ShelvesPerCart * EstPro.GetSummary(cp.PId).PanelsPerShelf;
                        }
                        
                        t.UpdateDate = DateTime.Now;

                        if (remine <= 0) break;
                    }
                }
                else
                {
                    //shouln't be here
                    var temp = ent.Temp_CartPoolPlan.Where(x => x.PId > 0 && x.PoolNum == cp.PoolNo && x.SessionId == EstPro.SessionId.ToString()).First();
                    temp.Carts = temp.Carts - carts;
                    temp.Panels = temp.Carts * EstPro.GetSummary(cp.PId).ShelvesPerCart * EstPro.GetSummary(cp.PId).PanelsPerShelf;
                    temp.UpdateDate = DateTime.Now;
                    remine = 0;
                }
                ent.SaveChanges();
                EstPro.AddNote(cp.PId, "Loaded " + (carts - remine).ToString() + " carts from CartPool");
            }

            return remine;
        }
        public int GetPoolNumByType(string type)
        {
            return Ent.CartPools.Where(x => x.PoolType == type).Select(x => x.PoolNum).Single();
        }
        public bool IsSameTypeInPool(int pid, int carts, KilnProvider kpro)
        {
            int no = GetPoolNumByType("DK");

            var tempsum = new SimulatorEntities().EstimateSummaries.Where(x => x.RunNum == EstPro.RunNo && x.PPId == pid).Single();

            var tempp = new SimulatorEntities().Temp_CartPoolPlan.Where(x => x.PoolNum == no && x.SessionId == EstPro.SessionId.ToString() && x.Panels > 0).ToList();

            foreach(var tp in tempp)
            {
                if(kpro.IsSameType(pid, tp.PId) && tp.Panels >= carts * tempsum.KilnShelvesPerCart * tempsum.KilnPanelsPerShelf)
                {
                    return true;
                }
            }

            return false;
        }
    }
}
