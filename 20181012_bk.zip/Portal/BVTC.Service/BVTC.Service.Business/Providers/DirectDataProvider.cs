﻿using BVTC.Service.Data.Models.Portal;
using BVTC.Service.TransferObject.Portal;
using BVTC.Service.Data.DAOs;

namespace BVTC.Service.Business.Providers
{
    public class DirectDataProvider
    {
        public void RunSql(CommandDTO cmdd)
        {
            var dao = new SqlExecutorDAO(new MPMPortalEntities());
            dao.Execute(cmdd);
        }
    }
}
