﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;

using BVTC.Service.Data.Models.Simulator;
using BVTC.Service.Business.TransferObjects;

namespace BVTC.Service.Business
{
    public class DryerProvider
    {
        private SimulatorTracing _st; 

        public EstimateProvider EstPro { get; set; }
        public SimulatorEntities Ent { get; set; }

        public string TeamNm { get; set; }
        public int CurrDryer { get; set; }
        public int CurrHour { get; set; }
        
        public DryerProvider(EstimateProvider estpro)
        {
            _st = new SimulatorTracing();
            EstPro = estpro;
            Ent = new SimulatorEntities();
            TeamNm = "";
        }
       
        public void SetTeam (string team, int hour)
        {
            TeamNm = team;
            CurrHour = hour;
        }
        private int GetDryerToLoad()
        {
            int dryerno = 0;

            var tt = Ent.vwDryerToLoads.ToList()
                     .OrderBy(x => x.DryerNumber).OrderByDescending(x => x.aval)
                     .OrderByDescending(x => x.inuse).ToList();

            var run = Ent.EstimateRuns.Where(x => x.RunNum == EstPro.RunNo).Single();

            var tt1 = new List<int>();
            
            foreach(var t in tt)
            {
                if (t.DryerNumber < (run.DryerStart ?? -9999) || t.DryerNumber > (run.DryerEnd ?? 9999))
                    continue;

                tt1.Add(t.DryerNumber);
            }

            foreach(var t in tt1)
            {
                if(StatusManager.CanUse<Dryer>(t, TeamNm))
                {
                   // StatusManager.SetStatus<Dryer>(t, TeamNm);
                    dryerno = t;
                    break;
                }
            }
          
            return dryerno;
        }
        private int GetDryerToUnload()
        {
            int dryerno = 0;
            var tt = Ent.vwDryersToUnloads
                .OrderByDescending(x => x.inunload).Select(y => y.DryerNumber).ToList();

            foreach (var t in tt)
            {
                if (StatusManager.CanUse<Dryer>(t, TeamNm))
                {
                    StatusManager.SetStatus<Dryer>(t, TeamNm);
                    dryerno = t;
                    break;
                }
            }

            return dryerno;
        }
        public bool UnloadDryers()
        {
            bool ret = true;
            var dryerno = GetDryerToUnload();

            if (dryerno > 0)
            {
                var cppro = new CartPoolProvider(EstPro);
             
                var pool = Ent.CartPools.Where(x => x.PoolType == "DK").Single();
                var der = Ent.Dryers.Where(x => x.DryerNumber == dryerno).Single();

                int used = new SimulatorEntities().Temp_CartPoolPlan.Where(x => x.PoolNum == pool.PoolNum && x.SessionId == EstPro.SessionId.ToString()).Sum(x => x.Carts) ?? 0;

                var totalcarts = Ent.Temp_DryerPlan.Where(x => x.DryerNumber == dryerno && x.SessionId == EstPro.SessionId.ToString()).Sum(x => x.Carts);

                if (Math.Min(der.LoadRate, (int)totalcarts) > pool.Capacity - used)
                {
                    _st.Tracing("Unable to unload dryer", EstPro.SessionId.ToString());

                    EstPro.AddNote("DK Pool is full for push");
                    EstPro.AddAction("None");
                    return false;
                }

                _st.Tracing("At " + CurrHour.ToString() + ": Unloading dryer#" + dryerno.ToString() + " by " + TeamNm, EstPro.SessionId.ToString());

                EstPro.AddNote("Unloading dryer#" + dryerno.ToString());
                EstPro.AddAction("Unload Dryer");

                EstPro.SaveActivity(new TeamActivity
                {
                    TeamName = TeamNm,
                    Act = "Unload Dryer",
                    KilnNo = dryerno,
                    PId = 0,
                    SessionId = EstPro.SessionId.ToString()
                });
                var cpdto = cppro.GetPoolToPush("DK");

                using (var ent = new SimulatorEntities())
                {
                    var tempdps = ent.Temp_DryerPlan.Where(x => x.DryerNumber == dryerno && x.SessionId == EstPro.SessionId.ToString()).ToList();
                    //Carts for a dryer in the temp table is calulated in whole 
                    if (totalcarts - der.LoadRate <= 0) //
                    {
                        foreach (var tempdp in tempdps.Where(x => x.Carts > 0)
                                                      .Select(x => new CartPoolDTO
                                                      {
                                                          Carts = x.Carts,
                                                          PId = x.PId,
                                                          PoolNo = pool.PoolNum
                                                      }).ToList())
                        {
                            _st.Tracing("Debug: P#" + tempdp.PId + " added " + tempdp.Carts + " carts. DKPool, T#" + TeamNm, TraceLevel.Verbose, EstPro.SessionId.ToString());
                            cppro.Add(tempdp);

                            SaveActivity(new DryerActivity
                            {
                                DryerNumber = dryerno,
                                Operation = "Unloading",
                                Carts = tempdp.Carts,
                                PId = tempdp.PId,
                                SessionId = EstPro.SessionId.ToString()
                            });
                        }
                        ent.Temp_DryerPlan.RemoveRange(tempdps);
                        //no need to save CartsDried in temp summary table. this table is used for load only
                    }
                    else
                    {
                        //TODO: test to see if tempdp needs to be pulled from db 
                        int remine = der.LoadRate;

                        foreach (var tempdp in tempdps)
                        {
                             int unloaded = tempdp.Carts >= remine ? remine : tempdp.Carts ?? 0;

                            cppro.Add(new CartPoolDTO
                            {
                                PoolNo = pool.PoolNum,
                                PId = tempdp.PId,
                                Carts = unloaded
                            });

                            SaveActivity(new DryerActivity
                            {
                                DryerNumber = dryerno,
                                Operation = "Unloading",
                                Carts = unloaded,
                                PId = tempdp.PId,
                                SessionId = EstPro.SessionId.ToString()
                            });

                            _st.Tracing("Debug: P#" + tempdp.PId + " added " + unloaded + " carts. DKPool, T#" + TeamNm, TraceLevel.Verbose, EstPro.SessionId.ToString());
                            tempdp.Carts = tempdp.Carts >= remine ? tempdp.Carts - remine : 0;
                            tempdp.UpdateDate = DateTime.Now;
                            
                            remine = remine - unloaded;
                            if (remine <= 0) break;
                        }
                    }


                    ent.SaveChanges();
                }
            }
            else
            {
                ret = false;
                EstPro.AddNote("No dryer to unload");
            }

          //  EstPro.CurrCanUnload = ret;
            return ret;
        }
        public bool LoadDryers()
        {
            bool ret = true;
            var dryerno = GetDryerToLoad();

            if(dryerno == 0)
            {
                _st.Tracing("No dryer to load", EstPro.SessionId.ToString());
                EstPro.AddNote("No dryer to load");
                return false;
            }
            var cppro = new CartPoolProvider(EstPro);

            int ttltoload = cppro.GetTotalInPoolsToLoad("ED");

            if (ttltoload == 0)
                return false;
            if ((!EstPro.AllPlanExted() &&  ttltoload < new SimulatorEntities().Dryers
                                         .Where(x => x.DryerNumber == dryerno).Select(x => x.LoadRate).Single()))
            {
                EstPro.AddNote("No enough carts in Pool to load into dryer");
                return false;
            }
            
            if (dryerno > 0)
            {
                StatusManager.SetStatus<Dryer>(dryerno, TeamNm);

                _st.Tracing("At " + CurrHour + ": Loading dryer#" + dryerno.ToString() + " by " + TeamNm, EstPro.SessionId.ToString());

                EstPro.AddNote("Loading dryer#" + dryerno.ToString());
                EstPro.AddAction("Load Dryer");

                EstPro.SaveActivity(new TeamActivity
                {
                    TeamName = TeamNm,
                    Act = "Load Dryer",
                    KilnNo = dryerno,
                    PId = 0,
                    SessionId = EstPro.SessionId.ToString()
                });

                using (var ent = new SimulatorEntities())
                {
                    var tempdps = ent.Temp_DryerPlan.Where(x => x.DryerNumber == dryerno && x.SessionId == EstPro.SessionId.ToString()).ToList();

                    var der = ent.Dryers.Where(x => x.DryerNumber == dryerno).Single();

                    var pools = cppro.GetPoolToTarget("ED"); //local copy
                    var newpool = new List<CartPoolDTO>();

                    int remine = EstPro.AllPlanExted() ? Math.Min(der.LoadRate, pools.Sum(x => x.Carts) ?? 0) : der.LoadRate;
                    foreach (var cp in pools)
                    {
                        remine = cppro.Remove(cp, remine, newpool);
                        SaveActivity(new DryerActivity
                        {
                            DryerNumber = dryerno,
                            Operation = "Loading",
                            Carts = cp.Carts,
                            PId = cp.PId,
                            SessionId = EstPro.SessionId.ToString()
                        });

                        if (remine <= 0)
                            break;
                    }
                    //shouldn't happen
                    if (remine > 0)
                    {
                        EstPro.AddNote(EstPro.GetProcessingPlan(TeamNm).Id, "Error in loading, no enough carts.");
                        return false;
                    }

                    var cps = from a in newpool
                              group a by a.PId into b
                              select new
                              {
                                  PId = b.Key,
                                  carts = b.Sum(a => a.Carts)
                              };
                    if (tempdps.Count() == 0)
                    {
                        foreach (var cp in cps)
                        {
                            var temp = new Temp_DryerPlan
                            {
                                Carts = cp.carts,
                                UpdateDate = DateTime.Now,
                                PId = cp.PId,
                                DryingAt = -1,
                                DryerNumber = dryerno,
                                SessionId = EstPro.SessionId.ToString()
                            };

                            ent.Temp_DryerPlan.Add(temp);
                            var sum = ent.EstimateSummaries.Where(x => x.PPId == cp.PId && x.SessionId == EstPro.SessionId.ToString()).Single();
                            sum.DryersUsed = GetUsed(cp.PId, dryerno);
                        }

                        ent.SaveChanges();
                    }
                    else
                    {
                        foreach (var cp in cps)
                        {
                            if (tempdps.Any(x => x.PId == cp.PId))
                            {
                                var temp = tempdps.Where(x => x.PId == cp.PId).First();
                                temp.Carts = temp.Carts + cp.carts;
                                temp.UpdateDate = DateTime.Now;
                            }
                            else
                            {
                                var temp1 = new Temp_DryerPlan
                                {
                                    Carts = cp.carts,
                                    UpdateDate = DateTime.Now,
                                    PId = cp.PId,
                                    DryingAt = -1,
                                    DryerNumber = dryerno,
                                    SessionId = EstPro.SessionId.ToString()
                                };

                                ent.Temp_DryerPlan.Add(temp1);
                                var sum = ent.EstimateSummaries.Where(x => x.PPId == cp.PId && x.SessionId == EstPro.SessionId.ToString()).Single();
                                sum.DryersUsed = GetUsed(cp.PId, dryerno);
                            }
                        }
                        ent.SaveChanges();
                    }

                    tempdps = ent.Temp_DryerPlan.Where(x => x.DryerNumber == dryerno && x.SessionId == EstPro.SessionId.ToString()).ToList();
                    ttltoload = cppro.GetTotalInPoolsToLoad("ED");

                    var totalcarts = tempdps.Sum(x => x.Carts);

                    foreach (var dp in tempdps)
                    {
                        dp.DryingAt = totalcarts >= der.Capacity 
                                      || (EstPro.AllPlanExted() && ttltoload == 0 && dp.DryingAt == -1) ?
                                     CurrHour : dp.DryingAt;

                        if (dp.DryingAt > 0)
                        {
                            SaveActivity(new DryerActivity
                            {
                                DryerNumber = dp.DryerNumber,
                                Operation = "Drying",
                                Carts = dp.Carts,
                                PId = dp.PId,
                                SessionId = EstPro.SessionId.ToString()
                            });
                            _st.Tracing("Debug: P#" + dp.PId + ", D#" + dp.DryerNumber.ToString() +
                                        " drying " + dp.Carts + " carts by T#" + TeamNm, TraceLevel.Verbose, EstPro.SessionId.ToString());
                        }
                    }
                    ent.SaveChanges();
                }

            }
            else
            {
                ret = false;
                EstPro.AddNote(EstPro.GetProcessingPlan(TeamNm).Id, "No dryer to load");
            }

            return ret;
        }
        public int GetPanelsByWaitTime(int pid, int hrs, KilnProvider kpro)
        {
            //TODO: need predicator to determine the carpool status at dry unloading time. assume can unload 

            var plan = Ent.ProductionPlans.Where(x => x.Id == pid).Single();

            var dcs = new SimulatorEntities().Temp_DryerPlan.Where(x => x.DryingAt > 0 && x.Carts > 0 && x.SessionId == EstPro.SessionId.ToString()).ToList();

            var panels = 0;

            foreach(var dc in dcs)
            {
                var tempplan = Ent.ProductionPlans.Where(x => x.Id == dc.PId).Single();
                if (!kpro.IsSameType(pid, dc.PId))
                    continue;

                var dryer = Ent.Dryers.Where(x => x.DryerNumber == dc.DryerNumber).Single();
                var summ = new SimulatorEntities().EstimateSummaries.Where(x => x.PPId == dc.PId && x.RunNum == EstPro.RunNo && x.SessionId == EstPro.SessionId.ToString()).Single();

                var duetime = dc.DryingAt + tempplan.DryerTime;

                if(duetime + dryer.Capacity / dryer.LoadRate <= hrs)
                {
                    panels += (int)dc.Carts * summ.ShelvesPerCart ?? 0 * summ.PanelsPerShelf ?? 0;
                }

            }
            return panels;
        }
        private string GetUsed(int pid, int dryerno)
        {
           
            var sum = new SimulatorEntities().EstimateSummaries.Where(x => x.PPId == pid && x.SessionId == EstPro.SessionId.ToString()).Single();
            string ret = sum.DryersUsed;

            var temp = "," + (string.IsNullOrEmpty(sum.DryersUsed) ? "" : sum.DryersUsed) + ",";

            if(temp.IndexOf("," + dryerno.ToString() + ",") < 0)
                ret = string.IsNullOrEmpty(sum.DryersUsed)
                                          ? dryerno.ToString()
                                          : sum.DryersUsed + "," + dryerno.ToString();
            return ret;
        }
        private void SaveActivity(DryerActivity da)
        {
            using (var ent = new SimulatorEntities())
            {
                ent.DryerActivities.Add(new DryerActivity{
                    HourAt = CurrHour,
                    Carts = da.Carts,
                    PId = da.PId,
                    CreateDate = DateTime.Now,
                    DryerNumber = da.DryerNumber,
                    Operation = da.Operation,  //drying/firing, loading, unloading, cleaned
                    RunNum = EstPro.RunNo,
                    SessionId = EstPro.SessionId.ToString()
                });

                ent.SaveChanges();
            }
        }
    }
}