﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.Data.Entity;
using System.IO;

using BVTC.Service.Data.Models.Portal;
using BVTC.Service.TransferObject.Portal;
using BVTC.Service.TransferObject.Main;
using BVTC.Service.Common;
using BVTC.Service.Data.Factory;

namespace BVTC.Service.Business.Providers
{
    public class PortalUIProvider
    {
        private const string KEY_APPUSER = "Portal_AppUser";
        private const string KEY_FILEROOT = "Portal_FileDir";

        private static readonly List<ElementAttributeDTO> ViewOnlyAttrs = new List<ElementAttributeDTO> {new ElementAttributeDTO{
                                                                                                  Code = "add", Idx = 1, PName = "navGrid",
                                                                                                  PId = 141, Value = "false"},
                                                                                                new ElementAttributeDTO{
                                                                                                  Code = "edit", Idx = 1, PName = "navGrid",
                                                                                                  PId = 141, Value = "false"},
                                                                                                new ElementAttributeDTO{
                                                                                                  Code = "del", Idx = 1, PName = "navGrid",
                                                                                                  PId = 141, Value = "false"} };

        public BVTCUserDTO BUD;

        private class DicItem
        {
            public int C1 { get; set; }
            public int C2 { get; set; }
        }
        public PortalUIProvider(BVTCUserDTO bud)
        {
            BUD = bud;
        }
        public Dictionary<int, int> GetEleIdsOfUser(string uname)
        {
            var ret = new Dictionary<int, int>();

            using (var ent = new MPMPortalEntities())
            {
                string sql = "select distinct eid, max(permidx) over(partition by eid) perm"
                           + " from"
                           + " (select b.eid, b.permidx from employee a, UIElementgrant b"
                           + "   where b.uid = a.id and b.utype = 'U' and b.status = 1 and a.Status = 1"
                           + "     and a.username = '" + uname + "'"
                           + " union"
                           + " select c.eid, c.permidx from employee a, employeerole b, uielementgrant c"
                           + "  where b.eid = a.id and c.uid = b.rid and c.utype = 'R' and b.status = 1 and a.status = 1"
                           + "    and a.username = '" + uname + "') o1;";
                var set = ent.Database.SqlQuery<DicItem>(sql).ToList();
                foreach(var d in set)
                {
                    ret.Add(d.C1, d.C2);
                }
            }

            return ret;
        }
        public Dictionary<int, int> GetEleIdsOfRoles(string[] role)
        {
            var ret = new Dictionary<int, int>();

            var ent = new MPMPortalEntities();

            foreach (var d in ent.UIElementGrants.Where(x => x.Status && x.UType == "R").ToList())
            {
                if(role.Any(x => x == d.UId))
                {
                    if(!ret.ContainsKey(d.EId))
                        ret.Add(d.EId, d.PermIdx);
                    else
                    {
                        if(d.PermIdx > ret[d.EId])
                            ret[d.EId] = d.PermIdx;
                    }
                }
            }
            return ret;
        }
        public bool NoPerm(int uiid)
        {
            return new MPMPortalEntities().UIElements.Any(x => x.Id == uiid && x.Perm == (int)UIPermission.None);
        }

        public Dictionary<string, string> GetKeyValueListByEntityName(string name, string parent)
        {
            var ent = new MPMPortalEntities();
            var ret = new Dictionary<string, string>();
            var tt = new List<KeyValueHolder>();

            switch (name.ToUpper())
            {
                case "ADDRCITY":
                    var id1 = Convert.ToInt32(parent);
                    var country1 = ent.CountryCities.Where(x => x.Id == id1).Select(x => x.CountryCode).Single();
                    var state = ent.CountryCities.Where(x => x.Id == id1).Select(x => x.RegionCode).Single();
                    tt = ent.CountryCities.Where(x => x.CountryCode == country1 && x.RegionCode == state)
                         .Select(x => new KeyValueHolder { Key = x.Id.ToString(), Value = x.CityName })
                                   .Distinct().OrderBy(x => x.Value).ToList();
                    break;
                  case "ADDRSTATE":
                    var id = Convert.ToInt32(parent);
                    var country = ent.CountryCities.Where(x => x.Id == id).Select(x => x.CountryCode).Single();

                    tt = ent.CountryCities.Where(x => x.CountryCode == country)
                         .Select(x => new KeyValueHolder { Key = x.RegionCode, Value = x.RegionCode + " - " + x.RegionName })
                                   .Distinct().OrderBy(x => x.Value).ToList();
                    break;
                case "BATCHDATATYPE":
                     tt = ent.BatchDataTypes.Select(x => new KeyValueHolder { Key = x.Code, Value = x.Code })
                                   .OrderBy(x => x.Value).ToList();
                    break;
                case "CARRIER":
                    tt = ent.FreightCarriers
                        .Select(x => new KeyValueHolder { Key = x.Id.ToString(), Value = x.Number + " - " + x.Name })
                                   .OrderBy(x => x.Value).ToList();
                    break;
              
                case "CLIPDESCRIPTION":
                    tt = ent.ClipDescriptions.Select(x => new KeyValueHolder { Key = x.Code, Value = x.Code }).OrderBy(x => x.Key).ToList();
                    break;
                case "CLIPPART":
                    tt = ent.ClipParts.Select(x => new KeyValueHolder { Key = x.Id.ToString(), Value = x.PartNo + " -- " + x.Description })
                        .OrderBy(x => x.Value).ToList();
                    break;
                case "CLIPPROFILECODE":
                    tt = ent.ClipProfiles.Select(x => new KeyValueHolder { Key = x.Code, Value = x.Code + " -- " + x.Description })
                        .OrderBy(x => x.Value).ToList();
                    break;
                case "CLIPSTATUS":
                    tt = ent.StatusCodes.Where(x => x.Category == "TC")
                      .Select(x => new KeyValueHolder { Key = x.Code, Value = x.Code })
                      .Distinct().ToList();
                    break;
                case "COUNTRY":
                    tt = new List<KeyValueHolder>();
                    tt.Add(new KeyValueHolder { Key = "CA", Value = "CA - Canada" });
                    tt.Add(new KeyValueHolder { Key = "US", Value = "US - United States" });

                    tt.AddRange(ent.CountryCodes.Where(x => x.Code != "CA" && x.Code != "US")
                        .Select(x => new KeyValueHolder { Key = x.Code, Value = x.Code + " - " + x.Name })
                                   .OrderBy(x => x.Value).ToList());
                    break;
                case "COUNTRYSTATE":
                    tt = ent.CountryCities.Where(x => x.CountryCode == parent)
                         .Select(x => new KeyValueHolder { Key = x.RegionCode, Value = x.RegionCode + " - " + x.RegionName })
                                   .Distinct().OrderBy(x => x.Value).ToList();
                    break;
               case "DEPARTMENT":
                    tt = ent.Departments
                        .Select(x => new KeyValueHolder { Key = x.Code, Value = x.Code + " - " + x.Name })
                                   .OrderBy(x => x.Value).ToList();
                    break;
                case "DOCUMENTTYPE":
                    tt = ent.DocumentTypes.Where(x => (x.SelectList)).Select(x => new KeyValueHolder
                    {
                        Key = x.Code,
                        Value = x.Code
                    }).ToList();
                    break;
                case "DRAFTINGUSER":
                    tt = ent.Employees.Where(x => x.Status && x.DeptCode.Contains("DFT"))
                        .Select(x => new KeyValueHolder { Key = x.Id.ToString(), Value = x.FirstName + " " + x.LastName })
                                   .OrderBy(x => x.Value).ToList();
                    break;
                case "DRAWINGTYPE":
                    tt = ent.DrawingTypes.Select(x => new KeyValueHolder { Key = x.Code, Value = x.Code + " - " + x.Description })
                                   .OrderByDescending(x => x.Value).ToList();
                    break;
              
                case "EMPLOYEE":
                    tt = ent.Employees.Where(x => x.Status)
                        .Select(x => new KeyValueHolder { Key = x.Id.ToString(), Value = x.FirstName + " " + x.LastName })
                                   .OrderBy(x => x.Value).ToList();
                    break;
                case "FINISHCODE":
                    tt = ent.ClipColors
                        .Select(x => new KeyValueHolder { Key = x.Abbr, Value = x.Abbr + " - " + x.Code })
                                   .OrderBy(x => x.Value).ToList();
                    break;
                case "INVENTORY":
                    tt = ent.Inventories.Where(x => x.Status)
                        .Select(x => new KeyValueHolder { Key = x.Id.ToString(), Value = x.InvName }).ToList();
                    break;
                case "PACKCRATE":
                    var bolmid = Convert.ToInt32(parent);
                    tt = ent.vwPackAvailableToBOLs.Where(x => x.BOLMId == bolmid).Select(x => new KeyValueHolder { Key = x.PackId.ToString(),
                        Value = "#" + x.CrateNo.ToString() + " - " + x.TtlBlocks.ToString() + " blks"}).Distinct().ToList();
                    break;
                case "PACKSTATUS":
                    tt = ent.StatusCodes.Where(x => x.Category == "Package")
                      .Select(x => new KeyValueHolder { Key = x.Code, Value = x.Code })
                      .Distinct().ToList();
                    break;
                case "PARTDRAWING":
                    tt = ent.Drawings.Where(x => x.DrawingType == "C")
                       .Select(x => new KeyValueHolder { Key = x.Id.ToString(), Value = x.DrawingNo })
                       .OrderBy(x => x.Value).ToList();
                    break;
                case "PARTDRAWINGFILE":
                    tt = ent.Documents.Where(x => x.DocType == "PartDrawing" && (x.Status ?? true))
                         .Select(x => new KeyValueHolder { Key = x.Id.ToString(), Value = x.Name })
                         .ToList();
                    break;
                case "PAYMENTTERM":
                    tt = ent.Terms.Where(x => x.Category == "Payment")
                        .Select(x => new KeyValueHolder { Key = x.Code, Value = x.Code + " - " + x.Description })
                                   .OrderBy(x => x.Value).ToList();
                    break;
                case "POCATEGORY":
                    tt = ent.CategoryCodes.Where(x => x.Category == "PO")
                      .Select(x => new KeyValueHolder { Key = x.Code, Value = x.Code })
                      .Distinct().ToList();
                    break;
                case "POSTATUS":
                    tt = ent.StatusCodes.Where(x => x.Category == "PO")
                      .Select(x => new KeyValueHolder { Key = x.Code, Value = x.Code })
                      .Distinct().ToList();
                    break;
                case "PROJECT":
                    tt = ent.ProjectHeaders.Select(x => new KeyValueHolder { Key = x.ProjectNo, Value = x.ProjectNo + " - " + x.ShortDesc })
                        .Distinct().OrderByDescending(x => x.Value).ToList();
                    break;
                case "PROJECTINPROGRESS":
                    tt = ent.ProjectHeaders.Where(x => x.Status == "IN PROGRESS").Select(x => new KeyValueHolder { Key = x.ProjectNo, Value = x.ProjectNo + " - " + x.ShortDesc })
                        .OrderByDescending(x => x.Value).ToList();
                    break;
                case "PROJECTDRAWING":
                    tt = ent.Drawings.Where(x => x.ProjectNo == parent)
                        .Select(x => new KeyValueHolder { Key = x.Id.ToString(), Value = x.DrawingNo })
                        .Distinct().ToList();
                    break;
                case "PROJECTDRAWINGPDF":
                    tt = ent.Documents.Where(x => x.ProjectNo == parent && x.DocType == "ShopDrawing" && (x.Status ?? true))
                        .Select(x => new KeyValueHolder { Key = x.Id.ToString(), Value = x.Name})
                        .ToList();
                    break;
                case "PROJECTPHOTO":
                    tt = ent.Documents.Where(x => x.ProjectNo == parent && x.DocType == "CratePhoto" && (x.Status ?? true))
                        .Select(x => new KeyValueHolder { Key = x.Id.ToString(), Value = x.Name })
                        .ToList();
                    break;
                case "PROJECTPRIORITY":
                    if (!string.IsNullOrEmpty(parent))
                        tt = ent.ProjectDetails.Where(x => x.ProjectNo == parent)
                         .Select(x => new KeyValueHolder { Key = x.Id.ToString(), Value = x.Priority })
                         .Distinct().ToList();
                
                    tt = tt.OrderByDescending(x => x.Key).ToList();
                    break;
                 case "PROJECTQUOTELINE":
                    tt = (from a in ent.ProjectHeaders
                          join b in ent.QuoteLines on a.QuoteId equals b.QHId
                          where a.ProjectNo == parent
                          select new KeyValueHolder { Key = b.Id.ToString(), Value = b.CategoryCode })
                         .ToList();
                    break;
                case "PROJECTSTATUS":
                    tt = ent.StatusCodes.Where(x => x.Category == "Project")
                      .Select(x => new KeyValueHolder { Key = x.Code, Value = x.Code })
                      .Distinct().ToList();
                    break;
                case "PROJECTTCTRACK":
                    tt = ent.ClipTracks.Where(x => x.ProjectNo == parent)
                        .Select(x => new KeyValueHolder { Key = x.Id.ToString(), Value = x.TrackNo + " - " + x.Length.ToString()}).ToList();
                    break;
                case "PROJECTTCPART":
                    tt = ent.vwProjectTCParts.Where(x => x.ProjectNo == parent)
                        .Select(x => new KeyValueHolder { Key = x.PartId.ToString(), Value = x.PartNo + " - " + x.Description })
                        .OrderBy(x => x.Value).ToList();
                    break;
                case "REASONCODE":
                    tt = ent.ReasonCodes
                        .Select(x => new KeyValueHolder { Key = x.Code, Value = x.Code + " - " + x.Description })
                                   .OrderBy(x => x.Value).ToList();

                    break;
                case "REASONCODESHIPHOLD":
                    tt = ent.ReasonCodes.Where(x => x.Category == "ShipHold")
                        .Select(x => new KeyValueHolder { Key = x.Description, Value = x.Description })
                                   .OrderBy(x => x.Value).ToList();

                    break;
                case "RECENTPROJECT":
                    string uname = BUD.Uname;
                    tt = ent.vwRecentProjects.Where(x => x.UserName == uname)
                        .OrderByDescending(x => x.CreateDate).Select(x => new KeyValueHolder
                        {
                            Key = x.ProjectNo, Value = x.ProjectNo + " - " + x.ShortDesc
                        }).Take(20).ToList();

                    break;
                case "SHIPMENT":
                    tt = ent.ShipmentMasters.Where(x => x.ProjectNo == parent)
                      .Select(x => new KeyValueHolder { Key = x.Id.ToString(), Value = x.Name })
                      .Distinct().ToList();
                    break;
              
               case "SHIPSTATUS":
                    tt = ent.StatusCodes.Where(x => x.Category == "Shipment")
                      .Select(x => new KeyValueHolder { Key = x.Code, Value = x.Code })
                      .Distinct().ToList();
                    break;
                case "SHIPHOLDREASON":
                    tt = ent.ReasonCodes.Where(x => x.Category == "ShipHold")
                      .Select(x => new KeyValueHolder { Key = x.Code, Value = x.Code + " - " + x.Description })
                      .Distinct().ToList();
                    break;
                case "SHIPPINGUSER":
                    tt = ent.Employees.Where(x => x.Status && x.DeptCode.Contains("SHP"))
                        .Select(x => new KeyValueHolder { Key = x.Id.ToString(), Value = x.FirstName + " " + x.LastName })
                                   .OrderBy(x => x.Value).ToList();
                    break;
                case "SHIPPRIORITY":
                    tt = ent.vwShipments
                      .Select(x => new KeyValueHolder { Key = x.Id.ToString(), Value = x.ProjectNo })
                      .Distinct().ToList();
                    break;
               
                case "SITECATEGORY":
                    tt = ent.SiteCategories.Where(x => x.Status)
                         .Select(x => new KeyValueHolder { Key = x.Code, Value = x.Code }).OrderBy(x => x.Key).ToList();
                    break;
                case "STATECITY":
                    if (!string.IsNullOrEmpty(parent))
                    { 
                        var scode = parent.Substring(0, parent.IndexOf('-'));
                        var ccode = parent.Substring(parent.IndexOf('-') + 1);
                        tt = ent.CountryCities.Where(x => x.RegionCode == scode
                                                      && x.CountryCode == ccode)
                        .Select(x => new KeyValueHolder { Key = x.Id.ToString(), Value = x.CityName })
                                  .OrderBy(x => x.Value).ToList();
                    }
                    break;
               case "SUBMITTALSTATUS":
                    tt = ent.StatusCodes.Where(x => x.Category == "Submittal")
                      .Select(x => new KeyValueHolder { Key = x.Code, Value = x.Code })
                      .Distinct().ToList();
                    break;
                case "TCPROFILECODE":
                    tt = ent.ClipProfiles.Select(x => new KeyValueHolder { Key = x.Code, Value = x.Code + " - " + x.Description })
                                   .OrderBy(x => x.Value).ToList();
                    break;
                case "VENDORCODE":
                    tt = ent.Vendors.Select(x => new KeyValueHolder { Key = x.Id.ToString(), Value = x.VendorCode + " - " + x.Name })
                        .OrderBy(x => x.Value).ToList();
                    break;
                
                default:
                    break;
            }
            foreach (var t in tt)
            {
                ret.Add(t.Key, t.Value);
            }
            return ret;
        }
        public int SaveDataRecord(ElementDataDTO edd)
        {
            return EntityHelperFactory.SaveDTO(new MPMPortalEntities(), edd, BUD);
        }
        public int GetUIIdByUIName(string name)
        {
            return new MPMPortalEntities().UIElements.Where(x => x.Name == name && (x.Status ?? true)).Select(x => x.Id).Single();
        }
        public UIElement GetUIByUIName(string name)
        {
            return new MPMPortalEntities().UIElements.Where(x => x.Name == name && (x.Status ?? true)).Single();
        }
        public UIElement GetUIEleByUIName(string name)
        {
            return new MPMPortalEntities().UIElements.Where(x => x.Name == name && (x.Status ?? true)).Single();
        }
        public ElementDataDTO GetDataSourceByUIID(ElementRequestDTO erd)
        {
            var obj = new MPMPortalEntities().UIElements.Where(x => x.Id == erd.Id).Single();
            erd.Name = obj.DataTarget;

            if (!string.IsNullOrEmpty(obj.Sort) && obj.Sort.Length > 0)
            {
                erd.Sorts.Clear();
                var hm = obj.Sort.Split(';');

                for(int i = 0; i < hm.Length; i++)
                {
                    var ss = hm[i].Split(':');
                    erd.Sorts.Add( new Sort { ColName = ss[0], Asc = Convert.ToBoolean(ss[1]) });
                }
                return GetDataSourceByDataTarget(erd);
            }

            

            return GetDataSourceByDataTarget(erd);
        }
       
        public ElementDataDTO GetDataSourceByDataTarget(ElementRequestDTO erd)
        {
            return EntityHelperFactory.GetDTO(new MPMPortalEntities(), erd, BUD);
        }
        public ElementDataDTO GetDataSourceByCols(ElementRequestDTO erd)
        {
            return EntityHelperFactory.GetDTO(new MPMPortalEntities(), erd, BUD);
        }
        public UIElementDTO GetElementById(int uiid, bool viewonly = false)
        {
            var ent = new MPMPortalEntities();

            var ret = ent.UIElements.Where(x => (x.Status ?? true) && x.Id == uiid)
                      .Select(x => new UIElementDTO
                      {
                          ContainerId = x.ContainerId ?? 0,
                          Controller = x.Controller,
                          CreateDate = x.CreateDate,
                          CreatedBy = x.CreatedBy,
                          DataTarget = x.DataTarget,
                          Description = x.Description,
                          EleType = x.UIType,
                          Id = x.Id,
                          Name = x.Name,
                          ParentId = x.ParentId ?? 0,
                          Perm = x.Perm ?? (int)UIPermission.None,
                          Status = x.Status ?? true,
                          SubCode = x.SubCode,
                          UpdateDate = x.UpdateDate ?? DateTime.MinValue,
                          UpdatedBy = x.UpdatedBy
                      }).SingleOrDefault();

            ret.Attrs = ent.UIElementAttributes.Where(x => x.EId == ret.Id && x.Status)
                      .Select(x => new ElementAttributeDTO
                      {
                          DefaultValue = x.UIElementAttributeCode.DefaultValue,
                          Id = x.UIElementAttributeCode.Id,
                          Idx = x.Idx,
                          PId = x.UIElementAttributeCode.ParentId ?? 0,
                          ValueType = x.UIElementAttributeCode.ValueType,
                          Value = x.AttrValue,
                          ValueFrom = x.UIElementAttributeCode.ValueFrom,
                          ValueTo = x.UIElementAttributeCode.ValueTo,
                          DBName = x.UIElementAttributeCode.DBName,
                          Code = x.UIElementAttributeCode.Code,
                          PName = x.UIElementAttributeCode.UIElementAttributeCode2.Code, //uielementattributecode1.code
                          CreateDate = x.CreateDate,
                          CreatedBy = x.CreatedBy,
                          UpdateDate = x.UpdateDate ?? DateTime.MinValue,
                          UpdatedBy = x.UpdatedBy
                      }).ToArray();
             if(viewonly)
             {
                var temp = ret.Attrs.ToList();
                temp.AddRange(ViewOnlyAttrs);
                ret.Attrs = temp.ToArray();
             }           
             return ret;
        }
        public int GetUIdByUName(string uname)
        {
            return new MPMPortalEntities().Employees.Where(x => x.UserName == uname).Select(x => x.Id).Single();
        }
        public UIElementDTO[] GetElementsOfPage(string uname, string pname)
        {
            var allperms = GetEleIdsOfUser(uname);

            var ent = new MPMPortalEntities();

            int pid = ent.UIElements.Where(x => x.Name == pname && x.Status == true).Select(x => x.Id).SingleOrDefault();

            var ret = ent.UIElements.Where(x => x.ParentId == pid && x.Status == true && allperms.Any(y => y.Key == x.Id && y.Value >= x.Perm))
                      .Select(x => new UIElementDTO {
                          CreateDate = x.CreateDate,
                          CreatedBy = x.CreatedBy,
                          Attrs = x.UIElementAttributes.Where(y => y.Status).Select(y => new ElementAttributeDTO {
                                      DefaultValue = y.UIElementAttributeCode.DefaultValue,
                                      Id = y.UIElementAttributeCode.Id,
                                      Idx = y.Idx,
                                      PId = y.UIElementAttributeCode.ParentId ?? 0,
                                      ValueType = y.UIElementAttributeCode.ValueType,
                                      Value = y.AttrValue,
                                      ValueFrom = y.UIElementAttributeCode.ValueFrom,
                                      ValueTo = y.UIElementAttributeCode.ValueTo,
                                      DBName = y.UIElementAttributeCode.DBName,
                                      Code = y.UIElementAttributeCode.Code,
                                      PName = y.UIElementAttributeCode.UIElementAttributeCode2.Code, //uielementattributecode1.code
                                      CreateDate = y.CreateDate,
                                      CreatedBy = y.CreatedBy,
                                      UpdateDate = y.UpdateDate ?? DateTime.MinValue,
                                      UpdatedBy = y.UpdatedBy
                                 }).ToArray(),          
                          ContainerId = x.ContainerId ?? 0,
                          Controller = x.Controller,
                          DataTarget = x.DataTarget,
                          Description = x.Description,
                          Id = x.Id,
                          Name = x.Name,
                          ParentId = x.ParentId ?? 0,
                          Perm = x.Perm ?? (int)UIPermission.None,
                          Status = x.Status ?? false,
                          SubCode = x.SubCode,
                          EleType = x.UIType,
                          UpdateDate = x.UpdateDate ?? DateTime.MinValue,
                          UpdatedBy = x.UpdatedBy
                }).ToArray();

            return ret;
        }
        public static string GetAppUser()
        {
            return ConfigurationManager.AppSettings[KEY_APPUSER].ToString();
        }
        public string SaveFile(byte[] content, string filename, string type)
        {
            var root = ConfigurationManager.AppSettings[KEY_FILEROOT].ToString();

            var fn = root + "\\" + type + "\\" + filename;

            using (BinaryWriter writer = new BinaryWriter(File.Open(fn, FileMode.Create)))
            {
                writer.Write(content);
            }
            return fn;
        }
        public bool IsViewOnlyUI(int id)
        {
            bool edit = false;
            using (var ent = new MPMPortalEntities())
            {
                var set = (from a in ent.UIElements
                           join b in ent.UIElementGrants on a.Id equals b.EId
                           where a.Id == id
                           select new
                           {
                               Dept = b.UId,
                               Perm = b.PermIdx,
                               GPerm = a.Perm
                           }
                    ).ToList();

              
                foreach (var v in set)
                { 
                    edit = v.GPerm >= (int)UIPermission.View && BUD.Roles.ToList().Contains(v.Dept) && v.Perm > v.GPerm;
                    if (edit)
                        break;

                    edit = ent.DepartmentManagers.Any(x => x.EId == BUD.UId && x.DeptCode == v.Dept && x.Status);
                    if (edit)
                       break;
                }
            }

            return !edit;
        }
        public bool IsGridEditAllowedToUser(string gname)
        {
            // this method doesn't consider grid perm. only used in power user's selection
            var ret = false;
            using (var ent = new MPMPortalEntities())
            {
                var set = (from a in ent.UIElements 
                           join b in ent.UIElementGrants on a.Id equals b.EId
                           where a.Name == gname
                           select new
                           {
                               Dept = b.UId,
                               Perm = b.PermIdx
                           }
                    ).ToList();

                foreach (var v in set.Where(x => x.Perm > (int)UIPermission.View))
                {
                    if (ent.DepartmentManagers.Any(x => x.EId == BUD.UId && x.DeptCode == v.Dept && x.Status))
                    {
                        ret = true;
                        break;
                    }
                }
            }

            return ret;
        }
    }
}
