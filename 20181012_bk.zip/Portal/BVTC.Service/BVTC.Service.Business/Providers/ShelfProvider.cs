﻿using System;
using System.Linq;

using BVTC.Service.Data.Models.Simulator;

namespace BVTC.Service.Business
{
    public class ShelfProvider
    {
        public EstimateProvider EstPro { get; set; }
        public SimulatorEntities Ent { get; set; }

        public ShelfProvider(EstimateProvider estpro)
        {
            EstPro = estpro;
            Ent = new SimulatorEntities();
        }
        public int GetShelfTotal(int pid)
        {
            string snm = GetShelfName(pid);
            return Ent.Shelves.Where(x => x.ShelfName == snm)
                                 .Select(x => x.ShelfTotal).SingleOrDefault();
        }
        public int GetUsedShelves(int pid)
        {
            string snm = GetShelfName(pid);
            return new SimulatorEntities().Temp_ShelfPlan.Where(x => x.ShelfName == snm && x.SessionId == EstPro.SessionId.ToString()).Sum(x => x.Used);
        }
        public void Add(int used, int pid)
        {
            //leave the capacity check to caller
            using (var ent = new SimulatorEntities())
            {
                string sn = GetShelfName(pid);

                if(ent.Temp_ShelfPlan.Any(x => x.ShelfName == sn && x.PId == pid && x.SessionId == EstPro.SessionId.ToString()))
                {
                    var temp1 = ent.Temp_ShelfPlan.Where(x => x.ShelfName == sn && x.PId == pid && x.SessionId == EstPro.SessionId.ToString())
                        .Single();
                    temp1.Used = temp1.Used + used;
                }
                else
                {
                   var temp = new Temp_ShelfPlan{
                     PId = pid,
                     ShelfName = sn,
                     Used = used,
                     UpdateDate = DateTime.Now,
                     SessionId = EstPro.SessionId.ToString()
                   };

                    ent.Temp_ShelfPlan.Add(temp);
                }
                ent.SaveChanges();
            }
        }
       
        public int Free(int amt, int pid)
        {
            int remine = 0;
            using (var ent = new SimulatorEntities())
            {
                string sn = GetShelfName(pid);
                
                var temp = ent.Temp_ShelfPlan.Where(x => x.ShelfName == sn && x.PId == pid && x.SessionId == EstPro.SessionId.ToString())
                        .Single();
                remine = temp.Used > amt ? 0 : amt - temp.Used;
                temp.Used = temp.Used > amt ? temp.Used - amt : 0;

                ent.SaveChanges();
            }
            return remine;
        }
        public string GetShelfName(int pid)
        {
            string mnm;
            string extnm;

            if (EstPro.CurrPlans.Any(x => x.Plan.Id == pid && x.Status == Common.Constants.Processing))
                extnm = EstPro.GetSummary(pid).ExtruderName;
            else
            {
                extnm = new SimulatorEntities().EstimateSummaries.Where(x => x.PPId == pid && x.SessionId == EstPro.SessionId.ToString())
                                             .Select(x => x.ExtruderName).SingleOrDefault();

            }
            mnm = Ent.Extruders.Where(x => x.ExtruderName == extnm)
                                    .Select(x => x.Manufacturer).SingleOrDefault();
            return Ent.Shelves.Where(x => x.Manufacturer == mnm && x.ShelfType == "DS").Select(x => x.ShelfName).SingleOrDefault();
        }
    }
}
