﻿using BVTC.Service.Data.Models.Simulator;

namespace BVTC.Service.Business.TransferObjects
{
    public class CartPoolDTO
    {
        public int PoolNo { get; set; }
        public int? Carts { get; set; }
        public int PId { get; set; }
        public int Panels { get; set; }
    }
    public class KilnTotalDTO
    {
        public int KilnNo { get; set; }
        public int PId { get; set; }
        public int Carts { get; set; }
        public int Shelevs { get; set; }
        public int Panels { get; set; }
        public int Height { get; set; }
        public int LoadIdx { get; set; }
        public bool InLoading { get; set; }
    }
    public class DryerStatus
    {
        public int DryerNo { get; set; }
        public bool InUse { get; set; }
        public string UsedBy { get; set; }
    }
    public class KilnStatus
    {
        public int KilnNo { get; set; }
        public bool InUse { get; set; }
        public string UsedBy { get; set; }
    }
    public class PlanStatus
    {
        public ProductionPlan Plan { get; set; }
        public string Team { get; set; }
        public string Status { get; set; } //Processing, Extruded, Dried, Fired
        public string ExtName { get; set; }
    }
}
