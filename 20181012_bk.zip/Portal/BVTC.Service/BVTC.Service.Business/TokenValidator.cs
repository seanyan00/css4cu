﻿using System;
using System.Linq;
using System.Data;
using System.Configuration;

using BVTC.Service.TransferObject.Main;
using BVTC.Service.Data.Models.Portal;
using BVTC.Service.Common;
using BVTC.Service.Common.Utilities;

namespace BVTC.Service.Business
{
    public static class TokenValidator
    {
        public static bool IsValidToken(BVTCUserDTO bud)
        {
            bool ret = false;
            int tw = Convert.ToInt32(ConfigurationManager.AppSettings[Constants.KEY_TOKENWINDOW].ToString());
            using (var ent = new MPMPortalEntities())
            {
                var temp = ent.SessionTokens.Where(x => x.UserName == bud.Uname
                                                        && x.Token == bud.Token
                                                        && x.LoginStatus == (int)LoginStatus.Active).SingleOrDefault();

                if(temp != null)
                {
                    if (temp.LastAccess == null || DateTimeHelper.IsDifferent(temp.LastAccess, DateTime.MaxValue) == 0
                                               || temp.LastAccess.AddMinutes((double)tw) > DateTime.Now)
                    {
                        ret = true;
                    }   else
                    {
                        temp.LoginStatus = (int)LoginStatus.IdleTooLong;
                    }

                    temp.LastAccess = DateTime.Now;
                    ent.SaveChanges();
                }
            }
            return ret;
        }
    }
}
