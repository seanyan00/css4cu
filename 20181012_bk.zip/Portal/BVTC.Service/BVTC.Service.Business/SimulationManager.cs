﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Configuration;
using Microsoft.VisualBasic.FileIO;

using BVTC.Service.Data.Models.Simulator;
using BVTC.Service.Business.TransferObjects;
using BVTC.Service.Common;
using BVTC.Service.Common.Utilities;

namespace BVTC.Service.Business
{
    public class SimulationManager
    {
        //TODO: change "Entities" to other name 
        private const string KEY_PRODUCTIONPLAN = "Ext_ProductionPlanFile";
        private const string KEY_RUNSETUP = "Ext_RunSetUpFile";
        private const string KEY_TABLESTOTRUNCATE = "Ext_TablesToTruncate";
        private const string KEY_EMPTYRUNTABLE = "Ext_EmptyRunTable";
        private const string KEY_LOADPLAN = "Ext_LoadPlan";
        private const string KEY_LOADRUN = "Ext_LoadRun";
        private const string KEY_RESULTFILE = "Ext_ResultFile";

        public EstimateProvider EstPro { get; set; }

        private int CurrHour;

        private SimulatorTracing _st = new SimulatorTracing();

        private DryerProvider dryerprovider;
        private ExtruderProvider extprovider;
        private ShiftProvider shiftprovider;
        private KilnProvider kilnprovider;

        public Dictionary<int, string> Teams { get; set; }

        public void Setup(Guid sid, int runno = 0)
        {
            int tr = GetRunNo(runno);

            ClearRunTables(tr);
            LoadPlanFromFile();
            LoadRunFromFile();

            EstPro = new EstimateProvider(tr, sid);
            _st.Tracing("Entering Setup...", EstPro.SessionId.ToString());

            InitInstance();

            SetupCartPool();
            SetupShelf();
        }
        private int GetRunNo(int runno)
        {
            return runno == 0 ? new SimulatorEntities().EstimateRuns.Max(x => x.RunNum) : runno;
        }
        private void RunNoOK(ref int runno)
        {//no need for dropdownlist
            int temp = runno;
            while (true)
            {
                if (temp == 0 || new SimulatorEntities().EstimateRuns.Any(x => x.RunNum == temp))
                {
                    runno = temp;
                    break;
                }
                Console.Write("No Setup found, try again: ");
                string s = Console.ReadLine();
                if (!int.TryParse(s, out temp))
                {
                    temp = 0;
                }
            }
        }
        private void InitInstance()
        {
            dryerprovider = new DryerProvider(EstPro);
            extprovider = new ExtruderProvider(EstPro);
            shiftprovider = new ShiftProvider(EstPro);
            kilnprovider = new KilnProvider(EstPro);
         
            Teams = new Dictionary<int, string>();
          
            CurrHour = 0;

            var erun = new SimulatorEntities().EstimateRuns.Where(x => x.RunNum == EstPro.RunNo).SingleOrDefault();

            for (int i = 10; i < 10 + (erun.DKTeams ?? 1); i++)
            {
                Teams.Add(i, "DKTeam" + (i - 9).ToString());

            }
            for (int i = 1; i <= (erun.ShiftTeams ?? 1); i++)
            {
                Teams.Add(i, "ExtTeam" + i.ToString());
            }

        }
        public void StartEstimate(ManualResetEvent wh, CancellationToken ct)
        {
            var plans = EstPro.GetAllPlans();

            EstPro.SaveSessionRun();

            _st.Tracing("Total Plan: " + plans.Count, EstPro.SessionId.ToString());
            if(plans.Count == 0)
            {
                throw new Exception("No Plan to estimate");    
            }

            // Dictionary<string, bool> teamstates = new Dictionary<string, bool>();
            bool dryerdone = false;
            bool kilndone = false;
            try
            {
                while (true)
                {
                    if (ct.IsCancellationRequested)
                    {
                        ClearRunTables(EstPro.RunNo);
                        ct.ThrowIfCancellationRequested();
                    }
                
                    wh.WaitOne();
                    
                    ++CurrHour;

                    List<Task> lt = new List<Task>();

                    var temp = Teams.Where(x => x.Value.Contains("Ext")).ToList();
                    int pid = 0;

                    for (int i = 0; i < temp.Count; i++)
                    {
                        pid = EstPro.GetNextPlan(temp[i].Value, plans);

                        if (pid > 0)
                        {
                            if (!EstPro.CurrPlans.Any(x => x.Plan.Id == pid))
                            {
                                EstPro.InitSum(plans.Where(x => x.Id == pid).Single(), CurrHour, temp[i].Value);
                                var lsum = EstPro.EstSums.Where(x => x.PPId == pid).Single();
                                lsum.ExtruderName = EstPro.GetUniqueExtName(pid, temp[i].Value);
                            }
                            // trust getnextplan()
                            EstPro.CurrPlans.Add(new PlanStatus
                            {
                                Plan = plans.Where(x => x.Id == pid).Single(),
                                Status = Constants.Processing,
                                Team = temp[i].Value,
                                ExtName = EstPro.GetUniqueExtName(pid, temp[i].Value)
                            });
                        }

                        if (pid == -9999)
                            pid = EstPro.CurrPlans.Where(x => x.Team == temp[i].Value && x.Status == Constants.Processing).Select(x => x.Plan.Id).Single();

                                   
                        if (pid == 0 || EstPro.AllPanelLoaded(pid))
                        {
                            continue; 
                        }

                        EstPro.InitDetail(pid, CurrHour);

                        if (!shiftprovider.CanWork(CurrHour))
                        {
                            continue; 
                        }

                        var t = Task.Run(() =>
                        {
                            DoExtWork(temp[i].Value, EstPro.GetUniqueExtName(pid, temp[i].Value));
                        });
                        t.Wait();// as a task for furture usage

                        if (EstPro.AllPanelLoaded(pid))
                        {
                            _st.Tracing("All plan#" + pid.ToString() + " Panels Extruded. Dryer/Kiln Loading...", EstPro.SessionId.ToString());
                            var cps = EstPro.CurrPlans.Where(x => x.Plan.Id == pid).ToList();
                            EstPro.SaveSummary(pid);
                            foreach(var cp in cps)
                                cp.Status = "Extruded";
                        }
                    }

                    if (!shiftprovider.CanWork(CurrHour))
                    {
                        EstPro.SaveDetail(); //only the hour matters, picking any detail
                        continue;
                    }

                    if (EstPro.AllPlanExted())
                    {
                        if (EstPro.EstSums.Any(x => x.PPId == 0))
                        {
                            EstPro.InitDetail(0, CurrHour);
                        }
                        else
                        {
                            var p = new SimulatorEntities().ProductionPlans.Where(x => x.Id == 0).Single();
                            EstPro.InitSum(p, CurrHour);
                            EstPro.InitDetail(0, CurrHour);
                        }
                    }
                    var temp1 = Teams.Where(x => x.Value.Contains("DK")).ToList();
                    for (int i = 0; i < temp1.Count; i++)
                    {
                        Task dktask = Task.Run(() =>
                        {
                            if (DoKilnWork(temp1[i].Value))
                                kilnprovider.FireAll();
                            else
                                DoDryerWork(temp1[i].Value);

                            EstPro.SaveDetail(temp1[i].Value);
                        });
                        dktask.Wait();
                    }
                    StatusManager.ReSetStatus<Kiln>();
                    StatusManager.ReSetStatus<Dryer>();

                    var ent = new SimulatorEntities();
                    if (EstPro.AllPlanExted() && !dryerdone)
                    {
                        int dpno = ent.CartPools.Where(x => x.PoolType == "ED").Select(x => x.PoolNum).Single();

                        dryerdone = !ent.Temp_CartPoolPlan.Any(x => x.PoolNum == dpno && x.SessionId == EstPro.SessionId.ToString() && x.Carts > 0 && x.PId > 0) 
                            && !ent.Temp_DryerPlan.Any(x => x.Carts > 0 && x.SessionId == EstPro.SessionId.ToString());

                        if (dryerdone)
                            _st.Tracing("All plan Panels Dryed. Kiln Loading...", EstPro.SessionId.ToString());
                    }
                    if (dryerdone && !kilndone)
                    {
                        int dpno = ent.CartPools.Where(x => x.PoolType == "DK").Select(x => x.PoolNum).Single();

                        kilndone = !ent.Temp_CartPoolPlan.Any(x => x.PoolNum == dpno && x.SessionId == EstPro.SessionId.ToString() && x.Panels > 0) 
                            && !ent.Temp_KilnPlan.Any(x => x.Panels > 0 && x.SessionId == EstPro.SessionId.ToString());
                    }
                    if (kilndone)
                    {
                        EstPro.SaveSummary(0);
                        _st.Tracing("Kiln Done.", EstPro.SessionId.ToString());
                        break;
                    }

                    if (ct.IsCancellationRequested)
                    {
                        ClearRunTables(EstPro.RunNo);
                        ct.ThrowIfCancellationRequested();
                    }
                   
                }
            }
            catch(Exception ex)
            {
                if(ex.InnerException == null)
                    Log2File.LogInfo("Error: " + ex.Message + " " + ex.StackTrace);
                else
                    Log2File.LogInfo("Error: " + ex.InnerException.Message + " " + ex.InnerException.StackTrace);
                //  Thread.CurrentThread.Abort();
            }
            
        }

        public void DoDryerWork(string tnm)
        {
            dryerprovider.SetTeam(tnm, CurrHour);
            if (!dryerprovider.UnloadDryers())
            {
                dryerprovider.LoadDryers();
            }
        }
        public void DoExtWork(string tnm, string ext)
        {
            extprovider.SetTeamAndExt(tnm, ext);
            extprovider.DoExt();

            EstPro.SaveDetail(tnm);
        }
        public bool DoKilnWork(string tnm)
        {
            kilnprovider.SetTeam(tnm, CurrHour);
            return kilnprovider.UnloadKiln() || kilnprovider.LoadKiln();

        }
        public void EndEstimate()
        {
            ;//nothing here   
        }

        private void ClearRunTables(int runno)
        {
            string clean = ConfigurationManager.AppSettings[KEY_EMPTYRUNTABLE].ToString();
            string sql = "";
            
            string[] tbls = ConfigurationManager.AppSettings[KEY_TABLESTOTRUNCATE].ToString().Split(new char[] { ',' });

           /* string sid = "";
            var sr = new SimulatorEntities().SessionRuns.Where(x => x.RunNum == runno).ToList();
            if (sr.Count > 0 || clean.ToUpper() != "NO") {
                if (sr.Count > 0)
                    sid = sr.Where(x => x.CreateDate == sr.Max(y => y.CreateDate)).Select(z => z.SessionId).Single();
                */
                var sd = new Data.SimulatorDAO();
                foreach (var tbl in tbls)
                {
                    if (clean.ToUpper() == "NO")
                    {
                        if (tbl.ToUpper().Contains("ESTIMATEDETAIL"))
                        {
                            sql = "delete a from " + tbl + " a join estimatesummary b on a.sumid = b.id where b.runnum ="
                            + runno.ToString() + ";";
                        } else
                            sql = "delete a from " + tbl + " a join sessionrun b on a.sessionid = b.sessionid where b.runnum ="
                                + runno.ToString() + ";";
                    } else
                    {
                        sql = "truncate table " + tbl + ";";
                    }

                    sd.ExecuteSql(sql);
                }
                sd.ExecuteSql("delete dbo.estimatesummary where runnum =" + runno.ToString());
          //  }
        }
        public int LoadPlanFromFile()
        {
            int ret = 0;
        
            return ret;
        }

        private void LoadRunFromFile()
        {
            if (!ConfigurationManager.AppSettings[KEY_LOADRUN].ToString().Equals("File"))
                return;

            bool first = true;

            using (TextFieldParser parser =
                new TextFieldParser(ConfigurationManager.AppSettings[KEY_RUNSETUP].ToString()))
            {
                parser.SetDelimiters(new string[] { "," });
                parser.TextFieldType = FieldType.Delimited;
                parser.HasFieldsEnclosedInQuotes = true;

                string[] row = parser.ReadFields();

                var truncate = ConfigurationManager.AppSettings["KEY_EMPTYRUNTABLE"].ToString();

                using (var ent = new SimulatorEntities())
                {
                    while (!parser.EndOfData)
                    {
                        if (first && truncate.Equals("Yes"))
                        {
                            new Data.SimulatorDAO().ExecuteSql("truncate table dbo.estimaterun;");
                            first = false;
                        }

                        ent.EstimateRuns.Add(new EstimateRun
                        {
                            PlanStart = Convert.ToInt32(row[0].ToString()),
                            PlanEnd = Convert.ToInt32(row[1].ToString()),
                            PlanOrder = row[2].ToString(), //Id default, or Date
                            DryerStart = Convert.ToInt32(row[3].ToString()),
                            DryerEnd = Convert.ToInt32(row[4].ToString()),
                            ExtColor = row[5].ToString(),
                            ExtDye = Convert.ToInt32(row[6].ToString()),
                            ShiftName = row[7].ToString(),
                            CartPool1 = Convert.ToInt32(row[8].ToString()),
                            CartPool2 = Convert.ToInt32(row[9].ToString()),
                            RackTotal = Convert.ToInt32(row[10].ToString()),
                            CreateDate = DateTime.Now,
                            CreatedBy = Environment.UserName

                        });

                        row = parser.ReadFields();
                    }

                    ent.SaveChanges();
                }
            }
        }

        private void SetupCartPool()
        {
            using (var ent = new SimulatorEntities())
            {
                var cartpool1 = new Temp_CartPoolPlan
                {
                    PoolNum = ent.CartPools.Where(x => x.PoolType == "ED").Select(x => x.PoolNum).Single(),
                    PId = 0,
                    UpdateDate = DateTime.Now,
                    Carts = EstPro.EstRun.CartPool1 ?? 0,
                    SessionId = EstPro.SessionId.ToString()
                };
                ent.Temp_CartPoolPlan.Add(cartpool1);

                var cartpool2 = new Temp_CartPoolPlan
                {
                    PoolNum = ent.CartPools.Where(x => x.PoolType == "KE").Select(x => x.PoolNum).Single(),
                    PId = 0,
                    UpdateDate = DateTime.Now,
                    SessionId = EstPro.SessionId.ToString(),
                    Carts = EstPro.EstRun.CartPool2 ?? Math.Min(ent.CartPools.Where(x => x.PoolType == "KE").Select(x => x.Capacity).Single(),
                                                  ent.Carts.Where(x => x.CartType == "DC").Select(x => x.TotalCarts).Single())
                };

                ent.Temp_CartPoolPlan.Add(cartpool2);

                int cap = ent.CartPools.Where(x => x.PoolType == "DK").Select(x => x.Capacity).Single();

                var cartpool3 = new Temp_CartPoolPlan
                {
                    PoolNum = ent.CartPools.Where(x => x.PoolType == "DK").Select(x => x.PoolNum).Single(),
                    PId = 0,
                    UpdateDate = DateTime.Now,
                    Carts = EstPro.EstRun.CartPool3 ?? 0,
                    SessionId = EstPro.SessionId.ToString()
                };

                ent.Temp_CartPoolPlan.Add(cartpool3);

                ent.SaveChanges();
            }
        }
        private void SetupDryer()
        {
            throw new NotImplementedException();
        }
        private void SetupShelf()
        {
            using (var ent = new SimulatorEntities())
            {
                int? shelfsetup = EstPro.EstRun.RackTotal;

                var racks = ent.Shelves.Where(x => x.ShelfType == "DS").ToList();

                foreach (var rack in racks)
                {
                    ent.Temp_ShelfPlan.Add(new Temp_ShelfPlan
                    {
                        PId = 0,
                        UpdateDate = DateTime.Now,
                        Used = shelfsetup ?? 0,
                        ShelfName = rack.ShelfName,
                        SessionId = EstPro.SessionId.ToString()
                    });
                }
                ent.SaveChanges();
            }
        }
    }
}
