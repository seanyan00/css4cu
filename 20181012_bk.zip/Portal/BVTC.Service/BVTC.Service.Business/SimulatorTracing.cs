﻿namespace BVTC.Service.Business
{
    public class SimulatorTracing : Common.Utilities.Log
    {
        public override void AddDBTracing(string msg, string sid)
        {
            using (var ent = new Data.Models.Simulator.SimulatorEntities())
            {
                ent.EstimateTracings.Add(new Data.Models.Simulator.EstimateTracing
                {
                    SessionId = sid,
                    TracingMsg = msg
                });

                ent.SaveChanges();
            }
        }
    }
}
