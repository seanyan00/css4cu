﻿using System.ServiceModel;

using BVTC.Service.TransferObject.Portal;
using BVTC.Service.TransferObject.Main;

namespace BVTC.Service.Base.Contracts
{
    [ServiceContract]
    public interface IWorkBookService
    {
        [OperationContract]
        UIElementDTO[] GetUIElementByUIType(string uityp);
        [OperationContract]
        UIElementDTO GetUIElementByUIId(string uiid);
        [OperationContract]
        ElementDataDTO GetDataSourceByRequest(ElementRequestDTO erd);
        [OperationContract]
        int SetDataRecord(ElementDataDTO edd);
        [OperationContract]
        KeyValueItem[] GetKeyValueList(string name, string parent);
        [OperationContract]
        ElementDataDTO GetDataSourceByCols(ElementDataDTO edd);
        [OperationContract]
        int GetUIdByUName(string uname);
        [OperationContract]
        bool IsEditAllowed(string gname);
        [OperationContract]
        void SendEmailMessage(string name, string type, string[] ps);
        [OperationContract]
        void RunSqlCommand(CommandDTO cmdd);
    }
}
