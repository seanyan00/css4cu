﻿using System.ServiceModel;

using BVTC.Service.TransferObject.Portal;

namespace BVTC.Service.Base.Contracts
{
    [ServiceContract]
    public interface IBarCodeService
    {
        [OperationContract]
        string CreateCodeForBlock(int blockid, string token);
        [OperationContract]
        int SaveScan(ScanResultDTO[] srdto, string token);
        [OperationContract]
        string GetLastLocationByCode(string code, string token);
        [OperationContract]
        string GetLastLocationByBlock(int blockid, string token);
        [OperationContract]
        string GetNextLocationByCode(string code, string token);
        [OperationContract]
        string GetNextLocationByBlock(int blockid, string token);
        [OperationContract]
        ScanResultDTO[] GetScanHistByCode(string code, string token);
        [OperationContract]
        ScanResultDTO[] GetScanHistByBlock(int blockid, string token);
    }
}
