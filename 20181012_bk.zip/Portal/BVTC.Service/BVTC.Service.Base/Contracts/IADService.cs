﻿using System.ServiceModel;

using BVTC.Service.TransferObject.Main;

namespace BVTC.Service.Base.Contracts
{
    [ServiceContract]
    public interface IADService
    {
        [FaultContract(typeof(AuthFault))]
        [OperationContract]
        BVTCUserDTO GetBVTCUser(string domin, string pwd, BVTCUserDTO bu);
        [OperationContract]
        BVTCUserDTO GetBVTCUserById(string pwd, int eid);
        [OperationContract]
        string[] GetUserGroups(string domin, string uname, string pwd);
        [OperationContract]
        string IsAuthenticated(string domin, string uname, string pwd);
        [OperationContract]
        string[] GetGroupsByToken(string token);
        [OperationContract]
        BVTCUserDTO GetUserGrant(string uname, string type);
        [OperationContract]
        void SignOut(string appname, string uname);
    }
}
