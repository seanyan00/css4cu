﻿using System;
using System.Collections.Generic;
using System.ServiceModel;

using BVTC.Service.TransferObject;

namespace BVTC.Service.Base.Contracts
{
    [ServiceContract]
    public interface ISimulatorService
    {
        [OperationContract]
        Guid StartEstimate(int runno);
        [OperationContract]
        void PauseEstimate(Guid id);
        [OperationContract]
        void ResumeEstimate(Guid id);
        [OperationContract]
        void ExitEstimate(Guid id);
        [OperationContract]
        Dictionary<int, string> GetStatus(Guid id, int lastid);
        [OperationContract]
        EstRunDTO[] GetRuns();
        [OperationContract]
        ShiftDTO[] GetShifts();
        [OperationContract]
        DryerDTO[] GetDryers();
        [OperationContract]
        KilnDTO[] GetKilns();
        [OperationContract]
        void SaveEstRun(EstRunDTO ero);
        [OperationContract]
        SummaryDTO GetSummary(int runno);
        [OperationContract]
        PlanDTO[] GetPlans();
        [OperationContract]
        EstSummaryDTO[] GetEstSummaries(int runno);
        [OperationContract]
        EstDetailDTO[] GetEstDetails(int runno);
        [OperationContract]
        TeamActDTO[] GetTeamActs(int runno);
        [OperationContract]
        DryerActDTO[] GetDryerActs(int runno);
        [OperationContract]
        KilnActDTO[] GetKilnActs(int runno);
        [OperationContract]
        CartDTO[] GetCarts();
        [OperationContract]
        ShelfDTO[] GetShelves();
        [OperationContract]
        CartPoolDTO[] GetCartPools();
        [OperationContract]
        ExtruderDTO[] GetExtruders();
        [OperationContract]
        ShiftBreakDTO[] GetShiftBreaks();
        [OperationContract] 
        void SavePlan(PlanDTO pd);
        [OperationContract]
        void SaveCart(CartDTO cd);
        [OperationContract]
        void SaveShelf(ShelfDTO sd);
        [OperationContract]
        void SaveCartPool(CartPoolDTO cpd);
        [OperationContract]
        void SaveExtruder(ExtruderDTO ed);
        [OperationContract]
        void SaveShiftBreak(ShiftBreakDTO sd);
        [OperationContract]
        void SaveShift(ShiftDTO sd);
        [OperationContract]
        void SaveDryer(DryerDTO dd);
        [OperationContract]
        void SaveKiln(KilnDTO kd);
    }
    
}
