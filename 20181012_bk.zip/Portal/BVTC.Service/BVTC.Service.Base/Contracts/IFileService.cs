﻿using System.ServiceModel;
using System.IO;

using BVTC.Service.TransferObject.Portal;
using BVTC.Service.TransferObject.Main;

namespace BVTC.Service.Base.Contracts
{
    [ServiceContract]
    public interface IFileService
    {
        [OperationContract]
        string UploadFile(byte[] data, string fname, string type, string projno);
        [OperationContract]
        string UploadFileA(byte[] data, DocumentDTO ddto);
        [OperationContract]
        int SaveDoc(DocumentDTO ddto);
        [OperationContract]
        Stream DownloadFile(string fname);
        [OperationContract(Name = "DownloadFileWithType")]
        Stream DownloadFile(string fname, string type, string projno);
        [OperationContract]
        Stream DownloadFileById(int id, bool hist);
        [OperationContract]
        Stream CreatePDFById(string id, string doctype, string projno);
        [OperationContract]
        void BatchLoadData(byte[] data, string type, string projno);
        [OperationContract]
        Stream GetReport(ReportRequestDTO rrd);
        [OperationContract]
        int BulkUploadFile(BulkUploadDTO buld);
        [OperationContract]
        FileDirDTO GetTargetDirInfo(string path, int pid);
        [OperationContract]
        void ResetDocDefault(int id);
    }
}
