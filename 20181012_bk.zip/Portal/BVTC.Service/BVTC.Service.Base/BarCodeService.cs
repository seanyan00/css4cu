﻿using System;

using BVTC.Service.TransferObject.Portal;

namespace BVTC.Service.Base
{
    public class BarCodeService : Contracts.IBarCodeService
    {
        public string CreateCodeForBlock(int blockid, string token)
        {
            throw new NotImplementedException();
        }
        public int SaveScan(ScanResultDTO[] srdto, string token)
        {
            throw new NotImplementedException();
        }
        public string GetLastLocationByCode(string code, string token)
        {
            throw new NotImplementedException();
        }
        public string GetLastLocationByBlock(int blockid, string token)
        {
            throw new NotImplementedException();
        }
        public string GetNextLocationByCode(string code, string token)
        {
            throw new NotImplementedException();
        }
        public string GetNextLocationByBlock(int blockid, string token)
        {
            throw new NotImplementedException();
        }
        public ScanResultDTO[] GetScanHistByCode(string code, string token)
        {
            throw new NotImplementedException();
        }
        public ScanResultDTO[] GetScanHistByBlock(int blockid, string token)
        {
            throw new NotImplementedException();
        }
    }
}
