﻿using System;
using System.IO;
using System.ServiceModel.Channels;
using System.Xml;
using System.Xml.Serialization;
using System.ServiceModel.Security;

using BVTC.Service.TransferObject.Main;

namespace BVTC.Service.Base.Extensions
{
    public class SessionHeader : MessageHeader
    {
        public BVTCUserDTO User { get;  }

        public SessionHeader(BVTCUserDTO puser)
        {
            User = puser;
        }

        public override string Name
        {
            get { return (SessionHeaderNames.CustomHeaderName); }
        }

        public override string Namespace
        {
            get { return (SessionHeaderNames.CustomHeaderNamespace); }
        }

        protected override void OnWriteHeaderContents(XmlDictionaryWriter writer, MessageVersion messageVersion)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(BVTCUserDTO));
            StringWriter tw = new StringWriter();
            serializer.Serialize(tw, User);
            tw.Close();
                      
            writer.WriteElementString(SessionHeaderNames.CustomHeaderName, SessionHeaderNames.KeyName, tw.ToString().Trim());
        }

        public static BVTCUserDTO ReadHeader(Message request)
        {
            BVTCUserDTO ret = null;

            Int32 hp = request.Headers.FindHeader(SessionHeaderNames.CustomHeaderName, SessionHeaderNames.CustomHeaderNamespace);
            if (hp == -1)
            {
                throw new Exception("No session info found in SOAP header");
            }

            try
            {
                MessageHeaderInfo headerInfo = request.Headers[hp];

                XmlNode[] content = request.Headers.GetHeader<XmlNode[]>(hp);

                string text = content[0].InnerText;

                XmlSerializer deserializer = new XmlSerializer(typeof(BVTCUserDTO));
                TextReader tr = new StringReader(text);
                ret = (BVTCUserDTO)deserializer.Deserialize(tr);
                tr.Close();
             
            }
            catch(Exception ex)
            {
                 throw new MessageSecurityException(ex.Message);
            }
            
            return ret;
        }
    }

    public static class SessionHeaderNames
    {
        public const String CustomHeaderName = "SessionHeader";

        public const String KeyName = "Key";

        public const String CustomHeaderNamespace = "http://portal.bostonvally.com/SessionHeader";

    }

}
