﻿using System;
using System.ServiceModel;
using System.ServiceModel.Dispatcher;
using System.ServiceModel.Channels;
using System.Web;
using System.Configuration;

using BVTC.Service.TransferObject.Main;
using BVTC.Service.Common;
using BVTC.Service.Common.Utilities;

namespace BVTC.Service.Base.Extensions
{
    public class CustomMessageInspector : IDispatchMessageInspector, IClientMessageInspector
    {
        public object AfterReceiveRequest(ref Message request, IClientChannel channel, InstanceContext instanceContext)
        {
            BVTCUserDTO header = SessionHeader.ReadHeader(request);

            try
            {
                if (Business.TokenValidator.IsValidToken(header))
                    SessionUserList.AddUser(request.Headers.MessageId.ToString(), header);
                else
                {
                    throw new FaultException("Invalid Session Token");
                }
            }
            catch (FaultException)
            {
                throw;
            }
            catch(Exception ex)
            {
                Log2File.LogInfo("Error: bud uname=" + (string.IsNullOrEmpty(header.Uname) ? "EMPTY" : header.Uname) + "; Token=" + (string.IsNullOrEmpty(header.Token) ? "EMPTY" : header.Token) + ".");
                Log2File.LogInfo("Error: " + ex.Message + " " + ex.StackTrace);
                throw new FaultException("Server Error");
            }
            return null;
        }

        public void BeforeSendReply(ref Message reply, object correlationState)
        {
        }

        public void AfterReceiveReply(ref Message reply, object correlationState)
        {
        }

        public object BeforeSendRequest(ref Message request, IClientChannel channel)
        {
            MessageBuffer buffer = request.CreateBufferedCopy(Int32.MaxValue);
            request = buffer.CreateMessage();

            var temp = ConfigurationManager.AppSettings[Constants.KEY_BVTCUSER].ToString();

            BVTCUserDTO bud = (BVTCUserDTO)HttpContext.Current.Session[temp];

            //Log2File.LogInfo("Info: bud uname=" + (string.IsNullOrEmpty(bud.Uname) ? "EMPTY" : bud.Uname) + "; Token=" + (string.IsNullOrEmpty(bud.Token) ? "EMPTY" : bud.Token) + ".");
            request.Headers.Add(new SessionHeader(bud));

            return null;
        }

               
    }

}
