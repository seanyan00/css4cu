﻿using System.ServiceModel;

using BVTC.Service.Base.Contracts;
using BVTC.Service.Business;
using BVTC.Service.Common;
using BVTC.Service.TransferObject.Portal;
using BVTC.Service.TransferObject.Main;

namespace BVTC.Service.Base
{
    public class WorkBookService : IWorkBookService
    {
        public BVTCUserDTO BUD { get; set; }
        public WorkBookService()
        {
            BUD = GetBVTCUser();
        }
        public UIElementDTO[] GetUIElementByUIType(string uityp)
        {
            return null;
        }
        public int SetDataRecord(ElementDataDTO edd)
        {
            return new PortalUIManager(BUD).SaveDataRecord(edd);
        }
        public UIElementDTO GetUIElementByUIId(string uiid)
        {
             return new PortalUIManager(BUD).GetElementById(uiid);
        }
        public ElementDataDTO GetDataSourceByRequest(ElementRequestDTO erd)
        {
             return new PortalUIManager(BUD).GetDataSourceByRequest(erd);
        }
        public KeyValueItem[] GetKeyValueList(string name, string parent)
        {
            return new PortalUIManager(BUD).GetKeyValueArray(name, parent);
        }
        public ElementDataDTO GetDataSourceByCols(ElementDataDTO edd)
        {
            return new PortalUIManager(BUD).GetDataSourceByCols(edd);
        }
        public int GetUIdByUName(string uname)
        {
            return new PortalUIManager(BUD).GetUIdByUName(uname);
        }
        public string UploadFile(byte[] content, string filename, string type)
        {
            return new PortalUIManager(BUD).UploadFile(content, filename, type);
        }
        public bool IsEditAllowed(string gname)
        {
            return new PortalUIManager(BUD).IsEditAllowed(gname);
        }
        public void SendEmailMessage(string name, string type, string[] ps)
        {
            new PortalUIManager(BUD).SendEmailMessage(name, type, ps);
        }
        public void RunSqlCommand(CommandDTO cmdd)
        {
            new PortalUIManager(BUD).RunSql(cmdd);
        }
    
        private BVTCUserDTO GetBVTCUser()
        {
            return SessionUserList.Users[OperationContext.Current.IncomingMessageHeaders.MessageId.ToString()];
        }
    }
}
