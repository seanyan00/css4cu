﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.ServiceModel;
//using System.Collections.Concurrent;
using System.Linq;

using BVTC.Service.Business;
using BVTC.Service.Business.Providers;
using BVTC.Service.Common;
using BVTC.Service.Common.Utilities;
using BVTC.Service.TransferObject;

namespace BVTC.Service.Base
{
    public class TaskCancelStatus
    {
        public Guid Id { get; set; }
        public CancellationTokenSource TSource { get; set; }
        public Task CTask { get; set; }
    }
    public class SimulatorService : Contracts.ISimulatorService
    {
        private static Dictionary<Guid, ManualResetEvent> wHandles = new Dictionary<Guid, ManualResetEvent>();
        private static List<TaskCancelStatus> cTokens = new List<TaskCancelStatus>();
               
        public Guid StartEstimate(int runno)
        {
            GraceShutDownEvent.ServiceClosing += UnlockAll;

            var tokenSource = new CancellationTokenSource();
            var token = tokenSource.Token;

            var ret = Guid.NewGuid();
            try
            {
                wHandles.Add(ret, new ManualResetEvent(initialState: true));
                var manager = new SimulationManager();

                manager.Setup(ret, runno);

                Log2File.LogInfo("Starting Extimate...");
              
                Task t = Task.Run(() => { manager.StartEstimate(wHandles[ret], token); }, token);
                 cTokens.Add(new TaskCancelStatus { Id = ret, TSource = tokenSource, CTask = t });

                Log2File.LogInfo("Estimate Ends...");
                manager.EndEstimate();
            }
            catch(AggregateException ex)
            {
                Log2File.LogInfo("Exit: " + ex.Message);
            }
            catch (OperationCanceledException ex)
            {
                Log2File.LogInfo("Exit: " + ex.Message);
            }
            catch (Exception ex)
            {
                 Log2File.LogInfo("Error: " + ex.Message);
                 throw new FaultException("Server Error on Running Estimate");
            }
            return ret;

        }
        public EstRunDTO[] GetRuns()
        {
            var ret = new List<EstRunDTO>();

            try
            {
                ret = new RunSummaryProvider().GetRuns();
            }
            catch(Exception ex)
            {
                Log2File.LogInfo("Error: " + ex.Message);
            }
            return ret.ToArray();
        }
        public ShiftDTO[] GetShifts()
        {
            var ret = new List<ShiftDTO>();

            try
            {
                ret = new RunSummaryProvider().GetShifts();
            }
            catch (Exception ex)
            {
                Log2File.LogInfo("Error: " + ex.Message);
            }
            return ret.ToArray();
        }
        public void PauseEstimate(Guid id)
        {
            wHandles[id].Reset();
        }
        public void ExitEstimate(Guid id)
        {
            wHandles[id].Set();
            wHandles.Remove(id);

            var temp = cTokens.Where(x => x.Id == id).Single();
            temp.TSource.Cancel();
            cTokens.Remove(temp);
            while(temp.CTask.Status != TaskStatus.Canceled && temp.CTask.Status != TaskStatus.RanToCompletion)
            {
                Thread.Sleep(500);
            }
        }
        public DryerDTO[] GetDryers()
        {
            var ret = new List<DryerDTO>();

            try
            {
                ret = new RunSummaryProvider().GetDryers();
            }
            catch (Exception ex)
            {
                Log2File.LogInfo("Error: " + ex.Message);
            }
            return ret.ToArray();
        }
        public KilnDTO[] GetKilns()
        {
            var ret = new List<KilnDTO>();

            try
            {
                ret = new RunSummaryProvider().GetKilns();
            }
            catch (Exception ex)
            {
                Log2File.LogInfo("Error: " + ex.Message);
            }
            return ret.ToArray();
        }
        public void SaveEstRun(EstRunDTO ero)
        {
            try
            {
                new RunSummaryProvider().SaveEstRun(ero);
            }
            catch (Exception ex)
            {
                Log2File.LogInfo("Error: " + ex.Message);
                throw new FaultException("Server Error. See log file for details");
            }
        }

        public void ResumeEstimate(Guid id)
        {
            wHandles[id].Set();
        }
        public Dictionary<int, string> GetStatus(Guid sid, int lastid)
        {
            return new Data.SimulatorDAO().GetTrace(sid.ToString(), lastid);
        }
        //THIS service inst may disposed while host service is still running. no overriding on dispose()
        public static void UnlockAll(object sender, EventArgs e)
        {
            foreach (var h in wHandles)
            {
                h.Value.Set();
            }
        }
        public SummaryDTO GetSummary(int runno)
        {
            try
            {
                return new RunSummaryProvider().GetSummary(runno);
            }
            catch (Exception ex)
            {
                Log2File.LogInfo("Error: " + ex.Message);
                throw new FaultException("No Run found for the number");
            }
        }
        public PlanDTO[] GetPlans()
        {
            return new RunSummaryProvider().GetPlans();
        }

        public EstSummaryDTO[] GetEstSummaries(int runno)
        {
            return new RunSummaryProvider().GetEstSummaries(runno);
        }

        public EstDetailDTO[] GetEstDetails(int runno)
        {
            return new RunSummaryProvider().GetEstDetails(runno);
        }

        public TeamActDTO[] GetTeamActs(int runno)
        {
            return new RunSummaryProvider().GetTeamActs(runno);
        }

        public DryerActDTO[] GetDryerActs(int runno)
        {
            return new RunSummaryProvider().GetDryerActs(runno);
        }

        public KilnActDTO[] GetKilnActs(int runno)
        {
            return new RunSummaryProvider().GetKilnActs(runno);
        }

        public CartDTO[] GetCarts()
        {
            return new RunSummaryProvider().GetCarts();
        }

        public ShelfDTO[] GetShelves()
        {
            return new RunSummaryProvider().GetShelves();
        }

        public CartPoolDTO[] GetCartPools()
        {
            return new RunSummaryProvider().GetCartPools();
        }

        public ExtruderDTO[] GetExtruders()
        {
            return new RunSummaryProvider().GetExtruders();
        }

        public ShiftBreakDTO[] GetShiftBreaks()
        {
            return new RunSummaryProvider().GetShiftBreaks();
        }

        public void SavePlan(PlanDTO pd)
        {
            new RunSummaryProvider().SavePlan(pd);
        }

        public void SaveCart(CartDTO cd)
        {
            new RunSummaryProvider().SaveCart(cd);
        }

        public void SaveShelf(ShelfDTO sd)
        {
            new RunSummaryProvider().SaveShelf(sd);
        }
        public void SaveCartPool(CartPoolDTO cd)
        {
            new RunSummaryProvider().SaveCartPool(cd);
        }
        public void SaveExtruder(ExtruderDTO ed)
        {
            new RunSummaryProvider().SaveExtruder(ed);
        }

        public void SaveShiftBreak(ShiftBreakDTO sd)
        {
            new RunSummaryProvider().SaveShiftBreak(sd);
        }

        public void SaveShift(ShiftDTO sd)
        {
            new RunSummaryProvider().SaveShift(sd);
        }

        public void SaveDryer(DryerDTO dd)
        {
            new RunSummaryProvider().SaveDryer(dd);
        }

        public void SaveKiln(KilnDTO kd)
        {
            new RunSummaryProvider().SaveKiln(kd);
        }
    }
}
