﻿using System;
using System.IO;
using System.ServiceModel;

using BVTC.Service.Base.Contracts;
using BVTC.Service.Business.Providers;
using BVTC.Service.Common;
using BVTC.Service.Common.Utilities;
using BVTC.Service.TransferObject.Main;
using BVTC.Service.TransferObject.Portal;

namespace BVTC.Service.Base
{
    public class FileService : IFileService
    {
        public BVTCUserDTO BUD { get; set; }
        public FileService()
        {
            BUD = GetBVTCUser();
        }
        public string UploadFile(byte[] data, string fname, string type, string projno)
        {
            return new FileAccessProvider(BUD, projno).SaveFile(data, fname, type);
        }
        public string UploadFileA(byte[] data, DocumentDTO ddto)
        {
            return new FileAccessProvider(BUD, ddto.ProjectNo).SaveFile(data, ddto);
        }
        public int SaveDoc(DocumentDTO ddto)
        {
            try
            {
                return new FileAccessProvider(BUD, ddto.ProjectNo).SaveDoc(ddto);
            }
            catch (Exception ex)
            {
                Log2File.LogInfo("Error: FileService.SaveDoc# ", ex, System.Diagnostics.TraceLevel.Error);
                throw new FaultException(ex.Message);
            }
        }
        public void BatchLoadData(byte[] data, string type, string projno)
        {
            try
            {
                new FileAccessProvider(BUD, projno).SaveData(data, type, projno);
            }
            catch (Exception ex)
            {
                Log2File.LogInfo("Error: BatchLoadData# ", ex, System.Diagnostics.TraceLevel.Error);
                throw new FaultException(ex.Message);
            }
        }
        public Stream DownloadFile(string fname)
        {
            return new FileAccessProvider(BUD).GetFile(fname);
        }
        public Stream DownloadFile(string fname, string type, string projno)
        {
            return new FileAccessProvider(BUD).GetFile(fname, type, projno);
        }
        public Stream DownloadFileById (int id, bool hist)
        {
            return new FileAccessProvider(BUD).GetFile(id, hist);
        }
        public Stream CreatePDFById(string id, string doctype, string projno)
        {
            try
            {
                return new PDFProvider(BUD, projno).Create(id, doctype, projno);
            }
            catch(Exception ex)
            {
                Log2File.LogInfo("Error: @CreatePDFById #" + ex.Message, System.Diagnostics.TraceLevel.Error);
                if (ex.Message.Contains("no pages"))
                    throw new FaultException("The underneath item list is empty");
                else
                    throw new FaultException("Server Error");
            }
        }
        public int BulkUploadFile(BulkUploadDTO buld)
        {
            try
            {
                return new FileAccessProvider(BUD, buld.ProjectNo).BulkUpload(buld);
            }
            catch (Exception ex)
            {
                Log2File.LogInfo("Error: @BulkUploadFile", ex, System.Diagnostics.TraceLevel.Error);
                throw new FaultException("Server Error");
            }
        }
        public void ResetDocDefault(int id)
        {
            try
            {
                new FileAccessProvider(BUD).ResetDocDefault(id);
            }
            catch (Exception ex)
            {
                Log2File.LogInfo("Error: @ResetDocDefault", ex, System.Diagnostics.TraceLevel.Error);
                throw new FaultException("Server Error");
            }
        }
        public Stream GetReport(ReportRequestDTO rrd)
        {
            try
            {
                return new ReportProvider().GetReport(rrd);
            }
            catch (Exception ex)
            {
                Log2File.LogInfo("Error: @GetReport", ex, System.Diagnostics.TraceLevel.Error);
                throw new FaultException("Server Error");
            }
        }
        public FileDirDTO GetTargetDirInfo(string path, int pid)
        {
            try
            {
                return new FileAccessProvider(BUD).GetDirInfo(path, pid);
            }
            catch (Exception ex)
            {
                Log2File.LogInfo("Error: @GetTargetDirInfo", ex, System.Diagnostics.TraceLevel.Error);
                throw new FaultException("Server Error");
            }
        }
      
        private BVTCUserDTO GetBVTCUser()
        {
            return SessionUserList.Users[OperationContext.Current.IncomingMessageHeaders.MessageId.ToString()];
        }
    }
}
