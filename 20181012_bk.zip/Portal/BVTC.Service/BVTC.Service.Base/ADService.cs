﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Configuration;

using BVTC.Service.Base.Contracts;
using BVTC.Service.Business.Providers;
using BVTC.Service.Common.Utilities;
using BVTC.Service.TransferObject.Main;

namespace BVTC.Service.Base
{
    public class ADService : IADService
    {
        private const string KEY_AUTHADPATH = "Auth_ADPath";

        public AuthProvider Authpro {get; set; }

        public ADService()
        {
            string path = ConfigurationManager.AppSettings[KEY_AUTHADPATH].ToString();

            Authpro = new AuthProvider(path);
        }
        public string[] GetUserGroups(string domain, string uname, string pwd)
        {
            var ret = new List<string>();
            try
            {
                if(Authpro.IsAuthenticated(domain, uname, pwd))
                {
                    ret = Authpro.GetGroups();
                }
            }
            catch (Exception ex)
            {
                Log2File.LogInfo("Error: for User " + uname + ex.Message);
                throw new FaultException("Server Error on getting User Groups");
            }
            return ret.ToArray();
        }

        public string IsAuthenticated(string domin, string uname, string pwd)
        {
            throw new NotImplementedException();
        }
        
        public string[] GetGroupsByToken(string token)
        {
            throw new NotImplementedException();
        }
        public BVTCUserDTO GetUserGrant(string uname, string utype)
        {
            throw new NotImplementedException();
        }
        public void SaveSessionToken(string uname, string token)
        {

        }
        public void SignOut(string appname, string uname)
        {
            Authpro.SignOut(appname, uname);
        }
        public BVTCUserDTO GetBVTCUser(string domain, string pwd, BVTCUserDTO bu)
        {
            return Authpro.CreateSession(domain, pwd, bu);
        }
        public BVTCUserDTO GetBVTCUserById(string pwd, int eid)
        {
            return Authpro.CreateSession(pwd, eid);
        }
    }

}
