﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using System.Data.Objects;
using System.Data.Objects.DataClasses;
using System.Data.Linq.Mapping;
using System.Data.Metadata.Edm;
using System.Data.Entity.Infrastructure;
using System.Reflection;

using BVTC.Service.TransferObject.Portal;

namespace BVTC.Service.Data
{
    public class Generalizer
    {
        public ElementDataDTO ToEntityDTO<T>(T ent) where T : class
        {

            return null;
        }
       
     
        public ElementDataDTO FromEntity<T>(DbContext ctx) where T : class
        {
            var ret = new ElementDataDTO();
            
            var objectContext = (ctx as IObjectContextAdapter).ObjectContext;
            var entitySet = objectContext.CreateObjectSet<T>().EntitySet;
            var keys = entitySet.ElementType.KeyMembers.Select(x =>
                new EleValueDTO
                {
                    DBName = x.Name,
                    DataType = GetTypedEdmValue(x.TypeUsage.EdmType).Name,
                    DefValue = GetDefaultValue(GetTypedEdmValue(x.TypeUsage.EdmType)).ToString()

                }).ToArray();
            ret.DataElements = keys;

            //var ret = GetList<T>(ctx, x => (T)x);
            return ret;
        }
        public IEnumerable<T> GetList<T>(DbContext ctx, Func<object, T> caster)
        {
            var setmethod = ctx.GetType().GetMethod("Set").MakeGenericMethod(typeof(T));

            var querable = ((DbSet<object>)setmethod
                            .Invoke(this, null))
                            .AsNoTracking()
                            .AsQueryable();

            return querable
                .Select(x => caster(x))
                .ToList();
        }
        
            /*
               var sets = typeof(FooContext).GetProperties()
                          .Where(pi => pi.PropertyType.IsInterface && pi.PropertyType.GetGenericTypeDefinition().ToString().ToLower().Contains("idbset"));

          foreach (var set in sets)
          {
          ------------------------------------
          System.Reflection.MethodInfo mi = typeof(API).GetMethod("DoSomething", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
mi.MakeGenericMethod(typeof(Type.GetType(entityTypeName))).Invoke(new API(),new object[]{_db});



 class API
 {        

     private void DoSomething<T>(DbContext db)
     {
       IQueryable<T> items = db.Set<T>();
      // Do something you need .....

     }
 }

              */
        
    }
}
