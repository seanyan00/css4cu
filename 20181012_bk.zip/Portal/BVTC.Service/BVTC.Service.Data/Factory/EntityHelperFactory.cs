﻿using System;
using System.Data.Entity;
using System.Reflection;

using BVTC.Service.TransferObject.Portal;
using BVTC.Service.TransferObject.Main;

namespace BVTC.Service.Data.Factory
{
    public static class EntityHelperFactory
    {
        public static object CreateInstance(DbContext ctx, ElementDataDTO edd, BVTCUserDTO bud)
        {
            // Type targ = Type.GetType(edd.TableName);
            Type targ = Extensions.TypeHelper.GetDataType(edd.TableName);

            Type gclass = typeof(Extensions.EntityHelper<>);
            Type cclass = gclass.MakeGenericType(targ);

            return Activator.CreateInstance(cclass, new object[] { ctx, edd, bud });
        }
        public static object CreateInstance(DbContext ctx, ElementRequestDTO erd, BVTCUserDTO bud)
        {
            // Type targ = Type.GetType(edd.TableName);
            Type targ = Extensions.TypeHelper.GetDataType(erd.Name);

            Type gclass = typeof(Extensions.EntityHelper<>);
            Type cclass = gclass.MakeGenericType(targ);

            return Activator.CreateInstance(cclass, new object[] { ctx, erd, bud });
        }

        public static ElementDataDTO GetDTO(DbContext ctx, ElementRequestDTO erd, BVTCUserDTO bud)
        {
            object obj = CreateInstance(ctx, erd, bud);
            Type otype = obj.GetType();

            MethodInfo m1 = otype.GetMethod("GetDTO");

            return (ElementDataDTO)m1.Invoke(obj, new object[] { });
        }

        public static int SaveDTO(DbContext ctx, ElementDataDTO edd, BVTCUserDTO bud)
        {
            object obj = CreateInstance(ctx, edd, bud);
            Type otype = obj.GetType();

            MethodInfo m1 = otype.GetMethod("PersistChange");

            return (int)m1.Invoke(obj, new object[] { });
        }
    }
}
