﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Configuration; 

using BVTC.Service.TransferObject.Portal;
using BVTC.Service.Data.Extensions;

namespace BVTC.Service.Data.DAOs
{
    public class SqlExecutorDAO : IDisposable
    {
        private readonly DbContext _cntx;
        private bool _disposed;
        private SqlDataReader _reader;
        private readonly SqlConnection _conn;
        private SqlCommand _cmd;

        public SqlExecutorDAO()
        {
            var str = ConfigurationManager.ConnectionStrings[Common.Constants.KEY_PORTALCONNSTR].ToString();
            _conn = new SqlConnection(str);
            _reader = null;
            _cmd = null;
        }

        public SqlExecutorDAO(DbContext cntx) : this()
        {
            _cntx = cntx;
        }
     
        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    if (_reader != null)
                    {
                        _reader.Close();
                        _reader = null;
                    }
                    
                    if(_conn.State != ConnectionState.Closed)
                    {
                        _conn.Close();
                    }
                }
            }
            _disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        public List<T> ExecuteList<T>(CommandDTO cmdd)
        {
            //_cntx.Database.SqlQuery<T>("sproc",params);

            return null;
        }

        public SqlDataReader GetDataReader(CommandDTO cmdd)
        {
            if (_conn.State == ConnectionState.Closed)
                _conn.Open();

            _cmd = new SqlCommand();
            _cmd.Connection = _conn;
            _cmd.CommandTimeout = Common.Constants.DBCommandTimeout;

            switch (cmdd.Type) {
                case "Report":
                    var rep = _cntx.Set<Models.Portal.Report>().Where(x => x.Id == cmdd.Id).Single();
                    _cmd.CommandText = rep.Statement;
                    _cmd.Parameters.AddRange(GetParams(cmdd.Params).ToArray());

                    break;
                default:
                    break;
            }

            return null;
        }

        public List<EleRowDTO> DB2DTO(SqlDataReader reader)
        {  
            var ret = new List<EleRowDTO>();
            int rid = 0;

            while(reader.Read())
            {
                ++rid;

                for (int i = 0; i < reader.FieldCount; i++)
                {
                    var temp = new EleRowDTO();
                    temp.RowId = rid.ToString();
                    temp.DBName = reader.GetName(i);
                    temp.DataType = reader.GetFieldType(i).GetNonNullType();
                    temp.DataValue = reader.GetValue(i) == null ? Convert.ToString(EntityAttrHelper.GetDefaultValue(reader.GetFieldType(i)))
                                                          : EntityAttrHelper.SetValue(reader.GetValue(i));

                }
            }
          
            return ret;
        }
        public void Execute(CommandDTO cmdd)
        {
            var sql = "";
            switch (cmdd.Type)
            {
                case "SPROC":
                    sql = "exec " + cmdd.Name;
                    break;
                case "QUERY":
                    break;
                default:
                    break;
            }
            var pms = GetParams(cmdd.Params);

            _cntx.Database.ExecuteSqlCommand(sql, pms.ToArray());
        }

        private List<SqlParameter> GetParams(List<Parameter> parameters)
        {
            var ret = new List<SqlParameter>();

            foreach(var p in parameters.Where(x => x.Direction == "Input").ToList())
            {
                Type t = Type.GetType(p.DataType);

                ret.Add(new SqlParameter(p.Name, EntityAttrHelper.GetValue(p.Value, t)));
            }
            return ret;
        }
    }
}
