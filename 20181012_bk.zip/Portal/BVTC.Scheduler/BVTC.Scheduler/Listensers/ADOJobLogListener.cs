﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Common.Logging;
using Quartz;
using Quartz.Listener;

using BVTC.Scheduler.Shared;

namespace BVTC.Scheduler.Listensers
{
    
    public class ADOJobLogListener : JobListenerSupport, IJobLogReport
    {

        public const string STATUS_FAILED = "FAILED";
        public const string STATUS_SUCCESS = "SUCCESS";
        
        private readonly string _connectionString;

        private const string SELECT_COMMAND = "SELECT TOP 100 LOG_DATE,JOB_START,JOB_END,JOB_GROUP,JOB_NAME,SCHEDULE_GROUP,SCHEDULE_NAME,JOB_CLASS_NAME ,JOB_DATA ,STATUS,ERROR_INFO FROM BVTC_JOB_LOG ORDER BY LOG_DATE DESC";
        
        private readonly ILog _logger;
      
        public ADOJobLogListener()
        {

            try
            {
                _logger = LogManager.GetLogger("ADOJobLogListener");

                #region Debug

                Debug.Assert(_logger != null);

                #endregion

            }
            
            catch (Exception)
            {
                //nothing to do here has to be handled or the scheduler state can be corrupted
            }


            try
            {

                ADOLogListenerConfigurationSection configuration = (ADOLogListenerConfigurationSection)ConfigurationManager.GetSection("scheduler/adoLogJobListener");
                
                _connectionString = ConfigurationManager.ConnectionStrings[configuration.ConnectionName].ConnectionString;

                #region Debug

                Debug.Assert(!String.IsNullOrWhiteSpace(_connectionString));

                #endregion

            }
            catch (Exception e)
            {
                _logger.Error("Read configuration", e);
            }
        }

        public override Task JobWasExecuted(IJobExecutionContext context, JobExecutionException jobException, CancellationToken token)
        {
            return Task.CompletedTask;
        }

        public override string Name
        {
            get { return "ADOJobLogListener"; }
        }

        public IEnumerable<JobLogData> GetJobLogData()
        {
            List<JobLogData> results=new List<JobLogData>();
            
            using (IDbConnection connection=new SqlConnection(_connectionString))
            {
                connection.Open();
                using (IDbCommand command=new SqlCommand(SELECT_COMMAND))
                {
                    command.Connection = connection;
                    using (IDataReader reader= command.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                       
                        reader.Close();
                    }
                }
            }

            return results.OrderBy(c => c.LOG_DATE);
        }
    }
}
