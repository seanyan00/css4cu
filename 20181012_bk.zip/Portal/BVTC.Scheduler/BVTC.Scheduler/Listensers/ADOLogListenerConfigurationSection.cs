﻿using System;
using System.Configuration;

namespace BVTC.Scheduler.Listensers
{
    public class ADOLogListenerConfigurationSection : ConfigurationSection
    {
        [ConfigurationProperty("connectionName", IsRequired = true)]
        public String ConnectionName
        {
            get
            {
                return (String)this["connectionName"];
            }
            set
            {
                this["connectionName"] = value;
            }
        }
    

    }
}