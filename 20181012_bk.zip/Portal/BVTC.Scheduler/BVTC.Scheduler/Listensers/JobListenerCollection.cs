﻿using System;
using System.Collections;
using System.Configuration;

namespace BVTC.Scheduler.Listensers
{
    public class JobListenerCollection : ConfigurationElementCollection
    {
        public JobListenerCollection()
        {
        }

        public JobListenerCollection(IComparer comparer) : base(comparer)
        {
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new ListenerElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            ListenerElement listenerElement = (ListenerElement)element;
            return GetKey(listenerElement);
        }

        private static string GetKey(ListenerElement element)
        {
            return element.Name;
        }
    }    
}