﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading;
using System.Threading.Tasks;
using Common.Logging;
using Quartz;
using Quartz.Listener;

namespace BVTC.Scheduler.Listensers
{
    public class SMTPListener: JobListenerSupport
    {

        public const string ON_RUN_EVENT = "notifyemail";
        public const string ON_FAIL_EVENT = "notifyfailemail";
        
        private readonly string _host;
        private readonly string _user;
        private readonly string _password;
        private readonly ILog _logger;
        private readonly string _from;

        private readonly bool _active;

        public SMTPListener()
        {


            try
            {
                _logger = LogManager.GetLogger("ADOJobLogListener");

                #region Debug

                Debug.Assert(_logger != null);

                #endregion

            }
            catch (Exception)
            {
                _active = false;
                return;
            }

            try
            {

                SMTPListenerConfigurationSection configuration = (SMTPListenerConfigurationSection) ConfigurationManager.GetSection("scheduler/smtpJobListener");

                _host = configuration.HostName;
                _from = configuration.From;

                #region Debug

                Debug.Assert(!String.IsNullOrWhiteSpace(_host));
                Debug.Assert(!String.IsNullOrWhiteSpace(_from));

                #endregion

              
                _password = configuration.Password;
                _user = configuration.UserName;

                _active = true;

            }
            catch (Exception e)
            {
                _active = false;
                _logger.Error("Read configuration", e);
            }
        }

        public override Task JobWasExecuted(IJobExecutionContext context, JobExecutionException jobException,  CancellationToken token)
        {

            if (!_active)
                return Task.CompletedTask;

            try
            {
                HashSet<string> toAddresses = ExtractAddress(context,ON_RUN_EVENT);

                if(jobException!=null)
                {
                    HashSet<string> failAddresses = ExtractAddress(context, ON_FAIL_EVENT);
                    toAddresses.UnionWith(failAddresses);
                }


                if (toAddresses.Count != 0)
                {
                    string subject = BuildSubject(context, jobException);
                    string body = BuildBody(context, jobException);

                    MailMessage message = BuildMessage(_from, subject, body, toAddresses);
                    Send(message);

                }

            }
            catch (Exception e)
            {
                _logger.Error(e);
            
            
            }
            return Task.CompletedTask;
        }

        private static HashSet<string> ExtractAddress(IJobExecutionContext context,string eventType)
        {
            
            HashSet<string> addresses=new HashSet<string>();
            
            if(context.MergedJobDataMap.ContainsKey(eventType))
            {
                string s = context.MergedJobDataMap.GetString(eventType);

                foreach (string token in s.Split(','))
                {
                    addresses.Add(token);
                } 
            }

            return addresses;

        }

        private static string BuildSubject(IJobExecutionContext context, JobExecutionException jobException)
        {

            try
            {
                if (jobException==null)
                {
                    return string.Format("[JOB SUCCESS : {0} > {1} : {2}]",DateTime.Now, context.Trigger.JobKey.Group,context.Trigger.JobKey.Name);
                }

                return string.Format("[JOB FAILURE : : {0} > {1} : {2}]", DateTime.Now, context.Trigger.JobKey.Group, context.Trigger.JobKey.Name);

            }
            catch (Exception e)
            {
                return string.Format("ERROR BUILDING SUBJECT : {0}", e.Message);
            }
        
        }

        private static string BuildBody(IJobExecutionContext context, JobExecutionException jobException)
        {
            string body = "Job competion notification";
            body += Environment.NewLine;
            
            try
            {
                body+=string.Format("Run Time : {0}",context.JobRunTime);
                body += Environment.NewLine;
                body += Environment.NewLine;
                body += string.Format("Job Type :{0}",context.JobDetail.JobType.AssemblyQualifiedName);
                body += Environment.NewLine;
                body += Environment.NewLine;
                body += "[Runtime Parameters]"; 
                body+= Environment.NewLine;
                body = context.MergedJobDataMap.Keys.Aggregate(body, (current, key) => current + string.Format("{0} = {1} {2}", key, context.MergedJobDataMap.GetString(key), Environment.NewLine));

                if (jobException != null)
                {
                    body += Environment.NewLine;
                    body += "[Exception information]";
                    body += Environment.NewLine;
                    body += jobException.ToString();
                }
            }
            catch (Exception e)
            {
                body += string.Format(":  ERROR BUILDING BODY  {0}", e.Message);
            }
            
            return body;

        }

        private static MailMessage BuildMessage(string from, string subject, string body, IEnumerable<string> addresses)
        {
            
            MailAddress fromAddress = new MailAddress(from);

            MailMessage message = new MailMessage {BodyEncoding = System.Text.Encoding.UTF8, SubjectEncoding = System.Text.Encoding.UTF8, From = fromAddress, Subject = subject, Body = body};

            foreach (MailAddress to in addresses.Select(address => new MailAddress(address)))
            {
                message.To.Add(to);
            }
            
            return message;
        }

        private void Send(MailMessage message)
        {
            using (SmtpClient client = new SmtpClient(_host))
            {
                if (!string.IsNullOrWhiteSpace(_user))
                {
                    client.Credentials = new NetworkCredential(_user, _password);
                }
                client.Send(message);
            }

        }

        public override string Name
        {
            get { return "SMTP Job Listener"; }
        }
    
    }
}
