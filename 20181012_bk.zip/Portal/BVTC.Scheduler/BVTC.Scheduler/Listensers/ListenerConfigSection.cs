﻿using System.Configuration;

namespace BVTC.Scheduler.Listensers
{
    public class ListenerConfigSection : ConfigurationSection
    {
        [ConfigurationProperty("listeners", IsDefaultCollection = false)]
        [ConfigurationCollection(typeof(JobListenerCollection), AddItemName = "add", ClearItemsName = "clear",
            RemoveItemName = "remove")]
        public JobListenerCollection Listeners
        {
            get
            {
                return (JobListenerCollection)base["listeners"];
            }
        }
    }
}