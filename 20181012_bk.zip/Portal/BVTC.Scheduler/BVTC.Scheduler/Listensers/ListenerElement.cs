﻿using System.Configuration;

namespace BVTC.Scheduler.Listensers
{
    public class ListenerElement : ConfigurationElement
    {

        [ConfigurationProperty("name", IsRequired = true)]
        public string Name
        {
            get
            {
                return (string)this["name"];
            }
            set { this["name"] = value; }
        }


        [ConfigurationProperty("type", IsRequired = true)]
        public string Type
        {
            get
            {
                return (string)this["type"];
            }
            set { this["type"] = value; }
        }

        [ConfigurationProperty("active",  DefaultValue = "true")]
        public bool  Active
        {
            get
            {
                return (bool)this["active"];
            }
            set { this["active"] = value; }
        }

    
    }



}