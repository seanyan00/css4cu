﻿using System;
using System.Configuration;

namespace BVTC.Scheduler.Listensers
{
    public class SMTPListenerConfigurationSection:ConfigurationSection
    {

        [ConfigurationProperty("hostName", IsRequired = true)]
        public String HostName
        {
            get
            {
                return (String)this["hostName"];
            }
            set
            {
                this["hostName"] = value;
            }
        }
        
        [ConfigurationProperty("userName", IsRequired = false ,DefaultValue="")]
        public String UserName
        {
            get
            {
                return (String)this["hostName"];
            }
            set
            {
                this["hostName"] = value;
            }
        }

        [ConfigurationProperty("password", IsRequired = false, DefaultValue = "")]
        public String Password
        {
            get
            {
                return (String)this["password"];
            }
            set
            {
                this["password"] = value;
            }
        }

        [ConfigurationProperty("from", IsRequired = true, DefaultValue = "")]
        public String From
        {
            get
            {
                return (String)this["from"];
            }
            set
            {
                this["from"] = value;
            }
        }

    }
}