﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting;
using System.ServiceModel;
using System.ServiceProcess;
using Common.Logging;
using Quartz;
using Quartz.Impl;
using Quartz.Impl.Matchers;

using BVTC.Scheduler.Listensers;
using BVTC.Scheduler.Shared;
using BVTC.Scheduler.Shared.SimpleMap;

namespace BVTC.Scheduler
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public sealed partial class Scheduler : ServiceBase, ISchedulerService, ISchedulerServiceInfo
    {
        private readonly ILog _logger;
        private IScheduler _scheduler;

        private IJobLogReport _jobLogReport;

        private HashSet<JobType> _jobTypes;

        private const string DEFAULT_GROUP = "DEFAULT";

        private static void Main(string[] args)
        {
            Scheduler service = new Scheduler();

            if (Environment.UserInteractive)
            {
                service.OnStart(args);
                Console.WriteLine(@"Press any key to stop program");
                Console.Read();
                service.OnStop();
            }
            else
            {
                Run(service);
            }
        }

        public Scheduler()
        {

            ServiceName = "BVTC Scheduler";

            _logger = LogManager.GetLogger(ServiceName);

            #region Debug
            Debug.Assert(_logger != null);
            #endregion

            InitializeComponent();
        }

        #region Infrastructure

        private void InitalizeScheduler()
        {
            #region Debug
            Debug.WriteLine(string.Format("Enter : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));
            #endregion

            ISchedulerFactory schedulerFactory = new StdSchedulerFactory();

            _scheduler = schedulerFactory.GetScheduler().Result;

            #region Debug
            Debug.Assert(_scheduler != null);
            #endregion

            #region Debug
            Debug.WriteLine(string.Format("Exit : {0} {1}", MethodBase.GetCurrentMethod().ToString(), DateTime.Now));
            #endregion
        }

        private void InitializeJobLogReport()
        {
            JobLogReportConfigurationSection config = (JobLogReportConfigurationSection)ConfigurationManager.GetSection("scheduler/jobLogReportProvider");

            if (config != null)
            {
                const int typeINdex = 0;
                const int assemblyIndex = 1;

                string[] typeINfo = config.Type.Split(',');
                ObjectHandle objectHandle = Activator.CreateInstance(typeINfo[assemblyIndex], typeINfo[typeINdex], null);
                _jobLogReport = (IJobLogReport)objectHandle.Unwrap();
            }
        }

        private void LoadJobTypes()
        {
            _jobTypes = new HashSet<JobType>();

            DirectoryTypeEnumerator typeEnumerator = new DirectoryTypeEnumerator();

            IEnumerable<Type> enumerable = typeEnumerator.GetTypes(typeof(IJob));

            foreach (Type type in enumerable.Where(e => e.IsAbstract == false))
            {
                object[] customAttributes = type.GetCustomAttributes(true);

                string description = type.Name;

                foreach (JobInfoAttribute infoAttribute in customAttributes.OfType<JobInfoAttribute>())
                {
                    description = infoAttribute.Description;
                }

                JobType t = new JobType(type.AssemblyQualifiedName, description);

                _jobTypes.Add(t);

            }


        }

        private void InitalizeListeners()
        {

            ListenerConfigSection config = (ListenerConfigSection)ConfigurationManager.GetSection("scheduler/jobListeners");

            if (config != null)
            {
                const int typeINdex = 0;
                const int assemblyIndex = 1;

                foreach (ListenerElement l in config.Listeners)
                {
                    if (!l.Active)
                    {
                        continue;
                    }
                    string[] typeINfo = l.Type.Split(',');
                    ObjectHandle objectHandle = Activator.CreateInstance(typeINfo[assemblyIndex], typeINfo[typeINdex], null);
                    _scheduler.ListenerManager.AddJobListener((IJobListener)objectHandle.Unwrap(), new IMatcher<JobKey>[] { EverythingMatcher<JobKey>.AllJobs() });
                }
            }
        }

        #endregion

        #region Service Controls

        protected override void OnStart(string[] args)
        {

            StartScheduler();
            ServiceHost host = new ServiceHost(this);
            host.Open();
        }

        protected override void OnStop()
        {
            StopScheduler();
        }

        protected override void OnContinue()
        {
            ResumeAllJobs();
        }

        protected override void OnPause()
        {
            PauseAllJobs();
        }

        protected override void OnShutdown()
        {
            StopScheduler();
        }

        #endregion

        #region ISchedulerService


        public ServiceResponse StartScheduler()
        {


            #region Debug
            Debug.WriteLine(string.Format("Enter : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));
            #endregion

            ConfigurationManager.RefreshSection("AppSettings");
            ConfigurationManager.RefreshSection("ConnectionStrings");


            ServiceResponse response = new ServiceResponse(MethodBase.GetCurrentMethod().ToString());

            try
            {

                LoadJobTypes();

                InitalizeScheduler();

                #region Debug

                Debug.Assert(_scheduler != null);

                #endregion

                InitalizeListeners();

                InitializeJobLogReport();

                _scheduler.Start();

                response.Success = true;

            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                response.SetError(ex.ToString());
            }


            #region Debug
            Debug.WriteLine(string.Format("Exit : {0} {1}", MethodBase.GetCurrentMethod().ToString(), DateTime.Now));
            #endregion


            return response;
        }

        public ServiceResponse RunJobNow(string jobName)
        {
            return RunJobNow(jobName, DEFAULT_GROUP);
        }

        public ServiceResponse RunScheduleNow(string scheduleName)
        {
            return RunScheduleNow(scheduleName, DEFAULT_GROUP);
        }

        public ServiceResponse RunScheduleNow(string scheduleName, string scheduleGroup)
        {
            #region Debug
            Debug.WriteLine(string.Format("Enter : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));
            Debug.WriteLine(string.Format("scheduleName : {0} {1}", scheduleName, DateTime.Now));
            Debug.WriteLine(string.Format("scheduleGroup : {0} {1}", scheduleGroup, DateTime.Now));
            #endregion

            ServiceResponse response = new ServiceResponse(MethodBase.GetCurrentMethod().ToString());

            try
            {

                ITrigger trigger = _scheduler.GetTrigger(new TriggerKey(scheduleName, scheduleGroup)).Result;

                IJobDetail jobDetail = _scheduler.GetJobDetail(trigger.JobKey).Result;

                JobDataMap map = jobDetail.JobDataMap;

                foreach (KeyValuePair<string, object> keyValuePair in trigger.JobDataMap)
                {

                    if (map.ContainsKey(keyValuePair.Key))
                    {
                        map[keyValuePair.Key] = keyValuePair.Value;
                    }
                    else
                    {
                        map.Add(keyValuePair);
                    }

                }


                _scheduler.TriggerJob(trigger.JobKey, map);

                response.Success = true;

            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                response.SetError(ex.ToString());
            }


            #region Debug
            Debug.WriteLine(string.Format("Exit : {0} {1}", MethodBase.GetCurrentMethod().ToString(), DateTime.Now));
            #endregion


            return response;

        }

        public ServiceResponse RunJobNow(string jobName, string jobGroup)
        {
            #region Debug
            Debug.WriteLine(string.Format("Enter : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));
            Debug.WriteLine(string.Format("jobName : {0} {1}", jobName, DateTime.Now));
            #endregion

            ServiceResponse response = new ServiceResponse(MethodBase.GetCurrentMethod().ToString());

            try
            {

                JobKey jobKey = new JobKey(jobName, jobGroup);

                _scheduler.TriggerJob(jobKey);

                response.Success = true;

            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                response.SetError(ex.ToString());
            }


            #region Debug
            Debug.WriteLine(string.Format("Exit : {0} {1}", MethodBase.GetCurrentMethod().ToString(), DateTime.Now));
            #endregion


            return response;

        }

        public ServiceResponse AddJob(string jobName, string description, string targetType, bool replace, Dictionary<string, object> parms)
        {
            return AddJob(jobName, DEFAULT_GROUP, description, targetType, replace, parms);
        }

        public ServiceResponse AddJob(string jobName, string jobGroupName, string description, string assemblyQualifiedTypeName, bool replace, Dictionary<string, object> parms)
        {

            #region Debug

            Debug.WriteLine(string.Format("Enter : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));
            Debug.WriteLine(string.Format("jobName : {0} {1}", jobName, DateTime.Now));
            Debug.WriteLine(string.Format("jobGroupName : {0} {1}", jobGroupName, DateTime.Now));
            Debug.WriteLine(string.Format("description : {0} {1}", description, DateTime.Now));
            Debug.WriteLine(string.Format("assemblyQualifiedTypeName : {0} {1}", assemblyQualifiedTypeName, DateTime.Now));
            Debug.WriteLine(string.Format("replace : {0} {1}", replace, DateTime.Now));

            #endregion

            ServiceResponse response = new ServiceResponse(MethodBase.GetCurrentMethod().ToString());


            try
            {
                JobKey jobKey = new JobKey(jobName, jobGroupName);

                Type target = Type.GetType(assemblyQualifiedTypeName);

                JobDataMap jdm = new JobDataMap((IDictionary<string, object>)parms ?? new Dictionary<string, object>());

                IJobDetail jobDetail = JobBuilder.Create().WithIdentity(jobKey).WithDescription(description).StoreDurably(true).OfType(target).UsingJobData(jdm).Build();

                _scheduler.AddJob(jobDetail, replace);

                response.Success = true;

            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                response.SetError(ex.ToString());
            }

            #region Debug

            Debug.WriteLine(string.Format("Exit : {0} {1}", MethodBase.GetCurrentMethod().ToString(), DateTime.Now));

            #endregion

            return response;
        }

        public ServiceResponse UnSchedule(string scheduleName, string scheduleGroup)
        {


            #region Debug

            Debug.WriteLine(string.Format("Enter : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));
            Debug.WriteLine(string.Format("scheduleName : {0} {1}", scheduleName, DateTime.Now));
            Debug.WriteLine(string.Format("scheduleGroup : {0} {1}", scheduleGroup, DateTime.Now));

            #endregion

            ServiceResponse response = new ServiceResponse(MethodBase.GetCurrentMethod().ToString());

            try
            {
               // Validator.Demand(() => scheduleName);
              //  Validator.Demand(() => scheduleGroup);


                TriggerKey key = new TriggerKey(scheduleName, scheduleGroup);

                _scheduler.UnscheduleJob(key);

                response.Success = true;

            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                response.SetError(ex.ToString());
            }


            #region Debug

            Debug.WriteLine(string.Format("Exit : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));

            #endregion


            return response;

        }

        public ServiceResponse ScheduleJob(string jobName, string jobGroup, string scheduleName, string scheduleGroup, string description, string cronExpression, Dictionary<string, object> parms)
        {

            #region Debug

            Debug.WriteLine(string.Format("Enter : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));
            Debug.WriteLine(string.Format("jobName : {0} {1}", jobName, DateTime.Now));
            Debug.WriteLine(string.Format("jobGroup : {0} {1}", jobGroup, DateTime.Now));
            Debug.WriteLine(string.Format("scheduleName : {0} {1}", scheduleName, DateTime.Now));
            Debug.WriteLine(string.Format("scheduleGroup : {0} {1}", scheduleGroup, DateTime.Now));
            Debug.WriteLine(string.Format("description : {0} {1}", description, DateTime.Now));
            Debug.WriteLine(string.Format("cronExpression : {0} {1}", cronExpression, DateTime.Now));

            #endregion

            ServiceResponse response = new ServiceResponse(MethodBase.GetCurrentMethod().ToString());

            try
            {
                IJobDetail jobDetail = _scheduler.GetJobDetail(new JobKey(jobName, jobGroup)).Result;

                if (jobDetail != null)
                {

                    JobDataMap jdm = new JobDataMap((IDictionary<string, object>)parms ?? new Dictionary<string, object>());

                    TriggerKey triggerKey;

                    if (string.IsNullOrWhiteSpace(scheduleGroup))
                    {
                        triggerKey = new TriggerKey(scheduleName, DEFAULT_GROUP);
                    }
                    else
                    {
                        triggerKey = new TriggerKey(scheduleName, scheduleGroup);
                    }


                    ITrigger trigger = TriggerBuilder.Create().ForJob(jobDetail).WithDescription(description).UsingJobData(jdm).WithIdentity(triggerKey).WithCronSchedule(cronExpression).Build();

                    _scheduler.ScheduleJob(trigger);

                    response.Success = true;

                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                response.SetError(ex.ToString());
            }


            #region Debug

            Debug.WriteLine(string.Format("Exit : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));

            #endregion

            return response;
        }

        public ServiceResponse ReScheduleJob(string scheduleName, string scheduleGroup, string cronExpression, Dictionary<string, object> parms)
        {

            #region Debug
            Debug.WriteLine(string.Format("Enter : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));
            Debug.WriteLine(string.Format("scheduleName : {0} {1}", scheduleName, DateTime.Now));
            Debug.WriteLine(string.Format("scheduleGroup : {0} {1}", scheduleGroup, DateTime.Now));
            Debug.WriteLine(string.Format("cronExpression : {0} {1}", cronExpression, DateTime.Now));
            #endregion


            ServiceResponse response = new ServiceResponse(MethodBase.GetCurrentMethod().ToString());

            try
            {
                TriggerKey key = new TriggerKey(scheduleName, scheduleGroup);

                ITrigger currentTrigger = _scheduler.GetTrigger(key).Result;

                if (currentTrigger != null)
                {
                    JobDataMap jdm = new JobDataMap((IDictionary<string, object>)parms ?? new Dictionary<string, object>());

                    ITrigger trigger = TriggerBuilder.Create().WithIdentity(key).UsingJobData(jdm).WithDescription(currentTrigger.Description).WithCronSchedule(cronExpression).Build();

                    _scheduler.RescheduleJob(key, trigger);

                    response.Success = true;

                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                response.SetError(ex.ToString());
            }


            #region Debug
            Debug.WriteLine(string.Format("Exit : {0} {1}", MethodBase.GetCurrentMethod().ToString(), DateTime.Now));
            #endregion

            return response;

        }

        public ServiceResponse RemoveJob(string jobName)
        {
            return RemoveJob(jobName, null);
        }

        public ServiceResponse RemoveJob(string jobName, string jobGroup)
        {

            #region Debug
            Debug.WriteLine(string.Format("Enter : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));
            Debug.WriteLine(string.Format("jobName : {0} {1}", jobName, DateTime.Now));
            Debug.WriteLine(string.Format("jobGroup : {0} {1}", jobGroup, DateTime.Now));
            #endregion


            ServiceResponse response = new ServiceResponse(MethodBase.GetCurrentMethod().ToString());

            try
            {
                JobKey key = new JobKey(jobName, jobGroup);
                _scheduler.DeleteJob(key);

                response.Success = true;

            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                response.SetError(ex.ToString());
            }


            #region Debug
            Debug.WriteLine(string.Format("Exit : {0} {1}", MethodBase.GetCurrentMethod().ToString(), DateTime.Now));
            #endregion

            return response;

        }

        public ServiceResponse PauseAllJobs()
        {


            #region Debug
            Debug.WriteLine(string.Format("Enter : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));
            #endregion


            Debug.Assert(_scheduler != null);


            ServiceResponse response = new ServiceResponse(MethodBase.GetCurrentMethod().ToString());

            try
            {
                _scheduler.PauseAll();
                response.Success = true;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                response.SetError(ex.Message);
            }

            #region Debug
            Debug.WriteLine(string.Format("Exit : {0} {1}", MethodBase.GetCurrentMethod().ToString(), DateTime.Now));
            #endregion

            return response;

        }

        public ServiceResponse ResumeAllJobs()
        {

            #region Debug

            Debug.WriteLine(string.Format("Enter : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));

            #endregion

            ServiceResponse response = new ServiceResponse(MethodBase.GetCurrentMethod().ToString());

            Debug.Assert(_scheduler != null);

            try
            {
                _scheduler.ResumeAll();
                response.Success = true;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                response.SetError(ex.Message);
            }

            #region Debug

            Debug.WriteLine(string.Format("Exit : {0} {1}", MethodBase.GetCurrentMethod().ToString(), DateTime.Now));

            #endregion


            return response;
        }

        public ServiceResponse StopScheduler()
        {

            #region Debug
            Debug.WriteLine(string.Format("Enter : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));
            #endregion


            Debug.Assert(_scheduler != null);


            ServiceResponse response = new ServiceResponse(MethodBase.GetCurrentMethod().ToString());

            try
            {
                _scheduler.Shutdown();
                response.Success = true;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                response.SetError(ex.ToString());
            }


            #region Debug
            Debug.WriteLine(string.Format("Exit : {0} {1}", MethodBase.GetCurrentMethod().ToString(), DateTime.Now));
            #endregion

            return response;
        }

        public IEnumerable<JobData> GetJobs()
        {
            #region Debug

            Debug.WriteLine(string.Format("Enter : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));
            Debug.Assert(_scheduler != null);

            #endregion

            List<JobData> jobs = new List<JobData>();

            IList<string> groups = _scheduler.GetJobGroupNames().Result.ToList();

            Debug.Assert(groups != null);

            foreach (string @group in groups)
            {
                IReadOnlyCollection<JobKey> jobKeys = _scheduler.GetJobKeys(GroupMatcher<JobKey>.GroupEquals(group)).Result;

                foreach (JobKey jobKey in jobKeys)
                {
                    IJobDetail jobDetail;

                    try
                    {
                        jobDetail = _scheduler.GetJobDetail(jobKey).Result;

                        if (jobDetail != null)
                        {
                            jobs.Add(new JobData(jobDetail));
                        }

                    }
                    catch (JobPersistenceException e)
                    {
                        JobData jobData = new JobData(jobKey) { JobType = "ERROR LOADING TYPE" };
                        jobs.Add(jobData);
                    }
                }
            }

            #region Debug
            Debug.WriteLine(string.Format("Enter : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));
            #endregion

            return jobs;

        }

        public ServiceState GetServiceState()
        {

            #region Debug
            Debug.WriteLine(string.Format("Enter : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));
            Debug.Assert(_scheduler != null);
            #endregion

            SchedulerMetaData schedulerMetaData = _scheduler.GetMetaData().Result;

            Debug.Assert(schedulerMetaData != null);

            ServiceState state = new ServiceState(schedulerMetaData);


            #region Debug
            Debug.WriteLine(string.Format("Enter : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));
            #endregion


            return state;

        }

        public IEnumerable<JobType> GetJobTypes()
        {
            return _jobTypes;
        }

        public IEnumerable<JobData> GetExecutingJobs()
        {

            #region Debug
            Debug.WriteLine(string.Format("Enter : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));
            Debug.Assert(_scheduler != null);
            #endregion

            List<JobData> jobs = new List<JobData>();

            IReadOnlyCollection<IJobExecutionContext> executionContexts = _scheduler.GetCurrentlyExecutingJobs().Result;

            Debug.Assert(executionContexts != null);


            foreach (IJobExecutionContext executionContext in executionContexts)
            {

                IJobDetail jobDetail = executionContext.JobDetail;

                JobData jobData = new JobData(jobDetail, executionContext.MergedJobDataMap);

                jobs.Add(jobData);

            }



            #region Debug
            Debug.WriteLine(string.Format("Enter : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));
            #endregion

            return jobs;

        }

        public IEnumerable<ScheduledData> GetSchedules()
        {

            #region Debug

            Debug.WriteLine(string.Format("Enter : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));
            Debug.Assert(_scheduler != null);

            #endregion

            List<ScheduledData> triggers = new List<ScheduledData>();

            var groups = _scheduler.GetTriggerGroupNames().Result;

            Debug.Assert(groups != null);

            foreach (string @group in groups)
            {
                var triggerKeys = _scheduler.GetTriggerKeys(GroupMatcher<TriggerKey>.GroupEquals(group)).Result;


                foreach (TriggerKey triggerKey in triggerKeys)
                {
                    try
                    {
                        ITrigger trigger = _scheduler.GetTrigger(triggerKey).Result;

                        if (trigger != null)
                        {
                            ScheduledData scheduledData = new ScheduledData(trigger);

                            triggers.Add(scheduledData);
                        }

                    }
                    catch (JobPersistenceException e)
                    {
                        ScheduledData scheduledData = new ScheduledData(triggerKey) { Description = "ERROR LOADING" };
                        triggers.Add(scheduledData);
                    }
                }
            }

            #region Debug
            Debug.WriteLine(string.Format("Enter : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));
            #endregion

            return triggers;


        }

        public IEnumerable<JobLogData> GetJobLogData()
        {

            #region Debug

            Debug.WriteLine(string.Format("Enter : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));
            Debug.Assert(_scheduler != null);

            #endregion

            if (_jobLogReport != null)
            {
                return _jobLogReport.GetJobLogData();
            }

            return new List<JobLogData>();


            #region Debug
            Debug.WriteLine(string.Format("Enter : {0} {1}", MethodBase.GetCurrentMethod(), DateTime.Now));
            #endregion

        }

        #endregion

    }









}