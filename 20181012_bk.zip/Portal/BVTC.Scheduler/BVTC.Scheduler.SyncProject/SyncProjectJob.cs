﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using Quartz;
using log4net;
using Pervasive.Data.SqlClient;

using BVTC.Scheduler.Shared;
using BVTC.Scheduler.Shared.Jobs;

namespace BVTC.Scheduler.Jobs.SyncProject
{
    [JobInfo(" Sync Project and Customer from cTrac ")]
    public class SyncProjectJob : IJob
    {
        #region Constants
        private const string CONN_STR_NAME = "connection";
        private const string PSQL_CONN = "psqlconn";
        
        #endregion

        private ILog log = LogManager.GetLogger("EmailNotifications");


        public Task Execute(IJobExecutionContext context)
        {

            string connectionName = context.MergedJobDataMap.GetString(CONN_STR_NAME);
            string pconnstrname = context.MergedJobDataMap.GetString(PSQL_CONN);
          
            ConnectionStringSettings connectionStringSettings = ConfigurationManager.ConnectionStrings[connectionName];
                                   
            if (connectionStringSettings == null)
            {
                log.Debug("No connection string named " + connectionName + " was found");
                throw new ApplicationException(string.Format("No connection named {0} has been configured", connectionName));
            }
            else if (string.IsNullOrEmpty(pconnstrname))
            {
                log.Debug("No Paramters Found. PSQL connection not found!!!");
                throw new ApplicationException("No Parameter found. (psql connection) ");
            }
          
            string connectionString = connectionStringSettings.ConnectionString;
            string pconnstr = ConfigurationManager.ConnectionStrings[pconnstrname].ConnectionString;

            var phlist = new List<Models.ProjectHeader>();
            var custlist = new List<Models.Customer>();
            var batchts = DateTime.Now;

            try
            {
                using (var pconn = new PsqlConnection(pconnstr))
                {
                    pconn.Open();
                 
                    string sql = "select \"Project Number\", \"Short Description\", \"Project Description\",  \"Customer Number\","
                                + "\"Project Mgr Init\", \"Project Status\", \"Scheduled Completion\", \"Product Line\", \"PCode\","
                                + "\"Date Authorized\", \"Date Entered\", \"Contact Phone\" as ShipToPhone, \"Estimated Units\",\"Est Number Shipments\","
                                + "\"ShipTo Name\", \"ShipTo Address\", \"ShipTo Spec Instr\", \"ShipTo City\", \"ShipTo State\"," 
                                + "\"ShipTo Zip\", \"Contact Proj Mgr Nam\", \"Proj Mgr Phone\", \"Proj Mgr Email\","
                                + "\"Contact Name\", \"Contact Phone\", \"Contact Email\", \"Contact Fax\""
                                + " from \"Project Master Heade\";";
                 
                    var pcmd = new PsqlCommand(sql, pconn);
                    pcmd.CommandTimeout = 600;
                    PsqlDataReader reader = pcmd.ExecuteReader();

                    while (reader.Read())
                    {
                        phlist.Add(new Models.ProjectHeader {
                            ProjectNo = reader.GetString(0),
                            ShortDesc = SafeGetString(reader, 1),
                            Description = SafeGetString(reader, 2),
                            CustomerNo = SafeGetString(reader, 3),
                            BVTCPM = SafeGetString(reader, 4),
                            Status = SafeGetString(reader, 5),
                            SchCompletionDate = SafeGetDateTime(reader, 6),
                            ProductLine = SafeGetString(reader, 7),
                            Code = SafeGetString(reader, 8),
                            AuthDate = SafeGetDateTime(reader, 9),
                            EnterDate = SafeGetDateTime(reader, 10),
                            ShipToPhone = SafeGetString(reader, 11),
                            EstUnits = reader.IsDBNull(12) ? 0 : reader.GetInt32(12),
                            EstTotalShipment = reader.IsDBNull(13) ? 0 : reader.GetInt32(13),
                            ShipToName = SafeGetString(reader, 14),
                            ShipToAddress = SafeGetString(reader, 15),
                            ShippingInst = SafeGetString(reader, 16),
                            ShipToCity = SafeGetString(reader, 17),
                            ShipToState = SafeGetString(reader, 18),
                            ShipToZip = SafeGetString(reader, 19),
                            ClientPMName = SafeGetString(reader, 20),
                            ClientPMPhone = SafeGetString(reader, 21),
                            ClientPMEmail = SafeGetString(reader, 22),
                            ContactName = SafeGetString(reader, 23),
                            ContactPhone = SafeGetString(reader, 24),
                            ContactEmail = SafeGetString(reader, 25),
                            ContactFax = SafeGetString(reader, 26)
                        });
                    }
                    reader.Close();

                    sql = "select \"Customer Number\", \"Name\", \"Bill To Address\", \"Bill To Address 2\", \"Bill To City\","
                        + "\"Bill To State\", \"Bill To Zip\", \"Primary Phone\", \"Primary Fax\", \"Primary Contact\", \"Main Email\","
                        + "\"Billing Email\", \"Billing Contact\", \"Billing Phone\", \"Billing Phone Ext\", \"Customer Since\","
                        + "\"Ship-To Name\", \"Ship-To Address\", \"Ship-To City\", \"Ship-To State\", \"Ship-To Zip\","
                        + "\"Ship-To Contact\", \"Ship-To Spec Instruc\""
                        + " from \"Customer Master File\";";
                    pcmd.CommandText = sql;
                    pcmd.Parameters.Clear();
                    reader = pcmd.ExecuteReader();

                    while (reader.Read())
                    {
                        custlist.Add(new Models.Customer {
                            CustNo = SafeGetString(reader, 0),
                            Name = SafeGetString(reader, 1),
                            BillingAddress1 = SafeGetString(reader, 2),
                            BillingAddress2 = SafeGetString(reader, 3),
                            BillingCity = SafeGetString(reader, 4),
                            BillingStateCode = SafeGetString(reader, 5),
                            BillingZip = SafeGetString(reader, 6),
                            Phone = SafeGetString(reader, 7),
                            Fax = SafeGetString(reader, 8),
                            Contact = SafeGetString(reader, 9),
                            Email = SafeGetString(reader, 10),
                            BillingEmail = SafeGetString(reader, 11),
                            BillingContact = SafeGetString(reader, 12),
                            BillingPhone = SafeGetString(reader, 13) + (string.IsNullOrEmpty(SafeGetString(reader, 14)) 
                                                                                            ? "" : " " + SafeGetString(reader, 14)),
                            CustSince = SafeGetDateTime(reader, 15),
                            ShippingName = SafeGetString(reader, 16),
                            ShippingAddress1 = SafeGetString(reader, 17),
                            ShippingCity = SafeGetString(reader, 18),
                            ShipingStateCode = SafeGetString(reader, 19),
                            ShipingZip = SafeGetString(reader, 20),
                            ShippingContact = SafeGetString(reader, 21),
                            ShippingInstruction = SafeGetString(reader, 22)
                        });
                    }
                    reader.Close();
                }

                // no trans control. once extraction failed, no further steps will be executed
                using (var conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = "truncate table dbo.Temp_ProjectHeader;";

                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandTimeout = 600;
                  
                    cmd.ExecuteNonQuery();
                    
                    sql = "insert into dbo.Temp_ProjectHeader(ProjectNo, ShortDesc, Description, CustomerNo, BVTCPM, Status,"
                               + " SchCompletionDate, ProductLine, Code, AuthDate, EnterDate, ShipToName, ShipToAddress, ShippingInst,"
                               + " ShipToCity, ShipToState, ShipToZip, EstUnits, EstTotalShipment, ShipToPhone, ClientPMName,"
                               + " ClientPMPhone, ClientPMEmail, ContactName, ContactPhone, ContactEmail, ContactFax, BatchTS)"
                               + " values(@ProjectNo, @ShortDesc, @Description, @CustomerNo, @BVTCPM, @Status,"
                               + " @SchCompletionDate, @ProductLine, @Code, @AuthDate, @EnterDate, @ShipToName, @ShipToAddress, @ShippingInst,"
                               + " @ShipToCity, @ShipToState, @ShipToZip, @EstUnits, @EstTotalShipment, @ShipToPhone, @ClientPMName,"
                               + " @ClientPMPhone, @ClientPMEmail, @ContactName, @ContactPhone, @ContactEmail, @ContactFax, @BatchTS)";

                    cmd.Parameters.Clear();
                    cmd.CommandText = sql;
                  
                    foreach (var v in phlist)
                    {
                        cmd.Parameters.Clear();
                        cmd.Parameters.Add("@ProjectNo", SqlDbType.VarChar, 25).Value = v.ProjectNo;
                        cmd.Parameters.Add("@ShortDesc", SqlDbType.VarChar, 200).Value = v.ShortDesc;
                        cmd.Parameters.Add("@Description", SqlDbType.VarChar, 500).Value = v.Description;
                        cmd.Parameters.Add("@CustomerNo", SqlDbType.VarChar, 50).Value = v.CustomerNo;
                        cmd.Parameters.Add("@BVTCPM", SqlDbType.VarChar, 100).Value = v.BVTCPM;
                        cmd.Parameters.Add("@Status", SqlDbType.VarChar, 50).Value = v.Status;
                        cmd.Parameters.Add("@SchCompletionDate", SqlDbType.DateTime).Value = v.SchCompletionDate;
                        cmd.Parameters.Add("@ProductLine", SqlDbType.Char, 2).Value = v.ProductLine;
                        cmd.Parameters.Add("@Code", SqlDbType.VarChar, 25).Value = v.Code;
                        cmd.Parameters.Add("@AuthDate", SqlDbType.DateTime).Value = v.AuthDate;
                        cmd.Parameters.Add("@EnterDate", SqlDbType.DateTime).Value = v.EnterDate;
                        cmd.Parameters.Add("@ShipToName", SqlDbType.VarChar, 150).Value = v.ShipToName;
                        cmd.Parameters.Add("@ShipToAddress", SqlDbType.VarChar, 200).Value = v.ShipToAddress;
                        cmd.Parameters.Add("@ShippingInst", SqlDbType.VarChar, 500).Value = v.ShippingInst;
                        cmd.Parameters.Add("@ShipToCity", SqlDbType.VarChar, 100).Value = v.ShipToCity;
                        cmd.Parameters.Add("@ShipToState", SqlDbType.VarChar, 10).Value = v.ShipToState;
                        cmd.Parameters.Add("@ShipToZip", SqlDbType.VarChar, 20).Value = v.ShipToZip;
                        cmd.Parameters.Add("@EstUnits", SqlDbType.Int).Value = v.EstUnits;
                        cmd.Parameters.Add("@EstTotalShipment", SqlDbType.Int).Value = v.EstTotalShipment;
                        cmd.Parameters.Add("@ShipToPhone", SqlDbType.VarChar, 200).Value = v.ShipToPhone;
                        cmd.Parameters.Add("@ClientPMName", SqlDbType.VarChar, 150).Value = v.ClientPMName;
                        cmd.Parameters.Add("@ClientPMPhone", SqlDbType.VarChar, 50).Value = v.ClientPMPhone;
                        cmd.Parameters.Add("@ClientPMEmail", SqlDbType.VarChar, 100).Value = v.ClientPMEmail;
                        cmd.Parameters.Add("@ContactName", SqlDbType.VarChar, 150).Value = v.ContactName;
                        cmd.Parameters.Add("@ContactPhone", SqlDbType.VarChar, 50).Value = v.ContactPhone;
                        cmd.Parameters.Add("@ContactEmail", SqlDbType.VarChar, 100).Value = v.ContactEmail;
                        cmd.Parameters.Add("@ContactFax", SqlDbType.VarChar, 50).Value = v.ContactFax;
                        cmd.Parameters.Add("@BatchTS", SqlDbType.DateTime).Value = batchts;

                        cmd.ExecuteNonQuery();
                    }

                    cmd.Parameters.Clear();
                    sql = "truncate table dbo.Temp_Customer;";

                    cmd.CommandText = sql;
                    cmd.ExecuteNonQuery();

                    cmd.Parameters.Clear();
                    sql = "insert into dbo.Temp_Customer(CustNo, Name, Contact, Phone, Fax, Email, ShippingName, ShippingAddress1,"
                         + "ShippingCity, ShipingStateCode, ShipingZip, ShippingInstruction, BillingAddress1, BillingAddress2, BillingCity,"
                         + "BillingStateCode, BillingZip, CustSince, BillingEmail, BillingPhone, Status, BillingContact, ShippingContact, BatchTS)"
                         + " values(@CustNo, @Name, @Contact, @Phone, @Fax, @Email,"
                         + " @ShippingName, @ShippingAddress1, @ShippingCity, @ShipingStateCode, @ShipingZip, @ShippingInstruction,"
                         + " @BillingAddress1, @BillingAddress2, @BillingCity, @BillingStateCode, @BillingZip, @CustSince, @BillingEmail,"
                         + " @BillingPhone, @Status, @BillingContact, @ShippingContact, @BatchTS)";

                    cmd.CommandText = sql;

                    foreach (var v in custlist)
                    {
                        cmd.Parameters.Clear();
                        cmd.Parameters.Add("@CustNo", SqlDbType.VarChar, 50).Value = v.CustNo;
                        cmd.Parameters.Add("@Name", SqlDbType.VarChar, 100).Value = v.Name;
                        cmd.Parameters.Add("@Contact", SqlDbType.VarChar, 150).Value = v.Contact;
                        cmd.Parameters.Add("@Phone", SqlDbType.VarChar, 50).Value = v.Phone;
                        cmd.Parameters.Add("@Fax", SqlDbType.VarChar, 25).Value = v.Fax;
                        cmd.Parameters.Add("@Email", SqlDbType.VarChar, 100).Value = v.Email;
                        cmd.Parameters.Add("@ShippingName", SqlDbType.VarChar, 100).Value = v.ShippingName;
                        cmd.Parameters.Add("@ShippingAddress1", SqlDbType.VarChar, 250).Value = v.ShippingAddress1;
                        cmd.Parameters.Add("@ShippingCity", SqlDbType.VarChar, 100).Value = v.ShippingCity;
                        cmd.Parameters.Add("@ShipingStateCode", SqlDbType.VarChar, 10).Value = v.ShipingStateCode;
                        cmd.Parameters.Add("@ShipingZip", SqlDbType.VarChar, 15).Value = v.ShipingZip;
                        cmd.Parameters.Add("@ShippingInstruction", SqlDbType.VarChar, 500).Value = v.ShippingInstruction;
                        cmd.Parameters.Add("@BillingAddress1", SqlDbType.VarChar, 250).Value = v.BillingAddress1;
                        cmd.Parameters.Add("@BillingAddress2", SqlDbType.VarChar, 250).Value = v.BillingAddress2;
                        cmd.Parameters.Add("@BillingCity", SqlDbType.VarChar, 100).Value = v.BillingCity;
                        cmd.Parameters.Add("@BillingStateCode", SqlDbType.VarChar, 10).Value = v.BillingStateCode;
                        cmd.Parameters.Add("@BillingZip", SqlDbType.VarChar, 15).Value = v.BillingZip;
                        cmd.Parameters.Add("@CustSince", SqlDbType.DateTime).Value = v.CustSince;
                        cmd.Parameters.Add("@BillingEmail", SqlDbType.VarChar, 100).Value = v.BillingEmail;
                        cmd.Parameters.Add("@BillingPhone", SqlDbType.VarChar, 25).Value = v.BillingPhone;
                        cmd.Parameters.Add("@Status", SqlDbType.Bit).Value = 1;
                        cmd.Parameters.Add("@BillingContact", SqlDbType.VarChar, 150).Value = v.BillingContact;
                        cmd.Parameters.Add("@ShippingContact", SqlDbType.VarChar, 150).Value = v.ShippingContact;
                        cmd.Parameters.Add("@BatchTS", SqlDbType.DateTime).Value = batchts;

                        cmd.ExecuteNonQuery();
                    }

                    sql = "exec dbo.sprocDailyCtracMerge;";

                    cmd.Parameters.Clear();
                    cmd.CommandText = sql;

                    cmd.ExecuteNonQuery();
                    
                }

                return Task.CompletedTask;
            }
            catch (Exception exp)
            {
                throw new ApplicationException(exp.Message);
            }
        }

        private string SafeGetString(PsqlDataReader reader, int idx)
        {
            if (!reader.IsDBNull(idx))
                    return reader.GetString(idx);
            return string.Empty;
        }
        private DateTime SafeGetDateTime(PsqlDataReader reader, int idx)
        {
            if (!reader.IsDBNull(idx) && !(reader.GetString(idx).IndexOf("0000") == 0))
                return DateTime.ParseExact(reader.GetString(idx), "yyyyMMdd", null);

            return new DateTime(1753, 1, 2);
        }
    }
}
