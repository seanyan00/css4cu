﻿using System;

namespace BVTC.Scheduler.Jobs.SyncProject.Models
{
    public class ProjectHeader
    {
        public string ProjectNo { get; set; }
        public string ShortDesc { get; set; }
        public string Description { get; set; }
        public string CustomerNo { get; set; }
        public string BVTCPM { get; set; }
        public string Status { get; set; }
        public DateTime SchCompletionDate { get; set; }
        public string ProductLine { get; set; }
        public string Code { get; set; }
        public DateTime AuthDate { get; set; }
        public DateTime EnterDate { get; set; }
        public string ShipToName { get; set; }
        public string ShipToAddress { get; set; }
        public string ShippingInst { get; set; }
        public string ShipToCity { get; set; }
        public string ShipToState { get; set; }
        public string ShipToZip { get; set; }
        public int EstUnits { get; set; }
        public int EstTotalShipment { get; set; }
        public string ShipToPhone { get; set; }
        public string ClientPMName { get; set; }
        public string ClientPMPhone { get; set; }
        public string ClientPMEmail { get; set; }
        public string ContactName { get; set; }
        public string ContactPhone { get; set; }
        public string ContactEmail { get; set; }
        public string ContactFax { get; set; }
  
    }

    public class Customer
    {
        public string CustNo { get; set; }
        public string Name { get; set; }
        public string Contact { get; set; }
	    public string Phone { get; set; }
	    public string Fax { get; set; }
	    public string Email { get; set; }
	    public string ShippingName { get; set; }
	    public string ShippingAddress1 { get; set; }
	  	public string ShippingCity { get; set; }
	    public string ShipingStateCode { get; set; }
	    public string ShipingZip { get; set; }
	    public string ShippingInstruction { get; set; }
	    public string BillingAddress1 { get; set; }
	    public string BillingAddress2 { get; set; }
	    public string BillingCity { get; set; }
	    public string BillingStateCode { get; set; }
	    public string BillingZip { get; set; }
		public DateTime CustSince { get; set; }
	    public string BillingEmail { get; set; }
	    public string BillingPhone { get; set; }
	    public bool Status { get; set; }
        public string BillingContact { get; set; }
        public string ShippingContact { get; set; }
    }
}
