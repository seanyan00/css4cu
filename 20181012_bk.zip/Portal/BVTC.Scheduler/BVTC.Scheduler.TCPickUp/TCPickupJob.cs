﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Threading.Tasks;
using System.Diagnostics;
using System.IO;

using Quartz;
using log4net;

using BVTC.Scheduler.Shared;
using BVTC.Scheduler.Shared.Data;

namespace BVTC.Scheduler.Jobs.TCPickUp
{
    [JobInfo(" TC Pick List")]
    public class TCPickUpJob : IJob
    {
        #region Constants
        private const string CONN_STR_NAME = "connection";
        private const string PERIOD = "period";
        private const string SENDTO = "sendto";
        private const string FROM = "from";

        private const string KEY_FILEROOT = "fileroot";
        #endregion

        private ILog log = LogManager.GetLogger("TCPickUp");      
        
        public Task Execute(IJobExecutionContext context)
        {
            string connectionName = context.MergedJobDataMap.GetString(CONN_STR_NAME);
            string period = context.MergedJobDataMap.GetString(PERIOD);
            string sendto = context.MergedJobDataMap.GetString(SENDTO);
            string from = context.MergedJobDataMap.GetString(FROM);

            ConnectionStringSettings connectionStringSettings = ConfigurationManager.ConnectionStrings[connectionName];

            string fpath = ConfigurationManager.AppSettings[KEY_FILEROOT].ToString();
            fpath = Path.Combine(fpath, "WeeklyTCPick_" + DateTime.Now.ToString("yyyyMMdd") + ".csv");
            if (File.Exists(fpath))
                File.Delete(fpath);

            //Validate job parameters 
            if (connectionStringSettings == null)
            {
                log.Debug("No connection string named " + connectionName + " was found");
                throw new ApplicationException(string.Format("No connection named {0} has been configured", connectionName));
            }
            else if (string.IsNullOrEmpty(sendto))
            {
                log.Debug("No Paramters Found. Email Notification details not found!!!");
                throw new ApplicationException("No Parameter found. (sendto) ");
            }
            else if (string.IsNullOrEmpty(from))
            {
                log.Debug("No Paramters Found. Email Sender not found!!!");
                throw new ApplicationException("No Parameter found. (from) ");
            }
            else if (string.IsNullOrEmpty(period))
            {
                log.Debug("No Paramters Found. Period not found!!!");
                throw new ApplicationException("No Parameter found. (period) ");
            }
           
            string connectionString = connectionStringSettings.ConnectionString;

            string connectionStringName = context.MergedJobDataMap.GetString(CONN_STR_NAME);
            connectionString = ConfigurationManager.ConnectionStrings[connectionStringName].ConnectionString;    

            try
            {
                DataSet ds = new DataSet();
                using (var conn = new SqlConnection(connectionString))
                {
                    var cmd = new SqlCommand("dbo.sprocGetTCActions", conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    StringBuilder sb = new StringBuilder();
                    StreamWriter sw = new StreamWriter(fpath);

                    conn.Open();
                    var reader = cmd.ExecuteReader();

                    var columnNames = Enumerable.Range(0, reader.FieldCount)
                        .Select(reader.GetName)  
                        .ToList();
                    
                    sb.Append(string.Join(",", columnNames));
                    sb.AppendLine();

                    while (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            string value = reader[i].ToString();
                            if (value.Contains(","))
                                value = "\"" + value + "\"";

                            sb.Append(value.Replace(Environment.NewLine, " ") + ",");
                        }
                        sb.Length--;
                        sb.AppendLine();
                    }

                    reader.Close();
                    sw.Write(sb.ToString());
                    sw.Close();
                }

                Email email = new Email{
                    Subject = "Week of " + DateTime.Now.ToString("yyyyMMdd") + " Track&Clip Pick List",
                    Attachment = fpath,
                    Body = "",
                    CCEmail = "",
                    FromEMail = from,
                    ToEmail = sendto
                };

                email.SendEmail();
                                      
                return Task.CompletedTask;
            }
            catch (Exception exp)
            {
                throw new ApplicationException(exp.Message);
            }
        }
    }
}
