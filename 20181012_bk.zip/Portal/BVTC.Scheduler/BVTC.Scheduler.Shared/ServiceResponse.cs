﻿using System;
using System.Runtime.Serialization;

namespace BVTC.Scheduler.Shared
{
    [DataContract]
    public class ServiceResponse
    {
        public ServiceResponse()
        {
        }

        public ServiceResponse(string action)
        {
            Action = action;
        }

        [DataMember]
        public String Action { get; set; }

        [DataMember]
        public bool Success { get; set; }
        [DataMember]
        public string Error { get; set; }

        public void SetError(string message)
        {
            Success = false;
            Error = message;
        }
    }
}