﻿namespace BVTC.Scheduler.Shared
{
    //public interface IJobTypeMetadataProvider
    //{
    //    string Description { get; set; }
    //}
}