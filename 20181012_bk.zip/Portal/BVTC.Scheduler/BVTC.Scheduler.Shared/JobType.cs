﻿using System.Runtime.Serialization;

namespace BVTC.Scheduler.Shared
{
    [DataContract]
    public class JobType
    {
        public JobType()
        {
        }

        public JobType(string typeName, string description)
        {
            AssemblyQualifiedTypeName = typeName;
            Description = description;
        }

        [DataMember]
        public string AssemblyQualifiedTypeName { get; set; }

        [DataMember]
        public string Description { get; set; }


        public bool Equals(JobType other)
        {
            if (ReferenceEquals(null, other))
            {
                return false;
            }
            if (ReferenceEquals(this, other))
            {
                return true;
            }
            return Equals(other.AssemblyQualifiedTypeName, AssemblyQualifiedTypeName);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj))
            {
                return false;
            }
            if (ReferenceEquals(this, obj))
            {
                return true;
            }
            if (obj.GetType() != typeof (JobType))
            {
                return false;
            }
            return Equals((JobType) obj);
        }

        public override int GetHashCode()
        {
            return (AssemblyQualifiedTypeName != null ? AssemblyQualifiedTypeName.GetHashCode() : 0);
        }
    }
}