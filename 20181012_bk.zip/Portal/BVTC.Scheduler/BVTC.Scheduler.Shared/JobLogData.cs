﻿using System;
using System.Runtime.Serialization;

namespace BVTC.Scheduler.Shared
{
    [DataContract]
    public class JobLogData
    {
        [DataMember]
        public DateTime LOG_DATE { get; set; }
        [DataMember]
        public DateTime JOB_START { get; set; }
        [DataMember]
        public DateTime? JOB_END { get; set; }
        [DataMember]
        public string JOB_GROUP { get; set; }
        [DataMember]
        public string JOB_NAME { get; set; }
        [DataMember]
        public string SCHEDULE_GROUP { get; set; }
        [DataMember]
        public string SCHEDULE_NAME { get; set; }
        [DataMember]
        public string JOB_CLASS_NAME { get; set; }
        [DataMember]
        public string JOB_DATA { get; set; }
        [DataMember]
        public string STATUS { get; set; }
        [DataMember]
        public string ERROR_INFO { get; set; }
    }
}