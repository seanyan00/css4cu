﻿using System.Collections.Generic;
using System.ServiceModel;

namespace BVTC.Scheduler.Shared
{
    [ServiceContract]
    public interface ISchedulerService
    {

        [OperationContract]
        ServiceResponse RunScheduleNow(string scheduleName, string scheduleGroup);

        [OperationContract]
        ServiceResponse RunJobNow(string jobName, string jobGroup);
        
        [OperationContract]
        ServiceResponse AddJob(string jobName, string jobGroupName, string description, string assemblyQualifiedTypeName, bool replace, Dictionary<string, object> dataMap);

        [OperationContract]
        ServiceResponse UnSchedule(string scheduleName, string scheduleGroup);
        
        [OperationContract]
        ServiceResponse ScheduleJob(string jobName, string jobGroup, string scheduleName, string scheduleGroup, string description, string cronExpression, Dictionary<string, object> parms);
        
        [OperationContract]
        ServiceResponse ReScheduleJob(string scheduleName, string scheduleGroup, string chronExpression, Dictionary<string, object> parms);
        
        [OperationContract]
        ServiceResponse RemoveJob(string jobName, string jobGroup);
        
        [OperationContract]
        ServiceResponse PauseAllJobs();
        
        [OperationContract]
        ServiceResponse ResumeAllJobs();
        
        [OperationContract]
        ServiceResponse StopScheduler();

        [OperationContract]
        ServiceResponse StartScheduler();

    }

    [ServiceContract]
    public interface ISchedulerServiceInfo
    {
        [OperationContract]
        ServiceState GetServiceState();

        [OperationContract]
        IEnumerable<JobType> GetJobTypes();

        [OperationContract]
        IEnumerable<JobData> GetExecutingJobs();

        [OperationContract]
        IEnumerable<JobData> GetJobs();

        [OperationContract]
        IEnumerable<ScheduledData> GetSchedules();

        [OperationContract]
        IEnumerable<JobLogData> GetJobLogData();
    
        
    }



}