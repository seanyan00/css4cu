﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BVTC.Scheduler.Shared.Base
{
    public interface IRecordActions
    {
        bool TrimValues(string[] record, char[] sValue);
        bool FilterStartsWith(string[] record, int colIndex, string sFilter);
        bool FilterEndsWith(string[] record, int colIndex, string sFilter);
        bool FilterEmpty(string[] record, int colIndex, string sFilter);
        bool ChangeValueIfEqual(string[] record, int colIndex, string sFilter, string replaceVal);
    }
}
