﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BVTC.Scheduler.Shared.Base
{
    public class DataFileObject
    {
        public DataFileObject()
        {
            inputPath = "";
            delimiter = ',';
            skipHeader = false;
        }
        public string inputPath { get; set; }
        public char delimiter { get; set; }
        public bool skipHeader { get; set; }
        public ICollection<Type> fieldTypeMapping { get; set; }
    }
}
