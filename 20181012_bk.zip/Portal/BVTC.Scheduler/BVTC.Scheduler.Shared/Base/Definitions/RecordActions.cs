﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BVTC.Scheduler.Shared.Base.Definitions
{
    public class RecordActions : IRecordActions
    {
        //Not used yet.. still working on this class to allow options on manipulating reading records from a file


        /// <summary>
        /// Modifies a record's field values.
        /// </summary>
        /// <param name="record"></param>
        public bool TrimValues(string[] record, char[] sValue)
        {
            record[0] = record[0].TrimStart(sValue).TrimEnd(sValue);
            record[record.Length - 1] = record[record.Length - 1].TrimStart(sValue).TrimEnd(sValue);
            return true;
            /*
            for (int i = 0; i < record.Length; i++)
            {
                record[i] = record[i].TrimStart('"').TrimEnd('"');
            }
            return true;
             */
        }

        public bool FilterStartsWith(string[] record, int colIndex, string sFilter)
        {

            if (!(record[colIndex].TrimEnd().StartsWith(sFilter)))
            {
                return false;
            }

            return true;
        }

        public bool FilterEndsWith(string[] record, int colIndex, string sFilter)
        {
            if (!(record[colIndex].TrimEnd().EndsWith(sFilter)))
            {
                return false;
            }

            return true;
        }

        public bool FilterEmpty(string[] record, int colIndex, string sFilter)
        {
            if (string.IsNullOrWhiteSpace(record[colIndex]))
            {
                return false;
            }

            return true;
        }

        public bool ChangeValueIfEqual(string[] record, int colIndex, string sFilter, string replaceVal)
        {
            if (record[colIndex].ToLower() == sFilter)
            {
                record[colIndex] = replaceVal;
            }

            return true;
        }
    }
}
