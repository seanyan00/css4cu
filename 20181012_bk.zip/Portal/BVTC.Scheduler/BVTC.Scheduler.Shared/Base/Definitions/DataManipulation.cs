﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;

namespace BVTC.Scheduler.Shared.Base.Definitions
{
    public class DataManipulation : IDataManipulation
    {
        public string _connectionStringName = "";
        public int _commandTimeout = 0;

        public void TruncateTable(DataTableObject tObj)
        {
            // delete current data
            using (SqlConnection connection = new SqlConnection(tObj.connectionString))
            {
                connection.Open();
                using (SqlCommand command = connection.CreateCommand())
                {
                    command.CommandTimeout = tObj.connectionTimeOut;
                    command.CommandText = String.Format("DELETE FROM {0}", tObj.tableName);
                    command.ExecuteNonQuery();
                }
            }
        }

        public void ExecuteNonQueryStoredProc(DataTableObject tObj, string storedProcName, List<SqlParameter> paramList = null)
        {
            // delete current data
            using (SqlConnection connection = new SqlConnection(tObj.connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(storedProcName, connection))
                {
                    command.CommandTimeout = tObj.connectionTimeOut;
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Clear();
                    if (paramList != null)
                    {
                        command.Parameters.AddRange(paramList.ToArray());
                    }
                    command.ExecuteNonQuery();
                }
            }
        }

        public DataTable ExecuteReaderStoredProc(DataTableObject tObj, string storedProcName, List<SqlParameter> paramList = null)
        {
            DataTable dt = new DataTable();

            // delete current data
            using (SqlConnection connection = new SqlConnection(tObj.connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(storedProcName, connection))
                {
                    command.CommandTimeout = tObj.connectionTimeOut;
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Clear();
                    if (paramList != null)
                    {
                        command.Parameters.AddRange(paramList.ToArray());
                    }
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        dt.Load(reader);
                    }
                }
            }
            return dt;
        }


        public string GetConnectionString(string connectionName)
        {
            ConnectionStringSettings connectionStringSettings = ConfigurationManager.ConnectionStrings[connectionName];

            if (connectionStringSettings == null)
            {
                throw new ConfigurationErrorsException(string.Format("A connection string named {0} was not present", connectionName));
            }

            return connectionStringSettings.ConnectionString;

        }
    }
}
