﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace BVTC.Scheduler.Shared.Base
{
    public interface IDataManipulation
    {
        void TruncateTable(DataTableObject tObj);
        DataTable ExecuteReaderStoredProc(DataTableObject tObj, string storedProcName, List<SqlParameter> paramList = null);
        void ExecuteNonQueryStoredProc(DataTableObject tObj, string storedProcName, List<SqlParameter> paramList = null);
        string GetConnectionString(string connectionName);
    }
}
