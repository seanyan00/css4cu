﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BVTC.Scheduler.Shared.Base
{
    public class DataTableObject
    {
        public DataTableObject()
        {
            connectionString = "";
            connectionTimeOut = 0;
            tableName = "";
        }
        public string connectionString { get; set; }
        public int connectionTimeOut { get; set; }
        public string tableName { get; set; }
    }
}
