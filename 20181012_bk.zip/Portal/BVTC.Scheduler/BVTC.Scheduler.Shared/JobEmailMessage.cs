﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;

namespace BVTC.Scheduler.Shared
{
    public class JobEmailMessage : MailMessage
    {
        private string _smtpHost;
        private string _toEmail;
        private string _body;
        private IEnumerable<string> _ccEmails;
        private string _subject;
        string _fromEmail;

        public string SmtpHost
        {
            get { return _smtpHost; }
            set { _smtpHost = value; }
        }

        public string ToEmail
        {
            get { return _toEmail.Trim(); }
            set { _toEmail = value.Trim(); }
        }

        public string FromEmail
        {
            get { return _fromEmail.Trim(); }
            set { _fromEmail = value.Trim(); }
        }

        public IEnumerable<string> CCEmails
        {
            get { return _ccEmails; }
            set { _ccEmails = value; }
        }

        public void SendEmail()
            {
                this.From = new MailAddress(
                    FromEmail,
                    FromEmail);
                this.Bcc.Add(FromEmail);

                if (CCEmails != null )
                {
                    foreach (string ccEmail in CCEmails)
                    {
                        if (!string.IsNullOrEmpty(ccEmail))
                            this.CC.Add(new MailAddress(ccEmail));
                    }
                }
                this.IsBodyHtml = true;
                this.To.Add(this.ToEmail);

                SmtpClient smtp = new SmtpClient(this.SmtpHost);
                smtp.Send(this);
            }

        }
}
