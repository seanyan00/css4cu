﻿#region

using System;
using System.Collections.Generic;
using System.Data;

using BVTC.Scheduler.Shared.SimpleMap.Binders;
using BVTC.Scheduler.Shared.SimpleMap.ClassFactories;
using BVTC.Scheduler.Shared.SimpleMap.Extractors;
using BVTC.Scheduler.Shared.SimpleMap.Setters;

#endregion

namespace BVTC.Scheduler.Shared.SimpleMap
{
    /// <summary>
    ///   Projects data from an IDatareader into a target POCO
    /// </summary>
    public class Projector<T>
    {
        private readonly List<IValueBinding<T>> _elements;

        private readonly IClassFactory<T> _factory;

        public Projector(IValueBindingExtractor<T> extractor, IClassFactory<T> factory)
        {
            if (factory == null)
            {
                throw new ArgumentNullException("factory");
            }

            if (extractor == null)
            {
                throw new ArgumentNullException("extractor");
            }

            _factory = factory;
            _elements = extractor.Extract();
        }

        public Projector(List<IValueBinding<T>> elements, IClassFactory<T> factory)
        {
            if (factory == null)
            {
                throw new ArgumentNullException("factory");
            }

            if ((elements == null) || (_elements.Count == 0))
            {
                throw new ApplicationException("at least one binding must be provided.");
            }

            _factory = factory;
            _elements = elements;
        }

        /// <summary>
        ///   Creates a generic projector
        /// </summary>
        /// <param name = "useCodeGeneration">if true the projector will use il code for property setting.
        /// </param>
        /// <returns>Projector</returns>
        public static Projector<T> CreateProjector(bool useCodeGeneration)
        {
            IPropertyValueSetterFactory<T> setterFactory =
                new PropertySetterValueFactory<T>(useCodeGeneration);
            IClassFactory<T> classFactory = new ClassFactory<T>();

            IValueBindingExtractor<T> extractor =
                new PropertyBindingExtractor<T>(setterFactory);

            Projector<T> p = new Projector<T>(extractor, classFactory);

            return p;
        }

        public static Projector<T> CreateProjector(Type typeToCreate, bool useCodeGeneration)
        {
            IPropertyValueSetterFactory<T> setterFactory =
                new PropertySetterValueFactory<T>(useCodeGeneration);
            IClassFactory<T> classFactory = new StaticClassFactory<T>(typeToCreate);

            IValueBindingExtractor<T> extractor =new PropertyBindingExtractor<T>(setterFactory);

            Projector<T> p = new Projector<T>(extractor, classFactory);

            return p;
        }

        /// <summary>
        ///   Fills a collection with projected objects
        /// </summary>
        /// <param name = "collection">collection to fill</param>
        /// <param name = "reader">data reader to use as data source</param>
        public void Project(ICollection<T> collection, IDataReader reader)
        {
            IEnumerator<T> e = new ProjectionEnumerator<T>(reader, _elements, _factory);

            while (e.MoveNext())
            {
                collection.Add(e.Current);
            }
        }


        /// <summary>
        ///   Creates an enumerable cursor for a projection.
        /// </summary>
        /// <param name = "reader">data reader to use as data source</param>
        /// <returns>IEumerable</returns>
        public ProjectionCursor<T> GetCursor(IDataReader reader)
        {
            return new ProjectionCursor<T>(new ProjectionEnumerator<T>(reader, _elements, _factory));
        }
    }
}