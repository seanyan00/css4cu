﻿#region

using System.Collections;
using System.Collections.Generic;

#endregion

namespace BVTC.Scheduler.Shared.SimpleMap
{
    /// <summary>
    ///   Enumeraion facade for a projector
    /// </summary>
    public class ProjectionCursor<T> : IEnumerable<T>
    {
        private readonly ProjectionEnumerator<T> _e;

        internal ProjectionCursor(ProjectionEnumerator<T> e)
        {
            _e = e;
        }

        #region IEnumerable<T> Members

        public IEnumerator<T> GetEnumerator()
        {
            return _e;
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return _e;
        }

        #endregion
    }
}