﻿#region

using System.Reflection;

#endregion

namespace BVTC.Scheduler.Shared.SimpleMap.Setters
{
    public class PropertySetterValueFactory<T> : IPropertyValueSetterFactory<T>
    {
        private readonly bool _useCodeGeneration;

        public PropertySetterValueFactory(bool useCodeGeneration)
        {
            _useCodeGeneration = useCodeGeneration;
        }

        #region IPropertyValueSetterFactory<T> Members

        public IValueSetter<T> CreateSetter(PropertyInfo property)
        {
            if (_useCodeGeneration)
            {
                return new DynamicIlPropertyValueSetter<T>(property);
            }
            return new ReflectionPropertyValueSetter<T>(property);
        }

        #endregion
    }
}