﻿#region

using System.Reflection;

#endregion

namespace BVTC.Scheduler.Shared.SimpleMap.Setters
{
    public interface IPropertyValueSetterFactory<in T>
    {
        IValueSetter<T> CreateSetter(PropertyInfo property);
    }
}