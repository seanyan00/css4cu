﻿#region

using System;
using System.Reflection;

#endregion

namespace BVTC.Scheduler.Shared.SimpleMap.Setters
{
    /// <summary>
    ///   Maps a value in the target object using properties.
    /// </summary>
    public class ReflectionPropertyValueSetter<T> : IValueSetter<T>
    {
        private readonly PropertyInfo _property;

        public ReflectionPropertyValueSetter(PropertyInfo property)
        {
            if (property == null)
            {
                throw new ArgumentNullException("property");
            }

            _property = property;
        }

        #region IValueSetter<T> Members

        public string Name
        {
            get { return _property.Name; }
        }

        /// <summary>
        ///   Sets the value in the target object
        /// </summary>
        /// <param name = "target">Object to update</param>
        /// <param name = "fieldValue">The value to set</param>
        public void SetValue(T target, object fieldValue)
        {
            _property.SetValue(target, fieldValue == DBNull.Value ? null : fieldValue, null);
        }

        #endregion

        public override string ToString()
        {
            return _property.Name;
        }
    }


    internal delegate void LateBoundPropertySet(object target, object value);
}