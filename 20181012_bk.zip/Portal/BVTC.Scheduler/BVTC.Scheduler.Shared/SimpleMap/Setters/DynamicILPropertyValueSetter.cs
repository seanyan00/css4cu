﻿#region

using System;
using System.Reflection;
using System.Reflection.Emit;

#endregion

namespace BVTC.Scheduler.Shared.SimpleMap.Setters
{
    public class DynamicIlPropertyValueSetter<T> : IValueSetter<T>
    {
        private readonly LateBoundPropertySet _setter;

        public DynamicIlPropertyValueSetter(PropertyInfo property)
        {
            if (property == null)
            {
                throw new ArgumentNullException("property");
            }

            Name = property.Name;
            _setter = CreateLateboundSetter(property);
        }

        #region IValueSetter<T> Members

        public string Name { get; private set; }

        /// <summary>
        ///   Sets the value in the target object
        /// </summary>
        /// <param name = "target">Object to update</param>
        /// <param name = "fieldValue">The value to set</param>
        public void SetValue(T target, object fieldValue)
        {
            _setter(target, fieldValue == DBNull.Value ? null : fieldValue);
        }

        #endregion

        /// <summary>
        ///   Generates a dynamic binding
        /// </summary>
        /// <param name = "property"></param>
        /// <returns></returns>
        private static LateBoundPropertySet CreateLateboundSetter(PropertyInfo property)
        {
            DynamicMethod method = new DynamicMethod("Set" + property.Name, null,
                                                     new[] {typeof (object), typeof (object)}, true);

            ILGenerator gen = method.GetILGenerator();

            Type sourceType = property.DeclaringType;
            MethodInfo setter = property.GetSetMethod(true);

            gen.Emit(OpCodes.Ldarg_0); // Load input to stack
            gen.Emit(OpCodes.Castclass, sourceType); // Cast to source type
            gen.Emit(OpCodes.Ldarg_1); // Load value to stack
            gen.Emit(OpCodes.Unbox_Any, property.PropertyType); // Unbox the value to its proper value type
            gen.Emit(OpCodes.Callvirt, setter); // Call the setter method
            gen.Emit(OpCodes.Ret);

            LateBoundPropertySet result = (LateBoundPropertySet) method.CreateDelegate(typeof (LateBoundPropertySet));

            return result;
        }
    }
}