﻿namespace BVTC.Scheduler.Shared.SimpleMap.Setters
{
    /// <summary>
    ///   An object that can map a value to the storage of the target object.
    /// </summary>
    public interface IValueSetter<in T>
    {
        string Name { get; }

        /// <summary>
        ///   Sets the value in the target object
        /// </summary>
        /// <param name = "target">Object to update</param>
        /// <param name = "fieldValue">The value to set</param>
        void SetValue(T target, object fieldValue);
    }
}