﻿namespace BVTC.Scheduler.Shared.SimpleMap.ClassFactories
{
    public interface IClassFactory<out T>
    {
        T Create();
    }
}