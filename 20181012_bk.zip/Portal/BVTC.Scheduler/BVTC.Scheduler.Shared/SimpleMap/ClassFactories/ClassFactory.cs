﻿#region

using System;

#endregion

namespace BVTC.Scheduler.Shared.SimpleMap.ClassFactories
{
    public class ClassFactory<T> : IClassFactory<T>
    {
        #region IClassFactory<T> Members

        public T Create()
        {
            return Activator.CreateInstance<T>();
        }

        #endregion
    }


    public class StaticClassFactory<T> : IClassFactory<T>
    {
        private readonly Type _typeToCreate;


        public StaticClassFactory(Type typeToCreate)
        {
            _typeToCreate = typeToCreate;
        }

        #region IClassFactory<T> Members

        public T Create()
        {
            return (T) Activator.CreateInstance(_typeToCreate);
        }

        #endregion
    }
}