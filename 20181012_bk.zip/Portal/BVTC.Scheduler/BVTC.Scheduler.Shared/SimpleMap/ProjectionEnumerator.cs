﻿#region

using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using BVTC.Scheduler.Shared.SimpleMap.Binders;
using BVTC.Scheduler.Shared.SimpleMap.ClassFactories;
using BVTC.Scheduler.Shared.SimpleMap.DataLinks;

#endregion

namespace BVTC.Scheduler.Shared.SimpleMap
{
    public class ProjectionEnumerator<T> : IEnumerator<T>
    {
        private const string NAME_COLUMN = "ColumnName";
        private const string ORDINAL_COLUMN = "ColumnOrdinal";
        private readonly List<IValueBinding<T>> _elements;
        private readonly IClassFactory<T> _factory;
        private readonly List<ProjectionLink<T>> _projectionSet;
        private readonly IDataReader _reader;

        public ProjectionEnumerator(IDataReader reader, List<IValueBinding<T>> elements, IClassFactory<T> factory)
        {
            if (factory == null)
            {
                throw new ArgumentNullException("factory");
            }

            if ((elements == null) || (elements.Count == 0))
            {
                throw new ApplicationException("Atleast one link element is required");
            }

            _factory = factory;
            _elements = elements;
            _projectionSet = ProjectionSet(reader.GetSchemaTable());
            _reader = reader;
        }

        #region IEnumerator<T> Members

        public T Current
        {
            get
            {
                T item = _factory.Create();

                foreach (ProjectionLink<T> field in _projectionSet)
                {
                    field.Setter.SetValue(item, _reader[field.Ordinal]);
                }


                return item;
            }
        }

        public void Dispose()
        {
        }

        object IEnumerator.Current
        {
            get { return Current; }
        }

        public bool MoveNext()
        {
            return _reader.Read();
        }

        public void Reset()
        {
            throw new NotImplementedException();
        }

        #endregion

        private List<ProjectionLink<T>> ProjectionSet(DataTable schema)
        {
            List<ProjectionLink<T>> set = new List<ProjectionLink<T>>();

            foreach (IValueBinding<T> e in _elements)
            {
                foreach (DataRow r in schema.Rows)
                {
                    if (r[NAME_COLUMN].ToString() != e.Column) continue;
                    ProjectionLink<T> item = new ProjectionLink<T>
                                                 {
                                                     Setter = e.Setter,
                                                     Ordinal = (Int32) r[ORDINAL_COLUMN]
                                                 };
                    set.Add(item);
                }
            }

            return set;
        }
    }
}