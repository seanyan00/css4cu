﻿#region

using System;

using BVTC.Scheduler.Shared.SimpleMap.Setters;

#endregion

namespace BVTC.Scheduler.Shared.SimpleMap.Binders
{
    /// <summary>
    ///   defines map between a field in the data source and a value 
    ///   setter for the target object.
    /// </summary>
    public class ValueBinding<T> : IValueBinding<T>
    {
        public ValueBinding(IValueSetter<T> setter, string column)
        {
            if (setter == null)
            {
                throw new ArgumentNullException("setter");
            }
            if (string.IsNullOrEmpty(column))
            {
                throw new ArgumentOutOfRangeException("column");
            }

            Setter = setter;
            Column = column;
        }

        #region IValueBinding<T> Members

        /// <summary>
        ///   Setter used to update the value on the target object
        /// </summary>
        public IValueSetter<T> Setter { get; private set; }

        /// <summary>
        ///   The column in the datasouce to for the value
        /// </summary>
        public string Column { get; set; }

        #endregion

        public override string ToString()
        {
            return string.Format("{0}:{1}", Column, Setter);
        }
    }
}