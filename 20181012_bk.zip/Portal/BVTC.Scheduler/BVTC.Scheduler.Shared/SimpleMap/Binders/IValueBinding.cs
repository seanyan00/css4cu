﻿#region

using BVTC.Scheduler.Shared.SimpleMap.Setters;

#endregion

namespace BVTC.Scheduler.Shared.SimpleMap.Binders
{
    /// <summary>
    ///   Definss a map between a field in the data source  and a value setter for the target object.
    /// </summary>
    public interface IValueBinding<in T>
    {
        /// <summary>
        ///   The name of the column in the datasource to use as a value
        /// </summary>
        string Column { get; set; }

        /// <summary>
        ///   The setter used to uopdate the target object
        /// </summary>
        IValueSetter<T> Setter { get; }
    }
}