﻿#region

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

using BVTC.Scheduler.Shared.SimpleMap.Binders;
using BVTC.Scheduler.Shared.SimpleMap.Setters;

#endregion

namespace BVTC.Scheduler.Shared.SimpleMap.Extractors
{
    /// <summary>
    ///   Extracts column to propery data value mappings defaulting to 
    ///   the filed name in the datasource matches the property name.
    ///   The default behavior name can be adjusted by the use of 
    ///   the Ignore or Column Attribute.
    /// </summary>
    public class PropertyBindingExtractor<T> : IValueBindingExtractor<T>
    {
        private readonly IPropertyValueSetterFactory<T> _setterFactory;

        public PropertyBindingExtractor(IPropertyValueSetterFactory<T> setterFactory)
        {
            if (setterFactory == null)
            {
                throw new ArgumentNullException("setterFActory");
            }

            _setterFactory = setterFactory;
        }

        #region IValueBindingExtractor<T> Members

        /// <summary>
        ///   Extracts list of IValueBinding values based on properties.
        /// </summary>
        /// <returns></returns>
        public List<IValueBinding<T>> Extract()
        {
            List<IValueBinding<T>> elements = new List<IValueBinding<T>>();

            foreach (PropertyInfo p in ExtractProperties())
            {
                object[] attributes = p.GetCustomAttributes(typeof (BindingExtractionAttribute), true);

                bool skip = false;
                string column = p.Name;

                foreach (Attribute a in attributes)
                {
                    if (a is Ignore)
                    {
                        skip = true;
                        break;
                    }

                    if (a is Column)
                    {
                        column = ((Column) a).Name;
                    }
                }


                if (skip) continue;
                IValueSetter<T> setter = _setterFactory.CreateSetter(p);
                IValueBinding<T> binding = new ValueBinding<T>(setter, column);
                elements.Add(binding);
            }

            return elements;
        }

        #endregion

        private static IEnumerable<PropertyInfo> ExtractProperties()
        {
            List<PropertyInfo> propertyInfos = new List<PropertyInfo>();

            propertyInfos.AddRange(
                typeof (T).GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic |
                                         BindingFlags.FlattenHierarchy));

            propertyInfos.AddRange(
                typeof (T).GetInterfaces().SelectMany(
                    interfaceType =>
                    interfaceType.GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic |
                                                BindingFlags.FlattenHierarchy)));


            return propertyInfos;
        }
    }
}