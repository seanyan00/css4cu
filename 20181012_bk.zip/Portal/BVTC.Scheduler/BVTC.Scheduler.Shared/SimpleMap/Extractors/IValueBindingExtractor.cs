﻿#region

using System.Collections.Generic;

using BVTC.Scheduler.Shared.SimpleMap.Binders;

#endregion

namespace BVTC.Scheduler.Shared.SimpleMap.Extractors
{
    /// <summary>
    ///   Represents an algorithm used to extract column to propery data value 
    ///   mappings from a target type.
    /// </summary>
    /// <typeparam name = "T"></typeparam>
    public interface IValueBindingExtractor<T>
    {
        /// <summary>
        ///   Retuns a list of value binding from the target type 
        ///   based on the implmented algorithm
        /// </summary>
        /// <returns></returns>
        List<IValueBinding<T>> Extract();
    }
}