﻿namespace BVTC.Scheduler.Shared.SimpleMap.Extractors
{
    /// <summary>
    ///   Causes the binding extractor to skip a
    ///   property when it generates the bindings.
    /// </summary>
    public class Ignore : BindingExtractionAttribute
    {
    }
}