﻿#region

using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

using BVTC.Scheduler.Shared.SimpleMap.Binders;
using BVTC.Scheduler.Shared.SimpleMap.Setters;

#endregion

namespace BVTC.Scheduler.Shared.SimpleMap.Extractors
{
    public class CustomExtractor<T> : IValueBindingExtractor<T>
    {
        private readonly List<IValueBinding<T>> _elements = new List<IValueBinding<T>>();


        public CustomExtractor(IValueBindingExtractor<T> extractor)
        {
            _elements = extractor.Extract();
        }

        #region IValueBindingExtractor<T> Members

        public List<IValueBinding<T>> Extract()
        {
            return _elements;
        }

        #endregion

        public static CustomExtractor<T> CreateAuto(IPropertyValueSetterFactory<T> setterFactory)
        {
            IValueBindingExtractor<T> e = new PropertyBindingExtractor<T>(setterFactory);
            return new CustomExtractor<T>(e);
        }


        public void AddBinding(string column, PropertyInfo p)
        {
            _elements.Add(new ValueBinding<T>(new DynamicIlPropertyValueSetter<T>(p), column));
        }


        public void ChangeBinding(string column, PropertyInfo p)
        {
            foreach (IValueBinding<T> b in _elements.Where(b => b.Setter.Name == p.Name))
            {
                b.Column = column;
            }
        }

        public void ChangeBinding(string column, Expression<Func<T, object>> property)
        {
            MemberExpression m = (MemberExpression) property.Body;
            PropertyInfo p = m.Member.ReflectedType.GetProperty(m.Member.Name);

            ChangeBinding(column, p);
        }


        public void AddBinding(string column, Expression<Func<T, object>> property)
        {
            MemberExpression m = (MemberExpression) property.Body;
            PropertyInfo p = m.Member.ReflectedType.GetProperty(m.Member.Name);


            AddBinding(column, p);
        }
    }
}