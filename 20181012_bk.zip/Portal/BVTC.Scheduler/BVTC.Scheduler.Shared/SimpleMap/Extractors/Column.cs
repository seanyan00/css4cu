﻿namespace BVTC.Scheduler.Shared.SimpleMap.Extractors
{
    /// <summary>
    ///   Overides the default column map from the name of the property
    ///   to a value specified.
    /// </summary>
    public class Column : BindingExtractionAttribute
    {
        /// <summary>
        /// </summary>
        /// <param name = "column">The name of the column to target when mapping data for the data source.</param>
        public Column(string column)
        {
            Name = column;
        }


        /// <summary>
        ///   The name of the column to target when mapping data for the data source.
        /// </summary>
        public string Name { get; private set; }
    }
}