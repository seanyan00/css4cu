﻿#region

using System;

#endregion

namespace BVTC.Scheduler.Shared.SimpleMap.Extractors
{
    /// <summary>
    ///   Base for all Binding Extraction Attributes.
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public abstract class BindingExtractionAttribute : Attribute
    {
    }
}