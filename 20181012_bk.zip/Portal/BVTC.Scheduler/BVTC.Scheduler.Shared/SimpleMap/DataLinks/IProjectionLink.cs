﻿#region

using BVTC.Scheduler.Shared.SimpleMap.Setters;

#endregion

namespace BVTC.Scheduler.Shared.SimpleMap.DataLinks
{
    /// <summary>
    ///   A linked between a value setter and a column ordinal for a specific dataset
    /// </summary>
    public interface IProjectionLink<T>
    {
        /// <summary>
        ///   The ordinal of the column to get the value from
        /// </summary>
        IValueSetter<T> Setter { get; set; }

        /// <summary>
        ///   The binding to use for the value
        /// </summary>
        int Ordinal { get; set; }
    }
}