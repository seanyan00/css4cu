﻿#region

using BVTC.Scheduler.Shared.SimpleMap.Setters;

#endregion

namespace BVTC.Scheduler.Shared.SimpleMap.DataLinks
{
    /// <summary>
    ///   A linked between a value setter and a column ordinal for a specific dataset
    /// </summary>
    public class ProjectionLink<T> : IProjectionLink<T>
    {
        #region IProjectionLink<T> Members

        /// <summary>
        ///   The ordinal of the column to get the value from
        /// </summary>
        public int Ordinal { get; set; }

        /// <summary>
        ///   The setter to use for the value
        /// </summary>
        public IValueSetter<T> Setter { get; set; }

        #endregion
    }
}