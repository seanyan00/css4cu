﻿using System.Collections.Generic;

namespace BVTC.Scheduler.Shared
{
    public interface IJobLogReport
    {
        IEnumerable<JobLogData> GetJobLogData();
    }
}
