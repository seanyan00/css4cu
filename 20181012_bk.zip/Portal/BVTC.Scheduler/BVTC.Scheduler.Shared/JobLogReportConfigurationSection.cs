﻿using System;
using System.Configuration;

namespace BVTC.Scheduler.Shared
{
    public class JobLogReportConfigurationSection : ConfigurationSection
    {
        [ConfigurationProperty("type", IsRequired = false, DefaultValue = "")]
        public String Type
        {
            get
            {
                return (String)this["type"];
            }
            set
            {
                this["type"] = value;
            }
        }


    }
}