﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using Common.Logging;
using Quartz;

namespace BVTC.Scheduler.Shared.Jobs
{
    
    
    public class MissingParameterException:Exception
    {

        private readonly string _parmName;


        public override string Message
        {
            get { return string.Format("Missing parameter :{0}", _parmName); }
        }

        public MissingParameterException(string parmName)
        {
            this._parmName = parmName;
        }

        protected MissingParameterException(SerializationInfo info, StreamingContext context, string parmName) : base(info, context)
        {
            _parmName = parmName;
        }
    }

    
    public abstract class JobBase : IJob
    {
        protected ILog Log { get; private set; }

        private readonly List<string> _parms = new List<string>();

        public async Task Execute(IJobExecutionContext context)
        {
            try
            {

                Debug.Assert(context != null);
                
                Log = LogManager.GetLogger("JobLogger");
            
                BeforValidateParameters();
                
                VerifyParameters(context);

                ContextParametersReady(context);

                BeforAction(context);
                
                await Action(context);
            
            }
            catch(JobExecutionException je)
            {
                throw;
            }
            catch (Exception e)
            {
                if (context!=null && context.JobDetail!=null)
                {
                    Log.Error(context.JobDetail.Key, e);
                }
                
                throw new JobExecutionException(e);
            }

        }

        protected virtual void BeforAction(IJobExecutionContext context)
        {
        }

        protected abstract Task Action(IJobExecutionContext context);

        protected virtual void BeforValidateParameters()
        {
        }

        protected virtual void ContextParametersReady(IJobExecutionContext context)
        {
        }

        protected void AddParameterToValidate(string name)
        {
            _parms.Add(name);
        }

        protected void VerifyParameters(IJobExecutionContext context)
        {
            foreach (string parm in  _parms.Where(parm => !context.MergedJobDataMap.Keys.Contains(parm)))
            {
                throw new MissingParameterException(parm);
            }
        }

    }
}