﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Quartz;

namespace BVTC.Scheduler.Shared.Jobs
{
    [JobInfoAttribute("System Test Job")]
    public class SchedulerTestJob : JobBase
    {

        protected override Task Action(IJobExecutionContext context)
        {
            int delayParm = context.MergedJobDataMap.GetIntValue("delay");

            int secondsToWait = delayParm == 0 ? 10 : delayParm;

            var tcs = new TaskCompletionSource<bool>();
            System.Timers.Timer timer = new System.Timers.Timer();
            timer.Elapsed += (obj, args) =>
            {
                tcs.TrySetResult(true);
            };
            timer.Interval = secondsToWait * 1000;
            timer.AutoReset = false;
            Log.Debug((string.Format("Scheduler Test job enter - {0}", DateTime.Now.ToString("r"))));
            
            timer.Start();

            Log.Debug((string.Format("Scheduler Test job exit -{0}", DateTime.Now.ToString("r"))));

            return tcs.Task;
        }
    }
}