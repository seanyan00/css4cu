﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Mime;
using System.Reflection;
using System.Text;

namespace BVTC.Scheduler.Shared
{

    public class DirectoryTypeEnumerator
    {
        private readonly string _path;

        public DirectoryTypeEnumerator()
        {
            _path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().GetModules()[0].FullyQualifiedName);

        }

        public DirectoryTypeEnumerator(string path)
        {
            _path = path;
        }

        public IEnumerable<Type> GetTypes(Type type)
        {

            HashSet<Type> results = new HashSet<Type>();

            string[] dllFiles = Directory.GetFiles(_path, "*.dll");

            string[] exeFiles = Directory.GetFiles(_path, "*.exe");

            IEnumerable<string> allFiles = exeFiles.Concat(dllFiles);

            foreach (string file in allFiles)
            {
                try
                {
                    Assembly asmbly = Assembly.LoadFile(file);

                    IEnumerable<Type> extractedTypes = asmbly.Extract(type);

                    foreach (Type extractedType in extractedTypes)
                    {
                        results.Add(extractedType);
                    }

                }

                catch (Exception ex)
                {
                    Debug.WriteLine(ex);
                }

            }

            return results;
        }

    }

    public static class AssembyExtensions
    {

        public static IEnumerable<Type> Extract(this Assembly source, Type filter)
        {

            HashSet<Type> matches = new HashSet<Type>();

            foreach (Type type in source.GetTypes().Where(type => type.Implements(filter)))
            {
                matches.Add(type);
            }

            return matches;

        }


    }

    public static class TypeExtensions
    {

        public static bool Implements(this Type source, Type type)
        {

            Type intfce = source.GetInterface(type.FullName);

            return intfce != null;
        }


    }

}

