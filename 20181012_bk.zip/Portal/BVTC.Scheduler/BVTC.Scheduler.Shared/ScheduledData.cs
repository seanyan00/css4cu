﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Quartz;
using Quartz.Util;

namespace BVTC.Scheduler.Shared
{
    [DataContract]
    public class ScheduledData
    {
        public ScheduledData(ITrigger trigger)
        {
            Name = trigger.Key.Name;
            Group = trigger.Key.Group;
            Description = trigger.Description;
            NextRunTime = trigger.GetNextFireTimeUtc();
            LastRunTime = trigger.GetPreviousFireTimeUtc();

            JobName = trigger.JobKey.Name;
            JobGroup = trigger.JobKey.Group;

            if (trigger is ICronTrigger)
            {
                ICronTrigger t = (ICronTrigger) trigger;

                Cron = t.CronExpressionString;
            }


            if (trigger.JobDataMap != null)
            {
                foreach (KeyValuePair<string, object> keyValuePair in trigger.JobDataMap)
                {
                    Parameters += string.Format("{0}={1};", keyValuePair.Key, keyValuePair.Value);
                }
            }
        }

        public ScheduledData(Key<TriggerKey> key)
        {
            Name = key.Name;
            Group =key.Group;
        }

        public ScheduledData()
        {
        }

        [DataMember]
        public DateTimeOffset? NextRunTime { get; set; }

        [DataMember]
        public DateTimeOffset? LastRunTime { get; set; }

        [DataMember]
        public string Description { get; set; }

        [DataMember]
        public string Group { get; set; }
        
        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public string JobGroup { get; set; }

        [DataMember]
        public string JobName { get; set; }

        [DataMember]
        public string Parameters { get; set; }


        [DataMember]
        public string Cron { get; set; }
    
    }
}