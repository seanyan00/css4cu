﻿using System;

namespace BVTC.Scheduler.Shared
{
    public class JobInfoAttribute:Attribute
    {
        public JobInfoAttribute(string description)
        {
            Description = description;
        }

        public string Description { get; set; }
    }
}