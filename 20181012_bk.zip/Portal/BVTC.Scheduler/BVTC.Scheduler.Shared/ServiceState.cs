﻿using System;
using System.Runtime.Serialization;
using Quartz;

namespace BVTC.Scheduler.Shared
{
    [DataContract]
    public class ServiceState
    {
        public ServiceState()
        {
        }

        public ServiceState(SchedulerMetaData schedulerMetaData)
        {

            if (schedulerMetaData==null)
            {
                throw new ArgumentNullException("schedulerMetaData");
            }

            
            Summary = schedulerMetaData.GetSummary();
            IsStarted = schedulerMetaData.Started;
            IsStandby = schedulerMetaData.InStandbyMode;
            IsShutdown = schedulerMetaData.Shutdown;
            RunningSince = schedulerMetaData.RunningSince;
            
        }

        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public bool IsStarted { get; set; }
        [DataMember]
        public bool IsStandby { get; set; }
        [DataMember]
        public bool IsShutdown { get; set; }
        [DataMember]
        public DateTimeOffset? RunningSince { get; set; }
        [DataMember]
        public string Summary { get; set; }
    }
}