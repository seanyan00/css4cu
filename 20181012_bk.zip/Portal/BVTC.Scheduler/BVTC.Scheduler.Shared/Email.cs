﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Net.Mail;
using log4net;

namespace BVTC.Scheduler.Shared
{
    //constant from BVTC.Common
    public static class EmailConstants
    {
        /// <summary>
        /// Boston Valley outgoing STMP Server for Office 365
        /// </summary>
        public static string STMP_SERVER = "smtp.office365.com";
        /// <summary>
        /// Boston Valley outgoing STMP Port for Office 365 
        /// </summary>
        public static int STMP_PORT = 587;
        /// <summary>
        /// Boston Valley outgoing STMP encryption method for Office 365
        /// </summary>
        public static string STMP_ENCRYPTION = "TLS";
        /// <summary>
        /// Boston Valley username to authenticate with SMTP Server.
        /// This user must be allowed to send emails as another group if using SendAs
        /// </summary>
        public static string AUTH_USER = "xerox@bostonvalley.com";
        /// <summary>
        /// Constant Password for AUTH_USER.
        /// Set in Outlook Exchange to never expire.
        /// </summary>
        public static string AUTH_PASS = "bvtcX3r0x";
        /// <summary>
        /// To be used to send as, must be allowed on email server.
        /// This is what will appear in the "from" field when users recieve an email.
        /// </summary>
        public static string SEND_AS = "it@bostonvalley.com";
    }

    public class Email
    {       
        public string FromEMail { get; set; }
        public string ToEmail { get; set; }
        public string CCEmail { get; set; }       
        public string Subject { get; set; }
        public string Body { get; set; }
        public string Attachment { get; set; }
      
        private ILog log = LogManager.GetLogger("Email");      

        public bool ValidateEmailIds(DataTable dt,int[] EmailColumnIndex)
        {
            bool ValidEmailIds = true;
            System.Text.RegularExpressions.Regex ValidEmailID = new System.Text.RegularExpressions.Regex(@"([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})");            
            foreach(int columnIndex in EmailColumnIndex)
                foreach (DataRow dr in dt.Rows)
                {
                   string[] EmailIds = Convert.ToString(dr[columnIndex]).Split(',');                
                    foreach (string EmailID in EmailIds)
                    {
                        if(!string.IsNullOrEmpty(EmailID))
                            if (!ValidEmailID.IsMatch(EmailID))
                            {
                                ValidEmailIds = false;
                                log.Debug("Invalid Email ID found: " + EmailID);
                                break;
                            }
                    }
                    if (!ValidEmailIds) break;
                }
            return ValidEmailIds;
        }       

        public bool SendEmail(string HostIP = "", int Port = 0)
        {
            bool bIsEmailSuccess = true;
            try
            {
                MailMessage message = new MailMessage(FromEMail,
                                                    ToEmail,
                                                    Subject,
                                                    Body);
                message.IsBodyHtml = true;
                if (!string.IsNullOrEmpty(Attachment))
                    message.Attachments.Add(new Attachment(Attachment));

                SmtpClient client = new SmtpClient(string.IsNullOrEmpty(HostIP) ? EmailConstants.STMP_SERVER : HostIP, 
                                                   Port == 0 ? EmailConstants.STMP_PORT : Port);
                // client.UseDefaultCredentials = true;
                client.Credentials = new System.Net.NetworkCredential(EmailConstants.AUTH_USER, EmailConstants.AUTH_PASS);
                client.EnableSsl = true;

                client.Send(message);
            }
            catch (Exception exp)
            {
                log.Error("Exception When Sending Email.");
                log.Error(exp);
                bIsEmailSuccess = false;
            }
            return bIsEmailSuccess;           
        }
    }
}
