﻿using System;
using System.Data.SqlClient;

namespace BVTC.Scheduler.Shared.Data
{
    public static class ReaderHelper
    {
        public static string SafeGetString(this SqlDataReader reader, int idx)
        {
            if (!reader.IsDBNull(idx))
                return reader.GetString(idx);
            return string.Empty;
        }
        public static DateTime SafeGetDateTime(this SqlDataReader reader, int idx)
        {
            if (!reader.IsDBNull(idx) && !(reader.GetString(idx).IndexOf("0000") == 0))
                return DateTime.ParseExact(reader.GetString(idx), "yyyyMMdd", null);

            return new DateTime(1753, 1, 2);
        }
    }
}
