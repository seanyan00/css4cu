﻿using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Quartz;
using Quartz.Util;

namespace BVTC.Scheduler.Shared
{
    [DataContract]
    public class JobData
    {
        public JobData()
        {
        }

        public JobData(Key<JobKey> key)
        {
            Group = key.Group;
            Name = key.Name;
        }

        public JobData(IJobDetail jobDetail)
        {
            Group = jobDetail.Key.Group;
            Name = jobDetail.Key.Name;
            Description = jobDetail.Description;
            JobType = jobDetail.JobType.AssemblyQualifiedName;
            Durable = jobDetail.Durable;


            if (jobDetail.JobDataMap != null)
            {
                foreach (KeyValuePair<string, object> keyValuePair in jobDetail.JobDataMap)
                {
                    Parameters += string.Format("{0}={1};", keyValuePair.Key, keyValuePair.Value);
                }
            }

        }

        public JobData(IJobDetail jobDetail,IEnumerable map)
        {
            Group = jobDetail.Key.Group;
            Name = jobDetail.Key.Name;
            Description = jobDetail.Description;
            JobType = jobDetail.JobType.ToString();
            Durable = jobDetail.Durable;

            if (map!=null)
            {
                foreach (KeyValuePair<string,object> keyValuePair in map)
                {
                    Parameters += string.Format("{0}={1};", keyValuePair.Key,keyValuePair.Value);
                }
            }

        }

        [DataMember]
        public string JobType { get; set; }
        
        [DataMember]
        public bool Durable { get; set; }
        
        [DataMember]
        public string Group { get; set; }
        
        [DataMember]
        public string Name { get; set; }
    
        [DataMember]
        public string Description { get; set; }

        [DataMember]
        public string Parameters { get; set; }

    
    
    }
}