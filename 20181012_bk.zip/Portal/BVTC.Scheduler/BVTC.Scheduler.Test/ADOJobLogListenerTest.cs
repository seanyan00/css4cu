﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Quartz;
using Rhino.Mocks;
using BVTC.Scheduler.Listensers;
using BVTC.Scheduler.Shared;

namespace BVTC.Scheduler.Test
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class ADOJobLogListenerTest
    {
        public ADOJobLogListenerTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void TestMethod1()
        {
            ADOJobLogListener l = new ADOJobLogListener();
            
            IJobExecutionContext jobExecutionContext = MockRepository.GenerateStub<IJobExecutionContext>();

            IDictionary<string,object> map=new Dictionary<string, object> {{"v1", "Value1"}, {"v2", "Value2"}};

            IJobDetail detail = MockRepository.GenerateStub<IJobDetail>();
            detail.Stub(x => x.Key).Return(new JobKey("nm", "gr"));
            detail.Stub(x => x.JobType).Return(this.GetType());
            

            ITrigger trigger = MockRepository.GenerateStub<ITrigger>();
            trigger.Stub(x=>x.Key).Return(new TriggerKey("tn", "tg"));
            trigger.Stub(x => x.StartTimeUtc).Return(new DateTimeOffset(DateTime.Now));
            

            jobExecutionContext.Stub(x => x.JobDetail).Return(detail);
            jobExecutionContext.Stub(x => x.Trigger).Return(trigger);
            jobExecutionContext.Stub(x => x.MergedJobDataMap).Return(new JobDataMap(map));
            
            JobExecutionException ex = null;

            l.JobWasExecuted(jobExecutionContext, ex, new System.Threading.CancellationToken());

        }
    }
}
