﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Quartz;
using Rhino.Mocks;
using BVTC.Scheduler.Listensers;

namespace BVTC.Scheduler.Test
{
    [TestClass]
    public class SMTPJobListenerTest
    {
        [TestMethod]
        public void TestMethod1()
        {
            IJobExecutionContext jobExecutionContext = MockRepository.GenerateStub<IJobExecutionContext>();

            IDictionary<string, object> map = new Dictionary<string, object> { { "v1", "Value1" }, { "v2", "Value2" }, { "notifyemail" ,"syan@bostonvalley.net"} };

            IJobDetail detail = MockRepository.GenerateStub<IJobDetail>();
            detail.Stub(x => x.Key).Return(new JobKey("nm", "gr"));
            detail.Stub(x => x.JobType).Return(this.GetType());

            ITrigger trigger = MockRepository.GenerateStub<ITrigger>();
            trigger.Stub(x => x.Key).Return(new TriggerKey("tn", "tg"));
            trigger.Stub(x => x.StartTimeUtc).Return(new DateTimeOffset(DateTime.Now));


            trigger.Stub(x=>x.JobKey).Return(new JobKey("j1","j2"));
                

            jobExecutionContext.Stub(x => x.JobDetail).Return(detail);
            jobExecutionContext.Stub(x => x.Trigger).Return(trigger);
            jobExecutionContext.Stub(x => x.MergedJobDataMap).Return(new JobDataMap(map));


            JobExecutionException ex = null;
        
            SMTPListener listener=new SMTPListener();
            listener.JobWasExecuted(jobExecutionContext, ex, new System.Threading.CancellationToken());
        


        }
    }
}
