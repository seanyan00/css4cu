﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BVTC.Scheduler.UI
{
    public partial class JobLogView : Form
    {
        public JobLogView(object current)
        {
            InitializeComponent();
            bindingSource1.DataSource = current;
        }
    
                
    
    }
}
