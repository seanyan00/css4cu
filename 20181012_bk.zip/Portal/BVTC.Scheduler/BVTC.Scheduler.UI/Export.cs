﻿using BVTC.Scheduler.UI.SchedulerService;

namespace BVTC.Scheduler.UI
{
    public class Export
    {
        public JobData[] Jobs { get; set; }
        public ScheduledData[] Schedules { get; set; }
    }
}