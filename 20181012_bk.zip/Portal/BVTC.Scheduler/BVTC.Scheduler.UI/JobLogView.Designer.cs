﻿namespace BVTC.Scheduler.UI
{
    partial class JobLogView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label jOB_CLASS_NAMELabel;
            System.Windows.Forms.Label jOB_DATALabel;
            System.Windows.Forms.Label jOB_ENDLabel;
            System.Windows.Forms.Label jOB_GROUPLabel;
            System.Windows.Forms.Label jOB_NAMELabel;
            System.Windows.Forms.Label jOB_STARTLabel;
            System.Windows.Forms.Label lOG_DATELabel;
            System.Windows.Forms.Label sCHEDULE_GROUPLabel;
            System.Windows.Forms.Label sCHEDULE_NAMELabel;
            System.Windows.Forms.Label sTATUSLabel;
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.detailTab = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.jOB_CLASS_NAMETextBox = new System.Windows.Forms.TextBox();
            this.jOB_GROUPTextBox = new System.Windows.Forms.TextBox();
            this.jOB_NAMETextBox = new System.Windows.Forms.TextBox();
            this.sCHEDULE_GROUPTextBox = new System.Windows.Forms.TextBox();
            this.sCHEDULE_NAMETextBox = new System.Windows.Forms.TextBox();
            this.sTATUSTextBox = new System.Windows.Forms.TextBox();
            this.jOB_DATATextBox = new System.Windows.Forms.TextBox();
            this.eRROR_INFOTextBox = new System.Windows.Forms.TextBox();
            this.lOG_DATETextBox = new System.Windows.Forms.TextBox();
            this.jOB_STARTTextBox = new System.Windows.Forms.TextBox();
            this.jOB_ENDTextBox = new System.Windows.Forms.TextBox();
            jOB_CLASS_NAMELabel = new System.Windows.Forms.Label();
            jOB_DATALabel = new System.Windows.Forms.Label();
            jOB_ENDLabel = new System.Windows.Forms.Label();
            jOB_GROUPLabel = new System.Windows.Forms.Label();
            jOB_NAMELabel = new System.Windows.Forms.Label();
            jOB_STARTLabel = new System.Windows.Forms.Label();
            lOG_DATELabel = new System.Windows.Forms.Label();
            sCHEDULE_GROUPLabel = new System.Windows.Forms.Label();
            sCHEDULE_NAMELabel = new System.Windows.Forms.Label();
            sTATUSLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.detailTab.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // bindingSource1
            // 
            this.bindingSource1.AllowNew = false;
            this.bindingSource1.DataSource = typeof(BVTC.Scheduler.UI.SchedulerService.JobLogData);
            // 
            // detailTab
            // 
            this.detailTab.Controls.Add(this.tabPage1);
            this.detailTab.Controls.Add(this.tabPage2);
            this.detailTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.detailTab.Location = new System.Drawing.Point(0, 0);
            this.detailTab.Name = "detailTab";
            this.detailTab.SelectedIndex = 0;
            this.detailTab.Size = new System.Drawing.Size(825, 365);
            this.detailTab.TabIndex = 22;
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.Controls.Add(this.jOB_ENDTextBox);
            this.tabPage1.Controls.Add(this.jOB_STARTTextBox);
            this.tabPage1.Controls.Add(this.lOG_DATETextBox);
            this.tabPage1.Controls.Add(this.jOB_DATATextBox);
            this.tabPage1.Controls.Add(jOB_CLASS_NAMELabel);
            this.tabPage1.Controls.Add(this.jOB_CLASS_NAMETextBox);
            this.tabPage1.Controls.Add(jOB_DATALabel);
            this.tabPage1.Controls.Add(jOB_ENDLabel);
            this.tabPage1.Controls.Add(jOB_GROUPLabel);
            this.tabPage1.Controls.Add(this.jOB_GROUPTextBox);
            this.tabPage1.Controls.Add(jOB_NAMELabel);
            this.tabPage1.Controls.Add(this.jOB_NAMETextBox);
            this.tabPage1.Controls.Add(jOB_STARTLabel);
            this.tabPage1.Controls.Add(lOG_DATELabel);
            this.tabPage1.Controls.Add(sCHEDULE_GROUPLabel);
            this.tabPage1.Controls.Add(this.sCHEDULE_GROUPTextBox);
            this.tabPage1.Controls.Add(sCHEDULE_NAMELabel);
            this.tabPage1.Controls.Add(this.sCHEDULE_NAMETextBox);
            this.tabPage1.Controls.Add(sTATUSLabel);
            this.tabPage1.Controls.Add(this.sTATUSTextBox);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(817, 336);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Details";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.eRROR_INFOTextBox);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(817, 336);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Error";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // jOB_CLASS_NAMELabel
            // 
            jOB_CLASS_NAMELabel.AutoSize = true;
            jOB_CLASS_NAMELabel.Location = new System.Drawing.Point(13, 101);
            jOB_CLASS_NAMELabel.Name = "jOB_CLASS_NAMELabel";
            jOB_CLASS_NAMELabel.Size = new System.Drawing.Size(130, 17);
            jOB_CLASS_NAMELabel.TabIndex = 22;
            jOB_CLASS_NAMELabel.Text = "JOB CLASS NAME:";
            // 
            // jOB_CLASS_NAMETextBox
            // 
            this.jOB_CLASS_NAMETextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "JOB_CLASS_NAME", true));
            this.jOB_CLASS_NAMETextBox.Location = new System.Drawing.Point(160, 98);
            this.jOB_CLASS_NAMETextBox.Name = "jOB_CLASS_NAMETextBox";
            this.jOB_CLASS_NAMETextBox.ReadOnly = true;
            this.jOB_CLASS_NAMETextBox.Size = new System.Drawing.Size(649, 22);
            this.jOB_CLASS_NAMETextBox.TabIndex = 23;
            // 
            // jOB_DATALabel
            // 
            jOB_DATALabel.AutoSize = true;
            jOB_DATALabel.Location = new System.Drawing.Point(13, 163);
            jOB_DATALabel.Name = "jOB_DATALabel";
            jOB_DATALabel.Size = new System.Drawing.Size(80, 17);
            jOB_DATALabel.TabIndex = 24;
            jOB_DATALabel.Text = "JOB DATA:";
            // 
            // jOB_ENDLabel
            // 
            jOB_ENDLabel.AutoSize = true;
            jOB_ENDLabel.Location = new System.Drawing.Point(424, 131);
            jOB_ENDLabel.Name = "jOB_ENDLabel";
            jOB_ENDLabel.Size = new System.Drawing.Size(72, 17);
            jOB_ENDLabel.TabIndex = 25;
            jOB_ENDLabel.Text = "JOB END:";
            // 
            // jOB_GROUPLabel
            // 
            jOB_GROUPLabel.AutoSize = true;
            jOB_GROUPLabel.Location = new System.Drawing.Point(424, 13);
            jOB_GROUPLabel.Name = "jOB_GROUPLabel";
            jOB_GROUPLabel.Size = new System.Drawing.Size(94, 17);
            jOB_GROUPLabel.TabIndex = 27;
            jOB_GROUPLabel.Text = "JOB GROUP:";
            // 
            // jOB_GROUPTextBox
            // 
            this.jOB_GROUPTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "JOB_GROUP", true));
            this.jOB_GROUPTextBox.Location = new System.Drawing.Point(524, 13);
            this.jOB_GROUPTextBox.Name = "jOB_GROUPTextBox";
            this.jOB_GROUPTextBox.ReadOnly = true;
            this.jOB_GROUPTextBox.Size = new System.Drawing.Size(285, 22);
            this.jOB_GROUPTextBox.TabIndex = 28;
            // 
            // jOB_NAMELabel
            // 
            jOB_NAMELabel.AutoSize = true;
            jOB_NAMELabel.Location = new System.Drawing.Point(424, 44);
            jOB_NAMELabel.Name = "jOB_NAMELabel";
            jOB_NAMELabel.Size = new System.Drawing.Size(82, 17);
            jOB_NAMELabel.TabIndex = 29;
            jOB_NAMELabel.Text = "JOB NAME:";
            // 
            // jOB_NAMETextBox
            // 
            this.jOB_NAMETextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "JOB_NAME", true));
            this.jOB_NAMETextBox.Location = new System.Drawing.Point(524, 41);
            this.jOB_NAMETextBox.Name = "jOB_NAMETextBox";
            this.jOB_NAMETextBox.ReadOnly = true;
            this.jOB_NAMETextBox.Size = new System.Drawing.Size(285, 22);
            this.jOB_NAMETextBox.TabIndex = 30;
            // 
            // jOB_STARTLabel
            // 
            jOB_STARTLabel.AutoSize = true;
            jOB_STARTLabel.Location = new System.Drawing.Point(13, 131);
            jOB_STARTLabel.Name = "jOB_STARTLabel";
            jOB_STARTLabel.Size = new System.Drawing.Size(89, 17);
            jOB_STARTLabel.TabIndex = 31;
            jOB_STARTLabel.Text = "JOB START:";
            // 
            // lOG_DATELabel
            // 
            lOG_DATELabel.AutoSize = true;
            lOG_DATELabel.Location = new System.Drawing.Point(13, 73);
            lOG_DATELabel.Name = "lOG_DATELabel";
            lOG_DATELabel.Size = new System.Drawing.Size(83, 17);
            lOG_DATELabel.TabIndex = 33;
            lOG_DATELabel.Text = "LOG DATE:";
            // 
            // sCHEDULE_GROUPLabel
            // 
            sCHEDULE_GROUPLabel.AutoSize = true;
            sCHEDULE_GROUPLabel.Location = new System.Drawing.Point(13, 16);
            sCHEDULE_GROUPLabel.Name = "sCHEDULE_GROUPLabel";
            sCHEDULE_GROUPLabel.Size = new System.Drawing.Size(141, 17);
            sCHEDULE_GROUPLabel.TabIndex = 35;
            sCHEDULE_GROUPLabel.Text = "SCHEDULE GROUP:";
            // 
            // sCHEDULE_GROUPTextBox
            // 
            this.sCHEDULE_GROUPTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "SCHEDULE_GROUP", true));
            this.sCHEDULE_GROUPTextBox.Location = new System.Drawing.Point(160, 11);
            this.sCHEDULE_GROUPTextBox.Name = "sCHEDULE_GROUPTextBox";
            this.sCHEDULE_GROUPTextBox.ReadOnly = true;
            this.sCHEDULE_GROUPTextBox.Size = new System.Drawing.Size(258, 22);
            this.sCHEDULE_GROUPTextBox.TabIndex = 36;
            // 
            // sCHEDULE_NAMELabel
            // 
            sCHEDULE_NAMELabel.AutoSize = true;
            sCHEDULE_NAMELabel.Location = new System.Drawing.Point(13, 44);
            sCHEDULE_NAMELabel.Name = "sCHEDULE_NAMELabel";
            sCHEDULE_NAMELabel.Size = new System.Drawing.Size(129, 17);
            sCHEDULE_NAMELabel.TabIndex = 37;
            sCHEDULE_NAMELabel.Text = "SCHEDULE NAME:";
            // 
            // sCHEDULE_NAMETextBox
            // 
            this.sCHEDULE_NAMETextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "SCHEDULE_NAME", true));
            this.sCHEDULE_NAMETextBox.Location = new System.Drawing.Point(160, 41);
            this.sCHEDULE_NAMETextBox.Name = "sCHEDULE_NAMETextBox";
            this.sCHEDULE_NAMETextBox.ReadOnly = true;
            this.sCHEDULE_NAMETextBox.Size = new System.Drawing.Size(258, 22);
            this.sCHEDULE_NAMETextBox.TabIndex = 38;
            // 
            // sTATUSLabel
            // 
            sTATUSLabel.AutoSize = true;
            sTATUSLabel.Location = new System.Drawing.Point(424, 75);
            sTATUSLabel.Name = "sTATUSLabel";
            sTATUSLabel.Size = new System.Drawing.Size(67, 17);
            sTATUSLabel.TabIndex = 39;
            sTATUSLabel.Text = "STATUS:";
            // 
            // sTATUSTextBox
            // 
            this.sTATUSTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "STATUS", true));
            this.sTATUSTextBox.Location = new System.Drawing.Point(524, 70);
            this.sTATUSTextBox.Name = "sTATUSTextBox";
            this.sTATUSTextBox.ReadOnly = true;
            this.sTATUSTextBox.Size = new System.Drawing.Size(284, 22);
            this.sTATUSTextBox.TabIndex = 40;
            // 
            // jOB_DATATextBox
            // 
            this.jOB_DATATextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "JOB_DATA", true));
            this.jOB_DATATextBox.Location = new System.Drawing.Point(16, 183);
            this.jOB_DATATextBox.Multiline = true;
            this.jOB_DATATextBox.Name = "jOB_DATATextBox";
            this.jOB_DATATextBox.ReadOnly = true;
            this.jOB_DATATextBox.Size = new System.Drawing.Size(793, 132);
            this.jOB_DATATextBox.TabIndex = 41;
            // 
            // eRROR_INFOTextBox
            // 
            this.eRROR_INFOTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "ERROR_INFO", true));
            this.eRROR_INFOTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.eRROR_INFOTextBox.Location = new System.Drawing.Point(3, 3);
            this.eRROR_INFOTextBox.Multiline = true;
            this.eRROR_INFOTextBox.Name = "eRROR_INFOTextBox";
            this.eRROR_INFOTextBox.ReadOnly = true;
            this.eRROR_INFOTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.eRROR_INFOTextBox.Size = new System.Drawing.Size(811, 330);
            this.eRROR_INFOTextBox.TabIndex = 3;
            // 
            // lOG_DATETextBox
            // 
            this.lOG_DATETextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "LOG_DATE", true));
            this.lOG_DATETextBox.Location = new System.Drawing.Point(160, 69);
            this.lOG_DATETextBox.Name = "lOG_DATETextBox";
            this.lOG_DATETextBox.ReadOnly = true;
            this.lOG_DATETextBox.Size = new System.Drawing.Size(258, 22);
            this.lOG_DATETextBox.TabIndex = 44;
            // 
            // jOB_STARTTextBox
            // 
            this.jOB_STARTTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "JOB_START", true));
            this.jOB_STARTTextBox.Location = new System.Drawing.Point(160, 131);
            this.jOB_STARTTextBox.Name = "jOB_STARTTextBox";
            this.jOB_STARTTextBox.ReadOnly = true;
            this.jOB_STARTTextBox.Size = new System.Drawing.Size(258, 22);
            this.jOB_STARTTextBox.TabIndex = 45;
            // 
            // jOB_ENDTextBox
            // 
            this.jOB_ENDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "JOB_END", true));
            this.jOB_ENDTextBox.Location = new System.Drawing.Point(524, 128);
            this.jOB_ENDTextBox.Name = "jOB_ENDTextBox";
            this.jOB_ENDTextBox.ReadOnly = true;
            this.jOB_ENDTextBox.Size = new System.Drawing.Size(284, 22);
            this.jOB_ENDTextBox.TabIndex = 46;
            // 
            // JobLogView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(825, 365);
            this.Controls.Add(this.detailTab);
            this.Name = "JobLogView";
            this.Text = "Job Log";
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.detailTab.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.TabControl detailTab;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox jOB_DATATextBox;
        private System.Windows.Forms.TextBox jOB_CLASS_NAMETextBox;
        private System.Windows.Forms.TextBox jOB_GROUPTextBox;
        private System.Windows.Forms.TextBox jOB_NAMETextBox;
        private System.Windows.Forms.TextBox sCHEDULE_GROUPTextBox;
        private System.Windows.Forms.TextBox sCHEDULE_NAMETextBox;
        private System.Windows.Forms.TextBox sTATUSTextBox;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox eRROR_INFOTextBox;
        private System.Windows.Forms.TextBox jOB_ENDTextBox;
        private System.Windows.Forms.TextBox jOB_STARTTextBox;
        private System.Windows.Forms.TextBox lOG_DATETextBox;
    }
}