﻿using System;

namespace BVTC.Scheduler.UI
{
    partial class SchedulerMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnShutdown = new System.Windows.Forms.Button();
            this.status = new System.Windows.Forms.ListBox();
            this.mainTab = new System.Windows.Forms.TabControl();
            this.tabSchedule = new System.Windows.Forms.TabPage();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.schedulesTree = new System.Windows.Forms.TreeView();
            this.scheduledTreeContextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.runScheduleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cloneScheduleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteScheduleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnSchClone = new System.Windows.Forms.Button();
            this.txtScheduleCron = new System.Windows.Forms.TextBox();
            this.btnScheduleNew = new System.Windows.Forms.Button();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.btnRunScheduleNow = new System.Windows.Forms.Button();
            this.btnSaveSchedule = new System.Windows.Forms.Button();
            this.cmbScheduleJob = new System.Windows.Forms.ComboBox();
            this.btnDeleteSchedule = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtScheduleParm = new System.Windows.Forms.TextBox();
            this.txtScheduleDescription = new System.Windows.Forms.TextBox();
            this.txtScheduleName = new System.Windows.Forms.TextBox();
            this.txtScheduleGroup = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tabJobs = new System.Windows.Forms.TabPage();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.jobsTree = new System.Windows.Forms.TreeView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnJobNew = new System.Windows.Forms.Button();
            this.cmbJobTypeList = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtJobParms = new System.Windows.Forms.TextBox();
            this.txtJobType = new System.Windows.Forms.TextBox();
            this.btnRunNow = new System.Windows.Forms.Button();
            this.txtJobDescription = new System.Windows.Forms.TextBox();
            this.txtJobName = new System.Windows.Forms.TextBox();
            this.txtJobGroup = new System.Windows.Forms.TextBox();
            this.jobDurable = new System.Windows.Forms.CheckBox();
            this.lbljobDescription = new System.Windows.Forms.Label();
            this.lbljobName = new System.Windows.Forms.Label();
            this.lbljobGroup = new System.Windows.Forms.Label();
            this.tabExecuting = new System.Windows.Forms.TabPage();
            this.ExecutingJobsDataGridiew = new System.Windows.Forms.DataGridView();
            this.tabJobTypes = new System.Windows.Forms.TabPage();
            this.jobTypesDataGridView = new System.Windows.Forms.DataGridView();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabStatus = new System.Windows.Forms.TabPage();
            this.btnRefreshStatus = new System.Windows.Forms.Button();
            this.tabJobLog = new System.Windows.Forms.TabPage();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.JobLogDataGrid = new System.Windows.Forms.DataGridView();
            this.dataGridViewButtonColumn1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.jOBSTARTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jOBENDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.JOB_GROUP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.JOB_NAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jobLogDataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnRefreshJobLog = new System.Windows.Forms.Button();
            this.refreshTimmer = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.connectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.disconnectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.importToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refreshToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.strConnectionStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.mainTab.SuspendLayout();
            this.tabSchedule.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.scheduledTreeContextMenu.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabJobs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabExecuting.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ExecutingJobsDataGridiew)).BeginInit();
            this.tabJobTypes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.jobTypesDataGridView)).BeginInit();
            this.tabStatus.SuspendLayout();
            this.tabJobLog.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.JobLogDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.jobLogDataBindingSource)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(502, 7);
            this.btnStart.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(65, 19);
            this.btnStart.TabIndex = 3;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.BtnStartClick);
            // 
            // btnShutdown
            // 
            this.btnShutdown.Location = new System.Drawing.Point(502, 31);
            this.btnShutdown.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnShutdown.Name = "btnShutdown";
            this.btnShutdown.Size = new System.Drawing.Size(65, 19);
            this.btnShutdown.TabIndex = 5;
            this.btnShutdown.Text = "Shutdown";
            this.btnShutdown.UseVisualStyleBackColor = true;
            this.btnShutdown.Click += new System.EventHandler(this.BtnShutdownClick);
            // 
            // status
            // 
            this.status.Enabled = false;
            this.status.FormattingEnabled = true;
            this.status.Location = new System.Drawing.Point(4, 7);
            this.status.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.status.Name = "status";
            this.status.Size = new System.Drawing.Size(494, 290);
            this.status.TabIndex = 6;
            // 
            // mainTab
            // 
            this.mainTab.Controls.Add(this.tabSchedule);
            this.mainTab.Controls.Add(this.tabJobs);
            this.mainTab.Controls.Add(this.tabExecuting);
            this.mainTab.Controls.Add(this.tabJobTypes);
            this.mainTab.Controls.Add(this.tabStatus);
            this.mainTab.Controls.Add(this.tabJobLog);
            this.mainTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainTab.Location = new System.Drawing.Point(0, 24);
            this.mainTab.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.mainTab.Name = "mainTab";
            this.mainTab.SelectedIndex = 0;
            this.mainTab.Size = new System.Drawing.Size(772, 423);
            this.mainTab.TabIndex = 7;
            this.mainTab.SelectedIndexChanged += new System.EventHandler(this.MainTabSelectedIndexChanged);
            // 
            // tabSchedule
            // 
            this.tabSchedule.Controls.Add(this.splitContainer2);
            this.tabSchedule.Location = new System.Drawing.Point(4, 22);
            this.tabSchedule.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabSchedule.Name = "tabSchedule";
            this.tabSchedule.Size = new System.Drawing.Size(764, 397);
            this.tabSchedule.TabIndex = 4;
            this.tabSchedule.Text = "Schedule";
            this.tabSchedule.UseVisualStyleBackColor = true;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.schedulesTree);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.groupBox2);
            this.splitContainer2.Size = new System.Drawing.Size(764, 397);
            this.splitContainer2.SplitterDistance = 279;
            this.splitContainer2.SplitterWidth = 3;
            this.splitContainer2.TabIndex = 7;
            // 
            // schedulesTree
            // 
            this.schedulesTree.ContextMenuStrip = this.scheduledTreeContextMenu;
            this.schedulesTree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.schedulesTree.Location = new System.Drawing.Point(0, 0);
            this.schedulesTree.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.schedulesTree.Name = "schedulesTree";
            this.schedulesTree.Size = new System.Drawing.Size(279, 397);
            this.schedulesTree.TabIndex = 0;
            this.schedulesTree.BeforeSelect += new System.Windows.Forms.TreeViewCancelEventHandler(this.SchedulesTreeBeforeSelect);
            this.schedulesTree.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.SchedulesTreeViewAfterSelect);
            this.schedulesTree.MouseDown += new System.Windows.Forms.MouseEventHandler(this.SchedulesTreeMouseDown);
            // 
            // scheduledTreeContextMenu
            // 
            this.scheduledTreeContextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.runScheduleToolStripMenuItem,
            this.cloneScheduleToolStripMenuItem,
            this.deleteScheduleToolStripMenuItem});
            this.scheduledTreeContextMenu.Name = "scheduledTreeContextMenu";
            this.scheduledTreeContextMenu.Size = new System.Drawing.Size(133, 70);
            // 
            // runScheduleToolStripMenuItem
            // 
            this.runScheduleToolStripMenuItem.Name = "runScheduleToolStripMenuItem";
            this.runScheduleToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.runScheduleToolStripMenuItem.Text = "Run";
            this.runScheduleToolStripMenuItem.Click += new System.EventHandler(this.RunToolStripMenuItemClick);
            // 
            // cloneScheduleToolStripMenuItem
            // 
            this.cloneScheduleToolStripMenuItem.Name = "cloneScheduleToolStripMenuItem";
            this.cloneScheduleToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.cloneScheduleToolStripMenuItem.Text = "Clone";
            this.cloneScheduleToolStripMenuItem.Click += new System.EventHandler(this.CloneScheduleToolStripMenuItemClick);
            // 
            // deleteScheduleToolStripMenuItem
            // 
            this.deleteScheduleToolStripMenuItem.Name = "deleteScheduleToolStripMenuItem";
            this.deleteScheduleToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.deleteScheduleToolStripMenuItem.Text = "Delete";
            this.deleteScheduleToolStripMenuItem.Click += new System.EventHandler(this.DeleteScheduleToolStripMenuItemClick);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.btnSchClone);
            this.groupBox2.Controls.Add(this.txtScheduleCron);
            this.groupBox2.Controls.Add(this.btnScheduleNew);
            this.groupBox2.Controls.Add(this.linkLabel2);
            this.groupBox2.Controls.Add(this.btnRunScheduleNow);
            this.groupBox2.Controls.Add(this.btnSaveSchedule);
            this.groupBox2.Controls.Add(this.cmbScheduleJob);
            this.groupBox2.Controls.Add(this.btnDeleteSchedule);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtScheduleParm);
            this.groupBox2.Controls.Add(this.txtScheduleDescription);
            this.groupBox2.Controls.Add(this.txtScheduleName);
            this.groupBox2.Controls.Add(this.txtScheduleGroup);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox2.Size = new System.Drawing.Size(482, 339);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Schedule Details";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 119);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(24, 13);
            this.label6.TabIndex = 25;
            this.label6.Text = "Job";
            // 
            // btnSchClone
            // 
            this.btnSchClone.Enabled = false;
            this.btnSchClone.Location = new System.Drawing.Point(133, 314);
            this.btnSchClone.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSchClone.Name = "btnSchClone";
            this.btnSchClone.Size = new System.Drawing.Size(56, 19);
            this.btnSchClone.TabIndex = 6;
            this.btnSchClone.Text = "Clone";
            this.btnSchClone.UseVisualStyleBackColor = true;
            this.btnSchClone.Click += new System.EventHandler(this.BtnSchCloneClick);
            // 
            // txtScheduleCron
            // 
            this.txtScheduleCron.Enabled = false;
            this.txtScheduleCron.Location = new System.Drawing.Point(70, 86);
            this.txtScheduleCron.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtScheduleCron.Name = "txtScheduleCron";
            this.txtScheduleCron.Size = new System.Drawing.Size(352, 20);
            this.txtScheduleCron.TabIndex = 19;
            // 
            // btnScheduleNew
            // 
            this.btnScheduleNew.Enabled = false;
            this.btnScheduleNew.Location = new System.Drawing.Point(72, 314);
            this.btnScheduleNew.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnScheduleNew.Name = "btnScheduleNew";
            this.btnScheduleNew.Size = new System.Drawing.Size(56, 19);
            this.btnScheduleNew.TabIndex = 2;
            this.btnScheduleNew.Text = "New";
            this.btnScheduleNew.UseVisualStyleBackColor = true;
            this.btnScheduleNew.Click += new System.EventHandler(this.BtnNewScheduleClick);
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Location = new System.Drawing.Point(11, 92);
            this.linkLabel2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(29, 13);
            this.linkLabel2.TabIndex = 24;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Cron";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLabel2LinkClicked);
            // 
            // btnRunScheduleNow
            // 
            this.btnRunScheduleNow.Enabled = false;
            this.btnRunScheduleNow.Location = new System.Drawing.Point(11, 314);
            this.btnRunScheduleNow.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnRunScheduleNow.Name = "btnRunScheduleNow";
            this.btnRunScheduleNow.Size = new System.Drawing.Size(56, 19);
            this.btnRunScheduleNow.TabIndex = 5;
            this.btnRunScheduleNow.Text = "Run Now";
            this.btnRunScheduleNow.UseVisualStyleBackColor = true;
            this.btnRunScheduleNow.Click += new System.EventHandler(this.BtnRunScheduleNowClick);
            // 
            // btnSaveSchedule
            // 
            this.btnSaveSchedule.Enabled = false;
            this.btnSaveSchedule.Location = new System.Drawing.Point(194, 314);
            this.btnSaveSchedule.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSaveSchedule.Name = "btnSaveSchedule";
            this.btnSaveSchedule.Size = new System.Drawing.Size(56, 19);
            this.btnSaveSchedule.TabIndex = 3;
            this.btnSaveSchedule.Text = "Save";
            this.btnSaveSchedule.UseVisualStyleBackColor = true;
            this.btnSaveSchedule.Click += new System.EventHandler(this.BtnSaveScheduleClick);
            // 
            // cmbScheduleJob
            // 
            this.cmbScheduleJob.Enabled = false;
            this.cmbScheduleJob.FormattingEnabled = true;
            this.cmbScheduleJob.Location = new System.Drawing.Point(70, 115);
            this.cmbScheduleJob.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cmbScheduleJob.Name = "cmbScheduleJob";
            this.cmbScheduleJob.Size = new System.Drawing.Size(352, 21);
            this.cmbScheduleJob.TabIndex = 23;
            // 
            // btnDeleteSchedule
            // 
            this.btnDeleteSchedule.Enabled = false;
            this.btnDeleteSchedule.Location = new System.Drawing.Point(365, 314);
            this.btnDeleteSchedule.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnDeleteSchedule.Name = "btnDeleteSchedule";
            this.btnDeleteSchedule.Size = new System.Drawing.Size(56, 19);
            this.btnDeleteSchedule.TabIndex = 4;
            this.btnDeleteSchedule.Text = "Delete";
            this.btnDeleteSchedule.UseVisualStyleBackColor = true;
            this.btnDeleteSchedule.Click += new System.EventHandler(this.BtnDeleteScheduleClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 145);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 21;
            this.label2.Text = "Parameters";
            // 
            // txtScheduleParm
            // 
            this.txtScheduleParm.Enabled = false;
            this.txtScheduleParm.Location = new System.Drawing.Point(11, 169);
            this.txtScheduleParm.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtScheduleParm.Multiline = true;
            this.txtScheduleParm.Name = "txtScheduleParm";
            this.txtScheduleParm.Size = new System.Drawing.Size(411, 136);
            this.txtScheduleParm.TabIndex = 24;
            // 
            // txtScheduleDescription
            // 
            this.txtScheduleDescription.Enabled = false;
            this.txtScheduleDescription.Location = new System.Drawing.Point(70, 63);
            this.txtScheduleDescription.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtScheduleDescription.Name = "txtScheduleDescription";
            this.txtScheduleDescription.Size = new System.Drawing.Size(352, 20);
            this.txtScheduleDescription.TabIndex = 18;
            // 
            // txtScheduleName
            // 
            this.txtScheduleName.Enabled = false;
            this.txtScheduleName.Location = new System.Drawing.Point(70, 39);
            this.txtScheduleName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtScheduleName.Name = "txtScheduleName";
            this.txtScheduleName.Size = new System.Drawing.Size(352, 20);
            this.txtScheduleName.TabIndex = 17;
            // 
            // txtScheduleGroup
            // 
            this.txtScheduleGroup.Enabled = false;
            this.txtScheduleGroup.Location = new System.Drawing.Point(70, 15);
            this.txtScheduleGroup.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtScheduleGroup.Name = "txtScheduleGroup";
            this.txtScheduleGroup.Size = new System.Drawing.Size(352, 20);
            this.txtScheduleGroup.TabIndex = 16;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 67);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "Description";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 43);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 19);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "Group";
            // 
            // tabJobs
            // 
            this.tabJobs.Controls.Add(this.splitContainer3);
            this.tabJobs.Location = new System.Drawing.Point(4, 22);
            this.tabJobs.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabJobs.Name = "tabJobs";
            this.tabJobs.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabJobs.Size = new System.Drawing.Size(764, 403);
            this.tabJobs.TabIndex = 0;
            this.tabJobs.Text = "Jobs";
            this.tabJobs.UseVisualStyleBackColor = true;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(2, 2);
            this.splitContainer3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.jobsTree);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.groupBox1);
            this.splitContainer3.Size = new System.Drawing.Size(761, 401);
            this.splitContainer3.SplitterDistance = 338;
            this.splitContainer3.SplitterWidth = 3;
            this.splitContainer3.TabIndex = 13;
            // 
            // jobsTree
            // 
            this.jobsTree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jobsTree.Location = new System.Drawing.Point(0, 0);
            this.jobsTree.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.jobsTree.Name = "jobsTree";
            this.jobsTree.Size = new System.Drawing.Size(254, 401);
            this.jobsTree.TabIndex = 0;
            this.jobsTree.BeforeSelect += new System.Windows.Forms.TreeViewCancelEventHandler(this.JobsTreeBeforeSelect);
            this.jobsTree.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.JobsTreeViewAfterSelect);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.btnDelete);
            this.groupBox1.Controls.Add(this.btnSave);
            this.groupBox1.Controls.Add(this.btnJobNew);
            this.groupBox1.Controls.Add(this.cmbJobTypeList);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtJobParms);
            this.groupBox1.Controls.Add(this.txtJobType);
            this.groupBox1.Controls.Add(this.btnRunNow);
            this.groupBox1.Controls.Add(this.txtJobDescription);
            this.groupBox1.Controls.Add(this.txtJobName);
            this.groupBox1.Controls.Add(this.txtJobGroup);
            this.groupBox1.Controls.Add(this.jobDurable);
            this.groupBox1.Controls.Add(this.lbljobDescription);
            this.groupBox1.Controls.Add(this.lbljobName);
            this.groupBox1.Controls.Add(this.lbljobGroup);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(505, 346);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Job Details";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 94);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Job Type";
            // 
            // btnDelete
            // 
            this.btnDelete.Enabled = false;
            this.btnDelete.Location = new System.Drawing.Point(370, 308);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(56, 19);
            this.btnDelete.TabIndex = 10;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.BtnDeleteJobClick);
            // 
            // btnSave
            // 
            this.btnSave.Enabled = false;
            this.btnSave.Location = new System.Drawing.Point(140, 308);
            this.btnSave.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(56, 19);
            this.btnSave.TabIndex = 11;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.BtnSaveJobClick);
            // 
            // btnJobNew
            // 
            this.btnJobNew.Enabled = false;
            this.btnJobNew.Location = new System.Drawing.Point(79, 308);
            this.btnJobNew.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnJobNew.Name = "btnJobNew";
            this.btnJobNew.Size = new System.Drawing.Size(56, 19);
            this.btnJobNew.TabIndex = 12;
            this.btnJobNew.Text = "New";
            this.btnJobNew.UseVisualStyleBackColor = true;
            this.btnJobNew.Click += new System.EventHandler(this.BtnNewJobClick);
            // 
            // cmbJobTypeList
            // 
            this.cmbJobTypeList.FormattingEnabled = true;
            this.cmbJobTypeList.Location = new System.Drawing.Point(75, 114);
            this.cmbJobTypeList.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cmbJobTypeList.Name = "cmbJobTypeList";
            this.cmbJobTypeList.Size = new System.Drawing.Size(352, 21);
            this.cmbJobTypeList.TabIndex = 12;
            this.cmbJobTypeList.SelectedIndexChanged += new System.EventHandler(this.CmbTypeListSelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 144);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Parameters";
            // 
            // txtJobParms
            // 
            this.txtJobParms.Location = new System.Drawing.Point(16, 168);
            this.txtJobParms.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtJobParms.Multiline = true;
            this.txtJobParms.Name = "txtJobParms";
            this.txtJobParms.Size = new System.Drawing.Size(411, 136);
            this.txtJobParms.TabIndex = 9;
            // 
            // txtJobType
            // 
            this.txtJobType.Enabled = false;
            this.txtJobType.Location = new System.Drawing.Point(75, 91);
            this.txtJobType.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtJobType.Name = "txtJobType";
            this.txtJobType.Size = new System.Drawing.Size(352, 20);
            this.txtJobType.TabIndex = 8;
            // 
            // btnRunNow
            // 
            this.btnRunNow.Enabled = false;
            this.btnRunNow.Location = new System.Drawing.Point(18, 308);
            this.btnRunNow.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnRunNow.Name = "btnRunNow";
            this.btnRunNow.Size = new System.Drawing.Size(56, 19);
            this.btnRunNow.TabIndex = 9;
            this.btnRunNow.Text = "Run Now";
            this.btnRunNow.UseVisualStyleBackColor = true;
            this.btnRunNow.Click += new System.EventHandler(this.BtnRunNowClick);
            // 
            // txtJobDescription
            // 
            this.txtJobDescription.Enabled = false;
            this.txtJobDescription.Location = new System.Drawing.Point(75, 62);
            this.txtJobDescription.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtJobDescription.Name = "txtJobDescription";
            this.txtJobDescription.Size = new System.Drawing.Size(352, 20);
            this.txtJobDescription.TabIndex = 6;
            // 
            // txtJobName
            // 
            this.txtJobName.Enabled = false;
            this.txtJobName.Location = new System.Drawing.Point(75, 38);
            this.txtJobName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtJobName.Name = "txtJobName";
            this.txtJobName.Size = new System.Drawing.Size(352, 20);
            this.txtJobName.TabIndex = 5;
            // 
            // txtJobGroup
            // 
            this.txtJobGroup.Enabled = false;
            this.txtJobGroup.Location = new System.Drawing.Point(75, 14);
            this.txtJobGroup.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtJobGroup.Name = "txtJobGroup";
            this.txtJobGroup.Size = new System.Drawing.Size(352, 20);
            this.txtJobGroup.TabIndex = 4;
            // 
            // jobDurable
            // 
            this.jobDurable.AutoSize = true;
            this.jobDurable.Checked = true;
            this.jobDurable.CheckState = System.Windows.Forms.CheckState.Checked;
            this.jobDurable.Location = new System.Drawing.Point(309, 141);
            this.jobDurable.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.jobDurable.Name = "jobDurable";
            this.jobDurable.Size = new System.Drawing.Size(47, 14);
            this.jobDurable.TabIndex = 3;
            this.jobDurable.Text = "Durable";
            this.jobDurable.UseVisualStyleBackColor = true;
            // 
            // lbljobDescription
            // 
            this.lbljobDescription.AutoSize = true;
            this.lbljobDescription.Location = new System.Drawing.Point(14, 66);
            this.lbljobDescription.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbljobDescription.Name = "lbljobDescription";
            this.lbljobDescription.Size = new System.Drawing.Size(60, 13);
            this.lbljobDescription.TabIndex = 2;
            this.lbljobDescription.Text = "Description";
            // 
            // lbljobName
            // 
            this.lbljobName.AutoSize = true;
            this.lbljobName.Location = new System.Drawing.Point(14, 42);
            this.lbljobName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbljobName.Name = "lbljobName";
            this.lbljobName.Size = new System.Drawing.Size(35, 13);
            this.lbljobName.TabIndex = 1;
            this.lbljobName.Text = "Name";
            // 
            // lbljobGroup
            // 
            this.lbljobGroup.AutoSize = true;
            this.lbljobGroup.Location = new System.Drawing.Point(14, 18);
            this.lbljobGroup.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbljobGroup.Name = "lbljobGroup";
            this.lbljobGroup.Size = new System.Drawing.Size(36, 13);
            this.lbljobGroup.TabIndex = 0;
            this.lbljobGroup.Text = "Group";
            // 
            // tabExecuting
            // 
            this.tabExecuting.Controls.Add(this.ExecutingJobsDataGridiew);
            this.tabExecuting.Location = new System.Drawing.Point(4, 22);
            this.tabExecuting.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabExecuting.Name = "tabExecuting";
            this.tabExecuting.Size = new System.Drawing.Size(764, 403);
            this.tabExecuting.TabIndex = 3;
            this.tabExecuting.Text = "Executing";
            this.tabExecuting.UseVisualStyleBackColor = true;
            // 
            // ExecutingJobsDataGridiew
            // 
            this.ExecutingJobsDataGridiew.AllowUserToAddRows = false;
            this.ExecutingJobsDataGridiew.AllowUserToDeleteRows = false;
            this.ExecutingJobsDataGridiew.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ExecutingJobsDataGridiew.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ExecutingJobsDataGridiew.Location = new System.Drawing.Point(0, 0);
            this.ExecutingJobsDataGridiew.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ExecutingJobsDataGridiew.Name = "ExecutingJobsDataGridiew";
            this.ExecutingJobsDataGridiew.ReadOnly = true;
            this.ExecutingJobsDataGridiew.RowTemplate.Height = 24;
            this.ExecutingJobsDataGridiew.Size = new System.Drawing.Size(766, 405);
            this.ExecutingJobsDataGridiew.TabIndex = 0;
            // 
            // tabJobTypes
            // 
            this.tabJobTypes.Controls.Add(this.jobTypesDataGridView);
            this.tabJobTypes.Location = new System.Drawing.Point(4, 22);
            this.tabJobTypes.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabJobTypes.Name = "tabJobTypes";
            this.tabJobTypes.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabJobTypes.Size = new System.Drawing.Size(764, 403);
            this.tabJobTypes.TabIndex = 2;
            this.tabJobTypes.Text = "Job Types";
            this.tabJobTypes.UseVisualStyleBackColor = true;
            // 
            // jobTypesDataGridView
            // 
            this.jobTypesDataGridView.AllowUserToAddRows = false;
            this.jobTypesDataGridView.AllowUserToDeleteRows = false;
            this.jobTypesDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.jobTypesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.jobTypesDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Description,
            this.Type});
            this.jobTypesDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jobTypesDataGridView.Location = new System.Drawing.Point(2, 2);
            this.jobTypesDataGridView.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.jobTypesDataGridView.Name = "jobTypesDataGridView";
            this.jobTypesDataGridView.ReadOnly = true;
            this.jobTypesDataGridView.RowTemplate.Height = 24;
            this.jobTypesDataGridView.Size = new System.Drawing.Size(761, 401);
            this.jobTypesDataGridView.TabIndex = 0;
            // 
            // Description
            // 
            this.Description.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Description.DataPropertyName = "Description";
            this.Description.HeaderText = "Description";
            this.Description.Name = "Description";
            this.Description.ReadOnly = true;
            // 
            // Type
            // 
            this.Type.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Type.DataPropertyName = "AssemblyQualifiedTypeName";
            this.Type.HeaderText = "Type";
            this.Type.Name = "Type";
            this.Type.ReadOnly = true;
            // 
            // tabStatus
            // 
            this.tabStatus.Controls.Add(this.btnRefreshStatus);
            this.tabStatus.Controls.Add(this.status);
            this.tabStatus.Controls.Add(this.btnShutdown);
            this.tabStatus.Controls.Add(this.btnStart);
            this.tabStatus.Location = new System.Drawing.Point(4, 22);
            this.tabStatus.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabStatus.Name = "tabStatus";
            this.tabStatus.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabStatus.Size = new System.Drawing.Size(764, 403);
            this.tabStatus.TabIndex = 1;
            this.tabStatus.Text = "Status";
            this.tabStatus.UseVisualStyleBackColor = true;
            // 
            // btnRefreshStatus
            // 
            this.btnRefreshStatus.Location = new System.Drawing.Point(503, 100);
            this.btnRefreshStatus.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnRefreshStatus.Name = "btnRefreshStatus";
            this.btnRefreshStatus.Size = new System.Drawing.Size(56, 19);
            this.btnRefreshStatus.TabIndex = 7;
            this.btnRefreshStatus.Text = "Refresh";
            this.btnRefreshStatus.UseVisualStyleBackColor = true;
            this.btnRefreshStatus.Click += new System.EventHandler(this.BtnRefreshStatusClick);
            // 
            // tabJobLog
            // 
            this.tabJobLog.Controls.Add(this.splitContainer4);
            this.tabJobLog.Location = new System.Drawing.Point(4, 22);
            this.tabJobLog.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabJobLog.Name = "tabJobLog";
            this.tabJobLog.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabJobLog.Size = new System.Drawing.Size(764, 403);
            this.tabJobLog.TabIndex = 5;
            this.tabJobLog.Text = "Job Log";
            this.tabJobLog.UseVisualStyleBackColor = true;
            // 
            // splitContainer4
            // 
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(2, 2);
            this.splitContainer4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.splitContainer4.Name = "splitContainer4";
            this.splitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.JobLogDataGrid);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.btnRefreshJobLog);
            this.splitContainer4.Size = new System.Drawing.Size(761, 401);
            this.splitContainer4.SplitterDistance = 460;
            this.splitContainer4.SplitterWidth = 3;
            this.splitContainer4.TabIndex = 0;
            // 
            // JobLogDataGrid
            // 
            this.JobLogDataGrid.AutoGenerateColumns = false;
            this.JobLogDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.JobLogDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewButtonColumn1,
            this.jOBSTARTDataGridViewTextBoxColumn,
            this.jOBENDDataGridViewTextBoxColumn,
            this.JOB_GROUP,
            this.JOB_NAME});
            this.JobLogDataGrid.DataSource = this.jobLogDataBindingSource;
            this.JobLogDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.JobLogDataGrid.Location = new System.Drawing.Point(0, 0);
            this.JobLogDataGrid.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.JobLogDataGrid.MultiSelect = false;
            this.JobLogDataGrid.Name = "JobLogDataGrid";
            this.JobLogDataGrid.ReadOnly = true;
            this.JobLogDataGrid.RowTemplate.Height = 24;
            this.JobLogDataGrid.Size = new System.Drawing.Size(761, 374);
            this.JobLogDataGrid.TabIndex = 0;
            this.JobLogDataGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.JobLogDataGridCellContentClick);
            // 
            // dataGridViewButtonColumn1
            // 
            this.dataGridViewButtonColumn1.DataPropertyName = "STATUS";
            this.dataGridViewButtonColumn1.HeaderText = "STATUS";
            this.dataGridViewButtonColumn1.Name = "dataGridViewButtonColumn1";
            this.dataGridViewButtonColumn1.ReadOnly = true;
            // 
            // jOBSTARTDataGridViewTextBoxColumn
            // 
            this.jOBSTARTDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.jOBSTARTDataGridViewTextBoxColumn.DataPropertyName = "JOB_START";
            this.jOBSTARTDataGridViewTextBoxColumn.HeaderText = "JOB_START";
            this.jOBSTARTDataGridViewTextBoxColumn.Name = "jOBSTARTDataGridViewTextBoxColumn";
            this.jOBSTARTDataGridViewTextBoxColumn.ReadOnly = true;
            this.jOBSTARTDataGridViewTextBoxColumn.Width = 94;
            // 
            // jOBENDDataGridViewTextBoxColumn
            // 
            this.jOBENDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.jOBENDDataGridViewTextBoxColumn.DataPropertyName = "JOB_END";
            this.jOBENDDataGridViewTextBoxColumn.HeaderText = "JOB_END";
            this.jOBENDDataGridViewTextBoxColumn.Name = "jOBENDDataGridViewTextBoxColumn";
            this.jOBENDDataGridViewTextBoxColumn.ReadOnly = true;
            this.jOBENDDataGridViewTextBoxColumn.Width = 81;
            // 
            // JOB_GROUP
            // 
            this.JOB_GROUP.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.JOB_GROUP.DataPropertyName = "JOB_GROUP";
            this.JOB_GROUP.HeaderText = "JOB_GROUP";
            this.JOB_GROUP.Name = "JOB_GROUP";
            this.JOB_GROUP.ReadOnly = true;
            this.JOB_GROUP.Width = 97;
            // 
            // JOB_NAME
            // 
            this.JOB_NAME.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.JOB_NAME.DataPropertyName = "JOB_NAME";
            this.JOB_NAME.HeaderText = "JOB_NAME";
            this.JOB_NAME.Name = "JOB_NAME";
            this.JOB_NAME.ReadOnly = true;
            // 
            // jobLogDataBindingSource
            // 
            this.jobLogDataBindingSource.DataSource = typeof(BVTC.Scheduler.UI.SchedulerService.JobLogData);
            // 
            // btnRefreshJobLog
            // 
            this.btnRefreshJobLog.Location = new System.Drawing.Point(4, 2);
            this.btnRefreshJobLog.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnRefreshJobLog.Name = "btnRefreshJobLog";
            this.btnRefreshJobLog.Size = new System.Drawing.Size(56, 19);
            this.btnRefreshJobLog.TabIndex = 0;
            this.btnRefreshJobLog.Text = "Refresh";
            this.btnRefreshJobLog.UseVisualStyleBackColor = true;
            this.btnRefreshJobLog.Click += new System.EventHandler(this.BtnRefreshJobLogClick);
            // 
            // refreshTimmer
            // 
            this.refreshTimmer.Tick += new System.EventHandler(this.RefreshTimmerTick);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.viewToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(772, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.connectToolStripMenuItem,
            this.disconnectToolStripMenuItem,
            this.exportToolStripMenuItem1,
            this.importToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // connectToolStripMenuItem
            // 
            this.connectToolStripMenuItem.Name = "connectToolStripMenuItem";
            this.connectToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.connectToolStripMenuItem.Text = "Connect";
            this.connectToolStripMenuItem.Click += new System.EventHandler(this.ConnectToolStripMenuItemClick);
            // 
            // disconnectToolStripMenuItem
            // 
            this.disconnectToolStripMenuItem.Name = "disconnectToolStripMenuItem";
            this.disconnectToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.disconnectToolStripMenuItem.Text = "Disconnect";
            this.disconnectToolStripMenuItem.Click += new System.EventHandler(this.DisconnectToolStripMenuItemClick);
            // 
            // exportToolStripMenuItem1
            // 
            this.exportToolStripMenuItem1.Name = "exportToolStripMenuItem1";
            this.exportToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.exportToolStripMenuItem1.Text = "Export";
            this.exportToolStripMenuItem1.Click += new System.EventHandler(this.exportToolStripMenuItem1_Click);
            // 
            // importToolStripMenuItem
            // 
            this.importToolStripMenuItem.Name = "importToolStripMenuItem";
            this.importToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.importToolStripMenuItem.Text = "Import";
            this.importToolStripMenuItem.Click += new System.EventHandler(this.importToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.ExitToolStripMenuItemClick);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.refreshToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.viewToolStripMenuItem.Text = "&View";
            // 
            // refreshToolStripMenuItem
            // 
            this.refreshToolStripMenuItem.Name = "refreshToolStripMenuItem";
            this.refreshToolStripMenuItem.Size = new System.Drawing.Size(113, 22);
            this.refreshToolStripMenuItem.Text = "Refresh";
            this.refreshToolStripMenuItem.Click += new System.EventHandler(this.RefreshToolStripMenuItemClick);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.strConnectionStatus});
            this.statusStrip1.Location = new System.Drawing.Point(0, 447);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 10, 0);
            this.statusStrip1.Size = new System.Drawing.Size(772, 22);
            this.statusStrip1.TabIndex = 999;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // strConnectionStatus
            // 
            this.strConnectionStatus.Name = "strConnectionStatus";
            this.strConnectionStatus.Size = new System.Drawing.Size(79, 17);
            this.strConnectionStatus.Text = "Disconnected";
            // 
            // SchedulerMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(772, 469);
            this.Controls.Add(this.mainTab);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "SchedulerMain";
            this.Text = "Scheduler";
            this.mainTab.ResumeLayout(false);
            this.tabSchedule.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.scheduledTreeContextMenu.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabJobs.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabExecuting.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ExecutingJobsDataGridiew)).EndInit();
            this.tabJobTypes.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.jobTypesDataGridView)).EndInit();
            this.tabStatus.ResumeLayout(false);
            this.tabJobLog.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.JobLogDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.jobLogDataBindingSource)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnShutdown;
        private System.Windows.Forms.ListBox status;
        private System.Windows.Forms.TabControl mainTab;
        private System.Windows.Forms.TabPage tabJobs;
        private System.Windows.Forms.TabPage tabStatus;
        private System.Windows.Forms.TreeView jobsTree;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox jobDurable;
        private System.Windows.Forms.Label lbljobDescription;
        private System.Windows.Forms.Label lbljobName;
        private System.Windows.Forms.Label lbljobGroup;
        private System.Windows.Forms.TextBox txtJobType;
        private System.Windows.Forms.TextBox txtJobDescription;
        private System.Windows.Forms.TextBox txtJobName;
        private System.Windows.Forms.TextBox txtJobGroup;
        private System.Windows.Forms.Button btnRunNow;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TabPage tabJobTypes;
        private System.Windows.Forms.DataGridView jobTypesDataGridView;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtJobParms;
        private System.Windows.Forms.TabPage tabExecuting;
        private System.Windows.Forms.Button btnJobNew;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TabPage tabSchedule;
        private System.Windows.Forms.Button btnDeleteSchedule;
        private System.Windows.Forms.Button btnSaveSchedule;
        private System.Windows.Forms.Button btnScheduleNew;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TreeView schedulesTree;
        private System.Windows.Forms.ComboBox cmbJobTypeList;
        private System.Windows.Forms.Button btnRefreshStatus;

        private System.Windows.Forms.Timer refreshTimmer;
        private System.Windows.Forms.TextBox txtScheduleCron;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.ComboBox cmbScheduleJob;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtScheduleParm;
        private System.Windows.Forms.TextBox txtScheduleDescription;
        private System.Windows.Forms.TextBox txtScheduleName;
        private System.Windows.Forms.TextBox txtScheduleGroup;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnRunScheduleNow;
        private System.Windows.Forms.DataGridViewTextBoxColumn Description;
        private System.Windows.Forms.DataGridViewTextBoxColumn Type;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem refreshToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem connectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem disconnectToolStripMenuItem;
        private System.Windows.Forms.Button btnSchClone;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel strConnectionStatus;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.ContextMenuStrip scheduledTreeContextMenu;
        private System.Windows.Forms.ToolStripMenuItem runScheduleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cloneScheduleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteScheduleToolStripMenuItem;
        private System.Windows.Forms.TabPage tabJobLog;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.DataGridView JobLogDataGrid;
        private System.Windows.Forms.Button btnRefreshJobLog;
        private System.Windows.Forms.BindingSource jobLogDataBindingSource;
        private System.Windows.Forms.DataGridView ExecutingJobsDataGridiew;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewButtonColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn jOBSTARTDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn jOBENDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn JOB_GROUP;
        private System.Windows.Forms.DataGridViewTextBoxColumn JOB_NAME;
        private System.Windows.Forms.ToolStripMenuItem exportToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem importToolStripMenuItem;
    }
}

