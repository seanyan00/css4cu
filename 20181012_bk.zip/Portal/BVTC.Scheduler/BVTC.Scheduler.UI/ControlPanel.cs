﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Configuration;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using BVTC.Scheduler.UI.Properties;
using BVTC.Scheduler.UI.SchedulerService;

namespace BVTC.Scheduler.UI
{
    public partial class SchedulerMain : Form
    {

        const int SCHEDULES_TAB_INDEX = 0;
        const int JOBS_TAB_INDEX = 1;
        const int EXECUTING_JOBS_TAB_INDEX = 2;
        const int REGISTERED_JOB_TYPES_TAB_INDEX = 3;
        const int JOB_LOG_TAB_INDEX = 5;
        const int VALUE_SET_NAME_INDEX = 0;
        const int VALUE_VALUE_NAME_INDEX = 1;

        private const string local_binding = "local";
        private const string manage_binding = "manage";

        private string _activeBinding = local_binding;

        List<string> _endpointNames = new List<string>();

        private SchedulerServiceClient _client;
        private SchedulerServiceInfoClient _infoClient;

        readonly string[] _newLine = new string[] { "\n" };

        private IEnumerable<JobData> _jobs;
        private IEnumerable<JobType> _jobTypes;
        private IEnumerable<ScheduledData> _schedules;
        private IEnumerable<JobData> _executingJobs;
        private IEnumerable<JobLogData> _jobLogData;
        private ServiceState _serviceState;

        private bool _connected = false;

        private bool _isAddingJob;
        private bool _isEditingJob;

        private bool _isAddingSchedule;
        private bool _isEditingSchedule;

        private JobData _selectedJobData;
        private ScheduledData _selectedScheduledData;

        private void Connect()
        {
            try
            {
                using (new CursorKeeper(Cursors.WaitCursor))
                {
                    if (_infoClient == null || _infoClient.State == CommunicationState.Faulted)
                    {
                        _infoClient = new SchedulerServiceInfoClient(_activeBinding);
                        _infoClient.Open();
                    }
                }


                if (_activeBinding == local_binding)
                {

                    using (new CursorKeeper(Cursors.WaitCursor))
                    {
                        if (_client == null || _client.State == CommunicationState.Faulted)
                        {
                            _client = new SchedulerServiceClient(manage_binding);
                            _client.Open();
                        }
                    }
                }

                _connected = true;
                refreshTimmer.Interval = (int)TimeSpan.FromSeconds(2).TotalMilliseconds;
                refreshTimmer.Start();
                RefreshClient();
                strConnectionStatus.Text = string.Format("Connected - {0}", _activeBinding);
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Disconnect()
        {
            try
            {
                using (new CursorKeeper(Cursors.WaitCursor))
                {

                    if (_infoClient != null && _infoClient.State == CommunicationState.Opened)
                    {
                        refreshTimmer.Stop();
                        _client.Close();
                        _client = null;
                        RefreshClient();
                    }
                }

                if (_client != null && _client.State == CommunicationState.Opened)
                {
                    _client.Close();
                    _client = null;
                }

                _connected = false;
                strConnectionStatus.Text = "Disconnected";
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        public SchedulerMain()
        {
            try
            {
                InitializeComponent();

                ToolStripItem stripItem = connectToolStripMenuItem.DropDownItems.Add(local_binding);
                stripItem.Click += ToolStripItemClick;


                ClientSection clientSection = ConfigurationManager.GetSection("system.serviceModel/client") as ClientSection;

                ChannelEndpointElementCollection endpointCollection = clientSection.ElementInformation.Properties[string.Empty].Value as ChannelEndpointElementCollection;

                if (endpointCollection != null)
                    foreach (ChannelEndpointElement endpointElement in endpointCollection)
                    {
                        if (endpointElement.Name != local_binding && endpointElement.Name != manage_binding)
                        {
                            ToolStripItem toolStripItem = connectToolStripMenuItem.DropDownItems.Add(endpointElement.Name);
                            toolStripItem.Click += ToolStripItemClick;

                        }
                    }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void ToolStripItemClick(object sender, EventArgs e)
        {
            ToolStripDropDownItem t = sender as ToolStripDropDownItem;
            if (t != null) _activeBinding = t.Text;
            Connect();
        }

        #region Service interface


        private void ExecuteRefreshJobLog()
        {
            if (!_connected) return;

            try
            {
                jobLogDataBindingSource.DataSource = _infoClient.GetJobLogData();
            }
            catch (Exception exception)
            {
                _connected = false;
                MessageBox.Show(exception.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExecuteGetExecutingJobs()
        {
            if (!_connected) return;

            try
            {
                _executingJobs = _infoClient.GetExecutingJobs();
                ExecutingJobsDataGridiew.DataSource = _executingJobs;
            }
            catch (Exception exception)
            {
                _connected = false;
                MessageBox.Show(exception.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExecuteRunJobNow()
        {
            if (!_connected) return;

            try
            {
                ServiceResponse response = _client.RunJobNow(txtJobName.Text, txtJobGroup.Text);

                if (!response.Success)
                {
                    MessageBox.Show(response.Error, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            catch (Exception exception)
            {
                _connected = false;
                MessageBox.Show(exception.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExecuteGetJobs()
        {
            if (!_connected) return;

            try
            {
                _jobs = _infoClient.GetJobs();

                jobsTree.Nodes.Clear();

                foreach (string jobGroupName in _jobs.OrderBy(c => c.Group).Select(c => c.Group).Distinct())
                {
                    TreeNode groupNode = new TreeNode(jobGroupName);
                    jobsTree.Nodes.Add(groupNode);

                    foreach (JobData jobData in _jobs.Where(c => c.Group == jobGroupName).OrderBy(c => c.Name))
                    {
                        TreeNode jobNode = new TreeNode(jobData.Name) { Tag = jobData };
                        groupNode.Nodes.Add(jobNode);

                        if (_selectedJobData != null)
                        {
                            if (_selectedJobData.Name == jobData.Name && _selectedJobData.Group == jobData.Group)
                            {
                                jobsTree.SelectedNode = jobNode;
                            }
                        }
                    }
                }

                FillJobList();
            }
            catch (Exception exception)
            {
                _connected = false;
                MessageBox.Show(exception.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void ExecuteSaveSchedule()
        {
            try
            {
                Dictionary<string, object> parms = ExtractParms(txtScheduleParm.Lines);

                Debug.Assert(parms != null);

                JobData jobData = _jobs.First(c => BuildJobDataDisplayName(c) == cmbScheduleJob.SelectedItem.ToString());

                ServiceResponse response;

                if (_isEditingSchedule)
                {
                    response = _client.ReScheduleJob(txtScheduleName.Text, txtScheduleGroup.Text, txtScheduleCron.Text, parms);
                }
                else
                {
                    response = _client.ScheduleJob(jobData.Name, jobData.Group, txtScheduleName.Text, txtScheduleGroup.Text, txtScheduleDescription.Text, txtScheduleCron.Text, parms);
                }

                if (!response.Success)
                {
                    MessageBox.Show(response.Error, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    btnScheduleNew.Text = Resources.SchedulerMain_BtnNewClick_New;
                    _isEditingJob = false;
                    _isAddingJob = false;
                    ExecuteGetSchedules();

                }
            }



            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void ExecuteGetSchedules()
        {

            if (!_connected) return;

            try
            {
                _schedules = _infoClient.GetSchedules();

                schedulesTree.Nodes.Clear();


                foreach (string scheduleGroup in _schedules.OrderBy(c => c.Group).Select(c => c.Group).Distinct())
                {
                    TreeNode groupNode = new TreeNode(scheduleGroup);

                    schedulesTree.Nodes.Add(groupNode);

                    foreach (ScheduledData scheduledData in _schedules.Where(c => c.Group == scheduleGroup).OrderBy(c => c.Name))
                    {
                        TreeNode scheduledNode = new TreeNode(scheduledData.Name) { Tag = scheduledData };
                        groupNode.Nodes.Add(scheduledNode);

                        if (_selectedScheduledData != null)
                        {
                            if (_selectedScheduledData.Group == scheduledData.Group && _selectedScheduledData.Name == scheduledData.Name)
                            {
                                schedulesTree.SelectedNode = scheduledNode;
                            }
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                _connected = false;
                MessageBox.Show(exception.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        public void ExecuteGetSummary()
        {
            if (!_connected) return;

            try
            {
                _serviceState = _infoClient.GetServiceState();
                status.Items.Clear();
                string[] strings = _serviceState.Summary.Split(_newLine, StringSplitOptions.RemoveEmptyEntries);
                status.Items.AddRange(strings);
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExecuteGetJobTypes()
        {
            if (!_connected) return;

            _jobTypes = _infoClient.GetJobTypes();
            jobTypesDataGridView.DataSource = _jobTypes;

            FillTypeList();

        }

        private void ExecuteDeleteJob()
        {
            if (!_connected) return;

            try
            {
                List<JobData> jobDatas = GetJobDataFromGroupNode(jobsTree.SelectedNode).ToList();

                if (jobDatas.Count == 1)
                {
                    JobData jobData = jobDatas.First();
                    ServiceResponse response = _client.RemoveJob(jobData.Name, jobData.Group);


                    if (!response.Success)
                    {
                        MessageBox.Show(response.Error, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        jobsTree.Nodes.Remove(jobsTree.SelectedNode);
                        _selectedJobData = null;
                    }
                }


            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExecuteSaveJob()
        {

            if (!_connected) return;

            try
            {
                Dictionary<string, object> parms = ExtractParms(txtJobParms.Lines);

                Debug.Assert(parms != null);


                ServiceResponse response = _client.AddJob(txtJobName.Text, txtJobGroup.Text, txtJobDescription.Text, txtJobType.Text, _isEditingJob, parms);

                if (!response.Success)
                {
                    MessageBox.Show(response.Error, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    _isEditingJob = false;
                    _isAddingJob = false;

                    btnJobNew.Text = btnJobNew.Text = Resources.SchedulerMain_BtnNewClick_New;
                    ExecuteGetJobs();
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExecuteStart()
        {
            try
            {
                ServiceResponse response = _client.StartScheduler();

                if (!response.Success)
                {
                    MessageBox.Show(response.Error, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    _connected = true;
                    RefreshClient();
                }
            }
            catch (Exception exception)
            {
                _connected = false;
                MessageBox.Show(exception.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExecuteShutdown()
        {

            if (!_connected) return;

            try
            {
                ServiceResponse serviceResponse = _client.StopScheduler();
                if (!serviceResponse.Success)
                {
                    MessageBox.Show(serviceResponse.Error);
                }
                else
                {
                    btnStart.Enabled = _activeBinding == local_binding;
                    ExecuteGetSummary();
                }
            }
            catch (Exception exception)
            {
                _connected = false;
                btnStart.Enabled = _activeBinding == local_binding;
                MessageBox.Show(exception.ToString());
            }
        }

        private void ExecuteRunScheduleNow(ScheduledData scheduledData)
        {

            if (!_connected) return;

            try
            {
                ServiceResponse response = _client.RunScheduleNow(scheduledData.Name, scheduledData.Group);

                if (!response.Success)
                {
                    MessageBox.Show(response.Error, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            catch (Exception exception)
            {
                _connected = false;
                MessageBox.Show(exception.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void ExecuteDeleteSchedule()
        {
            try
            {
                List<ScheduledData> scheduledData = GetScheduleDataFromGroupNode(schedulesTree.SelectedNode).ToList();

                if (scheduledData.Count == 1)
                {
                    ScheduledData data = scheduledData.First();
                    ServiceResponse response = _client.UnSchedule(data.Name, data.Group);

                    if (!response.Success)
                    {
                        MessageBox.Show(response.Error, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        schedulesTree.Nodes.Remove(schedulesTree.SelectedNode);
                        _selectedScheduledData = null;
                    }
                }

            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshClient()
        {


            _isEditingJob = false;
            _isAddingSchedule = false;
            _isAddingJob = false;
            _isEditingSchedule = false;

            _selectedJobData = null;
            _selectedScheduledData = null;

            ExecuteGetSummary();

            if (_serviceState != null && !_serviceState.IsShutdown)
            {
                ExecuteGetJobs();
                ExecuteGetJobTypes();
                ExecuteGetSchedules();
            }

            RefreshButtons();

            SetJobControls();
            SetScheduleControls();
        }

        private void RefreshButtons()
        {
            if (_serviceState != null && !_serviceState.IsShutdown)
            {
                btnStart.Enabled = _serviceState.IsShutdown || _serviceState.IsStandby && _activeBinding == local_binding;
                btnShutdown.Enabled = !_serviceState.IsShutdown && _activeBinding == local_binding;

                btnScheduleNew.Enabled = !_serviceState.IsShutdown && _activeBinding == local_binding;
                btnJobNew.Enabled = !_serviceState.IsShutdown && _activeBinding == local_binding;
            }
        }

        private void FillJobList()
        {
            cmbScheduleJob.Items.Clear();

            foreach (JobData jobData in _jobs)
            {
                cmbScheduleJob.Items.Add(BuildJobDataDisplayName(jobData));
            }
        }

        private void FillTypeList()
        {

            cmbJobTypeList.Items.Clear();

            foreach (JobType jobType in _jobTypes)
            {
                cmbJobTypeList.Items.Add(jobType.Description);
            }
        }

        private void SetJobControls()
        {

            txtJobName.Enabled = _isAddingJob && _activeBinding == local_binding;
            txtJobGroup.Enabled = _isAddingJob && _activeBinding == local_binding;
            cmbJobTypeList.Enabled = (_isAddingJob | _isEditingJob) && _activeBinding == local_binding;


            txtJobDescription.Enabled = (_isAddingJob | _isEditingJob) && _activeBinding == local_binding;
            jobDurable.Enabled = false;
            txtJobType.Enabled = (_isAddingJob | _isEditingJob) && _activeBinding == local_binding;


            btnRunNow.Enabled = _isEditingJob && _activeBinding == local_binding;
            btnDelete.Enabled = _isEditingJob && _activeBinding == local_binding;


            txtJobName.Text = _isEditingJob ? _selectedJobData.Name : string.Empty;
            txtJobGroup.Text = _isEditingJob ? _selectedJobData.Group : GetDefaultJobGroupName();
            txtJobDescription.Text = _isEditingJob ? _selectedJobData.Description : string.Empty;
            jobDurable.Checked = _isEditingJob ? _selectedJobData.Durable : false;
            txtJobType.Text = _isEditingJob ? _selectedJobData.JobType : string.Empty;

            if (_isEditingJob)
            {
                if (!string.IsNullOrEmpty(_selectedJobData.Parameters))
                {
                    txtJobParms.Lines = _selectedJobData.Parameters.Split(';');
                }
                else
                {
                    txtJobParms.Text = string.Empty;
                }
            }
            else
            {
                txtJobParms.Text = string.Empty;
            }

            btnSave.Enabled = (_isEditingJob | _isAddingJob) && _activeBinding == local_binding;
            btnRunNow.Enabled = (_isEditingJob) && _activeBinding == local_binding;
            btnDelete.Enabled = (_isEditingJob) && _activeBinding == local_binding;

        }

        private void SetScheduleControls()
        {


            txtScheduleGroup.Enabled = _isAddingSchedule && _activeBinding == local_binding;
            txtScheduleName.Enabled = _isAddingSchedule && _activeBinding == local_binding;
            cmbScheduleJob.Enabled = _isAddingSchedule && _activeBinding == local_binding;

            txtScheduleDescription.Enabled = (_isEditingSchedule | _isAddingSchedule) && _activeBinding == local_binding;
            txtScheduleCron.Enabled = (_isEditingSchedule | _isAddingSchedule) && _activeBinding == local_binding;
            txtScheduleParm.Enabled = (_isEditingSchedule | _isAddingSchedule) && _activeBinding == local_binding;

            txtScheduleName.Text = _isEditingSchedule ? _selectedScheduledData.Name : string.Empty;
            txtScheduleGroup.Text = _isEditingSchedule ? _selectedScheduledData.Group : GetDefaultScheduleGroupName();
            txtScheduleCron.Text = _isEditingSchedule ? _selectedScheduledData.Cron : "10 0/5 * * * ?";
            txtScheduleDescription.Text = _isEditingSchedule ? _selectedScheduledData.Description : string.Empty;

            if (_isEditingSchedule)
            {
                if (!string.IsNullOrWhiteSpace(_selectedScheduledData.Parameters))
                {
                    txtScheduleParm.Lines = _selectedScheduledData.Parameters.Split(';');
                }
                else
                {
                    txtScheduleParm.Text = string.Empty;
                }
            }
            else
            {
                txtScheduleParm.Text = string.Empty;
            }

            if (_isEditingSchedule)
            {
                string displayName = BuildJobDataDisplayName(_selectedScheduledData.JobGroup, _selectedScheduledData.JobName);

                int index = cmbScheduleJob.Items.IndexOf(displayName);

                cmbScheduleJob.SelectedIndex = index;
            }

            btnSaveSchedule.Enabled = (_isEditingSchedule | _isAddingSchedule) && _activeBinding == local_binding;
            btnRunScheduleNow.Enabled = _isEditingSchedule && _activeBinding == local_binding;
            btnDeleteSchedule.Enabled = _isEditingSchedule && _activeBinding == local_binding;
            btnSchClone.Enabled = _isEditingSchedule && _activeBinding == local_binding;
            scheduledTreeContextMenu.Enabled = _activeBinding == local_binding;

        }

        private string GetDefaultJobGroupName()
        {
            string name = "DEFAULT";

            TreeNode node = jobsTree.SelectedNode;

            if (node != null)
            {

                if (node.Tag == null)
                {
                    name = node.Text;
                }
                else
                {
                    JobData d = (JobData)node.Tag;
                    name = d.Group;
                }
            }


            return name;

        }

        private string GetDefaultScheduleGroupName()
        {
            string name = "DEFAULT";

            TreeNode node = schedulesTree.SelectedNode;

            if (node != null)
            {
                if (node.Tag == null)
                {
                    name = node.Text;
                }
                else
                {
                    ScheduledData d = (ScheduledData)node.Tag;
                    name = d.Group;
                }
            }


            return name;

        }

        #endregion

        #region Tree Handlers

        private void JobsTreeViewAfterSelect(object sender, TreeViewEventArgs e)
        {

            _selectedJobData = GetJobData(e.Node);

            if (_selectedJobData != null)
            {
                _isAddingJob = false;
                _isEditingJob = true;
            }
            else
            {
                _isAddingJob = false;
                _isEditingJob = false;

            }

            SetJobControls();
        }

        private void SchedulesTreeViewAfterSelect(object sender, TreeViewEventArgs e)
        {
            SelectScheduleNode(e.Node);
            SetScheduleControls();
        }

        private void SelectScheduleNode(TreeNode node)
        {
            _selectedScheduledData = GetScheduleData(node);

            if (_selectedScheduledData != null)
            {
                _isEditingSchedule = true;
                _isAddingSchedule = false;
            }
            else
            {
                _isEditingSchedule = false;
                _isAddingSchedule = false;
            }
        }

        #endregion

        #region Button Handlers

        protected void LinkLabel2LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            using (new CursorKeeper(Cursors.WaitCursor))
            {
                Process.Start("http://en.wikipedia.org/wiki/Cron");
            }
        }

        private void BtnRunNowClick(object sender, EventArgs e)
        {
            using (new CursorKeeper(Cursors.WaitCursor))
            {
                ExecuteRunJobNow();
                jobsTree.Focus();
            }
        }

        private void BtnDeleteJobClick(object sender, EventArgs e)
        {
            using (new CursorKeeper(Cursors.WaitCursor))
            {
                ExecuteDeleteJob();
                jobsTree.Focus();
            }
        }

        private void BtnNewJobClick(object sender, EventArgs e)
        {
            using (new CursorKeeper(Cursors.WaitCursor))
            {
                if (!_isAddingJob)
                {
                    btnJobNew.Text = Resources.SchedulerMain_BtnNewClick_Cancel;
                    _isEditingJob = false;
                    _isAddingJob = true;
                }
                else
                {
                    btnJobNew.Text = Resources.SchedulerMain_BtnNewClick_New;
                    _isEditingJob = false;
                    _isAddingJob = false;
                }

                SetJobControls();
            }
        }

        private void BtnSaveJobClick(object sender, EventArgs e)
        {

            using (new CursorKeeper(Cursors.WaitCursor))
            {
                ExecuteSaveJob();
                jobsTree.Focus();
            }
        }

        private void BtnRefreshRunningClick(object sender, EventArgs e)
        {

            using (new CursorKeeper(Cursors.WaitCursor))
            {
                try
                {
                    ExecuteGetExecutingJobs();
                }
                catch (Exception exception)
                {
                    MessageBox.Show(exception.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        private void CmbTypeListSelectedIndexChanged(object sender, EventArgs e)
        {
            JobType jobType = _jobTypes.FirstOrDefault(c => c.Description == (string)cmbJobTypeList.SelectedItem);

            if (jobType != null)
            {
                txtJobType.Text = jobType.AssemblyQualifiedTypeName;
            }
        }

        private void BtnDeleteScheduleClick(object sender, EventArgs e)
        {
            DeleteSchedule();
        }

        private void DeleteSchedule()
        {
            using (new CursorKeeper(Cursors.WaitCursor))
            {
                ExecuteDeleteSchedule();
                schedulesTree.Focus();
            }
        }

        private void BtnSaveScheduleClick(object sender, EventArgs e)
        {
            using (new CursorKeeper(Cursors.WaitCursor))
            {

                ExecuteSaveSchedule();
                schedulesTree.Focus();
            }
        }

        private void BtnNewScheduleClick(object sender, EventArgs e)
        {

            ExecuteScheduleNew();
        }

        private void ExecuteScheduleNew()
        {
            using (new CursorKeeper(Cursors.WaitCursor))
            {

                if (!_isAddingSchedule)
                {
                    btnScheduleNew.Text = Resources.SchedulerMain_BtnNewClick_Cancel;
                    _isAddingSchedule = true;
                    _isEditingSchedule = false;
                }
                else
                {
                    btnScheduleNew.Text = Resources.SchedulerMain_BtnNewClick_New;
                    _isAddingSchedule = false;
                    _isEditingSchedule = false;
                }

                SetScheduleControls();
            }
        }

        private void RefreshTimmerTick(object sender, EventArgs e)
        {

            ExecuteGetExecutingJobs();
            ExecuteGetSummary();
        }

        private void BtnStartClick(object sender, EventArgs e)
        {
            using (new CursorKeeper(Cursors.WaitCursor))
            {
                ExecuteStart();
            }
        }

        private void BtnShutdownClick(object sender, EventArgs e)
        {
            using (new CursorKeeper(Cursors.WaitCursor))
            {
                ExecuteShutdown();
            }


        }

        private void BtnRunScheduleNowClick(object sender, EventArgs e)
        {
            using (new CursorKeeper(Cursors.WaitCursor))
            {
                ExecuteRunScheduleNow(_selectedScheduledData);
                schedulesTree.Focus();
            }

        }

        private void BtnSchCloneClick(object sender, EventArgs e)
        {
            CloneSchedule();
        }

        private void CloneSchedule()
        {
            using (new CursorKeeper(Cursors.WaitCursor))
            {
                ScheduledData selectedScheduledData = _selectedScheduledData;
                ExecuteScheduleNew();
                txtScheduleGroup.Text = selectedScheduledData.Group;
                txtScheduleName.Text = string.Format("Copy Of {0}", selectedScheduledData.Name);
                txtScheduleCron.Text = selectedScheduledData.Cron;
                txtScheduleParm.Text = txtScheduleDescription.Text = selectedScheduledData.Description;

                if (!string.IsNullOrWhiteSpace(selectedScheduledData.Parameters))
                {
                    txtScheduleParm.Lines = selectedScheduledData.Parameters.Split(';');
                }
                else
                {
                    txtScheduleParm.Text = string.Empty;
                }

                txtJobName.Text = BuildJobDataDisplayName(selectedScheduledData.JobGroup, selectedScheduledData.JobGroup);
            }
        }

        #endregion

        #region Helpers

        private static JobData GetJobData(TreeNode node)
        {

            if (node == null)
            {
                return null;
            }

            if (node.Tag == null)
            {
                return null;
            }

            return (JobData)node.Tag;
        }

        private static ScheduledData GetScheduleData(TreeNode node)
        {
            if (node == null)
            {
                return null;
            }

            if (node.Tag == null)
            {
                return null;
            }

            return (ScheduledData)node.Tag;
        }

        private static IEnumerable<JobData> GetJobDataFromGroupNode(TreeNode node)
        {

            List<JobData> jobDatas = new List<JobData>();

            if (node != null)
            {
                if (node.Nodes.Count != 0)
                {
                    foreach (TreeNode treeNode in node.Nodes)
                    {
                        JobData data = (JobData)treeNode.Tag;
                        jobDatas.Add(data);
                    }
                }
                else
                {
                    if (node.Tag != null)
                    {
                        JobData data = (JobData)node.Tag;
                        jobDatas.Add(data);
                    }
                }
            }
            return jobDatas;
        }

        private static IEnumerable<ScheduledData> GetScheduleDataFromGroupNode(TreeNode node)
        {

            List<ScheduledData> scheduledDatas = new List<ScheduledData>();

            if (node != null)
            {
                if (node.Nodes.Count != 0)
                {
                    foreach (TreeNode treeNode in node.Nodes)
                    {
                        ScheduledData data = (ScheduledData)treeNode.Tag;
                        scheduledDatas.Add(data);
                    }
                }
                else
                {
                    if (node.Tag != null)
                    {
                        ScheduledData data = (ScheduledData)node.Tag;
                        scheduledDatas.Add(data);
                    }
                }
            }

            return scheduledDatas;
        }

        private static Dictionary<string, object> ExtractParms(IEnumerable<string> lines)
        {

            Dictionary<string, object> parms = new Dictionary<string, object>();

            if (lines != null)
            {

                foreach (string valueSet in lines)
                {
                    if (string.IsNullOrWhiteSpace(valueSet)) continue;

                    string fixedValue = valueSet.Replace("\n", string.Empty);

                    string[] tokens = fixedValue.Split(new[] { '=' }, StringSplitOptions.RemoveEmptyEntries);

                    if (tokens.Length != 2)
                    {
                        throw new FormatException("parameters not formated properly");
                    }

                    parms.Add(tokens[VALUE_SET_NAME_INDEX], tokens[VALUE_VALUE_NAME_INDEX]);
                }
            }
            return parms;
        }

        private static string BuildJobDataDisplayName(JobData data)
        {
            return BuildJobDataDisplayName(data.Group, data.Name);
        }

        private static string BuildJobDataDisplayName(string groupName, string jobName)
        {
            return string.Format("{0} > {1}", groupName, jobName);
        }

        #endregion

        #region Private Methods

        private void SchedulesTreeMouseDown(object sender, MouseEventArgs e)
        {

            if (e.Button == MouseButtons.Right)
            {
                schedulesTree.SelectedNode = schedulesTree.GetNodeAt(e.X, e.Y);
            }
        }

        private void SchedulesTreeBeforeSelect(object sender, TreeViewCancelEventArgs e)
        {
            if (_isAddingJob)
            {
                e.Cancel = true;
                MessageBox.Show("Please cance pending change", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void JobsTreeBeforeSelect(object sender, TreeViewCancelEventArgs e)
        {
            if (_isAddingJob)
            {
                e.Cancel = true;
                MessageBox.Show("Please cance pending change", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BtnRefreshStatusClick(object sender, EventArgs e)
        {
            RefreshClient();
        }

        private void ExitToolStripMenuItemClick(object sender, EventArgs e)
        {
            Disconnect();
            Close();
        }

        private void MainTabSelectedIndexChanged(object sender, EventArgs e)
        {


            switch (mainTab.SelectedIndex)
            {

                case SCHEDULES_TAB_INDEX:
                    ExecuteGetSchedules();
                    schedulesTree.Focus();
                    break;
                case JOBS_TAB_INDEX:
                    ExecuteGetJobs();
                    jobsTree.Focus();
                    break;
                case EXECUTING_JOBS_TAB_INDEX:
                    ExecuteGetExecutingJobs();
                    break;
                case REGISTERED_JOB_TYPES_TAB_INDEX:
                    ExecuteGetJobTypes();
                    break;
                case JOB_LOG_TAB_INDEX:
                    ExecuteRefreshJobLog();
                    break;
                default:
                    break;
            }
        }

        private void ConnectToolStripMenuItemClick(object sender, EventArgs e)
        {
            Connect();
        }

        private void DisconnectToolStripMenuItemClick(object sender, EventArgs e)
        {
            Disconnect();
        }

        private void RefreshToolStripMenuItemClick(object sender, EventArgs e)
        {
            RefreshClient();
        }

        private void RunToolStripMenuItemClick(object sender, EventArgs e)
        {
            using (new CursorKeeper(Cursors.WaitCursor))
            {

                if (schedulesTree.SelectedNode.Nodes.Count != 0)
                {
                    foreach (ScheduledData scheduledData in from TreeNode node in schedulesTree.SelectedNode.Nodes select GetScheduleData(node))
                    {
                        ExecuteRunScheduleNow(scheduledData);
                    }
                }
                else
                {
                    ExecuteRunScheduleNow(_selectedScheduledData);
                }

                schedulesTree.Focus();
            }
        }

        private void CloneScheduleToolStripMenuItemClick(object sender, EventArgs e)
        {

            CloneSchedule();
        }

        private void DeleteScheduleToolStripMenuItemClick(object sender, EventArgs e)
        {
            DeleteSchedule();
        }

        private void BtnRefreshJobLogClick(object sender, EventArgs e)
        {
            using (new CursorKeeper(Cursors.WaitCursor))
            {
                ExecuteRefreshJobLog();
            }
        }

        private void JobLogDataGridCellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            using (JobLogView d = new JobLogView(jobLogDataBindingSource.Current))
            {
                d.ShowDialog(this);
            }

        }

        private void exportToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            try
            {
                JobData[] jobDatas = _infoClient.GetJobs();
                ScheduledData[] scheduledDatas = _infoClient.GetSchedules();

                Export export = new Export();
                export.Jobs = jobDatas;
                export.Schedules = scheduledDatas;

                SaveFileDialog saveFileDialog1 = new SaveFileDialog();
                saveFileDialog1.CheckFileExists = false;
                saveFileDialog1.Filter = "xml files (*.xml)|*.xml|All files (*.*)|*.*";
                saveFileDialog1.FilterIndex = 2;
                saveFileDialog1.RestoreDirectory = true;
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(Export));
                    TextWriter textWriter = new StreamWriter(saveFileDialog1.FileName);
                    serializer.Serialize(textWriter, export);
                    textWriter.Close();
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void importToolStripMenuItem_Click(object sender, EventArgs e)
        {

            try
            {


                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.CheckFileExists = false;
                openFileDialog.Filter = "xml files (*.xml)|*.xml|All files (*.*)|*.*";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(Export));
                    TextReader textReader = new StreamReader(openFileDialog.FileName);
                    Export deserialize = (Export)serializer.Deserialize(textReader);
                    textReader.Close();

                    foreach (JobData jobData in deserialize.Jobs)
                    {

                        Dictionary<string, object> jobParms;
                        if (jobData.Parameters != null)
                        {
                            string[] jobParmTokens = jobData.Parameters.Split(';');
                            jobParms = ExtractParms(jobParmTokens);
                        }
                        else
                        {
                            jobParms = new Dictionary<string, object>();
                        }

                        _client.AddJob(jobData.Name, jobData.Group, jobData.Description, jobData.JobType, true, jobParms);
                    }


                    foreach (ScheduledData scheduledData in deserialize.Schedules)
                    {

                        Dictionary<string, object> scheduleParms;

                        if (scheduledData.Parameters != null)
                        {
                            string[] scheduleParmTokens = scheduledData.Parameters.Split(';');

                            scheduleParms = ExtractParms(scheduleParmTokens);
                        }
                        else
                        {
                            scheduleParms = new Dictionary<string, object>();
                        }

                        _client.ScheduleJob(scheduledData.JobName, scheduledData.JobGroup, scheduledData.Name, scheduledData.Group, scheduledData.Description, scheduledData.Cron, scheduleParms);
                    }

                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Application Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        #endregion

    }
}
