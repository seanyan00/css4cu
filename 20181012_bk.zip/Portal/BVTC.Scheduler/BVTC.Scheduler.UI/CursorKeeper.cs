﻿using System;
using System.Windows.Forms;

namespace BVTC.Scheduler.UI
{
    public class CursorKeeper : IDisposable
    {
        private readonly Cursor _originalCursor;
        private bool _isDisposed;

        public CursorKeeper(Cursor newCursor)
        {
            _originalCursor = Cursor.Current;
            Cursor.Current = newCursor;
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_isDisposed)
            {
                if (disposing)
                {
                    Cursor.Current = _originalCursor;
                }
            }
            _isDisposed = true;

        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}